// sync/companies.js — companies
        function syncCompAddMoneyPlaceholders() {
            var usd = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
            var unit = usd ? '$' : 'IQD';
            var ob = document.getElementById('c-opening-balance');
            var dl = document.getElementById('c-debt-limit');
            if (ob) {
                ob.placeholder = 'دەینی کەڤن (' + unit + ')';
            }
            if (dl) {
                dl.placeholder = 'سنووری قەرز (' + unit + ')';
            }
            if (typeof syncDuhokPaperUsdInputHints === 'function') syncDuhokPaperUsdInputHints();
        }

        function saveCompany() {
            if (!checkPermission('companies_manage', 'زێدەکرنا کۆمپانیێ')) return;
            const name = (document.getElementById('c-name')?.value || '').trim();
            const phone = (document.getElementById('c-phone')?.value || '').trim();
            const addr = (document.getElementById('c-addr')?.value || '').trim();
            const openingBalance = parseCcEditMoneyField(document.getElementById('c-opening-balance')?.value);
            const debtLimit = parseCcEditMoneyField(document.getElementById('c-debt-limit')?.value);
            const payTerm = (typeof readProfilePaymentTerm === 'function')
                ? readProfilePaymentTerm('c-payment-term-value', 'c-payment-term-unit')
                : { value: 0, unit: 'day' };
            if (!name) return showToast('⚠️ هیڤیە ناڤێ کۆمپانیێ بنڤیسە!', 'error');
            if (name.length < 2) return showToast('⚠️ ناڤ گەلەک یێ کورتە!', 'error');

            const formData = new FormData();
            formData.append('action', 'save_company');
            formData.append('name', name);
            formData.append('phone', phone);
            formData.append('address', addr);
            formData.append('opening_balance', openingBalance);
            formData.append('debt_limit', debtLimit);
            formData.append('payment_term_value', payTerm.value);
            formData.append('payment_term_unit', payTerm.unit);

            fetch('?action=save_company', { method: 'POST', body: formData, credentials: 'same-origin' })
            .then(function(res) { return res.json().catch(function() { throw new Error('وەڵامێ سێرڤەرێ نادروستە'); }); })
            .then(function(data) {
                if (data.status === 'success') {
                    const obSt = (typeof debtFormAmountToStoredIqd === 'function') ? debtFormAmountToStoredIqd(openingBalance) : openingBalance;
                    const dlSt = (typeof debtFormAmountToStoredIqd === 'function') ? debtFormAmountToStoredIqd(debtLimit) : debtLimit;
                    const bal = (typeof data.balance !== 'undefined') ? (parseFloat(data.balance) || 0) : obSt;
                    if (!db.companies) db.companies = [];
                    db.companies.push({ id: data.id, name: name, phone: phone, address: addr, opening_balance: obSt, debt_limit: dlSt, balance: bal, payment_term_value: payTerm.value, payment_term_unit: payTerm.unit });
                    document.getElementById('c-name').value = '';
                    document.getElementById('c-phone').value = '';
                    document.getElementById('c-addr').value = '';
                    const elOB = document.getElementById('c-opening-balance'); if (elOB) elOB.value = '0';
                    const elDL = document.getElementById('c-debt-limit'); if (elDL) elDL.value = '0';
                    const elPTV = document.getElementById('c-payment-term-value'); if (elPTV) elPTV.value = '0';
                    const elPTU = document.getElementById('c-payment-term-unit'); if (elPTU) elPTU.value = 'day';
                    renderCompanies();
                    if (typeof window.refreshEntityDatalists === 'function') window.refreshEntityDatalists();
                    if (typeof saveDB === 'function') saveDB();
                    if (typeof showToast === 'function') showToast('✅ کۆمپانیا هاتە تۆمارکردن.');
                } else {
                    showToast('❌ ' + (data.message || 'هەڵە د تۆمارکرنێ دا.'), 'error');
                }
            })
            .catch(function(err) { if (typeof showToast === 'function') showToast('❌ هەڵە: ' + (err.message || 'پەیوەندی'), 'error'); });
        }

        window.saveCompany = saveCompany;

        window.companiesActiveTab = window.companiesActiveTab || 'purchase';

        function setCompaniesTab(which) {
            window.companiesActiveTab = which === 'manufacturers' ? 'manufacturers' : 'purchase';
            var purchasePanel = document.getElementById('companies-purchase-panel');
            var mfrPanel = document.getElementById('companies-manufacturers-panel');
            var btnPurchase = document.getElementById('companies-tab-purchase');
            var btnMfr = document.getElementById('companies-tab-manufacturers');
            var shortcut = document.getElementById('companies-purchase-shortcut');
            var printBtn = document.getElementById('companies-print-btn');
            if (purchasePanel) purchasePanel.style.display = companiesActiveTab === 'purchase' ? '' : 'none';
            if (mfrPanel) mfrPanel.style.display = companiesActiveTab === 'manufacturers' ? '' : 'none';
            if (btnPurchase) {
                btnPurchase.classList.toggle('btn-brand', companiesActiveTab === 'purchase');
                btnPurchase.classList.toggle('btn-info', companiesActiveTab !== 'purchase');
            }
            if (btnMfr) {
                btnMfr.classList.toggle('btn-brand', companiesActiveTab === 'manufacturers');
                btnMfr.classList.toggle('btn-info', companiesActiveTab !== 'manufacturers');
            }
            if (shortcut) shortcut.style.display = companiesActiveTab === 'purchase' ? '' : 'none';
            if (printBtn) printBtn.style.display = companiesActiveTab === 'purchase' ? '' : 'none';
            if (companiesActiveTab === 'purchase') renderCompanies();
            else renderManufacturers();
            if (typeof window.applyI18nSubtree === 'function') {
                var root = document.getElementById('view-companies');
                if (root) window.applyI18nSubtree(root);
            }
        }
        window.setCompaniesTab = setCompaniesTab;

        function renderCompaniesView() {
            setCompaniesTab(window.companiesActiveTab || 'purchase');
        }
        window.renderCompaniesView = renderCompaniesView;

        function resetManufacturerEditForm() {
            var idEl = document.getElementById('mfr-edit-id');
            var nameEl = document.getElementById('mfr-name');
            var phoneEl = document.getElementById('mfr-phone');
            var noteEl = document.getElementById('mfr-note');
            var saveBtn = document.getElementById('mfr-save-btn');
            var cancelBtn = document.getElementById('mfr-cancel-edit-btn');
            if (idEl) idEl.value = '';
            if (nameEl) nameEl.value = '';
            if (phoneEl) phoneEl.value = '';
            if (noteEl) noteEl.value = '';
            if (saveBtn) {
                var T = (typeof t === 'function' ? t : function(k) { return k; });
                saveBtn.innerHTML = '<i class="fas fa-plus"></i> ' + (T('debt_add_btn') !== 'debt_add_btn' ? T('debt_add_btn') : 'زێدەکرن');
            }
            if (cancelBtn) cancelBtn.classList.add('hidden');
        }
        window.cancelManufacturerEdit = resetManufacturerEditForm;

        function applyManufacturerRenameInLocalDb(oldName, newName) {
            if (!oldName || !newName || oldName === newName || !db) return;
            (db.products || []).forEach(function(p) {
                if (p && String(p.manufacturer || '') === oldName) p.manufacturer = newName;
            });
        }

        function parseManufacturerApiResponse(res) {
            return res.text().then(function (t) {
                try {
                    return JSON.parse(t);
                } catch (e) {
                    throw new Error(t.indexOf('<!DOCTYPE') !== -1 || (t && t.charAt(0) === '<')
                        ? 'سێرڤەر وەڵامێ HTML گەڕاندەوە.'
                        : 'وەڵامێ سێرڤەر نادروستە');
                }
            });
        }

        function saveManufacturer() {
            if (!checkPermission('companies_manage', 'زێدەکرنا کۆمپانیا دروستکەر')) return;
            var editId = parseInt(document.getElementById('mfr-edit-id')?.value, 10) || 0;
            if (editId <= 0 && typeof canAddManufacturer === 'function' && !canAddManufacturer()) {
                if (typeof showManufacturerSlotPurchasePopup === 'function') showManufacturerSlotPurchasePopup();
                return;
            }
            var name = (document.getElementById('mfr-name')?.value || '').trim();
            var phone = (document.getElementById('mfr-phone')?.value || '').trim();
            var note = (document.getElementById('mfr-note')?.value || '').trim();
            if (!name) return showToast('⚠️ هیڤیە ناوی کۆمپانیا دروستکەر بنووسە!', 'error');
            if (name.length < 2) return showToast('⚠️ ناڤ گەلەک کورتە!', 'error');

            var formData = new FormData();
            formData.append('action', editId > 0 ? 'update_manufacturer' : 'save_manufacturer');
            if (editId > 0) formData.append('id', String(editId));
            formData.append('name', name);
            formData.append('phone', phone);
            formData.append('note', note);

            fetch('?action=' + (editId > 0 ? 'update_manufacturer' : 'save_manufacturer'), { method: 'POST', body: formData, credentials: 'same-origin' })
            .then(parseManufacturerApiResponse)
            .then(function(data) {
                if (data.status !== 'success') {
                    if (data.reason === 'manufacturer_slot_limit' && typeof showManufacturerSlotPurchasePopup === 'function') {
                        showManufacturerSlotPurchasePopup();
                    }
                    showToast('❌ ' + (data.message || 'هەڵە'), 'error');
                    return;
                }
                if (!db.manufacturers) db.manufacturers = [];
                if (editId > 0) {
                    var m = db.manufacturers.find(function(x) { return x && String(x.id) === String(editId); });
                    var oldName = m ? (m.name || '') : (data.old_name || '');
                    if (m) {
                        m.name = name;
                        m.phone = phone;
                        m.note = note;
                    }
                    applyManufacturerRenameInLocalDb(oldName, name);
                    showToast('✅ کۆمپانیا دروستکەر نوێکرایەوە.');
                } else {
                    db.manufacturers.push({ id: data.id, name: name, phone: phone, note: note });
                    showToast('✅ کۆمپانیا دروستکەر هاتە تۆمارکردن.');
                }
                resetManufacturerEditForm();
                renderManufacturers();
                if (typeof renderProducts === 'function') renderProducts();
                if (typeof saveDB === 'function') saveDB();
            })
            .catch(function(err) { if (typeof showToast === 'function') showToast('❌ هەڵە: ' + (err.message || 'پەیوەندی'), 'error'); });
        }
        window.saveManufacturer = saveManufacturer;

        function refreshProductManufacturerSelect(selectedName) {
            var mfrSelect = document.getElementById('p-manufacturer');
            if (!mfrSelect || !db) return;
            var phKey = 'product_form_manufacturer_placeholder';
            var phOpt = (typeof t === 'function' && t(phKey) !== phKey) ? t(phKey) : 'هەلبژێرە...';
            mfrSelect.innerHTML = '<option value="">' + escapeHtml(phOpt) + '</option>';
            (db.manufacturers || []).forEach(function (m) {
                if (!m || !m.name) return;
                mfrSelect.innerHTML += '<option value="' + escapeHtml(m.name) + '">' + escapeHtml(m.name) + '</option>';
            });
            if (selectedName) mfrSelect.value = selectedName;
        }
        window.refreshProductManufacturerSelect = refreshProductManufacturerSelect;

        function saveQuickManufacturer(data) {
            var name = String(data && data.name || '').trim();
            var phone = String(data && data.phone || '').trim();
            var note = String(data && data.note || '').trim();
            if (!name) return;
            if (name.length < 2) {
                if (typeof showToast === 'function') showToast('⚠️ ناڤ گەلەک کورتە!', 'error');
                return;
            }
            if ((db.manufacturers || []).some(function (m) { return m && String(m.name).toLowerCase() === name.toLowerCase(); })) {
                refreshProductManufacturerSelect(name);
                if (typeof showToast === 'function') showToast('⚠️ ئەڤ کۆمپانیایە پێشتر هەیە — هەڵبژێردرا.', false);
                return;
            }
            var formData = new FormData();
            formData.append('action', 'save_manufacturer');
            formData.append('name', name);
            formData.append('phone', phone);
            formData.append('note', note);
            fetch('?action=save_manufacturer', { method: 'POST', body: formData, credentials: 'same-origin' })
                .then(parseManufacturerApiResponse)
                .then(function (data) {
                    if (!data || data.status !== 'success') {
                        if (data && data.reason === 'manufacturer_slot_limit' && typeof showManufacturerSlotPurchasePopup === 'function') {
                            showManufacturerSlotPurchasePopup();
                        }
                        if (typeof showToast === 'function') showToast('❌ ' + ((data && data.message) ? data.message : 'نەشیا کۆمپانیا زێدە بکەت!'), 'error');
                        return;
                    }
                    if (!db.manufacturers) db.manufacturers = [];
                    db.manufacturers.push({ id: data.id, name: name, phone: phone, note: note });
                    refreshProductManufacturerSelect(name);
                    var wmsMfr = document.getElementById('wms-filter-manufacturer');
                    if (wmsMfr && typeof renderWarehouse === 'function') {
                        var prev = wmsMfr.value;
                        wmsMfr.innerHTML = '<option value="">' + (typeof t === 'function' ? t('wh_filter_all') : 'هەموو') + '</option>';
                        (db.manufacturers || []).forEach(function (m) {
                            if (!m || !m.name) return;
                            wmsMfr.innerHTML += '<option value="' + escapeHtml(m.name) + '">' + escapeHtml(m.name) + '</option>';
                        });
                        if (prev) wmsMfr.value = prev;
                    }
                    if (typeof window.refreshEntityDatalists === 'function') window.refreshEntityDatalists();
                    if (typeof saveDB === 'function') saveDB();
                    if (typeof showToast === 'function') showToast('✅ کۆمپانیا دروستکەر هاتە زێدەکرن!');
                })
                .catch(function (err) {
                    if (typeof showToast === 'function') showToast('❌ هەڵە: ' + (err && err.message ? err.message : 'پەیوەندی'), 'error');
                });
        }

        window.quickAddManufacturer = function () {
            if (typeof checkPermission === 'function' && !checkPermission('companies_manage', 'زێدەکرنا کۆمپانیا دروستکەر')) return;
            if (typeof canAddManufacturer === 'function' && !canAddManufacturer()) {
                if (typeof showManufacturerSlotPurchasePopup === 'function') showManufacturerSlotPurchasePopup();
                return;
            }
            if (typeof openPosEntityNamePrompt === 'function') {
                openPosEntityNamePrompt({
                    entityType: 'manufacturer',
                    icon: 'fa-industry',
                    iconTone: 'manufacturer',
                    onConfirm: saveQuickManufacturer
                });
                return;
            }
            var name = prompt('ناڤێ کۆمپانیا دروستکەرێ نوێ بنووسە:');
            if (!name || !String(name).trim()) return;
            saveQuickManufacturer({ name: String(name).trim(), phone: '', note: '' });
        };

        function editManufacturer(id) {
            if (!db.manufacturers) return;
            var m = db.manufacturers.find(function(x) { return x && String(x.id) === String(id); });
            if (!m) return;
            var idEl = document.getElementById('mfr-edit-id');
            var nameEl = document.getElementById('mfr-name');
            var phoneEl = document.getElementById('mfr-phone');
            var noteEl = document.getElementById('mfr-note');
            var saveBtn = document.getElementById('mfr-save-btn');
            var cancelBtn = document.getElementById('mfr-cancel-edit-btn');
            if (idEl) idEl.value = String(m.id);
            if (nameEl) nameEl.value = m.name || '';
            if (phoneEl) phoneEl.value = m.phone || '';
            if (noteEl) noteEl.value = m.note || '';
            if (saveBtn) {
                var T = (typeof t === 'function' ? t : function(k) { return k; });
                saveBtn.innerHTML = '<i class="fas fa-save"></i> ' + (T('btn_save') !== 'btn_save' ? T('btn_save') : 'پاراستن');
            }
            if (cancelBtn) cancelBtn.classList.remove('hidden');
            if (nameEl) nameEl.focus();
        }
        window.editManufacturer = editManufacturer;

        function deleteManufacturer(id) {
            if (!checkPermission('companies_manage', 'ژێبرنا کۆمپانیا دروستکەر')) return;
            if (!confirm('دڵنیای لە ژێبرنی ئەم کۆمپانیا دروستکەرە؟\nئایتمەکان دەبنە «بێ کۆمپانیا دروستکەر».')) return;
            var formData = new FormData();
            formData.append('action', 'delete_manufacturer');
            formData.append('id', String(id));
            fetch('?action=delete_manufacturer', { method: 'POST', body: formData, credentials: 'same-origin' })
            .then(function(res) { return res.json(); })
            .then(function(data) {
                if (data.status !== 'success') {
                    showToast('❌ ' + (data.message || 'هەڵە'), 'error');
                    return;
                }
                var removed = (db.manufacturers || []).find(function(x) { return x && String(x.id) === String(id); });
                if (removed && removed.name) {
                    (db.products || []).forEach(function(p) {
                        if (p && String(p.manufacturer || '') === removed.name) p.manufacturer = '';
                    });
                }
                db.manufacturers = (db.manufacturers || []).filter(function(x) { return x && String(x.id) !== String(id); });
                renderManufacturers();
                if (typeof renderProducts === 'function') renderProducts();
                if (typeof saveDB === 'function') saveDB();
                showToast('✅ سڕایەوە.');
            })
            .catch(function() { showToast('❌ هەڵە لە پەیوەندیدا', 'error'); });
        }
        window.deleteManufacturer = deleteManufacturer;

        function renderManufacturers() {
            if (!db.manufacturers) db.manufacturers = [];
            var container = document.getElementById('manufacturers-grid');
            if (!container) return;
            var T = (typeof t === 'function' ? t : function(k) { return k; });
            var esc = (typeof escapeHtml === 'function' ? escapeHtml : function(s) { return String(s == null ? '' : s); });

            var prevSearch = '';
            try {
                var _si = document.getElementById('mfr-search-input');
                if (_si) prevSearch = _si.value;
            } catch (e0) {}

            var list = [...db.manufacturers].sort(function(a, b) {
                return String(a.name || '').localeCompare(String(b.name || ''), 'ku', { sensitivity: 'base' });
            });
            var totalProducts = 0;
            var slotsUsed = (typeof getPosManufacturerSlotsUsed === 'function') ? getPosManufacturerSlotsUsed() : list.length;
            var slotsMax = (typeof getPosMaxManufacturersAllowed === 'function') ? getPosMaxManufacturersAllowed() : 9999;
            var isProMfr = slotsMax >= 9999;
            list.forEach(function(m) {
                m._itemCount = (db.products || []).filter(function(p) {
                    return p && String(p.manufacturer || '').trim() === String(m.name || '').trim();
                }).length;
                totalProducts += m._itemCount;
            });

            var controlsHtml = '<div style="grid-column:1/-1;display:flex;gap:10px;margin-bottom:15px;flex-wrap:wrap;">' +
                '<div style="flex:1;position:relative;">' +
                '<i class="fas fa-search" style="position:absolute;right:15px;top:15px;color:var(--text-muted);"></i>' +
                '<input type="text" id="mfr-search-input" class="input-std" placeholder="' + esc(T('mfr_search_ph') !== 'mfr_search_ph' ? T('mfr_search_ph') : 'گەڕان لە دروستکەر…') + '" style="margin:0;padding-right:40px;" onkeyup="renderManufacturers()">' +
                '</div></div>';

            var html = '<div style="grid-column:1/-1;display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:15px;margin-bottom:20px;">' +
                '<div class="card mfr-stat-card" style="padding:15px;margin:0;">' +
                '<h4 style="color:#a5b4fc;margin:0 0 5px 0;"><i class="fas fa-industry" style="margin-left:6px;"></i> ' + esc(T('mfr_count_title') !== 'mfr_count_title' ? T('mfr_count_title') : 'ژمارەی دروستکەر') + '</h4>' +
                '<h1 style="color:#818cf8;margin:0;">' + list.length + (isProMfr ? '' : (' <small style="font-size:0.72rem;color:var(--text-muted);">/ ' + slotsMax + '</small>')) + '</h1>' +
                (!isProMfr ? '<small style="color:var(--text-muted);">' + esc(T('mfr_slots_hint') !== 'mfr_slots_hint' ? T('mfr_slots_hint') : 'یەکجار $50 = تا ١٠٠ کۆمپانیا · Pro = بێسنوور') + '</small>' : '') +
                '</div>' +
                '<div class="card mfr-stat-card" style="padding:15px;margin:0;">' +
                '<h4 style="color:var(--text-muted);margin:0 0 5px 0;"><i class="fas fa-box" style="margin-left:6px;color:var(--brand);"></i> ' + esc(T('mfr_linked_products') !== 'mfr_linked_products' ? T('mfr_linked_products') : 'ئایتمە پەیوەستەکان') + '</h4>' +
                '<h1 style="color:var(--brand);margin:0;">' + totalProducts + '</h1></div></div>' + controlsHtml;

            if (!isProMfr && slotsUsed >= slotsMax) {
                var packUnlocked = (typeof isManufacturerPackUnlocked === 'function') && isManufacturerPackUnlocked();
                var atPackCap = packUnlocked && slotsMax >= ((typeof POS_MFR_PACK_MAX !== 'undefined') ? POS_MFR_PACK_MAX : 100);
                html += '<div class="card" style="grid-column:1/-1;padding:14px 16px;margin-bottom:12px;border:1px dashed rgba(245,158,11,0.45);background:rgba(245,158,11,0.08);display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;">' +
                    '<div style="font-size:0.88rem;color:var(--text-muted);"><i class="fas fa-lock" style="color:#fbbf24;"></i> ' + esc(typeof manufacturerSlotPurchasePopupMessage === 'function' ? manufacturerSlotPurchasePopupMessage() : '') + '</div>' +
                    (atPackCap ? '' : ('<button type="button" class="btn btn-sm btn-warning" onclick="showManufacturerSlotPurchasePopup()"><i class="fas fa-key"></i> ' + esc(T('mfr_slot_buy_btn') !== 'mfr_slot_buy_btn' ? T('mfr_slot_buy_btn') : 'چالاککردن ($50)') + '</button>')) +
                    '</div>';
            }

            var searchTerm = (prevSearch || '').toLowerCase();
            var filtered = list.filter(function(m) {
                return (m.name || '').toLowerCase().includes(searchTerm) ||
                    (m.phone && m.phone.includes(searchTerm)) ||
                    (m.note && m.note.toLowerCase().includes(searchTerm));
            });

            if (!filtered.length) {
                html += '<div class="card" style="grid-column:1/-1;padding:24px;text-align:center;color:var(--text-muted);">' +
                    '<i class="fas fa-industry" style="font-size:2rem;opacity:0.35;margin-bottom:10px;display:block;"></i>' +
                    esc(T('mfr_empty') !== 'mfr_empty' ? T('mfr_empty') : 'هیچ کۆمپانیایەکی دروستکەر نییە.') + '</div>';
            } else {
                html += filtered.map(function(m) {
                    var itemCount = m._itemCount || 0;
                    var phoneDisp = m.phone ? esc(m.phone) : '—';
                    return '<div class="card mfr-entity-card" style="padding:0;overflow:hidden;border:1px solid color-mix(in srgb,#6366f1 22%,var(--border));transition:transform 0.2s;">' +
                        '<div style="padding:15px;display:flex;justify-content:space-between;align-items:flex-start;gap:10px;background:linear-gradient(135deg,rgba(99,102,241,0.12),transparent);">' +
                        '<div style="display:flex;align-items:flex-start;gap:10px;min-width:0;">' +
                        '<div style="width:52px;height:52px;border-radius:50%;background:rgba(99,102,241,0.2);color:#818cf8;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:1.35rem;"><i class="fas fa-industry"></i></div>' +
                        '<div style="min-width:0;"><h3 style="margin:0;font-size:1rem;">' + esc(m.name) + '</h3>' +
                        '<small style="color:var(--text-muted);display:block;"><i class="fas fa-phone" style="margin-left:4px;"></i> ' + phoneDisp + '</small>' +
                        (m.note ? '<small style="color:var(--text-muted);display:block;margin-top:4px;"><i class="fas fa-sticky-note" style="margin-left:4px;"></i> ' + esc(m.note) + '</small>' : '') +
                        '<span style="background:rgba(99,102,241,0.12);padding:2px 8px;border-radius:6px;font-size:0.75rem;color:#a5b4fc;margin-top:6px;display:inline-block;"><i class="fas fa-box"></i> ' + itemCount + ' ' + esc(T('comp_items_unit') !== 'comp_items_unit' ? T('comp_items_unit') : 'ئایتم') + '</span></div></div></div>' +
                        '<div class="page-action-row" style="padding:10px;display:flex;gap:5px;background:var(--card);">' +
                        '<button type="button" class="btn btn-sm btn-warning" style="flex:1;" onclick="editManufacturer(' + m.id + ')"><i class="fas fa-edit"></i> ' + esc(T('debt_btn_edit') !== 'debt_btn_edit' ? T('debt_btn_edit') : 'دەستکاری') + '</button>' +
                        '<button type="button" class="btn btn-sm btn-danger" onclick="deleteManufacturer(' + m.id + ')"><i class="fas fa-trash"></i></button></div></div>';
                }).join('');
            }

            container.innerHTML = html;
            try {
                var nSi = document.getElementById('mfr-search-input');
                if (nSi) nSi.value = prevSearch;
            } catch (e1) {}
            if (typeof window.applyI18nSubtree === 'function') {
                var root = document.getElementById('view-companies');
                if (root) window.applyI18nSubtree(root);
            }
        }
        window.renderManufacturers = renderManufacturers;

        // --- CUSTOMER / COMPANY EDIT MODAL ---
        function parseCcEditMoneyField(raw) {
            var kind = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD') ? 'usd' : 'iqd';
            if (typeof parseAmountInput === 'function') {
                return Math.max(0, parseAmountInput(raw, kind));
            }
            return Math.max(0, parseFloat(String(raw == null ? '' : raw).replace(/,/g, '')) || 0);
        }

        function syncCcEditMoneyFieldLabels() {
            var usd = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
            var unit = usd ? '$' : 'IQD';
            var obLbl = document.querySelector('label[for="cc-edit-opening-balance"]');
            var dlLbl = document.querySelector('label[for="cc-edit-debt-limit"]');
            if (obLbl) obLbl.textContent = 'دەینی کەڤن (Opening Balance) — ' + unit;
            if (dlLbl) dlLbl.textContent = 'سنووری قەرز (Debt Limit) — ' + unit;
            var obIn = document.getElementById('cc-edit-opening-balance');
            var dlIn = document.getElementById('cc-edit-debt-limit');
            if (typeof syncDuhokPaperUsdInputHints === 'function') syncDuhokPaperUsdInputHints();
        }

        function applyCompanyRenameInLocalDb(oldName, newName) {
            if (!oldName || !newName || oldName === newName || !db) return;
            (db.supplies || []).forEach(function(s) {
                if (s && String(s.company || '') === oldName) s.company = newName;
            });
            (db.products || []).forEach(function(p) {
                if (p && String(p.supplier || '') === oldName) p.supplier = newName;
            });
            (db.purchase_returns || []).forEach(function(r) {
                if (!r) return;
                if (String(r.company_name || '') === oldName) r.company_name = newName;
                if (String(r.company || '') === oldName) r.company = newName;
            });
        }

        function applyCustomerRenameInLocalDb(oldName, newName) {
            if (!oldName || !newName || oldName === newName || !db) return;
            (db.deliveries || []).forEach(function(d) {
                if (d && String(d.customer_name || '') === oldName) d.customer_name = newName;
            });
        }

        function refreshCustomerProfileHeaderFromEntity(cust) {
            if (!cust || currentViewingCustomerId == null || String(cust.id) !== String(currentViewingCustomerId)) return;
            var nameEl = document.getElementById('cust-p-name');
            var phoneEl = document.getElementById('cust-p-phone');
            var addrEl = document.getElementById('cust-p-address');
            var balEl = document.getElementById('cust-p-balance');
            if (nameEl) nameEl.innerText = cust.name || '';
            if (phoneEl) phoneEl.innerText = cust.phone || '';
            if (addrEl) addrEl.innerText = cust.address ? (' | ' + cust.address) : '';
            if (typeof fillElWithCurrencyAndDuhokPaper === 'function') {
                var hdrCustFx = (typeof fxUsdRateFormatOptsForEntityBalance === 'function')
                    ? fxUsdRateFormatOptsForEntityBalance(cust.id, 'customer', cust.balance)
                    : undefined;
                fillElWithCurrencyAndDuhokPaper(balEl, cust.balance || 0, hdrCustFx);
            }
            else if (balEl) balEl.innerText = formatCurrency(cust.balance || 0) + ' ' + getCurrencySymbol();
        }

        function debtLedgerMoneyForCard(iqd, fxOpts) {
            return formatCurrency(Math.max(0, parseFloat(iqd) || 0), fxOpts);
        }

        function duhokPaperHintHtmlSafe(iqd, inline, extraOpts) {
            if (typeof duhokPaperHintHtml !== 'function') return '';
            var opts = extraOpts ? Object.assign({}, extraOpts) : {};
            if (inline) opts.inline = true;
            return duhokPaperHintHtml(iqd, Object.keys(opts).length ? opts : undefined);
        }

        function duhokPaperLegendHtmlSafe() {
            if (typeof duhokPaperLegendHtml === 'function') return duhokPaperLegendHtml();
            return '';
        }

        function syncDebtAddCustomerMoneyPlaceholders() {
            var usd = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
            var unit = usd ? '$' : 'IQD';
            var ob = document.getElementById('new-cust-opening-balance');
            var dl = document.getElementById('new-cust-debt-limit');
            if (ob) {
                ob.placeholder = 'دەینی کەڤن (' + unit + ')';
            }
            if (dl) {
                dl.placeholder = 'سنووری قەرز (' + unit + ')';
            }
            if (typeof syncDuhokPaperUsdInputHints === 'function') syncDuhokPaperUsdInputHints();
        }

        function refreshCompanyProfileHeaderFromEntity(comp) {
            if (!comp || currentViewingCompanyId == null || String(comp.id) !== String(currentViewingCompanyId)) return;
            var nameEl = document.getElementById('cp-name');
            var phoneEl = document.getElementById('cp-phone');
            var addrEl = document.getElementById('cp-address');
            var balEl = document.getElementById('cp-balance');
            if (nameEl) nameEl.innerText = comp.name || '';
            if (phoneEl) phoneEl.innerText = comp.phone || '';
            if (addrEl) addrEl.innerText = comp.address ? (' | ' + comp.address) : '';
            var compBalFx = (typeof fxUsdRateFormatOptsForEntityBalance === 'function')
                ? fxUsdRateFormatOptsForEntityBalance(comp.id, 'company', comp.balance)
                : undefined;
            if (typeof fillElWithCurrencyAndDuhokPaper === 'function') fillElWithCurrencyAndDuhokPaper(balEl, comp.balance || 0, compBalFx);
            else if (balEl) balEl.innerText = formatCurrency(comp.balance || 0, compBalFx) + ' ' + getCurrencySymbol();
        }

        function fillCustomerCompanyEditFields(ent) {
            if (!ent) return;
            var name = ent.name || ent.customer_name || '';
            var phone = ent.phone || '';
            var address = ent.address || '';
            var obIqd = Math.max(0, parseFloat(ent.opening_balance != null ? ent.opening_balance : (ent.opening || 0)) || 0);
            var dlIqd = Math.max(0, parseFloat(ent.debt_limit || 0) || 0);
            var openingBalance = (typeof storedIqdToDebtFormAmount === 'function') ? storedIqdToDebtFormAmount(obIqd) : obIqd;
            var debtLimit = (typeof storedIqdToDebtFormAmount === 'function') ? storedIqdToDebtFormAmount(dlIqd) : dlIqd;
            var nameEl = document.getElementById('cc-edit-name');
            var phoneEl = document.getElementById('cc-edit-phone');
            var addrEl = document.getElementById('cc-edit-address');
            if (nameEl) nameEl.value = name;
            if (phoneEl) phoneEl.value = phone;
            if (addrEl) addrEl.value = address;
            var obEl = document.getElementById('cc-edit-opening-balance');
            var dlEl = document.getElementById('cc-edit-debt-limit');
            if (obEl) obEl.value = openingBalance;
            if (dlEl) dlEl.value = debtLimit;
            var ptVal = Math.max(0, parseInt(ent.payment_term_value, 10) || 0);
            var ptUnit = (typeof normalizePaymentTermUnit === 'function') ? normalizePaymentTermUnit(ent.payment_term_unit || 'day') : 'day';
            var ccPtVal = document.getElementById('cc-edit-payment-term-value');
            var ccPtUnit = document.getElementById('cc-edit-payment-term-unit');
            if (ccPtVal) ccPtVal.value = String(ptVal);
            if (ccPtUnit) ccPtUnit.value = ptUnit;
            syncCcEditMoneyFieldLabels();
            var fmtKind = (typeof getMoneyInputKind === 'function') ? getMoneyInputKind() : 'int';
            if (typeof formatPaymentInputElement === 'function') {
                if (obEl) formatPaymentInputElement(obEl, fmtKind);
                if (dlEl) formatPaymentInputElement(dlEl, fmtKind);
            }
            if (typeof syncDuhokPaperUsdInputHints === 'function') syncDuhokPaperUsdInputHints();
        }

        function openCustomerCompanyEditModal(entityType, id, fallbackName) {
            const modal = document.getElementById('cc-edit-modal');
            if(!modal) return;

            const isCustomer = entityType === 'customer';
            const list = isCustomer ? (db.customers || []) : (db.companies || []);
            var ent = list.find(function(x){ return x && String(x.id) === String(id); });
            if (!ent) {
                ent = { id: id, name: fallbackName || '', phone: '', address: '', opening_balance: 0, debt_limit: 0, payment_term_value: 0, payment_term_unit: 'day' };
            } else if ((!ent.name || String(ent.name).trim() === '') && fallbackName) {
                ent = Object.assign({}, ent, { name: fallbackName });
            }

            document.getElementById('cc-edit-entity-type').value = isCustomer ? 'customer' : 'company';
            document.getElementById('cc-edit-id').value = String(id);
            modal.setAttribute('data-cc-edit-req', String(id) + ':' + (isCustomer ? 'customer' : 'company'));

            document.getElementById('cc-edit-title').textContent = isCustomer ? 'دەستکاریکرنا کریاری' : 'دەستکاریکرنا کۆمپانیێ';
            document.getElementById('cc-edit-subtitle').textContent = 'ناڤ، تەلەفۆن، ناڤنیشان و داتایێن قەرز';

            fillCustomerCompanyEditFields(ent);

            var saveBtn = modal.querySelector('.btn-success');
            if (saveBtn) saveBtn.disabled = false;

            modal.style.display = 'flex';
            setTimeout(function() {
                var nameIn = document.getElementById('cc-edit-name');
                if (nameIn && !nameIn.value) nameIn.focus();
            }, 50);

            var action = isCustomer ? 'get_customer' : 'get_company';
            var fd = new FormData();
            fd.append('action', action);
            fd.append('id', id);
            fetch('?action=' + action, { method: 'POST', body: fd, credentials: 'same-origin' })
            .then(function(res) { return res.json().catch(function() { return null; }); })
            .then(function(data) {
                if (!data || data.status !== 'success') return;
                var still = modal.getAttribute('data-cc-edit-req') === (String(id) + ':' + (isCustomer ? 'customer' : 'company'));
                if (!still || modal.style.display === 'none') return;
                var row = isCustomer ? data.customer : data.company;
                if (!row) return;
                fillCustomerCompanyEditFields(row);
                if (isCustomer && typeof posUpsertCustomers === 'function') posUpsertCustomers([row]);
                else if (!isCustomer && typeof posUpsertCompanies === 'function') posUpsertCompanies([row]);
            })
            .catch(function() { /* keep local fill */ });
        }

        function closeCustomerCompanyEditModal() {
            const modal = document.getElementById('cc-edit-modal');
            if(modal) modal.style.display = 'none';
        }

        function saveCustomerCompanyEdit() {
            const modal = document.getElementById('cc-edit-modal');
            const saveBtn = modal ? modal.querySelector('.btn-success') : null;
            if (saveBtn && saveBtn.disabled) return;

            const entityType = (document.getElementById('cc-edit-entity-type')?.value || '').trim();
            const id = parseInt(document.getElementById('cc-edit-id')?.value || '0', 10);

            if(entityType !== 'customer' && entityType !== 'company') {
                showToast('❌ هەڵە: entityType نادۆزێنەوە', 'error');
                return;
            }
            if(!id || id <= 0) {
                showToast('❌ هەڵە: id نادۆزێنەوە', 'error');
                return;
            }

            const isCustomer = entityType === 'customer';
            if(isCustomer) {
                if(!checkPermission('debt_manage', 'دەستکاریکرنا کریاری')) return;
            } else {
                if(!checkPermission('companies_manage', 'دەستکاریکرنا کۆمپانیێ')) return;
            }

            const list = isCustomer ? (db.customers || []) : (db.companies || []);
            const entBefore = list.find(function(x){ return x && String(x.id) === String(id); });
            const oldName = (entBefore && entBefore.name) ? String(entBefore.name) : '';

            const name = (document.getElementById('cc-edit-name')?.value || '').trim();
            const phone = (document.getElementById('cc-edit-phone')?.value || '').trim();
            const address = (document.getElementById('cc-edit-address')?.value || '').trim();
            const openingBalance = parseCcEditMoneyField(document.getElementById('cc-edit-opening-balance')?.value);
            const debtLimit = parseCcEditMoneyField(document.getElementById('cc-edit-debt-limit')?.value);
            const payTerm = (typeof readProfilePaymentTerm === 'function')
                ? readProfilePaymentTerm('cc-edit-payment-term-value', 'cc-edit-payment-term-unit')
                : { value: 0, unit: 'day' };

            if(!name) name = oldName;
            if(!name) return showToast('⚠️ ناڤ پێدڤیە', 'error');
            if(name.length < 2) return showToast('⚠️ ناڤ گەلەک یێ کورتە! (لانی کەم ٢ پیت)', 'error');

            const action = isCustomer ? 'update_customer' : 'update_company';

            const fd = new FormData();
            fd.append('action', action);
            fd.append('id', id);
            fd.append('name', name);
            fd.append('phone', phone);
            fd.append('address', address);
            fd.append('opening_balance', openingBalance);
            fd.append('debt_limit', debtLimit);
            fd.append('payment_term_value', payTerm.value);
            fd.append('payment_term_unit', payTerm.unit);

            if (saveBtn) saveBtn.disabled = true;

            fetch('?action=' + action, { method: 'POST', body: fd, credentials: 'same-origin' })
            .then(function(res) {
                return res.json().catch(function() {
                    throw new Error('وەڵامێ سێرڤەرێ نادروستە');
                });
            })
            .then(function(data){
                if(data.status === 'success') {
                    const obSt = (typeof data.opening_balance !== 'undefined')
                        ? (parseFloat(data.opening_balance) || 0)
                        : ((typeof debtFormAmountToStoredIqd === 'function') ? debtFormAmountToStoredIqd(openingBalance) : openingBalance);
                    const dlSt = (typeof data.debt_limit !== 'undefined')
                        ? (parseFloat(data.debt_limit) || 0)
                        : ((typeof debtFormAmountToStoredIqd === 'function') ? debtFormAmountToStoredIqd(debtLimit) : debtLimit);
                    const ptValSt = (typeof data.payment_term_value !== 'undefined') ? (parseInt(data.payment_term_value, 10) || 0) : payTerm.value;
                    const ptUnitSt = (typeof data.payment_term_unit !== 'undefined') ? (typeof normalizePaymentTermUnit === 'function' ? normalizePaymentTermUnit(data.payment_term_unit) : 'day') : payTerm.unit;
                    if(isCustomer) {
                        const c = (db.customers || []).find(function(x){ return x && String(x.id) === String(id); });
                        const renameFrom = (data.old_name && String(data.old_name)) || oldName;
                        if (renameFrom && renameFrom !== name) {
                            applyCustomerRenameInLocalDb(renameFrom, name);
                        }
                        if(c) {
                            c.name = name;
                            c.phone = phone;
                            c.address = address;
                            c.opening_balance = obSt;
                            c.debt_limit = dlSt;
                            c.payment_term_value = ptValSt;
                            c.payment_term_unit = ptUnitSt;
                            if(typeof data.balance !== 'undefined') c.balance = parseFloat(data.balance) || 0;
                        }
                        renderDebtView('customers');
                        if (typeof window.populateCustomerDatalist === 'function') window.populateCustomerDatalist();
                        if (currentViewingCustomerId != null && String(currentViewingCustomerId) === String(id) && c) {
                            refreshCustomerProfileHeaderFromEntity(c);
                            renderCustomerHistory();
                            renderCustomerLedgerHistory();
                        }
                        showToast('✅ زانیاریێن کریاری هاتنە نویکرن');
                    } else {
                        const c = (db.companies || []).find(function(x){ return x && String(x.id) === String(id); });
                        const renameFrom = (data.old_name && String(data.old_name)) || oldName;
                        if (renameFrom && renameFrom !== name) {
                            applyCompanyRenameInLocalDb(renameFrom, name);
                        }
                        if(c) {
                            c.name = name;
                            c.phone = phone;
                            c.address = address;
                            c.opening_balance = obSt;
                            c.debt_limit = dlSt;
                            c.payment_term_value = ptValSt;
                            c.payment_term_unit = ptUnitSt;
                            if(typeof data.balance !== 'undefined') c.balance = parseFloat(data.balance) || 0;
                        }
                        renderCompanies();
                        if (typeof initPurchaseScreen === 'function') initPurchaseScreen();
                        if (typeof renderPurchaseReturnsProductGrid === 'function') renderPurchaseReturnsProductGrid();

                        if(currentViewingCompanyId != null && String(currentViewingCompanyId) === String(id) && c) {
                            refreshCompanyProfileHeaderFromEntity(c);
                            if (renameFrom && renameFrom !== name) {
                                renderCompanyInventory(name);
                                renderCompanyHistory(name);
                                renderLedgerHistory(id);
                            }
                        }

                        showToast('✅ زانیاریێن کۆمپانیێ هاتنە نویکرن');
                    }
                    closeCustomerCompanyEditModal();
                    if (typeof saveDB === 'function') saveDB();
                } else {
                    showToast('❌ ' + (data.message || 'هەڵە ل دەستکاریکرنێ'), 'error');
                }
            })
            .catch(function(err){ showToast('❌ هەڵە: ' + (err && err.message ? err.message : err), 'error'); })
            .finally(function() {
                if (saveBtn) saveBtn.disabled = false;
            });
        }

        function editCompany(id, fallbackName) {
            if(!checkPermission('companies_manage', 'دەستکاریکرنا کۆمپانیێ')) return;
            openCustomerCompanyEditModal('company', id, fallbackName);
        }

        window.openCustomerCompanyEditModal = openCustomerCompanyEditModal;
        window.closeCustomerCompanyEditModal = closeCustomerCompanyEditModal;
        window.saveCustomerCompanyEdit = saveCustomerCompanyEdit;
        window.editCompany = editCompany;

        function bindCompanyListCardActions(container) {
            if (!container) return;
            container.onclick = function(ev) {
                var btn = ev.target.closest('[data-comp-action]');
                if (btn) {
                    ev.preventDefault();
                    ev.stopPropagation();
                    var action = btn.getAttribute('data-comp-action');
                    var id = btn.getAttribute('data-comp-id');
                    var cname = btn.getAttribute('data-comp-name') || '';
                    if (id == null || id === '') return;
                    if (action === 'profile') openCompanyProfile(id);
                    else if (action === 'edit') editCompany(id, cname);
                    else if (action === 'delete') deleteCompany(id);
                    return;
                }
                var card = ev.target.closest('.txn-entity-card[data-comp-id]');
                if (card) openCompanyProfile(card.getAttribute('data-comp-id'));
            };
        }

        function posSupplierProductCountMap() {
            var map = Object.create(null);
            (db.products || []).forEach(function(p) {
                if (!p || !p.supplier) return;
                var s = String(p.supplier);
                map[s] = (map[s] || 0) + 1;
            });
            return map;
        }

        function posScheduleListRender(key, fn) {
            var ms = (typeof posDebouncedListRenderMs === 'function') ? posDebouncedListRenderMs() : 0;
            if (key === 'companies' || String(key).indexOf('debt_') === 0) {
                ms = Math.max(ms, 200);
            }
            if (ms > 0) {
                window['_posListRender_' + key] = fn;
                clearTimeout(window['_posListRenderTimer_' + key]);
                window['_posListRenderTimer_' + key] = setTimeout(function() {
                    var f = window['_posListRender_' + key];
                    if (typeof f === 'function') f();
                }, ms);
                return;
            }
            fn();
        }

        function posFilterEntityRowsLocal(list, q) {
            list = Array.isArray(list) ? list : [];
            q = String(q || '').trim().toLowerCase();
            var qn = (typeof normalizeForSearch === 'function') ? normalizeForSearch(q) : q;
            return list.filter(function(item) {
                if (!item) return false;
                if (item.is_active != null && Number(item.is_active) === 0) return false;
                if (!q) return true;
                var nameRaw = String(item.name || '').toLowerCase();
                var nameNorm = (typeof normalizeForSearch === 'function') ? normalizeForSearch(item.name || '') : nameRaw;
                var phoneRaw = String(item.phone || '');
                var idRaw = String(item.id != null ? item.id : '');
                return nameRaw.indexOf(q) !== -1
                    || (qn && nameNorm.indexOf(qn) !== -1)
                    || (phoneRaw && phoneRaw.indexOf(q) !== -1)
                    || (idRaw && (idRaw === q || ('#' + idRaw) === q || idRaw.indexOf(q) !== -1));
            });
        }
        window.posFilterEntityRowsLocal = posFilterEntityRowsLocal;

        function posFetchEntitySearchLocal(entityType, q, limit, offset) {
            if (typeof posFetchEntitySearch === 'function') {
                return posFetchEntitySearch(entityType, q, limit, offset);
            }
            return Promise.resolve({ status: 'error' });
        }

        function renderCompanies() {
            posScheduleListRender('companies', renderCompaniesBody);
        }

        /** Per-company purchase total + margin (sell catalog − buy) from db.supplies. */
        function buildCompanyPurchaseStatsMap() {
            var byName = Object.create(null);
            var supplies = (typeof db !== 'undefined' && db && Array.isArray(db.supplies)) ? db.supplies : [];
            var needProfit = (typeof canViewProfit === 'function') ? canViewProfit() : true;
            var productMap = null;
            function getProductMap() {
                if (productMap) return productMap;
                productMap = new Map();
                var prods = (db && db.products) || [];
                for (var pi = 0; pi < prods.length; pi++) {
                    if (prods[pi] && prods[pi].id != null) productMap.set(Number(prods[pi].id), prods[pi]);
                }
                return productMap;
            }
            function pieceSell(prodId) {
                var prod = getProductMap().get(Number(prodId));
                if (!prod) return 0;
                if (typeof getPriceForUnit === 'function') return Number(getPriceForUnit(prod, 'piece')) || 0;
                if (typeof getCatalogPieceSellIqd === 'function') return Number(getCatalogPieceSellIqd(prod)) || 0;
                return Number(prod.price) || 0;
            }
            function pieceSellUsd(prodId) {
                var prod = getProductMap().get(Number(prodId));
                if (!prod) return 0;
                if (typeof getCatalogPieceSellUsd === 'function') return Number(getCatalogPieceSellUsd(prod)) || 0;
                return 0;
            }
            for (var i = 0; i < supplies.length; i++) {
                var s = supplies[i];
                if (!s) continue;
                var ctype = String(s.type || '').toLowerCase();
                if (ctype === 'opening') continue;
                var cname = String(s.company || '').trim();
                if (!cname) continue;
                var key = cname.toLowerCase();
                if (!byName[key]) byName[key] = { purchase: 0, profit: 0, sell: 0, purchaseUsd: 0, sellUsd: 0 };
                var cost = parseFloat(s.totalCost) || 0;
                var pieces = parseFloat(s.qtyAdded) || 0;
                var isReturn = (ctype === 'return') || pieces < 0;
                var isGift = (typeof window.isSupplyItemGift === 'function')
                    ? window.isSupplyItemGift(s)
                    : !!(s && (s.isGift === true || s.is_gift === 1 || s.is_gift === '1' || s.is_gift === true));
                var absPieces = Math.abs(pieces);
                var absCost = Math.abs(cost);
                var fxOne = 0;
                if (typeof fxBundleToRatePerOne === 'function' && s.fx_usd_rate != null && s.fx_usd_rate !== '') {
                    fxOne = fxBundleToRatePerOne(s.fx_usd_rate);
                }
                if (!(fxOne > 0)) fxOne = 1500;
                var absCostUsd = fxOne > 0 ? (absCost / fxOne) : 0;
                if (isReturn) {
                    byName[key].purchase -= absCost;
                    byName[key].purchaseUsd -= absCostUsd;
                    if (needProfit && absPieces > 0 && !isGift) {
                        byName[key].sell -= pieceSell(s.prodId) * absPieces;
                        byName[key].sellUsd -= pieceSellUsd(s.prodId) * absPieces;
                    }
                } else {
                    if (!isGift) {
                        byName[key].purchase += absCost;
                        byName[key].purchaseUsd += absCostUsd;
                    }
                    if (needProfit && absPieces > 0 && !isGift) {
                        byName[key].sell += pieceSell(s.prodId) * absPieces;
                        byName[key].sellUsd += pieceSellUsd(s.prodId) * absPieces;
                    }
                }
            }
            var out = Object.create(null);
            var companies = (db && db.companies) || [];
            for (var ci = 0; ci < companies.length; ci++) {
                var comp = companies[ci];
                if (!comp || comp.id == null) continue;
                var nk = String(comp.name || '').trim().toLowerCase();
                if (!nk || !byName[nk]) continue;
                var st = byName[nk];
                out[String(comp.id)] = {
                    purchase: st.purchase,
                    sell: st.sell,
                    profit: st.sell - st.purchase,
                    purchaseUsd: st.purchaseUsd,
                    sellUsd: st.sellUsd,
                    profitUsd: st.sellUsd - st.purchaseUsd
                };
            }
            return out;
        }
        window.buildCompanyPurchaseStatsMap = buildCompanyPurchaseStatsMap;

        function renderCompaniesBody(opts) {
            opts = opts || {};
            if (!db.companies) db.companies = [];
            const container = document.getElementById('companies-grid');
            if (!container) return;
            var T = (typeof t === 'function' ? t : function(k) { return k; });
            var esc = (typeof escapeHtml === 'function' ? escapeHtml : function(s) { return String(s == null ? '' : s); });

            var prevSearch = opts.preserveSearch != null ? opts.preserveSearch : '';
            var prevSort = 'high_debt';
            if (!opts.serverRows) {
                try {
                    var _si = document.getElementById('comp-search-input');
                    var _ss = document.getElementById('comp-sort-select');
                    if (_si) prevSearch = _si.value;
                    if (_ss && _ss.value) prevSort = _ss.value;
                } catch (e0) {}
            }
            var searchTrim = String(prevSearch || '').trim();
            if (!opts.serverRows) {
                var localRows = posFilterEntityRowsLocal(db.companies || [], searchTrim);
                renderCompaniesBody({
                    serverRows: localRows,
                    serverHasMore: false,
                    preserveSearch: prevSearch,
                    fromLocal: true
                });
                var seq = (window._posCompSearchSeq = (window._posCompSearchSeq || 0) + 1);
                var seqNow = seq;
                var fetchFn = (typeof posFetchEntitySearchLocal === 'function')
                    ? posFetchEntitySearchLocal
                    : ((typeof posFetchEntitySearch === 'function') ? posFetchEntitySearch : null);
                if (!fetchFn) return;
                var compLimit = (typeof posListRenderLimit === 'function') ? posListRenderLimit(searchTrim) : 120;
                var p = fetchFn('companies', searchTrim, compLimit, 0);
                var timed = Promise.race([
                    p,
                    new Promise(function(resolve) {
                        setTimeout(function() { resolve({ status: 'timeout' }); }, 8000);
                    })
                ]);
                timed.then(function(res) {
                    if (seqNow !== window._posCompSearchSeq) return;
                    var inp = document.getElementById('comp-search-input');
                    if (inp && String(inp.value || '') !== String(prevSearch || '')) return;
                    if (!res || res.status !== 'ok') return;
                    if (res.rows && typeof posUpsertCompanies === 'function') posUpsertCompanies(res.rows);
                    renderCompaniesBody({ serverRows: res.rows || [], serverHasMore: !!res.has_more, preserveSearch: prevSearch });
                }).catch(function() {});
                return;
            }

            var controlsHtml = `
            <div style="grid-column: 1 / -1; display: flex; gap: 10px; margin-bottom: 15px; flex-wrap: wrap;">
                <div style="flex: 1; position: relative;">
                    <i class="fas fa-search" style="position: absolute; right: 15px; top: 15px; color: var(--text-muted);"></i>
                    <input type="text" id="comp-search-input" class="input-std" placeholder="${String(T('debt_search_placeholder')).replace(/"/g, '&quot;')}" style="margin:0; padding-right: 40px;" onkeyup="renderCompanies()">
                </div>
                <select id="comp-sort-select" class="input-std" style="width: auto; margin:0;" onchange="renderCompanies()">
                    <option value="high_debt">${esc(T('debt_sort_high'))}</option>
                    <option value="low_debt">${esc(T('debt_sort_low'))}</option>
                    <option value="name">${esc(T('debt_sort_name'))}</option>
                    <option value="recent">${esc(T('debt_sort_recent'))}</option>
                </select>
            </div>`;

            var list = opts.serverRows ? opts.serverRows.slice() : [...db.companies];
            list = list.filter(function(item) {
                return item && (item.is_active == null || Number(item.is_active) !== 0);
            });
            var totalDebt = (typeof roundMoney === 'function' ? roundMoney : function(x) { return Math.round(Number(x)); })(list.reduce(function(sum, item) { return sum + (parseFloat(item.balance) || 0); }, 0));
            var totalDebtUsd = 0;
            var isUsdMode = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
            if (isUsdMode) {
                list.forEach(function(item) {
                    var b = parseFloat(item.balance) || 0;
                    if (b <= 0) return;
                    var bFx = (typeof fxUsdRateFormatOptsForEntityBalance === 'function')
                        ? fxUsdRateFormatOptsForEntityBalance(item.id, 'company', b)
                        : undefined;
                    var usdAmt = 0;
                    if (typeof storedIqdToUsdDisplayAmount === 'function') {
                        usdAmt = storedIqdToUsdDisplayAmount(b, bFx);
                    } else if (bFx && bFx.fxUsdRate > 0) {
                        usdAmt = Math.round((b / (bFx.fxUsdRate / 100)) * 100) / 100;
                    } else {
                        var r = (typeof getUsdRatePerOne === 'function') ? getUsdRatePerOne() : 1500;
                        usdAmt = r > 0 ? (b / r) : 0;
                    }
                    totalDebtUsd += (usdAmt || 0);
                });
            }
            var totalCompDebtFx = (isUsdMode && totalDebtUsd > 0 && totalDebt > 0)
                ? { directUsd: totalDebtUsd, fxUsdRate: Math.round((totalDebt / totalDebtUsd) * 100) }
                : undefined;
            var companyCount = opts.serverRows ? list.length : list.length;
            var sortMode = prevSort || 'high_debt';

            if (sortMode === 'high_debt') list.sort(function(a, b) { return (b.balance || 0) - (a.balance || 0); });
            else if (sortMode === 'low_debt') list.sort(function(a, b) { return (a.balance || 0) - (b.balance || 0); });
            else if (sortMode === 'name') list.sort(function(a, b) { return (a.name || '').localeCompare(b.name || ''); });
            else if (sortMode === 'recent') list.sort(function(a, b) { return b.id - a.id; });

            var html = `
            <div style="grid-column: 1 / -1; display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 20px;">
                <div class="card duhok-debt-total-card" style="background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); border: 1px solid #334155; padding: 15px; margin:0;">
                    <h4 style="color: #94a3b8; margin: 0 0 5px 0;"><i class="fas fa-file-invoice-dollar" style="margin-left:6px;"></i> ${esc(T('comp_total_debt_title'))}</h4>
                    <h1 style="color: #ef4444; margin: 0;">${formatCurrency(totalDebt, totalCompDebtFx)} <small style="font-size: 1rem;">${getCurrencySymbol()}</small></h1>
                    ${duhokPaperHintHtmlSafe(totalDebt, false, totalCompDebtFx)}
                    ${duhokPaperLegendHtmlSafe()}
                </div>
                <div class="card" style="background: var(--card); border: 1px solid var(--border); padding: 15px; margin:0;">
                    <h4 style="color: var(--text-muted); margin: 0 0 5px 0;"><i class="fas fa-building" style="margin-left:6px;color:var(--brand);"></i> ${esc(T('comp_count_title'))}</h4>
                    <h1 style="color: var(--brand); margin: 0;">${companyCount} <small style="font-size: 1rem;">${esc(T('comp_count_unit'))}</small></h1>
                </div>
            </div>
            ${controlsHtml}`;

            var searchTerm = (prevSearch || '').toLowerCase();
            var searchNorm = (typeof normalizeForSearch === 'function') ? normalizeForSearch(prevSearch || '') : searchTerm;
            var filteredList = opts.serverRows ? list : list.filter(function(item) {
                var nameRaw = String(item.name || '').toLowerCase();
                var nameNorm = (typeof normalizeForSearch === 'function') ? normalizeForSearch(item.name || '') : nameRaw;
                var phoneRaw = String(item.phone || '');
                var idRaw = String(item.id != null ? item.id : '');
                return (!searchTerm && !searchNorm)
                    || nameRaw.indexOf(searchTerm) !== -1
                    || (searchNorm && nameNorm.indexOf(searchNorm) !== -1)
                    || (phoneRaw && phoneRaw.indexOf(searchTerm) !== -1)
                    || (idRaw && (idRaw === searchTerm || ('#' + idRaw) === searchTerm || idRaw.indexOf(searchTerm) !== -1));
            });
            var listLimit = (typeof posListRenderLimit === 'function') ? posListRenderLimit(searchTerm) : 100;
            var supplierCounts = posSupplierProductCountMap();
            var showCardProfit = (typeof canViewProfit === 'function') ? canViewProfit() : true;
            var purchaseStatsMap = buildCompanyPurchaseStatsMap();
            if (opts.serverRows && !opts.fromLocal) {
                html += '<p style="grid-column:1/-1;font-size:0.85rem;color:var(--text-muted);margin:0 0 8px;"><i class="fas fa-database"></i> '
                    + esc(T('search_results_server') !== 'search_results_server' ? T('search_results_server') : 'ئەنجام لە سێرڤەر')
                    + (opts.serverHasMore ? ' — ' + esc(T('list_search_for_more') !== 'list_search_for_more' ? T('list_search_for_more') : 'گەڕان بکە بۆ زیاتر') : '')
                    + '</p>';
            }

            html += filteredList.slice(0, listLimit).map(function(c) {
                var balance = parseFloat(c.balance) || 0;
                var isDebt = balance > 0;
                var isSupplierCredit = balance < 0;
                var statusColor = isDebt ? '#ef4444' : (isSupplierCredit ? '#3b82f6' : '#10b981');
                var statusText = isDebt ? T('debt_status_owed') : (isSupplierCredit ? T('debt_status_supplier_credit') : T('debt_status_clear'));
                var debtLimitStored = Math.max(0, parseFloat(c.debt_limit) || 0);
                var openingBalanceStored = Math.max(0, parseFloat(c.opening_balance) || 0);
                var overLimit = debtLimitStored > 0 && balance > debtLimitStored;
                var compBalFx = (typeof fxUsdRateFormatOptsForEntityBalance === 'function')
                    ? fxUsdRateFormatOptsForEntityBalance(c.id, 'company', balance)
                    : undefined;
                var itemCount = supplierCounts[c.name] || 0;
                var debtRatio = Math.min((balance / 1000000) * 100, 100);
                var phoneDisp = c.phone ? escapeHtml(c.phone) : esc(T('debt_no_phone'));
                var stats = purchaseStatsMap[String(c.id)] || { purchase: 0, profit: 0, purchaseUsd: 0, profitUsd: 0 };
                var purchaseAmt = parseFloat(stats.purchase) || 0;
                var profitAmt = parseFloat(stats.profit) || 0;
                var profitColor = profitAmt > 0 ? '#10b981' : (profitAmt < 0 ? '#ef4444' : 'var(--text)');
                var purchaseFx = (isUsdMode && stats.purchaseUsd != null)
                    ? { directUsd: stats.purchaseUsd }
                    : undefined;
                var profitFx = (isUsdMode && stats.profitUsd != null)
                    ? { directUsd: stats.profitUsd }
                    : undefined;

                return `
                <div class="card txn-entity-card" title="${escapeHtml((typeof window.getEntityPaymentDueInfo === 'function' && window.getEntityPaymentDueInfo('company', c) && window.getEntityPaymentDueInfo('company', c).label) ? window.getEntityPaymentDueInfo('company', c).label : '')}" data-comp-id="${c.id}" style="padding: 0; overflow: hidden; border: 1px solid ${overLimit ? '#f59e0b' : 'var(--border)'}; transition: transform 0.2s; cursor: pointer;">
                    <div style="padding: 15px; display: flex; justify-content: space-between; align-items: center; background: var(--input-bg);">
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <div style="width: 52px; height: 52px; border-radius: 50%; background: ${statusColor}20; color: ${statusColor}; display: flex; align-items: center; justify-content: center; font-size:1.35rem;">
                                <i class="fas fa-building"></i>
                            </div>
                            <div>
                                <h3 style="margin: 0; font-size: 1rem; display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
                                    <span>${escapeHtml(c.name)}</span>
                                    <span style="background:rgba(59,130,246,0.15); color:#3b82f6; padding:1px 7px; border-radius:6px; font-size:0.72rem; font-weight:700; direction:ltr;" title="${esc(T('debt_card_id'))}">#${escapeHtml(String(c.id != null ? c.id : ''))}</span>
                                </h3>
                                ${(typeof window.renderPaymentDueBadgeHtml === 'function') ? window.renderPaymentDueBadgeHtml('company', c) : ''}
                                <small style="color: var(--text-muted); display:block;"><i class="fas fa-phone" style="margin-left:4px;"></i> ${phoneDisp}</small>
                                ${c.address ? '<small style="color: var(--text-muted); display:block;"><i class="fas fa-location-dot" style="margin-left:4px;"></i> ' + escapeHtml(c.address) + '</small>' : ''}
                                <span style="background:rgba(0,0,0,0.1); padding:2px 6px; border-radius:6px; font-size:0.75rem; color:var(--text-muted); margin-top:4px; display:inline-block;"><i class="fas fa-box"></i> ${itemCount} ${esc(T('comp_items_unit'))}</span>
                            </div>
                        </div>
                        <div style="text-align: right;">
                            <h3 style="margin: 0; color: ${statusColor};"><i class="fas fa-coins" style="font-size:0.85rem;margin-left:4px;"></i> ${formatCurrency(balance, compBalFx)}</h3>
                            ${duhokPaperHintHtmlSafe(balance, false, compBalFx)}
                            <small style="color: ${statusColor}; font-weight: bold;">${esc(statusText)}</small>
                        </div>
                    </div>
                    <div style="padding:8px 12px; background:${overLimit ? 'rgba(245,158,11,0.15)' : 'var(--card)'}; border-top:1px dashed var(--border); font-size:0.82rem; color:var(--text-muted); display:flex; justify-content:space-between; gap:10px; flex-wrap:wrap;">
                        <span><i class="fas fa-clock-rotate-left" style="margin-left:4px;"></i> ${esc(T('debt_card_old_opening'))}: <b style="color:var(--text);">${debtLedgerMoneyForCard(openingBalanceStored, compBalFx)}</b>${duhokPaperHintHtmlSafe(openingBalanceStored, true, compBalFx)}</span>
                        <span><i class="fas fa-gauge-high" style="margin-left:4px;"></i> ${esc(T('debt_card_limit'))}: <b style="color:${debtLimitStored > 0 ? (overLimit ? '#f59e0b' : 'var(--text)') : 'var(--text-muted)'};">${debtLimitStored > 0 ? debtLedgerMoneyForCard(debtLimitStored, compBalFx) : '—'}</b></span>
                        ${overLimit ? '<span style="color:#f59e0b; font-weight:700;"><i class="fas fa-exclamation-triangle"></i> ' + esc(T('debt_over_limit_warning')) + '</span>' : ''}
                    </div>
                    ${(typeof window.renderPaymentDueRemainingRowHtml === 'function') ? window.renderPaymentDueRemainingRowHtml('company', c) : ''}
                    <div style="padding:6px 12px; background:var(--card); border-top:1px dashed var(--border); font-size:0.82rem; color:var(--text-muted); display:flex; justify-content:space-between; gap:10px; flex-wrap:wrap;">
                        <span><i class="fas fa-truck" style="margin-left:4px;"></i> ${esc(T('comp_card_purchases'))}: <b style="color:var(--brand);">${formatCurrency(purchaseAmt, purchaseFx)}</b></span>
                        ${showCardProfit ? '<span data-perm="view_profit"><i class="fas fa-chart-line" style="margin-left:4px;"></i> ' + esc(T('debt_card_profit')) + ': <b style="color:' + profitColor + ';">' + formatCurrency(profitAmt, profitFx) + '</b></span>' : ''}
                    </div>
                    ${isDebt ? '<div style="height: 4px; background: var(--border); width: 100%;"><div style="height: 100%; background: ' + statusColor + '; width: ' + debtRatio + '%;"></div></div>' : ''}
                    <div class="page-action-row" style="padding: 10px; display: flex; gap: 5px; background: var(--card);">
                        <div class="page-actions-standard" style="display: flex; gap: 5px; width: 100%;">
                            <button type="button" class="btn btn-sm btn-info" style="flex: 1;" data-comp-action="profile" data-comp-id="${c.id}"><i class="fas fa-list"></i> ${esc(T('debt_btn_statement'))}</button>
                            <button type="button" class="btn btn-sm btn-warning" style="padding:0 10px;" data-comp-action="edit" data-comp-id="${c.id}" data-comp-name="${esc(c.name || '')}" title="${esc(T('debt_btn_edit'))}"><i class="fas fa-edit"></i> ${esc(T('debt_btn_edit'))}</button>
                            <button type="button" class="btn btn-sm btn-danger" style="padding:0 10px;" data-comp-action="delete" data-comp-id="${c.id}"><i class="fas fa-trash"></i></button>
                        </div>
                    </div>
                </div>`;
            }).join('');

            if (filteredList.length > listLimit) {
                html += '<p style="grid-column:1/-1;text-align:center;color:var(--text-muted);font-size:0.88rem;margin:8px 0 0;">'
                    + '<i class="fas fa-search"></i> '
                    + esc((typeof T === 'function' && T('list_search_for_more') !== 'list_search_for_more') ? T('list_search_for_more') : 'گەڕان بکە بۆ بینینا زیاتر')
                    + ' — ' + listLimit + ' / ' + filteredList.length
                    + '</p>';
            }

            container.innerHTML = html;
            bindCompanyListCardActions(container);
            try {
                var nSi = document.getElementById('comp-search-input');
                var nSs = document.getElementById('comp-sort-select');
                if (nSi) nSi.value = prevSearch;
                if (nSs) nSs.value = sortMode;
            } catch (e1) {}
            if (typeof window.applyI18nSubtree === 'function') {
                var compViewRoot = document.getElementById('view-companies');
                if (compViewRoot) window.applyI18nSubtree(compViewRoot);
            }
            clearTimeout(window.__posDebtSyncTmr);
            window.__posDebtSyncTmr = setTimeout(function () {
                if (typeof window.posNotifyMobileDebtSync === 'function') {
                    window.posNotifyMobileDebtSync('companies_view');
                }
            }, 1500);
        }

        window.renderCompanies = renderCompanies;

        function deleteCompany(id) {
            if(confirm("دڵنیای ژ ژێبرنێ؟ ئایتمێن وێ دێ چنە سەر کڕین ڕاستەوخۆ (Direct Store).")) { 
                const formData = new FormData();
                formData.append('action', 'delete_company');
                formData.append('id', id);
                fetch('?action=delete_company', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if(data.status === 'success') {
                        const comp = db.companies.find(c => c.id === id);
                        if(comp) {
                            db.products.forEach(p => {
                                if(p.supplier === comp.name) p.supplier = "Direct Store";
                            });
                            db.companies = db.companies.filter(c => c.id !== id); 
                            renderCompanies(); 
                        }
                } else if(data.message && confirm(data.message + '\n\nئەرێ تە دڤێت ژ کار بێخی ل شوینا ژێبرنێ؟')) {
                        const fd = new FormData();
                        fd.append('action', 'void_company');
                        fd.append('id', id);
                        fd.append('user', currentUser ? currentUser.name : 'System');
                        fetch('?action=void_company', { method: 'POST', body: fd }).then(r => r.json()).then(d => {
                            if(d.status === 'success') {
                                if (window.db && Array.isArray(window.db.companies)) {
                                    window.db.companies = window.db.companies.filter(function(c) { return String(c.id) !== String(id); });
                                }
                                renderCompanies();
                                if (typeof connectToDB === 'function') connectToDB(true);
                            }
                        });
                    } else if(data.message) showToast(data.message, 'error');
                });
            }
        }

