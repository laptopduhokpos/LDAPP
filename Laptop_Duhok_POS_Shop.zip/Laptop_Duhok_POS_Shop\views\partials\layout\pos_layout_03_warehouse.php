        <div id="view-warehouse" class="workspace wms-premium">
            <div class="wms-page-bg" aria-hidden="true">
                <span class="wms-page-orb wms-page-orb--1"></span>
                <span class="wms-page-orb wms-page-orb--2"></span>
            </div>
            <div class="wms-page-inner">
                <header class="wms-page-header">
                    <div class="wms-page-header__icon" aria-hidden="true">
                        <span class="wms-flat-ic wms-flat-ic--hero"><i class="fas fa-warehouse"></i></span>
                    </div>
                    <div class="wms-page-header__text">
                        <h2 class="wms-page-title"><i class="fas fa-warehouse pos-ic" aria-hidden="true"></i> <span data-i18n="view_warehouse_title">کۆگەه</span></h2>
                        <p class="wms-page-tagline"><i class="fas fa-info-circle pos-ic" aria-hidden="true"></i> <span data-i18n="wh_page_tagline">بەڕێوەبەریا کۆگەه، ئاگەهداری و لیستا کەرەستەیان</span></p>
                    </div>
                </header>

                <div id="wms-multi-wh-premium-teaser" class="card wms-multi-wh-premium-teaser" style="display:none;" aria-labelledby="wms-mwh-teaser-title">
                    <div class="wms-mwh-teaser__glow" aria-hidden="true"></div>
                    <div class="wms-mwh-teaser__inner">
                        <div class="wms-mwh-teaser__content">
                            <div class="wms-mwh-teaser__badges">
                                <span class="wms-mwh-teaser__badge-pro">FEAT</span>
                                <span class="wms-mwh-teaser__badge-price" data-pos-price="feature">$50</span>
                            </div>
                            <h3 id="wms-mwh-teaser-title" class="wms-mwh-teaser__title"><i class="fas fa-store-alt"></i> <span data-i18n="multi_wh_teaser_title">کۆگای فرە — بەڕێوەبردنی چەند شوێن</span></h3>
                            <p class="wms-mwh-teaser__desc" data-i18n="multi_wh_teaser_desc">ئەم بەشە لە پلانی Pro ـە. چەند کۆگە دروست بکە، کاڵا بگوازەوە، وەسڵ چاپ بکە — هەمووی لە یەک شوێن.</p>
                            <ul class="wms-mwh-teaser__features">
                                <li><i class="fas fa-warehouse"></i> <span data-i18n="multi_wh_teaser_f1">چەند کۆگە (فرۆشگا، کۆگەی سەرەکی، …)</span></li>
                                <li><i class="fas fa-dolly"></i> <span data-i18n="multi_wh_teaser_f2">گواستنەوەی کاڵا بە بارکود + وەسڵا چاپ</span></li>
                                <li><i class="fas fa-shopping-basket"></i> <span data-i18n="multi_wh_teaser_f3">هەڵبژاردنی کۆگە ل کڕین و ئایتم</span></li>
                                <li><i class="fas fa-clipboard-check"></i> <span data-i18n="multi_wh_teaser_f4">جەرد و ڕاپۆرت بەپێی کۆگە</span></li>
                            </ul>
                            <button type="button" class="btn btn-brand wms-mwh-teaser__cta" onclick="if(typeof openMultiWarehousePremiumUpsell==='function')openMultiWarehousePremiumUpsell();">
                                <i class="fas fa-unlock-alt"></i> <span data-i18n="multi_wh_teaser_cta">بیکڕە و چالاک بکە — $224</span>
                            </button>
                            <p class="wms-mwh-teaser__foot" data-i18n="multi_wh_teaser_foot">پەیوەندی بە پشتیوانی بکە · دوای کڕین کۆدی Pro لێرە چالاک دەکەیت.</p>
                        </div>
                        <div class="wms-mwh-teaser__preview" aria-hidden="true">
                            <div class="wms-mwh-teaser__mock">
                                <div class="wms-mwh-teaser__mock-bar"><span class="wms-mwh-teaser__mock-chip is-on"><i class="fas fa-layer-group"></i> هەموو</span><span class="wms-mwh-teaser__mock-chip"><i class="fas fa-store"></i> فرۆشگا 1</span><span class="wms-mwh-teaser__mock-chip"><i class="fas fa-warehouse"></i> کۆگە</span><span class="wms-mwh-teaser__mock-ic"><i class="fas fa-dolly"></i></span></div>
                                <div class="wms-mwh-teaser__mock-row"><i class="fas fa-barcode"></i> بارکود سکان → گواستنەوە</div>
                                <div class="wms-mwh-teaser__mock-row"><i class="fas fa-file-invoice"></i> وەسڵا #000042</div>
                            </div>
                            <div class="wms-mwh-teaser__lock"><i class="fas fa-lock"></i></div>
                        </div>
                    </div>
                </div>

                <div id="wms-warehouse-hub" class="card wms-wh-hub">
                    <div class="wms-wh-toolbar">
                        <div class="wms-wh-toolbar__title">
                            <span class="wms-wh-toolbar__badge" aria-hidden="true"><i class="fas fa-store"></i></span>
                            <span class="wms-wh-toolbar__name" data-i18n="wh_locations_title">کۆگاکان</span>
                            <span id="wms-wh-count-badge" class="wms-wh-badge">0</span>
                        </div>
                        <div id="wms-wh-chips" class="wms-wh-chips" role="tablist" aria-label="هەڵبژاردنی کۆگە"></div>
                        <div class="wms-wh-toolbar__actions">
                            <button type="button" id="wms-wh-manage-toggle" class="wms-wh-tool-btn wms-wh-manage-toggle" onclick="if(typeof toggleWmsWhManageMode==='function')toggleWmsWhManageMode();" title="بەڕێوەبردنی کۆگاکان"><i class="fas fa-pen" aria-hidden="true"></i></button>
                            <button type="button" class="wms-wh-tool-btn wms-wh-transfer-toggle" onclick="if(typeof openWhTransferModal==='function')openWhTransferModal();" title="گواستنەوە"><i class="fas fa-dolly" aria-hidden="true"></i></button>
                        </div>
                    </div>
                    <div class="wms-wh-quick-bar" role="group" aria-label="زیادکردنی کۆگە" hidden>
                        <input type="hidden" id="wms-wh-edit-id" value="">
                        <input type="text" id="wms-wh-quick-name" class="input-std wms-wh-quick-input" placeholder="ناوی کۆگەی نوێ" autocomplete="off" onkeydown="if(event.key==='Enter'){event.preventDefault();if(typeof quickAddWarehouse==='function')quickAddWarehouse();}">
                        <input type="password" id="wms-wh-quick-pin" class="input-std wms-wh-quick-input wms-wh-quick-pin" placeholder="پاسۆرد (ئارەزوو)" inputmode="numeric" autocomplete="new-password" maxlength="8" title="٤ تا ٨ ژمارە — بەتاڵ = بێ پاسۆرد">
                        <button type="button" id="wms-wh-cancel-edit-btn" class="wms-wh-tool-btn wms-wh-cancel-edit-btn" style="display:none" onclick="if(typeof cancelEditWarehouse==='function')cancelEditWarehouse();" title="هەڵوەشاندنەوە"><i class="fas fa-times"></i></button>
                        <button type="button" id="wms-wh-quick-add-btn" class="btn btn-brand wms-wh-quick-add-btn" onclick="if(typeof quickAddWarehouse==='function')quickAddWarehouse();"><i class="fas fa-plus" id="wms-wh-quick-add-icon" aria-hidden="true"></i> <span id="wms-wh-quick-add-label">زیادکردن</span></button>
                    </div>
                    <input type="hidden" id="wms-filter-warehouse" value="">
                </div>

                <div class="card wms-filters-card">
                    <div class="wms-filters-grid">
                        <div class="wms-filter-field">
                            <label class="wms-field-label"><i class="fas fa-tags"></i> <span data-i18n="products_tbl_category">پۆل</span></label>
                            <select id="wms-filter-cat" class="input-std wms-input" onchange="renderWarehouse()">
                                <option value="" data-i18n-opt="wh_filter_all">هەمی</option>
                            </select>
                        </div>
                        <div class="wms-filter-field" id="wms-filter-currency-field">
                            <label class="wms-field-label"><i class="fas fa-coins"></i> <span data-i18n="wh_filter_currency">دراڤ</span></label>
                            <select id="wms-filter-currency" class="input-std wms-input" onchange="if(typeof renderWarehouse==='function')renderWarehouse()" aria-label="فلتەرا دراڤی">
                                <option value="" data-i18n-opt="wh_filter_currency_all">هەمی کەرەستە</option>
                                <option value="IQD" data-i18n-opt="wh_filter_currency_iqd">کەرەستەیێن ب دینار</option>
                                <option value="USD" data-i18n-opt="wh_filter_currency_usd">کەرەستەیێن ب دۆلار</option>
                            </select>
                        </div>
                        <div class="wms-filter-field" id="wms-filter-manufacturer-field">
                            <label class="wms-field-label"><i class="fas fa-industry"></i> <span data-i18n="wh_filter_manufacturer">کۆمپانیا دروستکەر</span></label>
                            <select id="wms-filter-manufacturer" class="input-std wms-input" onchange="renderWarehouse()">
                                <option value="" data-i18n-opt="wh_filter_all">هەمی</option>
                            </select>
                        </div>
                        <div class="wms-filter-field wms-filter-field--search">
                            <label class="wms-field-label"><i class="fas fa-search"></i> <span data-i18n="wh_search_label">گەڕان / بارکۆد</span></label>
                            <label class="wms-search-wrap" for="wh-search">
                                <i class="fas fa-search wms-search-wrap__icon" aria-hidden="true"></i>
                                <input type="text" id="wh-search" class="input-std wms-input wms-search-input" data-i18n-placeholder="wh_search_placeholder" placeholder="لێگەڕیان (SKU، بارکۆد، ناڤ)..." onkeyup="renderWarehouse()" oninput="if(typeof convertArabicNumerals==='function')convertArabicNumerals(this); if(typeof renderWarehouse==='function')renderWarehouse();" onfocus="this.select()" data-i18n-title="wh_search_input_title" title="بارکۆدی سکان بکە یان بنڤیسە بۆ گەڕانێ" autocomplete="off">
                            </label>
                        </div>
                        <button type="button" class="wms-barcode-btn" onclick="document.getElementById('wh-search').focus(); document.getElementById('wh-search').select();"><span class="wms-flat-ic wms-flat-ic--barcode"><i class="fas fa-barcode"></i></span><span data-i18n="products_tbl_barcode">بارکۆد</span></button>
                    </div>
                </div>

                <div class="wms-kpi-grid">
                    <div class="wms-kpi-card wms-kpi-card--dark wms-kpi-card--cost">
                        <span class="wms-flat-ic wms-flat-ic--cost" aria-hidden="true"><i class="fas fa-coins"></i></span>
                        <div class="wms-kpi-card__body"><h3><i class="fas fa-coins pos-ic" aria-hidden="true"></i> <span data-i18n="wh_kpi_total_cost">بهایێ کۆگەهێ (کرین)</span></h3><h1 id="wh-total-cost">0</h1></div>
                    </div>
                    <div class="wms-kpi-card wms-kpi-card--dark wms-kpi-card--sale">
                        <span class="wms-flat-ic wms-flat-ic--sale" aria-hidden="true"><i class="fas fa-tags"></i></span>
                        <div class="wms-kpi-card__body"><h3><i class="fas fa-tags pos-ic" aria-hidden="true"></i> <span data-i18n="wh_kpi_total_sale">بهایێ فرۆتنێ</span></h3><h1 id="wh-total-sale">0</h1></div>
                    </div>
                    <div class="wms-kpi-card wms-kpi-card--dark wms-kpi-card--profit">
                        <span class="wms-flat-ic wms-flat-ic--profit" aria-hidden="true"><i class="fas fa-chart-line"></i></span>
                        <div class="wms-kpi-card__body"><h3><i class="fas fa-chart-line pos-ic" aria-hidden="true"></i> <span data-i18n="wh_kpi_expected_profit">قازانجێ چاوەڕوانکری</span></h3><h1 id="wh-total-profit">0</h1></div>
                    </div>
                    <div class="wms-kpi-card wms-kpi-card--light wms-kpi-card--clickable" onclick="renderWarehouse('all')" data-i18n-title="wh_kpi_title_all" title="هەمی ئایتم">
                        <span class="wms-flat-ic wms-flat-ic--all" aria-hidden="true"><i class="fas fa-boxes"></i></span>
                        <div class="wms-kpi-card__body"><h3><i class="fas fa-boxes pos-ic" aria-hidden="true"></i> <span data-i18n="products_tbl_item">ئایتم</span></h3><h1 id="wh-count-all">0</h1></div>
                    </div>
                    <div class="wms-kpi-card wms-kpi-card--light wms-kpi-card--warn wms-kpi-card--clickable" onclick="renderWarehouse('low')" data-i18n-title="wh_kpi_title_low" title="کەمبوونەوە">
                        <span class="wms-flat-ic wms-flat-ic--warn" aria-hidden="true"><i class="fas fa-exclamation-triangle"></i></span>
                        <div class="wms-kpi-card__body"><h3><i class="fas fa-bell pos-ic" aria-hidden="true"></i> <span data-i18n="wh_kpi_alert_title">ئاگەهداری</span></h3><h1 id="wh-count-low">0</h1></div>
                    </div>
                    <div class="wms-kpi-card wms-kpi-card--light wms-kpi-card--out wms-kpi-card--clickable" onclick="renderWarehouse('out')" data-i18n-title="wh_kpi_title_out" title="نەما">
                        <span class="wms-flat-ic wms-flat-ic--out" aria-hidden="true"><i class="fas fa-ban"></i></span>
                        <div class="wms-kpi-card__body"><h3><i class="fas fa-ban pos-ic" aria-hidden="true"></i> <span data-i18n="wh_kpi_out_title">نەما</span></h3><h1 id="wh-count-out">0</h1></div>
                    </div>
                    <div class="wms-kpi-card wms-kpi-card--light wms-kpi-card--exp wms-kpi-card--clickable" onclick="renderWarehouse('expired')" data-i18n-title="wh_kpi_title_exp" title="بەسەرچوون">
                        <span class="wms-flat-ic wms-flat-ic--exp" aria-hidden="true"><i class="fas fa-calendar-times"></i></span>
                        <div class="wms-kpi-card__body"><h3><i class="fas fa-calendar-times pos-ic" aria-hidden="true"></i> <span data-i18n="wh_kpi_expiring_title">بەسەرچوویی</span></h3><h1 id="wh-count-exp">0</h1></div>
                    </div>
                </div>

                <div id="wms-alerts-strip" class="wms-alerts-card card" style="display:none;">
                    <div class="wms-alerts-card__head">
                        <h4 class="wms-alerts-card__title"><i class="fas fa-bell"></i> <span data-i18n="wh_alerts_heading">ئاگەهداری</span></h4>
                        <div id="wms-alerts-nav" class="wms-alerts-card__nav" style="display:none;">
                            <button type="button" class="btn btn-sm wms-pager-btn" id="wms-alerts-prev" onclick="if(typeof window.wmsAlertsStep==='function')window.wmsAlertsStep(-1);" data-i18n-title="wh_alerts_prev" title="پێشوو"><i class="fas fa-chevron-right"></i></button>
                            <span id="wms-alerts-page-info" class="wms-pager-info"></span>
                            <button type="button" class="btn btn-sm wms-pager-btn" id="wms-alerts-next" onclick="if(typeof window.wmsAlertsStep==='function')window.wmsAlertsStep(1);" data-i18n-title="wh_alerts_next" title="دواتر"><i class="fas fa-chevron-left"></i></button>
                        </div>
                    </div>
                    <div id="wms-alerts-content" class="wms-alerts-card__body"></div>
                </div>

                <div class="card wms-tasks-card" data-perm="warehouse_view">
                    <div class="wms-tasks-card__head">
                        <h3 class="wms-section-title"><i class="fas fa-th-large"></i> <span data-i18n="wh_tasks_heading">ئەرکێن کۆگەهێ</span></h3>
                        <p class="wms-section-hint"><span data-i18n="wh_tasks_hint">هەر دوگمەیەک کارێکی ڕوون دەکات. هەڵبژێرە بۆ ئەوەی دەتەوێت.</span></p>
                    </div>
                    <div class="wms-action-grid wh-sub-nav">
                        <button type="button" class="wms-action-tile wms-action-tile--movements" data-shortcut-id="warehouse-movements" draggable="true" onclick="nav('warehouse-movements')" title="لڤین و هویرکاریا ئایتمی — هاتن، چوون، کۆمپانیا کرینێ"><span class="wms-flat-ic wms-flat-ic--tile wms-flat-ic--movements"><i class="fas fa-exchange-alt"></i></span><span class="wms-action-tile__label" data-i18n="wh_nav_movements">١ لڤین / هویرکاری</span></button>
                        <button type="button" class="wms-action-tile wms-action-tile--stocktake" data-shortcut-id="warehouse-stocktake" draggable="true" onclick="nav('warehouse-stocktake')" title="پێداچوون/جەرد"><span class="wms-flat-ic wms-flat-ic--tile wms-flat-ic--stocktake"><i class="fas fa-clipboard-check"></i></span><span class="wms-action-tile__label" data-i18n="wh_nav_stocktake">٢ پێداچوون</span></button>
                        <button type="button" class="wms-action-tile wms-action-tile--suppliers" data-shortcut-id="warehouse-suppliers" draggable="true" onclick="nav('warehouse-suppliers')" title="دابینکەر"><span class="wms-flat-ic wms-flat-ic--tile wms-flat-ic--suppliers"><i class="fas fa-truck-loading"></i></span><span class="wms-action-tile__label" data-i18n="wh_nav_suppliers">٣ دابینکەر</span></button>
                        <button type="button" class="wms-action-tile wms-action-tile--reports" data-shortcut-id="warehouse-reports" draggable="true" onclick="nav('warehouse-reports')" title="ڕاپۆرت"><span class="wms-flat-ic wms-flat-ic--tile wms-flat-ic--reports"><i class="fas fa-chart-bar"></i></span><span class="wms-action-tile__label" data-i18n="wh_nav_reports">٤ ڕاپۆرت</span></button>
                        <button type="button" class="wms-action-tile wms-action-tile--transfer wms-action-tile--pro-locked" data-multi-wh-teaser-trigger onclick="if(typeof openMultiWarehousePremiumUpsell==='function')openMultiWarehousePremiumUpsell();" style="display:none;" title="گواستنەوە — Pro"><span class="wms-pro-lock-badge">FEAT · <span data-pos-price="feature">$50</span></span><span class="wms-flat-ic wms-flat-ic--tile wms-flat-ic--transfer"><i class="fas fa-dolly"></i></span><span class="wms-action-tile__label" data-i18n="wh_nav_transfer_pro">گواستنەوە</span></button>
                        <button type="button" class="wms-action-tile wms-action-tile--locations wms-action-tile--pro-locked" data-multi-wh-teaser-trigger onclick="if(typeof openMultiWarehousePremiumUpsell==='function')openMultiWarehousePremiumUpsell();" style="display:none;" title="کۆگاکان — Pro"><span class="wms-pro-lock-badge">FEAT · <span data-pos-price="feature">$50</span></span><span class="wms-flat-ic wms-flat-ic--tile wms-flat-ic--locations"><i class="fas fa-store"></i></span><span class="wms-action-tile__label" data-i18n="wh_nav_locations_pro">کۆگاکان</span></button>
                    </div>
                </div>

                <div class="card wms-table-card">
                    <div class="wms-table-card__head">
                        <h3 id="wh-list-title" class="wms-section-title"><i class="fas fa-list-alt"></i> لیستا کەرەستەیان</h3>
                        <div class="wms-print-tools">
                            <button type="button" id="wms-print-zero-toggle" class="wms-print-zero-toggle is-on" role="switch" aria-checked="true" onclick="if(typeof toggleWmsPrintZeroItems==='function')toggleWmsPrintZeroItems();" data-i18n-title="wh_print_zero_title" title="ل چاپێ: ON = ئایتمێن سفر دیار، OFF = نەدیار">
                                <span class="wms-print-zero-toggle__name" data-i18n="wh_print_zero_items">ئایتمێن سفر</span>
                                <span class="wms-print-zero-toggle__off">OFF</span>
                                <span class="wms-print-zero-toggle__track" aria-hidden="true"><span class="wms-print-zero-toggle__thumb"></span></span>
                                <span class="wms-print-zero-toggle__on">ON</span>
                            </button>
                            <button type="button" class="wms-print-btn" onclick="printInventoryList()"><i class="fas fa-print"></i> <span data-i18n="wh_print_list">چاپ</span></button>
                        </div>
                    </div>
                    <div class="wms-table-scroll">
                        <table class="report-table wms-products-table">
                            <thead>
                                <tr>
                                    <th><i class="fas fa-hashtag pos-ic" aria-hidden="true"></i> SKU</th>
                                    <th><i class="fas fa-barcode pos-ic" aria-hidden="true"></i> <span data-i18n="products_tbl_barcode">بارکۆد</span></th>
                                    <th><i class="fas fa-box pos-ic" aria-hidden="true"></i> <span data-i18n="wh_col_name">ناڤ</span></th>
                                    <th><i class="fas fa-layer-group pos-ic" aria-hidden="true"></i> <span data-i18n="products_tbl_category">پۆل</span></th>
                                    <th class="wms-col-manufacturer"><i class="fas fa-industry pos-ic" aria-hidden="true"></i> <span data-i18n="wh_col_manufacturer">کۆمپانیا دروستکەر</span></th>
                                    <th><i class="fas fa-coins pos-ic" aria-hidden="true"></i> <span data-i18n="products_tbl_cost">کرین (تاک)</span></th>
                                    <th><i class="fas fa-tag pos-ic" aria-hidden="true"></i> <span data-i18n="products_tbl_price">نرخ</span></th>
                                    <th><i class="fas fa-sort-numeric-down pos-ic" aria-hidden="true"></i> <span data-i18n="th_qty">ژمارە</span></th>
                                    <th><i class="fas fa-arrow-down pos-ic" aria-hidden="true"></i> <span data-i18n="wh_col_min">کەمترین</span></th>
                                    <th><i class="fas fa-calendar-alt pos-ic" aria-hidden="true"></i> <span data-i18n="wh_col_expiry">بەسەرچوون</span></th>
                                    <th><i class="fas fa-traffic-light pos-ic" aria-hidden="true"></i> <span data-i18n="wh_col_status">دۆخ</span></th>
                                </tr>
                            </thead>
                            <tbody id="wh-list-body"></tbody>
                        </table>
                    </div>
                    <div id="wh-table-nav" class="wms-table-pager" style="display:none;">
                        <button type="button" class="btn btn-sm wms-pager-btn" id="wh-table-prev" onclick="if(typeof window.wmsTablePageStep==='function')window.wmsTablePageStep(-1);" data-i18n-title="wh_alerts_prev" title="پێشوو"><i class="fas fa-chevron-right"></i></button>
                        <span id="wh-table-page-info" class="wms-pager-info"></span>
                        <button type="button" class="btn btn-sm wms-pager-btn" id="wh-table-next" onclick="if(typeof window.wmsTablePageStep==='function')window.wmsTablePageStep(1);" data-i18n-title="wh_alerts_next" title="دواتر"><i class="fas fa-chevron-left"></i></button>
                    </div>
                </div>
            </div>
        </div>

        <!-- پەنجەرا وردەکاریێن کەرەستەی (پەرگەهێ پێشکەفتی) -->
        <div id="wms-product-modal" class="modal-overlay" style="display:none;">
            <div class="glass-card wms-product-detail-card" style="max-width:520px; width:95%;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px;">
                    <h3 style="margin:0;"><i class="fas fa-box-open"></i> وردەکاریێن کەرەستەی (پەرگەهێ کەرەستەی)</h3>
                    <button type="button" class="btn btn-dark btn-sm" onclick="document.getElementById('wms-product-modal').style.display='none';">✖</button>
                </div>
                <div id="wms-product-detail-body" style="display:grid; gap:10px;"></div>
            </div>
        </div>

        <!-- پەنجەرا مێژویا کڕینێ (سەرجەمێ کڕینان) -->
        <div id="wms-purchase-history-modal" class="modal-overlay hist-modal" style="display:none; z-index: 1060;">
            <div class="glass-card hist-shell" data-accent="brand">
                <div class="hist-header">
                    <h2 class="hist-title"><i class="fas fa-history"></i> مێژویا کڕینێ (سەرجەمێ کڕینان)</h2>
                    <button type="button" class="btn btn-danger btn-sm" onclick="document.getElementById('wms-purchase-history-modal').style.display='none';"><i class="fas fa-times"></i> <span data-i18n="btn_close">داخستن</span></button>
                </div>
                <div style="font-weight:bold; margin-bottom:10px; font-size:1.1rem; color:var(--brand); flex-shrink:0;" id="wms-purchase-history-title"></div>
                <div class="hist-body" id="wms-purchase-history-body"></div>
            </div>
        </div>

        <!-- بەڕێوەبردنی کۆگاکان -->
        <div id="view-warehouse-locations" class="workspace">
            <h2 style="margin-bottom:4px;"><i class="fas fa-store"></i> <span data-i18n="wh_locations_title">کۆگاکان</span></h2>
            <div data-multi-wh-teaser-slot="locations"></div>
            <div data-multi-wh-active-only>
            <p style="color:var(--text-muted); margin-bottom:16px;">کۆگەی نوێ زیاد بکە — نموونە: سەرەکی، شەقە ٢، فرێزەر، کۆگەی دووەم.</p>
            <div class="card" style="margin-bottom:16px;">
                <h3 style="margin-top:0;">زیادکردن / دەستکاری</h3>
                <input type="hidden" id="wh-loc-edit-id" value="0">
                <div style="display:grid; gap:10px; grid-template-columns:repeat(auto-fit,minmax(180px,1fr));">
                    <div><label class="wms-field-label">ناوی کۆگە</label><input type="text" id="wh-loc-name" class="input-std" placeholder="کۆگەی سەرەکی"></div>
                    <div><label class="wms-field-label">کۆد</label><input type="text" id="wh-loc-code" class="input-std" placeholder="MAIN" dir="ltr"></div>
                    <div><label class="wms-field-label">ناونیشان</label><input type="text" id="wh-loc-address" class="input-std" placeholder="ناونیشان (ئارەزوومەندانە)"></div>
                    <div><label class="wms-field-label">ڕیزبەندی</label><input type="number" id="wh-loc-sort" class="input-std" value="0" min="0"></div>
                </div>
                <label style="display:flex;align-items:center;gap:8px;margin-top:10px;"><input type="checkbox" id="wh-loc-default"> کۆگەی سەرەکی (فرۆشتن و کڕین)</label>
                <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap;">
                    <button type="button" class="btn btn-brand" onclick="if(typeof saveWarehouseLocation==='function')saveWarehouseLocation();"><i class="fas fa-save"></i> پاراستن</button>
                    <button type="button" class="btn btn-outline" onclick="if(typeof resetWarehouseLocationForm==='function')resetWarehouseLocationForm();">پاککردنەوە</button>
                    <button type="button" class="btn btn-dark" onclick="nav('warehouse')"><i class="fas fa-arrow-right"></i> گەڕانەوە</button>
                </div>
            </div>
            <div class="card">
                <table class="report-table" style="width:100%;">
                    <thead><tr><th>ناو</th><th>کۆد</th><th>سەرەکی</th><th>ژمارەی ئایتم</th><th>کردار</th></tr></thead>
                    <tbody id="wh-locations-body"></tbody>
                </table>
            </div>
            </div>
        </div>

        <!-- گواستنەوە لە کۆگەیەک بۆ یەکێکی تر -->
        <div id="view-warehouse-transfers" class="workspace">
            <h2 style="margin-bottom:4px;"><i class="fas fa-dolly"></i> گواستنەوەی کاڵا</h2>
            <div data-multi-wh-teaser-slot="transfers"></div>
            <div data-multi-wh-active-only>
            <p style="color:var(--text-muted); margin-bottom:16px;">کاڵا لە کۆگەیەک بۆ کۆگەیەکی تر بگوازەوە — ژمارە لە سەرچاوە کەم، لە مەبەست زیاد دەبێت.</p>
            <div class="card" style="margin-bottom:16px;">
                <div style="display:grid;gap:12px;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));">
                    <div><label class="wms-field-label">لە کۆگە</label><select id="wh-transfer-from" class="input-std" onchange="if(typeof renderWarehouseTransferGrid==='function')renderWarehouseTransferGrid();"></select></div>
                    <div><label class="wms-field-label">بۆ کۆگە</label><select id="wh-transfer-to" class="input-std"></select></div>
                    <div><label class="wms-field-label">تێبینی</label><input type="text" id="wh-transfer-note" class="input-std" placeholder="هۆکار / تێبینی"></div>
                </div>
                <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap;">
                    <button type="button" class="btn btn-brand" onclick="if(typeof openWhTransferModal==='function')openWhTransferModal();"><i class="fas fa-dolly"></i> گواستنەوە (مۆدال)</button>
                    <button type="button" class="btn btn-brand" onclick="if(typeof openWhTransferHistoryModal==='function')openWhTransferHistoryModal();"><i class="fas fa-history"></i> مێژوو</button>
                    <button type="button" class="btn btn-dark" onclick="nav('warehouse')"><i class="fas fa-arrow-right"></i> گەڕانەوە</button>
                </div>
            </div>
            <div class="card">
                <div style="max-height:420px;overflow:auto;">
                    <table class="report-table" style="width:100%;">
                        <thead><tr><th>ئایتم</th><th>بەردەست (سەرچاوە)</th><th>ژمارەی گواستنەوە</th></tr></thead>
                        <tbody id="wh-transfer-grid-body"></tbody>
                    </table>
                </div>
            </div>
            <div class="card" style="margin-top:16px;">
                <h3 style="margin-top:0;">دوایین گواستنەوەکان</h3>
                <div id="wh-transfer-history" style="max-height:220px;overflow:auto;"></div>
            </div>
            </div>
        </div>

        <!-- پۆلێنکرن: تصنيف المواد بكل وضوح -->
        <div id="view-warehouse-categories" class="workspace">
            <h2 style="margin-bottom:4px;"><i class="fas fa-layer-group"></i> پۆلێنکرن</h2>
            <p style="color:var(--text-muted); margin-bottom:16px; font-size:0.95rem;">ئایتمەکان بە پۆل ڕێکبخە. پۆلێک هەڵبژێرە بۆ بینینی ئایتمەکانی ئەو پۆلە. <span id="wh-cat-summary" style="font-size:0.9rem;"></span></p>
            <div class="card" style="margin-bottom:15px;">
                <label style="display:block; font-weight:600; margin-bottom:8px; color:var(--text);">پۆل: هەڵبژاردن</label>
                <div style="display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
                    <select id="wh-cat-filter" class="input-std" style="max-width:280px; margin:0;" onchange="renderWarehouseByCategory()">
                        <option value="">هەمی ئایتم</option>
                    </select>
                    <button type="button" class="btn btn-sm btn-outline" onclick="nav('products')" data-perm="products_manage"><i class="fas fa-tags"></i> گۆڕینی پۆل → ڕێڤەبرنا ئایتمان</button>
                </div>
            </div>
            <div class="card">
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; margin-bottom:10px;">
                    <h3 id="wh-cat-list-title" style="margin:0;">ئایتم لگۆرەی ڤی جۆری</h3>
                    <button type="button" class="btn btn-sm btn-brand" onclick="printCategoryReport()"><i class="fas fa-print"></i> چاپ</button>
                </div>
                <div style="max-height:450px; overflow-y:auto;">
                    <table class="report-table">
                        <thead><tr><th>ئایتم</th><th>پۆل</th><th>ژمارە</th><th>دۆخ</th></tr></thead>
                        <tbody id="wh-cat-list-body"></tbody>
                    </table>
                </div>
            </div>
            <button type="button" class="btn btn-dark" onclick="nav('warehouse')"><i class="fas fa-arrow-right"></i> زڤڕین بۆ کۆگەهێ</button>
        </div>

        <!-- ڕێڤەبرنا پرێنتەران (پرێنتەر) -->
        <div id="view-warehouse-printers" class="workspace">
            <h2><i class="fas fa-print"></i> پرێنتەر (ڕێڤەبرنا پرێنتەران)</h2>
            <p style="color:var(--text-muted); margin-bottom:16px;">گرێدانا پرێنتەران بۆ چاپکرنا لاپەران یان ڕاپۆرتا پێداچوون/جەردی.</p>
            <div class="card" style="margin-bottom:15px;">
                <h3 style="margin:0 0 10px 0;">پرێنتەرێن تۆمارکری</h3>
                <ul id="wh-printers-list" style="list-style:none; padding:0; margin:0;"></ul>
                <div style="display:flex; gap:10px; align-items:center; margin-top:12px; flex-wrap:wrap;">
                    <input type="text" id="wh-printer-name" class="input-std" placeholder="ناڤێ پرێنتەری" style="max-width:220px; margin:0;">
                    <button type="button" class="btn btn-brand" onclick="addWarehousePrinter()"><i class="fas fa-plus"></i> زێدەکرن</button>
                </div>
            </div>
            <div class="card">
                <p style="margin:0 0 10px 0; font-size:0.9rem;"><i class="fas fa-info-circle" style="color:var(--brand);"></i> د دەمێ چاپکرنا ڕاپۆرتێ یان لاپەرەی، ئەڤ پرێنتەرە وەک هەلبژاردە دێ دەرکەڤن.</p>
                <button type="button" class="btn btn-info btn-sm" onclick="window.print();"><i class="fas fa-print"></i> تاقیکرنا چاپی</button>
            </div>
            <button type="button" class="btn btn-dark" onclick="nav('warehouse')"><i class="fas fa-arrow-right"></i> زڤڕین بۆ کۆگەهێ</button>
        </div>

        <!-- پێداچوون/جەرد: خسار/زێدە ب پارە + مێژوویا جەردێن هەیڤانە و ساڵانە -->
        <div id="view-warehouse-stocktake" class="workspace">
            <h2 style="margin-bottom:4px;"><i class="fas fa-clipboard-list"></i> پێداچوون/جەردا کۆگەهێ</h2>
            <p style="color:var(--text-muted); margin-bottom:12px; font-size:0.95rem;">ژمارا دروست بنڤیسە — دەمێ بنڤیسی، خسار و زێدە ب <strong>پارە</strong> دەردکەڤن. جەردا هەیڤانە یان ساڵانە تۆمار بکە بۆ بینینی جارا بەری.</p>
            <div class="card" style="margin-bottom:16px;padding:12px;" data-multi-wh-only>
                <label class="wms-field-label" for="stocktake-warehouse-select"><i class="fas fa-warehouse"></i> کۆگە بۆ جەرد</label>
                <select id="stocktake-warehouse-select" class="input-std" style="max-width:320px;" onchange="if(typeof renderWarehouseStocktake==='function')renderWarehouseStocktake();"></select>
            </div>
            <div id="stocktake-last-banner" style="display:none; margin-bottom:14px; padding:12px 14px; border-radius:10px; background:rgba(37,99,235,0.08); border:1px solid rgba(37,99,235,0.18); font-size:0.92rem;"></div>
            <div id="stocktake-kpi-grid" style="display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); gap:10px; margin-bottom:14px;">
                <div class="card" style="margin:0; padding:12px; border-right:4px solid var(--danger);">
                    <div style="font-size:0.8rem; color:var(--text-muted);">خسار (کێم)</div>
                    <div id="st-kpi-short-money" style="font-size:1.2rem; font-weight:800; color:var(--danger);">0</div>
                    <div id="st-kpi-short-meta" style="font-size:0.8rem; color:var(--text-muted);">0 ئایتم</div>
                </div>
                <div class="card" style="margin:0; padding:12px; border-right:4px solid var(--success);">
                    <div style="font-size:0.8rem; color:var(--text-muted);">زێدە (هاتییە دیتن)</div>
                    <div id="st-kpi-surplus-money" style="font-size:1.2rem; font-weight:800; color:var(--success);">0</div>
                    <div id="st-kpi-surplus-meta" style="font-size:0.8rem; color:var(--text-muted);">0 ئایتم</div>
                </div>
                <div class="card" style="margin:0; padding:12px; border-right:4px solid var(--brand);">
                    <div style="font-size:0.8rem; color:var(--text-muted);">خالص (زێدە − خسار)</div>
                    <div id="st-kpi-net-money" style="font-size:1.2rem; font-weight:800; color:var(--brand);">0</div>
                    <div id="st-kpi-ok-meta" style="font-size:0.8rem; color:var(--text-muted);">0 ئایتم ڕاست</div>
                </div>
            </div>
            <div class="card no-print" style="margin-bottom:15px;">
                <div style="display:flex; flex-wrap:wrap; gap:12px; align-items:center;">
                    <label style="font-weight:700;">جۆرێ جەردێ:</label>
                    <select id="stocktake-period" class="input-std" style="margin:0; max-width:180px;">
                        <option value="monthly">هەیڤانە</option>
                        <option value="yearly">ساڵانە</option>
                        <option value="spot">جەردا ئێستا</option>
                    </select>
                    <input type="text" id="stocktake-note" class="input-std" placeholder="تێبینی (ئارەزوو)..." style="margin:0; min-width:180px; flex:1;">
                    <button type="button" class="btn btn-success" onclick="applyStocktake()"><i class="fas fa-save"></i> نویکرنا کۆگەهێ (ئەپلای)</button>
                    <button type="button" class="btn btn-brand" onclick="printStocktakeReport()" id="btn-print-stocktake"><i class="fas fa-print"></i> چاپکرنا ڕاپۆرت</button>
                </div>
            </div>
            <div class="card no-print stocktake-filters-card" style="margin-bottom:16px;">
                <div class="wms-filters-grid stocktake-filters-grid">
                    <div class="wms-filter-field">
                        <label class="wms-field-label" for="stocktake-cat-filter"><i class="fas fa-tags"></i> <span data-i18n="products_tbl_category">پۆل</span></label>
                        <select id="stocktake-cat-filter" class="input-std wms-input" onchange="if(typeof renderWarehouseStocktake==='function')renderWarehouseStocktake();">
                            <option value="" data-i18n-opt="wh_filter_all">هەمی</option>
                        </select>
                    </div>
                    <div class="wms-filter-field wms-filter-field--search">
                        <label class="wms-field-label" for="stocktake-search"><i class="fas fa-search"></i> <span data-i18n="wh_search_label">گەڕان / بارکۆد</span></label>
                        <label class="wms-search-wrap" for="stocktake-search">
                            <i class="fas fa-search wms-search-wrap__icon" aria-hidden="true"></i>
                            <input type="text" id="stocktake-search" class="input-std wms-input wms-search-input" data-i18n-placeholder="wh_search_placeholder" placeholder="لێگەڕیان (SKU، بارکۆد، ناڤ)..." onkeyup="if(typeof renderWarehouseStocktake==='function')renderWarehouseStocktake();" oninput="if(typeof convertArabicNumerals==='function')convertArabicNumerals(this); if(typeof renderWarehouseStocktake==='function')renderWarehouseStocktake();" onfocus="this.select()" data-i18n-title="wh_search_input_title" title="بارکۆدی سکان بکە یان بنڤیسە بۆ گەڕانێ" autocomplete="off">
                        </label>
                    </div>
                    <button type="button" class="wms-barcode-btn" onclick="var el=document.getElementById('stocktake-search'); if(el){el.focus();el.select();}"><span class="wms-flat-ic wms-flat-ic--barcode"><i class="fas fa-barcode"></i></span><span data-i18n="products_tbl_barcode">بارکۆد</span></button>
                </div>
                <div style="display:flex; flex-wrap:wrap; gap:8px; margin-top:12px;">
                    <button type="button" class="btn btn-sm btn-brand st-view-tab active" id="st-view-all" onclick="setStocktakeViewFilter('all')">هەمی</button>
                    <button type="button" class="btn btn-sm btn-danger st-view-tab" id="st-view-short" onclick="setStocktakeViewFilter('short')">کێم (خسار)</button>
                    <button type="button" class="btn btn-sm btn-success st-view-tab" id="st-view-surplus" onclick="setStocktakeViewFilter('surplus')">زێدە</button>
                    <button type="button" class="btn btn-sm btn-outline st-view-tab" id="st-view-diff" onclick="setStocktakeViewFilter('diff')">تەنێ جوداهی</button>
                </div>
                <p class="stocktake-visible-meta" style="margin:10px 0 0 0; font-size:0.85rem; color:var(--text-muted);"><span id="stocktake-visible-count">0 / 0</span> <span data-i18n="products_tbl_item">ئایتم</span></p>
            </div>
            <div class="card" id="stocktake-report-area">
                <h3 style="margin:0 0 12px 0;">لیستا پێداچوون/جەرد</h3>
                <div style="max-height:500px; overflow-y:auto;">
                    <table class="report-table" id="stocktake-table">
                        <thead><tr><th>ئایتم</th><th>کۆگەها سیستەم</th><th>ژمارا دروست (بنڤیسە)</th><th>جوداهی</th><th>پارە</th></tr></thead>
                        <tbody id="stocktake-tbody"></tbody>
                    </table>
                </div>
            </div>
            <div class="card" style="margin-top:16px;">
                <h3 style="margin:0 0 8px 0;"><i class="fas fa-history"></i> مێژوویا جەردان (هەیڤانە / ساڵانە)</h3>
                <p style="color:var(--text-muted); font-size:0.85rem; margin:0 0 10px 0;">جارا بەری چەوا کربو: خسار، زێدە، خالص. کلیک بکە بۆ هویرکاری.</p>
                <div style="max-height:280px; overflow-y:auto;">
                    <table class="report-table">
                        <thead><tr><th>بەروار</th><th>جۆر</th><th>خسار</th><th>زێدە</th><th>خالص</th><th>کارمەند</th></tr></thead>
                        <tbody id="stocktake-history-tbody"><tr><td colspan="6" style="text-align:center; color:var(--text-muted);">هێشتا جەرد تۆمار نەبوویە</td></tr></tbody>
                    </table>
                </div>
                <div id="stocktake-history-detail" style="display:none; margin-top:12px;"></div>
            </div>
            <button type="button" class="btn btn-dark no-print" style="margin-top:12px;" onclick="nav('warehouse')"><i class="fas fa-arrow-right"></i> زڤڕین بۆ کۆگەهێ</button>
        </div>

        <!-- لڤین: هەمی هاتن و چوون و تەلەف ئێکجار + گەڕانا ئایتمێ -->
        <div id="view-warehouse-movements" class="workspace">
            <h2 style="margin-bottom:4px;"><i class="fas fa-exchange-alt"></i> لڤین و هویرکاریا ئایتمی</h2>
            <p style="color:var(--text-muted); margin-bottom:14px; font-size:0.95rem;">ئایتمێ هەلبژێرە: هەمی هاتن و چوون، کۆمپانیا کرینێ، و هویرکاریا هەژمارێ — ئێک پەیج.</p>
            <div class="card" style="margin-bottom:14px;">
                <div style="display:flex; flex-wrap:wrap; gap:12px; align-items:center; margin-bottom:12px;">
                    <div class="wms-mov-search-box" style="position:relative; flex:1; min-width:260px;">
                        <label class="wms-search-wrap" for="wms-mov-item-search" style="width:100%;">
                            <i class="fas fa-search wms-search-wrap__icon" aria-hidden="true"></i>
                            <input type="text" id="wms-mov-item-search" class="input-std wms-input wms-search-input" placeholder="ئایتم هەلبژێرە: ناڤ یان بارکۆد..." style="margin:0; width:100%;" oninput="if(typeof convertArabicNumerals==='function')convertArabicNumerals(this); if(typeof scheduleWmsMovements==='function')scheduleWmsMovements();" onkeydown="if(typeof handleWmsMovSearchKey==='function')handleWmsMovSearchKey(event);" onfocus="if(typeof paintWmsMovSuggestions==='function')paintWmsMovSuggestions();" autocomplete="off">
                        </label>
                        <div id="wms-mov-suggest" class="wms-mov-suggest" style="display:none; position:absolute; top:calc(100% + 4px); right:0; left:0; z-index:40; max-height:280px; overflow-y:auto; background:var(--card-bg, #fff); border:1px solid var(--border, #e5e7eb); border-radius:10px; box-shadow:0 8px 24px rgba(0,0,0,0.12);"></div>
                    </div>
                    <span style="font-weight:600; color:var(--text);">بەروار:</span>
                    <input type="date" id="wms-mov-date-start" class="input-std" style="margin:0; font-size:0.9rem;" onchange="renderWmsMovements()">
                    <span>تا</span>
                    <input type="date" id="wms-mov-date-end" class="input-std" style="margin:0; font-size:0.9rem;" onchange="renderWmsMovements()">
                    <button type="button" class="btn btn-sm btn-outline" title="هەمی بەروار" onclick="(function(){ var a=document.getElementById('wms-mov-date-start'); var b=document.getElementById('wms-mov-date-end'); if(a)a.value=''; if(b)b.value=''; if(typeof renderWmsMovements==='function')renderWmsMovements(); })();"><i class="fas fa-times"></i> پاککردنەوە</button>
                    <button type="button" class="btn btn-sm btn-outline" title="تەنێ ئەڤرۆ" onclick="(function(){ var t=(typeof getTodayDateInputValue==='function')?getTodayDateInputValue():''; var a=document.getElementById('wms-mov-date-start'); var b=document.getElementById('wms-mov-date-end'); if(a)a.value=t; if(b)b.value=t; if(typeof renderWmsMovements==='function')renderWmsMovements(); })();">ئەڤرۆ</button>
                    <span style="margin-right:auto;"></span>
                    <button type="button" class="btn btn-brand btn-sm" onclick="printStockMovementLog()"><i class="fas fa-print"></i> چاپ</button>
                </div>
                <p style="margin:0 0 10px 0; font-size:0.85rem; color:var(--text-muted);"><strong>هەمی</strong> = هاتن + چوون + تەلەف | <strong>هاتن</strong> = کرین + زڤڕاندن کریار | <strong>چوون</strong> = فرۆتن + زڤڕاندن دابینکەر | <strong>تەلەف</strong></p>
                <div style="display:flex; gap:8px; flex-wrap:wrap; margin-bottom:12px;">
                    <button type="button" class="btn btn-brand btn-sm wms-mov-tab active" id="wms-mov-tab-all" onclick="setWmsMovTab('all')">هەمی</button>
                    <button type="button" class="btn btn-success btn-sm wms-mov-tab" id="wms-mov-tab-in" onclick="setWmsMovTab('inbound')">هاتن (کرین + زڤڕاندن)</button>
                    <button type="button" class="btn btn-danger btn-sm wms-mov-tab" id="wms-mov-tab-out" onclick="setWmsMovTab('outbound')">چوون (فرۆتن + زڤڕاندن)</button>
                    <button type="button" class="btn btn-warning btn-sm wms-mov-tab" id="wms-mov-tab-damaged" onclick="setWmsMovTab('damaged')">تەلەف</button>
                </div>
                <div id="wms-mov-item-summary" style="display:none; margin:0 0 12px 0;"></div>
                <input type="hidden" id="stock-card-search" value="">
                <div id="wms-mov-item-ledger" style="display:none; margin:0 0 12px 0;">
                    <div id="stock-card-product" class="card" style="margin-bottom:12px; display:none;">
                        <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:10px;">
                            <div>
                                <h3 id="stock-card-product-name" style="margin-top:0;"></h3>
                                <p id="stock-card-product-meta" style="color:var(--text-muted); margin:0 0 10px 0;"></p>
                                <div id="stock-card-summary" style="display:grid; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); gap:10px; margin-bottom:12px;"></div>
                            </div>
                            <button type="button" class="btn btn-sm btn-brand" onclick="printStockCardReport()"><i class="fas fa-print"></i> چاپ (هویرکاری)</button>
                        </div>
                    </div>
                    <div class="card" style="margin-bottom:12px;">
                        <h3 style="margin:0 0 8px 0;">هویرکاریا هەژمارێ (کرین، فرۆتن، زڤڕاندن)</h3>
                        <div style="max-height:280px; overflow-y:auto;">
                            <table class="report-table">
                                <thead><tr><th>بەروار</th><th>جۆرێ کارێ</th><th>ژمارە</th><th>کرین</th><th>پەیوەند</th><th>بەکارهێنەر</th></tr></thead>
                                <tbody id="stock-card-tbody"></tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div style="max-height:520px; overflow-y:auto;">
                    <table class="report-table">
                        <thead><tr><th>بەروار</th><th>ئایتم</th><th>جۆرێ کارێ</th><th>کۆمپانی</th><th>ژمارە</th><th>تێبینی</th></tr></thead>
                        <tbody id="wms-movements-tbody"></tbody>
                    </table>
                </div>
            </div>
            <button type="button" class="btn btn-dark" onclick="nav('warehouse')"><i class="fas fa-arrow-right"></i> زڤڕین بۆ کۆگەهێ</button>
        </div>

        <!-- ڕێڤەبرنا دابینکەران -->
        <div id="view-warehouse-suppliers" class="workspace">
            <h2><i class="fas fa-truck"></i> دابینکەر</h2>
            <p style="color:var(--text-muted); margin-bottom:14px;">لیستا دابینکەران دگەل قەرز و مێژوویا کڕینێ.</p>
            <div class="card">
                <div style="display:flex; justify-content:flex-end; margin-bottom:10px;"><button type="button" class="btn btn-sm btn-brand" onclick="printSuppliersList()"><i class="fas fa-print"></i> چاپکرنا لیستێ</button></div>
                <div style="max-height:500px; overflow-y:auto;">
                    <table class="report-table">
                        <thead><tr><th>ناڤ</th><th>تەلەفۆن</th><th>قەرز</th><th>کڕین (ژمارە)</th><th>کار</th></tr></thead>
                        <tbody id="wms-suppliers-tbody"></tbody>
                    </table>
                </div>
            </div>
            <button type="button" class="btn btn-dark" style="margin-top:12px;" onclick="nav('warehouse')"><i class="fas fa-arrow-right"></i> زڤڕین</button>
        </div>

        <!-- ڕاپۆرتێن کۆگەهێ -->
        <div id="view-warehouse-reports" class="workspace">
            <h2><i class="fas fa-chart-bar"></i> ڕاپۆرتا کۆگەهێ</h2>
            <div class="stat-grid" style="margin-bottom:16px;">
                <div class="stat-card" style="border-right-color:var(--brand);">
                    <h3>بهایێ کۆگەهێ</h3>
                    <h1 id="wms-report-value">0</h1>
                </div>
                <div class="stat-card" style="border-right-color:var(--success);">
                    <h3>ژمارا لڤینان (هاتن)</h3>
                    <h1 id="wms-report-inbound-count">0</h1>
                </div>
                <div class="stat-card" style="border-right-color:var(--danger);">
                    <h3>ژمارا زیانان (تەلەف)</h3>
                    <h1 id="wms-report-waste-count">0</h1>
                </div>
            </div>
            <div class="card">
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; margin-bottom:10px;">
                    <div><h3 style="margin:0;">مێژوویا لڤینان (تۆمارا لڤینان)</h3><p style="color:var(--text-muted); font-size:0.9rem; margin:4px 0 0 0;">کۆیا دوماهی یا هاتن، چوون و تێکچوونێ.</p></div>
                    <button type="button" class="btn btn-sm btn-brand" onclick="printStockMovementLog()"><i class="fas fa-print"></i> چاپ</button>
                </div>
                <div style="max-height:400px; overflow-y:auto;">
                    <table class="report-table">
                        <thead><tr><th>بەروار</th><th>جۆر</th><th>کەرەستە</th><th>ژمارە</th><th>تێبینی</th></tr></thead>
                        <tbody id="wms-report-log-tbody"></tbody>
                    </table>
                </div>
            </div><button type="button" class="btn btn-success" style="margin-top:12px;" onclick="nav('warehouse-stocktake')"><i class="fas fa-clipboard-list"></i> ڕاپۆرتا پێداچوون/جەردی</button>
            <button type="button" class="btn btn-dark" style="margin-top:12px; margin-right:8px;" onclick="nav('warehouse')"><i class="fas fa-arrow-right"></i> زڤڕین</button>
        </div>

        <!-- WASTE MANAGEMENT VIEW (same shell as POS / فرۆشتن) -->
        <div id="view-waste" class="workspace txn-mobile-screen txn-view-shell txn-theme txn-theme--waste">
            <div class="pos-layout returns-layout">
                <div id="waste-menu-panel" class="pos-menu returns-menu no-print">
                    <div class="pos-top-bar txn-view-top-bar pos-header-polished no-print">
                        <div class="pos-header-row pos-header-row-top">
                            <div class="pos-header-brand txn-screen-head-waste">
                                <div class="txn-screen-head-icon txn-screen-head-icon-waste" aria-hidden="true">
                                    <i class="fas fa-trash-alt"></i>
                                </div>
                                <h3 class="txn-screen-head-title" data-i18n="nav_waste">تەلەف</h3>
                            </div>
                            <div class="pos-top-bar-actions pos-header-toolbar">
                                <button type="button" class="btn btn-sm btn-pos-refresh pos-header-tool-btn txn-toolbar-refresh" onclick="if(typeof initWasteScreen==='function')initWasteScreen();" title="تازەکردنەوە" aria-label="تازەکردنەوە"><i class="fas fa-sync-alt"></i></button>
                                <div class="txn-toolbar-more">
                                    <button type="button" class="btn btn-sm pos-header-tool-btn" onclick="if(typeof openWasteHistoryPanel==='function')openWasteHistoryPanel('history');" data-i18n-title="waste_log_title" title="مێژوو"><i class="fas fa-history"></i></button>
                                    <button type="button" class="btn btn-sm pos-header-tool-btn" onclick="if(typeof openWasteHistoryPanel==='function')openWasteHistoryPanel('expiry');" data-i18n-title="waste_expiry_section_title" title="بەسەرچوون"><i class="fas fa-exclamation-triangle"></i></button>
                                </div>
                                <button type="button" class="btn btn-sm pos-header-tool-btn txn-toolbar-toggle" title="زیاتر" aria-label="زیاتر"><i class="fas fa-ellipsis-h"></i></button>
                                <button type="button" class="btn btn-sm pos-header-tool-btn" onclick="nav('pos')" title="فرۆشتن" aria-label="فرۆشتن"><i class="fas fa-cash-register"></i></button>
                            </div>
                        </div>
                        <div class="pos-header-row pos-header-row-fields pos-header-fields-unified">
                            <div class="pos-header-search-box" style="flex:1;">
                                <div class="pos-search-unit-bar txn-unit-bar">
                                    <label class="pos-search-field" for="waste-barcode-input-main">
                                        <i class="fas fa-search pos-search-field-icon" aria-hidden="true"></i>
                                        <input type="text" id="waste-barcode-input-main" class="pos-search-input pos-header-input" data-i18n-placeholder="waste_search_placeholder" placeholder="لێگەریان / بارکۆد بۆ تەلەف..." onkeyup="if(event.key !== 'Enter' && typeof debouncedRenderWasteMenu==='function')debouncedRenderWasteMenu(this.value)" onkeydown="if(typeof handleWasteBarcode==='function')handleWasteBarcode(event)" oninput="convertArabicNumerals(this)">
                                    </label>
                                    <div id="waste-unit-toggles" class="pos-unit-toggles no-print">
                                        <button type="button" id="btn-waste-unit-piece" class="pos-unit-btn active" data-unit="piece" onclick="setWasteUnit('piece')" data-i18n-title="pos_unit_piece" title="تاک"><i class="fas fa-cube"></i></button>
                                        <button type="button" id="btn-waste-unit-pack" class="pos-unit-btn" data-unit="pack" onclick="setWasteUnit('pack')" data-i18n-title="pos_unit_pack" title="پاکێت"><i class="fas fa-boxes"></i></button>
                                        <button type="button" id="btn-waste-unit-carton" class="pos-unit-btn" data-unit="carton" onclick="setWasteUnit('carton')" data-i18n-title="pos_unit_carton" title="کارتۆن"><i class="fas fa-box"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <p class="waste-txn-hint no-print is-hidden" data-i18n="waste_txn_hint" hidden>سکان بکە یان کاڵایێ هەلبژێرە — د سەبەتێ دا دکە، پاشان تۆمار بکە.</p>
                    </div>
                    <div id="waste-category-tabs-scroll-wrap" class="category-tabs-scroll-wrap">
                        <button type="button" class="cat-scroll-btn" data-cat-scroll="prev" onclick="if(typeof scrollTxnCategoryTabs==='function')scrollTxnCategoryTabs('waste-category-tabs',false);" title="پێشوو" aria-label="پێشوو"><i class="fas fa-chevron-right"></i></button>
                        <div id="waste-category-tabs" class="category-list-container"></div>
                        <button type="button" class="cat-scroll-btn" data-cat-scroll="next" onclick="if(typeof scrollTxnCategoryTabs==='function')scrollTxnCategoryTabs('waste-category-tabs',true);" title="دواتر" aria-label="دواتر"><i class="fas fa-chevron-left"></i></button>
                    </div>
                    <div class="pos-content-wrapper">
                        <div class="pos-products-toolbar no-print">
                            <span class="pos-products-toolbar-title"><i class="fas fa-trash-alt" aria-hidden="true"></i> <span data-i18n="waste_products_toolbar">کاڵا بۆ تەلەف</span></span>
                            <span id="waste-products-count" class="pos-products-count-badge">0</span>
                        </div>
                        <div id="waste-products" class="product-grid"></div>
                    </div>
                </div>
                <div class="cart-resize-divider no-print" data-resize-handle="waste" role="separator" aria-orientation="vertical" aria-valuemin="280" aria-valuemax="720" aria-label="قەبارەی سەبەتە" title="ڕاکێشە بۆ گەورە/بچووککردنی سەبەتە"></div>
                <div id="waste-bill-panel" class="pos-bill returns-bill returns-bill-redesign unified-cart-panel txn-sheet-panel txn-sheet-collapsed">
                    <div class="returns-bill-header pos-bill-header-slim no-print">
                        <h2 class="returns-bill-title"><i class="fas fa-trash-alt"></i> <span data-i18n="waste_cart_title">سەبەتەیا تەلەفێ</span></h2>
                        <div class="pos-bill-header-slim-actions pos-cart-chrome no-print">
                            <button type="button" class="returns-bill-clear" onclick="if(typeof clearWasteCart==='function')clearWasteCart()" data-i18n-title="waste_cart_clear" title="پاککردنەوە"><i class="fas fa-trash-alt"></i></button>
                        </div>
                    </div>
                    <div class="bill-expand-main">
                        <div class="waste-cart-reason-bar no-print">
                            <div class="waste-cart-reason-top">
                                <span class="waste-cart-reason-label" data-i18n="waste_th_reason">ئەگەر</span>
                                <div class="pos-waste-reason-chips waste-cart-reason-chips" id="waste-cart-reason-chips">
                                    <button type="button" class="pos-waste-reason-chip is-active" data-reason="بەسەرچوون" data-i18n="waste_reason_expired" onclick="if(typeof wasteCartPickReason==='function')wasteCartPickReason(this)">بەسەرچوون</button>
                                    <button type="button" class="pos-waste-reason-chip" data-reason="شکان" data-i18n="waste_reason_broken" onclick="if(typeof wasteCartPickReason==='function')wasteCartPickReason(this)">شکان</button>
                                    <button type="button" class="pos-waste-reason-chip" data-reason="خراپی" data-i18n="waste_reason_spoiled" onclick="if(typeof wasteCartPickReason==='function')wasteCartPickReason(this)">خراپی</button>
                                    <button type="button" class="pos-waste-reason-chip" data-reason="__other__" data-i18n="waste_reason_other" onclick="if(typeof wasteCartPickReason==='function')wasteCartPickReason(this)">هۆکارێ تر</button>
                                </div>
                            </div>
                            <input type="text" id="waste-cart-reason-input" class="input-std waste-cart-reason-input is-hidden" data-i18n-placeholder="waste_prompt_reason" placeholder="ئەگەر چییە؟" value="بەسەرچوون" aria-hidden="true">
                        </div>
                        <div class="bill-items returns-bill-items">
                            <div class="returns-cart-header-slim basket-list-header bill-items-header waste-cart-header no-print">
                                <span class="returns-h-item basket-h-item" data-i18n="waste_th_item">ئایتم</span>
                                <span class="returns-h-price basket-h-price" data-i18n="waste_th_cost">کرین</span>
                                <span class="returns-h-qty basket-h-qty" data-i18n="waste_th_qty">ژمارە</span>
                                <span class="returns-h-total basket-h-total" data-i18n="returns_h_total">کۆم</span>
                                <span class="returns-h-action basket-h-action"></span>
                            </div>
                            <div id="waste-bill-rows" class="returns-cart-rows-wrap"></div>
                        </div>
                        <div class="bill-footer pos-bill-footer-compact returns-bill-footer">
                            <div class="bill-total-section pos-bill-total-strip">
                                <div class="pos-bill-total-main">
                                    <span class="bill-total-label" data-i18n="waste_loss_total">زەرەر (کرین)</span>
                                    <h2 id="waste-bill-total" class="bill-total-value">0</h2>
                                </div>
                            </div>
                            <div class="pos-action-grid pos-bill-action-grid pos-bill-checkout-bar no-print">
                                <div class="pos-action-left pos-bill-tools" role="group" aria-label="ئامراز">
                                    <button type="button" class="btn-pos-mini btn-pos-tool danger" onclick="if(typeof clearWasteCart==='function')clearWasteCart()" title="ژێبرن"><i class="fas fa-trash-alt"></i><span class="pos-tool-label">ژێبرن</span></button>
                                </div>
                                <div class="pos-action-right pos-bill-checkout-actions">
                                    <button type="button" id="waste-confirm-btn" class="btn-sell-large btn-sell-primary btn-sell-returns returns-confirm-btn" onclick="if(typeof processWasteCart==='function')processWasteCart()" data-i18n-title="waste_btn_report" title="تۆمارکرنا تەلەفێ"><i class="fas fa-check" aria-hidden="true"></i> <span data-i18n="waste_btn_report">تۆمارکرنا تەلەفێ</span></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="waste-history-panel" class="waste-history-panel is-hidden no-print" aria-hidden="true">
                <div class="waste-history-panel-backdrop" onclick="if(typeof closeWasteHistoryPanel==='function')closeWasteHistoryPanel();"></div>
                <div class="waste-history-panel-sheet card">
                    <div class="waste-history-panel-head">
                        <h3 id="waste-history-panel-title" style="margin:0;"><i class="fas fa-history"></i> <span data-i18n="waste_log_title">مێژوویا تەلەف بوونێ</span></h3>
                        <button type="button" class="btn btn-sm btn-dark" onclick="if(typeof closeWasteHistoryPanel==='function')closeWasteHistoryPanel();"><i class="fas fa-times"></i></button>
                    </div>
                    <div id="waste-history-section">
                        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:10px;">
                            <div style="display:flex; gap:5px; align-items:center; flex-wrap:wrap;">
                                <input type="date" id="date-start-waste" class="input-std" style="margin:0; font-size:0.9rem;" onchange="renderWasteList()">
                                <span data-i18n="waste_date_to">تا</span>
                                <input type="date" id="date-end-waste" class="input-std" style="margin:0; font-size:0.9rem;" onchange="renderWasteList()">
                                <button type="button" class="btn btn-sm btn-dark" onclick="resetDateFilter('waste', renderWasteList)" title="پاککردنەوەی فلتەر"><i class="fas fa-times"></i></button>
                                <span id="waste-filter-hint" class="pos-waste-filter-hint is-hidden"></span>
                            </div>
                            <button type="button" class="btn btn-sm btn-brand" onclick="printWasteReport()"><i class="fas fa-print"></i> <span data-i18n="waste_btn_print_report">چاپکرنا ڕاپۆرتێ</span></button>
                        </div>
                        <div style="max-height:55vh; overflow:auto;">
                            <table class="report-table"><thead><tr><th><i class="fas fa-hashtag"></i> <span data-i18n="waste_th_id">ID</span></th><th><i class="fas fa-box"></i> <span data-i18n="waste_th_item">ئایتم</span></th><th><i class="fas fa-sort-numeric-down"></i> <span data-i18n="waste_th_qty">ژمارە</span></th><th><i class="fas fa-coins"></i> <span data-i18n="waste_th_cost">کرین</span></th><th><i class="fas fa-question-circle"></i> <span data-i18n="waste_th_reason">ئەگەر</span></th><th><i class="fas fa-user"></i> <span data-i18n="waste_th_staff">کارمەند</span></th><th><i class="fas fa-calendar-alt"></i> <span data-i18n="waste_th_date">بەروار</span></th><th><i class="fas fa-undo"></i> <span data-i18n="waste_th_action">کار</span></th></tr></thead>
                            <tbody id="waste-list-body"></tbody></table>
                        </div>
                    </div>
                    <div id="waste-expiry-section" class="is-hidden">
                        <p style="color:var(--text-muted); font-size:0.9rem;" data-i18n="waste_expiry_section_hint">ئەڤ ئایتمە نێزیکی بەسەرچوونێ نە یان بەسەرچووینە. کلیک بکە بۆ زێدەکرن بۆ سەبەتێ.</p>
                        <div style="max-height:55vh; overflow:auto;">
                            <table class="report-table">
                                <thead><tr>
                                    <th data-i18n="waste_th_item">ئایتم</th>
                                    <th data-i18n="waste_th_stock">کۆگەه</th>
                                    <th data-i18n="waste_th_expiry">بەروار</th>
                                    <th data-i18n="waste_th_days_left">ڕۆژێن ماین</th>
                                    <th data-i18n="waste_th_action">کار</th>
                                </tr></thead>
                                <tbody id="waste-candidates-body"></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- RECIPE MANAGER VIEW -->
        <div id="view-recipes" class="workspace">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                <h2><i class="fas fa-boxes-packing recipe-ui-icon"></i> <span data-i18n="nav_recipes">ڕەچەتە</span></h2>
            </div>
            
            <div class="card">
                <div style="background:rgba(59, 130, 246, 0.1); padding:15px; border-radius:12px; border:1px dashed var(--brand); margin-bottom:20px; display:flex; gap:15px; align-items:center;">
                    <i class="fas fa-info-circle" style="font-size:2rem; color:var(--brand);"></i>
                    <div>
                        <h4 style="margin:0 0 5px 0;">چەوا کار دکەت؟</h4>
                        <p style="margin:0; font-size:0.9rem; opacity:0.8;">١) ڕەچەتە دیار بکە (مەتەلەن: برگەر = نان + گۆشت + سەلاد). ٢) <strong>دروستکرن</strong> بکە — کەرەستە کەم دبن، بەرهەما ئامادە د کۆگەهێ زیاد دبیت. ٣) دەمێ فرۆتنێ، ئەگەر برگەر ل کۆگەهێ هەبیت تەنها وێ دکەمە؛ ئەگەر نەبیت کەرەستە دکەمە (وەک پێشوو).</p>
                    </div>
                </div>

                <div style="position:relative;">
                    <i class="fas fa-search" style="position:absolute; right:15px; top:15px; color:var(--text-muted);"></i>
                    <input type="text" class="input-std" placeholder="🔍 لێگەریان ل ئایتمان (Search Products)..." style="padding-right:40px;" onkeyup="renderRecipeManager(this.value)">
                </div>
                
                <div id="recipe-manager-grid" class="recipe-grid"></div>
            </div>
        </div>

