<?php
/**
 * Supabase license gate: each installation has a unique serial in settings (pos_license_serial).
 * On Windows/Linux the serial is derived from BIOS/device serial when possible so it matches the laptop identifier.
 * Admin activates licenses in Supabase (table licenses); RPC check_pos_license allows anon to verify one serial only.
 *
 * Offline use (after one successful activation): when Supabase is unreachable or rate-limited (HTTP 0, 402, 408, 429, 5xx), POS keeps working while pos_license_cache_ok=1 and pos_license_cache_until is valid.
 * Admin delete/block in Supabase applies within pos_license_online_recheck_seconds (default 30s) when the client has internet — not bypassed by the long offline-until stamp.
 * Pass ?license_recheck=1 to force an immediate Supabase ping (page load / admin-revoke poll).
 * Per-machine device gate uses pos_dev_grace for short TTL and pos_dev_trusted for devices that verified ok at least once (offline with valid license cache only).
 * Env: POS_LICENSE_ONLINE_RECHECK_SEC (30–600) reduces Supabase API calls when many shops are online.
 */
if (!defined('POS_SUPABASE_URL')) {
    define('POS_SUPABASE_URL', 'https://aqdfwriwdmgsqjhofwfb.supabase.co');
}
if (!defined('POS_SUPABASE_ANON_KEY')) {
    define('POS_SUPABASE_ANON_KEY', 'sb_publishable_myt7cKSr4LaTvtxtEuYKsw_nbHQNWhi');
}
/** Strict $99 slot + TERM per فرعی laptop/phone. Set false only for explicit admin open-access testing. */
if (!defined('POS_TERMINAL_REQUIRE_SECURITY')) {
    define('POS_TERMINAL_REQUIRE_SECURITY', true);
}

/**
 * POST JSON to Supabase REST. Retries with SSL verify off if typical Windows/XAMPP CA issues (code 0 / SSL errors).
 *
 * @return array{0:int,1:string,2:?string,3:bool} [http_code, body, curl_error, used_insecure_ssl]
 */
function pos_supabase_http_post_json($url, $body, array $headerLines) {
    $headerLines[] = 'Accept: application/json';
    $attemptInsecure = false;
    if (function_exists('curl_init')) {
        for ($attempt = 0; $attempt < 2; $attempt++) {
            $verify = !$attemptInsecure;
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $body,
                CURLOPT_HTTPHEADER => $headerLines,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 8,
                CURLOPT_CONNECTTIMEOUT => 4,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_SSL_VERIFYPEER => $verify,
                CURLOPT_SSL_VERIFYHOST => $verify ? 2 : 0,
            ]);
            $res = curl_exec($ch);
            $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $cerr = curl_error($ch);
            $errno = (int)curl_errno($ch);
            curl_close($ch);

            $bodyOut = $res === false ? '' : (string)$res;
            $sslProblem = ($code === 0 && ($errno === 60 || $errno === 77 || $errno === 35 || $errno === 51 || $errno === 58))
                || (stripos((string)$cerr, 'SSL') !== false);

            if ($code !== 200 && $code !== 0 && !$attemptInsecure) {
                return [$code, $bodyOut, $cerr !== '' ? $cerr : null, false];
            }
            if ($code === 200) {
                return [$code, $bodyOut, $cerr !== '' ? $cerr : null, $attemptInsecure];
            }
            // Retry once without SSL verify (common on XAMPP Windows without ca-bundle).
            if ($attempt === 0 && ($code === 0 || $sslProblem)) {
                $attemptInsecure = true;
                continue;
            }
            return [$code, $bodyOut, $cerr !== '' ? $cerr : null, $attemptInsecure];
        }
        return [0, '', 'curl failed', $attemptInsecure];
    }
    $ctx = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => implode("\r\n", $headerLines) . "\r\n",
            'content' => $body,
            'timeout' => 8,
            'ignore_errors' => true,
        ],
        'ssl' => [
            'verify_peer' => true,
            'verify_peer_name' => true,
        ],
    ]);
    $res = @file_get_contents($url, false, $ctx);
    $code = 0;
    if (isset($http_response_header[0]) && preg_match('/\s(\d{3})\s/', (string)$http_response_header[0], $m)) {
        $code = (int)$m[1];
    }
    if ($code !== 200 && $res === false) {
        $ctx2 = stream_context_create([
            'http' => [
                'method' => 'POST',
                'header' => implode("\r\n", $headerLines) . "\r\n",
                'content' => $body,
                'timeout' => 8,
                'ignore_errors' => true,
            ],
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
            ],
        ]);
        $res = @file_get_contents($url, false, $ctx2);
        if (isset($http_response_header[0]) && preg_match('/\s(\d{3})\s/', (string)$http_response_header[0], $m)) {
            $code = (int)$m[1];
        }
        return [$code, $res === false ? '' : (string)$res, null, true];
    }
    return [$code, $res === false ? '' : (string)$res, null, false];
}

/**
 * @return array{ok:bool,status?:string,reason?:string,http_code?:int,detail?:string}
 */
function pos_supabase_check_license_remote($serial) {
    $key = POS_SUPABASE_ANON_KEY;
    if ($key === '') {
        return ['ok' => false, 'reason' => 'config'];
    }
    $url = rtrim(POS_SUPABASE_URL, '/') . '/rest/v1/rpc/check_pos_license';
    $payload = json_encode(['p_serial' => $serial], JSON_UNESCAPED_UNICODE);
    $headers = [
        'Content-Type: application/json',
        'apikey: ' . $key,
        'Authorization: Bearer ' . $key,
    ];
    list($code, $raw, $curlErr, $insecureSsl) = pos_supabase_http_post_json($url, $payload, $headers);
    // Compatibility fallback: some Supabase projects define RPC argument as "serial" (not "p_serial"),
    // which returns HTTP 400 if the JSON key does not match.
    if ($code === 400) {
        $payloadAlt = json_encode(['serial' => $serial], JSON_UNESCAPED_UNICODE);
        list($code2, $raw2, $curlErr2, $insecureSsl2) = pos_supabase_http_post_json($url, $payloadAlt, $headers);
        if ($code2 === 200) {
            $code = $code2;
            $raw = $raw2;
            $curlErr = $curlErr2;
            $insecureSsl = $insecureSsl2;
        } else {
            // Keep the second attempt details because they usually include the definitive RPC signature error.
            $code = $code2;
            $raw = $raw2;
            if (!empty($curlErr2)) {
                $curlErr = $curlErr2;
            }
            $insecureSsl = $insecureSsl2;
        }
    }
    if ($code !== 200) {
        return [
            'ok' => false,
            'reason' => 'http',
            'http_code' => $code,
            'detail' => substr($raw, 0, 400),
            'curl_error' => $curlErr,
            'insecure_ssl' => $insecureSsl,
        ];
    }
    $j = json_decode($raw, true);
    if (is_string($j)) {
        $j = json_decode($j, true);
    }
    if (!is_array($j)) {
        return ['ok' => false, 'reason' => 'parse', 'detail' => substr($raw, 0, 200), 'insecure_ssl' => $insecureSsl];
    }
    if (isset($j['ok'])) {
        return $j;
    }
    return ['ok' => false, 'reason' => 'shape', 'detail' => substr($raw, 0, 200)];
}

/**
 * Normalize browser device key — must stay aligned with Postgres public._pos_normalize_client_device_key.
 */
function pos_normalize_client_device_key(string $raw): string {
    $v = strtolower(trim($raw));
    $v = preg_replace('/[^a-z0-9_-]/', '', $v);
    if ($v === '' || strlen($v) < 8 || strlen($v) > 128) {
        return '';
    }
    return $v;
}

/**
 * Server-visible client IP (same for all browsers on one PC on typical LAN DHCP per host).
 * Optional: POS_TRUST_PROXY_FOR_DEVICE_IP=1 with X-Forwarded-For first hop behind reverse proxy.
 */
function pos_normalize_request_ip(string $raw): string {
    $s = strtolower(trim($raw));
    if ($s === '') {
        return '';
    }
    if (strpos($s, '%') !== false) {
        $parts = explode('%', $s, 2);
        $s = trim((string)($parts[0] ?? ''));
    }
    $s = preg_replace('/[^0-9a-f\.:]/', '', $s);
    if ($s === '') {
        return '';
    }
    return substr($s, 0, 63);
}

function pos_client_request_ip_for_pos_device(): string {
    $trust = getenv('POS_TRUST_PROXY_FOR_DEVICE_IP');
    if (
        $trust !== false && trim((string)$trust) !== ''
        && !in_array(strtolower(trim((string)$trust)), ['0', 'false', 'off', 'no'], true)
    ) {
        $xff = isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? (string)$_SERVER['HTTP_X_FORWARDED_FOR'] : '';
        if ($xff !== '') {
            $first = trim(explode(',', $xff, 2)[0]);
            $nip = pos_normalize_request_ip($first);
            if ($nip !== '') {
                return $nip;
            }
        }
    }
    $ra = isset($_SERVER['REMOTE_ADDR']) ? (string)$_SERVER['REMOTE_ADDR'] : '';
    return pos_normalize_request_ip($ra);
}

/**
 * Generic Supabase RPC POST with optional JSON body fallback (HTTP 400 signature mismatch).
 *
 * @return array Decoded JSON object on success, or error structure with reason/http_code.
 */
function pos_supabase_rpc_post_json(string $rpcName, array $payload, ?array $payloadAlt = null): array {
    $key = POS_SUPABASE_ANON_KEY;
    if ($key === '') {
        return ['ok' => false, 'reason' => 'config', 'registered' => false];
    }
    $url = rtrim(POS_SUPABASE_URL, '/') . '/rest/v1/rpc/' . rawurlencode($rpcName);
    $body = json_encode($payload, JSON_UNESCAPED_UNICODE);
    $headers = [
        'Content-Type: application/json',
        'apikey: ' . $key,
        'Authorization: Bearer ' . $key,
    ];
    list($code, $raw, $curlErr, $insecureSsl) = pos_supabase_http_post_json($url, $body, $headers);
    if ($code === 400 && $payloadAlt !== null) {
        $bodyAlt = json_encode($payloadAlt, JSON_UNESCAPED_UNICODE);
        list($code2, $raw2, $curlErr2, $insecureSsl2) = pos_supabase_http_post_json($url, $bodyAlt, $headers);
        if ($code2 === 200) {
            $code = $code2;
            $raw = $raw2;
            $curlErr = $curlErr2;
            $insecureSsl = $insecureSsl2;
        } else {
            $code = $code2;
            $raw = $raw2;
            if (!empty($curlErr2)) {
                $curlErr = $curlErr2;
            }
            $insecureSsl = $insecureSsl2;
        }
    }
    if ($code !== 200) {
        return [
            'ok' => false,
            'reason' => 'http',
            'http_code' => $code,
            'detail' => substr((string)$raw, 0, 400),
            'curl_error' => $curlErr,
            'insecure_ssl' => $insecureSsl,
            'registered' => false,
        ];
    }
    $j = json_decode($raw, true);
    if (is_string($j)) {
        $j = json_decode($j, true);
    }
    if (!is_array($j)) {
        return ['ok' => false, 'reason' => 'parse', 'detail' => substr((string)$raw, 0, 200), 'insecure_ssl' => $insecureSsl, 'registered' => false];
    }
    return $j;
}

/**
 * @return array{registered?:bool,status?:string,reason?:string,ok?:bool}
 */
function pos_supabase_register_device_remote(string $installationSerial, string $deviceKeyRaw, array $meta): array {
    $serial = trim($installationSerial);
    $keyNorm = pos_normalize_client_device_key($deviceKeyRaw);
    if ($serial === '' || strlen($serial) < 4 || $keyNorm === '') {
        return ['registered' => false, 'reason' => 'invalid_input'];
    }
    $payload = [
        'p_installation_serial' => $serial,
        'p_device_key' => $keyNorm,
        'p_meta' => $meta,
    ];
    $payloadAlt = [
        'installation_serial' => $serial,
        'device_key' => $keyNorm,
        'meta' => $meta,
    ];
    $j = pos_supabase_rpc_post_json('register_pos_device', $payload, $payloadAlt);
    if (isset($j['reason']) && $j['reason'] === 'http') {
        return $j;
    }
    if (isset($j['registered'])) {
        return $j;
    }
    return ['registered' => false, 'reason' => 'shape', 'detail' => json_encode($j, JSON_UNESCAPED_UNICODE)];
}

/**
 * @return array{ok:bool,status?:string,reason?:string,http_code?:int}
 */
function pos_supabase_check_device_remote(string $installationSerial, string $deviceKeyRaw): array {
    $serial = trim($installationSerial);
    $keyNorm = pos_normalize_client_device_key($deviceKeyRaw);
    if ($serial === '' || strlen($serial) < 4 || $keyNorm === '') {
        return ['ok' => false, 'status' => 'invalid', 'reason' => 'invalid_input'];
    }
    $payload = [
        'p_installation_serial' => $serial,
        'p_device_key' => $keyNorm,
    ];
    $payloadAlt = [
        'installation_serial' => $serial,
        'device_key' => $keyNorm,
    ];
    $j = pos_supabase_rpc_post_json('check_pos_device', $payload, $payloadAlt);
    if (isset($j['reason']) && $j['reason'] === 'http') {
        return [
            'ok' => false,
            'status' => 'http',
            'reason' => 'http',
            'http_code' => isset($j['http_code']) ? (int)$j['http_code'] : 0,
            'detail' => isset($j['detail']) ? (string)$j['detail'] : '',
            'curl_error' => isset($j['curl_error']) ? $j['curl_error'] : null,
        ];
    }
    if (isset($j['ok'])) {
        return $j;
    }
    return ['ok' => false, 'status' => 'shape', 'reason' => 'shape'];
}

function pos_http_read_pos_device_key(): string {
    $h = '';
    if (!empty($_SERVER['HTTP_X_POS_DEVICE_KEY'])) {
        $h = trim((string)$_SERVER['HTTP_X_POS_DEVICE_KEY']);
    } elseif (!empty($_SERVER['REDIRECT_HTTP_X_POS_DEVICE_KEY'])) {
        $h = trim((string)$_SERVER['REDIRECT_HTTP_X_POS_DEVICE_KEY']);
    }
    return $h;
}

function pos_http_read_pos_device_role(): string {
    $h = '';
    if (!empty($_SERVER['HTTP_X_POS_DEVICE_ROLE'])) {
        $h = trim((string)$_SERVER['HTTP_X_POS_DEVICE_ROLE']);
    } elseif (!empty($_SERVER['REDIRECT_HTTP_X_POS_DEVICE_ROLE'])) {
        $h = trim((string)$_SERVER['REDIRECT_HTTP_X_POS_DEVICE_ROLE']);
    }
    return strtolower($h);
}

function pos_terminal_pro_required_message(): string {
    return 'Pro plan is required to enable sub-device/terminal (branch) access. Upgrade from Basic ($224), then purchase $99 slots per device.';
}

function pos_terminal_pro_plus_required_message(): string {
    return pos_terminal_pro_required_message();
}

function pos_terminal_slot_required_message(): string {
    return 'خانەی سیکوریتی ($99) نییە — ١ خانە = ١ لاپتۆپ/موبایلی فرعی. لە لاپتۆپی سەرەکی خانە بکڕە، پاشان کۆدی TERM لێرە بنووسە.';
}

function pos_tier_allows_terminal_branches(string $tier): bool {
    $t = pos_subscription_tier_normalize($tier);
    return $t === 'pro' || $t === 'pro_plus';
}

function pos_api_terminal_pro_required_exit($conn, string $serial, string $message = ''): void {
    if (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: application/json; charset=utf-8');
    $msg = trim($message) !== '' ? trim($message) : pos_terminal_pro_required_message();
    echo json_encode([
        'status' => 'terminal_pro_required',
        'message' => $msg,
        'license_serial' => $serial,
        'device_detail' => 'pro_required',
        'terminal_activation_required' => true,
        'terminal_security_required' => true,
        'device_role' => 'terminal',
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

function pos_api_terminal_pro_plus_required_exit($conn, string $serial, string $message = ''): void {
    pos_api_terminal_pro_required_exit($conn, $serial, $message);
}

/** Shop already on Pro / Pro Plus — phone should enter TERM, not an upgrade wall. */
function pos_shop_allows_fragi_term_redeem($conn, string $serial): bool {
    if (!$conn || trim($serial) === '' || !function_exists('pos_subscription_sync_tier')) {
        return false;
    }
    $tier = (string) pos_subscription_sync_tier($conn, $serial);
    return pos_tier_allows_terminal_branches($tier);
}

function pos_api_fragi_needs_term_code_exit($conn, string $serial, string $message = ''): void {
    $msg = trim($message) !== ''
        ? trim($message)
        : 'کۆدی TERM بنڤیسە — ژ لاپتۆپێ سەرەکی ڕێکخستن → خانەی سیکوریتی.';
    $securityCode = function_exists('pos_ensure_license_security_code')
        ? (string) pos_ensure_license_security_code($conn)
        : '';
    pos_api_device_json_exit($conn, $serial, $msg, [
        'device_detail' => 'slot_required',
        'device_role' => 'terminal',
        'terminal_security_required' => true,
        'terminal_activation_required' => true,
        'license_security_code' => $securityCode,
    ]);
}

function pos_normalize_network_mac(string $raw): string {
    $m = strtoupper(preg_replace('/[^A-F0-9]/', '', $raw));
    if (strlen($m) !== 12) {
        return '';
    }
    return substr($m, 0, 2) . ':' . substr($m, 2, 2) . ':' . substr($m, 4, 2) . ':'
        . substr($m, 6, 2) . ':' . substr($m, 8, 2) . ':' . substr($m, 10, 2);
}

function pos_network_adapter_type_from_label(string $label): string {
    $t = strtolower(trim($label));
    if ($t === '') {
        return 'unknown';
    }
    if (strpos($t, 'wi-fi') !== false || strpos($t, 'wifi') !== false || strpos($t, 'wireless') !== false || strpos($t, '802.11') !== false) {
        return 'wifi';
    }
    if (strpos($t, 'ethernet') !== false || strpos($t, 'lan') !== false || strpos($t, 'gbe') !== false || strpos($t, 'realtek') !== false) {
        return 'lan';
    }
    return 'unknown';
}

/**
 * @return list<array{mac:string,type:string,name:string}>
 */
function pos_detect_network_adapters(): array {
    static $cached = null;
    if (is_array($cached)) {
        return $cached;
    }
    $out = [];
    $os = defined('PHP_OS_FAMILY') ? PHP_OS_FAMILY : PHP_OS;

    if ($os === 'Windows') {
        $ps = 'powershell -NoProfile -ExecutionPolicy Bypass -Command '
            . '"Get-CimInstance Win32_NetworkAdapterConfiguration | Where-Object { $_.IPEnabled -eq $true -and $_.MACAddress } '
            . '| Select-Object Description, MACAddress | ConvertTo-Json -Compress"';
        $raw = pos_license_shell_read($ps);
        if ($raw !== '') {
            $decoded = json_decode($raw, true);
            $rows = is_array($decoded) && isset($decoded[0]) ? $decoded : (is_array($decoded) ? [$decoded] : []);
            foreach ($rows as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $name = trim((string)($row['Description'] ?? ''));
                $mac = pos_normalize_network_mac((string)($row['MACAddress'] ?? ''));
                if ($mac === '') {
                    continue;
                }
                $out[] = [
                    'mac' => $mac,
                    'type' => pos_network_adapter_type_from_label($name),
                    'name' => $name,
                ];
            }
        }
        if (!$out) {
            $getmac = pos_license_shell_read('getmac /v /fo list');
            if ($getmac !== '') {
                $currentName = '';
                $currentMac = '';
                foreach (preg_split('/\r\n|\r|\n/', $getmac) as $line) {
                    $line = trim((string)$line);
                    if ($line === '') {
                        continue;
                    }
                    if (stripos($line, 'Connection Name:') === 0) {
                        $currentName = trim(substr($line, strlen('Connection Name:')));
                    } elseif (stripos($line, 'Physical Address:') === 0) {
                        $currentMac = pos_normalize_network_mac(trim(substr($line, strlen('Physical Address:'))));
                        if ($currentMac !== '') {
                            $out[] = [
                                'mac' => $currentMac,
                                'type' => pos_network_adapter_type_from_label($currentName),
                                'name' => $currentName,
                            ];
                        }
                        $currentName = '';
                        $currentMac = '';
                    }
                }
            }
        }
    } elseif ($os === 'Linux') {
        $sys = @glob('/sys/class/net/*') ?: [];
        foreach ($sys as $path) {
            $iface = basename($path);
            if ($iface === 'lo' || !is_readable($path . '/address')) {
                continue;
            }
            $mac = pos_normalize_network_mac((string)@file_get_contents($path . '/address'));
            if ($mac === '') {
                continue;
            }
            $out[] = [
                'mac' => $mac,
                'type' => pos_network_adapter_type_from_label($iface),
                'name' => $iface,
            ];
        }
    }

    $cached = $out;
    return $out;
}

/**
 * @return array{mac:string,type:string,adapters:array<int,array{mac:string,type:string,name:string}>}
 */
function pos_pick_network_identity(string $prefer = 'auto'): array {
    $adapters = pos_detect_network_adapters();
    if (!$adapters) {
        return ['mac' => '', 'type' => 'unknown', 'adapters' => []];
    }
    $pick = null;
    $prefer = strtolower(trim($prefer));
    if ($prefer === 'wifi' || $prefer === 'lan') {
        foreach ($adapters as $a) {
            if (($a['type'] ?? '') === $prefer) {
                $pick = $a;
                break;
            }
        }
    }
    if ($pick === null) {
        foreach ($adapters as $a) {
            if (($a['type'] ?? '') === 'wifi') {
                $pick = $a;
                break;
            }
        }
    }
    if ($pick === null) {
        foreach ($adapters as $a) {
            if (($a['type'] ?? '') === 'lan') {
                $pick = $a;
                break;
            }
        }
    }
    if ($pick === null) {
        $pick = $adapters[0];
    }
    return [
        'mac' => (string)($pick['mac'] ?? ''),
        'type' => (string)($pick['type'] ?? 'unknown'),
        'adapters' => $adapters,
    ];
}

/**
 * Client on LAN/Wi‑Fi hitting the XAMPP host (phone/tablet) — not the primary console on localhost.
 */
function pos_client_is_remote_lan_pos_client(): bool {
    $ip = pos_client_request_ip_for_pos_device();
    if ($ip === '' || $ip === '127.0.0.1' || $ip === '::1') {
        return false;
    }
    if (stripos($ip, '::ffff:127.0.0.1') === 0) {
        return false;
    }
    $server = '';
    if (!empty($_SERVER['SERVER_ADDR'])) {
        $server = pos_normalize_request_ip((string)$_SERVER['SERVER_ADDR']);
    }
    if ($server !== '' && $ip === $server) {
        return false;
    }
    return true;
}

function pos_http_read_pos_client_seed(): string {
    $h = '';
    if (!empty($_SERVER['HTTP_X_POS_CLIENT_SEED'])) {
        $h = trim((string)$_SERVER['HTTP_X_POS_CLIENT_SEED']);
    } elseif (!empty($_SERVER['REDIRECT_HTTP_X_POS_CLIENT_SEED'])) {
        $h = trim((string)$_SERVER['REDIRECT_HTTP_X_POS_CLIENT_SEED']);
    }
    if ($h === '' && isset($_POST['client_seed'])) {
        $h = trim((string)$_POST['client_seed']);
    }
    if ($h === '' && isset($_GET['client_seed'])) {
        $h = trim((string)$_GET['client_seed']);
    }
    return substr($h, 0, 128);
}

/**
 * Mobile/tablet on Wi‑Fi cannot expose real MAC to PHP — bind slot to a stable per-browser seed.
 */
function pos_derive_terminal_device_key_from_client_seed(string $installationSerial, string $clientSeed): string {
    $serial = trim($installationSerial);
    $seed = trim($clientSeed);
    if ($serial === '' || strlen($serial) < 4 || $seed === '') {
        return '';
    }
    $hash = hash('sha256', 'pos-term-client-v1:' . $serial . ':' . $seed, false);
    return pos_normalize_client_device_key('pos-term-' . substr($hash, 0, 32));
}

function pos_client_seed_as_network_mac(string $clientSeed): string {
    $seed = trim($clientSeed);
    if ($seed === '') {
        return '';
    }
    $hex = strtoupper(substr(hash('sha256', 'pos-term-mac-v1:' . $seed, false), 0, 12));
    return substr($hex, 0, 2) . ':' . substr($hex, 2, 2) . ':' . substr($hex, 4, 2) . ':'
        . substr($hex, 6, 2) . ':' . substr($hex, 8, 2) . ':' . substr($hex, 10, 2);
}

function pos_client_is_terminal_attempt(): bool {
    $role = pos_http_read_pos_device_role();
    if ($role === 'terminal') {
        return true;
    }
    $postRole = isset($_POST['device_role']) ? strtolower(trim((string)$_POST['device_role'])) : '';
    if ($postRole === 'terminal') {
        return true;
    }
    if (pos_is_fragi_device_key(pos_http_read_pos_device_key())) {
        return true;
    }
    if (pos_client_is_remote_lan_pos_client() && pos_http_read_pos_client_seed() !== '') {
        return true;
    }
    return false;
}

function pos_client_is_terminal_device_key(string $deviceKey): bool {
    $k = pos_normalize_client_device_key($deviceKey);
    return $k !== '' && strpos($k, 'pos-term-') === 0;
}

function pos_client_is_terminal_context(string $deviceKey, array $checkResult = []): bool {
    if (pos_client_is_terminal_attempt()) {
        return true;
    }
    if (pos_client_is_terminal_device_key($deviceKey)) {
        return true;
    }
    if (isset($checkResult['device_role']) && (string)$checkResult['device_role'] === 'terminal') {
        return true;
    }
    return false;
}

/**
 * Strict default: each فرعی needs a purchased $99 slot + TERM code (١ خانە = ١ ئامێر).
 * Opt-out: define('POS_TERMINAL_REQUIRE_SECURITY', false) or licenses.terminal_security_required = false in Supabase.
 */
function pos_license_terminal_security_required($conn, string $serial): bool {
    if (defined('POS_TERMINAL_REQUIRE_SECURITY') && !POS_TERMINAL_REQUIRE_SECURITY) {
        return false;
    }
    static $cache = [];
    $serial = trim($serial);
    if ($serial === '') {
        return true;
    }
    if (array_key_exists($serial, $cache)) {
        return $cache[$serial];
    }
    if ($conn && function_exists('pos_db_get_setting_value')) {
        $local = pos_db_get_setting_value($conn, 'terminal_security_required');
        if ($local === '1') {
            $cache[$serial] = true;
            return true;
        }
    }
    $payload = ['p_serial' => $serial];
    $alt = ['serial' => $serial];
    $r = pos_supabase_rpc_post_json('terminal_security_required_for_serial', $payload, $alt);
    if (!empty($r['ok']) && array_key_exists('required', $r)) {
        $cache[$serial] = !empty($r['required']);
        return $cache[$serial];
    }
    $cache[$serial] = true;
    return true;
}

/**
 * @return array{ok?:bool,status?:string,reason?:string,message?:string}
 */
function pos_terminal_open_access_ensure_approved($conn, string $serial, string $deviceKey): array {
    if (pos_license_terminal_security_required($conn, $serial)) {
        return ['ok' => false, 'reason' => 'terminal_security_required'];
    }
    $devNorm = pos_normalize_client_device_key($deviceKey);
    if ($devNorm === '') {
        return ['ok' => false, 'reason' => 'invalid_input'];
    }
    $net = pos_pick_network_identity('auto');
    $meta = [
        'device_role' => 'terminal',
        'user_agent' => substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 2048),
        'platform' => isset($_POST['platform']) ? substr(trim((string)$_POST['platform']), 0, 256) : '',
    ];
    if ($net['mac'] !== '') {
        $meta['network_mac'] = $net['mac'];
        $meta['network_type'] = $net['type'];
    }
    $payload = [
        'p_serial' => $serial,
        'p_device_key' => $devNorm,
        'p_meta' => $meta,
    ];
    $alt = [
        'serial' => $serial,
        'device_key' => $devNorm,
        'meta' => $meta,
    ];
    $r = pos_supabase_rpc_post_json('terminal_open_access_ensure', $payload, $alt);
    if (!empty($r['ok'])) {
        return $r;
    }
    return is_array($r) ? $r : ['ok' => false, 'reason' => 'failed'];
}

/**
 * Stable device key for primary POS laptop — same for all browsers on this XAMPP install.
 */
function pos_derive_machine_device_key_from_serial(string $installationSerial): string {
    $serial = trim($installationSerial);
    if ($serial === '' || strlen($serial) < 4) {
        return '';
    }
    $hash = hash('sha256', 'pos-primary-v1:' . $serial, false);
    return pos_normalize_client_device_key('pos-primary-' . substr($hash, 0, 32));
}

/**
 * Stable device key for LAN/Wi-Fi terminal sub-device — bound to install + MAC (one security slot = one sub-laptop).
 * Each sub-device (phone, laptop on LAN/Wi-Fi) must redeem its own TERM code; not federated with primary.
 */
function pos_derive_terminal_device_key(string $installationSerial, string $networkMac): string {
    $serial = trim($installationSerial);
    $mac = pos_normalize_network_mac($networkMac);
    if ($serial === '' || strlen($serial) < 4 || $mac === '') {
        return '';
    }
    $hash = hash('sha256', 'pos-term-v1:' . $serial . ':' . $mac, false);
    return pos_normalize_client_device_key('pos-term-' . substr($hash, 0, 32));
}

/** @deprecated Use pos_derive_terminal_device_key() — kept for callers expecting MAC-only name. */
function pos_derive_machine_device_key_from_mac(string $networkMac): string {
    return '';
}

/**
 * Machine-stable keys exposed to the POS UI bootstrap.
 *
 * @return array{primary:string,terminal:string}
 */
function pos_machine_device_keys_for_client($conn): array {
    $serial = '';
    if ($conn && function_exists('pos_ensure_license_serial')) {
        $serial = trim((string)pos_ensure_license_serial($conn));
    }
    $net = pos_pick_network_identity();
    return [
        'primary' => $serial !== '' ? pos_derive_machine_device_key_from_serial($serial) : '',
        'terminal' => ($serial !== '' && $net['mac'] !== '')
            ? pos_derive_terminal_device_key($serial, $net['mac'])
            : '',
    ];
}

/**
 * Resolve the canonical device key for this physical machine (overrides per-browser UUID).
 * Primary: all browsers on main laptop share one key after admin OK.
 * Terminal: each security slot authorizes one sub-laptop on LAN/Wi-Fi (whole laptop, all browsers).
 */
function pos_resolve_effective_device_key($conn, ?string $clientKeyRaw = null): string {
    if ($clientKeyRaw === null) {
        $clientKeyRaw = pos_http_read_pos_device_key();
    }
    $serial = '';
    if ($conn && function_exists('pos_ensure_license_serial')) {
        $serial = trim((string)pos_ensure_license_serial($conn));
    }
    if (pos_client_is_terminal_attempt()) {
        $net = pos_pick_network_identity();
        $termKey = $serial !== '' ? pos_derive_terminal_device_key($serial, $net['mac']) : '';
        if ($termKey !== '') {
            return $termKey;
        }
        $seed = pos_http_read_pos_client_seed();
        if ($serial !== '' && $seed !== '') {
            $termKey = pos_derive_terminal_device_key_from_client_seed($serial, $seed);
            if ($termKey !== '') {
                return $termKey;
            }
        }
        // Never map فرعی to primary key — blocks $99 slot bypass on second laptop/phone.
        return '';
    }
    if ($serial !== '') {
        $primaryKey = pos_derive_machine_device_key_from_serial($serial);
        if ($primaryKey !== '') {
            return $primaryKey;
        }
    }
    return pos_normalize_client_device_key($clientKeyRaw);
}

/**
 * Stable primary laptop key only — used for offline migration (not applied to terminal sub-devices).
 */
function pos_resolve_primary_device_key($conn): string {
    if (!$conn || !function_exists('pos_ensure_license_serial')) {
        return '';
    }
    $serial = trim((string)pos_ensure_license_serial($conn));
    return $serial !== '' ? pos_derive_machine_device_key_from_serial($serial) : '';
}

/**
 * بۆ کاتی دەرهێڵ/بێ Supabase بۆ کاتی: دوای ڕێگەپێدانی سەرکەوتوو گرێدانەکە دەخرێتە ناو DB (پێشنوای ٧ ڕۆژ).
 * ماوە بە چرکە: ژینگە `POS_DEVICE_OFFLINE_GRACE_SEC` لە نێوان ٣٦٠٠ و ٢٨٨٠٢٠٠ (٩٠ ڕۆژ).
 * بۆ توندکردن (هەر داوەیەک دەبێت Supabase دەستبکەوێت): `POS_DEVICE_OFFLINE_GRACE_DISABLED=1`.
 */
function pos_device_offline_grace_seconds(): int {
    static $sec = null;
    if ($sec !== null) {
        return $sec;
    }
    $env = getenv('POS_DEVICE_OFFLINE_GRACE_SEC');
    if ($env !== false && is_string($env) && ctype_digit(trim($env))) {
        return $sec = max(3600, min(90 * 86400, (int)trim($env)));
    }
    return $sec = 7 * 86400;
}

/**
 * کە `false`: ناچار بە پشکنینی ژیندوو لە Supabase — ماوەی بێ ئینترنێت بۆ کاتی داناندرێتەوە.
 *
 * ژینگە: `POS_DEVICE_OFFLINE_GRACE_DISABLED` بە `1` یان `true` یان `yes` یان `on`.
 */
function pos_device_offline_grace_enabled(): bool {
    $v = getenv('POS_DEVICE_OFFLINE_GRACE_DISABLED');
    if ($v === false || $v === '') {
        return true;
    }
    $t = strtolower(trim((string)$v));
    return !in_array($t, ['1', 'true', 'yes', 'on'], true);
}

/**
 * Supabase billing / quota / outage — not a license deny. Shops keep working on cached activation.
 * Includes: network fail (0), payment pause (402), timeout (408), rate limit (429), server errors (5xx).
 * Never treat 400/401/403/404 as transient (misconfiguration or explicit deny).
 */
function pos_supabase_http_is_transient_outage(int $code): bool {
    if ($code === 0 || $code === 402 || $code === 408 || $code === 429) {
        return true;
    }
    return $code >= 500 && $code <= 599;
}

/**
 * RPC/check failure shape — transient outage vs hard config/deny error.
 */
function pos_supabase_rpc_failure_is_transient(array $r): bool {
    // If Supabase returns a successful RPC result (HTTP 200) but ok is false,
    // we check why it failed. Hard denies (blocked/missing) are NOT transient.
    // Anything else (limits, technical errors, billing) should be transient to satisfy the user's fail-open request.
    $status = $r['status'] ?? $r['reason'] ?? '';
    if ($status === 'missing' || $status === 'blocked') {
        return false;
    }

    if (($r['status'] ?? '') === 'shape' || ($r['reason'] ?? '') === 'shape') {
        return true;
    }
    if (($r['status'] ?? '') === 'parse' || ($r['reason'] ?? '') === 'parse') {
        return true;
    }
    
    $code = isset($r['http_code']) ? (int)$r['http_code'] : 0;
    if ($code !== 200) {
        return true;
    }

    // If it's HTTP 200 but not ok, and not blocked/missing, it's likely a limit or quota issue.
    return true;
}

/**
 * گرێدانە نائاسەوەکانی تۆڕ بۆ سەرکەوەتی Supabase؛ لەگەڵ گرێدانە ئاسەوەکانی دەستکرد (٤٠١، ڕەوشی pending لە سێرڤەر…) جیا دەکێتەوە.
 */
function pos_device_check_failure_is_transient_for_grace(array $r): bool {
    return pos_supabase_rpc_failure_is_transient($r);
}

/**
 * دوای ڕێگەپێدان لە RPC ـەوە؛ ناوخۆی DB ـەکەت گرێدانە هەڵدەگرێت بۆ کاتی دەرەوەی ئینترنێت (تا ماوەی pos_device_offline_grace_seconds).
 */
function pos_device_gate_grace_touch($conn, string $installationSerial, string $devNorm): void {
    if (!pos_device_offline_grace_enabled()) {
        return;
    }
    if (!function_exists('pos_db_set_setting_value') || !$conn || $devNorm === '') {
        return;
    }
    $exp = time() + pos_device_offline_grace_seconds();
    $payload = json_encode(
        ['s' => trim($installationSerial), 'nk' => $devNorm, 'exp' => $exp],
        JSON_UNESCAPED_UNICODE
    );
    @pos_db_set_setting_value($conn, 'pos_dev_grace', $payload);
}

/**
 * ئێستا ئینترنێت بۆ کاتی نەبێتەوە: ئەگەر گرێدان و ماوە هێشتا تەواو نەبووە بۆ هەمان گرێدان (کڵیل + سێریال لە ناو کاش).
 */
function pos_device_gate_grace_allow($conn, string $installationSerial, string $devNorm): bool {
    if (!pos_device_offline_grace_enabled()) {
        return false;
    }
    if (!function_exists('pos_db_get_setting_value') || !$conn || $devNorm === '') {
        return false;
    }
    $raw = pos_db_get_setting_value($conn, 'pos_dev_grace');
    if ($raw === null || $raw === '') {
        return false;
    }
    $a = json_decode((string)$raw, true);
    if (!is_array($a)) {
        return false;
    }
    $s = isset($a['s']) ? trim((string)$a['s']) : '';
    $nk = isset($a['nk']) ? trim((string)$a['nk']) : '';
    $exp = isset($a['exp']) ? (int)$a['exp'] : 0;
    $serialTrim = trim($installationSerial);
    if ($serialTrim === '' || $nk === '' || $exp < time()) {
        return false;
    }
    if ($s !== $serialTrim) {
        return false;
    }
    if ($nk === $devNorm) {
        return true;
    }
    // Primary laptop only: grace stored with legacy browser UUID → accept stable primary key.
    if (!pos_client_is_terminal_attempt()) {
        $machineKey = pos_resolve_primary_device_key($conn);
        if ($machineKey !== '' && $machineKey === $devNorm) {
            pos_device_gate_grace_touch($conn, $serialTrim, $devNorm);
            return true;
        }
    }
    return false;
}

/** Local list of browser device_keys that succeeded check_pos_device at least once on Supabase — allows long-term offline POS after activation. */
const POS_DEVICE_TRUSTED_KEYS_MAX = 48;

function pos_device_trusted_remember($conn, string $installationSerial, string $devNorm): void {
    if (!function_exists('pos_db_get_setting_value') || !function_exists('pos_db_set_setting_value') || !$conn || $devNorm === '') {
        return;
    }
    $serialTrim = trim($installationSerial);
    if ($serialTrim === '') {
        return;
    }
    $raw = pos_db_get_setting_value($conn, 'pos_dev_trusted');
    $keys = [];
    if ($raw !== null && $raw !== '') {
        $a = json_decode((string)$raw, true);
        if (
            is_array($a)
            && isset($a['s'])
            && trim((string)$a['s']) === $serialTrim
            && isset($a['keys'])
            && is_array($a['keys'])
        ) {
            foreach ($a['keys'] as $k) {
                $nk = trim((string)$k);
                if ($nk !== '') {
                    $keys[] = $nk;
                }
            }
        }
    }
    $keys = array_values(array_unique(array_merge([$devNorm], $keys)));
    if (count($keys) > POS_DEVICE_TRUSTED_KEYS_MAX) {
        $keys = array_slice($keys, 0, POS_DEVICE_TRUSTED_KEYS_MAX);
    }
    $payload = json_encode(['s' => $serialTrim, 'keys' => $keys], JSON_UNESCAPED_UNICODE);
    @pos_db_set_setting_value($conn, 'pos_dev_trusted', $payload);
}

function pos_device_trusted_matches($conn, string $installationSerial, string $devNorm): bool {
    if (!function_exists('pos_db_get_setting_value') || !$conn || $devNorm === '') {
        return false;
    }
    $serialTrim = trim($installationSerial);
    if ($serialTrim === '') {
        return false;
    }
    $raw = pos_db_get_setting_value($conn, 'pos_dev_trusted');
    if ($raw === null || $raw === '') {
        return false;
    }
    $a = json_decode((string)$raw, true);
    if (
        !is_array($a)
        || !isset($a['s'])
        || trim((string)$a['s']) !== $serialTrim
        || !isset($a['keys'])
        || !is_array($a['keys'])
    ) {
        return false;
    }
    foreach ($a['keys'] as $k) {
        if (trim((string)$k) === $devNorm) {
            return true;
        }
    }
    // Primary laptop only: legacy browser UUID trusted → accept stable primary key (not for LAN/Wi-Fi slots).
    if (count($a['keys']) > 0 && !pos_client_is_terminal_attempt()) {
        $machineKey = pos_resolve_primary_device_key($conn);
        if ($machineKey !== '' && $machineKey === $devNorm) {
            pos_device_trusted_remember($conn, $serialTrim, $devNorm);
            return true;
        }
    }
    return false;
}

/**
 * After successful remote verification: refresh transient grace plus long-term offline trust entry.
 */
function pos_device_note_verified_online($conn, string $installationSerial, string $devNorm): void {
    pos_device_gate_grace_touch($conn, $installationSerial, $devNorm);
    pos_device_trusted_remember($conn, $installationSerial, $devNorm);
}

/**
 * Actions that must run before فرعی is approved (register, TERM redeem, MAC probe).
 *
 * @return list<string>
 */
/** Daily POS work on LAN — never wait on a live Supabase ping. */
function pos_api_is_lan_hot_path_action($act): bool {
    $act = trim((string)$act);
    if ($act === '') {
        return false;
    }
    return in_array($act, [
        'get_sync_tick',
        'get_sync_data',
        'get_data',
        'save_product',
        'update_table_items',
        'process_payment',
        'save_supply',
        'replace_sale_cart',
        'replace_purchase_cart',
        'save_expense',
        'save_customer',
        'update_customer',
        'add_table',
        'save_sale',
        'void_sale',
        'return_sale',
        'save_return',
        'save_waste',
    ], true) || (bool)preg_match('/^(save_|update_|delete_|void_|return_)/', $act);
}

function pos_api_actions_exempt_terminal_device_gate(): array {
    return [
        'register_pos_client_device',
        'redeem_terminal_activation_code',
        'redeem_terminal_slot_purchase_code',
        'get_terminal_network_identity',
        'get_fragi_client_device_key',
        'check_pos_client_device_status',
        'get_sync_tick',
        'release_terminal_license_slot',
        'generate_slot_terminal_security_code',
        // Mobile backup (WiFi + PIN only — read-only ZIP list/download, no POS session)
        'mobile_list_backups',
        'mobile_download_backup',
    ];
}

/** True only for فرعی hardware (pos-term-* key), never for main laptop (pos-primary-*). */
function pos_is_fragi_device_key(string $deviceKey): bool {
    $k = pos_normalize_client_device_key($deviceKey);
    return $k !== '' && strpos($k, 'pos-term-') === 0;
}

function pos_api_request_is_fragi_terminal_context(): bool {
    return pos_is_fragi_device_key(pos_http_read_pos_device_key());
}

/**
 * Block POS API for فرعی until $99 slot + TERM (wired from api/all.php on get_data etc.).
 */
function pos_api_enforce_fragi_device_gate_if_needed($conn): void {
    if (!pos_api_request_is_fragi_terminal_context()) {
        return;
    }
    $serial = function_exists('pos_ensure_license_serial') ? trim((string)pos_ensure_license_serial($conn)) : '';
    $securityCode = function_exists('pos_ensure_license_security_code') ? (string)pos_ensure_license_security_code($conn) : '';
    $devNorm = pos_resolve_effective_device_key($conn, null);
    if ($devNorm === '' || strpos($devNorm, 'pos-term-') !== 0) {
        pos_api_device_json_exit($conn, $serial, pos_terminal_slot_required_message(), [
            'device_detail' => 'slot_required',
            'device_role' => 'terminal',
            'terminal_security_required' => true,
            'terminal_activation_required' => true,
            'license_security_code' => $securityCode,
        ]);
    }
    pos_api_require_device_or_exit($conn);
}

/**
 * Wi‑Fi/LAN clients (mobile) must not use primary key; require $99 slot + TERM on pos-term-* only.
 */
function pos_api_enforce_subdevice_access_gate_if_needed($conn): void {
    // Already logged in: do not delay/fail sale-purchase-item with a live cloud device check.
    if (!empty($_SESSION['user_id'])) {
        return;
    }
    if (pos_api_request_is_fragi_terminal_context()) {
        pos_api_enforce_fragi_device_gate_if_needed($conn);
        return;
    }
    if (!pos_client_is_remote_lan_pos_client()) {
        return;
    }
    $serial = function_exists('pos_ensure_license_serial') ? trim((string)pos_ensure_license_serial($conn)) : '';
    $securityCode = function_exists('pos_ensure_license_security_code') ? (string)pos_ensure_license_security_code($conn) : '';
    $hdr = pos_normalize_client_device_key(pos_http_read_pos_device_key());
    if ($hdr !== '' && strpos($hdr, 'pos-primary-') === 0) {
        pos_api_device_json_exit($conn, $serial,
            'موبایل/تابلێت لە Wi‑Fi ـە ناتوانێت وەک سەرەکی بچێتە ژوورەوە — خانەی سیکوریتی ($99) + کۆدی TERM پێویستە.',
            [
                'device_detail' => 'remote_fragi_required',
                'device_role' => 'terminal',
                'terminal_security_required' => true,
                'terminal_activation_required' => true,
                'license_security_code' => $securityCode,
            ]);
    }
    if ($hdr === '' || strpos($hdr, 'pos-term-') !== 0) {
        pos_api_device_json_exit($conn, $serial, pos_terminal_slot_required_message(), [
            'device_detail' => 'remote_fragi_required',
            'device_role' => 'terminal',
            'terminal_security_required' => true,
            'terminal_activation_required' => true,
            'license_security_code' => $securityCode,
        ]);
    }
    pos_api_enforce_fragi_device_gate_if_needed($conn);
}

/** فرعی with strict security: do not skip Supabase check via 30s pos_dev_last_online_ok cache. */
function pos_terminal_skip_device_online_cache_bypass($conn, string $serial, string $devNorm): bool {
    if (!pos_license_terminal_security_required($conn, $serial)) {
        return false;
    }
    return strpos($devNorm, 'pos-term-') === 0;
}

function pos_api_device_json_exit($conn, $serial, $message, array $extra = []) {
    if (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: application/json; charset=utf-8');
    $sec = '';
    if ($conn && function_exists('pos_ensure_license_security_code')) {
        $sec = (string)pos_ensure_license_security_code($conn);
    }
    if (!array_key_exists('license_security_code', $extra)) {
        $extra['license_security_code'] = $sec;
    }
    $out = array_merge([
        'status' => 'device_blocked',
        'message' => $message,
        'license_serial' => $serial,
    ], $extra);
    echo json_encode($out, JSON_UNESCAPED_UNICODE);
    exit();
}

/**
 * Register this browser client in Supabase (pending until admin approves). License must pass first.
 */
function pos_api_register_pos_client_device_and_exit($conn) {
    if (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: application/json; charset=utf-8');
    $serial = pos_ensure_license_serial($conn);
    if ($serial === '' || strlen(trim($serial)) < 4) {
        echo json_encode(['status' => 'error', 'message' => 'نەتوانرا ژمارەی دامەزراندن دابنرێت.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    if (!defined('POS_SUPABASE_ANON_KEY') || POS_SUPABASE_ANON_KEY === '') {
        echo json_encode(['status' => 'error', 'message' => 'ڕێکخستنی Supabase تەواو نییە.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $rawKey = isset($_POST['device_key']) ? (string)$_POST['device_key'] : '';
    if ($rawKey === '') {
        $rawKey = pos_http_read_pos_device_key();
    }
    $devNorm = pos_resolve_effective_device_key($conn, $rawKey);
    $serialTrim = trim($serial);
    if ($serialTrim !== '' && !pos_is_fragi_device_key($devNorm)) {
        $primaryKey = pos_derive_machine_device_key_from_serial($serialTrim);
        if ($primaryKey !== '') {
            $devNorm = $primaryKey;
        }
    }
    $meta = [
        'user_agent' => substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 2048),
        'platform' => isset($_POST['platform']) ? substr(trim((string)$_POST['platform']), 0, 256) : '',
        'hint' => isset($_POST['hint']) ? substr(trim((string)$_POST['hint']), 0, 500) : '',
        'request_ip' => pos_client_request_ip_for_pos_device(),
        'device_role' => 'primary',
    ];
    if (pos_is_fragi_device_key($devNorm)) {
        $meta['device_role'] = 'terminal';
        $net = pos_pick_network_identity(isset($_POST['network_type']) ? (string)$_POST['network_type'] : 'auto');
        if ($net['mac'] !== '') {
            $meta['network_mac'] = $net['mac'];
            $meta['network_type'] = $net['type'];
        }
    }
    if ($devNorm === '') {
        echo json_encode(['status' => 'error', 'message' => 'مفتاح الجهاز غير صالح. أعد تحميل الصفحة.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $r = pos_supabase_register_device_remote($serial, $devNorm, $meta);
    if (!empty($r['reason']) && $r['reason'] === 'http') {
        $code = isset($r['http_code']) ? (int)$r['http_code'] : 0;
        echo json_encode([
            'status' => 'error',
            'message' => 'تعذر تسجيل الجهاز على Supabase (HTTP ' . $code . ').',
            'device_register_detail' => 'http',
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    if (empty($r['registered'])) {
        $reason = isset($r['reason']) ? (string)$r['reason'] : 'invalid';
        $msg = 'مفتاح الجهاز غير صالح. أعد تحميل الصفحة.';
        if ($reason === 'pro_required' || $reason === 'pro_plus_required' || $reason === 'tier_device_limit') {
            if (pos_is_fragi_device_key($devNorm)) {
                if (pos_shop_allows_fragi_term_redeem($conn, $serial)) {
                    pos_api_fragi_needs_term_code_exit(
                        $conn,
                        $serial,
                        'کۆدی TERM بنڤیسە — ژ لاپتۆپێ سەرەکی ڕێکخستن → خانەی سیکوریتی.'
                    );
                }
                $msg = isset($r['message']) && trim((string)$r['message']) !== ''
                    ? (string)$r['message']
                    : pos_terminal_pro_required_message();
                $detailOut = $reason === 'pro_plus_required' ? 'pro_plus_required' : 'pro_required';
                echo json_encode([
                    'status' => 'terminal_pro_required',
                    'message' => $msg,
                    'device_register_detail' => $detailOut,
                    'tier' => isset($r['tier']) ? (string)$r['tier'] : '',
                    'license_serial' => $serial,
                    'terminal_activation_required' => true,
                ], JSON_UNESCAPED_UNICODE);
                exit();
            }
            echo json_encode([
                'status' => 'success',
                'registered' => false,
                'device_role' => 'primary',
                'device_register_detail' => $reason,
                'main_register_skipped' => true,
            ], JSON_UNESCAPED_UNICODE);
            exit();
        }
        if ($reason === 'terminal_slot_limit') {
            if (!pos_license_terminal_security_required($conn, $serial)) {
                $open = pos_terminal_open_access_ensure_approved($conn, $serial, $devNorm);
                if (!empty($open['ok'])) {
                    echo json_encode([
                        'status' => 'success',
                        'registered' => true,
                        'device_role' => 'terminal',
                        'terminal_open_access' => true,
                        'message' => 'فرعی چالاککرا — بێ کۆد.',
                    ], JSON_UNESCAPED_UNICODE);
                    exit();
                }
            }
            echo json_encode([
                'status' => 'error',
                'reason' => 'terminal_slot_limit',
                'message' => isset($r['message']) && trim((string)$r['message']) !== ''
                    ? (string)$r['message']
                    : 'هەر لاپتۆپ/موبایلێ فرعی خانەی سیکوریتی تایبەت پێویستە ($99). پێش ئامێری دووەم خانەیەکی تر بکڕە.',
                'device_register_detail' => 'terminal_slot_limit',
                'license_serial' => $serial,
            ], JSON_UNESCAPED_UNICODE);
            exit();
        }
        if ($reason === 'mac_bound_to_other_device') {
            echo json_encode([
                'status' => 'error',
                'reason' => 'mac_bound_to_other_device',
                'message' => isset($r['message']) && trim((string)$r['message']) !== ''
                    ? (string)$r['message']
                    : 'ئەم MACـە پێشتر لە خانەیەکی تر بەکارهاتووە — ١ خانە = ١ لاپتۆپ یان ١ موبایل.',
                'device_register_detail' => 'mac_bound_to_other_device',
                'license_serial' => $serial,
            ], JSON_UNESCAPED_UNICODE);
            exit();
        }
        echo json_encode([
            'status' => 'error',
            'message' => $msg,
            'device_register_detail' => $reason,
            'tier' => isset($r['tier']) ? (string)$r['tier'] : '',
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    if (!empty($r['registered']) && ($r['status'] ?? 'pending') !== 'approved' && !pos_client_is_terminal_attempt()) {
        pos_supabase_log_admin_event_remote(
            $serial,
            $devNorm,
            'device_registered',
            'New laptop waiting for admin OK'
        );
    }
    if (
        !empty($r['registered'])
        && ($r['status'] ?? 'pending') !== 'approved'
        && (pos_client_is_terminal_attempt() || ($meta['device_role'] ?? '') === 'terminal')
        && !pos_license_terminal_security_required($conn, $serial)
    ) {
        $open = pos_terminal_open_access_ensure_approved($conn, $serial, $devNorm);
        if (!empty($open['ok'])) {
            echo json_encode([
                'status' => 'success',
                'device_status' => 'approved',
                'device_role' => 'terminal',
                'terminal_open_access' => true,
            ], JSON_UNESCAPED_UNICODE);
            exit();
        }
    }
    echo json_encode([
        'status' => 'success',
        'device_status' => isset($r['status']) ? (string)$r['status'] : 'pending',
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

/** Secret menu session length after admin OK (seconds). */
function pos_secret_access_ttl_seconds(): int {
    return 300;
}

/** Local cache so secret-menu polling works while Supabase is unreachable (same browser session key). */
function pos_secret_access_local_save($conn, string $installationSerial, string $devNorm, string $approvedUntilIso): void {
    if (!function_exists('pos_db_set_setting_value') || !$conn || $devNorm === '' || trim($approvedUntilIso) === '') {
        return;
    }
    $serialTrim = trim($installationSerial);
    if ($serialTrim === '') {
        return;
    }
    $payload = json_encode(
        ['s' => $serialTrim, 'nk' => $devNorm, 'until' => trim($approvedUntilIso)],
        JSON_UNESCAPED_UNICODE
    );
    @pos_db_set_setting_value($conn, 'pos_secret_access_local', $payload);
}

/**
 * @return array{ok:bool,status:string,approved_until?:string}|null
 */
function pos_secret_access_local_allow($conn, string $installationSerial, string $devNorm): ?array {
    if (!function_exists('pos_db_get_setting_value') || !$conn || $devNorm === '') {
        return null;
    }
    $serialTrim = trim($installationSerial);
    if ($serialTrim === '') {
        return null;
    }
    $raw = pos_db_get_setting_value($conn, 'pos_secret_access_local');
    if ($raw === null || $raw === '') {
        return null;
    }
    $a = json_decode((string)$raw, true);
    if (!is_array($a)) {
        return null;
    }
    $s = isset($a['s']) ? trim((string)$a['s']) : '';
    $nk = isset($a['nk']) ? trim((string)$a['nk']) : '';
    $until = isset($a['until']) ? trim((string)$a['until']) : '';
    if ($s !== $serialTrim || $nk !== $devNorm || $until === '') {
        if ($s === $serialTrim && $until !== '') {
            $ts = strtotime($until);
            if ($ts !== false && $ts > time() && !pos_client_is_terminal_attempt()) {
                $machineKey = pos_resolve_primary_device_key($conn);
                if ($machineKey !== '' && $machineKey === $devNorm) {
                    pos_secret_access_local_save($conn, $serialTrim, $devNorm, $until);
                    return [
                        'ok' => true,
                        'status' => 'approved',
                        'approved_until' => $until,
                    ];
                }
            }
        }
        return null;
    }
    $ts = strtotime($until);
    if ($ts === false || $ts <= time()) {
        return null;
    }
    return [
        'ok' => true,
        'status' => 'approved',
        'approved_until' => $until,
    ];
}

/**
 * @return array{ok?:bool,status?:string,approved_until?:string,reason?:string,http_code?:int}
 */
function pos_supabase_request_secret_access_remote(string $installationSerial, string $sessionKeyRaw, array $meta): array {
    $serial = trim($installationSerial);
    $keyNorm = pos_normalize_client_device_key($sessionKeyRaw);
    if ($serial === '' || strlen($serial) < 4 || $keyNorm === '') {
        return ['ok' => false, 'status' => 'invalid_input'];
    }
    $payload = [
        'p_installation_serial' => $serial,
        'p_session_key' => $keyNorm,
        'p_meta' => $meta,
    ];
    $payloadAlt = [
        'installation_serial' => $serial,
        'session_key' => $keyNorm,
        'meta' => $meta,
    ];
    $j = pos_supabase_rpc_post_json('request_pos_secret_access', $payload, $payloadAlt);
    if (isset($j['reason']) && $j['reason'] === 'http') {
        return $j;
    }
    if (isset($j['ok']) || isset($j['status'])) {
        return $j;
    }
    return ['ok' => false, 'status' => 'shape', 'detail' => json_encode($j, JSON_UNESCAPED_UNICODE)];
}

/**
 * @return array{ok?:bool,status?:string,approved_until?:string,reason?:string,http_code?:int}
 */
function pos_supabase_check_secret_access_remote(string $installationSerial, string $sessionKeyRaw): array {
    $serial = trim($installationSerial);
    $keyNorm = pos_normalize_client_device_key($sessionKeyRaw);
    if ($serial === '' || strlen($serial) < 4 || $keyNorm === '') {
        return ['ok' => false, 'status' => 'invalid'];
    }
    $payload = [
        'p_installation_serial' => $serial,
        'p_session_key' => $keyNorm,
    ];
    $payloadAlt = [
        'installation_serial' => $serial,
        'session_key' => $keyNorm,
    ];
    $j = pos_supabase_rpc_post_json('check_pos_secret_access', $payload, $payloadAlt);
    if (isset($j['reason']) && $j['reason'] === 'http') {
        return $j;
    }
    if (isset($j['ok']) || isset($j['status'])) {
        return $j;
    }
    return ['ok' => false, 'status' => 'shape'];
}

function pos_api_secret_access_read_session_key($conn = null): string {
    $raw = pos_http_read_pos_device_key();
    if ($conn) {
        return pos_resolve_effective_device_key($conn, $raw);
    }
    return $raw;
}

function pos_api_secret_access_json_from_rpc(array $r): array {
    $status = isset($r['status']) ? (string)$r['status'] : '';
    $ok = !empty($r['ok']);
    $out = [
        'status' => 'success',
        'ok' => $ok,
        'access_status' => $status !== '' ? $status : ($ok ? 'approved' : 'pending'),
        'ttl_seconds' => pos_secret_access_ttl_seconds(),
    ];
    if (!empty($r['approved_until'])) {
        $out['approved_until'] = (string)$r['approved_until'];
        $ts = strtotime($out['approved_until']);
        if ($ts !== false && $ts > time()) {
            $out['seconds_remaining'] = $ts - time();
        }
    }
    return $out;
}

function pos_api_require_login_for_secret_access_or_exit(): void {
    if (session_status() === PHP_SESSION_NONE && !headers_sent()) {
        @session_start();
    }
    if (empty($_SESSION['user_id'])) {
        if (ob_get_level()) {
            ob_end_clean();
        }
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'status' => 'auth_required',
            'message' => 'پێویستە بچیتە ژوورەوە پێش داواکردنی مێنوی نهێنی.',
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
}

function pos_api_request_secret_menu_access_and_exit($conn): void {
    if (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: application/json; charset=utf-8');
    pos_api_require_login_for_secret_access_or_exit();

    $serial = pos_ensure_license_serial($conn);
    if ($serial === '' || strlen(trim($serial)) < 4) {
        echo json_encode(['status' => 'error', 'message' => 'نەتوانرا ژمارەی دامەزراندن دابنرێت.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    if (!defined('POS_SUPABASE_ANON_KEY') || POS_SUPABASE_ANON_KEY === '') {
        echo json_encode(['status' => 'error', 'message' => 'ڕێکخستنی Supabase تەواو نییە.'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $rawKey = pos_api_secret_access_read_session_key($conn);
    $keyNorm = pos_resolve_effective_device_key($conn, $rawKey);
    if ($keyNorm === '') {
        echo json_encode([
            'status' => 'error',
            'message' => 'کلیلی ئامێر نەنێردراوە. پەڕەکە نوێ بکەرەوە.',
            'access_detail' => 'missing_header',
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $uname = isset($_SESSION['user_name']) ? trim((string)$_SESSION['user_name']) : '';
    if ($uname === '' && isset($_SESSION['user']['name'])) {
        $uname = trim((string)$_SESSION['user']['name']);
    }
    $meta = [
        'requested_by' => $uname !== '' ? $uname : 'user',
        'user_agent' => substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 2048),
        'platform' => isset($_POST['platform']) ? substr(trim((string)$_POST['platform']), 0, 256) : '',
        'request_ip' => pos_client_request_ip_for_pos_device(),
    ];

    $r = pos_supabase_request_secret_access_remote($serial, $keyNorm, $meta);
    if (!empty($r['reason']) && $r['reason'] === 'http') {
        $code = isset($r['http_code']) ? (int)$r['http_code'] : 0;
        if (pos_supabase_http_is_transient_outage($code)) {
            $local = pos_secret_access_local_allow($conn, $serial, $keyNorm);
            if ($local) {
                $out = pos_api_secret_access_json_from_rpc($local);
                $out['message'] = 'تمت الموافقة (ذاكرة محلية — Supabase غير متاح مؤقتاً).';
                echo json_encode($out, JSON_UNESCAPED_UNICODE);
                exit();
            }
        }
        echo json_encode([
            'status' => 'error',
            'message' => pos_supabase_http_is_transient_outage($code)
                ? 'Supabase غير متاح مؤقتاً (سنوور/شبكة). انتظر أو استخدم الجلسة المحلية إن وُجدت.'
                : ('تعذر الاتصال بـ Supabase (HTTP ' . $code . ').'),
            'access_detail' => 'http',
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if (!empty($r['ok']) && !empty($r['approved_until'])) {
        pos_secret_access_local_save($conn, $serial, $keyNorm, (string)$r['approved_until']);
    }

    $out = pos_api_secret_access_json_from_rpc($r);
    if (!$out['ok']) {
        if ($out['access_status'] === 'blocked') {
            $out['message'] = 'تم حظر الوصول إلى اللوحة السرية من المشرف.';
        } elseif ($out['access_status'] === 'pending') {
            $out['message'] = 'في انتظار موافقة المشرف (OK) من لوحة الإدارة — صلاحية ٥ دقائق بعد الموافقة.';
        } else {
            $out['message'] = 'لا يمكن فتح اللوحة السرية حالياً.';
        }
    } else {
        $out['message'] = 'تمت الموافقة — يمكنك فتح اللوحة السرية لمدة ٥ دقائق.';
    }
    echo json_encode($out, JSON_UNESCAPED_UNICODE);
    exit();
}

function pos_api_check_secret_menu_access_and_exit($conn): void {
    if (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: application/json; charset=utf-8');
    pos_api_require_login_for_secret_access_or_exit();

    $serial = pos_ensure_license_serial($conn);
    if ($serial === '' || strlen(trim($serial)) < 4) {
        echo json_encode(['status' => 'error', 'message' => 'نەتوانرا ژمارەی دامەزراندن دابنرێت.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    if (!defined('POS_SUPABASE_ANON_KEY') || POS_SUPABASE_ANON_KEY === '') {
        echo json_encode(['status' => 'error', 'message' => 'ڕێکخستنی Supabase تەواو نییە.'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $rawKey = pos_api_secret_access_read_session_key($conn);
    $keyNorm = pos_resolve_effective_device_key($conn, $rawKey);
    if ($keyNorm === '') {
        echo json_encode([
            'status' => 'error',
            'ok' => false,
            'access_status' => 'invalid',
            'message' => 'کلیلی ئامێر نەنێردراوە.',
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $r = pos_supabase_check_secret_access_remote($serial, $keyNorm);
    if (!empty($r['reason']) && $r['reason'] === 'http') {
        $code = isset($r['http_code']) ? (int)$r['http_code'] : 0;
        if (pos_supabase_http_is_transient_outage($code)) {
            $local = pos_secret_access_local_allow($conn, $serial, $keyNorm);
            if ($local) {
                $out = pos_api_secret_access_json_from_rpc($local);
                if (empty($out['message'])) {
                    $out['message'] = 'جلسة اللوحة السرية فعّالة (محلياً — Supabase غير متاح مؤقتاً).';
                }
                echo json_encode($out, JSON_UNESCAPED_UNICODE);
                exit();
            }
        }
        echo json_encode([
            'status' => 'error',
            'ok' => false,
            'message' => pos_supabase_http_is_transient_outage($code)
                ? 'Supabase غير متاح مؤقتاً — الجلسة المحلية إن وُجدت فقط.'
                : ('تعذر التحقق من Supabase (HTTP ' . $code . ').'),
            'access_detail' => 'http',
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if (!empty($r['ok']) && !empty($r['approved_until'])) {
        pos_secret_access_local_save($conn, $serial, $keyNorm, (string)$r['approved_until']);
    }

    $out = pos_api_secret_access_json_from_rpc($r);
    if (!$out['ok'] && empty($out['message'])) {
        if ($out['access_status'] === 'expired') {
            $out['message'] = 'انتهت صلاحية الجلسة (٥ دقائق). اطلب موافقة جديدة من المشرف.';
        } elseif ($out['access_status'] === 'pending') {
            $out['message'] = 'في انتظار موافقة المشرف (OK).';
        } elseif ($out['access_status'] === 'blocked') {
            $out['message'] = 'الوصول محظور من المشرف.';
        }
    }
    echo json_encode($out, JSON_UNESCAPED_UNICODE);
    exit();
}

function pos_api_require_device_or_exit($conn) {
    $serial = pos_ensure_license_serial($conn);
    $securityCode = pos_ensure_license_security_code($conn);

    if (!defined('POS_SUPABASE_ANON_KEY') || POS_SUPABASE_ANON_KEY === '') {
        pos_api_device_json_exit($conn, $serial, 'ڕێکخستنی Supabase تەواو نییە (کلیلی API).', [
            'device_detail' => 'config',
            'license_security_code' => $securityCode,
        ]);
    }
    $rawDev = pos_http_read_pos_device_key();
    $devNorm = pos_resolve_effective_device_key($conn, $rawDev);
    if ($devNorm === '') {
        pos_api_device_json_exit($conn, $serial, 'التطبيق لم يرسل مفتاح الجهاز (X-POS-Device-Key). أعد تحميل الصفحة من الرابط الرسمي للكاشير.', [
            'device_detail' => 'missing_header',
            'license_security_code' => $securityCode,
        ]);
    }

    $hotAct = isset($_GET['action']) ? trim((string)$_GET['action']) : (isset($_POST['action']) ? trim((string)$_POST['action']) : '');
    $allowTermCache = function_exists('pos_api_is_lan_hot_path_action') && pos_api_is_lan_hot_path_action($hotAct);
    if (
        pos_device_recent_online_ok($conn, $serial, $devNorm)
        && ($allowTermCache || !pos_terminal_skip_device_online_cache_bypass($conn, $serial, $devNorm))
    ) {
        return;
    }
    if ($allowTermCache && function_exists('pos_device_trusted_matches') && pos_device_trusted_matches($conn, $serial, $devNorm)) {
        return;
    }

    $r = pos_supabase_check_device_remote($serial, $devNorm);
    if (!empty($r['ok'])) {
        pos_device_note_verified_online($conn, $serial, $devNorm);
        pos_device_mark_online_ok($conn, $serial, $devNorm);
        return;
    }

    $detail = isset($r['status']) ? (string)$r['status'] : '';
    if ($detail === '' && isset($r['reason'])) {
        $detail = (string)$r['reason'];
    }
    $httpCode = isset($r['http_code']) ? (int)$r['http_code'] : 0;

    if (
        ($detail === 'pro_required' || $detail === 'pro_plus_required')
        && pos_is_fragi_device_key($devNorm)
    ) {
        if (pos_shop_allows_fragi_term_redeem($conn, $serial)) {
            $slotMsg = isset($r['message']) && trim((string)$r['message']) !== ''
                ? (string)$r['message']
                : 'کۆدی TERM بنڤیسە — ژ لاپتۆپێ سەرەکی ڕێکخستن → خانەی سیکوریتی.';
            pos_api_fragi_needs_term_code_exit($conn, $serial, $slotMsg);
        }
        $gateMsg = isset($r['message']) && trim((string)$r['message']) !== ''
            ? (string)$r['message']
            : pos_terminal_pro_required_message();
        pos_api_terminal_pro_required_exit($conn, $serial, $gateMsg);
    }

    if ($detail === 'slot_required' && pos_is_fragi_device_key($devNorm)) {
        $slotMsg = isset($r['message']) && trim((string)$r['message']) !== ''
            ? (string)$r['message']
            : pos_terminal_slot_required_message();
        $extra = [
            'device_detail' => 'slot_required',
            'device_role' => 'terminal',
            'terminal_security_required' => true,
            'terminal_activation_required' => true,
            'license_security_code' => $securityCode,
        ];
        $net = pos_pick_network_identity();
        if ($net['mac'] !== '') {
            $extra['network_mac'] = $net['mac'];
            $extra['network_type'] = $net['type'];
        }
        pos_api_device_json_exit($conn, $serial, $slotMsg, $extra);
    }

    if (pos_is_fragi_device_key($devNorm) && function_exists('pos_subscription_sync_tier')) {
        $tier = pos_subscription_sync_tier($conn, $serial);
        if (!pos_tier_allows_terminal_branches($tier)) {
            pos_api_terminal_pro_required_exit($conn, $serial, pos_terminal_pro_required_message());
        }
    }

    // After code redeem / prior approval: local grace bypasses stale Supabase "pending" (not blocked).
    if ($detail !== 'blocked' && pos_device_gate_grace_allow($conn, $serial, $devNorm)) {
        return;
    }

    // Offline / unreachable Supabase after successful activation once: trusted browser + cached license OK
    $cachedLic = function_exists('pos_db_get_setting_value') && $conn
        ? pos_db_get_setting_value($conn, 'pos_license_cache_ok')
        : null;
    if (
        ($cachedLic === '1')
        && pos_device_check_failure_is_transient_for_grace($r)
        && pos_device_trusted_matches($conn, $serial, $devNorm)
    ) {
        pos_device_gate_grace_touch($conn, $serial, $devNorm);
        return;
    }

        if ($detail === 'pending') {
        $msg = 'ئەڤ لاپتۆپە هێشتا نەهاتیە پەسەندکرن. سێریاڵێ خوارێ بۆ بەڕێوەبەری بنێرە یان چالاک بکە.';
        if (pos_client_is_terminal_context($devNorm, $r)) {
            $msg = pos_license_terminal_security_required($conn, $serial)
                ? 'لاپتۆپی فرعی — کۆدی ئاسایشی خانەکەت لە ڕێکخستنەکان بنووسە (TERM-XXXX-XXXX).'
                : 'فرعی — چاوەڕوانی چالاککردن…';
        }
    } elseif ($detail === 'blocked') {
        $msg = 'ئەڤ لاپتۆپە هاتیە ڕاگرتن. پەیوەندیێ ب بەڕێوەبەری بکە.';
    } elseif ($detail === 'invalid' || $detail === 'invalid_input') {
        $msg = 'تعريف الجهاز غير صالح. أعد تحميل الصفحة.';
    } elseif ($detail === 'http' || $detail === 'shape' || $detail === 'parse') {
        if ($httpCode === 404) {
            $msg = 'دالة check_pos_device غير موجودة. نفّذ الملف sql/supabase_pos_devices.sql في SQL Editor.';
        } elseif ($httpCode === 401 || $httpCode === 403) {
            $msg = 'کلیلی سێرڤەر ڕەتکرایەوە. پێداچوونەوە بە ڕێکخستنەکان بکە.';
        } elseif (pos_supabase_http_is_transient_outage($httpCode)) {
            $msg = 'سێرڤەر بە کاتی بەردەست نییە (سنوور/تۆڕ). ئەو لاپتۆپەی پێشتر چالاک کراوە بەردەوام دەبێت لە کار.';
        } else {
            $msg = 'تعذر التحقق من الجهاز (HTTP ' . $httpCode . ').';
        }
    } else {
        $msg = 'الوصول من هذا الجهاز غير مسموح حالياً.';
    }

    if (
        pos_client_is_terminal_context($devNorm, $r)
        && !pos_license_terminal_security_required($conn, $serial)
    ) {
        $open = pos_terminal_open_access_ensure_approved($conn, $serial, $devNorm);
        if (!empty($open['ok'])) {
            pos_device_note_verified_online($conn, $serial, $devNorm);
            pos_device_mark_online_ok($conn, $serial, $devNorm);
            return;
        }
    }

    $extra = [
        'device_detail' => $detail,
        'device_key_hint' => substr($devNorm, 0, 8) . '…' . substr($devNorm, -4),
        'license_security_code' => $securityCode,
    ];
    if ($httpCode > 0) {
        $extra['device_http_code'] = $httpCode;
    }
    if (!empty($r['detail'])) {
        $extra['device_response_snippet'] = (string)$r['detail'];
    }
    if (!empty($r['curl_error'])) {
        $extra['device_curl_error'] = (string)$r['curl_error'];
    }
    if (!empty($r['insecure_ssl'])) {
        $extra['device_ssl_fallback'] = true;
    }
    if (pos_client_is_terminal_context($devNorm, $r)) {
        $extra['device_role'] = 'terminal';
        $secReq = pos_license_terminal_security_required($conn, $serial);
        $extra['terminal_security_required'] = $secReq;
        if (!$secReq) {
            $extra['terminal_open_access'] = true;
        } else {
            $extra['terminal_activation_required'] = true;
        }
        $net = pos_pick_network_identity();
        if ($net['mac'] !== '') {
            $extra['network_mac'] = $net['mac'];
            $extra['network_type'] = $net['type'];
        }
    }

    pos_api_device_json_exit($conn, $serial, $msg, $extra);
}

/**
 * True if WMI/DMI reports a meaningless placeholder (common on cheap boards / VMs).
 */
function pos_license_serial_is_placeholder(string $candidate): bool {
    $t = strtolower(trim($candidate));
    if ($t === '') {
        return true;
    }
    $junk = ['to be filled', 'o.e.m.', 'default string', 'system serial', 'not applicable', 'not specified', 'invalid serial', 'invalid', 'unknown', 'none', 'n/a', 'xxxxxxxx', '0123456789'];
    foreach ($junk as $j) {
        if (strpos($t, $j) !== false) {
            return true;
        }
    }
    if (preg_match('/^[0\s\-_.]+$/', $t)) {
        return true;
    }
    return false;
}

/**
 * Run a shell command and return trimmed stdout (empty if disabled or failure).
 */
function pos_license_shell_read(string $command): string {
    if (!function_exists('shell_exec')) {
        return '';
    }
    $disabled = array_filter(array_map('trim', explode(',', (string)ini_get('disable_functions'))));
    if (in_array('shell_exec', $disabled, true)) {
        return '';
    }
    $out = @shell_exec($command);
    return is_string($out) ? trim($out) : '';
}

function pos_license_parse_wmic_bios_serial(string $output): string {
    $lines = preg_split('/\r\n|\r|\n/', trim($output));
    foreach ($lines as $line) {
        $line = trim((string)$line);
        if ($line === '' || stripos($line, 'SerialNumber') !== false) {
            continue;
        }
        return $line;
    }
    return '';
}

/**
 * Best-effort BIOS/baseboard serial on this machine (Windows XAMPP / Linux).
 */
function pos_detect_machine_serial(): string {
    $os = defined('PHP_OS_FAMILY') ? PHP_OS_FAMILY : PHP_OS;

    if ($os === 'Windows') {
        $ps = 'powershell -NoProfile -ExecutionPolicy Bypass -Command "(Get-CimInstance -ClassName Win32_BIOS).SerialNumber"';
        $sn = pos_license_shell_read($ps);
        if ($sn !== '' && !pos_license_serial_is_placeholder($sn)) {
            return $sn;
        }
        $wmic = pos_license_shell_read('wmic bios get serialnumber 2>nul');
        $sn = pos_license_parse_wmic_bios_serial($wmic);
        if ($sn !== '' && !pos_license_serial_is_placeholder($sn)) {
            return $sn;
        }
        $ps2 = 'powershell -NoProfile -ExecutionPolicy Bypass -Command "(Get-CimInstance -ClassName Win32_BaseBoard).SerialNumber"';
        $sn = pos_license_shell_read($ps2);
        if ($sn !== '' && !pos_license_serial_is_placeholder($sn)) {
            return $sn;
        }
        return '';
    }

    if ($os === 'Linux') {
        $paths = ['/sys/class/dmi/id/board_serial', '/sys/class/dmi/id/product_serial'];
        foreach ($paths as $p) {
            if (!is_readable($p)) {
                continue;
            }
            $raw = @file_get_contents($p);
            $sn = is_string($raw) ? trim($raw) : '';
            if ($sn !== '' && !pos_license_serial_is_placeholder($sn)) {
                return $sn;
            }
        }
    }

    return '';
}

/**
 * Normalize device serial for DB + Supabase: alphanumeric, dash, underscore, dot; minimum length for RPC.
 */
function pos_canonical_license_serial(string $raw): string {
    $raw = trim($raw);
    if ($raw === '') {
        return '';
    }
    $s = preg_replace('/[^A-Za-z0-9\-_.]/', '', $raw);
    if ($s === '' || strlen($s) < 4) {
        return '';
    }
    if (strlen($s) >= 8) {
        return $s;
    }
    return $s . '~' . substr(strtoupper(hash('sha256', $raw, false)), 0, 10);
}

/**
 * New installation key: laptop/device serial when readable, otherwise random hex (legacy behaviour).
 */
function pos_generate_installation_license_serial(): string {
    $hw = pos_detect_machine_serial();
    if ($hw !== '') {
        $canonical = pos_canonical_license_serial($hw);
        if ($canonical !== '') {
            return $canonical;
        }
    }
    return bin2hex(random_bytes(16));
}

function pos_ensure_license_serial($conn) {
    if (!function_exists('pos_db_get_setting_value') || !function_exists('pos_db_set_setting_value')) {
        return '';
    }
    $s = pos_db_get_setting_value($conn, 'pos_license_serial');
    if ($s !== null && trim((string)$s) !== '') {
        return trim((string)$s);
    }
    $newSerial = pos_generate_installation_license_serial();
    pos_db_set_setting_value($conn, 'pos_license_serial', $newSerial);
    return $newSerial;
}

/**
 * Short numeric security code for this installation (shown with serial on startup / admin verification).
 */
function pos_ensure_license_security_code($conn) {
    if (!function_exists('pos_db_get_setting_value') || !function_exists('pos_db_set_setting_value')) {
        return '';
    }
    $s = pos_db_get_setting_value($conn, 'pos_license_security_code');
    if ($s !== null && trim((string)$s) !== '') {
        return trim((string)$s);
    }
    $code = str_pad((string)random_int(100000, 999999), 6, '0', STR_PAD_LEFT);
    pos_db_set_setting_value($conn, 'pos_license_security_code', $code);
    return $code;
}

function pos_api_license_json_exit($serial, $message, array $extra = []) {
    if (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: application/json; charset=utf-8');
    if (!array_key_exists('license_security_code', $extra)) {
        $extra['license_security_code'] = '';
    }
    $out = array_merge([
        'status' => 'license_blocked',
        'message' => $message,
        'license_serial' => $serial,
    ], $extra);
    echo json_encode($out, JSON_UNESCAPED_UNICODE);
    exit();
}

function pos_license_online_recheck_seconds(): int {
    static $sec = null;
    if ($sec !== null) {
        return $sec;
    }
    $env = getenv('POS_LICENSE_ONLINE_RECHECK_SEC');
    if ($env !== false && is_string($env) && ctype_digit(trim($env))) {
        return $sec = max(30, min(600, (int)trim($env)));
    }
    return $sec = 30;
}

/** Client requested immediate license ping (startup / admin-revoke poll). */
function pos_api_license_force_recheck_requested(): bool {
    if (!isset($_GET['license_recheck'])) {
        return false;
    }
    $v = $_GET['license_recheck'];
    return $v === '1' || $v === 1 || $v === true || $v === 'true';
}

/** Skip repeated Supabase license ping when cache OK and checked within recheck window. */
function pos_license_recent_online_ok($conn): bool {
    if (!function_exists('pos_db_get_setting_value') || !$conn) {
        return false;
    }
    if (pos_db_get_setting_value($conn, 'pos_license_cache_ok') !== '1') {
        return false;
    }
    $last = pos_db_get_setting_value($conn, 'pos_license_last_online_ok_at');
    if ($last === null || $last === '') {
        return false;
    }
    return (time() - (int)$last) < pos_license_online_recheck_seconds();
}

function pos_license_mark_online_ok($conn): void {
    if (function_exists('pos_db_set_setting_value') && $conn) {
        @pos_db_set_setting_value($conn, 'pos_license_last_online_ok_at', (string)time());
    }
}

/** Clear local activation after admin delete/block — forces re-register on next online check. */
function pos_license_clear_local_activation_cache($conn): void {
    if (!$conn || !function_exists('pos_db_set_setting_value')) {
        return;
    }
    pos_db_set_setting_value($conn, 'pos_license_cache_ok', '0');
    pos_db_set_setting_value($conn, 'pos_license_cache_until', '0');
    @pos_db_set_setting_value($conn, 'pos_license_last_online_ok_at', '0');
    @pos_db_set_setting_value($conn, 'pos_dev_trusted', '');
    @pos_db_set_setting_value($conn, 'pos_dev_grace', '');
    @pos_db_set_setting_value($conn, 'pos_dev_last_online_ok', '');
    pos_license_clear_local_feature_unlocks($conn);
}

/** Strip à-la-carte FEAT unlocks locally when license is blocked/deleted. */
function pos_license_clear_local_feature_unlocks($conn): void {
    if (!$conn || !function_exists('pos_load_app_settings_array') || !function_exists('pos_db_set_setting_value')) {
        return;
    }
    $settings = pos_load_app_settings_array($conn);
    if (!is_array($settings)) {
        return;
    }
    $settings['purchasedFeatures'] = [];
    $settings['premiumFeatureUnlocks'] = [];
    if (!isset($settings['premiumFeatureForceLocked']) || !is_array($settings['premiumFeatureForceLocked'])) {
        $settings['premiumFeatureForceLocked'] = [];
    }
    $json = json_encode($settings, JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        return;
    }
    $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('app_settings', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
    if ($stmt) {
        $stmt->bind_param('ss', $json, $json);
        $stmt->execute();
        $stmt->close();
    }
}

function pos_device_mark_online_ok($conn, string $installationSerial, string $devNorm): void {
    if (!function_exists('pos_db_set_setting_value') || !$conn || $devNorm === '') {
        return;
    }
    $payload = json_encode(
        ['s' => trim($installationSerial), 'k' => $devNorm, 't' => time(), 'ok' => '1'],
        JSON_UNESCAPED_UNICODE
    );
    @pos_db_set_setting_value($conn, 'pos_dev_last_online_ok', $payload);
}

function pos_device_recent_online_ok($conn, string $installationSerial, string $devNorm): bool {
    if (!function_exists('pos_db_get_setting_value') || !$conn || $devNorm === '') {
        return false;
    }
    $raw = pos_db_get_setting_value($conn, 'pos_dev_last_online_ok');
    if ($raw === null || $raw === '') {
        return false;
    }
    $a = json_decode((string)$raw, true);
    if (!is_array($a) || ($a['ok'] ?? '') !== '1') {
        return false;
    }
    $age = time() - (int)($a['t'] ?? 0);
    if ($age >= pos_license_online_recheck_seconds()) {
        return false;
    }
    return trim((string)($a['s'] ?? '')) === trim($installationSerial)
        && trim((string)($a['k'] ?? '')) === $devNorm;
}

function pos_api_require_license_or_exit($conn) {
    // [AUTOMATIC OFFLINE MODE]
    // If the system was ever activated locally ($cachedOk === '1'), we allow it to work 
    // even if the cloud server is unreachable or has transient errors.
    $cachedOk = pos_db_get_setting_value($conn, 'pos_license_cache_ok');
    
    $serial = pos_ensure_license_serial($conn);
    $securityCode = pos_ensure_license_security_code($conn);

    if ($serial === '') {
        pos_api_license_json_exit('', 'نەتوانرا ژمارەی دامەزراندن دابنرێت.', ['license_detail' => 'no_serial', 'license_security_code' => $securityCode]);
    }
    if (!defined('POS_SUPABASE_ANON_KEY') || POS_SUPABASE_ANON_KEY === '') {
        pos_api_license_json_exit($serial, 'ڕێکخستنی Supabase تەواو نییە (کلیلی API).', ['license_detail' => 'config', 'license_security_code' => $securityCode]);
    }

    $act = isset($_GET['action']) ? trim((string)$_GET['action']) : (isset($_POST['action']) ? trim((string)$_POST['action']) : '');
    // Never delay shift close / logout / sales history on a live Supabase ping (weak laptops + slow networks).
    if (in_array($act, ['end_shift', 'logout', 'get_sales_history', 'get_returns_history', 'get_sale_record', 'get_sync_tick', 'get_sync_data'], true)) {
        return;
    }
    if (function_exists('pos_api_is_lan_hot_path_action') && pos_api_is_lan_hot_path_action($act) && $cachedOk === '1') {
        return;
    }

    // Login screen + PIN must stay local-fast after format / first open.
    if (in_array($act, ['login', 'get_login_data', 'register_pos_client_device', 'check_pos_app_update', 'download_pos_app_update', 'apply_pos_app_update'], true)) {
        return;
    }

    $now = time();
    $untilRaw = pos_db_get_setting_value($conn, 'pos_license_cache_until');
    $until = ($untilRaw !== null && $untilRaw !== '') ? (int)$untilRaw : 0;

    // Login + bootstrap refresh: trust local license cache — do not block cashier on Supabase (8–16s+ per call).
    $isBootstrapGet = ($act === 'get_data' && !empty($_GET['bootstrap']));
    if ($isBootstrapGet) {
        $uid = 0;
        if (session_status() === PHP_SESSION_ACTIVE && !empty($_SESSION['user_id'])) {
            $uid = (int)$_SESSION['user_id'];
        }
        if ($uid <= 0) {
            return;
        }
        if ($cachedOk === '1') {
            return;
        }
    }
    $isTerminalSetup = in_array($act, [
        'redeem_terminal_activation_code',
        'get_terminal_network_identity',
        'get_fragi_client_device_key',
        'check_pos_client_device_status',
    ], true);
    if ($isTerminalSetup && $cachedOk === '1') {
        return;
    }

    $mustRecheck = pos_api_license_force_recheck_requested() || !pos_license_recent_online_ok($conn);

    // Skip repeated Supabase ping when cache OK and checked within recheck window (default 30s).
    if ($cachedOk === '1' && !$mustRecheck) {
        return;
    }

    // Re-verify with Supabase periodically; admin delete/block applies within recheck window (default 30s).
    $r = pos_supabase_check_license_remote($serial);
    if (!empty($r['ok'])) {
        pos_db_set_setting_value($conn, 'pos_license_cache_until', (string)($now + 90 * 86400));
        pos_db_set_setting_value($conn, 'pos_license_cache_ok', '1');
        pos_license_mark_online_ok($conn);
        if (!empty($r['subscription_tier']) && function_exists('pos_subscription_save_tier_to_settings')) {
            pos_subscription_save_tier_to_settings($conn, (string)$r['subscription_tier']);
        }
        return;
    }

    $detail = isset($r['status']) ? (string)$r['status'] : '';
    if ($detail === '' && isset($r['reason'])) {
        $detail = (string)$r['reason'];
    }
    $httpCode = isset($r['http_code']) ? (int)$r['http_code'] : 0;

    // Explicit deny: missing/blocked license — clear cache, never allow offline bypass.
    if ($detail === 'missing' || $detail === 'blocked') {
        pos_license_clear_local_activation_cache($conn);
    } elseif ($cachedOk === '1') {
        // [AUTOMATIC FALLBACK]
        // If we have a local activation, and the cloud check failed (transient error, timeout, or unreachable),
        // we automatically allow the program to continue working to ensure business continuity.
        return;
    } else {
        pos_db_set_setting_value($conn, 'pos_license_cache_ok', '0');
    }

    if ($detail === 'missing') {
        $msg = 'سیستەمەکە هێشتا چالاک نەکراوە. سێریاڵەکەی خوارەوە بنێرە بۆ بەڕێوەبەر بۆ ئەوەی بۆتی چالاک بکات.';
    } elseif ($detail === 'blocked') {
        $msg = 'ئەم سیستەمە ڕاگیراوە (بلۆک کراوە). تکایە پەیوەندی بە بەڕێوەبەرەوە بکە.';
    } elseif ($detail === 'http') {
        if ($httpCode === 404) {
            $msg = 'دالة check_pos_license غير موجودة. افتح SQL Editor والصق محتوى الملف sql/supabase_check_pos_license_only.sql ونفّذه ثم أعد المحاولة.';
        } elseif ($httpCode === 401 || $httpCode === 403) {
            $msg = 'کلیلی سێرڤەر ڕەتکرایەوە. تکایە پێداچوونەوە بکە.';
        } elseif ($httpCode === 0 || pos_supabase_http_is_transient_outage($httpCode)) {
            $msg = 'سێرڤەر بە کاتی بەردەست نییە (سنوور یان پارەدان یان تۆڕ). دوکان بە کاشی ناوخۆیی بەردەوامە — دواتر هەوڵ بدەرەوە.';
        } else {
            $msg = 'رد غير متوقع من السيرفر (HTTP ' . $httpCode . '). راجع لوحة المشروع.';
        }
    } elseif ($detail === 'parse' || $detail === 'shape') {
        $msg = 'استجابة غير صالحة من السيرفر. نفّذ sql/supabase_check_pos_license_only.sql في SQL Editor.';
    } elseif ($detail === 'config') {
        $msg = 'إعداد السيرفر غير مكتمل.';
    } else {
        $msg = 'سێریاڵی سیستەمەکە دروست نییە.';
    }

    $extra = ['license_detail' => $detail];
    if ($httpCode > 0) {
        $extra['license_http_code'] = $httpCode;
    }
    if (!empty($r['detail'])) {
        $extra['license_response_snippet'] = (string)$r['detail'];
    }
    if (!empty($r['curl_error'])) {
        $extra['license_curl_error'] = (string)$r['curl_error'];
    }
    if (!empty($r['insecure_ssl'])) {
        $extra['license_ssl_fallback'] = true;
    }

    $extra['license_security_code'] = $securityCode;
    pos_api_license_json_exit($serial, $msg, $extra);
}

/** @return 'free'|'pro'|'pro_plus' */
function pos_subscription_tier_normalize($raw): string {
    $t = strtolower(trim((string)$raw));
    if ($t === 'pro' || $t === 'pro_plus') {
        return $t;
    }
    return 'free';
}

function pos_subscription_save_tier_to_settings($conn, string $tier): void {
    if (!$conn || !function_exists('pos_load_app_settings_array')) {
        return;
    }
    $settings = pos_load_app_settings_array($conn);
    $settings['subscription_tier'] = pos_subscription_tier_normalize($tier);
    $json = json_encode($settings, JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        return;
    }
    $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('app_settings', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
    if ($stmt) {
        $stmt->bind_param('ss', $json, $json);
        $stmt->execute();
        $stmt->close();
    }
}

/** Map Supabase lowercase feature_key → app_settings camelCase key. */
function pos_premium_canonical_feature_key(string $key): string {
    static $map = [
        'enabletakeaway' => 'enableTakeaway',
        'takeawayaswholesale' => 'takeawayAsWholesale',
        'enablewholesale' => 'enableWholesale',
        'showitemnoteicon' => 'showItemNoteIcon',
        'showtables' => 'showTables',
        'enablegift' => 'enableGift',
        'enablemanualsale' => 'enableManualSale',
        'enablerecipe' => 'enableRecipe',
        'unlockstaffbeyondfive' => 'unlockStaffBeyondFive',
        'fabmenu' => 'fabMenu',
        'enabledelivery' => 'enableDelivery',
        'requireopeningbalanceprompt' => 'requireOpeningBalancePrompt',
        'requireendshiftreconcileprompt' => 'requireEndShiftReconcilePrompt',
        'allownegativestock' => 'allowNegativeStock',
        'enablemoneyrounding' => 'enableMoneyRounding',
        'showpaymentmodal' => 'showPaymentModal',
        'showstockonpos' => 'showStockOnPos',
        'enablemultiwarehouse' => 'enableMultiWarehouse',
        'showprintnotepopup' => 'showPrintNotePopup',
        'enablecustomerinstallments' => 'enableCustomerInstallments',
        'manufacturerslot' => 'manufacturerSlot',
        'enablepurchasebatch' => 'enablePurchaseBatch',
        'enabletechspecs' => 'enableTechSpecs',
        'enablesalefollowup' => 'enableSaleFollowup',
    ];
    $lk = strtolower(trim($key));
    return $map[$lk] ?? $key;
}

/**
 * Persist à-la-carte feature purchase in local app_settings (survives reload / bootstrap).
 */
function pos_subscription_persist_purchased_feature($conn, string $featureKey): void {
    $featureKey = pos_premium_canonical_feature_key(trim($featureKey));
    if (!$conn || $featureKey === '' || !function_exists('pos_load_app_settings_array')) {
        return;
    }
    $settings = pos_load_app_settings_array($conn);
    if (!is_array($settings)) {
        $settings = [];
    }
    if (!isset($settings['purchasedFeatures']) || !is_array($settings['purchasedFeatures'])) {
        $settings['purchasedFeatures'] = [];
    }
    $settings['purchasedFeatures'][$featureKey] = true;
    if (!isset($settings['premiumFeatureUnlocks']) || !is_array($settings['premiumFeatureUnlocks'])) {
        $settings['premiumFeatureUnlocks'] = [];
    }
    if (!isset($settings['premiumFeatureForceLocked']) || !is_array($settings['premiumFeatureForceLocked'])) {
        $settings['premiumFeatureForceLocked'] = [];
    }
    $settings['premiumFeatureUnlocks'][$featureKey] = true;
    $settings['premiumFeatureForceLocked'][$featureKey] = false;
    $optOutKeys = ['requireOpeningBalancePrompt', 'requireEndShiftReconcilePrompt', 'enableMoneyRounding'];
    if (in_array($featureKey, $optOutKeys, true)) {
        $settings[$featureKey] = true;
    } elseif ($featureKey === 'showPaymentModal' || $featureKey === 'showPrintNotePopup') {
        $settings[$featureKey] = true;
    } elseif ($featureKey === 'enableCustomerInstallments') {
        $settings['enableCustomerInstallments'] = true;
    } elseif ($featureKey === 'manufacturerSlot') {
        $settings['manufacturerSlotsPurchased'] = defined('POS_MANUFACTURER_PACK_MAX') ? (int)POS_MANUFACTURER_PACK_MAX : 100;
    } else {
        $settings[$featureKey] = true;
    }
    $json = json_encode($settings, JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        return;
    }
    $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('app_settings', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
    if ($stmt) {
        $stmt->bind_param('ss', $json, $json);
        $stmt->execute();
        $stmt->close();
    }
}

/**
 * Merge remote entitlement features into settings.purchasedFeatures for offline recognition.
 *
 * @param array<string,mixed> $settings
 * @param array<string,mixed>|null $entitlements
 * @return array<string,mixed>
 */
function pos_subscription_merge_entitlements_into_settings(array $settings, ?array $entitlements): array {
    if (!is_array($entitlements) || empty($entitlements['features']) || !is_array($entitlements['features'])) {
        return $settings;
    }
    if (!isset($settings['purchasedFeatures']) || !is_array($settings['purchasedFeatures'])) {
        $settings['purchasedFeatures'] = [];
    }
    if (!isset($settings['premiumFeatureUnlocks']) || !is_array($settings['premiumFeatureUnlocks'])) {
        $settings['premiumFeatureUnlocks'] = [];
    }
    foreach ($entitlements['features'] as $fkey => $enabled) {
        if (!$enabled) {
            continue;
        }
        $canonical = pos_premium_canonical_feature_key((string)$fkey);
        $settings['purchasedFeatures'][$canonical] = true;
        $settings['premiumFeatureUnlocks'][$canonical] = true;
        if (!isset($settings['premiumFeatureForceLocked']) || !is_array($settings['premiumFeatureForceLocked'])) {
            $settings['premiumFeatureForceLocked'] = [];
        }
        $settings['premiumFeatureForceLocked'][$canonical] = false;
    }
    return $settings;
}

/**
 * Fetch remote entitlements and persist purchased features into app_settings (MySQL).
 *
 * @return array{ok:bool,entitlements?:array,settings?:array,saved?:bool,reason?:string}
 */
function pos_subscription_repair_feature_entitlements($conn, ?string $serial = null): array {
    if (!$conn || !function_exists('pos_ensure_license_serial') || !function_exists('pos_load_app_settings_array')) {
        return ['ok' => false, 'reason' => 'no_conn'];
    }
    $serial = trim($serial ?? (string)pos_ensure_license_serial($conn));
    if ($serial === '' || strlen($serial) < 4) {
        return ['ok' => false, 'reason' => 'no_serial'];
    }
    $ent = pos_subscription_fetch_entitlements_remote($serial);
    if (empty($ent['ok'])) {
        return ['ok' => false, 'reason' => isset($ent['reason']) ? (string)$ent['reason'] : 'remote_failed', 'entitlements' => $ent];
    }
    $settings = pos_load_app_settings_array($conn);
    if (!is_array($settings)) {
        $settings = [];
    }
    $settings = pos_subscription_merge_entitlements_into_settings($settings, $ent);
    $json = json_encode($settings, JSON_UNESCAPED_UNICODE);
    $saved = false;
    if ($json !== false) {
        $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('app_settings', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        if ($stmt) {
            $stmt->bind_param('ss', $json, $json);
            $saved = (bool)$stmt->execute();
            $stmt->close();
        }
    }
    return ['ok' => true, 'entitlements' => $ent, 'settings' => $settings, 'saved' => $saved];
}

/**
 * @return array{ok?:bool,tier?:string,premium?:bool,max_staff?:int,multi_device?:bool,reason?:string}
 */
function pos_subscription_fetch_entitlements_remote(string $serial): array {
    $serial = trim($serial);
    if ($serial === '' || strlen($serial) < 4) {
        return ['ok' => false, 'tier' => 'free', 'premium' => false];
    }
    $payload = ['p_serial' => $serial];
    $alt = ['serial' => $serial];
    $j = pos_supabase_rpc_post_json('get_subscription_entitlements', $payload, $alt);
    if (!empty($j['ok']) && isset($j['tier'])) {
        return $j;
    }
    return ['ok' => false, 'tier' => 'free', 'premium' => false, 'reason' => isset($j['reason']) ? (string)$j['reason'] : 'http'];
}

/** Sync subscription tier from Supabase into local app_settings (offline grace). */
function pos_subscription_sync_tier($conn, ?string $serial = null): string {
    if (!$conn || !function_exists('pos_ensure_license_serial') || !function_exists('pos_load_app_settings_array')) {
        return 'free';
    }
    $serial = trim($serial ?? (string)pos_ensure_license_serial($conn));
    if ($serial === '' || strlen($serial) < 4) {
        return 'free';
    }
    $settings = pos_load_app_settings_array($conn);
    $local = pos_subscription_tier_normalize($settings['subscription_tier'] ?? 'free');

    if (pos_license_recent_online_ok($conn)) {
        return $local;
    }

    $lic = pos_supabase_check_license_remote($serial);
    if (!empty($lic['subscription_tier'])) {
        $tier = pos_subscription_tier_normalize($lic['subscription_tier']);
        if ($tier !== $local) {
            pos_subscription_save_tier_to_settings($conn, $tier);
        }
        return $tier;
    }

    $ent = pos_subscription_fetch_entitlements_remote($serial);
    if (!empty($ent['ok']) && isset($ent['tier'])) {
        $tier = pos_subscription_tier_normalize($ent['tier']);
        if ($tier !== $local) {
            pos_subscription_save_tier_to_settings($conn, $tier);
        }
        return $tier;
    }

    return $local;
}

/**
 * @return array{ok?:bool,tier?:string,reason?:string,entitlements?:array}
 */
function pos_supabase_redeem_activation_code_remote(string $serial, string $code): array {
    $serial = trim($serial);
    $code = trim($code);
    if ($serial === '' || strlen($serial) < 4 || $code === '') {
        return ['ok' => false, 'reason' => 'invalid_input'];
    }
    $payload = ['p_serial' => $serial, 'p_code' => $code];
    $alt = ['serial' => $serial, 'code' => $code];
    return pos_supabase_rpc_post_json('redeem_activation_code', $payload, $alt);
}

/**
 * @return array{ok?:bool,status?:string,reason?:string,message?:string}
 */
function pos_supabase_redeem_device_activation_code_remote(string $serial, string $deviceKey, string $code): array {
    $serial = trim($serial);
    $deviceKey = pos_normalize_client_device_key(trim($deviceKey));
    $code = trim($code);
    if ($serial === '' || strlen($serial) < 4 || $deviceKey === '' || $code === '') {
        return ['ok' => false, 'reason' => 'invalid_input'];
    }
    $payload = [
        'p_serial' => $serial,
        'p_device_key' => $deviceKey,
        'p_code' => $code,
    ];
    $alt = [
        'serial' => $serial,
        'device_key' => $deviceKey,
        'code' => $code,
    ];
    return pos_supabase_rpc_post_json('redeem_device_activation_code', $payload, $alt);
}

function pos_supabase_log_admin_event_remote(string $serial, string $deviceKey, string $eventType, string $message = ''): void {
    if (!defined('POS_SUPABASE_ANON_KEY') || POS_SUPABASE_ANON_KEY === '') {
        return;
    }
    $payload = [
        'p_serial' => trim($serial),
        'p_device_key' => trim($deviceKey),
        'p_event_type' => $eventType,
        'p_message' => $message,
    ];
    pos_supabase_rpc_post_json('log_pos_admin_event', $payload, null);
}

/**
 * Fetch unread user notifications from Supabase for this installation + device.
 *
 * @return array{ok:bool,notifications?:array<int,array<string,mixed>>,reason?:string}
 */
function pos_supabase_fetch_user_notifications_remote(string $installationSerial, string $deviceId): array {
    $serial = trim($installationSerial);
    $device = trim($deviceId);
    if ($serial === '' || strlen($serial) < 4 || $device === '') {
        return ['ok' => false, 'reason' => 'invalid_input', 'notifications' => []];
    }
    if (!defined('POS_SUPABASE_ANON_KEY') || POS_SUPABASE_ANON_KEY === '') {
        return ['ok' => false, 'reason' => 'config', 'notifications' => []];
    }
    $payload = [
        'p_installation_serial' => $serial,
        'p_device_id' => substr($device, 0, 120),
    ];
    $alt = [
        'installation_serial' => $serial,
        'device_id' => substr($device, 0, 120),
    ];
    $j = pos_supabase_rpc_post_json('fetch_pos_user_notifications', $payload, $alt);
    if (isset($j['reason']) && $j['reason'] === 'http') {
        return ['ok' => false, 'reason' => 'http', 'notifications' => []];
    }
    if (empty($j['ok'])) {
        return ['ok' => false, 'reason' => (string)($j['reason'] ?? 'error'), 'notifications' => []];
    }
    $rows = isset($j['notifications']) && is_array($j['notifications']) ? $j['notifications'] : [];
    return ['ok' => true, 'notifications' => $rows];
}

/**
 * Fetch latest POS app release from Supabase (OTA self-update).
 * Supports granular targeting by installation serial.
 *
 * @return array{ok:bool,has_update?:bool,latest?:array<string,mixed>,reason?:string}
 */
function pos_supabase_fetch_latest_app_release_remote(string $currentVersion, string $installationSerial = ''): array {
    $cur = trim($currentVersion);
    if ($cur === '') {
        $cur = '0';
    }
    $serial = trim($installationSerial);
    if (!defined('POS_SUPABASE_ANON_KEY') || POS_SUPABASE_ANON_KEY === '') {
        return ['ok' => false, 'reason' => 'config', 'has_update' => false];
    }
    $payload = [
        'p_current_version' => $cur,
        'p_installation_serial' => $serial !== '' ? $serial : null,
    ];
    $alt = [
        'current_version' => $cur,
        'installation_serial' => $serial !== '' ? $serial : null,
    ];
    $j = pos_supabase_rpc_post_json('fetch_latest_pos_app_release', $payload, $alt);
    // If remote RPC fails on older Supabase schema (parameter mismatch), fallback to 1-param:
    if (empty($j['ok']) && !empty($j['reason']) && $j['reason'] !== 'http') {
        $jFallback = pos_supabase_rpc_post_json('fetch_latest_pos_app_release', ['p_current_version' => $cur], ['current_version' => $cur]);
        if (!empty($jFallback['ok'])) {
            $j = $jFallback;
        }
    }
    if (isset($j['reason']) && $j['reason'] === 'http') {
        return ['ok' => false, 'reason' => 'http', 'has_update' => false];
    }
    if (empty($j['ok'])) {
        return ['ok' => false, 'reason' => (string)($j['reason'] ?? 'error'), 'has_update' => false];
    }
    $latest = (isset($j['latest']) && is_array($j['latest'])) ? $j['latest'] : null;
    return [
        'ok' => true,
        'has_update' => !empty($j['has_update']),
        'latest' => $latest,
    ];
}

/**
 * Dotted version compare: 1 if a>b, -1 if a<b, 0 equal.
 */
function pos_app_version_cmp(string $a, string $b): int {
    $pa = preg_split('/\./', preg_replace('/[^0-9.]+/', '', $a) ?: '0') ?: ['0'];
    $pb = preg_split('/\./', preg_replace('/[^0-9.]+/', '', $b) ?: '0') ?: ['0'];
    $n = max(count($pa), count($pb));
    for ($i = 0; $i < $n; $i++) {
        $na = isset($pa[$i]) ? (int)$pa[$i] : 0;
        $nb = isset($pb[$i]) ? (int)$pb[$i] : 0;
        if ($na > $nb) return 1;
        if ($na < $nb) return -1;
    }
    return 0;
}

/**
 * Mark Supabase user notifications as read for this installation + device.
 *
 * @param string[] $notificationIds UUID strings
 */
function pos_supabase_mark_user_notifications_read_remote(string $installationSerial, string $deviceId, array $notificationIds): array {
    $serial = trim($installationSerial);
    $device = trim($deviceId);
    $ids = array_values(array_filter(array_map('strval', $notificationIds), static function ($v) {
        return $v !== '';
    }));
    if ($serial === '' || strlen($serial) < 4 || $device === '' || empty($ids)) {
        return ['ok' => false, 'reason' => 'invalid_input'];
    }
    if (!defined('POS_SUPABASE_ANON_KEY') || POS_SUPABASE_ANON_KEY === '') {
        return ['ok' => false, 'reason' => 'config'];
    }
    $payload = [
        'p_installation_serial' => $serial,
        'p_device_id' => substr($device, 0, 120),
        'p_notification_ids' => $ids,
    ];
    $alt = [
        'installation_serial' => $serial,
        'device_id' => substr($device, 0, 120),
        'notification_ids' => $ids,
    ];
    $j = pos_supabase_rpc_post_json('mark_pos_user_notifications_read', $payload, $alt);
    if (isset($j['reason']) && $j['reason'] === 'http') {
        return ['ok' => false, 'reason' => 'http'];
    }
    return is_array($j) ? $j : ['ok' => false, 'reason' => 'parse'];
}

/**
 * Redeem device activation code before device gate (laptop blocked screen).
 */
function pos_api_redeem_device_activation_code_and_exit($conn) {
    if (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: application/json; charset=utf-8');
    if (pos_client_is_terminal_attempt()) {
        echo json_encode([
            'status' => 'error',
            'reason' => 'terminal_code_required',
            'message' => 'Sub-devices must use a terminal activation code (TERM-XXXX-XXXX) — primary device codes cannot unlock terminals.',
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $serial = pos_ensure_license_serial($conn);
    if ($serial === '' || strlen(trim($serial)) < 4) {
        echo json_encode(['status' => 'error', 'message' => 'نەتوانرا ژمارەی دامەزراندن دابنرێت.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    if (!defined('POS_SUPABASE_ANON_KEY') || POS_SUPABASE_ANON_KEY === '') {
        echo json_encode(['status' => 'error', 'message' => 'ڕێکخستنی Supabase تەواو نییە.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $rawKey = isset($_POST['device_key']) ? (string)$_POST['device_key'] : '';
    if ($rawKey === '' && function_exists('pos_http_read_pos_device_key')) {
        $rawKey = pos_http_read_pos_device_key();
    }
    $code = trim((string)($_POST['code'] ?? ''));
    if ($code === '') {
        echo json_encode(['status' => 'error', 'message' => 'کۆدی چالاککردنی ئامێر پێویستە.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $devNorm = pos_resolve_effective_device_key($conn, $rawKey);
    if ($devNorm === '') {
        echo json_encode(['status' => 'error', 'message' => 'مفتاح الجهاز غير صالح. أعد تحميل الصفحة.'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    // Ensure device row exists in Supabase before redeem (fixes race with page load register).
    $regMeta = [
        'user_agent' => substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 2048),
        'platform' => '',
        'hint' => 'redeem_precheck',
        'request_ip' => pos_client_request_ip_for_pos_device(),
        'device_role' => 'primary',
    ];
    $reg = pos_supabase_register_device_remote($serial, $devNorm, $regMeta);
    if (!empty($reg['registered'])) {
        pos_supabase_log_admin_event_remote($serial, $devNorm, 'device_registered', 'Device registered from POS');
    }

    $r = pos_supabase_redeem_device_activation_code_remote($serial, $devNorm, $code);
    if (empty($r['ok'])) {
        $reason = isset($r['reason']) ? (string)$r['reason'] : 'error';
        if ($reason === 'http') {
            $http = isset($r['http_code']) ? (int)$r['http_code'] : 0;
            $detail = isset($r['detail']) ? (string)$r['detail'] : '';
            $rpcMissing = ($http === 404) || stripos($detail, 'redeem_device_activation_code') !== false;
            echo json_encode([
                'status' => 'error',
                'reason' => 'http',
                'message' => $rpcMissing
                    ? 'دالة Supabase غير موجودة — نفّذ sql/supabase_device_activation_codes.sql في SQL Editor.'
                    : ('تعذر الاتصال بـ Supabase (HTTP ' . $http . ').'),
            ], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $localSec = function_exists('pos_ensure_license_security_code') && $conn
            ? trim((string)pos_ensure_license_security_code($conn))
            : '';
        $codeDigits = preg_replace('/[^0-9]/', '', $code);
        $reasonMsgs = [
            'invalid_input' => 'الكود أو السيريال غير صالح.',
            'code_not_found' => ($localSec !== '' && $codeDigits === preg_replace('/[^0-9]/', '', $localSec))
                ? 'هذا «كود الأمان» المحلي للتعريف فقط — استخدم كود التفعيل الذي أنشأته من لوحة الأدmin (6 أرقام).'
                : 'كود التفعيل غير موجود — أنشئ كوداً جديداً من الأدmin (الخطوة ②).',
            'code_revoked' => 'تم إلغاء هذا الكود.',
            'code_already_used' => 'هذا الكود مستخدم مسبقاً.',
            'serial_mismatch' => 'الكود لا يطابق سيريال هذا المتجر.',
            'license_missing' => 'سجّل العميل في لوحة الأدمن أولاً (الخطوة ③).',
            'person_name_required' => 'اسم المالك مطلوب في التسجيل قبل تفعيل الجهاز.',
            'license_not_active' => 'ترخيص المتجر غير نشط.',
            'tier_device_limit' => isset($r['message']) && trim((string)$r['message']) !== ''
                ? (string)$r['message']
                : 'خطة Pro تسمح بجهاز واحد فقط. ترقية إلى Pro Plus.',
            'device_not_registered' => 'الجهاز غير مسجّل. أعد تحميل الصفحة.',
            'device_archived' => 'الجهاز مؤرشف.',
            'device_blocked' => 'الجهاز محظور — راجع المشرف.',
        ];
        echo json_encode([
            'status' => 'error',
            'reason' => $reason,
            'message' => $reasonMsgs[$reason] ?? 'فشل تفعيل الجهاز بالكود.',
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    pos_device_note_verified_online($conn, $serial, $devNorm);
    pos_supabase_log_admin_event_remote($serial, $devNorm, 'device_code_redeemed', 'Code accepted on laptop');
    for ($i = 0; $i < 4; $i++) {
        $chk = pos_supabase_check_device_remote($serial, $devNorm);
        if (!empty($chk['ok'])) {
            break;
        }
        if ($i < 3) {
            usleep(250000);
        }
    }
    echo json_encode([
        'status' => 'success',
        'device_status' => isset($r['status']) ? (string)$r['status'] : 'approved',
        'message' => 'تم تفعيل الجهاز بنجاح.',
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

/**
 * Lightweight device status check — runs before device gate (for polling while blocked).
 */
function pos_api_check_pos_client_device_status_and_exit($conn) {
    if (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: application/json; charset=utf-8');
    $serial = pos_ensure_license_serial($conn);
    if ($serial === '' || strlen(trim($serial)) < 4) {
        echo json_encode(['status' => 'error', 'message' => 'نەتوانرا ژمارەی دامەزراندن دابنرێت.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    if (!defined('POS_SUPABASE_ANON_KEY') || POS_SUPABASE_ANON_KEY === '') {
        echo json_encode(['status' => 'error', 'message' => 'ڕێکخستنی Supabase تەواو نییە.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $rawKey = isset($_POST['device_key']) ? (string)$_POST['device_key'] : '';
    if ($rawKey === '' && function_exists('pos_http_read_pos_device_key')) {
        $rawKey = pos_http_read_pos_device_key();
    }
    $devNorm = pos_resolve_effective_device_key($conn, $rawKey);
    if ($devNorm === '') {
        echo json_encode([
            'status' => 'error',
            'device_status' => 'invalid',
            'message' => 'مفتاح الجهاز غير صالح — أعد تحميل الصفحة.',
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $r = pos_supabase_check_device_remote($serial, $devNorm);
    if (!empty($r['ok'])) {
        pos_device_note_verified_online($conn, $serial, $devNorm);
        echo json_encode([
            'status' => 'success',
            'ok' => true,
            'device_status' => 'approved',
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $detail = isset($r['status']) ? (string)$r['status'] : 'pending';
    if ($detail === 'slot_required' && pos_is_fragi_device_key($devNorm)) {
        $slotMsg = isset($r['message']) && trim((string)$r['message']) !== ''
            ? (string)$r['message']
            : pos_terminal_slot_required_message();
        echo json_encode([
            'status' => 'device_blocked',
            'ok' => false,
            'device_status' => 'slot_required',
            'message' => $slotMsg,
            'license_serial' => $serial,
            'device_detail' => 'slot_required',
            'terminal_activation_required' => true,
            'terminal_security_required' => true,
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    if (($detail === 'pro_required' || $detail === 'pro_plus_required') && pos_is_fragi_device_key($devNorm)) {
        if (pos_shop_allows_fragi_term_redeem($conn, $serial)) {
            echo json_encode([
                'status' => 'device_blocked',
                'ok' => false,
                'device_status' => 'slot_required',
                'message' => 'کۆدی TERM بنڤیسە — ژ لاپتۆپێ سەرەکی ڕێکخستن → خانەی سیکوریتی.',
                'license_serial' => $serial,
                'device_detail' => 'slot_required',
                'terminal_activation_required' => true,
                'terminal_security_required' => true,
            ], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $gateMsg = isset($r['message']) && trim((string)$r['message']) !== ''
            ? (string)$r['message']
            : pos_terminal_pro_required_message();
        echo json_encode([
            'status' => 'terminal_pro_required',
            'ok' => false,
            'device_status' => $detail,
            'message' => $gateMsg,
            'license_serial' => $serial,
            'terminal_activation_required' => true,
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    echo json_encode([
        'status' => 'success',
        'ok' => false,
        'device_status' => $detail !== '' ? $detail : 'pending',
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

/**
 * Sub-device / terminal network status for Settings (Pro Plus multi-terminal).
 */
function pos_supabase_get_sub_device_network_status_remote(string $serial, string $callerDeviceKey = ''): array {
    $serial = trim($serial);
    if ($serial === '' || strlen($serial) < 4) {
        return ['ok' => false, 'reason' => 'invalid_serial'];
    }
    $callerNorm = pos_normalize_client_device_key($callerDeviceKey);
    $payload = [
        'p_serial' => $serial,
        'p_caller_device_key' => $callerNorm !== '' ? $callerNorm : null,
    ];
    $alt = [
        'serial' => $serial,
        'caller_device_key' => $callerNorm !== '' ? $callerNorm : null,
    ];
    return pos_supabase_rpc_post_json('get_sub_device_network_status', $payload, $alt);
}

function pos_api_get_sub_device_network_status_and_exit($conn) {
    if (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: application/json; charset=utf-8');
    if (function_exists('pos_session_require_login_json')) {
        pos_session_require_login_json();
    }
    $serial = pos_ensure_license_serial($conn);
    if ($serial === '' || strlen(trim($serial)) < 4) {
        echo json_encode(['status' => 'error', 'message' => 'نەتوانرا ژمارەی دامەزراندن دابنرێت.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    if (!defined('POS_SUPABASE_ANON_KEY') || POS_SUPABASE_ANON_KEY === '') {
        echo json_encode(['status' => 'error', 'message' => 'ڕێکخستنی Supabase تەواو نییە.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $rawKey = function_exists('pos_http_read_pos_device_key') ? pos_http_read_pos_device_key() : '';
    $callerKey = pos_resolve_effective_device_key($conn, $rawKey);
    $r = pos_supabase_get_sub_device_network_status_remote($serial, $callerKey);
    if (empty($r['ok'])) {
        $reason = isset($r['reason']) ? (string)$r['reason'] : 'error';
        if ($reason === 'http') {
            $http = isset($r['http_code']) ? (int)$r['http_code'] : 0;
            $detail = isset($r['detail']) ? (string)$r['detail'] : '';
            $rpcMissing = ($http === 404) || stripos($detail, 'get_sub_device_network_status') !== false;
            echo json_encode([
                'status' => 'error',
                'reason' => 'http',
                'message' => $rpcMissing
                    ? 'دالة Supabase غير موجودة — نفّذ sql/supabase_terminal_licenses.sql في SQL Editor.'
                    : ('تعذر الاتصال بـ Supabase (HTTP ' . $http . ').'),
            ], JSON_UNESCAPED_UNICODE);
            exit();
        }
        echo json_encode([
            'status' => 'error',
            'reason' => $reason,
            'message' => 'تعذر تحميل حالة الأجهزة الفرعية.',
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    echo json_encode([
        'status' => 'success',
        'data' => $r,
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

function pos_subscription_tier_from_settings(array $settings): string {
    return pos_subscription_tier_normalize($settings['subscription_tier'] ?? 'free');
}

/** One-time manufacturer pack ($50): up to this many companies after purchase (not per-slot). */
if (!defined('POS_MANUFACTURER_PACK_MAX')) {
    define('POS_MANUFACTURER_PACK_MAX', 100);
}

/** Purchased à-la-carte manufacturer pack (one-time $50 → up to POS_MANUFACTURER_PACK_MAX companies). */
function pos_manufacturer_slots_purchased(array $settings): int {
    if (!isset($settings['manufacturerSlotsPurchased'])) {
        return 0;
    }
    $n = (int)$settings['manufacturerSlotsPurchased'];
    return $n < 0 ? 0 : $n;
}

function pos_manufacturer_pack_unlocked(array $settings): bool {
    $tier = pos_subscription_tier_from_settings($settings);
    if ($tier === 'pro' || $tier === 'pro_plus') {
        return true;
    }
    $packMax = defined('POS_MANUFACTURER_PACK_MAX') ? (int)POS_MANUFACTURER_PACK_MAX : 100;
    if (pos_manufacturer_slots_purchased($settings) >= $packMax) {
        return true;
    }
    $unlocks = $settings['premiumFeatureUnlocks'] ?? null;
    if (is_array($unlocks) && !empty($unlocks['manufacturerSlot'])) {
        return true;
    }
    $pf = $settings['purchasedFeatures'] ?? null;
    if (is_array($pf) && !empty($pf['manufacturerSlot'])) {
        return true;
    }
    return false;
}

function pos_max_manufacturers_allowed($conn): int {
    if (!$conn || !function_exists('pos_load_app_settings_array')) {
        return 0;
    }
    $settings = pos_load_app_settings_array($conn);
    if (!is_array($settings)) {
        $settings = [];
    }
    $tier = pos_subscription_tier_from_settings($settings);
    if ($tier === 'pro' || $tier === 'pro_plus') {
        return 9999;
    }
    if (pos_manufacturer_pack_unlocked($settings)) {
        return defined('POS_MANUFACTURER_PACK_MAX') ? (int)POS_MANUFACTURER_PACK_MAX : 100;
    }
    return pos_manufacturer_slots_purchased($settings);
}

function pos_active_manufacturer_count($conn): int {
    if (!$conn) {
        return 0;
    }
    try {
        $res = $conn->query('SELECT COUNT(*) AS c FROM manufacturers WHERE (is_active IS NULL OR is_active = 1)');
        if ($res && ($row = $res->fetch_assoc())) {
            return max(0, (int)($row['c'] ?? 0));
        }
    } catch (Throwable $e) {
    }
    return 0;
}

function pos_manufacturer_slot_limit_message($conn): ?string {
    $max = pos_max_manufacturers_allowed($conn);
    if ($max >= 9999) {
        return null;
    }
    $cur = pos_active_manufacturer_count($conn);
    if ($cur < $max) {
        return null;
    }
    $settings = function_exists('pos_load_app_settings_array') ? pos_load_app_settings_array($conn) : [];
    if (!is_array($settings)) {
        $settings = [];
    }
    $price = function_exists('pos_premium_feature_price_usd') ? pos_premium_feature_price_usd('manufacturerSlot') : (defined('POS_PREMIUM_FEATURE_PRICE_USD') ? (int)POS_PREMIUM_FEATURE_PRICE_USD : 50);
    $packMax = defined('POS_MANUFACTURER_PACK_MAX') ? (int)POS_MANUFACTURER_PACK_MAX : 100;
    if (pos_manufacturer_pack_unlocked($settings) && $max >= $packMax) {
        return 'سنووری پاکێتا گەیشتی (' . $cur . '/' . $max . '). Pro بکڕە بۆ بێسنوور.';
    }
    return 'سنووری کۆمپانیا دروستکەر: ' . $cur . '/' . $max . '. یەکجار $' . $price . ' بکڕە (تا ' . $packMax . ' کۆمپانیا) یان Pro.';
}

/** Purchase batch/lot number (وەجبە) — only when user enabled enablePurchaseBatch in settings. */
function pos_can_use_purchase_batch($conn): bool {
    if (!$conn || !function_exists('pos_load_app_settings_array')) {
        return false;
    }
    $settings = pos_load_app_settings_array($conn);
    if (!is_array($settings)) {
        $settings = [];
    }
    if (empty($settings['enablePurchaseBatch'])) {
        return false;
    }
    $tier = pos_subscription_tier_from_settings($settings);
    if ($tier === 'pro' || $tier === 'pro_plus') {
        return true;
    }
    $pf = $settings['purchasedFeatures'] ?? null;
    if (is_array($pf) && !empty($pf['enablePurchaseBatch'])) {
        return true;
    }
    $pu = $settings['premiumFeatureUnlocks'] ?? null;
    if (is_array($pu) && !empty($pu['enablePurchaseBatch'])) {
        return true;
    }
    return false;
}

function pos_purchase_batch_limit_message(): string {
    $price = function_exists('pos_premium_feature_price_usd') ? pos_premium_feature_price_usd('enablePurchaseBatch') : 25;
    return 'ژمارا وەجبێ (batch) تایبەتمەندییەکی Pro یە — Pro بکڕە یان چالاک بکە ($' . $price . ').';
}

/** Laptop/phone specs on product form + labels — only when enableTechSpecs is on. */
function pos_can_use_tech_specs($conn): bool {
    if (!$conn || !function_exists('pos_load_app_settings_array')) {
        return false;
    }
    $settings = pos_load_app_settings_array($conn);
    if (!is_array($settings)) {
        $settings = [];
    }
    if (empty($settings['enableTechSpecs'])) {
        return false;
    }
    $tier = pos_subscription_tier_from_settings($settings);
    if ($tier === 'pro' || $tier === 'pro_plus') {
        return true;
    }
    $pf = $settings['purchasedFeatures'] ?? null;
    if (is_array($pf) && !empty($pf['enableTechSpecs'])) {
        return true;
    }
    $pu = $settings['premiumFeatureUnlocks'] ?? null;
    if (is_array($pu) && !empty($pu['enableTechSpecs'])) {
        return true;
    }
    return false;
}

/** After-sale WhatsApp follow-up — Pro/Pro Plus + toggle, or à-la-carte FEAT ($50). */
function pos_can_use_sale_followup($conn): bool {
    if (!$conn || !function_exists('pos_load_app_settings_array')) {
        return false;
    }
    $settings = pos_load_app_settings_array($conn);
    if (!is_array($settings)) {
        $settings = [];
    }
    if (empty($settings['enableSaleFollowup'])) {
        return false;
    }
    $tier = pos_subscription_tier_from_settings($settings);
    if ($tier === 'pro' || $tier === 'pro_plus') {
        return true;
    }
    $pf = $settings['purchasedFeatures'] ?? null;
    if (is_array($pf) && !empty($pf['enableSaleFollowup'])) {
        return true;
    }
    $pu = $settings['premiumFeatureUnlocks'] ?? null;
    if (is_array($pu) && !empty($pu['enableSaleFollowup'])) {
        return true;
    }
    return false;
}

function pos_max_staff_for_tier(string $tier): int {
    if ($tier === 'pro_plus') {
        return 99;
    }
    if ($tier === 'pro') {
        return 5;
    }
    return 3;
}

function pos_subscription_staff_cap_message(string $tier, int $maxStaff): string {
    if ($tier === 'pro') {
        return 'خطة Pro تسمح بـ 5 موظفين كحد أقصى. ترقية إلى Pro Plus لموظفين غير محدودين.';
    }
    return 'سنوورێ کارمەند: زیاتر لە ' . $maxStaff . ' هەژمار ڕێگەپێدراو نییە. بۆ زیادکردن پەیوەندی بە پشتیوانی بکە.';
}

/**
 * @return array{ok?:bool,status?:string,reason?:string,message?:string,network_mac?:string,network_type?:string}
 */
function pos_supabase_redeem_terminal_activation_code_remote(
    string $serial,
    string $deviceKey,
    string $code,
    string $networkMac,
    string $networkType,
    array $meta = []
): array {
    $serial = trim($serial);
    $deviceKey = pos_normalize_client_device_key(trim($deviceKey));
    $code = trim($code);
    $networkMac = pos_normalize_network_mac($networkMac);
    $networkType = strtolower(trim($networkType));
    if ($serial === '' || strlen($serial) < 4 || $deviceKey === '' || $code === '') {
        return ['ok' => false, 'reason' => 'invalid_input'];
    }
    $payload = [
        'p_serial' => $serial,
        'p_device_key' => $deviceKey,
        'p_code' => $code,
        'p_network_mac' => $networkMac !== '' ? $networkMac : null,
        'p_network_type' => in_array($networkType, ['wifi', 'lan', 'unknown'], true) ? $networkType : 'unknown',
        'p_meta' => array_merge($meta, ['device_role' => 'terminal']),
    ];
    $alt = [
        'serial' => $serial,
        'device_key' => $deviceKey,
        'code' => $code,
        'network_mac' => $networkMac !== '' ? $networkMac : null,
        'network_type' => $payload['p_network_type'],
        'meta' => $payload['p_meta'],
    ];
    return pos_supabase_rpc_post_json('redeem_terminal_activation_code', $payload, $alt);
}

function pos_api_get_terminal_network_identity_and_exit($conn): void {
    if (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: application/json; charset=utf-8');
    $serial = pos_ensure_license_serial($conn);
    $prefer = isset($_GET['network_type']) ? (string)$_GET['network_type'] : 'auto';
    $seed = pos_http_read_pos_client_seed();
    if (pos_client_is_remote_lan_pos_client() && $seed !== '') {
        $mac = pos_client_seed_as_network_mac($seed);
        echo json_encode([
            'status' => 'success',
            'license_serial' => $serial,
            'network_mac' => $mac,
            'network_type' => 'wifi',
            'client_seed' => true,
            'adapters' => [],
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $net = pos_pick_network_identity($prefer);
    echo json_encode([
        'status' => 'success',
        'license_serial' => $serial,
        'network_mac' => $net['mac'],
        'network_type' => $net['type'],
        'adapters' => $net['adapters'],
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

function pos_api_get_fragi_client_device_key_and_exit($conn): void {
    if (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: application/json; charset=utf-8');
    $serial = pos_ensure_license_serial($conn);
    if ($serial === '' || strlen(trim($serial)) < 4) {
        echo json_encode(['status' => 'error', 'message' => 'نەتوانرا ژمارەی دامەزراندن دابنرێت.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $seed = pos_http_read_pos_client_seed();
    if ($seed === '') {
        echo json_encode(['status' => 'error', 'message' => 'client_seed required'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $key = pos_derive_terminal_device_key_from_client_seed($serial, $seed);
    if ($key === '') {
        echo json_encode(['status' => 'error', 'message' => 'Could not derive device key.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    echo json_encode([
        'status' => 'success',
        'device_key' => $key,
        'network_mac' => pos_client_seed_as_network_mac($seed),
        'network_type' => 'wifi',
        'license_serial' => $serial,
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

function pos_api_redeem_terminal_activation_code_and_exit($conn): void {
    if (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: application/json; charset=utf-8');
    if (!pos_client_is_terminal_attempt()) {
        echo json_encode([
            'status' => 'error',
            'reason' => 'terminal_context_required',
            'message' => 'Terminal activation codes can only be redeemed on a sub-device connection (LAN/Wi-Fi terminal mode).',
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $serial = pos_ensure_license_serial($conn);
    if ($serial === '' || strlen(trim($serial)) < 4) {
        echo json_encode(['status' => 'error', 'message' => 'نەتوانرا ژمارەی دامەزراندن دابنرێت.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    if (!defined('POS_SUPABASE_ANON_KEY') || POS_SUPABASE_ANON_KEY === '') {
        echo json_encode(['status' => 'error', 'message' => 'ڕێکخستنی Supabase تەواو نییە.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $rawKey = isset($_POST['device_key']) ? (string)$_POST['device_key'] : '';
    if ($rawKey === '') {
        $rawKey = pos_http_read_pos_device_key();
    }
    $code = trim((string)($_POST['code'] ?? ''));
    if ($code === '') {
        echo json_encode(['status' => 'error', 'message' => 'Terminal activation code is required.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $devNorm = pos_resolve_effective_device_key($conn, $rawKey);
    if ($devNorm === '') {
        echo json_encode(['status' => 'error', 'message' => 'مفتاح الجهاز غير صالح. أعد تحميل الصفحة.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $postedMac = pos_normalize_network_mac((string)($_POST['network_mac'] ?? ''));
    $postedType = strtolower(trim((string)($_POST['network_type'] ?? '')));
    $clientSeed = pos_http_read_pos_client_seed();
    $net = pos_pick_network_identity($postedType !== '' ? $postedType : 'auto');
    $mac = $postedMac !== '' ? $postedMac : $net['mac'];
    $type = in_array($postedType, ['wifi', 'lan', 'unknown'], true) ? $postedType : $net['type'];
    if ($mac === '' && $clientSeed !== '') {
        $mac = pos_client_seed_as_network_mac($clientSeed);
        $type = 'wifi';
    }
    if ($mac === '') {
        echo json_encode([
            'status' => 'error',
            'reason' => 'network_mac_required',
            'message' => 'Could not detect Wi-Fi/LAN MAC on this device. Connect via local network and retry.',
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $regMeta = [
        'user_agent' => substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 2048),
        'platform' => isset($_POST['platform']) ? substr(trim((string)$_POST['platform']), 0, 256) : '',
        'hint' => 'terminal_code_redeem',
        'request_ip' => pos_client_request_ip_for_pos_device(),
        'device_role' => 'terminal',
        'network_mac' => $mac,
        'network_type' => $type,
    ];
    pos_supabase_register_device_remote($serial, $devNorm, $regMeta);

    $meta = [
        'user_agent' => $regMeta['user_agent'],
        'platform' => $regMeta['platform'],
        'hint' => $regMeta['hint'],
        'request_ip' => $regMeta['request_ip'],
        'device_role' => 'terminal',
    ];
    $r = pos_supabase_redeem_terminal_activation_code_remote($serial, $devNorm, $code, $mac, $type, $meta);
    if (empty($r['ok'])) {
        $reason = isset($r['reason']) ? (string)$r['reason'] : 'error';
        if ($reason === 'http') {
            $http = isset($r['http_code']) ? (int)$r['http_code'] : 0;
            $detail = isset($r['detail']) ? (string)$r['detail'] : '';
            $rpcMissing = ($http === 404) || stripos($detail, 'redeem_terminal_activation_code') !== false;
            echo json_encode([
                'status' => 'error',
                'reason' => 'http',
                'message' => $rpcMissing
                    ? 'Supabase RPC missing — run sql/supabase_terminal_activation_codes.sql in SQL Editor.'
                    : ('Supabase error (HTTP ' . $http . ').'),
            ], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $reasonMsgs = [
            'invalid_input' => 'Invalid terminal code or device key.',
            'code_not_found' => 'کۆدی سیکوریتی نەدۆزرایەوە — لە لاپتۆپی سەرەکی ڕێکخستنەکان → خانەی سیکوریتی کۆد دروست بکە.',
            'code_revoked' => 'This terminal code was revoked.',
            'code_already_used' => 'This terminal code was already used on another device.',
            'serial_mismatch' => 'Code does not match this store installation serial.',
            'network_mac_required' => 'Wi-Fi/LAN MAC is required to bind this terminal.',
            'network_mac_mismatch' => 'This code is bound to a different network adapter MAC.',
            'network_type_mismatch' => 'Network type mismatch (Wi-Fi vs LAN).',
            'license_missing' => 'Register the client in admin Step ③ first.',
            'person_name_required' => 'Owner name required before terminal activation.',
            'license_not_active' => 'Store license is not active.',
            'pro_required' => pos_terminal_pro_required_message(),
            'pro_plus_required' => pos_terminal_pro_required_message(),
            'terminal_slot_limit' => isset($r['message']) ? (string)$r['message'] : 'خانەی سیکوریتی نییە — بۆ لاپتۆپ/موبایلی دووەم پێشتر خانەیەکی تر بکڕە ($99).',
            'mac_bound_to_other_device' => isset($r['message']) ? (string)$r['message'] : 'ئەم ئامێرە (MAC) پێشتر لە خانەیەکی تر چالاک کراوە — ١ خانە = ١ لاپتۆپ یان ١ موبایل.',
            'primary_device_forbidden' => 'Terminal codes cannot activate a primary/master system.',
            'terminal_code_primary_forbidden' => 'Terminal codes only authorize sub-devices on LAN/Wi-Fi.',
            'device_archived' => 'Device is archived.',
            'device_blocked' => 'Device is blocked by admin.',
        ];
        echo json_encode([
            'status' => 'error',
            'reason' => $reason,
            'message' => $reasonMsgs[$reason] ?? (isset($r['message']) ? (string)$r['message'] : 'Terminal activation failed.'),
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    pos_device_note_verified_online($conn, $serial, $devNorm);
    pos_supabase_log_admin_event_remote($serial, $devNorm, 'terminal_code_redeemed', 'Terminal code accepted · ' . $mac);
    $chk = pos_supabase_check_device_remote($serial, $devNorm);
    if (empty($chk['ok'])) {
        usleep(150000);
        $chk = pos_supabase_check_device_remote($serial, $devNorm);
    }
    echo json_encode([
        'status' => 'success',
        'device_status' => isset($r['status']) ? (string)$r['status'] : 'approved',
        'device_role' => 'terminal',
        'network_mac' => $mac,
        'network_type' => $type,
        'message' => 'فرعێ (لاپتۆپی فرعی) ل سەر ئەم ئامێرە دروستکرا — ١ خانەی سیکوریتی ($99) = ١ ئامێر.',
        'terminal_branch_on_device' => true,
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

/**
 * @return array{ok?:bool,slot_id?:string,slot_number?:int,terminal_slots_purchased?:int,reason?:string,message?:string}
 */
function pos_supabase_redeem_terminal_slot_purchase_code_remote(string $serial, string $code, ?int $slotNumber = null): array {
    $serial = trim($serial);
    $code = trim($code);
    if ($serial === '' || strlen($serial) < 4 || $code === '') {
        return ['ok' => false, 'reason' => 'invalid_input'];
    }
    $payload = [
        'p_serial' => $serial,
        'p_code' => $code,
        'p_slot_number' => $slotNumber,
    ];
    $alt = [
        'serial' => $serial,
        'code' => $code,
        'slot_number' => $slotNumber,
    ];
    return pos_supabase_rpc_post_json('redeem_terminal_slot_purchase_code', $payload, $alt);
}

/**
 * @return array{ok?:bool,slot_id?:string,slot_number?:int,status?:string,reason?:string}
 */
function pos_supabase_release_terminal_license_slot_remote(string $serial, string $slotId, string $callerDeviceKey = ''): array {
    $serial = trim($serial);
    $slotId = trim($slotId);
    if ($serial === '' || $slotId === '') {
        return ['ok' => false, 'reason' => 'invalid_input'];
    }
    $callerNorm = pos_normalize_client_device_key($callerDeviceKey);
    $payload = [
        'p_serial' => $serial,
        'p_slot_id' => $slotId,
        'p_caller_device_key' => $callerNorm !== '' ? $callerNorm : null,
    ];
    $alt = [
        'serial' => $serial,
        'slot_id' => $slotId,
        'caller_device_key' => $callerNorm !== '' ? $callerNorm : null,
    ];
    return pos_supabase_rpc_post_json('release_terminal_license_slot', $payload, $alt);
}

function pos_api_redeem_terminal_slot_purchase_code_and_exit($conn): void {
    if (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: application/json; charset=utf-8');
    if (pos_client_is_terminal_attempt()) {
        echo json_encode([
            'status' => 'error',
            'reason' => 'primary_only',
            'message' => 'Slot purchase codes must be redeemed on the main device in Settings → Terminal Licenses.',
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $serial = pos_ensure_license_serial($conn);
    if ($serial === '' || strlen(trim($serial)) < 4) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid installation serial.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    if (!defined('POS_SUPABASE_ANON_KEY') || POS_SUPABASE_ANON_KEY === '') {
        echo json_encode(['status' => 'error', 'message' => 'Supabase not configured.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $code = trim((string)($_POST['code'] ?? ''));
    if ($code === '') {
        echo json_encode(['status' => 'error', 'message' => 'Activation code is required.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $slotNumber = isset($_POST['slot_number']) ? (int)$_POST['slot_number'] : null;
    if ($slotNumber !== null && $slotNumber <= 0) {
        $slotNumber = null;
    }
    $r = pos_supabase_redeem_terminal_slot_purchase_code_remote($serial, $code, $slotNumber);
    if (empty($r['ok'])) {
        $reason = isset($r['reason']) ? (string)$r['reason'] : 'error';
        if ($reason === 'http') {
            $http = isset($r['http_code']) ? (int)$r['http_code'] : 0;
            $detail = isset($r['detail']) ? (string)$r['detail'] : '';
            $rpcMissing = ($http === 404) || stripos($detail, 'redeem_terminal_slot_purchase_code') !== false;
            echo json_encode([
                'status' => 'error',
                'message' => $rpcMissing
                    ? 'Run sql/supabase_terminal_slot_management.sql in Supabase SQL Editor.'
                    : ('Supabase error (HTTP ' . $http . ').'),
            ], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $msgs = [
            'code_not_found' => 'کۆدی کڕینی خانە نەدۆزرایەوە.',
            'code_revoked' => 'This code was revoked.',
            'code_already_used' => 'This code was already used.',
            'serial_mismatch' => 'Code does not match this store.',
            'pro_required' => pos_terminal_pro_required_message(),
            'pro_plus_required' => pos_terminal_pro_required_message(),
            'person_name_required' => 'Owner name required in admin registration.',
            'license_not_active' => 'License is not active.',
            'slot_already_purchased' => 'This slot is already unlocked.',
        ];
        echo json_encode([
            'status' => 'error',
            'reason' => $reason,
            'message' => $msgs[$reason] ?? (isset($r['message']) ? (string)$r['message'] : 'Could not unlock slot.'),
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    echo json_encode([
        'status' => 'success',
        'message' => 'خانەی سیکوریتی کراوە — کۆدەکە لە خوارەوە بۆ لاپتۆپی فرعی بنووسە.',
        'slot_id' => isset($r['slot_id']) ? (string)$r['slot_id'] : '',
        'slot_number' => isset($r['slot_number']) ? (int)$r['slot_number'] : 0,
        'security_code' => isset($r['security_code']) ? (string)$r['security_code'] : '',
        'terminal_slots_purchased' => isset($r['terminal_slots_purchased']) ? (int)$r['terminal_slots_purchased'] : 0,
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

/**
 * @return array{ok?:bool,code?:string,slot_id?:string,slot_number?:int,reason?:string,message?:string}
 */
function pos_supabase_generate_slot_terminal_security_code_remote(
    string $serial,
    string $slotId,
    string $callerDeviceKey = ''
): array {
    $serial = trim($serial);
    $slotId = trim($slotId);
    if ($serial === '' || strlen($serial) < 4 || $slotId === '') {
        return ['ok' => false, 'reason' => 'invalid_input'];
    }
    $callerNorm = pos_normalize_client_device_key($callerDeviceKey);
    $payload = [
        'p_serial' => $serial,
        'p_slot_id' => $slotId,
        'p_caller_device_key' => $callerNorm !== '' ? $callerNorm : null,
    ];
    $alt = [
        'serial' => $serial,
        'slot_id' => $slotId,
        'caller_device_key' => $callerNorm !== '' ? $callerNorm : null,
    ];
    return pos_supabase_rpc_post_json('generate_slot_terminal_security_code', $payload, $alt);
}

function pos_api_generate_slot_terminal_security_code_and_exit($conn): void {
    if (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: application/json; charset=utf-8');
    if (pos_client_is_terminal_attempt()) {
        echo json_encode([
            'status' => 'error',
            'reason' => 'primary_only',
            'message' => 'تەنها لە لاپتۆپی سەرەکی دەتوانیت کۆدی خانە دروست بکەیت.',
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $serial = pos_ensure_license_serial($conn);
    if ($serial === '' || strlen(trim($serial)) < 4) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid installation serial.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    if (!defined('POS_SUPABASE_ANON_KEY') || POS_SUPABASE_ANON_KEY === '') {
        echo json_encode(['status' => 'error', 'message' => 'Supabase not configured.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $slotId = trim((string)($_POST['slot_id'] ?? ''));
    if ($slotId === '') {
        echo json_encode(['status' => 'error', 'message' => 'Slot id is required.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $rawKey = pos_http_read_pos_device_key();
    $callerKey = pos_resolve_effective_device_key($conn, $rawKey);
    $r = pos_supabase_generate_slot_terminal_security_code_remote($serial, $slotId, $callerKey);
    if (empty($r['ok'])) {
        $reason = isset($r['reason']) ? (string)$r['reason'] : 'error';
        if ($reason === 'http') {
            $http = isset($r['http_code']) ? (int)$r['http_code'] : 0;
            $detail = isset($r['detail']) ? (string)$r['detail'] : '';
            $rpcMissing = ($http === 404) || stripos($detail, 'generate_slot_terminal_security_code') !== false;
            echo json_encode([
                'status' => 'error',
                'message' => $rpcMissing
                    ? 'Run sql/supabase_terminal_slot_self_service.sql in Supabase SQL Editor.'
                    : ('Supabase error (HTTP ' . $http . ').'),
            ], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $msgs = [
            'invalid_input' => 'Invalid request.',
            'slot_not_found' => 'Security slot not found.',
            'slot_not_empty' => isset($r['message']) ? (string)$r['message'] : 'This slot is already in use.',
            'primary_only' => isset($r['message']) ? (string)$r['message'] : 'Only the primary laptop can generate slot codes.',
            'pro_required' => pos_terminal_pro_required_message(),
            'pro_plus_required' => pos_terminal_pro_required_message(),
            'license_not_active' => 'License is not active.',
            'generate_failed' => 'Could not generate security code — try again.',
        ];
        echo json_encode([
            'status' => 'error',
            'reason' => $reason,
            'message' => $msgs[$reason] ?? (isset($r['message']) ? (string)$r['message'] : 'Could not generate code.'),
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    echo json_encode([
        'status' => 'success',
        'message' => 'کۆدی سیکوریتی خانە ئامادەیە — لە لاپتۆپ/موبایلی فرعی لە ڕێکخستنەکان بنووسە.',
        'security_code' => isset($r['code']) ? (string)$r['code'] : '',
        'slot_id' => isset($r['slot_id']) ? (string)$r['slot_id'] : $slotId,
        'slot_number' => isset($r['slot_number']) ? (int)$r['slot_number'] : 0,
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

function pos_api_release_terminal_license_slot_and_exit($conn): void {
    if (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: application/json; charset=utf-8');
    if (pos_client_is_terminal_attempt()) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Slot transfer must be done on the main device.',
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $serial = pos_ensure_license_serial($conn);
    $slotId = trim((string)($_POST['slot_id'] ?? ''));
    if ($serial === '' || $slotId === '') {
        echo json_encode(['status' => 'error', 'message' => 'Invalid request.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $rawKey = pos_http_read_pos_device_key();
    $callerKey = pos_resolve_effective_device_key($conn, $rawKey);
    $r = pos_supabase_release_terminal_license_slot_remote($serial, $slotId, $callerKey);
    if (empty($r['ok'])) {
        $reason = isset($r['reason']) ? (string)$r['reason'] : 'error';
        $msgs = [
            'slot_not_found' => 'Slot not found.',
            'primary_only' => 'Only the primary device can release or transfer a slot.',
        ];
        echo json_encode([
            'status' => 'error',
            'reason' => $reason,
            'message' => $msgs[$reason] ?? 'Could not release slot.',
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    echo json_encode([
        'status' => 'success',
        'message' => 'Device removed from slot — seat is ready for a new terminal.',
        'slot_id' => isset($r['slot_id']) ? (string)$r['slot_id'] : $slotId,
        'slot_number' => isset($r['slot_number']) ? (int)$r['slot_number'] : 0,
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

