<?php
// POST: CSV import, multi-warehouse
    // --- Import products from CSV (mapping + optional currency conversion) ---
    if ($act == 'import_products') {
        
        header('Content-Type: application/json; charset=utf-8');
        if (empty($_FILES['file']['tmp_name']) || !is_uploaded_file($_FILES['file']['tmp_name'])) {
            echo json_encode(['status' => 'error', 'message' => 'چ فایل نەهاتینە بارکرن']);
            exit();
        }
        $mappingJson = isset($_POST['mapping']) ? $_POST['mapping'] : '{}';
        $mapping = json_decode($mappingJson, true);
        if (!is_array($mapping)) $mapping = [];
        $firstRowHeader = isset($_POST['first_row_header']) && $_POST['first_row_header'] === '1';
        $sourceCurrency = (isset($_POST['source_currency']) && in_array($_POST['source_currency'], ['IQD', 'USD'])) ? $_POST['source_currency'] : 'IQD';
        $updateExisting = isset($_POST['update_existing']) && $_POST['update_existing'] === '1';

        $settings = [];
        $sres = $conn->query("SELECT setting_value FROM settings WHERE setting_key = 'app_settings'");
        if ($sres && $row = $sres->fetch_assoc()) {
            $dec = json_decode($row['setting_value'], true);
            if ($dec) $settings = $dec;
        }
        $systemCurrency = pos_settings_currency_mode_from_array($settings);
        $usdRateRaw = isset($settings['usdRate']) ? (float)$settings['usdRate'] : 150000;
        if ($usdRateRaw <= 0) $usdRateRaw = 150000;
        $usdRate = $usdRateRaw >= 100 ? $usdRateRaw / 100 : $usdRateRaw;

        $path = $_FILES['file']['tmp_name'];
        $content = file_get_contents($path);
        if ($content === false) {
            echo json_encode(['status' => 'error', 'message' => 'نەشێت فایلی بخوێنیت']);
            exit();
        }
        $content = preg_replace('/^\xEF\xBB\xBF/', '', $content);
        $lines = preg_split('/\r\n|\r|\n/', $content);
        if (empty($lines)) {
            echo json_encode(['status' => 'error', 'message' => 'فایل یێ ڤالایە']);
            exit();
        }
        $delimiter = ',';
        if (strpos($lines[0], ';') !== false && substr_count($lines[0], ';') >= substr_count($lines[0], ',')) $delimiter = ';';
        $rows = [];
        foreach ($lines as $line) {
            $rows[] = str_getcsv($line, $delimiter);
        }
        if ($firstRowHeader && count($rows) > 0) array_shift($rows);

        $imported = 0; $updated = 0; $skipped = 0; $errors = [];
        $stmtIns = $conn->prepare("INSERT INTO products (name, barcode, price, cost, qty, category, supplier, trackStock, unitType, qty_mode, itemsPerCarton, takeawayPrice, expiry, wholesaleQty, wholesalePrice, item_type, pieces_per_pack, packs_per_carton, barcode_pack, barcode_carton, price_pack, price_carton, cost_pack, cost_carton, unit_show_pack, unit_show_carton) VALUES (?, ?, ?, ?, ?, ?, ?, 1, 'carton', ?, 1, 0, '', 0, 0, 'constant', 1, 1, '', '', 0, 0, 0, 0, 1, 1)");
        if (!$stmtIns) {
            echo json_encode(['status' => 'error', 'message' => 'DB prepare failed: ' . $conn->error]);
            exit();
        }
        if (!$stmtIns) {
            echo json_encode(['status' => 'error', 'message' => 'DB prepare failed: ' . $conn->error]);
            exit();
        }
        $stmtUpd = $conn->prepare("UPDATE products SET name=?, price=?, cost=?, qty=?, category=?, supplier=?, qty_mode=? WHERE barcode=? AND barcode!=''");
        $stmtDup = $conn->prepare("SELECT id FROM products WHERE barcode=? AND barcode!='' LIMIT 1");

        foreach ($rows as $rowIndex => $row) {
            $lineNum = $rowIndex + ($firstRowHeader ? 2 : 1);
            $get = function($key) use ($row, $mapping) {
                $idx = isset($mapping[$key]) ? (int)$mapping[$key] : -1;
                if ($idx < 0 || $idx >= count($row)) return '';
                return trim(isset($row[$idx]) ? $row[$idx] : '');
            };
            $name = $get('name');
            if ($name === '') {
                $skipped++;
                continue;
            }
            $barcode = $get('barcode');
            $price = $get('price'); $cost = $get('cost');
            $price = preg_replace('/[^\d.-]/', '', $price);
            $cost = preg_replace('/[^\d.-]/', '', $cost);
            $price = $price === '' ? 0 : (float)$price;
            $cost = $cost === '' ? 0 : (float)$cost;
            $enteredPrice = $price;
            $enteredCost = $cost;
            if ($sourceCurrency === 'USD' && $systemCurrency === 'IQD') {
                $price = $price * $usdRate;
                $cost = $cost * $usdRate;
            } elseif ($sourceCurrency === 'IQD' && $systemCurrency === 'USD') {
                $price = $usdRate > 0 ? $price / $usdRate : $price;
                $cost = $usdRate > 0 ? $cost / $usdRate : $cost;
            }
            $price = roundMoney($price);
            $cost = roundMoney($cost);
            $qty = (float)preg_replace('/[^\d.]/', '', $get('qty'));
            if ($qty < 0) $qty = 0;
            $category = $get('category');
            $supplier = $get('supplier');

            if ($updateExisting && $barcode !== '') {
                $stmtDup->bind_param("s", $barcode);
                $stmtDup->execute();
                $res = $stmtDup->get_result();
                if ($res && $res->num_rows > 0) {
            $dupRow = $res->fetch_assoc();
            $updId = $dupRow ? (int)($dupRow['id'] ?? 0) : 0;
            $qtyModeImport = (abs($qty - floor($qty)) > 0.000001) ? 'kilo' : 'piece';
            $stmtUpd->bind_param("sddissss", $name, $price, $cost, $qty, $category, $supplier, $qtyModeImport, $barcode);
                    if ($stmtUpd->execute()) {
                        $updated++;
                        if ($updId > 0 && function_exists('pos_product_write_base_fields')) {
                            if ($systemCurrency === 'USD') {
                                $bp = ($sourceCurrency === 'USD') ? $enteredPrice : (($usdRate > 0) ? ($enteredPrice / $usdRate) : 0);
                                $bc = ($sourceCurrency === 'USD') ? $enteredCost : (($usdRate > 0) ? ($enteredCost / $usdRate) : 0);
                            } else {
                                $bp = ($sourceCurrency === 'USD') ? ($enteredPrice * $usdRate) : $enteredPrice;
                                $bc = ($sourceCurrency === 'USD') ? ($enteredCost * $usdRate) : $enteredCost;
                            }
                            pos_product_write_base_fields($conn, $updId, $systemCurrency, $bp, $bc);
                        }
                    }
                    else $errors[] = ['row' => $lineNum, 'message' => 'Update failed'];
                    continue;
                }
            }

            $qtyModeImport = (abs($qty - floor($qty)) > 0.000001) ? 'kilo' : 'piece';
            $stmtIns->bind_param("ssdddsss", $name, $barcode, $price, $cost, $qty, $category, $supplier, $qtyModeImport);
            if ($stmtIns->execute()) {
                $imported++;
                $newImportId = (int)$conn->insert_id;
                if ($newImportId > 0 && function_exists('pos_product_write_base_fields')) {
                    if ($systemCurrency === 'USD') {
                        $bp = ($sourceCurrency === 'USD') ? $enteredPrice : (($usdRate > 0) ? ($enteredPrice / $usdRate) : 0);
                        $bc = ($sourceCurrency === 'USD') ? $enteredCost : (($usdRate > 0) ? ($enteredCost / $usdRate) : 0);
                    } else {
                        $bp = ($sourceCurrency === 'USD') ? ($enteredPrice * $usdRate) : $enteredPrice;
                        $bc = ($sourceCurrency === 'USD') ? ($enteredCost * $usdRate) : $enteredCost;
                    }
                    pos_product_write_base_fields($conn, $newImportId, $systemCurrency, $bp, $bc);
                }
            }
            else $errors[] = ['row' => $lineNum, 'message' => $stmtIns->error ?: 'Insert failed'];
        }

        touchLastUpdate($conn);
        echo json_encode([
            'status' => 'ok',
            'imported' => $imported,
            'updated' => $updated,
            'skipped' => $skipped,
            'errors' => array_slice($errors, 0, 50)
        ]);
        exit();
    }

    // --- Multi-warehouse: save location ---
    if ($act === 'save_warehouse') {
        if (!pos_multi_warehouse_pro_enabled($conn)) {
            echo json_encode(['status' => 'error', 'message' => 'کۆگای فرە تەنها بۆ Pro — لە ڕێکخستن چالاک بکە']); exit();
        }
        if (!pos_session_can_use_multi_warehouse($conn)) {
            pos_json_perm_denied(); exit();
        }
        $id = (int)($_POST['id'] ?? 0);
        $name = trim((string)($_POST['name'] ?? ''));
        $code = trim((string)($_POST['code'] ?? ''));
        $address = trim((string)($_POST['address'] ?? ''));
        $sortOrder = (int)($_POST['sort_order'] ?? 0);
        $makeDefault = !empty($_POST['is_default']);
        if ($name === '') {
            echo json_encode(['status' => 'error', 'message' => 'ناوی کۆگە پێویستە']); exit();
        }
        if ($code === '') {
            $code = 'WH' . ($id > 0 ? $id : time());
        }
        $conn->begin_transaction();
        try {
            if ($id > 0) {
                $st = $conn->prepare("UPDATE warehouses SET code = ?, name = ?, address = ?, sort_order = ? WHERE id = ?");
                $st->bind_param('sssii', $code, $name, $address, $sortOrder, $id);
                $st->execute();
            } else {
                $st = $conn->prepare("INSERT INTO warehouses (code, name, address, is_default, is_active, sort_order) VALUES (?, ?, ?, 0, 1, ?)");
                $st->bind_param('sssi', $code, $name, $address, $sortOrder);
                $st->execute();
                $id = (int)$conn->insert_id;
            }
            if ($makeDefault && $id > 0) {
                $conn->query("UPDATE warehouses SET is_default = 0");
                $stD = $conn->prepare("UPDATE warehouses SET is_default = 1 WHERE id = ?");
                $stD->bind_param('i', $id);
                $stD->execute();
                pos_db_set_setting_value($conn, 'default_warehouse_id', (string)$id);
            }
            $pinRaw = trim((string)($_POST['pin'] ?? ''));
            if ($id > 0 && $pinRaw !== '') {
                if (!preg_match('/^\d{4,8}$/', $pinRaw)) {
                    throw new Exception('پاسۆرد: ٤ تا ٨ ژمارە');
                }
                if (function_exists('pos_ensure_warehouse_pin_column')) pos_ensure_warehouse_pin_column($conn);
                $hash = password_hash($pinRaw, PASSWORD_DEFAULT);
                $stPin = $conn->prepare("UPDATE warehouses SET pin_hash = ? WHERE id = ?");
                $stPin->bind_param('si', $hash, $id);
                $stPin->execute();
            }
            $conn->commit();
            touchLastUpdate($conn);
            echo json_encode(['status' => 'success', 'id' => $id]); exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]); exit();
        }
    }

    if ($act === 'delete_warehouse') {
        if (!pos_multi_warehouse_pro_enabled($conn)) {
            echo json_encode(['status' => 'error', 'message' => 'کۆگای فرە تەنها بۆ Pro']); exit();
        }
        if (!pos_session_can_use_multi_warehouse($conn)) {
            pos_json_perm_denied(); exit();
        }
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) { echo json_encode(['status' => 'error', 'message' => 'Invalid id']); exit(); }
        $st = $conn->prepare("SELECT is_default FROM warehouses WHERE id = ? LIMIT 1");
        $st->bind_param('i', $id);
        $st->execute();
        $row = $st->get_result()->fetch_assoc();
        if (!$row) { echo json_encode(['status' => 'error', 'message' => 'کۆگە نەدۆزرایەوە']); exit(); }
        if ((int)($row['is_default'] ?? 0) === 1) {
            echo json_encode(['status' => 'error', 'message' => 'ناتوانیت کۆگەی سەرەکی بسڕیتەوە']); exit();
        }
        $stQty = $conn->prepare("SELECT COALESCE(SUM(qty),0) AS t FROM warehouse_stock WHERE warehouse_id = ?");
        $stQty->bind_param('i', $id);
        $stQty->execute();
        $qtyRow = $stQty->get_result()->fetch_assoc();
        if ((float)($qtyRow['t'] ?? 0) > 0.0001) {
            echo json_encode(['status' => 'error', 'message' => 'کۆگە هێشتا کاڵای تێدایە — سەرەتا گواستنەوە یان خالی بکەوە']); exit();
        }
        $stDel = $conn->prepare("UPDATE warehouses SET is_active = 0 WHERE id = ?");
        $stDel->bind_param('i', $id);
        $stDel->execute();
        touchLastUpdate($conn);
        echo json_encode(['status' => 'success']); exit();
    }

    if ($act === 'save_stock_transfer') {
        if (!pos_multi_warehouse_pro_enabled($conn)) {
            echo json_encode(['status' => 'error', 'message' => 'کۆگای فرە تەنها بۆ Pro']); exit();
        }
        if (!pos_session_can_use_multi_warehouse($conn)) {
            pos_json_perm_denied(); exit();
        }
        $fromWh = pos_resolve_warehouse_id($conn, $_POST['from_warehouse_id'] ?? 0);
        $toWh = pos_resolve_warehouse_id($conn, $_POST['to_warehouse_id'] ?? 0);
        $user = trim((string)($_POST['user'] ?? (isset($_SESSION['user']) ? $_SESSION['user'] : 'System')));
        $note = trim((string)($_POST['note'] ?? ''));
        $items = json_decode($_POST['items'] ?? '[]', true);
        if ($fromWh <= 0 || $toWh <= 0 || $fromWh === $toWh) {
            echo json_encode(['status' => 'error', 'message' => 'کۆگەی سەرچاوە و مەبەست جیا بن']); exit();
        }
        if (!is_array($items) || empty($items)) {
            echo json_encode(['status' => 'error', 'message' => 'هیچ ئایتمێک هەڵنەبژێردراوە']); exit();
        }
        $date = date('Y-m-d H:i:s');
        $totalQty = 0.0;
        $linesToInsert = [];
        if (function_exists('pos_heal_warehouse_qty_gap_from_products')) {
            pos_heal_warehouse_qty_gap_from_products($conn);
        }
        $conn->begin_transaction();
        try {
            foreach ($items as $line) {
                $pid = (int)($line['product_id'] ?? $line['id'] ?? 0);
                $qty = roundMoney((float)($line['qty'] ?? 0));
                if ($pid <= 0 || $qty <= 0) continue;
                $stAvail = $conn->prepare("SELECT ws.qty, p.cost, p.barcode, p.trackStock, p.qty AS product_qty FROM warehouse_stock ws JOIN products p ON p.id = ws.product_id WHERE ws.warehouse_id = ? AND ws.product_id = ? LIMIT 1");
                if ($stAvail) {
                    $stAvail->bind_param('ii', $fromWh, $pid);
                    $stAvail->execute();
                    $availRow = $stAvail->get_result()->fetch_assoc();
                } else {
                    $availRow = null;
                }
                if (!$availRow) {
                    $stP = $conn->prepare("SELECT cost, barcode, trackStock, qty FROM products WHERE id = ? LIMIT 1");
                    if ($stP) {
                        $stP->bind_param('i', $pid);
                        $stP->execute();
                        $pr = $stP->get_result()->fetch_assoc();
                        if ($pr) {
                            $availRow = $pr;
                            $availRow['qty'] = 0;
                            $availRow['product_qty'] = (float)($pr['qty'] ?? 0);
                        }
                    }
                }
                $avail = $availRow ? (float)($availRow['qty'] ?? 0) : 0;
                if ($avail <= 0.0001 && $availRow && (float)($availRow['product_qty'] ?? 0) > 0.0001) {
                    if (function_exists('pos_heal_warehouse_qty_gap_from_products')) {
                        pos_heal_warehouse_qty_gap_from_products($conn);
                    }
                    pos_ensure_warehouse_stock_row($conn, $fromWh, $pid);
                    $stAvail2 = $conn->prepare("SELECT qty FROM warehouse_stock WHERE warehouse_id = ? AND product_id = ? LIMIT 1");
                    if ($stAvail2) {
                        $stAvail2->bind_param('ii', $fromWh, $pid);
                        $stAvail2->execute();
                        $row2 = $stAvail2->get_result()->fetch_assoc();
                        if ($row2) $avail = (float)($row2['qty'] ?? 0);
                    }
                }
                if ($availRow && (int)($availRow['trackStock'] ?? 1) === 0) continue;
                if ($qty > $avail + 0.0001) {
                    throw new Exception("ژمارە لە کۆگەی سەرچاوە زیاترە (product #$pid)");
                }
                $cost = $availRow ? (float)($availRow['cost'] ?? 0) : 0;
                $barcode = $availRow ? trim((string)($availRow['barcode'] ?? '')) : '';
                pos_delta_warehouse_stock($conn, $fromWh, $pid, -$qty);
                pos_delta_warehouse_stock($conn, $toWh, $pid, $qty);
                $totalQty = roundMoney($totalQty + $qty);
                $linesToInsert[] = ['pid' => $pid, 'qty' => $qty, 'cost' => $cost, 'barcode' => $barcode];
            }
            if (empty($linesToInsert)) throw new Exception('هیچ ئایتمێکی دروست نەبوو');
            $stH = $conn->prepare("INSERT INTO stock_transfers (from_warehouse_id, to_warehouse_id, status, transaction_id, total_qty, date, user, note) VALUES (?, ?, 'completed', '0', ?, ?, ?, ?)");
            $stH->bind_param('iidsss', $fromWh, $toWh, $totalQty, $date, $user, $note);
            $stH->execute();
            $transferId = (int)$conn->insert_id;
            $txnId = pos_format_stock_transfer_number($transferId);
            $stUp = $conn->prepare("UPDATE stock_transfers SET transaction_id = ? WHERE id = ? LIMIT 1");
            $stUp->bind_param('si', $txnId, $transferId);
            $stUp->execute();
            $stL = $conn->prepare("INSERT INTO stock_transfer_lines (transfer_id, product_id, qty, unit_cost) VALUES (?, ?, ?, ?)");
            foreach ($linesToInsert as $ln) {
                $stL->bind_param('iidd', $transferId, $ln['pid'], $ln['qty'], $ln['cost']);
                $stL->execute();
                $val = roundMoney($ln['cost'] * $ln['qty']);
                insertStockMovement($conn, $ln['pid'], $ln['barcode'], 'transfer_out', -$ln['qty'], $ln['cost'], $val, 'transfer', $transferId, $date, $user, $note ?: 'گواستنەوە', $fromWh, $toWh);
                insertStockMovement($conn, $ln['pid'], $ln['barcode'], 'transfer_in', $ln['qty'], $ln['cost'], $val, 'transfer', $transferId, $date, $user, $note ?: 'گواستنەوە', $toWh, $fromWh);
            }
            $conn->commit();
            touchLastUpdate($conn);
            $detail = pos_fetch_stock_transfer_detail($conn, $transferId);
            echo json_encode(['status' => 'success', 'id' => $transferId, 'transaction_id' => $txnId, 'transfer' => $detail], JSON_UNESCAPED_UNICODE); exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]); exit();
        }
    }

    if ($act === 'unlock_warehouse') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        $whId = (int)($_POST['warehouse_id'] ?? 0);
        $pin = trim((string)($_POST['pin'] ?? ''));
        if ($whId <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'کۆگەه دیار نییە'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $resolved = pos_resolve_warehouse_id($conn, $whId);
        if ($resolved !== $whId) {
            echo json_encode(['status' => 'error', 'message' => 'کۆگەه نەدۆزرایەوە'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $hash = function_exists('pos_warehouse_pin_hash') ? pos_warehouse_pin_hash($conn, $whId) : '';
        if ($hash !== '') {
            if ($pin === '' || !password_verify($pin, $hash)) {
                echo json_encode(['status' => 'error', 'message' => 'پاسۆرد هەڵەیە'], JSON_UNESCAPED_UNICODE);
                exit();
            }
        }
        pos_set_open_warehouse_id($whId);
        echo json_encode([
            'status' => 'success',
            'open_warehouse_id' => $whId,
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if ($act === 'lock_warehouse') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        pos_set_open_warehouse_id(0);
        echo json_encode(['status' => 'success', 'open_warehouse_id' => 0], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if ($act === 'set_warehouse_pin') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        if (!pos_session_is_admin()) pos_json_perm_denied();
        $whId = (int)($_POST['warehouse_id'] ?? 0);
        $pin = trim((string)($_POST['pin'] ?? ''));
        $clear = !empty($_POST['clear']);
        if ($whId <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'کۆگەه دیار نییە'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        if (function_exists('pos_ensure_warehouse_pin_column')) pos_ensure_warehouse_pin_column($conn);
        if ($clear || $pin === '') {
            $empty = '';
            $st = $conn->prepare("UPDATE warehouses SET pin_hash = ? WHERE id = ?");
            $st->bind_param('si', $empty, $whId);
            $st->execute();
            touchLastUpdate($conn);
            echo json_encode(['status' => 'success', 'has_pin' => 0], JSON_UNESCAPED_UNICODE);
            exit();
        }
        if (!preg_match('/^\d{4,8}$/', $pin)) {
            echo json_encode(['status' => 'error', 'message' => 'پاسۆرد: ٤ تا ٨ ژمارە'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $hash = password_hash($pin, PASSWORD_DEFAULT);
        $st = $conn->prepare("UPDATE warehouses SET pin_hash = ? WHERE id = ?");
        $st->bind_param('si', $hash, $whId);
        $st->execute();
        touchLastUpdate($conn);
        echo json_encode(['status' => 'success', 'has_pin' => 1], JSON_UNESCAPED_UNICODE);
        exit();
    }
