<?php
if (!defined('POS_APP_VERSION')) {
    require_once __DIR__ . '/../config/version.php';
}
/** Installation IDs for startup overlay (readable without API — license gate runs on API only). */
$pos_startup_serial = '';
$pos_startup_security = '';
$pos_bios_raw = '';
$pos_public_install_serial = '';
/** If license already activated (cache OK), hide serial/security on startup — only show until admin enables. */
$pos_show_startup_license_codes = true;
if (!empty($conn)) {
    require_once __DIR__ . '/../config/supabase_license.php';
    if (function_exists('pos_ensure_license_serial')) {
        $pos_public_install_serial = (string) pos_ensure_license_serial($conn);
    }
    if (function_exists('pos_db_get_setting_value')) {
        $pos_license_cached_ok = pos_db_get_setting_value($conn, 'pos_license_cache_ok');
        if ($pos_license_cached_ok === '1') {
            $pos_show_startup_license_codes = false;
        }
    }
    if ($pos_show_startup_license_codes && function_exists('pos_detect_machine_serial')) {
        $pos_bios_raw = (string) pos_detect_machine_serial();
    }
    if ($pos_show_startup_license_codes && function_exists('pos_ensure_license_serial')) {
        $pos_startup_serial = (string) pos_ensure_license_serial($conn);
    }
    if ($pos_show_startup_license_codes && function_exists('pos_ensure_license_security_code')) {
        $pos_startup_security = (string) pos_ensure_license_security_code($conn);
    }
    if (function_exists('pos_ensure_license_serial')) {
        $pos_settings_install_serial = (string) pos_ensure_license_serial($conn);
    }
    if (function_exists('pos_ensure_license_security_code')) {
        $pos_settings_security_code = (string) pos_ensure_license_security_code($conn);
    }
    if (function_exists('pos_machine_device_keys_for_client')) {
        $pos_machine_device_keys = pos_machine_device_keys_for_client($conn);
    }
}
if (!isset($pos_settings_install_serial)) {
    $pos_settings_install_serial = '';
}
if (!isset($pos_settings_security_code)) {
    $pos_settings_security_code = '';
}
if (!isset($pos_machine_device_keys) || !is_array($pos_machine_device_keys)) {
    $pos_machine_device_keys = ['primary' => '', 'terminal' => ''];
}
$pos_default_logo_url = POS_DEFAULT_LOGO_PATH;
$pos_default_shop_logo_url = defined('POS_DEFAULT_SHOP_LOGO_PATH') ? POS_DEFAULT_SHOP_LOGO_PATH : 'public/assets/brand/laptop-duhok-logo.png';
require __DIR__ . '/partials/pos_head.php';
require __DIR__ . '/partials/pos_modals.php';
require __DIR__ . '/partials/pos_overlays.php';
require __DIR__ . '/partials/pos_layout.php';
require __DIR__ . '/partials/pos_settings_hidden.php';
require __DIR__ . '/partials/pos_footer.php';
