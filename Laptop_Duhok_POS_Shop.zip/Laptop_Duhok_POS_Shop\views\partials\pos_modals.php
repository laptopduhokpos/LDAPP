    <!-- PRINTABLE AREA (UPDATED KURDISH ARABIC SCRIPT & LOGO) -->
    <div id="printable-area"></div>

    <!-- COMPANY PROFILE MODAL (FIXED WITH PHONE ID) -->
    <div id="company-profile-modal" class="profile-modal">
        <div class="profile-content">
            <div class="profile-header">
                <div>
                    <h2 id="cp-name" style="margin:0; color:var(--text);">کۆمپانیا</h2>
                    <small id="cp-id" style="display:inline-block; margin-top:4px; background:rgba(59,130,246,0.15); color:#3b82f6; padding:2px 8px; border-radius:6px; font-size:0.78rem; font-weight:700; direction:ltr;"></small>
                    <small id="cp-phone" style="font-size:0.9rem; opacity:0.9; display:block; margin-top:4px;"></small>
                    <small id="cp-address" style="font-size:0.9rem; opacity:0.9; margin-right: 10px;"></small>
                </div>
                <button style="background:none; border:none; color:var(--text); font-size:1.5rem; cursor:pointer;" onclick="closeCompanyProfile()">✖</button>
            </div>
            <div class="profile-tabs">
                <button id="tab-btn-inventory" class="tab-btn active" onclick="switchTab('inventory')">📦 <span data-i18n="view_warehouse_title">کۆگەه</span></button>
                <button id="tab-btn-history" class="tab-btn" onclick="switchTab('history')">📝 <span data-i18n="comp_profile_tab_history">مێژوو</span></button>
                <button id="tab-btn-ledger" class="tab-btn" onclick="switchTab('ledger')">📒 <span data-i18n="comp_profile_tab_ledger">پێداچوون/جەرد</span></button>
                <button id="tab-btn-receipts" class="tab-btn" onclick="switchTab('receipts')">🧾 <span data-i18n="comp_profile_tab_receipts">پسوولە (وەسڵ)</span></button>
                <button id="tab-btn-receipts-archive" class="tab-btn" onclick="switchTab('receipts-archive')">🗂️ <span data-i18n="comp_profile_tab_receipts_archive">ئەرشیفێ پسوولەیان</span></button>
            </div>
            <div id="tab-inventory" class="tab-content active">
                <h3 style="color:var(--text)" data-i18n="comp_profile_section_inventory">داتایێن کۆگەهی</h3>
                <div class="card">
                    <div class="comp-profile-kpi-grid" style="display:grid; grid-template-columns: 1fr 1fr 1fr; gap:20px; margin-bottom:20px;">
                        <div class="p-box" style="background:var(--input-bg); border-color:var(--border);"><h4 data-comp-i18n="comp_profile_kpi_stock_value">کۆم بهایێ کۆگەهی</h4><h2 id="cp-total-stock-value">0</h2></div>
                        <div class="p-box" style="background:var(--input-bg); border-color:var(--border);"><h4 data-comp-i18n="comp_profile_kpi_remaining_debt">قەرزێ مای</h4><h2 id="cp-balance" style="color:red">0</h2></div>
                        <div><button id="btn-company-debt-action" class="btn btn-success" onclick="payDebt()" style="height:100%; width:100%; font-size:1.2rem;"><i class="fas fa-money-bill-wave"></i> <span data-i18n="pay_debt">دانەڤا قەرزی</span></button></div>
                    </div>
                    <h4 data-comp-i18n="comp_profile_items_list">لیستا هەمی ئایتمان</h4>
                    <div class="comp-profile-scroll-list" style="max-height:400px; overflow-y:auto;">
                        <table class="report-table"><thead><tr><th data-comp-i18n="comp_profile_col_item">ئایتم</th><th data-comp-i18n="comp_profile_col_warehouse">کۆگەه</th><th data-comp-i18n="comp_profile_col_cost_piece">Cost (تاک)</th><th data-comp-i18n="comp_profile_col_price_piece">Price (تاک)</th><th data-comp-i18n="comp_profile_col_profit">مفا</th><th data-comp-i18n="comp_profile_col_action">کار</th></tr></thead>
                            <tbody id="cp-items-list"></tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div id="tab-history" class="tab-content">
                <h3 style="color:var(--text)" data-i18n="comp_profile_section_history">مێژوویا کڕین و داخازیان</h3>
                <div class="comp-profile-filters" style="display:flex; gap:5px; margin-bottom:10px; align-items:center;">
                    <input type="date" id="date-start-cp-history" class="input-std" style="margin:0; font-size:0.9rem;" onchange="renderCompanyHistory()">
                    <span data-i18n="waste_date_to">تا</span>
                    <input type="date" id="date-end-cp-history" class="input-std" style="margin:0; font-size:0.9rem;" onchange="renderCompanyHistory()">
                    <button class="btn btn-sm btn-dark" onclick="resetDateFilter('cp-history', renderCompanyHistory)"><i class="fas fa-times"></i></button>
                </div>
                <div class="comp-profile-scroll-list" style="max-height:500px; overflow-y:auto;">
                    <table class="report-table">
                        <thead><tr><th data-comp-i18n="comp_profile_hist_col_date">بەروار</th><th data-comp-i18n="comp_profile_col_item">ئایتم</th><th data-comp-i18n="comp_profile_hist_col_pay_type">جۆر</th><th data-comp-i18n="comp_profile_hist_col_total">کۆم بهای</th><th data-comp-i18n="comp_profile_hist_col_actions">کار</th></tr></thead>
                        <tbody id="cp-history-list"></tbody>
                    </table>
                </div>
            </div>
            <div id="tab-ledger" class="tab-content">
                <h3 style="color:var(--text)" data-i18n="comp_profile_section_ledger">پێداچوون/جەردێ پارەدان و قەرزان</h3>
                <button type="button" class="btn btn-warning" onclick="printLedger()" data-i18n-title="comp_ledger_print_title"><i class="fas fa-print"></i> <span data-i18n="comp_ledger_print_btn">چاپ (پێداچوون/جەردێ پارەدان و قەرزان)</span></button>
                <div class="comp-profile-filters" style="display:flex; gap:8px; margin-top:10px; margin-bottom:10px; align-items:center;">
                    <select id="cp-ledger-history-date-preset" class="input-std" style="width:160px; margin:0;" onchange="applyGlobalDatePreset(this.value, 'cp-ledger', renderLedgerHistory)">
                        <option value="today" selected>☀️ ئەڤرۆ (Today)</option>
                        <option value="week">📅 حەفتییا بۆری (Last 7 Days)</option>
                        <option value="month">🌙 ئەڤ هەیڤە (This Month)</option>
                        <option value="90d">📅 ٩٠ ڕۆژ (Last 90 Days)</option>
                        <option value="1y">📅 ١ ساڵ (1 Year)</option>
                        <option value="all">📅 هەمی دەم (All Time)</option>
                        <option value="custom">✍️ دیارکرنا دەمی (Custom)</option>
                    </select>
                    <input type="date" id="date-start-cp-ledger" class="input-std" style="margin:0; font-size:0.9rem; display:none;" onchange="renderLedgerHistory()">
                    <span data-i18n="waste_date_to" style="display:none;">تا</span>
                    <input type="date" id="date-end-cp-ledger" class="input-std" style="margin:0; font-size:0.9rem; display:none;" onchange="renderLedgerHistory()">
                    <button class="btn btn-sm btn-dark" onclick="resetDateFilter('cp-ledger', renderLedgerHistory)"><i class="fas fa-times"></i></button>
                </div>
                <div class="comp-profile-scroll-list" style="max-height:500px; overflow-y:auto; margin-top:15px;">                    <table class="report-table">
                        <thead><tr><th data-comp-i18n="comp_profile_ledger_col_date">بەروار</th><th data-comp-i18n="comp_profile_ledger_col_txn_type">جۆرێ کارێ</th><th data-comp-i18n="comp_profile_ledger_col_amount">بڕ</th><th data-comp-i18n="comp_profile_ledger_col_debt_balance">ماوەیێ قەرزی</th><th data-comp-i18n="comp_profile_ledger_col_note">تێبینی</th><th style="text-align:center;">کردار</th></tr></thead>
                        <tbody id="cp-ledger-list"></tbody>
                    </table>
                </div>
            </div>
            <div id="tab-receipts" class="tab-content">
                <h3 style="color:var(--text)" data-i18n="comp_profile_section_receipts">وەسڵێن کۆمپانیایێ (هویرکاریێن دروست)</h3>
                <div class="comp-profile-filters" style="display:flex; gap:8px; margin-bottom:10px; align-items:center;">
                    <input type="text" id="cp-receipts-search" class="input-std" style="margin:0; font-size:0.9rem;" data-comp-i18n-placeholder="comp_profile_receipts_search_ph" placeholder="لێگەڕیان ب ژمارا لڤینێ / ژمارا پسوولەیێ / جۆر..." onkeyup="renderCompanyReceipts()">
                    <button class="btn btn-sm btn-dark" onclick="document.getElementById('cp-receipts-search').value=''; renderCompanyReceipts();"><i class="fas fa-times"></i></button>
                </div>
                <div class="comp-profile-scroll-list" style="max-height:500px; overflow-y:auto;">
                    <table class="report-table">
                        <thead><tr><th data-comp-i18n="comp_profile_rcpt_col_date">بەروار</th><th data-comp-i18n="comp_profile_rcpt_col_type">جۆر</th><th data-comp-i18n="comp_profile_rcpt_col_ref">ژمارا پسوولەیێ/لڤینێ</th><th data-comp-i18n="comp_profile_rcpt_col_details">هویرکاری</th><th data-comp-i18n="comp_profile_rcpt_col_amount">کوژم</th><th data-comp-i18n="comp_profile_rcpt_col_action">کار (ئەمر)</th></tr></thead>
                        <tbody id="cp-receipts-list"></tbody>
                    </table>
                </div>
            </div>
            <div id="tab-receipts-archive" class="tab-content">
                <h3 style="color:var(--text)" data-i18n="comp_profile_section_archive">ئەرشیفێ پسوولەیان (چاپ/تۆمار)</h3>
                <div class="comp-profile-filters" style="display:flex; gap:8px; margin-bottom:10px; align-items:center;">
                    <input type="text" id="cp-receipts-archive-search" class="input-std" style="margin:0; font-size:0.9rem;" data-comp-i18n-placeholder="comp_profile_archive_search_ph" placeholder="لێگەڕیان د ئەرشیفێ پسوولەیان دا..." onkeyup="renderCompanyReceiptsArchive()">
                    <button class="btn btn-sm btn-dark" onclick="document.getElementById('cp-receipts-archive-search').value=''; renderCompanyReceiptsArchive();"><i class="fas fa-times"></i></button>
                </div>
                <div class="comp-profile-scroll-list" style="max-height:500px; overflow-y:auto;">
                    <table class="report-table">
                        <thead><tr><th data-comp-i18n="comp_profile_arch_col_printed">دەمێ چاپکرنێ</th><th data-comp-i18n="comp_profile_arch_col_type">جۆر</th><th data-comp-i18n="comp_profile_arch_col_ref">ناسناما</th><th data-comp-i18n="comp_profile_arch_col_user">بکارهێنەر</th><th data-comp-i18n="comp_profile_arch_col_note">تێبینی</th><th data-comp-i18n="comp_profile_arch_col_details">هویرکاری</th></tr></thead>
                        <tbody id="cp-receipts-archive-list"></tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>

    <!-- PAY COMPANY DEBT (select company first) -->
    <div id="pay-company-debt-modal" class="profile-modal pcd-modal" style="display:none;" role="dialog" aria-labelledby="pcd-modal-title">
        <div class="pcd-modal__panel">
            <div class="pcd-modal__header">
                <div class="pcd-modal__title-wrap">
                    <h2 id="pcd-modal-title"><i class="fas fa-building pos-ic"></i> <span data-i18n="pcd_modal_title">دانەڤا قەرزی کۆمپانیا</span></h2>
                    <p class="pcd-modal__sub" data-i18n="pcd_modal_sub">سەرەتا کۆمپانیا هەڵبژێرە، پاشان بڕی پارەدانێ بنووسە</p>
                </div>
                <button type="button" class="pcd-modal__close" onclick="closePayCompanyDebtModal()" aria-label="Close"><i class="fas fa-times"></i></button>
            </div>
            <div class="pcd-modal__body">
                <label class="pcd-modal__label" for="pcd-search"><i class="fas fa-industry pos-ic"></i> <span data-i18n="pcd_pick_company">کۆمپانیا</span></label>
                <div class="pcd-modal__search-wrap">
                    <i class="fas fa-search pcd-modal__search-ic" aria-hidden="true"></i>
                    <input type="text" id="pcd-search" class="input-std pcd-modal__search" data-i18n-placeholder="pcd_search_ph" placeholder="گەڕان بە ناوی کۆمپانیا..." onkeyup="renderPayCompanyDebtPicker(this.value)">
                </div>
                <div id="pcd-company-list" class="pay-debt-list pcd-company-list"></div>
                <input type="hidden" id="pcd-selected-id" value="">
                <div id="pcd-selected-box" class="pcd-selected-box" style="display:none;">
                    <div class="pcd-selected-box__lbl"><i class="fas fa-check-circle pos-ic"></i> <span data-i18n="pcd_selected_label">هەڵبژێردراو</span></div>
                    <div id="pcd-selected-name" class="pcd-selected-box__name"></div>
                    <div class="pcd-selected-box__debt"><i class="fas fa-file-invoice-dollar pos-ic"></i> <span data-i18n="pcd_debt_remaining">قەرزی مای</span>: <strong id="pcd-selected-balance">0</strong></div>
                </div>
                <label class="pcd-modal__label" for="pcd-amount"><i class="fas fa-money-bill-wave pos-ic"></i> <span data-i18n="pcd_amount_label">بڕی پارەدانێ</span></label>
                <input type="text" inputmode="decimal" id="pcd-amount" class="input-std pcd-modal__amount" placeholder="0">
                <div class="pcd-modal__actions">
                    <button type="button" class="btn btn-dark" onclick="closePayCompanyDebtModal()"><i class="fas fa-ban pos-ic"></i> <span data-i18n="del_btn_cancel">هەڵوەشاندن</span></button>
                    <button type="button" class="btn btn-success" onclick="confirmPayCompanyDebt()"><i class="fas fa-check pos-ic"></i> <span data-i18n="pcd_confirm_pay">تۆمارکرن و چاپ</span></button>
                </div>
            </div>
        </div>
    </div>

    <!-- COLLECT CUSTOMER / USER DEBT PAYMENT -->
    <div id="collect-debt-modal" class="profile-modal pcd-modal" style="display:none;" role="dialog" aria-labelledby="cdm-modal-title">
        <div class="pcd-modal__panel">
            <div class="pcd-modal__header">
                <div class="pcd-modal__title-wrap">
                    <h2 id="cdm-modal-title"><i class="fas fa-hand-holding-usd pos-ic"></i> <span data-i18n="cdm_modal_title">وەرگرتنا پارەی</span></h2>
                    <p class="pcd-modal__sub" data-i18n="cdm_modal_sub">بڕێ پارەی وەرگیراو بنووسە — 0 واتە هەمی قەرز</p>
                </div>
                <button type="button" class="pcd-modal__close" onclick="closeCollectDebtModal()" aria-label="Close"><i class="fas fa-times"></i></button>
            </div>
            <div class="pcd-modal__body">
                <div id="cdm-entity-box" class="pcd-selected-box cdm-entity-box">
                    <div class="pcd-selected-box__lbl"><i class="fas fa-user pos-ic"></i> <span data-i18n="cdm_entity_label">کڕیار</span></div>
                    <div id="cdm-entity-name" class="pcd-selected-box__name"></div>
                    <div id="cdm-entity-meta" class="cdm-entity-meta"></div>
                    <div class="pcd-selected-box__debt cdm-debt-hero">
                        <i class="fas fa-file-invoice-dollar pos-ic"></i>
                        <span data-i18n="cdm_current_debt">بارێ لای بکرێ نوکە</span>:
                        <strong id="cdm-current-debt">0</strong>
                    </div>
                </div>
                <label class="pcd-modal__label" for="cdm-amount"><i class="fas fa-money-bill-wave pos-ic"></i> <span data-i18n="cdm_amount_label">بڕێ پارەی وەرگیراو</span></label>
                <input type="text" inputmode="decimal" id="cdm-amount" class="input-std pcd-modal__amount" dir="ltr" placeholder="0" oninput="updateCollectDebtPreview()">
                <div class="cdm-quick-row">
                    <button type="button" class="btn btn-sm btn-dark" onclick="fillCollectDebtFullAmount()"><i class="fas fa-coins"></i> <span data-i18n="cdm_pay_full">هەمی قەرز</span></button>
                </div>
                <div class="cdm-after-row">
                    <span data-i18n="cdm_after_balance">بارێ دوای پارەدان</span>:
                    <strong id="cdm-after-balance">0</strong>
                </div>
                <label class="pcd-modal__label" for="cdm-receipt"><i class="fas fa-receipt pos-ic"></i> <span data-i18n="cdm_receipt_label">ژمارا ئیسڵەق / فاتوورە (ئۆپشناڵ)</span></label>
                <input type="text" id="cdm-receipt" class="input-std" dir="ltr" maxlength="40" placeholder="">
                <label class="cdm-print-row">
                    <input type="checkbox" id="cdm-print-chk" checked>
                    <span data-i18n="cdm_print_after">چاپی وەسڵ دوای تۆمارکرن</span>
                </label>
                <input type="hidden" id="cdm-target-id" value="">
                <input type="hidden" id="cdm-target-type" value="">
                <div class="pcd-modal__actions">
                    <button type="button" class="btn btn-dark" onclick="closeCollectDebtModal()"><i class="fas fa-ban pos-ic"></i> <span data-i18n="del_btn_cancel">هەڵوەشاندن</span></button>
                    <button type="button" class="btn btn-success" id="cdm-confirm-btn" onclick="confirmCollectDebtPayment()"><i class="fas fa-check pos-ic"></i> <span data-i18n="cdm_confirm_pay">تۆمارکرنا پارەی</span></button>
                </div>
            </div>
        </div>
    </div>

    <!-- CUSTOMER PROFILE MODAL -->
    <div id="customer-profile-modal" class="profile-modal" style="display:none;">
        <div class="profile-content">
            <div class="profile-header">
                <div>
                    <h2 id="cust-p-name" style="margin:0; color:var(--text);">کڕیار</h2>
                    <small id="cust-p-id" style="display:inline-block; margin-top:4px; background:rgba(59,130,246,0.15); color:#3b82f6; padding:2px 8px; border-radius:6px; font-size:0.78rem; font-weight:700; direction:ltr;"></small>
                    <small id="cust-p-phone" style="font-size:0.9rem; opacity:0.9; display:block; margin-top:4px;"></small>
                    <small id="cust-p-address" style="font-size:0.9rem; opacity:0.9; margin-right: 10px;"></small>
                </div>
                <button style="background:none; border:none; color:var(--text); font-size:1.5rem; cursor:pointer;" onclick="closeCustomerProfile()">✖</button>
            </div>
            
            <div class="cust-profile-balance-card" style="background:var(--card); border:1px solid var(--border); border-radius:12px; padding:15px; margin-bottom:20px; display:flex; justify-content:space-between; align-items:center;">
                <div class="cust-profile-balance-main">
                    <h3 class="cust-profile-balance-label" style="margin:0; color:var(--text-muted); font-size:0.9rem;" data-i18n="cust_balance_current_label">ڕەسیدێ نوکە</h3>
                    <h1 id="cust-p-balance" class="cust-profile-balance-value" style="margin:5px 0 0 0; color:var(--danger); font-size:1.8rem;">0</h1>
                </div>
                <button id="btn-customer-debt-action" class="btn btn-success" style="padding:10px 20px; font-size:1.1rem;"></button>
            </div>

            <div class="profile-tabs">
                <button id="tab-btn-cust-history" class="tab-btn active" onclick="switchCustomerTab('cust-history')">📝 <span data-i18n="cust_profile_tab_history">مێژوو</span></button>
                <button id="tab-btn-cust-ledger" class="tab-btn" onclick="switchCustomerTab('cust-ledger')">📒 <span data-i18n="cust_profile_tab_ledger">پێداچوون/جەرد</span></button>
                <button id="tab-btn-cust-installments" class="tab-btn" onclick="switchCustomerTab('cust-installments')">💳 <span data-i18n="cust_profile_tab_installments">قست</span><span id="cust-inst-tab-pro-badge" class="wms-pro-lock-badge" style="display:none;margin-inline-start:6px;font-size:0.62rem;vertical-align:middle;">PRO · $224</span></button>
            </div>
            
            <div id="tab-cust-history" class="tab-content active">
                <h3 style="color:var(--text)" data-i18n="cust_profile_section_sales_history">مێژوویا کڕینان</h3>
                <div id="cust-p-history-list" class="cust-profile-scroll-list" style="max-height:400px; overflow-y:auto;"></div>
            </div>

            <div id="tab-cust-ledger" class="tab-content">
                <h3 style="color:var(--text)" data-i18n="comp_profile_section_ledger">پێداچوون/جەردێ پارەدان و قەرزان</h3>
                <button type="button" class="btn btn-warning" onclick="printCustomerLedger()" data-i18n-title="cust_ledger_print_title"><i class="fas fa-print"></i> <span data-i18n="cust_ledger_print_btn">چاپ (پێداچوون/جەردێ کڕیاری)</span></button>
                <div class="cust-profile-ledger-filters" style="display:flex; gap:8px; margin-top:10px; margin-bottom:10px; align-items:center;">
                    <select id="cust-ledger-history-date-preset" class="input-std" style="width:160px; margin:0;" onchange="applyGlobalDatePreset(this.value, 'cust-ledger', renderCustomerLedgerHistory)">
                        <option value="today" selected>☀️ ئەڤرۆ (Today)</option>
                        <option value="week">📅 حەفتییا بۆری (Last 7 Days)</option>
                        <option value="month">🌙 ئەڤ هەیڤە (This Month)</option>
                        <option value="90d">📅 ٩٠ ڕۆژ (Last 90 Days)</option>
                        <option value="1y">📅 ١ ساڵ (1 Year)</option>
                        <option value="all">📅 هەمی دەم (All Time)</option>
                        <option value="custom">✍️ دیارکرنا دەمی (Custom)</option>
                    </select>
                    <input type="date" id="date-start-cust-ledger" class="input-std" style="margin:0; font-size:0.9rem; display:none;" onchange="renderCustomerLedgerHistory()">
                    <span data-i18n="waste_date_to" style="display:none;">تا</span>
                    <input type="date" id="date-end-cust-ledger" class="input-std" style="margin:0; font-size:0.9rem; display:none;" onchange="renderCustomerLedgerHistory()">
                    <button class="btn btn-sm btn-dark" onclick="resetDateFilter('cust-ledger', renderCustomerLedgerHistory)"><i class="fas fa-times"></i></button>
                </div>
                <div class="cust-profile-scroll-list" style="max-height:500px; overflow-y:auto; margin-top:15px;">
                    <table class="report-table">
                        <thead><tr><th>بەروار (Date)</th><th>جۆرێ کارێ (Type)</th><th>بڕ (Amount)</th><th>ماوەیێ قەرزی (Balance)</th><th>تێبینی (Note)</th><th style="text-align:center;">کردار</th></tr></thead>
                        <tbody id="cust-p-ledger-list"></tbody>
                    </table>
                </div>
            </div>

            <div id="tab-cust-installments" class="tab-content">
                <div id="cust-installments-root"></div>
            </div>
        </div>
    </div>

    <!-- DEBT SELECTION MODAL (FOR POS) -->
    <div id="debt-select-modal" class="modal-overlay" style="display:none;">
        <div class="glass-card" style="width: 600px; text-align: right;">
            <h2 style="margin-top:0;"><i class="fas fa-users"></i> <span data-i18n="view_debt_title">کریار</span></h2>
            <p style="color:var(--text-muted);" data-i18n="payment_debt_search_placeholder">کێ دێ ڤی بابەتی ب دەین بەت؟</p>
            
            <div class="page-action-row" style="display:flex; gap:10px; margin-bottom:10px;">
                <div class="page-actions-standard" style="display:flex; gap:10px;">
                    <button class="btn btn-brand" onclick="renderDebtSelect('customer')"><span data-i18n="print_customer">کریار</span></button>
                    <button class="btn btn-info" onclick="renderDebtSelect('user')"><span data-i18n="nav_staff">کارمەند</span></button>
                </div>
            </div>
            <div id="debt-person-list" class="debt-modal-grid"></div>
            <button class="btn btn-danger" style="margin-top:20px; width:100%;" onclick="closeDebtModal()" data-i18n="btn_cancel">پاشگەزبوونەوە</button>
        </div>
    </div>

    <!-- CUSTOMER / COMPANY EDIT MODAL -->
    <div id="cc-edit-modal" class="modal-overlay" style="display:none;">
        <div class="glass-card" style="width: 780px; text-align: right; display:flex; flex-direction:column; max-height:90vh; overflow:hidden;">
            <div style="border-bottom:1px solid var(--border); padding:12px 15px; display:flex; justify-content:space-between; align-items:center;">
                <div>
                    <h2 style="margin:0; color:var(--brand);"><i class="fas fa-user-edit"></i> <span id="cc-edit-title"></span></h2>
                    <small id="cc-edit-subtitle" style="color:var(--text-muted);"></small>
                </div>
                <button class="btn btn-sm btn-dark" style="font-size:1.05rem; padding:6px 12px;" onclick="closeCustomerCompanyEditModal()" title="داخستن">✖</button>
            </div>

            <input type="hidden" id="cc-edit-entity-type" value="">
            <input type="hidden" id="cc-edit-id" value="0">

            <div style="padding:15px; display:grid; grid-template-columns: 1fr 1fr; gap:15px; align-items:end; flex:1; overflow-y:auto;">
                <div><label style="font-size:0.85rem;">ناڤ (Name)</label><input type="text" id="cc-edit-name" class="input-std" style="margin:0;"></div>
                <div><label style="font-size:0.85rem;">تەلەفۆن (Phone)</label><input type="text" id="cc-edit-phone" class="input-std" style="margin:0;"></div>
                <div style="grid-column: 1 / -1;"><label style="font-size:0.85rem;">ناڤنیشان (Address)</label><input type="text" id="cc-edit-address" class="input-std" style="margin:0;"></div>
                <div><label for="cc-edit-opening-balance" style="font-size:0.85rem;">دەینی کەڤن (Opening Balance)</label><input type="text" id="cc-edit-opening-balance" class="input-std" style="margin:0;" value="0" inputmode="decimal" dir="ltr"></div>
                <div><label for="cc-edit-debt-limit" style="font-size:0.85rem;">سنووری قەرز (Debt Limit)</label><input type="text" id="cc-edit-debt-limit" class="input-std" style="margin:0;" value="0" inputmode="decimal" dir="ltr"></div>
                <div><label for="cc-edit-payment-term-value" style="font-size:0.85rem;" data-i18n="payment_due_label">مەوعدێ پارەدانێ</label><div style="display:flex; gap:8px; align-items:center;"><input type="number" id="cc-edit-payment-term-value" class="input-std" style="margin:0; flex:1;" min="0" step="1" value="0" inputmode="numeric" dir="ltr"><select id="cc-edit-payment-term-unit" class="input-std" style="margin:0; width:auto;"><option value="minute" data-i18n-opt="payment_term_unit_minute">خولەک</option>
                            <option value="hour" data-i18n-opt="payment_term_unit_hour">دەمژمێر</option><option value="day" data-i18n-opt="payment_term_unit_day" selected>ڕۆژ</option><option value="month" data-i18n-opt="payment_term_unit_month">مانگ</option><option value="year" data-i18n-opt="payment_term_unit_year">ساڵ</option></select></div></div>
            </div>

            <div class="page-action-row" style="display:flex; padding:15px; border-top:1px solid var(--border);">
                <div class="page-actions-standard" style="display:flex; gap:10px; width:100%; justify-content:flex-end;">
                    <button class="btn btn-success" style="padding:12px 18px; min-width:200px;" onclick="saveCustomerCompanyEdit()"><i class="fas fa-save"></i> پاراستن (Save)</button>
                    <button class="btn btn-dark" style="padding:12px 18px; min-width:200px;" onclick="closeCustomerCompanyEditModal()">پاشگەزبوونەوە</button>
                </div>
            </div>
        </div>
    </div>

    <!-- RECIPE MODAL -->
    <div id="recipe-modal" class="modal-overlay" style="display:none;">
        <div class="glass-card" style="width: 700px; text-align: right; display:flex; flex-direction:column; max-height:90vh;">
            <input type="hidden" id="recipe-modal-pid">
            <datalist id="recipe-datalist"></datalist>
            
            <div style="border-bottom:1px solid var(--border); padding-bottom:15px; margin-bottom:15px; display:flex; justify-content:space-between; align-items:center;">
                <div>
                    <h2 style="margin:0; color:var(--brand);"><i class="fas fa-boxes-packing recipe-ui-icon"></i> <span id="recipe-prod-name"></span></h2>
                    <p style="margin:5px 0 0 0; color:var(--text-muted); font-size:0.9rem;">پێکهاتەیێن ڤی ئایتمی دیار بکە</p>
                </div>
                <button class="btn btn-sm btn-dark" onclick="document.getElementById('recipe-modal').style.display='none'">✖</button>
            </div>
            
            <div class="recipe-modal-body" id="recipe-ingredients-list"></div>
            
            <div style="margin-top:10px; text-align:center;">
                <button class="btn btn-info" style="width:100%; border-style:dashed;" onclick="addRecipeRow()"><i class="fas fa-plus-circle"></i> زێدەکرنا کەرەستەیەک (Add Ingredient)</button>
            </div>

            <div style="margin-top:auto; padding-top:20px; border-top:1px solid var(--border);">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px; background:var(--input-bg); padding:10px; border-radius:10px;">
                    <span>💰 کرینیێ خەمڵێنراو (Est. Cost):</span>
                    <span id="recipe-total-cost" style="font-weight:bold; color:var(--warning); font-size:1.2rem;">0</span>
                </div>
                <div id="recipe-sale-mode-panel" style="display:none; margin-bottom:15px; padding:12px; border-radius:10px; border:1px dashed var(--brand); background:rgba(37,99,235,0.06);">
                    <strong style="color:var(--brand); display:block; margin-bottom:8px;"><i class="fas fa-cash-register"></i> <span data-i18n="recipe_sale_mode_title">شێوازی فرۆشتن لە POS</span></strong>
                    <p style="margin:0 0 10px; font-size:0.85rem; opacity:0.9;" data-i18n="recipe_sale_mode_hint">هەر ئایتمێک لە پسوولەدا دەردەکەوێت: راستەوخو یان دروستکردن.</p>
                    <div style="display:flex; flex-wrap:wrap; gap:12px;">
                        <label style="cursor:pointer;"><input type="radio" name="recipe-sale-mode" value="auto" checked> <span data-i18n="recipe_sale_mode_auto">خۆکار</span></label>
                        <label style="cursor:pointer;"><input type="radio" name="recipe-sale-mode" value="direct"> <span data-i18n="recipe_sale_mode_direct">راستەوخو (لە کۆگە)</span></label>
                        <label style="cursor:pointer;"><input type="radio" name="recipe-sale-mode" value="manufacture"> <span data-i18n="recipe_sale_mode_manufacture">دروستکردن (کەرەستە)</span></label>
                    </div>
                </div>
                <div id="recipe-produce-panel" style="display:none; margin-bottom:15px; padding:12px; border-radius:10px; border:1px dashed var(--success); background:rgba(16,185,129,0.08);">
                    <div style="display:flex; flex-wrap:wrap; gap:10px; align-items:center; justify-content:space-between;">
                        <div>
                            <strong style="color:var(--success);"><i class="fas fa-industry"></i> دروستکرنا بەرهەمێ ئامادە</strong>
                            <p style="margin:4px 0 0; font-size:0.85rem; opacity:0.85;">کەرەستە دکەمێت، بەرهەما ئامادە د کۆگەهێ زیاد دبیت (پێویستە حیسابا کۆگەهی چالاک بیت).</p>
                        </div>
                        <div style="display:flex; gap:8px; align-items:center;">
                            <label style="margin:0; font-size:0.85rem;">ژمارە:</label>
                            <input type="number" id="recipe-produce-qty" class="input-std" min="1" step="1" value="1" style="width:80px; margin:0;" onkeydown="if(event.key==='Enter'){event.preventDefault();produceRecipeBatch();}">
                            <button type="button" class="btn btn-success" onclick="produceRecipeBatch()"><i class="fas fa-hammer"></i> دروستکرن</button>
                        </div>
                    </div>
                </div>
                <div class="page-action-row" style="display:flex; gap:10px;">
                    <div class="page-actions-standard" style="display:flex; gap:10px;">
                        <button class="btn btn-success" style="flex:1; padding:12px;" onclick="saveRecipe()"><i class="fas fa-save"></i> پاراستن (Save)</button>
                        <button class="btn btn-dark" style="flex:1; padding:12px;" onclick="document.getElementById('recipe-modal').style.display='none'">پاشگەزبوونەوە</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- RETURN DETAILS MODAL -->
    <div id="return-details-modal" class="modal-overlay" style="display:none;">
        <div class="glass-card" style="width: 500px; text-align: right;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px; border-bottom:1px solid var(--border); padding-bottom:10px;">
                <h3 id="return-details-modal-title" style="margin:0;"><i class="fas fa-info-circle"></i> <span id="return-details-modal-title-text">وردەکاریێن زڤڕاندنێ (Return Details)</span></h3>
                <button class="btn btn-danger btn-sm" onclick="document.getElementById('return-details-modal').style.display='none'">✖</button>
            </div>
            <div id="return-details-content" style="max-height:400px; overflow-y:auto;"></div>
        </div>
    </div>



    <!-- DELIVERY MODAL -->
    <div id="delivery-modal" class="modal-overlay" style="display:none;">
        <div class="glass-card" style="width: 600px; max-width: 96vw; text-align: right;">
            <h2 style="margin-top:0;"><i class="fas fa-truck"></i> <span data-i18n="del_modal_title">بەریدا نوی</span></h2>
            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:10px;">
                <select id="del-customer-id" class="input-std" onchange="if(typeof onDeliveryCustomerChange==='function')onDeliveryCustomerChange()" style="grid-column:span 2;">
                    <option value="0" data-i18n="del_customer_pick">کریار — هەلبژێرە</option>
                </select>
                <input type="text" id="del-cust-name" class="input-std" placeholder="ناڤێ کریاری" data-i18n-placeholder="del_ph_customer">
                <input type="text" id="del-phone" class="input-std" placeholder="تەلەفۆن" data-i18n-placeholder="del_ph_phone">
                <input type="text" id="del-address" class="input-std" placeholder="ناڤنیشان" data-i18n-placeholder="del_ph_address" style="grid-column:span 2;">
                <select id="del-driver-id" class="input-std" onchange="if(typeof onDeliveryDriverChange==='function')onDeliveryDriverChange()" style="grid-column:span 2;">
                    <option value="0" data-i18n="del_driver_pick">سایێق — هەلبژێرە</option>
                </select>
                <input type="hidden" id="del-driver-name" value="">
                <input type="hidden" id="del-driver-phone" value="">
                <input type="text" id="del-delivery-cost" class="input-std" placeholder="بهایێ گەهاندنێ" inputmode="decimal" dir="ltr" oninput="calcDeliveryTotal()">
                <input type="number" id="del-total" class="input-std" placeholder="کۆمێ پارەی">
                <input type="text" id="del-note" class="input-std" placeholder="تێبینی" style="grid-column:span 2;">
            </div>
            <button type="button" class="btn btn-success" style="width:100%; margin-top:10px;" onclick="saveDelivery()"><i class="fas fa-paper-plane"></i> <span data-i18n="send_delivery">هنارتن</span></button>
            <button type="button" class="btn btn-danger" style="width:100%; margin-top:5px;" onclick="document.getElementById('delivery-modal').style.display='none'"><span data-i18n="del_btn_close">داخستن</span></button>
        </div>
    </div>

    <!-- DRIVER REGISTRY MODAL -->
    <div id="driver-modal" class="modal-overlay" style="display:none;">
        <div class="glass-card" style="width: 520px; max-width: 96vw; text-align: right;">
            <div style="display:flex; justify-content:space-between; align-items:center; gap:8px;">
                <h2 style="margin:0;"><i class="fas fa-id-card"></i> <span data-i18n="del_drivers_heading">سایێق</span></h2>
                <button type="button" class="btn btn-sm btn-danger" onclick="document.getElementById('driver-modal').style.display='none'"><i class="fas fa-times"></i></button>
            </div>
            <input type="hidden" id="drv-edit-id" value="0">
            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:8px; margin-top:12px;">
                <input type="text" id="drv-name" class="input-std" placeholder="ناڤێ سایێقی" style="grid-column:span 2;">
                <input type="text" id="drv-phone" class="input-std" placeholder="تەلەفۆن">
                <input type="text" id="drv-note" class="input-std" placeholder="تێبینی">
            </div>
            <button type="button" class="btn btn-success" style="width:100%; margin-top:10px;" onclick="saveDriver()"><i class="fas fa-save"></i> <span data-i18n="del_driver_save">پاراستن</span></button>
            <div id="drivers-manage-list" class="delivery-drivers-manage" style="margin-top:14px; max-height:280px; overflow-y:auto;"></div>
        </div>
    </div>

    <!-- DRIVER PROFILE MODAL -->
    <div id="driver-profile-modal" class="profile-modal" style="display:none;">
        <div class="profile-content">
            <div class="profile-header drv-p-header">
                <div class="drv-p-ident">
                    <span class="drv-p-avatar" aria-hidden="true"><i class="fas fa-motorcycle"></i></span>
                    <div>
                    <h2 id="drv-p-name" style="margin:0; color:var(--text);">سایێق</h2>
                    <small id="drv-p-id" style="display:inline-block; margin-top:4px; background:rgba(217,119,6,0.15); color:#c2410c; padding:2px 8px; border-radius:6px; font-size:0.78rem; font-weight:700; direction:ltr;"></small>
                    <small class="drv-p-phone"><i class="fas fa-phone drv-p-inline-ico"></i> <span id="drv-p-phone"></span></small>
                    <small id="drv-p-note" style="font-size:0.9rem; opacity:0.9; display:block; margin-top:4px;"></small>
                    </div>
                </div>
                <button type="button" class="drv-p-close" aria-label="داخستن" onclick="closeDriverProfile()"><i class="fas fa-times"></i></button>
            </div>
            <div class="cust-profile-balance-card drv-p-balance" style="background:var(--card); border:1px solid var(--border); border-radius:12px; padding:15px; margin-bottom:20px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
                <div class="drv-p-balance-main">
                    <h3 style="margin:0; color:var(--text-muted); font-size:0.9rem;"><i class="fas fa-money-bill-wave"></i> <span data-i18n="del_kpi_driver_cash">پارە ل دەف سایقان</span></h3>
                    <h1 id="drv-p-hold" style="margin:5px 0 0 0; color:#0284c7; font-size:1.8rem;">0</h1>
                    <small id="drv-p-active-count" style="color:var(--text-muted);"></small>
                </div>
                <div style="display:flex; gap:8px; flex-wrap:wrap;">
                    <button type="button" class="btn btn-brand drv-picto-action" onclick="if(typeof openDeliveryForCurrentDriver==='function')openDeliveryForCurrentDriver()"><i class="fas fa-plus"></i> <i class="fas fa-truck"></i> <span data-i18n="del_btn_new">گەهاندنا نوی</span></button>
                    <button type="button" class="btn btn-warning drv-picto-action" onclick="if(typeof editDriverFromProfile==='function')editDriverFromProfile()"><i class="fas fa-edit"></i> <span data-i18n="debt_btn_edit">دەستکاری</span></button>
                </div>
            </div>
            <div class="profile-tabs">
                <button type="button" id="tab-btn-drv-active" class="tab-btn active" onclick="switchDriverTab('drv-active')"><i class="fas fa-truck"></i> <span data-i18n="del_active_heading">گەهاندنێن چالاک</span></button>
                <button type="button" id="tab-btn-drv-history" class="tab-btn" onclick="switchDriverTab('drv-history')"><i class="fas fa-clock-rotate-left"></i> <span data-i18n="del_history_heading">مێژوو</span></button>
            </div>
            <div id="tab-drv-active" class="tab-content active">
                <div id="drv-p-active-list" class="cust-profile-scroll-list" style="max-height:420px; overflow-y:auto;"></div>
            </div>
            <div id="tab-drv-history" class="tab-content">
                <div class="drv-picto-filters" role="group">
                    <button type="button" class="drv-picto-btn active" data-st="" onclick="if(typeof setDriverHistoryFilter==='function')setDriverHistoryFilter('')" title="هەمی"><i class="fas fa-layer-group"></i></button>
                    <button type="button" class="drv-picto-btn ok" data-st="delivered" onclick="if(typeof setDriverHistoryFilter==='function')setDriverHistoryFilter('delivered')" title="گەهشت"><i class="fas fa-check"></i></button>
                    <button type="button" class="drv-picto-btn warn" data-st="refused" onclick="if(typeof setDriverHistoryFilter==='function')setDriverHistoryFilter('refused')" title="رەفس"><i class="fas fa-undo"></i></button>
                    <button type="button" class="drv-picto-btn bad" data-st="cancelled" onclick="if(typeof setDriverHistoryFilter==='function')setDriverHistoryFilter('cancelled')" title="هەلوەشاندی"><i class="fas fa-times"></i></button>
                    <select id="drv-p-history-status" class="input-std drv-hist-status-select" aria-hidden="true" onchange="if(typeof renderDriverProfileHistory==='function')renderDriverProfileHistory()">
                        <option value="" data-i18n="del_filter_all">هەمی</option>
                        <option value="delivered" data-i18n="del_status_delivered">گەهشت</option>
                        <option value="refused" data-i18n="del_status_refused">رەفس</option>
                        <option value="cancelled" data-i18n="del_status_cancelled">هەلوەشاندی</option>
                    </select>
                </div>
                <div id="drv-p-history-list" class="cust-profile-scroll-list" style="max-height:420px; overflow-y:auto;"></div>
            </div>
        </div>
    </div>

    <!-- ITEM REPORT MODAL (NEW) -->
    <div id="item-report-modal" class="modal-overlay" style="display:none; align-items: flex-start; padding-top: 5vh;">
        <div class="glass-card" style="width: 90%; max-width: 880px; text-align: right; max-height: 90vh; overflow-y: auto;">
            <div style="display:flex; justify-content: space-between; align-items: center; gap:10px; flex-wrap:wrap;">
                <h2 style="margin:0;"><i class="fas fa-chart-bar"></i> <span data-i18n="item_report_title">ڕاپۆرتا تاکەکەسی یا ئایتمی</span></h2>
                <button class="btn btn-danger btn-sm" onclick="document.getElementById('item-report-modal').style.display='none'"><i class="fas fa-times"></i></button>
            </div>
            <div class="hist-filters daily-summary-range-bar" id="item-report-range-bar" style="margin-top:12px;">
                <label class="daily-summary-range-field" for="item-report-date-from">
                    <span data-i18n="item_report_date_from">ژ</span>
                    <input type="date" id="item-report-date-from" class="input-std daily-summary-date-input">
                </label>
                <label class="daily-summary-range-field" for="item-report-date-to">
                    <span data-i18n="item_report_date_to">تا</span>
                    <input type="date" id="item-report-date-to" class="input-std daily-summary-date-input">
                </label>
                <button type="button" class="btn btn-sm btn-brand daily-summary-apply-btn" onclick="typeof applyItemReportDateRange==='function'&&applyItemReportDateRange()" title="جێبەجێکرن"><i class="fas fa-check"></i> <span data-i18n="item_report_apply">جێبەجێکرن</span></button>
                <button type="button" class="btn btn-sm" onclick="typeof setItemReportRangeToday==='function'&&setItemReportRangeToday()"><span data-i18n="item_report_today">ئەڤڕۆ</span></button>
                <button type="button" class="btn btn-sm" onclick="typeof setItemReportRangeAll==='function'&&setItemReportRangeAll()"><span data-i18n="item_report_all">هەمی</span></button>
            </div>
            <div id="item-report-content">
                <!-- Content will be generated by JavaScript -->
            </div>
        </div>
    </div>

    <!-- DAILY HISTORY MODAL -->
    <div id="daily-history-modal" class="modal-overlay hist-modal" style="display:none;">
        <div class="glass-card hist-shell" data-accent="brand">
            <div class="hist-header">
                <h2 class="hist-title"><i class="fas fa-calendar-day"></i> <span data-i18n="daily_summary_modal_title">پوختەیا ڕۆژێ</span></h2>
                <button type="button" class="btn btn-sm btn-danger" onclick="closeDailyHistoryModal()"><i class="fas fa-times"></i> <span data-i18n="btn_close">داخستن</span></button>
            </div>
            <div class="hist-filters daily-summary-range-bar">
                <label class="daily-summary-range-field" for="date-start-daily">
                    <span data-i18n="daily_summary_date_from">ژ</span>
                    <input type="date" id="date-start-daily" class="input-std daily-summary-date-input">
                </label>
                <label class="daily-summary-range-field" for="date-end-daily">
                    <span data-i18n="daily_summary_date_to">تا</span>
                    <input type="date" id="date-end-daily" class="input-std daily-summary-date-input">
                </label>
                <button type="button" class="btn btn-sm btn-brand daily-summary-apply-btn" onclick="typeof applyDailyHistoryDateRange==='function'&&applyDailyHistoryDateRange()" data-i18n-title="daily_summary_apply_range" title="جێبەجێکرن"><i class="fas fa-check"></i> <span data-i18n="daily_summary_apply_range">جێبەجێکرن</span></button>
            </div>
            <div id="daily-history-content" class="hist-body"></div>
            <div id="daily-sum-detail-sheet" class="daily-sum-detail-sheet" style="display:none;" role="dialog" aria-modal="true" onclick="if(event.target===this&&typeof closeDailySummaryDetailSheet==='function')closeDailySummaryDetailSheet();">
                <div class="daily-sum-detail-sheet__panel" onclick="event.stopPropagation();">
                    <div class="daily-sum-detail-sheet__head">
                        <h3 id="daily-sum-detail-sheet-title" class="daily-sum-detail-sheet__title"><i class="fas fa-list-ul"></i> <span data-i18n="daily_summary_detail_title">وردەکاری</span></h3>
                        <button type="button" class="btn btn-sm btn-danger" onclick="typeof closeDailySummaryDetailSheet==='function'&&closeDailySummaryDetailSheet()"><i class="fas fa-times"></i> <span data-i18n="btn_close">داخستن</span></button>
                    </div>
                    <div id="daily-sum-detail-sheet-body" class="daily-sum-detail-sheet__body"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- MANUAL ITEM MODAL: Larger, Entry collapsible, state in localStorage -->
    <div id="manual-item-modal" class="modal-overlay manual-item-modal-overlay" style="display:none;" onclick="if(event.target===this&&typeof closeManualItemModal==='function')closeManualItemModal();">
        <div class="glass-card manual-sale-card" style="width: 620px; max-width: 95vw; text-align:right;">
            <div class="manual-sale-head">
                <h2 class="manual-sale-title"><i class="fas fa-pen-fancy"></i> <span data-i18n="manual_sale_title">فرۆتنا دەستی</span></h2>
                <button type="button" class="manual-manage-icon-btn no-print" id="manual-manage-toggle" data-i18n-title="manual_manage_quick" onclick="if(typeof toggleManualManagePanel==='function') toggleManualManagePanel();" title="إدارة الأصناف السريعة"><i class="fas fa-cog"></i></button>
            </div>
            <p class="manual-sale-desc" data-i18n="manual_sale_desc">ئایتمە خێراکان بەبێ بارکۆد، یان نوسینی دەستی.</p>

            <div class="manual-sale-scroll">
                <div class="manual-form-section collapsible">
                    <div class="manual-form-section-header" id="manual-entry-toggle" onclick="if(typeof toggleManualEntrySection==='function') toggleManualEntrySection();">
                        <span class="manual-form-section-title"><i class="fas fa-edit"></i> <span data-i18n="manual_entry">إدخال يدوي</span></span>
                        <span class="manual-form-section-icon" id="manual-entry-toggle-icon" aria-hidden="true"><i class="fas fa-chevron-down"></i></span>
                    </div>
                    <div class="manual-form-section-body" id="manual-entry-body">
                        <div class="manual-form-fields compact">
                            <div class="manual-field-row">
                                <label for="manual-item-name"><span data-i18n="manual_item_name">ناڤێ صنفێ</span></label>
                                <input type="text" id="manual-item-name" class="input-std" data-i18n-placeholder="manual_name_placeholder" placeholder="نموونە: چایا تایبەت">
                            </div>
                            <div class="manual-field-row">
                                <label for="manual-item-price"><span data-i18n="manual_item_price">نرخ (IQD)</span></label>
                                <input type="text" inputmode="decimal" id="manual-item-price" class="input-std pos-money-input" placeholder="0" style="direction:ltr; text-align:left;" data-placeholder-iqd="1000">
                            </div>
                            <div class="manual-field-row">
                                <label for="manual-item-cost"><span data-i18n="manual_item_cost">کرین (دینار)</span></label>
                                <input type="text" inputmode="decimal" id="manual-item-cost" class="input-std pos-money-input" placeholder="0" style="direction:ltr; text-align:left;" data-i18n-placeholder="manual_cost_optional">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="manual-quick-section">
                    <h3 class="manual-section-label"><i class="fas fa-bolt"></i> <span data-i18n="manual_quick_items">أصناف سريعة</span></h3>
                    <div id="manual-quick-items-container" class="manual-quick-items-grid"></div>
                </div>

                <div class="manual-manage-panel no-print" id="manual-manage-panel" style="display:none;">
                    <div class="manual-manage-panel-head">
                        <h4><i class="fas fa-sliders-h"></i> <span data-i18n="manual_manage_quick">ڕێکخستنا کەلوپەلێن بلەز</span></h4>
                    </div>
                    <div id="manual-modal-quick-list" class="manual-modal-quick-list"></div>
                    <div class="manual-modal-add-row">
                        <input type="text" id="manual-modal-new-name" class="input-std" data-i18n-placeholder="manual_new_name_placeholder" placeholder="اسم الصنف">
                        <input type="text" inputmode="decimal" id="manual-modal-new-price" class="input-std pos-money-input manual-modal-money-in" placeholder="0" style="width:72px; direction:ltr; text-align:left;" data-i18n-placeholder="manual_item_price">
                        <input type="text" inputmode="decimal" id="manual-modal-new-cost" class="input-std pos-money-input manual-modal-money-in" placeholder="0" style="width:72px; direction:ltr; text-align:left;" data-i18n-placeholder="manual_item_cost">
                        <button type="button" class="btn-manual-add-quick" onclick="if(typeof addQuickItemFromModal==='function') addQuickItemFromModal();" data-i18n-title="manual_add_quick" title="زێدەکرن"><i class="fas fa-plus"></i></button>
                    </div>
                    <div class="manual-manage-save-row">
                        <button type="button" class="btn btn-brand-manual btn-manual-save-quick" onclick="if(typeof saveManualQuickItemsFromModal==='function') saveManualQuickItemsFromModal();"><i class="fas fa-save"></i> <span data-i18n="btn_save">پاراستن</span></button>
                    </div>
                </div>
            </div>

            <div class="manual-sale-footer no-print">
                <button type="button" class="btn btn-cancel-manual" onclick="closeManualItemModal()"><i class="fas fa-times"></i> <span data-i18n="manual_cancel">داخستن</span></button>
                <button type="button" class="btn btn-brand-manual manual-footer-add-btn" onclick="confirmManualItem()"><i class="fas fa-cart-plus"></i> <span data-i18n="manual_add_cart">زێدەکرن بۆ سەبەتێ</span></button>
            </div>
        </div>
    </div>

    <!-- PURCHASE: edit product catalog item (same form as Add Items, without leaving purchase) -->
    <div id="purchase-product-edit-modal" class="modal-overlay purchase-product-edit-modal" style="display:none;" onclick="if(event.target===this&&typeof closePurchaseProductEditModal==='function')closePurchaseProductEditModal();">
        <div class="purchase-product-edit-shell card" role="dialog" aria-modal="true" aria-labelledby="purchase-product-edit-title">
            <div class="purchase-product-edit-head">
                <h2 id="purchase-product-edit-title" class="purchase-product-edit-title"><i class="fas fa-pen"></i> <span data-i18n="purchase_product_edit_title">دەستکاری ئایتم (ل کڕین)</span></h2>
                <button type="button" class="btn btn-dark btn-sm" onclick="closePurchaseProductEditModal()" data-i18n-title="btn_close" title="داخستن"><i class="fas fa-times"></i></button>
            </div>
            <div class="purchase-product-edit-body">
                <div id="purchase-product-edit-mount"></div>
            </div>
            <p class="purchase-product-edit-hint" data-i18n="purchase_product_edit_hint">دوای پاراستن دەگەڕێیتەوە بۆ کڕین — سەبەتە و دابینکەر دەمێننەوە.</p>
        </div>
    </div>

    <!-- QUICK DEFINE MODAL (purchase only — barcode not found → define & add to purchase cart) -->
    <div id="quick-define-modal" class="modal-overlay pos-quick-define-modal" style="display:none;" onclick="if(event.target===this&&typeof closeQuickDefineModal==='function')closeQuickDefineModal();">
        <div class="card qd-product-form pos-quick-define-card" role="dialog" aria-modal="true" aria-labelledby="qd-title" style="direction:rtl;" autocomplete="off">
            <input type="hidden" id="qd-unit-show-pack" value="0">
            <input type="hidden" id="qd-unit-show-carton" value="0">
            <input type="hidden" id="qd-auto-cost" value="1">
            <input type="hidden" id="qd-auto-price" value="1">
            <div class="qd-modal-body">
            <div class="form-section qd-modal-main-section">
                <div class="form-section-title product-form-section-title"><i class="fas fa-info-circle"></i> <span id="qd-title" data-i18n="qd_modal_title">پێناسەکرنا ئایتمێ نوی</span></div>
                <p class="qd-modal-hint product-form-optional-desc" style="font-size:0.78rem; color:var(--text-muted); margin:0 0 10px 0;"><i class="fas fa-info-circle"></i> <span data-i18n="qd_modal_hint">ئەڤ بارکۆدە نەهاتە دیتن. تو دشێی نوکە پێناسە بکەی.</span></p>
                <label class="product-form-label" for="qd-barcode-input"><i class="fas fa-barcode"></i> <span data-i18n="product_form_label_barcode">بارکۆد</span></label>
                <div style="display:flex; flex-wrap:wrap; gap:6px; align-items:center;">
                    <code id="qd-barcode-display" class="p-barcode-display" style="flex:1; min-width:120px;"></code>
                    <input type="text" id="qd-barcode-input" class="input-std is-hidden" style="flex:1; min-width:120px;" autocomplete="off" spellcheck="false" dir="ltr" onkeydown="if(event.key==='Enter'){event.preventDefault();qdToggleBarcodeEdit(true);}">
                    <button type="button" id="btn-qd-edit-barcode" class="btn btn-info btn-sm" onclick="qdToggleBarcodeEdit()" data-i18n-title="btn_edit" title="دەستکاری"><i class="fas fa-pen"></i></button>
                </div>
                <label class="product-form-label" for="qd-name"><i class="fas fa-tag"></i> <span data-i18n="product_form_label_name">ناڤێ ئایتمی</span></label>
                <input type="text" id="qd-name" class="input-std" data-i18n-placeholder="product_form_name_placeholder" placeholder="ناڤ" autocomplete="off" spellcheck="false">
                <label class="product-form-label" for="qd-category"><i class="fas fa-folder"></i> <span data-i18n="product_form_label_category">پۆل</span></label>
                <div style="display:flex; flex-wrap:wrap; gap:6px; align-items:center;">
                    <select id="qd-category" class="input-std" style="flex:1; margin:0;"></select>
                    <button type="button" class="btn btn-info btn-sm" onclick="qdQuickAddCategory()" data-i18n-title="product_form_cat_add_title" title="زێدەکرنا پۆلێ نوێ"><i class="fas fa-plus"></i></button>
                </div>
                <label class="product-form-label"><i class="fas fa-layer-group"></i> <span data-i18n="product_form_unit_levels_title">تاک + پاکێت + کارتۆن (هەمیشە)</span></label>
                <p class="product-form-optional-desc" style="font-size:0.7rem; color:var(--text-muted); margin:0 0 8px 0;"><i class="fas fa-info-circle"></i> <span data-i18n="product_form_unit_levels_desc">سەرەتا تاک هەیە؛ سووچەکە بکەرەوە بۆ پاکێت یان کارتۆن — «هەیە» یان «نینە».</span></p>
                <div id="qd-add-unit-levels-row" class="p-unit-levels-row" style="margin-bottom:10px;">
                    <div class="p-unit-level-item p-unit-level-item--pack">
                        <span class="p-unit-toggle-label p-unit-toggle-pack"><i class="fas fa-boxes"></i> <span data-i18n="product_form_pack_label">پاکێت</span></span>
                        <button type="button" id="btn-qd-unit-pack-toggle" class="p-unit-level-switch p-unit-level-switch--pack" role="switch" aria-checked="false" onclick="qdTogglePackLevel()" data-i18n-title="product_form_unit_toggle_title" title="سووچ بکەرەوە — هەیە یان نینە">
                            <span class="p-unit-level-switch__text p-unit-level-switch__text--off" data-i18n="product_form_unit_no">نینە</span>
                            <span class="p-unit-level-switch__track" aria-hidden="true"><span class="p-unit-level-switch__thumb"></span></span>
                            <span class="p-unit-level-switch__text p-unit-level-switch__text--on" data-i18n="product_form_unit_yes">هەیە</span>
                        </button>
                    </div>
                    <div class="p-unit-level-item p-unit-level-item--carton">
                        <span class="p-unit-toggle-label p-unit-toggle-carton"><i class="fas fa-box"></i> <span data-i18n="product_form_carton_label">کارتۆن</span></span>
                        <button type="button" id="btn-qd-unit-carton-toggle" class="p-unit-level-switch p-unit-level-switch--carton" role="switch" aria-checked="false" onclick="qdToggleCartonLevel()" data-i18n-title="product_form_unit_toggle_title" title="سووچ بکەرەوە — هەیە یان نینە">
                            <span class="p-unit-level-switch__text p-unit-level-switch__text--off" data-i18n="product_form_unit_no">نینە</span>
                            <span class="p-unit-level-switch__track" aria-hidden="true"><span class="p-unit-level-switch__thumb"></span></span>
                            <span class="p-unit-level-switch__text p-unit-level-switch__text--on" data-i18n="product_form_unit_yes">هەیە</span>
                        </button>
                    </div>
                    <div class="p-unit-level-item p-unit-level-item--stock">
                        <span class="p-unit-toggle-label p-unit-toggle-stock"><i class="fas fa-cubes"></i> <span data-i18n="product_form_track_stock">حیسابا کۆگەهی؟</span></span>
                        <input type="checkbox" id="qd-track" checked hidden aria-hidden="true" tabindex="-1">
                        <button type="button" id="btn-qd-unit-stock-toggle" class="p-unit-level-switch p-unit-level-switch--stock is-on" role="switch" aria-checked="true" onclick="qdToggleTrackStock()" data-i18n-title="product_form_unit_toggle_title" title="سووچ بکەرەوە — هەیە یان نینە">
                            <span class="p-unit-level-switch__text p-unit-level-switch__text--off" data-i18n="product_form_unit_no">نینە</span>
                            <span class="p-unit-level-switch__track" aria-hidden="true"><span class="p-unit-level-switch__thumb"></span></span>
                            <span class="p-unit-level-switch__text p-unit-level-switch__text--on" data-i18n="product_form_unit_yes">هەیە</span>
                        </button>
                    </div>
                </div>
                <div id="qd-stock-cost-section" class="qd-stock-block" style="margin-top:12px; padding-top:12px; border-top:1px solid var(--border);">
                    <div class="form-section-title product-form-section-title"><i class="fas fa-coins"></i> <span id="qd-pricing-section-title" data-i18n="product_form_section_units">یەکە، بارکۆد، کرین، فرۆتن، کۆگەه</span></div>
                    <div id="qd-auto-toggle-group" class="pos-qd-auto-toggle-group is-hidden" style="margin:0 0 8px 0;">
                        <button type="button" id="btn-qd-auto-cost" class="pos-qd-auto-toggle is-on" onclick="qdToggleAutoCost()" title="کڕین: خۆکار">
                            <i class="fas fa-magic"></i> <span id="qd-auto-cost-label" data-i18n="qd_auto_cost_on">کڕین: خۆکار</span>
                        </button>
                        <button type="button" id="btn-qd-auto-price" class="pos-qd-auto-toggle is-on" onclick="qdToggleAutoPrice()" title="فرۆتن: خۆکار">
                            <i class="fas fa-magic"></i> <span id="qd-auto-price-label" data-i18n="qd_auto_price_on">فرۆتن: خۆکار</span>
                        </button>
                    </div>
                    <div id="qd-conv-row" class="is-hidden qd-conv-grid">
                        <div id="qd-conv-ppp-wrap" class="p-conv-pack is-hidden">
                            <label id="qd-label-ppp" class="p-conv-label"><i class="fas fa-link"></i> <span data-i18n="product_form_conv_ppp">دانە ل پاکێتی دا</span></label>
                            <input type="number" id="qd-pieces-per-pack" class="input-std" min="1" value="1" style="margin:0;" dir="ltr" oninput="qdOnConvChange()">
                        </div>
                        <div id="qd-conv-ppc-wrap" class="p-conv-carton is-hidden">
                            <label class="p-conv-label"><i class="fas fa-link"></i> <span data-i18n="product_form_conv_ppc">پاکێت ل کارتۆنی دا</span></label>
                            <input type="number" id="qd-packs-per-carton" class="input-std" min="1" value="1" style="margin:0;" dir="ltr" oninput="qdOnConvChange()">
                        </div>
                    </div>
                    <p id="qd-conv-preview" class="p-conv-carton-preview"></p>
                    <div class="report-table">
                        <table style="width:100%; border-collapse:collapse;">
                            <thead><tr>
                                <th style="text-align:right;"><i class="fas fa-ruler"></i> <span data-i18n="product_form_th_unit">یەکە</span></th>
                                <th style="text-align:right;"><i class="fas fa-barcode"></i> <span data-i18n="product_form_label_barcode">بارکۆد</span></th>
                                <th style="text-align:right;"><i class="fas fa-shopping-cart"></i> <span data-i18n="product_form_th_cost">کرین</span></th>
                                <th style="text-align:right;"><i class="fas fa-tag"></i> <span data-i18n="product_form_th_sale">فرۆتن</span></th>
                                <th class="product-form-th-stock" style="text-align:right;"><i class="fas fa-cubes"></i> <span data-i18n="product_form_th_stock">کۆگەه</span></th>
                            </tr></thead>
                            <tbody>
                                <tr id="qd-ml-row-piece" class="p-ml-row p-ml-row-piece">
                                    <td><i class="fas fa-cube"></i> <span data-i18n="product_form_piece_label">تاک</span></td>
                                    <td><input type="text" id="qd-piece-barcode-ref" class="input-std" dir="ltr" placeholder="—" autocomplete="off" oninput="if(typeof qdSyncBarcodeFromPieceCell==='function')qdSyncBarcodeFromPieceCell();"></td>
                                    <td><input type="text" inputmode="decimal" id="qd-cost" class="input-std pos-money-input" placeholder="0" dir="ltr" oninput="qdSyncFromLevel('qd-cost')"></td>
                                    <td><input type="text" inputmode="decimal" id="qd-price" class="input-std pos-money-input" placeholder="0" dir="ltr" oninput="qdSyncFromLevel('qd-price')"></td>
                                    <td class="product-form-stock-cell"><input type="number" id="qd-stock-piece" class="input-std" min="0" step="1" value="0" dir="ltr" oninput="qdCalcTotalStock()"></td>
                                </tr>
                                <tr id="qd-ml-row-pack" class="p-ml-row p-ml-row-pack" style="display:none;">
                                    <td><i class="fas fa-boxes"></i> <span data-i18n="product_form_pack_label">پاکێت</span></td>
                                    <td><input type="text" id="qd-barcode-pack" class="input-std" placeholder="—" autocomplete="off" dir="ltr" oninput="if(typeof onLevelBarcodeInput==='function')onLevelBarcodeInput(this);" onblur="if(typeof onLevelBarcodeBlur==='function')onLevelBarcodeBlur(this);"></td>
                                    <td><input type="text" inputmode="decimal" id="qd-cost-pack" class="input-std pos-money-input pos-qd-derived-input" placeholder="0" dir="ltr" oninput="qdSyncFromLevel('qd-cost-pack')"></td>
                                    <td><input type="text" inputmode="decimal" id="qd-price-pack" class="input-std pos-money-input pos-qd-derived-input" placeholder="0" dir="ltr" oninput="qdSyncFromLevel('qd-price-pack')"></td>
                                    <td class="product-form-stock-cell"><input type="number" id="qd-stock-pack" class="input-std" min="0" step="1" value="0" dir="ltr" oninput="qdCalcTotalStock()"></td>
                                </tr>
                                <tr id="qd-ml-row-carton" class="p-ml-row p-ml-row-carton" style="display:none;">
                                    <td><i class="fas fa-box"></i> <span data-i18n="product_form_carton_label">کارتۆن</span></td>
                                    <td><input type="text" id="qd-barcode-carton" class="input-std" placeholder="—" autocomplete="off" dir="ltr" oninput="if(typeof onLevelBarcodeInput==='function')onLevelBarcodeInput(this);" onblur="if(typeof onLevelBarcodeBlur==='function')onLevelBarcodeBlur(this);"></td>
                                    <td><input type="text" inputmode="decimal" id="qd-cost-carton" class="input-std pos-money-input pos-qd-derived-input" placeholder="0" dir="ltr" oninput="qdSyncFromLevel('qd-cost-carton')"></td>
                                    <td><input type="text" inputmode="decimal" id="qd-price-carton" class="input-std pos-money-input pos-qd-derived-input" placeholder="0" dir="ltr" oninput="qdSyncFromLevel('qd-price-carton')"></td>
                                    <td class="product-form-stock-cell"><input type="number" id="qd-stock-carton" class="input-std" min="0" step="1" value="0" dir="ltr" oninput="qdCalcTotalStock()"></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div id="qd-total-stock-preview" style="text-align:center; font-size:0.8rem; color:var(--success); font-weight:bold; margin:6px 0;"></div>
                    <p class="product-stock-lock-hint" style="display:none; margin:0 0 6px;"><i class="fas fa-lock"></i> <span data-i18n="product_stock_lock_hint">عەدەدێ کوگەهێ ژ بەشێ کڕین زێدە / کێم بکە — دەستکاری ل ڤێرێ خەلەتیێ دروست دکەت</span></p>
                </div>
                <label class="product-form-label" for="qd-supplier" style="margin-top:10px;"><i class="fas fa-truck"></i> <span data-i18n="product_form_label_supplier">دابینکەر / شەریک</span></label>
                <div style="display:flex; flex-wrap:wrap; gap:6px; align-items:center;">
                    <select id="qd-supplier" class="input-std" style="flex:1; margin:0;"></select>
                    <button type="button" class="btn btn-info btn-sm" onclick="qdQuickAddSupplier()" data-i18n-title="purchase_supplier_add_title" title="زێدەکرنا دابینکەرێ نوێ"><i class="fas fa-plus"></i></button>
                </div>
            </div>
            </div>
            <div class="qd-modal-footer pos-quick-define-actions">
                <div class="page-actions-standard">
                    <button type="button" class="btn btn-dark" onclick="closeQuickDefineModal()"><i class="fas fa-times"></i> <span data-i18n="btn_cancel">پاشگەزبوونەوە</span></button>
                    <button type="button" class="btn btn-info" onclick="saveQuickProduct({ openEdit: true })"><i class="fas fa-edit"></i> <span data-i18n="qd_save_edit">پاراستن &amp; دەستکاری</span></button>
                    <button type="button" class="btn btn-brand" onclick="saveQuickProduct()"><i class="fas fa-save"></i> <span id="qd-save-sell-label" data-i18n="qd_save_purchase">پاراستن &amp; کڕین</span></button>
                </div>
            </div>
        </div>
    </div>

    <!-- WASTE REPORT MODAL -->
    <div id="waste-report-modal" class="modal-overlay pos-waste-modal" style="display:none;" onclick="if(event.target===this&&typeof closeWasteReportModal==='function')closeWasteReportModal();">
        <div class="glass-card pos-waste-card" role="dialog" aria-modal="true" aria-labelledby="waste-modal-title">
            <div class="pos-waste-head">
                <span class="pos-waste-icon" aria-hidden="true"><i class="fas fa-trash-alt"></i></span>
                <div>
                    <h2 id="waste-modal-title" class="pos-waste-title" data-i18n="waste_modal_title">تۆمارکرنا تەلەفێ</h2>
                    <p id="waste-modal-hint" class="pos-waste-hint" data-i18n="waste_prompt_barcode">بارکۆدێ ئایتمی سکان بکە یان بنڤیسە</p>
                </div>
            </div>
            <div id="waste-barcode-step" class="pos-waste-section">
                <label for="waste-barcode-input" class="pos-waste-label" data-i18n="waste_modal_barcode_label">بارکۆد</label>
                <div class="pos-waste-barcode-row">
                    <input type="text" id="waste-barcode-input" class="input-std pos-waste-barcode-input" autocomplete="off" spellcheck="false" dir="ltr" placeholder="868..." onkeydown="if(event.key==='Enter'){event.preventDefault();wasteModalLookupBarcode();}">
                    <button type="button" class="btn btn-brand pos-waste-lookup-btn" onclick="wasteModalLookupBarcode()"><i class="fas fa-barcode"></i> <span data-i18n="waste_modal_lookup">گەڕان</span></button>
                </div>
            </div>
            <div id="waste-form-step" class="pos-waste-section is-hidden">
                <div id="waste-product-card" class="pos-waste-product-card">
                    <div class="pos-waste-product-name" id="waste-product-name">—</div>
                    <div class="pos-waste-product-meta">
                        <span><i class="fas fa-barcode"></i> <code id="waste-product-barcode">—</code></span>
                        <span><i class="fas fa-warehouse"></i> <span data-i18n="waste_prompt_stock_label">مەخزەن</span>: <strong id="waste-product-stock">0</strong></span>
                    </div>
                </div>
                <div class="pos-waste-field">
                    <label for="waste-qty-input" data-i18n="waste_prompt_qty">چەند دانە تەلەف بوون؟</label>
                    <div class="pos-waste-qty-row">
                        <button type="button" class="btn btn-sm btn-dark pos-waste-qty-btn" onclick="wasteModalAdjustQty(-1)"><i class="fas fa-minus"></i></button>
                        <input type="number" id="waste-qty-input" class="input-std pos-waste-qty-input" min="1" step="1" value="1" dir="ltr" oninput="wasteModalValidateQty()">
                        <button type="button" class="btn btn-sm btn-dark pos-waste-qty-btn" onclick="wasteModalAdjustQty(1)"><i class="fas fa-plus"></i></button>
                    </div>
                    <p id="waste-qty-error" class="pos-waste-qty-error is-hidden"></p>
                </div>
                <div class="pos-waste-field">
                    <label for="waste-reason-input" data-i18n="waste_prompt_reason">ئەگەر چییە؟</label>
                    <div class="pos-waste-reason-chips">
                        <button type="button" class="pos-waste-reason-chip is-active" data-reason="بەسەرچوون" onclick="wasteModalPickReason(this)" data-i18n="waste_prompt_reason_default">بەسەرچوون</button>
                        <button type="button" class="pos-waste-reason-chip" data-reason="شکان" onclick="wasteModalPickReason(this)" data-i18n="waste_reason_broken">شکان</button>
                        <button type="button" class="pos-waste-reason-chip" data-reason="کەمبوونەوەی کوێلیت" onclick="wasteModalPickReason(this)" data-i18n="waste_reason_quality">کەمبوونەوەی کوێلیت</button>
                        <button type="button" class="pos-waste-reason-chip" data-reason="هۆکاری تر" onclick="wasteModalPickReason(this)" data-i18n="waste_reason_other">هۆکاری تر</button>
                    </div>
                    <input type="text" id="waste-reason-input" class="input-std" value="بەسەرچوون" autocomplete="off">
                </div>
            </div>
            <input type="hidden" id="waste-selected-prod-id" value="">
            <div class="page-action-row pos-waste-actions">
                <div class="page-actions-standard">
                    <button type="button" class="btn btn-dark" onclick="closeWasteReportModal()"><i class="fas fa-times"></i> <span data-i18n="btn_cancel">پاشگەزبوونەوە</span></button>
                    <button type="button" id="waste-save-btn" class="btn btn-danger is-hidden" onclick="saveWasteFromModal()"><i class="fas fa-check"></i> <span data-i18n="waste_modal_btn_save">تۆمارکرن</span></button>
                </div>
            </div>
        </div>
    </div>


    <!-- PRINT NOTE MODAL — professional pre-print note -->
    <div id="print-note-modal" class="modal-overlay print-note-modal-overlay" style="display:none;" role="dialog" aria-modal="true" aria-labelledby="print-note-modal-title">
        <div class="glass-card no-print print-note-modal-card">
            <div class="print-note-modal-header">
                <div class="print-note-modal-icon" aria-hidden="true"><i class="fas fa-pen-fancy"></i></div>
                <div>
                    <h3 id="print-note-modal-title" class="print-note-modal-title"><span data-i18n="pre_print_note">تێبینی بەری چاپێ</span></h3>
                    <p id="print-note-context" class="print-note-modal-context"></p>
                </div>
            </div>
            <p class="print-note-modal-desc" data-i18n="pre_print_note_desc">تێبینێک بنووسە بۆ نیشاندان لەسەر وەسڵ — یان بەبێ تێبینی چاپ بکە.</p>
            <div class="print-note-quick-row" role="group" aria-label="Quick notes">
                <button type="button" class="print-note-quick-chip" data-note="" data-i18n="print_note_chip_none">— بەبێ تێبینی</button>
                <button type="button" class="print-note-quick-chip" data-note="گەیاندن" data-i18n="print_note_chip_delivery">گەیاندن</button>
                <button type="button" class="print-note-quick-chip" data-note="وەرگرتن لە کۆگە" data-i18n="print_note_chip_pickup">وەرگرتن</button>
                <button type="button" class="print-note-quick-chip" data-note="سوپاس بۆ داواکاری" data-i18n="print_note_chip_thanks">سوپاس</button>
            </div>
            <label class="print-note-field-label" for="print-note-input" data-i18n="print_note_field_label">دەقی تێبینی</label>
            <textarea id="print-note-input" class="input-std print-note-textarea" rows="4" data-i18n-placeholder="print_note_placeholder" placeholder="وەک: ژمارەی مۆبایل، ناونیشان، کاتێ گەیاندن..." maxlength="280"></textarea>
            <p class="print-note-hint" data-i18n="print_note_hint_keys"><kbd>Ctrl</kbd>+<kbd>Enter</kbd> = چاپ · <kbd>Esc</kbd> = داخستن</p>
            <div class="print-note-modal-actions">
                <button type="button" class="btn btn-dark" id="print-note-cancel"><i class="fas fa-times"></i> <span data-i18n="btn_cancel">پاشگەزبوونەوە</span></button>
                <button type="button" class="btn btn-secondary" id="print-note-skip"><i class="fas fa-print"></i> <span data-i18n="print_note_skip">چاپ بەبێ تێبینی</span></button>
                <button type="button" class="btn btn-success" id="print-note-confirm"><i class="fas fa-check"></i> <span data-i18n="print_note_confirm">چاپ لەگەڵ تێبینی</span></button>
            </div>
        </div>
    </div>

    <!-- GENERAL HISTORY PREVIEW MODAL -->
    <div id="gh-preview-modal" class="modal-overlay gh-preview-overlay" style="display:none;" role="dialog" aria-modal="true" aria-labelledby="gh-preview-title">
        <div class="glass-card gh-preview-card no-print">
            <div class="gh-preview-head">
                <div class="gh-preview-head-text">
                    <h3 id="gh-preview-title" class="gh-preview-title"><i class="fas fa-file-alt"></i> <span id="gh-preview-title-text">دۆکومێنت</span></h3>
                    <p id="gh-preview-meta" class="gh-preview-meta"></p>
                    <span id="gh-preview-action-badge" class="gh-preview-action-badge" hidden></span>
                </div>
                <button type="button" class="btn btn-dark btn-sm gh-preview-close" onclick="closeGeneralHistoryPreview()" aria-label="داخستن"><i class="fas fa-times"></i></button>
            </div>
            <div id="gh-preview-body" class="gh-preview-body"></div>
            <p id="gh-preview-hint" class="gh-preview-hint"></p>
            <div class="gh-preview-actions">
                <button type="button" id="gh-preview-reprint-btn" class="btn btn-success gh-preview-btn-reprint" onclick="reprintFromGeneralHistory()"><i class="fas fa-print"></i> <span data-i18n="gh_preview_reprint">دووبارە چاپ</span></button>
                <button type="button" class="btn btn-secondary" onclick="closeGeneralHistoryPreview()"><i class="fas fa-times"></i> <span data-i18n="gh_preview_cancel">پاشگەزبوونەوە</span></button>
            </div>
        </div>
    </div>


    <!-- USD RATE MODAL (NEW) -->
    <div id="usd-rate-modal" class="modal-overlay" style="display:none;">
        <div class="glass-card" style="width: 450px; text-align:center; background: linear-gradient(145deg, #1e293b, #0f172a); border: 1px solid #334155;">
            <div style="margin-bottom: 20px;">
                <div style="width: 60px; height: 60px; background: rgba(16, 185, 129, 0.1); color: #10b981; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px auto; font-size: 1.8rem;">
                    <i class="fas fa-hand-holding-usd"></i>
                </div>
                <h2 style="margin:0; color:white;">نرخێ دۆلاری (Exchange Rate)</h2>
                <p style="color:#94a3b8; margin: 5px 0;">نرخێ <span style="color:#10b981; font-weight:bold;">100$</span> دیار بکە</p>
            </div>
            
            <div style="background: rgba(0,0,0,0.2); padding: 20px; border-radius: 15px; margin-bottom: 20px; border: 1px solid #334155;">
                <div style="display:flex; align-items:center; justify-content:center; gap:10px; margin-bottom: 10px;">
                    <button class="btn btn-dark" style="width:40px; height:40px; border-radius:50%; padding:0;" onclick="adjustUSDRate(-250)"><i class="fas fa-minus"></i></button>
                    <input type="number" id="modal-usd-rate-input" class="input-std" style="margin:0; width:160px; text-align:center; font-size:2rem; font-weight:bold; color:#10b981; background: transparent; border: none; border-bottom: 2px solid #10b981; border-radius: 0;" value="150000" oninput="updateUSDRatePreview()">
                    <button class="btn btn-dark" style="width:40px; height:40px; border-radius:50%; padding:0;" onclick="adjustUSDRate(250)"><i class="fas fa-plus"></i></button>
                </div>
                <div id="usd-rate-preview" style="color: #94a3b8; font-size: 0.9rem;">1$ = 1,500 IQD</div>
            </div>

            <div style="display:flex; flex-wrap:wrap; gap:8px; justify-content:center; margin-bottom:25px;">
                <button class="btn btn-sm" style="background:#334155; color:white; border:1px solid #475569;" onclick="setQuickRate(148000)">148,000</button>
                <button class="btn btn-sm" style="background:#334155; color:white; border:1px solid #475569;" onclick="setQuickRate(149000)">149,000</button>
                <button class="btn btn-sm" style="background:#334155; color:white; border:1px solid #475569;" onclick="setQuickRate(150000)">150,000</button>
                <button class="btn btn-sm" style="background:#334155; color:white; border:1px solid #475569;" onclick="setQuickRate(151000)">151,000</button>
                <button class="btn btn-sm" style="background:#334155; color:white; border:1px solid #475569;" onclick="setQuickRate(152000)">152,000</button>
                <button class="btn btn-sm btn-info" onclick="window.open('https://kurrency.com/', '_blank')"><i class="fas fa-globe"></i> Online</button>
            </div>
            
            <div id="usd-rate-history-wrap" style="text-align:right; margin-bottom:16px; max-height:140px; overflow:auto; border:1px solid #334155; border-radius:10px; padding:8px; display:none;">
                <div id="usd-rate-history-title" style="color:#94a3b8; font-size:0.75rem; margin-bottom:6px;" data-i18n="exchange_rate_history_title">دوایین گۆڕینەکان (سەرچاوە)</div>
                <table id="usd-rate-history-table" style="width:100%; font-size:0.78rem; color:#e2e8f0; border-collapse:collapse;"></table>
            </div>

            <div style="display:flex; gap:10px;">
                <button class="btn btn-dark" style="flex:1; padding: 12px;" onclick="document.getElementById('usd-rate-modal').style.display='none'">پاشگەزبوونەوە</button>
                <button class="btn btn-success" style="flex:1; padding: 12px;" onclick="saveUSDRateFromModal()"><i class="fas fa-save"></i> پاراستن</button>
            </div>
        </div>
    </div>

    <!-- ADVANCED PAYMENT INTERFACE MODAL -->
    <div id="payment-modal" class="modal-overlay" style="display:none;">
        <div class="glass-card pay-modal-glass">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
                <h2 style="margin:0; color:var(--brand);"><i class="fas fa-cash-register"></i> <span data-i18n="payment_modal_title">وەرگرتنا پارەی</span></h2>
                <button type="button" class="btn btn-dark btn-sm" onclick="closePaymentModal()" data-i18n-title="btn_close" title="داخستن">✖</button>
            </div>
            
            <div class="pay-modal-layout">
                <!-- Left: Numpad (decimal . when USD field active) -->
                <div class="pay-numpad">
                    <button type="button" class="pay-num-btn" onclick="handlePayNumpad('7')">7</button>
                    <button type="button" class="pay-num-btn" onclick="handlePayNumpad('8')">8</button>
                    <button type="button" class="pay-num-btn" onclick="handlePayNumpad('9')">9</button>
                    <button type="button" class="pay-num-btn" onclick="handlePayNumpad('4')">4</button>
                    <button type="button" class="pay-num-btn" onclick="handlePayNumpad('5')">5</button>
                    <button type="button" class="pay-num-btn" onclick="handlePayNumpad('6')">6</button>
                    <button type="button" class="pay-num-btn" onclick="handlePayNumpad('1')">1</button>
                    <button type="button" class="pay-num-btn" onclick="handlePayNumpad('2')">2</button>
                    <button type="button" class="pay-num-btn" onclick="handlePayNumpad('3')">3</button>
                    <button type="button" class="pay-num-btn" onclick="handlePayNumpad('0')">0</button>
                    <button type="button" class="pay-num-btn" onclick="handlePayNumpad('00')">00</button>
                    <button type="button" class="pay-num-btn" id="pay-numpad-dot" onclick="handlePayNumpad('.')" data-i18n-title="payment_numpad_decimal_title" title=".">.</button>
                    <button type="button" class="pay-num-btn" onclick="handlePayNumpad('C')" style="color:var(--danger);">C</button>
                </div>

                <!-- Right: Details -->
                <div class="pay-details">
                    <div class="pay-total-block">
                        <small style="color:var(--text-muted);"><span data-i18n="payment_total_label">کۆیا گشتی</span></small>
                        <h1 id="pay-modal-total" class="pay-total-amount">0</h1>
                        <small id="pay-modal-iqd-visual" data-allow-iqd="1" style="display:none; color:var(--text-muted); margin-top:4px;"></small>
                    </div>

                    <div class="pay-method-tabs">
                        <button type="button" class="pay-method-btn active" id="pm-btn-cash" onclick="togglePayMethod('cash')"><i class="fas fa-money-bill-wave"></i> <span data-i18n="payment_tab_cash">نەقد</span></button>
                        <button type="button" class="pay-method-btn" id="pm-btn-debt" onclick="togglePayMethod('debt')"><i class="fas fa-book"></i> <span data-i18n="payment_tab_debt">قەرز</span></button>
                        <button type="button" class="pay-method-btn" id="pm-btn-bankcard" onclick="togglePayMethod('fib')"><i class="fas fa-university"></i> <span data-i18n="payment_tab_bank">FIB</span></button>
                    </div>

                    <!-- Debt Section -->
                    <div id="pay-debt-section" class="pay-debt-section">
                        <div class="pay-field-row pay-field-row-debt">
                            <label id="pay-debt-amount-label" style="font-weight:bold; color:var(--danger); white-space:nowrap;">بڕی قەرز – د.ع</label>
                            <input type="text" inputmode="numeric" id="pay-debt-amount" class="input-std pos-pay-amount-input" placeholder="0" style="text-align:center; font-weight:bold; color:var(--danger);" oninput="onPayDebtAmountInput(this)" onfocus="setActivePayInput('pay-debt-amount'); this.select()">
                        </div>
                        <input type="text" id="pay-debt-search" class="input-std" data-i18n-placeholder="payment_debt_search_placeholder" placeholder="ل ناڤێ کڕیاری بگەڕێ..." style="margin:0;" onkeyup="renderPayDebtSearch(this.value)">
                        <div id="pay-debt-list" class="pay-debt-list"></div>
                        <input type="hidden" id="pay-selected-debt-id">
                        <input type="hidden" id="pay-selected-debt-type">
                    </div>

                    <!-- Bank/Card Section -->
                    <div id="pay-bank-section" class="pay-bank-section">
                        <div class="pay-field-row pay-field-row-bank">
                            <label id="pay-bank-amount-label" style="font-weight:bold; color:#2563eb; white-space:nowrap;">FIB – د.ع</label>
                            <input type="text" inputmode="numeric" id="pay-bank-card-amount" class="input-std pos-pay-amount-input" placeholder="0" style="text-align:center; font-weight:bold; color:#2563eb;" oninput="onPayBankCardAmountInput(this)" onfocus="setActivePayInput('pay-bank-card-amount'); this.select()">
                        </div>
                    </div>

                    <!-- USD Payment Input (decimal supported: e.g. 0.66) -->
                    <div class="pay-usd-row">
                        <label style="font-weight:bold; color:#059669; white-space:nowrap;"><span data-i18n="payment_usd_row_label">پارەدان بە دۆلار ($):</span></label>
                        <input type="text" inputmode="decimal" id="pay-usd-input" class="input-std pos-pay-amount-input" placeholder="0.00" style="text-align:center; font-weight:bold; color:#059669;" oninput="onPayUsdInput(this)" onfocus="setActivePayInput('pay-usd-input'); this.select()">
                        <span id="pay-usd-rate-display" class="pay-usd-rate-text"></span>
                    </div>
                    <small id="pay-received-visual-iqd" data-allow-iqd="1" style="display:none; color:var(--text-muted); margin-top:4px;"></small>

                    <div class="pay-split-row">
                        <div class="pay-split-col pay-split-col-discount">
                            <label style="font-size:0.8rem; font-weight:bold;"><span data-i18n="payment_discount_label">داشکاندن (%)</span></label>
                            <input type="number" step="any" id="pay-discount-pct" class="input-std" placeholder="0" style="text-align:center;" oninput="calcPayModalTotals()">
                        </div>
                        <div class="pay-split-col pay-split-col-received">
                            <label id="pay-received-label" style="font-size:0.8rem; font-weight:bold;">پارەی وەرگیراو – د.ع</label>
                            <div class="pay-received-inline">
                                <input type="text" inputmode="decimal" id="pay-received" class="input-std pos-pay-amount-input" placeholder="0" style="text-align:center; font-size:1.4rem; font-weight:bold; color:var(--success);" oninput="onPayReceivedInput(this)" onkeydown="if(event.key==='Enter') confirmAdvancedPayment()" onfocus="setActivePayInput('pay-received'); this.select()">
                                <button type="button" class="btn btn-success" id="pay-toggle-usd" onclick="document.getElementById('pay-usd-input').focus(); setActivePayInput('pay-usd-input');" data-i18n-title="payment_toggle_usd_title" title="" style="padding:0 12px;"><i class="fas fa-dollar-sign"></i></button>
                                <button type="button" class="btn btn-info" id="pay-toggle-iqd" onclick="document.getElementById('pay-received').focus(); setActivePayInput('pay-received');" data-i18n-title="payment_toggle_iqd_title" title="" style="padding:0 12px;">د.ع</button>
                            </div>
                        </div>
                    </div>

                    <div class="pay-change-block">
                        <span style="color:var(--text-muted);"><span data-i18n="payment_cashback_label">گەڕاندن:</span></span>
                        <h2 id="pay-change" class="pay-change-amount">0</h2>
                        <span style="color:var(--text-muted); display:block; margin-top:8px;"><span data-i18n="payment_split_debt_label">قەرز:</span></span>
                        <h2 id="pay-debt" class="pay-change-amount" style="font-size:1.5rem;">0</h2>
                        <small id="pay-change-hint" style="display:block; margin-top:4px; font-size:0.8rem;"></small>
                    </div>

                    <button type="button" class="btn btn-success" style="width:100%; padding:15px; font-size:1.3rem;" onclick="confirmAdvancedPayment()"><i class="fas fa-check-circle"></i> <span data-i18n="payment_complete_btn">تەواوکرن</span></button>
                </div>
            </div>
        </div>
    </div>

    <!-- BILL TOTAL EDIT MODAL (manual total / discount) -->
    <div id="bill-total-edit-modal" class="modal-overlay bill-total-edit-overlay" style="display:none;" onclick="if(event.target===this&&typeof closeBillTotalEditModal==='function')closeBillTotalEditModal();">
        <div class="glass-card bill-total-edit-card" role="dialog" aria-labelledby="bill-total-edit-title">
            <div class="bill-total-edit-head">
                <h2 id="bill-total-edit-title"><i class="fas fa-tags"></i> <span data-i18n="bill_total_edit_title">دەستکارییا کۆیێ گشتی</span></h2>
                <button type="button" class="btn btn-dark btn-sm" onclick="if(typeof closeBillTotalEditModal==='function')closeBillTotalEditModal();" data-i18n-title="btn_close" title="داخستن">✖</button>
            </div>
            <p class="bill-total-edit-hint" data-i18n="bill_total_edit_hint">کۆیێ گشتی نوێ بنڤیسە — داشکاندن خۆکار دەبێت.</p>
            <div class="bill-total-edit-stats">
                <div class="bill-total-edit-stat">
                    <small data-i18n="bill_total_edit_subtotal">ژێرکۆ</small>
                    <strong id="bill-total-edit-sub">0</strong>
                </div>
                <div class="bill-total-edit-stat bill-total-edit-stat--disc">
                    <small data-i18n="bill_total_edit_discount">داشکاندن</small>
                    <strong id="bill-total-edit-disc">0</strong>
                </div>
            </div>
            <div class="bill-total-edit-layout">
                <div class="bill-total-edit-main">
                    <label for="bill-total-edit-input" class="bill-total-edit-label" data-i18n="bill_total_edit_new">کۆیێ گشتی نوێ</label>
                    <div class="bill-total-edit-step-wrap">
                        <button type="button" class="purchase-price-nudge purchase-total-nudge bill-total-edit-nudge" onclick="if(typeof nudgeBillTotalEdit==='function')nudgeBillTotalEdit(-1)" title="کێمکرنا کۆم" aria-label="کێمکرنا کۆم"><i class="fas fa-minus"></i></button>
                        <input type="text" inputmode="decimal" id="bill-total-edit-input" class="bill-total-edit-input input-std" autocomplete="off" spellcheck="false" oninput="if(typeof updateBillTotalEditPreview==='function')updateBillTotalEditPreview();">
                        <button type="button" class="purchase-price-nudge purchase-total-nudge bill-total-edit-nudge" onclick="if(typeof nudgeBillTotalEdit==='function')nudgeBillTotalEdit(1)" title="زێدەکرنا کۆم" aria-label="زێدەکرنا کۆم"><i class="fas fa-plus"></i></button>
                    </div>
                    <small id="bill-total-edit-currency-hint" class="bill-total-edit-currency-hint"></small>
                </div>
                <div class="pay-numpad bill-total-edit-numpad" dir="ltr">
                    <button type="button" class="pay-num-btn" onclick="handleBillTotalEditNumpad('7')">7</button>
                    <button type="button" class="pay-num-btn" onclick="handleBillTotalEditNumpad('8')">8</button>
                    <button type="button" class="pay-num-btn" onclick="handleBillTotalEditNumpad('9')">9</button>
                    <button type="button" class="pay-num-btn" onclick="handleBillTotalEditNumpad('4')">4</button>
                    <button type="button" class="pay-num-btn" onclick="handleBillTotalEditNumpad('5')">5</button>
                    <button type="button" class="pay-num-btn" onclick="handleBillTotalEditNumpad('6')">6</button>
                    <button type="button" class="pay-num-btn" onclick="handleBillTotalEditNumpad('1')">1</button>
                    <button type="button" class="pay-num-btn" onclick="handleBillTotalEditNumpad('2')">2</button>
                    <button type="button" class="pay-num-btn" onclick="handleBillTotalEditNumpad('3')">3</button>
                    <button type="button" class="pay-num-btn" onclick="handleBillTotalEditNumpad('0')">0</button>
                    <button type="button" class="pay-num-btn" onclick="handleBillTotalEditNumpad('00')">00</button>
                    <button type="button" class="pay-num-btn" id="bill-total-edit-dot" onclick="handleBillTotalEditNumpad('.')">.</button>
                    <button type="button" class="pay-num-btn bill-total-edit-clear" onclick="handleBillTotalEditNumpad('C')">C</button>
                </div>
            </div>
            <div class="bill-total-edit-actions">
                <button type="button" class="btn btn-dark" onclick="if(typeof closeBillTotalEditModal==='function')closeBillTotalEditModal();"><i class="fas fa-times"></i> <span data-i18n="btn_cancel">پاشگەزبوونەوە</span></button>
                <button type="button" class="btn btn-success bill-total-edit-save" onclick="if(typeof confirmBillTotalEdit==='function')confirmBillTotalEdit();"><i class="fas fa-check"></i> <span data-i18n="bill_total_edit_save">پاراستن</span></button>
            </div>
        </div>
    </div>

    <!-- PURCHASE PAYMENT MODAL (same layout as sales payment modal) -->
    <div id="purchase-payment-modal" class="modal-overlay" style="display:none;">
        <div class="glass-card pay-modal-glass">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
                <h2 style="margin:0; color:var(--brand);"><i class="fas fa-cash-register"></i> <span data-i18n="payment_modal_title">وەرگرتنا پارەی</span></h2>
                <button type="button" class="btn btn-dark btn-sm" onclick="closePurchasePaymentModal()" data-i18n-title="btn_close" title="داخستن">✖</button>
            </div>
            
            <div class="pay-modal-layout">
                <div class="pay-numpad">
                    <button type="button" class="pay-num-btn" onclick="handlePurchasePayNumpad('7')">7</button>
                    <button type="button" class="pay-num-btn" onclick="handlePurchasePayNumpad('8')">8</button>
                    <button type="button" class="pay-num-btn" onclick="handlePurchasePayNumpad('9')">9</button>
                    <button type="button" class="pay-num-btn" onclick="handlePurchasePayNumpad('4')">4</button>
                    <button type="button" class="pay-num-btn" onclick="handlePurchasePayNumpad('5')">5</button>
                    <button type="button" class="pay-num-btn" onclick="handlePurchasePayNumpad('6')">6</button>
                    <button type="button" class="pay-num-btn" onclick="handlePurchasePayNumpad('1')">1</button>
                    <button type="button" class="pay-num-btn" onclick="handlePurchasePayNumpad('2')">2</button>
                    <button type="button" class="pay-num-btn" onclick="handlePurchasePayNumpad('3')">3</button>
                    <button type="button" class="pay-num-btn" onclick="handlePurchasePayNumpad('0')">0</button>
                    <button type="button" class="pay-num-btn" onclick="handlePurchasePayNumpad('00')">00</button>
                    <button type="button" class="pay-num-btn" id="ppay-numpad-dot" onclick="handlePurchasePayNumpad('.')" data-i18n-title="payment_numpad_decimal_title" title=".">.</button>
                    <button type="button" class="pay-num-btn" onclick="handlePurchasePayNumpad('C')" style="color:var(--danger);">C</button>
                </div>

                <div class="pay-details">
                    <div class="pay-total-block">
                        <small style="color:var(--text-muted);"><span data-i18n="payment_total_label">کۆیا گشتی</span></small>
                        <h1 id="ppay-modal-total" class="pay-total-amount">0</h1>
                    </div>

                    <div class="pay-method-tabs">
                        <button type="button" class="pay-method-btn active" id="ppm-btn-cash" onclick="togglePurchasePayMethod('cash')"><i class="fas fa-money-bill-wave"></i> <span data-i18n="payment_tab_cash">نەقد</span></button>
                        <button type="button" class="pay-method-btn" id="ppm-btn-debt" onclick="togglePurchasePayMethod('debt')"><i class="fas fa-book"></i> <span data-i18n="payment_tab_debt">قەرز</span></button>
                        <button type="button" class="pay-method-btn" id="ppm-btn-bankcard" onclick="togglePurchasePayMethod('fib')"><i class="fas fa-university"></i> <span data-i18n="payment_tab_bank">FIB</span></button>
                    </div>

                    <div id="ppay-debt-section" class="pay-debt-section">
                        <div class="pay-field-row pay-field-row-debt">
                            <label id="ppay-debt-amount-label" style="font-weight:bold; color:var(--danger); white-space:nowrap;">بڕی قەرز – د.ع</label>
                            <input type="text" inputmode="numeric" id="ppay-debt-amount" class="input-std pos-pay-amount-input" placeholder="0" style="text-align:center; font-weight:bold; color:var(--danger);" oninput="onPPayDebtAmountInput(this)" onfocus="setActivePurchasePayInput('ppay-debt-amount'); this.select()">
                        </div>
                        <input type="text" id="ppay-debt-search" class="input-std" data-i18n-placeholder="payment_purchase_debt_search_ph" placeholder="ناڤێ کۆمپانیایێ بنڤیسە..." style="margin:0;" onkeyup="renderPurchasePayDebtSearch(this.value)">
                        <div id="ppay-debt-list" class="pay-debt-list"></div>
                        <input type="hidden" id="ppay-selected-debt-id">
                        <input type="hidden" id="ppay-selected-debt-type">
                    </div>

                    <div id="ppay-bank-section" class="pay-bank-section">
                        <div class="pay-field-row pay-field-row-bank">
                            <label id="ppay-bank-amount-label" style="font-weight:bold; color:#2563eb; white-space:nowrap;">FIB – د.ع</label>
                            <input type="text" inputmode="numeric" id="ppay-bank-card-amount" class="input-std pos-pay-amount-input" placeholder="0" style="text-align:center; font-weight:bold; color:#2563eb;" oninput="onPPayBankCardAmountInput(this)" onfocus="setActivePurchasePayInput('ppay-bank-card-amount'); this.select()">
                        </div>
                    </div>

                    <div class="pay-usd-row">
                        <label style="font-weight:bold; color:#059669; white-space:nowrap;"><span data-i18n="payment_usd_row_label">پارەدان بە دۆلار ($):</span></label>
                        <input type="text" inputmode="decimal" id="ppay-usd-input" class="input-std pos-pay-amount-input" placeholder="0.00" style="text-align:center; font-weight:bold; color:#059669;" oninput="onPPayUsdInput(this)" onfocus="setActivePurchasePayInput('ppay-usd-input'); this.select()">
                        <span id="ppay-usd-rate-display" class="pay-usd-rate-text"></span>
                    </div>

                    <div class="pay-split-row">
                        <div class="pay-split-col pay-split-col-discount">
                            <label style="font-size:0.8rem; font-weight:bold;"><span data-i18n="payment_discount_label">داشکاندن (%)</span></label>
                            <input type="number" step="any" id="ppay-discount-pct" class="input-std" placeholder="0" style="text-align:center;" oninput="calcPurchasePayModalTotals()">
                        </div>
                        <div class="pay-split-col pay-split-col-received">
                            <label id="ppay-received-label" style="font-size:0.8rem; font-weight:bold;">پارەی وەرگیراو – د.ع</label>
                            <div class="pay-received-inline">
                                <input type="text" inputmode="decimal" id="ppay-received" class="input-std pos-pay-amount-input" placeholder="0" style="text-align:center; font-size:1.4rem; font-weight:bold; color:var(--success);" oninput="onPPayReceivedInput(this)" onkeydown="if(event.key==='Enter') confirmPurchaseAdvancedPayment()" onfocus="setActivePurchasePayInput('ppay-received'); this.select()">
                                <button type="button" class="btn btn-success" id="ppay-toggle-usd" onclick="document.getElementById('ppay-usd-input').focus(); setActivePurchasePayInput('ppay-usd-input');" data-i18n-title="payment_toggle_usd_title" title="" style="padding:0 12px;"><i class="fas fa-dollar-sign"></i></button>
                                <button type="button" class="btn btn-info" id="ppay-toggle-iqd" onclick="document.getElementById('ppay-received').focus(); setActivePurchasePayInput('ppay-received');" data-i18n-title="payment_toggle_iqd_title" title="" style="padding:0 12px;">د.ع</button>
                            </div>
                        </div>
                    </div>

                    <div class="pay-change-block">
                        <span style="color:var(--text-muted);"><span data-i18n="payment_purchase_remainder_label">باقی/گەڕاندن:</span></span>
                        <h2 id="ppay-change" class="pay-change-amount">0</h2>
                        <small id="ppay-change-hint" style="display:block; margin-top:4px; font-size:0.8rem;"></small>
                    </div>

                    <button type="button" class="btn btn-success" style="width:100%; padding:15px; font-size:1.3rem;" onclick="confirmPurchaseAdvancedPayment()"><i class="fas fa-check-circle"></i> <span data-i18n="payment_complete_btn">تەواوکرن</span></button>
                </div>
            </div>
        </div>
    </div>

    <!-- USER PROFILE MODAL (ADVANCED) -->
    <div id="user-profile-modal" class="profile-modal" translate="no">
        <div class="profile-content staff-profile-content">
            <div class="profile-header staff-profile-header">
                <div class="staff-profile-user">
                    <h2 class="staff-profile-title"><i class="fas fa-id-badge"></i> <span id="up-name-display">User</span></h2>
                    <small id="up-role-display" class="staff-profile-role"></small>
                </div>
                <button class="staff-profile-close-btn" onclick="document.getElementById('user-profile-modal').style.display='none'"><i class="fas fa-times"></i></button>
            </div>
            <div class="profile-tabs staff-profile-tabs">
                <button id="tab-btn-u-overview" type="button" class="tab-btn active" onclick="switchUserTab('u-overview')"><i class="fas fa-chart-pie"></i> <span data-i18n="profile_tab_overview"></span></button>
                <button id="tab-btn-u-shifts" type="button" class="tab-btn" onclick="switchUserTab('u-shifts')"><i class="fas fa-clock"></i> <span data-i18n="profile_tab_shifts"></span></button>
                <button id="tab-btn-u-financials" type="button" class="tab-btn" onclick="switchUserTab('u-financials')"><i class="fas fa-wallet"></i> <span data-i18n="profile_tab_financials"></span></button>
                <button id="tab-btn-u-activity" type="button" class="tab-btn" onclick="switchUserTab('u-activity')"><i class="fas fa-stream"></i> <span data-i18n="profile_tab_activity"></span></button>
                <button id="tab-btn-u-settings" type="button" class="tab-btn" onclick="switchUserTab('u-settings')"><i class="fas fa-sliders-h"></i> <span data-i18n="profile_tab_settings"></span></button>
            </div>
            
            <!-- TAB 1: OVERVIEW -->
            <div id="tab-u-overview" class="tab-content active staff-profile-tab">
                <div class="stat-grid staff-profile-stat-grid">
                    <div class="stat-card staff-profile-stat-card is-sales">
                        <h3><i class="fas fa-shopping-cart"></i> <span data-i18n="profile_stat_total_sales"></span></h3>
                        <h1 id="up-total-sales">0</h1>
                    </div>
                    <div class="stat-card staff-profile-stat-card is-hours">
                        <h3><i class="fas fa-clock"></i> <span data-i18n="profile_stat_total_hours"></span></h3>
                        <h1 id="up-total-hours">0</h1>
                    </div>
                    <div class="stat-card staff-profile-stat-card is-debt">
                        <h3><i class="fas fa-hand-holding-usd"></i> <span data-i18n="profile_stat_current_debt"></span></h3>
                        <h1 id="up-current-debt">0</h1>
                    </div>
                    <div class="stat-card staff-profile-stat-card is-salary">
                        <h3><i class="fas fa-money-bill-wave"></i> <span data-i18n="profile_stat_est_salary"></span></h3>
                        <h1 id="up-est-salary">0</h1>
                    </div>
                    <div class="stat-card staff-profile-stat-card is-salary-paid">
                        <h3><i class="fas fa-user-tie"></i> <span data-i18n="profile_stat_salary_paid">مووچەی دراو</span></h3>
                        <h1 id="up-salary-paid-card">0</h1>
                    </div>
                    <div class="stat-card staff-profile-stat-card is-advance-paid">
                        <h3><i class="fas fa-hand-holding-usd"></i> <span data-i18n="profile_stat_advance_paid">نزبا</span></h3>
                        <h1 id="up-advance-paid-card">0</h1>
                    </div>
                </div>

                <div class="staff-profile-fin-grid staff-profile-ov-pay-split">
                    <div class="card staff-profile-sub-card staff-profile-ov-pay-card is-salary">
                        <h3 data-i18n="profile_ov_salary_title">مووچەی دراو</h3>
                        <p class="staff-profile-sub-hint" data-i18n="profile_ov_salary_hint">مووچێ هەیفانە یێ ژ قاسێ هاتە دان</p>
                        <div class="staff-profile-table-wrap">
                            <table class="report-table">
                                <thead><tr><th data-i18n="profile_th_date"></th><th data-i18n="profile_th_note"></th><th data-i18n="profile_th_amount"></th></tr></thead>
                                <tbody id="up-ov-salary-list"></tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card staff-profile-sub-card staff-profile-ov-pay-card is-advance">
                        <h3 data-i18n="profile_ov_advance_title">نزبا یا کاری</h3>
                        <p class="staff-profile-sub-hint" data-i18n="profile_ov_advance_hint">پارێ ڕۆژانە یێ ژ قاسێ هاتە دان</p>
                        <div class="staff-profile-table-wrap">
                            <table class="report-table">
                                <thead><tr><th data-i18n="profile_th_date"></th><th data-i18n="profile_th_note"></th><th data-i18n="profile_th_amount"></th></tr></thead>
                                <tbody id="up-ov-advance-list"></tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="card staff-profile-range-card">
                    <h3 class="staff-profile-period-title"><i class="fas fa-filter"></i> <span data-i18n="profile_range_title">گەڕان بە مەودای بەروار</span></h3>
                    <div class="staff-profile-range-controls">
                        <label class="staff-profile-range-field">
                            <span data-i18n="profile_range_from">لە مانگ:</span>
                            <input type="month" id="up-range-from" class="input-std staff-profile-range-input">
                        </label>
                        <label class="staff-profile-range-field">
                            <span data-i18n="profile_range_to">تا مانگ:</span>
                            <input type="month" id="up-range-to" class="input-std staff-profile-range-input">
                        </label>
                        <button type="button" class="btn btn-primary staff-profile-range-btn" onclick="applyStaffProfileRange()">
                            <i class="fas fa-search"></i> <span data-i18n="profile_range_apply">نیشاندان</span>
                        </button>
                    </div>
                    <div id="up-range-label" class="staff-profile-period-badge is-range"></div>
                    <div class="staff-profile-period-stats staff-profile-range-stats">
                        <div class="staff-profile-period-stat"><span data-i18n="profile_period_hours">کاتژمێر</span><strong id="up-range-hours">—</strong></div>
                        <div class="staff-profile-period-stat"><span data-i18n="profile_period_sales">فرۆتن</span><strong id="up-range-sales">—</strong></div>
                        <div class="staff-profile-period-stat"><span data-i18n="profile_period_invoices">وەسڵ</span><strong id="up-range-invoices">—</strong></div>
                        <div class="staff-profile-period-stat"><span data-i18n="profile_period_shifts">شیفت</span><strong id="up-range-shifts">—</strong></div>
                        <div class="staff-profile-period-stat"><span data-i18n="profile_period_salary">مووچە</span><strong id="up-range-salary">—</strong></div>
                        <div class="staff-profile-period-stat"><span data-i18n="profile_period_advance">نزبا</span><strong id="up-range-advance">—</strong></div>
                        <div class="staff-profile-period-stat"><span data-i18n="profile_period_salary_paid">مووچەی دراو</span><strong id="up-range-salary-paid">—</strong></div>
                    </div>
                    <div id="up-range-yearly-wrap" class="staff-profile-range-yearly" style="display:none;">
                        <h4 data-i18n="profile_range_yearly_title">کۆی ساڵانە</h4>
                        <div id="up-range-yearly-grid" class="staff-profile-range-yearly-grid"></div>
                    </div>
                    <h4 class="staff-profile-range-subtitle" data-i18n="profile_range_monthly_title">وردەکاری بەپێی مانگ</h4>
                    <div class="staff-profile-table-wrap is-short">
                        <table class="report-table">
                            <thead>
                                <tr>
                                    <th data-i18n="profile_range_th_year">ساڵ</th>
                                    <th data-i18n="profile_range_th_month">مانگ</th>
                                    <th data-i18n="profile_period_hours">کاتژمێر</th>
                                    <th data-i18n="profile_period_sales">فرۆتن</th>
                                    <th data-i18n="profile_period_shifts">شیفت</th>
                                    <th data-i18n="profile_period_salary">مووچە</th>
                                    <th data-i18n="profile_period_advance">نزبا</th>
                                    <th data-i18n="profile_period_salary_paid">مووچەی دراو</th>
                                </tr>
                            </thead>
                            <tbody id="up-range-monthly-body"></tbody>
                        </table>
                    </div>
                </div>

                <div class="staff-profile-period-grid">
                    <div class="card staff-profile-period-card">
                        <h3 class="staff-profile-period-title"><i class="fas fa-calendar-alt"></i> <span data-i18n="profile_month_this">ئەم مانگە</span></h3>
                        <div id="up-month-this-label" class="staff-profile-period-badge"></div>
                        <div class="staff-profile-period-stats">
                            <div class="staff-profile-period-stat"><span data-i18n="profile_period_hours">کاتژمێر</span><strong id="up-month-this-hours">0</strong></div>
                            <div class="staff-profile-period-stat"><span data-i18n="profile_period_sales">فرۆتن</span><strong id="up-month-this-sales">0</strong></div>
                            <div class="staff-profile-period-stat"><span data-i18n="profile_period_shifts">شیفت</span><strong id="up-month-this-shifts">0</strong></div>
                            <div class="staff-profile-period-stat"><span data-i18n="profile_period_salary">مووچە</span><strong id="up-month-this-salary">0</strong></div>
                            <div class="staff-profile-period-stat"><span data-i18n="profile_period_advance">نزبا</span><strong id="up-month-this-advance">0</strong></div>
                            <div class="staff-profile-period-stat"><span data-i18n="profile_period_salary_paid">مووچەی دراو</span><strong id="up-month-this-salary-paid">0</strong></div>
                        </div>
                    </div>
                    <div class="card staff-profile-period-card">
                        <h3 class="staff-profile-period-title"><i class="fas fa-history"></i> <span data-i18n="profile_month_prev">مانگی پێشوو</span></h3>
                        <div id="up-month-prev-label" class="staff-profile-period-badge"></div>
                        <div class="staff-profile-period-stats">
                            <div class="staff-profile-period-stat"><span data-i18n="profile_period_hours">کاتژمێر</span><strong id="up-month-prev-hours">0</strong></div>
                            <div class="staff-profile-period-stat"><span data-i18n="profile_period_sales">فرۆتن</span><strong id="up-month-prev-sales">0</strong></div>
                            <div class="staff-profile-period-stat"><span data-i18n="profile_period_shifts">شیفت</span><strong id="up-month-prev-shifts">0</strong></div>
                            <div class="staff-profile-period-stat"><span data-i18n="profile_period_salary">مووچە</span><strong id="up-month-prev-salary">0</strong></div>
                            <div class="staff-profile-period-stat"><span data-i18n="profile_period_advance">نزبا</span><strong id="up-month-prev-advance">0</strong></div>
                            <div class="staff-profile-period-stat"><span data-i18n="profile_period_salary_paid">مووچەی دراو</span><strong id="up-month-prev-salary-paid">0</strong></div>
                        </div>
                    </div>
                </div>

                <div class="card staff-profile-yesterday-card staff-profile-today-card">
                    <h3><i class="fas fa-sun"></i> <span data-i18n="profile_today_detail">وردەکاریی ئەڤرۆ</span></h3>
                    <div id="up-today-label" class="staff-profile-period-badge is-today"></div>
                    <div class="staff-profile-period-stats staff-profile-yesterday-stats">
                        <div class="staff-profile-period-stat"><span data-i18n="profile_period_hours">کاتژمێر</span><strong id="up-today-hours">0</strong></div>
                        <div class="staff-profile-period-stat"><span data-i18n="profile_period_sales">فرۆتن</span><strong id="up-today-sales">0</strong></div>
                        <div class="staff-profile-period-stat"><span data-i18n="profile_period_invoices">وەسڵ</span><strong id="up-today-invoices">0</strong></div>
                        <div class="staff-profile-period-stat"><span data-i18n="profile_period_shifts">شیفت</span><strong id="up-today-shifts">0</strong></div>
                    </div>
                    <div id="up-today-detail-list" class="staff-profile-yesterday-list"></div>
                </div>

                <div class="card staff-profile-yesterday-card">
                    <h3><i class="fas fa-calendar-day"></i> <span data-i18n="profile_yesterday_detail">وردەکاریی دوێنێ</span></h3>
                    <div id="up-yesterday-label" class="staff-profile-period-badge is-yesterday"></div>
                    <div class="staff-profile-period-stats staff-profile-yesterday-stats">
                        <div class="staff-profile-period-stat"><span data-i18n="profile_period_hours">کاتژمێر</span><strong id="up-yesterday-hours">0</strong></div>
                        <div class="staff-profile-period-stat"><span data-i18n="profile_period_sales">فرۆتن</span><strong id="up-yesterday-sales">0</strong></div>
                        <div class="staff-profile-period-stat"><span data-i18n="profile_period_invoices">وەسڵ</span><strong id="up-yesterday-invoices">0</strong></div>
                        <div class="staff-profile-period-stat"><span data-i18n="profile_period_shifts">شیفت</span><strong id="up-yesterday-shifts">0</strong></div>
                    </div>
                    <div id="up-yesterday-detail-list" class="staff-profile-yesterday-list"></div>
                </div>

                <div class="card staff-profile-chart-card">
                    <h3 data-i18n="profile_perf_title"></h3>
                    <canvas id="userPerformanceChart" class="staff-profile-chart"></canvas>
                </div>
            </div>

            <!-- TAB 2: SHIFTS -->
            <div id="tab-u-shifts" class="tab-content staff-profile-tab">
                <h3 data-i18n="profile_shifts_history"></h3>
                <div class="staff-profile-table-wrap">
                    <table class="report-table">
                        <thead><tr><th data-i18n="profile_shift_th_date"></th><th data-i18n="profile_shift_th_start"></th><th data-i18n="profile_shift_th_end"></th><th data-i18n="profile_shift_th_duration"></th><th data-i18n="profile_shift_th_salary"></th></tr></thead>
                        <tbody id="up-shifts-list"></tbody>
                    </table>
                </div>
            </div>

            <!-- TAB 3: FINANCIALS -->
            <div id="tab-u-financials" class="tab-content staff-profile-tab">
                <div class="card staff-profile-sub-card" style="margin-bottom:16px;">
                    <h3 data-i18n="profile_fin_debt_title"></h3>
                    <p class="staff-profile-sub-hint" data-i18n="profile_fin_debt_hint"></p>
                    <div class="staff-profile-table-wrap is-short">
                        <table class="report-table">
                            <thead><tr><th data-i18n="profile_th_date"></th><th data-i18n="profile_th_item"></th><th data-i18n="profile_th_total"></th></tr></thead>
                            <tbody id="up-debt-items-list"></tbody>
                        </table>
                    </div>
                </div>
                <div class="staff-profile-fin-grid">
                    <div class="card staff-profile-sub-card staff-profile-ov-pay-card is-salary">
                        <h3 data-i18n="profile_ov_salary_title">مووچەی دراو</h3>
                        <p class="staff-profile-sub-hint" data-i18n="profile_ov_salary_hint">مووچێ هەیفانە یێ ژ قاسێ هاتە دان</p>
                        <div class="staff-profile-table-wrap is-short">
                            <table class="report-table">
                                <thead><tr><th data-i18n="profile_th_date"></th><th data-i18n="profile_th_note"></th><th data-i18n="profile_th_amount"></th></tr></thead>
                                <tbody id="up-fin-salary-list"></tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card staff-profile-sub-card staff-profile-ov-pay-card is-advance">
                        <h3 data-i18n="profile_ov_advance_title">نزبا یا کاری</h3>
                        <p class="staff-profile-sub-hint" data-i18n="profile_ov_advance_hint">پارێ ڕۆژانە یێ ژ قاسێ هاتە دان</p>
                        <div class="staff-profile-table-wrap is-short">
                            <table class="report-table">
                                <thead><tr><th data-i18n="profile_th_date"></th><th data-i18n="profile_th_note"></th><th data-i18n="profile_th_amount"></th></tr></thead>
                                <tbody id="up-fin-advance-list"></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- TAB 4: ACTIVITY -->
            <div id="tab-u-activity" class="tab-content staff-profile-tab">
                <h3 data-i18n="staff_tab_activity_title"></h3>
                <div id="up-activity-list" class="staff-profile-activity-list"></div>
            </div>

            <!-- TAB 5: SETTINGS -->
            <div id="tab-u-settings" class="tab-content">
                <div class="card" style="max-width:600px; margin:0 auto;">
                    <h3 data-i18n="staff_profile_edit_title"></h3>
                    <input type="hidden" id="edit-u-id">
                    <label><span data-i18n="staff_label_name"></span></label><input type="text" id="edit-u-name" class="input-std">
                    <label><span data-i18n="staff_label_pin_new"></span></label><input type="text" id="edit-u-pin" class="input-std" inputmode="numeric" maxlength="4" pattern="[0-9]*" autocomplete="off" data-i18n-placeholder="staff_pin_keep_placeholder" oninput="this.value=this.value.replace(/\D/g,'').slice(0,4)">
                    <label><span data-i18n="staff_label_role"></span></label>
                    <select id="edit-u-role" class="input-std" onchange="toggleEditPermissions(true)">
                        <option value="admin" data-i18n-opt="role_option_admin"></option>
                        <option value="manager" data-i18n-opt="role_option_manager"></option>
                        <option value="supervisor" data-i18n-opt="role_option_supervisor"></option>
                        <option value="cashier" data-i18n-opt="role_option_cashier"></option>
                        <option value="stock_manager" data-i18n-opt="role_option_stock_manager"></option>
                        <option value="inventory_clerk" data-i18n-opt="role_option_inventory_clerk"></option>
                        <option value="accountant" data-i18n-opt="role_option_accountant"></option>
                        <option value="finance_viewer" data-i18n-opt="role_option_finance_viewer"></option>
                        <option value="sales_rep" data-i18n-opt="role_option_sales_rep"></option>
                        <option value="sales_viewer" data-i18n-opt="role_option_sales_viewer"></option>
                        <option value="waiter" data-i18n-opt="role_option_waiter"></option>
                    </select>
                    <label><span data-i18n="staff_label_rate"></span></label><input type="number" id="edit-u-rate" class="input-std">
                    
                    <div id="edit-perms-container" style="background:var(--input-bg); padding:15px; border-radius:10px; border:1px solid var(--border); margin-bottom:20px;">
                        <h4 style="margin-top:0; color:var(--brand);"><span data-i18n="staff_perm_heading"></span></h4>

                        <!-- HIGHLIGHTED: PROFIT VISIBILITY -->
                        <div style="background:linear-gradient(135deg, rgba(239,68,68,0.12), rgba(245,158,11,0.08)); border:2px solid #ef4444; border-radius:12px; padding:12px; margin-bottom:12px;">
                            <label style="display:flex; align-items:center; gap:10px; cursor:pointer; font-weight:bold;">
                                <input type="checkbox" class="edit-perm-chk" value="view_profit" style="width:20px; height:20px; accent-color:#ef4444;">
                                <span style="font-size:1rem; color:#ef4444;" data-i18n="staff_perm_view_profit_title"></span>
                            </label>
                            <small style="display:block; margin-top:6px; color:var(--text-muted); padding-right:30px;" data-i18n="staff_perm_view_profit_hint"></small>
                        </div>
                        <div style="background:linear-gradient(135deg, rgba(217,119,6,0.12), rgba(245,158,11,0.06)); border:2px solid #d97706; border-radius:12px; padding:12px; margin-bottom:12px;">
                            <label style="display:flex; align-items:center; gap:10px; cursor:pointer; font-weight:bold;">
                                <input type="checkbox" class="edit-perm-chk" value="view_cost" style="width:20px; height:20px; accent-color:#d97706;">
                                <span style="font-size:1rem; color:#d97706;" data-i18n="staff_perm_view_cost_title"></span>
                            </label>
                            <small style="display:block; margin-top:6px; color:var(--text-muted); padding-right:30px;" data-i18n="staff_perm_view_cost_hint"></small>
                        </div>

                        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:8px; font-size:0.9rem; max-height:320px; overflow-y:auto;">
                            <div class="perm-group-title"><span data-i18n="staff_perm_grp_visible"></span></div>
                            <label><input type="checkbox" class="edit-perm-chk" value="pos_access"> <span data-i18n="perm_pos_access"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="warehouse_view"> <span data-i18n="perm_warehouse_view"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="products_manage"> <span data-i18n="perm_products_manage"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="companies_manage"> <span data-i18n="perm_companies_manage"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="debt_view"> <span data-i18n="perm_debt_view"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="expenses_manage"> <span data-i18n="perm_expenses_manage"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="waste_manage"> <span data-i18n="perm_waste_manage"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="recipes_manage"> <span data-i18n="perm_recipes_manage"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="delivery_view"> <span data-i18n="perm_delivery_view"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="reports_view"> <span data-i18n="perm_reports_view"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="view_daily_summary"> <span data-i18n="perm_view_daily_summary"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="send_telegram_report"> <span data-i18n="perm_send_telegram_report"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="view_sales_history"> <span data-i18n="perm_view_sales_history"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="view_purchase_history"> <span data-i18n="perm_view_purchase_history"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="returns_manage"> <span data-i18n="perm_returns_manage"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="edit_staff"> <span data-i18n="perm_edit_staff"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="access_settings"> <span data-i18n="perm_access_settings"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="manage_printers"> <span data-i18n="perm_manage_printers"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="view_audit_logs"> <span data-i18n="perm_view_audit_logs"></span></label>

                            <div class="perm-group-title"><span data-i18n="staff_perm_grp_pos"></span></div>
                            <label><input type="checkbox" class="edit-perm-chk" value="pos_sell"> <span data-i18n="perm_pos_sell"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="pos_discount"> <span data-i18n="perm_pos_discount"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="pos_price"> <span data-i18n="perm_pos_price"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="pos_delete_item"> <span data-i18n="perm_pos_delete_item"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="pos_void_invoice"> <span data-i18n="perm_pos_void_invoice"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="pos_open_drawer"> <span data-i18n="perm_pos_open_drawer"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="pos_kitchen"> <span data-i18n="perm_pos_kitchen"></span></label>

                            <div class="perm-group-title"><span data-i18n="staff_perm_grp_wh"></span></div>
                            <label class="perm-multi-warehouse-wrap"><input type="checkbox" class="edit-perm-chk" value="multi_warehouse"> <span data-i18n="perm_multi_warehouse"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="stock_view"> <span data-i18n="perm_stock_view"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="stock_edit"> <span data-i18n="perm_stock_edit"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="stock_delete"> <span data-i18n="perm_stock_delete"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="stock_audit"> <span data-i18n="perm_stock_audit"></span></label>

                            <div class="perm-group-title"><span data-i18n="staff_perm_grp_fin"></span></div>
                            <label><input type="checkbox" class="edit-perm-chk" value="view_expenses"> <span data-i18n="perm_view_expenses"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="debt_manage"> <span data-i18n="perm_debt_manage"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="manage_debts"> <span data-i18n="perm_manage_debts"></span></label>
                            <label><input type="checkbox" class="edit-perm-chk" value="set_exchange_rate"> <span data-i18n="perm_set_exchange_rate"></span></label>
                        </div>
                    </div>
                    <button type="button" class="btn btn-dark" style="width:100%; margin-bottom:10px;" onclick="toggleEditPermissions(true)"><i class="fas fa-redo"></i> <span data-i18n="staff_apply_role_template">گەڕاندن بۆ بنەڕەتی ئەم ڕۆڵە</span></button>
                    <button class="btn btn-success" style="width:100%;" onclick="saveUserProfile()"><i class="fas fa-save"></i> <span data-i18n="btn_save"></span></button>
                </div>
            </div>
        </div>
    </div>

    <!-- POS confirm dialog (replaces browser confirm) -->
    <div id="pos-confirm-modal" class="modal-overlay pos-confirm-overlay" style="display:none;" role="dialog" aria-modal="true" aria-labelledby="pos-confirm-title">
        <div class="pos-confirm-card">
            <div class="pos-confirm-icon" id="pos-confirm-icon-wrap"><i class="fas fa-question-circle" aria-hidden="true"></i></div>
            <h3 id="pos-confirm-title" class="pos-confirm-title">دڵنیایت؟</h3>
            <p id="pos-confirm-message" class="pos-confirm-message"></p>
            <div id="pos-confirm-phrase-wrap" class="pos-confirm-phrase-wrap" style="display:none;">
                <label id="pos-confirm-phrase-label" class="pos-confirm-phrase-label" for="pos-confirm-phrase-input"></label>
                <div id="pos-confirm-phrase-source" class="pos-confirm-phrase-source" style="display:none;">
                    <p id="pos-confirm-phrase-source-text" class="pos-confirm-phrase-source-text"></p>
                    <button type="button" id="pos-confirm-phrase-copy" class="btn pos-confirm-phrase-copy"><i class="fas fa-copy" aria-hidden="true"></i> <span id="pos-confirm-phrase-copy-label">کۆپی</span></button>
                </div>
                <textarea id="pos-confirm-phrase-input" class="pos-confirm-phrase-input input-std" rows="1" autocomplete="off" autocapitalize="off" spellcheck="false" dir="rtl"></textarea>
            </div>
            <div class="pos-confirm-actions">
                <button type="button" id="pos-confirm-cancel" class="btn pos-confirm-btn pos-confirm-btn--cancel"><span data-i18n="btn_cancel">پاشگەزبوون</span></button>
                <div id="pos-confirm-choices" class="pos-confirm-choices" style="display:none;"></div>
                <button type="button" id="pos-confirm-ok" class="btn btn-dark pos-confirm-btn"><span data-i18n="btn_confirm">بەڵێ</span></button>
            </div>
        </div>
    </div>

    <!-- SECURITY CENTER MODAL -->
    <div id="security-modal" class="modal-overlay" style="display:none; backdrop-filter: blur(15px);">
        <div class="security-modal-content">
            <div class="sec-header">
                <h2 style="margin:0; color:#38bdf8;"><i class="fas fa-shield-alt"></i> سەنتەرێ ئاسایشێ (Security Center)</h2>
                <button class="btn btn-danger btn-sm" onclick="document.getElementById('security-modal').style.display='none'">✖</button>
            </div>
            <div style="padding: 15px; background: #1e293b; border-bottom: 1px solid #334155; display: flex; gap: 10px; flex-wrap: wrap; align-items: center;">
                <input type="text" id="sec-search" class="input-std" placeholder="🔍 لێگەریان (Search Logs)..." style="margin:0; flex:1; min-width:160px; background: #0f172a; border-color: #475569; color: white;" onkeyup="renderSecurityLogs()">
                <select id="sec-filter" class="input-std" style="margin:0; width: 200px; background: #0f172a; border-color: #475569; color: white;" onchange="renderSecurityLogs()">
                    <option value="all">هەمی (All)</option>
                    <option value="staff">👤 کارمەند</option>
                    <option value="price">💰 نرخ / داشکاندن</option>
                    <option value="product">کەلوپەل / ئایتم</option>
                    <option value="waste">تەلەف</option>
                    <option value="settings">ڕێکخستن</option>
                    <option value="alert">⚠️ مەترسی (Alerts)</option>
                    <option value="delete">ژێبرن (Delete)</option>
                    <option value="edit">دەستکاری (Edit)</option>
                    <option value="login">چوونەژوور (Login)</option>
                    <option value="sale">فرۆتن (Sales)</option>
                </select>
                <button type="button" class="btn btn-sm btn-info" onclick="if(typeof refreshAuditLogs==='function')refreshAuditLogs(function(){renderSecurityLogs();});" title="نوێکردنەوەی تۆمارەکان لە سێرڤەر"><i class="fas fa-sync-alt"></i></button>
            </div>
            <div id="security-logs-body" class="sec-body">
                <!-- Logs go here -->
            </div>
        </div>
    </div>

    <!-- SECRET PIN + optional Telegram group invite (dismissible) -->
    <div id="secret-pin-modal" class="modal-overlay" style="display:none; backdrop-filter: blur(10px); z-index:2147482960;" role="dialog" aria-modal="true" aria-labelledby="secret-pin-modal-title">
        <div class="glass-card secret-pin-box" style="width:420px; max-width:94vw; text-align:right; background:#1e1b4b; border:1px solid #6366f1;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:10px;">
                <h2 id="secret-pin-modal-title" style="margin:0; color:#a5b4fc; font-size:1.05rem;"><i class="fas fa-lock"></i> <span data-i18n="secret_pin_modal_title">ژمارا نهێنی</span></h2>
                <button type="button" class="btn btn-dark btn-sm" onclick="if(typeof posSecretPinModalCancel==='function')posSecretPinModalCancel()">✖</button>
            </div>
            <label for="secret-pin-input" style="display:block; color:#cbd5e1; margin-bottom:6px; font-size:0.9rem;" data-i18n="secret_pin_modal_label">ژمارا نهێنی بنڤیسە</label>
            <input type="password" id="secret-pin-input" class="input-std" dir="ltr" inputmode="numeric" autocomplete="off" maxlength="16" style="margin:0 0 14px; width:100%; text-align:center; letter-spacing:0.2em; font-size:1.15rem;" onkeydown="if(event.key==='Enter'){event.preventDefault(); if(typeof posSecretPinModalSubmit==='function')posSecretPinModalSubmit();}">
            <div style="display:flex; gap:8px; justify-content:flex-end; flex-wrap:wrap; margin-bottom:4px;">
                <button type="button" class="btn btn-dark" onclick="if(typeof posSecretPinModalCancel==='function')posSecretPinModalCancel()" data-i18n="secret_pin_modal_cancel">پاشگەڕبوونەوە</button>
                <button type="button" class="btn btn-success" onclick="if(typeof posSecretPinModalSubmit==='function')posSecretPinModalSubmit()"><i class="fas fa-check"></i> <span data-i18n="secret_pin_modal_ok">باشە</span></button>
            </div>
            <div id="secret-pin-tg-invite" style="display:none; margin-top:16px; padding-top:14px; border-top:1px dashed rgba(148,163,184,0.35);">
                <p style="margin:0 0 10px; color:#7dd3fc; font-weight:700; font-size:0.92rem;"><i class="fab fa-telegram"></i> <span data-i18n="secret_tg_invite_title">دخلی گروپێ تیلیگرام ببن</span></p>
                <div style="display:flex; gap:12px; align-items:center;">
                    <img src="public/assets/brand/telegram-group-qr.png?v=<?php echo rawurlencode(defined('POS_APP_VERSION') ? (string) POS_APP_VERSION : '1'); ?>" alt="Telegram group" width="108" height="112" style="width:108px; height:auto; border-radius:12px; background:#fff; padding:4px; flex:0 0 auto;">
                    <div style="min-width:0;">
                        <p style="margin:0 0 8px; color:#94a3b8; font-size:0.8rem; line-height:1.5;" data-i18n="secret_tg_invite_hint">ب موبایلێ خۆ سکەن بکە. ئەگەر داخلی، ڤەشارە — ئیتر ناهێت.</p>
                        <button type="button" class="btn btn-dark btn-sm" onclick="if(typeof posSecretPinHideTelegramInvite==='function')posSecretPinHideTelegramInvite()"><i class="fas fa-eye-slash"></i> <span data-i18n="secret_tg_invite_hide">من داخلم — ڤەشارە</span></button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- SECRET MENU: انتظار موافقة الأدمن (٥ دقائق لكل OK) -->
    <div id="secret-access-pending-modal" class="modal-overlay" style="display:none; backdrop-filter: blur(10px); z-index:2147482900;">
        <div class="glass-card" style="width: 520px; text-align: right; background: #1e1b4b; border: 1px solid #f59e0b;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:10px;">
                <h2 style="margin:0; color:#fde68a; font-size:1.05rem;"><i class="fas fa-hourglass-half"></i> <span data-i18n="secret_access_pending_title">چاوەڕێی ڕێگەپێدانی ئەدمین</span></h2>
                <button type="button" class="btn btn-dark btn-sm" onclick="posSecretAccessClosePendingModal()">✖</button>
            </div>
            <p id="secret-access-pending-msg" style="color:#e2e8f0; line-height:1.7; margin:0 0 12px;" data-i18n="secret_access_pending_body">هیچ کەس ناتوانێت بچێتە مێنوی نهێنی تا ئەدمین لە لوحەی بەڕێوەبردن دوگمەی OK بدات. دوای OK تەنها ٥ خولەک دەمێنێتەوە؛ پاشان پێویستە دووبارە OK بدرێت.</p>
            <p id="secret-access-pending-user" style="font-size:0.85rem; color:#94a3b8; margin:0 0 8px;"></p>
            <p id="secret-access-pending-countdown" style="display:none; font-size:0.9rem; color:#6ee7b7; margin:0 0 12px;"></p>
            <div style="display:flex; gap:10px; justify-content:flex-end; flex-wrap:wrap;">
                <button type="button" class="btn btn-dark" onclick="posSecretAccessClosePendingModal()" data-i18n="secret_access_cancel">پاشگەڕبوونەوە</button>
                <button type="button" class="btn btn-warning" onclick="posSecretAccessRetryRequest()"><i class="fas fa-sync"></i> <span data-i18n="secret_access_retry">دووبارە داوا بکە</span></button>
            </div>
        </div>
    </div>

    <!-- Premium locked section — purchase popup -->
    <div id="premium-lock-popup" class="premium-lock-popup" style="display:none;" role="dialog" aria-modal="true" aria-labelledby="premium-lock-popup-title">
        <div class="premium-lock-popup__backdrop" onclick="closePremiumLockedPurchasePopup()"></div>
        <div class="premium-lock-popup__card">
            <button type="button" class="premium-lock-popup__close" onclick="closePremiumLockedPurchasePopup()" aria-label="Close">&times;</button>
            <div class="premium-lock-popup__glow" aria-hidden="true"></div>
            <div class="premium-lock-popup__icon-wrap">
                <i class="fas fa-lock premium-lock-popup__icon" aria-hidden="true"></i>
            </div>
            <h3 id="premium-lock-popup-title" class="premium-lock-popup__title" data-i18n="premium_lock_popup_title">ئەم بەشە قفڵە</h3>
            <p id="premium-lock-popup-feature" class="premium-lock-popup__feature" style="display:none;"></p>
            <p class="premium-lock-popup__intro" data-i18n="premium_lock_popup_intro">ئەم تایبەتمەندییە بەشێکە لە وەشانێ پریمیەمە. پلانێ هەڵبژێرە و کۆدی چالاککردن بنووسە:</p>
            <div id="premium-lock-feature-only-panel" class="premium-lock-popup__feature-only" style="display:none;">
                <p class="premium-lock-popup__feature-only-title" data-i18n="premium_lock_feature_only_title">تەنها ئەم تایبەتمەندیە · $50</p>
                <p class="premium-lock-popup__feature-only-note" data-i18n="premium_lock_feature_only_note">Pro پێویست نییە — کۆدی FEAT لە ئەدمین وەربگرە و لێرە چالاک بکە.</p>
                <div class="premium-lock-popup__redeem-row">
                    <input type="text" id="premium-lock-feature-code-input" class="input-std premium-lock-popup__code-input" dir="ltr" placeholder="FEAT-TAKE-XXXX-XXXX" autocomplete="off" inputmode="text" />
                    <button type="button" class="btn btn-success premium-lock-popup__redeem-btn" id="premium-lock-feature-redeem-btn" onclick="redeemFeatureActivationCodeFromPopup()">
                        <i class="fas fa-shopping-bag"></i>
                        <span data-i18n="premium_lock_feature_redeem_btn">چالاککردن ($50)</span>
                    </button>
                </div>
                <p id="premium-lock-feature-code-msg" class="activation-msg premium-lock-popup__code-msg"></p>
            </div>
            <p id="premium-lock-or-pro-divider" class="premium-lock-popup__divider" style="display:none;" data-i18n="premium_lock_or_pro_divider">— یان هەموو تایبەتمەندیەکان بە Pro —</p>
            <div class="premium-lock-popup__plans" id="premium-lock-pro-plans">
                <button type="button" class="premium-lock-popup__plan premium-lock-popup__plan--pro" data-tier="pro" onclick="selectPremiumLockPlan('pro')">
                    <span class="premium-lock-popup__plan-badge">Pro</span>
                    <span class="premium-lock-popup__plan-price" data-pos-price="pro">$224</span>
                    <span class="premium-lock-popup__plan-note" data-i18n="premium_lock_popup_pro_note">Pro · هەموو تایبەتمەندییەکان · ٥ کارمەند · یەک ئامێر</span>
                    <span class="premium-lock-popup__plan-cta" data-i18n="premium_lock_plan_select_pro">کۆد بنووسە ←</span>
                </button>
                <button type="button" class="premium-lock-popup__plan premium-lock-popup__plan--plus" data-tier="pro_plus" onclick="selectPremiumLockPlan('pro_plus')">
                    <span class="premium-lock-popup__plan-badge">Pro Plus</span>
                    <span class="premium-lock-popup__plan-price" data-pos-price="pro_plus">$424</span>
                    <span class="premium-lock-popup__plan-note" data-i18n="premium_lock_popup_pro_plus_note">Pro Plus · هەموو تایبەتمەندییەکان · کارمەند بێ سنوور · چەند ئامێر</span>
                    <span class="premium-lock-popup__plan-cta" data-i18n="premium_lock_plan_select_plus">کۆد بنووسە ←</span>
                </button>
            </div>
            <div id="premium-lock-redeem-panel" class="premium-lock-popup__redeem" style="display:none;">
                <p id="premium-lock-redeem-hint" class="premium-lock-popup__redeem-hint" data-i18n="premium_lock_redeem_hint_pro">کۆدی Pro ـەکەت بنووسە:</p>
                <div class="premium-lock-popup__redeem-row">
                    <input type="text" id="premium-lock-code-input" class="input-std premium-lock-popup__code-input" dir="ltr" placeholder="PRO-XXXX-XXXX" autocomplete="off" inputmode="text" />
                    <button type="button" class="btn btn-brand premium-lock-popup__redeem-btn" id="premium-lock-redeem-btn" onclick="redeemActivationCodeFromPopup()">
                        <i class="fas fa-unlock"></i>
                        <span data-i18n="settings_activation_redeem_btn">چالاککردن</span>
                    </button>
                </div>
                <p id="premium-lock-code-msg" class="activation-msg premium-lock-popup__code-msg"></p>
            </div>
            <p class="premium-lock-popup__footer" data-i18n="premium_lock_popup_footer">بۆ کڕین پەیوەندی بە پشتیوانی بکە · دوای کڕین کۆدەکە لێرە چالاک بکە.</p>
            <button type="button" class="btn btn-brand premium-lock-popup__btn" onclick="closePremiumLockedPurchasePopup()" data-i18n="premium_lock_popup_close">باشە، تێگەیشتم</button>
        </div>
    </div>

    <!-- SECRET MENU MODAL -->
    <div id="secret-menu-modal" class="modal-overlay" style="display:none; backdrop-filter: blur(10px);">
        <div class="glass-card" style="width: 600px; text-align: right; background: #1e1b4b; border: 1px solid #6366f1;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:10px;">
                <h2 style="margin:0; color:#a5b4fc;"><i class="fas fa-user-secret"></i> مێنویێ نهێنی (Secret Menu)</h2>
                <button class="btn btn-danger btn-sm" onclick="document.getElementById('secret-menu-modal').style.display='none'">✖</button>
            </div>

            <div class="card" style="background: rgba(255,255,255,0.05); margin-bottom:15px;">
                <label>١. ناڤێ سیستەمی (System Name)</label>
                <div style="display:flex; gap:10px;">
                    <input type="text" id="secret-sys-name" class="input-std" style="margin:0;">
                    <button class="btn btn-success" onclick="saveSecretSystemName()">Save</button>
                </div>
            </div>

            <div class="card" style="background: rgba(255,255,255,0.05); margin-bottom:15px;">
                <label>٢. گوهۆڕینا سیستەمی (System Mode)</label>
                <div style="display:grid; grid-template-columns: 1fr 1fr; gap:5px; margin-top:5px;">
                    <button class="btn btn-sm btn-brand" onclick="setSystemMode('market')">مارکێت (Market)</button>
                    <button class="btn btn-sm btn-success" onclick="setSystemMode('pharmacy')">دەرمانخانە (Pharmacy)</button>
                    <button class="btn btn-sm btn-info" onclick="setSystemMode('stationery')">قرطاسیە (Stationery)</button>
                    <button class="btn btn-sm" style="background:#5b7a9a; color:white;" onclick="setSystemMode('mobile')">مۆبایل (Mobile)</button>
                    <button class="btn btn-sm btn-dark" onclick="setSystemMode('company')">کۆمپانیا (Company)</button>
                    <button class="btn btn-sm" style="background:#8a4b38; color:white;" onclick="setSystemMode('cafe')">کوفی شۆپ (Coffee Shop)</button>
                    <button class="btn btn-sm btn-warning" onclick="setSystemMode('restaurant')">مەتعەم (Restaurant)</button>
                    <button class="btn btn-sm btn-success" style="background:#16a34a;" onclick="setSystemMode('clinic')">عیادة / دکتور</button>
                    <button class="btn btn-sm btn-info" style="background:#0ea5e9;" onclick="setSystemMode('hotel')">فندق (Hotel)</button>
                    <button class="btn btn-sm btn-primary" style="background:#4f46e5; color:white;" onclick="setSystemMode('school')">قوتابخانە (School)</button>
                    <button class="btn btn-sm" style="background:#0891b2; color:white;" onclick="setSystemMode('factory')">کارگە (Factory)</button>
                    <button class="btn btn-sm" style="background:#c9a227; color:#1a1508;" onclick="setSystemMode('jewelry')">زیڤ و زێر (Jewelry)</button>
                    <button class="btn btn-sm btn-secondary" onclick="setSystemMode('general')">گشتی (General)</button>
                </div>
            </div>

            <div class="card" style="background: rgba(245, 158, 11, 0.1); border: 1px solid rgba(245, 158, 11, 0.4); margin-bottom:15px;">
                <label style="color:#fcd34d;"><i class="fas fa-coins"></i> <span data-i18n="secret_currency_label">دراڤ (گوهۆڕین هەر کاتێک)</span></label>
                <p style="font-size:0.85rem; color:#94a3b8; margin:8px 0 12px;" data-i18n="secret_currency_hint">لێرە دەتوانیت دینار ↔ دۆلار بگۆڕیت تەنانەت دوای زیادکردنی ئایتم. لە ڕێکخستن قفڵ دەمێنێتەوە.</p>
                <div style="display:flex; gap:8px; flex-wrap:wrap; margin-bottom:12px;">
                    <button type="button" class="btn btn-warning" id="secret-currency-btn-iqd" onclick="setSecretCurrencyMode('IQD')"><i class="fas fa-money-bill-wave"></i> IQD</button>
                    <button type="button" class="btn btn-success" id="secret-currency-btn-usd" onclick="setSecretCurrencyMode('USD')"><i class="fas fa-dollar-sign"></i> USD</button>
                </div>
                <label style="font-size:0.85rem; color:#94a3b8; display:block; margin-bottom:6px;" data-i18n="secret_currency_rate_label">بهایێ 100$ (دینار)</label>
                <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                    <input type="number" id="secret-exchange-rate" class="input-std" min="10000" step="1" placeholder="150000" value="150000" style="margin:0; max-width:160px;" dir="ltr">
                    <button type="button" class="btn btn-info btn-sm" id="secret-exchange-rate-save" onclick="saveSecretExchangeRateOnly()"><i class="fas fa-save"></i> <span data-i18n="secret_currency_rate_save">Rate</span></button>
                </div>
                <p id="secret-currency-current-hint" style="font-size:0.8rem; color:#64748b; margin:10px 0 0;" dir="auto">—</p>
            </div>

            <div class="card" style="background: rgba(255,255,255,0.05); margin-bottom:15px;">
                <label>٣. ژمارا نهێنی یا ڕێڤەبەری (Manager PIN)</label>
                <div style="display:flex; gap:10px;">
                    <input type="text" id="secret-manager-pin" class="input-std" style="margin:0;">
                    <button class="btn btn-success" onclick="saveSecretManagerPin()">Update</button>
                </div>
            </div>

            <div class="card" style="background: rgba(234, 179, 8, 0.08); border: 1px solid rgba(234, 179, 8, 0.35); margin-bottom:15px;">
                <label style="color:#fde68a;"><i class="fas fa-users"></i> <span data-i18n="secret_max_staff_label">حدّ حسابات الموظفين المسموحة</span></label>
                <p style="font-size:0.85rem; color:#94a3b8; margin:8px 0 12px;" data-i18n="secret_max_staff_hint">الافتراضي ٣. بعد الدفع غيّر إلى ٤ أو ٥ أو أي رقم.</p>
                <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                    <input type="number" id="secret-max-staff-allowed" class="input-std" min="1" max="999" step="1" value="3" style="margin:0; max-width:140px;" dir="ltr">
                    <button type="button" class="btn btn-success" onclick="saveSecretMaxStaffAllowed()"><i class="fas fa-save"></i> <span data-i18n="secret_max_staff_save">Save</span></button>
                </div>
                <p id="secret-max-staff-current-hint" style="font-size:0.8rem; color:#64748b; margin:10px 0 0;" dir="auto"></p>
            </div>

            <div class="card" style="background: rgba(99, 102, 241, 0.1); border: 1px solid rgba(99, 102, 241, 0.35); margin-bottom:15px;">
                <label style="color:#c7d2fe;"><i class="fas fa-shopping-cart"></i> <span data-i18n="secret_max_cart_tabs_label">عدد سلال التسوق المسموح</span></label>
                <p style="font-size:0.85rem; color:#94a3b8; margin:8px 0 12px;" data-i18n="secret_max_cart_tabs_hint">بنەڕەت ٣. پشتی پارەدانێ بگوهۆڕە بۆ ٤–٨.</p>
                <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                    <input type="number" id="secret-max-cart-tabs-allowed" class="input-std" min="1" max="8" step="1" value="2" style="margin:0; max-width:140px;" dir="ltr">
                    <button type="button" class="btn btn-success" onclick="saveSecretMaxCartTabsAllowed()"><i class="fas fa-save"></i> <span data-i18n="secret_max_cart_tabs_save">Save</span></button>
                </div>
                <p id="secret-max-cart-tabs-current-hint" style="font-size:0.8rem; color:#64748b; margin:10px 0 0;" dir="auto"></p>
            </div>

            <div class="card" style="background: rgba(99, 102, 241, 0.1); border: 1px solid rgba(99, 102, 241, 0.35); margin-bottom:15px;">
                <label style="color:#c7d2fe;"><i class="fas fa-industry"></i> <span data-i18n="secret_mfr_slots_label">پاکێتا کۆمپانیا دروستکەر ($50)</span></label>
                <p style="font-size:0.85rem; color:#94a3b8; margin:8px 0 12px;" data-i18n="secret_mfr_slots_hint">یەکجار $50 = تا ١٠٠ کۆمپانیا دروستکەر. Pro = بێسنوور.</p>
                <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                    <input type="number" id="secret-manufacturer-slots-purchased" class="input-std" min="0" max="999" step="1" value="0" style="margin:0; max-width:140px;" dir="ltr">
                    <button type="button" class="btn btn-success" onclick="saveSecretManufacturerSlotsPurchased()"><i class="fas fa-save"></i> <span data-i18n="secret_mfr_slots_save">Save</span></button>
                </div>
                <p id="secret-manufacturer-slots-current-hint" style="font-size:0.8rem; color:#64748b; margin:10px 0 0;" dir="auto"></p>
            </div>

            <div class="card" style="background: rgba(16, 185, 129, 0.08); border: 1px solid rgba(16, 185, 129, 0.35); margin-bottom:15px;">
                <label style="color:#6ee7b7;"><i class="fas fa-cash-register"></i> <span data-i18n="secret_max_daily_sales_label">عدد مبيعات اليوم المسموح</span></label>
                <p style="font-size:0.85rem; color:#94a3b8; margin:8px 0 12px;" data-i18n="secret_max_daily_sales_hint">الافتراضي ٥ مبيعات/يوم عبر شاشة الدفع. ٩٩+ = غير محدود (Pro).</p>
                <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                    <input type="number" id="secret-max-daily-sales-allowed" class="input-std" min="1" max="99999" step="1" value="5" style="margin:0; max-width:140px;" dir="ltr">
                    <button type="button" class="btn btn-success" onclick="saveSecretMaxDailySalesAllowed()"><i class="fas fa-save"></i> <span data-i18n="secret_max_daily_sales_save">Save</span></button>
                </div>
                <p id="secret-max-daily-sales-current-hint" style="font-size:0.8rem; color:#64748b; margin:10px 0 0;" dir="auto"></p>
            </div>

            <div class="card" style="background: rgba(251, 146, 60, 0.1); border: 1px solid rgba(251, 146, 60, 0.4); margin-bottom:15px;">
                <label style="color:#fdba74;"><i class="fas fa-hashtag"></i> ژمارا وەسڵێ (Invoice number)</label>
                <p style="font-size:0.85rem; color:#94a3b8; margin:8px 0 12px;">خۆت بنڤیسە کا وەسڵێ داهاتوو ژ چ ژمارەیێ دەستپێ بکەت — وەک <b dir="ltr">1</b> یان <b dir="ltr">1000</b>. ناکرێت ژ دوایین وەسڵێ کێمتر بیت.</p>
                <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(140px,1fr)); gap:10px; margin-bottom:12px;">
                    <div style="background:rgba(15,23,42,0.45); border:1px solid rgba(148,163,184,0.25); border-radius:10px; padding:10px;">
                        <div style="font-size:0.75rem; color:#94a3b8;">دوایین وەسڵ</div>
                        <div id="secret-sale-id-max" style="font-size:1.15rem; color:#fdba74; margin-top:4px;" dir="ltr">—</div>
                    </div>
                    <div style="background:rgba(15,23,42,0.45); border:1px solid rgba(148,163,184,0.25); border-radius:10px; padding:10px;">
                        <div style="font-size:0.75rem; color:#94a3b8;">داهاتوو (ئێستا)</div>
                        <div id="secret-sale-id-next-now" style="font-size:1.15rem; color:#86efac; margin-top:4px;" dir="ltr">—</div>
                    </div>
                </div>
                <label style="font-size:0.85rem; color:#94a3b8; display:block; margin-bottom:6px;">ژمارا داهاتوو بنڤیسە</label>
                <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap; margin-bottom:10px;">
                    <input type="number" id="secret-next-sale-id" class="input-std" min="1" step="1" placeholder="1000" style="margin:0; max-width:160px;" dir="ltr">
                    <button type="button" class="btn btn-success" onclick="if(typeof saveSecretNextSaleId==='function')saveSecretNextSaleId();"><i class="fas fa-save"></i> پاراستن</button>
                </div>
                <label style="font-size:0.85rem; color:#94a3b8; display:block; margin-bottom:6px;">درێژاهیا نیشاندانێ (pad) — وەک 000007</label>
                <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                    <input type="number" id="secret-sale-id-pad" class="input-std" min="1" max="10" step="1" value="6" style="margin:0; max-width:100px;" dir="ltr">
                    <span style="font-size:0.8rem; color:#64748b;">١–١٠</span>
                </div>
                <p id="secret-sale-id-hint" style="font-size:0.8rem; color:#64748b; margin:10px 0 0;" dir="auto">—</p>
            </div>

            <div class="card" style="background: rgba(14, 165, 233, 0.08); border: 1px solid rgba(14, 165, 233, 0.35); margin-bottom:15px;">
                <label style="color:#7dd3fc;"><i class="fas fa-chart-line"></i> ڕاپۆرتا فرۆتنا ئەمڕۆ (Admin Daily)</label>
                <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:10px; margin-top:10px;">
                    <div style="background:rgba(15,23,42,0.45); border:1px solid rgba(148,163,184,0.25); border-radius:10px; padding:10px;">
                        <div style="font-size:0.75rem; color:#94a3b8;">وەسڵا فرۆتنێ (Invoices)</div>
                        <div id="secret-today-sales-count" style="font-size:1.15rem; color:#e0f2fe; margin-top:4px;">0</div>
                    </div>
                    <div style="background:rgba(15,23,42,0.45); border:1px solid rgba(148,163,184,0.25); border-radius:10px; padding:10px;">
                        <div style="font-size:0.75rem; color:#94a3b8;">دانەی فرۆشراوی (Items)</div>
                        <div id="secret-today-items-sold" style="font-size:1.15rem; color:#e0f2fe; margin-top:4px;">0</div>
                    </div>
                    <div style="background:rgba(15,23,42,0.45); border:1px solid rgba(148,163,184,0.25); border-radius:10px; padding:10px;">
                        <div style="font-size:0.75rem; color:#94a3b8;">کۆی بڕی فرۆتن (Total)</div>
                        <div id="secret-today-sales-total" style="font-size:1.15rem; color:#22d3ee; margin-top:4px;">0</div>
                    </div>
                </div>
                <p id="secret-today-sales-hint" style="font-size:0.8rem; color:#64748b; margin:10px 0 0;">—</p>
            </div>

            <div id="secret-features-vault-wrap" class="card" style="grid-column:1/-1; background:linear-gradient(165deg, rgba(15,23,42,0.97) 0%, rgba(30,27,75,0.94) 55%, rgba(15,23,42,0.98) 100%); border-radius:22px; border:1px solid rgba(212,175,55,0.42); box-shadow:0 0 46px rgba(212,175,55,0.11), inset 0 1px 0 rgba(255,255,255,0.07); padding:20px 22px; margin-bottom:6px; position:relative; overflow:hidden;">
                <div style="position:absolute; top:-40px; left:50%; transform:translateX(-50%); width:120%; height:80px; background:radial-gradient(ellipse at center, rgba(250,204,21,0.14) 0%, transparent 70%); pointer-events:none;"></div>
                <div style="display:flex; align-items:flex-start; justify-content:space-between; gap:16px; flex-wrap:wrap; margin-bottom:16px; padding-bottom:14px; border-bottom:1px solid rgba(148,163,184,0.2); position:relative; z-index:1;">
                    <div>
                        <h3 style="margin:0; color:#fde68a; font-size:1.08rem; letter-spacing:0.03em; text-shadow:0 0 20px rgba(250,204,21,0.25);"><i class="fas fa-gem" style="opacity:0.95;"></i> خەزنەی قفڵی تایبەت / <span dir="ltr" style="opacity:0.88; font-weight:600;">Premium vault</span></h3>
                        <p style="margin:10px 0 0; font-size:0.8rem; color:#94a3b8; max-width:560px; line-height:1.55;">تەنها کردنەوە و داخستنی قفڵی بەش — دوای کردنەوە، چالاک/ناچالاک لە <strong>ڕێکخستن</strong> دەگۆڕیت.</p>
                    </div>
                </div>
                <div id="secret-features-vault-grid" style="display:grid; grid-template-columns:repeat(auto-fill, minmax(182px, 1fr)); gap:13px; position:relative; z-index:1;"></div>
            </div>

            <div class="card" style="background: rgba(239, 68, 68, 0.1); border: 1px solid #ef4444;">
                <label style="color:#fca5a5;">٤. گوهۆڕینا کۆدێ نهێنی (Change Secret PIN)</label>
                <div style="display:flex; gap:10px;">
                    <input type="password" id="secret-current-pin" class="input-std" placeholder="Current Secret PIN" style="margin:0;">
                    <input type="password" id="secret-new-pin" class="input-std" placeholder="New Secret PIN" style="margin:0;">
                    <button class="btn btn-danger" onclick="changeSecretPin()">Change</button>
                </div>
            </div>

            <div class="card" style="background: rgba(239, 68, 68, 0.15); border: 2px solid #ef4444; margin-top:15px;">
                <label style="color:#fecaca; font-weight:bold;"><i class="fas fa-exclamation-triangle"></i> ٥. ڕێکخستن/ژێبرنا سیستەمی (System Format / Reset)</label>
                <p style="font-size:0.9rem; color:rgba(254,202,202,0.9); margin:8px 0;">هەمی داتا (ئایتم، فرۆتن، کۆگەه، مێژوو) دێ هێنە ژێبرن و داتابەیس دێ گەڕیتە دۆخێ بەتاڵ. تەنها بۆ دکانێ نوی.</p>
                <button type="button" class="btn btn-danger" onclick="openSystemResetConfirm()"><i class="fas fa-database"></i> ڕێکخستن / ژێبرن (Format / Reset)</button>
            </div>
        </div>
    </div>

    <!-- SYSTEM RESET CONFIRMATION MODAL -->
    <div id="secret-reset-modal" class="modal-overlay" style="display:none; backdrop-filter: blur(10px);">
        <div class="glass-card" style="width: 520px; text-align: right; background: #1e1b4b; border: 2px solid #ef4444;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px; border-bottom:1px solid rgba(239,68,68,0.3); padding-bottom:10px;">
                <h2 style="margin:0; color:#fca5a5;"><i class="fas fa-exclamation-triangle"></i> دڵنیاکردنەوە (Confirmation)</h2>
                <button class="btn btn-sm btn-dark" onclick="closeSystemResetConfirm()">✖</button>
            </div>
            <p style="color:#fecaca; margin-bottom:12px; font-weight:bold;">ئەڤە دێ هەمی داتایان ژێبەت: ئایتمان، فرۆتن، کۆگەه، کۆمپانیا، مەزاختن، مێژوویا مامەڵەکان، و هەموو تۆمارەکانی تر. ناگەڕێتەوە!</p>
            <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:15px;">بۆ دڵنیابوون، بنڤیسە <strong style="color:#fef08a;">RESET</strong> ل خوارەوە:</p>
            <input type="text" id="secret-reset-typed" class="input-std" placeholder="RESET" style="margin:0 0 15px 0; text-align:center; font-weight:bold;" oninput="toggleSystemResetButton()" autocomplete="off">
            <div style="display:flex; gap:10px; justify-content:flex-end;">
                <button type="button" class="btn btn-dark" onclick="closeSystemResetConfirm()">پاشگەڕبوونەوە</button>
                <button type="button" id="btn-do-system-reset" class="btn btn-danger" disabled onclick="performSystemReset()"><i class="fas fa-database"></i> بەڵێ، هەمی داتا بسڕەوە</button>
            </div>
        </div>
    </div>


    <!-- DATABASE MANAGEMENT MODAL -->
    <div id="modal-db-manage" class="modal-overlay" style="display:none;">
        <div class="glass-card pos-db-manage-card">
            <div class="pos-db-manage-head">
                <h2 style="margin:0; color:var(--info);"><i class="fas fa-database"></i> <span data-i18n="modal_db_manage_title">بەڕێوەبردنی داتابەیس</span></h2>
                <button type="button" class="btn btn-sm btn-dark" onclick="document.getElementById('modal-db-manage').style.display='none'" aria-label="Close">✖</button>
            </div>

            <div class="pos-db-manage-intro">
                <p style="margin:0;" data-i18n="modal_db_backup_line">پاشەکەوت · گەڕاندنەوە</p>
                <button type="button" class="btn btn-sm btn-light" onclick="document.getElementById('modal-transfer-guide').style.display='flex'" style="color:black;"><i class="fas fa-question-circle"></i> <span data-i18n="modal_db_guide_btn">ڕێنمایی</span></button>
            </div>

            <!-- Backup -->
            <section class="pos-db-manage-section">
                <h3 class="pos-db-manage-section-title"><span data-i18n="modal_db_sec_backup">پاشەکەوت (Backup)</span></h3>
                <button type="button" class="btn btn-success pos-db-manage-btn pos-db-manage-btn-wide" onclick="exportDB()" style="min-height:64px; font-size:1.15rem; font-weight:900; letter-spacing:0.5px;">
                    <i class="fas fa-shield-alt fa-lg"></i>
                    <span data-i18n="modal_db_full_full_backup_btn">پاشەکەوتکردنا فول فول (هەموو داتا)</span>
                </button>
                <p class="pos-db-manage-hint" style="color:#86efac; margin:8px 0 15px; font-weight:600; line-height:1.5;">
                    <i class="fas fa-check-double"></i> <span data-i18n="modal_db_full_full_backup_hint">هەموو تشت: مەزاختن، ڕوژمێر، کڕین، کارمەند، فاتورە، کریار، فرۆتن، کۆمپانیا، ئایتم و داتای هەموو ڕۆژان.</span>
                </p>

                <button type="button" class="btn btn-info pos-db-manage-btn pos-db-manage-btn-wide" onclick="posExportDbToCloud()"><i class="fas fa-cloud-upload-alt"></i><span data-i18n="modal_db_cloud_backup_btn">نێردن بۆ Mobile Manager (Cloud)</span></button>
                <p class="pos-db-manage-hint" data-i18n="modal_db_cloud_backup_hint">یەک کلیک: backup + Cloud · پێشتر Firebase login لە Settings</p>

                <div id="flash-backup-panel" class="pos-db-flash-panel" style="margin:12px 0;padding:12px;border-radius:12px;border:1px solid rgba(34,197,94,.4);background:rgba(34,197,94,.08);">
                    <div style="font-weight:700;margin-bottom:6px;color:#86efac;"><i class="fab fa-usb"></i> <span data-i18n="modal_db_flash_title">پاشەکەوت بۆ فلاش (USB)</span></div>
                    <p class="pos-db-manage-hint" style="margin:0 0 8px;" data-i18n="modal_db_flash_simple_hint">ئێک کلیک: فلاش هەڵبژێرە. ئۆتۆماتیک ON دبیت — دوای هەر فرۆشتنێ داتا دچیتە فلاش. سوبەهی لاپتۆپ بشکێت، داتا لسەر فلاشە.</p>
                    <div id="flash-backup-status" style="font-size:0.9rem;font-weight:700;margin-bottom:10px;color:#94a3b8;">هێشتا فلاش هەڵنەبژێردراوە</div>
                    <input type="checkbox" id="flash-auto-toggle" style="display:none" aria-hidden="true">

                    <button type="button" class="btn btn-success pos-db-manage-btn pos-db-manage-btn-wide" onclick="if(typeof posFlashOneClickBind==='function')posFlashOneClickBind();" style="min-height:54px;font-size:1.08rem;font-weight:900;">
                        <i class="fab fa-usb fa-lg"></i> <span data-i18n="modal_db_flash_pick_btn">هەڵبژاردنی فلاش — ئۆتۆماتیک دەستپێدکەت</span>
                    </button>
                    <button type="button" class="btn pos-db-manage-btn pos-db-manage-btn-wide" onclick="if(typeof posFlashPushNow==='function')posFlashPushNow();" style="min-height:52px;font-weight:900;background:#2563eb;color:#fff;border:none;margin-top:8px;">
                        <i class="fas fa-paper-plane fa-lg"></i> <span data-i18n="modal_db_flash_now_btn">ناردن بۆ فلاش ئێستا (ئێک کلیک)</span>
                    </button>
                    <button type="button" class="btn btn-danger pos-db-manage-btn pos-db-manage-btn-wide" style="font-weight:800;margin-top:8px;" onclick="if(typeof posRestoreFromFlashSqlEasy==='function')posRestoreFromFlashSqlEasy();">
                        <i class="fas fa-undo"></i> <span data-i18n="modal_db_flash_restore_btn">گەڕاندنەوە لە فلاش</span>
                    </button>
                    <p class="pos-db-manage-hint" style="color:#86efac;margin:8px 0 10px;font-weight:600;" data-i18n="modal_db_flash_now_hint">ناردن ئێستا = هەموو فرۆتن، کڕین، قەرز، ئایتم، کریار. پاشان خۆکار بەردەوام دبیت.</p>

                    <div id="flash-backups-list" class="pos-db-local-backups-list" style="max-height:160px;overflow:auto;"></div>

                    <details style="margin-top:10px;opacity:.85;">
                        <summary style="cursor:pointer;font-size:0.82rem;color:#94a3b8;">زیاتر (چالاککردنەوە / وەستان / کارەسات)</summary>
                        <div style="margin-top:10px;padding:10px;border-radius:10px;border:1px solid rgba(148,163,184,.3);">
                            <button type="button" id="flash-auto-onoff-btn" class="btn pos-db-manage-btn pos-db-manage-btn-wide" onclick="if(typeof posFlashToggleAuto==='function')posFlashToggleAuto();" style="font-size:0.95rem;font-weight:800;min-height:40px;margin-bottom:8px;">
                                <i class="fas fa-power-off"></i> <span id="flash-auto-onoff-label">OFF</span>
                            </button>
                            <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:8px;">
                                <button type="button" class="btn btn-sm btn-info" onclick="if(typeof posReactivateFlashPermission==='function')posReactivateFlashPermission();"><i class="fas fa-bolt"></i> چالاککردنەوە</button>
                                <button type="button" class="btn btn-sm btn-dark" onclick="if(typeof posRefreshFlashBackupUi==='function')posRefreshFlashBackupUi(true);"><i class="fas fa-sync-alt"></i></button>
                                <button type="button" class="btn btn-sm btn-warning" onclick="if(typeof posClearFlashBackupFolder==='function')posClearFlashBackupFolder();"><i class="fas fa-unlink"></i> لابردن</button>
                                <button type="button" class="btn btn-sm btn-warning" onclick="if(typeof posFlashSanitizeAll==='function')posFlashSanitizeAll({interactive:true});"><i class="fas fa-broom"></i> پاککردنی ZIP</button>
                            </div>
                            <p class="pos-db-manage-hint" style="margin:0 0 8px;">کارەسات / لاپتۆپی نوێ — Stop MySQL</p>
                            <div style="display:flex;flex-wrap:wrap;gap:8px;">
                                <button type="button" class="btn btn-sm btn-warning" onclick="if(typeof posBackupMysqlDataToFlash==='function')posBackupMysqlDataToFlash('full');"><i class="fas fa-database"></i> data → فلاش</button>
                                <button type="button" class="btn btn-sm btn-light" style="color:#111;" onclick="if(typeof posBackupMysqlDataToFlash==='function')posBackupMysqlDataToFlash('db');"><i class="fas fa-folder"></i> تەنها DB → فلاش</button>
                                <button type="button" class="btn btn-sm btn-dark" onclick="if(typeof posRestoreMysqlDataFromFlashFolder==='function')posRestoreMysqlDataFromFlashFolder();"><i class="fas fa-undo"></i> data → XAMPP</button>
                                <input type="file" id="restore-mysql-data-input" accept=".zip,.posbak,application/zip" style="display:none" onchange="if(typeof posRestoreMysqlDataUpload==='function')posRestoreMysqlDataUpload(this)">
                                <button type="button" class="btn btn-sm btn-dark" onclick="if(typeof confirmRestoreMysqlDataPickFile==='function')confirmRestoreMysqlDataPickFile();"><i class="fas fa-file-archive"></i> لە فایل</button>
                            </div>
                        </div>
                    </details>
                </div>

                <div class="pos-db-mobile-pin" style="margin:10px 0;padding:10px 12px;border-radius:10px;border:1px solid rgba(99,102,241,.35);background:rgba(99,102,241,.08);">
                    <div style="font-size:0.82rem;margin-bottom:6px;" data-i18n="modal_db_mobile_pin_label">PIN بۆ داونلۆد لە موبایل (بێ پارە · هەمان WiFi):</div>
                    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                        <code id="mobile-backup-pin" dir="ltr" style="font-size:1.1rem;font-weight:700;letter-spacing:2px;padding:6px 12px;border-radius:8px;background:rgba(0,0,0,.2);">——</code>
                        <button type="button" class="btn btn-sm btn-dark" onclick="if(typeof refreshMobileBackupPinUi==='function')refreshMobileBackupPinUi();"><i class="fas fa-sync-alt"></i></button>
                        <button type="button" class="btn btn-sm btn-warning" onclick="if(typeof regenerateMobileBackupPin==='function')regenerateMobileBackupPin();"><i class="fas fa-key"></i> <span data-i18n="modal_db_mobile_pin_new">PIN نوێ</span></button>
                    </div>
                </div>
                <p class="pos-db-manage-hint" data-i18n="modal_db_mobile_pin_hint">ئەگەر PIN تایبەت نییە = هەمان PINـی ڕێکخستن (settingsPin) · لە موبایل localhost کار ناکات — IPـی WiFi بنووسە</p>
                <div id="local-backups-panel" class="pos-db-local-backups">
                    <div class="pos-db-local-backups-head">
                        <strong data-i18n="modal_db_local_list_title">پاشەکەوتێن ناو سیستەم</strong>
                        <button type="button" class="btn btn-sm btn-dark" onclick="loadLocalBackupsList()" aria-label="Refresh"><i class="fas fa-sync-alt"></i></button>
                    </div>
                    <div id="local-backups-list" class="pos-db-local-backups-list" data-i18n="modal_db_local_loading">بارکردن…</div>
                </div>
            </section>

            <!-- Restore -->
            <section class="pos-db-manage-section">
                <h3 class="pos-db-manage-section-title"><span data-i18n="modal_db_sec_restore">گەڕاندنەوە (Restore)</span></h3>
                <input type="file" id="restore-input" accept=".posbak,.json,.zip,.gz,.json.gz,application/gzip,application/json,application/zip,application/octet-stream" multiple style="display:none" onchange="restoreBackup(this)">
                <button type="button" class="btn btn-danger pos-db-manage-btn pos-db-manage-btn-wide" onclick="openRestoreWarningModal()"><i class="fas fa-upload"></i><span data-i18n="modal_db_restore">گەڕاندنەوە لە فایل</span></button>
                <p class="pos-db-manage-hint" data-i18n="modal_db_restore_simple_hint">فایلێ .posbak (یان JSON/ZIP یێن کەڤن) — هەموو داتا دەگەڕێتەوە</p>
            </section>

            <!-- Items -->
            <section class="pos-db-manage-section pos-db-manage-section-last">
                <h3 class="pos-db-manage-section-title"><span data-i18n="modal_db_sec_items">ئایتمەکان</span></h3>
                <button type="button" class="btn btn-primary pos-db-manage-btn pos-db-manage-btn-wide" onclick="backupItemsToLocal()"><i class="fas fa-download"></i><span data-i18n="modal_db_backup_items">داونلۆد تەنها ئایتمەکان</span></button>
                <input type="file" id="merge-items-input" accept=".posbak,.json,.zip,.gz,.json.gz,application/gzip,application/json,application/zip,application/octet-stream" multiple style="display:none" onchange="mergeItemsBackup(this)">
                <button type="button" class="btn btn-warning pos-db-manage-btn pos-db-manage-btn-wide" onclick="document.getElementById('merge-items-input').click()"><i class="fas fa-compress-arrows-alt"></i><span data-i18n="modal_db_merge_items">تێکەڵکردنی ئایتمەکان</span></button>
                <p class="pos-db-manage-hint" data-i18n="modal_db_items_hint">داونلۆد: ئێک فایل .posbak · عەدەد=٠ · Merge: هەر .posbak / JSON / ZIP</p>
                <button type="button" class="btn btn-brand pos-db-manage-btn pos-db-manage-btn-wide" onclick="if(typeof repairHistoricalSaleCogs==='function')repairHistoricalSaleCogs();"><i class="fas fa-calculator"></i><span data-i18n="modal_db_repair_cogs">چاککرنا قازانجا وەسڵێن کەڤن</span></button>
                <p class="pos-db-manage-hint" data-i18n="modal_db_repair_cogs_hint">قازانجا فرۆتنێن کۆن لسەر کرینێن هەمان دەمی دووبارە حساب دکەت (هەفتە/مانگ/ساڵ)</p>
            </section>
        </div>
    </div>

    <!-- TRANSFER GUIDE MODAL -->
    <div id="modal-transfer-guide" class="modal-overlay" style="display:none; backdrop-filter: blur(10px);">
        <div class="glass-card" style="width: 500px; text-align: right; border: 1px solid var(--info);">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px; border-bottom:1px solid rgba(56, 189, 248, 0.3); padding-bottom:10px;">
                <h2 style="margin:0; color:var(--info);"><i class="fas fa-book-open"></i> ڕێبەرییا ڤەگوهاستنێ (Transfer Guide)</h2>
                <button class="btn btn-sm btn-dark" onclick="document.getElementById('modal-transfer-guide').style.display='none'">✖</button>
            </div>
            <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 8px; padding: 10px; margin-bottom: 15px; color: #fca5a5; font-size: 0.9rem;">
                <i class="fas fa-exclamation-triangle"></i> <strong>تێبینی:</strong> بێی بەرنامێ (XAMPP) سیستەم ل لاپتۆپێ نوی کار ناکەت!
            </div>
            
            <p style="color:var(--text); margin-bottom:10px; font-weight:bold;">تۆ پێدڤی ب ٢ فایلانە:</p>
            <ul style="list-style:none; padding:0; margin-bottom:15px; color:#94a3b8; line-height:1.6;">
                <li><i class="fas fa-cube text-brand"></i> 1️⃣ بەرنامە (LAPTOP DUHOK POS).</li>
                <li><i class="fas fa-file-code text-success"></i> 2️⃣ فایلێ داتایان: (.posbak — یان .json / .zip یێن کەڤن).</li>
            </ul>
            
            <p style="color:var(--text); margin-bottom:10px; font-weight:bold;"><i class="fab fa-usb"></i> فلاش (USB) — ئەگەر هارد تێکچوو؟</p>
            <ol style="padding-right: 20px; color:#94a3b8; line-height:1.8; margin-bottom: 15px;">
                <li>لە Settings → بەڕێوەبردنی داتابەیس → <strong>هەڵبژاردنی فلاش</strong>.</li>
                <li>هەموو بک‌ئەپ دەچن بۆ فۆڵدەری <code>Laptop_Duhok_POS_Backups</code> لەسەر فلاش.</li>
                <li>لە لاپتۆپی نوێ: POS دابمەزرێنە → هەمان فلاش هەڵبژێرە → <strong>گەڕاندنەوە</strong> لە لیست.</li>
            </ol>

            <p style="color:var(--text); margin-bottom:10px; font-weight:bold;"><i class="fas fa-folder-open"></i> چەوا ل لاپتۆپێ نوی دابنم؟</p>
            <ol style="padding-right: 20px; color:#94a3b8; line-height:1.8; margin-bottom: 15px;">
                <li>بەرنامێ <strong>XAMPP</strong> دابەزێنە و (Apache + MySQL) پێ بکە.</li>
                <li>بەرنامێ <strong>LAPTOP DUHOK POS</strong> بکە د ناڤ فولدەرا (<code>C:/xampp/htdocs</code>).</li>
                <li>سیستەمی ڤەکە، پاشان ل Settings دوگما <strong>Restore</strong> لێدە و فایلێ <code>.posbak</code> هەڵبژێرە (JSON/ZIP یێن کەڤن ژی دکارن).</li>
            </ol>
            
            <div style="text-align:center; color:var(--success); font-weight:bold; margin-top:10px;">
                <i class="fas fa-check-circle"></i> ب ڤێ چەندێ بەرنامە و هەمی داتا دێ ڤەگەڕێن.
            </div>
        </div>
    </div>

    <!-- PRODUCT STOCK MANUAL EDIT WARNING -->
    <div id="modal-product-stock-warn" class="modal-overlay" style="display:none; backdrop-filter:blur(10px); z-index:10050;" role="dialog" aria-modal="true" aria-labelledby="product-stock-warn-title" onclick="if(event.target===this && typeof closeProductStockWarnModal==='function')closeProductStockWarnModal();">
        <div class="glass-card" style="width:min(520px,94vw); text-align:right; border:2px solid #f59e0b;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px; border-bottom:1px solid rgba(245,158,11,.35); padding-bottom:10px;">
                <h2 id="product-stock-warn-title" style="margin:0; color:#d97706;"><i class="fas fa-exclamation-triangle"></i> <span data-i18n="product_stock_warn_title">ئاگەهداری — کۆگەه ب دەست مەگوهۆڕە</span></h2>
                <button type="button" class="btn btn-sm btn-dark" onclick="if(typeof closeProductStockWarnModal==='function')closeProductStockWarnModal();" aria-label="Close">✖</button>
            </div>
            <p style="color:var(--text); margin:0 0 12px; font-size:1.05rem; line-height:1.7; font-weight:700;" data-i18n="product_stock_warn_body">زێدەکرن یان کێمکرنا مەوادێ ل ڤێرێ گەلەک خەلەتیێ دروست دکەت. مەواد ژ بەشێ <strong>کڕین</strong> تۆمار بکە.</p>
            <div style="background:rgba(245,158,11,.12); border:1px solid rgba(245,158,11,.35); border-radius:10px; padding:10px 12px; margin-bottom:18px; color:#b45309; font-size:0.95rem; line-height:1.6;" data-i18n="product_stock_warn_hint">ئەگەر هەر مسڕ بیت دەستکاری بکەی، دەستی دووێم «هەر دەستکاری بکە».</div>
            <div style="display:flex; gap:10px; justify-content:flex-end; flex-wrap:wrap;">
                <button type="button" class="btn btn-dark" onclick="if(typeof closeProductStockWarnModal==='function')closeProductStockWarnModal();"><span data-i18n="product_stock_warn_close">داخستن</span></button>
                <button type="button" class="btn btn-warning" onclick="if(typeof productStockAllowManual==='function')productStockAllowManual();"><i class="fas fa-unlock"></i> <span data-i18n="product_stock_warn_insist">هەر دەستکاری بکە</span></button>
                <button type="button" class="btn btn-success" onclick="if(typeof productStockGoToPurchase==='function')productStockGoToPurchase();"><i class="fas fa-shopping-basket"></i> <span data-i18n="product_stock_warn_go_purchase">بچە کڕین</span></button>
            </div>
        </div>
    </div>

    <!-- RESTORE WARNING MODAL -->
    <div id="modal-restore-warning" class="modal-overlay" style="display:none; backdrop-filter: blur(10px); z-index: 10000;">
        <div class="glass-card" style="width: 500px; text-align: right; border: 2px solid var(--danger);">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px; border-bottom:1px solid rgba(239, 68, 68, 0.3); padding-bottom:10px;">
                <h2 style="margin:0; color:var(--danger);"><i class="fas fa-exclamation-triangle"></i> <span data-settings-i18n="modal_restore_warning_title">ئاگەهدارییا مەترسیدار!</span></h2>
                <button class="btn btn-sm btn-dark" onclick="document.getElementById('modal-restore-warning').style.display='none'">✖</button>
            </div>
            
            <p style="color:var(--text); margin-bottom:15px; font-size:1.1rem; line-height:1.6;">
                <span data-settings-i18n="modal_restore_warning_body">ئەڤ کارە دێ هەمی داتایێن نوکە ژێبەت و یێن فایلێ دانێت. ئەگەر بک‌ئەپ لە تیلیگرام ٢ پارچە بوو، part1 و part2 پێکەوە هەڵبژێرە.</span>
            </p>
            
            <div style="background: rgba(250, 204, 21, 0.1); border: 1px solid rgba(250, 204, 21, 0.3); border-radius: 8px; padding: 10px; margin-bottom: 20px; color: #fde047; font-size: 0.95rem;">
                <i class="fas fa-info-circle"></i> <span data-settings-i18n="modal_restore_warning_confirm">ئەرێ تو دڵنیای دڤێت ڤی کاری بکەی؟</span>
            </div>
            <p class="pos-db-manage-hint" style="margin:0 0 16px;color:#fca5a5;" data-i18n="confirm_data_restore_pin_hint">دواتر نڤیسینەکا درێژ کۆپی بکە و پەیست بکە بۆ پشتڕاستکرن — داتای نوکە دەسڕدرێتەوە.</p>

            <div style="margin-bottom: 16px;">
                <label style="color:#94a3b8; font-size:0.85rem; margin-bottom:6px; display:block;" data-i18n="modal_restore_currency_label">دراڤی سیستەم دوای گەڕاندنەوە:</label>
                <select id="restore-currency-choice" class="input-std" style="width:100%;">
                    <option value="IQD" data-i18n="modal_restore_currency_iqd">دینار عێراقی (IQD)</option>
                    <option value="USD" data-i18n="modal_restore_currency_usd">دولار ($)</option>
                </select>
            </div>
            
            <div style="display:flex; gap:10px; justify-content:flex-end;">
                <button type="button" class="btn btn-dark" onclick="document.getElementById('modal-restore-warning').style.display='none'"><span data-settings-i18n="modal_restore_warning_cancel">نەخێر، پاشگەزبووم</span></button>
                <button type="button" class="btn btn-danger" onclick="if(typeof confirmRestoreThenPickFile==='function')confirmRestoreThenPickFile();"><i class="fas fa-upload"></i> <span data-settings-i18n="modal_restore_warning_ok">بەڵێ، دڵنیام (Restore)</span></button>
            </div>
        </div>
    </div>

    <!-- MERGE ITEMS: Dollar or Dinar -->
    <div id="modal-merge-items-currency" class="modal-overlay" style="display:none; backdrop-filter: blur(10px); z-index: 10020;" role="dialog" aria-modal="true" aria-labelledby="merge-items-currency-title" onclick="if(event.target===this && typeof closeMergeItemsCurrencyModal==='function')closeMergeItemsCurrencyModal();">
        <div class="glass-card" style="width:min(460px,94vw); text-align:right; border:2px solid #f59e0b;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px; border-bottom:1px solid rgba(245,158,11,.35); padding-bottom:10px;">
                <h2 id="merge-items-currency-title" style="margin:0; color:#d97706;"><i class="fas fa-coins"></i> <span data-i18n="modal_merge_currency_title">دراڤ: دولار یان دینار؟</span></h2>
                <button type="button" class="btn btn-sm btn-dark" onclick="if(typeof closeMergeItemsCurrencyModal==='function')closeMergeItemsCurrencyModal();" aria-label="Close">✖</button>
            </div>
            <p style="color:var(--text); margin:0 0 10px; font-size:1.05rem; line-height:1.7; font-weight:700;" data-i18n="modal_merge_currency_body">پشتی تێکەڵکرنێ، دراڤی سیستەم دێ بیتە:</p>
            <p id="merge-items-currency-files" style="color:#94a3b8; font-size:0.9rem; margin:0 0 14px;"></p>
            <div style="background:rgba(245,158,11,.12); border:1px solid rgba(245,158,11,.35); border-radius:10px; padding:10px 12px; margin-bottom:16px; color:#b45309; font-size:0.92rem; line-height:1.6;" data-i18n="modal_merge_currency_hint">ئایتمێن نوێ زیاد دبن (عەدەد=٠). دووبارە نابنەوە.</div>
            <div style="display:flex; gap:10px; justify-content:stretch; flex-wrap:wrap; margin-bottom:12px;">
                <button type="button" class="btn btn-success" style="flex:1; min-height:52px; font-size:1.05rem; font-weight:800;" onclick="if(typeof confirmMergeItemsWithCurrency==='function')confirmMergeItemsWithCurrency('IQD');"><i class="fas fa-money-bill-wave"></i> <span data-i18n="modal_merge_currency_iqd">دینار عێراقی</span></button>
                <button type="button" class="btn btn-primary" style="flex:1; min-height:52px; font-size:1.05rem; font-weight:800;" onclick="if(typeof confirmMergeItemsWithCurrency==='function')confirmMergeItemsWithCurrency('USD');"><i class="fas fa-dollar-sign"></i> <span data-i18n="modal_merge_currency_usd">دولار ($)</span></button>
            </div>
            <div style="display:flex; justify-content:flex-end;">
                <button type="button" class="btn btn-dark" onclick="if(typeof closeMergeItemsCurrencyModal==='function')closeMergeItemsCurrencyModal();"><span data-i18n="modal_merge_currency_cancel">پاشگەزبووم</span></button>
            </div>
        </div>
    </div>

    <!-- ARCHIVE SELECTION MODAL -->
    <div id="modal-archive-selection" class="modal-overlay" style="display:none; backdrop-filter: blur(10px);">
        <div class="glass-card" style="width: 450px; text-align: right; border: 1px solid var(--warning);">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px; border-bottom:1px solid rgba(250, 204, 21, 0.3); padding-bottom:10px;">
                <h2 style="margin:0; color:var(--warning);"><i class="fas fa-archive"></i> ئەرشیفکرنا داتایان</h2>
                <button class="btn btn-sm btn-dark" onclick="document.getElementById('modal-archive-selection').style.display='none'">✖</button>
            </div>
            
            <p style="color:var(--text); margin-bottom:15px; font-size:0.95rem;">
                تکایە دەمێ ئەرشیفکرنێ هەڵبژێرە. هەمی داتایێن (فرۆتن و مەزاختن) یێن <strong>بەریا</strong> ڤی دەمی دێ چنە د خشتەیێ ئەرشیفێ دا بۆ سووککرنا سیستەمی.
            </p>
            
            <div style="margin-bottom: 20px;">
                <label style="color:#94a3b8; font-size:0.85rem; margin-bottom:5px; display:block;">ماوەیێ داتایێن کەڤن:</label>
                <select id="archive-time-selection" class="input-std" style="width:100%;">
                    <option value="365">بەریا ١ ساڵێ (1 Year ago)</option>
                    <option value="180">بەریا ٦ هەیڤان (6 Months ago)</option>
                    <option value="90">بەریا ٣ هەیڤان (3 Months ago)</option>
                    <option value="30">بەریا ١ هەیڤێ (1 Month ago)</option>
                    <option value="all">هەموو داتا (All Data)</option>
                </select>
            </div>
            
            <div style="display:flex; gap:10px; justify-content:flex-end;">
                <button type="button" class="btn btn-dark" onclick="document.getElementById('modal-archive-selection').style.display='none'">پاشگەزبووم</button>
                <button type="button" class="btn btn-warning" onclick="confirmArchiveOldData()"><i class="fas fa-check"></i> دەستپێکرنا ئەرشیفێ</button>
            </div>
        </div>
    </div>

    <!-- DELETE ARCHIVED DATA MODAL -->
    <div id="modal-delete-archive-selection" class="modal-overlay" style="display:none; backdrop-filter: blur(10px);">
        <div class="glass-card" style="width: 450px; text-align: right; border: 1px solid var(--danger);">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px; border-bottom:1px solid rgba(239, 68, 68, 0.3); padding-bottom:10px;">
                <h2 style="margin:0; color:var(--danger);"><i class="fas fa-trash-alt"></i> <span data-i18n="modal_db_delete_archive_title">سڕینەوەی داتای ئەرشیف</span></h2>
                <button class="btn btn-sm btn-dark" onclick="document.getElementById('modal-delete-archive-selection').style.display='none'">✖</button>
            </div>

            <p style="color:var(--text); margin-bottom:15px; font-size:0.95rem;" data-i18n="modal_db_delete_archive_desc">
                داتای ئەرشیڤکراو (فرۆشتن و مەزاختن) لە خشتەی ئەرشیف بە تەواوی دەسڕێتەوە — ناگەڕێتەوە.
            </p>

            <div style="margin-bottom: 20px;">
                <label style="color:#94a3b8; font-size:0.85rem; margin-bottom:5px; display:block;" data-i18n="modal_db_delete_archive_range">چ داتایەک بسڕێتەوە:</label>
                <select id="delete-archive-time-selection" class="input-std" style="width:100%;">
                    <option value="365">ئەرشیفی بەرتر لە ١ ساڵ (1 Year+)</option>
                    <option value="180">ئەرشیفی بەرتر لە ٦ هەیڤان (6 Months+)</option>
                    <option value="90">ئەرشیفی بەرتر لە ٣ هەیڤان (3 Months+)</option>
                    <option value="30">ئەرشیفی بەرتر لە ١ هەیڤ (1 Month+)</option>
                    <option value="all">هەموو ئەرشیف (All archived)</option>
                </select>
            </div>

            <div style="display:flex; gap:10px; justify-content:flex-end;">
                <button type="button" class="btn btn-dark" onclick="document.getElementById('modal-delete-archive-selection').style.display='none'" data-i18n="modal_cancel">پاشگەزبووم</button>
                <button type="button" class="btn btn-danger" onclick="confirmDeleteArchivedData()"><i class="fas fa-trash-alt"></i> <span data-i18n="modal_db_delete_archive_confirm">سڕینەوە</span></button>
            </div>
        </div>
    </div>

    <!-- TELEGRAM MODAL -->
    <div id="modal-telegram" class="modal-overlay" style="display:none; z-index:9999; padding:20px; overflow-y:auto; align-items:flex-start;">
        <div class="glass-card" style="width: 800px; max-width:100%; text-align: right; background: linear-gradient(145deg, var(--card), #0f172a); border: 2px solid #38bdf8; box-shadow: 0 10px 40px rgba(56, 189, 248, 0.2); border-radius: 20px; overflow: hidden; padding: 0; margin:auto;">
            
            <!-- Header -->
            <div style="background: linear-gradient(90deg, #0284c7, #38bdf8); padding: 15px 20px; color: white; display: flex; justify-content: space-between; align-items: center;">
                <h2 style="margin:0; font-size: 1.4rem; text-shadow: 0 2px 5px rgba(0,0,0,0.2);"><i class="fab fa-telegram fa-bounce" style="margin-left:8px;"></i> <span data-i18n="tg_modal_title">سیستەمێ تێلیگرام (پێشکەفتی)</span></h2>
                <button class="btn btn-sm" style="background: rgba(255,255,255,0.2); color:white; border:none; border-radius:50%; width:35px; height:35px; display:flex; align-items:center; justify-content:center;" onclick="document.getElementById('modal-telegram').style.display='none'"><i class="fas fa-times"></i></button>
            </div>
            
            <div class="protected" style="padding: 20px;">
                <div style="background: rgba(56, 189, 248, 0.05); border: 1px solid rgba(56, 189, 248, 0.2); padding: 12px; border-radius: 12px; margin-bottom: 20px; display:flex; align-items:center; gap:15px;">
                    <i class="fas fa-info-circle" style="font-size:1.8rem; color:#38bdf8;"></i>
                    <p style="margin:0; font-size:0.9rem; color:var(--text-muted); line-height: 1.5;"><span data-i18n="tg_modal_intro_main">لڤێرە داتایێن خۆ ببەستە ب تێلیگرامیڤە بۆ پاراستنا زانیاریان.</span><br><b style="color:#10b981;" data-i18n="tg_modal_intro_bold">نوی: باک ئەپی داتابەیسێ (JSON) ئوتوماتیکی هەر ٣ دەمژمێران جارەکێ دێ هێتە ناردن بێ کێشە!</b></p>
                </div>

                <div style="display:grid; grid-template-columns: 1fr 1fr; gap:15px;">
                    <div>
                        <label style="font-weight:bold; color:var(--text); margin-bottom:5px; display:block; font-size:0.9rem;"><i class="fas fa-id-badge text-brand"></i> <span data-i18n="tg_label_chat_id">ناسنامەی چاتێ</span></label>
                        <input type="text" id="tg-chat-id" class="input-std" data-i18n-placeholder="tg_placeholder_chat_id" placeholder="نموونە: 123456789، 987654321…" style="border-radius: 10px; border: 1px solid var(--border); padding: 10px; background: var(--input-bg); margin:0;">
                    </div>
                    <div>
                        <label style="font-weight:bold; color:var(--text); margin-bottom:5px; display:block; font-size:0.9rem;"><i class="fas fa-key text-info"></i> <span data-i18n="tg_label_bot_token">تۆکنێ بۆتێ</span></label>
                        <input type="password" id="tg-bot-token" class="input-std" data-i18n-placeholder="tg_placeholder_bot_token" placeholder="7123456789:AAH…" style="border-radius: 10px; border: 1px solid var(--border); padding: 10px; background: var(--input-bg); margin:0;">
                    </div>
                    <!-- Auto report removed as per plan -->

                    <div style="grid-column: 1 / -1; background: rgba(255,255,255,0.03); padding: 15px; border-radius: 12px; border: 1px solid var(--border);">
                        <h4 style="margin: 0 0 15px 0; font-size: 1rem; color: var(--brand);"><i class="fas fa-user-clock"></i> <span data-i18n="tg_section_shift_reports">ڕاپۆرتێن شفتێ</span></h4>
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                            <label class="setting-toggle-card" for="set-tg-shift-start-report" style="margin:0; padding:10px;">
                                <div style="flex:1;">
                                    <div style="font-weight:bold; font-size:0.85rem;" data-i18n="tg_shift_start_title">دەستپێکرنا شفتێ</div>
                                    <small style="opacity:0.7; font-size:0.75rem;" data-i18n="tg_shift_start_hint">ناردنا نامەیێ ل دەستپێکێ</small>
                                </div>
                                <div class="toggle-switch"><input type="checkbox" id="set-tg-shift-start-report" onchange="savePrintSettings(); updateToggleCards()"><span class="slider"></span></div>
                            </label>
                            
                            <label class="setting-toggle-card" for="set-tg-shift-end-report" style="margin:0; padding:10px;">
                                <div style="flex:1;">
                                    <div style="font-weight:bold; font-size:0.85rem;" data-i18n="tg_shift_end_title">دوماهیک ئینانا شفتێ</div>
                                    <small style="opacity:0.7; font-size:0.75rem;" data-i18n="tg_shift_end_hint">ناردنا ڕاپۆرتێ ل دوماهیکێ</small>
                                </div>
                                <div class="toggle-switch"><input type="checkbox" id="set-tg-shift-end-report" onchange="savePrintSettings(); updateToggleCards()"><span class="slider"></span></div>
                            </label>

                            <label class="setting-toggle-card" for="set-tg-include-cash-in-drawer" style="margin:0; padding:10px;">
                                <div style="flex:1;">
                                    <div style="font-weight:bold; font-size:0.85rem;" data-i18n="tg_cash_drawer_title">پارێ قاسێ</div>
                                    <small style="opacity:0.7; font-size:0.75rem;" data-i18n="tg_cash_drawer_hint">دیارکرنا پارێ د قاسێ دا</small>
                                </div>
                                <div class="toggle-switch"><input type="checkbox" id="set-tg-include-cash-in-drawer" onchange="savePrintSettings(); updateToggleCards()"><span class="slider"></span></div>
                            </label>

                            <div>
                                <label style="font-weight:bold; color:var(--text); margin-bottom:5px; display:block; font-size:0.85rem;"><span data-i18n="tg_report_type_label">جۆرێ ڕاپۆرتێ</span></label>
                                <select id="set-tg-report-type" class="input-std" style="border-radius: 10px; border: 1px solid var(--border); padding: 8px; background: var(--input-bg); margin:0; width:100%; font-size:0.85rem;" onchange="savePrintSettings()">
                                    <option value="full" data-i18n-opt="tg_report_type_full">📊 ڕاپۆرتا گشتی</option>
                                    <option value="no_profit" data-i18n-opt="tg_report_type_no_profit">📝 بێ قازانج (وردەکاری)</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                
                <hr style="border-color:var(--border); margin:20px 0;">
                
                <div style="display:grid; grid-template-columns: 1fr 1fr 1fr; gap:10px;">
                    <button class="btn btn-brand" style="padding: 12px; border-radius: 10px; font-size:0.9rem;" onclick="sendTelegramReport()"><i class="fas fa-paper-plane"></i> <span data-i18n="tg_btn_send_data">ناردنا داتایان</span></button>
                    <button class="btn btn-dark" style="padding: 12px; border-radius: 10px; font-size:0.9rem;" onclick="manualTelegramSend()"><i class="fas fa-comment-dots"></i> <span data-i18n="tg_btn_manual_msg">نامەیەکا دەستی</span></button>
                    <button class="btn btn-danger" style="padding: 12px; border-radius: 10px; font-size:0.9rem;" onclick="downloadPDFReport()"><i class="fas fa-file-pdf"></i> <span data-i18n="tg_btn_pdf_download">PDF دابەزێنە</span></button>
                </div>
            </div>
        </div>
    </div>

    <!-- SAVE INDICATOR -->
    <div id="save-indicator" class="save-indicator">
        <i class="fas fa-save"></i> هاتە پاراستن...
    </div>
    
    <!-- SHOP OWNER GUIDE -->
    <div id="modal-shop-guide" class="modal-overlay shop-guide-overlay" style="display:none;" role="dialog" aria-labelledby="shop-guide-title" aria-modal="true">
        <div class="shop-guide-shell glass-card">
            <header class="shop-guide-head">
                <div>
                    <h2 id="shop-guide-title"><i class="fas fa-graduation-cap"></i> <span data-i18n="shop_guide_title">ڕێبەرێ تەمام یێ دوکانێ</span></h2>
                    <p class="shop-guide-sub" data-i18n="shop_guide_subtitle">هەمی داتا: فرۆشتن، کرین، زڤراندن، کریار، کومپانی، کوگەه، مەزاختن، تەلەف — ب ڕوونی و فێرکرن</p>
                </div>
                <div class="shop-guide-head-actions">
                    <span class="shop-guide-badge" data-pos-app-version>v<?php echo htmlspecialchars(defined('POS_APP_VERSION') ? POS_APP_VERSION : '', ENT_QUOTES, 'UTF-8'); ?></span>
                    <button type="button" class="btn btn-sm btn-dark" onclick="closeShopGuideModal()" aria-label="Close">✖</button>
                </div>
            </header>
            <div class="shop-guide-body">
                <nav id="shop-guide-nav" class="shop-guide-nav" aria-label="Guide sections"></nav>
                <main id="shop-guide-content" class="shop-guide-content"></main>
            </div>
        </div>
    </div>

    <!-- EDIT PAYMENT MODAL -->
    <div id="edit-payment-modal" class="modal-overlay" style="display:none;" role="dialog" aria-labelledby="epm-title">
        <div class="glass-card" style="width: 450px; text-align: right; display:flex; flex-direction:column;">
            <div style="border-bottom:1px solid var(--border); padding:12px 15px; display:flex; justify-content:space-between; align-items:center;">
                <h2 id="epm-title" style="margin:0; color:var(--brand);"><i class="fas fa-edit"></i> تەعدیل کرنا پارەی</h2>
                <button class="btn btn-sm btn-dark" style="font-size:1.05rem; padding:6px 12px;" onclick="closeEditPaymentModal()" title="داخستن">✖</button>
            </div>
            
            <input type="hidden" id="epm-payment-id">
            <input type="hidden" id="epm-current-amount">

            <div style="padding:20px;">
                <label for="epm-new-amount" style="font-size:0.95rem; font-weight:bold; margin-bottom:8px; display:block;">بڕێ نوی یێ پارەی بنووسە:</label>
                <div style="display:flex; align-items:center; gap:10px;">
                    <input type="number" id="epm-new-amount" class="input-std" style="font-size:1.2rem; font-weight:bold; text-align:left; direction:ltr; margin:0;" inputmode="numeric" onkeydown="if(event.key==='Enter') saveEditPaymentModal()">
                    <span id="epm-currency-sym" style="font-weight:bold; color:var(--text-muted); font-size:1.1rem;"></span>
                </div>
                <small style="color:var(--text-muted); display:block; margin-top:8px;">بڕێ تۆمارکریێ نوکە: <span id="epm-old-amount-display" style="font-weight:bold; color:var(--brand);" dir="ltr"></span></small>
            </div>

            <div class="page-action-row" style="display:flex; padding:15px; border-top:1px solid var(--border);">
                <div class="page-actions-standard" style="display:flex; gap:10px; width:100%; justify-content:flex-end;">
                    <button class="btn btn-primary" style="padding:10px 20px; font-weight:bold;" onclick="saveEditPaymentModal()"><i class="fas fa-save"></i> پاراستن (Save)</button>
                    <button class="btn btn-dark" style="padding:10px 20px;" onclick="closeEditPaymentModal()">پاشگەزبوونەوە</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Jewelry weight entry (replaces ugly window.prompt) -->
    <div id="modal-jewelry-weight" class="modal-overlay" style="display:none; z-index:2147483010; backdrop-filter:blur(6px);" role="dialog" aria-modal="true" aria-labelledby="jewelry-weight-modal-title" onclick="if(event.target===this && typeof closeJewelryWeightModal==='function')closeJewelryWeightModal(false);">
        <div class="glass-card" style="width:min(380px,92vw); text-align:right; display:flex; flex-direction:column; border:1px solid rgba(201,162,39,0.35); box-shadow:0 16px 48px rgba(0,0,0,0.28);" onclick="event.stopPropagation();">
            <div style="padding:16px 18px 8px; display:flex; justify-content:space-between; align-items:center; gap:10px;">
                <h2 id="jewelry-weight-modal-title" style="margin:0; color:#a67c00; font-size:1.15rem;"><i class="fas fa-weight-hanging"></i> کێش (گرام)</h2>
                <button type="button" class="btn btn-sm btn-dark" onclick="if(typeof closeJewelryWeightModal==='function')closeJewelryWeightModal(false);" title="داخستن">✖</button>
            </div>
            <div style="padding:4px 18px 16px;">
                <p id="jewelry-weight-modal-meta" style="margin:0 0 12px 0; font-size:0.9rem; color:var(--text-muted); min-height:1.2em;"></p>
                <label class="product-form-label" for="jewelry-weight-modal-input" style="color:#a67c00;"><i class="fas fa-balance-scale"></i> گرام</label>
                <input type="number" id="jewelry-weight-modal-input" class="input-std" min="0.001" step="0.001" placeholder="0.000" dir="ltr" style="font-size:1.6rem; font-weight:800; text-align:center; padding:14px 12px; border:2px solid rgba(201,162,39,0.55); border-radius:12px; background:rgba(201,162,39,0.08);" onkeydown="if(event.key==='Enter'){event.preventDefault(); if(typeof closeJewelryWeightModal==='function')closeJewelryWeightModal(true);} if(event.key==='Escape'){event.preventDefault(); if(typeof closeJewelryWeightModal==='function')closeJewelryWeightModal(false);}">
                <p style="margin:10px 0 0; font-size:0.8rem; color:#94a3b8;">نرخ ب گرام × نرخی ڕۆژانە حیساب دبیت</p>
            </div>
            <div style="display:flex; gap:8px; padding:14px 18px; border-top:1px solid var(--border);">
                <button type="button" class="btn btn-dark" style="flex:1;" onclick="if(typeof closeJewelryWeightModal==='function')closeJewelryWeightModal(false);">هەڵوەشاندن</button>
                <button type="button" class="btn btn-brand" style="flex:2; background:linear-gradient(135deg,#c9a227,#a67c00); border:none;" onclick="if(typeof closeJewelryWeightModal==='function')closeJewelryWeightModal(true);"><i class="fas fa-check"></i> باشیە</button>
            </div>
        </div>
    </div>

    <!-- Jewelry daily metal rates (POS quick entry — jewelry mode only) -->
    <div id="modal-jewelry-daily-rates" class="modal-overlay jewelry-only" style="display:none; z-index:2147483000;" role="dialog" aria-modal="true" aria-labelledby="jewelry-rates-modal-title" onclick="if(event.target===this && typeof closeJewelryDailyRatesModal==='function')closeJewelryDailyRatesModal();">
        <div class="glass-card" style="width:min(520px,96vw); text-align:right; display:flex; flex-direction:column;" onclick="event.stopPropagation();">
            <div style="border-bottom:1px solid var(--border); padding:14px 16px; display:flex; justify-content:space-between; align-items:center; gap:10px;">
                <h2 id="jewelry-rates-modal-title" style="margin:0; color:#a67c00; font-size:1.15rem;"><i class="fas fa-coins"></i> نرخی ڕۆژانە — کڕین و فرۆشتن</h2>
                <button type="button" class="btn btn-sm btn-dark" onclick="if(typeof closeJewelryDailyRatesModal==='function')closeJewelryDailyRatesModal();" title="داخستن">✖</button>
            </div>
            <div style="padding:16px;">
                <p style="margin:0 0 12px 0; font-size:0.85rem; color:var(--text-muted);">نرخی هەر <strong>گرام</strong>ێک (دینار) — کڕین = بە چەند دەکڕیت، فرۆشتن = بە چەند دەفرۆشیت.</p>

                <div style="margin-bottom:14px; padding:12px; border-radius:12px; background:rgba(148,163,184,0.12); border:1px solid rgba(148,163,184,0.35);">
                    <div style="display:flex; justify-content:space-between; align-items:center; gap:8px; margin-bottom:8px;">
                        <div style="font-weight:800; color:#64748b;"><i class="fas fa-circle"></i> زیڤ — دەرجە (گرام)</div>
                        <button type="button" class="btn btn-sm btn-brand" onclick="if(typeof promptAddSilverGrade==='function')promptAddSilverGrade(true)"><i class="fas fa-plus"></i> دەرجە</button>
                    </div>
                    <div style="display:grid; grid-template-columns:1.2fr 1fr 1fr auto; gap:6px; margin-bottom:6px; font-size:0.75rem; font-weight:700; color:#64748b;">
                        <span>ناڤ / دەرجە</span>
                        <span style="text-align:center;">کڕین</span>
                        <span style="text-align:center;">فرۆشتن</span>
                        <span></span>
                    </div>
                    <div id="pos-jew-silver-grades-list"></div>
                </div>

                <div style="padding:12px; border-radius:12px; background:rgba(201,162,39,0.1); border:1px solid rgba(201,162,39,0.35);">
                    <div style="font-weight:800; margin-bottom:8px; color:#a67c00;"><i class="fas fa-certificate"></i> زێر (گرام)</div>
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px; margin-bottom:8px;">
                        <div style="font-size:0.75rem; font-weight:700; color:#64748b; text-align:center;">کڕین</div>
                        <div style="font-size:0.75rem; font-weight:700; color:#64748b; text-align:center;">فرۆشتن</div>
                    </div>
                    <div style="display:grid; grid-template-columns:auto 1fr 1fr; gap:8px; align-items:center; margin-bottom:6px;">
                        <span style="font-weight:700; font-size:0.85rem;">21K</span>
                        <input type="number" id="pos-jew-buy-21" class="input-std" min="0" step="1" placeholder="کڕین" dir="ltr">
                        <input type="number" id="pos-jew-rate-21" class="input-std" min="0" step="1" placeholder="فرۆشتن" dir="ltr">
                    </div>
                    <div style="display:grid; grid-template-columns:auto 1fr 1fr; gap:8px; align-items:center; margin-bottom:6px;">
                        <span style="font-weight:700; font-size:0.85rem;">18K</span>
                        <input type="number" id="pos-jew-buy-18" class="input-std" min="0" step="1" placeholder="کڕین" dir="ltr">
                        <input type="number" id="pos-jew-rate-18" class="input-std" min="0" step="1" placeholder="فرۆشتن" dir="ltr">
                    </div>
                    <div style="display:grid; grid-template-columns:auto 1fr 1fr; gap:8px; align-items:center; margin-bottom:6px;">
                        <span style="font-weight:700; font-size:0.85rem;">22K</span>
                        <input type="number" id="pos-jew-buy-22" class="input-std" min="0" step="1" placeholder="کڕین" dir="ltr">
                        <input type="number" id="pos-jew-rate-22" class="input-std" min="0" step="1" placeholder="فرۆشتن" dir="ltr">
                    </div>
                    <div style="display:grid; grid-template-columns:auto 1fr 1fr; gap:8px; align-items:center;">
                        <span style="font-weight:700; font-size:0.85rem;">24K</span>
                        <input type="number" id="pos-jew-buy-24" class="input-std" min="0" step="1" placeholder="کڕین" dir="ltr">
                        <input type="number" id="pos-jew-rate-24" class="input-std" min="0" step="1" placeholder="فرۆشتن" dir="ltr">
                    </div>
                </div>
            </div>
            <div style="display:flex; gap:8px; padding:14px 16px; border-top:1px solid var(--border);">
                <button type="button" class="btn btn-dark" style="flex:1;" onclick="if(typeof closeJewelryDailyRatesModal==='function')closeJewelryDailyRatesModal();">داخستن</button>
                <button type="button" class="btn btn-brand" style="flex:2;" onclick="if(typeof saveJewelryDailyRatesFromModal==='function')saveJewelryDailyRatesFromModal();"><i class="fas fa-save"></i> پاراستن</button>
            </div>
        </div>
    </div>

    <!-- OTA APP UPDATE ALERT (Supabase) -->
    <div id="modal-pos-ota-update" class="modal-overlay" style="display:none; backdrop-filter:blur(8px); z-index:2147483020 !important;" role="dialog" aria-modal="true" aria-labelledby="pos-ota-modal-title">
        <div class="glass-card" style="width:min(540px,94vw); text-align:right; display:flex; flex-direction:column;">
            <div style="border-bottom:1px solid var(--border); padding:14px 16px; display:flex; justify-content:space-between; align-items:center; gap:10px;">
                <h2 id="pos-ota-modal-title" style="margin:0; color:#6ee7b7; font-size:1.15rem;"><i class="fas fa-cloud-download-alt"></i> نوێکردنەوەی سیستەم</h2>
                <div style="display:flex; gap:6px; align-items:center;">
                    <button type="button" class="btn btn-sm btn-info" id="pos-ota-modal-minimize" onclick="if(typeof posOtaMinimizeModal==='function')posOtaMinimizeModal();" title="بچووک بکە ل بنێ — بەردەوامی کار"><i class="fas fa-window-minimize"></i></button>
                    <button type="button" class="btn btn-sm btn-dark" id="pos-ota-modal-close" onclick="if(typeof posOtaDismissModal==='function')posOtaDismissModal();" title="بچووک بکە / دواتر">✖</button>
                </div>
            </div>
            <div style="padding:18px 16px;">
                <p id="pos-ota-modal-status" style="margin:0 0 12px; font-size:1rem; font-weight:700; color:var(--text);" dir="auto">…</p>
                <p id="pos-ota-modal-version" style="margin:0 0 10px; font-size:1.05rem; font-weight:700; color:var(--brand);" dir="ltr"></p>
                <p id="pos-ota-modal-body" style="margin:0; color:var(--text-muted); line-height:1.7; white-space:pre-wrap; font-size:0.92rem;" dir="auto"></p>
                <div id="pos-ota-modal-progress" style="display:none; margin-top:16px;">
                    <div style="height:10px; background:rgba(148,163,184,0.25); border-radius:999px; overflow:hidden;">
                        <div id="pos-ota-modal-progress-bar" style="height:100%; width:0%; background:linear-gradient(90deg,#10b981,#059669); transition:width .3s;"></div>
                    </div>
                    <p id="pos-ota-modal-progress-text" style="margin:8px 0 0; font-size:0.88rem; color:#fbbf24; font-weight:600;"></p>
                </div>
                <p style="margin:14px 0 0; font-size:0.82rem; color:#94a3b8;" data-i18n="ota_modal_footer_hint">داتا پاراستیە · بشێی کار بکەیت دەمێ داونلۆدێ · دوگمێ بچووک ل بنێ</p>
            </div>
            <div class="page-action-row" style="display:flex; padding:14px 16px; border-top:1px solid var(--border); gap:8px; flex-wrap:wrap; justify-content:flex-end;">
                <button type="button" class="btn btn-dark" id="pos-ota-modal-later" onclick="if(typeof posOtaDismissModal==='function')posOtaDismissModal();" title="بچووک بکە ل بنێ — بەردەوامی کار"><i class="fas fa-compress-arrows-alt"></i> <span id="pos-ota-modal-later-label">بچووک بکە — بەردەوامی کار</span></button>
                <button type="button" class="btn btn-info" id="pos-ota-modal-check" onclick="if(typeof posOtaCheckUpdate==='function')posOtaCheckUpdate(true);"><i class="fas fa-sync-alt"></i> پشکنین</button>
                <button type="button" class="btn btn-success" id="pos-ota-modal-apply" style="display:none;" onclick="if(typeof posOtaDownloadAndApply==='function')posOtaDownloadAndApply();"><i class="fas fa-bolt"></i> ئێستا نوێ بکە</button>
            </div>
        </div>
    </div>

    <!-- SUB-DEVICE & NETWORK MODAL -->
    <div id="sub-device-network-modal" class="modal-overlay" style="display:none;" onclick="if(event.target===this&&typeof closeSubDeviceNetworkModal==='function')closeSubDeviceNetworkModal();">
        <div class="glass-card" style="width:min(920px, 96vw); max-height:94vh; overflow-y:auto; padding:0;">
            <div style="padding:16px 20px; border-bottom:1px solid var(--border); display:flex; justify-content:space-between; align-items:flex-start; gap:12px; position:sticky; top:0; background:var(--card); z-index:10;">
                <div>
                    <h2 style="margin:0; font-size:1.2rem;"><i class="fas fa-network-wired"></i> <span data-i18n="subdev_mgmt_title">ژێرسیستەم و تۆڕ · Sub-device & Network</span></h2>
                    <p class="subdev-mgmt__subtitle" style="margin-top:6px;" data-i18n="subdev_mgmt_subtitle">هەر خانەیەک ($99) = یەک لاپتۆپ/موبایل — کۆدی سیکوریتی لە ڕێکخستنەکان دروست دەکرێت، پێویست بە ئادمین نییە.</p>
                </div>
                <div style="display:flex; gap:6px; align-items:center; flex-shrink:0;">
                    <button type="button" class="btn btn-dark btn-sm" onclick="if(typeof loadSubDeviceNetworkPanel==='function')loadSubDeviceNetworkPanel(true);" title="نوێکردنەوە"><i class="fas fa-sync"></i></button>
                    <button type="button" class="btn btn-dark btn-sm" onclick="if(typeof closeSubDeviceNetworkModal==='function')closeSubDeviceNetworkModal();">✖</button>
                </div>
            </div>
            <div class="subdev-mgmt" style="padding:20px;">
                <div id="subdev-tier-gate" class="subdev-mgmt__gate" style="display:none;">
                    <i class="fas fa-crown"></i>
                    <p id="subdev-tier-gate-msg" data-i18n="subdev_pro_required">Pro پێویستە بۆ سیستەمە لاوەکییەکان — سەرەتا بەرز بکەرەوە بۆ Pro.</p>
                    <button type="button" class="btn btn-brand btn-sm" onclick="if(typeof showPremiumLockedPurchasePopup==='function')showPremiumLockedPurchasePopup('');">
                        <i class="fas fa-lock-open"></i> <span data-i18n="subdev_upgrade_btn">بەرزکردنەوە</span>
                    </button>
                </div>

                <div id="subdev-mgmt-body" style="display:none;">
                    <div class="subdev-profile card-inset">
                        <div class="subdev-profile__icon"><i class="fas fa-laptop"></i></div>
                        <div class="subdev-profile__body">
                            <p class="subdev-profile__label" data-i18n="subdev_primary_profile">پڕۆفایلی لاپتۆپێ سەرەکی</p>
                            <p class="subdev-profile__serial" id="subdev-primary-serial" dir="ltr">—</p>
                            <p class="subdev-profile__meta" id="subdev-primary-meta">—</p>
                            <p class="subdev-profile__capacity" id="subdev-purchased-summary">—</p>
                        </div>
                        <span class="subdev-badge subdev-badge--primary" data-i18n="subdev_role_primary">سەرەکی</span>
                    </div>

                    <div class="subdev-section">
                        <div class="subdev-section__head">
                            <h4><i class="fas fa-shield-halved"></i> <span data-i18n="subdev_license_slots_title">خانەکانی سیکوریتی · لاپتۆپی فرعی</span></h4>
                            <span class="subdev-price-tag"><i class="fas fa-shield-halved"></i> <span data-i18n="subdev_slot_security_badge">١ خانە = ١ لاپتۆپی فرعی</span></span>
                        </div>
                        <div id="subdev-license-slots" class="subdev-slots-grid"></div>
                    </div>

                    <div class="subdev-section">
                        <h4><i class="fas fa-history"></i> <span data-i18n="subdev_history_title">مێژووی کڕین / دابەشکردن</span></h4>
                        <div id="subdev-purchase-history" class="subdev-history-list"></div>
                    </div>

                    <div class="subdev-section">
                        <div class="subdev-section__head">
                            <h4><i class="fas fa-wifi"></i> <span data-i18n="subdev_connections_title">ئامێرێن پەیوەست · Connection Monitor</span></h4>
                        </div>
                        <div id="subdev-device-list" class="subdev-device-list"></div>
                    </div>

                    <div class="subdev-section subdev-section--toggle">
                        <p id="settings-multi-device-lock-hint" style="display:none; margin:0 0 10px 0; color:var(--warning); font-size:0.9rem;" data-i18n="settings_multi_device_pro_lock">Pro تەنها یەک ئامێر — بۆ چەند ئامێرە بەرزبکەرەوە بۆ Pro Plus.</p>
                        <label class="toggle-card" style="margin-bottom:0;">
                            <input type="checkbox" id="set-enable-multi-device" onchange="if(db&&db.settings){db.settings.enableMultiDeviceTerminal=this.checked;} if(typeof applyMultiDeviceSettingsUI==='function')applyMultiDeviceSettingsUI(); if(typeof saveSettings==='function')saveSettings().catch(function(){});">
                            <span data-i18n="settings_multi_device_toggle">چالاککردنی تۆمارکردنی ئامێرێن لاوەکی (LAN/Wi‑Fi)</span>
                        </label>
                        <p class="subdev-hint" data-i18n="subdev_access_hint">دوای کڕینی خانە، کۆدی TERM خۆکار دروست دەبێت — لە لاپتۆپ/موبایلی فرعی لە ڕێکخستنەکان بنووسە. ١ خانە = ١ ئامێر (MAC).</p>
                    </div>
                </div>

                <p id="subdev-load-error" class="subdev-error" style="display:none;"></p>
            </div>
        </div>
    </div>

    <!-- FIREBASE / MOBILE SYNC MODAL -->
    <div id="firebase-sync-modal" class="modal-overlay" style="display:none;" onclick="if(event.target===this&&typeof closeFirebaseSyncModal==='function')closeFirebaseSyncModal();">
        <div class="glass-card" style="width:min(860px, 96vw); max-height:94vh; overflow-y:auto; padding:0;">
            <div style="padding:16px 20px; border-bottom:1px solid var(--border); display:flex; justify-content:space-between; align-items:flex-start; gap:12px; background:var(--card); position:sticky; top:0; z-index:10;">
                <div>
                    <h2 style="margin:0; font-size:1.2rem;"><i class="fas fa-mobile-screen-button"></i> <span data-i18n="firebase_sync_title">تەزامونا موبایلێ</span></h2>
                    <p class="firebase-sync-card__tagline" style="margin-top:6px;" data-i18n="firebase_sync_desc">پێزانینێن سیستەمی ئوتوماتیکی دهێنە هنارتن بو بەرنامێ موبایلێ.</p>
                </div>
                <button type="button" class="btn btn-dark btn-sm" onclick="if(typeof closeFirebaseSyncModal==='function')closeFirebaseSyncModal();">✖</button>
            </div>
            <div class="firebase-sync-card" style="padding:20px; border:0; box-shadow:none;">
                <div class="firebase-sync-purpose" aria-label="sync scope">
                    <div class="firebase-sync-purpose__item">
                        <i class="fas fa-chart-line" aria-hidden="true"></i>
                        <span data-i18n="firebase_sync_chip_sales">فرۆشتن و داهات</span>
                    </div>
                    <div class="firebase-sync-purpose__item">
                        <i class="fas fa-boxes-stacked" aria-hidden="true"></i>
                        <span data-i18n="firebase_sync_chip_inventory">کۆگە و کاڵا</span>
                    </div>
                    <div class="firebase-sync-purpose__item">
                        <i class="fas fa-file-invoice" aria-hidden="true"></i>
                        <span data-i18n="firebase_sync_chip_reports">ڕاپۆرت و ئامار</span>
                    </div>
                    <div class="firebase-sync-purpose__item">
                        <i class="fas fa-scale-balanced" aria-hidden="true"></i>
                        <span>قەرز (کڕیار · کۆمپانیا)</span>
                    </div>
                </div>

                <p class="firebase-sync-note"><i class="fas fa-shield-halved" aria-hidden="true"></i> <span data-i18n="firebase_sync_note">تەنها هنارتن — داتای ناو سیستەم ناگۆڕدرێت.</span></p>
                <p id="firebase-sync-last-err" class="firebase-sync-note" style="display:none;color:var(--danger,#b91c1c);margin-top:6px;"></p>

                <div class="firebase-sync-info">
                    <div class="firebase-sync-info__item">
                        <span class="firebase-sync-info__label" data-i18n="firebase_label_email">ئیمێیل</span>
                        <span class="firebase-sync-info__value" id="firebase-sync-email" dir="ltr">—</span>
                    </div>
                    <div class="firebase-sync-info__item">
                        <span class="firebase-sync-info__label" data-i18n="firebase_label_channel">کەناڵ</span>
                        <span class="firebase-sync-info__value" id="firebase-sync-kioskid" dir="ltr">—</span>
                    </div>
                    <div class="firebase-sync-info__item">
                        <span class="firebase-sync-info__label" data-i18n="firebase_label_last_sync">دوایین هاوکات</span>
                        <span class="firebase-sync-info__value" id="firebase-sync-last">—</span>
                    </div>
                </div>

                <div class="firebase-sync-actions">
                    <button type="button" id="firebase-sync-connect-btn" class="btn btn-brand btn-sm" onclick="if(typeof openFirebaseSyncLogin==='function')openFirebaseSyncLogin();"><i class="fas fa-link"></i> <span data-i18n="firebase_sync_new">پەیوەستکردنی هەژماری نوێ</span></button>
                    <button type="button" class="btn btn-info btn-sm" onclick="if(typeof posFirebaseSyncNow==='function')posFirebaseSyncNow();else if(typeof scheduleFirebaseMobilePush==='function'){scheduleFirebaseMobilePush('manual',true);if(typeof pushFirebaseMobileDebtOnly==='function')pushFirebaseMobileDebtOnly(true);}"><i class="fas fa-sync"></i> <span data-i18n="firebase_sync_now">ئێستا هاوکات بکە</span></button>
                    <button type="button" class="btn btn-info btn-sm" onclick="if(typeof posExportDbToCloud==='function')posExportDbToCloud();"><i class="fas fa-cloud-upload-alt"></i> <span data-i18n="firebase_cloud_backup_btn">Backup → Mobile Manager</span></button>
                    <button type="button" class="btn btn-dark btn-sm" onclick="if(typeof logoutFirebaseSync==='function')logoutFirebaseSync();"><i class="fas fa-sign-out-alt"></i> <span data-i18n="firebase_sync_close">دەرچوون</span></button>
                </div>

                <div class="firebase-sync-privacy" id="firebase-sync-privacy-block" style="margin-top:14px;padding:14px 16px;border-radius:12px;background:var(--input-bg,rgba(15,23,42,.35));border:1px solid var(--border,rgba(148,163,184,.2));">
                    <h4 style="margin:0 0 6px;font-size:0.92rem;display:flex;align-items:center;gap:8px;">
                        <i class="fas fa-eye-slash" style="color:var(--warning,#f59e0b);"></i>
                        <span data-i18n="firebase_mobile_privacy_title">تایبەتمەندی بینین لە موبایل</span>
                    </h4>
                    <p style="margin:0 0 12px;font-size:0.78rem;color:var(--text-muted);line-height:1.5;" data-i18n="firebase_mobile_privacy_desc">هەڵبژێرە چی بۆ ئەپ و PDF نەنێردرێت — دوای گۆڕانکاری «ئێستا هاوکات بکە» بکە.</p>
                    <div style="display:flex;flex-direction:column;gap:10px;">
                        <label style="display:flex;align-items:flex-start;gap:10px;cursor:pointer;font-size:0.85rem;line-height:1.45;">
                            <input type="checkbox" id="set-mobile-hide-profit" style="margin-top:3px;accent-color:var(--brand);" onchange="if(typeof onMobileSyncPrivacyChange==='function')onMobileSyncPrivacyChange('profit');">
                            <span><strong data-i18n="firebase_mobile_hide_profit">شاردنەوەی قازانج</strong><br><small style="color:var(--text-muted);" data-i18n="firebase_mobile_hide_profit_hint">قازانجی خاو لە داشبۆرد · سەرەکی · PDF · کارتەکانی دووکان دەردەنەخات</small></span>
                        </label>
                        <label style="display:flex;align-items:flex-start;gap:10px;cursor:pointer;font-size:0.85rem;line-height:1.45;">
                            <input type="checkbox" id="set-mobile-hide-sales-detail" style="margin-top:3px;accent-color:var(--brand);" onchange="if(typeof onMobileSyncPrivacyChange==='function')onMobileSyncPrivacyChange('salesDetail');">
                            <span><strong data-i18n="firebase_mobile_hide_sales">شاردنەوەی وردەکاری فرۆشتن</strong><br><small style="color:var(--text-muted);" data-i18n="firebase_mobile_hide_sales_hint">لیستی پسوولە و ئایتمەکان لە موبایل و PDF نادەن — ژمارەی پسوولە و کۆی فرۆشتن دەمێننەوە</small></span>
                        </label>
                    </div>
                </div>

                <div class="firebase-sync-mobile-app" id="firebase-mobile-app-block" style="margin-top:14px;padding-top:14px;border-top:1px dashed var(--border,rgba(148,163,184,.25));">
                    <h4 style="margin:0 0 8px;font-size:0.95rem;display:flex;align-items:center;gap:8px;">
                        <i class="fas fa-mobile-screen-button" style="color:var(--brand);"></i>
                        <span data-i18n="firebase_mobile_app_title">ئەپێ موبایل مانجێر</span>
                    </h4>
                    <p style="margin:0 0 10px;font-size:0.82rem;color:var(--text-muted);" data-i18n="firebase_mobile_app_desc">لینکەکە لە مۆبایل بکەرەوە و «دامەزراندن» بگرە — وەک ئەپی سەربەخۆ.</p>
                    <div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:10px;">
                        <code id="firebase-mobile-app-url" dir="ltr" style="flex:1;min-width:200px;font-size:0.75rem;padding:8px 10px;border-radius:8px;background:var(--input-bg,rgba(0,0,0,.15));word-break:break-all;">https://laptopduhokpos.github.io/LP/mobile_manager/</code>
                        <button type="button" class="btn btn-sm btn-info" onclick="if(typeof copyMobileManagerUrl==='function')copyMobileManagerUrl();"><i class="fas fa-copy"></i> <span data-i18n="firebase_mobile_copy">کۆپی</span></button>
                        <button type="button" class="btn btn-sm btn-brand" onclick="if(typeof openMobileManagerApp==='function')openMobileManagerApp();"><i class="fas fa-external-link-alt"></i> <span data-i18n="firebase_mobile_open">کردنەوە</span></button>
                    </div>
                    <div style="display:flex;gap:14px;align-items:flex-start;flex-wrap:wrap;">
                        <img id="firebase-mobile-app-qr" alt="QR — Mobile Manager" width="120" height="120" style="border-radius:10px;background:#fff;padding:6px;display:block;min-width:120px;min-height:120px;object-fit:contain;" />
                        <ol style="margin:0;padding-inline-start:18px;font-size:0.8rem;color:var(--text-muted);line-height:1.6;flex:1;min-width:180px;">
                            <li data-i18n="firebase_mobile_step1">لینک لە مۆبایل بکەرەوە (Chrome / Safari)</li>
                            <li data-i18n="firebase_mobile_step2">چوونەژوورەوە بە هەمان ئیمێیل/تێپەڕەوشەی Firebase</li>
                            <li data-i18n="firebase_mobile_step3">Android: دامەزراندن · iPhone: Add to Home Screen</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- SETTINGS INSTALL / LICENSE CODES MODAL -->
    <div id="settings-install-codes-modal" class="modal-overlay" style="display:none;" onclick="if(event.target===this&&typeof closeSettingsInstallCodesModal==='function')closeSettingsInstallCodesModal();">
        <div class="glass-card" style="width:min(720px, 96vw); max-height:94vh; overflow-y:auto; padding:0;">
            <div style="padding:16px 20px; border-bottom:1px solid var(--border); display:flex; justify-content:space-between; align-items:flex-start; gap:12px; background:var(--card); position:sticky; top:0; z-index:10;">
                <div>
                    <h2 style="margin:0; font-size:1.2rem;"><i class="fas fa-shield-alt"></i> <span data-i18n="settings_install_codes_title">کۆدێن ناسنامەیێ (دامەزراندن)</span></h2>
                </div>
                <button type="button" class="btn btn-dark btn-sm" onclick="if(typeof closeSettingsInstallCodesModal==='function')closeSettingsInstallCodesModal();">✖</button>
            </div>
            <div id="settings-install-codes" class="settings-install-codes" style="padding:20px;" aria-label="Installation codes">
                <p style="margin: 0 0 16px 0; color: var(--text-muted); font-size: 0.9rem;" data-i18n="settings_install_codes_intro">ئەڤ ژماران تایبەتن ب ڤێ دامەزراندنێ، بۆ چالاککرنێ ل دەف مە بینە.</p>
                <div class="settings-install-codes-grid">
                    <div class="settings-install-code-block">
                        <p class="settings-install-code-label"><i class="fas fa-key"></i> <span data-i18n="settings_security_code_label">کۆدی ناسنامەیێ</span></p>
                        <code id="settings-install-security" class="settings-install-code-value settings-install-code-security" dir="ltr"><?php echo htmlspecialchars($pos_settings_security_code ?: '—', ENT_QUOTES, 'UTF-8'); ?></code>
                    </div>
                    <div class="settings-install-code-block">
                        <p class="settings-install-code-label"><i class="fas fa-laptop"></i> <span data-i18n="settings_install_serial_label">سیریاڵێ دامەزراندن</span></p>
                        <code id="settings-install-serial" class="settings-install-code-value" dir="ltr"><?php echo htmlspecialchars($pos_settings_install_serial ?: '—', ENT_QUOTES, 'UTF-8'); ?></code>
                    </div>
                </div>
                <p class="settings-install-code-hint" data-i18n="settings_install_codes_hint">هەردوو ژمارە پێدڤین — بۆ پشتراستکرنا ئامێر و ترخیسێ.</p>
                <div class="settings-activation-code-row" style="margin-top:16px; padding-top:16px; border-top:1px dashed var(--border);">
                    <p class="settings-install-code-label"><i class="fas fa-crown"></i> <span data-i18n="settings_activation_code_label">کۆدی چالاککرنێ</span></p>
                    <p style="margin:0 0 10px 0; color:var(--text-muted); font-size:0.9rem;" data-i18n="settings_activation_code_hint">کۆدی پشتی کڕینێ ل ڤێرێ بنڤیسە.</p>
                    <div style="display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
                        <input type="text" id="settings-activation-code-input" class="input-std" dir="ltr" placeholder="PRO-XXXX-XXXX" autocomplete="off" style="flex:1; min-width:200px; text-transform:uppercase;" />
                        <button type="button" class="btn btn-brand" onclick="if(typeof redeemActivationCode==='function')redeemActivationCode();"><i class="fas fa-check"></i> <span data-i18n="settings_activation_redeem_btn">چالاککرن</span></button>
                    </div>
                    <p id="settings-activation-code-msg" class="activation-msg" style="margin-top:8px; font-size:0.9rem;"></p>
                </div>
            </div>
        </div>
    </div>

    <!-- SETTINGS CHANGELOG MODAL -->
    <div id="settings-changelog-modal" class="modal-overlay" style="display:none;" onclick="if(event.target===this&&typeof closeSettingsChangelogModal==='function')closeSettingsChangelogModal();">
        <div class="glass-card" style="width:min(720px, 96vw); max-height:94vh; overflow:hidden; padding:0; display:flex; flex-direction:column;">
            <div style="padding:16px 20px; border-bottom:1px solid var(--border); display:flex; justify-content:space-between; align-items:flex-start; gap:12px; background:var(--card); flex-shrink:0;">
                <div>
                    <h2 style="margin:0; font-size:1.2rem; color:#93c5fd;"><i class="fas fa-list-ul"></i> <span data-settings-i18n="settings_changelog_title">تۆمارا نوێکرن</span></h2>
                    <p style="margin:8px 0 0; color:var(--text-muted); font-size:0.82rem;" data-settings-i18n="settings_changelog_desc">نوێترین لە سەرەوە — کلیک بکە بۆ وردەکاری. بۆ وەشانە کۆنەکان بجوڵێنە خوارەوە.</p>
                </div>
                <button type="button" class="btn btn-dark btn-sm" onclick="if(typeof closeSettingsChangelogModal==='function')closeSettingsChangelogModal();">✖</button>
            </div>
            <div style="padding:16px 20px; overflow:hidden; flex:1; min-height:0; display:flex; flex-direction:column;">
                <div class="settings-changelog-scroll-wrap" id="settings-changelog-scroll-wrap">
                    <div id="settings-changelog-list" class="settings-changelog-list" aria-live="polite"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- REVENUE COMPARISON MODAL -->
    <div id="revenue-comparison-modal" class="modal-overlay" style="display:none;" onclick="if(event.target===this&&typeof closeRevenueComparisonModal==='function')closeRevenueComparisonModal();">
        <div class="glass-card" style="width:min(1200px, 96vw); max-height:94vh; overflow-y:auto; padding:0;">
            <div style="padding:16px 20px; border-bottom:1px solid var(--border); display:flex; justify-content:space-between; align-items:center; sticky:top; background:var(--card); z-index:10;">
                <h2 style="margin:0; font-size:1.25rem;"><i class="fas fa-chart-line"></i> <span data-i18n="reports_revenue_comparison">هەڤبەرکرنا داهاتی</span></h2>
                <button type="button" class="btn btn-dark btn-sm" onclick="closeRevenueComparisonModal()">✖</button>
            </div>
            <div style="padding:20px;">
                <div class="rev-comp-card-inner">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; flex-wrap:wrap; gap:12px;">
                        <div style="display:flex; gap:6px; flex-wrap:wrap;">
                            <button type="button" class="btn btn-sm btn-primary" onclick="applyRevenuePreset('month_vs_month')"><span data-i18n="reports_rev_preset_mvm">هەڤە هەیڤ</span></button>
                            <button type="button" class="btn btn-sm btn-primary" onclick="applyRevenuePreset('year_vs_year')"><span data-i18n="reports_rev_preset_yvy">٢ ساڵ</span></button>
                            <button type="button" class="btn btn-sm btn-info" onclick="applyRevenuePreset('last_4_weeks')"><span data-i18n="reports_rev_preset_4w">٤ هەفتە</span></button>
                            <button type="button" class="btn btn-sm btn-info" onclick="applyRevenuePreset('last_5_years')"><span data-i18n="reports_rev_preset_5y">٥ ساڵ</span></button>
                            <button type="button" class="btn btn-sm btn-warning" onclick="applyRevenuePreset('last_4_blocks_10d')"><span data-i18n="reports_rev_preset_4b10">٤ بلۆکی ١٠ ڕۆژ</span></button>
                            <button type="button" class="btn btn-sm" style="background:var(--input-bg);" onclick="applyRevenuePreset('10d_vs_10d')"><span data-i18n="reports_rev_preset_10d2">١٠ ڕۆژ × ٢</span></button>
                        </div>
                    </div>
                    <div id="rev-comp-periods-wrap" class="rev-comp-periods-wrap">
                        <!-- Dynamic period rows -->
                    </div>
                    <div style="display:flex; align-items:center; gap:10px; margin-bottom:16px; flex-wrap:wrap;">
                        <button type="button" class="btn btn-success btn-sm" onclick="loadRevenueComparison()"><i class="fas fa-sync-alt"></i> <span data-i18n="comparison">هەڤبەرکرن</span></button>
                        <button type="button" class="btn btn-sm" style="background:rgba(59,130,246,0.2); color:#93c5fd; border:1px dashed #3b82f6;" id="rev-comp-add-period-btn" onclick="revCompAddPeriod()"><i class="fas fa-plus"></i> <span data-i18n="reports_rev_add_period">زیادکردنی چەند بەروار</span></button>
                    </div>
                    <div id="rev-comp-summary-cards" class="rev-comp-summary-cards">
                        <!-- Filled by JS -->
                    </div>
                    <div style="height:400px; background:rgba(15,23,42,0.6); padding:16px; border-radius:12px; border:1px solid rgba(255,255,255,0.06);">
                        <canvas id="rev-comp-chart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- SIDEBAR OVERLAY (For Mobile/Tablet) -->
    <div id="sidebar-overlay" class="sidebar-overlay" onclick="toggleSidebar()"></div>

    <div id="modal-wh-pin" class="modal-overlay" style="display:none;" onclick="if(event.target===this)closeWarehousePinModal();">
        <div class="glass-card" style="width:380px;max-width:94vw;text-align:right;" onclick="event.stopPropagation();">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
                <h3 id="wh-pin-title" style="margin:0;">ڤەکرنا کۆگەهێ</h3>
                <button type="button" class="btn btn-sm btn-dark" onclick="closeWarehousePinModal()">✖</button>
            </div>
            <p id="wh-pin-name" style="margin:0 0 10px;font-weight:700;color:var(--brand);"></p>
            <label style="display:block;font-size:0.85rem;margin-bottom:4px;">پاسۆرد (٤–٨ ژمارە)</label>
            <input type="password" id="wh-pin-input" class="input-std" inputmode="numeric" maxlength="8" autocomplete="off" style="width:100%;margin-bottom:10px;" onkeydown="if(event.key==='Enter'){event.preventDefault();submitWarehousePin();}">
            <div id="wh-pin-confirm-wrap" style="display:none;">
                <label style="display:block;font-size:0.85rem;margin-bottom:4px;">دووبارە پاسۆرد</label>
                <input type="password" id="wh-pin-input-2" class="input-std" inputmode="numeric" maxlength="8" autocomplete="off" style="width:100%;margin-bottom:10px;" onkeydown="if(event.key==='Enter'){event.preventDefault();submitWarehousePin();}">
            </div>
            <div style="display:flex;gap:8px;flex-wrap:wrap;">
                <button type="button" class="btn btn-brand" onclick="submitWarehousePin()"><i class="fas fa-unlock"></i> باشە</button>
                <button type="button" class="btn btn-dark" onclick="closeWarehousePinModal()">هەڵوەشاندن</button>
                <button type="button" id="wh-pin-clear-btn" class="btn btn-danger" style="display:none;margin-inline-start:auto;" onclick="clearWarehousePin()">ژێبرنا پاسۆردێ</button>
            </div>
        </div>
    </div>
    <div id="modal-wh-pick" class="modal-overlay" style="display:none;" onclick="if(event.target===this)closePosWarehousePicker();">
        <div class="glass-card" style="width:400px;max-width:94vw;text-align:right;" onclick="event.stopPropagation();">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
                <h3 style="margin:0;">کۆگەها فرۆتنێ</h3>
                <button type="button" class="btn btn-sm btn-dark" onclick="closePosWarehousePicker()">✖</button>
            </div>
            <p style="margin:0 0 10px;color:var(--text-muted);font-size:0.9rem;">کۆگەهەکێ ڤەکە — فرۆتن تەنها ژ وێرێ دچیت. گرتن: دوگمەیا قفڵێ ل سەرێ فرۆتنێ.</p>
            <div id="wh-pick-list" style="display:flex;flex-direction:column;gap:8px;"></div>
            <button type="button" class="btn btn-dark" style="margin-top:12px;width:100%;" onclick="if(typeof lockOpenWarehouse==='function'){lockOpenWarehouse();closePosWarehousePicker();}">قفڵکرنا کۆگەها ڤەکری</button>
        </div>
    </div>

    <!-- MENU FAB -->
    <button class="menu-fab" onclick="toggleSidebar()"><i class="fas fa-bars"></i></button>

