<?php
/**
 * نفس مدخل index.php — للاستخدام مع الرابط Laptopduhok-POS.php
 */
require __DIR__ . '/index.php';
