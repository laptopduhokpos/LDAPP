@echo off
chcp 65001 >nul
title Laptop Duhok POS — دامەزراندن
echo.
echo  لاپتۆپێ نوی / فۆرماتکری
echo.
if not exist "C:\xampp\apache\bin\httpd.exe" (
  echo  سەرەتا فولدرێ C:\xampp ژ USB یان هارد کۆپی بکە بۆ ڤی لاپتۆپی.
  echo  پاشان ڤی فایلێ دوبارە بکە.
  echo.
  pause
  exit /b 1
)
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\tools\launcher\Install-DesktopIcon.ps1" -ExePath "%~dp0LaptopDuhokPOS.exe"
echo.
echo  ئایکۆن ل سەر مێزێ هاتە دانان: Laptop Duhok POS
echo  دوو جاران کلیک بکە — بەرنامە ڤەدبیت.
echo.
start "" "%~dp0LaptopDuhokPOS.exe"
exit /b 0
