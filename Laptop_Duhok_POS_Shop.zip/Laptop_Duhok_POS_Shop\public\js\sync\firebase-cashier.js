/**
 * Firebase mobile sync (read-only push): KPI doc + daily detail + warehouse inventory for public/mobile_manager/.
 * Does not import cloud data into local POS — one-way laptop → Firestore only.
 */
(function () {
    if (window.__posFirebaseSyncLoaded) return;
    window.__posFirebaseSyncLoaded = true;

    var FB_VER = "10.12.5";
    var MIN_PUSH_MS = 8000;
    var PUSH_INTERVAL_MS = 8000;
    var pendingPush = { reason: null, force: false };
    var pendingAfterPush = false;
    var LS_LAST_SYNC = "pos_firebase_last_sync_ms";
    var LS_LAST_ERR = "pos_firebase_last_err";
    var LS_LAST_CLOUD_BACKUP = "pos_firebase_last_cloud_backup_v1";
    var LS_SHOP_FIREBASE_ACCOUNT = "pos_firebase_shop_account_v1";

    var syncState = {
        modules: null,
        app: null,
        auth: null,
        db: null,
        lastPushAt: 0,
        lastDebtPushAt: 0,
        pushing: false,
        authUnsub: null,
        pushIntervalId: null
    };

    function getPosDb() {
        try {
            if (typeof window.db !== "undefined" && window.db) return window.db;
        } catch (e) {}
        return null;
    }

    function getShopFirebaseAccountRecord() {
        var db = getPosDb();
        if (db && db.settings && db.settings.firebaseAccountEmail) {
            return {
                email: String(db.settings.firebaseAccountEmail).trim().toLowerCase(),
                createdAt: Number(db.settings.firebaseAccountCreatedAt) || 0
            };
        }
        try {
            var raw = localStorage.getItem(LS_SHOP_FIREBASE_ACCOUNT);
            if (raw) {
                var parsed = JSON.parse(raw);
                if (parsed && parsed.email) return parsed;
            }
        } catch (e) {}
        return null;
    }

    function markShopFirebaseAccountCreated(email) {
        email = String(email || "").trim().toLowerCase();
        if (!email) return;
        var rec = { email: email, createdAt: Date.now() };
        try {
            localStorage.setItem(LS_SHOP_FIREBASE_ACCOUNT, JSON.stringify(rec));
        } catch (e) {}
        var db = getPosDb();
        if (db) {
            if (!db.settings) db.settings = {};
            db.settings.firebaseAccountEmail = email;
            db.settings.firebaseAccountCreatedAt = rec.createdAt;
            if (typeof saveSettings === "function") {
                saveSettings().catch(function () {});
            }
        }
        if (typeof window.updateFirebaseSyncUI === "function") {
            window.updateFirebaseSyncUI();
        }
    }

    function canCreateShopFirebaseAccount() {
        return !getShopFirebaseAccountRecord();
    }

    window.getShopFirebaseAccountRecord = getShopFirebaseAccountRecord;
    window.canCreateShopFirebaseAccount = canCreateShopFirebaseAccount;

    function isValidFirebaseGmail(email) {
        email = String(email || "").trim().toLowerCase();
        if (!email || email.indexOf("@") < 1) return false;
        var dom = email.split("@")[1] || "";
        return !!(dom && dom.indexOf(".") >= 1 && dom !== "0");
    }

    /** Shop saved a Firebase/mobile Gmail (settings or localStorage). */
    function shopHasFirebaseGmail() {
        var rec = getShopFirebaseAccountRecord();
        if (rec && isValidFirebaseGmail(rec.email)) return true;
        var db = getPosDb();
        if (db && db.settings && isValidFirebaseGmail(db.settings.firebaseAccountEmail)) return true;
        var u = syncState.auth && syncState.auth.currentUser;
        return !!(u && isValidFirebaseGmail(u.email));
    }

    /** Currently signed in to Firebase with a real email. */
    function firebaseLinkedEmail() {
        var u = syncState.auth && syncState.auth.currentUser;
        if (u && isValidFirebaseGmail(u.email)) return String(u.email).trim().toLowerCase();
        return "";
    }

    window.shopHasFirebaseGmail = shopHasFirebaseGmail;
    window.isFirebaseGmailLinked = function () {
        return !!firebaseLinkedEmail();
    };

    function quietSkipNoGmail() {
        if (firebaseLinkedEmail()) return null;
        if (!shopHasFirebaseGmail()) {
            return Promise.resolve({ skipped: true, reason: "not_authed" });
        }
        return null;
    }

    function recordFirebaseErr(err) {
        if (!firebaseLinkedEmail()) return;
        try {
            localStorage.setItem(LS_LAST_ERR, String(err && err.message ? err.message : err));
        } catch (e) {}
    }

    function clearFirebaseErr() {
        try {
            localStorage.removeItem(LS_LAST_ERR);
        } catch (e) {}
    }

    function bootFirebaseQuietly() {
        if (!shopHasFirebaseGmail()) {
            clearFirebaseErr();
            notifyUi();
            return Promise.resolve();
        }
        return ensureFirebaseApp()
            .then(function () {
                notifyUi();
            })
            .catch(function () {
                notifyUi();
            });
    }

    function ensureShopFirebaseAccountFromSession() {
        if (getShopFirebaseAccountRecord()) return;
        var u = syncState.auth && syncState.auth.currentUser;
        if (u && u.email) markShopFirebaseAccountCreated(u.email);
    }

    function queuePendingPush(reason, force) {
        pendingPush.reason = reason || pendingPush.reason || "queued";
        if (force) pendingPush.force = true;
    }

    function flushPendingPush() {
        if (!getPosDb()) return;
        if (!syncState.auth || !syncState.auth.currentUser || !syncState.auth.currentUser.email) return;
        if (!pendingPush.reason && !pendingPush.force) {
            window.scheduleFirebaseMobilePush("db_ready", true);
            scheduleDebtPushRetries();
            return;
        }
        var r = pendingPush.reason || "db_ready";
        var f = !!pendingPush.force;
        pendingPush = { reason: null, force: false };
        window.scheduleFirebaseMobilePush(r, f || true);
        scheduleDebtPushRetries();
    }

    window.posFirebasePushAfterDbReady = function () {
        bootFirebaseQuietly();
        flushPendingPush();
    };

    function scheduleDebtPushRetries() {
        [1500, 5000, 15000, 45000].forEach(function (ms) {
            setTimeout(function () {
                if (!syncState.auth || !syncState.auth.currentUser || !syncState.auth.currentUser.email) {
                    return;
                }
                if (typeof window.pushFirebaseMobileDebtOnly === "function") {
                    window.pushFirebaseMobileDebtOnly(true).catch(function () {});
                }
            }, ms);
        });
    }
    window.scheduleDebtPushRetries = scheduleDebtPushRetries;

    function startPeriodicMobilePush() {
        if (syncState.pushIntervalId) return;
        syncState.pushIntervalId = setInterval(function () {
            if (syncState.auth && syncState.auth.currentUser && syncState.auth.currentUser.email) {
                window.scheduleFirebaseMobilePush("interval", false);
                if (typeof window.pushFirebaseMobileDebtOnly === "function") {
                    window.pushFirebaseMobileDebtOnly(false).catch(function () {});
                }
            }
        }, PUSH_INTERVAL_MS);
    }

    function stopPeriodicMobilePush() {
        if (syncState.pushIntervalId) {
            clearInterval(syncState.pushIntervalId);
            syncState.pushIntervalId = null;
        }
    }

    function getConfig() {
        return window.POS_FIREBASE_CONFIG || null;
    }

    function channelIdFromUser(user) {
        if (!user || !user.email) return "";
        return String(user.email).toLowerCase();
    }

    function lastSyncDisplay() {
        try {
            var ms = parseInt(localStorage.getItem(LS_LAST_SYNC) || "0", 10);
            if (!ms) {
                if (typeof window.t === "function") {
                    var none = window.t("firebase_sync_last_none");
                    if (none && none !== "firebase_sync_last_none") return none;
                }
                return "—";
            }
            var d = new Date(ms);
            var loc = typeof window.getDateLocale === "function" ? window.getDateLocale() : "ar-IQ";
            if (typeof window.formatProfileDateTime === "function") {
                return window.formatProfileDateTime(d, loc);
            }
            return d.toLocaleString(loc, {
                year: "numeric",
                month: "short",
                day: "numeric",
                hour: "2-digit",
                minute: "2-digit",
                second: "2-digit",
                hour12: false
            });
        } catch (e) {
            return "—";
        }
    }

    window.getFirebaseSyncStatus = function () {
        var u = syncState.auth && syncState.auth.currentUser;
        return {
            connected: !!(u && u.email),
            email: u && u.email ? u.email : "",
            kioskId: u ? channelIdFromUser(u) : "—",
            lastSync: lastSyncDisplay()
        };
    };

    function notifyUi() {
        if (typeof window.updateFirebaseSyncUI === "function") {
            try {
                window.updateFirebaseSyncUI();
            } catch (e) {}
        }
    }

    function removeStaleFirebaseLocks() {
        try {
            var o = document.getElementById("pos-access-lock-overlay");
            if (o) o.remove();
            var old = document.getElementById("firebase-cashier-auth-modal");
            if (old) old.remove();
        } catch (e) {}
    }

    removeStaleFirebaseLocks();
    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", removeStaleFirebaseLocks);
    }

    function loadModules() {
        if (syncState.modules) return Promise.resolve(syncState.modules);
        var base = "https://www.gstatic.com/firebasejs/" + FB_VER + "/";
        return Promise.all([
            import(base + "firebase-app.js"),
            import(base + "firebase-auth.js"),
            import(base + "firebase-firestore.js"),
            import(base + "firebase-database.js"),
            import(base + "firebase-storage.js")
        ]).then(function (mods) {
            syncState.modules = {
                initializeApp: mods[0].initializeApp,
                getAuth: mods[1].getAuth,
                signInWithEmailAndPassword: mods[1].signInWithEmailAndPassword,
                createUserWithEmailAndPassword: mods[1].createUserWithEmailAndPassword,
                signOut: mods[1].signOut,
                onAuthStateChanged: mods[1].onAuthStateChanged,
                setPersistence: mods[1].setPersistence,
                browserLocalPersistence: mods[1].browserLocalPersistence,
                getFirestore: mods[2].getFirestore,
                doc: mods[2].doc,
                getDoc: mods[2].getDoc,
                setDoc: mods[2].setDoc,
                updateDoc: mods[2].updateDoc,
                onSnapshot: mods[2].onSnapshot,
                runTransaction: mods[2].runTransaction,
                serverTimestamp: mods[2].serverTimestamp,
                getDatabase: mods[3].getDatabase,
                ref: mods[3].ref,
                onValue: mods[3].onValue,
                getStorage: mods[4].getStorage,
                storageRef: mods[4].ref,
                uploadBytes: mods[4].uploadBytes,
                deleteObject: mods[4].deleteObject,
                getDownloadURL: mods[4].getDownloadURL
            };
            return syncState.modules;
        });
    }

    function ensureFirebaseApp() {
        var cfg = getConfig();
        if (!cfg || !cfg.apiKey) return Promise.reject(new Error("Missing POS_FIREBASE_CONFIG"));
        return loadModules().then(function (M) {
            if (!syncState.app) {
                syncState.app = M.initializeApp(cfg);
                syncState.auth = M.getAuth(syncState.app);
                syncState.db = M.getFirestore(syncState.app);
                syncState.rtdb = M.getDatabase(syncState.app);

                if (syncState.authUnsub) {
                    try {
                        syncState.authUnsub();
                    } catch (e) {}
                }
                return M.setPersistence(syncState.auth, M.browserLocalPersistence)
                    .catch(function () {})
                    .then(function () {
                        syncState.authUnsub = M.onAuthStateChanged(syncState.auth, function (user) {
                            if (user && user.email) {
                                ensureShopFirebaseAccountFromSession();
                                startPeriodicMobilePush();
                                if (getPosDb()) {
                                    window.scheduleFirebaseMobilePush("auth", true);
                                    scheduleDebtPushRetries();
                                    setTimeout(function () {
                                        if (typeof window.pushFirebaseMobileDebtOnly === "function") {
                                            window.pushFirebaseMobileDebtOnly(true).catch(function () {});
                                        }
                                    }, 2500);
                                    setTimeout(function () {
                                        if (typeof window.pushLatestLocalBackupToCloud === "function") {
                                            window.pushLatestLocalBackupToCloud(false).catch(function () {});
                                        }
                                    }, 12000);
                                } else {
                                    queuePendingPush("auth", true);
                                }
                            } else {
                                stopPeriodicMobilePush();
                                pendingPush = { reason: null, force: false };
                            }
                            notifyUi();
                        });
                        return syncState;
                    });
            }
            return syncState;
        });
    }

    function safeParseItems(items) {
        if (!items) return [];
        if (typeof items === "string") {
            try {
                var p = JSON.parse(items);
                return Array.isArray(p) ? p : [];
            } catch (e) {
                return [];
            }
        }
        return Array.isArray(items) ? items : [];
    }

    function todayBusinessDateStr() {
        if (typeof window.getBusinessDate === "function") {
            return window.getBusinessDate(new Date());
        }
        return new Date().toISOString().slice(0, 10);
    }

    /** Canonical IQD for mobile — DB always stores IQD even when POS display is USD. */
    function mobileStoredIqd(val) {
        if (typeof normalizeStoredIqdValue === "function") {
            return normalizeStoredIqdValue(val);
        }
        if (typeof roundMoney === "function") {
            return roundMoney(val, "IQD");
        }
        return Math.round(Number(val) || 0);
    }

    function getMobilePrivacyFlags() {
        var db = getPosDb();
        var s = db && db.settings ? db.settings : {};
        return {
            hideProfit: !!(
                s.mobileHideProfit === true ||
                s.mobileHideProfit === 1 ||
                s.mobileHideProfit === "true"
            ),
            hideSalesDetail: !!(
                s.mobileHideSalesDetail === true ||
                s.mobileHideSalesDetail === 1 ||
                s.mobileHideSalesDetail === "true"
            )
        };
    }

    function mobileSyncMeta(businessDateStr, extra) {
        var posDb = getPosDb();
        var bizStartHour = 0;
        if (posDb && posDb.settings && posDb.settings.businessDayStartHour !== undefined) {
            var sh = parseInt(posDb.settings.businessDayStartHour, 10);
            if (Number.isFinite(sh) && sh >= 0 && sh <= 23) bizStartHour = sh;
        }
        var meta = {
            businessDate: businessDateStr,
            businessDayStartHour: bizStartHour,
            shopTimezone: "Asia/Baghdad",
            app: "pos_web",
            amountCurrency: "IQD",
            posDisplayCurrency:
                typeof getActiveCurrency === "function"
                    ? getActiveCurrency()
                    : "IQD",
            usdRatePerOne:
                typeof getUsdRatePerOne === "function" ? getUsdRatePerOne() : 0,
            v: 3
        };
        if (extra) {
            Object.keys(extra).forEach(function (k) {
                meta[k] = extra[k];
            });
        }
        return meta;
    }

    function buildExtendedPayload(businessDateStr) {
        var metrics =
            typeof window.getFinancialMetrics === "function"
                ? window.getFinancialMetrics(businessDateStr)
                : null;
        if (!metrics) {
            return null;
        }

        var netSales = Number(metrics.netProfit) > 0 ? (Number(metrics.totalSales) || 0) : ((Number(metrics.totalSales) || 0) - (Number(metrics.totalReturns) || 0));
        var kpi = {
            salesToday: mobileStoredIqd(metrics.totalSales),
            expensesToday: mobileStoredIqd(metrics.totalOpExpenses || metrics.opExpenses),
            netProfitToday: mobileStoredIqd(metrics.netProfit),
            invoicesCountToday: 0
        };

        var salesRaw =
            typeof window.getAllSales === "function"
                ? window.getAllSales(false).filter(function (s) {
                      return (
                          window.getBusinessDate(new Date(s.date)) === businessDateStr
                      );
                  })
                : [];
        kpi.invoicesCountToday = salesRaw.length;

        var privacy = getMobilePrivacyFlags();
        if (privacy.hideProfit) {
            kpi.netProfitToday = null;
        }

        function groupSaleLineItems(rawItems) {
            var grouped = {};
            (rawItems || []).forEach(function (it) {
                var qty =
                    Number(it.qty) > 0
                        ? Number(it.qty)
                        : Number(it.count) > 0
                          ? Number(it.count)
                          : 1;
                var price = mobileStoredIqd(Number(it.price) || 0);
                var saleUnit = it.saleUnit || "piece";
                var note = String(it.note || "");
                var key =
                    String(it.id || it.name || "") +
                    "_" +
                    note +
                    "_" +
                    price +
                    "_" +
                    saleUnit;
                if (!grouped[key]) {
                    grouped[key] = {
                        name: String(it.name || "").slice(0, 200),
                        qty: 0,
                        price: price,
                        saleUnit: saleUnit
                    };
                }
                grouped[key].qty += qty;
            });
            return Object.keys(grouped).map(function (k) {
                return grouped[k];
            });
        }

        var salesOut = [];
        var maxSales = privacy.hideSalesDetail ? 0 : 100;
        for (var i = 0; i < salesRaw.length && salesOut.length < maxSales; i++) {
            var s = salesRaw[i];
            var items = groupSaleLineItems(safeParseItems(s.items)).slice(0, 100);
            salesOut.push({
                id: s.id,
                date: s.date,
                total: mobileStoredIqd(s.total),
                cashier: String(s.cashier || "").slice(0, 80),
                payment_method: String(s.payment_method || "").slice(0, 40),
                is_returned: s.is_returned == 1,
                items: items
            });
        }

        var db = getPosDb();
        var returnsOut = [];
        var expensesOut = [];
        if (db) {
            if (db.returns && db.returns.length) {
                db.returns.forEach(function (r) {
                    if (
                        typeof window.getBusinessDate === "function" &&
                        window.getBusinessDate(new Date(r.date)) === businessDateStr
                    ) {
                        returnsOut.push({
                            id: r.id,
                            date: r.date,
                            total: mobileStoredIqd(r.total),
                            sale_id: r.sale_id
                        });
                    }
                });
            }
            if (db.expenses && db.expenses.length) {
                db.expenses.forEach(function (e) {
                    if (
                        typeof window.getBusinessDate === "function" &&
                        window.getBusinessDate(new Date(e.date)) === businessDateStr && 
                        e.type !== 'capital'
                    ) {
                        expensesOut.push({
                            id: e.id,
                            date: e.date,
                            amount: mobileStoredIqd(e.amount),
                            type: e.type || "operational",
                            note: String(e.note || "").slice(0, 200)
                        });
                    }
                });
            }
            var purchasesGrouped = {};
            if (db.supplies && db.supplies.length) {
                db.supplies.forEach(function (s) {
                    if (s.type === "return") return;
                    if (
                        typeof window.getBusinessDate !== "function" ||
                        window.getBusinessDate(new Date(s.date)) !== businessDateStr
                    ) {
                        return;
                    }
                    var key =
                        s.transaction_id ||
                        "OLD_" + String(s.date) + "_" + String(s.prodId || "");
                    if (!purchasesGrouped[key]) {
                        var invNo = "";
                        if (typeof resolveCompanyInvoiceDisplayNumber === "function") {
                            invNo = resolveCompanyInvoiceDisplayNumber(
                                s.supplier_invoice_number,
                                s.transaction_id
                            );
                        } else {
                            invNo = String(
                                s.supplier_invoice_number || s.transaction_id || ""
                            ).trim();
                        }
                        purchasesGrouped[key] = {
                            invoiceNo: String(invNo || "---").slice(0, 80),
                            company: String(s.company || "").slice(0, 120),
                            total: 0
                        };
                    }
                    purchasesGrouped[key].total += mobileStoredIqd(s.totalCost);
                });
            }
            var purchasesOut = Object.keys(purchasesGrouped).map(function (k) {
                return purchasesGrouped[k];
            });
            purchasesOut.sort(function (a, b) {
                return String(b.invoiceNo || "").localeCompare(
                    String(a.invoiceNo || ""),
                    undefined,
                    { numeric: true }
                );
            });
        }

        var purchasesOutFinal =
            typeof purchasesOut !== "undefined" ? purchasesOut.slice(0, 100) : [];

        return {
            kpi: kpi,
            sales: salesOut,
            returns: returnsOut.slice(0, 100),
            expenses: expensesOut.slice(0, 100),
            purchases: purchasesOutFinal,
            privacy: privacy,
            meta: mobileSyncMeta(businessDateStr, {
                truncatedSales: !privacy.hideSalesDetail && salesRaw.length > maxSales,
                salesTotalRows: salesRaw.length,
                purchasesCount: purchasesOutFinal.length,
                hideProfit: privacy.hideProfit,
                hideSalesDetail: privacy.hideSalesDetail
            })
        };
    }

    function resolveDefaultWarehouseId(db) {
        if (!db || !db.warehouses || !db.warehouses.length) return 0;
        var def = db.warehouses.find(function (w) {
            return Number(w.is_default) === 1;
        });
        return def ? Number(def.id) : Number(db.warehouses[0].id);
    }

    function resolveWarehouseName(db, whId) {
        if (!db || !db.warehouses || !whId) return "";
        var w = db.warehouses.find(function (x) {
            return Number(x.id) === Number(whId);
        });
        return w ? String(w.name || "") : "";
    }

    function productQtyForWarehouseSync(p, whId, db) {
        if (!p) return 0;
        var whCount = db && db.warehouses ? db.warehouses.length : 0;
        var strictMulti =
            whCount > 1 &&
            ((typeof window.canUseMultiWarehouse === "function" &&
                window.canUseMultiWarehouse()) ||
                (db.settings &&
                    (db.settings.enableMultiWarehouse === true ||
                        db.settings.enableMultiWarehouse === 1 ||
                        db.settings.enableMultiWarehouse === "true")));
        if (!strictMulti && whCount <= 1) return parseFloat(p.qty) || 0;
        if (!whId) return parseFloat(p.qty) || 0;
        if (typeof window.getProductQtyForWarehouse === "function") {
            return window.getProductQtyForWarehouse(p, whId);
        }
        var whQty = 0;
        var rows = db && db.warehouse_stock ? db.warehouse_stock : [];
        for (var i = 0; i < rows.length; i++) {
            if (
                Number(rows[i].product_id) === Number(p.id) &&
                Number(rows[i].warehouse_id) === Number(whId)
            ) {
                whQty = parseFloat(rows[i].qty) || 0;
                break;
            }
        }
        var productQty = parseFloat(p.qty) || 0;
        if (!strictMulti && productQty > whQty + 0.000001) return productQty;
        return whQty;
    }

    function minStockForProductSync(p, db) {
        if (typeof window.getMinStock === "function") return window.getMinStock(p);
        if (
            db &&
            db.settings &&
            (db.settings.useGlobalMinStock == true ||
                db.settings.useGlobalMinStock == "true" ||
                db.settings.useGlobalMinStock == 1)
        ) {
            return db.settings.globalMinStockThreshold !== undefined &&
                db.settings.globalMinStockThreshold !== null
                ? parseInt(db.settings.globalMinStockThreshold, 10)
                : 5;
        }
        return p &&
            p.minStock !== undefined &&
            p.minStock !== null &&
            p.minStock !== ""
            ? parseInt(p.minStock, 10)
            : 5;
    }

    function movementBusinessDate(m) {
        if (!m || !m.date) return "";
        if (typeof window.getBusinessDate === "function") {
            try {
                return window.getBusinessDate(new Date(m.date));
            } catch (e) {}
        }
        return String(m.date).slice(0, 10);
    }

    function productCostSync(p) {
        if (typeof window.getCatalogPieceCostIqd === "function") {
            return Number(window.getCatalogPieceCostIqd(p)) || 0;
        }
        return parseFloat(p.cost) || 0;
    }

    function productSellSync(p) {
        if (typeof window.getCatalogPieceSellIqd === "function") {
            return Number(window.getCatalogPieceSellIqd(p)) || 0;
        }
        return parseFloat(p.price) || 0;
    }

    function productExpirySync(p) {
        if (typeof window.getProductCatalogExpiryDisplay === "function") {
            var d = window.getProductCatalogExpiryDisplay(p);
            if (d && d !== "-") return String(d).slice(0, 24);
        }
        var raw = p.expiry || p.expiry_date || "";
        return raw ? String(raw).slice(0, 24) : "";
    }

    function buildInventoryPayload(businessDateStr) {
        var db = getPosDb();
        if (!db || !db.products) return null;

        var whId = resolveDefaultWarehouseId(db);
        var whName = resolveWarehouseName(db, whId);
        var warehouses = (db.warehouses || []).map(function (w) {
            return {
                id: Number(w.id),
                name: String(w.name || "").slice(0, 120),
                isDefault: Number(w.is_default) === 1,
                itemCount: (function () {
                    var n = 0;
                    (db.warehouse_stock || []).forEach(function (r) {
                        if (
                            Number(r.warehouse_id) === Number(w.id) &&
                            (parseFloat(r.qty) || 0) > 0
                        ) {
                            n++;
                        }
                    });
                    return n;
                })()
            };
        });

        var tracked = db.products.filter(function (p) {
            return p && p.trackStock;
        });
        var inStock = 0;
        var lowStock = 0;
        var outOfStock = 0;
        var expiringSoon = 0;
        var productsOut = [];
        var maxProducts = 250;

        tracked.forEach(function (p) {
            var qty = productQtyForWarehouseSync(p, whId, db);
            var minS = minStockForProductSync(p, db);
            var cost = productCostSync(p);
            var price = productSellSync(p);
            var lossPrice = cost > price;
            var status = "ok";
            var statusLabel = "باشە";
            if (qty <= 0) {
                outOfStock++;
                status = "out";
                statusLabel = "نەما";
            } else {
                inStock++;
                if (qty <= minS) {
                    lowStock++;
                    status = "low";
                    statusLabel = "کەم";
                }
            }
            var expSoon = false;
            if (
                qty > 0 &&
                typeof window.productCatalogExpiryDaysLeft === "function"
            ) {
                var days = window.productCatalogExpiryDaysLeft(p);
                if (days != null && days <= 60) {
                    expiringSoon++;
                    expSoon = true;
                }
            }
            if (productsOut.length < maxProducts) {
                productsOut.push({
                    id: Number(p.id),
                    name: String(p.name || "").slice(0, 200),
                    barcode: String(p.barcode || "").slice(0, 64),
                    category: String(p.cat || p.category || "").slice(0, 80),
                    manufacturer: String(p.manufacturer || "").trim().slice(0, 80),
                    cost: cost,
                    price: price,
                    qty: qty,
                    minStock: minS,
                    expiry: productExpirySync(p),
                    status: status,
                    statusLabel: statusLabel,
                    lossPrice: lossPrice,
                    expSoon: expSoon,
                    unit_show_pack: p.unit_show_pack != null ? (Number(p.unit_show_pack) === 1) : false,
                    unit_show_carton: p.unit_show_carton != null ? (Number(p.unit_show_carton) === 1) : false,
                    pieces_per_pack: Number(p.pieces_per_pack) || 1,
                    packs_per_carton: Number(p.packs_per_carton) || 1,
                    barcode_pack: String(p.barcode_pack || "").slice(0, 64),
                    barcode_carton: String(p.barcode_carton || "").slice(0, 64),
                    price_pack: p.price_pack != null ? Number(p.price_pack) : null,
                    price_carton: p.price_carton != null ? Number(p.price_carton) : null,
                    cost_pack: p.cost_pack != null ? Number(p.cost_pack) : null,
                    cost_carton: p.cost_carton != null ? Number(p.cost_carton) : null,
                    wholesaleQty: Number(p.wholesaleQty) || 0,
                    wholesalePrice: Number(p.wholesalePrice) || 0,
                    note: String(p.note || "").slice(0, 100)
                });
            }
        });

        productsOut.sort(function (a, b) {
            if (a.qty <= 0 && b.qty > 0) return -1;
            if (a.qty > 0 && b.qty <= 0) return 1;
            return String(a.name).localeCompare(String(b.name), "ku", {
                sensitivity: "base"
            });
        });

        var movs = (db.warehouse_movements || []).filter(function (m) {
            return m && m.movement_type === "stocktake";
        });
        var stocktakeCountTotal = movs.length;
        var stocktakeCountToday = 0;
        var recentStocktakes = [];
        var sessionMap = Object.create(null);
        var maxRecent = 80;
        var maxSessions = 40;

        movs.forEach(function (m, idx) {
            var bd = movementBusinessDate(m);
            if (bd === businessDateStr) stocktakeCountToday++;
            if (idx < maxRecent) {
                recentStocktakes.push({
                    id: Number(m.id),
                    date: String(m.date || "").slice(0, 19),
                    businessDate: bd,
                    productId: Number(m.product_id),
                    productName: String(m.product_name || "").slice(0, 200),
                    qty: Number(m.quantity) || 0,
                    user: String(m.user || "").slice(0, 80),
                    warehouseId: Number(m.warehouse_id) || whId
                });
            }
            var sk = bd + "|" + (Number(m.warehouse_id) || whId);
            if (!sessionMap[sk]) {
                sessionMap[sk] = {
                    businessDate: bd,
                    warehouseId: Number(m.warehouse_id) || whId,
                    warehouseName: resolveWarehouseName(
                        db,
                        Number(m.warehouse_id) || whId
                    ),
                    itemCount: 0,
                    netVariance: 0
                };
            }
            sessionMap[sk].itemCount++;
            sessionMap[sk].netVariance += Number(m.quantity) || 0;
        });

        var stocktakeSessions = Object.keys(sessionMap)
            .map(function (k) {
                return sessionMap[k];
            })
            .sort(function (a, b) {
                return String(b.businessDate).localeCompare(String(a.businessDate));
            })
            .slice(0, maxSessions);

        var catSeen = Object.create(null);
        (db.categories || []).forEach(function (c) {
            var s = String(c || "").trim();
            if (s) catSeen[s] = 1;
        });
        tracked.forEach(function (p) {
            var c = String((p && (p.cat || p.category)) || "").trim();
            if (c) catSeen[c] = 1;
        });
        var categories = Object.keys(catSeen).sort(function (a, b) {
            return a.localeCompare(b, "ku", { sensitivity: "base" });
        });

        return {
            summary: {
                warehouseId: whId,
                warehouseName: whName,
                totalTracked: tracked.length,
                inStock: inStock,
                lowStock: lowStock,
                outOfStock: outOfStock,
                expiringSoon: expiringSoon,
                stocktakeCountTotal: stocktakeCountTotal,
                stocktakeCountToday: stocktakeCountToday,
                stocktakeSessionCount: stocktakeSessions.length
            },
            warehouses: warehouses,
            categories: categories,
            products: productsOut,
            recentStocktakes: recentStocktakes,
            stocktakeSessions: stocktakeSessions,
            meta: mobileSyncMeta(businessDateStr, {
                truncatedProducts: tracked.length > maxProducts,
                productsTotalRows: tracked.length
            })
        };
    }

    function buildDebtPayload() {
        var db = getPosDb();
        if (!db) return null;
        var roundM = mobileStoredIqd;

        function buildNameMap(rows) {
            var map = Object.create(null);
            (rows || []).forEach(function (r) {
                if (!r || r.id == null) return;
                map[String(r.id)] = String(r.name || "").slice(0, 120);
            });
            return map;
        }

        function buildLedgerByKey(entries, keyField, nameMap, maxPerKey, maxKeys) {
            var out = Object.create(null);
            var keyCount = 0;
            for (var i = entries.length - 1; i >= 0; i--) {
                var e = entries[i];
                if (!e) continue;
                var key = String(e[keyField]);
                if (!key || key === "0" || key === "NaN") continue;
                if (!out[key]) {
                    if (keyCount >= maxKeys) continue;
                    out[key] = [];
                    keyCount++;
                }
                if (out[key].length >= maxPerKey) continue;
                out[key].push({
                    type: String(e.type || "").slice(0, 24),
                    amount: roundM(e.amount || 0),
                    date: String(e.date || "").slice(0, 19),
                    note: String(e.note || "").slice(0, 120),
                    name: nameMap[key] || ""
                });
            }
            return out;
        }

        var customerReceivables = 0;
        var customerDebtorCount = 0;
        var customersOut = [];
        (db.customers || []).forEach(function (c) {
            var bal = roundM(c.balance || 0);
            var limit = roundM(c.debt_limit || 0);
            if (bal > 0) {
                customerReceivables += bal;
                customerDebtorCount++;
            }
            if (bal <= 0) return;
            customersOut.push({
                id: Number(c.id),
                name: String(c.name || "").slice(0, 120),
                phone: String(c.phone || "").slice(0, 40),
                balance: bal,
                debtLimit: limit,
                openingBalance: roundM(c.opening_balance || 0),
                overLimit: limit > 0 && bal > limit,
                hasDebt: true
            });
        });
        customersOut.sort(function (a, b) {
            return b.balance - a.balance;
        });
        var maxCust = 200;
        var custTruncated = customersOut.length > maxCust;
        customersOut = customersOut.slice(0, maxCust);

        var supplierPayables = 0;
        var supplierDebtCount = 0;
        var companiesOut = [];
        (db.companies || []).forEach(function (c) {
            var bal = roundM(c.balance || 0);
            if (bal > 0) {
                supplierPayables += bal;
                supplierDebtCount++;
            }
            if (bal <= 0) return;
            var limitC = roundM(c.debt_limit || 0);
            companiesOut.push({
                    id: Number(c.id),
                    name: String(c.name || "").slice(0, 120),
                    phone: String(c.phone || "").slice(0, 40),
                    balance: bal,
                    debtLimit: limitC,
                    openingBalance: roundM(c.opening_balance || 0),
                    overLimit: limitC > 0 && bal > limitC,
                    hasDebt: true
                });
        });
        companiesOut.sort(function (a, b) {
            return b.balance - a.balance;
        });
        var maxComp = 200;
        var compTruncated = companiesOut.length > maxComp;
        companiesOut = companiesOut.slice(0, maxComp);

        var customerLedgerRecent = [];
        var companyLedgerRecent = [];
        var maxLedger = 50;
        var cl = db.customer_ledger || [];
        for (var i = cl.length - 1; i >= 0 && customerLedgerRecent.length < maxLedger; i--) {
            var e = cl[i];
            if (!e) continue;
            var tid = String(e.target_id);
            customerLedgerRecent.push({
                targetId: Number(e.target_id),
                targetType: String(e.target_type || "customer").slice(0, 16),
                type: String(e.type || "").slice(0, 24),
                amount: roundM(e.amount || 0),
                date: String(e.date || "").slice(0, 19),
                note: String(e.note || "").slice(0, 120),
                name: buildNameMap(db.customers)[tid] || ""
            });
        }
        var lg = db.ledger || [];
        for (var j = lg.length - 1; j >= 0 && companyLedgerRecent.length < maxLedger; j--) {
            var le = lg[j];
            if (!le) continue;
            var cid = String(le.companyId);
            companyLedgerRecent.push({
                companyId: Number(le.companyId),
                type: String(le.type || "").slice(0, 24),
                amount: roundM(le.amount || 0),
                date: String(le.date || "").slice(0, 19),
                note: String(le.note || "").slice(0, 120),
                name: buildNameMap(db.companies)[cid] || ""
            });
        }

        var customerNameMap = buildNameMap(db.customers);
        var companyNameMap = buildNameMap(db.companies);
        var customerLedgerById = buildLedgerByKey(cl, "target_id", customerNameMap, 12, 80);
        var companyLedgerById = buildLedgerByKey(lg, "companyId", companyNameMap, 12, 80);

        return {
            summary: {
                customerReceivables: roundM(customerReceivables),
                customerDebtorCount: customerDebtorCount,
                supplierPayables: roundM(supplierPayables),
                supplierDebtCount: supplierDebtCount
            },
            customers: customersOut,
            companies: companiesOut,
            customerLedgerRecent: customerLedgerRecent,
            companyLedgerRecent: companyLedgerRecent,
            customerLedgerById: customerLedgerById,
            companyLedgerById: companyLedgerById,
            meta: mobileSyncMeta(todayBusinessDateStr(), {
                truncatedCustomers: custTruncated,
                truncatedCompanies: compTruncated,
                customersTotalRows: customerDebtorCount,
                companiesTotalRows: supplierDebtCount
            })
        };
    }

    function buildDebtSnapshotLite(debt) {
        if (!debt) return null;
        return {
            summary: debt.summary,
            customers: debt.customers,
            companies: debt.companies,
            customerLedgerRecent: debt.customerLedgerRecent || [],
            companyLedgerRecent: debt.companyLedgerRecent || [],
            meta: debt.meta
        };
    }

    function buildDebtFirestorePayload(debt, M) {
        if (!debt) return null;
        return {
            summary: debt.summary,
            customers: debt.customers,
            companies: debt.companies,
            customerLedgerRecent: debt.customerLedgerRecent,
            companyLedgerRecent: debt.companyLedgerRecent,
            customerLedgerById: debt.customerLedgerById,
            companyLedgerById: debt.companyLedgerById,
            meta: debt.meta,
            updatedAt: M.serverTimestamp()
        };
    }

    function writeDebtDoc(M, debtRef, debtPayload) {
        var lite = {
            summary: debtPayload.summary,
            customers: debtPayload.customers,
            companies: debtPayload.companies,
            customerLedgerRecent: debtPayload.customerLedgerRecent || [],
            companyLedgerRecent: debtPayload.companyLedgerRecent || [],
            meta: debtPayload.meta,
            updatedAt: debtPayload.updatedAt
        };
        return M.setDoc(debtRef, lite, { merge: true })
            .then(function () {
                if (!debtPayload.customerLedgerById && !debtPayload.companyLedgerById) {
                    return lite;
                }
                return M.setDoc(
                    debtRef,
                    {
                        customerLedgerById: debtPayload.customerLedgerById,
                        companyLedgerById: debtPayload.companyLedgerById
                    },
                    { merge: true }
                ).catch(function () {
                    return lite;
                });
            })
            .catch(function (err) {
                return M.setDoc(debtRef, lite, { merge: true }).catch(function () {
                    throw err;
                });
            });
    }

    window.pushFirebaseMobileDebtOnly = function (force) {
        var skip = quietSkipNoGmail();
        if (skip) return skip;
        return ensureFirebaseApp()
            .then(function () {
                var M = syncState.modules;
                var user = syncState.auth.currentUser;
                if (!user || !user.email) {
                    return { skipped: true, reason: "not_authed" };
                }
                var now = Date.now();
                if (!force && now - syncState.lastDebtPushAt < MIN_PUSH_MS) {
                    return { skipped: true, reason: "debounce" };
                }
                var debt = buildDebtPayload();
                if (!debt) {
                    return { skipped: true, reason: "no_db" };
                }
                var ch = channelIdFromUser(user);
                var debtRef = M.doc(syncState.db, "pos_mobile_debt", ch);
                var debtPayload = buildDebtFirestorePayload(debt, M);
                return writeDebtDoc(M, debtRef, debtPayload)
                    .then(function () {
                        syncState.lastDebtPushAt = Date.now();
                        syncState.lastPushAt = Date.now();
                        try {
                            localStorage.setItem(LS_LAST_SYNC, String(syncState.lastPushAt));
                            clearFirebaseErr();
                        } catch (e) {}
                        notifyUi();
                        return { ok: true, debt: true };
                    })
                    .catch(function (err) {
                        recordFirebaseErr(err);
                        return { ok: false, error: err };
                    });
            })
            .catch(function (err) {
                if (!firebaseLinkedEmail() && !shopHasFirebaseGmail()) {
                    return { skipped: true, reason: "not_authed" };
                }
                return { ok: false, error: err };
            });
    };

    function consumeFollowupAcksThen(M, channelId) {
        if (!M || !M.getDoc || !channelId || !syncState.db) {
            return Promise.resolve();
        }
        var ackRef = M.doc(syncState.db, "pos_mobile_followup_ack", channelId);
        return M.getDoc(ackRef)
            .then(function (snap) {
                if (!snap || !snap.exists()) return;
                var acks = (snap.data() || {}).acks;
                if (!acks || typeof acks !== "object") return;
                var keys = Object.keys(acks);
                if (!keys.length) return;
                keys.forEach(function (k) {
                    var a = acks[k] || {};
                    if (typeof window.markSaleFollowupDone === "function") {
                        try {
                            window.markSaleFollowupDone(a.sale_id, a.step_key);
                        } catch (eAck) {}
                    }
                });
                return M.setDoc(
                    ackRef,
                    { acks: {}, updatedAt: M.serverTimestamp() },
                    { merge: true }
                );
            })
            .catch(function () {});
    }

    function processMobilePendingItemsBatch(items) {
        if (!items || !items.length) return Promise.resolve();
        var p = Promise.resolve();
        items.forEach(function (item) {
            p = p.then(function () {
                var fd = new FormData();
                fd.append("action", "save_product");
                fd.append("barcode", item.barcode || "");
                fd.append("name", item.name || "");
                fd.append("price", item.price || 0);
                fd.append("cost", item.cost || 0);
                fd.append("qty", item.qty || 0);
                fd.append("qty_mode", item.qty_mode || "add");
                fd.append("category", item.category || "");
                fd.append("manufacturer", item.manufacturer || "");
                fd.append("supplier", item.supplier || "Direct Store");
                fd.append("product_id", item.id || 0);
                fd.append("trackStock", item.trackStock !== undefined ? item.trackStock : 1);
                fd.append("unit_show_pack", item.unit_show_pack ? 1 : 0);
                fd.append("unit_show_carton", item.unit_show_carton ? 1 : 0);
                fd.append("pieces_per_pack", item.pieces_per_pack || 1);
                fd.append("packs_per_carton", item.packs_per_carton || 1);
                fd.append("barcode_pack", item.barcode_pack || "");
                fd.append("barcode_carton", item.barcode_carton || "");
                if (item.price_pack != null) fd.append("price_pack", item.price_pack);
                if (item.price_carton != null) fd.append("price_carton", item.price_carton);
                if (item.cost_pack != null) fd.append("cost_pack", item.cost_pack);
                if (item.cost_carton != null) fd.append("cost_carton", item.cost_carton);
                if (item.wholesaleQty != null) fd.append("wholesaleQty", item.wholesaleQty);
                if (item.wholesalePrice != null) fd.append("wholesalePrice", item.wholesalePrice);
                if (item.expiry) fd.append("expiry", item.expiry);
                if (item.minStock != null) fd.append("minStock", item.minStock);
                if (item.note) fd.append("note", item.note);
                return fetch("mobile_entry.php", { method: "POST", body: fd })
                    .then(function (r) { return r.json(); })
                    .catch(function () {});
            });
        });
        return p;
    }

    function consumeMobilePendingItemsThen(M, channelId) {
        if (!M || !M.getDoc || !channelId || !syncState.db) {
            return Promise.resolve();
        }
        var invRef = M.doc(syncState.db, "pos_mobile_inventory", channelId);
        return M.getDoc(invRef)
            .then(function (snap) {
                if (!snap || !snap.exists()) return;
                var data = snap.data() || {};
                var items = data.pending_items;
                if (!Array.isArray(items) || !items.length) return;
                return processMobilePendingItemsBatch(items).then(function () {
                    return M.setDoc(invRef, { pending_items: [] }, { merge: true });
                });
            })
            .catch(function (e) {
                console.warn("Mobile pending items consume error:", e);
            });
    }

    window.pushFirebaseMobileSnapshot = function (force) {
        var skip = quietSkipNoGmail();
        if (skip) return skip;
        return ensureFirebaseApp()
            .then(function () {
                var M = syncState.modules;
                var user = syncState.auth.currentUser;
                if (!user || !user.email) {
                    return { skipped: true, reason: "not_authed" };
                }
                var now = Date.now();
                if (!force && now - syncState.lastPushAt < MIN_PUSH_MS) {
                    return { skipped: true, reason: "debounce" };
                }
                if (syncState.pushing) {
                    if (force) pendingAfterPush = true;
                    return { skipped: true, reason: "busy" };
                }
                syncState.pushing = true;

                var ch = channelIdFromUser(user);
                if (M.onSnapshot && syncState.db && ch && !syncState.unsubInvPending) {
                    try {
                        var invListenRef = M.doc(syncState.db, "pos_mobile_inventory", ch);
                        syncState.unsubInvPending = M.onSnapshot(invListenRef, function (snap) {
                            if (!snap || !snap.exists()) return;
                            var pItems = (snap.data() || {}).pending_items;
                            if (Array.isArray(pItems) && pItems.length > 0) {
                                consumeMobilePendingItemsThen(M, ch);
                            }
                        }, function () {});
                    } catch (eSnap) {}
                }
                return consumeFollowupAcksThen(M, ch)
                    .then(function () { return consumeMobilePendingItemsThen(M, ch); })
                    .then(function () {
                var bd = todayBusinessDateStr();
                var ext = buildExtendedPayload(bd);

                var dashRef = M.doc(syncState.db, "pos_mobile_dashboard", ch);
                var dayRef = M.doc(
                    syncState.db,
                    "pos_mobile_daily_detail",
                    ch,
                    "days",
                    bd
                );
                var invRef = M.doc(syncState.db, "pos_mobile_inventory", ch);
                var inv = buildInventoryPayload(bd);
                var debtRef = M.doc(syncState.db, "pos_mobile_debt", ch);
                var debt = buildDebtPayload();

                if (!ext && !inv && !debt) {
                    syncState.pushing = false;
                    return { skipped: true, reason: "no_payload" };
                }

                var dashPayload = null;
                var detailPayload = null;
                if (ext) {
                    var k = ext.kpi;
                    var dashMeta = ext.meta || mobileSyncMeta(bd);
                    var dashBizStart = dashMeta.businessDayStartHour != null ? dashMeta.businessDayStartHour : 0;
                    dashPayload = {
                        salesToday: k.salesToday,
                        expensesToday: k.expensesToday,
                        netProfitToday: ext.privacy && ext.privacy.hideProfit ? null : k.netProfitToday,
                        invoicesCountToday: k.invoicesCountToday,
                        businessDate: bd,
                        businessDayStartHour: dashBizStart,
                        meta: dashMeta,
                        privacy: ext.privacy || getMobilePrivacyFlags(),
                        amountCurrency: "IQD",
                        posDisplayCurrency:
                            typeof getActiveCurrency === "function"
                                ? getActiveCurrency()
                                : "IQD",
                        usdRatePerOne:
                            typeof getUsdRatePerOne === "function"
                                ? getUsdRatePerOne()
                                : 0,
                        syncVersion: 3,
                        updatedAt: M.serverTimestamp()
                    };
                    var fu = typeof window.getSaleFollowupMobilePayload === "function"
                        ? window.getSaleFollowupMobilePayload()
                        : { followupCount: 0, followups: [] };
                    dashPayload.followupCount = fu && fu.followupCount ? fu.followupCount : 0;
                    dashPayload.followups = (fu && Array.isArray(fu.followups)) ? fu.followups : [];
                    detailPayload = {
                        kpi: k,
                        sales: ext.sales,
                        returns: ext.returns,
                        expenses: ext.expenses,
                        purchases: ext.purchases,
                        privacy: ext.privacy || getMobilePrivacyFlags(),
                        meta: ext.meta,
                        pushedAt: M.serverTimestamp()
                    };
                }

                var invPayload = inv
                    ? {
                          summary: inv.summary,
                          warehouses: inv.warehouses,
                          categories: inv.categories,
                          products: inv.products,
                          recentStocktakes: inv.recentStocktakes,
                          stocktakeSessions: inv.stocktakeSessions,
                          meta: inv.meta,
                          debtSnapshot: debt ? buildDebtSnapshotLite(debt) : null,
                          updatedAt: M.serverTimestamp()
                      }
                    : null;

                var debtPayload = buildDebtFirestorePayload(debt, M);
                if (debtPayload && debt.meta) {
                    debtPayload.posDisplayCurrency = debt.meta.posDisplayCurrency;
                    debtPayload.usdRatePerOne = debt.meta.usdRatePerOne;
                }

                var tasks = [];
                if (ext && dashPayload && detailPayload) {
                    tasks.push(M.setDoc(dashRef, dashPayload, { merge: true }));
                    tasks.push(M.setDoc(dayRef, detailPayload, { merge: true }));
                }
                if (invPayload) {
                    if (inv.meta) {
                        invPayload.posDisplayCurrency = inv.meta.posDisplayCurrency;
                        invPayload.usdRatePerOne = inv.meta.usdRatePerOne;
                    }
                    tasks.push(M.setDoc(invRef, invPayload, { merge: true }));
                }
                if (debtPayload) {
                    tasks.push(writeDebtDoc(M, debtRef, debtPayload));
                }

                return Promise.all(tasks)
                    .then(function () {
                        syncState.lastPushAt = Date.now();
                        try {
                            localStorage.setItem(LS_LAST_SYNC, String(syncState.lastPushAt));
                            clearFirebaseErr();
                        } catch (e) {}
                        notifyUi();
                        return { ok: true };
                    })
                    .catch(function (err) {
                        recordFirebaseErr(err);
                        return { ok: false, error: err };
                    })
                    .finally(function () {
                        syncState.pushing = false;
                        if (pendingAfterPush) {
                            pendingAfterPush = false;
                            setTimeout(function () {
                                window.scheduleFirebaseMobilePush("queued", true);
                            }, 120);
                        }
                    });
                });
            })
            .catch(function (err) {
                syncState.pushing = false;
                if (!firebaseLinkedEmail() && !shopHasFirebaseGmail()) {
                    return { skipped: true, reason: "not_authed" };
                }
                return { ok: false, error: err };
            });
    };

    /** Upload backup ZIP to Firebase Storage (pos_mobile_backups/{email}/). Mobile app downloads with one tap. */
    window.pushLatestLocalBackupToCloud = function (force) {
        var skip = quietSkipNoGmail();
        if (skip) return skip;
        return ensureFirebaseApp()
            .then(function () {
                var user = syncState.auth && syncState.auth.currentUser;
                if (!user || !user.email) {
                    return { skipped: true, reason: "not_authed" };
                }
                return fetch("?action=list_local_backups", { credentials: "same-origin" })
                    .then(function (r) {
                        return r.json();
                    })
                    .then(function (data) {
                        if (data.status !== "success" || !data.backups || !data.backups.length) {
                            return { skipped: true, reason: "no_local" };
                        }
                        var latest = data.backups[0];
                        var name = latest.name;
                        var mtime = latest.mtime || 0;
                        if (!force) {
                            try {
                                var prev = JSON.parse(localStorage.getItem(LS_LAST_CLOUD_BACKUP) || "{}");
                                if (prev.name === name && prev.mtime === mtime) {
                                    return { skipped: true, reason: "already_uploaded" };
                                }
                            } catch (ePrev) {}
                        }
                        return fetch(
                            "?action=download_local_backup&name=" + encodeURIComponent(name),
                            { credentials: "same-origin" }
                        )
                            .then(function (res) {
                                if (!res.ok) {
                                    throw new Error("download_local_backup HTTP " + res.status);
                                }
                                return res.blob().then(function (blob) {
                                    return { blob: blob, name: name, mtime: mtime };
                                });
                            })
                            .then(function (pack) {
                                if (!pack.blob || pack.blob.size < 64) {
                                    throw new Error("backup empty");
                                }
                                return window.pushFirebaseMobileBackup(pack.blob, pack.name).then(function (r) {
                                    if (r && r.ok) {
                                        try {
                                            localStorage.setItem(
                                                LS_LAST_CLOUD_BACKUP,
                                                JSON.stringify({
                                                    name: pack.name,
                                                    mtime: pack.mtime,
                                                    at: Date.now()
                                                })
                                            );
                                        } catch (eStore) {}
                                    }
                                    return r;
                                });
                            });
                    });
            })
            .catch(function (err) {
                if (!firebaseLinkedEmail() && !shopHasFirebaseGmail()) {
                    return { skipped: true, reason: "not_authed" };
                }
                return { ok: false, error: err };
            });
    };

    window.pushFirebaseMobileBackup = function (blob, fileName) {
        fileName = String(fileName || "").replace(/[^\w.\-]+/g, "_");
        if (!fileName || !blob) return Promise.resolve({ ok: false, reason: "bad_args" });
        var skip = quietSkipNoGmail();
        if (skip) return skip;
        var maxItems = 1;
        var cloudFileName = "Laptop_Duhok_POS_Latest.zip";
        return ensureFirebaseApp()
            .then(function () {
                var user = syncState.auth && syncState.auth.currentUser;
                var ch = channelIdFromUser(user);
                if (!ch) return { ok: false, reason: "not_authed" };
                var M = syncState.modules;
                var fbStorage = M.getStorage(syncState.app);
                var storagePath = "pos_mobile_backups/" + ch + "/" + cloudFileName;
                var fileRef = M.storageRef(fbStorage, storagePath);
                var metaRef = M.doc(syncState.db, "pos_mobile_backups", ch);
                return M.uploadBytes(fileRef, blob, { contentType: "application/zip" })
                    .then(function () {
                        return M.getDoc(metaRef);
                    })
                    .then(function (snap) {
                        var prev = snap.exists() ? snap.data().items || [] : [];
                        var item = {
                            name: cloudFileName,
                            bytes: blob.size || 0,
                            uploadedAt: Date.now(),
                            path: storagePath,
                            sourceName: fileName
                        };
                        var items = [item];
                        var deletes = prev
                            .filter(function (x) {
                                return x && x.name;
                            })
                            .map(function (x) {
                                var p = x.path || "pos_mobile_backups/" + ch + "/" + x.name;
                                return M.deleteObject(M.storageRef(fbStorage, p)).catch(function () {});
                            });
                        return Promise.all(deletes).then(function () {
                            return M.setDoc(
                                metaRef,
                                { updatedAt: M.serverTimestamp(), latest: item, items: items },
                                { merge: true }
                            );
                        });
                    })
                    .then(function () {
                        return { ok: true, fileName: fileName };
                    });
            })
            .catch(function (err) {
                if (!firebaseLinkedEmail()) {
                    return { skipped: true, reason: "not_authed" };
                }
                var msg = err && err.message ? String(err.message) : String(err || "upload failed");
                if (/storage\/unauthorized|permission/i.test(msg)) {
                    msg = "Storage Rules → Publish (storage.rules)";
                }
                recordFirebaseErr(msg);
                return { ok: false, error: err, message: msg };
            });
    };

    window.scheduleFirebaseMobilePush = function (reason, force) {
        try {
            if (!firebaseLinkedEmail() && !shopHasFirebaseGmail()) {
                return;
            }
            if (!navigator.onLine) {
                queuePendingPush(reason, force);
                return;
            }
            if (!force && !getPosDb()) {
                queuePendingPush(reason, false);
                return;
            }
        } catch (e) {
            return;
        }
        var run = function () {
            window.pushFirebaseMobileSnapshot(!!force).catch(function () {});
        };
        if (force) {
            run();
            return;
        }
        if (typeof window.requestIdleCallback === "function") {
            window.requestIdleCallback(run, { timeout: 800 });
        } else {
            setTimeout(run, 50);
        }
    };

    window.posFirebaseMobilePushAfterChange = function (reason) {
        window.scheduleFirebaseMobilePush(reason || "change", false);
    };

    window.posNotifyMobileDebtSync = function (reason) {
        if (typeof window.pushFirebaseMobileDebtOnly === "function") {
            window.pushFirebaseMobileDebtOnly(true).catch(function () {});
        } else {
            window.scheduleFirebaseMobilePush(reason || "debt", true);
        }
        scheduleDebtPushRetries();
    };

    window.posFirebaseSyncNow = function () {
        if (!firebaseLinkedEmail()) {
            if (typeof window.openFirebaseSyncLogin === "function") {
                window.openFirebaseSyncLogin();
            }
            return Promise.resolve({ skipped: true, reason: "not_authed" });
        }
        if (typeof window.scheduleFirebaseMobilePush === "function") {
            window.scheduleFirebaseMobilePush("manual", true);
        }
        var debtP =
            typeof window.pushFirebaseMobileDebtOnly === "function"
                ? window.pushFirebaseMobileDebtOnly(true)
                : Promise.resolve({ skipped: true });
        scheduleDebtPushRetries();
        return debtP
            .then(function (r) {
                if (typeof window.showToast !== "function") return r;
                if (r && r.ok) {
                    var cust = 0;
                    var comp = 0;
                    try {
                        var d = buildDebtPayload();
                        if (d && d.summary) {
                            cust = Number(d.summary.customerDebtorCount) || 0;
                            comp = Number(d.summary.supplierDebtCount) || 0;
                        }
                    } catch (e) {}
                    window.showToast(
                        "✅ هاوکات — کۆگە + قەرز نێردرا بۆ مۆبایل",
                        "success"
                    );
                } else if (r && r.reason === "not_authed") {
                    return r;
                } else if (r && r.reason === "no_db") {
                    window.showToast("❌ داتای POS هێشتا بارنەبووە — چاوەڕێ بکە", "error");
                } else if (r && !r.ok && r.error) {
                    window.showToast("❌ هاوکات: " + String(r.error.message || r.error), "error");
                }
                return r;
            })
            .catch(function () {
                return { ok: false };
            });
    };

    window.logoutFirebaseSync = function () {
        return ensureFirebaseApp()
            .then(function () {
                return syncState.modules.signOut(syncState.auth);
            })
            .then(function () {
                notifyUi();
            })
            .catch(function () {
                return Promise.resolve();
            });
    };

    function refreshFirebaseAuthModalUi() {
        var createBtn = document.getElementById("fb-sync-create-btn");
        var hintEl = document.getElementById("fb-sync-once-hint");
        var emailIn = document.getElementById("fb-sync-email-in");
        var rec = getShopFirebaseAccountRecord();
        var canCreate = canCreateShopFirebaseAccount();
        if (createBtn) createBtn.style.display = canCreate ? "inline-flex" : "none";
        if (hintEl) {
            if (canCreate) {
                hintEl.style.color = "var(--warning,#d97706)";
                hintEl.textContent =
                    typeof window.t === "function"
                        ? window.t("firebase_modal_once_hint")
                        : "تەنها یەک جار دەتوانیت هەژمار دروست بکەیت.";
            } else if (rec && rec.email) {
                hintEl.style.color = "var(--text-muted,#64748b)";
                hintEl.textContent =
                    (typeof window.t === "function"
                        ? window.t("firebase_modal_account_exists")
                        : "هەژمار دروستکراوە:") +
                    " " +
                    rec.email;
            } else {
                hintEl.textContent = "";
            }
        }
        if (emailIn && rec && rec.email && !emailIn.value) {
            emailIn.value = rec.email;
        }
    }

    function firebaseAuthCredentialsFromForm(msgEl) {
        var em = (document.getElementById("fb-sync-email-in") || {}).value || "";
        var pw = (document.getElementById("fb-sync-pass-in") || {}).value || "";
        if (!em || !pw) {
            if (msgEl) {
                msgEl.textContent =
                    typeof window.t === "function"
                        ? window.t("firebase_err_enter_credentials")
                        : "Enter email and password.";
            }
            return null;
        }
        var emNorm = String(em).trim().toLowerCase();
        var dom = emNorm.split("@")[1] || "";
        if (!dom || dom.indexOf(".") < 1 || dom === "0") {
            if (msgEl) {
                msgEl.textContent =
                    "ئیمێیل هەڵەیە. دەبێت وەک shop@pos.com بێت (نە com.0@0).";
            }
            return null;
        }
        if (pw.length < 6) {
            if (msgEl) {
                msgEl.textContent =
                    typeof window.t === "function"
                        ? window.t("firebase_err_password_short")
                        : "تێپەڕەوشە لانیکەم ٦ پیت.";
            }
            return null;
        }
        return { email: emNorm, password: pw };
    }

    function firebaseAuthAfterSuccess(wrap, msgEl) {
        if (msgEl) msgEl.textContent = "";
        try {
            clearFirebaseErr();
        } catch (e) {}
        ensureShopFirebaseAccountFromSession();
        wrap.remove();
        notifyUi();
        window.scheduleFirebaseMobilePush("login", true);
        window.pushFirebaseMobileDebtOnly(true).catch(function () {});
        scheduleDebtPushRetries();
        if (typeof window.showToast === "function") {
            window.showToast(
                typeof window.t === "function"
                    ? window.t("firebase_toast_connected")
                    : "Firebase connected.",
                "success"
            );
        }
    }

    function setupFirebaseAuthModal(wrap) {
        var msg = document.getElementById("fb-sync-msg");
        document.getElementById("fb-sync-cancel-btn").onclick = function () {
            wrap.remove();
        };
        wrap.addEventListener("click", function (e) {
            if (e.target === wrap) wrap.remove();
        });
        refreshFirebaseAuthModalUi();

        document.getElementById("fb-sync-login-btn").onclick = function () {
            var creds = firebaseAuthCredentialsFromForm(msg);
            if (!creds) return;
            loadModules()
                .then(function () {
                    return ensureFirebaseApp();
                })
                .then(function () {
                    var M = syncState.modules;
                    return M.setPersistence(syncState.auth, M.browserLocalPersistence).then(function () {
                        return M.signInWithEmailAndPassword(syncState.auth, creds.email, creds.password);
                    });
                })
                .then(function () {
                    markShopFirebaseAccountCreated(creds.email);
                    firebaseAuthAfterSuccess(wrap, msg);
                })
                .catch(function (err) {
                    if (msg) {
                        msg.textContent =
                            (err && err.message) ||
                            (typeof window.t === "function"
                                ? window.t("firebase_err_login_failed")
                                : "Login failed");
                    }
                });
        };

        var createBtn = document.getElementById("fb-sync-create-btn");
        if (createBtn) {
            createBtn.onclick = function () {
                if (!canCreateShopFirebaseAccount()) {
                    if (msg) {
                        msg.textContent =
                            typeof window.t === "function"
                                ? window.t("firebase_err_account_already_created")
                                : "هەژمار پێشتر دروستکراوە — تەنها login.";
                    }
                    refreshFirebaseAuthModalUi();
                    return;
                }
                var creds = firebaseAuthCredentialsFromForm(msg);
                if (!creds) return;
                createBtn.disabled = true;
                loadModules()
                    .then(function () {
                        return ensureFirebaseApp();
                    })
                    .then(function () {
                        var M = syncState.modules;
                        return M.setPersistence(syncState.auth, M.browserLocalPersistence).then(function () {
                            return M.createUserWithEmailAndPassword(
                                syncState.auth,
                                creds.email,
                                creds.password
                            );
                        });
                    })
                    .then(function () {
                        markShopFirebaseAccountCreated(creds.email);
                        firebaseAuthAfterSuccess(wrap, msg);
                    })
                    .catch(function (err) {
                        var code = err && err.code ? String(err.code) : "";
                        if (msg) {
                            if (code.indexOf("email-already-in-use") >= 0) {
                                msg.textContent =
                                    typeof window.t === "function"
                                        ? window.t("firebase_err_email_in_use")
                                        : "ئەم ئیمێیلە هەیە — «پەیوەست بکە» بەکاربهێنە.";
                            } else {
                                msg.textContent =
                                    (err && err.message) ||
                                    (typeof window.t === "function"
                                        ? window.t("firebase_err_create_failed")
                                        : "دروستکردن سەرنەکەوت");
                            }
                        }
                    })
                    .finally(function () {
                        createBtn.disabled = false;
                    });
            };
        }
    }

    window.openFirebaseSyncLogin = function () {
        ensureFirebaseApp().catch(function () {
            if (typeof window.showToast === "function") {
                var txt =
                    typeof window.t === "function"
                        ? window.t("firebase_toast_config_missing")
                        : "Firebase config missing.";
                window.showToast(txt, "error");
            }
        });

        var existing = document.getElementById("firebase-cashier-auth-modal");
        if (existing) {
            existing.style.display = "flex";
            var ec = document.getElementById("firebase-cashier-auth-card");
            if (ec && typeof window.applyI18nSubtree === "function") {
                window.applyI18nSubtree(ec);
            }
            refreshFirebaseAuthModalUi();
            return;
        }

        var wrap = document.createElement("div");
        wrap.id = "firebase-cashier-auth-modal";
        wrap.style.cssText =
            "position:fixed;inset:0;z-index:30000;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center;padding:16px;";
        wrap.innerHTML =
            '<div id="firebase-cashier-auth-card" style="background:var(--card,#fff);color:var(--text,#111);max-width:400px;width:100%;padding:20px;border-radius:16px;box-shadow:0 20px 50px rgba(0,0,0,.3);">' +
            '<h3 style="margin:0 0 12px;font-size:1.1rem;"><span data-i18n="firebase_modal_title"></span></h3>' +
            '<p style="margin:0 0 8px;font-size:0.9rem;opacity:.85;"><span data-i18n="firebase_modal_desc"></span></p>' +
            '<p id="fb-sync-once-hint" style="margin:0 0 12px;font-size:0.78rem;line-height:1.45;"></p>' +
            '<label style="display:block;margin-bottom:6px;font-size:0.85rem;"><span data-i18n="firebase_modal_email"></span></label>' +
            '<input type="email" id="fb-sync-email-in" class="input-std" style="width:100%;margin-bottom:10px;" autocomplete="username" dir="ltr" />' +
            '<label style="display:block;margin-bottom:6px;font-size:0.85rem;"><span data-i18n="firebase_modal_password"></span></label>' +
            '<input type="password" id="fb-sync-pass-in" class="input-std" style="width:100%;margin-bottom:14px;" autocomplete="current-password" dir="ltr" />' +
            '<div style="display:flex;gap:10px;flex-wrap:wrap;">' +
            '<button type="button" id="fb-sync-create-btn" class="btn btn-success" style="flex:1;"><span data-i18n="firebase_modal_create"></span></button>' +
            '<button type="button" id="fb-sync-login-btn" class="btn btn-brand" style="flex:1;"><span data-i18n="firebase_modal_connect"></span></button>' +
            '<button type="button" id="fb-sync-cancel-btn" class="btn btn-dark"><span data-i18n="firebase_modal_cancel"></span></button>' +
            '</div>' +
            '<p id="fb-sync-msg" style="margin:10px 0 0;font-size:0.85rem;color:var(--danger,#b91c1c);min-height:1.2em;"></p>' +
            "</div>";

        document.body.appendChild(wrap);

        var fbCard = document.getElementById("firebase-cashier-auth-card");
        if (fbCard && typeof window.applyI18nSubtree === "function") {
            window.applyI18nSubtree(fbCard);
        }
        setupFirebaseAuthModal(wrap);
    };

    bootFirebaseQuietly();

    var POS_MOBILE_MANAGER_PUBLIC_URL = 'https://laptopduhokpos.github.io/LP/mobile_manager/';

    function getPosMobileManagerUrl(opts) {
        opts = opts || {};
        var url;
        if (typeof db !== 'undefined' && db.settings) {
            var custom = String(db.settings.mobileManagerUrl || '').trim();
            if (custom) url = custom.replace(/\/?$/, '/');
        }
        if (!url) url = POS_MOBILE_MANAGER_PUBLIC_URL;
        if (opts.cacheBust) {
            var ver = (typeof window.getPosAppVersion === 'function') ? String(window.getPosAppVersion()) : '';
            if (!ver && typeof window.POS_APP_VERSION !== 'undefined') ver = String(window.POS_APP_VERSION);
            if (!ver) ver = String(Date.now());
            url += (url.indexOf('?') >= 0 ? '&' : '?') + 'v=' + encodeURIComponent(ver);
        }
        return url;
    }

    function refreshMobileManagerAppUi() {
        var urlEl = document.getElementById('firebase-mobile-app-url');
        var qrEl = document.getElementById('firebase-mobile-app-qr');
        var url = getPosMobileManagerUrl();
        if (urlEl) urlEl.textContent = url;
        applyMobileSyncPrivacyUi();
        if (!qrEl) return;
        var qrPayload = url;
        var dataUrl = '';
        if (typeof window.posOfflineQrDataUrl === 'function') {
            dataUrl = window.posOfflineQrDataUrl(qrPayload, 120);
        }
        if (dataUrl) {
            qrEl.src = dataUrl;
            qrEl.style.display = 'block';
            qrEl.alt = 'QR — Mobile Manager';
            return;
        }
        qrEl.onerror = function () {
            qrEl.onerror = null;
            qrEl.src = 'https://api.qrserver.com/v1/create-qr-code/?size=120x120&margin=8&data=' + encodeURIComponent(qrPayload);
        };
        qrEl.src = 'https://api.qrserver.com/v1/create-qr-code/?size=120x120&margin=8&data=' + encodeURIComponent(qrPayload);
        qrEl.style.display = 'block';
        qrEl.alt = 'QR — Mobile Manager';
    }

    window.getPosMobileManagerUrl = getPosMobileManagerUrl;
    window.refreshMobileManagerAppUi = refreshMobileManagerAppUi;
    window.getMobilePrivacyFlags = getMobilePrivacyFlags;

    function applyMobileSyncPrivacyUi() {
        var db = getPosDb();
        var s = db && db.settings ? db.settings : {};
        var profitEl = document.getElementById('set-mobile-hide-profit');
        var salesEl = document.getElementById('set-mobile-hide-sales-detail');
        if (profitEl) {
            profitEl.checked = !!(
                s.mobileHideProfit === true ||
                s.mobileHideProfit === 1 ||
                s.mobileHideProfit === "true"
            );
        }
        if (salesEl) {
            salesEl.checked = !!(
                s.mobileHideSalesDetail === true ||
                s.mobileHideSalesDetail === 1 ||
                s.mobileHideSalesDetail === "true"
            );
        }
    }
    window.applyMobileSyncPrivacyUi = applyMobileSyncPrivacyUi;

    window.onMobileSyncPrivacyChange = function (key) {
        var db = getPosDb();
        if (!db) return;
        if (!db.settings) db.settings = {};
        var profitEl = document.getElementById('set-mobile-hide-profit');
        var salesEl = document.getElementById('set-mobile-hide-sales-detail');
        if (key === "profit" && profitEl) db.settings.mobileHideProfit = !!profitEl.checked;
        if (key === "salesDetail" && salesEl) {
            db.settings.mobileHideSalesDetail = !!salesEl.checked;
        }
        var done = function () {
            if (typeof window.scheduleFirebaseMobilePush === "function") {
                window.scheduleFirebaseMobilePush("privacy", true);
            }
            if (typeof window.showToast === "function") {
                window.showToast(
                    typeof window.t === "function"
                        ? window.t("firebase_mobile_privacy_saved")
                        : "ڕێکخستن پاشەکەوت کرا — هاوکاتکردن…",
                    "success"
                );
            }
        };
        if (typeof saveSettings === "function") {
            saveSettings().then(done).catch(function () {
                if (typeof window.showToast === "function") {
                    window.showToast("هەڵە د پاراستنێ دا", "error");
                }
            });
        } else {
            done();
        }
    };

    window.openMobileManagerApp = function () {
        var url = getPosMobileManagerUrl({ cacheBust: true });
        window.open(url, '_blank', 'noopener');
    };

    window.copyMobileManagerUrl = function () {
        var url = getPosMobileManagerUrl();
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(url).then(function () {
                if (typeof showToast === 'function') {
                    showToast(typeof t === 'function' ? t('firebase_mobile_copied') : 'لینک کۆپی کرا ✓');
                }
            }).catch(function () {
                window.prompt(typeof t === 'function' ? t('firebase_mobile_copy_prompt') : 'لینک:', url);
            });
        } else {
            window.prompt(typeof t === 'function' ? t('firebase_mobile_copy_prompt') : 'لینک:', url);
        }
    };

    function getPosApiBase() {
        var path = String(location.pathname || '');
        var lower = path.toLowerCase();
        var root = '/pos';
        var idx = lower.indexOf('/pos');
        if (idx >= 0) {
            root = path.substring(0, idx + 4);
        }
        root = root.replace(/\/$/, '');
        return location.origin + root;
    }

    window.refreshMobileBackupPinUi = function () {
        var pinEl = document.getElementById('mobile-backup-pin');
        if (!pinEl) return;
        fetch(getPosApiBase() + '/?action=get_mobile_backup_info', { credentials: 'same-origin' })
            .then(function (res) { return res.json(); })
            .then(function (data) {
                if (data.status === 'success' && data.pin) {
                    pinEl.textContent = data.pin;
                }
            })
            .catch(function () {});
    };

    window.regenerateMobileBackupPin = function () {
        if (!confirm('PINـی نوێ دروست بکرێت؟')) return;
        var fd = new FormData();
        fd.append('action', 'regenerate_mobile_backup_pin');
        fetch(getPosApiBase() + '/?action=regenerate_mobile_backup_pin', { method: 'POST', body: fd, credentials: 'same-origin' })
            .then(function (res) { return res.json(); })
            .then(function (data) {
                if (data.status === 'success' && data.pin) {
                    var pinEl = document.getElementById('mobile-backup-pin');
                    if (pinEl) pinEl.textContent = data.pin;
                    if (typeof showToast === 'function') showToast('✓ PIN نوێ: ' + data.pin);
                } else {
                    alert('❌ ' + (data.message || 'error'));
                }
            })
            .catch(function (err) { alert('❌ ' + err); });
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', refreshMobileManagerAppUi);
    } else {
        refreshMobileManagerAppUi();
    }

    if (typeof document !== 'undefined') {
        document.addEventListener('visibilitychange', function () {
            if (document.visibilityState !== 'visible') return;
            if (!syncState.auth || !syncState.auth.currentUser || !syncState.auth.currentUser.email) return;
            if (!getPosDb()) return;
            window.scheduleFirebaseMobilePush('visible', true);
        });
    }

    if (typeof window !== 'undefined') {
        window.addEventListener('online', function () {
            if (!syncState.auth || !syncState.auth.currentUser || !syncState.auth.currentUser.email) return;
            flushPendingPush();
            window.scheduleFirebaseMobilePush('online', true);
        });
    }
})();
