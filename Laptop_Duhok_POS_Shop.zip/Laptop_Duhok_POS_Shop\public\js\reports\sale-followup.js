// After-sale WhatsApp care: list due customers and open wa.me with a ready message.
(function () {
    var DEFAULT_MSG_BADINI = 'سلاڤ {name} 🌟\n\nئەز {shop} مە. تە ڤە بریە دەف مە (فاتوورا {invoice} — {date}):\n{item}\n\nهیڤی دکەم هەمی باش بیت و کێشە نینبیت. ئەگەر چ کێشە هەیە، بێژە مە — ئێمە ل خزمەتا تەینە.\n\n{warranty}\n\nکەیفا مە د تە دایە. ئێمە هەر دەم ل گەل تەینە 🤝\n{shop}';
    var DEFAULT_MSG_AR = 'مرحبا {name} 🌟\n\nأنا {shop}. اشتريت منّا (فاتورة {invoice} — {date}):\n{item}\n\nنتمنى أن يكون كل شيء بخير ولا مشكلة عندك. إذا عندك أي مشكلة، أخبرنا — نحن بخدمتك.\n\n{warranty}\n\nيسعدنا اهتمامك. نحن معك دائماً 🤝\n{shop}';
    var LEGACY_FOLLOWUP_MSG = [
        'سلاڤ {name}،\nئەز {shop} مە. هیڤی دکەم {item} یێ باش کار دکەت.\nئەگەر پێتڤی هاریکاری یان خزمەتگوزاریێ بووی، ئێمە ل خزمەتا تەینە.\nسوپاس 🙏',
        'مرحبا {name}،\nأنا {shop}. أتمنى أن يكون {item} يعمل بشكل جيد.\nإذا احتجت أي مساعدة أو خدمة، نحن بخدمتك.\nشكراً 🙏',
        'سلاف {name}، ئەز {shop} مە. هیڤی دکەم {item} یێ باش کار دکەت. ئەگەر پێتفی هاریکاری یان خزمەتگوزاریی بووی، ئیمە ل خزمەتا تەینە.',
        'سلاڤ {name}، ئەز {shop} مە. هیڤی دکەم {item} یێ باش کار دکەت. ئەگەر پێتڤی هاریکاری یان خزمەتگوزاریێ بووی، ئێمە ل خزمەتا تەینە.'
    ];

    function _db() {
        return (typeof db !== 'undefined' && db) ? db : (typeof window !== 'undefined' ? window.db : null);
    }

    function _t(key, fallback) {
        if (typeof t === 'function') {
            var s = t(key);
            if (s && s !== key) return s;
        }
        return fallback;
    }

    function isSaleFollowupEnabled() {
        if (typeof canUseSaleFollowup === 'function') {
            return !!canUseSaleFollowup();
        }
        var s = _db() && _db().settings;
        if (!s) return false;
        return s.enableSaleFollowup === true || s.enableSaleFollowup === 1 || s.enableSaleFollowup === '1';
    }

    function normalizeFollowupSchedule(raw) {
        var out = [];
        var seen = {};
        if (Array.isArray(raw)) {
            raw.forEach(function (row) {
                if (!row) return;
                var unit = String(row.unit || 'day').toLowerCase();
                if (unit === 'min' || unit === 'mins' || unit === 'minutes') unit = 'minute';
                if (unit === 'hr' || unit === 'hrs' || unit === 'hours') unit = 'hour';
                if (unit === 'days') unit = 'day';
                if (unit !== 'minute' && unit !== 'hour' && unit !== 'day') unit = 'day';
                var value = parseInt(row.value, 10) || 0;
                if (value < 1) return;
                if (unit === 'day' && value > 365) value = 365;
                if (unit !== 'day' && value > 999) value = 999;
                var key = value + (unit === 'minute' ? 'm' : (unit === 'hour' ? 'h' : 'd'));
                if (seen[key]) return;
                seen[key] = 1;
                out.push({ value: value, unit: unit, key: key });
            });
        }
        if (!out.length) {
            var d = parseInt(_db() && _db().settings && _db().settings.saleFollowupDays, 10);
            out.push({ value: d === 30 ? 30 : 10, unit: 'day', key: (d === 30 ? 30 : 10) + 'd' });
        }
        return out.slice(0, 6);
    }

    function getSaleFollowupSchedule() {
        var s = _db() && _db().settings ? _db().settings : {};
        return normalizeFollowupSchedule(s.saleFollowupSchedule);
    }

    function getSaleFollowupRefreshMs() {
        var minSec = 86400;
        getSaleFollowupSchedule().forEach(function (step) {
            var sec = step.unit === 'minute' ? step.value * 60 : (step.unit === 'hour' ? step.value * 3600 : step.value * 86400);
            if (sec < minSec) minSec = sec;
        });
        if (minSec <= 180) return 15000;
        if (minSec <= 3600) return 30000;
        return 120000;
    }

    function ensureSaleFollowupPoll() {
        if (!isSaleFollowupEnabled()) return;
        var ms = getSaleFollowupRefreshMs();
        if (window._saleFollowupPoll && window._saleFollowupPollMs === ms) return;
        if (window._saleFollowupPoll) {
            try { clearInterval(window._saleFollowupPoll); } catch (_eC) {}
        }
        window._saleFollowupPollMs = ms;
        window._saleFollowupPoll = setInterval(function () {
            if (!isSaleFollowupEnabled()) return;
            fetchSaleFollowups(true);
        }, ms);
    }

    function readFollowupScheduleFromUi() {
        var box = document.getElementById('sale-followup-schedule-list');
        var rows = [];
        if (!box) return getSaleFollowupSchedule();
        box.querySelectorAll('.followup-sched-row').forEach(function (el) {
            var valEl = el.querySelector('.followup-sched-val');
            var unitEl = el.querySelector('.followup-sched-unit');
            rows.push({
                value: valEl ? (parseInt(valEl.value, 10) || 1) : 1,
                unit: unitEl ? String(unitEl.value || 'day') : 'day'
            });
        });
        return normalizeFollowupSchedule(rows);
    }

    function renderFollowupScheduleUi(steps) {
        var box = document.getElementById('sale-followup-schedule-list');
        if (!box) return;
        var list = normalizeFollowupSchedule(steps);
        if (!list.length) list = [{ value: 10, unit: 'day', key: '10d' }];
        box.innerHTML = list.map(function (step, idx) {
            return '<div class="followup-sched-row">' +
                '<span class="followup-sched-idx">' + (idx + 1) + '</span>' +
                '<input type="number" class="input-std followup-sched-val" min="1" max="999" value="' + step.value + '" onchange="if(window.persistSaleFollowupSettings)persistSaleFollowupSettings();">' +
                '<select class="input-std followup-sched-unit" onchange="if(window.persistSaleFollowupSettings)persistSaleFollowupSettings();">' +
                '<option value="minute"' + (step.unit === 'minute' ? ' selected' : '') + '>' + _t('followup_unit_minute', 'خولەک') + '</option>' +
                '<option value="hour"' + (step.unit === 'hour' ? ' selected' : '') + '>' + _t('followup_unit_hour', 'دەمژمێر') + '</option>' +
                '<option value="day"' + (step.unit === 'day' ? ' selected' : '') + '>' + _t('followup_unit_day', 'ڕۆژ') + '</option>' +
                '</select>' +
                '<button type="button" class="btn btn-sm btn-dark followup-sched-del" onclick="if(window.removeSaleFollowupScheduleRow)removeSaleFollowupScheduleRow(this);" title="ژێبرن"><i class="fas fa-times"></i></button>' +
                '</div>';
        }).join('');
    }

    function addSaleFollowupScheduleRow() {
        var cur = readFollowupScheduleFromUi();
        if (cur.length >= 6) return;
        cur.push({ value: 1, unit: 'hour' });
        renderFollowupScheduleUi(cur);
        persistSaleFollowupSettings();
    }

    function removeSaleFollowupScheduleRow(btn) {
        var row = btn && btn.closest ? btn.closest('.followup-sched-row') : null;
        if (row && row.parentNode) row.parentNode.removeChild(row);
        var cur = readFollowupScheduleFromUi();
        if (!cur.length) cur = [{ value: 10, unit: 'day' }];
        renderFollowupScheduleUi(cur);
        persistSaleFollowupSettings();
    }

    function normalizeFollowupTpl(s) {
        return String(s || '').replace(/\s+/g, ' ').trim();
    }

    function isLegacyFollowupTemplate(saved) {
        var n = normalizeFollowupTpl(saved);
        if (!n) return true;
        for (var i = 0; i < LEGACY_FOLLOWUP_MSG.length; i++) {
            if (n === normalizeFollowupTpl(LEGACY_FOLLOWUP_MSG[i])) return true;
        }
        if (n.indexOf('{warranty}') === -1 && /هیڤی دکەم \{item\}/.test(n)) return true;
        if (n.indexOf('{warranty}') === -1 && /أتمنى أن يكون \{item\}/.test(n)) return true;
        return false;
    }

    function getSaleFollowupWarranty() {
        var s = _db() && _db().settings ? _db().settings : {};
        var value = parseInt(s.saleFollowupWarrantyValue, 10);
        if (!(value >= 1)) value = 12;
        if (value > 999) value = 999;
        var unit = String(s.saleFollowupWarrantyUnit || 'month').toLowerCase();
        if (unit !== 'day' && unit !== 'year' && unit !== 'month') unit = 'month';
        return { value: value, unit: unit };
    }

    function parseFollowupDate(raw) {
        if (raw instanceof Date) return isNaN(raw.getTime()) ? null : raw;
        var s = String(raw || '').trim();
        if (!s) return null;
        if (/^\d{4}-\d{2}-\d{2} /.test(s)) s = s.replace(' ', 'T');
        var d = new Date(s);
        return isNaN(d.getTime()) ? null : d;
    }

    function formatFollowupDate(raw) {
        var d = parseFollowupDate(raw);
        if (!d) return String(raw || '');
        var dd = String(d.getDate());
        var mm = String(d.getMonth() + 1);
        if (dd.length < 2) dd = '0' + dd;
        if (mm.length < 2) mm = '0' + mm;
        return dd + '/' + mm + '/' + d.getFullYear();
    }

    function warrantyUntilDate(createdAt, spec) {
        var d = parseFollowupDate(createdAt);
        if (!d) return null;
        d = new Date(d.getTime());
        var value = spec && spec.value ? spec.value : 12;
        var unit = spec && spec.unit ? spec.unit : 'month';
        if (unit === 'day') d.setDate(d.getDate() + value);
        else if (unit === 'year') d.setFullYear(d.getFullYear() + value);
        else d.setMonth(d.getMonth() + value);
        return d;
    }

    function buildWarrantyLine(row) {
        var spec = getSaleFollowupWarranty();
        var created = row && row.created_at ? row.created_at : '';
        var until = warrantyUntilDate(created, spec);
        if (!until) {
            return _t('followup_warranty_generic', 'ئەگەر زەمانێ گەرەنتییێ ما و کێشە هەیە، بەرە ڤە. ئەگەر خلاس بوو ژی، خزمەتگوزاری ل خزمەتا تە یە.');
        }
        var untilStr = formatFollowupDate(until);
        if (Date.now() >= until.getTime()) {
            return _t('followup_warranty_expired', 'زەمانێ گەرەنتییێ خلاس بوو ({until}). ئەگەر پێتڤی خزمەتگوزاریێ یان چاککرنێ بیت، پەیوەندیێ پێ بکە — ئێمە ل خزمەتا تەینە.').replace('{until}', untilStr);
        }
        return _t('followup_warranty_ok', 'زەمانێ گەرەنتییێ هێشتا ما هەتا {until}. ئەگەر کێشە هەیە، بەرە ڤە — ئێمە ل خزمەتا تەینە.').replace('{until}', untilStr);
    }

    function companySanitizeWaMessage(text) {
        return String(text || '').replace(/🙏/g, '🤝');
    }

    function getSaleFollowupDefaultMessage() {
        var lang = '';
        try {
            lang = String((_db() && _db().settings && _db().settings.language) || '').toLowerCase();
        } catch (_eL) {}
        return (lang.indexOf('ar') === 0) ? DEFAULT_MSG_AR : DEFAULT_MSG_BADINI;
    }

    function getSaleFollowupMessageTemplate() {
        var saved = _db() && _db().settings ? String(_db().settings.saleFollowupMessage || '').trim() : '';
        if (isLegacyFollowupTemplate(saved)) return getSaleFollowupDefaultMessage();
        return companySanitizeWaMessage(saved);
    }

    function getSaleFollowupShopName() {
        var s = _db() && _db().settings;
        var n = s ? String(s.cafeName || s.shopName || '').trim() : '';
        return n || 'دکان';
    }

    function normalizeWaPhoneDigits(raw) {
        var s = String(raw || '');
        s = s.replace(/[٠-٩]/g, function (ch) { return String(ch.charCodeAt(0) - 1632); });
        s = s.replace(/[۰-۹]/g, function (ch) { return String(ch.charCodeAt(0) - 1776); });
        s = s.replace(/[^\d]/g, '');
        if (s.indexOf('00') === 0) s = s.slice(2);
        if (s.indexOf('964') === 0) return s;
        if (s.length === 11 && s.charAt(0) === '0') return '964' + s.slice(1);
        if (s.length === 10 && s.charAt(0) === '7') return '964' + s;
        if (s.length >= 11 && s.length <= 15) return s;
        return '';
    }

    function buildSaleFollowupText(row) {
        var name = String((row && row.customer_name) || '').trim() || _t('followup_guest_name', 'برایێ من');
        var item = String((row && (row.invoice_items || row.item_names)) || '').trim() || _t('followup_item_fallback', 'کەرستێ تە');
        var shop = getSaleFollowupShopName();
        var invoice = String((row && row.invoice_no) || '').trim();
        if (!invoice && row && row.sale_id) invoice = '#' + String(row.sale_id);
        var date = formatFollowupDate(row && row.created_at);
        var warranty = buildWarrantyLine(row);
        var tpl = getSaleFollowupMessageTemplate();
        return tpl
            .replace(/\{name\}/g, name)
            .replace(/\{item\}/g, item)
            .replace(/\{shop\}/g, shop)
            .replace(/\{warranty\}/g, warranty)
            .replace(/\{invoice\}/g, invoice || '#')
            .replace(/\{date\}/g, date);
    }

    function getPosCustomerPhoneValue() {
        var bill = document.getElementById('pos-bill-panel');
        var expandPh = document.getElementById('pos-expand-customer-phone');
        var mainPh = document.getElementById('pos-customer-phone');
        if (bill && bill.classList.contains('expanded') && expandPh) {
            return String(expandPh.value || '').trim();
        }
        return mainPh ? String(mainPh.value || '').trim() : '';
    }

    function setPosCustomerPhoneValue(phone) {
        var v = String(phone || '');
        var mainPh = document.getElementById('pos-customer-phone');
        var expandPh = document.getElementById('pos-expand-customer-phone');
        if (mainPh) mainPh.value = v;
        if (expandPh) expandPh.value = v;
    }

    function syncPosCustomerPhoneFromName() {
        var name = (typeof getPosCustomerNameValue === 'function') ? getPosCustomerNameValue() : '';
        if (!name) {
            setPosCustomerPhoneValue('');
            return;
        }
        var d = _db();
        var c = d && Array.isArray(d.customers)
            ? d.customers.find(function (x) { return x && String(x.name) === String(name); })
            : null;
        if (c) setPosCustomerPhoneValue(String(c.phone || '').trim());
    }

    function patchCustomerPhone(id, phone) {
        var cid = parseInt(id, 10) || 0;
        var ph = String(phone || '').trim();
        if (cid <= 0) return;
        var d = _db();
        if (d && Array.isArray(d.customers)) {
            var c = d.customers.find(function (x) { return Number(x.id) === cid; });
            if (c) c.phone = ph;
        }
        var fd = new FormData();
        fd.append('action', 'patch_customer_phone');
        fd.append('id', String(cid));
        fd.append('phone', ph);
        var req = (typeof apiJson === 'function')
            ? apiJson('?action=patch_customer_phone', { method: 'POST', body: fd })
            : fetch('?action=patch_customer_phone', { method: 'POST', body: fd, credentials: 'same-origin' });
        Promise.resolve(req).catch(function () {});
    }

    function ensureFollowupCustomerPhone(customer, done) {
        var typed = getPosCustomerPhoneValue();
        var existing = customer ? String(customer.phone || '').trim() : '';
        var phone = typed || existing;
        var finish = typeof done === 'function' ? done : function () {};
        if (normalizeWaPhoneDigits(phone)) {
            if (customer && typed && typed !== existing) patchCustomerPhone(customer.id, typed);
            finish(phone);
            return;
        }
        if (!isSaleFollowupEnabled()) {
            finish('');
            return;
        }
        var entered = window.prompt(_t('followup_ask_phone', 'ژمارا واتسئاپێ یا کریاری بنڤیسە. بەتاڵ = فرۆتن بەردەوام، بەس نامە نایەت.'), typed || existing || '');
        if (entered && normalizeWaPhoneDigits(entered)) {
            entered = String(entered).trim();
            setPosCustomerPhoneValue(entered);
            if (customer) patchCustomerPhone(customer.id, entered);
            finish(entered);
            return;
        }
        if (typeof showToast === 'function') {
            showToast(_t('followup_no_phone_skip', 'بێ ژمارە: پشتی ١٠ ڕۆژا واتسئاپ نایەت'), true);
        }
        finish('');
    }

    function followupRowKey(row) {
        return String(parseInt(row && row.sale_id, 10) || 0) + '|' + String((row && row.step_key) || '').replace(/[^0-9mhd]/g, '');
    }

    function loadAnnouncedFollowupKeys() {
        try {
            var raw = sessionStorage.getItem('pos_sale_followup_announced') || '[]';
            var arr = JSON.parse(raw);
            return Array.isArray(arr) ? arr : [];
        } catch (_eA) {
            return [];
        }
    }

    function saveAnnouncedFollowupKeys(keys) {
        try {
            sessionStorage.setItem('pos_sale_followup_announced', JSON.stringify(keys.slice(-80)));
        } catch (_eS) {}
    }

    function goToFollowupNotifications() {
        if (typeof nav === 'function') {
            try { nav('notifications'); } catch (_eN) {}
        }
        setTimeout(function () {
            if (typeof renderNotifications === 'function') {
                try { renderNotifications(); } catch (_eR) {}
            }
        }, 200);
    }

    function renderFollowupAlertBar(rows) {
        var list = Array.isArray(rows) ? rows : [];
        var bar = document.getElementById('sale-followup-alert-bar');
        if (!list.length) {
            if (bar && bar.parentNode) bar.parentNode.removeChild(bar);
            return;
        }
        if (!bar) {
            bar = document.createElement('div');
            bar.id = 'sale-followup-alert-bar';
            document.body.appendChild(bar);
        }
        var first = list[0] || {};
        var name = String(first.customer_name || '').trim() || _t('followup_guest_name', 'برایێ من');
        var sid = parseInt(first.sale_id, 10) || 0;
        var stepKey = String(first.step_key || '10d').replace(/[^0-9mhd]/g, '');
        var phoneOk = !!normalizeWaPhoneDigits(first.phone);
        var title = list.length === 1
            ? _t('followup_toast_go', 'ریسالێ بو واتسئاپێ فرێکە — {name}').replace('{name}', name)
            : _t('followup_toast_go_many', '{n} کریار: ریسالێ بو واتسئاپێ فرێکە').replace('{n}', String(list.length));
        var waBtn = phoneOk
            ? ('<button type="button" class="sale-followup-alert-wa" data-sid="' + sid + '" data-step="' + stepKey + '"><i class="fab fa-whatsapp"></i> ' + _t('notif_followup_wa', 'واتسئاپ') + '</button>')
            : '';
        bar.innerHTML = '<span class="sale-followup-alert-text"><i class="fab fa-whatsapp"></i> ' + title.replace(/</g, '') + '</span>' +
            waBtn +
            '<button type="button" class="sale-followup-alert-list">' + _t('followup_toast_open_list', 'ئاگەهداری') + '</button>';
        var waEl = bar.querySelector('.sale-followup-alert-wa');
        if (waEl) {
            waEl.onclick = function () {
                openSaleFollowupWhatsApp(sid, stepKey);
            };
        }
        var listBtn = bar.querySelector('.sale-followup-alert-list');
        if (listBtn) {
            listBtn.onclick = function () { goToFollowupNotifications(); };
        }
    }

    function maybeAnnounceSaleFollowups(res) {
        var rows = (res && Array.isArray(res.rows)) ? res.rows : [];
        renderFollowupAlertBar(rows);
        if (!rows.length) return;
        var announced = loadAnnouncedFollowupKeys();
        var fresh = [];
        rows.forEach(function (row) {
            var k = followupRowKey(row);
            if (!k || announced.indexOf(k) >= 0) return;
            announced.push(k);
            fresh.push(row);
        });
        if (!fresh.length) return;
        saveAnnouncedFollowupKeys(announced);
        var first = fresh[0];
        var name = String((first && first.customer_name) || '').trim() || _t('followup_guest_name', 'برایێ من');
        var msg = fresh.length === 1
            ? _t('followup_toast_go', 'ریسالێ بو واتسئاپێ فرێکە — {name}').replace('{name}', name)
            : _t('followup_toast_go_many', '{n} کریار: ریسالێ بو واتسئاپێ فرێکە').replace('{n}', String(fresh.length));
        var sid = parseInt(first && first.sale_id, 10) || 0;
        var stepKey = String((first && first.step_key) || '10d').replace(/[^0-9mhd]/g, '');
        var phoneOk = !!normalizeWaPhoneDigits(first && first.phone);
        if (typeof showToast === 'function') {
            try {
                showToast(msg, 'info', {
                    durationMs: 18000,
                    actionLabel: phoneOk ? _t('followup_toast_open_wa', 'واتسئاپ') : _t('followup_toast_open_list', 'ئاگەهداری'),
                    onAction: function () {
                        if (phoneOk) openSaleFollowupWhatsApp(sid, stepKey);
                        else goToFollowupNotifications();
                    }
                });
            } catch (_eT) {}
        }
    }

    function fetchSaleFollowups(force) {
        if (!isSaleFollowupEnabled()) {
            window._saleFollowupCache = { rows: [], count: 0 };
            window._saleFollowupLoadedAt = Date.now();
            return Promise.resolve(window._saleFollowupCache);
        }
        var refreshMs = getSaleFollowupRefreshMs();
        if (!force && window._saleFollowupCache && (Date.now() - (window._saleFollowupLoadedAt || 0) < refreshMs)) {
            return Promise.resolve(window._saleFollowupCache);
        }
        if (window._saleFollowupFetching) return window._saleFollowupFetching;
        var req = (typeof apiJson === 'function')
            ? apiJson('?action=get_sale_followups')
            : fetch('?action=get_sale_followups', { credentials: 'same-origin' }).then(function (r) { return r.json(); });
        window._saleFollowupFetching = Promise.resolve(req).then(function (res) {
            window._saleFollowupLoadedAt = Date.now();
            if (res && res.status === 'success') {
                window._saleFollowupCache = res;
                maybeAnnounceSaleFollowups(res);
                ensureSaleFollowupPoll();
                if (typeof window.scheduleFirebaseMobilePush === 'function') {
                    try { window.scheduleFirebaseMobilePush('followup', true); } catch (_eFu) {}
                }
                var view = document.getElementById('view-notifications');
                if (view && view.classList.contains('active') && typeof renderNotifications === 'function') {
                    try { renderNotifications(); } catch (_eRn) {}
                }
                return res;
            }
            if (!window._saleFollowupCache) window._saleFollowupCache = { rows: [], count: 0 };
            return window._saleFollowupCache;
        }).catch(function () {
            window._saleFollowupLoadedAt = Date.now();
            if (!window._saleFollowupCache) window._saleFollowupCache = { rows: [], count: 0 };
            return window._saleFollowupCache;
        }).then(function (res) {
            window._saleFollowupFetching = null;
            if (typeof updateNotificationBadge === 'function') {
                try { updateNotificationBadge(); } catch (_eB) {}
            }
            return res;
        });
        return window._saleFollowupFetching;
    }

    function persistSaleFollowupSettings() {
        var d = _db();
        if (!d) return;
        if (!d.settings) d.settings = {};
        var en = document.getElementById('premium-sale-followup') || document.getElementById('set-enable-sale-followup');
        var msgEl = document.getElementById('set-sale-followup-message');
        d.settings.enableSaleFollowup = en ? !!en.checked : false;
        d.settings.saleFollowupSchedule = readFollowupScheduleFromUi();
        var firstDay = d.settings.saleFollowupSchedule.find(function (x) { return x.unit === 'day'; });
        d.settings.saleFollowupDays = firstDay ? firstDay.value : 10;
        if (msgEl) d.settings.saleFollowupMessage = companySanitizeWaMessage(String(msgEl.value || '')).slice(0, 2000);
        var wVal = document.getElementById('set-sale-followup-warranty-val');
        var wUnit = document.getElementById('set-sale-followup-warranty-unit');
        var wNum = wVal ? (parseInt(wVal.value, 10) || 12) : 12;
        if (wNum < 1) wNum = 1;
        if (wNum > 999) wNum = 999;
        d.settings.saleFollowupWarrantyValue = wNum;
        d.settings.saleFollowupWarrantyUnit = wUnit ? String(wUnit.value || 'month') : 'month';
        if (typeof updateToggleCards === 'function') {
            try { updateToggleCards(); } catch (_eU) {}
        }
        if (typeof syncSettingsLockedPreviewCards === 'function') {
            try { syncSettingsLockedPreviewCards(); } catch (_eL) {}
        }
        window._saleFollowupLoadedAt = 0;
        ensureSaleFollowupPoll();
        if (typeof saveSettings === 'function') {
            try { saveSettings().catch(function () {}); } catch (_eS) {}
        }
        fetchSaleFollowups(true).then(function () {
            var view = document.getElementById('view-notifications');
            if (view && view.classList.contains('active') && typeof renderNotifications === 'function') {
                renderNotifications();
            }
        });
    }

    function loadSaleFollowupSettingsUi() {
        var d = _db();
        var s = d && d.settings ? d.settings : {};
        var en = document.getElementById('premium-sale-followup') || document.getElementById('set-enable-sale-followup');
        if (en) en.checked = s.enableSaleFollowup === true || s.enableSaleFollowup === 1 || s.enableSaleFollowup === '1';
        renderFollowupScheduleUi(s.saleFollowupSchedule);
        var msgEl = document.getElementById('set-sale-followup-message');
        if (msgEl) {
            var savedMsg = String(s.saleFollowupMessage || '').trim();
            var nextMsg = companySanitizeWaMessage(isLegacyFollowupTemplate(savedMsg) ? getSaleFollowupDefaultMessage() : savedMsg);
            msgEl.value = nextMsg;
            if (d && d.settings && nextMsg !== savedMsg) {
                d.settings.saleFollowupMessage = nextMsg;
                if (typeof saveSettings === 'function') {
                    try { saveSettings().catch(function () {}); } catch (_eSv) {}
                }
            }
        }
        var wVal = document.getElementById('set-sale-followup-warranty-val');
        var wUnit = document.getElementById('set-sale-followup-warranty-unit');
        var w = getSaleFollowupWarranty();
        if (wVal) wVal.value = String(w.value);
        if (wUnit) wUnit.value = w.unit;
    }

    function buildSaleFollowupNotifHtml() {
        if (!isSaleFollowupEnabled()) return '';
        var cache = window._saleFollowupCache;
        var rows = (cache && Array.isArray(cache.rows)) ? cache.rows : [];
        if (!rows.length) return '';
        var esc = (typeof escapeHtml === 'function') ? escapeHtml : function (x) { return String(x == null ? '' : x); };
        var body = rows.map(function (row) {
            var sid = parseInt(row && row.sale_id, 10) || 0;
            var stepKey = String((row && row.step_key) || '10d').replace(/[^0-9mhd]/g, '');
            var rawName = String((row && row.customer_name) || '').trim() || _t('followup_guest_name', 'برایێ من');
            var who = esc(_t('notif_followup_whose', 'دەمێ: {name}').replace('{name}', rawName));
            var items = esc((row && row.item_names) || '');
            var phoneDisp = esc(String((row && row.phone) || '').trim());
            var phoneOk = !!normalizeWaPhoneDigits(row && row.phone);
            var stepLbl = formatFollowupStep(row);
            var ageLbl = formatFollowupAge(row);
            var waBtn = phoneOk
                ? ('<button type="button" class="btn btn-sm btn-success followup-wa-btn" onclick="openSaleFollowupWhatsApp(' + sid + ', \'' + stepKey + '\')"><i class="fab fa-whatsapp"></i> ' + esc(_t('notif_followup_wa', 'واتسئاپ')) + '</button>')
                : ('<span class="followup-nophone">' + esc(_t('notif_followup_nophone', 'تەلەفۆن نینە')) + '</span>');
            return '<li class="notif-stock-row followup-row">' +
                '<span class="notif-stock-name">' +
                '<b class="followup-who">' + who + '</b>' +
                (phoneDisp ? ('<small class="followup-phone" dir="ltr">' + phoneDisp + '</small>') : '') +
                (items ? ('<small class="followup-items">' + items + '</small>') : '') +
                '<small class="followup-meta">' + esc(stepLbl) + ' · ' + esc(ageLbl) + '</small>' +
                '</span>' +
                '<span class="followup-actions">' +
                waBtn +
                '<button type="button" class="btn btn-sm btn-dark" onclick="markSaleFollowupDone(' + sid + ', \'' + stepKey + '\')" title="' + esc(_t('notif_followup_done', 'هاتە ناردن')) + '"><i class="fas fa-check"></i></button>' +
                '</span></li>';
        }).join('');
        if (typeof buildNotifCard !== 'function') {
            return '<div class="notif-card notif-card--followup"><div class="notif-card-head"><h3>' + esc(_t('notif_followup_title', 'پەیوەندیا پشتی فرۆتنێ')) + '</h3></div><ul class="notif-stock-list">' + body + '</ul></div>';
        }
        return buildNotifCard({
            tone: 'followup',
            icon: 'fa-comment-dots',
            title: _t('notif_followup_title', 'پەیوەندیا پشتی فرۆتنێ'),
            count: rows.length,
            bodyHtml: '<p class="followup-hint">' + esc(_t('notif_followup_hint', 'ل ڤێرە دەمێ کێیە دێ دیار بیت. دوگمێ سەوز = نامە ئامادە د واتسئاپێ دا.')) + '</p><ul class="notif-stock-list">' + body + '</ul>'
        });
    }

    function formatFollowupStep(row) {
        var n = parseInt(row && row.step_index, 10) || 1;
        var val = parseInt(row && row.step_value, 10) || 1;
        var unit = String((row && row.step_unit) || 'day');
        var u = unit === 'minute' ? _t('followup_unit_minute', 'خولەک') : (unit === 'hour' ? _t('followup_unit_hour', 'دەمژمێر') : _t('followup_unit_day', 'ڕۆژ'));
        return _t('notif_followup_step', 'جارا {n} — پشتی {v} {u}').replace('{n}', String(n)).replace('{v}', String(val)).replace('{u}', u);
    }

    function formatFollowupAge(row) {
        var sec = parseInt(row && row.age_seconds, 10) || 0;
        if (sec < 3600) {
            return _t('notif_followup_minutes_ago', '{n} خولەک بەرێ').replace('{n}', String(Math.max(1, Math.round(sec / 60))));
        }
        if (sec < 86400) {
            return _t('notif_followup_hours_ago', '{n} دەمژمێر بەرێ').replace('{n}', String(Math.max(1, Math.round(sec / 3600))));
        }
        return _t('notif_followup_days_ago', '{n} ڕۆژ بەرێ').replace('{n}', String(Math.max(1, Math.round(sec / 86400))));
    }

    function findFollowupRow(saleId, stepKey) {
        var rows = (window._saleFollowupCache && window._saleFollowupCache.rows) || [];
        var id = parseInt(saleId, 10) || 0;
        var key = String(stepKey || '').replace(/[^0-9mhd]/g, '');
        for (var i = 0; i < rows.length; i++) {
            if (parseInt(rows[i].sale_id, 10) !== id) continue;
            if (key && String(rows[i].step_key || '') !== key) continue;
            return rows[i];
        }
        return null;
    }

    function openSaleFollowupWhatsApp(saleId, stepKey) {
        var row = findFollowupRow(saleId, stepKey);
        if (!row) return;
        var digits = normalizeWaPhoneDigits(row.phone);
        if (!digits) {
            if (typeof showToast === 'function') showToast(_t('notif_followup_nophone', 'تەلەفۆن نینە'), true);
            return;
        }
        var url = 'https://wa.me/' + digits + '?text=' + encodeURIComponent(buildSaleFollowupText(row));
        try { window.open(url, '_blank'); } catch (_eO) { window.location.href = url; }
    }

    function markSaleFollowupDone(saleId, stepKey) {
        var id = parseInt(saleId, 10) || 0;
        var key = String(stepKey || '10d').replace(/[^0-9mhd]/g, '') || '10d';
        if (id <= 0) return;
        var row = findFollowupRow(id, key);
        var fd = new FormData();
        fd.append('action', 'mark_sale_followup');
        fd.append('sale_id', String(id));
        fd.append('step_key', key);
        if (row && Array.isArray(row.sale_ids) && row.sale_ids.length) {
            fd.append('sale_ids', row.sale_ids.join(','));
        }
        var req = (typeof apiJson === 'function')
            ? apiJson('?action=mark_sale_followup', { method: 'POST', body: fd })
            : fetch('?action=mark_sale_followup', { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); });
        Promise.resolve(req).then(function (res) {
            if (!res || res.status !== 'success') {
                if (typeof showToast === 'function') showToast(_t('toast_save_failed', 'پاراستن سەرنەکەفت'), true);
                return;
            }
            if (window._saleFollowupCache && Array.isArray(window._saleFollowupCache.rows)) {
                window._saleFollowupCache.rows = window._saleFollowupCache.rows.filter(function (r) {
                    return !(parseInt(r.sale_id, 10) === id && String(r.step_key || '') === key);
                });
                window._saleFollowupCache.count = window._saleFollowupCache.rows.length;
            }
            renderFollowupAlertBar((window._saleFollowupCache && window._saleFollowupCache.rows) || []);
            if (typeof showToast === 'function') showToast(_t('toast_followup_marked', 'هاتە نیشانەکرن: نامە هاتە ناردن'));
            if (typeof renderNotifications === 'function') renderNotifications();
            if (typeof updateNotificationBadge === 'function') updateNotificationBadge();
        }).catch(function () {
            if (typeof showToast === 'function') showToast(_t('toast_save_failed', 'پاراستن سەرنەکەفت'), true);
        });
    }

    function getSaleFollowupDays() {
        var s = getSaleFollowupSchedule().find(function (x) { return x.unit === 'day'; });
        return s ? s.value : 10;
    }

    window.isSaleFollowupEnabled = isSaleFollowupEnabled;
    window.getSaleFollowupDays = getSaleFollowupDays;
    window.getSaleFollowupRefreshMs = getSaleFollowupRefreshMs;
    window.addSaleFollowupScheduleRow = addSaleFollowupScheduleRow;
    window.removeSaleFollowupScheduleRow = removeSaleFollowupScheduleRow;
    window.fetchSaleFollowups = fetchSaleFollowups;
    window.buildSaleFollowupNotifHtml = buildSaleFollowupNotifHtml;
    window.persistSaleFollowupSettings = persistSaleFollowupSettings;
    window.loadSaleFollowupSettingsUi = loadSaleFollowupSettingsUi;
    window.openSaleFollowupWhatsApp = openSaleFollowupWhatsApp;
    window.markSaleFollowupDone = markSaleFollowupDone;
    window.getSaleFollowupMobilePayload = function () {
        if (!isSaleFollowupEnabled()) {
            return { followupCount: 0, followups: [] };
        }
        var cache = window._saleFollowupCache;
        var rows = (cache && Array.isArray(cache.rows)) ? cache.rows : [];
        var out = [];
        for (var i = 0; i < rows.length && out.length < 20; i++) {
            var row = rows[i];
            var phone = normalizeWaPhoneDigits(row && row.phone);
            out.push({
                sale_id: parseInt(row && row.sale_id, 10) || 0,
                step_key: String((row && row.step_key) || '').replace(/[^0-9mhd]/g, '').slice(0, 12),
                sale_ids: Array.isArray(row && row.sale_ids) ? row.sale_ids.slice(0, 8) : [],
                customer_name: String((row && row.customer_name) || '').trim().slice(0, 80),
                phone: phone,
                invoice_no: String((row && row.invoice_no) || '').slice(0, 40),
                item_names: String((row && row.item_names) || '').slice(0, 220),
                text: String(buildSaleFollowupText(row) || '').slice(0, 1800)
            });
        }
        return { followupCount: out.length, followups: out };
    };
    window.getPosCustomerPhoneValue = getPosCustomerPhoneValue;
    window.setPosCustomerPhoneValue = setPosCustomerPhoneValue;
    window.syncPosCustomerPhoneFromName = syncPosCustomerPhoneFromName;
    window.ensureFollowupCustomerPhone = ensureFollowupCustomerPhone;
    window.patchCustomerPhone = patchCustomerPhone;

    function bootSaleFollowupWatch() {
        if (window._saleFollowupBooted) return;
        window._saleFollowupBooted = true;
        setTimeout(function () {
            if (!isSaleFollowupEnabled()) return;
            fetchSaleFollowups(true);
            ensureSaleFollowupPoll();
        }, 1500);
    }
    if (document.readyState === 'complete') bootSaleFollowupWatch();
    else window.addEventListener('load', bootSaleFollowupWatch);
})();
