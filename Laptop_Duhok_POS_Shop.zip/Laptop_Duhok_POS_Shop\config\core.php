<?php
// Core setup and helper functions
date_default_timezone_set('Asia/Baghdad');
