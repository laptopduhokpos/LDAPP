// POS reports - work calendar & shift summary
        // --- WORK CALENDAR (تقويم العمل) ---
        function _d(k, fb) {
            if (typeof t === 'function') {
                var v = t(k);
                if (v && v !== k) return v;
            }
            return fb || k;
        }
        function _safeTime(rawDate, loc) {
            if (!rawDate) return '';
            try {
                var d = (typeof parseSQLDate === 'function') ? parseSQLDate(rawDate) : new Date(rawDate);
                if (d && !isNaN(d.getTime())) {
                    return d.toLocaleTimeString(loc || 'ku-IQ', { hour: '2-digit', minute: '2-digit' });
                }
            } catch (_e) {}
            return String(rawDate).slice(11, 16) || '';
        }
        /** Server month rollup (full DB — client keeps only ~200 recent sales so past months looked empty). */
        let calViewDate = new Date();
        var calMonthStatsCache = {};
        var calMonthFetchCtrl = null;
        function _calMonthCacheKey(y, m1, userParam) {
            var scope = userParam || 'all';
            if (currentUser && currentUser.role !== 'admin' && currentUser.role !== 'manager') {
                scope = currentUser.name || 'user';
            }
            return y + '-' + m1 + '-' + scope;
        }
        function invalidateCalendarMonthCache() {
            calMonthStatsCache = {};
        }
        window.invalidateCalendarMonthCache = invalidateCalendarMonthCache;

        function getCalendarDayStatsRecord(dateStr, userParam) {
            var iso = String(dateStr || '').slice(0, 10);
            var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
            if (!m) return null;
            var y = parseInt(m[1], 10);
            var mo = parseInt(m[2], 10);
            var staffEl = document.getElementById('cal-staff-filter');
            var scope = userParam || (staffEl && staffEl.value) || 'all';
            var tryKeys = [];
            if (typeof _calMonthCacheKey === 'function') {
                tryKeys.push(_calMonthCacheKey(y, mo, scope));
                tryKeys.push(_calMonthCacheKey(y, mo, 'all'));
            }
            tryKeys.push(y + '-' + mo + '-' + scope);
            tryKeys.push(y + '-' + mo + '-all');
            var i;
            for (i = 0; i < tryKeys.length; i++) {
                var cached = calMonthStatsCache[tryKeys[i]];
                if (cached && cached.days && cached.days[iso]) return cached.days[iso];
            }
            for (var k in calMonthStatsCache) {
                if (!Object.prototype.hasOwnProperty.call(calMonthStatsCache, k)) continue;
                var c = calMonthStatsCache[k];
                if (c && c.days && c.days[iso]) return c.days[iso];
            }
            return null;
        }
        window.getCalendarDayStatsRecord = getCalendarDayStatsRecord;
        // Do NOT wrap as window.renderWorkCalendar = function(){ return renderWorkCalendar(); }:
        // in classic scripts the global binding and window property are the same → infinite recursion.

        function renderCalendarLoadingState() {
            var grid = document.getElementById('work-calendar-grid');
            var panel = document.getElementById('calendar-month-summary-panel');
            var loadingMsg = (typeof t === 'function') ? t('cal_loading') : 'چاوەڕێ بکە...';
            if (grid) {
                grid.innerHTML = getCalendarWeekdayHeaderHtml() +
                    '<div class="calendar-day-loading" style="grid-column:1/-1;padding:48px 16px;text-align:center;color:var(--text-muted);">' +
                    '<i class="fas fa-spinner fa-spin" style="font-size:1.5rem;margin-bottom:12px;color:var(--brand);"></i>' +
                    '<div style="font-size:0.95rem;">' + escapeHtml(loadingMsg) + '</div></div>';
            }
            if (panel) panel.innerHTML = '';
        }

        function _calBucketRowsByBusinessDate(rows, dateField, monthStart, monthEnd) {
            var map = {};
            (rows || []).forEach(function(row) {
                if (!row) return;
                var raw = dateField ? row[dateField] : (row.date || row.created_at);
                if (!raw) return;
                var ds = (typeof getBusinessDate === 'function' && typeof parseSQLDate === 'function')
                    ? getBusinessDate(parseSQLDate(raw))
                    : '';
                if (!ds || ds < monthStart || ds > monthEnd) return;
                if (!map[ds]) map[ds] = [];
                map[ds].push(row);
            });
            return map;
        }

        function _calBuildLocalMonthBuckets(year, month, monthStart, monthEnd, calSeeAllShop, selectedUser) {
            var _db = (typeof db !== 'undefined' && db) ? db : (typeof window !== 'undefined' ? window.db : null);
            var allSales = typeof getReportSales === 'function' ? getReportSales() : [];
            var allExpenses = (_db && _db.expenses) ? _db.expenses : [];
            var allReturns = (_db && _db.returns) ? _db.returns : [];
            if (!calSeeAllShop && currentUser) {
                allExpenses = allExpenses.filter(function(e) { return e.user === currentUser.name; });
                allSales = allSales.filter(function(s) { return s.cashier === currentUser.name; });
                allReturns = allReturns.filter(function(r) { return r.cashier === currentUser.name; });
            } else if (selectedUser && selectedUser !== 'all') {
                allExpenses = allExpenses.filter(function(e) { return e.user === selectedUser; });
                allSales = allSales.filter(function(s) { return s.cashier === selectedUser; });
                allReturns = allReturns.filter(function(r) { return r.cashier === selectedUser; });
            }
            return {
                salesByDate: _calBucketRowsByBusinessDate(allSales, null, monthStart, monthEnd),
                expensesByDate: _calBucketRowsByBusinessDate(allExpenses, 'date', monthStart, monthEnd),
                returnsByDate: _calBucketRowsByBusinessDate(allReturns, 'date', monthStart, monthEnd),
                purchaseReturnsByDate: _calBucketRowsByBusinessDate((_db && _db.purchase_returns) ? _db.purchase_returns : [], 'date', monthStart, monthEnd),
                ledgerByDate: _calBucketRowsByBusinessDate((_db && _db.ledger) ? _db.ledger : [], null, monthStart, monthEnd),
                customerLedgerByDate: _calBucketRowsByBusinessDate((_db && _db.customer_ledger) ? _db.customer_ledger : [], null, monthStart, monthEnd)
            };
        }

        function _calProductById(products) {
            var map = new Map();
            (products || []).forEach(function(p) {
                if (p && p.id != null) map.set(Number(p.id), p);
            });
            return map;
        }

        function isPosDeliveryFeatureOn() {
            return typeof isDeliveryFeatureEnabled === 'function'
                ? isDeliveryFeatureEnabled()
                : !!(typeof db !== 'undefined' && db && db.settings && db.settings.enableDelivery === true);
        }

        function deliveryBizDate(raw) {
            if (!raw) return '';
            if (typeof getBusinessDate === 'function' && typeof parseSQLDate === 'function') {
                try {
                    return getBusinessDate(parseSQLDate(raw)) || '';
                } catch (_eBiz) { return ''; }
            }
            var s = String(raw);
            return s.length >= 10 ? s.slice(0, 10) : '';
        }

        function deliveryStatusLabel(st) {
            st = String(st || '').toLowerCase();
            var _d = function(k, fb) {
                if (typeof t === 'function') {
                    var v = t(k);
                    if (v && v !== k) return v;
                }
                return fb || k;
            };
            if (st === 'delivered') return _d('del_status_delivered', 'گەهشت');
            if (st === 'refused') return _d('del_status_refused', 'رەفس');
            if (st === 'cancelled') return _d('del_status_cancelled', 'هەلوەشاندی');
            return _d('del_badge_pending', 'بەرێکرن');
        }

        function summarizeDeliveriesForRange(fromISO, toISO, rows) {
            var roundM = typeof roundMoney === 'function' ? roundMoney : function(x) { return Math.round(Number(x) || 0); };
            var list = Array.isArray(rows)
                ? rows
                : ((typeof db !== 'undefined' && db && Array.isArray(db.deliveries)) ? db.deliveries : []);
            var out = {
                delivery_total: 0,
                delivery_count: 0,
                delivery_pending: 0,
                delivery_pending_count: 0,
                delivery_delivered: 0,
                delivery_delivered_count: 0,
                delivery_refused: 0,
                delivery_refused_count: 0,
                delivery_cancelled: 0,
                delivery_cancelled_count: 0,
                delivery_hold: 0,
                delivery_hold_count: 0,
                rows: []
            };
            var seen = {};
            list.forEach(function(d) {
                if (!d) return;
                var st = String(d.status || '').toLowerCase();
                var amt = roundM(d.total || 0);
                var created = deliveryBizDate(d.date);
                var settled = deliveryBizDate(d.settled_at);
                var inCreated = !!(created && fromISO && toISO && created >= fromISO && created <= toISO);
                var inSettled = !!(settled && fromISO && toISO && settled >= fromISO && settled <= toISO);
                if (st === 'pending') {
                    out.delivery_hold = roundM(out.delivery_hold + amt);
                    out.delivery_hold_count++;
                }
                if (inCreated) {
                    out.delivery_total = roundM(out.delivery_total + amt);
                    out.delivery_count++;
                    if (st === 'pending') {
                        out.delivery_pending = roundM(out.delivery_pending + amt);
                        out.delivery_pending_count++;
                    }
                }
                if (inSettled) {
                    if (st === 'delivered') {
                        out.delivery_delivered = roundM(out.delivery_delivered + amt);
                        out.delivery_delivered_count++;
                    } else if (st === 'refused') {
                        out.delivery_refused = roundM(out.delivery_refused + amt);
                        out.delivery_refused_count++;
                    } else if (st === 'cancelled') {
                        out.delivery_cancelled = roundM(out.delivery_cancelled + amt);
                        out.delivery_cancelled_count++;
                    }
                }
                if (inCreated || inSettled) {
                    var id = d.id != null ? String(d.id) : (created + '-' + amt);
                    if (!seen[id]) {
                        seen[id] = true;
                        out.rows.push(d);
                    }
                }
            });
            return out;
        }

        function _calDayPoolsFromBuckets(buckets, dateStr) {
            var expenses = (buckets.expensesByDate[dateStr] || []).slice();
            var ledger = buckets.ledgerByDate[dateStr] || [];
            if (typeof mergeCompanyDebtExpensesFromLedger === 'function') {
                expenses = mergeCompanyDebtExpensesFromLedger(expenses, ledger, (db && db.companies) ? db.companies : []);
            }
            return {
                sales: buckets.salesByDate[dateStr] || [],
                expenses: expenses,
                returns: buckets.returnsByDate[dateStr] || [],
                purchase_returns: buckets.purchaseReturnsByDate[dateStr] || [],
                ledger: ledger,
                customer_ledger: buckets.customerLedgerByDate[dateStr] || []
            };
        }
        function getCalendarMonthName(m0) {
            var k = 'cal_month_' + m0;
            if (typeof t === 'function') {
                var s = t(k);
                if (s && s !== k) return s;
            }
            var fb = ['کانوون٢','شوبات','ئازار','نیسان','ئایار','حوزەیران','تەمموز','ئاب','ئەیلول','تشرینی١','تشرینی٢','کانوون١'];
            return fb[m0] || '';
        }
        /** Calendar header: numbers only (e.g. 08 / 2026) — not month names. */
        function formatCalendarMonthYearLabel(m0, year) {
            var mm = String((Number(m0) || 0) + 1);
            if (mm.length < 2) mm = '0' + mm;
            return mm + ' / ' + String(year);
        }

        var _calPickerYear = null;
        var _calPickerDocCloseBound = false;

        function _calPad2(n) {
            var s = String(n);
            return (s.length < 2) ? ('0' + s) : s;
        }

        function closeCalMonthPicker() {
            var pop = document.getElementById('cal-month-picker');
            var titleEl = document.getElementById('cal-month-title');
            if (pop) pop.style.display = 'none';
            if (titleEl) titleEl.classList.remove('is-open');
        }

        function renderCalMonthPickerGrid() {
            var grid = document.getElementById('cal-month-picker-grid');
            var yearEl = document.getElementById('cal-month-picker-year');
            if (!grid) return;
            var y = _calPickerYear != null ? _calPickerYear : calViewDate.getFullYear();
            _calPickerYear = y;
            if (yearEl) yearEl.textContent = String(y);
            var curY = calViewDate.getFullYear();
            var curM = calViewDate.getMonth();
            var html = '';
            for (var m = 0; m < 12; m++) {
                var isCur = (y === curY && m === curM);
                html += '<button type="button" class="cal-month-picker__m' + (isCur ? ' is-current' : '') + '"' +
                    ' onclick="typeof pickCalMonthYear===\'function\'&&pickCalMonthYear(' + y + ',' + m + ')">' +
                    _calPad2(m + 1) + '</button>';
            }
            grid.innerHTML = html;
        }

        function shiftCalMonthPickerYear(delta) {
            if (_calPickerYear == null) _calPickerYear = calViewDate.getFullYear();
            _calPickerYear = Math.max(1970, Math.min(2100, _calPickerYear + (parseInt(delta, 10) || 0)));
            renderCalMonthPickerGrid();
        }

        function openCalMonthPicker() {
            var pop = document.getElementById('cal-month-picker');
            var titleEl = document.getElementById('cal-month-title');
            if (!pop) return;
            _calPickerYear = calViewDate.getFullYear();
            renderCalMonthPickerGrid();
            pop.style.display = 'block';
            if (titleEl) titleEl.classList.add('is-open');
            if (!_calPickerDocCloseBound) {
                _calPickerDocCloseBound = true;
                document.addEventListener('click', function(ev) {
                    var popEl = document.getElementById('cal-month-picker');
                    var titleBtn = document.getElementById('cal-month-title');
                    if (!popEl || popEl.style.display === 'none') return;
                    var t = ev.target;
                    if (popEl.contains(t) || (titleBtn && titleBtn.contains(t))) return;
                    closeCalMonthPicker();
                }, true);
            }
        }

        function toggleCalMonthPicker(ev) {
            if (ev) {
                try { ev.stopPropagation(); } catch (_e) {}
            }
            var pop = document.getElementById('cal-month-picker');
            if (pop && pop.style.display !== 'none' && pop.style.display !== '') {
                closeCalMonthPicker();
                return;
            }
            openCalMonthPicker();
        }

        function pickCalMonthYear(year, month0) {
            var y = parseInt(year, 10);
            var m0 = parseInt(month0, 10);
            if (!Number.isFinite(y) || y < 1970 || y > 2100) return;
            if (!Number.isFinite(m0) || m0 < 0 || m0 > 11) return;
            calViewDate = new Date(y, m0, 1);
            closeCalMonthPicker();
            if (typeof renderWorkCalendar === 'function') renderWorkCalendar();
        }

        if (typeof window !== 'undefined') {
            window.toggleCalMonthPicker = toggleCalMonthPicker;
            window.openCalMonthPicker = openCalMonthPicker;
            window.closeCalMonthPicker = closeCalMonthPicker;
            window.shiftCalMonthPickerYear = shiftCalMonthPickerYear;
            window.pickCalMonthYear = pickCalMonthYear;
        }

        function getCalendarWeekdayHeaderHtml() {
            var keys = ['cal_dow_sat','cal_dow_sun','cal_dow_mon','cal_dow_tue','cal_dow_wed','cal_dow_thu','cal_dow_fri'];
            return keys.map(function(key) {
                var w = (typeof t === 'function') ? t(key) : key;
                return '<div style="text-align:center; font-weight:bold; color:var(--brand); padding:8px; font-size:0.85rem;">' + w + '</div>';
            }).join('');
        }
        function getCalendarWholesaleLabel() {
            return (typeof t === 'function') ? t('cal_label_batch') : 'جوملە';
        }

        function getCalendarInstallmentSummaryForDate(dateStr, instMapOverride) {
            if (!dateStr) return null;
            var today = new Date().toISOString().slice(0, 10);
            if (instMapOverride && instMapOverride[dateStr]) {
                var recSrv = instMapOverride[dateStr];
                return {
                    count: parseInt(recSrv.count, 10) || 0,
                    total: parseFloat(recSrv.total) || 0,
                    items: Array.isArray(recSrv.items) ? recSrv.items : [],
                    is_overdue: dateStr < today,
                    is_today: dateStr === today,
                    is_future: dateStr > today
                };
            }
            if (!db || !Array.isArray(db.installment_items)) return null;
            var items = [];
            var total = 0;
            (db.installment_items || []).forEach(function(it) {
                if (!it || String(it.due_date || '') !== String(dateStr)) return;
                if (String(it.status || '') === 'paid') return;
                var plan = (db.installment_plans || []).find(function(p) {
                    return p && String(p.id) === String(it.plan_id) && p.status === 'active';
                });
                if (!plan) return;
                var remaining = Math.round(Math.max(0, (parseFloat(it.amount) || 0) - (parseFloat(it.paid_amount) || 0)));
                if (remaining <= 0) return;
                var cust = (db.customers || []).find(function(c) { return c && String(c.id) === String(plan.customer_id); });
                total += remaining;
                items.push({
                    customer_id: plan.customer_id,
                    customer_name: cust ? (cust.name || ('#' + plan.customer_id)) : ('#' + plan.customer_id),
                    installment_no: it.installment_no,
                    remaining: remaining,
                    status: it.status
                });
            });
            if (!items.length) return null;
            return {
                count: items.length,
                total: total,
                items: items,
                is_overdue: dateStr < today,
                is_today: dateStr === today,
                is_future: dateStr > today
            };
        }

        function buildCalendarInstallmentHtml(instRec, dateStrKey) {
            if (!instRec || !instRec.count) return '';
            var cls = 'calendar-day-installment';
            if (instRec.is_overdue) cls += ' is-overdue';
            else if (instRec.is_today) cls += ' is-due-today';
            else cls += ' is-upcoming';
            var label = (typeof t === 'function') ? t('cal_installment_due') : 'قست';
            var tipItems = (instRec.items || []).slice(0, 4).map(function(it) {
                return (it.customer_name || '') + ' (' + (typeof formatCurrency === 'function' ? formatCurrency(Math.round(it.remaining || 0)) : Math.round(it.remaining || 0)) + ')';
            }).join(' | ');
            if ((instRec.items || []).length > 4) tipItems += ' ...';
            var escDate = encodeURIComponent(dateStrKey);
            return '<div class="' + cls + '" title="' + escapeHtml(tipItems) + '" onclick="event.stopPropagation(); openCalendarInstallmentDay(decodeURIComponent(\'' + escDate + '\'))">' +
                '<i class="fas fa-credit-card"></i> ' + escapeHtml(label) + ': ' + (typeof formatCurrency === 'function' ? formatCurrency(Math.round(instRec.total || 0)) : Math.round(instRec.total || 0)) +
                ' <span class="calendar-day-installment-count">(' + instRec.count + ')</span></div>';
        }

        function openCalendarInstallmentDay(dateStr) {
            if (!dateStr) return;
            var rec = getCalendarInstallmentSummaryForDate(dateStr);
            if (!rec || !rec.items.length) return;
            var title = (typeof t === 'function') ? t('cal_installment_day_title') : 'قستەکان';
            var lines = rec.items.map(function(it, idx) {
                return (idx + 1) + '. ' + (it.customer_name || '') + ' — ' + formatCurrency(it.remaining || 0);
            }).join('\n');
            var msg = title + ' (' + dateStr + ')\n\n' + lines + '\n\n' + ((typeof t === 'function') ? t('cal_installment_day_open_hint') : 'بۆ وردەکاری کریارێ هەڵبژێرە');
            var pick = prompt(msg, '1');
            if (pick === null) return;
            var n = parseInt(pick, 10);
            if (!n || n < 1 || n > rec.items.length) return;
            var chosen = rec.items[n - 1];
            if (chosen && chosen.customer_id && typeof openCustomerProfile === 'function') {
                openCustomerProfile(chosen.customer_id);
            }
        }
        window.openCalendarInstallmentDay = openCalendarInstallmentDay;

        function buildExpiryAlertsMapFromCache() {
            var map = {};
            var cache = window._expiryAlertsCache;
            if (!cache) return map;
            function addRows(rows) {
                (rows || []).forEach(function(r) {
                    var d = String(r.expiry_date || '').trim();
                    if (!d) return;
                    if (!map[d]) map[d] = { count: 0, items: [] };
                    map[d].count++;
                    map[d].items.push({
                        product_id: r.product_id,
                        name: r.name || ('#' + r.product_id),
                        qty: parseFloat(r.qty) || 0
                    });
                });
            }
            addRows(cache.expired);
            addRows(cache.expiring_soon);
            return map;
        }

        function getExpiryDaysMapForDate(dateStr) {
            if (!dateStr) return null;
            var m = /^(\d{4})-(\d{2})/.exec(String(dateStr));
            if (!m) return null;
            var y = parseInt(m[1], 10);
            var mo = parseInt(m[2], 10);
            if (typeof _calMonthCacheKey !== 'function' || typeof calMonthStatsCache === 'undefined') return null;
            var cached = calMonthStatsCache[_calMonthCacheKey(y, mo)];
            return (cached && cached.expiry_days) ? cached.expiry_days : null;
        }

        function getCalendarExpirySummaryForDate(dateStr, expiryMapOverride) {
            if (!dateStr) return null;
            var today = new Date().toISOString().slice(0, 10);
            var raw = null;
            if (expiryMapOverride && expiryMapOverride[dateStr]) {
                raw = expiryMapOverride[dateStr];
            } else {
                raw = buildExpiryAlertsMapFromCache()[dateStr];
            }
            if (!raw || !raw.count) return null;
            return {
                count: parseInt(raw.count, 10) || (raw.items ? raw.items.length : 0),
                items: Array.isArray(raw.items) ? raw.items : [],
                is_expired: dateStr < today,
                is_today: dateStr === today,
                is_future: dateStr > today
            };
        }

        function buildCalendarExpiryHtml(expRec, dateStrKey) {
            if (!expRec || !expRec.count) return '';
            var cls = 'calendar-day-expiry';
            if (expRec.is_expired) cls += ' is-overdue';
            else if (expRec.is_today) cls += ' is-due-today';
            else cls += ' is-upcoming';
            var label = (typeof t === 'function') ? t('cal_expiry_due') : 'بەسەرچوون';
            var tipItems = (expRec.items || []).slice(0, 4).map(function(it) {
                return (it.name || '') + ' (' + (typeof formatQtyForDisplay === 'function' ? formatQtyForDisplay(it.qty || 0) : String(it.qty || 0)) + ')';
            }).join(' | ');
            if ((expRec.items || []).length > 4) tipItems += ' ...';
            var escDate = encodeURIComponent(dateStrKey);
            return '<div class="' + cls + '" title="' + escapeHtml(tipItems) + '" onclick="event.stopPropagation(); openDailyHistoryModal(decodeURIComponent(\'' + escDate + '\'))">' +
                '<i class="fas fa-hourglass-end"></i> ' + escapeHtml(label) +
                ' <span class="calendar-day-expiry-count">(' + expRec.count + ')</span></div>';
        }

        function resolveCalendarDayBorder(baseBorder, instRec, expRec) {
            if (instRec) {
                return instRec.is_overdue ? '2px solid #ef4444' : (instRec.is_today ? '2px solid #f59e0b' : '2px solid #8b5cf6');
            }
            if (expRec) {
                return expRec.is_expired ? '2px solid #ef4444' : (expRec.is_today ? '2px solid #f59e0b' : '2px solid #14b8a6');
            }
            return baseBorder;
        }

        function buildDailyExpirySectionHtml(expRec, dateStr) {
            if (!expRec || !expRec.count) return '';
            var title = expRec.is_expired
                ? ((typeof t === 'function') ? t('cal_expiry_section_expired') : 'ئایتمێن بەسەرچووی')
                : (expRec.is_today
                    ? ((typeof t === 'function') ? t('cal_expiry_section_today') : 'ئەمڕۆ بەسەر دەچن')
                    : ((typeof t === 'function') ? t('cal_expiry_section_future') : 'ل ئەڤ ڕۆژە بەسەر دەچن'));
            var borderColor = expRec.is_expired ? '#ef4444' : (expRec.is_today ? '#f59e0b' : '#14b8a6');
            var rows = (expRec.items || []).map(function(it) {
                return '<div style="display:flex; justify-content:space-between; gap:10px; padding:6px 4px; border-bottom:1px dashed var(--border); font-size:0.9rem;">' +
                    '<span>' + escapeHtml(it.name || ('#' + it.product_id)) + '</span>' +
                    '<b style="color:' + borderColor + '; white-space:nowrap;">' + escapeHtml(typeof formatQtyForDisplay === 'function' ? formatQtyForDisplay(it.qty || 0) : String(it.qty || 0)) + '</b>' +
                    '</div>';
            }).join('');
            return '<div id="daily-expiry-section" class="card daily-sum-section" style="border:1px solid ' + borderColor + '33;">' +
                '<h4 style="color:' + borderColor + ';"><i class="fas fa-hourglass-end"></i> ' + escapeHtml(title) + ' (' + expRec.count + ')</h4>' +
                '<div style="font-size:0.78rem; color:var(--text-muted); margin-bottom:6px;">' + escapeHtml(dateStr || '') + '</div>' +
                '<div style="max-height:160px; overflow-y:auto;">' + rows + '</div>' +
                '<button type="button" class="btn btn-sm btn-dark" style="margin-top:8px;" onclick="nav(\'warehouse\')"><i class="fas fa-warehouse"></i> ' + escapeHtml((typeof t === 'function') ? t('notif_go_warehouse_btn') : 'چوون بۆ کۆگە') + '</button>' +
                '</div>';
        }

        function refreshDailyExpirySection(dateStr) {
            var content = document.getElementById('daily-history-content');
            if (!content || !dateStr) return;
            var old = document.getElementById('daily-expiry-section');
            if (old) old.remove();

            function applyRec(rec) {
                var html = buildDailyExpirySectionHtml(rec, dateStr);
                if (!html) return;
                var anchor = document.getElementById('daily-expiry-section-anchor');
                if (anchor) {
                    anchor.insertAdjacentHTML('afterend', html);
                } else {
                    content.insertAdjacentHTML('afterbegin', html);
                }
            }

            var map = getExpiryDaysMapForDate(dateStr);
            var rec = getCalendarExpirySummaryForDate(dateStr, map);
            if (rec) {
                applyRec(rec);
                return;
            }
            rec = getCalendarExpirySummaryForDate(dateStr, buildExpiryAlertsMapFromCache());
            if (rec) {
                applyRec(rec);
                return;
            }
            fetch('?action=get_expiry_for_date&date=' + encodeURIComponent(dateStr), { credentials: 'same-origin' })
                .then(function(r) { return r.json().catch(function() { return { status: 'error' }; }); })
                .then(function(res) {
                    if (!res || res.status !== 'ok' || !res.count) return;
                    applyRec({
                        count: parseInt(res.count, 10) || 0,
                        items: Array.isArray(res.items) ? res.items : [],
                        is_expired: dateStr < new Date().toISOString().slice(0, 10),
                        is_today: dateStr === new Date().toISOString().slice(0, 10),
                        is_future: dateStr > new Date().toISOString().slice(0, 10)
                    });
                })
                .catch(function() {});
        }
        window.refreshDailyExpirySection = refreshDailyExpirySection;

        function calendarDayMetrics(dateStr, fallbackProfit, opts) {
            opts = opts || {};
            if (opts.useServerProfit) {
                return {
                    profit: fallbackProfit,
                    returns: opts.returns != null ? opts.returns : 0
                };
            }
            if (opts.dayPools && typeof getFinancialMetrics === 'function') {
                var scopePools = { dayPools: opts.dayPools };
                if (currentUser && currentUser.role !== 'admin') scopePools.salesScope = 'report';
                var mPools = getFinancialMetrics(dateStr, scopePools);
                if (mPools) {
                    return {
                        profit: mPools.netProfit,
                        returns: mPools.totalReturns || 0
                    };
                }
            }
            if (typeof getFinancialMetrics === 'function') {
                var scope = (currentUser && currentUser.role !== 'admin') ? { salesScope: 'report' } : {};
                var m = getFinancialMetrics(dateStr, scope);
                if (m) {
                    return {
                        profit: m.netProfit,
                        returns: m.totalReturns || 0
                    };
                }
            }
            return { profit: fallbackProfit, returns: opts.returns || 0 };
        }

        function renderCalendarMonthSummaryPanel(stats, monthLabel) {
            var panel = document.getElementById('calendar-month-summary-panel');
            if (!panel) return;
            stats = stats || {};
            var roundM = typeof roundMoney === 'function' ? roundMoney : function(x) { return Math.round(Number(x) || 0); };
            var _d = function(k, fb) {
                if (typeof t === 'function') {
                    var v = t(k);
                    if (v && v !== k) return v;
                }
                return fb || k;
            };
            var _fc = function(v, usd) {
                if (typeof formatReportAmount === 'function') {
                    var usdN = (usd != null && usd !== '' && Number.isFinite(Number(usd))) ? Number(usd) : undefined;
                    return formatReportAmount(roundM(v), usdN);
                }
                return typeof formatCurrency === 'function' ? formatCurrency(roundM(v)) : String(roundM(v));
            };

            var totalSales = roundM(stats.sales != null ? stats.sales : 0);
            var saleCount = parseInt(stats.sale_count, 10) || 0;
            var opExpenses = roundM(stats.expenses || 0);
            var purchasesTotal = roundM(stats.purchases_total || 0);
            var purchaseCount = parseInt(stats.purchase_count, 10) || 0;
            var companyDebt = roundM(stats.company_debt_payments || 0);
            var companyDebtCount = parseInt(stats.company_debt_count, 10) || 0;
            var customerDebt = roundM(stats.customer_debt_in || 0);
            var customerDebtCount = parseInt(stats.customer_debt_count, 10) || 0;
            var purchaseReturns = roundM(stats.purchase_returns_total || 0);
            var purchaseReturnsCash = roundM(stats.purchase_returns_cash != null ? stats.purchase_returns_cash : purchaseReturns);
            var purchaseReturnCount = parseInt(stats.purchase_returns_count, 10) || 0;
            var purchasesCash = roundM(stats.purchases_cash || 0);
            var purchasesFib = roundM(stats.purchases_fib || 0);
            var purchasesDebt = roundM(stats.debt_purchases != null ? stats.debt_purchases : Math.max(0, purchasesTotal - purchasesCash - purchasesFib));
            var salesReturns = roundM(stats.returns_total || 0);
            var cashSales = roundM(stats.cash_sales || 0);
            var fibSales = roundM(stats.fib_sales || 0);
            var debtSales = roundM(stats.debt_sales != null ? stats.debt_sales : Math.max(0, totalSales - cashSales - fibSales));
            var cashReturns = roundM(stats.cash_returns != null ? stats.cash_returns : salesReturns);
            var returnsCount = parseInt(stats.returns_count, 10) || 0;
            var voidedSales = roundM(stats.voided_sales_total || 0);
            var voidedSalesCount = parseInt(stats.voided_sales_count, 10) || 0;
            var voidedPurchases = roundM(stats.voided_purchases_total || 0);
            var voidedPurchasesCount = parseInt(stats.voided_purchases_count, 10) || 0;
            var wasteTotal = roundM(stats.waste_total || 0);
            var wasteCount = parseInt(stats.waste_count, 10) || 0;
            var gifts = roundM(stats.gifts_sum || 0);
            var giftsCount = parseInt(stats.gifts_count, 10) || 0;
            var wholesale = roundM(stats.wholesale_sum || 0);
            var netProfit = roundM(stats.profit || 0);
            var cashDrawer = roundM(stats.cash_drawer != null ? stats.cash_drawer : (stats.cash_movement || 0));
            var instCount = parseInt(stats.installment_count, 10) || 0;
            var instTotal = roundM(stats.installment_total || 0);
            var expiryCount = parseInt(stats.expiry_count, 10) || 0;
            // Locked raw USD from Daily Summary aggregation (stats.*_usd). Never invent live FX here.
            var u = {
                sales: stats.sales_usd,
                cashSales: stats.cash_sales_usd,
                debtSales: stats.debt_sales_usd,
                fibSales: stats.fib_sales_usd,
                expenses: stats.expenses_usd,
                purchasesTotal: stats.purchases_total_usd,
                purchasesCash: stats.purchases_cash_usd,
                purchasesFib: stats.purchases_fib_usd,
                purchasesDebt: stats.debt_purchases_usd,
                companyDebt: stats.company_debt_payments_usd,
                customerDebt: stats.customer_debt_in_usd,
                purchaseReturns: stats.purchase_returns_total_usd,
                purchaseReturnsCash: stats.purchase_returns_cash_usd,
                salesReturns: stats.returns_total_usd,
                cashReturns: stats.cash_returns_usd,
                waste: stats.waste_total_usd,
                gifts: stats.gifts_usd,
                profit: stats.profit_usd,
                cashDrawer: stats.cash_drawer_usd
            };
            var wholesaleLabel = getCalendarWholesaleLabel();
            var delTotal = roundM(stats.delivery_total || 0);
            var delCount = parseInt(stats.delivery_count, 10) || 0;
            var delPending = roundM(stats.delivery_pending != null ? stats.delivery_pending : 0);
            var delPendingCount = parseInt(stats.delivery_pending_count, 10) || 0;
            var delDelivered = roundM(stats.delivery_delivered || 0);
            var delDeliveredCount = parseInt(stats.delivery_delivered_count, 10) || 0;
            var delRefused = roundM(stats.delivery_refused || 0);
            var delRefusedCount = parseInt(stats.delivery_refused_count, 10) || 0;
            var delCancelled = roundM(stats.delivery_cancelled || 0);
            var delCancelledCount = parseInt(stats.delivery_cancelled_count, 10) || 0;
            var showDeliveryGroup = isPosDeliveryFeatureOn() || delCount > 0 || delDeliveredCount > 0 || delPendingCount > 0 || delRefusedCount > 0 || delCancelledCount > 0;

            function statCard(opts) {
                opts = opts || {};
                var needsAttr = opts.needs ? ' data-needs="' + opts.needs + '"' : '';
                var detail = opts.detail ? String(opts.detail) : '';
                var clickAttr = detail
                    ? ' role="button" tabindex="0" title="' + escapeHtml(_d('daily_summary_click_for_table', 'کلیک بکە بۆ وردەکاری')) + '" onclick="typeof openCalMonthStatDetail===\'function\'&&openCalMonthStatDetail(\'' + detail + '\')" onkeydown="if(event.key===\'Enter\'||event.key===\' \'){event.preventDefault();typeof openCalMonthStatDetail===\'function\'&&openCalMonthStatDetail(\'' + detail + '\');}"'
                    : '';
                var countHtml = (opts.count != null && opts.count !== '')
                    ? '<span class="cal-month-stat__count">' + escapeHtml(String(opts.count)) + '</span>'
                    : '';
                return '<div class="cal-month-stat cal-month-stat--' + (opts.tone || 'default') + (detail ? ' is-clickable' : '') + '"' + needsAttr + clickAttr + '>' +
                    '<div class="cal-month-stat__main">' +
                    '<div class="cal-month-stat__icon"><i class="' + (opts.icon || 'fas fa-circle') + '"></i></div>' +
                    '<div class="cal-month-stat__label">' + escapeHtml(opts.label) + countHtml + '</div>' +
                    '</div>' +
                    '<div class="cal-month-stat__value' + (opts.valueClass ? ' ' + opts.valueClass : '') + '">' + opts.value +
                    (opts.sub ? '<span class="cal-month-stat__sub">' + opts.sub + '</span>' : '') +
                    '</div>' +
                    '</div>';
            }

            var drawerSubParts = [];
            if (cashSales > 0 && Math.abs(cashSales - totalSales) > 0.009) {
                drawerSubParts.push(escapeHtml(_d('daily_summary_cash_sales_drawer_hint', 'فرۆتنا نەقد')) + ': ' + _fc(cashSales, u.cashSales));
            }
            if (customerDebt > 0) drawerSubParts.push('+' + _fc(customerDebt, u.customerDebt) + ' ' + escapeHtml(_d('daily_summary_customer_debt_drawer_hint', 'وەرگرتنا قەرزی کریار')));
            if (purchasesCash > 0) drawerSubParts.push('−' + _fc(purchasesCash, u.purchasesCash) + ' ' + escapeHtml(_d('daily_summary_cash_purchases_drawer_hint', 'کڕینا نەقد')));
            if (companyDebt > 0) drawerSubParts.push('−' + _fc(companyDebt, u.companyDebt) + ' ' + escapeHtml(_d('daily_summary_company_debt_drawer_hint', 'دانەڤا قەرزی کۆمپانیا')));
            if (cashReturns > 0) drawerSubParts.push('−' + _fc(cashReturns, u.cashReturns) + ' ' + escapeHtml(_d('daily_summary_returns_label', 'زڤڕاندنا فرۆشتن')));
            if (opExpenses > 0) drawerSubParts.push('−' + _fc(opExpenses, u.expenses) + ' ' + escapeHtml(_d('daily_summary_expenses_label', 'مەزاختن')));
            if (purchaseReturnsCash > 0) drawerSubParts.push('+' + _fc(purchaseReturnsCash, u.purchaseReturnsCash) + ' ' + escapeHtml(_d('daily_summary_purchase_returns_drawer_hint', 'زڤڕاندنا کڕینێ')));
            var drawerSub = drawerSubParts.join('<br>');

            var salesCards = [
                statCard({ tone: 'sales', detail: 'daily-sec-sales', icon: 'fas fa-chart-line', label: _d('daily_summary_total_sales', 'فرۆتنا گشتی'), count: saleCount, value: _fc(totalSales, u.sales) }),
                statCard({ tone: 'cashsale', detail: 'daily-sec-sales', icon: 'fas fa-money-bill-wave', label: _d('daily_summary_cash_sales', 'فرۆتنا نەقد'), value: _fc(cashSales, u.cashSales) }),
                statCard({ tone: 'debsale', detail: 'daily-sec-sales', icon: 'fas fa-university', label: _d('daily_summary_fib_sales', 'فرۆتنا FIB'), value: _fc(fibSales, u.fibSales) }),
                statCard({ tone: 'debsale', detail: 'daily-sec-sales', icon: 'fas fa-file-invoice-dollar', label: _d('daily_summary_debt_sales', 'فرۆتنا دەین'), value: _fc(debtSales, u.debtSales) })
            ];
            if (wholesale > 0) {
                salesCards.push(statCard({ tone: 'wholesale', detail: 'daily-sec-sales', icon: 'fas fa-box', label: wholesaleLabel, value: _fc(wholesale) }));
            }
            var purchaseCards = [
                statCard({ tone: 'purchase', detail: 'daily-sec-purchases', icon: 'fas fa-shopping-cart', label: _d('daily_summary_purchases_label', 'کڕین'), count: purchaseCount, value: _fc(purchasesTotal, u.purchasesTotal) }),
                statCard({ tone: 'cashpur', detail: 'daily-sec-purchases', icon: 'fas fa-coins', label: _d('daily_summary_cash_purchases', 'کڕینا نەقد'), value: _fc(purchasesCash, u.purchasesCash) }),
                statCard({ tone: 'cashpur', detail: 'daily-sec-purchases', icon: 'fas fa-university', label: _d('daily_summary_fib_purchases', 'کڕینا FIB'), value: _fc(purchasesFib, u.purchasesFib) }),
                statCard({ tone: 'debpur', detail: 'daily-sec-purchases', icon: 'fas fa-handshake', label: _d('daily_summary_debt_purchases', 'کڕینا دەین'), value: _fc(purchasesDebt, u.purchasesDebt) })
            ];
            var moneyCards = [
                statCard({ tone: 'expenses', detail: 'daily-sec-expenses', icon: 'fas fa-wallet', label: _d('daily_summary_expenses_label', 'مەزاختن'), value: _fc(opExpenses, u.expenses), needs: 'expenses' }),
                statCard({ tone: 'waste', detail: 'daily-sec-waste', icon: 'fas fa-recycle', label: _d('daily_summary_waste_label', 'تەلەف'), count: wasteCount, value: _fc(wasteTotal, u.waste) }),
                statCard({ tone: 'cdebt', detail: 'daily-sec-company-debt', icon: 'fas fa-building', label: _d('daily_summary_company_debt_label', 'دانەڤا قەرزی کۆمپانیا'), count: companyDebtCount, value: _fc(companyDebt, u.companyDebt) }),
                statCard({ tone: 'udebt', detail: 'daily-sec-customer-debt', icon: 'fas fa-hand-holding-usd', label: _d('daily_summary_customer_debt_label', 'وەرگرتنا قەرزی کریار'), count: customerDebtCount, value: _fc(customerDebt, u.customerDebt) })
            ];
            var returnCards = [
                statCard({ tone: 'preturn', detail: 'daily-sec-purchase-returns', icon: 'fas fa-truck-loading', label: _d('daily_summary_purchase_returns_label', 'زڤڕاندنا کڕینێ'), count: purchaseReturnCount, value: _fc(purchaseReturns, u.purchaseReturns), sub: (purchaseReturnsCash > 0 && Math.abs(purchaseReturns - purchaseReturnsCash) > 0.009 ? (escapeHtml(_d('daily_summary_purchase_returns_cash_hint', 'ل قاسەدا زیاد دبێتەوە (وەرگرتن)')) + ': ' + _fc(purchaseReturnsCash, u.purchaseReturnsCash)) : '') }),
                statCard({ tone: 'sreturn', detail: 'daily-sec-returns', icon: 'fas fa-undo', label: _d('daily_summary_returns_label', 'زڤڕاندنا فرۆشتن'), count: returnsCount, value: _fc(salesReturns, u.salesReturns) }),
                statCard({ tone: 'void', detail: 'daily-sec-voided', icon: 'fas fa-trash-alt', label: _d('daily_summary_voided_label', 'وەسڵێن ژێبری (فرۆتن)'), count: voidedSalesCount, value: _fc(voidedSales) }),
                statCard({ tone: 'vpurchase', detail: 'daily-sec-voided-purchases', icon: 'fas fa-trash-alt', label: _d('daily_summary_voided_purchases_label', 'وەسڵێن ژێبری (کڕین)'), count: voidedPurchasesCount, value: _fc(voidedPurchases) }),
                statCard({ tone: 'gift', detail: 'daily-sec-gifts', icon: 'fas fa-gift', label: _d('daily_summary_gifts_label', 'دیاری'), count: giftsCount, value: _fc(gifts, u.gifts) })
            ];
            if (instCount > 0) {
                returnCards.push(statCard({ tone: 'installment', icon: 'fas fa-credit-card', label: _d('cal_sum_installments', 'قستا مانگê'), count: instCount, value: _fc(instTotal) }));
            }
            if (expiryCount > 0) {
                returnCards.push(statCard({ tone: 'expiry', icon: 'fas fa-hourglass-end', label: _d('cal_sum_expiry', 'بەسەرچوون'), count: expiryCount, value: String(expiryCount) }));
            }
            var deliveryCards = [
                statCard({ tone: 'delivery', detail: 'daily-sec-delivery', icon: 'fas fa-motorcycle', label: _d('daily_summary_delivery_total', 'گەهاندنا گشتی'), count: delCount, value: _fc(delTotal) }),
                statCard({ tone: 'delivok', detail: 'daily-sec-delivery', icon: 'fas fa-check-circle', label: _d('del_status_delivered', 'گەهشت'), count: delDeliveredCount, value: _fc(delDelivered) }),
                statCard({ tone: 'delivpend', detail: 'daily-sec-delivery', icon: 'fas fa-clock', label: _d('del_badge_pending', 'بەرێکرن'), count: delPendingCount, value: _fc(delPending) }),
                statCard({ tone: 'delivref', detail: 'daily-sec-delivery', icon: 'fas fa-times-circle', label: _d('del_status_refused', 'رەفس'), count: delRefusedCount, value: _fc(delRefused) })
            ];
            if (delCancelledCount > 0) {
                deliveryCards.push(statCard({ tone: 'delivcancel', detail: 'daily-sec-delivery', icon: 'fas fa-ban', label: _d('del_status_cancelled', 'هەلوەشاندی'), count: delCancelledCount, value: _fc(delCancelled) }));
            }

            function monthGroup(title, hint, tone, cards, gridMod) {
                return '<section class="cal-month-summary__group cal-month-summary__group--' + tone + '">' +
                    '<div class="cal-month-summary__group-head">' +
                        '<h4 class="cal-month-summary__group-title">' + escapeHtml(title) + '</h4>' +
                        (hint ? '<p class="cal-month-summary__group-hint">' + escapeHtml(hint) + '</p>' : '') +
                    '</div>' +
                    '<div class="cal-month-summary__grid' + (gridMod ? ' ' + gridMod : '') + '">' + cards.join('') + '</div>' +
                    '</section>';
            }

            var groupsHtml =
                monthGroup(
                    _d('cal_month_group_sales', 'فرۆتن'),
                    _d('cal_month_group_sales_hint', 'نەقد + دەین = فرۆتنا گشتی'),
                    'sales',
                    salesCards,
                    salesCards.length === 3 ? 'cal-month-summary__grid--trio' : ''
                ) +
                monthGroup(
                    _d('cal_month_group_purchases', 'کڕین'),
                    _d('cal_month_group_purchases_hint', 'نەقد + دەین = کڕینا گشتی'),
                    'purchase',
                    purchaseCards,
                    'cal-month-summary__grid--trio'
                ) +
                (showDeliveryGroup
                    ? monthGroup(
                        _d('cal_month_group_delivery', 'گەهاندن'),
                        _d('cal_month_group_delivery_hint', 'گەهشت دچیتە قاسێ — بەرید ل دەف سایقی'),
                        'delivery',
                        deliveryCards,
                        ''
                    )
                    : '') +
                monthGroup(
                    _d('cal_month_group_money', 'مەزاختن و قەرز'),
                    '',
                    'money',
                    moneyCards,
                    ''
                ) +
                monthGroup(
                    _d('cal_month_group_returns', 'زڤڕاندن و ژێبرن'),
                    '',
                    'returns',
                    returnCards,
                    ''
                );

            var profitTone = netProfit >= 0 ? 'profit' : 'loss';
            var drawerTone = cashDrawer >= 0 ? 'drawer' : 'drawer drawer--neg';

            panel.innerHTML =
                '<div class="cal-month-summary">' +
                    '<div class="cal-month-summary__head">' +
                        '<div class="cal-month-summary__head-icon"><i class="fas fa-chart-pie"></i></div>' +
                        '<div class="cal-month-summary__head-text">' +
                            '<h3 class="cal-month-summary__title">' + escapeHtml(_d('cal_month_summary_heading', 'پوختەی مانگانە')) + '</h3>' +
                            (monthLabel ? '<p class="cal-month-summary__subtitle">' + escapeHtml(monthLabel) + '</p>' : '') +
                            '<p class="cal-month-summary__hint">' + escapeHtml(_d('cal_month_lines_hint', 'کلیک ل سەر هێلێ بکە بۆ وردەکاری')) + '</p>' +
                        '</div>' +
                    '</div>' +
                    '<div class="cal-month-summary__groups">' + groupsHtml + '</div>' +
                    '<div class="cal-month-summary__totals">' +
                        statCard({ tone: drawerTone, detail: 'daily-sec-cash', icon: 'fas fa-cash-register', label: _d('daily_summary_cash_drawer', 'قاسە'), value: _fc(cashDrawer, u.cashDrawer), valueClass: cashDrawer < 0 ? 'is-negative' : '' }) +
                        statCard({ tone: profitTone, detail: 'daily-sec-profit', icon: 'fas fa-coins', label: _d('daily_summary_net_profit', 'قازانجێ سافی'), value: _fc(netProfit, u.profit), needs: 'profit', valueClass: netProfit < 0 ? 'is-negative' : '' }) +
                    '</div>' +
                '</div>';

            window._calLastMonthSummary = Object.assign({}, stats, { monthLabel: monthLabel || '' });
            if (typeof applyUserPermissions === 'function') applyUserPermissions();
        }

        function openCalMonthStatDetail(sectionId) {
            if (!sectionId || typeof openDailyHistoryModal !== 'function') return;
            var y = calViewDate.getFullYear();
            var m0 = calViewDate.getMonth();
            var pad = function(n) { var s = String(n); return (s.length < 2) ? ('0' + s) : s; };
            var daysInMonth = new Date(y, m0 + 1, 0).getDate();
            var from = y + '-' + pad(m0 + 1) + '-01';
            var to = y + '-' + pad(m0 + 1) + '-' + pad(daysInMonth);
            var staffSelect = document.getElementById('cal-staff-filter');
            var selectedUser = staffSelect ? staffSelect.value : 'all';
            openDailyHistoryModal(from, {
                dateFrom: from,
                dateTo: to,
                force: true,
                user: selectedUser,
                detailSection: sectionId,
                detailOnly: true
            });
        }
        if (typeof window !== 'undefined') {
            window.openCalMonthStatDetail = openCalMonthStatDetail;
        }

        function computeLocalMonthFinancialMetrics(year, month) {
            var roundM = typeof roundMoney === 'function' ? roundMoney : function(x) { return Math.round(Number(x) || 0); };
            var pad = function(n) { var s = String(n); return (s.length < 2) ? ('0' + s) : s; };
            var daysInMonth = new Date(year, month + 1, 0).getDate();
            var monthStart = year + '-' + pad(month + 1) + '-01';
            var monthEnd = year + '-' + pad(month + 1) + '-' + pad(daysInMonth);
            var calSeeAllShop = currentUser && (currentUser.role === 'admin' || currentUser.role === 'manager');
            var expiryMap = buildExpiryAlertsMapFromCache();
            var agg = {
                sales: 0, sale_count: 0, expenses: 0, profit: 0, gifts_sum: 0, gifts_count: 0,
                wholesale_sum: 0, returns_total: 0, returns_count: 0,
                voided_sales_total: 0, voided_sales_count: 0,
                voided_purchases_total: 0, voided_purchases_count: 0,
                waste_total: 0, waste_count: 0,
                purchases_total: 0, purchase_count: 0,
                purchase_returns_total: 0, purchase_returns_cash: 0, purchase_returns_count: 0,
                purchases_cash: 0, debt_purchases: 0, purchases_fib: 0,
                customer_debt_in: 0, customer_debt_count: 0,
                company_debt_payments: 0, company_debt_count: 0,
                opening_balance: 0, cash_movement: 0, cash_drawer: 0,
                cash_sales: 0, debt_sales: 0, fib_sales: 0, cash_returns: 0,
                installment_count: 0, installment_total: 0, expiry_count: 0,
                delivery_total: 0, delivery_count: 0,
                delivery_pending: 0, delivery_pending_count: 0,
                delivery_delivered: 0, delivery_delivered_count: 0,
                delivery_refused: 0, delivery_refused_count: 0,
                delivery_cancelled: 0, delivery_cancelled_count: 0,
                delivery_hold: 0, delivery_hold_count: 0,
                // Locked raw USD (same as Daily Summary / getFinancialMetrics *Usd) — never live FX.
                sales_usd: 0, cash_sales_usd: 0, debt_sales_usd: 0, fib_sales_usd: 0,
                expenses_usd: 0, profit_usd: 0, gifts_usd: 0,
                returns_total_usd: 0, cash_returns_usd: 0, waste_total_usd: 0,
                purchases_total_usd: 0, purchases_cash_usd: 0, purchases_fib_usd: 0, debt_purchases_usd: 0,
                purchase_returns_total_usd: 0, purchase_returns_cash_usd: 0,
                customer_debt_in_usd: 0, company_debt_payments_usd: 0,
                cash_movement_usd: 0, cash_drawer_usd: 0, opening_balance_usd: 0
            };

            var productById = _calProductById(db.products);
            var roundU = function(x) {
                var n = Number(x);
                if (!Number.isFinite(n)) return 0;
                return Math.round(n * 100) / 100;
            };
            var staffSelectEl = document.getElementById('cal-staff-filter');
            var selectedUserMonth = staffSelectEl ? staffSelectEl.value : 'all';
            var buckets = _calBuildLocalMonthBuckets(year, month, monthStart, monthEnd, calSeeAllShop, selectedUserMonth);

            for (var d = 1; d <= daysInMonth; d++) {
                var dateStr = year + '-' + pad(month + 1) + '-' + pad(d);
                if (typeof getFinancialMetrics !== 'function') continue;
                var pools = _calDayPoolsFromBuckets(buckets, dateStr);
                var m = getFinancialMetrics(dateStr, { dayPools: pools });
                if (!m) continue;
                agg.sales = roundM(agg.sales + (m.totalSales || 0));
                agg.expenses = roundM(agg.expenses + (m.opExpenses || 0));
                agg.profit = roundM(agg.profit + (m.netProfit || 0));
                agg.waste_total = roundM(agg.waste_total + (m.wasteLoss || 0));
                agg.waste_count += parseInt(m.wasteCount, 10) || 0;
                agg.gifts_sum = roundM(agg.gifts_sum + (m.totalGiftsValue || 0));
                agg.gifts_count += parseInt(m.giftsCount, 10) || 0;
                agg.returns_total = roundM(agg.returns_total + (m.totalReturns || 0));
                agg.customer_debt_in = roundM(agg.customer_debt_in + (m.debtPaymentsIn || 0));
                agg.purchase_returns_total = roundM(agg.purchase_returns_total + (m.totalPurchaseReturns != null ? m.totalPurchaseReturns : (m.purchaseReturnsIn || 0)));
                agg.purchase_returns_cash = roundM(agg.purchase_returns_cash + (m.purchaseReturnsIn || 0));
                agg.purchases_cash = roundM(agg.purchases_cash + (m.cashPurchases || 0));
                agg.purchases_fib = roundM(agg.purchases_fib + (m.fibPurchases || 0));
                agg.cash_sales = roundM(agg.cash_sales + (m.cashSales || 0));
                agg.debt_sales = roundM(agg.debt_sales + (m.debtSales || 0));
                agg.fib_sales = roundM(agg.fib_sales + (m.fibSales || 0));
                agg.cash_returns = roundM(agg.cash_returns + (m.cashRefunds || 0));
                agg.company_debt_payments = roundM(agg.company_debt_payments + (m.companyDebtPayments || 0));
                agg.cash_movement = roundM(agg.cash_movement + (m.cashMovement || 0));
                // Locked USD — same fields Daily Summary uses (never re-divide IQD by live rate).
                agg.sales_usd = roundU(agg.sales_usd + (m.totalSalesUsd || 0));
                agg.cash_sales_usd = roundU(agg.cash_sales_usd + (m.cashSalesUsd || 0));
                agg.debt_sales_usd = roundU(agg.debt_sales_usd + (m.debtSalesUsd || 0));
                agg.fib_sales_usd = roundU(agg.fib_sales_usd + (m.fibSalesUsd || 0));
                agg.expenses_usd = roundU(agg.expenses_usd + (m.opExpensesUsd || 0));
                agg.profit_usd = roundU(agg.profit_usd + (m.netProfitUsd || 0));
                agg.gifts_usd = roundU(agg.gifts_usd + (m.totalGiftsValueUsd || 0));
                agg.returns_total_usd = roundU(agg.returns_total_usd + (m.totalReturnsUsd || 0));
                agg.cash_returns_usd = roundU(agg.cash_returns_usd + (m.cashRefundsUsd || 0));
                agg.waste_total_usd = roundU(agg.waste_total_usd + (m.wasteLossUsd || 0));
                agg.purchases_cash_usd = roundU(agg.purchases_cash_usd + (m.cashPurchasesUsd || 0));
                agg.purchases_fib_usd = roundU(agg.purchases_fib_usd + (m.fibPurchasesUsd || 0));
                agg.purchases_total_usd = roundU(agg.purchases_total_usd + (m.totalPurchasesUsd || 0));
                agg.purchase_returns_total_usd = roundU(agg.purchase_returns_total_usd + (m.totalPurchaseReturnsUsd || 0));
                agg.purchase_returns_cash_usd = roundU(agg.purchase_returns_cash_usd + (m.purchaseReturnsInUsd || 0));
                agg.customer_debt_in_usd = roundU(agg.customer_debt_in_usd + (m.debtPaymentsInUsd || 0));
                agg.company_debt_payments_usd = roundU(agg.company_debt_payments_usd + (m.companyDebtPaymentsUsd || 0));
                agg.cash_movement_usd = roundU(agg.cash_movement_usd + (m.cashMovementUsd || 0));
                agg.sale_count += (pools.sales || []).length;
                agg.returns_count += (pools.returns || []).length;
                agg.purchase_returns_count += (pools.purchase_returns || []).length;
                agg.customer_debt_count += (pools.customer_ledger || []).filter(function(cl) {
                    return (typeof isCustomerDebtPaymentRow === 'function') ? isCustomerDebtPaymentRow(cl) : (cl && (cl.type === 'payment' || cl.type === 'pay'));
                }).length;
                agg.company_debt_count += (pools.expenses || []).filter(function(e) {
                    return e && e.type === 'debt_payment' &&
                        !(typeof isPurchaseLinkedDebtPayment === 'function' && isPurchaseLinkedDebtPayment(e, db.expenses));
                }).length;

                var dayWh = 0;
                (pools.sales || []).forEach(function(s) {
                    if (!s.items) return;
                    s.items.forEach(function(i) {
                        var prod = productById.get(Number(i.id));
                        if (!prod) return;
                        var lineQ = typeof getItemQty === 'function' ? getItemQty(i) : 1;
                        var twPrice = 0;
                        if (i.saleUnit === 'carton' && prod.takeawayPrice_carton) twPrice = Number(prod.takeawayPrice_carton);
                        else if (i.saleUnit === 'pack' && prod.takeawayPrice_pack) twPrice = Number(prod.takeawayPrice_pack);
                        else if (prod.takeawayPrice) twPrice = Number(prod.takeawayPrice);
                        if (twPrice > 0 && Math.round(Number(i.price) || 0) === Math.round(twPrice)) {
                            dayWh += (parseFloat(i.price) || 0) * lineQ;
                        }
                    });
                });
                agg.wholesale_sum = roundM(agg.wholesale_sum + dayWh);

                var ir = getCalendarInstallmentSummaryForDate(dateStr);
                if (ir) {
                    agg.installment_count += ir.count || 0;
                    agg.installment_total = roundM(agg.installment_total + (ir.total || 0));
                }
                var er = getCalendarExpirySummaryForDate(dateStr, expiryMap);
                if (er) agg.expiry_count += er.count || 0;
            }

            var monthSupplies = typeof filterReportablePurchases === 'function'
                ? filterReportablePurchases(db.supplies || []).filter(function(s) {
                    var ds = getBusinessDate(parseSQLDate(s.date));
                    return ds >= monthStart && ds <= monthEnd;
                })
                : [];
            function monthSupplyToUsd(s, costIqd) {
                if (typeof storedIqdToUsdDisplayAmount === 'function') {
                    var u0 = storedIqdToUsdDisplayAmount(costIqd, s);
                    if (u0 > 0) return u0;
                }
                var pid = Number(s && (s.prodId != null ? s.prodId : s.product_id));
                var qty = Number(s && s.qtyAdded) || 0;
                var p = (pid > 0 && productById) ? productById.get(pid) : null;
                var unitUsd = p && p.cost_usd != null && p.cost_usd !== '' ? Number(p.cost_usd) : NaN;
                if (!(Number.isFinite(unitUsd) && unitUsd > 0) && p && String(p.base_currency || '').toUpperCase() === 'USD' && p.base_cost != null) {
                    unitUsd = Number(p.base_cost);
                }
                if (Number.isFinite(unitUsd) && unitUsd > 0 && qty > 0 && costIqd > 0) {
                    var rate = costIqd / (unitUsd * qty);
                    if (rate > 0) return roundU(costIqd / rate);
                }
                return 0;
            }
            if (typeof summarizePurchasesByInvoice === 'function') {
                var purSumm = summarizePurchasesByInvoice(monthSupplies);
                agg.purchase_count = purSumm.length;
                agg.purchases_total = roundM(purSumm.reduce(function(s, p) { return s + (parseFloat(p.total) || 0); }, 0));
            }
            var purchasesUsdFromSupplies = 0;
            monthSupplies.forEach(function(s) {
                var costIqd = parseFloat(s && s.totalCost) || 0;
                if (costIqd > 0) purchasesUsdFromSupplies = roundU(purchasesUsdFromSupplies + monthSupplyToUsd(s, costIqd));
            });
            if (purchasesUsdFromSupplies > 0) {
                agg.purchases_total_usd = purchasesUsdFromSupplies;
            }
            var seenPurTxnMonth = {};
            monthSupplies.forEach(function(s) {
                if (s && s.transaction_id) seenPurTxnMonth[String(s.transaction_id).trim()] = true;
            });
            (db.expenses || []).forEach(function(e) {
                if (!e || e.type !== 'purchase') return;
                var ds = getBusinessDate(parseSQLDate(e.date));
                if (ds < monthStart || ds > monthEnd) return;
                var txn = String(e.transaction_id || '').trim();
                if (txn && seenPurTxnMonth[txn]) return;
                if (txn) seenPurTxnMonth[txn] = true;
                var amt = (typeof expenseAmountIqd === 'function') ? expenseAmountIqd(e) : (parseFloat(e.amount) || 0);
                if (amt <= 0) return;
                agg.purchase_count += 1;
                agg.purchases_total = roundM(agg.purchases_total + amt);
                var uExp = (typeof expenseAmountUsd === 'function')
                    ? expenseAmountUsd(e)
                    : ((typeof storedIqdToUsdDisplayAmount === 'function') ? storedIqdToUsdDisplayAmount(amt, e) : 0);
                agg.purchases_total_usd = roundU(agg.purchases_total_usd + (uExp || 0));
            });
            (db.ledger || []).forEach(function(l) {
                if (!l) return;
                var typ = String(l.type || '').toLowerCase();
                if (typ !== 'purchase' && typ !== 'credit_purchase') return;
                var ds = getBusinessDate(parseSQLDate(l.date || l.created_at));
                if (ds < monthStart || ds > monthEnd) return;
                var txn = String(l.transaction_id || '').trim();
                if (txn && seenPurTxnMonth[txn]) return;
                if (txn) seenPurTxnMonth[txn] = true;
                var amt = parseFloat(l.amount) || 0;
                if (amt <= 0) return;
                agg.purchase_count += 1;
                agg.purchases_total = roundM(agg.purchases_total + amt);
                var uLed = (typeof storedIqdToUsdDisplayAmount === 'function') ? storedIqdToUsdDisplayAmount(amt, l) : 0;
                agg.purchases_total_usd = roundU(agg.purchases_total_usd + (uLed || 0));
            });
            agg.debt_purchases = roundM(Math.max(0, (agg.purchases_total || 0) - (agg.purchases_cash || 0) - (agg.purchases_fib || 0)));
            agg.debt_purchases_usd = roundU(Math.max(0, (agg.purchases_total_usd || 0) - (agg.purchases_cash_usd || 0) - (agg.purchases_fib_usd || 0)));

            if (db.shifts) {
                var openingSelfOnly = !!(currentUser && currentUser.role !== 'admin');
                var firstDayKey = null;
                var firstDayOpening = 0;
                db.shifts.forEach(function(sh) {
                    var st = parseSQLDate(sh.startTime);
                    if (!st) return;
                    var ds = getBusinessDate(st);
                    if (ds < monthStart || ds > monthEnd) return;
                    if (openingSelfOnly && currentUser && Number(sh.userId) !== Number(currentUser.id)) return;
                    if (firstDayKey === null || ds < firstDayKey) {
                        firstDayKey = ds;
                        firstDayOpening = 0;
                    }
                    if (ds === firstDayKey) {
                        firstDayOpening += parseFloat(sh.opening_balance) || 0;
                    }
                });
                agg.opening_balance = roundM(firstDayOpening);
            }
            agg.cash_drawer = roundM(agg.opening_balance + agg.cash_movement);
            // Opening float is today's cash — live rate OK; movement stays locked from daily *Usd sums.
            if (agg.opening_balance > 0 && typeof storedIqdToUsdDisplayAmount === 'function') {
                agg.opening_balance_usd = roundU(storedIqdToUsdDisplayAmount(agg.opening_balance, {
                    fxUsdRate: (typeof getUsdRatePerOne === 'function' ? Math.round(getUsdRatePerOne() * 100) : 0)
                }));
            } else {
                agg.opening_balance_usd = 0;
            }
            agg.cash_drawer_usd = roundU((agg.opening_balance_usd || 0) + (agg.cash_movement_usd || 0));
            agg.metrics_engine = 'getFinancialMetrics';

            var delMonth = summarizeDeliveriesForRange(monthStart, monthEnd);
            agg.delivery_total = delMonth.delivery_total;
            agg.delivery_count = delMonth.delivery_count;
            agg.delivery_pending = delMonth.delivery_pending;
            agg.delivery_pending_count = delMonth.delivery_pending_count;
            agg.delivery_delivered = delMonth.delivery_delivered;
            agg.delivery_delivered_count = delMonth.delivery_delivered_count;
            agg.delivery_refused = delMonth.delivery_refused;
            agg.delivery_refused_count = delMonth.delivery_refused_count;
            agg.delivery_cancelled = delMonth.delivery_cancelled;
            agg.delivery_cancelled_count = delMonth.delivery_cancelled_count;
            agg.delivery_hold = delMonth.delivery_hold;
            agg.delivery_hold_count = delMonth.delivery_hold_count;

            /** Voided sales (invoice delete) — local fallback when server month stats unavailable */
            var voidSalesPool = typeof getAllSales === 'function' ? getAllSales(true) : (db.sales || []);
            (voidSalesPool || []).forEach(function(s) {
                if (!s || !(s.is_returned == 1 || s.is_returned === true || s.is_returned === '1')) return;
                if (!calSeeAllShop && currentUser && s.cashier !== currentUser.name) return;
                var ds = getBusinessDate(parseSQLDate(s.date || s.created_at));
                if (!ds || ds < monthStart || ds > monthEnd) return;
                agg.voided_sales_count += 1;
                agg.voided_sales_total = roundM(agg.voided_sales_total + (parseFloat(s.total) || 0));
            });

            return agg;
        }

        function _renderWorkCalendarFromServerStats(srv) {
            if (!db || !srv || srv.status !== 'ok') {
                renderWorkCalendarLocal();
                return;
            }

            var year = srv.year || calViewDate.getFullYear();
            var month = srv.month ? (srv.month - 1) : calViewDate.getMonth();
            calViewDate = new Date(year, month, 1);

            document.getElementById('cal-month-title').innerText = formatCalendarMonthYearLabel(month, year);

            const firstDay = new Date(year, month, 1);
            const lastDay = new Date(year, month + 1, 0);
            const startPad = firstDay.getDay();
            const daysInMonth = lastDay.getDate();

            let gridHtml = getCalendarWeekdayHeaderHtml();

            const emptyCells = (startPad + 1) % 7;
            for (let i = 0; i < emptyCells; i++) gridHtml += `<div class="calendar-day-empty"></div>`;

            var _calSalesLbl = escapeHtml((typeof t === 'function') ? t('daily_summary_total_sales') : 'فرۆتن');
            var _calProfitLbl = escapeHtml((typeof t === 'function') ? t('daily_summary_net_profit') : 'قازانج');
            const wholesaleLabel = getCalendarWholesaleLabel();
            const dayMap = srv.days || {};
            const instDayMap = srv.installment_days || {};
            const expiryDayMap = srv.expiry_days || {};
            const mt = srv.month_totals || {};

            let monthOrders = mt.sale_count != null ? parseInt(mt.sale_count, 10) : 0;
            let monthTotal = mt.sales != null ? parseFloat(mt.sales) : NaN;
            let monthExpenses = mt.expenses != null ? parseFloat(mt.expenses) : NaN;
            let monthProfit = mt.profit != null ? parseFloat(mt.profit) : NaN;
            let monthGifts = mt.gifts_sum != null ? parseFloat(mt.gifts_sum) : NaN;
            let monthWholesale = mt.wholesale_sum != null ? parseFloat(mt.wholesale_sum) : NaN;

            if (!Number.isFinite(monthTotal)) monthTotal = 0;
            if (!Number.isFinite(monthExpenses)) monthExpenses = 0;
            if (!Number.isFinite(monthProfit)) monthProfit = 0;
            if (!Number.isFinite(monthGifts)) monthGifts = 0;
            if (!Number.isFinite(monthWholesale)) monthWholesale = 0;
            if (!Number.isFinite(monthOrders)) monthOrders = 0;

            let accOrders = 0;
            let accProfit = 0;

            const _pad2 = function(n) { var s = String(n); return (s.length < 2) ? ('0' + s) : s; };

            for (let d = 1; d <= daysInMonth; d++) {
                const dateStrKey = `${year}-${_pad2(month + 1)}-${_pad2(d)}`;
                const rec = dayMap[dateStrKey];

                let dayTotal = rec && rec.sales_total !== undefined ? parseFloat(rec.sales_total) : 0;
                let dayCount = rec && rec.sale_count !== undefined ? parseInt(rec.sale_count, 10) : 0;
                let dayExp = rec && rec.exp_total !== undefined ? parseFloat(rec.exp_total) : 0;
                let dayGifts = rec && rec.gifts !== undefined ? parseFloat(rec.gifts) : 0;
                let dayWholesale = rec && rec.wholesale !== undefined ? parseFloat(rec.wholesale) : 0;
                let dayReturns = rec && rec.returns_total !== undefined ? parseFloat(rec.returns_total) : 0;
                let dayWaste = rec && rec.waste_total !== undefined ? parseFloat(rec.waste_total) : 0;
                const dateStrBiz = typeof getBusinessDate === 'function' ? getBusinessDate(new Date(year, month, d, 12, 0, 0)) : dateStrKey;
                let fallbackProfit = (dayTotal - dayReturns) - ((rec && rec.cogs !== undefined ? parseFloat(rec.cogs) : 0) - (rec && rec.returns_cogs !== undefined ? parseFloat(rec.returns_cogs) : 0)) - dayExp - (Number.isFinite(dayWaste) ? dayWaste : 0);
                if (rec && rec.profit !== undefined && Number.isFinite(parseFloat(rec.profit))) {
                    fallbackProfit = parseFloat(rec.profit);
                }
                var dayMetricsSrv = calendarDayMetrics(dateStrBiz, fallbackProfit, { useServerProfit: true, returns: dayReturns });
                let dayProfit = dayMetricsSrv.profit;

                if (!Number.isFinite(dayTotal)) dayTotal = 0;
                if (!Number.isFinite(dayCount)) dayCount = 0;
                if (!Number.isFinite(dayExp)) dayExp = 0;
                if (!Number.isFinite(dayGifts)) dayGifts = 0;
                if (!Number.isFinite(dayWholesale)) dayWholesale = 0;
                if (!Number.isFinite(dayWaste)) dayWaste = 0;
                if (!Number.isFinite(dayProfit)) dayProfit = 0;

                accOrders += dayCount;
                accProfit += dayProfit;
                var daySalesUsd = (rec && rec.sales_usd != null && Number.isFinite(parseFloat(rec.sales_usd))) ? parseFloat(rec.sales_usd) : null;
                var dayProfitUsd = (rec && rec.profit_usd != null && Number.isFinite(parseFloat(rec.profit_usd))) ? parseFloat(rec.profit_usd) : null;
                var _fmtCal = function (iqd, usd) {
                    return (typeof formatReportAmount === 'function') ? formatReportAmount(iqd, usd) : formatCurrency(iqd);
                };

                const isTodayCell = typeof getBusinessDate === 'function' ? (dateStrBiz === getBusinessDate(new Date())) : false;

                const bg = isTodayCell ? 'linear-gradient(135deg, rgba(56, 189, 248, 0.15), rgba(59, 130, 246, 0.1))' : 'var(--card)';
                const border = isTodayCell ? '2px solid var(--brand)' : '1px solid var(--border)';
                const profitColor = dayProfit >= 0 ? 'var(--success)' : 'var(--danger)';
                const _showCalProfit = (typeof canViewProfit === 'function') ? canViewProfit() : true;

                /** کرتەکە دەبێت ئەو بەروارڕۆژی ڕۆژمێری نیشان دەدات بۆ هەماهەنگ بێت لەگەڵ مانگەوە (DATE لە سێرڤەر) — مەزاختن لەگەڵ کارتەکە دەگونجێت */
                const escKey = encodeURIComponent(dateStrKey);
                const instRec = getCalendarInstallmentSummaryForDate(dateStrKey, instDayMap);
                const instHtml = buildCalendarInstallmentHtml(instRec, dateStrKey);
                const hasInst = !!instRec;
                const expRec = getCalendarExpirySummaryForDate(dateStrKey, expiryDayMap);
                const expHtml = buildCalendarExpiryHtml(expRec, dateStrKey);
                const hasExp = !!expRec;
                const dayBorder = resolveCalendarDayBorder(border, instRec, expRec);

                var staffSelectStr = document.getElementById('cal-staff-filter') ? document.getElementById('cal-staff-filter').value : 'all';
                var _onClickSrv = `openDailyHistoryModal(decodeURIComponent('${escKey}'), { user: decodeURIComponent('${encodeURIComponent(staffSelectStr)}') })`;

                gridHtml += `
                <div class="calendar-day-card${isTodayCell ? ' is-today' : ''}${hasInst ? ' has-installment' : ''}${hasExp ? ' has-expiry' : ''}" onclick="${_onClickSrv}" style="cursor:pointer; background:${bg}; border:${dayBorder}; border-radius:12px; padding:8px; min-height:148px; display:flex; flex-direction:column;">
                    <div class="calendar-day-head" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:5px;">
                        <div class="calendar-day-num" style="font-weight:bold; font-size:1.1rem; color:var(--text);">${d}</div>
                        <div class="calendar-day-orders" style="font-size:0.7rem; background:var(--input-bg); padding:2px 6px; border-radius:6px;">${dayCount} <i class="fas fa-receipt"></i></div>
                    </div>
                    ${instHtml}
                    ${expHtml}
                    <div class="calendar-day-sale" style="font-size:0.85rem; color:var(--brand); font-weight:bold; margin-bottom:2px;">+ ${_fmtCal(dayTotal, daySalesUsd)} <span style="font-size:0.65rem;font-weight:600;opacity:0.75;">${_calSalesLbl}</span></div>
                    ${dayReturns > 0 ? `<div class="calendar-day-ret" style="font-size:0.75rem; color:#c084fc; margin-bottom:2px;">↩ ${formatCurrency(dayReturns)}</div>` : ''}
                    ${dayExp > 0 ? `<div class="calendar-day-exp" style="font-size:0.75rem; color:var(--danger);">- ${formatCurrency(dayExp)}</div>` : ''}
                    ${dayWaste > 0 ? `<div class="calendar-day-waste" style="font-size:0.75rem; color:#fb923c; margin-bottom:2px;"><i class="fas fa-recycle" style="font-size:0.65rem;"></i> ${formatCurrency(dayWaste)}</div>` : ''}
                    ${dayGifts > 0 ? `<div class="calendar-day-gift" style="font-size:0.75rem; color:#ec4899; margin-bottom:2px;">🎁 ${(typeof t === 'function') ? t('shop_ov_gifts') : 'دیاری'}: ${formatCurrency(dayGifts)}${(rec && rec.gifts_count) ? ' · ' + (parseFloat(rec.gifts_count) || 0) + '×' : ''}</div>` : ''}
                    ${dayWholesale > 0 ? `<div class="calendar-day-wholesale" style="font-size:0.7rem; color:var(--warning); margin-bottom:2px;">${escapeHtml(wholesaleLabel)}: ${formatCurrency(dayWholesale)}</div>` : ''}
                    
                    ${_showCalProfit ? `<div class="calendar-day-profit" data-needs="profit" style="font-size:0.8rem; color:${profitColor}; font-weight:bold; margin-top:auto; border-top:1px dashed var(--border); padding-top:4px;">
                        ${dayProfit >= 0 ? '↗' : '↘'} ${_fmtCal(dayProfit, dayProfitUsd)} <span style="font-size:0.65rem;font-weight:600;opacity:0.85;">${_calProfitLbl}</span>
                    </div>` : ''}
                </div>`;
            }

            if (accOrders !== monthOrders) monthOrders = accOrders;

            /** Prefer Σ(day profit) if server month profit missing/out of sync */
            if (!srv.month_totals || srv.month_totals.profit == null || !Number.isFinite(parseFloat(mt.profit))) {
                monthProfit = accProfit;
            }

            document.getElementById('work-calendar-grid').innerHTML = gridHtml;

            monthTotal = roundMoney(monthTotal);
            monthExpenses = roundMoney(monthExpenses);
            monthProfit = roundMoney(monthProfit);
            monthGifts = roundMoney(monthGifts);
            monthWholesale = roundMoney(monthWholesale);

            if (mt.delivery_count == null && mt.delivery_pending_count == null && typeof summarizeDeliveriesForRange === 'function') {
                var padDel = function(n) { var s = String(n); return (s.length < 2) ? ('0' + s) : s; };
                var daysInM = new Date(year, month + 1, 0).getDate();
                var locDel = summarizeDeliveriesForRange(year + '-' + padDel(month + 1) + '-01', year + '-' + padDel(month + 1) + '-' + padDel(daysInM));
                mt.delivery_total = locDel.delivery_total;
                mt.delivery_count = locDel.delivery_count;
                mt.delivery_pending = locDel.delivery_pending;
                mt.delivery_pending_count = locDel.delivery_pending_count;
                mt.delivery_delivered = locDel.delivery_delivered;
                mt.delivery_delivered_count = locDel.delivery_delivered_count;
                mt.delivery_refused = locDel.delivery_refused;
                mt.delivery_refused_count = locDel.delivery_refused_count;
                mt.delivery_cancelled = locDel.delivery_cancelled;
                mt.delivery_cancelled_count = locDel.delivery_cancelled_count;
                mt.delivery_hold = locDel.delivery_hold;
                mt.delivery_hold_count = locDel.delivery_hold_count;
            }

            // Prefer PHP pos_get_financial_metrics_core when present (locked *Usd). Else local JS engine.
            var localMonthFin = computeLocalMonthFinancialMetrics(year, month);
            var monthPanelStats = Object.assign({}, localMonthFin, mt);
            renderCalendarMonthSummaryPanel(monthPanelStats, formatCalendarMonthYearLabel(month, year));
        }

        /** Offline calendar (truncated lists — fallback only). */
        /** Uses current `calViewDate` — navigation happens only inside `renderWorkCalendar`. */
        function renderWorkCalendarLocal(silent) {
            var _db = (typeof db !== 'undefined' && db) ? db : (typeof window !== 'undefined' ? window.db : null);
            if (!_db) return;

            var year = calViewDate.getFullYear();
            var month = calViewDate.getMonth();
            var titleElLoc = document.getElementById('cal-month-title');
            if (titleElLoc) titleElLoc.innerText = formatCalendarMonthYearLabel(month, year);

            var staffSelect = document.getElementById('cal-staff-filter');
            var selectedUser = staffSelect ? staffSelect.value : 'all';

            var calSeeAllShop = currentUser && (currentUser.role === 'admin' || currentUser.role === 'manager');
            var padDl = function(n) { var s = String(n); return (s.length < 2) ? ('0' + s) : s; };
            var daysInMonth = new Date(year, month + 1, 0).getDate();
            var monthStart = year + '-' + padDl(month + 1) + '-01';
            var monthEnd = year + '-' + padDl(month + 1) + '-' + padDl(daysInMonth);
            var buckets = _calBuildLocalMonthBuckets(year, month, monthStart, monthEnd, calSeeAllShop, selectedUser);

            var firstDay = new Date(year, month, 1);
            var startPad = firstDay.getDay();

            var gridHtml = getCalendarWeekdayHeaderHtml();

            var emptyCellsLocal = (startPad + 1) % 7;
            for (var ii = 0; ii < emptyCellsLocal; ii++) gridHtml += `<div class="calendar-day-empty"></div>`;

            var monthTotalLoc = 0, monthOrdersLoc = 0, monthExpensesLoc = 0, monthProfitLoc = 0, monthGiftsLoc = 0, monthWholesaleLoc = 0;
            var monthInstCountLoc = 0, monthInstTotalLoc = 0, monthExpiryCountLoc = 0;
            var wholesaleLabel = getCalendarWholesaleLabel();
            var expiryCacheMap = buildExpiryAlertsMapFromCache();
            var _calSalesLblLoc = escapeHtml((typeof t === 'function') ? t('daily_summary_total_sales') : 'فرۆتن');
            var _calProfitLblLoc = escapeHtml((typeof t === 'function') ? t('daily_summary_net_profit') : 'قازانج');
            var productById = _calProductById((_db && _db.products) ? _db.products : []);
            var resolveCost = (typeof resolveSaleLineCost === 'function') ? resolveSaleLineCost : function(i) { return parseFloat(i && i.cost) || 0; };

            for (var d = 1; d <= daysInMonth; d++) {
                var dObj = new Date(year, month, d, 12, 0, 0);
                var dateStr = typeof getBusinessDate === 'function' ? getBusinessDate(dObj) : '';
                var daySales = buckets.salesByDate[dateStr] || [];

                var dayTotal = daySales.reduce(function(a, b) { return a + (parseFloat(b.total) || 0); }, 0);
                var dayCount = daySales.length;

                var dayExp = (buckets.expensesByDate[dateStr] || []).filter(function(e) {
                    return typeof isOperationalExpenseRow === 'function' ? isOperationalExpenseRow(e) : (!e || !e.type || e.type === 'operational');
                }).reduce(function(a, b) { return a + (parseFloat(b.amount) || 0); }, 0);

                var dayCOGS = 0;
                var dayWholesale = 0;
                var dayGifts = 0;
                var dayGiftCountLoc = 0;
                daySales.forEach(function(s) {
                    if (!s.items) return;
                    s.items.forEach(function(i) {
                        var lineQ = typeof getItemQty === 'function' ? getItemQty(i) : 1;
                        dayCOGS += resolveCost(i, productById) * lineQ;
                        if (i.isGift) {
                            dayGifts += (parseFloat(i.price) || 0) * lineQ;
                            dayGiftCountLoc += lineQ;
                        }

                        var prod = productById.get(Number(i.id));
                        if (prod) {
                            var twPrice = 0;
                            if (i.saleUnit === 'carton' && prod.takeawayPrice_carton) twPrice = Number(prod.takeawayPrice_carton);
                            else if (i.saleUnit === 'pack' && prod.takeawayPrice_pack) twPrice = Number(prod.takeawayPrice_pack);
                            else if (prod.takeawayPrice) twPrice = Number(prod.takeawayPrice);

                            if (twPrice > 0 && Math.round(Number(i.price) || 0) === Math.round(twPrice)) {
                                dayWholesale += (parseFloat(i.price) || 0) * lineQ;
                            }
                        }
                    });
                });
                var dayReturnsLoc = 0;
                var dayReturnsCogsLoc = 0;
                (buckets.returnsByDate[dateStr] || []).forEach(function(r) {
                    dayReturnsLoc += parseFloat(r.total) || 0;
                    if (r.items) r.items.forEach(function(i) {
                        var lineQ = typeof getItemQty === 'function' ? getItemQty(i) : 1;
                        dayReturnsCogsLoc += resolveCost(i, productById) * lineQ;
                    });
                });
                var dayWasteLoc = (buckets.ledgerByDate[dateStr] || []).filter(function(l) {
                    return l && l.type === 'waste';
                }).reduce(function(a, l) { return a + (parseFloat(l.amount) || 0); }, 0);
                var fallbackProfitLoc = (dayTotal - dayReturnsLoc) - (dayCOGS - dayReturnsCogsLoc) - dayExp - dayWasteLoc;
                var dayMetricsLoc = calendarDayMetrics(dateStr, fallbackProfitLoc, { useServerProfit: true, returns: dayReturnsLoc });
                var dayProfit = dayMetricsLoc.profit;
                var dayReturns = dayMetricsLoc.returns || dayReturnsLoc;

                monthTotalLoc += dayTotal;
                monthOrdersLoc += dayCount;
                monthExpensesLoc += dayExp;
                monthProfitLoc += dayProfit;
                monthGiftsLoc += dayGifts;
                monthWholesaleLoc += dayWholesale;

                var isTodayL = typeof getBusinessDate === 'function' && dateStr === getBusinessDate(new Date());
                var bgL = isTodayL ? 'linear-gradient(135deg, rgba(56, 189, 248, 0.15), rgba(59, 130, 246, 0.1))' : 'var(--card)';
                var borderL = isTodayL ? '2px solid var(--brand)' : '1px solid var(--border)';
                var profitColorL = dayProfit >= 0 ? 'var(--success)' : 'var(--danger)';
                var _showCalProfitLoc = (typeof canViewProfit === 'function') ? canViewProfit() : true;

                var dateCalKey = year + '-' + padDl(month + 1) + '-' + padDl(d);
                var escKl = encodeURIComponent(dateCalKey);
                var instRecL = getCalendarInstallmentSummaryForDate(dateCalKey);
                if (instRecL) {
                    monthInstCountLoc += instRecL.count || 0;
                    monthInstTotalLoc += instRecL.total || 0;
                }
                var instHtmlL = buildCalendarInstallmentHtml(instRecL, dateCalKey);
                var hasInstL = !!instRecL;
                var expRecL = getCalendarExpirySummaryForDate(dateCalKey, expiryCacheMap);
                if (expRecL) monthExpiryCountLoc += expRecL.count || 0;
                var expHtmlL = buildCalendarExpiryHtml(expRecL, dateCalKey);
                var hasExpL = !!expRecL;
                var borderDayL = resolveCalendarDayBorder(borderL, instRecL, expRecL);
                var _onClick = `openDailyHistoryModal(decodeURIComponent('${escKl}'), { user: decodeURIComponent('${encodeURIComponent(selectedUser)}') })`;
                gridHtml += `
                <div class="calendar-day-card${isTodayL ? ' is-today' : ''}${hasInstL ? ' has-installment' : ''}${hasExpL ? ' has-expiry' : ''}" onclick="${_onClick}" style="cursor:pointer; background:${bgL}; border:${borderDayL}; border-radius:12px; padding:8px; min-height:148px; display:flex; flex-direction:column;">
                    <div class="calendar-day-head" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:5px;">
                        <div class="calendar-day-num" style="font-weight:bold; font-size:1.1rem; color:var(--text);">${d}</div>
                        <div class="calendar-day-orders" style="font-size:0.7rem; background:var(--input-bg); padding:2px 6px; border-radius:6px;">${dayCount} <i class="fas fa-receipt"></i></div>
                    </div>
                    ${instHtmlL}
                    ${expHtmlL}
                    <div class="calendar-day-sale" style="font-size:0.85rem; color:var(--brand); font-weight:bold; margin-bottom:2px;">+ ${formatCurrency(dayTotal)} <span style="font-size:0.65rem;font-weight:600;opacity:0.75;">${_calSalesLblLoc}</span></div>
                    ${dayReturns > 0 ? `<div class="calendar-day-ret" style="font-size:0.75rem; color:#c084fc; margin-bottom:2px;">↩ ${formatCurrency(dayReturns)}</div>` : ''}
                    ${dayExp > 0 ? `<div class="calendar-day-exp" style="font-size:0.75rem; color:var(--danger);">- ${formatCurrency(dayExp)}</div>` : ''}
                    ${dayWasteLoc > 0 ? `<div class="calendar-day-waste" style="font-size:0.75rem; color:#fb923c; margin-bottom:2px;"><i class="fas fa-recycle" style="font-size:0.65rem;"></i> ${formatCurrency(dayWasteLoc)}</div>` : ''}
                    ${dayGifts > 0 ? `<div class="calendar-day-gift" style="font-size:0.75rem; color:#ec4899; margin-bottom:2px;">🎁 ${(typeof t === 'function') ? t('shop_ov_gifts') : 'دیاری'}: ${formatCurrency(dayGifts)}${dayGiftCountLoc > 0 ? ' · ' + dayGiftCountLoc + '×' : ''}</div>` : ''}
                    ${dayWholesale > 0 ? `<div class="calendar-day-wholesale" style="font-size:0.7rem; color:var(--warning); margin-bottom:2px;">${escapeHtml(wholesaleLabel)}: ${formatCurrency(dayWholesale)}</div>` : ''}

                    ${_showCalProfitLoc ? `<div class="calendar-day-profit" data-needs="profit" style="font-size:0.8rem; color:${profitColorL}; font-weight:bold; margin-top:auto; border-top:1px dashed var(--border); padding-top:4px;">
                        ${dayProfit >= 0 ? '↗' : '↘'} ${formatCurrency(dayProfit)} <span style="font-size:0.65rem;font-weight:600;opacity:0.85;">${_calProfitLblLoc}</span>
                    </div>` : ''}
                </div>`;
            }

            document.getElementById('work-calendar-grid').innerHTML = gridHtml;

            renderCalendarMonthSummaryPanel(computeLocalMonthFinancialMetrics(year, month), formatCalendarMonthYearLabel(month, year));

            if (!silent) {
                try { if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('cal_offline_toast') : 'ئاگادار: ڕۆژمێر لە بیرگەکان تەنێ دواوە تۆماران دە بینیت — گرێدان پێ وی سێرڤەر باش نەبوو.', 'warning'); } catch(te) {}
            }
        }

        function renderWorkCalendar(direction) {
            try {
                var _db = (typeof db !== 'undefined' && db) ? db : (typeof window !== 'undefined' ? window.db : null);
                if (!_db) {
                    // Still paint month label so UI never stays on "---"
                    try {
                        var _te0 = document.getElementById('cal-month-title');
                        var _now0 = new Date();
                        if (_te0) _te0.innerText = formatCalendarMonthYearLabel(_now0.getMonth(), _now0.getFullYear());
                    } catch (_eTitle0) {}
                    return;
                }
                if (window._calMonthCacheStale && typeof invalidateCalendarMonthCache === 'function') {
                    try { invalidateCalendarMonthCache(); } catch (_eSt) {}
                    window._calMonthCacheStale = false;
                }
                if (typeof fetchExpiryAlerts === 'function') {
                    var expiryStale = !window._expiryAlertsLoadedAt || (Date.now() - window._expiryAlertsLoadedAt > 300000);
                    if (expiryStale) {
                        setTimeout(function() { fetchExpiryAlerts(); }, 200);
                    }
                }
                if (typeof fetchSaleFollowups === 'function' && typeof isSaleFollowupEnabled === 'function' && isSaleFollowupEnabled()) {
                    var followStale = !window._saleFollowupLoadedAt || (Date.now() - window._saleFollowupLoadedAt > 300000);
                    if (followStale) {
                        setTimeout(function() { fetchSaleFollowups(); }, 400);
                    }
                }
                if (direction === -1) calViewDate.setMonth(calViewDate.getMonth() - 1);
                else if (direction === 1) calViewDate.setMonth(calViewDate.getMonth() + 1);
                else if (direction === 0) calViewDate = new Date(); // 0 is today, undefined is refresh

                if (!(calViewDate instanceof Date) || isNaN(calViewDate.getTime())) {
                    calViewDate = new Date();
                }

                var staffSelect = document.getElementById('cal-staff-filter');
                if (staffSelect && staffSelect.options.length <= 1 && _db.users && Array.isArray(_db.users)) {
                    _db.users.forEach(function(u) {
                        if (!u || u.name == null) return;
                        var opt = document.createElement('option');
                        opt.value = u.name;
                        opt.textContent = u.name;
                        staffSelect.appendChild(opt);
                    });
                }
                var selectedUser = staffSelect ? staffSelect.value : 'all';

                var y = calViewDate.getFullYear();
                var m0 = calViewDate.getMonth();
                var m1 = m0 + 1;
                var titleEl = document.getElementById('cal-month-title');
                if (titleEl) titleEl.innerText = formatCalendarMonthYearLabel(m0, y);
                try { closeCalMonthPicker(); } catch (_eClose) {}

                var cacheKey = _calMonthCacheKey(y, m1, selectedUser);
                var cached = calMonthStatsCache[cacheKey];
                if (cached && cached.status === 'ok') {
                    _renderWorkCalendarFromServerStats(cached);
                    // If cached and cache is still fresh (< 30s), avoid duplicate network re-fetch unless forced
                    if (!window._calMonthForceFetch && cached._fetchedAt && (Date.now() - cached._fetchedAt < 30000)) {
                        return;
                    }
                } else {
                    // Paint local days immediately — never leave an empty grid waiting on network
                    renderWorkCalendarLocal(true);
                }

                if (window._calMonthInflightKey === cacheKey && calMonthFetchCtrl) {
                    // Same month/user fetch already in flight, let it complete
                    return;
                }

                if (calMonthFetchCtrl) {
                    try { calMonthFetchCtrl.abort(); } catch (abortErr) {}
                }
                calMonthFetchCtrl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
                window._calMonthInflightKey = cacheKey;
                var fetchOpts = { credentials: 'same-origin' };
                if (calMonthFetchCtrl) fetchOpts.signal = calMonthFetchCtrl.signal;

                var qs = 'action=get_calendar_month_stats&year=' + encodeURIComponent(y) + '&month=' + encodeURIComponent(m1) + '&user=' + encodeURIComponent(selectedUser);
                var fetchUrl = (typeof window.posRouterUrl === 'function') ? window.posRouterUrl(qs) : ('?' + qs);

                fetch(fetchUrl, fetchOpts)
                    .then(function(r) { return r.json().catch(function() { return { status: 'error' }; }); })
                    .then(function(srv) {
                        window._calMonthInflightKey = null;
                        if (!srv || srv.status === 'auth_required') {
                            return;
                        }
                        if (srv.status === 'ok') {
                            srv._fetchedAt = Date.now();
                            calMonthStatsCache[cacheKey] = srv;
                            // Only update UI if we are still looking at the same month/user
                            var curY = calViewDate.getFullYear();
                            var curM = calViewDate.getMonth() + 1;
                            var staffSel = document.getElementById('cal-staff-filter');
                            var curUser = staffSel ? staffSel.value : 'all';
                            if (curY === y && curM === m1 && curUser === selectedUser) {
                                _renderWorkCalendarFromServerStats(srv);
                            }
                        }
                    })
                    .catch(function(err) {
                        window._calMonthInflightKey = null;
                        if (err && err.name === 'AbortError') return;
                        // Local grid already painted above
                    });
            } catch (errCal) {
                try {
                    if (typeof console !== 'undefined' && console.warn) console.warn('renderWorkCalendar', errCal);
                } catch (_eLog) {}
                try { renderWorkCalendarLocal(false); } catch (_eLoc) {}
            }
        }
        // Expose for nav/onclick (direct assign — wrappers recurse on the global binding)
        window.renderWorkCalendar = renderWorkCalendar;
        function getCurrentShift() {
            if (!db || !db.shifts || !currentUser) return null;
            const userId = Number(currentUser.id);
            let userShifts = db.shifts.filter(function (s) { return Number(s.userId) === userId; });
            if (userShifts.length === 0) return null;
            let active = userShifts.find(function (s) { return !s.endTime; });
            if (active) return active;
            userShifts.sort(function (a, b) { return new Date(b.startTime) - new Date(a.startTime); });
            return userShifts[0];
        }

        /** Financial metrics scoped to shift start → now (not whole shop day). */
        function getShiftFinancialMetrics(shift) {
            if (!shift || !shift.startTime || !db || typeof getFinancialMetrics !== 'function') return null;
            var startDt = parseSQLDate(shift.startTime);
            var endDt = shift.endTime ? parseSQLDate(shift.endTime) : new Date();
            if (!startDt || isNaN(startDt.getTime())) return null;
            if (!endDt || isNaN(endDt.getTime())) endDt = new Date();
            var startMs = startDt.getTime();
            var endMs = endDt.getTime();
            function inShiftRange(d) {
                if (!d || isNaN(d.getTime())) return false;
                var t = d.getTime();
                return t >= startMs && t <= endMs;
            }
            var salesPool = (typeof getReportSales === 'function') ? getReportSales() : (typeof getAllSales === 'function' ? getAllSales() : []);
            var sales = salesPool.filter(function (s) {
                return inShiftRange(parseSQLDate(s.date || s.created_at)) && !s.is_returned;
            });
            var expenses = (db.expenses || []).filter(function (e) {
                return inShiftRange(parseSQLDate(e.date));
            });
            var returns = (db.returns || []).filter(function (r) {
                return inShiftRange(parseSQLDate(r.date));
            });
            var purchase_returns = (db.purchase_returns || []).filter(function (pr) {
                return inShiftRange(parseSQLDate(pr.date));
            });
            var ledger = (db.ledger || []).filter(function (l) {
                return inShiftRange(parseSQLDate(l.date || l.created_at));
            });
            var customer_ledger = (db.customer_ledger || []).filter(function (cl) {
                return inShiftRange(parseSQLDate(cl.date || cl.created_at));
            });
            return getFinancialMetrics(null, {
                dayPools: { sales: sales, expenses: expenses, returns: returns, purchase_returns: purchase_returns, ledger: ledger, customer_ledger: customer_ledger }
            });
        }
        window.getShiftFinancialMetrics = getShiftFinancialMetrics;

        function renderShiftSummary() {
            const box = document.getElementById('shift-summary-box');
            if (!box) return;
            const userEl = document.getElementById('shift-summary-user');
            const timeEl = document.getElementById('shift-summary-time');
            const openEl = document.getElementById('shift-opening');
            const cashEl = document.getElementById('shift-cash-sales');
            const expEl = document.getElementById('shift-expenses');
            const expcEl = document.getElementById('shift-expected');
            var sym = typeof getCurrencySymbol === 'function' ? getCurrencySymbol() : '';
            var setZeros = function (msg) {
                if (userEl && msg) userEl.innerText = msg;
                if (timeEl && msg) timeEl.innerText = '';
                if (openEl) openEl.innerText = '0';
                if (cashEl) cashEl.innerText = '0';
                if (expEl) expEl.innerText = '0';
                if (expcEl) expcEl.innerText = '0';
            };
            if (!currentUser) {
                setZeros('چ بەکارهێنەر نەهاتینە تومارکرن');
                return;
            }
            const shift = getCurrentShift();
            if (!shift) {
                if (userEl) userEl.innerText = currentUser.name + ' (' + currentUser.role + ')';
                if (timeEl) timeEl.innerText = 'چ شیفتێن چالاک نینن — دەستپێکردنی شیفت پێویستە.';
                setZeros('');
                return;
            }
            const start = parseSQLDate(shift.startTime);
            const end = shift.endTime ? parseSQLDate(shift.endTime) : new Date();
            const metrics = getShiftFinancialMetrics(shift);
            const opening = parseFloat(shift.opening_balance || 0) || 0;
            var expected = opening;
            if (typeof posComputeShiftExpectedFromLocal === 'function') {
                var loc = posComputeShiftExpectedFromLocal(shift);
                if (loc && loc.status === 'ok') expected = parseFloat(loc.expected) || opening;
            } else if (metrics) {
                expected = opening + (metrics.cashMovement || 0);
            }

            if (userEl) userEl.innerText = currentUser.name + ' (' + currentUser.role + ')';
            if (timeEl) {
                const durHrs = ((end - start) / (1000 * 60 * 60)) || 0;
                timeEl.innerText = start.toLocaleTimeString('ku-IQ') + ' → ' + (shift.endTime ? end.toLocaleTimeString('ku-IQ') : 'نوکە') + ' • ' + durHrs.toFixed(1) + 'h';
            }
            if (openEl) openEl.innerText = formatCurrency(opening) + ' ' + sym;
            if (cashEl) cashEl.innerText = formatCurrency(metrics ? metrics.cashSales : 0) + ' ' + sym;
            if (expEl) {
                var expTot = metrics ? (metrics.opExpenses + metrics.cashPurchases + metrics.companyDebtPayments) : 0;
                expEl.innerText = formatCurrency(expTot) + ' ' + sym;
            }
            if (expcEl) expcEl.innerText = formatCurrency(expected) + ' ' + sym;
        }
        window.renderShiftSummary = renderShiftSummary;

        function getPurchaseReturnLabel(pr) {
            if (!pr) return '—';
            var nm = pr.company_name != null ? String(pr.company_name).trim() : '';
            if (nm) return nm;
            var cid = Number(pr.company_id || 0);
            if (cid && db && db.companies) {
                var comp = db.companies.find(function(c) { return Number(c.id) === cid; });
                if (comp && comp.name) return String(comp.name);
            }
            return cid ? ('#' + cid) : '—';
        }

        function parseCustomerDebtPaymentMeta(cl) {
            if (!cl) return { name: '—', receipt: '', user: '' };
            var receipt = (cl.receipt_id != null && String(cl.receipt_id).trim() !== '') ? String(cl.receipt_id).trim() : '';
            var name = (cl.target_name != null && String(cl.target_name).trim() !== '') ? String(cl.target_name).trim() : '';
            var user = '';
            var note = cl.note != null ? String(cl.note).trim() : '';
            var genericNote = /^(وەرگرتنا پارەی|دانەڤا قەرزی|payment receipt)/i;

            if (note) {
                note.split('|').forEach(function(seg) {
                    seg = String(seg || '').trim();
                    if (!seg) return;
                    if (seg.indexOf('ناڤ:') >= 0) {
                        var nm = seg.replace(/^.*ناڤ:\s*/, '').trim();
                        if (nm) name = nm;
                    } else if (/^receipt#/i.test(seg)) {
                        if (!receipt) receipt = seg.replace(/^receipt#\s*/i, '').trim();
                    } else if (/^by:\s*/i.test(seg)) {
                        user = seg.replace(/^by:\s*/i, '').trim();
                    } else if (!name && !genericNote.test(seg)) {
                        var isl = seg.match(/ئیسڵەق\s*#?\s*(\S+)/i);
                        if (isl && !receipt) receipt = isl[1];
                        var stripped = seg.replace(/وەرگرتنا پارەی\s*-?\s*ئیسڵەق\s*#?\s*\S*/gi, '').trim();
                        if (stripped && stripped.length < 80) name = stripped;
                    }
                });
                if (!receipt) {
                    var mIsl = note.match(/ئیسڵەق\s*#?\s*([^\s|]+)/i);
                    if (mIsl) receipt = mIsl[1].trim();
                    var mRc = note.match(/\|\s*receipt#([^|]+)/i);
                    if (mRc) receipt = mRc[1].trim();
                }
            }

            if (!name) {
                var tid = Number(cl.target_id || 0);
                var tt = String(cl.target_type || 'customer');
                if (tid && db) {
                    var pool = tt === 'user' ? (db.users || []) : (db.customers || []);
                    var ent = pool.find(function(x) { return Number(x.id) === tid; });
                    if (ent) {
                        name = String(ent.name || ent.username || '').trim();
                        if (tt === 'user' && name) name = 'کارمەند: ' + name;
                    }
                }
                if (!name && tid) name = '#' + tid;
            }
            if (!name) name = '—';
            return { name: name, receipt: receipt, user: user };
        }

        function getCustomerDebtPaymentLabel(cl) {
            return parseCustomerDebtPaymentMeta(cl).name;
        }

        function formatCustomerDebtPaymentRowHtml(cl, clTime) {
            var meta = parseCustomerDebtPaymentMeta(cl);
            var subParts = [];
            var _locD = (typeof _d === 'function') ? _d : function(k, fb) {
                if (typeof t === 'function') { var v = t(k); if (v && v !== k) return v; }
                return fb || k;
            };
            if (meta.receipt) {
                subParts.push(escapeHtml(_locD('daily_summary_customer_debt_receipt', 'وەسڵ')) + ' #' + escapeHtml(meta.receipt));
            }
            if (clTime) subParts.push(escapeHtml(clTime));
            var ch = (typeof customerDebtPaymentChannel === 'function') ? customerDebtPaymentChannel(cl) : 'cash';
            subParts.push(ch === 'fib' ? 'FIB' : escapeHtml(_locD('payment_method_cash', 'نقد')));
            var subHtml = subParts.length
                ? '<div style="font-size:0.78rem;color:var(--text-muted);margin-top:2px;">' + subParts.join(' · ') + '</div>'
                : '';
            var amtColor = ch === 'fib' ? '#2563eb' : '#22c55e';
            return '<div style="display:flex; justify-content:space-between; align-items:flex-start; padding:5px; border-bottom:1px solid var(--border); font-size:0.9rem;">' +
                '<div><strong style="color:' + amtColor + ';">' + escapeHtml(meta.name) + '</strong>' + subHtml + '</div>' +
                '<span style="color:' + amtColor + '; font-weight:bold; white-space:nowrap;">+' + formatCurrency(cl.amount) + '</span></div>';
        }

        /** Voided invoices (daily-summary refund) are not in `returns` table — merge for display only (not metrics). */
        function mergeVoidedSalesIntoDailyReturns(returnsArr, targetDateISO, voidedSalesArr, dateToISO) {
            var base = Array.isArray(returnsArr) ? returnsArr.slice() : [];
            var voidPool = Array.isArray(voidedSalesArr) ? voidedSalesArr.slice() : [];
            var fromIso = targetDateISO;
            var toIso = dateToISO || targetDateISO;
            // Light local only — NEVER getAllSales(true) (freezes large shops / blank daily modal)
            try {
                if (typeof collectLocalVoidedSalesRows === 'function') {
                    collectLocalVoidedSalesRows(fromIso, toIso).forEach(function(s) {
                        if (s) voidPool.push(s);
                    });
                } else if (typeof db !== 'undefined' && db && Array.isArray(db.sales)) {
                    var sales = db.sales;
                    var maxScan = 1200;
                    var start = Math.max(0, sales.length - maxScan);
                    for (var i = start; i < sales.length; i++) {
                        var s = sales[i];
                        if (!s || !(s.is_returned == 1 || s.is_returned === true || s.is_returned === '1')) continue;
                        var d = getBusinessDate(parseSQLDate(s.date || s.created_at));
                        if (d >= fromIso && d <= toIso) voidPool.push(s);
                    }
                }
            } catch (_eLoc) {}
            if (currentUser && currentUser.role !== 'admin' && currentUser.role !== 'manager') {
                voidPool = voidPool.filter(function(s) {
                    return currentUser ? (s.cashier === currentUser.name) : true;
                });
            }
            var seenSaleIds = {};
            base.forEach(function(r) {
                if (r && r.sale_id != null && r.sale_id !== '') seenSaleIds[String(r.sale_id)] = true;
                if (r && r.type === 'void' && r.id != null) seenSaleIds[String(r.id)] = true;
            });
            voidPool.forEach(function(s) {
                if (!s || seenSaleIds[String(s.id)]) return;
                seenSaleIds[String(s.id)] = true;
                base.push({
                    id: s.id,
                    date: s.date || s.created_at,
                    items: s.items,
                    total: s.total,
                    note: 'ژێبرنا وەسڵێ (Void)',
                    cashier: s.cashier,
                    type: 'void',
                    payment_method: s.payment_method === 'debt' ? 'debt' : 'cash',
                    sale_id: s.id
                });
            });
            return base;
        }

        /** Collapse same product/unit/price lines → one row with summed qty (e.g. ×100 not 100× name). */
        function posShouldShowDailySaleWarehouse() {
            if (typeof isMultiWarehouseProEnabled === 'function' && isMultiWarehouseProEnabled()) return true;
            var list = (typeof db !== 'undefined' && db && Array.isArray(db.warehouses)) ? db.warehouses : [];
            return list.length > 1;
        }
        function posDailySaleItemWarehouseName(it, s) {
            var name = String((it && it.warehouse_name) || (s && s.warehouse_name) || '').trim();
            if (name) return name;
            var id = parseInt((it && it.warehouse_id) || (s && s.warehouse_id) || 0, 10) || 0;
            if (id <= 0 || typeof db === 'undefined' || !db || !Array.isArray(db.warehouses)) return '';
            var w = db.warehouses.find(function(x) { return x && parseInt(x.id, 10) === id; });
            return w ? String(w.name || '').trim() : '';
        }
        function groupDailySummarySaleLines(rawItems) {
            var items = rawItems;
            if (typeof items === 'string') {
                try { items = JSON.parse(items); } catch (_e) { items = []; }
            }
            if (items && typeof items === 'object' && !Array.isArray(items)) {
                items = Object.keys(items).map(function(k) { return items[k]; });
            }
            if (!Array.isArray(items) || !items.length) return [];
            var getQty = (typeof getItemQty === 'function')
                ? getItemQty
                : (typeof window.getSaleLineQty === 'function'
                    ? window.getSaleLineQty
                    : function(i) {
                        var q = parseFloat(i && (i.qty != null ? i.qty : i.count));
                        return (!isNaN(q) && q > 0) ? q : 1;
                    });
            var grouped = {};
            var order = [];
            items.forEach(function(i) {
                if (!i || typeof i !== 'object') return;
                var nm = (i.name != null ? i.name : i.title) ? String(i.name != null ? i.name : i.title) : 'ئایتم';
                var unit = i.saleUnit || 'piece';
                var price = Number(i.price) || 0;
                var gift = i.isGift ? '1' : '0';
                var note = String(i.note || '');
                var idPart = (i.id != null && i.id !== '') ? String(i.id) : ('n:' + nm);
                var whId = parseInt(i.warehouse_id, 10) || 0;
                var key = idPart + '|' + unit + '|' + price + '|' + gift + '|' + note + '|w:' + whId;
                var q = getQty(i);
                var lineTotal = (i.sub != null) ? (parseFloat(i.sub) || 0) : (price * q);
                var lineCost = Number(i.cost);
                if (!Number.isFinite(lineCost) || lineCost < 0) lineCost = 0;
                if (!grouped[key]) {
                    grouped[key] = {
                        id: i.id,
                        name: nm,
                        price: price,
                        saleUnit: unit,
                        isGift: !!i.isGift,
                        note: note,
                        warehouse_id: whId,
                        warehouse_name: String(i.warehouse_name || ''),
                        count: 0,
                        sub: 0,
                        cost: 0,
                        _costTotal: 0
                    };
                    order.push(key);
                }
                grouped[key].count += q;
                grouped[key].sub += (i.isGift ? 0 : lineTotal);
                grouped[key]._costTotal += (Number.isFinite(lineCost) ? lineCost : 0) * q;
            });
            return order.map(function(k) {
                var g = grouped[k];
                if (g.count > 0) {
                    g.cost = g._costTotal / g.count;
                }
                delete g._costTotal;
                return g;
            });
        }

        function formatDailyReturnItemsSummary(row) {
            var grouped = groupDailySummarySaleLines(row && row.items);
            if (!grouped.length) return '';
            return grouped.map(function(g) {
                var qShow = (typeof formatQtyForDisplay === 'function') ? formatQtyForDisplay(g.count, g) : String(g.count);
                return (g.name || 'ئایتم') + ' ×' + qShow;
            }).slice(0, 5).join('، ') + (grouped.length > 5 ? '…' : '');
        }

        function splitDailyReturnsAndVoids(list) {
            var all = Array.isArray(list) ? list : [];
            var real = [];
            var voids = [];
            all.forEach(function(r) {
                if (!r) return;
                if (r.type === 'void' || String(r.note || '').indexOf('Deleted Invoice') !== -1 || String(r.note || '').indexOf('ژێبرنا وەسڵ') !== -1) {
                    voids.push(r);
                } else {
                    real.push(r);
                }
            });
            return { returns: real, voids: voids };
        }

        function closeDailySummaryDetailSheet(opts) {
            opts = opts || {};
            var sheet = document.getElementById('daily-sum-detail-sheet');
            var body = document.getElementById('daily-sum-detail-sheet-body');
            var shell = document.querySelector('#daily-history-modal .hist-shell');
            if (shell) shell.classList.remove('is-detail-open');
            if (sheet) sheet.style.display = 'none';
            if (body) body.innerHTML = '';
            var wasDetailOnly = !!window._dailySummaryDetailOnly;
            if (!opts.keepFlags) {
                window._dailySummaryPendingSheet = null;
            }
            if (!opts.keepModal && wasDetailOnly) {
                window._dailySummaryDetailOnly = false;
                var modal = document.getElementById('daily-history-modal');
                if (modal) modal.style.display = 'none';
            } else if (!opts.keepFlags) {
                window._dailySummaryDetailOnly = false;
            }
        }

        function openDailySummaryDetailSheet(sectionId) {
            if (!sectionId) return;
            var src = document.getElementById(sectionId);
            if (!src) return;
            var sheet = document.getElementById('daily-sum-detail-sheet');
            var body = document.getElementById('daily-sum-detail-sheet-body');
            var titleEl = document.getElementById('daily-sum-detail-sheet-title');
            var shell = document.querySelector('#daily-history-modal .hist-shell');
            if (!sheet || !body) return;

            // Purchases section still empty while totals exist → force server refresh then reopen (once)
            if (sectionId === 'daily-sec-purchases') {
                var emptyMsg = src.querySelector('.daily-sum-empty');
                var hasCards = src.querySelectorAll('.daily-sum-purchase-card, .daily-sum-sale-card').length > 0;
                if (emptyMsg && !hasCards && !window._dailyPurchaseSheetRefreshing && !window._dailyPurchaseSheetTried) {
                    var dateFrom = window._dailyDetailLastFrom
                        || (document.getElementById('date-start-daily') && document.getElementById('date-start-daily').value)
                        || ((typeof getBusinessDate === 'function') ? getBusinessDate(new Date()) : '');
                    var dateTo = window._dailyDetailLastTo || dateFrom;
                    var uid = (typeof currentUser !== 'undefined' && currentUser) ? currentUser.id : null;
                    if (dateFrom && typeof fetchDailyDetailForModal === 'function') {
                        window._dailyPurchaseSheetRefreshing = true;
                        window._dailyPurchaseSheetTried = true;
                        body.innerHTML = '<div style="text-align:center;padding:28px;color:var(--text-muted);"><i class="fas fa-spinner fa-spin" style="font-size:1.4rem;"></i></div>';
                        sheet.style.display = 'flex';
                        if (shell) shell.classList.add('is-detail-open');
                        fetchDailyDetailForModal(dateFrom, uid, {
                            force: true,
                            user: window._dailyDetailLastUser || 'all',
                            dateTo: dateTo,
                            lite: true
                        }).then(function(dd) {
                            window._dailyPurchaseSheetRefreshing = false;
                            if (dd && dd.status === 'ok' && typeof applyDailyDetailFromServer === 'function') {
                                try {
                                    applyDailyDetailFromServer(dd, dateFrom, dateFrom, {
                                        dateFrom: dateFrom,
                                        dateTo: dateTo,
                                        user: window._dailyDetailLastUser || 'all'
                                    });
                                } catch (_eApplyPur) {}
                            }
                            openDailySummaryDetailSheet('daily-sec-purchases');
                        }).catch(function() {
                            window._dailyPurchaseSheetRefreshing = false;
                            openDailySummaryDetailSheet('daily-sec-purchases');
                        });
                        return;
                    }
                }
            }

            var titleText = '';
            var h4 = src.querySelector('h4');
            if (h4) titleText = (h4.textContent || '').trim();
            if (!titleText) {
                titleText = (typeof t === 'function') ? t('daily_summary_detail_title') : 'وردەکاری';
            }
            if (titleEl) {
                titleEl.innerHTML = '<i class="fas fa-list-ul"></i> ' + escapeHtml(titleText);
            }

            var clone = src.cloneNode(true);
            clone.id = sectionId + '-sheet';
            clone.classList.add('daily-sum-detail-clone');
            clone.style.margin = '0';
            clone.style.maxHeight = 'none';
            clone.style.scrollMarginTop = '0';
            body.innerHTML = '';
            body.appendChild(clone);
            if (shell) shell.classList.add('is-detail-open');
            sheet.style.display = 'flex';
            if (typeof applyUserPermissions === 'function') applyUserPermissions();
            try {
                body.scrollTop = 0;
            } catch (_e) {}
        }

        function scrollToDailySummarySection(sectionId) {
            openDailySummaryDetailSheet(sectionId);
        }
        function dailySummaryEditSale(saleId) {
            saleId = parseInt(saleId, 10);
            if (!saleId) return;
            if (typeof closeDailySummaryDetailSheet === 'function') closeDailySummaryDetailSheet();
            if (typeof closeDailyHistoryModal === 'function') closeDailyHistoryModal();
            else {
                var dhm = document.getElementById('daily-history-modal');
                if (dhm) dhm.style.display = 'none';
            }
            if (typeof startEditSaleInPos === 'function') startEditSaleInPos(saleId);
        }
        if (typeof window !== 'undefined') {
            window.scrollToDailySummarySection = scrollToDailySummarySection;
            window.openDailySummaryDetailSheet = openDailySummaryDetailSheet;
            window.closeDailySummaryDetailSheet = closeDailySummaryDetailSheet;
            window.dailySummaryEditSale = dailySummaryEditSale;
            window.dailySummaryEditPurchase = dailySummaryEditPurchase;
            window.dailySummaryReturnPurchase = dailySummaryReturnPurchase;
            window.dailySummaryPrintPurchase = dailySummaryPrintPurchase;
            window.dailySummaryVoidPurchase = dailySummaryVoidPurchase;
        }

        /** Supplies invoices + cash purchase expenses not linked to a supply row (same day). */
        function buildDailyPurchaseDisplay(dayPurchasesRaw, dayExpensesList, dayLedgerList) {
            var roundM = typeof roundMoney === 'function' ? roundMoney : function(x) { return Math.round(Number(x) || 0); };
            var map = {};
            var lines = [];
            (dayPurchasesRaw || []).forEach(function(row) {
                if (!row) return;
                lines.push(row);
                var inv = (typeof formatPurchaseInvoiceLabel === 'function')
                    ? formatPurchaseInvoiceLabel(row)
                    : (row.supplier_invoice_number || row.transaction_id || '—');
                var txn = String(row.transaction_id || '').trim();
                var key = txn
                    ? ('txn:' + txn)
                    : ('fb:' + String(row.company || '') + '|' + inv + '|' + (typeof getBusinessDate === 'function' ? getBusinessDate(parseSQLDate(row.date)) : String(row.date || '')));
                if (!map[key]) {
                    map[key] = {
                        company: row.company || ((typeof t === 'function') ? t('daily_summary_unknown_company') : 'نەزانراو'),
                        invoice: inv,
                        total: 0,
                        txnId: txn,
                        type: row.type || 'cash',
                        date: row.date || '',
                        items: []
                    };
                }
                map[key].total += parseFloat(row.totalCost) || 0;
                if (!map[key].txnId && txn) map[key].txnId = txn;
                if (row.type) map[key].type = row.type;
                map[key].items.push({
                    name: row.itemName || row.name || 'ئایتم',
                    qty: parseFloat(row.qtyAdded) || 0,
                    totalCost: parseFloat(row.totalCost) || 0
                });
            });
            var seenTxn = {};
            Object.keys(map).forEach(function(k) {
                if (map[k].txnId) seenTxn[String(map[k].txnId)] = true;
            });
            (dayExpensesList || []).forEach(function(e) {
                if (!e || e.type !== 'purchase') return;
                var txn = String(e.transaction_id || '').trim();
                if (txn && seenTxn[txn]) return;
                if (txn) seenTxn[txn] = true;
                var amt = (typeof expenseAmountIqd === 'function') ? expenseAmountIqd(e) : (parseFloat(e.amount) || 0);
                if (amt <= 0) return;
                var note = String(e.note || '').trim();
                map['exp:' + (txn || ('e' + (e.id || Math.random())))] = {
                    company: (typeof t === 'function') ? t('daily_summary_cash_purchase_row') : 'کڕینا نەقد',
                    invoice: note ? note.slice(0, 56) : (txn ? ('#' + txn.slice(-8)) : '—'),
                    total: roundM(amt),
                    txnId: txn,
                    type: 'cash',
                    date: e.date || '',
                    items: [],
                    expenseOnly: true
                };
            });
            // Fallback: ledger purchase / credit_purchase when supplies not yet in local db
            (dayLedgerList || []).forEach(function(l) {
                if (!l) return;
                var typ = String(l.type || '').toLowerCase();
                if (typ !== 'purchase' && typ !== 'credit_purchase') return;
                var txn = String(l.transaction_id || '').trim();
                if (txn && seenTxn[txn]) return;
                if (txn) seenTxn[txn] = true;
                var amt = parseFloat(l.amount) || 0;
                if (amt <= 0) return;
                var companyName = '';
                if (l.companyId != null && typeof db !== 'undefined' && db && Array.isArray(db.companies)) {
                    var comp = db.companies.find(function(c) { return c && String(c.id) === String(l.companyId); });
                    if (comp) companyName = comp.name || '';
                }
                var note = String(l.note || '').trim();
                map['led:' + (txn || ('l' + (l.id || Math.random())))] = {
                    company: companyName || ((typeof t === 'function') ? t('daily_summary_unknown_company') : 'نەزانراو'),
                    invoice: note ? note.slice(0, 56) : (txn ? ('#' + txn.slice(-8)) : '—'),
                    total: roundM(amt),
                    txnId: txn,
                    type: typ === 'credit_purchase' ? 'credit' : 'cash',
                    date: l.date || l.created_at || '',
                    items: [],
                    ledgerOnly: true
                };
            });
            var cashByTxn = {};
            (dayExpensesList || []).forEach(function(e) {
                if (!e || e.type !== 'purchase') return;
                var txn = String(e.transaction_id || '').trim();
                if (!txn) return;
                cashByTxn[txn] = (cashByTxn[txn] || 0) + ((typeof expenseAmountIqd === 'function') ? expenseAmountIqd(e) : (parseFloat(e.amount) || 0));
            });
            var summaries = Object.keys(map).map(function(k) {
                var x = map[k];
                x.total = roundM(x.total);
                return x;
            });
            var cashTotal = 0;
            var debtTotal = 0;
            var cashCount = 0;
            var debtCount = 0;
            summaries.forEach(function(p) {
                var tot = parseFloat(p.total) || 0;
                if (!(tot > 0)) return;
                var typ = String(p.type || '').toLowerCase();
                var cashPart = 0;
                var debtPart = 0;
                if (p.expenseOnly || typ === 'cash') {
                    cashPart = tot;
                } else if (typ === 'credit') {
                    debtPart = tot;
                } else if (typ === 'split') {
                    cashPart = Math.min(tot, Math.max(0, cashByTxn[String(p.txnId || '').trim()] || 0));
                    debtPart = Math.max(0, tot - cashPart);
                } else {
                    var linked = Math.max(0, cashByTxn[String(p.txnId || '').trim()] || 0);
                    if (linked >= tot - 0.009) cashPart = tot;
                    else if (linked > 0) {
                        cashPart = Math.min(tot, linked);
                        debtPart = Math.max(0, tot - cashPart);
                    } else {
                        debtPart = tot;
                    }
                }
                cashPart = roundM(cashPart);
                debtPart = roundM(debtPart);
                p.cashPart = cashPart;
                p.debtPart = debtPart;
                cashTotal += cashPart;
                debtTotal += debtPart;
                if (cashPart > 0.009) cashCount++;
                if (debtPart > 0.009) debtCount++;
            });
            try { window._dailySummaryPurchaseLines = lines; } catch (_eLines) {}
            var total = roundM(summaries.reduce(function(s, p) { return s + (parseFloat(p.total) || 0); }, 0));
            return {
                summaries: summaries,
                count: summaries.length,
                total: total,
                cashTotal: roundM(cashTotal),
                debtTotal: roundM(debtTotal),
                cashCount: cashCount,
                debtCount: debtCount
            };
        }

        function dailySummaryFindPurchaseLines(txnId) {
            txnId = String(txnId || '').trim();
            if (!txnId) return [];
            var pools = [
                window._dailySummaryPurchaseLines,
                window._fullPurchaseHistory,
                (typeof db !== 'undefined' && db && db.supplies) ? db.supplies : null
            ];
            for (var i = 0; i < pools.length; i++) {
                var list = pools[i];
                if (!Array.isArray(list) || !list.length) continue;
                var hit = list.filter(function(s) { return s && String(s.transaction_id || '') === txnId; });
                if (hit.length) return hit;
            }
            return [];
        }

        function dailySummaryEnsurePurchaseLines(txnId) {
            txnId = String(txnId || '').trim();
            var items = dailySummaryFindPurchaseLines(txnId);
            if (!items.length) return items;
            if (!Array.isArray(window._fullPurchaseHistory)) window._fullPurchaseHistory = [];
            var haveHist = window._fullPurchaseHistory.some(function(s) { return s && String(s.transaction_id || '') === txnId; });
            if (!haveHist) {
                window._fullPurchaseHistory = window._fullPurchaseHistory.concat(items);
            }
            if (typeof db !== 'undefined' && db && Array.isArray(db.supplies)) {
                items.forEach(function(it) {
                    if (!it || it.id == null) return;
                    var exists = db.supplies.some(function(s) { return s && String(s.id) === String(it.id); });
                    if (!exists) db.supplies.push(it);
                });
            }
            return items;
        }

        function dailySummaryEditPurchase(txnId) {
            txnId = String(txnId || '').trim();
            if (!txnId) return;
            dailySummaryEnsurePurchaseLines(txnId);
            if (typeof closeDailySummaryDetailSheet === 'function') closeDailySummaryDetailSheet();
            if (typeof closeDailyHistoryModal === 'function') closeDailyHistoryModal();
            else {
                var dhm = document.getElementById('daily-history-modal');
                if (dhm) dhm.style.display = 'none';
            }
            if (typeof startEditPurchaseInCart === 'function') startEditPurchaseInCart(txnId);
        }

        function dailySummaryReturnPurchase(txnId) {
            txnId = String(txnId || '').trim();
            if (!txnId) return;
            dailySummaryEnsurePurchaseLines(txnId);
            if (typeof closeDailySummaryDetailSheet === 'function') closeDailySummaryDetailSheet();
            if (typeof closeDailyHistoryModal === 'function') closeDailyHistoryModal();
            else {
                var dhm = document.getElementById('daily-history-modal');
                if (dhm) dhm.style.display = 'none';
            }
            if (typeof startPurchaseReturnFromHistory === 'function') startPurchaseReturnFromHistory(txnId);
        }

        function dailySummaryPrintPurchase(txnId) {
            txnId = String(txnId || '').trim();
            if (!txnId) return;
            var items = dailySummaryEnsurePurchaseLines(txnId);
            if (!items.length) {
                if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('purchase_edit_not_found') : 'وەسڵ نەهاتە دیتن', 'error');
                return;
            }
            if (typeof viewInvoiceHistoryDetails === 'function') viewInvoiceHistoryDetails(txnId);
        }

        function dailySummaryVoidPurchase(txnId) {
            txnId = String(txnId || '').trim();
            if (!txnId) return;
            dailySummaryEnsurePurchaseLines(txnId);
            if (typeof voidPurchaseInvoice === 'function') voidPurchaseInvoice(txnId);
        }

        function finalizeDailyModalContent(targetDateISO, todayPretty, spec) {
            const modal = document.getElementById('daily-history-modal');
            const content = document.getElementById('daily-history-content');
            if (!modal || !content || !spec || !spec.metricsScoped) {
                return false;
            }
            const metricsScoped = spec.metricsScoped;
            try {
                window._dailySummaryPaintedIqd = Math.max(
                    parseFloat(window._dailySummaryPaintedIqd) || 0,
                    parseFloat(metricsScoped.totalSales) || 0
                );
            } catch (_ePainted) {}
            var dateFromISO = (spec.dateFrom || targetDateISO);
            var dateToISO = (spec.dateTo || targetDateISO);
            var dateLineLabel = (dateFromISO === dateToISO)
                ? dateFromISO
                : (dateFromISO + ' → ' + dateToISO);

            // Prefer locked USD from server core engine; fall back to JS getFinancialMetrics on pools.
            var usdM = null;
            try {
                if (metricsScoped && metricsScoped.metrics_engine === 'pos_get_financial_metrics_core' && metricsScoped.totalSalesUsd != null) {
                    usdM = metricsScoped;
                } else if (typeof getFinancialMetrics === 'function' && (typeof isUsdMoneySystem === 'function' ? isUsdMoneySystem() : (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD'))) {
                    var poolsForUsd = spec.dayPools || null;
                    usdM = getFinancialMetrics(dateFromISO === dateToISO ? dateFromISO : targetDateISO, poolsForUsd ? { dayPools: poolsForUsd } : {});
                }
            } catch (_eUsdM) { usdM = null; }
            if (!usdM && metricsScoped && metricsScoped.totalSalesUsd != null) usdM = metricsScoped;
            var _fmt = function (iqd, usd) {
                if (typeof formatReportAmount === 'function') return formatReportAmount(iqd, usd);
                if (typeof formatCurrency === 'function') {
                    if (usd != null && typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD') {
                        return formatCurrency(0, { directUsd: usd });
                    }
                    return formatCurrency(iqd);
                }
                return String(iqd);
            };

            let totalSales = metricsScoped.totalSales;
            const companyDebtPayments = metricsScoped.companyDebtPayments || 0;
            const companyDebtPaymentsFib = metricsScoped.companyDebtPaymentsFib || 0;
            const debtPaymentsIn = metricsScoped.debtPaymentsIn || 0;
            const debtPaymentsInFib = metricsScoped.debtPaymentsInFib || 0;
            const purchaseReturnsIn = metricsScoped.purchaseReturnsIn || 0;
            const totalPurchaseReturns = metricsScoped.totalPurchaseReturns != null ? metricsScoped.totalPurchaseReturns : purchaseReturnsIn;
            const cashPurchasesOut = metricsScoped.cashPurchases || 0;
            const cashSalesOnly = metricsScoped.cashSales != null ? metricsScoped.cashSales : totalSales;
            const fibSalesOnly = metricsScoped.fibSales != null ? metricsScoped.fibSales : 0;
            const debtSalesOnly = metricsScoped.debtSales != null ? metricsScoped.debtSales : 0;
            const fibPurchasesOnly = metricsScoped.fibPurchases != null ? metricsScoped.fibPurchases : 0;
            var dayCustomerDebtList = spec.dayCustomerDebtList || [];
            var dayPurchaseReturnsList = spec.dayPurchaseReturnsList || [];
            var purchaseReturnsCount = dayPurchaseReturnsList.length;
            var dayPurchasesRaw = spec.dayPurchasesList || [];
            var dayExpensesForPurchases = spec.dayExpensesList || [];
            var dayLedgerForPurchases = spec.dayLedgerList || [];
            var purchaseDisplay = buildDailyPurchaseDisplay(dayPurchasesRaw, dayExpensesForPurchases, dayLedgerForPurchases);
            var purchaseSummaries = purchaseDisplay.summaries;
            var purchasesCount = purchaseDisplay.count;
            var totalPurchases = purchaseDisplay.total;
            // Prefer metrics cash (matches قاسە); debt = remaining of purchase invoices
            var cashPurchasesOnly = cashPurchasesOut > 0
                ? cashPurchasesOut
                : (purchaseDisplay.cashTotal != null ? purchaseDisplay.cashTotal : 0);
            var debtPurchasesOnly = purchaseDisplay.debtTotal != null
                ? purchaseDisplay.debtTotal
                : Math.max(0, totalPurchases - cashPurchasesOnly - fibPurchasesOnly);
            if (cashPurchasesOut > 0 && Math.abs((cashPurchasesOnly + debtPurchasesOnly + fibPurchasesOnly) - totalPurchases) > 1) {
                debtPurchasesOnly = Math.max(0, totalPurchases - cashPurchasesOnly - fibPurchasesOnly);
            }
            var cashPurchaseCount = purchaseDisplay.cashCount || 0;
            var debtPurchaseCount = purchaseDisplay.debtCount || 0;
            // Authoritative server stats when client pools were empty / incomplete
            var srvPur = spec.serverPurchaseStats;
            if (srvPur && (Number(srvPur.purchases_total) || 0) > 0) {
                var srvTot = Number(srvPur.purchases_total) || 0;
                var srvCash = Number(srvPur.purchases_cash) || 0;
                var srvFib = Number(srvPur.purchases_fib) || 0;
                var srvDebt = srvPur.purchases_debt != null
                    ? (Number(srvPur.purchases_debt) || 0)
                    : Math.max(0, srvTot - srvCash - srvFib);
                if (!(totalPurchases > 0) || Math.abs(totalPurchases - srvTot) > 1) {
                    totalPurchases = srvTot;
                    var srvCnt = parseInt(srvPur.purchase_count, 10);
                    if (Number.isFinite(srvCnt) && srvCnt > 0) purchasesCount = srvCnt;
                }
                if (!(cashPurchasesOnly > 0) && srvCash > 0) cashPurchasesOnly = srvCash;
                if (!(fibPurchasesOnly > 0) && srvFib > 0) fibPurchasesOnly = srvFib;
                if (!(debtPurchasesOnly > 0) && srvDebt > 0) debtPurchasesOnly = srvDebt;
                if (cashPurchasesOnly + debtPurchasesOnly + fibPurchasesOnly < srvTot - 1) {
                    cashPurchasesOnly = srvCash;
                    fibPurchasesOnly = srvFib;
                    debtPurchasesOnly = srvDebt;
                }
            }
            // Server invoice rows fill the list when local supplies pool was empty
            var srvInvoices = Array.isArray(spec.serverPurchaseInvoices) ? spec.serverPurchaseInvoices : [];
            if ((!purchaseSummaries || !purchaseSummaries.length) && srvInvoices.length) {
                purchaseSummaries = srvInvoices.map(function(inv) {
                    return {
                        company: inv.company || '',
                        invoice: inv.invoice || '—',
                        total: parseFloat(inv.total) || 0,
                        txnId: String(inv.txnId || inv.transaction_id || '').trim(),
                        type: inv.type || 'cash',
                        date: inv.date || '',
                        items: Array.isArray(inv.items) ? inv.items : [],
                        expenseOnly: !!inv.expenseOnly,
                        ledgerOnly: !!inv.ledgerOnly
                    };
                });
                purchasesCount = purchaseSummaries.length;
                if (!(totalPurchases > 0)) {
                    totalPurchases = purchaseSummaries.reduce(function(s, p) { return s + (parseFloat(p.total) || 0); }, 0);
                }
                cashPurchaseCount = 0;
                debtPurchaseCount = 0;
                purchaseSummaries.forEach(function(p) {
                    var typ = String(p.type || '').toLowerCase();
                    if (typ === 'credit' || typ === 'debt') debtPurchaseCount++;
                    else cashPurchaseCount++;
                });
            }
            // Last resort: totals exist but no invoice rows yet — show cash/debt summary cards (not empty message)
            if ((!purchaseSummaries || !purchaseSummaries.length) && totalPurchases > 0) {
                purchaseSummaries = [];
                if (cashPurchasesOnly > 0) {
                    purchaseSummaries.push({
                        company: (typeof t === 'function') ? t('daily_summary_cash_purchases') : 'کڕینا نەقد',
                        invoice: '—',
                        total: cashPurchasesOnly,
                        txnId: '',
                        type: 'cash',
                        date: '',
                        items: [],
                        expenseOnly: true
                    });
                }
                if (debtPurchasesOnly > 0) {
                    purchaseSummaries.push({
                        company: (typeof t === 'function') ? t('daily_summary_debt_purchases') : 'کڕینا دەین',
                        invoice: '—',
                        total: debtPurchasesOnly,
                        txnId: '',
                        type: 'credit',
                        date: '',
                        items: [],
                        ledgerOnly: true
                    });
                }
                if (!purchaseSummaries.length) {
                    purchaseSummaries.push({
                        company: (typeof t === 'function') ? t('daily_summary_purchases_label') : 'کڕین',
                        invoice: '—',
                        total: totalPurchases,
                        txnId: '',
                        type: 'cash',
                        date: '',
                        items: [],
                        expenseOnly: true
                    });
                }
                purchasesCount = purchaseSummaries.length;
                cashPurchaseCount = purchaseSummaries.filter(function(p) { return String(p.type || '') !== 'credit' && String(p.type || '') !== 'debt'; }).length;
                debtPurchaseCount = purchaseSummaries.length - cashPurchaseCount;
            }
            // Count must match visible rows — never wipe purchase totals when the list is empty
            // (local supplies cache miss used to force Total Purchases = $0 while Cash Purchases stayed).
            if (purchaseSummaries && purchaseSummaries.length) {
                purchasesCount = purchaseSummaries.length;
            } else {
                purchasesCount = 0;
                if (!(totalPurchases > 0)) {
                    if (srvPur && (Number(srvPur.purchases_total) || 0) > 0) {
                        totalPurchases = Number(srvPur.purchases_total) || 0;
                    } else if ((Number(metricsScoped.totalPurchases) || 0) > 0) {
                        totalPurchases = Number(metricsScoped.totalPurchases) || 0;
                    }
                }
                if (!(cashPurchasesOnly > 0) && cashPurchasesOut > 0) cashPurchasesOnly = cashPurchasesOut;
                if (!(debtPurchasesOnly > 0) && totalPurchases > 0) {
                    debtPurchasesOnly = Math.max(0, totalPurchases - cashPurchasesOnly - fibPurchasesOnly);
                }
            }
            let totalOperationalExpenses = (spec.overrideTotalExpenses !== undefined)
                ? spec.overrideTotalExpenses
                : (metricsScoped.opExpenses || 0);
            const totalGiftsValue = metricsScoped.totalGiftsValue || 0;
            const giftsCount = metricsScoped.giftsCount || 0;
            const totalReturns = metricsScoped.totalReturns || 0;
            const cashRefunds = metricsScoped.cashRefunds || 0;
            const wasteLoss = metricsScoped.wasteLoss || 0;
            var dayWasteList = Array.isArray(spec.dayWasteList) ? spec.dayWasteList : [];
            var wasteCount = dayWasteList.length || (parseInt(metricsScoped.wasteCount, 10) || 0);
            if (!wasteCount && wasteLoss > 0) wasteCount = 1;
            var dayDeliveriesList = Array.isArray(spec.dayDeliveriesList) ? spec.dayDeliveriesList : [];
            var delDay = summarizeDeliveriesForRange(dateFromISO, dateToISO, dayDeliveriesList.length ? dayDeliveriesList : null);
            if (!dayDeliveriesList.length && delDay.rows && delDay.rows.length) dayDeliveriesList = delDay.rows;
            var showDeliveryCards = isPosDeliveryFeatureOn() || delDay.delivery_count > 0 || delDay.delivery_delivered_count > 0 || delDay.delivery_pending_count > 0 || delDay.delivery_refused_count > 0 || delDay.delivery_cancelled_count > 0;
            var dayGiftLines = [];
            (spec.daySalesScoped || []).forEach(function(s) {
                (s.items || []).forEach(function(it) {
                    if (!it || !it.isGift) return;
                    var q = typeof getItemQty === 'function' ? getItemQty(it) : (Number(it.qty || it.count) || 1);
                    dayGiftLines.push({
                        name: it.name || 'ئایتم',
                        qty: q,
                        price: Number(it.price) || 0,
                        value: (Number(it.price) || 0) * q,
                        receipt: s.id,
                        cashier: s.cashier || ''
                    });
                });
            });
            var dayReturnsListAll = spec.dayReturnsList || [];
            var splitRet = splitDailyReturnsAndVoids(dayReturnsListAll);
            var dayReturnsList = splitRet.returns;
            var dayVoidedList = splitRet.voids;
            var dayVoidedPurchasesList = Array.isArray(spec.dayVoidedPurchasesList) ? spec.dayVoidedPurchasesList : [];
            const returnsCount = dayReturnsList.length;
            const voidedCount = dayVoidedList.length;
            const voidedPurchasesCount = dayVoidedPurchasesList.length;
            const displayReturnsTotal = dayReturnsList.reduce(function(sum, r) {
                return sum + (parseFloat(r && r.total) || 0);
            }, 0);
            const displayVoidedTotal = dayVoidedList.reduce(function(sum, r) {
                return sum + (parseFloat(r && r.total) || 0);
            }, 0);
            const displayVoidedPurchasesTotal = dayVoidedPurchasesList.reduce(function(sum, r) {
                return sum + (parseFloat(r && r.total) || 0);
            }, 0);
            // Only real customer returns reduce drawer cash — voided invoices already removed from sales
            const displayCashRefunds = dayReturnsList.reduce(function(sum, r) {
                if (!r || r.payment_method === 'debt') return sum;
                return sum + (parseFloat(r.total) || 0);
            }, 0);

            const daySalesScoped = spec.daySalesScoped || [];
            try {
                window._dailySummarySalesById = {};
                daySalesScoped.forEach(function(s) {
                    if (s && s.id != null) window._dailySummarySalesById[String(s.id)] = s;
                });
            } catch (_eMap) {}
            var dayExpensesList = spec.dayExpensesList || [];
            var dayCompanyDebtList = dayExpensesList.filter(function(e) {
                return e && e.type === 'debt_payment' && !(typeof isPurchaseLinkedDebtPayment === 'function' && isPurchaseLinkedDebtPayment(e, dayExpensesList));
            });
            var dayCompanyDebtFibList = dayExpensesList.filter(function(e) {
                return e && e.type === 'debt_payment_fib' && !(typeof isPurchaseLinkedDebtPayment === 'function' && isPurchaseLinkedDebtPayment(e, dayExpensesList));
            });
            var dayOperationalExpensesList = dayExpensesList.filter(function(e) {
                return typeof isOperationalExpenseRow === 'function' ? isOperationalExpenseRow(e) : (!e || !e.type || e.type === 'operational');
            });
            var dayShifts = spec.dayShifts || [];
            let lastReceiptIdShop = String(spec.lastReceiptIdShop || '');

            /** Opening balance: admin uses all shifts; others own shift only — unchanged behavior */
            var openingSelfOnly = !!(currentUser && currentUser.role !== 'admin');
            var dayShiftPoolOpening = openingSelfOnly
                ? dayShifts.filter(function(s) { return currentUser && Number(s.userId) === Number(currentUser.id); })
                : dayShifts.slice();
            let opening = 0;
            if (dayShiftPoolOpening.length > 0) {
                var firstShift = dayShiftPoolOpening.slice().sort(function(a, b) {
                    return String(a.startTime || a.start_time || '').localeCompare(String(b.startTime || b.start_time || ''));
                })[0];
                opening = parseFloat(firstShift && firstShift.opening_balance) || 0;
            }

            const cashDrawer = opening + (Number(metricsScoped.cashMovement) || 0);
            const profitPending = !!(spec.provisional && (metricsScoped.netProfit == null || metricsScoped.netProfit === ''));
            const netProfit = profitPending ? 0 : (Number(metricsScoped.netProfit) || 0);
            const canShowProfit = (typeof canViewProfit === 'function') ? canViewProfit() : true;
            const profitDisplay = profitPending
                ? '—'
                : _fmt(netProfit, usdM && usdM.netProfitUsd);

            var productByIdForProfit = new Map();
            try {
                (db && db.products ? db.products : []).forEach(function(p) {
                    if (p && p.id != null) productByIdForProfit.set(Number(p.id), p);
                });
            } catch (_ePb) {}
            var resolveCostForProfit = (typeof resolveSaleLineCost === 'function')
                ? resolveSaleLineCost
                : function(i) { return parseFloat(i && i.cost) || 0; };
            var getQtyForProfit = (typeof getItemQty === 'function')
                ? getItemQty
                : (typeof window.getSaleLineQty === 'function'
                    ? window.getSaleLineQty
                    : function(i) {
                        var q = parseFloat(i && (i.qty != null ? i.qty : i.count));
                        return (!isNaN(q) && q > 0) ? q : 1;
                    });
            var itemProfitMap = {};
            function accumulateItemProfit(rawItems, sign) {
                var src = rawItems;
                if (typeof src === 'string') {
                    try { src = JSON.parse(src); } catch (_e) { src = []; }
                }
                if (src && typeof src === 'object' && !Array.isArray(src)) {
                    src = Object.keys(src).map(function(k) { return src[k]; });
                }
                if (!Array.isArray(src)) src = [];
                src.forEach(function(i) {
                    if (!i || i.isGift) return;
                    var q = getQtyForProfit(i) * (sign || 1);
                    if (Math.abs(q) < 0.000001) return;
                    var price = Number(i.price) || 0;
                    var cost = resolveCostForProfit(i, productByIdForProfit);
                    var nm = (i.name != null ? i.name : i.title) ? String(i.name != null ? i.name : i.title) : 'ئایتم';
                    var unit = i.saleUnit || 'piece';
                    var key = String(i.id != null ? i.id : nm) + '|' + unit + '|' + nm;
                    if (!itemProfitMap[key]) {
                        itemProfitMap[key] = { name: nm, saleUnit: unit, qty: 0, profit: 0, revenue: 0 };
                    }
                    itemProfitMap[key].qty += q;
                    itemProfitMap[key].revenue += price * q;
                    itemProfitMap[key].profit += (price - cost) * q;
                });
            }
            daySalesScoped.forEach(function(s) {
                if (!s || s.is_returned) return;
                accumulateItemProfit(s.items, 1);
            });
            (dayReturnsList || []).forEach(function(r) {
                if (!r) return;
                accumulateItemProfit(r.items, -1);
            });
            var itemProfitRows = Object.keys(itemProfitMap).map(function(k) { return itemProfitMap[k]; })
                .filter(function(r) { return Math.abs(r.qty) > 0.0001 || Math.abs(r.profit) >= 0.5; })
                .sort(function(a, b) { return (b.profit || 0) - (a.profit || 0); });

            const itemStats = {};
            daySalesScoped.forEach(function(s) {
                if (s.items) {
                    s.items.forEach(function(i) {
                        var nm = (i && (i.name != null ? i.name : i.title)) ? String(i.name != null ? i.name : i.title) : '—';
                        if (!itemStats[nm]) itemStats[nm] = { qty: 0, total: 0 };
                        var lineQ = typeof getItemQty === 'function' ? getItemQty(i) : (typeof window.getSaleLineQty === 'function' ? window.getSaleLineQty(i) : 1);
                        itemStats[nm].qty += lineQ;
                        itemStats[nm].total += (parseFloat(i.price) || 0) * lineQ;
                    });
                }
            });
            var topItems = Object.entries(itemStats).sort(function(a, b) { return b[1].total - a[1].total; }).slice(0, 5);

            var staffNames = [...new Set(dayShifts.map(function(s) { return s.userName; }))];

            var _d = function(key, fb) {
                if (typeof t === 'function') {
                    var v = t(key);
                    if (v && v !== key) return v;
                }
                return fb || key;
            };
            var _timeLoc = (typeof getDateLocale === 'function') ? getDateLocale() : 'ku-IQ';
            var _clickHint = escapeHtml(_d('daily_summary_click_for_table', 'کلیک بکە بۆ وردەکاری'));
            var _cardNav = function(secId, tone, extraClass, tipOverride) {
                var cls = 'daily-sum-card daily-sum-card--' + (tone || 'default') + (extraClass ? ' ' + extraClass : '');
                var tip = tipOverride != null ? tipOverride : _clickHint;
                return 'class="' + cls + '" role="button" tabindex="0" title="' + tip + '" onclick="openDailySummaryDetailSheet(\'' + secId + '\')" onkeydown="if(event.key===\'Enter\'||event.key===\' \'){event.preventDefault();openDailySummaryDetailSheet(\'' + secId + '\');}"';
            };
            var _mkCard = function(secId, tone, icon, label, value, count) {
                var countBit = (count != null && count !== '') ? ' <span class="daily-sum-card__count">' + escapeHtml(String(count)) + '</span>' : '';
                return '<div ' + _cardNav(secId, tone) + '>' +
                    '<div class="daily-sum-card__icon"><i class="' + icon + '"></i></div>' +
                    '<div class="daily-sum-card__label">' + escapeHtml(label) + countBit + '</div>' +
                    '<div class="daily-sum-card__value">' + value + '</div>' +
                    '<div class="daily-sum-card__tap"><i class="fas fa-hand-pointer"></i> ' + escapeHtml(_d('daily_summary_tap_short', 'وردەکاری')) + '</div>' +
                    '</div>';
            };
            var _th = 'padding:8px 6px;border-bottom:1px solid var(--border);text-align:right;font-size:0.75rem;color:var(--text-muted);white-space:nowrap;';
            var _td = 'padding:8px 6px;border-bottom:1px solid var(--border);font-size:0.85rem;vertical-align:top;';

            var cashSaleCount = 0;
            var debtSaleCount = 0;
            daySalesScoped.forEach(function(s) {
                if (!s) return;
                var cashPart = (typeof saleCashInAmount === 'function')
                    ? saleCashInAmount(s)
                    : ((String(s.payment_method || '').toLowerCase() === 'debt') ? 0 : (parseFloat(s.total) || 0));
                var debtPart = (typeof saleDebtAmount === 'function')
                    ? saleDebtAmount(s)
                    : ((String(s.payment_method || '').toLowerCase() === 'debt')
                        ? (parseFloat(s.total) || 0)
                        : Math.max(0, parseFloat(s.debt_amount) || 0));
                if (cashPart > 0.0001) cashSaleCount++;
                if (debtPart > 0.0001) debtSaleCount++;
            });

            var metricCards = '';
            var u = usdM || {};
            var openingUsd = (typeof storedIqdToUsdDisplayAmount === 'function')
                ? storedIqdToUsdDisplayAmount(opening, { fxUsdRate: (typeof getUsdRatePerOne === 'function' ? Math.round(getUsdRatePerOne() * 100) : 0) })
                : null;
            // Opening float is "today's cash" — live rate OK; historical sales/COGS/debt/purchases use frozen USD.
            metricCards += _mkCard('daily-sec-cash', 'open', 'fas fa-wallet', _d('daily_summary_opening_balance', 'ڕەسیدێ دەستپێکێ'), _fmt(opening, openingUsd));
            metricCards += _mkCard('daily-sec-sales', 'sales', 'fas fa-chart-line', _d('daily_summary_total_sales', 'فرۆتنا گشتی'), _fmt(totalSales, u.totalSalesUsd), daySalesScoped.length);
            metricCards += _mkCard('daily-sec-sales', 'cashsale', 'fas fa-money-bill-wave', _d('daily_summary_cash_sales', 'فرۆتنا نەقد'), _fmt(cashSalesOnly, u.cashSalesUsd), cashSaleCount);
            metricCards += _mkCard('daily-sec-sales', 'debsale', 'fas fa-university', _d('daily_summary_fib_sales', 'فرۆتنا FIB'), _fmt(fibSalesOnly, u.fibSalesUsd));
            metricCards += _mkCard('daily-sec-sales', 'debsale', 'fas fa-file-invoice-dollar', _d('daily_summary_debt_sales', 'فرۆتنا دەین'), _fmt(debtSalesOnly, u.debtSalesUsd), debtSaleCount);
            if (lastReceiptIdShop) {
                metricCards += '<div class="daily-sum-card daily-sum-card--receipt">' +
                    '<div class="daily-sum-card__icon"><i class="fas fa-receipt"></i></div>' +
                    '<div class="daily-sum-card__label">' + escapeHtml(_d('daily_summary_last_receipt', 'دوایین وەسڵ')) + '</div>' +
                    '<div class="daily-sum-card__value">#' + escapeHtml(lastReceiptIdShop) + '</div>' +
                    '</div>';
            }
            metricCards += _mkCard('daily-sec-expenses', 'expenses', 'fas fa-money-bill-wave', _d('daily_summary_expenses_label', 'مەزاختن'), _fmt(totalOperationalExpenses, u.opExpensesUsd));
            metricCards += _mkCard('daily-sec-waste', 'waste', 'fas fa-recycle', _d('daily_summary_waste_label', 'تەلەف'), _fmt(wasteLoss, u.wasteLossUsd), wasteCount);
            metricCards += _mkCard('daily-sec-purchases', 'purchase', 'fas fa-shopping-cart', _d('daily_summary_purchases_label', 'کڕین'), _fmt(totalPurchases, u.totalPurchasesUsd), purchasesCount);
            metricCards += _mkCard('daily-sec-purchases', 'cashpur', 'fas fa-coins', _d('daily_summary_cash_purchases', 'کڕینا نەقد'), _fmt(cashPurchasesOnly, u.cashPurchasesUsd), cashPurchaseCount);
            metricCards += _mkCard('daily-sec-purchases', 'cashpur', 'fas fa-university', _d('daily_summary_fib_purchases', 'کڕینا FIB'), _fmt(fibPurchasesOnly, u.fibPurchasesUsd));
            var debtPurchUsd = (u.totalPurchasesUsd != null)
                ? Math.max(0, (Number(u.totalPurchasesUsd) || 0) - (Number(u.cashPurchasesUsd) || 0) - (Number(u.fibPurchasesUsd) || 0))
                : null;
            metricCards += _mkCard('daily-sec-purchases', 'debpur', 'fas fa-handshake', _d('daily_summary_debt_purchases', 'کڕینا دەین'), _fmt(debtPurchasesOnly, debtPurchUsd), debtPurchaseCount);
            if (companyDebtPayments > 0) {
                metricCards += _mkCard('daily-sec-company-debt', 'cdebt', 'fas fa-building', _d('daily_summary_company_debt_label', 'دانەڤا قەرزی کۆمپانیا'), _fmt(companyDebtPayments, u.companyDebtPaymentsUsd), dayCompanyDebtList.length);
            }
            if (companyDebtPaymentsFib > 0) {
                metricCards += _mkCard('daily-sec-company-debt', 'cdebt', 'fas fa-university', _d('daily_summary_company_debt_fib', 'دانەڤا قەرزی کۆمپانیا (FIB)'), formatCurrency(companyDebtPaymentsFib), dayCompanyDebtFibList.length);
            }
            if (debtPaymentsIn > 0) {
                metricCards += _mkCard('daily-sec-customer-debt', 'udebt', 'fas fa-hand-holding-usd', _d('daily_summary_customer_debt_label', 'وەرگرتنا قەرزی کریار'), _fmt(debtPaymentsIn, u.debtPaymentsInUsd), dayCustomerDebtList.filter(function(cl) {
                    return (typeof customerDebtPaymentChannel === 'function') ? customerDebtPaymentChannel(cl) === 'cash' : true;
                }).length);
            }
            if (debtPaymentsInFib > 0) {
                metricCards += _mkCard('daily-sec-customer-debt', 'udebt', 'fas fa-university', _d('daily_summary_customer_debt_fib', 'وەرگرتنا قەرزی کریار (FIB)'), formatCurrency(debtPaymentsInFib), dayCustomerDebtList.filter(function(cl) {
                    return (typeof customerDebtPaymentChannel === 'function') && customerDebtPaymentChannel(cl) === 'fib';
                }).length);
            }
            if (purchaseReturnsIn > 0 || totalPurchaseReturns > 0) {
                metricCards += _mkCard('daily-sec-purchase-returns', 'preturn', 'fas fa-truck-loading', _d('daily_summary_purchase_returns_label', 'زڤڕاندنا کڕینێ'), _fmt(totalPurchaseReturns, u.totalPurchaseReturnsUsd), purchaseReturnsCount);
            }
            metricCards += _mkCard('daily-sec-returns', 'sreturn', 'fas fa-undo', _d('daily_summary_returns_label', 'زڤڕاندنا فرۆشتن'), _fmt(displayReturnsTotal, u.totalReturnsUsd), returnsCount);
            metricCards += _mkCard('daily-sec-voided', 'void', 'fas fa-trash-alt', _d('daily_summary_voided_label', 'وەسڵێن ژێبری (فرۆتن)'), formatCurrency(displayVoidedTotal), voidedCount);
            metricCards += _mkCard('daily-sec-voided-purchases', 'vpurchase', 'fas fa-trash', _d('daily_summary_voided_purchases_label', 'وەسڵێن ژێبری (کڕین)'), formatCurrency(displayVoidedPurchasesTotal), voidedPurchasesCount);
            metricCards += _mkCard('daily-sec-gifts', 'gift', 'fas fa-gift', _d('daily_summary_gifts_label', 'دیاری'), _fmt(totalGiftsValue, u.totalGiftsValueUsd), giftsCount);
            if (showDeliveryCards) {
                metricCards += _mkCard('daily-sec-delivery', 'delivery', 'fas fa-motorcycle', _d('daily_summary_delivery_total', 'گەهاندنا گشتی'), formatCurrency(delDay.delivery_total), delDay.delivery_count);
                metricCards += _mkCard('daily-sec-delivery', 'delivok', 'fas fa-check-circle', _d('del_status_delivered', 'گەهشت'), formatCurrency(delDay.delivery_delivered), delDay.delivery_delivered_count);
                metricCards += _mkCard('daily-sec-delivery', 'delivpend', 'fas fa-clock', _d('del_badge_pending', 'بەرێکرن'), formatCurrency(delDay.delivery_pending), delDay.delivery_pending_count);
                metricCards += _mkCard('daily-sec-delivery', 'delivref', 'fas fa-times-circle', _d('del_status_refused', 'رەفس'), formatCurrency(delDay.delivery_refused), delDay.delivery_refused_count);
            }

            var cashDrawerUsd = null;
            if (u.cashDrawerUsd != null && Number.isFinite(Number(u.cashDrawerUsd))) {
                cashDrawerUsd = Number(u.cashDrawerUsd);
            } else if (u.cashMovementUsd != null) {
                cashDrawerUsd = (Number(openingUsd) || 0) + (Number(u.cashMovementUsd) || 0);
            }

            content.innerHTML = `
                <div class="daily-sum-wrap">
                    <div class="daily-sum-hero">
                        <div class="daily-sum-hero__head">
                            <div class="daily-sum-hero__badge"><i class="fas fa-calendar-check"></i></div>
                            <div class="daily-sum-hero__text">
                                <h3 class="daily-sum-hero__title">${escapeHtml(_d('daily_summary_financial_heading', 'پوختەی دارایی'))}</h3>
                                <p class="daily-sum-hero__date">${escapeHtml(todayPretty)}</p>
                            </div>
                        </div>
                        <p class="daily-sum-hint"><i class="fas fa-info-circle"></i> ${escapeHtml(_d('daily_summary_cards_hint', 'کلیک ل سەر کارتێ بکە بۆ وردەکاری'))}</p>
                        <div class="daily-sum-grid">${metricCards}</div>
                        <div class="daily-sum-totals">
                            <div ${_cardNav('daily-sec-cash', 'drawer', 'daily-sum-total-card')}>
                                <div class="daily-sum-total-card__icon"><i class="fas fa-cash-register"></i></div>
                                <div class="daily-sum-total-card__meta">
                                    <div class="daily-sum-total-card__label">${escapeHtml(_d('daily_summary_cash_drawer', 'قاسە'))}</div>
                                    <div class="daily-sum-total-card__value">${_fmt(cashDrawer, cashDrawerUsd)}</div>
                                    <div class="daily-sum-card__tap"><i class="fas fa-hand-pointer"></i> ${escapeHtml(_d('daily_summary_tap_short', 'وردەکاری'))}</div>
                                </div>
                            </div>
                            ${((typeof canViewProfit === 'function') ? canViewProfit() : true) ? `<div data-needs="profit" ${_cardNav('daily-sec-profit', netProfit >= 0 ? 'profit' : 'loss', 'daily-sum-total-card')}>
                                <div class="daily-sum-total-card__icon"><i class="fas fa-coins"></i></div>
                                <div class="daily-sum-total-card__meta">
                                    <div class="daily-sum-total-card__label">${escapeHtml(_d('daily_summary_net_profit', 'قازانجێ سافی'))}</div>
                                    <div class="daily-sum-total-card__value">${profitDisplay}</div>
                                    <div class="daily-sum-card__tap"><i class="fas fa-hand-pointer"></i> ${escapeHtml(_d('daily_summary_tap_short', 'وردەکاری'))}</div>
                                </div>
                            </div>` : ''}
                        </div>
                    </div>

                    <div id="daily-expiry-section-anchor"></div>

                    <div class="daily-sum-pair">
                        <div class="daily-sum-side-card">
                            <h4><i class="fas fa-users"></i> ${escapeHtml(_d('daily_summary_staff_section', 'کارمەندێن دەوامێ'))}</h4>
                            <div class="daily-sum-chips">
                                ${staffNames.length > 0 ? staffNames.map(function(n) { return '<span class="daily-sum-chip">' + escapeHtml(String(n || '')) + '</span>'; }).join('') : '<span class="daily-sum-empty">' + escapeHtml(_d('daily_summary_no_staff', 'چ کارمەند نینن')) + '</span>'}
                            </div>
                        </div>
                        <div class="daily-sum-side-card">
                            <h4><i class="fas fa-trophy"></i> ${escapeHtml(_d('daily_summary_top_items', 'پڕفرۆشترین ئایتم'))}</h4>
                            <div class="daily-sum-top-list">
                                ${topItems.length > 0 ? topItems.map(function(item, i) {
                                    return '<div class="daily-sum-top-row"><span class="daily-sum-top-rank">' + (i + 1) + '</span><span class="daily-sum-top-name">' + escapeHtml(item[0]) + '</span><span class="daily-sum-top-qty">' + item[1].qty + '</span></div>';
                                }).join('') : '<span class="daily-sum-empty">' + escapeHtml(_d('daily_summary_no_sales', 'چ فرۆتن نینن')) + '</span>'}
                            </div>
                        </div>
                    </div>
                </div>

                <div id="daily-sum-details-store" class="daily-sum-details-store" aria-hidden="true">
                <!-- CASH BREAKDOWN TABLE -->
                <div id="daily-sec-cash" class="card daily-sum-section" style="border:1px solid rgba(34,197,94,0.4);">
                    <h4 style="color:#22c55e;"><i class="fas fa-cash-register"></i> ${escapeHtml(_d('daily_summary_cash_section', 'خشتەیا قاسێ'))}</h4>
                    <div style="overflow-x:auto;">
                        <table style="width:100%; border-collapse:collapse;">
                            <thead><tr>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_item', 'بڕگە'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_effect', 'کاریگەری'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_amount', 'بڕ'))}</th>
                            </tr></thead>
                            <tbody>
                                <tr><td style="${_td}">${escapeHtml(_d('daily_summary_opening_balance', 'ڕەسیدێ دەستپێکێ'))}</td><td style="${_td};color:#86efac;">+</td><td style="${_td};font-weight:700;">${formatCurrency(opening)}</td></tr>
                                <tr><td style="${_td}">${escapeHtml(_d('daily_summary_cash_sales_drawer_hint', 'فرۆتنا نەقد'))}</td><td style="${_td};color:#86efac;">+</td><td style="${_td};font-weight:700;">${formatCurrency(cashSalesOnly)}</td></tr>
                                <tr><td style="${_td}">${escapeHtml(_d('daily_summary_customer_debt_drawer_hint', 'وەرگرتنا قەرزی کریار'))}</td><td style="${_td};color:#86efac;">+</td><td style="${_td};font-weight:700;">${formatCurrency(debtPaymentsIn)}</td></tr>
                                <tr><td style="${_td}">${escapeHtml(_d('daily_summary_purchase_returns_drawer_hint', 'زڤڕاندنا کڕینێ'))}</td><td style="${_td};color:#86efac;">+</td><td style="${_td};font-weight:700;">${formatCurrency(purchaseReturnsIn)}</td></tr>
                                <tr><td style="${_td}">${escapeHtml(_d('daily_summary_expenses_label', 'مەزاختن'))}</td><td style="${_td};color:#fca5a5;">−</td><td style="${_td};font-weight:700;">${formatCurrency(totalOperationalExpenses)}</td></tr>
                                <tr><td style="${_td}">${escapeHtml(_d('daily_summary_cash_purchases_drawer_hint', 'کڕینا نەقد'))}</td><td style="${_td};color:#fca5a5;">−</td><td style="${_td};font-weight:700;">${formatCurrency(cashPurchasesOut)}</td></tr>
                                <tr><td style="${_td}">${escapeHtml(_d('daily_summary_company_debt_drawer_hint', 'دانەڤا قەرزی کۆمپانیا'))}</td><td style="${_td};color:#fca5a5;">−</td><td style="${_td};font-weight:700;">${formatCurrency(companyDebtPayments)}</td></tr>
                                <tr><td style="${_td}">${escapeHtml(_d('daily_summary_returns_label', 'زڤڕاندنا فرۆشتن'))}</td><td style="${_td};color:#fca5a5;">−</td><td style="${_td};font-weight:700;">${formatCurrency(displayCashRefunds)}</td></tr>
                                <tr style="background:rgba(34,197,94,0.12);"><td style="${_td};font-weight:800;color:#22c55e;">${escapeHtml(_d('daily_summary_cash_drawer', 'قاسە'))}</td><td style="${_td}">=</td><td style="${_td};font-weight:900;color:#22c55e;font-size:1.05rem;">${formatCurrency(cashDrawer)}</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                ${canShowProfit ? `<!-- PROFIT BREAKDOWN TABLE -->
                <div id="daily-sec-profit" data-needs="profit" class="card daily-sum-section" style=" border:1px solid rgba(250,204,21,0.4); scroll-margin-top:12px;">
                    <h4 style="margin:0 0 10px 0; color:#facc15;"><i class="fas fa-chart-line"></i> ${escapeHtml(_d('daily_summary_profit_section', 'خشتەیا قازانجێ'))}</h4>
                    <div style="overflow-x:auto;">
                        <table style="width:100%; border-collapse:collapse;">
                            <thead><tr>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_item', 'بڕگە'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_effect', 'کاریگەری'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_amount', 'بڕ'))}</th>
                            </tr></thead>
                            <tbody>
                                <tr><td style="${_td}">${escapeHtml(_d('daily_summary_total_sales', 'فرۆتنا گشتی'))}</td><td style="${_td};color:#86efac;">+</td><td style="${_td};font-weight:700;">${formatCurrency(totalSales)}</td></tr>
                                <tr><td style="${_td};padding-right:18px;opacity:0.9;">↳ ${escapeHtml(_d('daily_summary_cash_sales', 'فرۆتنا نەقد'))}</td><td style="${_td};color:#86efac;"></td><td style="${_td};font-weight:600;color:#86efac;">${formatCurrency(cashSalesOnly)}</td></tr>
                                <tr><td style="${_td};padding-right:18px;opacity:0.9;">↳ ${escapeHtml(_d('daily_summary_fib_sales', 'فرۆتنا FIB'))}</td><td style="${_td};color:#93c5fd;"></td><td style="${_td};font-weight:600;color:#93c5fd;">${formatCurrency(fibSalesOnly)}</td></tr>
                                <tr><td style="${_td};padding-right:18px;opacity:0.9;">↳ ${escapeHtml(_d('daily_summary_debt_sales', 'فرۆتنا دەین'))}</td><td style="${_td};color:#fcd34d;"></td><td style="${_td};font-weight:600;color:#fcd34d;">${formatCurrency(debtSalesOnly)}</td></tr>
                                <tr><td style="${_td}">${escapeHtml(_d('daily_summary_returns_label', 'زڤڕاندنا فرۆشتن'))}</td><td style="${_td};color:#fca5a5;">−</td><td style="${_td};font-weight:700;">${formatCurrency(displayReturnsTotal)}</td></tr>
                                <tr><td style="${_td}">${escapeHtml(_d('daily_summary_purchases_label', 'کڕین'))}</td><td style="${_td};color:#fca5a5;">−</td><td style="${_td};font-weight:700;">${formatCurrency(totalPurchases)}</td></tr>
                                <tr><td style="${_td};padding-right:18px;opacity:0.9;">↳ ${escapeHtml(_d('daily_summary_cash_purchases', 'کڕینا نەقد'))}</td><td style="${_td};color:#5eead4;"></td><td style="${_td};font-weight:600;color:#5eead4;">${formatCurrency(cashPurchasesOnly)}</td></tr>
                                <tr><td style="${_td};padding-right:18px;opacity:0.9;">↳ ${escapeHtml(_d('daily_summary_fib_purchases', 'کڕینا FIB'))}</td><td style="${_td};color:#93c5fd;"></td><td style="${_td};font-weight:600;color:#93c5fd;">${formatCurrency(fibPurchasesOnly)}</td></tr>
                                <tr><td style="${_td};padding-right:18px;opacity:0.9;">↳ ${escapeHtml(_d('daily_summary_debt_purchases', 'کڕینا دەین'))}</td><td style="${_td};color:#fcd34d;"></td><td style="${_td};font-weight:600;color:#fcd34d;">${formatCurrency(debtPurchasesOnly)}</td></tr>
                                <tr><td style="${_td}">${escapeHtml(_d('daily_summary_expenses_label', 'مەزاختن'))}</td><td style="${_td};color:#fca5a5;">−</td><td style="${_td};font-weight:700;">${formatCurrency(totalOperationalExpenses)}</td></tr>
                                <tr><td style="${_td}">${escapeHtml(_d('daily_summary_waste_label', 'تەلەف'))}</td><td style="${_td};color:#fca5a5;">−</td><td style="${_td};font-weight:700;">${formatCurrency(wasteLoss)}</td></tr>
                                <tr style="background:rgba(250,204,21,0.12);"><td style="${_td};font-weight:800;color:#facc15;">${escapeHtml(_d('daily_summary_net_profit', 'قازانجێ سافی'))}</td><td style="${_td}">=</td><td style="${_td};font-weight:900;color:${profitPending ? '#94a3b8' : (netProfit >= 0 ? '#facc15' : '#ef4444')};font-size:1.05rem;">${profitDisplay}</td></tr>
                            </tbody>
                        </table>
                    </div>
                    <h4 style="margin:16px 0 8px 0; color:#facc15; font-size:0.95rem;"><i class="fas fa-boxes"></i> ${escapeHtml(_d('daily_summary_item_profit_section', 'قازانجا ئایتمان (ژ وەسڵان)'))}</h4>
                    <div style="overflow-x:auto; max-height:320px;">
                        <table style="width:100%; border-collapse:collapse;">
                            <thead><tr>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_item', 'بڕگە'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_qty', 'ژمارە'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_profit', 'قازانج'))}</th>
                            </tr></thead>
                            <tbody>
                                ${itemProfitRows.length
                                    ? itemProfitRows.map(function(r) {
                                        var qShow = (typeof formatQtyForDisplay === 'function') ? formatQtyForDisplay(r.qty, r) : String(r.qty);
                                        var unitLabel = '';
                                        if (r.saleUnit === 'carton') unitLabel = ' ' + escapeHtml(_d('unit_carton_short', 'کارتۆن'));
                                        else if (r.saleUnit === 'pack') unitLabel = ' ' + escapeHtml(_d('unit_pack_short', 'پاکەت'));
                                        var pCol = (r.profit >= 0) ? '#ca8a04' : '#ef4444';
                                        return '<tr><td style="' + _td + ';font-weight:700;">' + escapeHtml(r.name || 'ئایتم') + '</td>' +
                                            '<td style="' + _td + ';white-space:nowrap;">×' + escapeHtml(String(qShow)) + unitLabel + '</td>' +
                                            '<td style="' + _td + ';font-weight:800;color:' + pCol + ';white-space:nowrap;">' + formatCurrency(r.profit) + '</td></tr>';
                                    }).join('')
                                    : '<tr><td colspan="3" style="' + _td + ';text-align:center;color:var(--text-muted);">' + escapeHtml(_d('daily_summary_no_item_profit', 'چ قازانجا ئایتمی نینە')) + '</td></tr>'}
                            </tbody>
                        </table>
                    </div>
                    <p style="margin:8px 0 0;font-size:0.75rem;color:var(--text-muted);">${escapeHtml(_d('daily_summary_voided_profit_note', 'وەسڵێن ژێبری ژ فرۆتنێ دەرهاتینە — ل قازانجێ دوبارە ناهێنە ژمارتن.'))}</p>
                </div>` : ''}

                <!-- PURCHASES LIST -->
                <div id="daily-sec-purchases" class="card daily-sum-section daily-sum-purchases-panel" style=" border:1px solid rgba(20,184,166,0.35); scroll-margin-top:12px;">
                    <h4 style="margin:0 0 10px 0; color:#14b8a6;"><i class="fas fa-shopping-cart"></i> ${escapeHtml(_d('daily_summary_purchases_section', 'لیستا کڕینێ'))} (${purchasesCount})</h4>
                    <div class="daily-sum-sales-list">
                            ${purchaseSummaries.length > 0 ? purchaseSummaries.map(function(row, idx) {
                                var payType = String(row.type || 'cash').toLowerCase();
                                var payHtml;
                                if (payType === 'credit' || payType === 'debt') payHtml = '<span class="daily-sum-pay daily-sum-pay--debt">' + escapeHtml(_d('payment_method_debt', 'قەرز')) + '</span>';
                                else if (payType === 'split') payHtml = '<span class="daily-sum-pay daily-sum-pay--split">' + escapeHtml(_d('payment_method_split', 'قەرز + نەقد')) + '</span>';
                                else payHtml = '<span class="daily-sum-pay daily-sum-pay--cash">' + escapeHtml(_d('payment_method_cash', 'نەقد')) + '</span>';
                                var pTime = '';
                                try {
                                    if (row.date) pTime = parseSQLDate(row.date).toLocaleTimeString(_timeLoc, {hour:'2-digit', minute:'2-digit'});
                                } catch (_eT) { pTime = ''; }
                                var items = Array.isArray(row.items) ? row.items : [];
                                var itemsHtml = items.length
                                    ? items.map(function(it) {
                                        return '<div class="daily-sum-sale-item">' +
                                            '<span class="daily-sum-sale-item__name">' + escapeHtml(String(it.name || 'ئایتم')) + '</span>' +
                                            '<span class="daily-sum-sale-item__qty">×' + escapeHtml(String(it.qty != null ? it.qty : 0)) + '</span>' +
                                            '<span class="daily-sum-sale-item__price">' + ((typeof formatTxnMoney === 'function') ? formatTxnMoney(it.totalCost || 0, it.fx_usd_rate != null ? it : row) : formatCurrency(it.totalCost || 0, (typeof fxUsdRateFormatOpts === 'function') ? fxUsdRateFormatOpts(row) : undefined)) + '</span>' +
                                            '</div>';
                                    }).join('')
                                    : (row.expenseOnly
                                        ? '<div class="daily-sum-sale-item daily-sum-sale-item--empty">' + escapeHtml(_d('daily_summary_cash_purchase_row', 'کڕینا نەقد')) + '</div>'
                                        : '<div class="daily-sum-sale-item daily-sum-sale-item--empty">' + escapeHtml(_d('daily_summary_no_item_lines', 'ئایتم نەهاتنە دیتن')) + '</div>');
                                var txnId = String(row.txnId || '').trim();
                                var txnEsc = txnId.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
                                var canEditPurchase = !!txnId && !row.expenseOnly && payType !== 'return' && (
                                    (typeof currentUser !== 'undefined' && currentUser && (currentUser.role === 'admin' || currentUser.role === 'manager')) ||
                                    (typeof checkPermission === 'function' && checkPermission('companies_manage'))
                                );
                                var editTitle = escapeHtml(_d('daily_summary_edit_btn', 'تەعدیل'));
                                var returnTitle = escapeHtml(_d('daily_summary_return_btn', 'زڤڕاندن'));
                                var printTitle = escapeHtml(_d('daily_summary_print_btn', 'چاپکرن'));
                                var delTitle = escapeHtml(_d('daily_summary_delete_btn', 'ژێبرن'));
                                var actionsHtml = '';
                                if (txnId) {
                                    var editBtn = canEditPurchase
                                        ? '<button type="button" class="btn btn-sm btn-primary" onclick="event.stopPropagation();dailySummaryEditPurchase(\'' + txnEsc + '\')" title="' + editTitle + '"><i class="fas fa-edit"></i> ' + editTitle + '</button>'
                                        : '';
                                    var returnBtn = canEditPurchase
                                        ? '<button type="button" class="btn btn-sm btn-return-invoice" onclick="event.stopPropagation();dailySummaryReturnPurchase(\'' + txnEsc + '\')" title="' + returnTitle + '"><i class="fas fa-undo"></i> ' + returnTitle + '</button>'
                                        : '';
                                    actionsHtml =
                                        editBtn +
                                        returnBtn +
                                        '<button type="button" class="btn btn-sm btn-dark" onclick="event.stopPropagation();dailySummaryPrintPurchase(\'' + txnEsc + '\')" title="' + printTitle + '"><i class="fas fa-print"></i> ' + printTitle + '</button> ' +
                                        '<button type="button" class="btn btn-sm btn-danger" onclick="event.stopPropagation();dailySummaryVoidPurchase(\'' + txnEsc + '\')" title="' + delTitle + '"><i class="fas fa-trash-alt"></i> ' + delTitle + '</button>';
                                } else {
                                    actionsHtml = '<span class="daily-sum-voided-badge">' + escapeHtml(_d('daily_summary_purchase_no_actions', 'کردار بەردەست نینە')) + '</span>';
                                }
                                return '<article class="daily-sum-sale-card daily-sum-purchase-card">' +
                                  '<div class="daily-sum-sale-card__head">' +
                                    '<div class="daily-sum-sale-card__id">#' + (idx + 1) + '</div>' +
                                    '<div class="daily-sum-sale-card__meta">' +
                                      (pTime ? ('<span><i class="fas fa-clock"></i> ' + escapeHtml(pTime) + '</span>') : '') +
                                      '<span><i class="fas fa-building"></i> ' + escapeHtml(String(row.company || '')) + '</span>' +
                                      '<span><i class="fas fa-file-invoice"></i> ' + escapeHtml(String(row.invoice || '—')) + '</span>' +
                                      payHtml +
                                    '</div>' +
                                    '<div class="daily-sum-sale-card__total" style="color:#14b8a6;">' + ((typeof formatTxnMoney === 'function') ? formatTxnMoney(row.total, row) : formatCurrency(row.total, (typeof fxUsdRateFormatOpts === 'function') ? fxUsdRateFormatOpts(row) : undefined)) + '</div>' +
                                  '</div>' +
                                  '<div class="daily-sum-sale-card__items">' + itemsHtml + '</div>' +
                                  '<div class="daily-sum-sale-card__actions">' + actionsHtml + '</div>' +
                                  '</article>';
                            }).join('') : '<p class="daily-sum-empty" style="text-align:center;padding:20px;">' + escapeHtml(_d('daily_summary_no_purchases_list', 'چ کڕین بۆ ئەڤ ڕۆژە تۆمار نەکراوە.')) + '</p>'}
                    </div>
                </div>

                <!-- PURCHASE RETURNS LIST -->
                <div id="daily-sec-purchase-returns" class="card daily-sum-section" style=" border:1px solid rgba(245,158,11,0.35); scroll-margin-top:12px;">
                    <h4 style="margin:0 0 10px 0; color:#f59e0b;"><i class="fas fa-truck-loading"></i> ${escapeHtml(_d('daily_summary_purchase_returns_section', 'لیستا زڤڕاندنا کڕینێ (ل قاسە)'))} (${purchaseReturnsCount})</h4>
                    <div style="max-height:220px; overflow:auto;">
                        <table style="width:100%; border-collapse:collapse;">
                            <thead><tr>
                                <th style="${_th}">#</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_company', 'کۆمپانی'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_time', 'کات'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_amount', 'بڕ'))}</th>
                            </tr></thead>
                            <tbody>
                            ${dayPurchaseReturnsList.length > 0 ? dayPurchaseReturnsList.map(function(pr) {
                                var prTime = _safeTime(pr.date, _timeLoc);
                                var prLbl = getPurchaseReturnLabel(pr);
                                var invRef = pr.supplier_invoice_number ? (' · پسوول: ' + String(pr.supplier_invoice_number)) : '';
                                return '<tr><td style="' + _td + '">#' + escapeHtml(String(pr.id || '')) + '</td><td style="' + _td + ';font-weight:700;color:#f59e0b;">' + escapeHtml(prLbl) + escapeHtml(invRef) + '</td><td style="' + _td + ';color:var(--text-muted);">' + escapeHtml(prTime) + '</td><td style="' + _td + ';font-weight:700;color:#f59e0b;white-space:nowrap;">+' + formatCurrency(pr.total) + '</td></tr>';
                            }).join('') : '<tr><td colspan="4" style="' + _td + ';text-align:center;color:var(--text-muted);">' + escapeHtml(_d('daily_summary_no_purchase_returns_list', 'چ زڤڕاندنا کڕینێ بۆ ئەڤ ڕۆژە تۆمار نەکراوە.')) + '</td></tr>'}
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- SALES RETURNS LIST (real returns only) -->
                <div id="daily-sec-returns" class="card daily-sum-section" style=" scroll-margin-top:12px;">
                    <h4 style="margin:0 0 10px 0; color:#a855f7;"><i class="fas fa-undo"></i> ${escapeHtml(_d('daily_summary_returns_section', 'لیستا زڤڕاندنا فرۆشتن'))} (${returnsCount})</h4>
                    <div style="max-height:240px; overflow:auto;">
                        <table style="width:100%; border-collapse:collapse;">
                            <thead><tr>
                                <th style="${_th}">#</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_items', 'ئایتم'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_cashier', 'کاشێر'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_time', 'کات'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_amount', 'بڕ'))}</th>
                            </tr></thead>
                            <tbody>
                            ${dayReturnsList.length > 0 ? dayReturnsList.map(function(r) {
                                var rTime = _safeTime(r.date, _timeLoc);
                                var itemsSum = formatDailyReturnItemsSummary(r);
                                return '<tr style="cursor:pointer;" onclick="if(typeof showReturnDetails===\'function\')showReturnDetails(' + parseInt(r.id, 10) + ')"><td style="' + _td + ';font-weight:700;">#' + escapeHtml(String(r.id || '')) + '</td><td style="' + _td + '">' + escapeHtml(itemsSum || '—') + '</td><td style="' + _td + ';color:var(--text-muted);">' + escapeHtml(String(r.cashier || '-')) + '</td><td style="' + _td + ';color:var(--text-muted);">' + escapeHtml(rTime) + '</td><td style="' + _td + ';font-weight:700;color:#a855f7;white-space:nowrap;">' + formatCurrency(r.total) + '</td></tr>';
                            }).join('') : '<tr><td colspan="5" style="' + _td + ';text-align:center;color:var(--text-muted);">' + escapeHtml(_d('daily_summary_no_returns_list', 'چ زڤڕاندن نییە')) + '</td></tr>'}
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- VOIDED / DELETED INVOICES (SALES) -->
                <div id="daily-sec-voided" class="card daily-sum-section" style=" border:1px solid rgba(148,163,184,0.45); scroll-margin-top:12px;">
                    <h4 style="margin:0 0 10px 0; color:#94a3b8;"><i class="fas fa-trash-alt"></i> ${escapeHtml(_d('daily_summary_voided_section', 'لیستا وەسڵێن ژێبری (فرۆتن)'))} (${voidedCount})</h4>
                    <p style="margin:0 0 8px;font-size:0.78rem;color:var(--text-muted);">${escapeHtml(_d('daily_summary_voided_section_hint', 'ئەڤە ژێبرنا وەسڵێ یە — نە زڤڕاندنا فرۆتنێ. ئایتم و ژمارا وەسڵێ ل خوارێ.'))}</p>
                    <div style="max-height:260px; overflow:auto;">
                        <table style="width:100%; border-collapse:collapse;">
                            <thead><tr>
                                <th style="${_th}">#</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_items', 'ئایتم'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_cashier', 'کاشێر'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_time', 'کات'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_amount', 'بڕ'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_actions', 'کردار'))}</th>
                            </tr></thead>
                            <tbody>
                            ${dayVoidedList.length > 0 ? dayVoidedList.map(function(r) {
                                var rTime = _safeTime(r.date, _timeLoc);
                                var itemsSum = formatDailyReturnItemsSummary(r);
                                return '<tr><td style="' + _td + ';font-weight:700;"><span style="background:#ef4444;color:#fff;font-size:0.65rem;padding:1px 5px;border-radius:4px;margin-left:4px;">' + escapeHtml(_d('daily_summary_void_badge', 'ژێبراو')) + '</span> #' + escapeHtml(String(r.id || '')) + '</td><td style="' + _td + '">' + escapeHtml(itemsSum || _d('daily_summary_void_no_items', 'ئایتم نەهاتە پاراستن')) + '</td><td style="' + _td + ';color:var(--text-muted);">' + escapeHtml(String(r.cashier || '-')) + '</td><td style="' + _td + ';color:var(--text-muted);">' + escapeHtml(rTime) + '</td><td style="' + _td + ';font-weight:700;color:#94a3b8;white-space:nowrap;">' + formatCurrency(r.total) + '</td><td style="' + _td + ';white-space:nowrap;"><button type="button" class="btn btn-sm btn-success" onclick="event.stopPropagation();if(typeof restoreVoidedSale===\'function\')restoreVoidedSale(' + parseInt(r.id, 10) + ')" title="' + escapeHtml(_d('btn_undo_void', 'پەشێمان بم')) + '"><i class="fas fa-undo"></i> ' + escapeHtml(_d('btn_undo_void', 'پەشێمان بم')) + '</button> <button type="button" class="btn btn-sm btn-info" onclick="event.stopPropagation();if(typeof showReturnDetails===\'function\')showReturnDetails(' + parseInt(r.id, 10) + ')" title="' + escapeHtml(_d('daily_summary_tap_short', 'وردەکاری')) + '"><i class="fas fa-eye"></i></button></td></tr>';
                            }).join('') : '<tr><td colspan="6" style="' + _td + ';text-align:center;color:var(--text-muted);padding:16px 10px;">' + escapeHtml(_d('daily_summary_no_voided_list', 'چ وەسڵێن ژێبری نییە')) + '<div style="font-size:0.78rem;margin-top:6px;opacity:0.9;">' + escapeHtml(_d('daily_summary_void_traces_hint', 'دەمێ وەسڵ بهێتە ژێبرن، شینوار دمینن — دکەهی پەشێمان بم بکەی.')) + '</div></td></tr>'}
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- VOIDED / DELETED PURCHASE INVOICES -->
                <div id="daily-sec-voided-purchases" class="card daily-sum-section" style=" border:1px solid rgba(20,184,166,0.4); scroll-margin-top:12px;">
                    <h4 style="margin:0 0 10px 0; color:#14b8a6;"><i class="fas fa-trash-alt"></i> ${escapeHtml(_d('daily_summary_voided_purchases_section', 'لیستا وەسڵێن ژێبری (کڕین)'))} (${voidedPurchasesCount})</h4>
                    <p style="margin:0 0 8px;font-size:0.78rem;color:var(--text-muted);">${escapeHtml(_d('daily_summary_voided_purchases_section_hint', 'ئەڤە ژێبرنا پسولێ کڕینێ یە. کۆمپانیا، ئایتم و بڕ ل خوارێ.'))}</p>
                    <div style="max-height:260px; overflow:auto;">
                        <table style="width:100%; border-collapse:collapse;">
                            <thead><tr>
                                <th style="${_th}">#</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_company', 'کۆمپانی'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_items', 'ئایتم'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_cashier', 'کاشێر'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_time', 'کات'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_amount', 'بڕ'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_actions', 'کردار'))}</th>
                            </tr></thead>
                            <tbody>
                            ${dayVoidedPurchasesList.length > 0 ? dayVoidedPurchasesList.map(function(r) {
                                var rTime = _safeTime(r.date || r.created_at, _timeLoc);
                                var itemsSum = formatDailyReturnItemsSummary(r);
                                var invRef = r.supplier_invoice_number
                                    ? String(r.supplier_invoice_number)
                                    : (r.txn_id ? ('#' + String(r.txn_id)) : ('#' + String(r.id || '')));
                                var txnEsc = String(r.txn_id || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'");
                                var auditId = parseInt(r.audit_id || r.id, 10) || 0;
                                return '<tr><td style="' + _td + ';font-weight:700;"><span style="background:#14b8a6;color:#fff;font-size:0.65rem;padding:1px 5px;border-radius:4px;margin-left:4px;">' + escapeHtml(_d('daily_summary_void_badge', 'ژێبراو')) + '</span> ' + escapeHtml(invRef) + '</td><td style="' + _td + ';font-weight:700;color:#14b8a6;">' + escapeHtml(String(r.company || '—')) + '</td><td style="' + _td + '">' + escapeHtml(itemsSum || _d('daily_summary_void_no_items', 'ئایتم نەهاتە پاراستن')) + '</td><td style="' + _td + ';color:var(--text-muted);">' + escapeHtml(String(r.cashier || r.user || '-')) + '</td><td style="' + _td + ';color:var(--text-muted);">' + escapeHtml(rTime) + '</td><td style="' + _td + ';font-weight:700;color:#14b8a6;white-space:nowrap;">' + formatCurrency(r.total) + '</td><td style="' + _td + ';white-space:nowrap;"><button type="button" class="btn btn-sm btn-success" onclick="event.stopPropagation();if(typeof restoreVoidedPurchase===\'function\')restoreVoidedPurchase(\'' + txnEsc + '\',' + auditId + ')" title="' + escapeHtml(_d('btn_undo_void', 'پەشێمان بم')) + '"><i class="fas fa-undo"></i> ' + escapeHtml(_d('btn_undo_void', 'پەشێمان بم')) + '</button></td></tr>';
                            }).join('') : '<tr><td colspan="7" style="' + _td + ';text-align:center;color:var(--text-muted);">' + escapeHtml(_d('daily_summary_no_voided_purchases_list', 'چ وەسڵێن کڕینێ یێن ژێبری نییە')) + '</td></tr>'}
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- COMPANY DEBT PAYMENTS -->
                <div id="daily-sec-company-debt" class="card daily-sum-section" style=" border:1px solid rgba(14,165,233,0.35); scroll-margin-top:12px;">
                    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; margin-bottom:10px;">
                        <h4 style="margin:0; color:#0ea5e9;"><i class="fas fa-building"></i> ${escapeHtml(_d('daily_summary_company_debt_section', 'دانەڤا قەرزی کۆمپانیا (ل قاسە)'))} (${dayCompanyDebtList.length})</h4>
                        <button type="button" class="btn btn-sm btn-success" onclick="typeof openPayCompanyDebtModal==='function'&&openPayCompanyDebtModal()"><i class="fas fa-plus"></i> ${escapeHtml(_d('pcd_btn_open', 'دانەڤا قەرزی کۆمپانیا'))}</button>
                    </div>
                    <div style="max-height:220px; overflow:auto;">
                        <table style="width:100%; border-collapse:collapse;">
                            <thead><tr>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_company', 'کۆمپانی'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_cashier', 'کاشێر'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_amount', 'بڕ'))}</th>
                            </tr></thead>
                            <tbody>
                            ${dayCompanyDebtList.length > 0 ? dayCompanyDebtList.map(function(e) {
                                var compLbl = (typeof getCompanyDebtExpenseLabel === 'function') ? getCompanyDebtExpenseLabel(e) : String(e.note != null ? e.note : '');
                                return '<tr><td style="' + _td + ';font-weight:700;color:#0ea5e9;">' + escapeHtml(compLbl) + '</td><td style="' + _td + ';color:var(--text-muted);">' + escapeHtml(String(e.user || '-')) + '</td><td style="' + _td + ';font-weight:700;color:#0ea5e9;white-space:nowrap;">−' + ((typeof formatExpenseAmountDisplay === 'function') ? formatExpenseAmountDisplay(e) : formatCurrency((typeof expenseAmountIqd === 'function') ? expenseAmountIqd(e) : e.amount)) + '</td></tr>';
                            }).join('') : '<tr><td colspan="3" style="' + _td + ';text-align:center;color:var(--text-muted);">' + escapeHtml(_d('daily_summary_no_company_debt_list', 'هێشتا دانەڤا قەرزی کۆمپانیا تۆمار نەکراوە — کۆمپانیا هەڵبژێرە و پارە بدە.')) + '</td></tr>'}
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- CUSTOMER DEBT PAYMENTS -->
                <div id="daily-sec-customer-debt" class="card daily-sum-section" style=" border:1px solid rgba(34,197,94,0.35); scroll-margin-top:12px;">
                    <h4 style="margin:0 0 10px 0; color:#22c55e;"><i class="fas fa-hand-holding-usd"></i> ${escapeHtml(_d('daily_summary_customer_debt_section', 'وەرگرتنا قەرزی کریار (ل قاسە)'))} (${dayCustomerDebtList.length})</h4>
                    <div style="max-height:220px; overflow:auto;">
                        ${dayCustomerDebtList.length > 0 ? dayCustomerDebtList.map(function(cl) {
                            var clTime = _safeTime(cl.date, _timeLoc);
                            return formatCustomerDebtPaymentRowHtml(cl, clTime);
                        }).join('') : '<p style="text-align:center;color:var(--text-muted);margin:0;padding:8px;">' + escapeHtml(_d('daily_summary_no_customer_debt_list', 'هێشتا پارەدانێ قەرزی کریار بۆ ئەڤ ڕۆژە تۆمار نەکراوە.')) + '</p>'}
                    </div>
                </div>

                <!-- GIFTS LIST -->
                <div id="daily-sec-gifts" class="card daily-sum-section" style=" scroll-margin-top:12px;">
                    <h4 style="margin:0 0 10px 0; color:#ec4899;"><i class="fas fa-gift"></i> ${escapeHtml(_d('daily_summary_gifts_section', 'لیستا دیاریان'))} (${dayGiftLines.length})</h4>
                    <div style="max-height:220px; overflow:auto;">
                        <table style="width:100%; border-collapse:collapse;">
                            <thead><tr>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_item', 'بڕگە'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_qty', 'ژمارە'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_cashier', 'کاشێر'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_receipt_col', 'وەسڵ') || 'وەسڵ')}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_gifts_value_col', 'بهایێ دیاری') || 'بها')}</th>
                            </tr></thead>
                            <tbody>
                            ${dayGiftLines.length > 0 ? dayGiftLines.map(function(g) {
                                return '<tr><td style="' + _td + '">' + escapeHtml(String(g.name || '')) + ' <span style="color:#ec4899;font-weight:700;">(' + escapeHtml(_d('pos_gift_label', 'دیاری')) + ')</span></td><td style="' + _td + '">' + escapeHtml(String(g.qty)) + '</td><td style="' + _td + ';color:var(--text-muted);">' + escapeHtml(String(g.cashier || '-')) + '</td><td style="' + _td + '">#' + escapeHtml(String(g.receipt || '')) + '</td><td style="' + _td + ';font-weight:700;color:#ec4899;white-space:nowrap;">' + formatCurrency(g.value) + '</td></tr>';
                            }).join('') : '<tr><td colspan="5" style="' + _td + ';text-align:center;color:var(--text-muted);">' + escapeHtml(_d('daily_summary_no_gifts_list', 'چ دیاری نینن')) + '</td></tr>'}
                            </tbody>
                        </table>
                    </div>
                </div>

                ${showDeliveryCards ? `
                <!-- DELIVERIES LIST -->
                <div id="daily-sec-delivery" class="card daily-sum-section" style=" border:1px solid rgba(99,102,241,0.35); scroll-margin-top:12px;">
                    <h4 style="margin:0 0 8px 0; color:#6366f1;"><i class="fas fa-motorcycle"></i> ${escapeHtml(_d('daily_summary_delivery_section', 'لیستا گەهاندن'))} (${dayDeliveriesList.length})</h4>
                    <p style="margin:0 0 8px;font-size:0.78rem;color:var(--text-muted);">${escapeHtml(_d('cal_month_group_delivery_hint', 'گەهشت دچیتە قاسێ — بەرید ل دەف سایقی'))}</p>
                    <div style="max-height:260px; overflow:auto;">
                        <table style="width:100%; border-collapse:collapse;">
                            <thead><tr>
                                <th style="${_th}">#</th>
                                <th style="${_th}">${escapeHtml(_d('del_th_customer', 'کڕیار'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_driver', 'سایێق'))}</th>
                                <th style="${_th}">${escapeHtml(_d('del_th_status', 'دۆخ'))}</th>
                                <th style="${_th}">${escapeHtml(_d('del_th_date', 'بەروار'))}</th>
                                <th style="${_th}">${escapeHtml(_d('del_th_total', 'کۆم'))}</th>
                            </tr></thead>
                            <tbody>
                            ${dayDeliveriesList.length > 0 ? dayDeliveriesList.map(function(dRow) {
                                var stRaw = String(dRow.status || '').toLowerCase();
                                var stLbl = deliveryStatusLabel(stRaw);
                                var who = (typeof deliveryCustomerLabel === 'function') ? deliveryCustomerLabel(dRow) : (String(dRow.customer_name || '').trim() || _d('del_no_customer', 'بێ ناڤ'));
                                var drv = String(dRow.driver || '').trim() || '—';
                                var dTimeRaw = dRow.settled_at || dRow.date || '';
                                var dTime = '';
                                try {
                                    dTime = dTimeRaw && typeof parseSQLDate === 'function'
                                        ? parseSQLDate(dTimeRaw).toLocaleString(_timeLoc, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
                                        : String(dTimeRaw);
                                } catch (_eT) { dTime = String(dTimeRaw); }
                                var stColor = stRaw === 'delivered' ? '#16a34a' : (stRaw === 'refused' ? '#dc2626' : (stRaw === 'cancelled' ? '#64748b' : '#d97706'));
                                return '<tr><td style="' + _td + ';font-weight:700;">#' + escapeHtml(String(dRow.id || '')) + '</td><td style="' + _td + '">' + escapeHtml(who) + '</td><td style="' + _td + ';color:var(--text-muted);">' + escapeHtml(drv) + '</td><td style="' + _td + ';font-weight:700;color:' + stColor + ';">' + escapeHtml(stLbl) + '</td><td style="' + _td + ';color:var(--text-muted);white-space:nowrap;">' + escapeHtml(dTime) + '</td><td style="' + _td + ';font-weight:700;white-space:nowrap;">' + formatCurrency(dRow.total) + '</td></tr>';
                            }).join('') : '<tr><td colspan="6" style="' + _td + ';text-align:center;color:var(--text-muted);">' + escapeHtml(_d('daily_summary_no_deliveries', 'چ گەهاندن نینن')) + '</td></tr>'}
                            </tbody>
                        </table>
                    </div>
                </div>
                ` : ''}

                <!-- EXPENSES LIST -->
                <div id="daily-sec-expenses" class="card daily-sum-section" style=" scroll-margin-top:12px;">
                    <h4 style="margin:0 0 10px 0; color:var(--danger);"><i class="fas fa-file-invoice-dollar"></i> ${escapeHtml(_d('daily_summary_expenses_section', 'لیستا مەزاختنان'))}</h4>
                    <div style="max-height:220px; overflow:auto;">
                        <table style="width:100%; border-collapse:collapse;">
                            <thead><tr>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_note', 'تێبینی'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_cashier', 'کاشێر'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_amount', 'بڕ'))}</th>
                            </tr></thead>
                            <tbody>
                            ${dayOperationalExpensesList.length > 0 ? dayOperationalExpensesList.map(function(e) {
                                return '<tr><td style="' + _td + '">' + escapeHtml(String(e.note != null ? e.note : '')) + '</td><td style="' + _td + ';color:var(--text-muted);">' + escapeHtml(String(e.user || '-')) + '</td><td style="' + _td + ';font-weight:700;color:var(--danger);white-space:nowrap;">' + ((typeof formatExpenseAmountDisplay === 'function') ? formatExpenseAmountDisplay(e) : formatCurrency((typeof expenseAmountIqd === 'function') ? expenseAmountIqd(e) : e.amount)) + '</td></tr>';
                            }).join('') : '<tr><td colspan="3" style="' + _td + ';text-align:center;color:var(--text-muted);">' + escapeHtml(_d('daily_summary_no_expenses_list', 'چ مەزاختن نینن')) + '</td></tr>'}
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- WASTE LIST -->
                <div id="daily-sec-waste" class="card daily-sum-section" style=" scroll-margin-top:12px;">
                    <h4 style="margin:0 0 10px 0; color:#fb923c;"><i class="fas fa-recycle"></i> ${escapeHtml(_d('daily_summary_waste_section', 'لیستا تەلەفێ'))}</h4>
                    <div style="max-height:220px; overflow:auto;">
                        <table style="width:100%; border-collapse:collapse;">
                            <thead><tr>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_item', 'بڕگە'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_qty', 'ژمارە'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_note', 'تێبینی'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_cashier', 'کاشێر'))}</th>
                                <th style="${_th}">${escapeHtml(_d('daily_summary_col_amount', 'بڕ'))}</th>
                                <th style="${_th};width:52px;"></th>
                            </tr></thead>
                            <tbody>
                            ${dayWasteList.length > 0 ? dayWasteList.map(function(w) {
                                var wName = String((w && (w.prodName || w.name || w.note)) || '—');
                                var wQty = (w && w.qty != null) ? w.qty : '';
                                var wReason = String((w && w.reason) || '');
                                var wUser = String((w && (w.user || w.cashier)) || '-');
                                var wCost = (w && w.cost != null) ? w.cost : ((w && w.amount != null) ? w.amount : 0);
                                var wId = w && w.id != null ? parseInt(w.id, 10) : 0;
                                var canUndoW = (typeof canUndoWaste === 'function')
                                    ? canUndoWaste()
                                    : !!(currentUser && (currentUser.role === 'admin' || (typeof hasPermission === 'function' && hasPermission('waste_manage'))));
                                var undoLbl = escapeHtml(_d('waste_undo_btn', 'گەڕاندنەوە'));
                                var undoBtn = (canUndoW && wId > 0)
                                    ? '<button type="button" class="btn btn-sm btn-success" onclick="event.stopPropagation();if(typeof undoWaste===\'function\')undoWaste(' + wId + ')" title="' + undoLbl + '" aria-label="' + undoLbl + '"><i class="fas fa-undo"></i></button>'
                                    : '<span style="color:var(--text-muted);">—</span>';
                                return '<tr><td style="' + _td + '">' + escapeHtml(wName) + '</td><td style="' + _td + '">' + escapeHtml(String(wQty)) + '</td><td style="' + _td + ';color:var(--text-muted);">' + escapeHtml(wReason) + '</td><td style="' + _td + ';color:var(--text-muted);">' + escapeHtml(wUser) + '</td><td style="' + _td + ';font-weight:700;color:#fb923c;white-space:nowrap;">' + formatCurrency(wCost) + '</td><td style="' + _td + ';white-space:nowrap;text-align:center;">' + undoBtn + '</td></tr>';
                            }).join('') : '<tr><td colspan="6" style="' + _td + ';text-align:center;color:var(--text-muted);">' + escapeHtml(_d('daily_summary_no_waste_list', 'چ تەلەف نینن')) + '</td></tr>'}
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <!-- INVOICE LIST (SALES) -->
                <div id="daily-sec-sales" class="daily-sum-sales-panel" style="margin-top:10px; scroll-margin-top:12px;">
                    <h4 style="border-bottom:1px solid var(--border); padding-bottom:10px; margin-bottom:10px; color:var(--text);"><i class="fas fa-list"></i> ${escapeHtml(_d('daily_summary_invoices_section', 'وەسڵێن ڕۆژێ'))} (${daySalesScoped.length})</h4>
                    <div class="daily-sum-sales-list">
                            ${daySalesScoped.length > 0 ? daySalesScoped.slice().reverse().map(function(s) {
                                var payHtml;
                                if (s.payment_method === 'debt') payHtml = '<span class="daily-sum-pay daily-sum-pay--debt">' + escapeHtml(_d('payment_method_debt', 'قەرز')) + '</span>';
                                else if (s.payment_method === 'split') payHtml = '<span class="daily-sum-pay daily-sum-pay--split">' + escapeHtml(_d('payment_method_split', 'قەرز + نەقد')) + '</span>';
                                else payHtml = '<span class="daily-sum-pay daily-sum-pay--cash">' + escapeHtml(_d('payment_method_cash', 'نەقد')) + '</span>';
                                var sTime = _safeTime(s.date || s.created_at, _timeLoc);
                                var custName = '';
                                if (s.customer && String(s.customer).toLowerCase() !== 'general') {
                                    custName = String(s.customer);
                                } else if (s.customer_id && db && Array.isArray(db.customers)) {
                                    var custRow = db.customers.find(function(c) { return c && String(c.id) === String(s.customer_id); });
                                    if (custRow && custRow.name) custName = String(custRow.name);
                                }
                                if (!custName) custName = _d('daily_summary_walk_in', 'کریارێ گشتی');
                                var fxOpts = typeof fxUsdRateFormatOpts === 'function' ? fxUsdRateFormatOpts(s) : undefined;
                                var saleItemsGrouped = groupDailySummarySaleLines(s.items);
                                var saleLineProfitTotal = 0;
                                var showWh = posShouldShowDailySaleWarehouse();
                                var saleWhName = showWh ? posDailySaleItemWarehouseName(null, s) : '';
                                var whHeadHtml = '';
                                if (showWh && saleWhName) {
                                    whHeadHtml = '<span class="daily-sum-pay daily-sum-pay--wh" title="' + escapeHtml(_d('daily_summary_item_warehouse', 'کۆگەه')) + '"><i class="fas fa-warehouse"></i> ' + escapeHtml(saleWhName) + '</span>';
                                }
                                var itemsHtml = saleItemsGrouped.length
                                    ? saleItemsGrouped.map(function(it) {
                                        var q = Number(it.count) || 0;
                                        var qShow = (typeof formatQtyForDisplay === 'function') ? formatQtyForDisplay(q, it) : String(q);
                                        var nm = it.name || 'ئایتم';
                                        var lineTotal = (it.sub != null) ? it.sub : ((parseFloat(it.price) || 0) * q);
                                        var unitLabel = '';
                                        if (it.saleUnit === 'carton') unitLabel = ' ' + escapeHtml(_d('unit_carton_short', 'کارتۆن'));
                                        else if (it.saleUnit === 'pack') unitLabel = ' ' + escapeHtml(_d('unit_pack_short', 'پاکەت'));
                                        var lineProfitHtml = '';
                                        if (canShowProfit && !it.isGift) {
                                            var unitCost = resolveCostForProfit(it, productByIdForProfit);
                                            var lineProfit = ((Number(it.price) || 0) - unitCost) * q;
                                            saleLineProfitTotal += lineProfit;
                                            var pCol = lineProfit >= 0 ? '#ca8a04' : '#ef4444';
                                            lineProfitHtml = '<span class="daily-sum-sale-item__profit" style="color:' + pCol + ';" title="' + escapeHtml(_d('daily_summary_col_profit', 'قازانج')) + '">' + formatCurrency(lineProfit, fxOpts) + '</span>';
                                        }
                                        var lineWh = showWh ? posDailySaleItemWarehouseName(it, s) : '';
                                        var nameHtml = '<span class="daily-sum-sale-item__name">' +
                                            '<span class="daily-sum-sale-item__name-text">' + escapeHtml(nm) + '</span>' +
                                            (lineWh ? ('<span class="daily-sum-sale-item__wh"><i class="fas fa-warehouse"></i> ' + escapeHtml(lineWh) + '</span>') : '') +
                                            '</span>';
                                        return '<div class="daily-sum-sale-item' + (canShowProfit ? ' daily-sum-sale-item--with-profit' : '') + '">' +
                                            nameHtml +
                                            '<span class="daily-sum-sale-item__qty">×' + escapeHtml(String(qShow)) + unitLabel + '</span>' +
                                            '<span class="daily-sum-sale-item__price">' + formatCurrency(lineTotal, fxOpts) + '</span>' +
                                            lineProfitHtml +
                                            '</div>';
                                    }).join('')
                                    : '<div class="daily-sum-sale-item daily-sum-sale-item--empty">' + escapeHtml(_d('daily_summary_no_item_lines', 'ئایتم نەهاتنە دیتن')) + '</div>';
                                var canEditSale = !s.is_returned && (
                                    (typeof currentUser !== 'undefined' && currentUser && (currentUser.role === 'admin' || currentUser.role === 'manager')) ||
                                    (typeof checkPermission === 'function' && checkPermission('returns_manage'))
                                );
                                var editTitle = escapeHtml(_d('daily_summary_edit_btn', 'تەعدیل'));
                                var printTitle = escapeHtml(_d('daily_summary_print_btn', 'چاپکرن'));
                                var voidTitle = escapeHtml(_d('daily_summary_void_btn', 'ژێبرنا وەسڵێ'));
                                var editBtn = canEditSale
                                    ? '<button type="button" class="btn btn-sm btn-primary" onclick="event.stopPropagation();dailySummaryEditSale(' + s.id + ')" title="' + editTitle + '"><i class="fas fa-edit"></i> ' + editTitle + '</button>'
                                    : '';
                                var voidBtn = !s.is_returned
                                    ? '<button type="button" class="btn btn-sm btn-danger" onclick="event.stopPropagation();refundSale(' + s.id + ')" title="' + voidTitle + '"><i class="fas fa-trash-alt"></i> ' + escapeHtml(_d('daily_summary_delete_btn', 'ژێبرن')) + '</button>'
                                    : '<span class="daily-sum-voided-badge">' + escapeHtml(_d('daily_summary_already_voided', 'ژێبرای')) + '</span>';
                                var saleProfitBadge = (canShowProfit && saleItemsGrouped.length)
                                    ? '<div class="daily-sum-sale-card__profit" style="color:' + (saleLineProfitTotal >= 0 ? '#ca8a04' : '#ef4444') + ';">' +
                                        escapeHtml(_d('daily_summary_sale_profit', 'قازانج')) + ': ' + formatCurrency(saleLineProfitTotal, fxOpts) +
                                      '</div>'
                                    : '';
                                return '<article class="daily-sum-sale-card">' +
                                  '<div class="daily-sum-sale-card__head">' +
                                    '<div class="daily-sum-sale-card__id">#' + escapeHtml(String(s.id)) + '</div>' +
                                    '<div class="daily-sum-sale-card__meta">' +
                                      '<span><i class="fas fa-clock"></i> ' + escapeHtml(sTime) + '</span>' +
                                      '<span><i class="fas fa-user"></i> ' + escapeHtml(custName) + '</span>' +
                                      payHtml +
                                      whHeadHtml +
                                    '</div>' +
                                    '<div class="daily-sum-sale-card__total">' + formatCurrency(s.total, fxOpts) + '</div>' +
                                  '</div>' +
                                  '<div class="daily-sum-sale-card__items">' + itemsHtml + '</div>' +
                                  saleProfitBadge +
                                  '<div class="daily-sum-sale-card__actions">' +
                                    editBtn +
                                    '<button type="button" class="btn btn-sm btn-dark" onclick="event.stopPropagation();reprintBill(' + s.id + ')" title="' + printTitle + '"><i class="fas fa-print"></i> ' + printTitle + '</button> ' +
                                    voidBtn +
                                  '</div>' +
                                  '</article>';
                            }).join('') : '<p class="daily-sum-empty" style="text-align:center;padding:20px;">' + escapeHtml(_d('daily_summary_no_invoices', 'چ وەسڵ نینن')) + '</p>'}
                    </div>
                </div>
                </div>
                ${spec.usedLocalFallback ? '<p class="daily-sum-offline"><i class="fas fa-wifi"></i> ' + escapeHtml(_d('daily_summary_offline_warning', 'داتاکان تەن لە ناوکلاینت — ڕەنگە بۆ ڕۆژە کۆنان تەواو نەبن.')) + '</p>' : (spec.provisional ? '<p class="daily-sum-offline" style="opacity:0.85;"><i class="fas fa-sync-alt"></i> ' + escapeHtml(_d('daily_summary_refreshing', 'نوێدەبێت ژ سێرڤەرێ…')) + '</p>' : '')}
            `;

            closeDailySummaryDetailSheet({ keepModal: true, keepFlags: true });
            modal.style.display = 'flex';
            if (typeof applyUserPermissions === 'function') {
                applyUserPermissions();
            }
            refreshDailyExpirySection(dateFromISO);
            var pendingSheet = window._dailySummaryPendingSheet;
            if (pendingSheet && typeof openDailySummaryDetailSheet === 'function') {
                setTimeout(function () {
                    if (window._dailySummaryPendingSheet === pendingSheet && document.getElementById(pendingSheet)) {
                        openDailySummaryDetailSheet(pendingSheet);
                    }
                }, 0);
            }
            return true;
        }

        function dailySummaryLastReceiptMax(salesArr) {
            var bestStr = '';
            var bestNum = -Infinity;
            (salesArr || []).forEach(function(s) {
                var n = parseFloat(s.id);
                if (!Number.isFinite(n)) return;
                if (!Number.isFinite(bestNum) || n >= bestNum) {
                    bestNum = n;
                    bestStr = String(s.id);
                }
            });
            return bestStr;
        }

        function dailySummaryDb() {
            try {
                if (typeof window !== 'undefined' && window.db) return window.db;
            } catch (_eW) {}
            try {
                if (typeof db !== 'undefined' && db) return db;
            } catch (_eD) {}
            return null;
        }

        function dailySummaryNum(v) {
            var n = Number(v);
            return Number.isFinite(n) ? n : 0;
        }

        function dailySummaryRound(v) {
            if (typeof roundMoney === 'function') {
                try { return roundMoney(v, 'IQD'); } catch (_eR) {}
            }
            return Math.round(dailySummaryNum(v));
        }

        function readSaleOrReturnItems(row) {
            if (typeof saleOrReturnItems === 'function') {
                try { return saleOrReturnItems(row) || []; } catch (_eS) {}
            }
            if (!row) return [];
            var raw = (row.items != null && row.items !== '') ? row.items : row.items_json;
            if (typeof raw === 'string') {
                try { raw = JSON.parse(raw); } catch (_e) { return []; }
            }
            if (Array.isArray(raw)) return raw;
            if (raw && typeof raw === 'object') return Object.keys(raw).map(function(k) { return raw[k]; });
            return [];
        }

        /** Prefer unified getFinancialMetrics (mirrors pos_get_financial_metrics_core) — includes locked *Usd. */
        function computeDailyModalMetrics(pools) {
            pools = pools || {};
            if (typeof getFinancialMetrics === 'function') {
                try {
                    var m = getFinancialMetrics('1970-01-01', { dayPools: pools });
                    if (m && m.totalSales != null) {
                        return {
                            totalSales: dailySummaryRound(m.totalSales),
                            cashSales: dailySummaryRound(m.cashSales),
                            debtSales: dailySummaryRound(m.debtSales),
                            fibSales: dailySummaryRound(m.fibSales),
                            totalReturns: dailySummaryRound(m.totalReturns),
                            totalReturnsCost: dailySummaryRound(m.totalReturnsCost),
                            totalCogs: dailySummaryRound(m.totalCogs),
                            opExpenses: dailySummaryRound(m.opExpenses),
                            cashPurchases: dailySummaryRound(m.cashPurchases),
                            fibPurchases: dailySummaryRound(m.fibPurchases || 0),
                            totalPurchases: dailySummaryRound(m.totalPurchases || 0),
                            companyDebtPayments: dailySummaryRound(m.companyDebtPayments),
                            companyDebtPaymentsFib: dailySummaryRound(m.companyDebtPaymentsFib || 0),
                            debtPaymentsIn: dailySummaryRound(m.debtPaymentsIn),
                            debtPaymentsInFib: dailySummaryRound(m.debtPaymentsInFib || 0),
                            purchaseReturnsIn: dailySummaryRound(m.purchaseReturnsIn),
                            totalPurchaseReturns: dailySummaryRound(m.totalPurchaseReturns != null ? m.totalPurchaseReturns : m.purchaseReturnsIn),
                            grossProfit: dailySummaryRound(m.grossProfit),
                            netProfit: dailySummaryRound(m.netProfit),
                            cashMovement: dailySummaryRound(m.cashMovement),
                            wasteLoss: dailySummaryRound(m.wasteLoss),
                            wasteCount: parseInt(m.wasteCount, 10) || 0,
                            cashRefunds: dailySummaryRound(m.cashRefunds),
                            totalGiftsValue: dailySummaryRound(m.totalGiftsValue),
                            giftsCount: parseInt(m.giftsCount, 10) || 0,
                            totalSalesUsd: m.totalSalesUsd,
                            cashSalesUsd: m.cashSalesUsd,
                            debtSalesUsd: m.debtSalesUsd,
                            fibSalesUsd: m.fibSalesUsd,
                            totalReturnsUsd: m.totalReturnsUsd,
                            totalCogsUsd: m.totalCogsUsd,
                            opExpensesUsd: m.opExpensesUsd,
                            cashPurchasesUsd: m.cashPurchasesUsd,
                            fibPurchasesUsd: m.fibPurchasesUsd,
                            totalPurchasesUsd: m.totalPurchasesUsd,
                            companyDebtPaymentsUsd: m.companyDebtPaymentsUsd,
                            debtPaymentsInUsd: m.debtPaymentsInUsd,
                            purchaseReturnsInUsd: m.purchaseReturnsInUsd,
                            totalPurchaseReturnsUsd: m.totalPurchaseReturnsUsd,
                            wasteLossUsd: m.wasteLossUsd,
                            grossProfitUsd: m.grossProfitUsd,
                            netProfitUsd: m.netProfitUsd,
                            cashMovementUsd: m.cashMovementUsd,
                            cashRefundsUsd: m.cashRefundsUsd,
                            totalGiftsValueUsd: m.totalGiftsValueUsd,
                            metrics_engine: 'getFinancialMetrics'
                        };
                    }
                } catch (_eCore) { /* fall through to local plain math */ }
            }
            var sales = pools.sales || [];
            var returns = pools.returns || [];
            var expenses = pools.expenses || [];
            var cl = pools.customer_ledger || [];
            var waste = pools.waste || [];
            var purchaseReturns = pools.purchase_returns || [];
            var _db = dailySummaryDb();
            var productById = null;
            try {
                productById = new Map();
                ((_db && _db.products) || []).forEach(function(p) {
                    if (p && p.id != null) productById.set(Number(p.id), p);
                });
            } catch (_eMap) { productById = null; }
            var toUsd = function(iqd, row, hint) {
                try {
                    if (typeof storedIqdToUsdDisplayAmount === 'function') return Number(storedIqdToUsdDisplayAmount(iqd, row, hint)) || 0;
                } catch (_eU) {}
                return 0;
            };
            var lineCost = function(i) {
                try {
                    if (typeof resolveSaleLineCost === 'function') return dailySummaryNum(resolveSaleLineCost(i, productById));
                } catch (_eC) {}
                if (typeof saleLineHasExplicitCost === 'function' && saleLineHasExplicitCost(i)) return dailySummaryNum(i.cost);
                return dailySummaryNum(i && i.cost);
            };
            var lineQty = function(i) {
                try {
                    if (typeof getSaleLineQty === 'function') return dailySummaryNum(getSaleLineQty(i)) || 1;
                } catch (_eQ) {}
                var q = dailySummaryNum(i && (i.qty != null ? i.qty : i.count));
                return q > 0 ? q : 1;
            };
            var totalSales = 0, cashSales = 0, debtSales = 0, fibSales = 0, totalCogs = 0, gifts = 0, giftsCount = 0;
            var totalSalesUsd = 0, cashSalesUsd = 0, debtSalesUsd = 0, fibSalesUsd = 0, totalCogsUsd = 0, giftsUsd = 0;
            sales.forEach(function(s) {
                if (!s) return;
                var saleIqd = dailySummaryNum(s.total);
                totalSales += saleIqd;
                totalSalesUsd += toUsd(saleIqd, s, s.total_usd);
                try {
                    var c = (typeof saleCashInAmount === 'function') ? dailySummaryNum(saleCashInAmount(s)) : dailySummaryNum(s.paid_cash != null ? s.paid_cash : s.total);
                    var d = (typeof saleDebtAmount === 'function') ? dailySummaryNum(saleDebtAmount(s)) : dailySummaryNum(s.debt_amount);
                    var f = (typeof saleFibAmount === 'function') ? dailySummaryNum(saleFibAmount(s)) : 0;
                    cashSales += c; debtSales += d; fibSales += f;
                    cashSalesUsd += toUsd(c, s, saleIqd > 0 && s.total_usd != null ? (c / saleIqd) * Number(s.total_usd) : null);
                    debtSalesUsd += toUsd(d, s, saleIqd > 0 && s.total_usd != null ? (d / saleIqd) * Number(s.total_usd) : null);
                    fibSalesUsd += toUsd(f, s, saleIqd > 0 && s.total_usd != null ? (f / saleIqd) * Number(s.total_usd) : null);
                } catch (_eAmt) {
                    cashSales += saleIqd;
                    cashSalesUsd += toUsd(saleIqd, s, s.total_usd);
                }
                try {
                    readSaleOrReturnItems(s).forEach(function(i) {
                        var q = lineQty(i);
                        var lc = lineCost(i) * q;
                        totalCogs += lc;
                        totalCogsUsd += toUsd(lc, (i && (i.fx_usd_rate != null || i.exchange_rate != null)) ? i : s, (i && i.cost_usd != null ? Number(i.cost_usd) * q : null));
                        if (i && i.isGift) {
                            var gv = dailySummaryNum(i.price) * q;
                            gifts += gv;
                            giftsUsd += toUsd(gv, s, null);
                            giftsCount += q;
                        }
                    });
                } catch (_eL) {}
            });
            var totalReturns = 0, retCogs = 0, cashRefunds = 0;
            var totalReturnsUsd = 0, cashRefundsUsd = 0, retCogsUsd = 0;
            returns.forEach(function(r) {
                if (!r) return;
                var tot = dailySummaryNum(r.total);
                totalReturns += tot;
                totalReturnsUsd += toUsd(tot, r, r.total_usd);
                var pm = String(r.payment_method || '').toLowerCase();
                if (pm !== 'debt' && pm !== 'fib' && pm !== 'bank' && pm !== 'bankcard' && pm !== 'card') {
                    cashRefunds += tot;
                    cashRefundsUsd += toUsd(tot, r, r.total_usd);
                }
                try {
                    readSaleOrReturnItems(r).forEach(function(i) {
                        var lc = lineCost(i) * lineQty(i);
                        retCogs += lc;
                        retCogsUsd += toUsd(lc, r, (i && i.cost_usd != null ? Number(i.cost_usd) * lineQty(i) : null));
                    });
                } catch (_eR) {}
            });
            var opExp = 0, cashPurch = 0, companyDebt = 0;
            var opExpUsd = 0, cashPurchUsd = 0, companyDebtUsd = 0;
            expenses.forEach(function(e) {
                if (!e) return;
                var ty = e.type;
                var amt = (typeof expenseAmountIqd === 'function') ? expenseAmountIqd(e) : dailySummaryNum(e.amount);
                var u = (typeof expenseAmountUsd === 'function') ? expenseAmountUsd(e) : toUsd(amt, e);
                if (ty === 'purchase') { cashPurch += amt; cashPurchUsd += u; return; }
                if (ty === 'debt_payment') { companyDebt += amt; companyDebtUsd += u; return; }
                if (ty === 'purchase_return') return;
                if (ty && ty !== 'operational') return;
                opExp += amt;
                opExpUsd += u;
            });
            var debtIn = 0, debtInUsd = 0;
            cl.forEach(function(x) {
                if (!x) return;
                var ty = String(x.type || '').toLowerCase();
                if (ty !== 'payment' && ty !== 'pay') return;
                var ch = (typeof customerDebtPaymentChannel === 'function') ? customerDebtPaymentChannel(x) : 'cash';
                if (ch !== 'cash') return;
                var a = Math.abs(dailySummaryNum(x.amount));
                debtIn += a;
                debtInUsd += toUsd(a, x);
            });
            var wasteLoss = 0, wasteLossUsd = 0;
            waste.forEach(function(w) {
                if (!w) return;
                var c = dailySummaryNum(w.cost);
                wasteLoss += c;
                wasteLossUsd += toUsd(c, w);
            });
            var prIn = 0, prInUsd = 0;
            purchaseReturns.forEach(function(pr) {
                if (!pr) return;
                var p = (pr.cash_refunded != null && pr.cash_refunded !== '') ? dailySummaryNum(pr.cash_refunded) : dailySummaryNum(pr.total);
                prIn += p;
                prInUsd += toUsd(p, pr);
            });
            var gross = (totalSales - totalReturns) - (totalCogs - retCogs);
            var net = gross - opExp - wasteLoss;
            var move = (cashSales + debtIn + prIn) - (opExp + cashPurch + companyDebt + cashRefunds);
            return {
                totalSales: dailySummaryRound(totalSales),
                cashSales: dailySummaryRound(cashSales),
                debtSales: dailySummaryRound(debtSales),
                fibSales: dailySummaryRound(fibSales),
                totalReturns: dailySummaryRound(totalReturns),
                totalReturnsCost: dailySummaryRound(retCogs),
                totalCogs: dailySummaryRound(totalCogs),
                opExpenses: dailySummaryRound(opExp),
                cashPurchases: dailySummaryRound(cashPurch),
                fibPurchases: 0,
                companyDebtPayments: dailySummaryRound(companyDebt),
                debtPaymentsIn: dailySummaryRound(debtIn),
                purchaseReturnsIn: dailySummaryRound(prIn),
                totalPurchaseReturns: dailySummaryRound(prIn),
                grossProfit: dailySummaryRound(gross),
                netProfit: dailySummaryRound(net),
                cashMovement: dailySummaryRound(move),
                wasteLoss: dailySummaryRound(wasteLoss),
                wasteCount: waste.length,
                cashRefunds: dailySummaryRound(cashRefunds),
                totalGiftsValue: dailySummaryRound(gifts),
                giftsCount: giftsCount,
                totalSalesUsd: Math.round(totalSalesUsd * 100) / 100,
                cashSalesUsd: Math.round(cashSalesUsd * 100) / 100,
                debtSalesUsd: Math.round(debtSalesUsd * 100) / 100,
                fibSalesUsd: Math.round(fibSalesUsd * 100) / 100,
                totalReturnsUsd: Math.round(totalReturnsUsd * 100) / 100,
                totalCogsUsd: Math.round(totalCogsUsd * 100) / 100,
                opExpensesUsd: Math.round(opExpUsd * 100) / 100,
                cashPurchasesUsd: Math.round(cashPurchUsd * 100) / 100,
                companyDebtPaymentsUsd: Math.round(companyDebtUsd * 100) / 100,
                debtPaymentsInUsd: Math.round(debtInUsd * 100) / 100,
                purchaseReturnsInUsd: Math.round(prInUsd * 100) / 100,
                wasteLossUsd: Math.round(wasteLossUsd * 100) / 100,
                grossProfitUsd: Math.round(((totalSalesUsd - totalReturnsUsd) - (totalCogsUsd - retCogsUsd)) * 100) / 100,
                netProfitUsd: Math.round((((totalSalesUsd - totalReturnsUsd) - (totalCogsUsd - retCogsUsd)) - opExpUsd - wasteLossUsd) * 100) / 100,
                cashMovementUsd: Math.round(((cashSalesUsd + debtInUsd + prInUsd) - (opExpUsd + cashPurchUsd + companyDebtUsd + cashRefundsUsd)) * 100) / 100,
                cashRefundsUsd: Math.round(cashRefundsUsd * 100) / 100,
                totalGiftsValueUsd: Math.round(giftsUsd * 100) / 100
            };
        }

        function overlayServerDailyStats(metricsScoped, srvStats, opts) {
            if (!metricsScoped || !srvStats) return metricsScoped;
            opts = opts || {};
            var poolSales = dailySummaryNum(metricsScoped.totalSales);
            var poolHasSales = poolSales > 0.0001
                || dailySummaryNum(metricsScoped.cashSales) > 0.0001
                || dailySummaryNum(metricsScoped.debtSales) > 0.0001
                || dailySummaryNum(metricsScoped.fibSales) > 0.0001
                || (opts.poolSalesCount != null && Number(opts.poolSalesCount) > 0);
            var srvSales = srvStats.sales_total != null ? dailySummaryNum(srvStats.sales_total) : 0;
            var srvLooksEmpty = !(srvSales > 0.0001)
                && !(dailySummaryNum(srvStats.cash_sales) > 0.0001)
                && !(dailySummaryNum(srvStats.debt_sales) > 0.0001)
                && !(dailySummaryNum(srvStats.sale_count) > 0);
            if (poolHasSales && srvLooksEmpty) {
                return metricsScoped;
            }
            var applyIqd = function(destKey, srvKey) {
                if (srvStats[srvKey] == null || srvStats[srvKey] === '') return;
                var srv = dailySummaryNum(srvStats[srvKey]);
                var cur = dailySummaryNum(metricsScoped[destKey]);
                if (srv <= 0.0001 && cur > 0.0001) return;
                metricsScoped[destKey] = srv;
            };
            applyIqd('totalSales', 'sales_total');
            applyIqd('cashSales', 'cash_sales');
            applyIqd('debtSales', 'debt_sales');
            applyIqd('fibSales', 'fib_sales');
            if (srvStats.purchases_cash != null) metricsScoped.cashPurchases = dailySummaryNum(srvStats.purchases_cash);
            if (srvStats.purchases_fib != null) metricsScoped.fibPurchases = dailySummaryNum(srvStats.purchases_fib);
            if (srvStats.purchases_total != null) metricsScoped.totalPurchases = dailySummaryNum(srvStats.purchases_total);
            if (srvStats.op_expenses != null) metricsScoped.opExpenses = dailySummaryNum(srvStats.op_expenses);
            if (srvStats.returns_total != null) metricsScoped.totalReturns = dailySummaryNum(srvStats.returns_total);
            if (srvStats.cash_refunds != null) metricsScoped.cashRefunds = dailySummaryNum(srvStats.cash_refunds);
            if (srvStats.debt_payments_in != null) metricsScoped.debtPaymentsIn = dailySummaryNum(srvStats.debt_payments_in);
            if (srvStats.waste_loss != null) metricsScoped.wasteLoss = dailySummaryNum(srvStats.waste_loss);
            if (srvStats.total_cogs != null && dailySummaryNum(srvStats.total_cogs) > 0) {
                metricsScoped.totalCogs = dailySummaryNum(srvStats.total_cogs);
            }
            applyIqd('netProfit', 'net_profit');
            applyIqd('cashMovement', 'cash_movement');
            if (srvStats.sales_usd != null) metricsScoped.totalSalesUsd = dailySummaryNum(srvStats.sales_usd);
            if (srvStats.cash_sales_usd != null) metricsScoped.cashSalesUsd = dailySummaryNum(srvStats.cash_sales_usd);
            if (srvStats.debt_sales_usd != null) metricsScoped.debtSalesUsd = dailySummaryNum(srvStats.debt_sales_usd);
            if (srvStats.fib_sales_usd != null) metricsScoped.fibSalesUsd = dailySummaryNum(srvStats.fib_sales_usd);
            if (srvStats.expenses_usd != null) metricsScoped.opExpensesUsd = dailySummaryNum(srvStats.expenses_usd);
            if (srvStats.returns_usd != null) metricsScoped.totalReturnsUsd = dailySummaryNum(srvStats.returns_usd);
            if (srvStats.total_cogs_usd != null) metricsScoped.totalCogsUsd = dailySummaryNum(srvStats.total_cogs_usd);
            if (srvStats.net_profit_usd != null) metricsScoped.netProfitUsd = dailySummaryNum(srvStats.net_profit_usd);
            if (srvStats.cash_movement_usd != null) metricsScoped.cashMovementUsd = dailySummaryNum(srvStats.cash_movement_usd);
            if (srvStats.cash_drawer_usd != null) metricsScoped.cashDrawerUsd = dailySummaryNum(srvStats.cash_drawer_usd);
            if (srvStats.purchases_total_usd != null) metricsScoped.totalPurchasesUsd = dailySummaryNum(srvStats.purchases_total_usd);
            if (srvStats.purchases_cash_usd != null) metricsScoped.cashPurchasesUsd = dailySummaryNum(srvStats.purchases_cash_usd);
            if (srvStats.debt_payments_in_usd != null) metricsScoped.debtPaymentsInUsd = dailySummaryNum(srvStats.debt_payments_in_usd);
            if (srvStats.company_debt_payments_usd != null) metricsScoped.companyDebtPaymentsUsd = dailySummaryNum(srvStats.company_debt_payments_usd);
            if (srvStats.metrics_engine) metricsScoped.metrics_engine = srvStats.metrics_engine;
            var cashIn = (metricsScoped.cashSales || 0) + (metricsScoped.debtPaymentsIn || 0) + (metricsScoped.purchaseReturnsIn || 0);
            var cashOut = (metricsScoped.opExpenses || 0) + (metricsScoped.cashPurchases || 0) + (metricsScoped.companyDebtPayments || 0) + (metricsScoped.cashRefunds || 0);
            if (srvStats.cash_movement == null) {
                metricsScoped.cashMovement = dailySummaryRound(cashIn - cashOut);
            }
            return metricsScoped;
        }

        function hydrateDailyPoolItems(pools) {
            var _db = dailySummaryDb();
            if (!pools || !_db) return;
            var mapById = function(list) {
                var m = {};
                (list || []).forEach(function(s) {
                    if (s && s.id != null) m[String(s.id)] = s;
                });
                return m;
            };
            var fill = function(poolRows, localMap) {
                (poolRows || []).forEach(function(row) {
                    if (!row) return;
                    var items = readSaleOrReturnItems(row);
                    if (items.length) {
                        row.items = items;
                        return;
                    }
                    var loc = localMap[String(row.id)];
                    var locItems = loc ? readSaleOrReturnItems(loc) : [];
                    if (locItems.length) row.items = locItems;
                });
            };
            fill(pools.sales, mapById(_db.sales));
            fill(pools.returns, mapById(_db.returns));
        }

        function applyDailyDetailFromServer(dd, todayIso, todayPretty, rangeOpts) {
            try {
            if (!dd || dd.status !== 'ok' || !dd.pools) return false;
            rangeOpts = rangeOpts || {};
            var dateFrom = rangeOpts.dateFrom || dd.date_from || todayIso;
            var dateTo = rangeOpts.dateTo || dd.date_to || todayIso;
            var pools = dd.pools;
            try { hydrateDailyPoolItems(pools); } catch (_eHyd) {}
            ['sales', 'returns', 'purchase_returns'].forEach(function(k) {
                if (Array.isArray(pools[k])) {
                    pools[k].forEach(function(row) {
                        if (row.items && typeof row.items === 'object' && !Array.isArray(row.items)) {
                            row.items = Object.keys(row.items).map(function(x) { return row.items[x]; });
                        }
                    });
                }
            });
            var metricsScoped = computeDailyModalMetrics(pools);
            if (!metricsScoped) {
                metricsScoped = { totalSales: 0, cashSales: 0, debtSales: 0, fibSales: 0 };
            }
            var srvStats = (dd && dd.stats && typeof dd.stats === 'object') ? dd.stats : null;
            var poolSalesCount = Array.isArray(pools.sales) ? pools.sales.length : 0;
            overlayServerDailyStats(metricsScoped, srvStats, { poolSalesCount: poolSalesCount });
            if (srvStats && !(dailySummaryNum(metricsScoped.totalSales) > 0.0001) && dailySummaryNum(srvStats.sales_total) > 0.0001) {
                metricsScoped.totalSales = dailySummaryNum(srvStats.sales_total);
                if (srvStats.cash_sales != null) metricsScoped.cashSales = dailySummaryNum(srvStats.cash_sales);
                if (srvStats.debt_sales != null) metricsScoped.debtSales = dailySummaryNum(srvStats.debt_sales);
                if (srvStats.fib_sales != null) metricsScoped.fibSales = dailySummaryNum(srvStats.fib_sales);
                if (srvStats.net_profit != null && srvStats.net_profit !== '') metricsScoped.netProfit = dailySummaryNum(srvStats.net_profit);
                if (srvStats.cash_movement != null) metricsScoped.cashMovement = dailySummaryNum(srvStats.cash_movement);
                if (srvStats.sales_usd != null) metricsScoped.totalSalesUsd = dailySummaryNum(srvStats.sales_usd);
                if (srvStats.metrics_engine) metricsScoped.metrics_engine = srvStats.metrics_engine;
            }
            var _dbApply = dailySummaryDb();
            var daySalesScoped = pools.sales || [];
            var dayExpensesListSrv = pools.expenses || [];
            if (typeof mergeCompanyDebtExpensesFromLedger === 'function') {
                try {
                    dayExpensesListSrv = mergeCompanyDebtExpensesFromLedger(dayExpensesListSrv, pools.ledger || [], (_dbApply && _dbApply.companies) ? _dbApply.companies : []);
                } catch (_eMerg) {}
            }
            var ovExSrv;
            if (currentUser && currentUser.role !== 'admin' && currentUser.role !== 'manager') {
                if (Array.isArray(dayExpensesListSrv) && dayExpensesListSrv.length) {
                    ovExSrv = dayExpensesListSrv.filter(function(x) {
                        if (!x || (currentUser && x.user !== currentUser.name)) return false;
                        return typeof isOperationalExpenseRow === 'function' ? isOperationalExpenseRow(x) : (!x.type || x.type === 'operational');
                    }).reduce(function(a, x) {
                        return a + (parseFloat(x.amount) || 0);
                    }, 0);
                }
            }
            var lastRcSrv = '';
            if (currentUser && (currentUser.role === 'admin' || currentUser.role === 'manager') && dd.last_receipt_id_shop != null && dd.last_receipt_id_shop !== '') {
                lastRcSrv = String(dd.last_receipt_id_shop);
            } else {
                lastRcSrv = dailySummaryLastReceiptMax(daySalesScoped);
            }
            var dayCustomerDebtListSrv = (pools.customer_ledger || []).filter(function(cl) {
                return (typeof isCustomerDebtPaymentRow === 'function') ? isCustomerDebtPaymentRow(cl) : (cl && (cl.type === 'payment' || cl.type === 'pay'));
            });
            var dayPurchaseReturnsListSrv = pools.purchase_returns || [];
            var dayPurchasesListSrv = typeof filterReportablePurchases === 'function'
                ? filterReportablePurchases(pools.supplies || [])
                : (pools.supplies || []);
            var dayReturnsDisplaySrv = [];
            try {
                dayReturnsDisplaySrv = mergeVoidedSalesIntoDailyReturns(pools.returns || [], dateFrom, pools.voided_sales || [], dateTo);
            } catch (_eRetS) {
                dayReturnsDisplaySrv = pools.returns || [];
            }
            var dayWasteListSrv = Array.isArray(pools.waste) ? pools.waste.slice() : [];
            if (!dayWasteListSrv.length && _dbApply && Array.isArray(_dbApply.waste)) {
                dayWasteListSrv = _dbApply.waste.filter(function(w) {
                    var d = '';
                    try { d = getBusinessDate(parseSQLDate(w.date)); } catch (_eW) {}
                    if (!d && w && w.date) d = String(w.date).slice(0, 10);
                    return d >= dateFrom && d <= dateTo;
                });
            }
            return finalizeDailyModalContent(dateFrom, todayPretty, {
                metricsScoped: metricsScoped,
                dayPools: pools,
                daySalesScoped: daySalesScoped,
                dayExpensesList: dayExpensesListSrv,
                dayReturnsList: dayReturnsDisplaySrv,
                dayVoidedPurchasesList: pools.voided_purchases || [],
                dayPurchaseReturnsList: dayPurchaseReturnsListSrv,
                dayPurchasesList: dayPurchasesListSrv,
                dayLedgerList: pools.ledger || [],
                dayShifts: pools.shifts || [],
                dayCustomerDebtList: dayCustomerDebtListSrv,
                dayWasteList: dayWasteListSrv,
                dayDeliveriesList: pools.deliveries || [],
                lastReceiptIdShop: lastRcSrv,
                overrideTotalExpenses: ovExSrv,
                serverPurchaseStats: srvStats,
                serverPurchaseInvoices: Array.isArray(dd.purchase_invoices) ? dd.purchase_invoices : [],
                usedLocalFallback: false,
                dateFrom: dateFrom,
                dateTo: dateTo
            });
            } catch (_eApplyAll) {
                try { console.error('applyDailyDetailFromServer', _eApplyAll); } catch (_eLog) {}
                return false;
            }
        }

        window.applyDailyDetailFromServer = applyDailyDetailFromServer;
        window.buildDailySummaryFromLocal = buildDailySummaryFromLocal;
        window.buildDailyPurchaseDisplay = buildDailyPurchaseDisplay;

        function buildDailySummaryFromLocal(todayIso, todayPretty, selectedUser, rangeOpts) {
            try {
            var _db = dailySummaryDb();
            if (!_db) return false;
            rangeOpts = rangeOpts || {};
            var dateFrom = rangeOpts.dateFrom || todayIso;
            var dateTo = rangeOpts.dateTo || todayIso;
            var inRange = function(raw) {
                var keys = [];
                var s = String(raw || '');
                if (s.length >= 10) keys.push(s.slice(0, 10));
                try {
                    if (typeof getBusinessDate === 'function' && typeof parseSQLDate === 'function') {
                        var bd = getBusinessDate(parseSQLDate(raw));
                        if (bd) keys.push(bd);
                    }
                } catch (_eBiz) {}
                for (var i = 0; i < keys.length; i++) {
                    if (keys[i] >= dateFrom && keys[i] <= dateTo) return true;
                }
                return false;
            };
            var filterUser = selectedUser && selectedUser !== 'all' ? selectedUser : null;
            // Date-scoped local sales only (db.sales) — never full archive via getReportSales/getAllSales
            var daySalesScoped = [];
            try {
                var salesSrc = (_db.sales || []);
                var maxScan = 4000;
                var startIdx = Math.max(0, salesSrc.length - maxScan);
                for (var si = startIdx; si < salesSrc.length; si++) {
                    var sRow = salesSrc[si];
                    if (!sRow) continue;
                    if (sRow.is_returned == 1 || sRow.is_returned === true || sRow.is_returned === '1') continue;
                    if (!inRange(sRow.date || sRow.created_at)) continue;
                    daySalesScoped.push(sRow);
                }
            } catch (_eSales) {
                daySalesScoped = [];
            }
            var dayExpensesAll = (_db.expenses || []).filter(function(e) {
                return inRange(e.date);
            });
            var dayLedgerLoc = (_db.ledger || []).filter(function(l) {
                return inRange(l.date || l.created_at);
            });
            var dayReturnsLoc = (_db.returns || []).filter(function(r) {
                return inRange(r.date);
            });
            var dayReturnsDisplayLoc = [];
            try {
                dayReturnsDisplayLoc = mergeVoidedSalesIntoDailyReturns(dayReturnsLoc, dateFrom, null, dateTo);
            } catch (_eRetM) {
                dayReturnsDisplayLoc = dayReturnsLoc;
            }
            var dayPurchaseReturnsLoc = (_db.purchase_returns || []).filter(function(pr) {
                return inRange(pr.date);
            });
            var dayPurchasesLoc;
            if (dateFrom === dateTo && typeof getReportPurchasesForDate === 'function') {
                try { dayPurchasesLoc = getReportPurchasesForDate(dateFrom); } catch (_eP) { dayPurchasesLoc = []; }
            } else {
                var poolPurch = typeof filterReportablePurchases === 'function' ? filterReportablePurchases(_db.supplies) : (_db.supplies || []);
                dayPurchasesLoc = (poolPurch || []).filter(function(s) { return inRange(s.date); });
            }
            var dayCustomerDebtLoc = (_db.customer_ledger || []).filter(function(cl) {
                if (!cl) return false;
                var isPay = (typeof isCustomerDebtPaymentRow === 'function') ? isCustomerDebtPaymentRow(cl) : (cl.type === 'payment' || cl.type === 'pay');
                return isPay && inRange(cl.date || cl.created_at);
            });
            
            if (currentUser && currentUser.role !== 'admin' && currentUser.role !== 'manager') {
                filterUser = currentUser.name;
            }
            
            if (filterUser) {
                daySalesScoped = daySalesScoped.filter(function(s) { return s.cashier === filterUser; });
                dayReturnsLoc = dayReturnsLoc.filter(function(r) { return r.cashier === filterUser; });
                dayPurchaseReturnsLoc = dayPurchaseReturnsLoc.filter(function(pr) { return pr.user === filterUser; });
                dayExpensesAll = dayExpensesAll.filter(function(e) { return e.user === filterUser; });
                dayReturnsDisplayLoc = dayReturnsDisplayLoc.filter(function(r) { return r.cashier === filterUser; });
                // وەرگرتنا قەرزی کریار → قاسە (هەمی دوکان) — فیلترێن user مەکە؛ بەریا ڤێ گۆڕینێ هەمی پارە دسڕان
            }

            if (typeof mergeCompanyDebtExpensesFromLedger === 'function') {
                try {
                    dayExpensesAll = mergeCompanyDebtExpensesFromLedger(dayExpensesAll, dayLedgerLoc, _db.companies || []);
                } catch (_eMergL) {}
            }
            var dayWasteListLoc = (_db.waste || []).filter(function(w) {
                if (!inRange(w.date)) return false;
                if (filterUser && w.user !== filterUser) return false;
                return true;
            });
            var metricsScoped = computeDailyModalMetrics({
                sales: daySalesScoped,
                expenses: dayExpensesAll,
                returns: dayReturnsLoc,
                purchase_returns: dayPurchaseReturnsLoc,
                ledger: dayLedgerLoc,
                customer_ledger: dayCustomerDebtLoc,
                supplies: dayPurchasesLoc,
                waste: dayWasteListLoc
            });
            if (!metricsScoped) return false;
            var dayExpensesListLoc = dayExpensesAll;
            var ovEx;
            if (filterUser && dayExpensesListLoc.length) {
                ovEx = dayExpensesListLoc.filter(function(x) {
                    return typeof isOperationalExpenseRow === 'function' ? isOperationalExpenseRow(x) : (!x || !x.type || x.type === 'operational');
                }).reduce(function(a, x) {
                    return a + (parseFloat(x.amount) || 0);
                }, 0);
            }
            var dayShiftsLoc = (_db.shifts || []).filter(function(s) {
                return inRange(s.startTime || s.start_time);
            });
            var lastRc = dailySummaryLastReceiptMax(daySalesScoped);
            var localPools = {
                sales: daySalesScoped,
                expenses: dayExpensesListLoc,
                returns: dayReturnsDisplayLoc,
                purchase_returns: dayPurchaseReturnsLoc,
                supplies: dayPurchasesLoc,
                ledger: dayLedgerLoc,
                customer_ledger: dayCustomerDebtLoc,
                waste: dayWasteListLoc
            };
            return finalizeDailyModalContent(dateFrom, todayPretty, {
                metricsScoped: metricsScoped,
                dayPools: localPools,
                daySalesScoped: daySalesScoped,
                dayExpensesList: dayExpensesListLoc,
                dayReturnsList: dayReturnsDisplayLoc,
                dayVoidedPurchasesList: [],
                dayPurchaseReturnsList: dayPurchaseReturnsLoc,
                dayPurchasesList: dayPurchasesLoc,
                dayLedgerList: dayLedgerLoc,
                dayShifts: dayShiftsLoc,
                dayCustomerDebtList: dayCustomerDebtLoc,
                dayWasteList: dayWasteListLoc,
                dayDeliveriesList: (_db.deliveries || []).filter(function(d) {
                    if (!d) return false;
                    return inRange(d.date) || (d.settled_at && inRange(d.settled_at));
                }),
                lastReceiptIdShop: lastRc,
                overrideTotalExpenses: ovEx,
                usedLocalFallback: false,
                dateFrom: dateFrom,
                dateTo: dateTo
            });
            } catch (_eLocalAll) {
                return false;
            }
        }

