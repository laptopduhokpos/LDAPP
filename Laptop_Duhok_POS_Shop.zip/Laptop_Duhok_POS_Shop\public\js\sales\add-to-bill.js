// sales/add-to-bill.js — quick define, add to bill
        // --- QUICK DEFINE FUNCTIONS ---
        function applyQdModalLanguage(modal) {
            if (!modal) return;
            var tFn = function(k, fb) {
                if (typeof t !== 'function') return fb || k;
                var v = t(k);
                return (v && v !== k) ? v : (fb || k);
            };
            var titleEl = document.getElementById('qd-title');
            var hintEl = modal.querySelector('.qd-modal-hint');
            var pricingTitle = document.getElementById('qd-pricing-section-title');
            var saveLbl = document.getElementById('qd-save-sell-label');
            if (titleEl) titleEl.textContent = tFn('qd_modal_title', 'پێناسەکرنا ئایتمێ نوی');
            if (hintEl) hintEl.textContent = tFn('qd_modal_hint', 'ئەڤ بارکۆدە نەهاتە دیتن. تو دشێی نوکە پێناسە بکەی.');
            if (pricingTitle) pricingTitle.textContent = tFn('qd_section_pricing', 'نرخ، کرین و کۆگە');
            if (saveLbl) saveLbl.textContent = tFn('qd_save_purchase', 'پاراستن & کڕین');
            var editLbl = modal.querySelector('[data-i18n="qd_save_edit"]');
            if (editLbl) editLbl.textContent = tFn('qd_save_edit', 'پاراستن & دەستکاری');
            var autoLbl = document.getElementById('qd-auto-price-label');
            if (typeof qdApplyAutoTogglesUi === 'function') qdApplyAutoTogglesUi();
            else if (autoLbl) {
                var autoOn = document.getElementById('qd-auto-price') && document.getElementById('qd-auto-price').value !== '0';
                autoLbl.textContent = tFn(autoOn ? 'qd_auto_price_on' : 'qd_auto_price_off', autoOn ? 'فرۆتن: خۆکار' : 'فرۆتن: دەستی');
            }
            modal.querySelectorAll('[data-i18n]').forEach(function(el) {
                var key = el.getAttribute('data-i18n');
                if (key) el.textContent = tFn(key, el.textContent);
            });
            var nameInput = document.getElementById('qd-name');
            if (nameInput) nameInput.placeholder = tFn('product_form_name_placeholder', 'ناڤ');
        }
        function populateQdCategorySelect(selectedName) {
            var catSel = document.getElementById('qd-category');
            if (!catSel) return;
            var prev = selectedName != null ? selectedName : catSel.value;
            var cats = [];
            if (db.categories && db.categories.length) {
                cats = db.categories.slice();
            } else if (db.products && db.products.length) {
                db.products.forEach(function(p) {
                    var c = (p.category || p.cat || '').trim();
                    if (c && cats.indexOf(c) === -1) cats.push(c);
                });
            }
            if (cats.indexOf('General') === -1) cats.unshift('General');
            if (!cats.length) cats = ['General'];
            catSel.innerHTML = cats.map(function(c) {
                return '<option value="' + escapeHtml(c) + '">' + escapeHtml(c) + '</option>';
            }).join('');
            if (prev && cats.indexOf(prev) >= 0) catSel.value = prev;
        }
        window.populateQdCategorySelect = populateQdCategorySelect;
        function populateQdSupplierSelect(selectedName) {
            const select = document.getElementById('qd-supplier');
            if (!select) return;
            var prev = selectedName != null ? selectedName : select.value;
            var tFn = function(k, fb) {
                if (typeof t !== 'function') return fb || k;
                var v = t(k);
                return (v && v !== k) ? v : (fb || k);
            };
            var directLbl = tFn('product_form_supplier_direct', 'Direct Store');
            var directVal = 'Direct Store';
            select.innerHTML = '<option value="' + escapeHtml(directVal) + '">' + escapeHtml(directLbl.replace(' / —', '').trim() || directVal) + '</option>';
            if (db.companies) {
                db.companies.forEach(function(c) {
                    select.innerHTML += '<option value="' + escapeHtml(c.name) + '">' + escapeHtml(c.name) + '</option>';
                });
            }
            if (prev) select.value = prev;
        }
        window.populateQdSupplierSelect = populateQdSupplierSelect;
        window.qdQuickAddCategory = function() {
            if (typeof openPosEntityNamePrompt === 'function') {
                openPosEntityNamePrompt({
                    entityType: 'category',
                    icon: 'fa-tags',
                    iconTone: 'category',
                    onConfirm: function(data) {
                        var name = data && data.name ? String(data.name).trim() : '';
                        if (!name) return;
                        var formData = new FormData();
                        formData.append('action', 'add_category');
                        formData.append('name', name);
                        fetch('?action=add_category', { method: 'POST', body: formData })
                        .then(function() {
                            if (db && db.categories && db.categories.indexOf(name) === -1) db.categories.push(name);
                            populateQdCategorySelect(name);
                            if (typeof renderCategorySelect === 'function') renderCategorySelect();
                            if (typeof connectToDB === 'function') connectToDB(true);
                            if (typeof showToast === 'function') showToast('✅ پۆل هاتە زێدەکرن!');
                        })
                        .catch(function(err) {
                            if (typeof showToast === 'function') showToast('❌ هەڵە: ' + (err && err.message ? err.message : err), 'error');
                        });
                    }
                });
                return;
            }
            var raw = prompt('ناڤێ پۆلێ نوێ:');
            if (!raw || !raw.trim()) return;
            var formData = new FormData();
            formData.append('action', 'add_category');
            formData.append('name', raw.trim());
            fetch('?action=add_category', { method: 'POST', body: formData }).then(function() {
                if (db && db.categories && db.categories.indexOf(raw.trim()) === -1) db.categories.push(raw.trim());
                populateQdCategorySelect(raw.trim());
                if (typeof showToast === 'function') showToast('✅ پۆل هاتە زێدەکرن!');
            });
        };
        window.qdQuickAddSupplier = function() {
            if (typeof quickAddCompany === 'function') {
                quickAddCompany();
                return;
            }
            if (typeof openPosEntityNamePrompt === 'function') {
                openPosEntityNamePrompt({
                    entityType: 'supplier',
                    icon: 'fa-building',
                    iconTone: 'supplier',
                    onConfirm: function(data) {
                        var name = data && data.name ? String(data.name).trim() : '';
                        if (!name) return;
                        var formData = new FormData();
                        formData.append('action', 'save_company');
                        formData.append('name', name);
                        formData.append('phone', String(data.phone || '').trim());
                        formData.append('address', String(data.address || '').trim());
                        formData.append('opening_balance', parseFloat(data.opening_balance) || 0);
                        formData.append('debt_limit', parseFloat(data.debt_limit) || 0);
                        fetch('?action=save_company', { method: 'POST', body: formData })
                        .then(function(res) { return res.json(); })
                        .then(function(resp) {
                            if (resp.status === 'success') {
                                if (!db.companies) db.companies = [];
                                db.companies.push({ id: resp.id, name: name, phone: data.phone || '', address: data.address || '', balance: 0 });
                                populateQdSupplierSelect(name);
                                if (typeof showToast === 'function') showToast('✅ دابینکەر هاتە زێدەکرن!');
                            }
                        });
                    }
                });
            }
        };
        function qdGetBarcodeValue() {
            var bcInput = document.getElementById('qd-barcode-input');
            var bcDisplay = document.getElementById('qd-barcode-display');
            if (bcInput && !bcInput.classList.contains('is-hidden')) {
                return String(bcInput.value || '').trim();
            }
            return bcDisplay ? String(bcDisplay.dataset.val || bcDisplay.textContent || '').trim() : '';
        }
        function qdSetBarcodeValue(val) {
            var bcDisplay = document.getElementById('qd-barcode-display');
            var bcInput = document.getElementById('qd-barcode-input');
            var bcRef = document.getElementById('qd-piece-barcode-ref');
            if (bcDisplay) {
                bcDisplay.textContent = val || '—';
                bcDisplay.dataset.val = val || '';
            }
            if (bcInput) bcInput.value = val || '';
            if (bcRef) {
                if (bcRef.tagName === 'INPUT' || bcRef.tagName === 'TEXTAREA') {
                    if (document.activeElement !== bcRef) bcRef.value = val || '';
                } else {
                    bcRef.textContent = val || '—';
                }
            }
            if (typeof qdSyncInheritedLevelBarcodes === 'function') qdSyncInheritedLevelBarcodes();
        }
        window.qdSyncBarcodeFromPieceCell = function qdSyncBarcodeFromPieceCell() {
            var el = document.getElementById('qd-piece-barcode-ref');
            if (!el || (el.tagName !== 'INPUT' && el.tagName !== 'TEXTAREA')) return;
            var val = String(el.value || '').trim();
            qdSetBarcodeValue(val);
        };
        window.qdToggleBarcodeEdit = function qdToggleBarcodeEdit(forceSave) {
            var bcDisplay = document.getElementById('qd-barcode-display');
            var bcInput = document.getElementById('qd-barcode-input');
            var btn = document.getElementById('btn-qd-edit-barcode');
            if (!bcDisplay || !bcInput) return;
            var editing = !bcInput.classList.contains('is-hidden');
            if (editing || forceSave === true) {
                var val = String(bcInput.value || '').trim();
                if (!val) {
                    if (typeof showToast === 'function') showToast('⚠️ ' + qdT('product_form_label_barcode', 'بارکۆد') + ' — ' + qdT('product_new_requires_name', 'پێویستە'), 'warning');
                    bcInput.focus();
                    return;
                }
                qdSetBarcodeValue(val);
                bcInput.classList.add('is-hidden');
                bcDisplay.classList.remove('is-hidden');
                if (btn) btn.classList.remove('is-active');
            } else {
                bcInput.value = bcDisplay.dataset.val || bcDisplay.textContent || '';
                bcDisplay.classList.add('is-hidden');
                bcInput.classList.remove('is-hidden');
                if (btn) btn.classList.add('is-active');
                setTimeout(function() { bcInput.focus(); bcInput.select(); }, 50);
            }
        };
        function qdT(key, fb) {
            if (typeof t !== 'function') return fb || key;
            var v = t(key);
            return (v && v !== key) ? v : (fb || key);
        }
        function qdGetConversionFactors() {
            var showPackEl = document.getElementById('qd-unit-show-pack');
            var showCartonEl = document.getElementById('qd-unit-show-carton');
            var vp = !!(showPackEl && showPackEl.value === '1');
            var vc = !!(showCartonEl && showCartonEl.value === '1');
            var unitStructure = (vp && vc) || (vp && !vc) ? 'carton_pack_piece' : (vc ? 'carton_piece' : 'piece');
            var pppEl = document.getElementById('qd-pieces-per-pack');
            var ppcEl = document.getElementById('qd-packs-per-carton');
            var ppp = pppEl ? (parseInt(pppEl.value, 10) || 1) : 1;
            var ppc = ppcEl ? (parseInt(ppcEl.value, 10) || 1) : 1;
            if (unitStructure === 'carton_piece') {
                ppp = 1;
                ppc = Math.max(1, pppEl ? (parseInt(pppEl.value, 10) || 1) : 1);
            }
            if (!vp && vc) ppc = Math.max(1, ppc);
            if (!vp && !vc) { ppp = 1; ppc = 1; }
            return {
                unitStructure: unitStructure,
                vp: vp,
                vc: vc,
                ppp: Math.max(1, ppp),
                ppc: Math.max(1, ppc),
                piecesPerCarton: Math.max(1, ppp * ppc)
            };
        }
        function qdFormatDerived(n) {
            if (typeof productFormFormatDerivedField === 'function') return productFormFormatDerivedField(n);
            if (!isFinite(n)) return '';
            return String(Math.round(n));
        }
        function qdParseMoneyInput(el) {
            if (!el) return 0;
            return parseFloat(String(el.value || '').replace(/,/g, '')) || 0;
        }
        function qdMarkDerived(el, val, fmt) {
            if (!el) return;
            el.value = fmt(val);
            el.classList.add('is-auto-filled');
        }
        function qdSyncOneMoneyGroup(sourceId, pieceId, packId, cartonId, fmt, f) {
            var pieceEl = document.getElementById(pieceId);
            var packEl = document.getElementById(packId);
            var cartonEl = document.getElementById(cartonId);
            var piece = qdParseMoneyInput(pieceEl);
            var pack = qdParseMoneyInput(packEl);
            var carton = qdParseMoneyInput(cartonEl);
            var convFieldIds = { 'qd-pieces-per-pack': 1, 'qd-packs-per-carton': 1 };
            var fromConv = !!(sourceId && convFieldIds[sourceId]);
            if (!sourceId || fromConv) {
                if (piece > 0) sourceId = pieceId;
                else if (carton > 0) sourceId = cartonId;
                else if (pack > 0) sourceId = packId;
                else if (fromConv) return;
            }
            if (sourceId === cartonId && f.vc && f.piecesPerCarton > 0 && carton > 0) {
                qdMarkDerived(pieceEl, carton / f.piecesPerCarton, fmt);
                if (f.vp && f.ppp > 0 && f.unitStructure === 'carton_pack_piece' && packEl) {
                    qdMarkDerived(packEl, carton / f.ppc, fmt);
                }
            } else if (sourceId === packId && f.vp && f.ppp > 0 && pack > 0 && f.unitStructure === 'carton_pack_piece') {
                qdMarkDerived(pieceEl, pack / f.ppp, fmt);
                if (f.vc && cartonEl) qdMarkDerived(cartonEl, pack * f.ppc, fmt);
            } else if (sourceId === pieceId && piece > 0) {
                if (f.vp && packEl) qdMarkDerived(packEl, piece * f.ppp, fmt);
                if (f.vc && cartonEl) qdMarkDerived(cartonEl, piece * f.piecesPerCarton, fmt);
            }
        }
        function qdGetAutoCostPrefFromStorage() {
            try {
                var v = localStorage.getItem('qd_auto_cost');
                if (v === '0') return false;
                if (v === '1') return true;
            } catch (e) {}
            return true;
        }
        function qdGetAutoPricePrefFromStorage() {
            try {
                var v = localStorage.getItem('qd_auto_price');
                if (v === '0') return false;
                if (v === '1') return true;
            } catch (e) {}
            return true;
        }
        function qdSetAutoCostPref(checked) {
            try { localStorage.setItem('qd_auto_cost', checked ? '1' : '0'); } catch (e) {}
            var el = document.getElementById('qd-auto-cost');
            if (el) el.value = checked ? '1' : '0';
        }
        function qdSetAutoPricePref(checked) {
            try { localStorage.setItem('qd_auto_price', checked ? '1' : '0'); } catch (e) {}
            var el = document.getElementById('qd-auto-price');
            if (el) el.value = checked ? '1' : '0';
        }
        function qdIsAutoCostOn() {
            var el = document.getElementById('qd-auto-cost');
            return !el || el.value !== '0';
        }
        function qdIsAutoPriceOn() {
            var el = document.getElementById('qd-auto-price');
            return !el || el.value !== '0';
        }
        function qdUpdateAutoToggleBtn(btnId, lblId, on, onKey, offKey, fbOn, fbOff) {
            var btn = document.getElementById(btnId);
            var lbl = document.getElementById(lblId);
            if (btn) btn.classList.toggle('is-on', on);
            if (lbl) lbl.textContent = qdT(on ? onKey : offKey, on ? fbOn : fbOff);
        }
        function qdClearAutoFilled(ids) {
            ids.forEach(function(id) {
                var inp = document.getElementById(id);
                if (inp) inp.classList.remove('is-auto-filled');
            });
        }
        function qdApplyAutoTogglesUi() {
            qdUpdateAutoToggleBtn('btn-qd-auto-cost', 'qd-auto-cost-label', qdIsAutoCostOn(), 'qd_auto_cost_on', 'qd_auto_cost_off', 'کڕین: خۆکار', 'کڕین: دەستی');
            qdUpdateAutoToggleBtn('btn-qd-auto-price', 'qd-auto-price-label', qdIsAutoPriceOn(), 'qd_auto_price_on', 'qd_auto_price_off', 'فرۆتن: خۆکار', 'فرۆتن: دەستی');
        }
        function qdLoadAutoPrefsFromStorage() {
            qdSetAutoCostPref(qdGetAutoCostPrefFromStorage());
            qdSetAutoPricePref(qdGetAutoPricePrefFromStorage());
            qdApplyAutoTogglesUi();
        }
        window.qdToggleAutoCost = function qdToggleAutoCost() {
            var wasOn = qdIsAutoCostOn();
            qdSetAutoCostPref(!wasOn);
            qdApplyAutoTogglesUi();
            if (!wasOn) qdSyncFromLevel();
            else qdClearAutoFilled(['qd-cost-pack', 'qd-cost-carton']);
        };
        window.qdToggleAutoPrice = function qdToggleAutoPrice() {
            var wasOn = qdIsAutoPriceOn();
            qdSetAutoPricePref(!wasOn);
            qdApplyAutoTogglesUi();
            if (!wasOn) qdSyncFromLevel();
            else qdClearAutoFilled(['qd-price-pack', 'qd-price-carton']);
        };
        var _qdSyncFromLevelLock = false;
        window.qdSyncFromLevel = function qdSyncFromLevel(sourceId) {
            if (_qdSyncFromLevelLock) return;
            _qdSyncFromLevelLock = true;
            try {
                if (sourceId) {
                    var srcEl = document.getElementById(sourceId);
                    if (srcEl) srcEl.classList.remove('is-auto-filled');
                }
                var fmt = qdFormatDerived;
                var f = qdGetConversionFactors();
                if (!sourceId && document.activeElement && document.activeElement.id) sourceId = document.activeElement.id;
                if (qdIsAutoPriceOn()) {
                    qdSyncOneMoneyGroup(sourceId, 'qd-price', 'qd-price-pack', 'qd-price-carton', fmt, f);
                }
                if (qdIsAutoCostOn()) {
                    qdSyncOneMoneyGroup(sourceId, 'qd-cost', 'qd-cost-pack', 'qd-cost-carton', fmt, f);
                }
            } finally {
                _qdSyncFromLevelLock = false;
            }
        };
        function qdUpdateConvPreview() {
            var el = document.getElementById('qd-conv-preview');
            if (!el) return;
            var f = qdGetConversionFactors();
            if (!f.vp && !f.vc) { el.textContent = ''; return; }
            if (f.vp && f.vc) {
                el.textContent = '1 کارتۆن = ' + f.ppc + ' پاکێت = ' + f.piecesPerCarton + ' دانە';
            } else if (f.vc) {
                el.textContent = '1 کارتۆن = ' + f.piecesPerCarton + ' دانە';
            } else {
                el.textContent = '1 پاکێت = ' + f.ppp + ' دانە';
            }
        }
        function qdUpdateConvLabels() {
            var showPackEl = document.getElementById('qd-unit-show-pack');
            var showCartonEl = document.getElementById('qd-unit-show-carton');
            var showPack = showPackEl && showPackEl.value === '1';
            var showCarton = showCartonEl && showCartonEl.value === '1';
            var pppWrap = document.getElementById('qd-conv-ppp-wrap');
            var ppcWrap = document.getElementById('qd-conv-ppc-wrap');
            var convInner = document.getElementById('qd-conv-row');
            var labelPpp = document.getElementById('qd-label-ppp');
            var cartonOnly = showCarton && !showPack;
            if (pppWrap) pppWrap.classList.toggle('is-hidden', !(showPack || cartonOnly));
            if (ppcWrap) ppcWrap.classList.toggle('is-hidden', !showCarton || cartonOnly);
            if (convInner) {
                convInner.classList.toggle('is-single-col', cartonOnly || (showPack && !showCarton));
            }
            if (labelPpp) {
                labelPpp.textContent = cartonOnly
                    ? qdT('product_form_conv_piece_carton', 'دانە ل کارتۆنی دا')
                    : qdT('product_form_conv_ppp', 'دانە ل پاکێتی دا');
            }
        }
        window.qdOnConvChange = function qdOnConvChange() {
            qdUpdateConvPreview();
            qdSyncFromLevel();
            qdCalcTotalStock();
        };
        window.qdCalcTotalStock = function qdCalcTotalStock() {
            var f = qdGetConversionFactors();
            var scRaw = parseInt((document.getElementById('qd-stock-carton') && document.getElementById('qd-stock-carton').value) || '0', 10);
            var spRaw = parseInt((document.getElementById('qd-stock-pack') && document.getElementById('qd-stock-pack').value) || '0', 10);
            var siRaw = parseInt((document.getElementById('qd-stock-piece') && document.getElementById('qd-stock-piece').value) || '0', 10);
            if (!isFinite(scRaw) || scRaw < 0) scRaw = 0;
            if (!isFinite(spRaw) || spRaw < 0) spRaw = 0;
            if (!isFinite(siRaw) || siRaw < 0) siRaw = 0;
            var sc = f.vc ? scRaw : 0;
            var sp = (f.vp && f.unitStructure !== 'carton_piece') ? spRaw : 0;
            var total = (sc * f.piecesPerCarton) + (sp * f.ppp) + siRaw;
            var el = document.getElementById('qd-total-stock-preview');
            if (el) {
                el.innerHTML = total > 0
                    ? (qdT('qd_total_stock', 'کۆیا گشتی') + ': <strong>' + total + '</strong> ' + qdT('product_form_piece_label', 'دانە'))
                    : '';
            }
        };
        window.qdOnTrackStockChange = function qdOnTrackStockChange() {
            var trackEl = document.getElementById('qd-track');
            if (trackEl && typeof setProductFormTrackStockPref === 'function') {
                setProductFormTrackStockPref(!!trackEl.checked);
            }
            if (typeof qdToggleStockInputs === 'function') qdToggleStockInputs();
        };
        window.qdToggleTrackStock = function qdToggleTrackStock() {
            var trackEl = document.getElementById('qd-track');
            if (!trackEl) return;
            trackEl.checked = !trackEl.checked;
            qdOnTrackStockChange();
        };
        window.qdToggleStockInputs = function qdToggleStockInputs() {
            var trackEl = document.getElementById('qd-track');
            var isTracked = trackEl ? trackEl.checked : true;
            var table = document.querySelector('#quick-define-modal .qd-product-form .report-table');
            var preview = document.getElementById('qd-total-stock-preview');
            if (table) table.classList.toggle('no-stock-track', !isTracked);
            if (preview) preview.classList.toggle('is-hidden', !isTracked);
            if (!isTracked) {
                ['qd-stock-piece', 'qd-stock-pack', 'qd-stock-carton'].forEach(function (id) {
                    var el = document.getElementById(id);
                    if (el) el.value = '0';
                });
                if (preview) preview.innerHTML = '';
            } else if (typeof qdCalcTotalStock === 'function') {
                qdCalcTotalStock();
            }
            qdSyncUnitLevelSwitch('btn-qd-unit-stock-toggle', isTracked);
        };
        function qdSyncUnitLevelSwitch(btnId, isOn) {
            var btn = document.getElementById(btnId);
            if (!btn) return;
            btn.classList.toggle('is-on', !!isOn);
            btn.setAttribute('aria-checked', isOn ? 'true' : 'false');
        }
        function syncQdUnitLevelsUi() {
            var showPackEl = document.getElementById('qd-unit-show-pack');
            var showCartonEl = document.getElementById('qd-unit-show-carton');
            var showPack = showPackEl && showPackEl.value === '1';
            var showCarton = showCartonEl && showCartonEl.value === '1';
            var packRow = document.getElementById('qd-ml-row-pack');
            var cartonRow = document.getElementById('qd-ml-row-carton');
            var convRow = document.getElementById('qd-conv-row');
            var autoGroup = document.getElementById('qd-auto-toggle-group');
            if (packRow) packRow.style.display = showPack ? '' : 'none';
            if (cartonRow) cartonRow.style.display = showCarton ? '' : 'none';
            if (convRow) convRow.classList.toggle('is-hidden', !(showPack || showCarton));
            qdSyncUnitLevelSwitch('btn-qd-unit-pack-toggle', showPack);
            qdSyncUnitLevelSwitch('btn-qd-unit-carton-toggle', showCarton);
            if (autoGroup) autoGroup.classList.toggle('is-hidden', !showPack && !showCarton);
            qdUpdateConvLabels();
            qdUpdateConvPreview();
            qdCalcTotalStock();
            if (typeof qdSyncInheritedLevelBarcodes === 'function') qdSyncInheritedLevelBarcodes();
        }
        window.qdTogglePackLevel = function qdTogglePackLevel() {
            var el = document.getElementById('qd-unit-show-pack');
            if (!el) return;
            el.value = el.value === '1' ? '0' : '1';
            syncQdUnitLevelsUi();
        };
        window.qdToggleCartonLevel = function qdToggleCartonLevel() {
            var el = document.getElementById('qd-unit-show-carton');
            if (!el) return;
            el.value = el.value === '1' ? '0' : '1';
            syncQdUnitLevelsUi();
        };
        window.qdAddPackLevel = function() {
            var el = document.getElementById('qd-unit-show-pack');
            if (el) el.value = '1';
            syncQdUnitLevelsUi();
        };
        window.qdRemovePackLevel = function() {
            var el = document.getElementById('qd-unit-show-pack');
            if (el) el.value = '0';
            syncQdUnitLevelsUi();
        };
        window.qdAddCartonLevel = function() {
            var el = document.getElementById('qd-unit-show-carton');
            if (el) el.value = '1';
            syncQdUnitLevelsUi();
        };
        window.qdRemoveCartonLevel = function() {
            var el = document.getElementById('qd-unit-show-carton');
            if (el) el.value = '0';
            syncQdUnitLevelsUi();
        };
        window.openQuickDefineModal = function openQuickDefineModal(barcode, opts) {
            opts = opts || {};
            if(!hasPermission('products_manage')) {
                showToast((typeof t === 'function') ? t('purchase_define_yourself') : 'ئایتم نەهاتە داخلکرن — خۆت چێکە، زێدەکە، داخلکە', 'error');
                return;
            }
            
            const modal = document.getElementById('quick-define-modal');
            var bcEl = document.getElementById('qd-barcode-display');
            var bcInput = document.getElementById('qd-barcode-input');
            var bcEditBtn = document.getElementById('btn-qd-edit-barcode');
            var bcVal = String(barcode || '').trim();
            qdSetBarcodeValue(bcVal);
            var needBarcodeEdit = !bcVal || !!opts.fromPurchaseAdd;
            if (needBarcodeEdit && typeof qdToggleBarcodeEdit === 'function') {
                if (bcInput) bcInput.classList.remove('is-hidden');
                if (bcEl) bcEl.classList.add('is-hidden');
                if (bcEditBtn) bcEditBtn.classList.add('is-active');
                if (bcInput) bcInput.value = bcVal;
            } else {
                if (bcInput) bcInput.classList.add('is-hidden');
                if (bcEl) bcEl.classList.remove('is-hidden');
                if (bcEditBtn) bcEditBtn.classList.remove('is-active');
            }
            document.getElementById('qd-name').value = '';
            document.getElementById('qd-price').value = '';
            document.getElementById('qd-cost').value = '';
            var pricePack = document.getElementById('qd-price-pack');
            var costPack = document.getElementById('qd-cost-pack');
            var priceCarton = document.getElementById('qd-price-carton');
            var costCarton = document.getElementById('qd-cost-carton');
            if (pricePack) pricePack.value = '';
            if (costPack) costPack.value = '';
            if (priceCarton) priceCarton.value = '';
            if (costCarton) costCarton.value = '';
            var bcPack = document.getElementById('qd-barcode-pack');
            var bcCarton = document.getElementById('qd-barcode-carton');
            if (typeof resetLevelBarcodeField === 'function') {
                resetLevelBarcodeField(bcPack);
                resetLevelBarcodeField(bcCarton);
            } else {
                if (bcPack) bcPack.value = '';
                if (bcCarton) bcCarton.value = '';
            }
            if (typeof qdSyncInheritedLevelBarcodes === 'function') qdSyncInheritedLevelBarcodes();
            var stockPiece = document.getElementById('qd-stock-piece');
            var stockPack = document.getElementById('qd-stock-pack');
            var stockCarton = document.getElementById('qd-stock-carton');
            if (stockPiece) stockPiece.value = '0';
            if (stockPack) stockPack.value = '0';
            if (stockCarton) stockCarton.value = '0';
            var ppp = document.getElementById('qd-pieces-per-pack');
            var ppc = document.getElementById('qd-packs-per-carton');
            if (ppp) ppp.value = '1';
            if (ppc) ppc.value = '1';
            var showPackEl = document.getElementById('qd-unit-show-pack');
            var showCartonEl = document.getElementById('qd-unit-show-carton');
            if (showPackEl) showPackEl.value = '0';
            if (showCartonEl) showCartonEl.value = '0';
            qdLoadAutoPrefsFromStorage();
            modal.querySelectorAll('.pos-qd-derived-input.is-auto-filled').forEach(function(el) { el.classList.remove('is-auto-filled'); });
            var stockPrev = document.getElementById('qd-total-stock-preview');
            if (stockPrev) stockPrev.innerHTML = '';
            var qdTrack = document.getElementById('qd-track');
            if (qdTrack) {
                qdTrack.checked = (typeof getProductFormTrackStockPref === 'function')
                    ? getProductFormTrackStockPref()
                    : true;
            }
            if (typeof qdToggleStockInputs === 'function') qdToggleStockInputs();
            if (typeof unlockQuickDefineStockQty === 'function') unlockQuickDefineStockQty();
            syncQdUnitLevelsUi();
            populateQdCategorySelect();
            populateQdSupplierSelect();
            var purSup = document.getElementById('purchase-supplier-select');
            if (purSup && purSup.value && db && db.companies) {
                var purComp = db.companies.find(function(c) { return String(c.id) === String(purSup.value); });
                if (purComp && document.getElementById('qd-supplier')) {
                    document.getElementById('qd-supplier').value = purComp.name;
                }
            }
            
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
            applyQdModalLanguage(modal);
            var hintElOpen = modal.querySelector('.qd-modal-hint');
            if (hintElOpen) {
                hintElOpen.textContent = (typeof t === 'function')
                    ? t('purchase_define_yourself')
                    : 'ئایتم نەهاتە داخلکرن — خۆت چێکە، زێدەکە، داخلکە';
            }
            
            modal.style.display = 'flex';
            var qdBody = modal.querySelector('.qd-modal-body');
            var qdCard = modal.querySelector('.pos-quick-define-card');
            if (qdBody) qdBody.scrollTop = 0;
            if (qdCard) qdCard.scrollTop = 0;
            setTimeout(function() {
                var focusEl = (!bcVal && bcInput && !bcInput.classList.contains('is-hidden'))
                    ? bcInput
                    : document.getElementById('qd-name');
                if (focusEl) {
                    try { focusEl.focus({ preventScroll: true }); }
                    catch (e) { focusEl.focus(); }
                }
            }, 100);
        }

        window.closeQuickDefineModal = function closeQuickDefineModal() {
            document.getElementById('quick-define-modal').style.display = 'none';
        };

        window.saveQuickProduct = function saveQuickProduct(opts) {
            opts = opts || {};
            if (document.getElementById('qd-barcode-input') && !document.getElementById('qd-barcode-input').classList.contains('is-hidden')) {
                qdToggleBarcodeEdit(true);
            }
            const barcode = qdGetBarcodeValue();
            if (!barcode) return alert(qdT('product_form_label_barcode', 'بارکۆد') + ' — ' + qdT('product_new_requires_name', 'پێویستە'));
            const name = document.getElementById('qd-name').value;
            const price = productFormInputToIqd(document.getElementById('qd-price').value);
            const cost = productFormInputToIqd(document.getElementById('qd-cost').value);
            const supplier = document.getElementById('qd-supplier').value;
            const category = (document.getElementById('qd-category') && document.getElementById('qd-category').value) || 'General';
            var showPack = document.getElementById('qd-unit-show-pack') && document.getElementById('qd-unit-show-pack').value === '1';
            var showCarton = document.getElementById('qd-unit-show-carton') && document.getElementById('qd-unit-show-carton').value === '1';
            var pppSave = parseInt((document.getElementById('qd-pieces-per-pack') && document.getElementById('qd-pieces-per-pack').value) || '1', 10);
            var ppcSave = parseInt((document.getElementById('qd-packs-per-carton') && document.getElementById('qd-packs-per-carton').value) || '1', 10);
            if (!isFinite(pppSave) || pppSave < 1) pppSave = 1;
            if (!isFinite(ppcSave) || ppcSave < 1) ppcSave = 1;
            if (!showPack && !showCarton) { pppSave = 1; ppcSave = 1; }
            if (showPack && !showCarton) ppcSave = 1;
            if (!showPack && showCarton) { ppcSave = pppSave; pppSave = 1; }
            var itemsPerCarton = pppSave * ppcSave;
            var si = parseInt((document.getElementById('qd-stock-piece') && document.getElementById('qd-stock-piece').value) || '0', 10);
            var sp = showPack ? parseInt((document.getElementById('qd-stock-pack') && document.getElementById('qd-stock-pack').value) || '0', 10) : 0;
            var sc = showCarton ? parseInt((document.getElementById('qd-stock-carton') && document.getElementById('qd-stock-carton').value) || '0', 10) : 0;
            if (!isFinite(si) || si < 0) si = 0;
            if (!isFinite(sp) || sp < 0) sp = 0;
            if (!isFinite(sc) || sc < 0) sc = 0;
            var qdTrackEl = document.getElementById('qd-track');
            var trackStock = qdTrackEl ? qdTrackEl.checked : true;
            var totalQty = trackStock ? ((sc * itemsPerCarton) + (sp * pppSave) + si) : 0;
            var price_pack_raw = showPack && document.getElementById('qd-price-pack') ? String(document.getElementById('qd-price-pack').value).trim() : '';
            var cost_pack_raw = showPack && document.getElementById('qd-cost-pack') ? String(document.getElementById('qd-cost-pack').value).trim() : '';
            var price_carton_raw = showCarton && document.getElementById('qd-price-carton') ? String(document.getElementById('qd-price-carton').value).trim() : '';
            var cost_carton_raw = showCarton && document.getElementById('qd-cost-carton') ? String(document.getElementById('qd-cost-carton').value).trim() : '';
            var price_pack = price_pack_raw !== '' ? productFormInputToIqd(price_pack_raw) : '';
            var cost_pack = cost_pack_raw !== '' ? productFormInputToIqd(cost_pack_raw) : '';
            var price_carton = price_carton_raw !== '' ? productFormInputToIqd(price_carton_raw) : '';
            var cost_carton = cost_carton_raw !== '' ? productFormInputToIqd(cost_carton_raw) : '';

            if(!name) return alert("هیڤیە ناڤێ ئایتمی بنڤیسە!");
            if (!(price > 0)) {
                alert(typeof t === 'function' ? t('product_new_requires_price') : '⛔ سعر البيع يجب أن يكون أكبر من صفر.');
                document.getElementById('qd-price').focus();
                return;
            }
            if (isNaN(cost) || cost < 0) {
                alert(typeof t === 'function' ? t('product_new_requires_cost') : '⛔ أدخل تكلفة صالحة (≥ 0).');
                document.getElementById('qd-cost').focus();
                return;
            }
            if (showPack && price_pack_raw !== '' && !(price_pack > 0)) {
                alert(typeof t === 'function' ? t('product_new_requires_price') : '⛔ سعر البيع يجب أن يكون أكبر من صفر.');
                document.getElementById('qd-price-pack').focus();
                return;
            }
            if (showCarton && price_carton_raw !== '' && !(price_carton > 0)) {
                alert(typeof t === 'function' ? t('product_new_requires_price') : '⛔ سعر البيع يجب أن يكون أكبر من صفر.');
                document.getElementById('qd-price-carton').focus();
                return;
            }

            const formData = new FormData();
            formData.append('action', 'save_product');
            formData.append('name', name);
            formData.append('barcode', barcode);
            formData.append('price', price);
            formData.append('cost', cost);
            if (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD' && typeof productFormParseUsdRaw === 'function') {
                var _qdp = productFormParseUsdRaw(document.getElementById('qd-price').value);
                if (!isNaN(_qdp)) formData.append('price_usd', String(parseFloat(_qdp.toFixed(6))));
                var _qdc = productFormParseUsdRaw(document.getElementById('qd-cost').value);
                if (!isNaN(_qdc)) formData.append('cost_usd', String(parseFloat(_qdc.toFixed(6))));
                if (!isNaN(_qdp)) formData.append('base_price', String(parseFloat(_qdp.toFixed(6))));
                if (!isNaN(_qdc)) formData.append('base_cost', String(parseFloat(_qdc.toFixed(6))));
                formData.append('base_currency', 'USD');
            } else {
                formData.append('base_currency', 'IQD');
                formData.append('base_price', String(price));
                formData.append('base_cost', String(cost));
            }
            formData.append('qty', totalQty);
            formData.append('category', category);
            formData.append('supplier', supplier);
            formData.append('manufacturer', '');
            formData.append('trackStock', trackStock ? 1 : 0);
            formData.append('user', currentUser ? currentUser.name : 'System');

            formData.append('unitType', 'carton');
            formData.append('qty_mode', 'piece');
            formData.append('itemsPerCarton', String(itemsPerCarton));
            formData.append('takeawayPrice', '0');
            formData.append('wholesaleQty', '0');
            formData.append('wholesalePrice', '0');
            formData.append('expiry', '');
            formData.append('item_type', 'constant');
            formData.append('pieces_per_pack', String(pppSave));
            formData.append('packs_per_carton', String(ppcSave));
            var barcode_pack = showPack && document.getElementById('qd-barcode-pack') ? String(document.getElementById('qd-barcode-pack').value || '').trim() : '';
            var barcode_carton = showCarton && document.getElementById('qd-barcode-carton') ? String(document.getElementById('qd-barcode-carton').value || '').trim() : '';
            formData.append('barcode_pack', barcode_pack);
            formData.append('barcode_carton', barcode_carton);
            formData.append('price_pack', showPack && price_pack !== '' ? String(price_pack) : '');
            formData.append('price_carton', showCarton && price_carton !== '' ? String(price_carton) : '');
            formData.append('cost_pack', showPack && cost_pack !== '' ? String(cost_pack) : '');
            formData.append('cost_carton', showCarton && cost_carton !== '' ? String(cost_carton) : '');
            formData.append('unit_show_pack', showPack ? '1' : '0');
            formData.append('unit_show_carton', showCarton ? '1' : '0');
            formData.append('unit_name_piece', '');
            formData.append('unit_name_pack', '');
            formData.append('unit_name_carton', '');

            fetch('?action=save_product', { method: 'POST', body: formData })
            .then(function(res) { return res.text().then(function(t) { try { return JSON.parse(t); } catch(e) { throw new Error(t.indexOf('<!DOCTYPE') !== -1 || t.indexOf('<') === 0 ? 'سێرڤەر وەڵامێ HTML گەڕاندەوە.' : 'وەڵامێ سێرڤەر نادروستە (Not valid JSON).'); } }); })
            .then(data => {
                if(data.status === 'success') {
                    var _npu = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD' && typeof productFormParseUsdRaw === 'function') ? productFormParseUsdRaw(document.getElementById('qd-price').value) : NaN;
                    var _ncu = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD' && typeof productFormParseUsdRaw === 'function') ? productFormParseUsdRaw(document.getElementById('qd-cost').value) : NaN;
                    const newProd = {
                        id: data.id,
                        name: name,
                        barcode: barcode,
                        price: price,
                        cost: cost,
                        qty: totalQty,
                        category: category,
                        cat: category,
                        supplier: supplier,
                        manufacturer: '',
                        trackStock: trackStock,
                        qty_mode: 'piece',
                        pieces_per_pack: pppSave,
                        packs_per_carton: ppcSave,
                        itemsPerCarton: itemsPerCarton,
                        unit_show_pack: showPack ? 1 : 0,
                        unit_show_carton: showCarton ? 1 : 0,
                        unit_name_piece: '',
                        unit_name_pack: '',
                        unit_name_carton: '',
                        barcode_pack: barcode_pack,
                        barcode_carton: barcode_carton,
                        price_pack: showPack && price_pack !== '' ? price_pack : '',
                        price_carton: showCarton && price_carton !== '' ? price_carton : '',
                        cost_pack: showPack && cost_pack !== '' ? cost_pack : '',
                        cost_carton: showCarton && cost_carton !== '' ? cost_carton : ''
                    };
                    if (!isNaN(_npu)) newProd.price_usd = parseFloat(_npu.toFixed(6));
                    if (!isNaN(_ncu)) newProd.cost_usd = parseFloat(_ncu.toFixed(6));
                    if (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD') {
                        newProd.base_currency = 'USD';
                        if (!isNaN(_npu)) newProd.base_price = parseFloat(_npu.toFixed(6));
                        if (!isNaN(_ncu)) newProd.base_cost = parseFloat(_ncu.toFixed(6));
                    } else {
                        newProd.base_currency = 'IQD';
                        newProd.base_price = Number(price) || 0;
                        newProd.base_cost = Number(cost) || 0;
                    }
                    if (data.base_price != null) newProd.base_price = Number(data.base_price);
                    if (data.base_cost != null) newProd.base_cost = Number(data.base_cost);
                    if (data.base_currency) newProd.base_currency = data.base_currency;
                    db.products.push(newProd);
                    if (typeof updateCurrencyLockUI === 'function') updateCurrencyLockUI();
                    closeQuickDefineModal();
                    if (opts.openEdit) {
                        if (typeof nav === 'function') nav('products');
                        setTimeout(function() {
                            if (typeof editProd === 'function') editProd(data.id);
                        }, 250);
                        showToast(qdT('qd_saved_open_edit', '✅ هاتە پاراستن — دەستکاری بکە'));
                    } else if (typeof window.addToPurchaseCart === 'function') {
                        var purUnit = typeof purchaseSelectedUnit !== 'undefined' ? purchaseSelectedUnit : 'piece';
                        window.addToPurchaseCart(newProd.id, purUnit);
                        showToast(qdT('qd_saved_add_purchase', '✅ ئایتم هاتە پێناسەکرن و زێدەکرا بۆ کڕین!'));
                    } else {
                        showToast(qdT('qd_saved', '✅ ئایتم هاتە پێناسەکرن!'));
                    }
                } else {
                    alert("Error: " + data.message);
                }
            });
        }

        function addToBill(pid, saleUnit, opts) {
            opts = opts || {};
            if (window._posCartOperationLock) return false;
            var viewPos = document.getElementById('view-pos');
            var onPosScreen = viewPos && viewPos.classList.contains('active');
            if (!onPosScreen) return false;
            if (!db || !db.products) {
                if (typeof showToast === 'function') showToast('داتاکان هێشتا بار نەبوون — چاوەڕێ بکە', 'warning');
                return false;
            }
            saleUnit = saleUnit || (typeof posSelectedUnit !== 'undefined' ? posSelectedUnit : 'piece');
            const prod = (typeof posGetProductById === 'function')
                ? posGetProductById(pid)
                : (db.products.find(function(p) { return String(p.id) === String(pid); }));
            
            // Default Cart System: Ensure there's always an active cart
            if (!(typeof findActivePosTable === 'function' ? findActivePosTable() : null)) {
                if (typeof window.ensureDefaultCart === 'function') window.ensureDefaultCart();
                else if (typeof ensureDefaultCart === 'function') ensureDefaultCart();
            }
            
            const table = (typeof findActivePosTable === 'function') ? findActivePosTable() : null;
            if (!prod) {
                if (typeof showToast === 'function') showToast('ئایتم نەهاتە دیتن', 'error');
                return false;
            }
            if (!table) {
                if (typeof showToast === 'function') showToast('سەبەتە ئامادە نییە — دووبارە بچۆ ژوورەوە بۆ فرۆشتن', 'warning');
                return false;
            }
            if (!Array.isArray(table.items)) table.items = [];
            if (isWeightProduct(prod)) saleUnit = 'piece';

            if (productBarcodesAreShared(prod) === 'shared') {
                var smartBill = resolveSmartUnitForProduct(prod, saleUnit, false);
                saleUnit = smartBill.unit;
            }

            var f = typeof getProductUnitFactors === 'function' ? getProductUnitFactors(prod) : { piecesPerPack: 1, piecesPerCarton: 1 };
            var jewelrySetMode = (typeof isJewelrySetProduct === 'function') && isJewelrySetProduct(prod);
            if (jewelrySetMode) saleUnit = 'piece';

            window._posCartOperationLock = true;
            try {
                if (typeof cancelPendingPosTabSnapshot === 'function') cancelPendingPosTabSnapshot();
                var settings = db.settings || {};
                var piecesToDeduct = getPosPiecesNeededForUnit(saleUnit, prod);
                var isNegAllowed = (settings.allowNegativeStock == true || settings.allowNegativeStock == 'true' || settings.allowNegativeStock == 1);
                var availablePieces = typeof getPosAvailablePieces === 'function' ? getPosAvailablePieces(prod) : (parseFloat(prod.qty) || 0);
                if (jewelrySetMode && typeof jewelrySetAvailableCompleteSets === 'function') {
                    availablePieces = jewelrySetAvailableCompleteSets(prod);
                    piecesToDeduct = 1;
                }
                var displayQty = availablePieces;
                var isWeightPieceSale = isWeightProduct(prod) && saleUnit === 'piece';
                var defaultQty = 1;
                var qtyOverride = opts.qtyOverride;
                if (qtyOverride != null && qtyOverride !== '' && !isNaN(parseFloat(qtyOverride))) {
                    defaultQty = normalizeQtyForProduct(prod, qtyOverride);
                    if (!(defaultQty > 0)) {
                        if (typeof showToast === 'function') showToast('بارکۆدی تەرازوو نادروست', 'error');
                        return false;
                    }
                    piecesToDeduct = defaultQty;
                } else if (isWeightPieceSale) {
                    defaultQty = isNegAllowed ? normalizeQtyForProduct(prod, displayQty, true) : Math.min(1, Math.max(0, normalizeQtyForProduct(prod, displayQty)));
                    if (defaultQty <= 0 && isNegAllowed) defaultQty = 1;
                    piecesToDeduct = defaultQty;
                }
            if (!isNegAllowed && (jewelrySetMode || prod.trackStock || (typeof jewelryEnforcesStock === 'function' && jewelryEnforcesStock(prod))) && (availablePieces <= 0.000001 || availablePieces < piecesToDeduct)) {
                if (typeof showToast === 'function') {
                    if (jewelrySetMode) showToast('کۆگەی پارچەکانی سێت بەس نینە (گووهار/رستە…)', 'error');
                    else showToast(posSaleStockToastMessage(prod, saleUnit, availablePieces), 'error');
                }
                return false;
            }

            var jewelryWeight = null;
            var jewelryByWeight = (typeof isJewelryByWeightProduct === 'function') && isJewelryByWeightProduct(prod);
            if (jewelryByWeight) {
                // Weight is set on the product when adding — do NOT ask again at sale.
                // Only prompt if grams were never saved (0 / empty).
                if (opts.jewelryWeight != null && !isNaN(parseFloat(opts.jewelryWeight)) && parseFloat(opts.jewelryWeight) > 0) {
                    jewelryWeight = Math.round(parseFloat(opts.jewelryWeight) * 1000) / 1000;
                } else if (prod.weight_grams != null && Number(prod.weight_grams) > 0) {
                    jewelryWeight = Math.round(Number(prod.weight_grams) * 1000) / 1000;
                    if (saleUnit === 'pack') {
                        var fJew = typeof getProductUnitFactors === 'function' ? getProductUnitFactors(prod) : { piecesPerPack: 1 };
                        jewelryWeight = Math.round(jewelryWeight * (fJew.piecesPerPack || 1) * 1000) / 1000;
                    }
                } else if (opts.skipJewelryPrompt) {
                    jewelryWeight = null;
                } else {
                    // Beautiful modal instead of window.prompt — continue add after confirm
                    window._posCartOperationLock = false;
                    var metaLbl = (typeof jewelryMetaLabel === 'function') ? jewelryMetaLabel(prod) : '';
                    if (typeof openJewelryWeightModal === 'function') {
                        openJewelryWeightModal({
                            title: 'کێش (گرام)',
                            meta: metaLbl || (prod.name || ''),
                            defaultWeight: '',
                            onDone: function (w) {
                                if (w == null || !(w > 0)) return;
                                addToBill(pid, saleUnit, Object.assign({}, opts, { jewelryWeight: w }));
                            }
                        });
                    } else if (typeof showToast === 'function') {
                        showToast('کێشێ ئایتمێ نینە — ل زێدەکرنا ئایتمێ گرام بنڤیسە', 'error');
                    }
                    return false;
                }
                if (!(jewelryWeight > 0)) {
                    if (typeof showToast === 'function') showToast('کێشێ ئایتمێ نینە — ل زێدەکرنا ئایتمێ گرام بنڤیسە', 'error');
                    return false;
                }
            }

            var finalPrice = typeof getPriceForUnit === 'function' ? getPriceForUnit(prod, saleUnit, table) : prod.price;
            if (jewelryByWeight && jewelryWeight != null && typeof computeProductJewelryPrice === 'function') {
                // Live daily metal rate × saved grams + making
                finalPrice = computeProductJewelryPrice(prod, jewelryWeight);
                if (!(finalPrice > 0)) {
                    if (typeof showToast === 'function') showToast('نرخی ڕۆژانەی زیڤ/زێر د ڕێکخستنان دانە', 'warning');
                }
            }
            var rAdd = typeof getPosFrozenFxRatePerOne === 'function' ? getPosFrozenFxRatePerOne(null) : (typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0);
                var catalogIqd = Number(finalPrice) || 0;
                var billUnitUsd = 0;
                if (!jewelryByWeight && typeof getCatalogBillUnitUsdAtAdd === 'function') {
                    billUnitUsd = getCatalogBillUnitUsdAtAdd(prod, saleUnit, table);
                }
                if (billUnitUsd > 0 && rAdd > 0 && typeof usdValueLooksLikeIqdSnapshot === 'function'
                    && usdValueLooksLikeIqdSnapshot(billUnitUsd, catalogIqd, rAdd)) {
                    billUnitUsd = parseFloat((billUnitUsd / rAdd).toFixed(6));
                }
                if (!(billUnitUsd > 0) && rAdd > 0 && catalogIqd > 0) {
                    billUnitUsd = parseFloat((catalogIqd / rAdd).toFixed(6));
                }
                // item.price is always IQD. Never convert bill_unit_usd again — that caused $180,000 → 270,000,000 IQD.
                if (catalogIqd > 0) {
                    finalPrice = catalogIqd;
                } else if (billUnitUsd > 0 && rAdd > 0) {
                    finalPrice = (typeof usdAmountToStoredIqd === 'function')
                        ? usdAmountToStoredIqd(billUnitUsd, rAdd)
                        : ((typeof roundMoney === 'function') ? roundMoney(billUnitUsd * rAdd) : Math.round(billUnitUsd * rAdd));
                }
                var fCost = typeof getProductUnitFactors === 'function' ? getProductUnitFactors(prod) : { piecesPerPack: 1, piecesPerCarton: 1 };
                // Piece cost is source of truth after purchase sync — pack/carton = piece × factor
                // unless pack/carton only differs by floor leftover from a cheaper invoice total.
                var pieceCostBase = Number(prod.cost) || 0;
                var costForUnit = (typeof catalogCostForSaleUnit === 'function')
                    ? catalogCostForSaleUnit(prod, saleUnit)
                    : pieceCostBase;
                if (!(typeof catalogCostForSaleUnit === 'function')) {
                    if (saleUnit === 'carton') {
                        var multC = Math.max(1, parseFloat(fCost.piecesPerCarton) || 1);
                        costForUnit = pieceCostBase > 0 ? (pieceCostBase * multC) : (Number(prod.cost_carton) || 0);
                    } else if (saleUnit === 'pack') {
                        var multP = Math.max(1, parseFloat(fCost.piecesPerPack) || 1);
                        costForUnit = pieceCostBase > 0 ? (pieceCostBase * multP) : (Number(prod.cost_pack) || 0);
                    }
                }
                if (typeof roundMoney === 'function') costForUnit = roundMoney(costForUnit);
                if (costForUnit > finalPrice && finalPrice > 0 && saleUnit !== 'piece') {
                    var pc = pieceCostBase;
                    var pp = Number(prod.price) || 0;
                    if (pc > 0 && pp > 0) {
                        costForUnit = Math.round(finalPrice * (pc / pp));
                    }
                }
                var reservedFifoPieces = 0;
                try {
                    var tblFifo = (typeof db !== 'undefined' && db.tables && typeof activeTableId !== 'undefined')
                        ? db.tables.find(function(t) { return t.id === activeTableId; })
                        : null;
                    if (tblFifo && Array.isArray(tblFifo.items)) {
                        for (var ri = 0; ri < tblFifo.items.length; ri++) {
                            var rit = tblFifo.items[ri];
                            if (!rit || rit.isManualItem || Number(rit.id) !== Number(prod.id)) continue;
                            var rMult = (typeof piecesInSaleUnit === 'function') ? piecesInSaleUnit(prod, rit.saleUnit || 'piece') : 1;
                            var rQty = (typeof getSaleLineQty === 'function') ? getSaleLineQty(rit) : (parseFloat(rit.qty != null ? rit.qty : rit.count) || 1);
                            reservedFifoPieces += rMult * rQty;
                        }
                    }
                } catch (_eRes) {}
                var fifoUnitCost = (typeof inventoryFifoSaleUnitCost === 'function')
                    ? inventoryFifoSaleUnitCost(prod, { id: prod.id, saleUnit: saleUnit, qty: defaultQty, count: defaultQty }, {
                        remainingQty: parseFloat(prod.qty) || 0,
                        reservedPieces: reservedFifoPieces
                    })
                    : null;
                if (fifoUnitCost != null && isFinite(Number(fifoUnitCost))) costForUnit = fifoUnitCost;
                if (typeof roundMoney === 'function') costForUnit = roundMoney(costForUnit);

                var recipeSaleMode = 'auto';
                if (typeof productHasRecipe === 'function' && productHasRecipe(prod.id)) {
                    recipeSaleMode = typeof normalizeRecipeSaleMode === 'function'
                        ? normalizeRecipeSaleMode(prod.recipe_sale_mode || 'auto')
                        : 'auto';
                }
                // Store unit factors in item so backend doesn't have to guess or use old data
                var linePayload = {
                    id: prod.id,
                    name: prod.name,
                    barcode: prod.barcode,
                    sku: prod.sku,
                    category: prod.category,
                    is_weight: prod.is_weight,
                    qty_mode: prod.qty_mode || (isWeightProduct(prod) ? 'kilo' : 'piece'),
                    recipeSaleMode: recipeSaleMode,
                    trackStock: prod.trackStock,
                    wholesaleQty: prod.wholesaleQty,
                    wholesalePrice: prod.wholesalePrice,
                    qty: defaultQty,
                    count: defaultQty,
                    price: finalPrice,
                    cost: costForUnit,
                    saleUnit: saleUnit,
                    pieces_per_pack: fCost.ppp,
                    packs_per_carton: fCost.ppc,
                    itemsPerCarton: fCost.piecesPerCarton,
                    billId: Date.now()
                };
                if (billUnitUsd > 0) linePayload.bill_unit_usd = billUnitUsd;
                if (rAdd > 0) linePayload.fx_rate_per_one = rAdd;
                linePayload.sale_price = finalPrice;
                linePayload.sale_currency = (typeof getProductBaseCurrency === 'function') ? getProductBaseCurrency(prod) : ((typeof getActiveCurrency === 'function') ? getActiveCurrency() : 'IQD');
                if (typeof db !== 'undefined' && db && db.settings && db.settings.usdRate != null) {
                    var _saleFx = Math.round(Number(db.settings.usdRate));
                    if (_saleFx >= 1000) linePayload.sale_exchange_rate = _saleFx;
                }
                if (jewelrySetMode) {
                    linePayload.is_jewelry_set = true;
                    linePayload.jewelry_set_items = (typeof getJewelrySetMembers === 'function')
                        ? getJewelrySetMembers(prod)
                        : (prod.jewelry_set_items || []);
                    linePayload.trackStock = false;
                }
                if (jewelryByWeight && jewelryWeight != null) {
                    linePayload.jewelry_price_mode = 'by_weight';
                    linePayload.jewelry_weight = jewelryWeight;
                    linePayload.weight_grams = jewelryWeight;
                    linePayload.jewelry_making = Number(prod.making_charge) || 0;
                    linePayload.making_charge = linePayload.jewelry_making;
                    linePayload.jewelry_metal = (typeof normalizeMetalType === 'function') ? normalizeMetalType(prod.metal_type) : (prod.metal_type || '');
                    linePayload.metal_type = linePayload.jewelry_metal;
                    linePayload.jewelry_karat = (typeof normalizeKarat === 'function') ? normalizeKarat(prod.karat) : prod.karat;
                    linePayload.karat = linePayload.jewelry_karat;
                    linePayload.jewelry_rate = (typeof getRatePerGram === 'function') ? getRatePerGram(prod.metal_type, prod.karat) : 0;
                } else if (prod.metal_type) {
                    linePayload.metal_type = prod.metal_type;
                    linePayload.karat = prod.karat;
                    linePayload.weight_grams = prod.weight_grams;
                    linePayload.making_charge = prod.making_charge;
                    linePayload.jewelry_price_mode = prod.jewelry_price_mode || 'fixed';
                }
                table.items.push(linePayload);
                lastTableState = "";
                if (typeof onCartChanged === 'function') onCartChanged({ fast: true, productId: prod.id, saleUnit: saleUnit, skipFullRender: true });
                if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('pos', { clear: true, delay: 0 });
                return true;
            } catch (err) {
                console.error('addToBill failed', err);
                if (typeof showToast === 'function') showToast('هەڵە لە زیادکردن بۆ سەبەتە', 'error');
                return false;
            } finally {
                window._posCartOperationLock = false;
            }
            return false;
        }
        window.addToBill = addToBill;

        function getManualQuickItems() {
            if (!db || !db.settings) return [{ name: 'طباعة A4', price: 500 }, { name: 'عمل CV', price: 10000 }, { name: 'نسخ', price: 250 }];
            var list = db.settings.manualQuickItems;
            return Array.isArray(list) ? list : [{ name: 'طباعة A4', price: 500 }, { name: 'عمل CV', price: 10000 }, { name: 'نسخ', price: 250 }];
        }

        function parseManualCostInput(raw) {
            var cost = (typeof parseMoneyInputToIqd === 'function')
                ? parseMoneyInputToIqd(raw || '0')
                : parseFloat(String(raw || '0').replace(/,/g, ''));
            if (isNaN(cost) || cost < 0) cost = 0;
            return cost;
        }

        function renderSettingsQuickItems() {
            var listEl = document.getElementById('settings-quick-items-list');
            if (!listEl) return;
            if (!db || !db.settings) return;
            if (!Array.isArray(db.settings.manualQuickItems)) db.settings.manualQuickItems = [{ name: 'طباعة A4', price: 500 }, { name: 'عمل CV', price: 10000 }, { name: 'نسخ', price: 250 }];
            var items = db.settings.manualQuickItems;
            var delLabel = (typeof t === 'function' && window.LANGS && (window.LANGS.ar || window.LANGS.badini)) ? (t('btn_delete') || 'حذف') : 'حذف';
            listEl.innerHTML = items.length ? '<ul class="settings-quick-items-ul">' + items.map(function(q, idx) {
                var n = escapeHtml((q.name || '').trim() || ('Item ' + (idx + 1)));
                var pr = isNaN(parseFloat(q.price)) ? 0 : parseFloat(q.price);
                var prStr = (typeof formatCurrency === 'function') ? formatCurrency(pr) : pr;
                var co = isNaN(parseFloat(q.cost)) ? 0 : parseFloat(q.cost);
                var coStr = co > 0 ? ((typeof formatCurrency === 'function') ? formatCurrency(co) : co) : '—';
                return '<li class="settings-quick-item-row"><span class="sq-name">' + n + '</span><span class="sq-price">' + prStr + '</span><span class="sq-cost">' + coStr + '</span><button type="button" class="btn btn-sm btn-danger" onclick="removeSettingsQuickItem(' + idx + ')"><i class="fas fa-trash"></i> ' + delLabel + '</button></li>';
            }).join('') + '</ul>' : '<p class="settings-quick-empty">' + (typeof t === 'function' ? t('manual_quick_empty') : 'چ ئایتم نینن. ژ خوارێ زێدە بکە.') + '</p>';
        }

        function addSettingsQuickItem() {
            var nameIn = document.getElementById('settings-quick-item-name');
            var priceIn = document.getElementById('settings-quick-item-price');
            var costIn = document.getElementById('settings-quick-item-cost');
            if (!nameIn || !priceIn || !db || !db.settings) return;
            var name = (nameIn.value || '').trim();
            var price = (typeof parseMoneyInputToIqd === 'function')
                ? parseMoneyInputToIqd(priceIn.value || '0')
                : parseFloat((priceIn.value || '0').replace(/,/g, ''));
            var cost = costIn ? parseManualCostInput(costIn.value) : 0;
            if (!name) { if (typeof showToast === 'function') showToast('ناڤێ ئایتمی بنڤیسە.', 'error'); return; }
            if (isNaN(price) || price < 0) price = 0;
            if (!Array.isArray(db.settings.manualQuickItems)) db.settings.manualQuickItems = [];
            db.settings.manualQuickItems.push({ name: name, price: price, cost: cost });
            nameIn.value = ''; priceIn.value = ''; if (costIn) costIn.value = '';
            renderSettingsQuickItems();
            if (typeof saveSettings === 'function') saveSettings().then(function() { if (typeof showToast === 'function') showToast(typeof t === 'function' ? t('toast_saved') : 'تم الحفظ'); }).catch(function() {});
        }

        function removeSettingsQuickItem(idx) {
            if (!db || !db.settings || !Array.isArray(db.settings.manualQuickItems)) return;
            if (idx < 0 || idx >= db.settings.manualQuickItems.length) return;
            db.settings.manualQuickItems.splice(idx, 1);
            renderSettingsQuickItems();
            if (typeof saveSettings === 'function') saveSettings().then(function() { if (typeof showToast === 'function') showToast(typeof t === 'function' ? t('toast_saved') : 'تم الحفظ'); }).catch(function() {});
        }

        /** Stable id + merge helpers for manual sale lines (same name/price → one row). */
        function manualCartMergeKey(item) {
            if (!item) return '';
            var name = String(item.name || '').trim();
            var price = typeof getCartLineMatchPrice === 'function' ? getCartLineMatchPrice(item) : (Number(item.price) || 0);
            var cost = Number(item.cost) || 0;
            return name + '|' + price + '|' + cost + '|' + (item.note || '') + '|' + (item.saleUnit || 'piece') + '|' + (item.isGift ? '1' : '0');
        }
        function buildManualCartLineId(name, price, cost) {
            var n = String(name || '').trim().replace(/\s+/g, ' ');
            var p = Math.round(parseFloat(price) || 0);
            var c = Math.round(parseFloat(cost) || 0);
            var slug = n.replace(/[^\w\u0600-\u06FF\s-]/g, '').replace(/\s+/g, '_').slice(0, 48);
            if (!slug) slug = 'item';
            return 'M_' + slug + '_' + p + '_' + c;
        }
        function findManualCartLine(table, probe) {
            if (!table || !Array.isArray(table.items) || !probe) return null;
            var key = manualCartMergeKey(probe);
            for (var i = 0; i < table.items.length; i++) {
                var it = table.items[i];
                if (!it || !it.isManualItem) continue;
                if (manualCartMergeKey(it) === key) return it;
            }
            return null;
        }
        function consolidateManualCartLines(table) {
            if (!table || !Array.isArray(table.items) || !table.items.length) return false;
            var merged = [];
            var buckets = {};
            var changed = false;
            table.items.forEach(function(item) {
                if (!item || !item.isManualItem) {
                    merged.push(item);
                    return;
                }
                var key = manualCartMergeKey(item);
                if (!buckets[key]) {
                    var line = Object.assign({}, item);
                    line.id = buildManualCartLineId(item.name, item.price, item.cost);
                    line.qty = getItemQty(item);
                    if ((line.bill_unit_usd == null || line.bill_unit_usd === '')) {
                        var rCons = typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0;
                        if (rCons > 0) line.bill_unit_usd = parseFloat((line.price / rCons).toFixed(6));
                    }
                    buckets[key] = line;
                    merged.push(line);
                    if (line.id !== item.id || getItemQty(item) !== line.qty) changed = true;
                } else {
                    buckets[key].qty = getItemQty(buckets[key]) + getItemQty(item);
                    changed = true;
                }
            });
            if (changed) {
                table.items = merged;
                lastTableState = "";
            }
            return changed;
        }
        function addManualLineToCart(table, lineData) {
            if (!table) return null;
            if (!Array.isArray(table.items)) table.items = [];
            var qtyAdd = parseFloat(lineData.qty);
            if (isNaN(qtyAdd) || qtyAdd <= 0) qtyAdd = 1;
            var probe = Object.assign({}, lineData);
            var existing = findManualCartLine(table, probe);
            if (existing) {
                existing.qty = getItemQty(existing) + qtyAdd;
                existing.id = buildManualCartLineId(existing.name, existing.price, existing.cost);
                if (lineData.bill_unit_usd != null && lineData.bill_unit_usd !== '') existing.bill_unit_usd = lineData.bill_unit_usd;
                existing.price = lineData.price;
                if (lineData.cost != null && !isNaN(parseFloat(lineData.cost))) existing.cost = parseFloat(lineData.cost);
                return existing;
            }
            var item = Object.assign({}, lineData, {
                id: buildManualCartLineId(lineData.name, lineData.price, lineData.cost),
                name: String(lineData.name || '').trim() || 'صنف يدوي',
                qty: qtyAdd,
                billId: lineData.billId || Date.now()
            });
            table.items.push(item);
            return item;
        }

        /** Add a quick/manual item to cart. Services only — no inventory: trackStock false, no product id; bill line only. */
        function addManualQuickItemToCart(name, price, cost) {
            if (typeof isWorkspaceViewActive === 'function' && !isWorkspaceViewActive('pos')) return;
            // Default Cart System: Ensure there's always an active cart
            if (!activeTableId || !db.tables || !db.tables.find(t => t.id === activeTableId)) {
                ensureDefaultCart();
            }
            
            var table = db.tables && db.tables.find(function(t) { return t.id === activeTableId; });
            if (!table) return;
            var p = parseFloat(price);
            if (isNaN(p) || p < 0) p = 0;
            var c = parseManualCostInput(cost);
            var stored = typeof buildManualLineFromStoredIqd === 'function'
                ? buildManualLineFromStoredIqd((name || '').trim() || 'صنف يدوي', p)
                : { name: (name || '').trim() || 'صنف يدوي', price: Math.round(p) };
            addManualLineToCart(table, {
                name: stored.name,
                price: stored.price,
                bill_unit_usd: stored.bill_unit_usd,
                cost: c,
                barcode: '',
                supplier: 'Manual',
                cat: 'Custom',
                trackStock: false,
                isManualItem: true,
                isManualPrice: true
            });
            lastTableState = "";
            if (typeof onCartChanged === 'function') onCartChanged({ fast: true });
        }

        function renderManualQuickItems() {
            var container = document.getElementById('manual-quick-items-container');
            if (!container) return;
            var items = getManualQuickItems();
            container.innerHTML = items.length ? items.map(function(q, idx) {
                var n = (q.name || '').trim() || ('Item ' + (idx + 1));
                var pr = parseFloat(q.price);
                var prStr = (typeof formatCurrency === 'function') ? formatCurrency(isNaN(pr) ? 0 : pr) : (isNaN(pr) ? '0' : pr);
                return '<button type="button" class="manual-quick-btn" data-quick-index="' + idx + '"><span class="manual-quick-name">' + escapeHtml(n) + '</span><span class="manual-quick-price">' + prStr + '</span></button>';
            }).join('') : '<p class="manual-quick-empty">' + (typeof t === 'function' ? t('manual_quick_empty') : 'چ ئایتمێن خێرا نینن. ژ ڕێکخستنان زێدە بکە.') + '</p>';
            container.querySelectorAll('.manual-quick-btn').forEach(function(btn) {
                btn.onclick = function() {
                    var idx = parseInt(btn.getAttribute('data-quick-index'), 10);
                    var itemsNow = getManualQuickItems();
                    var q = itemsNow[idx];
                    if (q) addManualQuickItemToCart(q.name, q.price, q.cost);
                };
            });
        }

        function applyManualModalLanguage(modal) {
            if (!modal || typeof t !== 'function') return;
            modal.querySelectorAll('[data-i18n]').forEach(function(el) {
                var key = el.getAttribute('data-i18n');
                if (key) el.textContent = t(key);
            });
            modal.querySelectorAll('[data-i18n-placeholder]').forEach(function(el) {
                var key = el.getAttribute('data-i18n-placeholder');
                if (key) el.placeholder = t(key);
            });
            modal.querySelectorAll('[data-i18n-title]').forEach(function(el) {
                var key = el.getAttribute('data-i18n-title');
                if (key && typeof t === 'function') el.title = t(key);
            });
        }

        function renderManualModalQuickList() {
            var listEl = document.getElementById('manual-modal-quick-list');
            if (!listEl) return;
            var items = getManualQuickItems();
            var delTxt = typeof t === 'function' ? t('btn_delete') : 'حذف';
            listEl.innerHTML = items.length ? items.map(function(q, idx) {
                var n = escapeHtml((q.name || '').trim() || ('Item ' + (idx + 1)));
                var pr = isNaN(parseFloat(q.price)) ? 0 : parseFloat(q.price);
                var prStr = (typeof formatCurrency === 'function') ? formatCurrency(pr) : pr;
                var co = isNaN(parseFloat(q.cost)) ? 0 : parseFloat(q.cost);
                var coStr = co > 0 ? ((typeof formatCurrency === 'function') ? formatCurrency(co) : co) : '—';
                return '<div class="manual-modal-quick-row"><span class="mmq-name">' + n + '</span><span class="mmq-price">' + prStr + '</span><span class="mmq-cost">' + coStr + '</span><button type="button" class="btn btn-icon btn-danger" onclick="removeQuickItemFromModal(' + idx + ')" title="' + delTxt + '"><i class="fas fa-trash-alt"></i></button></div>';
            }).join('') : '<p class="manual-modal-quick-empty">—</p>';
        }

        function addQuickItemFromModal() {
            var nameIn = document.getElementById('manual-modal-new-name');
            var priceIn = document.getElementById('manual-modal-new-price');
            var costIn = document.getElementById('manual-modal-new-cost');
            if (!nameIn || !priceIn || !db || !db.settings) return;
            var name = (nameIn.value || '').trim();
            var price = (typeof parseMoneyInputToIqd === 'function')
                ? parseMoneyInputToIqd(priceIn.value || '0')
                : parseFloat((priceIn.value || '0').replace(/,/g, ''));
            var cost = costIn ? parseManualCostInput(costIn.value) : 0;
            if (!name) { if (typeof showToast === 'function') showToast(typeof t === 'function' ? t('manual_enter_name') : 'ناڤێ ئایتمی بنڤیسە', 'error'); return; }
            if (isNaN(price) || price < 0) price = 0;
            if (!Array.isArray(db.settings.manualQuickItems)) db.settings.manualQuickItems = [];
            db.settings.manualQuickItems.push({ name: name, price: price, cost: cost });
            nameIn.value = ''; priceIn.value = ''; if (costIn) costIn.value = '';
            if (typeof renderManualQuickItems === 'function') renderManualQuickItems();
            if (typeof renderManualModalQuickList === 'function') renderManualModalQuickList();
            if (typeof saveSettings === 'function') saveSettings().then(function() { if (typeof showToast === 'function') showToast(typeof t === 'function' ? t('toast_saved') : 'تم الحفظ'); }).catch(function() {});
        }

        function removeQuickItemFromModal(idx) {
            if (!db || !db.settings || !Array.isArray(db.settings.manualQuickItems)) return;
            if (idx < 0 || idx >= db.settings.manualQuickItems.length) return;
            db.settings.manualQuickItems.splice(idx, 1);
            if (typeof renderManualQuickItems === 'function') renderManualQuickItems();
            if (typeof renderManualModalQuickList === 'function') renderManualModalQuickList();
            if (typeof saveSettings === 'function') saveSettings().then(function() { if (typeof showToast === 'function') showToast(typeof t === 'function' ? t('toast_saved') : 'تم الحفظ'); }).catch(function() {});
        }

        function saveManualQuickItemsFromModal() {
            if (typeof saveSettings !== 'function') return;
            saveSettings().then(function() {
                if (typeof showToast === 'function') showToast(typeof t === 'function' ? t('toast_saved') : 'تم الحفظ');
            }).catch(function() {});
        }
        window.saveManualQuickItemsFromModal = saveManualQuickItemsFromModal;

        function toggleManualManagePanel() {
            var panel = document.getElementById('manual-manage-panel');
            var btn = document.getElementById('manual-manage-toggle');
            if (!panel || !btn) return;
            var show = panel.style.display === 'none' || !panel.style.display;
            panel.style.display = show ? 'block' : 'none';
            btn.classList.toggle('active', show);
        }

        var MANUAL_ENTRY_STORAGE_KEY = 'pos_manual_entry_collapsed';

        function toggleManualEntrySection() {
            var body = document.getElementById('manual-entry-body');
            var icon = document.getElementById('manual-entry-toggle-icon');
            if (!body || !icon) return;
            var isCollapsed = body.classList.contains('collapsed');
            body.classList.toggle('collapsed', !isCollapsed);
            try { localStorage.setItem(MANUAL_ENTRY_STORAGE_KEY, isCollapsed ? '0' : '1'); } catch (e) {}
            var iconI = icon.querySelector('i');
            if (iconI) {
                iconI.className = body.classList.contains('collapsed') ? 'fas fa-chevron-down' : 'fas fa-chevron-up';
            }
        }

        function applyManualEntrySectionState() {
            var body = document.getElementById('manual-entry-body');
            var icon = document.getElementById('manual-entry-toggle-icon');
            if (!body || !icon) return;
            var collapsed = false;
            try { collapsed = localStorage.getItem(MANUAL_ENTRY_STORAGE_KEY) === '1'; } catch (e) {}
            body.classList.toggle('collapsed', collapsed);
            var iconI = icon.querySelector('i');
            if (iconI) iconI.className = collapsed ? 'fas fa-chevron-down' : 'fas fa-chevron-up';
        }

        function openManualItemModal() {
            if (!db || !db.settings || db.settings.enableManualSale !== true) return;
            // Default Cart System: Ensure there's always an active cart
            if (!activeTableId || !db.tables || !db.tables.find(t => t.id === activeTableId)) {
                ensureDefaultCart();
            }
            
            const modal = document.getElementById('manual-item-modal');
            const nameInput = document.getElementById('manual-item-name');
            const priceInput = document.getElementById('manual-item-price');
            const costInput = document.getElementById('manual-item-cost');
            if (!modal || !nameInput || !priceInput) return;
            var panel = document.getElementById('manual-manage-panel');
            var toggleBtn = document.getElementById('manual-manage-toggle');
            if (panel) panel.style.display = 'none';
            if (toggleBtn) toggleBtn.classList.remove('active');
            if (typeof applyManualModalLanguage === 'function') applyManualModalLanguage(modal);
            if (typeof applyManualEntrySectionState === 'function') applyManualEntrySectionState();
            nameInput.value = '';
            priceInput.value = '';
            if (costInput) costInput.value = '';
            var newName = document.getElementById('manual-modal-new-name');
            var newPrice = document.getElementById('manual-modal-new-price');
            var newCost = document.getElementById('manual-modal-new-cost');
            if (newName) newName.value = ''; if (newPrice) newPrice.value = ''; if (newCost) newCost.value = '';
            if (typeof renderManualQuickItems === 'function') renderManualQuickItems();
            if (typeof renderManualModalQuickList === 'function') renderManualModalQuickList();
            if (typeof applyMoneyInputFields === 'function') applyMoneyInputFields(modal);
            modal.style.display = 'flex';
            var onManualKey = function(e) {
                if (e.key === 'Enter' && (e.target === nameInput || e.target === priceInput || e.target === costInput)) {
                    e.preventDefault();
                    confirmManualItem();
                }
            };
            modal._manualKeyHandler = onManualKey;
            document.addEventListener('keydown', onManualKey);
            setTimeout(function() { if (nameInput) nameInput.focus(); }, 50);
        }

        function closeManualItemModal() {
            const modal = document.getElementById('manual-item-modal');
            if (modal && modal._manualKeyHandler) {
                document.removeEventListener('keydown', modal._manualKeyHandler);
                modal._manualKeyHandler = null;
            }
            if (modal) modal.style.display = 'none';
        }

        /** Add manual-entry item to cart. Service line only — no stock deduction (trackStock false, no product id). */
        function confirmManualItem() {
            const nameInput = document.getElementById('manual-item-name');
            const priceInput = document.getElementById('manual-item-price');
            const costInput = document.getElementById('manual-item-cost');
            if (!nameInput || !priceInput) { closeManualItemModal(); return; }
            const name = (nameInput.value || '').trim();
            var money = (typeof buildCartLineMoneyFromInput === 'function')
                ? buildCartLineMoneyFromInput(priceInput.value || '')
                : { price: parseFloat((priceInput.value || '').replace(/,/g, '')) || 0 };
            var cost = costInput ? parseManualCostInput(costInput.value) : 0;
            if (!name) { showToast(typeof t === 'function' ? t('manual_enter_name') : "هیڤیە ناڤێ صنفێ بنڤیسی.", "error"); return; }
            if (!money.price || money.price <= 0) { showToast("بهای خەلەتە!", "error"); return; }
            const table = db.tables.find(t => t.id === activeTableId);
            if (!table) { showToast("هیڤیە " + (typeof getTablesLabelShort === 'function' ? getTablesLabelShort() : 'مێز') + " هەڵبژێری.", "error"); return; }
            addManualLineToCart(table, {
                name,
                price: money.price,
                bill_unit_usd: money.bill_unit_usd,
                cost: cost,
                barcode: '',
                supplier: 'Manual',
                cat: 'Custom',
                trackStock: false,
                isManualItem: true,
                isManualPrice: true
            });
            lastTableState = "";
            if (typeof onCartChanged === 'function') onCartChanged({ fast: true });
            closeManualItemModal();
        }
