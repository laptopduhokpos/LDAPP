<?php
/**
 * Laptop Duhok POS — Mobile Item Entry & API
 * Fast, lightweight, zero-impact endpoint for LD Manager and mobile product entry.
 */

// 1. CORS headers
if (file_exists(__DIR__ . '/config/cors.php')) {
    require_once __DIR__ . '/config/cors.php';
}

if (!function_exists('pos_api_cors_apply_headers')) {
    function pos_api_cors_apply_headers() {
        if (headers_sent()) return;
        $origin = isset($_SERVER['HTTP_ORIGIN']) ? trim((string)$_SERVER['HTTP_ORIGIN']) : '';
        if ($origin !== '') {
            header('Access-Control-Allow-Origin: ' . $origin);
            header('Vary: Origin');
            header('Access-Control-Allow-Credentials: true');
        } else {
            header('Access-Control-Allow-Origin: *');
        }
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
        $reqHdr = isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']) ? trim((string)$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']) : '';
        if ($reqHdr !== '') {
            header('Access-Control-Allow-Headers: ' . $reqHdr);
        } else {
            header('Access-Control-Allow-Headers: Content-Type, X-Requested-With, Authorization, Accept');
        }
        header('Access-Control-Max-Age: 86400');
    }
}

if (!function_exists('pos_api_cors_handle_options_and_exit')) {
    function pos_api_cors_handle_options_and_exit() {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'OPTIONS') {
            return false;
        }
        pos_api_cors_apply_headers();
        header('Content-Length: 0');
        http_response_code(204);
        return true;
    }
}

if (function_exists('pos_api_cors_handle_options_and_exit') && pos_api_cors_handle_options_and_exit()) {
    exit();
}

pos_api_cors_apply_headers();

// 2. Load DB
require_once __DIR__ . '/config/database.php';
if (file_exists(__DIR__ . '/config/version.php')) {
    require_once __DIR__ . '/config/version.php';
}
if (!defined('POS_APP_VERSION')) {
    define('POS_APP_VERSION', '3.16.24');
}

// 3. Helper for touchLastUpdate
if (!function_exists('touchLastUpdate')) {
    function touchLastUpdate($conn) {
        if (!$conn) return;
        $t = (string)microtime(true);
        $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('last_update', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        if ($stmt) {
            $stmt->bind_param("ss", $t, $t);
            $stmt->execute();
        }
    }
}

// 4. Handle AJAX API requests
$isPost = (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST');
$isAjax = isset($_GET['ajax']) || $isPost || (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest');

if ($isAjax) {
    header('Content-Type: application/json; charset=utf-8');
    $action = $_REQUEST['action'] ?? '';

    // Action: Lookup Barcode (Comprehensive with pieces, packs, cartons)
    if ($action === 'lookup_barcode') {
        $barcode = trim((string)($_GET['barcode'] ?? $_POST['barcode'] ?? ''));
        if ($barcode === '') {
            echo json_encode(['status' => 'error', 'message' => 'بارکۆد بەتاڵە']);
            exit();
        }
        $stmt = $conn->prepare("SELECT id, name, barcode, price, cost, qty, category, supplier, manufacturer, trackStock, unitType, qty_mode, itemsPerCarton, forSale, wholesaleQty, wholesalePrice, minStock, pieces_per_pack, packs_per_carton, barcode_pack, barcode_carton, price_pack, price_carton, cost_pack, cost_carton, unit_show_pack, unit_show_carton, expiry, note FROM products WHERE barcode = ? OR (barcode_pack != '' AND barcode_pack = ?) OR (barcode_carton != '' AND barcode_carton = ?) LIMIT 1");
        if ($stmt) {
            $stmt->bind_param('sss', $barcode, $barcode, $barcode);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($row = $res->fetch_assoc()) {
                echo json_encode([
                    'status' => 'success',
                    'found' => true,
                    'product' => [
                        'id' => (int)$row['id'],
                        'name' => $row['name'] ?? '',
                        'barcode' => $row['barcode'] ?? '',
                        'price' => (float)($row['price'] ?? 0),
                        'cost' => (float)($row['cost'] ?? 0),
                        'qty' => (float)($row['qty'] ?? 0),
                        'category' => $row['category'] ?? '',
                        'supplier' => $row['supplier'] ?? '',
                        'manufacturer' => $row['manufacturer'] ?? '',
                        'trackStock' => (int)($row['trackStock'] ?? 1),
                        'unitType' => $row['unitType'] ?? 'carton',
                        'qty_mode' => $row['qty_mode'] ?? 'piece',
                        'itemsPerCarton' => (int)($row['itemsPerCarton'] ?? 1),
                        'forSale' => (int)($row['forSale'] ?? 1),
                        'wholesaleQty' => (int)($row['wholesaleQty'] ?? 0),
                        'wholesalePrice' => (float)($row['wholesalePrice'] ?? 0),
                        'minStock' => (int)($row['minStock'] ?? 5),
                        'pieces_per_pack' => (int)($row['pieces_per_pack'] ?? 1),
                        'packs_per_carton' => (int)($row['packs_per_carton'] ?? 1),
                        'barcode_pack' => $row['barcode_pack'] ?? '',
                        'barcode_carton' => $row['barcode_carton'] ?? '',
                        'price_pack' => $row['price_pack'] !== null ? (float)$row['price_pack'] : 0,
                        'price_carton' => $row['price_carton'] !== null ? (float)$row['price_carton'] : 0,
                        'cost_pack' => $row['cost_pack'] !== null ? (float)$row['cost_pack'] : 0,
                        'cost_carton' => $row['cost_carton'] !== null ? (float)$row['cost_carton'] : 0,
                        'unit_show_pack' => (int)($row['unit_show_pack'] ?? 0),
                        'unit_show_carton' => (int)($row['unit_show_carton'] ?? 0),
                        'expiry' => $row['expiry'] ?? '',
                        'note' => $row['note'] ?? ''
                    ]
                ], JSON_UNESCAPED_UNICODE);
                exit();
            }
        }
        echo json_encode(['status' => 'success', 'found' => false]);
        exit();
    }

    // Action: Save or Update Product (Full data: Name, barcode, units, packs, cartons, costs, prices, stock, wholesale, expiry, manufacturer)
    if ($action === 'save_product') {
        $productId = (int)($_POST['product_id'] ?? ($_POST['id'] ?? 0));
        $name = trim((string)($_POST['name'] ?? ''));
        $barcode = trim((string)($_POST['barcode'] ?? ''));
        $category = trim((string)($_POST['category'] ?? ''));
        $manufacturer = trim((string)($_POST['manufacturer'] ?? ''));
        $supplier = trim((string)($_POST['supplier'] ?? 'Direct Store'));

        $price = (float)($_POST['price'] ?? 0);
        $cost = (float)($_POST['cost'] ?? 0);
        $inputQty = (float)($_POST['qty'] ?? 0);
        $qtyMode = trim((string)($_POST['qty_mode'] ?? 'add')); // 'add' or 'set'
        $trackStock = isset($_POST['trackStock']) ? (int)$_POST['trackStock'] : 1;

        $unit_show_pack = isset($_POST['unit_show_pack']) ? (int)$_POST['unit_show_pack'] : 0;
        $unit_show_carton = isset($_POST['unit_show_carton']) ? (int)$_POST['unit_show_carton'] : 0;
        $pieces_per_pack = max(1, (int)($_POST['pieces_per_pack'] ?? 1));
        $packs_per_carton = max(1, (int)($_POST['packs_per_carton'] ?? 1));
        $itemsPerCarton = $pieces_per_pack * $packs_per_carton;

        $barcode_pack = trim((string)($_POST['barcode_pack'] ?? ''));
        $barcode_carton = trim((string)($_POST['barcode_carton'] ?? ''));
        $price_pack = isset($_POST['price_pack']) && $_POST['price_pack'] !== '' ? (float)$_POST['price_pack'] : 0;
        $cost_pack = isset($_POST['cost_pack']) && $_POST['cost_pack'] !== '' ? (float)$_POST['cost_pack'] : 0;
        $price_carton = isset($_POST['price_carton']) && $_POST['price_carton'] !== '' ? (float)$_POST['price_carton'] : 0;
        $cost_carton = isset($_POST['cost_carton']) && $_POST['cost_carton'] !== '' ? (float)$_POST['cost_carton'] : 0;

        $wholesaleQty = (int)($_POST['wholesaleQty'] ?? 0);
        $wholesalePrice = (float)($_POST['wholesalePrice'] ?? 0);
        $expiry = trim((string)($_POST['expiry'] ?? ''));
        $minStock = isset($_POST['minStock']) && $_POST['minStock'] !== '' ? max(1, (int)$_POST['minStock']) : 5;
        $note = trim((string)($_POST['note'] ?? ''));
        $forSale = isset($_POST['forSale']) ? (int)$_POST['forSale'] : 1;

        if ($name === '' && $barcode !== '') {
            $name = 'کاڵا ' . $barcode;
        }

        if ($name === '') {
            echo json_encode(['status' => 'error', 'message' => 'تکایە ناڤێ کاڵای بنڤیسە']);
            exit();
        }

        // 4.1 Update existing by ID
        if ($productId > 0) {
            $sql = "UPDATE products SET 
                name = ?, 
                barcode = ?, 
                price = ?, 
                cost = ?, 
                category = ?, 
                supplier = ?, 
                manufacturer = ?, 
                trackStock = ?, 
                itemsPerCarton = ?, 
                forSale = ?, 
                wholesaleQty = ?, 
                wholesalePrice = ?, 
                expiry = ?, 
                minStock = ?, 
                pieces_per_pack = ?, 
                packs_per_carton = ?, 
                barcode_pack = ?, 
                barcode_carton = ?, 
                price_pack = ?, 
                price_carton = ?, 
                cost_pack = ?, 
                cost_carton = ?, 
                unit_show_pack = ?, 
                unit_show_carton = ?, 
                note = ?, 
                qty = (CASE WHEN ? = 'add' THEN qty + ? ELSE ? END) 
                WHERE id = ?";

            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param(
                    'ssddsssiisidsiiissddddiissddi',
                    $name,
                    $barcode,
                    $price,
                    $cost,
                    $category,
                    $supplier,
                    $manufacturer,
                    $trackStock,
                    $itemsPerCarton,
                    $forSale,
                    $wholesaleQty,
                    $wholesalePrice,
                    $expiry,
                    $minStock,
                    $pieces_per_pack,
                    $packs_per_carton,
                    $barcode_pack,
                    $barcode_carton,
                    $price_pack,
                    $price_carton,
                    $cost_pack,
                    $cost_carton,
                    $unit_show_pack,
                    $unit_show_carton,
                    $note,
                    $qtyMode,
                    $inputQty,
                    $inputQty,
                    $productId
                );

                if ($stmt->execute()) {
                    touchLastUpdate($conn);
                    $qRes = $conn->query("SELECT qty FROM products WHERE id = " . (int)$productId);
                    $curQty = $qRes ? (float)($qRes->fetch_assoc()['qty'] ?? 0) : $inputQty;

                    echo json_encode([
                        'status' => 'success',
                        'action' => 'update',
                        'id' => $productId,
                        'name' => $name,
                        'barcode' => $barcode,
                        'qty' => $curQty,
                        'price' => $price,
                        'message' => 'کاڵا ب سەرکەفتی هاتە نوێکرن'
                    ], JSON_UNESCAPED_UNICODE);
                    exit();
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'خەلەتیا نوێکرنێ: ' . $stmt->error]);
                    exit();
                }
            } else {
                echo json_encode(['status' => 'error', 'message' => 'خەلەتیا داتابەیسێ: ' . $conn->error]);
                exit();
            }
        } else {
            // 4.2 Check if barcode already exists
            if ($barcode !== '') {
                $chk = $conn->prepare("SELECT id FROM products WHERE barcode = ? OR (barcode_pack != '' AND barcode_pack = ?) OR (barcode_carton != '' AND barcode_carton = ?) LIMIT 1");
                $chk->bind_param('sss', $barcode, $barcode, $barcode);
                $chk->execute();
                $cRes = $chk->get_result();
                if ($cRow = $cRes->fetch_assoc()) {
                    $existId = (int)$cRow['id'];
                    $sql = "UPDATE products SET 
                        name = ?, 
                        barcode = ?, 
                        price = ?, 
                        cost = ?, 
                        category = ?, 
                        supplier = ?, 
                        manufacturer = ?, 
                        trackStock = ?, 
                        itemsPerCarton = ?, 
                        forSale = ?, 
                        wholesaleQty = ?, 
                        wholesalePrice = ?, 
                        expiry = ?, 
                        minStock = ?, 
                        pieces_per_pack = ?, 
                        packs_per_carton = ?, 
                        barcode_pack = ?, 
                        barcode_carton = ?, 
                        price_pack = ?, 
                        price_carton = ?, 
                        cost_pack = ?, 
                        cost_carton = ?, 
                        unit_show_pack = ?, 
                        unit_show_carton = ?, 
                        note = ?, 
                        qty = (CASE WHEN ? = 'add' THEN qty + ? ELSE ? END) 
                        WHERE id = ?";

                    $stmt = $conn->prepare($sql);
                    if ($stmt) {
                        $stmt->bind_param(
                            'ssddsssiisidsiiissddddiissddi',
                            $name,
                            $barcode,
                            $price,
                            $cost,
                            $category,
                            $supplier,
                            $manufacturer,
                            $trackStock,
                            $itemsPerCarton,
                            $forSale,
                            $wholesaleQty,
                            $wholesalePrice,
                            $expiry,
                            $minStock,
                            $pieces_per_pack,
                            $packs_per_carton,
                            $barcode_pack,
                            $barcode_carton,
                            $price_pack,
                            $price_carton,
                            $cost_pack,
                            $cost_carton,
                            $unit_show_pack,
                            $unit_show_carton,
                            $note,
                            $qtyMode,
                            $inputQty,
                            $inputQty,
                            $existId
                        );
                        if ($stmt->execute()) {
                            touchLastUpdate($conn);
                            $qRes = $conn->query("SELECT qty FROM products WHERE id = " . (int)$existId);
                            $curQty = $qRes ? (float)($qRes->fetch_assoc()['qty'] ?? 0) : $inputQty;
                            echo json_encode([
                                'status' => 'success',
                                'action' => 'update',
                                'id' => $existId,
                                'name' => $name,
                                'barcode' => $barcode,
                                'qty' => $curQty,
                                'price' => $price,
                                'message' => 'کاڵایێ هەبوو هاتە نوێکرن'
                            ], JSON_UNESCAPED_UNICODE);
                            exit();
                        }
                    }
                }
            }

            // 4.3 Insert new product
            $sql = "INSERT INTO products (
                name, barcode, price, cost, qty, category, supplier, manufacturer, 
                trackStock, unitType, qty_mode, itemsPerCarton, forSale, wholesaleQty, wholesalePrice, 
                expiry, minStock, pieces_per_pack, packs_per_carton, barcode_pack, barcode_carton, 
                price_pack, price_carton, cost_pack, cost_carton, unit_show_pack, unit_show_carton, note
            ) VALUES (
                ?, ?, ?, ?, ?, ?, ?, ?, 
                ?, 'carton', 'piece', ?, ?, ?, ?, 
                ?, ?, ?, ?, ?, ?, 
                ?, ?, ?, ?, ?, ?, ?
            )";

            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param(
                    'ssdddsssiisidsiiissddddiis',
                    $name,
                    $barcode,
                    $price,
                    $cost,
                    $inputQty,
                    $category,
                    $supplier,
                    $manufacturer,
                    $trackStock,
                    $itemsPerCarton,
                    $forSale,
                    $wholesaleQty,
                    $wholesalePrice,
                    $expiry,
                    $minStock,
                    $pieces_per_pack,
                    $packs_per_carton,
                    $barcode_pack,
                    $barcode_carton,
                    $price_pack,
                    $price_carton,
                    $cost_pack,
                    $cost_carton,
                    $unit_show_pack,
                    $unit_show_carton,
                    $note
                );

                if ($stmt->execute()) {
                    $newId = $conn->insert_id;
                    touchLastUpdate($conn);
                    echo json_encode([
                        'status' => 'success',
                        'action' => 'insert',
                        'id' => $newId,
                        'name' => $name,
                        'barcode' => $barcode,
                        'qty' => $inputQty,
                        'price' => $price,
                        'message' => 'کاڵایێ نوێ ب سەرکەفتی هاتە تۆمارکرن'
                    ], JSON_UNESCAPED_UNICODE);
                    exit();
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'نەهاتە تۆمارکرن: ' . $stmt->error]);
                    exit();
                }
            } else {
                echo json_encode(['status' => 'error', 'message' => 'خەلەتیا داتابەیسێ: ' . $conn->error]);
                exit();
            }
        }
    }

    echo json_encode(['status' => 'error', 'message' => 'کرداری نەناسراو']);
    exit();
}

// 5. If opened directly in browser, redirect to LD Manager with #entry
header('Location: _PRIVATE/mobile_manager/index.html#entry');
exit();
