<?php
// GET: export backup, mega stats dashboard
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_database_size_report') {
    header('Content-Type: application/json; charset=utf-8');
    pos_session_require_login_json();
    if (!pos_session_is_admin()) pos_json_perm_denied();
    $report = function_exists('pos_get_database_size_report')
        ? pos_get_database_size_report($conn)
        : ['total_mb' => 0, 'tables' => [], 'tips' => []];
    echo json_encode(['status' => 'success', 'report' => $report], JSON_UNESCAPED_UNICODE);
    exit();
}

// --- COMPREHENSIVE FULL BACKUP (JSON/ZIP) ---
// --- Incremental flash delta (new rows only; keeps POS fast) ---
if (isset($_GET['action']) && $_GET['action'] === 'export_flash_delta') {
    pos_session_require_login_json();
    header('Content-Type: application/json; charset=utf-8');
    $init = !empty($_GET['init']) && (string)$_GET['init'] === '1';
    $since = [];
    if (!$init) {
        $raw = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $raw = (string)file_get_contents('php://input');
            if ($raw === '' && isset($_POST['since'])) {
                $raw = (string)$_POST['since'];
            }
        } elseif (isset($_GET['since'])) {
            $raw = (string)$_GET['since'];
        }
        if ($raw !== '') {
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                $since = $decoded;
            } elseif (isset($decoded['watermarks']) && is_array($decoded['watermarks'])) {
                $since = $decoded['watermarks'];
            }
        }
        // Also accept { watermarks: {...} } body
        if (isset($since['watermarks']) && is_array($since['watermarks'])) {
            $since = $since['watermarks'];
        }
    }
    try {
        $payload = pos_build_flash_delta_payload($conn, is_array($since) ? $since : [], ['init' => $init]);
        echo json_encode(['status' => 'success', 'delta' => $payload], JSON_UNESCAPED_UNICODE);
    } catch (\Throwable $e) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
    }
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] == 'export_full_backup') {

    pos_session_require_login_json();
    $isTgAuto = isset($_GET['for_tg']) && $_GET['for_tg'] == 1;
    $isFlashAuto = isset($_GET['for_flash']) && $_GET['for_flash'] == '1';
    if (!pos_session_is_admin() && !$isTgAuto && !$isFlashAuto) pos_json_perm_denied();
    ini_set('memory_limit', '4096M');
    ini_set('max_execution_time', '1200');

    // Telegram / normal download: never mutate DB before backup (only explicit maintain=1 on manual safe backup).
    $runMaintain = !$isTgAuto && !empty($_GET['maintain']) && $_GET['maintain'] == '1';
    if ($runMaintain && function_exists('pos_run_ten_year_maintenance')) {
        $conn->begin_transaction();
        try {
            pos_run_ten_year_maintenance($conn, [
                'archive_days' => (int)($_GET['archive_days'] ?? 365),
                'movement_years' => 0,
            ]);
            $conn->commit();
            touchLastUpdate($conn);
        } catch (\Throwable $e) {
            $conn->rollback();
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
            exit();
        }
    }

    $backupOpts = ['profile' => $isTgAuto ? 'telegram_full' : 'full'];
    if ($isTgAuto) {
        // Full business data for Telegram — only internal rollback snapshots omitted.
    } elseif (isset($_GET['slim']) && $_GET['slim'] == '1') {
        $backupOpts['slim'] = true;
    }
    if (!$isTgAuto && isset($_GET['years_keep']) && (int)$_GET['years_keep'] > 0) {
        $backupOpts['years_keep'] = min(20, max(1, (int)$_GET['years_keep']));
    }

    $part = isset($_GET['part']) ? (int)$_GET['part'] : 0;
    if ($part === 1 || $part === 2) {
        $groups = pos_get_backup_split_groups($conn);
        $splitGap = pos_backup_split_missing_tables($conn, $groups);
        if ($splitGap) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode([
                'status' => 'error',
                'message' => 'Backup split incomplete — missing tables: ' . implode(', ', $splitGap),
            ], JSON_UNESCAPED_UNICODE);
            exit();
        }
        if (!isset($groups[$part])) {
            http_response_code(400);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['status' => 'error', 'message' => 'Invalid backup part'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $data = buildPartialBackupPayload($conn, $groups[$part], $backupOpts, $part, 2);
    } else {
        $tables = getBackupTableList($conn);
        $data = buildDatabaseBackupPayload($conn, $tables, $backupOpts);
    }

    $jsonFlags = JSON_UNESCAPED_UNICODE;
    if (defined('JSON_PARTIAL_OUTPUT_ON_ERROR')) $jsonFlags |= JSON_PARTIAL_OUTPUT_ON_ERROR;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) $jsonFlags |= JSON_INVALID_UTF8_SUBSTITUTE;

    $json = json_encode($data, $jsonFlags);
    if ($json === false) {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['status' => 'error', 'message' => 'JSON encode failed: ' . json_last_error_msg()], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $filenameBase = 'Laptop_Duhok_POS_FullBackup_' . date('Y-m-d_H-i-s');
    if ($part === 1 || $part === 2) {
        $filenameBase .= '_part' . $part;
    }
    $wantRawJson = isset($_GET['zip']) && (string)$_GET['zip'] === '0';
    $wantLegacyZip = isset($_GET['legacy_zip']) && (string)$_GET['legacy_zip'] === '1';
    $includeFiles = !$isTgAuto && (!isset($_GET['include_files']) || $_GET['include_files'] != 0);
    $saveGit = !$isTgAuto && isset($_GET['save_git']) && $_GET['save_git'] == 1;
    $saveLocal = !$isTgAuto && $part === 0 && (!isset($_GET['save_local']) || $_GET['save_local'] != '0');

    $outputData = $json;
    $downloadFileName = $filenameBase . '.json';
    $contentType = 'application/json; charset=utf-8';
    $verify = ($part > 0)
        ? ['ok' => true, 'missing' => [], 'table_counts' => ($data['table_counts'] ?? [])]
        : pos_verify_backup_payload($data, $conn);
    if ($part === 0 && empty($verify['ok'])) {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'status' => 'error',
            'message' => 'Backup incomplete — missing critical tables: ' . implode(', ', $verify['missing'] ?? []),
            'missing' => $verify['missing'] ?? [],
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $extraHeaders = [
        'X-Backup-Profile' => $backupOpts['profile'],
        'X-Backup-Verified' => !empty($verify['ok']) ? '1' : '0',
        'X-Backup-Tables' => (string)count($data['table_data'] ?? []),
        'X-Backup-Rows' => (string)array_sum(array_map('intval', $data['table_counts'] ?? [])),
    ];
    if ($part > 0) {
        $extraHeaders['X-Backup-Part'] = (string)$part;
        $extraHeaders['X-Backup-Parts-Total'] = '2';
    }

    if ($wantLegacyZip) {
        try {
            list($zipBinary, $manifest) = buildZipBackupPackage(__DIR__ . '/..', $data, $filenameBase, $includeFiles);
            $outputData = $zipBinary;
            $downloadFileName = $filenameBase . '.zip';
            $contentType = 'application/zip';
            $extraHeaders['X-Backup-Format'] = 'full_zip_package_v2';
        } catch (\Throwable $e) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
            $msg = 'فایلێ باک‌ئەپێ دروست نەبوو. Apache Restart بکە یان Chrome/Edge بکاربینە.';
            if (function_exists('logAction')) {
                logAction($conn, 'System', 'backup_error', $e->getMessage() . ' in ' . basename($e->getFile()) . ':' . $e->getLine());
            }
            echo json_encode(['status' => 'error', 'message' => $msg], JSON_UNESCAPED_UNICODE);
            exit();
        }
    } elseif (!$wantRawJson) {
        try {
            $pkg = pos_encode_posbak($data, $filenameBase, 'full');
            $outputData = $pkg['binary'];
            $downloadFileName = $pkg['filename'];
            $contentType = $pkg['content_type'];
            $extraHeaders['X-Backup-Format'] = $pkg['format'];
        } catch (\Throwable $e) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
            if (function_exists('logAction')) {
                logAction($conn, 'System', 'backup_error', $e->getMessage() . ' in ' . basename($e->getFile()) . ':' . $e->getLine());
            }
            echo json_encode(['status' => 'error', 'message' => 'فایلێ باک‌ئەپێ دروست نەبوو.'], JSON_UNESCAPED_UNICODE);
            exit();
        }
    } else {
        $extraHeaders['X-Backup-Format'] = 'json';
    }

    if ($saveLocal && function_exists('pos_save_backup_to_folder')) {
        $savedLocal = pos_save_backup_to_folder($outputData, $downloadFileName);
        if ($savedLocal && !empty($savedLocal['name'])) {
            $extraHeaders['X-Backup-Saved-Local'] = $savedLocal['name'];
        }
    }

    if ($saveGit && function_exists('pos_save_backup_to_git_folder')) {
        pos_save_backup_to_git_folder($outputData, $downloadFileName);
    }

    if (isset($_GET['copy_to_usb']) && (string)$_GET['copy_to_usb'] === '1') {
        header('Content-Type: application/json; charset=utf-8');
        $deviceId = function_exists('pos_flash_usb_normalize_device_id')
            ? pos_flash_usb_normalize_device_id($_GET['device_id'] ?? '')
            : '';
        $copied = function_exists('pos_flash_usb_copy_bytes')
            ? pos_flash_usb_copy_bytes($outputData, 'Laptop_Duhok_POS_Latest.posbak', $deviceId)
            : ['ok' => false, 'reason' => 'unsupported'];
        if (!empty($copied['ok'])) {
            echo json_encode([
                'status' => 'success',
                'ok' => true,
                'letter' => $copied['letter'] ?? '',
                'name' => $copied['name'] ?? '',
                'bytes' => (int)($copied['bytes'] ?? 0),
            ], JSON_UNESCAPED_UNICODE);
        } else {
            echo json_encode([
                'status' => 'error',
                'ok' => false,
                'reason' => $copied['reason'] ?? 'disconnected',
            ], JSON_UNESCAPED_UNICODE);
        }
        exit();
    }

    if (isset($_GET['download']) && $_GET['download'] == 1) {
        pos_send_backup_download_headers($contentType, $downloadFileName, $outputData, $extraHeaders);
        exit();
    }

    header('Content-Type: ' . $contentType);
    header('Content-Disposition: attachment; filename="' . $downloadFileName . '"');
    header('Content-Length: ' . strlen($outputData));
    echo $outputData;
    exit();
}

if (isset($_GET['action']) && $_GET['action'] === 'flash_usb_ping') {
    header('Content-Type: application/json; charset=utf-8');
    pos_session_require_login_json();
    $deviceId = function_exists('pos_flash_usb_normalize_device_id')
        ? pos_flash_usb_normalize_device_id($_GET['device_id'] ?? '')
        : '';
    $ping = function_exists('pos_flash_usb_ping')
        ? pos_flash_usb_ping($deviceId)
        : ['ok' => false, 'reason' => 'unsupported'];
    echo json_encode([
        'status' => !empty($ping['ok']) ? 'success' : 'error',
        'ok' => !empty($ping['ok']),
        'reason' => $ping['reason'] ?? '',
        'letter' => $ping['letter'] ?? '',
        'device_id' => $ping['device_id'] ?? '',
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

if (isset($_GET['action']) && $_GET['action'] === 'flash_usb_write') {
    header('Content-Type: application/json; charset=utf-8');
    pos_session_require_login_json();
    $deviceId = function_exists('pos_flash_usb_normalize_device_id')
        ? pos_flash_usb_normalize_device_id($_POST['device_id'] ?? ($_GET['device_id'] ?? ''))
        : '';
    $fileName = isset($_POST['filename']) ? (string)$_POST['filename'] : 'Laptop_Duhok_POS_Latest.posbak';
    if (!isset($_FILES['file']) || !is_uploaded_file($_FILES['file']['tmp_name'])) {
        echo json_encode(['status' => 'error', 'ok' => false, 'reason' => 'no_file'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $copied = function_exists('pos_flash_usb_copy_uploaded')
        ? pos_flash_usb_copy_uploaded($_FILES['file']['tmp_name'], $fileName, $deviceId)
        : ['ok' => false, 'reason' => 'unsupported'];
    echo json_encode([
        'status' => !empty($copied['ok']) ? 'success' : 'error',
        'ok' => !empty($copied['ok']),
        'reason' => $copied['reason'] ?? '',
        'letter' => $copied['letter'] ?? '',
        'name' => $copied['name'] ?? '',
        'bytes' => (int)($copied['bytes'] ?? 0),
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'list_local_backups') {
    header('Content-Type: application/json; charset=utf-8');
    pos_session_require_login_json();
    if (!pos_session_is_admin()) pos_json_perm_denied();
    $list = function_exists('pos_list_local_backups') ? pos_list_local_backups(25) : [];
    echo json_encode(['status' => 'success', 'backups' => $list, 'dir' => 'backups/'], JSON_UNESCAPED_UNICODE);
    exit();
}

// --- XAMPP mysql/data folder backup (raw, safer disaster recovery) ---
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'export_mysql_data_backup') {
    pos_session_require_login_json();
    $isFlashAuto = isset($_GET['for_flash']) && $_GET['for_flash'] == '1';
    if (!pos_session_is_admin() && !$isFlashAuto) pos_json_perm_denied();
    ini_set('memory_limit', '2048M');
    ini_set('max_execution_time', '900');

    $scope = isset($_GET['scope']) ? (string)$_GET['scope'] : 'full';
    try {
        $built = pos_build_mysql_data_zip($scope, $conn);
    } catch (\Throwable $e) {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $filename = 'XAMPP_MySQL_Data_' . ($built['scope'] === 'db' ? 'DB_' : 'FULL_') . date('Y-m-d_H-i-s') . '.zip';
    $savedLocal = '';
    if (!isset($_GET['save_local']) || $_GET['save_local'] != '0') {
        $bin = @file_get_contents($built['path']);
        if ($bin !== false && function_exists('pos_save_backup_to_folder')) {
            $saved = pos_save_backup_to_folder($bin, $filename, 30);
            if ($saved && !empty($saved['name'])) {
                $savedLocal = $saved['name'];
            }
            unset($bin);
        }
    }

    while (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . (string)$built['bytes']);
    header('X-Backup-Type: xampp_mysql_data');
    header('X-Backup-Scope: ' . $built['scope']);
    header('X-Backup-Files: ' . (string)$built['files']);
    header('X-Mysql-Data-Dir: ' . str_replace(["\r", "\n"], '', (string)$built['data_dir']));
    if ($savedLocal !== '') {
        header('X-Backup-Saved-Local: ' . $savedLocal);
    }
    header('Cache-Control: no-store, no-cache, must-revalidate');
    header('Pragma: no-cache');
    readfile($built['path']);
    @unlink($built['path']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'mysql_data_backup_info') {
    header('Content-Type: application/json; charset=utf-8');
    pos_session_require_login_json();
    if (!pos_session_is_admin()) pos_json_perm_denied();
    $dir = function_exists('pos_mysql_data_dir') ? pos_mysql_data_dir() : null;
    $pid = $dir ? is_file($dir . DIRECTORY_SEPARATOR . 'mysql.pid') : false;
    echo json_encode([
        'status' => 'success',
        'data_dir' => $dir,
        'mysql_running_hint' => $pid,
        'xampp_root' => function_exists('pos_xampp_root_path') ? pos_xampp_root_path() : null,
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'download_local_backup') {
    pos_session_require_login_json();
    if (!pos_session_is_admin()) pos_json_perm_denied();
    $name = isset($_GET['name']) ? (string)$_GET['name'] : '';
    try {
        $path = pos_resolve_local_backup_path($name);
    } catch (\Throwable $e) {
        http_response_code(404);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
        exit();
    }
    while (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . basename($name) . '"');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    header('Pragma: no-cache');
    header('Content-Length: ' . filesize($path));
    readfile($path);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_mobile_backup_info') {
    header('Content-Type: application/json; charset=utf-8');
    pos_session_require_login_json();
    if (!pos_session_is_admin()) pos_json_perm_denied();
    $pin = function_exists('pos_get_mobile_backup_pin') ? pos_get_mobile_backup_pin($conn, false) : '';
    $usesSettingsPin = false;
    if (function_exists('pos_load_app_settings_array')) {
        $s = pos_load_app_settings_array($conn);
        $dedicated = preg_replace('/\D/', '', (string)($s['mobileBackupPin'] ?? ''));
        $usesSettingsPin = (strlen($dedicated) < 4);
    }
    echo json_encode([
        'status' => 'success',
        'pin' => $pin,
        'uses_settings_pin' => $usesSettingsPin,
        'hint' => 'same_wifi',
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

$mobileBackupAction = isset($_GET['action']) ? (string)$_GET['action'] : (isset($_POST['action']) ? (string)$_POST['action'] : '');
$mobileBackupMethod = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if (($mobileBackupMethod === 'GET' || $mobileBackupMethod === 'POST') && $mobileBackupAction === 'mobile_list_backups') {
    header('Content-Type: application/json; charset=utf-8');
    if (function_exists('pos_mobile_backup_require_pin_or_exit')) {
        pos_mobile_backup_require_pin_or_exit($conn);
    }
    $list = function_exists('pos_list_local_backups') ? pos_list_local_backups(25) : [];
    echo json_encode(['status' => 'success', 'backups' => $list], JSON_UNESCAPED_UNICODE);
    exit();
}

if (($mobileBackupMethod === 'GET' || $mobileBackupMethod === 'POST') && $mobileBackupAction === 'mobile_download_backup') {
    if (function_exists('pos_mobile_backup_require_pin_or_exit')) {
        pos_mobile_backup_require_pin_or_exit($conn);
    }
    $name = isset($_POST['name']) ? (string)$_POST['name'] : (isset($_GET['name']) ? (string)$_GET['name'] : '');
    try {
        $path = pos_resolve_local_backup_path($name);
    } catch (\Throwable $e) {
        http_response_code(404);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
        exit();
    }
    while (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . basename($name) . '"');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    header('Pragma: no-cache');
    header('Content-Length: ' . filesize($path));
    readfile($path);
    exit();
}

// --- YEARLY COLD STORAGE BACKUP (one ZIP per year for 10-year plan) ---
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'export_yearly_backup') {
    pos_session_require_login_json();
    if (!pos_session_is_admin()) pos_json_perm_denied();
    ini_set('memory_limit', '1024M');
    ini_set('max_execution_time', '300');

    $year = isset($_GET['year']) ? (int)$_GET['year'] : ((int)date('Y') - 1);
    try {
        $data = buildYearlyBackupPayload($conn, $year);
    } catch (\Throwable $e) {
        http_response_code(400);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $filenameBase = 'Laptop_Duhok_POS_Year_' . $year . '_' . date('Y-m-d_H-i-s');
    $wantRawJson = isset($_GET['zip']) && (string)$_GET['zip'] === '0';
    $outputData = json_encode($data, JSON_UNESCAPED_UNICODE);
    $downloadFileName = $filenameBase . '.json';
    $contentType = 'application/json; charset=utf-8';

    if (!$wantRawJson) {
        $pkg = pos_encode_posbak($data, $filenameBase, 'full');
        $outputData = $pkg['binary'];
        $downloadFileName = $pkg['filename'];
        $contentType = $pkg['content_type'];
    }

    if (isset($_GET['download']) && $_GET['download'] == 1) {
        pos_send_backup_download_headers($contentType, $downloadFileName, $outputData);
        exit();
    }

    header('Content-Type: ' . $contentType);
    header('Content-Disposition: attachment; filename="' . $downloadFileName . '"');
    echo $outputData;
    exit();
}

// --- ITEMS ONLY BACKUP (JSON/ZIP) ---
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] == 'export_items_backup') {

    pos_session_require_login_json();
    if (!pos_session_is_admin()) pos_json_perm_denied();
    ini_set('memory_limit', '2048M');
    ini_set('max_execution_time', '600');
    
    $tables = function_exists('pos_backup_items_tables')
        ? pos_backup_items_tables($conn)
        : ['products', 'categories', 'manufacturers'];
    $data = buildDatabaseBackupPayload($conn, $tables, ['profile' => 'items_only']);
    if (function_exists('pos_sanitize_items_catalog_backup')) {
        $data = pos_sanitize_items_catalog_backup($data);
    }
    $jsonFlags = JSON_UNESCAPED_UNICODE;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
        $jsonFlags |= JSON_INVALID_UTF8_SUBSTITUTE;
    }
    $json = json_encode($data, $jsonFlags);
    if ($json === false) {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'status' => 'error',
            'message' => 'JSON encode failed: ' . json_last_error_msg(),
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    $filenameBase = 'Laptop_Duhok_POS_ItemsBackup_' . date('Y-m-d_H-i-s');
    $wantRawJson = isset($_GET['zip']) && (string)$_GET['zip'] === '0';
    $wantLegacyZip = isset($_GET['legacy_zip']) && (string)$_GET['legacy_zip'] === '1';

    $outputData = $json;
    $downloadFileName = $filenameBase . '.json';
    $contentType = 'application/json; charset=utf-8';
    $productCount = (int)($data['table_counts']['products'] ?? 0);
    $rowTotal = (int)array_sum(array_map('intval', $data['table_counts'] ?? []));
    $extraHeaders = [
        'X-Backup-Profile' => 'items_catalog_zero_stock',
        'X-Backup-Products' => (string)$productCount,
        'X-Backup-Tables' => (string)count($data['table_data'] ?? []),
        'X-Backup-Rows' => (string)$rowTotal,
        'X-Backup-Zero-Qty' => '1',
        'X-Backup-Verified' => ($productCount > 0 || empty($data['table_data']['products'])) ? '1' : '0',
    ];

    if ($wantLegacyZip && class_exists('ZipArchive')) {
        try {
            list($zipBinary, $manifest) = buildZipBackupPackage(__DIR__ . '/..', $data, $filenameBase, false);
            $outputData = $zipBinary;
            $downloadFileName = $filenameBase . '.zip';
            $contentType = 'application/zip';
            $extraHeaders['X-Backup-Format'] = 'full_zip_package_v2';
        } catch (\Throwable $e) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(["status" => "error", "message" => "ZIP Error: " . $e->getMessage()], JSON_UNESCAPED_UNICODE);
            exit();
        }
    } elseif (!$wantRawJson) {
        try {
            $pkg = pos_encode_posbak($data, $filenameBase, 'items');
            $outputData = $pkg['binary'];
            $downloadFileName = $pkg['filename'];
            $contentType = $pkg['content_type'];
            $extraHeaders['X-Backup-Format'] = $pkg['format'];
        } catch (\Throwable $e) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(["status" => "error", "message" => $e->getMessage()], JSON_UNESCAPED_UNICODE);
            exit();
        }
    } else {
        $extraHeaders['X-Backup-Format'] = 'json';
    }

    if (isset($_GET['download']) && $_GET['download'] == 1) {
        pos_send_backup_download_headers($contentType, $downloadFileName, $outputData, $extraHeaders);
        exit();
    }

    header('Content-Type: ' . $contentType);
    header('Content-Disposition: attachment; filename="' . $downloadFileName . '"');
    foreach ($extraHeaders as $hk => $hv) {
        header($hk . ': ' . $hv);
    }
    echo $outputData;
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] == 'export_app_update') {
    // Allow local export without strict session for Admin UI helper
    $isLocal = ($_SERVER['REMOTE_ADDR'] === '127.0.0.1' || $_SERVER['REMOTE_ADDR'] === '::1');
    if (!$isLocal) {
        pos_session_require_login_json();
        if (!pos_session_is_admin()) pos_json_perm_denied();
    }

    ini_set('memory_limit', '2048M');
    ini_set('max_execution_time', '1200');

    $root = realpath(__DIR__ . '/..');
    $diskEntries = [];
    $stringEntries = [];

    $skipExact = [
        'config/database.local.php' => true,
        'config/supabase.local.php' => true,
        '.env' => true,
        '.env.local' => true,
    ];
    $skipPrefix = [
        '_PRIVATE/',
        'backups/',
        'logs/',
        '.git/',
        'node_modules/',
    ];

    if (!function_exists('pos_ota_collect_app_files_recursive')) {
        function pos_ota_collect_app_files_recursive($dir, $base, &$diskEntries, $skipExact, $skipPrefix) {
            $items = @scandir($dir);
            if (!is_array($items)) return;
            foreach ($items as $item) {
                if ($item === '.' || $item === '..') continue;
                $full = $dir . DIRECTORY_SEPARATOR . $item;
                $rel = $base === '' ? $item : ($base . '/' . $item);
                $rel = str_replace('\\', '/', $rel);

                if (isset($skipExact[$rel])) continue;
                $skip = false;
                foreach ($skipPrefix as $sp) {
                    if (strpos($rel, $sp) === 0) {
                        $skip = true;
                        break;
                    }
                }
                if ($skip) continue;

                if (is_dir($full)) {
                    pos_ota_collect_app_files_recursive($full, $rel, $diskEntries, $skipExact, $skipPrefix);
                } elseif (is_file($full)) {
                    $diskEntries[] = ['zip' => $rel, 'abs' => $full];
                }
            }
        }
    }

    pos_ota_collect_app_files_recursive($root, '', $diskEntries, $skipExact, $skipPrefix);

    $version = defined('POS_APP_VERSION') ? (string)POS_APP_VERSION : '3.7.60';
    $tmpZip = rtrim(sys_get_temp_dir(), '/\\') . DIRECTORY_SEPARATOR . 'pos_update_pkg_' . bin2hex(random_bytes(4)) . '.zip';
    
    if (!function_exists('pos_zip_create_archive')) {
        require_once __DIR__ . '/all-backup-build.php';
    }
    $created = pos_zip_create_archive($tmpZip, $diskEntries, $stringEntries);
    if (!$created['ok']) {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['status' => 'error', 'message' => $created['message'] ?? 'ZIP creation failed'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $filename = 'POS_Update_v' . $version . '_' . date('Ymd_His') . '.zip';
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . filesize($tmpZip));
    header('Pragma: no-cache');
    header('Expires: 0');
    
    while (ob_get_level()) ob_end_clean();
    @readfile($tmpZip);
    @unlink($tmpZip);
    exit();
}
