// returns/screen.js — sales-return helpers, menu, init
window.returnsCart = [];
window.returnsActiveUnit = 'piece';
window.returnsActiveCategory = 'all';
window.returnsManualMode = false;
var _returnsCartRenderTimer = null;
function rt(key, fallback) {
    try {
        if (typeof window.t === 'function') {
            const v = window.t(key);
            if (v && v !== key) return v;
        }
    } catch (e) {}
    return fallback;
}
function getReturnsUnitLabel(prod, unitCode) {
    try {
        if (typeof window.getProductUnitLabel === 'function') {
            return window.getProductUnitLabel(prod || null, unitCode || 'piece');
        }
    } catch (e) {}
    if (typeof window.getDefaultUnitLabel === 'function') {
        return window.getDefaultUnitLabel(unitCode || 'piece');
    }
    if (unitCode === 'carton') return rt('pos_unit_carton', 'کارتۆن');
    if (unitCode === 'pack') return rt('pos_unit_pack', 'پاکێت');
    return rt('pos_unit_piece', 'تاک');
}
/** Return refund price for unit — uses sale line price, then price_pack/price_carton, not piece×mult. */
function getReturnsPriceForUnit(product, unit, sData) {
    unit = unit || 'piece';
    product = product || {};
    if (sData) {
        if (unit === 'pack' && Number(sData.lastPricePack) > 0) return Number(sData.lastPricePack);
        if (unit === 'carton' && Number(sData.lastPriceCarton) > 0) return Number(sData.lastPriceCarton);
        if (unit === 'piece') {
            if (Number(sData.lastPricePiece) > 0) return Number(sData.lastPricePiece);
            if (Number(sData.lastPrice) > 0) return Number(sData.lastPrice);
        }
    }
    if (typeof window.getPriceForUnit === 'function') {
        var catalog = window.getPriceForUnit(product, unit, null);
        if (catalog > 0) return catalog;
    }
    var factors = (typeof getProductUnitFactors === 'function') ? getProductUnitFactors(product) : { piecesPerPack: 1, piecesPerCarton: 1 };
    var base = (sData && Number(sData.lastPrice) > 0) ? Number(sData.lastPrice) : (parseFloat(product.price) || 0);
    var mult = 1;
    if (unit === 'carton') mult = factors.piecesPerCarton || 1;
    else if (unit === 'pack') mult = factors.piecesPerPack || 1;
    return base * mult;
}
function noteReturnsSoldLinePrice(soldEntry, item, mult) {
    if (!soldEntry || !item) return;
    var linePrice = parseFloat(item.price) || 0;
    var unit = item.saleUnit || 'piece';
    if (unit === 'pack') soldEntry.lastPricePack = linePrice;
    else if (unit === 'carton') soldEntry.lastPriceCarton = linePrice;
    else soldEntry.lastPricePiece = linePrice;
    soldEntry.lastPrice = mult > 0 ? (linePrice / mult) : linePrice;
}
function emptyReturnsSoldEntry(item) {
    return { qty: 0, lastPrice: parseFloat(item && item.price) || 0, lastPricePiece: 0, lastPricePack: 0, lastPriceCarton: 0 };
}
function isReturnsWeightProduct(prod) {
    try {
        if (typeof window.isWeightProduct === 'function') return !!window.isWeightProduct(prod);
    } catch (e) {}
    var unitType = String((prod && (prod.unitType || prod.unit_type)) || '').toLowerCase().trim();
    var weightUnit = String((prod && prod.weight_unit) || '').toLowerCase().trim();
    return unitType === 'kilo' || unitType === 'kg' || unitType === 'weight' || weightUnit === 'kg';
}
function normalizeReturnsQty(prod, qtyRaw) {
    var n = Number(qtyRaw);
    if (!isFinite(n) || n <= 0) return 0;
    if (isReturnsWeightProduct(prod)) return Math.round(n * 1000) / 1000;
    return Math.max(0, Math.floor(n));
}
function formatReturnsQtyInput(qty, prod) {
    if (typeof window.formatQtyForInput === 'function') return window.formatQtyForInput(qty, prod);
    var n = Number(qty);
    if (!isFinite(n) || n < 0) n = 0;
    if (n % 1 !== 0) return parseFloat(n.toFixed(3)).toString();
    return String(Math.round(n));
}

function roundReturnsMoney(value) {
    var n = Number(value);
    if (!isFinite(n)) return 0;
    return Math.max(0, Math.round(n));
}

function getReturnsLockedSale() {
    if (window.returnsManualMode) return null;
    if (window._returnsLoadedSale && window._returnsLoadedSale.id != null) return window._returnsLoadedSale;
    if (window.pendingReturnFromSale && window.pendingReturnFromSale.id != null) return window.pendingReturnFromSale;
    var inv = document.getElementById('returns-new-invoice-ref');
    if (inv && inv.value && typeof getRememberedReturnsSale === 'function') {
        return getRememberedReturnsSale(inv.value);
    }
    return null;
}

function isReturnsUsdMode() {
    var sale = getReturnsLockedSale();
    if (sale) {
        var m = String(sale.fx_currency_mode || sale.sale_currency || '').toUpperCase();
        if (m === 'USD') return true;
        if (m === 'IQD') return false;
    }
    try {
        if (typeof window.getActiveCurrency === 'function') return window.getActiveCurrency() === 'USD';
    } catch (e) {}
    return !!(window.db && window.db.settings && window.db.settings.currencyMode === 'USD');
}

function getReturnsUsdRatePerOne() {
    var sale = getReturnsLockedSale();
    if (sale && typeof window.getPosFrozenFxRatePerOne === 'function') {
        var locked = Number(window.getPosFrozenFxRatePerOne(sale));
        if (isFinite(locked) && locked > 0) return locked;
    }
    try {
        if (typeof window.getUsdRatePerOne === 'function') return Number(window.getUsdRatePerOne()) || 0;
    } catch (e) {}
    var raw = (window.db && window.db.settings && window.db.settings.usdRate) ? Number(window.db.settings.usdRate) : 0;
    return raw > 0 ? (raw / 100) : 0;
}

function returnsIqdToDisplay(iqdVal) {
    var v = Number(iqdVal) || 0;
    if (isReturnsUsdMode()) {
        var r = getReturnsUsdRatePerOne();
        return r > 0 ? (v / r) : 0;
    }
    return v;
}

function returnsDisplayToIqd(displayVal) {
    var v = Number(displayVal) || 0;
    if (isReturnsUsdMode()) {
        var r = getReturnsUsdRatePerOne();
        return r > 0 ? (v * r) : 0;
    }
    return v;
}

function returnsFormatMoney(iqdVal) {
    var sale = getReturnsLockedSale();
    var opts = (typeof window.fxUsdRateFormatOpts === 'function') ? window.fxUsdRateFormatOpts(sale) : undefined;
    if (!opts) {
        var r = getReturnsUsdRatePerOne();
        if (r > 0) opts = { fxUsdRate: Math.round(r * 100) };
    }
    if (typeof window.formatCurrency === 'function') return window.formatCurrency(iqdVal || 0, opts);
    return String(iqdVal || 0);
}

function getParsedItems(obj) {
    if (!obj || !obj.items) return [];
    let items = obj.items;
    if (typeof items === 'string') {
        try { items = JSON.parse(items); } catch(e) { items = []; }
    }
    return (Array.isArray(items)) ? items : [];
}

// Sold quantity from sale invoice row must come from sale count, not current product stock qty.
function getSaleLineProductId(item) {
    if (!item || typeof item !== 'object') return '';
    var pid = item.id != null ? item.id : (item.product_id != null ? item.product_id : item.productId);
    return pid != null && pid !== '' ? String(pid) : '';
}
function getSaleRowSoldQty(item) {
    if (!item || typeof item !== 'object') return 1;
    const candidates = [item.count, item.sold_qty, item.qty_sold, item.quantity];
    for (let i = 0; i < candidates.length; i++) {
        const n = parseFloat(candidates[i]);
        if (!isNaN(n) && n > 0) return n;
    }
    // Legacy fallback for old records where qty represented sold row quantity.
    const legacyQty = parseFloat(item.qty);
    if (!isNaN(legacyQty) && legacyQty > 0 && legacyQty <= 1000) return legacyQty;
    return 1;
}

function rememberReturnsSale(sale) {
    if (!sale || sale.id == null) return;
    window._returnsSaleById = window._returnsSaleById || {};
    window._returnsSaleById[String(sale.id)] = sale;
    window._returnsLoadedSale = sale;
}

function getRememberedReturnsSale(id) {
    if (id == null || id === '') return null;
    var map = window._returnsSaleById;
    if (map && map[String(id)]) return map[String(id)];
    if (window._returnsLoadedSale && String(window._returnsLoadedSale.id) === String(id)) return window._returnsLoadedSale;
    if (window.pendingReturnFromSale && String(window.pendingReturnFromSale.id) === String(id)) return window.pendingReturnFromSale;
    return null;
}

/** مبيعات + أرشيف (نفس منطق getAllSales) لبحث وصل الإرجاع */
function getSalesListForReturns() {
    var list;
    if (typeof window.getAllSales === 'function') {
        list = window.getAllSales(true).slice();
    } else {
        list = (window.db && window.db.sales) ? window.db.sales.slice() : [];
        if (window.db && window.db.archive && window.db.archive.length) {
            list = list.concat(window.db.archive);
        }
    }
    var map = window._returnsSaleById;
    if (map) {
        Object.keys(map).forEach(function (id) {
            var sale = map[id];
            if (!sale) return;
            var exists = list.some(function (s) { return s && String(s.id) === String(id); });
            if (!exists) list.push(sale);
        });
    }
    return list;
}

/**
 * يحوّل ما يُكتب في حقل «رقم الوصل» إلى id البيع الفعلي.
 * الوصل الحراري يعرض آخر 4 أرقام فقط (app.js: sale.id.toString().slice(-4))،
 * لذلك يجب قبول اللاحقة وليس المطابقة الصارمة فقط.
 * يدعم أيضاً transaction_id (مثل TX...) إن وُجد.
 */
function resolveReturnsInvoiceToSaleId(raw) {
    var trimmed = String(raw || '').trim();
    // Normalize common invoice input formats: "#61", "INV#61", "Invoice 61"
    // Keep transaction_id values (e.g. TX...) untouched for direct matching.
    var normalized = trimmed;
    if (!/^TX/i.test(normalized)) {
        normalized = normalized.replace(/^[^0-9]+/, '');
        normalized = normalized.replace(/[^0-9]+$/, '');
    }
    if (/^[0-9]+$/.test(normalized)) trimmed = normalized;
    if (!trimmed) return null;
    var remembered = getRememberedReturnsSale(trimmed);
    if (remembered && remembered.id != null) return parseInt(remembered.id, 10);
    if (/^[0-9]+$/.test(trimmed)) {
        remembered = getRememberedReturnsSale(parseInt(trimmed, 10));
        if (remembered && remembered.id != null) return parseInt(remembered.id, 10);
    }
    var sales = getSalesListForReturns();
    var i, s;
    for (i = 0; i < sales.length; i++) {
        s = sales[i];
        if (!s) continue;
        if (String(s.transaction_id || '') === trimmed) {
            return parseInt(s.id, 10);
        }
    }
    if (/^[0-9]+$/.test(trimmed)) {
        var n = parseInt(trimmed, 10);
        for (i = 0; i < sales.length; i++) {
            s = sales[i];
            if (!s) continue;
            if (Number(s.id) === n) return n;
        }
        var matches = [];
        for (i = 0; i < sales.length; i++) {
            s = sales[i];
            if (!s) continue;
            if (String(s.id).endsWith(trimmed)) matches.push(s);
        }
        if (matches.length === 1) return parseInt(matches[0].id, 10);
        if (matches.length > 1) {
            matches.sort(function (a, b) {
                return new Date(b.date || b.created_at || 0) - new Date(a.date || a.created_at || 0);
            });
            return parseInt(matches[0].id, 10);
        }
    }
    return null;
}

window._returnsRealtimeState = window._returnsRealtimeState || {
    timer: null,
    inFlight: false,
    queued: false,
    token: 0
};
window._returnsSessionAvailability = window._returnsSessionAvailability || { sale_id: 0, byProduct: {} };

function getCurrentReturnsSaleId() {
    const invInput = document.getElementById('returns-new-invoice-ref') || document.getElementById('sales-return-invoice-ref');
    const invRaw = invInput && invInput.value ? String(invInput.value).trim() : '';
    if (!invRaw) return null;
    return resolveReturnsInvoiceToSaleId(invRaw);
}

function buildReturnsRealtimeItemsPayload() {
    return (window.returnsCart || []).map(item => {
        const p = (window.db && window.db.products) ? window.db.products.find(x => String(x.id) === String(item.productId)) : null;
        return {
            id: item.productId,
            qty: item.qty,
            saleUnit: item.unit || 'piece',
            trackStock: p ? p.trackStock : true,
            pieces_per_pack: p ? (p.piecesPerPack || p.pieces_per_pack || 1) : 1,
            packs_per_carton: p ? (p.packsPerCarton || p.packs_per_carton || 1) : 1,
            itemsPerCarton: p ? (p.itemsPerCarton || p.piecesPerCarton || 1) : 1
        };
    });
}

function applyRealtimeReturnResponse(res) {
    if (!res) return;
    window._returnsSessionAvailability = {
        sale_id: Number(res.sale_id || 0),
        byProduct: (res.available_by_product && typeof res.available_by_product === 'object') ? res.available_by_product : {}
    };
    const viewReturns = document.getElementById('view-returns-new');
    if (viewReturns && viewReturns.classList.contains('active') && typeof renderReturnsMenu === 'function') {
        renderReturnsMenu();
    }
}

window.syncReturnsRealtimeStock = function(forceNow) {
    const st = window._returnsRealtimeState;
    if (!forceNow && st.timer) clearTimeout(st.timer);
    if (!forceNow) {
        st.timer = setTimeout(() => window.syncReturnsRealtimeStock(true), 160);
        return Promise.resolve({ status: 'queued' });
    }
    const saleId = getCurrentReturnsSaleId();
    if (!saleId) {
        window._returnsSessionAvailability = { sale_id: 0, byProduct: {} };
        return Promise.resolve({ status: 'skip' });
    }
    if (st.inFlight) {
        st.queued = true;
        return Promise.resolve({ status: 'busy' });
    }
    st.inFlight = true;
    st.queued = false;
    const token = ++st.token;
    const payloadItems = buildReturnsRealtimeItemsPayload();
    const fd = new FormData();
    fd.append('action', 'adjust_return_cart_realtime');
    fd.append('sale_id', String(saleId));
    fd.append('items', JSON.stringify(payloadItems));
    fd.append('cart_hash', JSON.stringify(payloadItems.map(i => [i.id, i.qty, i.saleUnit])));

    return fetch('?action=adjust_return_cart_realtime', { method: 'POST', body: fd })
        .then(r => r.json())
        .then(res => {
            if (token !== st.token) return res;
            if (res && res.status === 'success') {
                applyRealtimeReturnResponse(res);
            } else if (res && res.status === 'error' && res.message && window.showToast) {
                window.showToast(res.message, 'error');
            }
            return res;
        })
        .catch(err => {
            console.error('Realtime return stock sync failed:', err);
            return { status: 'error', message: err && err.message ? err.message : 'network' };
        })
        .finally(() => {
            st.inFlight = false;
            if (st.queued) window.syncReturnsRealtimeStock(true);
        });
};

function scheduleReturnsRealtimeSync() {
    if (typeof window.syncReturnsRealtimeStock === 'function') {
        window.syncReturnsRealtimeStock(false);
    }
}

function selectReturnsCustomerFromSale(sale) {
    if (!sale) return;
    var idStr = sale.customer_id ? String(sale.customer_id) : '';
    var typed = (sale.customer_type && sale.customer_id) ? (sale.customer_type + '_' + sale.customer_id) : '';
    ['returns-debt-select', 'returns-debt-customer'].forEach(function (sid) {
        var sel = document.getElementById(sid);
        if (!sel) return;
        var found = false;
        for (var i = 0; i < sel.options.length; i++) {
            var ov = sel.options[i].value;
            if ((typed && ov === typed) || (idStr && ov === idStr) || (sale.customer && sel.options[i].text.indexOf(sale.customer) === 0)) {
                sel.selectedIndex = i;
                found = true;
                break;
            }
        }
        if (!found && sale.customer && String(sale.customer).toLowerCase() !== 'general') {
            var opt = document.createElement('option');
            opt.value = typed || idStr || sale.customer;
            opt.textContent = String(sale.customer);
            sel.appendChild(opt);
            sel.selectedIndex = sel.options.length - 1;
        }
    });
}

function updateReturnsInvoiceBanner(sale) {
    var panel = document.getElementById('returns-bill-panel');
    var titleEl = document.querySelector('#view-returns-new .txn-screen-head-title');
    var existing = document.getElementById('return-invoice-mode-indicator');
    if (!sale) {
        if (existing) existing.remove();
        if (titleEl) titleEl.textContent = rt('returns_screen_title', 'زڤڕاندن');
        return;
    }
    if (titleEl) titleEl.textContent = rt('returns_screen_title', 'زڤڕاندن') + ' #' + sale.id;
    if (!panel) return;
    if (!existing) {
        existing = document.createElement('div');
        existing.id = 'return-invoice-mode-indicator';
        existing.style.cssText = 'background:#ef4444; color:white; text-align:center; padding:6px 8px; font-weight:bold; font-size:0.9rem;';
        panel.insertBefore(existing, panel.firstChild);
    }
    var esc = (typeof escapeHtml === 'function') ? escapeHtml : function (s) { return String(s == null ? '' : s); };
    existing.innerHTML = '↩️ ' + esc(rt('returns_invoice_banner', 'وەسڵ هاتە بارکرن — ژمارە کەم بکە یان ئایتم ژێبە، پاشان پەسەندکرن')) +
        ' <span style="opacity:.9">#' + esc(String(sale.id)) + '</span>' +
        ' <button type="button" class="btn btn-sm" style="margin-right:8px;background:rgba(255,255,255,0.2);color:#fff;border:1px solid rgba(255,255,255,0.4);padding:2px 8px;" onclick="typeof clearReturnsInvoiceLoad===\'function\'&&clearReturnsInvoiceLoad(true)">' +
        esc(rt('returns_invoice_cancel', 'هەلوەشاندن')) + '</button>';
}

window.clearReturnsInvoiceLoad = function (clearCart) {
    window.pendingReturnFromSale = null;
    window._returnsLoadedSale = null;
    var invEl = document.getElementById('returns-new-invoice-ref');
    if (invEl) invEl.value = '';
    var debtTop = document.getElementById('returns-debt-select');
    var debtFoot = document.getElementById('returns-debt-customer');
    if (debtTop) debtTop.value = '';
    if (debtFoot) debtFoot.value = '';
    if (clearCart) {
        window.returnsCart = [];
        if (typeof renderReturnsCart === 'function') renderReturnsCart();
    }
    updateReturnsInvoiceBanner(null);
    if (typeof renderReturnsMenu === 'function') renderReturnsMenu();
};

window.rememberReturnsSale = rememberReturnsSale;
window.getRememberedReturnsSale = getRememberedReturnsSale;

function applyPendingReturnFromSale() {
    var s = window.pendingReturnFromSale;
    if (!s) return false;
    rememberReturnsSale(s);
    var items = getParsedItems(s);
    var invEl = document.getElementById('returns-new-invoice-ref');
    if (invEl && s.id != null) invEl.value = String(s.id);
    selectReturnsCustomerFromSale(s);
    if (items.length && typeof loadReturnsCartFromSale === 'function') {
        loadReturnsCartFromSale(s);
    } else {
        updateReturnsInvoiceBanner(s);
        if (typeof renderReturnsMenu === 'function') renderReturnsMenu();
    }
    window.pendingReturnFromSale = null;
    return true;
}
window.applyPendingReturnFromSale = applyPendingReturnFromSale;

function initReturnsScreen() {
    window._returnsSessionAvailability = { sale_id: 0, byProduct: {} };
    if (!window.returnsCart) window.returnsCart = [];
    populateReturnsCustomers();
    if (typeof updateReturnsManualUi === 'function') updateReturnsManualUi();
    if (!applyPendingReturnFromSale()) {
        if (window._returnsLoadedSale && (!window.returnsCart || !window.returnsCart.length)) {
            loadReturnsCartFromSale(window._returnsLoadedSale);
        } else if (window._returnsLoadedSale) {
            updateReturnsInvoiceBanner(window._returnsLoadedSale);
        }
    }
    renderReturnsMenu();
    renderReturnsCart();

    // ژێبرنا دوگمەیا بەرێ یا مێژوویێ ژ شاشا زڤڕاندنێ (چونکە نوکە د مینیویێ دایە)
    var oldBtn1 = document.getElementById('btn-returns-sales-history-refresh');
    if (oldBtn1) oldBtn1.remove();
    var oldBtn2 = document.getElementById('btn-returns-sales-history-search');
    if (oldBtn2) oldBtn2.remove();
}

window.updateReturnsManualUi = function() {
    const btn = document.getElementById('returns-manual-toggle-btn');
    const warn = document.getElementById('returns-manual-warning');
    const inv = document.getElementById('returns-new-invoice-ref');
    if (btn) {
        btn.classList.toggle('btn-danger', !!window.returnsManualMode);
        btn.classList.toggle('btn-dark', !window.returnsManualMode);
        btn.innerHTML = window.returnsManualMode ? '<i class="fas fa-box-open"></i>' : '<i class="fas fa-plus-square"></i>';
        btn.title = window.returnsManualMode ? 'Manual Return ON' : 'زڤراندنا بێ وەسڵ';
    }
    if (warn) warn.style.display = window.returnsManualMode ? 'block' : 'none';
    if (inv) {
        inv.required = !window.returnsManualMode;
        if (window.returnsManualMode) inv.placeholder = 'Manual Return: وەسڵ نە پێدڤیە';
        else inv.placeholder = 'ژمارا وەسڵی بنڤیسە (پێدڤیە)...';
    }
    if (window.returnsManualMode && typeof window.expandTxnMetaForView === 'function') {
        window.expandTxnMetaForView('returns-new');
    }
};

window.toggleManualReturnMode = function() {
    window.returnsManualMode = !window.returnsManualMode;
    if (window.returnsManualMode) {
        const inv = document.getElementById('returns-new-invoice-ref');
        if (inv) inv.value = '';
    }
    if (typeof updateReturnsManualUi === 'function') updateReturnsManualUi();
    if (typeof renderReturnsMenu === 'function') {
        renderReturnsMenu(document.getElementById('returns-barcode-input') ? document.getElementById('returns-barcode-input').value : '');
    }
};

window.loadReturnsCartFromSale = function(sale) {
    const items = getParsedItems(sale);
    if (!items.length) return;
    rememberReturnsSale(sale);
    window.returnsCart = [];
    var grouped = {};

    items.forEach(function(i) {
        var pid = getSaleLineProductId(i);
        var unit = i.saleUnit || i.sale_unit || 'piece';
        var price = parseFloat(i.price) || 0;
        var key = pid + '_' + price + '_' + unit;
        if (!grouped[key]) grouped[key] = { id: pid || i.id, name: i.name, price: price, saleUnit: unit, count: 0 };
        var lineQty = getSaleRowSoldQty(i);
        if (typeof getSaleLineQty === 'function') {
            var gq = getSaleLineQty(i);
            if (gq > 0) lineQty = gq;
        }
        var prod = (window.db && window.db.products) ? window.db.products.find(function(x){ return String(x.id) === String(pid || i.id); }) : null;
        grouped[key].count += normalizeReturnsQty(prod, lineQty) || lineQty || 1;
    });

    var factorsFn = typeof getProductUnitFactors === 'function' ? getProductUnitFactors : function(){return {piecesPerPack:1,piecesPerCarton:1};};
    Object.values(grouped).forEach(function(g) {
        var p = (window.db && window.db.products) ? window.db.products.find(function(x) { return String(x.id) === String(g.id); }) : null;
        var factors = p ? factorsFn(p) : { piecesPerPack: 1, piecesPerCarton: 1 };
        var cost = 0;
        if (p) {
            var pc = parseFloat(p.cost) || 0;
            if (g.saleUnit === 'carton') {
                cost = (p.cost_carton != null && parseFloat(p.cost_carton) > 0) ? parseFloat(p.cost_carton) : (pc * (factors.piecesPerCarton || 1));
            } else if (g.saleUnit === 'pack') {
                cost = (p.cost_pack != null && parseFloat(p.cost_pack) > 0) ? parseFloat(p.cost_pack) : (pc * (factors.piecesPerPack || 1));
            } else {
                cost = pc;
            }
            if (typeof roundMoney === 'function') cost = roundMoney(cost);
            else cost = Math.round(cost);
        }
        var totalPieces = g.count;
        if (g.saleUnit === 'carton') totalPieces = g.count * (factors.piecesPerCarton || 1);
        else if (g.saleUnit === 'pack') totalPieces = g.count * (factors.piecesPerPack || 1);

        window.returnsCart.push({
            id: 'RET-' + Date.now() + Math.floor(Math.random()*1000),
            productId: g.id,
            name: g.name,
            unit: g.saleUnit,
            saleUnit: g.saleUnit,
            qty: g.count,
            price: g.price,
            cost: cost,
            discountPercent: 0,
            total: Math.max(0, g.count * g.price),
            totalCost: g.count * cost,
            totalPieces: totalPieces
        });
    });

    var invEl = document.getElementById('returns-new-invoice-ref');
    if (invEl && sale.id != null) invEl.value = String(sale.id);
    selectReturnsCustomerFromSale(sale);
    updateReturnsInvoiceBanner(sale);
    renderReturnsCart();
    if (typeof renderReturnsMenu === 'function') renderReturnsMenu();
    if (typeof window.updateReturnsDebtSummary === 'function') window.updateReturnsDebtSummary();
    if (typeof window.maybeCollapseTxnMetaAfterValid === 'function') {
        window.maybeCollapseTxnMetaAfterValid('returns-new', ['returns-new-invoice-ref']);
    }
    if (typeof window.showToast === 'function') {
        window.showToast(rt('returns_invoice_loaded', 'وەسڵ هاتە بارکرن بۆ زڤڕاندن') + ' #' + sale.id, 'success');
    }
};

function setReturnsUnit(unit) {
    window.returnsActiveUnit = unit;
    document.getElementById('btn-returns-unit-carton').classList.remove('active');
    document.getElementById('btn-returns-unit-pack').classList.remove('active');
    document.getElementById('btn-returns-unit-piece').classList.remove('active');
    document.getElementById('btn-returns-unit-' + unit).classList.add('active');
    renderReturnsMenu();
}
window.setReturnsUnit = setReturnsUnit;

function returnsProductCat(p) {
    return String((p && (p.cat || p.category)) || '').trim();
}

function renderReturnsCategories() {
    var container = document.getElementById('returns-category-tabs');
    if (!container || !window.db) return;
    var used = {};
    (window.db.products || []).forEach(function(p) {
        var c = returnsProductCat(p);
        if (c) used[c] = true;
    });
    var sourceCats = (window.db.categories && window.db.categories.length)
        ? window.db.categories.slice()
        : Object.keys(used);
    var cats = sourceCats.filter(function(c) { return !!used[c]; }).sort();
    var allLbl = rt('pos_category_all', 'هەمی');
    var html = '<button type="button" class="cat-btn ' + (window.returnsActiveCategory === 'all' ? 'active' : '') + '" onclick="setReturnsCategory(\'all\')"><i class="fas fa-border-all" aria-hidden="true"></i> ' + escapeHtml(allLbl) + '</button>';
    cats.forEach(function(c) {
        var safe = String(c).replace(/\\/g, '\\\\').replace(/'/g, "\\'");
        html += '<button type="button" class="cat-btn ' + (window.returnsActiveCategory === c ? 'active' : '') + '" onclick="setReturnsCategory(\'' + safe + '\')"><i class="fas fa-folder-open" aria-hidden="true"></i> ' + escapeHtml(c) + '</button>';
    });
    container.innerHTML = html;
    if (typeof window.refreshTxnCategoryTabsScrollUi === 'function') {
        requestAnimationFrame(function() { window.refreshTxnCategoryTabsScrollUi('returns-category-tabs'); });
    }
}
window.renderReturnsCategories = renderReturnsCategories;

function setReturnsCategory(cat) {
    window.returnsActiveCategory = cat || 'all';
    renderReturnsCategories();
    var q = (document.getElementById('returns-barcode-input') && document.getElementById('returns-barcode-input').value) || '';
    renderReturnsMenu(q);
}
window.setReturnsCategory = setReturnsCategory;

function stampReturnsTxnMobileCartLabels(root) {
    if (typeof window.isTxnMobileViewport !== 'function' || !window.isTxnMobileViewport() || !root) return;
    root.querySelectorAll('.returns-row-disc').forEach(function (el) {
        el.setAttribute('data-txn-label', 'داشکاندن');
    });
    root.querySelectorAll('.returns-row-price').forEach(function (el) {
        el.setAttribute('data-txn-label', 'نرخ');
    });
    root.querySelectorAll('.returns-row-qty-wrap input[type="number"]').forEach(function (el) {
        el.setAttribute('data-txn-label', 'ژمارە');
    });
}

function renderReturnsMenu(searchQ = '') {
    const grid = document.getElementById('returns-products');
    if (!grid) return;

    const catTabs = document.getElementById('returns-category-tabs');
    if (catTabs && typeof window.isTxnMobileViewport === 'function' && window.isTxnMobileViewport()) {
        catTabs.classList.add('txn-cats-sticky');
    }
    if (typeof renderReturnsCategories === 'function') renderReturnsCategories();
    
    if (!window.db || !window.db.products) return;
    
    const customerSelTop = document.getElementById('returns-debt-select');
    const customerSelBottom = document.getElementById('returns-debt-customer');
    // Prefer top panel selector if it has a value set
    const customerSel = (customerSelTop && customerSelTop.value) ? customerSelTop : customerSelBottom;
    const customerVal = customerSel ? customerSel.value : '';
    let customerName = null;
    let customerId = null;
    let isSpecificCustomer = false;
    
    if (customerVal && customerVal.startsWith('customer_')) {
        customerId = parseInt(customerVal.split('_')[1], 10);
        let cust = (window.db.customers || []).find(c => c.id === customerId);
        if (cust) customerName = cust.name;
        isSpecificCustomer = true;
    } else if (customerVal && customerVal.startsWith('user_')) {
        customerId = parseInt(customerVal.split('_')[1], 10);
        let usr = (window.db.users || []).find(u => u.id === customerId);
        if (usr) customerName = usr.name;
        isSpecificCustomer = true;
    } else if (customerVal && customerVal !== '' && !isNaN(parseInt(customerVal, 10))) {
        // Plain numeric ID from the top panel selector
        customerId = parseInt(customerVal, 10);
        let cust = (window.db.customers || []).find(c => c.id === customerId);
        if (cust) customerName = cust.name;
        isSpecificCustomer = true;
        // Sync bottom selector too
        if (customerSelBottom && customerSelBottom.value !== customerVal) customerSelBottom.value = customerVal;
    } else if (customerVal && customerVal !== '') {
        isSpecificCustomer = true;
        if (customerSel.options && customerSel.options[customerSel.selectedIndex]) {
            customerName = customerSel.options[customerSel.selectedIndex].text.replace(' (Customer)', '').replace(' (Staff)', '').split(' - ')[0].trim();
        }
    }

    const invInput = document.getElementById('returns-new-invoice-ref') || document.getElementById('sales-return-invoice-ref');
    const invRaw = invInput && invInput.value ? String(invInput.value).trim() : '';
    const invId = invRaw ? resolveReturnsInvoiceToSaleId(invRaw) : null;

    if (invRaw && invId == null) {
        grid.innerHTML = '<div style="grid-column:1/-1; text-align:center; padding:30px; color:var(--danger); font-size:1.05rem;"><i class="fas fa-search" style="font-size:2.5rem; margin-bottom:12px; opacity:0.6; display:block;"></i>' + rt('returns_invoice_not_found', 'لم يُعثر على وصل بهذا الرقم. جرّب الرقم الكامل أو آخر 4 أرقام كما على الطباعة.') + '</div>';
        return;
    }

    let soldItems = {};
    let invoiceSoldItems = {};
    let hasFilters = isSpecificCustomer || (invId != null);

    if (hasFilters) {
        const salesList = getSalesListForReturns();
        salesList.forEach(sale => {
            let match = false;
            if (invId != null && Number(sale.id) === invId) match = true;
            else if (invId == null && isSpecificCustomer) {
                if (sale.customer_id == customerId) match = true;
                else if (sale.customer === customerName) match = true;
            }

            let items = sale.items;
            if (typeof items === 'string') {
                try { items = JSON.parse(items); } catch(e) { items = []; }
            }
            if (match && items && Array.isArray(items)) {
                items.forEach(item => {
                    const pid = getSaleLineProductId(item);
                    if (!pid) return;
                    if (!soldItems[pid]) {
                        soldItems[pid] = emptyReturnsSoldEntry(item);
                    }
                    if (!invoiceSoldItems[pid]) {
                        invoiceSoldItems[pid] = { qty: 0 };
                    }
                    let mult = 1;
                    let factors = (typeof getProductUnitFactors === 'function') ? getProductUnitFactors(item) : { piecesPerPack: 1, piecesPerCarton: 1 };
                    if (item.saleUnit === 'carton') mult = factors.piecesPerCarton || 1;
                    else if (item.saleUnit === 'pack') mult = factors.piecesPerPack || 1;

                    const lineQty = Math.max(1, getSaleRowSoldQty(item));
                    soldItems[pid].qty += (mult * lineQty);
                    invoiceSoldItems[pid].qty += (mult * lineQty);
                    noteReturnsSoldLinePrice(soldItems[pid], item, mult);
                });
            }
        });

        if (window.db.returns) {
            window.db.returns.forEach(ret => {
                let match = false;
                if (invId != null && Number(ret.sale_id) === invId) match = true;
                else if (invId == null && isSpecificCustomer) {
                    if (ret.target_id == customerId) match = true;
                }

                let retItems = getParsedItems(ret);
                if (match && retItems.length) {
                    retItems.forEach(item => {
                        const pid = getSaleLineProductId(item);
                        if (!pid) return;
                        if (soldItems[pid]) {
                            let mult = 1;
                            let factors = (typeof getProductUnitFactors === 'function') ? getProductUnitFactors(item) : { piecesPerPack: 1, piecesPerCarton: 1 };
                            if (item.saleUnit === 'carton') mult = factors.piecesPerCarton || 1;
                            else if (item.saleUnit === 'pack') mult = factors.piecesPerPack || 1;

                            const returnedLineQty = Math.max(1, parseFloat(item.qty) || 1);
                            soldItems[pid].qty -= (mult * returnedLineQty);
                        }
                    });
                }
            });
        }
    }

    if (window.returnsManualMode) {
        hasFilters = true;
        soldItems = {};
        (window.db.products || []).forEach(function(p) {
            if (p && p.forSale !== false) {
                soldItems[String(p.id)] = { qty: Number.MAX_SAFE_INTEGER, lastPrice: parseFloat(p.price) || 0, lastPricePiece: parseFloat(p.price) || 0, lastPricePack: 0, lastPriceCarton: 0 };
            }
        });
    }

    if (!window.returnsManualMode && !invRaw) {
        grid.innerHTML = '<div class="txn-grid-empty-state"><i class="fas fa-file-invoice"></i><span>ژمارا پسوولا فرۆتنێ بنووسە یان کریار هەڵبژێرە.</span></div>';
        return;
    }

    if (!hasFilters) {
        grid.innerHTML = '<div class="txn-grid-empty-state"><i class="fas fa-user"></i><span>' + escapeHtml(rt('returns_empty_prompt', 'هیڤیە کریارەکێ یان ژمارا وەسڵێ هەڵبژێرە بۆ دیتنا کەرەستەیان.')) + '</span></div>';
        return;
    }

    let prods = window.db.products.filter(p => p.forSale !== false);

    if (!window.returnsManualMode) {
        prods = prods.filter(p => soldItems[String(p.id)] && soldItems[String(p.id)].qty > 0);
    }
    
    // Filter by unit
    const unit = window.returnsActiveUnit || 'piece';
    if (typeof window.productMatchesUnitFilter === 'function') {
        prods = prods.filter(p => window.productMatchesUnitFilter(p, unit, false));
    }
    if (window.returnsActiveCategory && window.returnsActiveCategory !== 'all') {
        prods = prods.filter(function(p) { return returnsProductCat(p) === window.returnsActiveCategory; });
    }
    
    var _retMax = (typeof window.posTxnGridProductLimit === 'function') ? window.posTxnGridProductLimit(searchQ) : 55;
    if (searchQ) {
        var qRaw = String(searchQ).trim();
        prods = prods.filter(function(p) {
            return typeof window.productMatchesBarcodeOrNameSearch === 'function'
                ? window.productMatchesBarcodeOrNameSearch(p, qRaw)
                : ((p.name && p.name.toLowerCase().indexOf(qRaw.toLowerCase()) >= 0) ||
                   (p.barcode && p.barcode.toLowerCase().indexOf(qRaw.toLowerCase()) >= 0));
        });
    }
    if (prods.length > _retMax) prods = prods.slice(0, _retMax);
    
    var countEl = document.getElementById('returns-products-count');
    if (countEl) countEl.textContent = String(prods.length);

    if (prods.length === 0) {
        grid.innerHTML = '<div class="txn-grid-empty-state pos-empty-products"><i class="fas fa-search"></i><span>' + escapeHtml(rt('returns_empty_no_items', 'چ ئایتم نین بۆ ڤی کریاری/وەسڵێ.')) + '</span></div>';
        return;
    }

    let html = '';
    var cardIconRet = (window.returnsActiveUnit === 'carton') ? 'fa-box' : ((window.returnsActiveUnit === 'pack') ? 'fa-boxes' : 'fa-cube');
    prods.forEach(p => {
        let factors = (typeof getProductUnitFactors === 'function') ? getProductUnitFactors(p) : { piecesPerPack: 1, piecesPerCarton: 1 };
        let sData = soldItems[String(p.id)];
        const unit = window.returnsActiveUnit || 'piece';
        let unitLabel = getReturnsUnitLabel(p, unit);
        let activePrice = getReturnsPriceForUnit(p, unit, sData);
        // Pick barcode to show based on active unit, or default to piece
        let barcodeDisplay = p.barcode;
        if (window.returnsActiveUnit === 'carton') barcodeDisplay = p.barcode_carton || p.barcode;
        else if (window.returnsActiveUnit === 'pack') barcodeDisplay = p.barcode_pack || p.barcode;

        const priceLine = unitLabel + ': ' + (activePrice > 0 ? window.formatCurrency(activePrice) : '-');
        const availablePieces = window.getReturnsAvailablePieces(p.id);
        var mult = 1;
        if (unit === 'carton') mult = factors.piecesPerCarton || 1;
        else if (unit === 'pack') mult = factors.piecesPerPack || 1;
        const availableInUnit = Math.max(0, availablePieces / mult).toFixed(2).replace(/\.00$/, '');
        const availLine = window.returnsManualMode
            ? (rt('returns_current_price_label', '') + ' <b>' + (activePrice > 0 ? window.formatCurrency(activePrice) : '-') + '</b>')
            : (rt('returns_remain_for_return', '') + ' <b>' + availableInUnit + '</b> ' + unitLabel);

        html += `
            <div class="unified-product-card txn-product-card txn-product-card--sales-return return-prod-card" style="height:auto; min-height:180px; cursor:pointer;" role="button" tabindex="0" data-product-id="${p.id}" data-sale-unit="${String(window.returnsActiveUnit || 'piece').replace(/"/g, '')}" data-sale-price="${activePrice}" onclick="if(typeof handleReturnsProductCardClick==='function'){handleReturnsProductCardClick(this);} event.stopPropagation();">
                <div class="unified-card-header">
                    <div class="unified-card-icon"><i class="fas ${cardIconRet}"></i></div>
                    <div class="unified-card-barcode">${escapeHtml(barcodeDisplay || '---')}</div>
                </div>
                <div class="unified-card-name">${escapeHtml(p.name || 'ئایتم')}</div>
                <div class="unified-card-price">${priceLine}</div>
                <div class="txn-card-meta">${availLine}</div>
                <div class="unified-card-cta"><i class="fas fa-undo-alt"></i> ${escapeHtml(rt('unified_card_cta_return', 'کلیک بکە بۆ زڤڕاندن'))}</div>
            </div>
        `;
    });
    grid.innerHTML = html;
}
