<?php
/**
 * Human-facing application release (shown in UI, print footers via JS, page titles).
 * Bump this when shipping a new customer-facing version.
 */
    if (!defined('POS_APP_VERSION')) {
        define('POS_APP_VERSION', '3.16.23');
    }
    if (!defined('POS_APP_RELEASE_LABEL')) {
        define('POS_APP_RELEASE_LABEL', 'Laptop Duhok POS v3.16.23 - Boot Protection & Power Recovery');
    }
/** Subtle receipt watermark — shop-facing prints (not «developed by»). */
if (!defined('POS_RECEIPT_BRAND_NAME')) {
    define('POS_RECEIPT_BRAND_NAME', 'Laptop Duhok POS');
}
if (!defined('POS_RECEIPT_BRAND_PHONE')) {
    define('POS_RECEIPT_BRAND_PHONE', '07507367680');
}
require_once __DIR__ . '/premium_pricing.php';
/** Bundled default brand logo (offline-first; no external CDN). */
if (!defined('POS_DEFAULT_LOGO_PATH')) {
    define('POS_DEFAULT_LOGO_PATH', 'public/assets/brand/laptop-duhok-logo.png');
}
/** Default shop/store logo for invoices & home when no custom logo is uploaded. */
if (!defined('POS_DEFAULT_SHOP_LOGO_PATH')) {
    define('POS_DEFAULT_SHOP_LOGO_PATH', 'public/assets/brand/laptop-duhok-logo.png');
}
/** Terminal sub-laptop security slot — admin ledger price (USD); customer UI shows security slots, not price. */
if (!defined('POS_TERMINAL_SLOT_PRICE_USD')) {
    define('POS_TERMINAL_SLOT_PRICE_USD', 99);
}
