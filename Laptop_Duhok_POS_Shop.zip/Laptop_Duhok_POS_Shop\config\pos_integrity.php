<?php
/**
 * POS file integrity watchdog — boot + event-driven verification (not per-second polling).
 */

function pos_integrity_config_dir(): string {
    return dirname(__DIR__) . '/config';
}

function pos_integrity_manifest_path(): string {
    return pos_integrity_config_dir() . '/.pos_integrity_manifest';
}

function pos_integrity_protected_relative_paths(): array {
    return [
        'supabase_license.php',
        'pos_integrity.php',
    ];
}

function pos_integrity_hash_file(string $absPath): string {
    if (!is_file($absPath) || !is_readable($absPath)) {
        return '';
    }
    return hash_file('sha256', $absPath);
}

/** @return array<string,string> relative path => sha256 */
function pos_integrity_collect_hashes(): array {
    $dir = pos_integrity_config_dir();
    $out = [];
    foreach (pos_integrity_protected_relative_paths() as $rel) {
        $abs = $dir . '/' . $rel;
        $hash = pos_integrity_hash_file($abs);
        if ($hash !== '') {
            $out[$rel] = $hash;
        }
    }
    return $out;
}

function pos_integrity_build_manifest(): bool {
    $hashes = pos_integrity_collect_hashes();
    if (!$hashes) {
        return false;
    }
    $payload = [
        'version' => 1,
        'built_at' => gmdate('c'),
        'files' => $hashes,
    ];
    $path = pos_integrity_manifest_path();
    $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    if ($json === false) {
        return false;
    }
    return @file_put_contents($path, $json . "\n", LOCK_EX) !== false;
}

/**
 * @return array{ok:bool,reason?:string,file?:string}
 */
function pos_integrity_verify_manifest(): array {
    $path = pos_integrity_manifest_path();
    if (!is_file($path) || !is_readable($path)) {
        if (pos_integrity_build_manifest()) {
            return ['ok' => true];
        }
        return ['ok' => false, 'reason' => 'manifest_missing'];
    }
    $raw = @file_get_contents($path);
    if ($raw === false || trim($raw) === '') {
        return ['ok' => false, 'reason' => 'manifest_empty'];
    }
    $data = json_decode($raw, true);
    if (!is_array($data) || !isset($data['files']) || !is_array($data['files'])) {
        return ['ok' => false, 'reason' => 'manifest_invalid'];
    }
    $dir = pos_integrity_config_dir();
    foreach ($data['files'] as $rel => $expected) {
        $rel = (string)$rel;
        $expected = strtolower(trim((string)$expected));
        if ($rel === '' || $expected === '') {
            continue;
        }
        $abs = $dir . '/' . $rel;
        if (!is_file($abs)) {
            return ['ok' => false, 'reason' => 'file_missing', 'file' => $rel];
        }
        $actual = pos_integrity_hash_file($abs);
        if ($actual === '' || !hash_equals($expected, $actual)) {
            return ['ok' => false, 'reason' => 'checksum_mismatch', 'file' => $rel];
        }
    }
    return ['ok' => true];
}

function pos_integrity_recent_ok($conn): bool {
    if (!$conn || !function_exists('pos_db_get_setting_value')) {
        return false;
    }
    $raw = pos_db_get_setting_value($conn, 'pos_integrity_ok_at');
    if ($raw === null || $raw === '') {
        return false;
    }
    return (time() - (int)$raw) < 3600;
}

function pos_integrity_mark_ok($conn): void {
    if ($conn && function_exists('pos_db_set_setting_value')) {
        @pos_db_set_setting_value($conn, 'pos_integrity_ok_at', (string)time());
    }
}

function pos_integrity_lock_and_report($conn, string $reason, string $file = ''): void {
    if ($conn && function_exists('pos_license_clear_local_activation_cache')) {
        pos_license_clear_local_activation_cache($conn);
    }
    if ($conn && function_exists('pos_db_set_setting_value')) {
        @pos_db_set_setting_value($conn, 'pos_integrity_ok_at', '0');
        @pos_db_set_setting_value($conn, 'pos_integrity_lock_reason', substr($reason . ($file !== '' ? ':' . $file : ''), 0, 200));
    }
    if (function_exists('pos_supabase_log_admin_event_remote') && function_exists('pos_ensure_license_serial')) {
        $serial = pos_ensure_license_serial($conn);
        $msg = 'Integrity violation: ' . $reason;
        if ($file !== '') {
            $msg .= ' (' . $file . ')';
        }
        @pos_supabase_log_admin_event_remote($serial, null, 'integrity_violation', $msg);
    }
}

function pos_integrity_verify_or_lock($conn): bool {
    static $verifiedThisRequest = false;
    if ($verifiedThisRequest) {
        return true;
    }
    if (pos_integrity_recent_ok($conn)) {
        $verifiedThisRequest = true;
        return true;
    }
    $r = pos_integrity_verify_manifest();
    if (!empty($r['ok'])) {
        pos_integrity_mark_ok($conn);
        $verifiedThisRequest = true;
        return true;
    }
    $reason = isset($r['reason']) ? (string)$r['reason'] : 'failed';
    $file = isset($r['file']) ? (string)$r['file'] : '';
    pos_integrity_lock_and_report($conn, $reason, $file);
    return false;
}

function pos_api_integrity_json_exit($conn, string $reason, string $file = ''): void {
    if (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: application/json; charset=utf-8');
    http_response_code(403);
    $serial = function_exists('pos_ensure_license_serial') ? pos_ensure_license_serial($conn) : '';
    echo json_encode([
        'status' => 'integrity_locked',
        'message' => 'فایلەکانی سیکوریتی دەستکاری کراون یان کەمن. پەیوەندی بە ئەدمین بکە بۆ کۆدی نوێ.',
        'integrity_reason' => $reason,
        'integrity_file' => $file,
        'license_serial' => $serial,
        'self_lock' => true,
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

function pos_api_require_integrity_or_exit($conn): void {
    if (pos_integrity_verify_or_lock($conn)) {
        return;
    }
    $reason = 'checksum_mismatch';
    $file = '';
    if ($conn && function_exists('pos_db_get_setting_value')) {
        $raw = pos_db_get_setting_value($conn, 'pos_integrity_lock_reason');
        if ($raw !== null && $raw !== '') {
            $parts = explode(':', (string)$raw, 2);
            $reason = $parts[0] !== '' ? $parts[0] : $reason;
            if (isset($parts[1])) {
                $file = $parts[1];
            }
        }
    }
    pos_api_integrity_json_exit($conn, $reason, $file);
}

function pos_api_report_integrity_violation_and_exit($conn): void {
    if (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: application/json; charset=utf-8');
    $reason = isset($_POST['reason']) ? substr(trim((string)$_POST['reason']), 0, 64) : 'client_report';
    pos_integrity_lock_and_report($conn, $reason);
    pos_api_integrity_json_exit($conn, $reason);
}
