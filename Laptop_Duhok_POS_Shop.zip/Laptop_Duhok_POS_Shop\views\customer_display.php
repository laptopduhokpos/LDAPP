<?php
if (!defined('POS_APP_VERSION')) {
    require_once __DIR__ . '/../config/version.php';
}
$pos_machine_device_keys = ['primary' => '', 'terminal' => ''];
if (!empty($conn)) {
    require_once __DIR__ . '/../config/supabase_license.php';
    if (function_exists('pos_machine_device_keys_for_client')) {
        $pos_machine_device_keys = pos_machine_device_keys_for_client($conn);
    }
}
?><!DOCTYPE html>
    <html lang="ku" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
        <meta http-equiv="Pragma" content="no-cache" />
        <meta http-equiv="Expires" content="0" />
        <title><?php echo htmlspecialchars('Customer Display · v' . POS_APP_VERSION, ENT_QUOTES, 'UTF-8'); ?></title>
        <link rel="preload" href="public/vendor/fontawesome/webfonts/fa-solid-900.woff2" as="font" type="font/woff2" crossorigin>
        <link rel="preload" href="public/vendor/fontawesome/webfonts/fa-brands-400.woff2" as="font" type="font/woff2" crossorigin>
        <link rel="stylesheet" href="public/vendor/fontawesome/css/all.min.css">
        <link rel="preload" href="public/fonts/rudaw/Rudaw-Regular.ttf" as="font" type="font/ttf" crossorigin>
        <!-- Offline-first: Rudaw only -->
        <link rel="stylesheet" href="public/css/pos-00-fonts.css?v=<?php echo time(); ?>">
        <link rel="stylesheet" href="public/css/customer.css?v=<?php echo time(); ?>">
        <script>
        (function posCustomerDisplayBootstrap() {
            try {
                var KEY = 'pos_client_device_key';
                var serverKeys = {
                    primary: <?php echo json_encode((string)($pos_machine_device_keys['primary'] ?? ''), JSON_UNESCAPED_UNICODE); ?>,
                    terminal: <?php echo json_encode((string)($pos_machine_device_keys['terminal'] ?? ''), JSON_UNESCAPED_UNICODE); ?>
                };
                var isTerminal = false;
                try {
                    if (localStorage.getItem('pos_fragi_device_mode') === '1') {
                        isTerminal = true;
                    } else {
                        var lk = localStorage.getItem('pos_client_device_key') || '';
                        if (String(lk).indexOf('pos-term-') === 0) {
                            isTerminal = true;
                        }
                    }
                    if (!isTerminal) {
                        localStorage.setItem('pos_enable_multi_device', '0');
                    }
                } catch (eT) {}
                var v = '';
                if (isTerminal) {
                    if (serverKeys.terminal && String(serverKeys.terminal).length >= 8) {
                        v = serverKeys.terminal;
                    } else {
                        window.__posTerminalMacMissing = true;
                    }
                } else {
                    v = serverKeys.primary || '';
                }
                if (!isTerminal && (!v || String(v).length < 8)) {
                    v = typeof localStorage !== 'undefined' ? localStorage.getItem(KEY) : null;
                }
                if (!v || String(v).length < 8) {
                    if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') v = crypto.randomUUID();
                    else v = 'dk' + String(Date.now()) + Math.random().toString(36).slice(2, 14);
                }
                try { localStorage.setItem(KEY, v); } catch (e0) {}
                window.__posDeviceKey = v;
            } catch (e) {
                window.__posDeviceKey = '';
            }
            try {
                if (typeof window.fetch === 'function' && !window.__posCustFetchWrapped) {
                    window.__posCustFetchWrapped = true;
                    var _f = window.fetch.bind(window);
                    window.fetch = function (input, init) {
                        init = init || {};
                        try {
                            if (window.__posDeviceKey && typeof input === 'string' && typeof Headers !== 'undefined' && (
                                input.indexOf('?action=') !== -1 || input.indexOf('api/all.php') !== -1
                            )) {
                                var h = new Headers(init.headers || undefined);
                                if (!h.has('X-POS-Device-Key')) h.set('X-POS-Device-Key', window.__posDeviceKey);
                                init.headers = h;
                            }
                        } catch (eH) {}
                        return _f(input, init);
                    };
                }
                var dk = window.__posDeviceKey || '';
                if (dk) {
                    var fd = new FormData();
                    fd.append('action', 'register_pos_client_device');
                    fd.append('device_key', dk);
                    try { fd.append('platform', typeof navigator !== 'undefined' ? (navigator.platform || '') + ' · customer-display' : 'customer-display'); } catch (e2) {}
                    fetch('?action=register_pos_client_device', { method: 'POST', body: fd, credentials: 'same-origin' }).catch(function () {});
                }
            } catch (e3) { /* noop */ }
        })();
        </script>
        <script src="public/js/display/customer-display.js?v=<?php echo time(); ?>" defer></script>
    </head>
    <body>
        <div class="bg-shapes">
            <div class="shape shape-1"></div>
            <div class="shape shape-2"></div>
        </div>

        <div id="conn-status" title="Connection Status"></div>

        <div id="idle-screen">
            <div class="logo-area"><i class="fas fa-cube"></i> Laptop Duhok POS v<?php echo htmlspecialchars(POS_APP_VERSION, ENT_QUOTES, 'UTF-8'); ?></div>
            <h1 style="font-size: 4rem; margin: 0; font-weight: 900;">بەخێربێن</h1>
            <p style="font-size: 2rem; opacity: 0.8; letter-spacing: 2px;">Welcome to Laptop Duhok POS v<?php echo htmlspecialchars(POS_APP_VERSION, ENT_QUOTES, 'UTF-8'); ?></p>
        </div>

        <div id="active-screen">
            <div class="left-panel">
                <div class="cart-header">
                    <span><i class="fas fa-shopping-cart"></i> سەبەت (Cart)</span>
                    <span id="item-count-badge">0 Items</span>
                </div>
                <div class="cart-list" id="cart-list"></div>
            </div>
            <div class="right-panel">
                <div class="last-item-box" id="last-item-box" style="opacity:0">
                    <div class="last-item-icon"><i class="fas fa-box-open"></i></div>
                    <div class="last-item-name" id="last-name"></div>
                    <div class="last-item-price" id="last-price"></div>
                </div>
                <div class="total-card">
                    <div class="total-label">کۆی گشتی (Total)</div>
                    <div class="total-amount"><span id="total-display">0</span> <small style="font-size:2rem" id="currency-symbol">IQD</small></div>
                </div>
            </div>
        </div>

        <div id="success-screen" class="success-overlay">
            <div class="success-icon"><i class="fas fa-check-circle"></i></div>
            <h1 style="font-size: 5rem; margin: 0; font-weight: 900;">سوپاس!</h1>
            <h2 style="font-size: 2.5rem; opacity: 0.9;">Thank You for Shopping</h2>
            <div id="change-display" style="font-size: 2rem; margin-top: 20px; background: rgba(0,0,0,0.2); padding: 10px 30px; border-radius: 20px;"></div>
        </div>

        
    </body>
    </html>