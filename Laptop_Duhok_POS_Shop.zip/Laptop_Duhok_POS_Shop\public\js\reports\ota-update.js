/**
 * Supabase OTA self-update (shop side).
 * Clear modal feedback: checking / already latest / downloading / done / error.
 */
(function () {
    'use strict';

    var DISMISS_KEY = 'pos_ota_dismissed_version';
    var LAST_CHECK_KEY = 'pos_ota_last_check_at';
    var SOFT_TOAST_KEY = 'pos_ota_soft_toasted_version';
    var DOCK_MIN_KEY = 'pos_ota_dock_minimized';
    var PENDING_KEY = 'pos_ota_pending_latest';
    var POLL_MS = 15 * 60 * 1000;
    var _latest = null;
    var _busy = false;
    var _pollTimer = null;
    var _pendingCount = 0;
    var _uiDocked = false;
    var _lastModalOpts = null;

    function esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function (ch) {
            return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch];
        });
    }

    function currentVersion() {
        if (typeof window.getPosAppVersion === 'function') return String(window.getPosAppVersion() || '0');
        return String(window.POS_APP_VERSION || '0');
    }

    function parseVerParts(v) {
        return String(v || '0').replace(/^v/i, '').split(/[.+-]/).map(function (x) {
            return parseInt(x, 10) || 0;
        });
    }

    function cmpVer(a, b) {
        var pa = parseVerParts(a);
        var pb = parseVerParts(b);
        var n = Math.max(pa.length, pb.length);
        for (var i = 0; i < n; i++) {
            var da = pa[i] || 0;
            var db = pb[i] || 0;
            if (da > db) return 1;
            if (da < db) return -1;
        }
        return 0;
    }

    /** How many release notes are newer than the installed version (capped by remote latest if given). */
    function countUpdatesAhead(toVer) {
        var cur = currentVersion();
        var list = window.POS_CHANGELOG || [];
        var n = 0;
        var seen = Object.create(null);
        for (var i = 0; i < list.length; i++) {
            var v = String((list[i] && list[i].version) || '');
            if (!v || seen[v]) continue;
            if (cmpVer(v, cur) <= 0) continue;
            if (toVer && cmpVer(v, toVer) > 0) continue;
            seen[v] = 1;
            n++;
        }
        if (toVer && cmpVer(toVer, cur) > 0 && n < 1) n = 1;
        return n;
    }

    function isArLang() {
        return (typeof getCurrentLanguage === 'function' ? getCurrentLanguage() : 'badini') === 'ar';
    }

    function savePendingLatest(latest) {
        try {
            if (latest && latest.version) {
                localStorage.setItem(PENDING_KEY, JSON.stringify({
                    version: latest.version,
                    title: latest.title || '',
                    notes: latest.notes || '',
                    package_url: latest.package_url || '',
                    sha256: latest.sha256 || '',
                    force_update: !!latest.force_update
                }));
            } else {
                localStorage.removeItem(PENDING_KEY);
            }
        } catch (_e) {}
    }

    function loadPendingLatest() {
        try {
            var raw = localStorage.getItem(PENDING_KEY);
            if (!raw) return null;
            var o = JSON.parse(raw);
            if (!o || !o.version) return null;
            if (cmpVer(o.version, currentVersion()) <= 0) {
                localStorage.removeItem(PENDING_KEY);
                return null;
            }
            return o;
        } catch (_e2) {
            return null;
        }
    }

    function restorePendingDock() {
        var pending = loadPendingLatest();
        if (!pending) {
            hideOtaDock();
            return;
        }
        _latest = pending;
        paintLoginOtaButton(true, pending);
        paintOtaDock(pending);
        paintHasUpdate(pending);
    }

    function hideOtaDock() {
        var dock = el('pos-ota-dock');
        if (!dock) return;
        dock.style.display = 'none';
        dock.hidden = true;
        dock.classList.remove('is-visible', 'is-minimized', 'is-progressing');
        _pendingCount = 0;
        setDockProgress(false, 0, '');
    }

    function setDockProgress(show, pct, text) {
        var wrap = el('pos-ota-dock-progress-wrap');
        var bar = el('pos-ota-dock-progress-bar');
        var txt = el('pos-ota-dock-progress-text');
        var icon = el('pos-ota-dock-icon');
        if (!wrap) return;
        if (!show) {
            wrap.style.display = 'none';
            wrap.setAttribute('aria-hidden', 'true');
            if (icon) icon.className = 'fas fa-cloud-download-alt';
            return;
        }
        wrap.style.display = 'flex';
        wrap.setAttribute('aria-hidden', 'false');
        if (bar) bar.style.width = Math.max(0, Math.min(100, pct || 0)) + '%';
        if (txt) txt.textContent = text || '';
        if (icon) {
            icon.className = (pct >= 99)
                ? 'fas fa-check-circle'
                : 'fas fa-spinner fa-spin';
        }
    }

    function ensureOtaDockVisible() {
        var dock = el('pos-ota-dock');
        if (!dock || isLoginScreenVisible()) return null;
        dock.hidden = false;
        dock.style.display = 'flex';
        dock.classList.add('is-visible');
        return dock;
    }

    function updateDockFromOpts(opts) {
        opts = opts || {};
        var dock = ensureOtaDockVisible();
        if (!dock) return;
        dock.classList.remove('is-minimized');
        var textEl = el('pos-ota-dock-text');
        var applyBtn = el('pos-ota-dock-apply');
        var countEl = el('pos-ota-dock-count');
        var plainStatus = String(opts.statusHtml || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
        var ar = isArLang();
        if (opts.progress || _busy) {
            dock.classList.add('is-progressing');
            if (countEl) countEl.style.display = 'none';
            if (applyBtn) applyBtn.style.display = 'none';
            if (textEl) {
                textEl.textContent = plainStatus
                    || (ar ? 'التحديث يعمل في الأسفل — يمكنك العمل' : 'ئابدەیت ل بنێ دەڕوات — کار بکە');
            }
            setDockProgress(true, (opts.progress && opts.progress.pct) || 0, (opts.progress && opts.progress.text) || '');
            return;
        }
        dock.classList.remove('is-progressing');
        setDockProgress(false, 0, '');
        if (countEl) countEl.style.display = '';
        if (applyBtn) applyBtn.style.display = '';
        if (_latest && _latest.version) {
            paintOtaDock(_latest);
            if (textEl && plainStatus) textEl.textContent = plainStatus;
        } else if (textEl) {
            textEl.textContent = plainStatus || (ar ? 'التحديث' : 'ئابدەیت');
        }
    }

    function minimizeOtaModalToDock(opts) {
        _uiDocked = true;
        var modal = el('modal-pos-ota-update');
        if (modal) modal.style.display = 'none';
        updateDockFromOpts(opts || _lastModalOpts || {});
        try {
            if (typeof showToast === 'function') {
                showToast(isArLang()
                    ? 'التحديث في الأسفل — تابع عملك'
                    : 'ئابدەیت ل بنێ یە — بەردەوامی کار بکە', 'info');
            }
        } catch (_eT) {}
    }

    function paintOtaDock(latest) {
        var dock = el('pos-ota-dock');
        if (!dock) return;
        if (!latest || !latest.version) {
            if (!_busy) hideOtaDock();
            return;
        }
        // On login screen the dedicated OTA panel/button is enough
        if (isLoginScreenVisible()) {
            if (!_busy) hideOtaDock();
            return;
        }
        var ver = String(latest.version || '');
        var count = countUpdatesAhead(ver);
        if (count < 1) count = 1;
        _pendingCount = count;
        var countEl = el('pos-ota-dock-count');
        var textEl = el('pos-ota-dock-text');
        var ar = isArLang();
        if (countEl) {
            countEl.style.display = '';
            countEl.textContent = String(count);
        }
        if (textEl && !_busy) {
            textEl.textContent = ar
                ? (count + ' تحديث متوفر · v' + ver + ' — اعمل الآن وحدّث لاحقاً إن أردت')
                : (count + ' ئابدەیت هاتیە · v' + ver + ' — کار بکە، د دڵی خو دا نوێ بکە');
        }
        var minimized = false;
        try { minimized = localStorage.getItem(DOCK_MIN_KEY) === '1'; } catch (_eM) {}
        dock.hidden = false;
        dock.style.display = 'flex';
        dock.classList.add('is-visible');
        if (!_busy) {
            dock.classList.remove('is-progressing');
            setDockProgress(false, 0, '');
            dock.classList.toggle('is-minimized', !!minimized);
            var applyBtn = el('pos-ota-dock-apply');
            if (applyBtn) applyBtn.style.display = '';
        }
    }

    function minimizeOtaDock() {
        try { localStorage.setItem(DOCK_MIN_KEY, '1'); } catch (_e) {}
        var dock = el('pos-ota-dock');
        if (dock && dock.classList.contains('is-visible') && !dock.classList.contains('is-progressing')) {
            dock.classList.add('is-minimized');
        }
        try {
            if (typeof showToast === 'function') {
                showToast(isArLang()
                    ? 'التحديث ينتظر في الأسفل — يمكنك المتابعة بالعمل'
                    : 'ئابدەیت ل بنێ چاوەڕێیە — بەردەوامی کار بکە', 'info');
            }
        } catch (_eT) {}
    }

    function expandOtaDock() {
        try { localStorage.removeItem(DOCK_MIN_KEY); } catch (_e) {}
        var dock = el('pos-ota-dock');
        if (dock) dock.classList.remove('is-minimized');
    }

    function softNotifyUpdate(latest) {
        if (!latest || !latest.version || latest.force_update) return;
        var ver = String(latest.version);
        var last = '';
        try { last = String(localStorage.getItem(SOFT_TOAST_KEY) || ''); } catch (_e) {}
        if (last === ver) return;
        try { localStorage.setItem(SOFT_TOAST_KEY, ver); } catch (_e2) {}
        var n = countUpdatesAhead(ver) || 1;
        try {
            if (typeof showToast === 'function') {
                showToast(isArLang()
                    ? (n + ' تحديث في الأسفل — يمكنك العمل ثم التحديث')
                    : (n + ' ئابدەیت ل بنێ — کار بکە، پاشتر نوێ بکە'), 'info');
            }
        } catch (_e3) {}
    }

    function isAdminUser() {
        try {
            if (typeof currentUser !== 'undefined' && currentUser && String(currentUser.role || '').toLowerCase() === 'admin') return true;
        } catch (_e) {}
        return false;
    }

    function isLoginScreenVisible() {
        var login = el('login-screen');
        if (!login) return false;
        if (login.style.display === 'none') return false;
        try {
            var cs = window.getComputedStyle(login);
            if (cs.display === 'none' || cs.visibility === 'hidden') return false;
        } catch (_e) {}
        return true;
    }

    function getLoginPinAuth() {
        var pinEl = el('pin-code');
        var userEl = el('login-user-select');
        var pin = pinEl ? String(pinEl.value || '').trim() : '';
        var userId = userEl ? String(userEl.value || '').trim() : '';
        return { pin: pin, userId: userId };
    }

    function paintLoginOtaButton(hasUpdate, latest) {
        var btn = el('login-ota-btn');
        var badge = el('login-ota-badge');
        var label = el('login-ota-btn-label');
        var icon = el('login-ota-btn-icon');
        var hint = el('login-ota-hint');
        if (!btn) return;
        if (hasUpdate && latest) {
            btn.style.background = 'linear-gradient(135deg,#059669,#10b981)';
            btn.style.color = '#fff';
            btn.style.borderColor = '#059669';
            btn.style.boxShadow = '0 4px 14px rgba(16,185,129,.35)';
            if (badge) badge.style.display = 'inline-block';
            if (label) label.textContent = 'ئابدەیتی نوێ';
            if (icon) icon.className = 'fas fa-cloud-download-alt';
            if (hint) {
                hint.style.display = 'block';
                hint.style.color = '#059669';
                hint.textContent = 'دوماهیک ئابدەیت هاتووە: v' + String(latest.version || '') + ' — کلیک بکە بۆ داونلۆد';
            }
        } else {
            btn.style.background = '';
            btn.style.color = '';
            btn.style.borderColor = '';
            btn.style.boxShadow = '';
            if (badge) badge.style.display = 'none';
            if (label) label.textContent = 'نوێکردنەوە';
            if (icon) icon.className = 'fas fa-cloud-download-alt';
            if (hint) {
                hint.style.display = 'none';
                hint.textContent = '';
            }
        }
    }

    function apiUrl(action) {
        return 'api/all.php?action=' + encodeURIComponent(action) + '&t=' + Date.now();
    }

    function el(id) {
        return document.getElementById(id);
    }

    function setCardProgress(show, pct, text) {
        var wrap = el('settings-ota-progress');
        var bar = el('settings-ota-progress-bar');
        var txt = el('settings-ota-progress-text');
        if (wrap) wrap.style.display = show ? 'block' : 'none';
        if (bar) bar.style.width = Math.max(0, Math.min(100, pct || 0)) + '%';
        if (txt) txt.textContent = text || '';
    }

    function setModalProgress(show, pct, text) {
        var wrap = el('pos-ota-modal-progress');
        var bar = el('pos-ota-modal-progress-bar');
        var txt = el('pos-ota-modal-progress-text');
        if (wrap) wrap.style.display = show ? 'block' : 'none';
        if (bar) bar.style.width = Math.max(0, Math.min(100, pct || 0)) + '%';
        if (txt) txt.textContent = text || '';
        setCardProgress(show, pct, text);
    }

    function setCardStatus(html, notes) {
        var statusEl = el('settings-ota-status');
        var notesEl = el('settings-ota-notes');
        var applyBtn = el('settings-ota-apply-btn');
        if (statusEl) statusEl.innerHTML = html;
        if (notesEl) {
            if (notes) {
                notesEl.style.display = 'block';
                notesEl.textContent = notes;
            } else {
                notesEl.style.display = 'none';
                notesEl.textContent = '';
            }
        }
        if (applyBtn) applyBtn.style.display = (_latest && isAdminUser()) ? 'inline-flex' : 'none';
    }

    function syncLoginPanelFromModal(opts) {
        if (!isLoginScreenVisible()) return;
        if (typeof window.__posShowLoginOtaPanel !== 'function') return;
        var plainStatus = String(opts.statusHtml || '').replace(/<[^>]+>/g, '').trim();
        var title = plainStatus || 'نوێکردنەوە';
        var body = [opts.versionText || '', opts.bodyText || ''].filter(Boolean).join('\n');
        var showApply = !!opts.showApply && !_busy;
        window.__posShowLoginOtaPanel(title, body, {
            showApply: showApply,
            hideLater: !!opts.hideClose,
            hideCheck: !!opts.hideCheck || !!opts.progress,
            keepProgress: !!opts.progress
        });
        var progWrap = el('login-ota-panel-progress');
        var progBar = el('login-ota-panel-bar');
        var progTxt = el('login-ota-panel-prog-text');
        if (opts.progress) {
            if (progWrap) progWrap.style.display = 'block';
            if (progBar) progBar.style.width = Math.max(0, Math.min(100, opts.progress.pct || 0)) + '%';
            if (progTxt) progTxt.textContent = opts.progress.text || '';
        } else if (opts.clearProgress) {
            if (progWrap) progWrap.style.display = 'none';
        }
        var panelApply = el('login-ota-panel-apply');
        if (panelApply) {
            panelApply.style.display = showApply ? 'inline-flex' : 'none';
            panelApply.disabled = !!opts.disableApply || _busy;
        }
    }

    function setModalUi(opts) {
        opts = opts || {};
        _lastModalOpts = opts;
        var modal = el('modal-pos-ota-update');
        var titleEl = el('pos-ota-modal-title');
        var statusEl = el('pos-ota-modal-status');
        var verEl = el('pos-ota-modal-version');
        var bodyEl = el('pos-ota-modal-body');
        var laterBtn = el('pos-ota-modal-later');
        var laterLabel = el('pos-ota-modal-later-label');
        var closeBtn = el('pos-ota-modal-close');
        var minBtn = el('pos-ota-modal-minimize');
        var applyBtn = el('pos-ota-modal-apply');
        var checkBtn = el('pos-ota-modal-check');
        var ar = isArLang();

        if (titleEl) titleEl.innerHTML = opts.titleHtml || '<i class="fas fa-cloud-download-alt"></i> نوێکردنەوەی سیستەم';
        if (statusEl) {
            statusEl.innerHTML = opts.statusHtml || '';
            statusEl.style.color = opts.statusColor || 'var(--text)';
        }
        if (verEl) verEl.textContent = opts.versionText || ('ئێستا: v' + currentVersion());
        if (bodyEl) bodyEl.textContent = opts.bodyText || '';

        // Show apply on login screen too (PIN sent with request)
        var showApply = !!opts.showApply && !_busy && (isAdminUser() || isLoginScreenVisible());
        if (applyBtn) {
            applyBtn.style.display = showApply ? '' : 'none';
            applyBtn.disabled = !!opts.disableApply || _busy;
            if (showApply) applyBtn.innerHTML = '<i class="fas fa-bolt"></i> ئێستا نوێ بکە';
        }
        // Always allow minimize-to-dock so shop can keep selling during check/download
        var canMinimize = !opts.forceBlock;
        if (laterBtn) {
            laterBtn.style.display = canMinimize ? '' : 'none';
            if (opts.isNoUpdate) {
                laterBtn.innerHTML = '<i class="fas fa-check"></i> ' + (ar ? 'حسناً' : 'باشە (تەواو)');
            } else if (laterLabel) {
                laterLabel.textContent = (_busy || opts.progress)
                    ? (ar ? 'تصغير للأسفل — متابعة العمل' : 'بچووک بکە — بەردەوامی کار')
                    : (ar ? 'لاحقاً — متابعة العمل' : 'بچووک بکە — بەردەوامی کار');
            } else {
                laterBtn.innerHTML = '<i class="fas fa-compress-arrows-alt"></i> ' + (
                    (_busy || opts.progress)
                        ? (ar ? 'تصغير للأسفل — متابعة العمل' : 'بچووک بکە — بەردەوامی کار')
                        : (ar ? 'لاحقاً — متابعة العمل' : 'بچووک بکە — بەردەوامی کار')
                );
            }
        }
        if (closeBtn) closeBtn.style.display = canMinimize ? '' : 'none';
        
        // Minimize button (the small "-" at top) - hide if it's just a "No update" info modal
        if (minBtn) minBtn.style.display = (canMinimize && !opts.isNoUpdate) ? '' : 'none';
        
        if (checkBtn) {
            checkBtn.style.display = (opts.hideCheck || opts.progress || _busy) ? 'none' : '';
            checkBtn.disabled = !!_busy;
        }

        if (opts.progress) {
            setModalProgress(true, opts.progress.pct || 0, opts.progress.text || '');
        } else if (opts.clearProgress) {
            setModalProgress(false, 0, '');
        }

        // Always mirror status onto login card (login sits above normal modals)
        syncLoginPanelFromModal(opts);

        if (!modal) return;
        modal.style.zIndex = '2147483020';

        // Docked mode: keep working — no full-screen block; progress lives at bottom
        if (_uiDocked && !opts.forceModal && !isLoginScreenVisible()) {
            modal.style.display = 'none';
            updateDockFromOpts(opts);
            return;
        }

        modal.style.display = isLoginScreenVisible() ? 'none' : 'flex';
        if (opts.progress || _busy) {
            // Still sync dock so minimize is instant later
            updateDockFromOpts(opts);
        }
    }

    function paintNoUpdate() {
        _latest = null;
        setCardStatus(
            '<i class="fas fa-check-circle" style="color:#34d399;"></i> وەشانی ئێستا <strong dir="ltr">v' + esc(currentVersion()) + '</strong> — نوێترینە.',
            ''
        );
        setCardProgress(false, 0, '');
    }

    function paintHasUpdate(latest) {
        _latest = latest || null;
        if (!_latest) {
            paintNoUpdate();
            return;
        }
        var title = String(_latest.title || '').trim();
        var notes = String(_latest.notes || '').trim();
        var ver = String(_latest.version || '').trim();
        var force = !!_latest.force_update;
        var html = '<i class="fas fa-exclamation-circle" style="color:#fbbf24;"></i> ئابدەیتی نوێ: <strong dir="ltr">v' + esc(ver) + '</strong>'
            + (title ? (' — ' + esc(title)) : '')
            + (force ? ' <span style="color:#f87171;">(پێویستە)</span>' : '')
            + '<br><span style="opacity:.85;">ئێستا: <span dir="ltr">v' + esc(currentVersion()) + '</span></span>';
        if (!isAdminUser()) {
            html += '<br><span style="color:#94a3b8; font-size:0.85rem;">بۆ دانان، بچۆ ژوورەوە وەک ئەدمین.</span>';
        }
        setCardStatus(html, notes);
    }

    function dismissedVersion() {
        try { return String(localStorage.getItem(DISMISS_KEY) || ''); } catch (_e) { return ''; }
    }

    function setDismissed(ver) {
        try { localStorage.setItem(DISMISS_KEY, String(ver || '')); } catch (_e) {}
    }

    function shouldAutoPrompt(latest) {
        if (!latest || !latest.version) return false;
        // Forced updates still interrupt. Optional ones use bottom dock so shops keep working (poor WiFi).
        if (latest.force_update) return true;
        return false;
    }

    function openModalForLatest(latest) {
        _latest = latest;
        _uiDocked = false;
        paintHasUpdate(latest);
        
        var lang = typeof getCurrentLanguage === 'function' ? getCurrentLanguage() : 'badini';
        var isAr = lang === 'ar';
        
        var loginHint = '';
        if (isLoginScreenVisible()) {
            loginHint = isAr 
                ? '\n\n• «تحديث الآن» = تنزيل وتثبيت فوري\n• «تصغير» = العمل أثناء التحديث من الأسفل\n• «فحص» = إعادة الفحص\n\nأدخل رمز PIN للمدير قبل «تحديث الآن».'
                : '\n\n• «نوکە ئابدەیت بکە» = داونلود و دانان\n• «بچووک بکە» = کار بکە؛ ئابدەیت ل بنێ دەڕوات\n• «پشکنین» = دوبارە سەحکێ\n\nکودێ PIN یێ ئەدمینی بنفیسە بەری «نوکە ئابدەیت بکە».';
        } else {
            loginHint = isAr
                ? '\n\n• «تحديث الآن» = يبدأ التحميل ويصغر للأسفل لتعمل\n• «تصغير» = متابعة البيع\n• «فحص» = إعادة الفحص'
                : '\n\n• «نوکە ئابدەیت بکە» = داونلود دەستپێدکەت و دچیتە بنێ — کار بکە\n• «بچووک بکە» = بەردەوامی فرۆتن\n• «پشکنین» = دوبارە سەحکێ';
        }

        var titleHtml = isAr ? '<i class="fas fa-cloud-download-alt"></i> تحديث جديد متوفر' : '<i class="fas fa-cloud-download-alt"></i> ئابدەیتەکێ نوی یێ ئامادەیە';
        var statusHtml = isAr ? '<i class="fas fa-exclamation-circle" style="color:#fbbf24;"></i> يتوفر تحديث أخير — اختر: الآن أو تصغير للأسفل' : '<i class="fas fa-exclamation-circle" style="color:#fbbf24;"></i> دوماهیک ئابدەیت یێ هاتی — نوکە یان بچووک بکە ل بنێ';
        var defaultBody = isAr ? 'نسخة جديدة متوفرة.' : 'ڤێرژنەکێ نوی یێ ئامادەیە.';
        
        setModalUi({
            titleHtml: titleHtml,
            statusHtml: statusHtml,
            statusColor: '#fbbf24',
            versionText: 'v' + String(latest.version || '') + (isAr ? '  ←  الحالي v' : '  ←  نوکە v') + currentVersion(),
            bodyText: String(latest.notes || latest.title || defaultBody) + loginHint,
            showApply: true,
            hideClose: false,
            clearProgress: true,
            forceModal: true
        });
    }

    function openModalNoUpdate(reason) {
        _latest = null;
        _uiDocked = false;
        try { hideOtaDock(); } catch (_eH) {}
        paintNoUpdate();
        
        var lang = typeof getCurrentLanguage === 'function' ? getCurrentLanguage() : 'badini';
        var isAr = lang === 'ar';
        
        var body = isAr ? 'نظامك محدث حالياً. لا حاجة للتنزيل.' : 'سیستەمێ تە یێ نوی یە. پێدڤی ب داونلودێ ناکەت.';
        if (reason === 'none') {
            body = isAr ? 'لم يتم نشر أي تحديث على السيرفر بعد.' : 'هێشتا چ ئابدەیت ل سەر سێرڤەری نینن.';
        } else if (reason === 'offline') {
            body = isAr ? 'لا يوجد إنترنت أو اتصال بالسيرفر. حاول مرة أخرى.' : 'ئینتەرنێت یان پەیوەندی ب سێرڤەری نینە. دوبارە هەول بدە.';
        } else if (reason === 'error') {
            body = isAr ? 'فشل الفحص. حاول مرة أخرى أو اذهب إلى الإعدادات → التحديث.' : 'پشکنین سەرنەکەفت. دوبارە هەول بدە یان بچە ڕێکخستن → ئابدەیت.';
        }
        
        var titleHtml = isAr ? '<i class="fas fa-check-circle"></i> التحديث' : '<i class="fas fa-check-circle"></i> ئابدەیت';
        var statusHtml = reason === 'offline' || reason === 'error'
            ? '<i class="fas fa-times-circle" style="color:#f87171;"></i> ' + (isAr ? (reason === 'offline' ? 'لا يوجد اتصال' : 'خطأ') : (reason === 'offline' ? 'پەیوەندی نینە' : 'خەلەتی'))
            : '<i class="fas fa-check-circle" style="color:#34d399;"></i> ' + (isAr ? 'لا حاجة للتنزيل — النسخة حديثة' : 'پێدڤی ب داونلودێ ناکەت — ڤێرژن یێ نوی یە');

        setModalUi({
            titleHtml: titleHtml,
            statusHtml: statusHtml,
            statusColor: (reason === 'offline' || reason === 'error') ? '#f87171' : '#34d399',
            versionText: (isAr ? 'الحالي: v' : 'نوکە: v') + currentVersion(),
            bodyText: body,
            showApply: false,
            clearProgress: true,
            forceModal: true,
            isNoUpdate: true
        });
    }

    function openModalChecking() {
        var lang = typeof getCurrentLanguage === 'function' ? getCurrentLanguage() : 'badini';
        var isAr = lang === 'ar';
        // Don't block the shop: check runs in bottom dock
        _uiDocked = !isLoginScreenVisible();
        
        setModalUi({
            titleHtml: '<i class="fas fa-sync-alt fa-spin"></i> ' + (isAr ? 'جاري الفحص...' : 'پشکنین...'),
            statusHtml: isAr ? 'يرجى الانتظار — جاري فحص التحديثات...' : 'چاڤەڕێ بە — پشکنینا ئابدەیتان...',
            statusColor: '#fbbf24',
            versionText: (isAr ? 'الحالي: v' : 'نوکە: v') + currentVersion(),
            bodyText: isAr ? 'جاري الاتصال بالسيرفر... يمكنك العمل — التحديث في الأسفل.' : 'پەیوەندیێ ب سێرڤەری دکەت... کار بکە — ئابدەیت ل بنێ یە.',
            showApply: false,
            hideClose: false,
            progress: { pct: 15, text: isAr ? 'جاري الفحص...' : 'پشکنین...' }
        });
    }

    function closeModal() {
        var modal = el('modal-pos-ota-update');
        if (modal) modal.style.display = 'none';
        if (!_busy) setModalProgress(false, 0, '');
    }

    function dismissModal() {
        // During download/check: only dock — never cancel the running update
        if (_busy || (_lastModalOpts && _lastModalOpts.progress)) {
            minimizeOtaModalToDock(_lastModalOpts);
            return;
        }
        
        // If it was just a "No update" info modal, close it completely without docking
        if (_lastModalOpts && _lastModalOpts.isNoUpdate) {
            closeModal();
            return;
        }

        if (_latest && _latest.version && !_latest.force_update) {
            setDismissed(_latest.version);
        }
        _uiDocked = true;
        closeModal();
        var panel = el('login-ota-panel');
        if (panel) panel.style.display = 'none';
        var hint = el('login-ota-hint');
        if (hint && _latest && _latest.version) {
            hint.style.display = 'block';
            hint.style.color = '#b45309';
            hint.textContent = 'ئابدەیت v' + String(_latest.version) + ' پاش بێخرایە — کار بکە؛ کاتێک ئامادە بوویت نوێ بکە';
        }
        paintLoginOtaButton(!!(_latest && _latest.version), _latest);
        if (_latest && _latest.version) paintOtaDock(_latest);
        try {
            if (typeof showToast === 'function') {
                showToast(isArLang()
                    ? 'يمكنك المتابعة بالعمل — التحديث يظهر في الأسفل'
                    : 'بەردەوامی کار بکە — ئابدەیت ل بنێ دیارە', 'info');
            }
        } catch (_eT) {}
    }

    function goToSettings() {
        closeModal();
        try {
            if (typeof nav === 'function') nav('settings');
        } catch (_e) {}
        setTimeout(function () {
            var card = el('settings-ota-update-card');
            if (card && card.scrollIntoView) {
                try { card.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch (_e2) {}
            }
            if (typeof posOtaRefreshCard === 'function') posOtaRefreshCard();
        }, 250);
    }

    function postForm(fields) {
        var form = new URLSearchParams();
        Object.keys(fields || {}).forEach(function (k) {
            form.set(k, fields[k] == null ? '' : String(fields[k]));
        });
        // From login screen: send admin PIN so download/apply works before session
        if (!isAdminUser()) {
            var auth = getLoginPinAuth();
            if (auth.pin) {
                if (!form.has('admin_pin')) form.set('admin_pin', auth.pin);
                if (auth.userId && !form.has('user_id')) form.set('user_id', auth.userId);
            }
        }
        return fetch('api/all.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
            body: form.toString(),
            credentials: 'same-origin',
            cache: 'no-store'
        }).then(function (r) { return r.json(); });
    }

    function checkUpdate(opts) {
        opts = opts || {};
        var interactive = !!opts.interactive;
        var showModalIfNew = opts.showModalIfNew !== false;
        var alwaysModal = !!opts.alwaysModal;
        if (_busy) return Promise.resolve(null);

        var checkBtn = el('settings-ota-check-btn');
        if (interactive && checkBtn) {
            checkBtn.disabled = true;
            checkBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> …';
        }
        if (interactive) {
            setCardStatus('<i class="fas fa-spinner fa-spin"></i> پشکنین…', '');
        }
        if (alwaysModal || (interactive && showModalIfNew)) {
            openModalChecking();
        }

        var url = apiUrl('check_pos_app_update') + '&current=' + encodeURIComponent(currentVersion());
        try {
            var clientSerial = (typeof window.__posLicenseSerial !== 'undefined' && window.__posLicenseSerial)
                ? String(window.__posLicenseSerial).trim()
                : ((window.db && window.db.settings && window.db.settings.pos_license_serial) ? String(window.db.settings.pos_license_serial).trim() : '');
            if (clientSerial) {
                url += '&serial=' + encodeURIComponent(clientSerial);
            }
        } catch (_eSer) {}
        return fetch(url, { credentials: 'same-origin', cache: 'no-store' })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                try { localStorage.setItem(LAST_CHECK_KEY, String(Date.now())); } catch (_e) {}
                if (!data || data.status !== 'success') {
                    if (interactive) setCardStatus('<i class="fas fa-exclamation-triangle" style="color:#f87171;"></i> پشکنین سەرنەکەوت.', '');
                    if (alwaysModal || interactive) openModalNoUpdate(data && data.remote_ok === false ? 'offline' : 'error');
                    return data;
                }
                if (!data.has_update || !data.latest) {
                    paintNoUpdate();
                    paintLoginOtaButton(false, null);
                    savePendingLatest(null);
                    hideOtaDock();
                    if (alwaysModal || interactive) {
                        var reason = 'uptodate';
                        if (data.remote_ok && !data.latest) reason = 'none';
                        openModalNoUpdate(reason);
                    }
                    return data;
                }
                paintHasUpdate(data.latest);
                paintLoginOtaButton(true, data.latest);
                savePendingLatest(data.latest);
                paintOtaDock(data.latest);
                if (alwaysModal || interactive || (showModalIfNew && shouldAutoPrompt(data.latest))) {
                    openModalForLatest(data.latest);
                } else {
                    softNotifyUpdate(data.latest);
                }
                return data;
            })
            .catch(function () {
                if (interactive) {
                    setCardStatus('<i class="fas fa-wifi" style="color:#f87171;"></i> ئینتەرنێت / پەیوەندی نەبوو.', '');
                }
                if (alwaysModal || interactive) openModalNoUpdate('offline');
                return null;
            })
            .finally(function () {
                if (interactive && checkBtn) {
                    checkBtn.disabled = false;
                    checkBtn.innerHTML = '<i class="fas fa-sync-alt"></i> پشکنین';
                }
            });
    }

    function downloadAndApply() {
        if (_busy) return;
        var loginAuth = getLoginPinAuth();
        var canApply = isAdminUser() || (isLoginScreenVisible() && loginAuth.pin.length >= 1);
        if (!canApply) {
            setModalUi({
                statusHtml: '<i class="fas fa-lock" style="color:#f87171;"></i> PINـی ئەدمین پێویستە',
                statusColor: '#f87171',
                versionText: 'ئێستا: v' + currentVersion(),
                bodyText: isLoginScreenVisible()
                    ? 'لە شاشەی چوونەژوور: Manager Admin هەڵبژێرە + PIN بنووسە، پاشان «داگرتن و دانان».'
                    : 'بچۆ ژوورەوە وەک ئەدمین، یان لە شاشەی چوونەژوور PIN بنووسە و نوێکردنەوە بکە.',
                showApply: true,
                clearProgress: true
            });
            return;
        }
        if (!_latest || !_latest.package_url) {
            checkUpdate({ interactive: true, alwaysModal: true }).then(function (data) {
                if (data && data.has_update && data.latest) downloadAndApply();
            });
            return;
        }

        if (!window.confirm(
            'دڵنیای دەتەوێت وەشانی v' + String(_latest.version || '') + ' دابگریت و دابنێیت؟\n\n'
            + 'شاشە دچیتە بنێ — دشێی کار بکەیت دەمێ داونلۆدێ.\n'
            + 'داتای دوکان ناگۆڕدرێت.'
        )) return;

        _busy = true;
        // Auto-dock so cashier can keep selling while download/apply runs
        _uiDocked = !isLoginScreenVisible();
        setModalUi({
            titleHtml: '<i class="fas fa-download"></i> داونلۆد…',
            statusHtml: '<i class="fas fa-spinner fa-spin"></i> داونلۆد دەستی پێکرد — کار بکە، ئابدەیت ل بنێ یە',
            statusColor: '#fbbf24',
            versionText: 'v' + String(_latest.version || '') + ' ← v' + currentVersion(),
            bodyText: 'شاشە بچووک بوو ل بنێ. مەیکوژێنەوە و پەڕە مەگۆڕە تا تەواو دەبێت.',
            showApply: false,
            hideClose: false,
            hideSettings: true,
            progress: { pct: 10, text: '① داونلۆد… (١–٢ خولەک)' }
        });
        try {
            if (typeof showToast === 'function' && _uiDocked) {
                showToast(isArLang()
                    ? 'التحديث يعمل في الأسفل — تابع البيع'
                    : 'ئابدەیت ل بنێ دەڕوات — بەردەوامی فرۆتن بکە', 'info');
            }
        } catch (_eToastDl) {}
        setCardStatus('<i class="fas fa-spinner fa-spin"></i> داگرتن…', String(_latest.notes || ''));

        var applyBtn = el('settings-ota-apply-btn');
        var modalApply = el('pos-ota-modal-apply');
        if (applyBtn) applyBtn.disabled = true;
        if (modalApply) modalApply.disabled = true;

        postForm({
            action: 'download_pos_app_update',
            package_url: _latest.package_url,
            version: _latest.version || '',
            sha256: _latest.sha256 || ''
        }).then(function (dl) {
            if (!dl || dl.status !== 'success' || !dl.path) {
                throw new Error((dl && dl.message) ? dl.message : 'داونلۆد سەرنەکەوت');
            }
            var mb = dl.bytes ? (Math.round(dl.bytes / (1024 * 1024) * 10) / 10) + ' MB' : '';
            setModalUi({
                titleHtml: '<i class="fas fa-cog fa-spin"></i> دانان…',
                statusHtml: '<i class="fas fa-spinner fa-spin"></i> داونلۆد تەواو بوو — ئێستا دانان…',
                statusColor: '#38bdf8',
                versionText: 'v' + String(_latest.version || ''),
                bodyText: 'فایلەکان دادەنرێن… ' + mb + ' — کار بکە؛ ئابدەیت ل بنێ یە.',
                showApply: false,
                hideClose: false,
                hideSettings: true,
                progress: { pct: 60, text: '② دانان… (' + mb + ')' }
            });
            return postForm({
                action: 'apply_pos_app_update',
                path: dl.path
            });
        }).then(function (ap) {
            if (!ap || ap.status !== 'success') {
                throw new Error((ap && ap.message) ? ap.message : 'دانان سەرنەکەوت');
            }
            setModalUi({
                titleHtml: '<i class="fas fa-check-circle"></i> سەرکەوتوو',
                statusHtml: '<i class="fas fa-check-circle" style="color:#34d399;"></i> ئابدەیت تەواو بوو — پەڕە نوێ دەبێتەوە',
                statusColor: '#34d399',
                versionText: 'v' + String(_latest.version || ''),
                bodyText: 'فایل نووسرا: ' + (ap.written || '?') + ' · پشتگوێخراو: ' + (ap.skipped || 0),
                showApply: false,
                hideClose: true,
                hideSettings: true,
                forceModal: true,
                progress: { pct: 100, text: '③ تەواو ✓' }
            });
            setCardStatus('<i class="fas fa-check-circle" style="color:#34d399;"></i> سەرکەوتوو! نوێکردنەوەی پەڕە…', '');
            try { setDismissed(String(_latest.version || '')); } catch (_eD) {}
            try { savePendingLatest(null); hideOtaDock(); } catch (_eH) {}
            setTimeout(function () {
                try {
                    var u = new URL(window.location.href);
                    u.searchParams.set('_ota', String(Date.now()));
                    window.location.replace(u.toString());
                } catch (_eLoc) {
                    window.location.reload(true);
                }
            }, 1200);
        }).catch(function (err) {
            var msg = (err && err.message) ? err.message : String(err || 'هەڵە');
            _busy = false;
            _uiDocked = false;
            var needPinHint = /PIN|ئەدمین|ڕێگەپێدان/i.test(msg);
            setModalUi({
                titleHtml: '<i class="fas fa-times-circle"></i> هەڵە',
                statusHtml: '<i class="fas fa-times-circle" style="color:#f87171;"></i> داونلۆد / دانان سەرنەکەوت',
                statusColor: '#f87171',
                versionText: 'ئێستا: v' + currentVersion(),
                bodyText: msg + (needPinHint && isLoginScreenVisible() ? '\n\nManager Admin + PIN بنووسە، پاشان دووبارە هەوڵ بدە.' : ''),
                showApply: true,
                hideClose: false,
                clearProgress: true,
                forceModal: true
            });
            setCardStatus('<i class="fas fa-times-circle" style="color:#f87171;"></i> ' + esc(msg), '');
            setCardProgress(false, 0, '');
            if (applyBtn) applyBtn.disabled = false;
            if (modalApply) modalApply.disabled = false;
        }).finally(function () {
            // keep _busy true until reload on success
            if (el('pos-ota-modal-progress-text') && /تەواو/.test(el('pos-ota-modal-progress-text').textContent || '')) {
                return;
            }
        });
    }

    function refreshCard() {
        return checkUpdate({ interactive: false, showModalIfNew: false, alwaysModal: false });
    }

    function maybeStartPolling() {
        if (_pollTimer) return;
        function tick() {
            try {
                if (typeof currentUser === 'undefined' || !currentUser) return;
            } catch (_e) { return; }
            var last = 0;
            try { last = parseInt(localStorage.getItem(LAST_CHECK_KEY) || '0', 10) || 0; } catch (_e2) {}
            // Change to 24 hours (24 * 60 * 60 * 1000) instead of 10 minutes
            if (Date.now() - last < 24 * 60 * 60 * 1000) return;
            checkUpdate({ interactive: false, showModalIfNew: true, alwaysModal: false });
        }
        setTimeout(tick, 25000);
        _pollTimer = setInterval(tick, POLL_MS);
    }

    function isOtaNotification(msg) {
        if (!msg) return false;
        var t = String(msg.title || '') + ' ' + String(msg.message || '');
        return /نوێکردنەوە|ئابدەیت|ئابدێت|ئاپدێت|update|OTA/i.test(t);
    }

    window.posOtaCheckUpdate = function (interactive) {
        return checkUpdate({ interactive: !!interactive, showModalIfNew: !!interactive, alwaysModal: !!interactive });
    };
    window.posOtaDownloadAndApply = downloadAndApply;
    window.posOtaCloseModal = closeModal;
    window.posOtaDismissModal = dismissModal;
    window.posOtaMinimizeModal = function () {
        minimizeOtaModalToDock(_lastModalOpts);
    };
    window.posOtaGoToSettings = goToSettings;
    window.posOtaRefreshCard = refreshCard;
    window.posOtaMinimizeDock = minimizeOtaDock;
    window.posOtaOpenFromDock = function () {
        expandOtaDock();
        if (_busy) {
            // Re-open modal to watch progress; download keeps running
            _uiDocked = false;
            if (_lastModalOpts) {
                setModalUi(Object.assign({}, _lastModalOpts, { forceModal: true }));
            }
            return;
        }
        _uiDocked = false;
        if (_latest && _latest.package_url) {
            openModalForLatest(_latest);
            return;
        }
        checkUpdate({ interactive: true, showModalIfNew: true, alwaysModal: true });
    };
    window.posOtaPendingCount = function () { return _pendingCount || 0; };
    window.posOtaOpenFromNotification = function () {
        // Always open modal with clear result (even if already latest)
        checkUpdate({ interactive: true, showModalIfNew: true, alwaysModal: true });
    };
    window.posOtaIsUpdateNotification = isOtaNotification;

    window.posOtaFromLoginScreen = function () {
        if (_latest && _latest.package_url) {
            openModalForLatest(_latest);
            return;
        }
        checkUpdate({ interactive: true, showModalIfNew: true, alwaysModal: true });
    };

    function scheduleLoginScreenOtaCheck() {
        function tryCheck() {
            if (!isLoginScreenVisible()) return;
            var last = 0;
            try { last = parseInt(localStorage.getItem(LAST_CHECK_KEY) || '0', 10) || 0; } catch (_e2) {}
            // Change to 24 hours (24 * 60 * 60 * 1000) instead of 10 minutes
            if (Date.now() - last < 24 * 60 * 60 * 1000) return;

            checkUpdate({ interactive: false, showModalIfNew: false, alwaysModal: false }).then(function (data) {
                if (data && data.has_update && data.latest) {
                    paintLoginOtaButton(true, data.latest);
                    // Login: open panel once for forced, or if not yet dismissed for optional
                    if (data.latest.force_update || dismissedVersion() !== String(data.latest.version)) {
                        openModalForLatest(data.latest);
                    }
                } else {
                    paintLoginOtaButton(false, null);
                }
            });
        }
        setTimeout(tryCheck, 2500);
        setInterval(function () {
            if (isLoginScreenVisible()) tryCheck();
        }, 5 * 60 * 1000);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
            restorePendingDock();
            maybeStartPolling();
            scheduleLoginScreenOtaCheck();
        });
    } else {
        restorePendingDock();
        maybeStartPolling();
        scheduleLoginScreenOtaCheck();
    }
})();
