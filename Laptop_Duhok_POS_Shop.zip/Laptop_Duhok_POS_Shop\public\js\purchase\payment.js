// purchase/payment.js — purchase payment, save, print
        var currentPurchasePayMethod = 'cash';
        var activePurchasePayInputId = 'ppay-received';
        var isAutoUpdatingSplitCashPurchase = false;
        var isProcessingPurchasePayment = false;
        var _purchaseSaveBusyAt = 0;

        window.resetPurchaseSaveBusy = function () {
            isProcessingPurchasePayment = false;
            _purchaseSaveBusyAt = 0;
            var btn = document.getElementById('btn-save-purchase-invoice');
            if (btn) {
                btn.disabled = false;
                btn.removeAttribute('disabled');
                btn.removeAttribute('aria-busy');
                btn.classList.remove('is-busy');
                btn.style.pointerEvents = '';
            }
        };

        function getPurchaseCartSubtotal() {
            var roundM3 = typeof roundMoney === 'function' ? roundMoney : function(x) { return Math.round(Number(x)); };
            return purchaseCart.reduce(function(s, row) {
                return roundM3(s + purchaseLineTotal(row));
            }, 0);
        }

        function applyPurchaseCartGrandTotal(newTotalIqd) {
            var roundM = typeof roundMoney === 'function' ? roundMoney : function(x) { return Math.round(Number(x)); };
            var usdMode = typeof isPurchaseUsdMode === 'function' && isPurchaseUsdMode();
            newTotalIqd = Math.max(0, Number(newTotalIqd) || 0);
            newTotalIqd = usdMode ? roundM(newTotalIqd) : Math.round(newTotalIqd);
            var idxs = [];
            for (var i = 0; i < purchaseCart.length; i++) {
                var r = purchaseCart[i];
                if (!r || r.isGift || !(Number(r.qty) > 0)) continue;
                idxs.push(i);
            }
            if (!idxs.length) return false;
            var weights = idxs.map(function(i) { return Math.max(0, purchaseLineTotal(purchaseCart[i])); });
            var current = weights.reduce(function(a, b) { return a + b; }, 0);
            if (current <= 0) {
                var first = purchaseCart[idxs[0]];
                var q0 = Number(first.qty) || 1;
                if (!usdMode && Math.abs(q0 - Math.round(q0)) < 1e-9 && Math.round(q0) >= 1) {
                    var q0i = Math.round(q0);
                    var unit0 = Math.ceil((newTotalIqd + (Number(first.discount) || 0)) / q0i);
                    if (unit0 < 0) unit0 = 0;
                    first.costPerUnit = unit0;
                    first.discount = Math.max(0, (q0i * unit0) - newTotalIqd);
                } else {
                    first.costPerUnit = roundM((newTotalIqd + (Number(first.discount) || 0)) / q0);
                    if (first.costPerUnit < 0) first.costPerUnit = 0;
                    var still0 = roundM(newTotalIqd - purchaseLineTotal(first));
                    if (still0 !== 0) {
                        first.discount = roundM(Math.max(0, (Number(first.discount) || 0) - still0));
                    }
                }
                return true;
            }
            var remaining = newTotalIqd;
            idxs.forEach(function(i, k) {
                var row = purchaseCart[i];
                var share = (k === idxs.length - 1) ? remaining : roundM(newTotalIqd * (weights[k] / current));
                remaining = roundM(remaining - share);
                var q = Number(row.qty) || 0;
                var disc = Number(row.discount) || 0;
                if (!(q > 0)) return;
                var cost = (share + disc) / q;
                if (cost < 0) {
                    row.discount = roundM(Math.max(0, disc + (cost * q)));
                    row.costPerUnit = 0;
                } else {
                    row.costPerUnit = roundM(cost);
                }
            });
            function lockLastPurchaseLineToRemainder(targetIqd) {
                var last = purchaseCart[idxs[idxs.length - 1]];
                var others = 0;
                for (var oi = 0; oi < idxs.length - 1; oi++) {
                    others += purchaseLineTotal(purchaseCart[idxs[oi]]);
                }
                others = usdMode ? roundM(others) : Math.round(others);
                var want = (usdMode ? roundM(targetIqd - others) : Math.round(targetIqd - others));
                if (want < 0) want = 0;
                var qLast = Number(last.qty) || 0;
                var discLast = Number(last.discount) || 0;
                if (!(qLast > 0)) return;
                var qi = Math.round(qLast);
                var qtyIsInt = !usdMode && Math.abs(qLast - qi) < 1e-9 && qi >= 1;
                if (qtyIsInt) {
                    var unit = Math.ceil(want / qi);
                    if (unit < 0) unit = 0;
                    last.costPerUnit = unit;
                    last.discount = Math.max(0, (qi * unit) - want);
                } else {
                    last.costPerUnit = roundM((want + discLast) / qLast);
                    var still = roundM(want - purchaseLineTotal(last));
                    if (still !== 0) last.discount = roundM(Math.max(0, discLast - still));
                }
            }
            lockLastPurchaseLineToRemainder(newTotalIqd);
            return true;
        }

        function openPurchaseCartTotalEdit() {
            if (!purchaseCart.length) return;
            var sub = getPurchaseCartSubtotal();
            if (typeof openBillTotalEditModal === 'function') {
                openBillTotalEditModal(sub, { source: 'purchase' });
            }
        }

        function getPurchaseGrandTotalSnapStepIqd() {
            if (typeof isPurchaseUsdMode === 'function' && isPurchaseUsdMode()) {
                return typeof purchaseDisplayToIqd === 'function' ? purchaseDisplayToIqd(0.01) : 1;
            }
            try {
                if (typeof window.isPremiumSettingsFeatureEnabled === 'function'
                    && window.isPremiumSettingsFeatureEnabled('set-enable-money-rounding')) {
                    return 250;
                }
            } catch (eRound) {}
            return 1000;
        }
        function snapPurchaseGrandTotalIqd(current, dir) {
            var step = getPurchaseGrandTotalSnapStepIqd();
            if (!(step > 0)) step = 1000;
            current = Math.round(Number(current) || 0);
            if (dir > 0) return Math.ceil((current + 1) / step) * step;
            var next = Math.floor((current - 1) / step) * step;
            return next < 0 ? 0 : next;
        }
        function nudgePurchaseCartGrandTotal(dir) {
            if (!purchaseCart.length) return;
            var next = snapPurchaseGrandTotalIqd(getPurchaseCartSubtotal(), dir);
            applyPurchaseCartGrandTotal(next);
            schedulePurchaseCartRender();
        }

        function confirmPurchaseCartTotalEdit() {
            var inp = document.getElementById('bill-total-edit-input');
            if (!inp) return;
            var raw = String(inp.value || '').replace(/,/g, '').trim();
            var newDisplay = raw === '' ? NaN : parseFloat(raw);
            if (isNaN(newDisplay) || newDisplay < 0) {
                var inv = (typeof t === 'function') ? t('bill_total_edit_invalid') : 'ژمارە خەلەتە';
                if (typeof showToast === 'function') showToast(inv, 'error');
                else alert(inv);
                return;
            }
            if (typeof isPurchaseUsdMode === 'function' && !isPurchaseUsdMode()) newDisplay = Math.round(newDisplay);
            var newIqd = (typeof purchaseDisplayToIqd === 'function') ? purchaseDisplayToIqd(newDisplay) : newDisplay;
            applyPurchaseCartGrandTotal(newIqd);
            if (typeof schedulePurchaseCartRender === 'function') schedulePurchaseCartRender();
            else renderPurchaseCart();
            if (typeof closeBillTotalEditModal === 'function') closeBillTotalEditModal();
            var ok = (typeof t === 'function') ? t('purchase_total_edit_ok') : 'کۆم هاتە گوهۆڕین';
            if (typeof showToast === 'function') showToast(ok, 'success');
        }
        window.openPurchaseCartTotalEdit = openPurchaseCartTotalEdit;
        window.nudgePurchaseCartGrandTotal = nudgePurchaseCartGrandTotal;
        window.confirmPurchaseCartTotalEdit = confirmPurchaseCartTotalEdit;

        function applyPurchaseModalDiscountToRows(rows, discPct) {
            var pct = parseFloat(discPct) || 0;
            if (pct <= 0 || pct > 100) return rows.map(function(r) { return Object.assign({}, r); });
            var roundM = typeof roundMoney === 'function' ? roundMoney : function(x) { return Math.round(Number(x)); };
            return rows.map(function(row) {
                if (row.isGift) return Object.assign({}, row);
                var line = Math.max(0, (row.qty || 0) * (row.costPerUnit || 0) - (row.discount || 0));
                var extraDisc = roundM(line * (pct / 100));
                var nr = Object.assign({}, row);
                nr.discount = roundM((nr.discount || 0) + extraDisc);
                return nr;
            });
        }

        function setActivePurchasePayInput(id) {
            activePurchasePayInputId = id;
        }

        function openPurchasePaymentModal() {
            if (isTxnMobileUi()) {
                if (typeof window.collapseTxnSheet === 'function') window.collapseTxnSheet('purchase');
            }
            var sel = document.getElementById('purchase-supplier-select');
            var supplierId = sel && sel.value ? parseInt(sel.value, 10) : null;
            var comp = supplierId ? (db.companies || []).find(function(c) { return c.id === supplierId; }) : null;
            if (!comp) {
                if (typeof window.highlightTxnMetaFields === 'function') {
                    window.highlightTxnMetaFields('purchase', ['purchase-supplier-select']);
                }
                if (typeof showToast === 'function') showToast('کۆمپانیایەکێ هەلبژێرە', 'error');
                else alert('کۆمپانیایەکێ هەلبژێرە');
                return;
            }
            if (typeof window.clearTxnMetaErrors === 'function') window.clearTxnMetaErrors('purchase');
            var validRows = purchaseCart.filter(function(row) { return (row.qty || 0) > 0; });
            if (validRows.length === 0) { alert('سەبەتا کڕینێ یا بەتاڵە یان ژمارە ٠'); return; }
            if (!requirePurchaseSupplierInvoiceNumber()) return;
            if (!requirePurchaseBatchNumber()) return;

            if (!isAutoPaymentModalEnabled()) {
                if (typeof window.purchaseCheckoutWithSupplierPaid === 'function' && window.purchaseCheckoutWithSupplierPaid()) {
                    return;
                }
                executeSavePurchaseInvoice(comp, validRows.map(function(r) { return Object.assign({}, r); }), 'cash', 0, null);
                return;
            }

            var subTotal = getPurchaseCartSubtotal();
            var totalEl = document.getElementById('ppay-modal-total');
            if (totalEl) totalEl.dataset.subtotal = subTotal;
            var pd = document.getElementById('ppay-discount-pct');
            if (pd) pd.value = '';
            document.getElementById('ppay-received').value = '';
            document.getElementById('ppay-usd-input').value = '';
            var ppDebt = document.getElementById('ppay-debt-amount');
            var ppBank = document.getElementById('ppay-bank-card-amount');
            if (ppDebt) {
                _setPayInputFormatted('ppay-debt-amount', 0, getPurchasePaymentInputKind());
                ppDebt.removeAttribute('maxlength');
                ppDebt.removeAttribute('max');
                ppDebt.setAttribute('oninput', "setActivePurchasePayInput(this.id); onPPayDebtAmountInput(this);");
            }
            if (ppBank) {
                _setPayInputFormatted('ppay-bank-card-amount', 0, getPurchasePaymentInputKind());
                ppBank.removeAttribute('maxlength');
                ppBank.removeAttribute('max');
                ppBank.setAttribute('oninput', "setActivePurchasePayInput(this.id); onPPayBankCardAmountInput(this);");
            }
            document.getElementById('ppay-selected-debt-id').value = '';
            document.getElementById('ppay-selected-debt-type').value = '';

            var discPct = 0;
            var discount = 0;
            var totalAfterDiscount = subTotal - discount;

            var totalElForFinal = document.getElementById('ppay-modal-total');
            if (totalElForFinal) totalElForFinal.dataset.final = String(totalAfterDiscount);

            var sysCurrency = (typeof getActiveCurrency === 'function')
                ? getActiveCurrency()
                : ((db && db.settings && String(db.settings.currencyMode || 'IQD').toUpperCase() === 'USD') ? 'USD' : 'IQD');
            document.getElementById('ppay-received').value = '';
            var ppUsdClear = document.getElementById('ppay-usd-input');
            if (ppUsdClear) ppUsdClear.value = '';
            var ppDebtClear = document.getElementById('ppay-debt-amount');
            if (ppDebtClear) ppDebtClear.value = '';
            var ppBankClear = document.getElementById('ppay-bank-card-amount');
            if (ppBankClear) ppBankClear.value = '';
            activePurchasePayInputId = (sysCurrency === 'USD') ? 'ppay-usd-input' : 'ppay-received';

            var ratePerOne = typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0;
            var rateDisp = document.getElementById('ppay-usd-rate-display');
            if (rateDisp) {
                var isUsdMode2 = (typeof getActiveCurrency === 'function') ? (getActiveCurrency() === 'USD') : false;
                if (isUsdMode2) rateDisp.innerText = '';
                else {
                    var _rn2 = Math.round(ratePerOne).toLocaleString();
                    rateDisp.innerText = (typeof t === 'function') ? String(t('payment_fx_line')).replace(/\{n\}/g, _rn2) : ('1$ = ' + _rn2 + ' د.ع');
                }
            }
            try {
                var _ppayGlass = document.querySelector('#purchase-payment-modal .pay-modal-glass');
                if (_ppayGlass && typeof applyI18nSubtree === 'function') applyI18nSubtree(_ppayGlass);
            } catch (ePPayI18n) {}
            if (typeof applyCurrencyModeUiText === 'function') applyCurrencyModeUiText();
            if (comp && comp.id) {
                document.getElementById('ppay-selected-debt-id').value = String(comp.id);
                document.getElementById('ppay-selected-debt-type').value = 'company';
            }
            if (typeof renderPurchasePayDebtSearch === 'function') renderPurchasePayDebtSearch('');

            /* Pre-fill from «پارێ دای» on purchase header (cash portion; remainder → debt in modal) */
            var headerPaidEl = document.getElementById('purchase-supplier-paid');
            var headerPaidIqd = headerPaidEl ? parsePurchaseSupplierPaidToIqd(headerPaidEl.value) : 0;
            if (headerPaidIqd > 0) {
                var tolHdr = 1;
                var debtRemain = Math.max(0, totalAfterDiscount - headerPaidIqd);
                var paidDisp = purchasePaymentIqdToDisplay(headerPaidIqd);
                var kindHdr = getPurchasePaymentInputKind();
                if (sysCurrency === 'USD') {
                    _setPayInputFormatted('ppay-usd-input', paidDisp, 'usd');
                    _setPayInputFormatted('ppay-received', paidDisp, 'usd');
                } else {
                    _setPayInputFormatted('ppay-received', Math.round(headerPaidIqd), 'iqd');
                    if (typeof updateUSDFromIQD_Purchase === 'function') {
                        updateUSDFromIQD_Purchase(document.getElementById('ppay-received').value);
                    }
                }
                if (debtRemain > tolHdr) {
                    togglePurchasePayMethod('debt');
                    _setPayInputFormatted('ppay-debt-amount', purchasePaymentIqdToDisplay(debtRemain), kindHdr);
                } else {
                    togglePurchasePayMethod('cash');
                }
                if (typeof calcPurchasePayModalTotals === 'function') calcPurchasePayModalTotals();
            } else if (comp) {
                togglePurchasePayMethod('debt');
            } else {
                togglePurchasePayMethod('cash');
            }
            if (typeof calcPurchasePayModalTotals === 'function') calcPurchasePayModalTotals();

            document.getElementById('purchase-payment-modal').style.display = 'flex';
            setTimeout(function() {
                if (sysCurrency === 'USD') {
                    var u = document.getElementById('ppay-usd-input');
                    if (u) { u.focus(); if (u.select) u.select(); }
                } else {
                    var p = document.getElementById('ppay-received');
                    if (p) { p.focus(); if (p.select) p.select(); }
                }
            }, 100);
        }

        function closePurchasePaymentModal() {
            var m = document.getElementById('purchase-payment-modal');
            if (m) m.style.display = 'none';
        }

        function convertUSDPurchasePayment(usdVal) {
            var usd = typeof parseAmountInput === 'function' ? parseAmountInput(String(usdVal)) : parseFloat(String(usdVal).replace(/,/g, ''));
            if (!isNaN(usd) && usd >= 0) {
            var iqd = (typeof usdAmountToStoredIqd === 'function')
                ? usdAmountToStoredIqd(usd, (typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0))
                : (usd * (typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0));
                if (isPurchasePaymentUsdMode()) _setPayInputFormatted('ppay-received', usd, 'usd');
                else _setPayInputFormatted('ppay-received', Math.round(iqd), 'iqd');
            } else {
                document.getElementById('ppay-received').value = '';
            }
            calcPurchasePayModalTotals();
        }

        function updateUSDFromIQD_Purchase(iqdVal) {
            var iqd = typeof parseAmountInput === 'function' ? parseAmountInput(String(iqdVal)) : parseFloat(String(iqdVal).replace(/,/g, ''));
            var rate = typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0;
            if (!isNaN(iqd) && iqd >= 0) {
                if (rate > 0) _setPayInputFormatted('ppay-usd-input', iqd / rate, 'usd');
                else _setPayInputFormatted('ppay-usd-input', 0, 'usd');
            } else {
                document.getElementById('ppay-usd-input').value = '';
            }
        }

        function handlePurchasePayNumpad(key) {
            var input = document.getElementById(activePurchasePayInputId);
            if (!input) return;
            var kind = activePurchasePayInputId === 'ppay-usd-input'
                ? 'usd'
                : (activePurchasePayInputId === 'ppay-received' ? 'iqd' : getPurchasePaymentInputKind());
            var raw = (input.value || '').replace(/,/g, '');
            if (key === 'C') {
                raw = '';
            } else if (key === '.') {
                if (kind === 'usd' && raw.indexOf('.') === -1) raw += '.';
            } else {
                raw += key;
            }
            input.value = raw;
            if (typeof formatPaymentInputElement === 'function') formatPaymentInputElement(input, kind);
            if (activePurchasePayInputId === 'ppay-usd-input') {
                convertUSDPurchasePayment(input.value);
            } else {
                calcPurchasePayModalTotals();
                if (activePurchasePayInputId === 'ppay-received' && typeof updateUSDFromIQD_Purchase === 'function') updateUSDFromIQD_Purchase(input.value);
            }
        }

        function togglePurchasePayMethod(method) {
            var m = String(method || '').toLowerCase();
            if (m === 'bankcard' || m === 'bank' || m === 'card') m = 'fib';
            currentPurchasePayMethod = m;
            var bc = document.getElementById('ppm-btn-cash');
            var bd = document.getElementById('ppm-btn-debt');
            var bb = document.getElementById('ppm-btn-bankcard');
            if (bc) bc.classList.toggle('active', m === 'cash');
            if (bd) bd.classList.toggle('active', m === 'debt');
            if (bb) bb.classList.toggle('active', m === 'fib');

            var debtSec = document.getElementById('ppay-debt-section');
            var bankSec = document.getElementById('ppay-bank-section');
            if (m === 'debt') {
                if (debtSec) debtSec.style.display = 'block';
                if (bankSec) bankSec.style.display = 'none';
                var totalEl = document.getElementById('ppay-modal-total');
                var total = totalEl ? (parseFloat(totalEl.dataset.final) || 0) : 0;
                var da = document.getElementById('ppay-debt-amount');
                if (da) _setPayInputFormatted('ppay-debt-amount', purchasePaymentIqdToDisplay(total), getPurchasePaymentInputKind());
                var pr = document.getElementById('ppay-received');
                if (pr) { pr.value = ''; pr.focus(); }
                var pu = document.getElementById('ppay-usd-input');
                if (pu) pu.value = '';
                var ba0 = document.getElementById('ppay-bank-card-amount');
                if (ba0) ba0.value = '';
                if (typeof renderPurchasePayDebtSearch === 'function') renderPurchasePayDebtSearch((document.getElementById('ppay-debt-search') && document.getElementById('ppay-debt-search').value) || '');
                if (typeof setActivePurchasePayInput === 'function') setActivePurchasePayInput('ppay-received');
            } else if (m === 'fib') {
                if (debtSec) debtSec.style.display = 'none';
                if (bankSec) bankSec.style.display = 'block';
                var totalElF = document.getElementById('ppay-modal-total');
                var totalF = totalElF ? (parseFloat(totalElF.dataset.final) || 0) : 0;
                var pr = document.getElementById('ppay-received');
                if (pr) pr.value = '';
                var pu = document.getElementById('ppay-usd-input');
                if (pu) pu.value = '';
                var daF = document.getElementById('ppay-debt-amount');
                if (daF) daF.value = '';
                var elb = document.getElementById('ppay-bank-card-amount');
                if (elb) {
                    _setPayInputFormatted('ppay-bank-card-amount', purchasePaymentIqdToDisplay(totalF), getPurchasePaymentInputKind());
                    elb.focus();
                    if (elb.select) elb.select();
                }
                if (typeof setActivePurchasePayInput === 'function') setActivePurchasePayInput('ppay-bank-card-amount');
            } else {
                if (debtSec) debtSec.style.display = 'none';
                if (bankSec) bankSec.style.display = 'none';
                var totalEl = document.getElementById('ppay-modal-total');
                var total = totalEl ? (parseFloat(totalEl.dataset.final) || 0) : 0;
                var pr = document.getElementById('ppay-received');
                if (pr) { _setPayInputFormatted('ppay-received', purchasePaymentIqdToDisplay(total), getPurchasePaymentInputKind()); pr.focus(); }
                if (typeof updateUSDFromIQD_Purchase === 'function') updateUSDFromIQD_Purchase(total);
                var da = document.getElementById('ppay-debt-amount');
                if (da) da.value = '';
                var ba = document.getElementById('ppay-bank-card-amount');
                if (ba) ba.value = '';
            }
            calcPurchasePayModalTotals();
        }
        window.togglePurchasePayMethod = togglePurchasePayMethod;

        function renderPurchasePayDebtSearch(q) {
            var container = document.getElementById('ppay-debt-list');
            if (!container || !db || !db.companies) return;
            var lowerQ = (q || '').toLowerCase();
            var filtered = db.companies.filter(function(c) {
                return c && c.name && String(c.name).toLowerCase().includes(lowerQ);
            }).slice(0, 20);
            container.innerHTML = filtered.map(function(p) {
                return '<div class="pay-debt-item" data-supplier-id="' + p.id + '" onclick="selectPurchasePayDebtTarget(' + p.id + ', \'company\', this)">' +
                    '<b>' + escapeHtml(p.name) + '</b><br><small>' + escapeHtml((typeof t === 'function') ? t('payment_debt_supplier_tag') : 'دابینکەر') + '</small></div>';
            }).join('');
            var sel = document.getElementById('purchase-supplier-select');
            var sid = sel && sel.value ? String(sel.value) : '';
            if (sid) {
                var match = container.querySelector('.pay-debt-item[data-supplier-id="' + sid + '"]');
                if (match) selectPurchasePayDebtTarget(parseInt(sid, 10), 'company', match);
            }
        }

        function selectPurchasePayDebtTarget(id, type, el) {
            document.querySelectorAll('#ppay-debt-list .pay-debt-item').forEach(function(e) { e.classList.remove('selected'); });
            if (el) el.classList.add('selected');
            document.getElementById('ppay-selected-debt-id').value = id;
            document.getElementById('ppay-selected-debt-type').value = type;
        }

        function getPurchasePayCashRaw() {
            if (isPurchasePaymentUsdMode()) {
                var usdEl = document.getElementById('ppay-usd-input');
                if (usdEl && String(usdEl.value || '').trim() !== '') return usdEl.value;
            }
            var recEl = document.getElementById('ppay-received');
            return recEl ? recEl.value : '';
        }

        function calcPurchasePayModalTotals() {
            var totalEl = document.getElementById('ppay-modal-total');
            if (!totalEl) return;
            var rm = typeof roundMoney === 'function' ? roundMoney : function(x) { return Math.round(Number(x) || 0); };
            var subTotal = rm(parseFloat(totalEl.dataset.subtotal) || 0);
            var discEl = document.getElementById('ppay-discount-pct');
            var discPct = discEl ? (parseFloat(discEl.value) || 0) : 0;
            var discount = 0;
            if (discPct > 0 && discPct <= 100) discount = rm(subTotal * (discPct / 100));
            var total = rm(subTotal - discount);
            totalEl.innerText = formatCurrency(total) + ' ' + getCurrencySymbol();
            totalEl.dataset.final = String(total);

            var cashRaw = getPurchasePayCashRaw();
            var cash = purchasePaymentDisplayToIqd(cashRaw);
            var debtRaw = (document.getElementById('ppay-debt-amount') && document.getElementById('ppay-debt-amount').value || '');
            var debt = purchasePaymentDisplayToIqd(debtRaw);
            var bankRaw = (document.getElementById('ppay-bank-card-amount') && document.getElementById('ppay-bank-card-amount').value || '');
            var bank = purchasePaymentDisplayToIqd(bankRaw);
            var isUsdDebtFlow = isPurchasePaymentUsdMode() && currentPurchasePayMethod === 'debt';

            // Auto-fill cash as "remaining" when editing debt/bank, so the split always covers the total.
            if (!isAutoUpdatingSplitCashPurchase && (activePurchasePayInputId === 'ppay-debt-amount' || activePurchasePayInputId === 'ppay-bank-card-amount')) {
                var autoCash = Math.max(0, total - (debt + bank));
                if (String(cash) !== String(autoCash)) {
                    isAutoUpdatingSplitCashPurchase = true;
                    var cashEl = document.getElementById('ppay-received');
                    if (cashEl) _setPayInputFormatted('ppay-received', purchasePaymentIqdToDisplay(autoCash), getPurchasePaymentInputKind());
                    if (typeof updateUSDFromIQD_Purchase === 'function') updateUSDFromIQD_Purchase(String(autoCash));
                    cash = autoCash;
                    isAutoUpdatingSplitCashPurchase = false;
                }
            } else if (!isAutoUpdatingSplitCashPurchase && activePurchasePayInputId === 'ppay-received' && currentPurchasePayMethod === 'debt') {
                var autoDebt = Math.max(0, total - cash);
                if (String(debt) !== String(autoDebt)) {
                    isAutoUpdatingSplitCashPurchase = true;
                    var debtEl = document.getElementById('ppay-debt-amount');
                    if (debtEl) _setPayInputFormatted('ppay-debt-amount', purchasePaymentIqdToDisplay(autoDebt), getPurchasePaymentInputKind());
                    debt = autoDebt;
                    isAutoUpdatingSplitCashPurchase = false;
                }
            }

            var allocated = cash + debt + bank;
            var remaining = total - allocated;
            var change = allocated - total;
            if (isUsdDebtFlow) {
                var paidNow = cash + bank;
                debt = Math.max(0, total - paidNow);
                var debtElFlow = document.getElementById('ppay-debt-amount');
                if (debtElFlow) _setPayInputFormatted('ppay-debt-amount', purchasePaymentIqdToDisplay(debt), getPurchasePaymentInputKind());
                remaining = 0;
                change = Math.max(0, paidNow - total);
            }
            var changeEl = document.getElementById('ppay-change');
            var hintEl = document.getElementById('ppay-change-hint');
            if (remaining > 0) {
                changeEl.innerText = formatCurrency(remaining) + ' ' + getCurrencySymbol();
                changeEl.style.color = 'var(--danger)';
                if (hintEl) {
                    var _tp = (typeof t === 'function');
                    hintEl.textContent = _tp ? t('payment_purchase_hint_need_more') : 'باقی بۆ تەواوکردن';
                    hintEl.style.color = 'var(--danger)';
                }
            } else {
                changeEl.innerText = formatCurrency(Math.max(0, change)) + ' ' + getCurrencySymbol();
                changeEl.style.color = 'var(--success)';
                if (hintEl) {
                    var _tp2 = (typeof t === 'function');
                    if (change > 0) {
                        hintEl.textContent = _tp2 ? t('payment_purchase_hint_change') : 'پارەی گەڕاوە';
                        hintEl.style.color = 'var(--success)';
                    } else if (debt > 0) {
                        var _debtLab = _tp2 ? t('payment_purchase_hint_debt_prefix') : 'کۆژمی قەرز:';
                        hintEl.innerHTML = '<div style="color:var(--danger); font-size:1.2rem; font-weight:bold; margin-top:8px; padding-top:8px; border-top:1px dashed var(--border);">' + escapeHtml(_debtLab) + ' ' + formatCurrency(debt) + ' ' + getCurrencySymbol() + '</div>';
                    } else {
                        hintEl.textContent = _tp2 ? t('payment_purchase_hint_done') : 'تەواو';
                        hintEl.style.color = 'var(--success)';
                    }
                }
            }
        }

        function confirmPurchaseAdvancedPayment() {
            var totalEl = document.getElementById('ppay-modal-total');
            var total = parseFloat(totalEl && totalEl.dataset.final) || 0;
            var cash = purchasePaymentDisplayToIqd(getPurchasePayCashRaw());
            var debt = purchasePaymentDisplayToIqd((document.getElementById('ppay-debt-amount') && document.getElementById('ppay-debt-amount').value) || '');
            var bank = purchasePaymentDisplayToIqd((document.getElementById('ppay-bank-card-amount') && document.getElementById('ppay-bank-card-amount').value) || '');
            var isUsdMode = isPurchasePaymentUsdMode();
            if (isPurchasePaymentUsdMode() && currentPurchasePayMethod === 'debt') {
                debt = Math.max(0, total - (cash + bank));
                var debtElSync = document.getElementById('ppay-debt-amount');
                if (debtElSync) _setPayInputFormatted('ppay-debt-amount', purchasePaymentIqdToDisplay(debt), getPurchasePaymentInputKind());
            }
            var allocated = cash + debt + bank;
            var remaining = total - allocated;
            var discPct = document.getElementById('ppay-discount-pct') && document.getElementById('ppay-discount-pct').value;

            var sel = document.getElementById('purchase-supplier-select');
            var supplierId = sel && sel.value ? parseInt(sel.value, 10) : null;
            var comp = supplierId ? (db.companies || []).find(function(c) { return c.id === supplierId; }) : null;
            if (!comp) {
                if (typeof showToast === 'function') showToast('کۆمپانیایەکێ هەلبژێرە', 'error'); 
                else if (typeof window.posAlert === 'function') window.posAlert({ message: 'کۆمپانیایەکێ هەلبژێرە', tone: 'danger' });
                else alert('کۆمپانیایەکێ هەلبژێرە');
                return;
            }

            var validRows = purchaseCart.filter(function(row) { return (row.qty || 0) > 0; });
            if (validRows.length === 0) {
                if (typeof showToast === 'function') showToast('سەبەتا کڕینێ یا بەتاڵە', 'error'); 
                else if (typeof window.posAlert === 'function') window.posAlert({ message: 'سەبەتا کڕینێ یا بەتاڵە', tone: 'danger' });
                else alert('سەبەتا کڕینێ یا بەتاڵە');
                return;
            }

            if (allocated <= 0) {
                if (typeof showToast === 'function') showToast('هیڤییە بەری هەر تشتەکی بڕێ پارەی دیار بکە!', 'error'); 
                else if (typeof window.posAlert === 'function') window.posAlert({ message: 'هیڤییە بەری هەر تشتەکی بڕێ پارەی دیار بکە!', tone: 'danger' });
                else alert('هیڤییە بەری هەر تشتەکی بڕێ پارەی دیار بکە!');
                return;
            }
            if (isUsdMode) {
                var paidNowConfirm = cash + bank;
                debt = Math.max(0, total - paidNowConfirm);
                allocated = paidNowConfirm + debt;
                remaining = 0;
                var debtElConfirm = document.getElementById('ppay-debt-amount');
                if (debtElConfirm) _setPayInputFormatted('ppay-debt-amount', purchasePaymentIqdToDisplay(debt), getPurchasePaymentInputKind());
            }
            // USD purchase mode: any unpaid remainder must become supplier debt automatically.
            if (isUsdMode && remaining > 0) {
                debt = (typeof roundMoney === 'function' ? roundMoney : function(x){ return Number(x) || 0; })(debt + remaining);
                allocated = cash + debt + bank;
                remaining = total - allocated;
                var debtElAuto = document.getElementById('ppay-debt-amount');
                if (debtElAuto) _setPayInputFormatted('ppay-debt-amount', purchasePaymentIqdToDisplay(debt), getPurchasePaymentInputKind());
            }
            if (remaining > 0) {
                if (typeof showToast === 'function') showToast('باقی یێ مای: ' + formatCurrency(remaining) + ' ' + getCurrencySymbol(), 'error');
                else if (typeof window.posAlert === 'function') window.posAlert({ message: 'باقی یێ مای: ' + formatCurrency(remaining) + ' ' + getCurrencySymbol(), tone: 'warning' });
                else alert('باقی یێ مای: ' + formatCurrency(remaining) + ' ' + getCurrencySymbol());
                return;
            }

            if (debt > 0) {
                var tid = document.getElementById('ppay-selected-debt-id').value;
                if (!tid) {
                    if (typeof showToast === 'function') showToast('هیڤییە دابینکەرەکی هەلبژێرە بۆ قەرزی!', 'error'); 
                    else if (typeof window.posAlert === 'function') window.posAlert({ message: 'هیڤییە دابینکەرەکی هەلبژێرە بۆ قەرزی!', tone: 'danger' });
                    else alert('هیڤییە دابینکەرەکی هەلبژێرە بۆ قەرزی!');
                    return;
                }
                if (parseInt(tid, 10) !== supplierId) {
                    if (typeof showToast === 'function') showToast('دابینکەرێ قەرزدار دڤێت هەمان دابینکەرێ سەرەکی بیت!', 'error'); 
                    else if (typeof window.posAlert === 'function') window.posAlert({ message: 'دابینکەرێ قەرزدار دڤێت هەمان دابینکەرێ سەرەکی بیت!', tone: 'danger' });
                    else alert('دابینکەرێ قەرزدار دڤێت هەمان دابینکەرێ سەرەکی بیت!');
                    return;
                }
            }

            var rowsToSave = applyPurchaseModalDiscountToRows(validRows, discPct);

            var type = 'cash';
            var cashPaidForSplit = 0;
            var splitAlloc = null;
            var tol = 1;
            if (debt <= 0 && bank >= total - tol && cash <= tol) {
                type = 'fib';
                splitAlloc = { cash: 0, bank: bank, debt: 0 };
            } else if (debt <= 0 && (cash + bank) >= total - tol && bank <= tol) {
                type = 'cash';
            } else if ((cash + bank) <= 0 && debt >= total - tol) {
                type = 'credit';
            } else {
                type = 'split';
                cashPaidForSplit = cash + bank;
                splitAlloc = { cash: cash, bank: bank, debt: debt };
            }

            var hid = document.getElementById('purchase-payment-type-value');
            if (hid) hid.value = type;

            closePurchasePaymentModal();
            executeSavePurchaseInvoice(comp, rowsToSave, type, cashPaidForSplit, splitAlloc);
        }
        window.confirmPurchaseAdvancedPayment = confirmPurchaseAdvancedPayment;

        /** Supplier selected: پارێ دای = cash, remainder = debt. Returns true if checkout started, false if no supplier. */
        window.purchaseCheckoutWithSupplierPaid = function() {
            var sel = document.getElementById('purchase-supplier-select');
            var supplierId = sel && sel.value ? parseInt(sel.value, 10) : null;
            var comp = supplierId ? (db.companies || []).find(function(c) { return c.id === supplierId; }) : null;
            if (!comp) return false;

            var validRows = purchaseCart.filter(function(row) { return (row.qty || 0) > 0; });
            if (validRows.length === 0) {
                if (typeof showToast === 'function') showToast("⚠️ سەبەتا کڕینێ یا بەتاڵە!", "error");
                return false;
            }

            var paidInput = document.getElementById('purchase-supplier-paid');
            var paidAmount = paidInput ? parsePurchaseSupplierPaidToIqd(paidInput.value) : 0;
            var subTotal = getPurchaseCartSubtotal();
            var tol = 1;

            if (paidAmount >= subTotal - tol) {
                executeSavePurchaseInvoice(comp, validRows, 'cash', 0, null);
            } else if (paidAmount > 0) {
                executeSavePurchaseInvoice(comp, validRows, 'split', paidAmount, { cash: paidAmount, bank: 0, debt: subTotal - paidAmount });
            } else {
                executeSavePurchaseInvoice(comp, validRows, 'credit', 0, null);
            }
            return true;
        };

        window.purchaseOnCredit = function() {
            if (typeof window.savePurchaseInvoice === 'function') window.savePurchaseInvoice();
        };

        function executeSavePurchaseInvoice(comp, validRows, type, cashPaidForSplit, splitAlloc) {
            if (isProcessingPurchasePayment) {
                if (_purchaseSaveBusyAt && (Date.now() - _purchaseSaveBusyAt) < 8000) {
                    return;
                }
                isProcessingPurchasePayment = false;
            }
            if (!requirePurchaseSupplierInvoiceNumber()) return;
            if (!requirePurchaseBatchNumber()) return;

            var editingMeta = (window._posEditingPurchase && window._posEditingPurchase.txnId) ? window._posEditingPurchase : null;
            if (editingMeta) {
                isProcessingPurchasePayment = true;
                _purchaseSaveBusyAt = Date.now();
                try {
                var rowsToSend = validRows.map(function(r) {
                    var copy = Object.assign({}, r);
                    delete copy.productRef;
                    if (typeof shouldShowPurchaseWarehouseUi === 'function' && shouldShowPurchaseWarehouseUi()) {
                        copy.warehouseId = getPurchaseRowWarehouseId(copy);
                    }
                    return copy;
                });
                normalizePurchaseExpiryRows(rowsToSend);
                var btn = document.getElementById('btn-save-purchase-invoice');
                var user = (typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : 'System';
                var invNumEl = document.getElementById('purchase-supplier-invoice-number');
                var batchEl = document.getElementById('purchase-batch-number');
                var supplierInvoiceNumber = (invNumEl && invNumEl.value) ? String(invNumEl.value).trim() : '';
                var batchNumber = (batchEl && batchEl.value && (typeof canUsePurchaseBatch !== 'function' || canUsePurchaseBatch())) ? String(batchEl.value).trim() : '';
                if (btn) {
                    btn.disabled = false;
                    btn.removeAttribute('disabled');
                    btn.setAttribute('aria-busy', 'true');
                    btn.classList.add('is-busy');
                    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> …';
                }
                var formData = new FormData();
                formData.append('action', 'replace_purchase_cart');
                formData.append('transaction_id', String(editingMeta.txnId));
                formData.append('items', JSON.stringify(rowsToSend));
                formData.append('user', user);
                formData.append('supplier_invoice_number', supplierInvoiceNumber);
                formData.append('batch_number', batchNumber);
                var purCurEl = document.getElementById('purchase-currency');
                if (purCurEl && (purCurEl.value === 'USD' || purCurEl.value === 'IQD')) {
                    formData.append('currency', purCurEl.value);
                }
                if (typeof getUsdRatePerOne === 'function') {
                    formData.append('exchange_rate', String(getUsdRatePerOne()));
                }
                var purWh = document.getElementById('purchase-warehouse-select');
                if (purWh && purWh.value) formData.append('warehouse_id', purWh.value);
                else if (typeof getDefaultWarehouseId === 'function' && getDefaultWarehouseId()) {
                    formData.append('warehouse_id', String(getDefaultWarehouseId()));
                }
                var apiUrl = (typeof window.posRouterUrl === 'function')
                    ? window.posRouterUrl('action=replace_purchase_cart')
                    : '?action=replace_purchase_cart';
                var saveWatch = setTimeout(function () {
                    if (!isProcessingPurchasePayment) return;
                    if (typeof window.resetPurchaseSaveBusy === 'function') window.resetPurchaseSaveBusy();
                    else {
                        isProcessingPurchasePayment = false;
                        if (btn) btn.disabled = false;
                    }
                    if (typeof updatePurchaseEditModeUI === 'function') updatePurchaseEditModeUI();
                    if (typeof showToast === 'function') showToast('پاراستن درەنگ بوو — دووبارە هەول بدە', 'error');
                }, 20000);
                fetch(apiUrl, { method: 'POST', body: formData, credentials: 'same-origin' })
                    .then(function(r) { return r.json().catch(function() { return {}; }); })
                    .then(function(data) {
                        clearTimeout(saveWatch);
                        isProcessingPurchasePayment = false;
                        _purchaseSaveBusyAt = 0;
                        if (!data || data.status !== 'success') {
                            if (typeof window.resetPurchaseSaveBusy === 'function') window.resetPurchaseSaveBusy();
                            if (btn) {
                                btn.disabled = false;
                                if (typeof updatePurchaseEditModeUI === 'function') updatePurchaseEditModeUI();
                            }
                            var errMsg = (data && data.message) ? String(data.message) : 'تەعدیل سەرنەکەوت';
                            if (typeof showToast === 'function') showToast(errMsg, 'error');
                            else alert(errMsg);
                            return;
                        }
                        var txnKeep = String(editingMeta.txnId);
                        // Refresh local supplies for this txn from cart
                        if (window.db && Array.isArray(window.db.supplies)) {
                            window.db.supplies = window.db.supplies.filter(function(s) {
                                return String(s.transaction_id || '') !== txnKeep;
                            });
                            var nowIso = editingMeta.date || new Date().toISOString();
                            var roundM = typeof roundMoney === 'function' ? roundMoney : function(x) { return Math.round(Number(x)); };
                            rowsToSend.forEach(function(row) {
                                var p = (db.products || []).find(function(x) { return String(x.id) === String(row.productId); });
                                var factors = (typeof getProductUnitFactors === 'function') ? getProductUnitFactors(p) : { piecesPerPack: 1, piecesPerCarton: 1 };
                                var mult = 1;
                                if (row.unit === 'carton') mult = factors.piecesPerCarton || 1;
                                else if (row.unit === 'pack') mult = factors.piecesPerPack || 1;
                                var pieces = (row.qty || 0) * mult;
                                var lineTotal = purchaseLineTotal(row);
                                window.db.supplies.push({
                                    id: Date.now() + Math.floor(Math.random() * 1000),
                                    company: comp.name,
                                    prodId: row.productId,
                                    itemName: row.productName,
                                    qtyAdded: pieces,
                                    totalCost: lineTotal,
                                    date: nowIso,
                                    type: editingMeta.type || type,
                                    transaction_id: txnKeep,
                                    supplier_invoice_number: supplierInvoiceNumber,
                                    batch_number: batchNumber,
                                    is_gift: row.isGift ? 1 : 0,
                                    expiry_date: row.expiry_date ? row.expiry_date : null,
                                    warehouse_id: (typeof getPurchaseRowWarehouseId === 'function') ? getPurchaseRowWarehouseId(row) : null
                                });
                            });
                        }
                        if (comp && data.company_balance != null && data.company_balance !== '') {
                            comp.balance = (typeof roundMoney === 'function' ? roundMoney : function(x) { return Math.round(Number(x)); })(parseFloat(data.company_balance) || 0);
                        }
                        window._posEditingPurchase = null;
                        purchaseCart = [];
                        if (typeof renderPurchaseCart === 'function') renderPurchaseCart();
                        if (typeof updatePurchaseEditModeUI === 'function') updatePurchaseEditModeUI();
                        if (typeof showToast === 'function') {
                            showToast((typeof t === 'function') ? t('purchase_edit_saved') : 'تەعدیل هاتە پاراستن', 'success');
                        }
                        if (typeof renderCompanies === 'function') renderCompanies();
                        if (typeof renderPurchaseHistory === 'function') renderPurchaseHistory();
                        if (typeof loadPurchaseHistory === 'function') loadPurchaseHistory();
                        setTimeout(function() {
                            if (typeof syncLiveData === 'function') syncLiveData(false);
                            else if (typeof connectToDB === 'function') connectToDB(true, { skipRenderOnRefresh: true });
                        }, 200);
                    })
                    .catch(function(err) {
                        clearTimeout(saveWatch);
                        isProcessingPurchasePayment = false;
                        _purchaseSaveBusyAt = 0;
                        if (typeof window.resetPurchaseSaveBusy === 'function') window.resetPurchaseSaveBusy();
                        if (btn) {
                            btn.disabled = false;
                            if (typeof updatePurchaseEditModeUI === 'function') updatePurchaseEditModeUI();
                        }
                        if (typeof showToast === 'function') showToast('❌ ' + (err.message || err), 'error');
                        else alert(err.message || err);
                    });
                } catch (saveErr) {
                    isProcessingPurchasePayment = false;
                    _purchaseSaveBusyAt = 0;
                    if (typeof window.resetPurchaseSaveBusy === 'function') window.resetPurchaseSaveBusy();
                    if (typeof updatePurchaseEditModeUI === 'function') updatePurchaseEditModeUI();
                    if (typeof showToast === 'function') showToast('❌ ' + ((saveErr && saveErr.message) ? saveErr.message : saveErr), 'error');
                }
                return;
            }

            isProcessingPurchasePayment = true;
            _purchaseSaveBusyAt = Date.now();
            var rowsToSend = validRows.map(function(r) {
                var copy = Object.assign({}, r);
                delete copy.productRef;
                if (typeof shouldShowPurchaseWarehouseUi === 'function' && shouldShowPurchaseWarehouseUi()) {
                    copy.warehouseId = getPurchaseRowWarehouseId(copy);
                }
                return copy;
            });
            normalizePurchaseExpiryRows(rowsToSend);

            var btn = document.getElementById('btn-save-purchase-invoice');
            var user = (typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : 'System';
            var invNumEl = document.getElementById('purchase-supplier-invoice-number');
            var batchEl = document.getElementById('purchase-batch-number');
            var supplierInvoiceNumber = (invNumEl && invNumEl.value) ? String(invNumEl.value).trim() : '';
            var batchNumber = (batchEl && batchEl.value && (typeof canUsePurchaseBatch !== 'function' || canUsePurchaseBatch())) ? String(batchEl.value).trim() : '';
            var rowsForPrint = validRows.map(function(r) { return Object.assign({}, r); });

            var rollback = {
                cart: purchaseCart.map(function(r) { return Object.assign({}, r); }),
                compBalance: comp ? (parseFloat(comp.balance) || 0) : 0,
                productQty: {},
                suppliesLen: (db.supplies || []).length,
                ledgerLen: (db.ledger || []).length,
                expensesLen: (db.expenses || []).length,
                todayExpenses: db.today_stats ? (parseFloat(db.today_stats.expenses) || 0) : 0,
                treasury: db.treasury !== undefined ? (parseFloat(db.treasury) || 0) : undefined
            };
            rowsToSend.forEach(function(row) {
                var p = (db.products || []).find(function(x) { return x.id === row.productId; });
                if (p) rollback.productQty[row.productId] = parseFloat(p.qty) || 0;
            });

            function resetPurchaseSaveBtn() {
                if (typeof window.resetPurchaseSaveBusy === 'function') window.resetPurchaseSaveBusy();
                else {
                    isProcessingPurchasePayment = false;
                    if (btn) btn.disabled = false;
                }
                if (btn) {
                    btn.innerHTML = '<i class="fas fa-save"></i> پاراستنا وەسڵێ (Save)';
                }
            }

            function rollbackPurchaseSave() {
                purchaseCart = rollback.cart;
                if (comp) comp.balance = rollback.compBalance;
                Object.keys(rollback.productQty).forEach(function(pid) {
                    var p = (db.products || []).find(function(x) { return String(x.id) === String(pid); });
                    if (p) p.qty = rollback.productQty[pid];
                });
                if (db.supplies && db.supplies.length > rollback.suppliesLen) db.supplies.length = rollback.suppliesLen;
                if (db.ledger && db.ledger.length > rollback.ledgerLen) db.ledger.length = rollback.ledgerLen;
                if (db.expenses && db.expenses.length > rollback.expensesLen) db.expenses.length = rollback.expensesLen;
                if (db.today_stats) db.today_stats.expenses = rollback.todayExpenses;
                if (rollback.treasury !== undefined && db.treasury !== undefined) db.treasury = rollback.treasury;
                if (typeof renderPurchaseCart === 'function') renderPurchaseCart();
                if (typeof debouncedRenderPurchaseProductGrid === 'function') debouncedRenderPurchaseProductGrid();
            }

            var provisionalTxnId = allocateNextPurchaseTransactionId();
            // Baghdad wall-clock SQL datetime — matches server supplies.date / getBusinessDate filtering
            var nowIso = (function() {
                if (typeof getPosTimezoneParts === 'function') {
                    var p = getPosTimezoneParts(new Date());
                    return p.year + '-' + p.month + '-' + p.day + ' ' + p.hour + ':' + p.minute + ':' + p.second;
                }
                try {
                    return new Date().toLocaleString('sv-SE', { timeZone: 'Asia/Baghdad' }).replace('T', ' ');
                } catch (_eNow) {
                    return new Date().toISOString().slice(0, 19).replace('T', ' ');
                }
            })();
            var roundM = typeof roundMoney === 'function' ? roundMoney : function(x) { return Math.round(Number(x)); };
            var grandTotalLocal = 0;

            rowsToSend.forEach(function(row) {
                var p = (db.products || []).find(function(x) { return x.id === row.productId; });
                var factors = (typeof getProductUnitFactors === 'function') ? getProductUnitFactors(p) : { piecesPerPack: 1, piecesPerCarton: 1 };
                var mult = 1;
                if (row.unit === 'carton') mult = factors.piecesPerCarton || 1;
                else if (row.unit === 'pack') mult = factors.piecesPerPack || 1;
                var pieces = Math.round((row.qty || 0) * mult);
                var lineTotal = purchaseLineTotal(row);
                grandTotalLocal = roundM(roundM(grandTotalLocal + lineTotal));

                if (!db.supplies) db.supplies = [];
                db.supplies.push({
                    id: Date.now() + Math.floor(Math.random() * 1000),
                    company: comp.name,
                    prodId: row.productId,
                    itemName: row.productName,
                    qtyAdded: pieces,
                    totalCost: lineTotal,
                    date: nowIso,
                    type: type,
                    transaction_id: provisionalTxnId,
                    supplier_invoice_number: supplierInvoiceNumber,
                    batch_number: batchNumber,
                    is_gift: row.isGift ? 1 : 0,
                    expiry_date: row.expiry_date ? row.expiry_date : null,
                    warehouse_id: (typeof getPurchaseRowWarehouseId === 'function') ? getPurchaseRowWarehouseId(row) : null
                });

                if (p && p.trackStock) p.qty = (parseFloat(p.qty) || 0) + pieces;
                if (p && row.sellPerUnit != null && typeof applyPurchaseSellToProduct === 'function') {
                    applyPurchaseSellToProduct(p, row.unit || 'piece', row.sellPerUnit);
                }
                if (p && !row.isGift && typeof applyPurchaseCostToProduct === 'function') {
                    var qPay = Number(row.qty) || 0;
                    var paidPerUnit = qPay > 0 ? (lineTotal / qPay) : row.costPerUnit;
                    if (paidPerUnit > 0) applyPurchaseCostToProduct(p, row.unit || 'piece', paidPerUnit);
                } else if (p && row.isGift && typeof applyPurchaseWacAfterStockIn === 'function') {
                    applyPurchaseWacAfterStockIn(p, pieces, lineTotal);
                }
            });
            try {
                if (typeof window.posInvalidateFifoSupplyCache === 'function') window.posInvalidateFifoSupplyCache();
                else {
                    window._fifoSuppliesByProduct = {};
                    window._fifoStockBatchesByProduct = {};
                }
            } catch (_eFifo) {}

            var purchaseDebtAmountLocal = 0;
            if (type === 'credit') purchaseDebtAmountLocal = grandTotalLocal;
            else if (type === 'split') purchaseDebtAmountLocal = roundM(Math.max(0, grandTotalLocal - (parseFloat(cashPaidForSplit) || 0)));
            if (purchaseDebtAmountLocal > 0) {
                var debtRatioLocal = (grandTotalLocal > 0) ? (purchaseDebtAmountLocal / grandTotalLocal) : 0;
                (db.supplies || []).forEach(function(s) {
                    if (!s || s.transaction_id !== provisionalTxnId) return;
                    if (type === 'credit') s.remaining_debt = parseFloat(s.totalCost) || 0;
                    else if (type === 'split') s.remaining_debt = roundM((parseFloat(s.totalCost) || 0) * debtRatioLocal);
                });
            }
            if (purchaseDebtAmountLocal > 0 && typeof computePaymentDueAtIso === 'function') {
                var ptLocal = (typeof resolveTxnPaymentTerm === 'function') ? resolveTxnPaymentTerm('purchase', comp) : { value: 0, unit: 'day' };
                var dueAtLocal = computePaymentDueAtIso(ptLocal.value, ptLocal.unit, nowIso);
                if (dueAtLocal) {
                    (db.supplies || []).forEach(function(s) {
                        if (s && s.transaction_id === provisionalTxnId) s.payment_due_at = dueAtLocal;
                    });
                }
            }

            if (comp) {
                if (type === 'credit') comp.balance = (parseFloat(comp.balance) || 0) + grandTotalLocal;
                else if (type === 'split') comp.balance = (parseFloat(comp.balance) || 0) + grandTotalLocal - (parseFloat(cashPaidForSplit) || 0);
            }
            if (!db.ledger) db.ledger = [];
            if (comp) {
                var baseNote = 'فاتورة شراء #' + provisionalTxnId + (supplierInvoiceNumber ? (' | Supplier Inv: ' + supplierInvoiceNumber) : '');
                if (type === 'credit') {
                    db.ledger.push({ id: Date.now(), companyId: comp.id, type: 'credit_purchase', amount: grandTotalLocal, date: nowIso, note: baseNote + ' | type=credit', transaction_id: provisionalTxnId });
                } else if (type === 'split') {
                    var paidNow = parseFloat(cashPaidForSplit) || 0;
                    var debtPart = Math.max(0, grandTotalLocal - paidNow);
                    if (debtPart > 0) db.ledger.push({ id: Date.now() + 1, companyId: comp.id, type: 'credit_purchase', amount: debtPart, date: nowIso, note: baseNote + ' | split debt', transaction_id: provisionalTxnId });
                    if (paidNow > 0) db.ledger.push({ id: Date.now() + 2, companyId: comp.id, type: 'payment', amount: paidNow, date: nowIso, note: baseNote + ' | split payment', transaction_id: provisionalTxnId });
                } else if (type === 'fib') {
                    db.ledger.push({ id: Date.now() + 3, companyId: comp.id, type: 'purchase_fib', amount: grandTotalLocal, date: nowIso, note: baseNote + ' | type=fib', transaction_id: provisionalTxnId });
                } else {
                    db.ledger.push({ id: Date.now() + 3, companyId: comp.id, type: 'purchase', amount: grandTotalLocal, date: nowIso, note: baseNote + ' | type=cash', transaction_id: provisionalTxnId });
                }
            }

            var cashOut = 0;
            if (type === 'cash') cashOut = grandTotalLocal;
            else if (type === 'split') cashOut = (splitAlloc && splitAlloc.cash != null) ? (parseFloat(splitAlloc.cash) || 0) : (parseFloat(cashPaidForSplit) || 0);
            else if (type === 'fib') cashOut = 0;
            if (cashOut > 0) {
                if (!db.expenses) db.expenses = [];
                var expNoteLocal = 'کڕین (نەقد): وەسڵ #' + provisionalTxnId + (supplierInvoiceNumber ? (' | ' + supplierInvoiceNumber) : '');
                db.expenses.push({
                    id: Date.now() + 4,
                    note: expNoteLocal,
                    amount: cashOut,
                    date: nowIso,
                    user: user,
                    type: 'purchase',
                    transaction_id: provisionalTxnId
                });
                if (db.treasury !== undefined) {
                    db.treasury = roundM((parseFloat(db.treasury) || 0) - cashOut);
                }
            }

            purchaseCart = [];
            if (typeof renderPurchaseCart === 'function') renderPurchaseCart();
            if (typeof debouncedRenderPurchaseProductGrid === 'function') debouncedRenderPurchaseProductGrid();
            if (typeof window.collapseTxnSheet === 'function') window.collapseTxnSheet('purchase');
            resetPurchaseSaveBtn();
            if (typeof showToast === 'function') showToast('✅ وەسڵا کڕینێ هاتە پاراستن');
            if (typeof posFlashScheduleSync === 'function') posFlashScheduleSync('purchase');
            if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('purchase');

            var printMeta = splitAlloc ? Object.assign({ paymentType: type }, splitAlloc) : { paymentType: type };
            printMeta.internalId = provisionalTxnId;
            printMeta.supplierInvoiceNumber = supplierInvoiceNumber;
            printMeta.batchNumber = batchNumber;

            if (typeof posInvalidateDailyDetailCache === 'function' && typeof getBusinessDate === 'function') {
                try { posInvalidateDailyDetailCache(getBusinessDate(new Date())); } catch (_eInvPur) {}
            }
            setTimeout(function() {
                if (typeof db !== 'undefined' && db.settings && db.settings.autoPrintPurchaseInvoice && typeof printPurchaseInvoiceFromRows === 'function') {
                    printPurchaseInvoiceFromRows(rowsForPrint, comp, type, printMeta);
                }
                if (typeof posRefreshOpenFinancialScreens === 'function') {
                    try { posRefreshOpenFinancialScreens(); } catch (_eRefPur) {}
                } else if (typeof updateStats === 'function') {
                    updateStats();
                }
                if (typeof renderPurchaseReturnsProductGrid === 'function') renderPurchaseReturnsProductGrid();
            }, 0);

            var formData = new FormData();
            formData.append('action', 'save_purchase_invoice');
            formData.append('company_id', comp.id);
            formData.append('company_name', comp.name);
            formData.append('items', JSON.stringify(rowsToSend));
            formData.append('type', type);
            if (type === 'split') {
                formData.append('cash_paid', cashPaidForSplit);
                if (splitAlloc) formData.append('split_allocations', JSON.stringify(splitAlloc));
            } else if (type === 'fib') {
                if (splitAlloc) formData.append('split_allocations', JSON.stringify(splitAlloc));
            }
            formData.append('user', user);
            formData.append('supplier_invoice_number', supplierInvoiceNumber);
            formData.append('batch_number', batchNumber);
            var purCurEl = document.getElementById('purchase-currency');
            if (purCurEl && (purCurEl.value === 'USD' || purCurEl.value === 'IQD')) {
                formData.append('currency', purCurEl.value);
            }
            if (typeof getUsdRatePerOne === 'function') {
                formData.append('exchange_rate', String(getUsdRatePerOne()));
            }
            var purWh = document.getElementById('purchase-warehouse-select');
            if (purWh && purWh.value) {
                formData.append('warehouse_id', purWh.value);
                if (typeof saveActiveWarehouseChoice === 'function') saveActiveWarehouseChoice('purchase', purWh.value);
            } else if (typeof getDefaultWarehouseId === 'function' && getDefaultWarehouseId()) {
                formData.append('warehouse_id', String(getDefaultWarehouseId()));
            }
            if (typeof appendPaymentTermToFormData === 'function') appendPaymentTermToFormData(formData, 'purchase');

            fetch('?action=save_purchase_invoice', { method: 'POST', body: formData, credentials: 'same-origin' })
                .then(function(r) { return r.json().catch(function() { return { status: 'error', message: 'وەڵامێ سێرڤەر نەهات' }; }); })
                .then(function(data) {
                    if (!data || data.status !== 'success') {
                        rollbackPurchaseSave();
                        resetPurchaseSaveBtn();
                        alert('هەڵە: ' + ((data && data.message) ? data.message : 'Unknown error'));
                        return;
                    }
                    var serverTxnId = data.transaction_id || provisionalTxnId;
                    if (serverTxnId !== provisionalTxnId) {
                        (db.supplies || []).forEach(function(s) {
                            if (s.transaction_id === provisionalTxnId) s.transaction_id = serverTxnId;
                        });
                        (db.ledger || []).forEach(function(l) {
                            if (l.transaction_id === provisionalTxnId) l.transaction_id = serverTxnId;
                        });
                        (db.expenses || []).forEach(function(e) {
                            if (e.transaction_id === provisionalTxnId) e.transaction_id = serverTxnId;
                        });
                    }
                    if (data.expense_id) {
                        var lastExp = (db.expenses || []).slice(-1)[0];
                        if (lastExp && lastExp.transaction_id === serverTxnId) lastExp.id = data.expense_id;
                    }
                    var serverPayType = data.payment_type || type;
                    if (comp && data.company_balance != null && data.company_balance !== '') {
                        comp.balance = (typeof roundMoney === 'function' ? roundMoney : function(x) { return Math.round(Number(x)); })(parseFloat(data.company_balance) || 0);
                    }
                    if (comp && serverPayType && serverPayType !== type && typeof showToast === 'function') {
                        var mismatchMsg = (typeof t === 'function') ? t('purchase_payment_type_mismatch') : 'جۆرێ پارەدانێ لە سێرڤەردا جیاوازە';
                        showToast(mismatchMsg + ' (' + serverPayType + ')', 'error');
                    }
                    if (typeof showToast === 'function') {
                        var payToastKey = serverPayType === 'credit' ? 'purchase_saved_as_credit' : (serverPayType === 'split' ? 'purchase_saved_as_split' : 'purchase_saved_as_cash');
                        var payToastFallback = serverPayType === 'credit'
                            ? 'وەسڵ بە قەرز تۆمارکرا — قەرزێ کۆمپانیێ زیاد بوو'
                            : (serverPayType === 'split' ? 'وەسڵ بە پارەدانێ تێکەڵ تۆمارکرا' : 'وەسڵ بە کاش تۆمارکرا — قەرزێ کۆمپانیێ نەگەهشت');
                        showToast((typeof t === 'function' && t(payToastKey) !== payToastKey) ? t(payToastKey) : payToastFallback, serverPayType === 'cash' ? 'info' : 'success');
                    }
                    if (data.payment_due_warning && data.payment_due_warning.message && typeof showToast === 'function') {
                        showToast('⚠️ ' + data.payment_due_warning.message, 'warning');
                    }
                    if (typeof posInvalidateDailyDetailCache === 'function' && typeof getBusinessDate === 'function') {
                        try { posInvalidateDailyDetailCache(getBusinessDate(new Date())); } catch (_eInvPur2) {}
                    }
                    if (typeof posRefreshOpenFinancialScreens === 'function') {
                        try { posRefreshOpenFinancialScreens(); } catch (_eRefPur2) {}
                    } else if (typeof updateStats === 'function') {
                        updateStats();
                    }
                    if (typeof renderCompanies === 'function') renderCompanies();
                    if (typeof window.scheduleFirebaseMobilePush === 'function') {
                        window.scheduleFirebaseMobilePush('purchase', false);
                    }
                    setTimeout(function() {
                        if (typeof syncLiveData === 'function') syncLiveData(false);
                        else if (typeof connectToDB === 'function') connectToDB(true, { skipRenderOnRefresh: true });
                    }, 200);
                })
                .catch(function(err) {
                    rollbackPurchaseSave();
                    resetPurchaseSaveBtn();
                    if (typeof showToast === 'function') showToast('❌ هەڵە د پاراستنێ دا: ' + (err.message || err), 'error');
                    else alert('هەڵە د پاراستنێ دا: ' + (err.message || err));
                });
        }

        /** Use header «پارێ دای» when payment modal is off or user entered an amount (cash / split / credit). */
        function tryPurchaseCheckoutWithHeaderPaid() {
            var sel = document.getElementById('purchase-supplier-select');
            if (!sel || !sel.value) return false;
            var modalOff = typeof isAutoPaymentModalEnabled === 'function' && !isAutoPaymentModalEnabled();
            if (!modalOff) {
                var paidEl = document.getElementById('purchase-supplier-paid');
                var raw = paidEl ? String(paidEl.value || '').replace(/,/g, '').trim() : '';
                if (!raw) return false;
            }
            if (typeof window.purchaseCheckoutWithSupplierPaid !== 'function') return false;
            return window.purchaseCheckoutWithSupplierPaid() === true;
        }
        window.tryPurchaseCheckoutWithHeaderPaid = tryPurchaseCheckoutWithHeaderPaid;

        function resolvePurchaseCompanyForSave() {
            var companies = (window.db && window.db.companies) || [];
            var sel = document.getElementById('purchase-supplier-select');
            var supplierId = sel && sel.value ? parseInt(sel.value, 10) : 0;
            var comp = supplierId ? companies.find(function (c) { return Number(c.id) === supplierId; }) : null;
            if (comp) return comp;
            var meta = window._posEditingPurchase;
            if (meta) {
                if (meta.company_id) {
                    comp = companies.find(function (c) { return Number(c.id) === Number(meta.company_id); }) || null;
                    if (comp) {
                        if (sel) sel.value = String(comp.id);
                        return comp;
                    }
                }
                var metaName = String(meta.company || '').trim().toLowerCase();
                if (metaName) {
                    comp = companies.find(function (c) { return String(c.name || '').trim().toLowerCase() === metaName; }) || null;
                    if (comp) {
                        if (sel) sel.value = String(comp.id);
                        return comp;
                    }
                }
            }
            var searchEl = document.getElementById('purchase-supplier-search');
            var q = searchEl && searchEl.value ? String(searchEl.value).trim().toLowerCase() : '';
            if (q) {
                comp = companies.find(function (c) { return String(c.name || '').trim().toLowerCase() === q; }) || null;
                if (comp) {
                    if (sel) sel.value = String(comp.id);
                    return comp;
                }
            }
            if (meta && (meta.company || meta.txnId)) {
                return {
                    id: meta.company_id || 0,
                    name: meta.company || '',
                    balance: 0
                };
            }
            return null;
        }

        function savePurchaseInvoice() {
            try {
            if (window._posEditingPurchase && window._posEditingPurchase.txnId) {
                var comp = resolvePurchaseCompanyForSave();
                if (!comp) {
                    if (typeof window.highlightTxnMetaFields === 'function') {
                        window.highlightTxnMetaFields('purchase', ['purchase-supplier-select']);
                    }
                    if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('purchase_select_company') : 'کۆمپانیایەکێ هەلبژێرە', 'error');
                    return;
                }
                var validRows = purchaseCart.filter(function(row) { return (row.qty || 0) > 0; });
                if (!validRows.length) {
                    if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('purchase_cart_empty') : 'سەبەتا کڕینێ یا بەتاڵە', 'error');
                    return;
                }
                var type = window._posEditingPurchase.type || 'cash';
                executeSavePurchaseInvoice(comp, validRows, type, 0, null);
                return;
            }
            if (typeof getCartPayMethod === 'function' && getCartPayMethod('purchase') === 'fib') {
                if (typeof savePurchaseInvoiceFib === 'function') {
                    savePurchaseInvoiceFib();
                    return;
                }
            }
            if (tryPurchaseCheckoutWithHeaderPaid()) return;
            openPurchasePaymentModal();
            } catch (saveClickErr) {
                if (typeof window.resetPurchaseSaveBusy === 'function') window.resetPurchaseSaveBusy();
                if (typeof showToast === 'function') {
                    showToast('❌ ' + ((saveClickErr && saveClickErr.message) ? saveClickErr.message : saveClickErr), 'error');
                }
            }
        }
        window.savePurchaseInvoice = savePurchaseInvoice;

        /** Instant FIB purchase — no payment modal. Cash drawer unchanged. */
        function savePurchaseInvoiceFib() {
            if (window._posEditingPurchase && window._posEditingPurchase.txnId) {
                savePurchaseInvoice();
                return;
            }
            if (typeof window.collapseTxnSheet === 'function') window.collapseTxnSheet('purchase');
            var sel = document.getElementById('purchase-supplier-select');
            var supplierId = sel && sel.value ? parseInt(sel.value, 10) : null;
            var comp = supplierId ? (db.companies || []).find(function(c) { return c.id === supplierId; }) : null;
            if (!comp) {
                if (typeof window.highlightTxnMetaFields === 'function') {
                    window.highlightTxnMetaFields('purchase', ['purchase-supplier-select']);
                }
                if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('purchase_select_company') : 'کۆمپانیایەکێ هەلبژێرە', 'error');
                else alert('کۆمپانیایەکێ هەلبژێرە');
                return;
            }
            var validRows = purchaseCart.filter(function(row) { return (row.qty || 0) > 0; });
            if (!validRows.length) {
                if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('purchase_cart_empty') : 'سەبەتا کڕینێ یا بەتاڵە', 'error');
                else alert('سەبەتا کڕینێ یا بەتاڵە');
                return;
            }
            var subTotal = typeof getPurchaseCartSubtotal === 'function' ? getPurchaseCartSubtotal() : 0;
            executeSavePurchaseInvoice(comp, validRows, 'fib', 0, { cash: 0, bank: subTotal, debt: 0 });
        }
        window.savePurchaseInvoiceFib = savePurchaseInvoiceFib;

        /** Build and print purchase invoice from saved rows (after save). Uses store logo/name/notes from settings. */
        function printPurchaseInvoiceFromRows(validRows, company, paymentType, printMeta) {
            if (!validRows || !validRows.length || !company) return;
            printMeta = printMeta || {};
            var roundM3 = typeof roundMoney === 'function' ? roundMoney : function(x){ return Math.round(Number(x)); };
            var grandTotal = 0;
            var rowsHtml = validRows.map(function(row) {
                var lineTotal = purchaseLineTotal(row);
                grandTotal = roundM3(grandTotal + lineTotal);
                var ul = getProductUnitLabel(row.productRef || row, row.unit || 'piece');
                var giftStr = row.isGift ? ' <span style="color:#ec4899; font-weight:bold;">(هدیە · فری)</span>' : '';
                var costCell = row.isGift ? '0' : formatCurrency(row.costPerUnit || 0);
                var totalCell = row.isGift ? '0' : formatCurrency(lineTotal);
                return '<tr><td class="row-item">' + escapeHtml(row.productName || 'ئایتم') + giftStr + ' <br><small>(' + ul + ')</small></td><td class="row-qty">' + (row.qty || 0) + '</td><td class="row-price">' + costCell + '</td><td class="row-price" style="text-align:left">' + totalCell + '</td></tr>';
            }).join('');

            // Debt history breakdown for this purchase invoice
            var companyCurrent = (db && db.companies && db.companies.find) ? (db.companies.find(function(c){ return (company.id && c.id == company.id) || (c.name && company.name && c.name === company.name); }) || company) : company;
            var companyBalance = parseFloat(companyCurrent?.balance || 0) || 0;
            var debtAdded = 0;
            var cashPaid = 0;
            var bankPaid = 0;
            if (paymentType === 'credit') {
                debtAdded = grandTotal;
            } else if (paymentType === 'cash') {
                cashPaid = grandTotal;
            } else if (paymentType === 'split') {
                debtAdded = roundM3(parseFloat(printMeta.debt) || 0);
                cashPaid = roundM3(parseFloat(printMeta.cash) || 0);
                bankPaid = roundM3(parseFloat(printMeta.bank) || 0);
            }
            var previousDebt = companyBalance - debtAdded;
            var totalOutstandingDebt = previousDebt + debtAdded;
            
            var invNumEl = document.getElementById('purchase-supplier-invoice-number');
            var supplierInvoiceNumber = printMeta.supplierInvoiceNumber || ((invNumEl && invNumEl.value) ? String(invNumEl.value).trim() : '') || '---';

            var cfg = typeof getPrintConfig === 'function' ? getPrintConfig('purchase_invoice') : { paper: '80mm', design: '1' };
            
            // If A4 is selected, use A4 specific layout
            if (cfg.paper === '210mm' || cfg.paper === 'A4') {
               return printPurchaseInvoiceA4(validRows, company, paymentType, cfg, printMeta);
            }

            var thermalLogoHtml = typeof getThermalLogoHtml === 'function' ? getThermalLogoHtml() : ((typeof getPosShopLogoUrl === 'function' && getPosShopLogoUrl()) ? '<img src="' + getPosShopLogoUrl() + '" class="thermal-logo">' : '');
            var thermalFontClasses = typeof getThermalFontClasses === 'function' ? getThermalFontClasses() : '';
            var payLabel = paymentType === 'credit'
                ? (typeof t === 'function' ? t('payment_method_debt') : 'قەرز')
                : (paymentType === 'fib' ? (typeof t === 'function' ? t('payment_method_fib') : 'FIB')
                : (paymentType === 'split' ? 'قەرز + نەقد / FIB' : (typeof t === 'function' ? t('payment_method_cash') : 'نەقد')));
            var locale = typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ';
            
            var html = '<div class="print-thermal-container design-' + (cfg.design || '1') + thermalFontClasses + '" style="max-width: ' + (cfg.paper || '80mm') + '; width: 100%;">' +
                thermalLogoHtml +
                '<div class="thermal-header"><h1>' + (db.settings && db.settings.cafeName ? escapeHtml(db.settings.cafeName) : 'Store') + '</h1><p>' + (db.settings && db.settings.cafeInfo ? escapeHtml(db.settings.cafeInfo) : '') + '</p></div>' +
                '<div class="thermal-divider"></div>' +
                '<h3 style="margin:5px 0; background:#eee; padding:5px; border-radius:4px;">' + (typeof t === 'function' ? t('print_purchase_invoice') : 'وەسڵا کڕین (Purchase)') + '</h3>' +
                '<div class="thermal-info"><span>' + (typeof t === 'function' ? t('print_date') : 'بەروار') + ':</span> <span>' + new Date().toLocaleString(locale) + '</span></div>' +
                '<div class="thermal-info"><span>' + (typeof t === 'function' ? t('print_supplier') : 'مۆرد') + ':</span> <span>' + escapeHtml(company.name || '') + '</span></div>' +
                '<div class="thermal-info"><span>' + (typeof t === 'function' ? t('print_type') : 'جۆر') + ':</span> <span>' + payLabel + '</span></div>' +
                '<div class="thermal-info"><span>ژمارا وەسڵێ:</span> <span>#' + escapeHtml(formatPurchaseTransactionIdForDisplay(printMeta.internalId || '')) + '</span></div>' +
                '<div class="thermal-info"><span>پسوولا کۆمپانیێ:</span> <span>' + (printMeta.supplierInvoiceNumber || supplierInvoiceNumber || '---') + '</span></div>' +
                '<div class="thermal-info"><span>ژمارا وەجبێ:</span> <span>' + escapeHtml(printMeta.batchNumber || (document.getElementById('purchase-batch-number') || {}).value || '---') + '</span></div>' +
                '<div class="thermal-divider"></div>' +
                '<table class="thermal-table print-unified-table"><thead><tr><th style="text-align:right">' + (typeof t === 'function' ? t('th_item') : 'ئایتم') + '</th><th style="text-align:center">' + (typeof t === 'function' ? t('th_qty') : 'ژ') + '</th><th style="text-align:left">' + (typeof t === 'function' ? t('th_price') : 'نرخ') + '</th><th style="text-align:left">' + (typeof t === 'function' ? t('th_total') : 'کۆم') + '</th></tr></thead><tbody>' + rowsHtml + '</tbody></table>' +
                '<div class="thermal-divider" style="opacity:1; border-top:2px solid #000;"></div>' +
                '<div class="grand-total">' + (typeof t === 'function' ? t('print_grand_total') : 'کۆیا گشتی') + ': ' + formatCurrency(grandTotal) + ' ' + (typeof getCurrencySymbol === 'function' ? getCurrencySymbol() : '') + '</div>' +
                ((debtAdded > 0 || totalOutstandingDebt > 0) ? '<div style="margin-top:8px; background:#f8fafc; border:1px dashed #cbd5e1; border-radius:10px; padding:10px;">' +
                    '<div style="display:flex; justify-content:space-between; gap:10px; font-size:0.9rem; color:#64748b;"><span>کۆیا گشتی (Grand Total):</span><b style="color:#0f172a;">' + formatCurrency(grandTotal) + '</b></div>' +
                    '<div style="display:flex; justify-content:space-between; gap:10px; font-size:0.9rem; color:#64748b; margin-top:6px;"><span>نەقد (Cash Paid):</span><b style="color:#059669;">' + formatCurrency(cashPaid) + '</b></div>' +
                    (bankPaid > 0 ? '<div style="display:flex; justify-content:space-between; gap:10px; font-size:0.9rem; color:#64748b; margin-top:6px;"><span>Bank/Card:</span><b style="color:#2563eb;">' + formatCurrency(bankPaid) + '</b></div>' : '') +
                    (debtAdded > 0 ? '<div style="display:flex; justify-content:space-between; gap:10px; font-size:0.9rem; color:#64748b; margin-top:6px;"><span>قەرزی نوی (Debt Added):</span><b style="color:#dc2626;">' + formatCurrency(debtAdded) + '</b></div>' : '') +
                    (previousDebt != 0 ? '<div style="display:flex; justify-content:space-between; gap:10px; font-size:0.9rem; color:#64748b; margin-top:6px;"><span>قەرزی پێشوو (Prev Debt):</span><b style="color:#0f172a;">' + formatCurrency(previousDebt) + '</b></div>' : '') +
                    '<div style="display:flex; justify-content:space-between; gap:10px; font-size:0.95rem; color:#64748b; margin-top:6px; border-top:1px solid #e2e8f0; padding-top:8px;"><span>کۆیا قەرزی (Total Debt):</span><b style="color:#0f172a;">' + formatCurrency(totalOutstandingDebt) + '</b></div>' +
                '</div>' : '') +
                '<div class="thermal-divider"></div>' +
                '<div class="thermal-info" style="font-weight:bold;"><span>' + (typeof t === 'function' ? t('print_cashier') : 'کاشێر') + ':</span> <span>' + ((typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : 'System') + '</span></div>' +
                (db.settings && db.settings.invoiceNote ? '<p style="margin-top:8px; font-size:0.85rem; border:1px dashed #ccc; padding:4px;">' + escapeHtml(db.settings.invoiceNote) + '</p>' : '') +
                '<div class="thermal-footer">' + (typeof buildPosReceiptBrandFooterHtml === 'function' ? buildPosReceiptBrandFooterHtml() : '') + '</div>' +
                '</div>';
            var doPrint = function () {
                if (typeof printContent === 'function') printContent(html, { fast: true, docType: 'purchase_invoice' });
            };
            if (typeof whenPrintFrameReady === 'function') whenPrintFrameReady(doPrint, 2500);
            else doPrint();
        }

        /** Company A4 — shared data + 3 luxe layouts (purchase / return) */
        function companyA4Font() {
            return (typeof a4InvoiceFont === 'function') ? a4InvoiceFont() : "'Rudaw', sans-serif";
        }
        function buildCompanyA4LogoHtml(d, boxPx) {
            if (typeof buildA4LogoStripHtml === 'function') return buildA4LogoStripHtml(d, boxPx);
            if (!d.mainLogo) return '';
            return '<div class="a4-logo-strip" data-size="' + boxPx + '"><span class="a4-logo-slot"><img src="' + d.mainLogo + '" alt=""></span></div>';
        }
        function buildCompanyA4StoreContactHtml(d) {
            var parts = [];
            if (d.storeAddress) parts.push('<span class="a4-contact-item">📍 ' + d.storeAddress + '</span>');
            if (d.storePhone) parts.push('<span class="a4-contact-item">☎ ' + d.storePhone + '</span>');
            if (!parts.length && d.cafeInfo) parts.push('<span class="a4-contact-item">' + d.cafeInfo + '</span>');
            return parts.length ? '<div class="a4-contact-lines">' + parts.join('') + '</div>' : '';
        }
        function buildCompanyA4PurchaseData(validRows, company, paymentType, printMeta, opts) {
            opts = opts || {};
            printMeta = printMeta || {};
            var roundM3 = typeof roundMoney === 'function' ? roundMoney : function(x) { return Math.round(Number(x)); };
            var isReturn = !!opts.isReturn;
            var grandTotal = 0;
            var items = (validRows || []).map(function(row) {
                var lineTotal = purchaseLineTotal(row);
                grandTotal = roundM3(grandTotal + lineTotal);
                var ul = getProductUnitLabel(row.productRef || row, row.unit || 'piece');
                var giftSuffix = row.isGift ? ' <span style="color:#ec4899;font-weight:bold;">(هدیە · فری)</span>' : '';
                var packLabel = (typeof formatProductPackagingLabel === 'function')
                    ? formatProductPackagingLabel(row.productRef || row)
                    : '—';
                return {
                    name: escapeHtml(row.productName || 'ئایتم') + giftSuffix,
                    unitLabel: ul,
                    packLabel: packLabel,
                    qty: row.qty || 0,
                    price: row.isGift ? 0 : (row.costPerUnit || 0),
                    lineTotal: lineTotal,
                    isGift: !!row.isGift
                };
            });
            var invNumEl = document.getElementById('purchase-supplier-invoice-number');
            var rawSupplierInv = printMeta.supplierInvoiceNumber || ((invNumEl && invNumEl.value) ? String(invNumEl.value).trim() : '') || (opts.invoiceRef || '');
            var rawInternalId = printMeta.internalId || opts.internalId || '';
            var internalFormatted = typeof formatPurchaseTransactionIdForDisplay === 'function'
                ? formatPurchaseTransactionIdForDisplay(rawInternalId)
                : (rawInternalId || '---');
            var displayInvoiceNumber = resolveCompanyInvoiceDisplayNumber(rawSupplierInv, rawInternalId);
            var supplierInvoiceNumber = escapeHtml(displayInvoiceNumber);
            var payLabel = isReturn ? (typeof t === 'function' ? t('print_purchase_return') : 'زڤڕاندن') : (paymentType === 'credit' ? (typeof t === 'function' ? t('payment_method_debt') : 'قەرز') : (paymentType === 'fib' ? (typeof t === 'function' ? t('payment_method_fib') : 'FIB') : (paymentType === 'split' ? 'قەرز + نەقد / FIB' : (typeof t === 'function' ? t('payment_method_cash') : 'نەقد'))));
            var locale = typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ';
            var now = new Date();
            var companyCurrent = (db && db.companies && db.companies.find) ? (db.companies.find(function(c) { return (company.id && c.id == company.id) || (c.name && company.name && c.name === company.name); }) || company) : company;
            var companyBalance = parseFloat(companyCurrent && companyCurrent.balance) || 0;
            var debtAdded = 0;
            var cashPaid = 0;
            var bankPaid = 0;
            if (isReturn) {
                debtAdded = -grandTotal;
            } else if (paymentType === 'credit') {
                debtAdded = grandTotal;
            } else if (paymentType === 'cash') {
                cashPaid = grandTotal;
            } else if (paymentType === 'split') {
                debtAdded = roundM3(parseFloat(printMeta.debt) || 0);
                cashPaid = roundM3(parseFloat(printMeta.cash) || 0);
                bankPaid = roundM3(parseFloat(printMeta.bank) || 0);
            }
            var previousDebt = companyBalance - debtAdded;
            var totalOutstandingDebt = previousDebt + debtAdded;
            var companyContact = (company && (company.contact || company.phone)) ? String(company.contact || company.phone) : '';
            var brandInfo = (typeof getPosReceiptBrandInfo === 'function') ? getPosReceiptBrandInfo() : { name: 'Laptop Duhok POS', phone: '07507367680' };
            var brand = brandInfo.name + (brandInfo.phone ? ' · ' + brandInfo.phone : '');
            return {
                isReturn: isReturn,
                cafeName: escapeHtml((db.settings && db.settings.cafeName) ? db.settings.cafeName : 'Store'),
                cafeInfo: escapeHtml((db.settings && db.settings.cafeInfo) ? db.settings.cafeInfo : ''),
                storeAddress: (db.settings && db.settings.cafeAddress) ? escapeHtml(db.settings.cafeAddress) : '',
                storePhone: (db.settings && db.settings.cafePhone) ? escapeHtml(db.settings.cafePhone) : '',
                mainLogo: (typeof getPosShopLogoUrl === 'function') ? getPosShopLogoUrl() : ((db.settings && db.settings.logo) ? String(db.settings.logo) : ''),
                design3LogoLayout: (db.settings && db.settings.a4Design3LogoLayout) ? String(db.settings.a4Design3LogoLayout) : 'center',
                design3LogoLeft: (db.settings && db.settings.a4Design3LogoLeft) ? String(db.settings.a4Design3LogoLeft) : '',
                design3LogoCenter: (db.settings && db.settings.a4Design3LogoCenter) ? String(db.settings.a4Design3LogoCenter) : '',
                design3LogoRight: (db.settings && db.settings.a4Design3LogoRight) ? String(db.settings.a4Design3LogoRight) : '',
                companyName: escapeHtml(company ? company.name : '---'),
                companyContact: companyContact ? escapeHtml(companyContact) : '',
                docTitle: isReturn ? ((typeof t === 'function' ? t('print_purchase_return') : 'زڤڕاندن بۆ کۆمپانیا')) : ((typeof t === 'function' ? t('print_purchase_invoice') : 'وەسڵا کڕینێ')),
                docBadge: isReturn ? 'RETURN' : 'B2B',
                internalId: escapeHtml(internalFormatted),
                supplierInvoiceNumber: supplierInvoiceNumber,
                displayInvoiceNumber: supplierInvoiceNumber,
                hasSupplierInvoice: !!(rawSupplierInv && String(rawSupplierInv).trim() && String(rawSupplierInv).trim() !== '---'),
                payLabel: payLabel,
                payColor: isReturn ? '#ea580c' : (paymentType === 'credit' ? '#dc2626' : '#059669'),
                dateStr: now.toLocaleDateString(locale),
                timeStr: now.toLocaleTimeString(locale, { hour: '2-digit', minute: '2-digit' }),
                items: items,
                itemCount: items.length,
                grandTotal: grandTotal,
                debtAdded: debtAdded,
                cashPaid: cashPaid,
                bankPaid: bankPaid,
                previousDebt: previousDebt,
                totalOutstandingDebt: totalOutstandingDebt,
                showDebt: isReturn ? (debtAdded !== 0 || totalOutstandingDebt > 0 || previousDebt != 0) : (debtAdded > 0 || totalOutstandingDebt > 0),
                currency: (typeof getCurrencySymbol === 'function' ? getCurrencySymbol() : ''),
                invoiceNote: (db.settings && db.settings.invoiceNote) ? escapeHtml(db.settings.invoiceNote) : '',
                footer: (db.settings && db.settings.footer) ? escapeHtml(db.settings.footer) : 'سوپاس بۆ مامەڵەکرن',
                printedBy: ((typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? escapeHtml(currentUser.name) : 'System'),
                brand: brand,
                thItem: (typeof t === 'function' ? t('th_item') : 'ئایتم'),
                thPackaging: (typeof t === 'function' ? t('th_packaging') : 'پێکهاتە'),
                thUnit: (typeof t === 'function' ? t('th_unit') : 'یەکە'),
                thQty: (typeof t === 'function' ? t('th_qty') : 'ژمارە'),
                thPrice: (typeof t === 'function' ? (t('th_unit_price') || t('th_price')) : 'نرخی یەکە'),
                thTotal: (typeof t === 'function' ? t('th_total') : 'کۆم'),
                lblSupplier: (typeof t === 'function' ? t('print_supplier') : 'مۆرد / کۆمپانیا'),
                lblPayment: (typeof t === 'function' ? t('print_type') : 'جۆرێ پارەی'),
                lblInternal: 'ژمارا وەسڵێ',
                lblSupplierInv: 'پسوولا کۆمپانیێ'
            };
        }
        function buildCompanyA4ItemRows(d) {
            if (!d || !Array.isArray(d.items)) return '';
            return d.items.map(function(it, idx) {
                var zebra = idx % 2 === 1 ? ' a4-row-alt' : '';
                var packCell = escapeHtml(it.packLabel || '—');
                var unitCell = escapeHtml(it.unitLabel || '—');
                if (d.isReturn) {
                    return '<tr class="a4-item-row' + zebra + '"><td class="a4-td-num">' + (idx + 1) + '</td>' +
                        '<td class="a4-td-item"><span class="a4-item-name">' + it.name + '</span></td>' +
                        '<td class="a4-td-pack">' + packCell + '</td>' +
                        '<td class="a4-td-unit">' + unitCell + '</td>' +
                        '<td class="a4-td-qty">' + it.qty + '</td>' +
                        '<td class="a4-td-money a4-td-total">' + formatCurrency(it.lineTotal) + '</td></tr>';
                }
                return '<tr class="a4-item-row' + zebra + '"><td class="a4-td-num">' + (idx + 1) + '</td>' +
                    '<td class="a4-td-item"><span class="a4-item-name">' + it.name + '</span></td>' +
                    '<td class="a4-td-pack">' + packCell + '</td>' +
                    '<td class="a4-td-unit">' + unitCell + '</td>' +
                    '<td class="a4-td-qty">' + it.qty + '</td>' +
                    '<td class="a4-td-money">' + formatCurrency(it.price) + '</td>' +
                    '<td class="a4-td-money a4-td-total">' + formatCurrency(it.lineTotal) + '</td></tr>';
            }).join('');
        }
        function buildCompanyA4TableHead(d) {
            if (d.isReturn) {
                return '<th class="a4-th-num">#</th><th>' + d.thItem + '</th>' +
                    '<th class="a4-th-pack">' + (d.thPackaging || 'پێکهاتە') + '</th>' +
                    '<th class="a4-th-unit">' + (d.thUnit || 'یەکە') + '</th>' +
                    '<th class="a4-th-qty">' + d.thQty + '</th><th class="a4-th-money">' + d.thTotal + '</th>';
            }
            return '<th class="a4-th-num">#</th><th>' + d.thItem + '</th>' +
                '<th class="a4-th-pack">' + (d.thPackaging || 'پێکهاتە') + '</th>' +
                '<th class="a4-th-unit">' + (d.thUnit || 'یەکە') + '</th>' +
                '<th class="a4-th-qty">' + d.thQty + '</th>' +
                '<th class="a4-th-money">' + d.thPrice + '</th><th class="a4-th-money">' + d.thTotal + '</th>';
        }
        function buildCompanyA4CompactHeader(d, logoPx) {
            var storeExtra = d.storePhone ? '<em>' + d.storePhone + '</em>' : '';
            var docSub = d.hasSupplierInvoice
                ? (d.lblInternal + ' #' + d.internalId)
                : '';
            var docMeta = (docSub ? docSub + ' · ' : '') + d.dateStr + ' · ' + d.timeStr;
            var logoPart = '';
            if (logoPx !== 0 && logoPx !== false) {
                logoPx = logoPx || 36;
                logoPart = '<div class="a4-co-head-logo">' + buildCompanyA4LogoHtml(d, logoPx) + '</div>';
            }
            return '<div class="a4-co-head-bar' + (logoPart ? '' : ' a4-co-head-bar--no-logo') + '">' +
                logoPart +
                '<div class="a4-co-head-col a4-co-head-store"><strong>' + d.cafeName + '</strong>' + storeExtra + '</div>' +
                '<div class="a4-co-head-col a4-co-head-doc"><span>' + d.docTitle + (d.isReturn ? ' · RETURN' : '') + '</span>' +
                '<b>#' + d.displayInvoiceNumber + '</b><em>' + docMeta + '</em></div>' +
                '<div class="a4-co-head-col a4-co-head-supplier"><span>' + d.lblSupplier + '</span><b>' + d.companyName + '</b>' +
                '<em>' + d.payLabel + (d.companyContact ? ' · ' + d.companyContact : '') + '</em></div></div>';
        }
        function buildCompanyA4TotalsHtml(d) {
            var debtHtml = '';
            if (d.showDebt) {
                debtHtml = '<div class="a4-debt-panel a4-debt-panel--company a4-debt-panel--compact">' +
                    '<div class="a4-debt-row"><span>نەقد</span><b class="a4-debt-cash">' + formatCurrency(d.cashPaid) + '</b></div>' +
                    (d.bankPaid > 0 ? '<div class="a4-debt-row"><span>Bank</span><b>' + formatCurrency(d.bankPaid) + '</b></div>' : '') +
                    (d.debtAdded !== 0 ? '<div class="a4-debt-row"><span>' + (d.isReturn ? 'کەمبوونەوە' : 'قەرزی نوی') + '</span><b class="a4-debt-new">' + formatCurrency(d.debtAdded) + '</b></div>' : '') +
                    (d.previousDebt != 0 ? '<div class="a4-debt-row"><span>قەرزی پێشوو</span><b>' + formatCurrency(d.previousDebt) + '</b></div>' : '') +
                    '<div class="a4-debt-row a4-debt-row-total"><span>کۆیا قەرز</span><b>' + formatCurrency(d.totalOutstandingDebt) + '</b></div></div>';
            }
            return '<div class="a4-totals-panel a4-totals-panel--company">' +
                '<div class="a4-grand-total a4-grand-total--company"><span>' + (d.isReturn ? 'کۆی زڤڕاندن' : 'کۆی گشتی') + '</span><strong>' + formatCurrency(d.grandTotal) + ' ' + d.currency + '</strong></div>' +
                debtHtml + '</div>';
        }
        function buildCompanyA4NotesFooterHtml(d) {
            return '<div class="a4-notes-block a4-notes-block--company a4-notes-block--compact">' +
                (d.invoiceNote ? '<p class="a4-note-line">' + d.invoiceNote + '</p>' : '') +
                '<div class="a4-sigs-company-inline"><span>ئیمزا مۆرد: ______</span><span>ئیمزا وەرگر: ______</span></div></div>';
        }
        function buildCompanyPurchaseA4Classic(d) {
            var rows = buildCompanyA4ItemRows(d);
            var retMod = d.isReturn ? ' invoice-a4-company--return' : '';
            var headCols = buildCompanyA4TableHead(d);
            var heroLogo = (typeof buildA4PngHeroLogoHtml === 'function')
                ? buildA4PngHeroLogoHtml(d, { className: 'a4-png-hero a4-png-hero--company' })
                : '';
            return '<div class="print-a4-container invoice-a4-company invoice-a4-company-classic a4-invoice-compact' + retMod + '" style="font-family:' + companyA4Font() + ';">' +
                heroLogo +
                buildCompanyA4CompactHeader(d, 0) +
                '<div class="a4-table-wrap a4-table-wrap--company"><table class="inv-table a4-items-table a4-items-company"><thead><tr>' + headCols + '</tr></thead><tbody>' + rows + '</tbody></table></div>' +
                '<div class="a4-bottom-split a4-bottom-split--company">' + buildCompanyA4NotesFooterHtml(d) + buildCompanyA4TotalsHtml(d) + '</div></div>';
        }
        function buildCompanyPurchaseA4Minimal(d) {
            var rows = buildCompanyA4ItemRows(d);
            var retMod = d.isReturn ? ' invoice-a4-company--return' : '';
            var headCols = buildCompanyA4TableHead(d);
            var heroLogo = (typeof buildA4PngHeroLogoHtml === 'function')
                ? buildA4PngHeroLogoHtml(d, { className: 'a4-png-hero a4-png-hero--company' })
                : '';
            return '<div class="print-a4-container invoice-a4-company invoice-a4-company-minimal a4-invoice-compact' + retMod + '" style="font-family:' + companyA4Font() + ';">' +
                heroLogo +
                buildCompanyA4CompactHeader(d, 0) +
                '<div class="a4-table-wrap a4-table-wrap--company-min"><table class="inv-table a4-items-table a4-items-company-min"><thead><tr>' + headCols + '</tr></thead><tbody>' + rows + '</tbody></table></div>' +
                '<div class="a4-bottom-split a4-bottom-split--company">' + buildCompanyA4NotesFooterHtml(d) + buildCompanyA4TotalsHtml(d) + '</div></div>';
        }
        function buildCompanyPurchaseA4Design3(d) {
            if (typeof buildA4InvoiceProHtml === 'function') {
                return buildA4InvoiceProHtml(d, { variant: 'company' });
            }
            return buildCompanyPurchaseA4Classic(d);
        }
        function buildCompanyPurchaseA4Html(validRows, company, paymentType, cfg, printMeta, opts) {
            var d = buildCompanyA4PurchaseData(validRows, company, paymentType, printMeta, opts);
            var design = String((cfg && cfg.design) || '1');
            if (design === '2') return buildCompanyPurchaseA4Minimal(d);
            if (design === '8') return buildCompanyPurchaseA4Design3(d);
            return buildCompanyPurchaseA4Classic(d);
        }
        function printPurchaseInvoiceA4(validRows, company, paymentType, cfg, printMeta) {
            var html = buildCompanyPurchaseA4Html(validRows, company, paymentType, cfg, printMeta, { isReturn: false });
            var doA4Print = function() {
                if (typeof printContent === 'function') printContent(html, { fast: true, docType: 'purchase_invoice' });
            };
            if (typeof whenPrintFrameReady === 'function') whenPrintFrameReady(doA4Print, 2500);
            else doA4Print();
        }

        /** Build and print purchase return invoice. */
        function printPurchaseReturnInvoice(validRows, company, invoiceRef, internalId) {
            if (!validRows || !validRows.length || !company) return;
            var roundM3 = typeof roundMoney === 'function' ? roundMoney : function(x){ return Math.round(Number(x)); };
            var grandTotal = 0;
            var rowsHtml = validRows.map(function(row) {
                var lineTotal = roundM3(Math.max(0, (row.qty || 0) * (row.costPerUnit || 0) - (row.discount || 0)));
                grandTotal = roundM3(grandTotal + lineTotal);
                var ul = getProductUnitLabel(row.productRef || row, row.unit || 'piece');
                return '<tr><td class="row-item">' + escapeHtml(row.productName || 'ئایتم') + ' <br><small>(' + ul + ')</small></td><td class="row-qty">' + (row.qty || 0) + '</td><td class="row-price" style="text-align:left">' + formatCurrency(lineTotal) + '</td></tr>';
            }).join('');

            var companyCurrent = (db && db.companies && db.companies.find) ? (db.companies.find(function(c){ return (company.id && c.id == company.id) || (c.name && company.name && c.name === company.name); }) || company) : company;
            var companyBalance = parseFloat(companyCurrent?.balance || 0) || 0;
            var finSplit = typeof getPurchaseReturnFinancialSplit === 'function'
                ? getPurchaseReturnFinancialSplit(grandTotal, null, company.name || '', invoiceRef)
                : { paymentType: 'credit', debtAdjusted: grandTotal, cashRefunded: 0 };
            var debtAdded = finSplit.debtAdjusted > 0 ? -finSplit.debtAdjusted : 0;
            var cashPaid = finSplit.cashRefunded || 0;
            var previousDebt = companyBalance;
            var totalOutstandingDebt = roundM3(companyBalance - (finSplit.debtAdjusted || 0));
            
            var cfg = typeof getPrintConfig === 'function' ? getPrintConfig('purchase_return') : { paper: '80mm', design: '1' };
            
            // If A4 is selected, use A4 specific layout
            if (cfg.paper === '210mm' || cfg.paper === 'A4') {
                var retHtml = buildCompanyPurchaseA4Html(validRows, company, 'return', cfg, { internalId: internalId, supplierInvoiceNumber: invoiceRef }, { isReturn: true, invoiceRef: invoiceRef, internalId: internalId });
                if (typeof printContent === 'function') printContent(retHtml, { docType: 'purchase_return' });
                return;
            }

            var thermalLogoHtml = typeof getThermalLogoHtml === 'function' ? getThermalLogoHtml() : ((typeof getPosShopLogoUrl === 'function' && getPosShopLogoUrl()) ? '<img src="' + getPosShopLogoUrl() + '" class="thermal-logo">' : '');
            var thermalFontClasses = typeof getThermalFontClasses === 'function' ? getThermalFontClasses() : '';
            var locale = typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ';
            
            var html = '<div class="print-thermal-container design-' + (cfg.design || '1') + thermalFontClasses + '" style="max-width: ' + (cfg.paper || '80mm') + '; width: 100%;">' +
                thermalLogoHtml +
                '<div class="thermal-header"><h1>' + (db.settings && db.settings.cafeName ? escapeHtml(db.settings.cafeName) : 'Store') + '</h1><p>' + (db.settings && db.settings.cafeInfo ? escapeHtml(db.settings.cafeInfo) : '') + '</p></div>' +
                '<div class="thermal-divider"></div>' +
                '<h3 style="margin:5px 0; background:#fff7ed; border:1px solid #f97316; color:#9a3412; padding:5px; border-radius:4px;">' + (typeof t === 'function' ? t('print_purchase_return') : 'زڤڕاندن بۆ کۆمپانیێ (Purchase Return)') + '</h3>' +
                '<div class="thermal-info"><span>' + (typeof t === 'function' ? t('print_date') : 'بەروار') + ':</span> <span>' + new Date().toLocaleString(locale) + '</span></div>' +
                '<div class="thermal-info"><span>' + (typeof t === 'function' ? t('print_supplier') : 'مۆرد') + ':</span> <span>' + escapeHtml(company.name || '') + '</span></div>' +
                '<div class="thermal-info"><span>ژمارا مە:</span> <span>#' + (internalId || '---') + '</span></div>' +
                '<div class="thermal-info"><span>پسوولا کۆمپانیێ:</span> <span>' + (invoiceRef || '---') + '</span></div>' +
                '<div class="thermal-divider"></div>' +
                '<table class="thermal-table print-unified-table"><thead><tr><th style="text-align:right">' + (typeof t === 'function' ? t('th_item') : 'ئایتم') + '</th><th style="text-align:center">' + (typeof t === 'function' ? t('th_qty') : 'ژ') + '</th><th style="text-align:left">' + (typeof t === 'function' ? t('th_total') : 'کۆیا بهای') + '</th></tr></thead><tbody>' + rowsHtml + '</tbody></table>' +
                '<div class="thermal-divider" style="opacity:1; border-top:2px solid #000;"></div>' +
                '<div class="grand-total" style="background:#fff7ed; color:#9a3412; border-color:#f97316;">' + (typeof t === 'function' ? t('print_return_total') : 'کۆیا زڤڕاندنێ') + ': ' + formatCurrency(grandTotal) + ' ' + (typeof getCurrencySymbol === 'function' ? getCurrencySymbol() : '') + '</div>' +
                '<div style="margin-top:8px; background:#f8fafc; border:1px dashed #cbd5e1; border-radius:10px; padding:10px;">' +
                    '<div style="display:flex; justify-content:space-between; gap:10px; font-size:0.9rem; color:#64748b;"><span>کۆیا گشتی (Grand Total):</span><b style="color:#0f172a;">' + formatCurrency(grandTotal) + '</b></div>' +
                    (finSplit.debtAdjusted > 0 ? '<div style="display:flex; justify-content:space-between; gap:10px; font-size:0.9rem; color:#64748b; margin-top:6px;"><span>کێمکرنا قەرزی:</span><b style="color:#dc2626;">' + formatCurrency(finSplit.debtAdjusted) + '</b></div>' : '') +
                    '<div style="display:flex; justify-content:space-between; gap:10px; font-size:0.9rem; color:#64748b; margin-top:6px;"><span>قەرزی پێشوو:</span><b style="color:#0f172a;">' + formatCurrency(previousDebt) + '</b></div>' +
                    '<div style="display:flex; justify-content:space-between; gap:10px; font-size:0.95rem; color:#64748b; margin-top:6px; border-top:1px solid #e2e8f0; padding-top:8px;"><span>کۆیا قەرزی:</span><b style="color:#0f172a;">' + formatCurrency(totalOutstandingDebt) + '</b></div>' +
                '</div>' +
                '<div class="thermal-divider"></div>' +
                '<div class="thermal-info" style="font-weight:bold;"><span>' + (typeof t === 'function' ? t('print_cashier') : 'کاشێر') + ':</span> <span>' + ((typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : 'System') + '</span></div>' +
                '<div class="thermal-footer">' + (typeof buildPosReceiptBrandFooterHtml === 'function' ? buildPosReceiptBrandFooterHtml() : '') + '</div>' +
                '</div>';
            if (typeof printContent === 'function') printContent(html, { docType: 'purchase_return' });
        }

        function buildPurchaseReturnInvoiceA4Classic(validRows, company, invoiceRef, cfg, internalId) {
            return buildCompanyPurchaseA4Html(validRows, company, 'return', cfg, { internalId: internalId, supplierInvoiceNumber: invoiceRef }, { isReturn: true, invoiceRef: invoiceRef, internalId: internalId });
        }
        function buildPurchaseReturnInvoiceA4Minimal(validRows, company, invoiceRef, cfg, internalId) {
            var c = cfg || { paper: '210mm', design: '2' };
            c.design = '2';
            return buildCompanyPurchaseA4Html(validRows, company, 'return', c, { internalId: internalId, supplierInvoiceNumber: invoiceRef }, { isReturn: true, invoiceRef: invoiceRef, internalId: internalId });
        }
        function buildCompanyPurchaseA4FromSupplies(supplyItems, company, txnId, invNum) {
            if (!supplyItems || !supplyItems.length) return '';
            var validRows = supplyItems.map(function(s) {
                var qty = parseFloat(s.qtyAdded) || 0;
                var total = parseFloat(s.totalCost) || 0;
                var isGift = (typeof window.isSupplyItemGift === 'function')
                    ? window.isSupplyItemGift(s)
                    : !!(s && (s.isGift === true || s.is_gift === 1 || s.is_gift === '1' || s.is_gift === true));
                return {
                    productName: s.itemName || '',
                    qty: qty,
                    costPerUnit: isGift ? 0 : (qty ? (total / qty) : 0),
                    discount: 0,
                    unit: 'piece',
                    isGift: isGift
                };
            });
            var txType = (supplyItems[0].type || '').toString();
            var isReturn = txType === 'return';
            var docKey = isReturn ? 'purchase_return' : 'purchase_invoice';
            var cfg = (typeof getPrintConfig === 'function') ? getPrintConfig(docKey) : { paper: '210mm', design: '1' };
            var paymentType = txType === 'credit' ? 'credit' : (txType === 'return' ? 'return' : 'cash');
            var resolvedInv = typeof resolveCompanyInvoiceDisplayNumber === 'function'
                ? resolveCompanyInvoiceDisplayNumber(invNum, txnId)
                : (invNum || txnId);
            return buildCompanyPurchaseA4Html(validRows, company, paymentType, cfg, { internalId: txnId, supplierInvoiceNumber: resolvedInv }, { isReturn: isReturn, invoiceRef: invNum, internalId: txnId });
        }
        if (typeof window !== 'undefined') {
            window.buildCompanyPurchaseA4Html = buildCompanyPurchaseA4Html;
            window.buildCompanyA4PurchaseData = buildCompanyA4PurchaseData;
            window.buildCompanyPurchaseA4FromSupplies = buildCompanyPurchaseA4FromSupplies;
        }
