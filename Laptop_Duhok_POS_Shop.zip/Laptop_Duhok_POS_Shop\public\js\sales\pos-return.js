// sales/pos-return.js — POS sales return
        function processReturnTransaction() {
            const table = db.tables.find(t => t.id === activeTableId);
            if (!table || table.items.length === 0) return;
            
            const total = (typeof roundMoney === 'function' ? roundMoney : function(x){return x;})(table.items.reduce(function(a, b) {
                var u = typeof getBillLineUnitIqd === 'function' ? getBillLineUnitIqd(b) : (parseFloat(b.price) || 0);
                return a + u * getItemQty(b);
            }, 0));
            var finalNote = "زڤڕاندن (Return)";

            const debtSel = document.getElementById('returns-debt-select');
            const debtCustVal = debtSel && debtSel.value ? String(debtSel.value).trim() : '';
            const parsedTarget = (typeof parseReturnsTargetId === 'function') ? parseReturnsTargetId(debtCustVal) : { id: parseInt((debtCustVal.split('_')[1] || '0'), 10) || 0, type: debtCustVal.split('_')[0] || 'customer' };
            const invRef = document.getElementById('returns-new-invoice-ref');
            const saleIdNum = invRef && invRef.value ? parseInt(invRef.value, 10) : 0;
            const linkedSale = saleIdNum > 0 && db.sales ? db.sales.find(function(s) { return String(s.id) === String(saleIdNum); }) : null;
            const finSplit = (typeof getSaleReturnFinancialSplit === 'function') ? getSaleReturnFinancialSplit(total, linkedSale) : { effectivePaymentMethod: parsedTarget.id > 0 ? 'debt' : 'cash', debtAdjusted: 0, cashRefunded: total };
            var payMethodSend = finSplit.effectivePaymentMethod;
            var targetIdSend = 0;
            var targetTypeSend = '';
            if (linkedSale && (parseInt(linkedSale.customer_id, 10) || 0) > 0) {
                targetIdSend = parseInt(linkedSale.customer_id, 10) || 0;
                targetTypeSend = linkedSale.customer_type || 'customer';
            } else if (parsedTarget.id > 0) {
                targetIdSend = parsedTarget.id;
                targetTypeSend = parsedTarget.type || 'customer';
                if (!linkedSale) payMethodSend = 'debt';
            } else {
                payMethodSend = 'cash';
            }

            const formData = new FormData();
            formData.append('action', 'save_return');
            formData.append('total', total);
            formData.append('items', JSON.stringify(table.items));
            formData.append('cashier', currentUser ? currentUser.name : 'System');
            formData.append('note', finalNote);
            if (saleIdNum > 0) formData.append('sale_id', String(saleIdNum));
            formData.append('payment_method', payMethodSend);
            if (saleIdNum > 0 && linkedSale) {
                var fxBundle = Math.round(Number(linkedSale.fx_usd_rate) || 0);
                if (!(fxBundle >= 1000) && linkedSale.exchange_rate != null) {
                    var erOne = Number(linkedSale.exchange_rate);
                    if (isFinite(erOne) && erOne > 0) {
                        fxBundle = (erOne >= 10000) ? Math.round(erOne) : Math.round(erOne * 100);
                    }
                }
                if (fxBundle >= 1000) formData.append('fx_usd_rate', String(fxBundle));
                var fxModeSend = String(linkedSale.fx_currency_mode || '').toUpperCase();
                if (fxModeSend === 'USD' || fxModeSend === 'IQD') formData.append('fx_currency_mode', fxModeSend);
            }
            if (targetIdSend > 0) {
                formData.append('target_id', String(targetIdSend));
                formData.append('target_type', targetTypeSend || 'customer');
            }

            fetch('?action=save_return', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                if(data.status === 'success') {
                    // Capture items for local update BEFORE clearing
                    const returnedItems = [...table.items];

                    const savedRet = {
                        id: data.id,
                        date: new Date().toISOString(),
                        items: returnedItems,
                        total: total,
                        note: finalNote,
                        cashier: currentUser ? currentUser.name : 'System',
                        target_id: targetIdSend,
                        target_type: targetTypeSend,
                        payment_method: data.payment_method || payMethodSend,
                        debt_adjusted: data.debt_adjusted != null ? data.debt_adjusted : finSplit.debtAdjusted,
                        cash_refunded: data.cash_refunded != null ? data.cash_refunded : finSplit.cashRefunded,
                        sale_id: saleIdNum > 0 ? saleIdNum : null,
                        fx_usd_rate: (linkedSale && linkedSale.fx_usd_rate != null)
                            ? Math.round(Number(linkedSale.fx_usd_rate))
                            : null,
                        fx_currency_mode: (linkedSale && (linkedSale.fx_currency_mode === 'USD' || linkedSale.fx_currency_mode === 'IQD'))
                            ? String(linkedSale.fx_currency_mode).toUpperCase()
                            : null,
                        exchange_rate: (linkedSale && linkedSale.exchange_rate != null) ? Number(linkedSale.exchange_rate) : null
                    };

                    if (db.settings && db.settings.autoPrint) {
                        const rc = typeof getPrintConfig === 'function' ? getPrintConfig('return_receipt') : { design: '1', paper: '80mm' };
                        const isA4 = (rc.paper === '210mm' || rc.paper === 'A4');
                        const html = isA4 ? buildReturnReceiptA4Html(savedRet, '') : buildReturnReceiptThermalHtml(savedRet, '');
                        printContent(html, { docType: 'return_receipt' });
                    }

                    // Clear Table
                    table.items = [];
                    lastTableState = "";
                    renderBill();
                    isReturnMode = false;
                    updatePOSModeUI();
                    
                    // Sync
                    const fd = new FormData();
                    fd.append('action', 'update_table_items');
                    fd.append('id', activeTableId);
                    fd.append('items', '[]');
                    fetch('?action=update_table_items', { method: 'POST', body: fd });
                    
                    // Update Local Stock Immediately
                    returnedItems.forEach(item => {
                        const p = db.products.find(x => x.id === item.id);
                        if(p && p.trackStock) {
                            var f = typeof getProductUnitFactors === 'function' ? getProductUnitFactors(item) : { piecesPerPack: 1, piecesPerCarton: 1 };
                            var mult = 1.0;
                            if (item.saleUnit === 'carton') mult = (parseFloat(f.piecesPerCarton) || 1.0);
                            else if (item.saleUnit === 'pack') mult = (parseFloat(f.piecesPerPack) || 1.0);
                            p.qty += (getItemQty(item) * mult);
                        }
                    });
                    if (typeof updateProductCardQty === 'function') {
                        returnedItems.forEach(item => {
                            var p = db.products.find(x => x.id === item.id);
                            if (p) updateProductCardQty(item.id, p.qty, p.trackStock);
                        });
                    }

                    if (data.customer_balance != null && targetIdSend > 0) {
                        var custUp = (db.customers || []).find(function(c) { return Number(c.id) === Number(targetIdSend); });
                        if (custUp) custUp.balance = parseFloat(data.customer_balance) || 0;
                        var usrUp = (db.users || []).find(function(u) { return Number(u.id) === Number(targetIdSend); });
                        if (usrUp) usrUp.balance = parseFloat(data.customer_balance) || 0;
                    } else if (targetIdSend > 0 && (data.debt_adjusted || 0) > 0) {
                        var custUp2 = (db.customers || []).find(function(c) { return Number(c.id) === Number(targetIdSend); });
                        if (custUp2) custUp2.balance = (parseFloat(custUp2.balance) || 0) - (parseFloat(data.debt_adjusted) || 0);
                        var usrUp2 = (db.users || []).find(function(u) { return Number(u.id) === Number(targetIdSend); });
                        if (usrUp2) usrUp2.balance = (parseFloat(usrUp2.balance) || 0) - (parseFloat(data.debt_adjusted) || 0);
                    }

                    alert("✅ زڤڕاندن هاتە ئەنجامدان (Refund Successful).");
                    db.returns.push(savedRet);
                    
                    // Update Stats immediately
                    if(db.today_stats) {
                        db.today_stats.returns = (parseFloat(db.today_stats.returns) || 0) + total;
                    }
                    if (typeof posInvalidateDailyDetailCache === 'function' && typeof getBusinessDate === 'function') {
                        posInvalidateDailyDetailCache(getBusinessDate(new Date()));
                    }
                    updateStats();
                    if (typeof posRefreshOpenFinancialScreens === 'function') posRefreshOpenFinancialScreens();
                    if (typeof renderReturnsReport === 'function') renderReturnsReport();
                    if (typeof renderSalesHistory === 'function') renderSalesHistory();
                    if(document.getElementById('view-warehouse').classList.contains('active')) renderWarehouse();
                    try {
                        if (typeof posFlashScheduleSync === 'function') posFlashScheduleSync('return');
                    } catch (_eFlashRet) {}
                    // Pull fresh server state so changes are visible immediately
                    // if (typeof connectToDB === 'function') {
                    //     setTimeout(function() { connectToDB(true); }, 120);
                    // }
                }
                else {
                    alert("❌ هەڵە: " + (data.message || 'هەڵە د پاراستنێ دا'));
                }
            })
            .catch(err => {
                alert("❌ هەڵە د پەیوەندیێ دا یان سێرڤەر: " + err.message);
            });
        }
