/**
 * UI: theme, sidebar, navigation, breadcrumb, home view.
 * Logic currently lives in app.js; can be moved here gradually.
 */
import { state } from './state.js';

function tr(key, fallback) {
    try {
        if (typeof window !== 'undefined' && typeof window.t === 'function') {
            const val = window.t(key);
            if (val && val !== key) return val;
        }
    } catch (e) {}
    return fallback;
}

export function applyTheme() {
    if (!state.db || !state.db.settings) return;
    if (state.db.settings.theme === 'dark' || !state.db.settings.theme) {
        state.db.settings.theme = 'medical';
    }
    document.body.classList.remove('light-mode', 'medical-mode', 'dark-mode');
    if (state.db.settings.theme === 'light') {
        document.body.classList.add('light-mode');
    } else {
        state.db.settings.theme = 'medical';
        document.body.classList.add('medical-mode');
    }
    const btn = document.getElementById('theme-toggle-btn');
    if (btn) {
        if (state.db.settings.theme === 'light') {
            btn.innerHTML = '<i class="fas fa-sun"></i> ' + tr('settings_theme_light', 'دێمێ ڕۆژێ');
        } else {
            btn.innerHTML = '<i class="fas fa-eye"></i> ' + tr('settings_theme_medical', 'دێمێ پزیشکی');
        }
    }
}

function getZoomTargets() {
    return {
        wrapper: document.getElementById('app-zoom-wrapper'),
        inner: document.getElementById('app-zoom-inner'),
        body: document.getElementById('pos-body') || document.body,
        html: document.documentElement
    };
}

function clearLegacyZoomInline(wrapper, inner, body) {
    if (body) {
        body.style.zoom = '';
        body.style.transform = '';
    }
    if (wrapper) {
        wrapper.style.zoom = '';
        wrapper.style.transform = '';
        wrapper.style.transformOrigin = '';
        wrapper.style.width = '';
        wrapper.style.minWidth = '';
        wrapper.style.height = '';
        wrapper.style.minHeight = '';
        wrapper.style.maxHeight = '';
        wrapper.style.flex = '';
    }
    if (inner) {
        inner.style.zoom = '';
        inner.style.transform = '';
        inner.style.transformOrigin = '';
        inner.style.width = '';
        inner.style.minHeight = '';
        inner.style.height = '';
        inner.style.flex = '';
    }
}

/**
 * Chrome-like UI zoom via CSS --pos-ui-scale on #app-zoom-inner (transform + inverse size).
 * Fills the viewport at any level; modals/FAB outside the wrapper are not scaled.
 */
export function applyZoomLevel(pct) {
    pct = Math.min(150, Math.max(70, parseInt(pct, 10) || 100));
    const scale = pct / 100;
    const targetLabel = pct + '%';
    const { wrapper, inner, body, html } = getZoomTargets();

    clearLegacyZoomInline(wrapper, inner, body);

    if (html) {
        html.style.setProperty('--pos-ui-scale', String(scale));
        html.setAttribute('data-pos-zoom', String(pct));
    }

    try { localStorage.setItem('pos_zoom', String(pct)); } catch (e) {}
    if (state.db && state.db.settings) state.db.settings.zoomLevel = pct;

    const sl = document.getElementById('set-zoom');
    const lb = document.getElementById('zoom-value');
    if (sl && String(sl.value) !== String(pct)) sl.value = pct;
    if (lb && lb.textContent !== targetLabel) lb.textContent = targetLabel;
}

export function adjustZoomLevel(delta) {
    const cur = parseInt(document.documentElement.getAttribute('data-pos-zoom'), 10);
    const base = (isFinite(cur) && cur >= 70) ? cur : 100;
    const next = Math.min(150, Math.max(70, base + (parseInt(delta, 10) || 0)));
    applyZoomLevel(next);
    if (typeof window.saveSettings === 'function') {
        window.saveSettings().catch(function () {});
    }
}

const CART_WIDTH_MIN = 280;
const CART_WIDTH_MAX = 960;
const CART_DENSITY_MIN = 85;
const CART_DENSITY_MAX = 130;

const TXN_CART_VIEWS = [
    { viewId: 'view-pos', billId: 'pos-bill-panel' },
    { viewId: 'view-purchase', billId: 'purchase-cart-panel' },
    { viewId: 'view-purchase-returns', billId: 'purchase-returns-cart-panel' },
    { viewId: 'view-returns-new', billId: 'returns-bill-panel' },
    { viewId: 'view-waste', billId: 'waste-bill-panel' }
];

function getActiveTxnCartEls() {
    for (let i = 0; i < TXN_CART_VIEWS.length; i++) {
        const cfg = TXN_CART_VIEWS[i];
        const view = document.getElementById(cfg.viewId);
        if (!view || !view.classList.contains('active')) continue;
        const layout = view.querySelector('.pos-layout') || view.querySelector('.returns-layout');
        const bill = document.getElementById(cfg.billId);
        if (layout && bill) return { layout, bill, viewId: cfg.viewId, billId: cfg.billId };
    }
    return getPosCartLayoutElsFallback();
}

function getPosCartLayoutElsFallback() {
    const view = document.getElementById('view-pos');
    const layout = (view && (view.querySelector('.pos-layout') || view.querySelector('.returns-layout')))
        || document.querySelector('.pos-layout')
        || document.querySelector('.returns-layout');
    const bill = document.getElementById('pos-bill-panel');
    return { layout, bill, viewId: 'view-pos', billId: 'pos-bill-panel' };
}

function getPosCartLayoutEls() {
    return getActiveTxnCartEls();
}

function clampCartWidth(px) {
    const n = Math.round(parseFloat(px) || 0);
    if (!isFinite(n)) return 380;
    return Math.min(CART_WIDTH_MAX, Math.max(CART_WIDTH_MIN, n));
}

/** Cart row text/controls scale (all txn carts). */
export function applyCartDensity(pct) {
    pct = Math.min(CART_DENSITY_MAX, Math.max(CART_DENSITY_MIN, parseInt(pct, 10) || 100));
    const scale = pct / 100;
    const label = pct + '%';
    document.documentElement.style.setProperty('--pos-cart-density', String(scale));
    document.documentElement.setAttribute('data-cart-density', String(pct));
    try { localStorage.setItem('pos_cart_density', String(pct)); } catch (e) {}
    if (state.db && state.db.settings) state.db.settings.cartDensity = pct;

    const sl = document.getElementById('set-cart-density');
    const lb = document.getElementById('cart-density-value');
    const peek = document.getElementById('pos-cart-density-peek');
    if (sl && String(sl.value) !== String(pct)) sl.value = pct;
    if (lb) lb.textContent = label;
    if (peek) peek.textContent = label;
}

export function adjustCartDensity(delta) {
    const cur = parseInt(document.documentElement.getAttribute('data-cart-density'), 10);
    const base = (isFinite(cur) && cur >= CART_DENSITY_MIN) ? cur : 100;
    applyCartDensity(base + (parseInt(delta, 10) || 0));
}

function readCartPanelWidthPx(layout, bill) {
    const fromInline = (el) => {
        if (!el || !el.style) return NaN;
        return parseFloat(el.style.getPropertyValue('--cart-panel-width'));
    };
    const fromComputed = (el) => {
        if (!el) return NaN;
        try {
            return parseFloat(window.getComputedStyle(el).getPropertyValue('--cart-panel-width'));
        } catch (e) {
            return NaN;
        }
    };
    let n = fromInline(bill);
    if (!isFinite(n) || n <= 0) n = fromInline(layout);
    if (!isFinite(n) || n <= 0) n = fromComputed(bill);
    if (!isFinite(n) || n <= 0) n = fromComputed(layout);
    if (!isFinite(n) || n <= 0) {
        try {
            n = parseFloat(window.getComputedStyle(bill).width);
        } catch (e2) {
            n = NaN;
        }
    }
    if (!isFinite(n) || n <= 0) n = 380;
    return n;
}

function storageKeyForCart(billId) {
    if (billId === 'pos-bill-panel') return 'cart_panel_width_pos';
    if (billId === 'purchase-cart-panel') return 'cart_panel_width_purchase';
    if (billId === 'purchase-returns-cart-panel') return 'cart_panel_width_purchase-returns';
    if (billId === 'returns-bill-panel') return 'cart_panel_width_returns';
    if (billId === 'waste-bill-panel') return 'cart_panel_width_waste';
    return 'cart_panel_width_pos';
}

/** POS / txn cart panel width (desktop drag + settings + header buttons). */
export function applyCartPanelWidthPos(widthPx, opts) {
    opts = opts || {};
    const els = getActiveTxnCartEls();
    let layout = els.layout;
    let bill = els.bill;
    // Hard fallback: always find POS cart if active lookup failed
    if (!bill) bill = document.getElementById('pos-bill-panel');
    if (!layout && bill) {
        layout = bill.closest('.pos-layout') || bill.closest('.returns-layout')
            || document.querySelector('#view-pos .pos-layout');
    }
    if (!layout || !bill) return;
    const w = clampCartWidth(widthPx);
    const wPx = w + 'px';
    const maxLabel = CART_WIDTH_MAX + 'px';
    const minLabel = CART_WIDTH_MIN + 'px';

    layout.style.setProperty('--cart-panel-width', wPx);
    layout.style.setProperty('--cart-panel-max-width', maxLabel);
    layout.style.setProperty('--cart-panel-min-width', minLabel);
    bill.style.setProperty('--cart-panel-width', wPx);
    bill.style.setProperty('--cart-panel-max-width', maxLabel);
    bill.style.setProperty('--cart-panel-min-width', minLabel);

    // Beat stylesheet !important by setting width/flex with important
    if (!bill.classList.contains('expanded')) {
        bill.style.setProperty('flex', '0 0 ' + wPx, 'important');
        bill.style.setProperty('flex-basis', wPx, 'important');
        bill.style.setProperty('width', wPx, 'important');
        bill.style.setProperty('min-width', minLabel, 'important');
        bill.style.setProperty('max-width', maxLabel, 'important');
    }

    const sk = storageKeyForCart(bill.id || els.billId || 'pos-bill-panel');
    try { localStorage.setItem(sk, String(w)); } catch (e) {}
    try { localStorage.setItem('cart_panel_width_pos', String(w)); } catch (e2) {}
    if (state.db && state.db.settings) state.db.settings.cartPanelWidthPos = w;

    const sl = document.getElementById('set-cart-width');
    const lb = document.getElementById('cart-width-value');
    if (sl) {
        if (parseInt(sl.max, 10) < CART_WIDTH_MAX) sl.max = String(CART_WIDTH_MAX);
        if (String(sl.value) !== String(w)) sl.value = w;
    }
    if (lb) lb.textContent = w + 'px';
    const wPeek = document.getElementById('pos-cart-width-peek');
    if (wPeek) wPeek.textContent = w + 'px';

    if (opts.toast !== false && typeof window.showToast === 'function' && opts.fromAdjust) {
        window.showToast('🧺 سەبەتە: ' + w + 'px', 'info');
    }
}

export function adjustCartPanelWidth(delta) {
    const { layout, bill } = getActiveTxnCartEls();
    const b = bill || document.getElementById('pos-bill-panel');
    const l = layout || (b && (b.closest('.pos-layout') || b.closest('.returns-layout')))
        || document.querySelector('#view-pos .pos-layout');
    if (!l || !b) {
        if (typeof window.showToast === 'function') window.showToast('⚠️ سەبەتە نەهاتە دیتن', 'warning');
        return;
    }
    const cur = readCartPanelWidthPx(l, b);
    const next = cur + (parseInt(delta, 10) || 0);
    if (next > CART_WIDTH_MAX && delta > 0) {
        applyCartPanelWidthPos(CART_WIDTH_MAX, { fromAdjust: true });
        return;
    }
    if (next < CART_WIDTH_MIN && delta < 0) {
        applyCartPanelWidthPos(CART_WIDTH_MIN, { fromAdjust: true });
        return;
    }
    applyCartPanelWidthPos(next, { fromAdjust: true });
}

import {
    normalizeGraphicsQuality,
    applyPerformanceDocumentFlags,
    scheduleGraphicsSettingsSave,
    autoConfigureGraphicsQualityIfNeeded,
    markPosGraphicsUserOverride,
    consumeAutoGraphicsNotify,
    hasPosGraphicsUserOverride
} from './performance.js';

export { normalizeGraphicsQuality, scheduleGraphicsSettingsSave };
export {
    isPosUltraGraphicsMode,
    isPosLowGraphicsMode,
    isPosCpuSaveMode,
    isPosLargeCatalogMode,
    isPosLargeShopMode,
    posDbHealthCount,
    posCatalogProductCount,
    posListRenderLimit,
    posEntityPickLimit,
    posEntityPickNeedsQuery,
    posDebouncedListRenderMs,
    shouldPosUseVirtualMenu,
    shouldPosUseLongPoll,
    isPosLanTerminalClient,
    isPosFastLanSync,
    isPosPrivateLanHost,
    posLiveSyncWaitMax,
    posCatalogBootstrapTier,
    posCatalogTierQueryString,
    posPollIntervalMs,
    posAutoRefreshDelayMs,
    posBackgroundRefreshDelayMs,
    posAfterWriteRefreshDelayMs,
    isPosTxnViewActive,
    updatePosTxnActiveClass,
    posLiveSyncDelayMs,
    isPosTxnLiteMode,
    posMaxPosMenuProducts,
    posTxnGridProductLimit,
    posTxnMenuDebounceMs,
    posTxnGridDebounceMs,
    posTxnCartRenderDebounceMs,
    posSkipCustomerDisplaySync,
    posCustomerDisplaySyncMs,
    posStartupDeferMs,
    posCartSaveDebounceMs,
    posLoginDeferMs,
    posLoginChromeDeferMs,
    posDeviceBootstrapWaitMs,
    enforceWeakDeviceGraphicsProfile,
    autoConfigureGraphicsQualityIfNeeded,
    markPosGraphicsUserOverride,
    consumeAutoGraphicsNotify,
    hasPosGraphicsUserOverride
} from './performance.js';

/**
 * UI graphics tier: normal | low (old laptops) | ultra (Gen3 / Celeron).
 * Avoids expensive universal CSS; toggles runtime CPU-saving flags.
 */
export function applyGraphicsQuality(level, options) {
    options = options || {};
    if (options.userChosen) markPosGraphicsUserOverride();
    const q = normalizeGraphicsQuality(level);
    applyPerformanceDocumentFlags(q);
    try { localStorage.setItem('pos_graphics_quality', q); } catch (e) {}
    if (state.db && state.db.settings) state.db.settings.graphicsQuality = q;
    syncGraphicsQualityControls(q);
    if (typeof window !== 'undefined') {
        if (typeof window.posRestartPollsForGraphics === 'function') window.posRestartPollsForGraphics();
        if (typeof window.posRestartLiveSync === 'function') window.posRestartLiveSync();
        if (q !== 'normal' && typeof window.renderHomeView === 'function') {
            const home = document.getElementById('view-home');
            if (home && home.classList.contains('active')) window.renderHomeView();
        }
        if (typeof window.showToast === 'function' && options.userChosen) {
            const msg = typeof window.t === 'function'
                ? window.t('toast_graphics_low')
                : 'گرافیک کەم کرا — سیستەم خێراترە';
            window.showToast(msg, 'info');
        }
    }
}

/** Settings UI: one-click apply low graphics. */
export function posPickGraphicsQuality(level) {
    applyGraphicsQuality(level, { userChosen: true });
    if (typeof scheduleGraphicsSettingsSave === 'function') scheduleGraphicsSettingsSave();
}

function syncGraphicsQualityControls(q) {
    const norm = normalizeGraphicsQuality(q);
    document.querySelectorAll('input[name="pos-graphics-quality"]').forEach(function (r) {
        r.checked = (r.value === norm);
    });
    document.querySelectorAll('.pos-graphics-quality-opt').forEach(function (lab) {
        const inp = lab.querySelector('input[name="pos-graphics-quality"]');
        lab.classList.toggle('is-selected', !!(inp && inp.value === norm));
    });
}

export function initGraphicsQualityFromStorage() {
    const enforced = enforceWeakDeviceGraphicsProfile();
    const autoTier = autoConfigureGraphicsQualityIfNeeded();
    let q = enforced || autoTier || 'low';
    try {
        if (!autoTier) {
            q = normalizeGraphicsQuality(localStorage.getItem('pos_graphics_quality') || 'low');
        }
    } catch (e) { q = 'low'; }
    if (q === 'normal') q = 'low';
    if (hasPosGraphicsUserOverride() && state.db && state.db.settings && state.db.settings.graphicsQuality) {
        q = normalizeGraphicsQuality(state.db.settings.graphicsQuality);
    }
    applyGraphicsQuality(q);
}

export function initCartAppearanceFromStorage() {
    let density = 100;
    try {
        density = parseInt(localStorage.getItem('pos_cart_density'), 10);
        if (!(density >= CART_DENSITY_MIN && density <= CART_DENSITY_MAX)) density = 100;
    } catch (e) { density = 100; }
    if (state.db && state.db.settings && state.db.settings.cartDensity) {
        density = parseInt(state.db.settings.cartDensity, 10) || density;
    }
    applyCartDensity(density);

    try {
        const stored = parseInt(localStorage.getItem('cart_panel_width_pos'), 10);
        if (isFinite(stored) && stored > 0) applyCartPanelWidthPos(stored);
    } catch (e) {}
}
