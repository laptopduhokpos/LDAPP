/**
 * Offline Font Awesome helpers + lightweight UI icon pass (no extra network, minimal GPU).
 */

const POS_I18N_ICON_MAP = {
    btn_cancel: 'fa-times',
    del_btn_cancel: 'fa-times',
    shift_opening_later: 'fa-clock',
    shift_opening_confirm: 'fa-check',
    save_close_session: 'fa-check-double',
    btn_save: 'fa-save',
    btn_delete: 'fa-trash-alt',
    btn_edit: 'fa-pen',
    btn_add: 'fa-plus',
    btn_search: 'fa-search',
    btn_print: 'fa-print',
    btn_export: 'fa-file-export',
    btn_refresh: 'fa-sync',
    btn_filter: 'fa-filter',
    login_btn_main: 'fa-sign-in-alt',
    settings_end_shift: 'fa-stop-circle',
    settings_end_shift_btn: 'fa-stop-circle',
    nav_staff: 'fa-user-tie',
    print_customer: 'fa-user',
    debt_tab_customers: 'fa-users',
    debt_tab_staff: 'fa-id-badge',
    wh_col_name: 'fa-box',
    wh_col_min: 'fa-arrow-down',
    wh_col_expiry: 'fa-calendar-times',
    wh_col_status: 'fa-traffic-light',
    wh_kpi_total_cost: 'fa-coins',
    wh_kpi_total_sale: 'fa-tags',
    wh_kpi_expected_profit: 'fa-chart-line',
    wh_kpi_alert_title: 'fa-bell',
    wh_kpi_out_title: 'fa-ban',
    wh_kpi_expiring_title: 'fa-calendar-times',
    wh_page_tagline: 'fa-info-circle',
    wh_tasks_heading: 'fa-th-large',
    wh_alerts_heading: 'fa-bell',
    wh_print_list: 'fa-print',
    wh_print_zero_items: 'fa-ban',
    products_tbl_barcode: 'fa-barcode',
    products_tbl_category: 'fa-layer-group',
    products_tbl_cost: 'fa-coins',
    products_tbl_price: 'fa-tag',
    products_tbl_item: 'fa-box-open',
    products_tbl_stock: 'fa-cubes',
    th_qty: 'fa-sort-numeric-down',
    waste_th_item: 'fa-box',
    waste_th_stock: 'fa-warehouse',
    waste_th_expiry: 'fa-calendar-alt',
    waste_th_qty: 'fa-sort-numeric-down',
    waste_th_cost: 'fa-coins',
    waste_th_reason: 'fa-question-circle',
    waste_th_staff: 'fa-user',
    waste_th_date: 'fa-calendar-day',
    waste_th_action: 'fa-hand-pointer',
    profile_th_date: 'fa-calendar',
    profile_th_item: 'fa-receipt',
    profile_th_total: 'fa-money-bill-wave',
    profile_th_note: 'fa-sticky-note',
    profile_th_amount: 'fa-coins',
    profile_shift_th_date: 'fa-calendar-day',
    profile_shift_th_start: 'fa-play',
    profile_shift_th_end: 'fa-stop',
    profile_shift_th_duration: 'fa-hourglass-half',
    profile_shift_th_salary: 'fa-wallet',
    staff_th_name: 'fa-user',
    staff_th_shift_start: 'fa-play-circle',
    staff_th_shift_end: 'fa-stop-circle',
    staff_th_sales_work: 'fa-chart-line',
    gh_th_id: 'fa-hashtag',
    reports_btn_daily: 'fa-sun',
    reports_btn_monthly: 'fa-calendar-alt',
    reports_btn_debt: 'fa-file-invoice-dollar',
    rollback_btn_custom: 'fa-undo',
    product_form_layout_reset: 'fa-undo-alt',
    daily_reconcile: 'fa-cash-register',
    payment_modal_title: 'fa-hand-holding-usd'
};

function posIconFromI18nKey(key) {
    if (!key) return null;
    if (POS_I18N_ICON_MAP[key]) return POS_I18N_ICON_MAP[key];
    const k = String(key).toLowerCase();
    if (k.indexOf('cancel') >= 0 || k.indexOf('close') >= 0 || k.indexOf('later') >= 0) return 'fa-times';
    if (k.indexOf('confirm') >= 0 || k.indexOf('save') >= 0 || k.indexOf('submit') >= 0) return 'fa-check';
    if (k.indexOf('delete') >= 0 || k.indexOf('remove') >= 0) return 'fa-trash-alt';
    if (k.indexOf('print') >= 0) return 'fa-print';
    if (k.indexOf('search') >= 0 || k.indexOf('find') >= 0) return 'fa-search';
    if (k.indexOf('add') >= 0 || k.indexOf('new') >= 0) return 'fa-plus';
    if (k.indexOf('edit') >= 0) return 'fa-pen';
    if (k.indexOf('barcode') >= 0) return 'fa-barcode';
    if (k.indexOf('expiry') >= 0 || k.indexOf('date') >= 0 || k.indexOf('calendar') >= 0) return 'fa-calendar-alt';
    if (k.indexOf('staff') >= 0 || k.indexOf('user') >= 0 || k.indexOf('cashier') >= 0) return 'fa-user';
    if (k.indexOf('customer') >= 0 || k.indexOf('debt') >= 0) return 'fa-users';
    if (k.indexOf('qty') >= 0 || k.indexOf('quantity') >= 0 || k.indexOf('count') >= 0) return 'fa-sort-numeric-down';
    if (k.indexOf('price') >= 0 || k.indexOf('amount') >= 0 || k.indexOf('total') >= 0 || k.indexOf('cost') >= 0) return 'fa-coins';
    if (k.indexOf('warehouse') >= 0 || k.indexOf('stock') >= 0) return 'fa-warehouse';
    if (k.indexOf('item') >= 0 || k.indexOf('product') >= 0) return 'fa-box';
    if (k.indexOf('phone') >= 0) return 'fa-phone';
    if (k.indexOf('note') >= 0) return 'fa-sticky-note';
    if (k.indexOf('action') >= 0 || k.indexOf('work') >= 0) return 'fa-cog';
    if (k.indexOf('shift') >= 0) return 'fa-clock';
    if (k.indexOf('report') >= 0) return 'fa-chart-bar';
    if (k.indexOf('payment') >= 0 || k.indexOf('pay') >= 0) return 'fa-money-bill-wave';
    if (k.indexOf('rollback') >= 0 || k.indexOf('undo') >= 0 || k.indexOf('return') >= 0) return 'fa-undo';
    return null;
}

export function posIconHtml(iconClass, extraClass) {
    if (!iconClass) return '';
    const cls = iconClass.indexOf('fa-') === 0 ? iconClass : ('fa-' + iconClass);
    const fam = cls.indexOf('fa-brands') >= 0 || cls.indexOf('fab') >= 0 ? 'fab' : 'fas';
    const ic = cls.replace(/^fa[sbr]?\s+/, '');
    return '<i class="' + fam + ' ' + ic + ' pos-ic' + (extraClass ? (' ' + extraClass) : '') + '" aria-hidden="true"></i> ';
}

function posInsertIconBefore(el, iconClass) {
    if (!el || !iconClass || el.querySelector('i.fas, i.far, i.fab, i.fa-solid, i.fa-regular')) return;
    const i = document.createElement('i');
    const fam = iconClass.indexOf('fa-brands') >= 0 ? 'fab' : 'fas';
    i.className = fam + ' ' + iconClass.replace(/^fa[sbr]?\s+/, '') + ' pos-ic' + (el.tagName === 'TH' ? ' pos-ic--th' : '');
    i.setAttribute('aria-hidden', 'true');
    el.insertBefore(i, el.firstChild);
    if (el.childNodes.length > 1) el.insertBefore(document.createTextNode(' '), el.childNodes[1]);
}

/** One-pass enhancement for buttons/headers missing icons (idle callback, weak-laptop safe). */
export function posEnhanceUiIcons() {
    const root = document.getElementById('app-zoom-wrapper') || document.body;
    if (!root) return;

    root.querySelectorAll('button.btn, a.btn, .btn[role="button"]').forEach(function (btn) {
        if (btn.dataset.posIcDone === '1') return;
        if (btn.querySelector('i.fas, i.far, i.fab, i.fa-solid, i.fa-regular')) {
            btn.dataset.posIcDone = '1';
            return;
        }
        const i18nEl = btn.querySelector('[data-i18n]');
        const key = i18nEl ? i18nEl.getAttribute('data-i18n') : null;
        const ic = posIconFromI18nKey(key);
        if (ic) posInsertIconBefore(btn, ic);
        btn.dataset.posIcDone = '1';
    });

    root.querySelectorAll('table thead th').forEach(function (th) {
        if (th.dataset.posIcDone === '1') return;
        if (th.querySelector('i.fas, i.far, i.fab')) {
            th.dataset.posIcDone = '1';
            return;
        }
        let key = th.getAttribute('data-i18n');
        if (!key) {
            const inner = th.querySelector('[data-i18n]');
            if (inner) key = inner.getAttribute('data-i18n');
        }
        const ic = posIconFromI18nKey(key);
        if (ic) posInsertIconBefore(th, ic);
        th.dataset.posIcDone = '1';
    });

    root.querySelectorAll('.setting-toggle-card').forEach(function (card) {
        if (card.dataset.posIcDone === '1') return;
        const inp = card.querySelector('input[type="checkbox"][id]');
        if (!inp || card.querySelector('i.fas')) {
            card.dataset.posIcDone = '1';
            return;
        }
        const ic = posIconFromI18nKey(inp.id.replace(/^set-/, 'settings_').replace(/-/g, '_'));
        if (ic) {
            const title = card.querySelector('div[style*="font-weight"]');
            if (title) posInsertIconBefore(title, ic);
        }
        card.dataset.posIcDone = '1';
    });
}

export function schedulePosEnhanceIcons() {
    const run = function () {
        try { posEnhanceUiIcons(); } catch (e) { console.warn('posEnhanceUiIcons', e); }
    };
    const delay = (typeof window.isPosCpuSaveMode === 'function' && window.isPosCpuSaveMode()) ? 2200 : 600;
    if (typeof requestIdleCallback === 'function') {
        requestIdleCallback(run, { timeout: delay + 2000 });
    } else {
        setTimeout(run, delay);
    }
}
