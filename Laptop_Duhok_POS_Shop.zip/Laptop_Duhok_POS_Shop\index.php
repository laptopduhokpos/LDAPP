<?php
/**
 * LP DUHOK POS - Main Router
 */

if (file_exists(__DIR__ . '/config/cors.php')) {
    require_once __DIR__ . '/config/cors.php';
}

if (!function_exists('pos_api_cors_apply_headers')) {
    function pos_api_cors_apply_headers() {
        if (headers_sent()) return;
        $origin = isset($_SERVER['HTTP_ORIGIN']) ? trim((string)$_SERVER['HTTP_ORIGIN']) : '';
        if ($origin !== '') {
            header('Access-Control-Allow-Origin: ' . $origin);
            header('Vary: Origin');
            header('Access-Control-Allow-Credentials: true');
        } else {
            header('Access-Control-Allow-Origin: *');
        }
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
        $reqHdr = isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']) ? trim((string)$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']) : '';
        if ($reqHdr !== '') {
            header('Access-Control-Allow-Headers: ' . $reqHdr);
        } else {
            header('Access-Control-Allow-Headers: Content-Type, X-Requested-With, X-Debug-Session-Id, X-POS-Language, X-POS-Mobile-Pin, Authorization, Accept, Accept-Language');
        }
        header('Access-Control-Max-Age: 86400');
    }
}

if (!function_exists('pos_api_cors_handle_options_and_exit')) {
    function pos_api_cors_handle_options_and_exit() {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'OPTIONS') {
            return false;
        }
        pos_api_cors_apply_headers();
        header('Content-Length: 0');
        http_response_code(204);
        return true;
    }
}

if (function_exists('pos_api_cors_handle_options_and_exit') && pos_api_cors_handle_options_and_exit()) {
    exit();
}

// 1. DB connection + automatic schema migrations (config/database.php → migrations.php)
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/core.php';
require_once __DIR__ . '/config/version.php';

// 2. API Routing (Backend)
if (isset($_GET['action']) || (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']))) {
    
    // Buffer output for API so no PHP notices/warnings corrupt JSON response
    ob_start();
    
    // For now, all API logic is in api/all.php to preserve exact functionality and avoid breaking the system
    require_once __DIR__ . '/api/all.php';
    
    exit();
}

// 3. View Routing (Frontend) — never cache HTML shell so JS/CSS ?v= and PHP updates apply immediately
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

if (isset($_GET['view']) && $_GET['view'] == 'customer') {
    require_once __DIR__ . '/views/customer_display.php';
} elseif (isset($_GET['view']) && in_array($_GET['view'], ['mobile', 'mobile_entry', 'entry', 'ld_manager'])) {
    header('Location: _PRIVATE/mobile_manager/index.html#entry');
    exit();
} else {
    require_once __DIR__ . '/views/pos_main.php';
}
