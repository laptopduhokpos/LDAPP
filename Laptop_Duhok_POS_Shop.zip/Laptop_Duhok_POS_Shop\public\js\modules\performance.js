/**
 * CPU-saving profile for low-end laptops (Gen3 / Celeron).
 * Used when graphics quality is "ultra" or "low".
 */

let _graphicsSaveTimer = null;

const GFX_AUTO_KEY = 'pos_graphics_auto_v1';
const GFX_AUTO_REFINED_KEY = 'pos_graphics_auto_refined_v2';
const GFX_USER_OVERRIDE_KEY = 'pos_graphics_user_override';
const GFX_TOAST_KEY = 'pos_graphics_auto_toast_v1';

export function normalizeGraphicsQuality(level) {
    const v = String(level || '').toLowerCase().trim();
    if (v === 'normal' || v === 'ultra' || v === 'low') return 'low';
    return 'low';
}

function graphicsQualityFromStorage() {
    try {
        return normalizeGraphicsQuality(localStorage.getItem('pos_graphics_quality'));
    } catch (e) {
        return 'low';
    }
}

function currentGraphicsQuality() {
    if (typeof window !== 'undefined' && window.POS_GRAPHICS_QUALITY) {
        return normalizeGraphicsQuality(window.POS_GRAPHICS_QUALITY);
    }
    return graphicsQualityFromStorage();
}

/** Large shops (2000+ items): extra CPU-saving without hiding data — search/load-more still reach full catalog. */
export function posDbHealthCount(key) {
    if (typeof window === 'undefined') return 0;
    const db = window.db;
    if (!db) return 0;
    const h = db._db_health || {};
    if (h[key] != null) {
        const n = parseInt(h[key], 10);
        if (Number.isFinite(n) && n >= 0) return n;
    }
    const fallbacks = {
        products_count: 'products',
        sales_count: 'sales',
        customers_count: 'customers',
        companies_count: 'companies',
        supplies_count: 'supplies'
    };
    const field = fallbacks[key];
    if (field && Array.isArray(db[field])) return db[field].length;
    return 0;
}

export function posCatalogProductCount() {
    const n = posDbHealthCount('products_count');
    if (n > 0) return n;
    if (typeof window !== 'undefined' && window.db && Array.isArray(window.db.products)) {
        return window.db.products.length;
    }
    return 0;
}

export function isPosLargeCatalogMode() {
    return posCatalogProductCount() >= 1000;
}

/**
 * Busy markets: many sales, customers, companies, purchases — not only product count.
 * Keeps POS/reports responsive on weak laptops; full data stays on server + search/load-more.
 */
export function isPosLargeShopMode() {
    if (isPosLargeCatalogMode()) return true;
    if (posDbHealthCount('sales_count') >= 2500) return true;
    if (posDbHealthCount('customers_count') >= 350) return true;
    if (posDbHealthCount('companies_count') >= 120) return true;
    if (posDbHealthCount('supplies_count') >= 1500) return true;
    return false;
}

/** Max cards rendered in debt / companies grids (search shows more). */
export function posListRenderLimit(hasSearch) {
    const searching = !!String(hasSearch || '').trim();
    if (isPosLargeShopMode()) return searching ? 72 : 40;
    return searching ? 120 : 100;
}

/** Customer / supplier pick-list cap (type to search in large shops). */
export function posEntityPickLimit() {
    return isPosLargeShopMode() ? 36 : 100;
}

export function posEntityPickNeedsQuery() {
    return isPosLargeShopMode();
}

export function shouldPosUseVirtualMenu(listLen) {
    if (!listLen || listLen < 48) return false;
    if (isPosLargeShopMode()) return true;
    if (isPosLargeCatalogMode()) return true;
    if (isPosCpuSaveMode()) return listLen >= 44;
    return listLen >= 72;
}

export function posDebouncedListRenderMs() {
    return isPosLargeShopMode() ? 300 : 0;
}

/** True when CPU-saving runtime should be active (low + ultra). */
export function isPosCpuSaveMode() {
    return currentGraphicsQuality() !== 'normal';
}

export function isPosUltraGraphicsMode() {
    return currentGraphicsQuality() !== 'normal';
}

export function isPosLowGraphicsMode() {
    return currentGraphicsQuality() !== 'normal';
}

export function isPosLanTerminalClient() {
    try {
        if (typeof window !== 'undefined' && typeof window.posIsRemoteLanPosClient === 'function' && window.posIsRemoteLanPosClient()) {
            return true;
        }
        if (typeof window !== 'undefined' && typeof window.posIsTerminalConnectionAttempt === 'function' && window.posIsTerminalConnectionAttempt()) {
            return true;
        }
        if (typeof localStorage !== 'undefined' && localStorage.getItem('pos_fragi_device_mode') === '1') {
            return true;
        }
    } catch (_eTerm) {}
    return false;
}

/** Shop PC on LAN / localhost — never treat as a public cloud host. */
export function isPosPrivateLanHost(hostname) {
    var h = String(hostname || '').toLowerCase().replace(/^\[|\]$/g, '');
    if (!h || h === 'localhost' || h === '127.0.0.1' || h === '::1') return true;
    if (/^192\.168\.\d{1,3}\.\d{1,3}$/.test(h)) return true;
    if (/^10\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(h)) return true;
    if (/^172\.(1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3}$/.test(h)) return true;
    if (h.indexOf('.') === -1) return true;
    if (h.slice(-6) === '.local') return true;
    return false;
}

/** Main PC + any shop laptop on the LAN: same-second sync without 25s Apache hold. */
export function isPosFastLanSync() {
    if (isPosLanTerminalClient()) return true;
    try {
        return isPosPrivateLanHost((typeof location !== 'undefined' && location.hostname) || '');
    } catch (_eH) {}
    return false;
}

/** Dual-laptop LAN never long-polls — holding Apache makes the other PC stall. */
export function shouldPosUseLongPoll() {
    if (isPosFastLanSync()) return false;
    return !isPosCpuSaveMode();
}

export function posLiveSyncWaitMax() {
    return isPosFastLanSync() ? 1 : 25;
}

/**
 * Bootstrap catalog size by laptop strength:
 * weak = 450 gradual (Celeron/2GB), standard = 1200, full = all products at once.
 */
export function posCatalogBootstrapTier() {
    if (typeof window !== 'undefined' && window.__posCatalogTier) {
        const t = String(window.__posCatalogTier || '').toLowerCase();
        if (t === 'weak' || t === 'standard' || t === 'full') return t;
    }
    try {
        const raw = String(localStorage.getItem('pos_graphics_quality') || '').toLowerCase().trim();
        if (raw === 'normal') return 'full';
    } catch (e) {}
    let weakScore = 0;
    const cores = parseInt(navigator.hardwareConcurrency, 10) || 2;
    const memGb = parseFloat(navigator.deviceMemory) || 0;
    if (cores <= 2) weakScore += 4;
    else if (cores < 4) weakScore += 3;
    else if (cores <= 4) weakScore += 2;
    else if (cores <= 6) weakScore += 1;
    else weakScore -= 1;
    if (memGb > 0 && memGb <= 2) weakScore += 4;
    else if (memGb > 0 && memGb <= 4) weakScore += 3;
    else if (memGb > 0 && memGb <= 6) weakScore += 1;
    else if (memGb >= 8) weakScore -= 2;
    const gpu = getWebGLRendererInfo();
    if (gpu.weak) weakScore += 3;
    if (weakScore >= 5) return 'weak';
    if (weakScore >= 2) return 'standard';
    return 'full';
}

export function posCatalogTierQueryString(options) {
    options = options || {};
    const tier = options.fullData ? 'full' : posCatalogBootstrapTier();
    if (typeof window !== 'undefined') window.__posCatalogTier = tier;
    return '&catalog_tier=' + encodeURIComponent(tier);
}

/** Active sale / purchase screens — must stay fast even in ultra graphics mode. */
export function isPosTxnViewActive() {
    if (typeof document === 'undefined') return false;
    const ids = ['view-pos', 'view-purchase', 'view-purchase-returns', 'view-returns-new', 'view-waste'];
    for (let i = 0; i < ids.length; i++) {
        const el = document.getElementById(ids[i]);
        if (el && el.classList.contains('active')) return true;
    }
    return false;
}

export function updatePosTxnActiveClass() {
    if (typeof document === 'undefined') return;
    const on = isPosTxnViewActive();
    document.body.classList.toggle('pos-txn-active', on);
    document.documentElement.classList.toggle('pos-txn-active', on);
}

/** Background-only refresh delay (reports, settings, idle). */
export function posBackgroundRefreshDelayMs() {
    const q = currentGraphicsQuality();
    if (q === 'low') return 3000;
    return 140;
}

/** @deprecated Use posBackgroundRefreshDelayMs or posAfterWriteRefreshDelayMs */
export function posAutoRefreshDelayMs() {
    return posBackgroundRefreshDelayMs();
}

/** After payment / supply / return — always responsive on weak laptops. */
export function posAfterWriteRefreshDelayMs(action) {
    const act = String(action || '');
    if (/^(process_payment|save_supply|save_return)$/.test(act)) return 100;
    if (act === 'update_table_items') return 100;
    if (isPosTxnViewActive()) return 150;
    return posBackgroundRefreshDelayMs();
}

export function posLiveSyncDelayMs() {
    return posPollIntervalMs(45000);
}

/** Sale/purchase/returns on weak laptops — batch DOM work, skip heavy sync. */
export function isPosTxnLiteMode() {
    return isPosCpuSaveMode() && isPosTxnViewActive();
}

export function posMaxPosMenuProducts() {
    if (isPosLargeCatalogMode()) {
        if (isPosTxnLiteMode()) return 32;
        if (isPosTxnViewActive()) return 36;
        return 40;
    }
    if (isPosLargeShopMode()) {
        if (isPosTxnLiteMode()) return 36;
        if (isPosTxnViewActive()) return 42;
        return 44;
    }
    if (isPosTxnLiteMode()) return 40;
    if (isPosTxnViewActive()) return 50;
    if (isPosUltraGraphicsMode()) return 40;
    if (isPosCpuSaveMode()) return 48;
    return 50;
}

/** Cap product cards in purchase / returns grids (weak laptops). More when user is searching. */
export function posTxnGridProductLimit(hasSearch) {
    const base = posMaxPosMenuProducts();
    if (String(hasSearch || '').trim()) return Math.min(base + 28, 72);
    return base;
}

/** Product menu / grid repaint delay while typing or scanning. */
export function posTxnMenuDebounceMs() {
    // Made much faster to ensure instant search response
    if (isPosLargeCatalogMode()) return isPosTxnLiteMode() ? 80 : 50;
    if (isPosTxnLiteMode()) return 60;
    if (isPosTxnViewActive()) return 40;
    return 30;
}

export function posTxnGridDebounceMs() {
    // Made much faster to ensure instant grid response
    if (isPosTxnLiteMode()) return 80;
    if (isPosTxnViewActive()) return 50;
    return 30;
}

/** Bill / returns cart row repaint coalesce (ms). 0 = paint on the same click. */
export function posTxnCartRenderDebounceMs() {
    return 0;
}

/** Skip customer-display HTTP + heavy localize during live txn on weak CPU. */
export function posSkipCustomerDisplaySync() {
    return isPosTxnLiteMode();
}

/** Customer display POST debounce — less CPU during live sale. */
export function posCustomerDisplaySyncMs() {
    if (posSkipCustomerDisplaySync()) return 1000;
    if (isPosTxnViewActive()) return 300;
    if (isPosCpuSaveMode()) return 400;
    return 200;
}

/** Cart SQL debounce — short during live sale/purchase. */
export function posCartSaveDebounceMs() {
    if (isPosFastLanSync()) return 50;
    if (isPosTxnViewActive()) return 100;
    const q = currentGraphicsQuality();
    if (q === 'low') return 150;
    return 100;
}

/** Stretch background poll intervals on weak devices. */
export function posPollIntervalMs(baseMs) {
    const base = parseInt(baseMs, 10) || 15000;
    if (isPosFastLanSync()) {
        if (base <= 4000) return 2000;
        if (base <= 15000) return 10000;
        return base;
    }
    const q = currentGraphicsQuality();
    // Do not stretch intervals too much even on low graphics, to keep data fresh
    if (q === 'low') return Math.max(base * 2, 30000);
    return base;
}

export function hasPosGraphicsUserOverride() {
    try {
        return localStorage.getItem(GFX_USER_OVERRIDE_KEY) === '1';
    } catch (e) {
        return false;
    }
}

export function markPosGraphicsUserOverride() {
    try {
        localStorage.setItem(GFX_USER_OVERRIDE_KEY, '1');
    } catch (e) {}
}

function getWebGLRendererInfo() {
    try {
        const canvas = document.createElement('canvas');
        const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
        if (!gl) return { renderer: '', weak: true };
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const renderer = ext
            ? String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) || '')
            : '';
        const weak = /intel|hd graphics|uhd graphics|iris|celeron|pentium|atom|mesa|swiftshader|microsoft basic render|hd 2\d{3}|hd 3\d{3}|hd 4\d{3}/i.test(renderer);
        return { renderer, weak };
    } catch (e) {
        return { renderer: '', weak: true };
    }
}

/**
 * Score weak hardware (higher = weaker). Used once on first visit unless user overrides.
 */
export function detectRecommendedGraphicsQuality() {
    let weakScore = 0;
    const cores = parseInt(navigator.hardwareConcurrency, 10) || 2;
    const memGb = parseFloat(navigator.deviceMemory) || 0;

    if (cores <= 2) weakScore += 4;
    else if (cores < 4) weakScore += 3;
    else if (cores <= 4) weakScore += 2;
    else if (cores <= 8) weakScore += 1;

    if (memGb > 0 && memGb <= 2) weakScore += 4;
    else if (memGb > 0 && memGb <= 4) weakScore += 3;
    else if (memGb > 0 && memGb <= 6) weakScore += 1;

    const gpu = getWebGLRendererInfo();
    if (gpu.weak) weakScore += 3;
    if (!gpu.renderer) weakScore += 2;

    return 'low';
}

/** UI timers after PIN (shift modal, nav paint) — keep short so login feels instant. */
export function posLoginDeferMs(baseMs) {
    const base = parseInt(baseMs, 10) || 500;
    if (isPosCpuSaveMode()) return Math.min(Math.max(base, 200), 700);
    return base;
}

/** Defer sidebar/home/theme after login screen is visible (weak laptops). */
export function posLoginChromeDeferMs() {
    if (!isPosCpuSaveMode()) return 0;
    return posStartupDeferMs(400);
}

/** Max wait for device-key bootstrap before first data fetch (Gen3 laptops). */
export function posDeviceBootstrapWaitMs() {
    if (!isPosCpuSaveMode()) return 0;
    return 180;
}

/** Background jobs (secondary fetch, auto-refresh) — can wait longer on weak laptops. */
export function posStartupDeferMs(baseMs) {
    const base = parseInt(baseMs, 10) || 1000;
    const q = currentGraphicsQuality();
    if (q === 'low') return Math.max(Math.round(base * 1.5), 1200);
    return base;
}

/**
 * First-run only: pick graphics tier for old/low-spec laptops (no normal on weak devices).
 * Returns applied tier or null if skipped.
 */
/**
 * On each load: bump graphics tier if hardware is weaker than stored setting (never downgrade).
 */
export function enforceWeakDeviceGraphicsProfile() {
    if (typeof window === 'undefined') return null;
    if (hasPosGraphicsUserOverride()) return null;
    try {
        const recommended = detectRecommendedGraphicsQuality();
        const current = graphicsQualityFromStorage();
        const rank = { normal: 0, low: 1, ultra: 1 };
        if ((rank[recommended] || 0) > (rank[current] || 0)) {
            localStorage.setItem('pos_graphics_quality', recommended);
            return recommended;
        }
    } catch (e) {}
    return null;
}

export function autoConfigureGraphicsQualityIfNeeded() {
    if (typeof window === 'undefined') return null;
    if (hasPosGraphicsUserOverride()) return null;

    try {
        const alreadyAuto = localStorage.getItem(GFX_AUTO_KEY) === '1';
        const refined = localStorage.getItem(GFX_AUTO_REFINED_KEY) === '1';

        if (alreadyAuto && refined) return null;

        let tier = null;

        if (!alreadyAuto) {
            tier = detectRecommendedGraphicsQuality();
            localStorage.setItem('pos_graphics_quality', tier);
            localStorage.setItem(GFX_AUTO_KEY, '1');
            if (tier !== 'normal') {
                queueAutoGraphicsToast(tier);
            }
        } else if (!refined) {
            const current = graphicsQualityFromStorage();
            const gpu = getWebGLRendererInfo();
            if (gpu.weak && current === 'normal') {
                tier = 'low';
                localStorage.setItem('pos_graphics_quality', tier);
                queueAutoGraphicsToast(tier);
            }
            localStorage.setItem(GFX_AUTO_REFINED_KEY, '1');
        }

        return tier;
    } catch (e) {
        return null;
    }
}

function queueAutoGraphicsToast(tier) {
    try {
        if (localStorage.getItem(GFX_TOAST_KEY) === '1') return;
        localStorage.setItem(GFX_TOAST_KEY, '1');
    } catch (e) {}
    if (typeof window !== 'undefined') {
        window.__posGraphicsAutoNotify = tier;
    }
}

export function consumeAutoGraphicsNotify() {
    if (typeof window === 'undefined') return null;
    const n = window.__posGraphicsAutoNotify || null;
    window.__posGraphicsAutoNotify = null;
    return n;
}

export function scheduleGraphicsSettingsSave() {
    if (typeof window === 'undefined') return;
    clearTimeout(_graphicsSaveTimer);
    _graphicsSaveTimer = setTimeout(function () {
        _graphicsSaveTimer = null;
        if (typeof window.saveSettings === 'function') {
            window.saveSettings().catch(function () {});
        }
    }, 3000);
}

export function applyPerformanceDocumentFlags(quality) {
    const q = normalizeGraphicsQuality(quality);
    const html = document.documentElement;
    const body = document.body;
    if (html) {
        html.setAttribute('data-pos-graphics', q);
        const saveOn = q !== 'normal';
        html.classList.toggle('pos-cpu-save', saveOn);
        html.classList.toggle('pos-cpu-ultra', saveOn);
    }
    if (body) {
        body.classList.toggle('pos-gfx-ultra', q !== 'normal');
        body.classList.toggle('pos-gfx-low', q !== 'normal');
    }
    if (typeof window !== 'undefined') {
        window.POS_GRAPHICS_QUALITY = q;
        window.POS_CHART_ANIMATIONS = (q === 'normal');
        window.POS_SKIP_HEAVY_SETTINGS = (q !== 'normal');
        window.POS_DEFER_SUBDEV_PANEL = (q !== 'normal');
        window.POS_USE_LONG_POLL = shouldPosUseLongPoll();
        window.POS_TXN_PRIORITY = true;
    }
    updatePosTxnActiveClass();
    if (q !== 'normal') {
        try {
            if (window.__posLanguageObserver) {
                window.__posLanguageObserver.disconnect();
                window.__posLanguageObserver = null;
            }
        } catch (eObs) {}
    }
    if (typeof window.posRestartPollsForGraphics === 'function') {
        window.posRestartPollsForGraphics();
    }
    if (typeof window.posRestartLiveSync === 'function') {
        window.posRestartLiveSync();
    }
}
