using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Printing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

/// <summary>
/// POS product labels: send SIZE to TSPL printers (Xprinter) so Windows
/// printer-preferences paper size is not required. GDI fallback for others.
/// C# 5 — compiled by Windows PowerShell 5 Add-Type.
/// </summary>
public static class PosLabelPrintHelper
{
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private class DOCINFO
    {
        [MarshalAs(UnmanagedType.LPWStr)]
        public string pDocName;
        [MarshalAs(UnmanagedType.LPWStr)]
        public string pOutputFile;
        [MarshalAs(UnmanagedType.LPWStr)]
        public string pDataType;
    }

    [DllImport("winspool.Drv", EntryPoint = "OpenPrinterW", SetLastError = true, CharSet = CharSet.Unicode, ExactSpelling = true)]
    private static extern bool OpenPrinter(string src, out IntPtr hPrinter, IntPtr pd);

    [DllImport("winspool.Drv", EntryPoint = "ClosePrinter", SetLastError = true, ExactSpelling = true)]
    private static extern bool ClosePrinter(IntPtr hPrinter);

    [DllImport("winspool.Drv", EntryPoint = "StartDocPrinterW", SetLastError = true, CharSet = CharSet.Unicode, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
    private static extern bool StartDocPrinter(IntPtr hPrinter, int level, [In, MarshalAs(UnmanagedType.LPStruct)] DOCINFO di);

    [DllImport("winspool.Drv", EntryPoint = "EndDocPrinter", SetLastError = true, ExactSpelling = true)]
    private static extern bool EndDocPrinter(IntPtr hPrinter);

    [DllImport("winspool.Drv", EntryPoint = "StartPagePrinter", SetLastError = true, ExactSpelling = true)]
    private static extern bool StartPagePrinter(IntPtr hPrinter);

    [DllImport("winspool.Drv", EntryPoint = "EndPagePrinter", SetLastError = true, ExactSpelling = true)]
    private static extern bool EndPagePrinter(IntPtr hPrinter);

    [DllImport("winspool.Drv", EntryPoint = "WritePrinter", SetLastError = true, ExactSpelling = true)]
    private static extern bool WritePrinter(IntPtr hPrinter, IntPtr pBytes, int dwCount, out int dwWritten);

    public static bool IsTsplPrinter(string printerName)
    {
        if (string.IsNullOrEmpty(printerName)) return false;
        string n = printerName.ToLowerInvariant();
        if (n.IndexOf("xprinter") >= 0) return true;
        if (n.IndexOf("xp-365") >= 0 || n.IndexOf("xp365") >= 0) return true;
        if (n.IndexOf("xp-236") >= 0 || n.IndexOf("xp-420") >= 0) return true;
        if (n.IndexOf("xp-dt") >= 0 || n.IndexOf("xp-370") >= 0) return true;
        if (n.StartsWith("tsc") || n.IndexOf(" tsc") >= 0 || n.IndexOf("tsc-") >= 0) return true;
        if (n.IndexOf("ttp-") >= 0 || n.IndexOf("te200") >= 0 || n.IndexOf("te300") >= 0) return true;
        return false;
    }

    public static string ResolvePrinterName(string requested)
    {
        if (string.IsNullOrWhiteSpace(requested)) return requested;
        requested = requested.Trim();

        System.Collections.Generic.List<string> installed = new System.Collections.Generic.List<string>();
        foreach (string p in PrinterSettings.InstalledPrinters)
        {
            if (!string.IsNullOrEmpty(p)) installed.Add(p);
        }

        int i;
        for (i = 0; i < installed.Count; i++)
        {
            if (string.Equals(installed[i], requested, StringComparison.OrdinalIgnoreCase))
                return installed[i];
        }

        string baseName = requested;
        int hash = requested.LastIndexOf(" #");
        if (hash > 0)
        {
            string numPart = requested.Substring(hash + 2).Trim();
            int dummy;
            if (int.TryParse(numPart, out dummy))
                baseName = requested.Substring(0, hash).Trim();
        }

        System.Collections.Generic.List<string> family = new System.Collections.Generic.List<string>();
        string baseLower = baseName.ToLowerInvariant();
        for (i = 0; i < installed.Count; i++)
        {
            string n = installed[i];
            string nl = n.ToLowerInvariant();
            if (nl == baseLower || nl.StartsWith(baseLower + " #"))
                family.Add(n);
        }
        if (family.Count == 1) return family[0];
        if (family.Count > 1)
        {
            family.Sort(StringComparer.OrdinalIgnoreCase);
            return family[family.Count - 1];
        }

        System.Collections.Generic.List<string> contains = new System.Collections.Generic.List<string>();
        for (i = 0; i < installed.Count; i++)
        {
            if (installed[i].IndexOf(baseName, StringComparison.OrdinalIgnoreCase) >= 0)
                contains.Add(installed[i]);
        }
        if (contains.Count == 1) return contains[0];

        return requested;
    }

    public static string Print(string printerName, string imagePath, double widthMm, double heightMm, int copies)
    {
        if (string.IsNullOrWhiteSpace(printerName)) throw new Exception("Printer name is empty");
        if (string.IsNullOrWhiteSpace(imagePath) || !File.Exists(imagePath)) throw new Exception("Image not found");
        if (copies < 1) copies = 1;
        if (copies > 50) copies = 50;
        if (widthMm < 10) widthMm = 10;
        if (heightMm < 10) heightMm = 10;

        string resolved = ResolvePrinterName(printerName);

        if (IsTsplPrinter(resolved) || IsTsplPrinter(printerName))
        {
            try
            {
                SendTspl(resolved, imagePath, widthMm, heightMm, copies);
                return "tspl";
            }
            catch (Exception tsplEx)
            {
                try
                {
                    PrintGdi(resolved, imagePath, widthMm, heightMm, copies);
                    return "gdi-fallback";
                }
                catch (Exception gdiEx)
                {
                    throw new Exception(
                        "پرینتەر نەهاتە دیتن: «" + printerName + "». ل ویندۆزێ: «" + resolved + "». "
                        + tsplEx.Message + " / " + gdiEx.Message
                    );
                }
            }
        }

        PrintGdi(resolved, imagePath, widthMm, heightMm, copies);
        return "gdi";
    }

    private static void SendRaw(string printerName, byte[] bytes)
    {
        IntPtr h;
        if (!OpenPrinter(printerName, out h, IntPtr.Zero))
            throw new Exception("OpenPrinter failed: " + printerName + " err=" + Marshal.GetLastWin32Error());
        try
        {
            DOCINFO di = new DOCINFO();
            di.pDocName = "POS Label";
            di.pDataType = "RAW";
            if (!StartDocPrinter(h, 1, di))
                throw new Exception("StartDocPrinter failed err=" + Marshal.GetLastWin32Error());
            try
            {
                StartPagePrinter(h);
                IntPtr p = Marshal.AllocHGlobal(bytes.Length);
                try
                {
                    Marshal.Copy(bytes, 0, p, bytes.Length);
                    int written;
                    if (!WritePrinter(h, p, bytes.Length, out written))
                        throw new Exception("WritePrinter failed err=" + Marshal.GetLastWin32Error());
                }
                finally
                {
                    Marshal.FreeHGlobal(p);
                }
                EndPagePrinter(h);
            }
            finally
            {
                EndDocPrinter(h);
            }
        }
        finally
        {
            ClosePrinter(h);
        }
    }

    private static void SendTspl(string printerName, string imagePath, double widthMm, double heightMm, int copies)
    {
        byte[] bmp = BuildTsplBitmap(imagePath, widthMm, heightMm);
        int wDots = Dots(widthMm);
        int hDots = Dots(heightMm);
        int wBytes = (wDots + 7) / 8;

        StringBuilder sb = new StringBuilder();
        sb.Append("SIZE ");
        sb.Append(Inv(widthMm));
        sb.Append(" mm, ");
        sb.Append(Inv(heightMm));
        sb.Append(" mm\r\n");
        sb.Append("GAP 2 mm, 0 mm\r\n");
        sb.Append("DENSITY 8\r\n");
        sb.Append("SPEED 4\r\n");
        sb.Append("DIRECTION 1\r\n");
        sb.Append("REFERENCE 0,0\r\n");
        sb.Append("CLS\r\n");
        sb.Append("BITMAP 0,0,");
        sb.Append(wBytes);
        sb.Append(",");
        sb.Append(hDots);
        sb.Append(",0,");

        byte[] header = Encoding.ASCII.GetBytes(sb.ToString());
        byte[] footer = Encoding.ASCII.GetBytes("\r\nPRINT " + copies.ToString() + ",1\r\n");

        byte[] job = new byte[header.Length + bmp.Length + footer.Length];
        Buffer.BlockCopy(header, 0, job, 0, header.Length);
        Buffer.BlockCopy(bmp, 0, job, header.Length, bmp.Length);
        Buffer.BlockCopy(footer, 0, job, header.Length + bmp.Length, footer.Length);
        SendRaw(printerName, job);
    }

    private static int Dots(double mm)
    {
        // 203 DPI label printers = 8 dots per mm
        int d = (int)Math.Round(mm * 8.0);
        if (d < 16) d = 16;
        return d;
    }

    private static string Inv(double v)
    {
        return v.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture);
    }

    private static byte[] BuildTsplBitmap(string imagePath, double widthMm, double heightMm)
    {
        int wDots = Dots(widthMm);
        int hDots = Dots(heightMm);
        int wBytes = (wDots + 7) / 8;
        byte[] data = new byte[wBytes * hDots];

        using (Image src = Image.FromFile(imagePath))
        using (Bitmap canvas = new Bitmap(wDots, hDots, PixelFormat.Format32bppArgb))
        {
            using (Graphics g = Graphics.FromImage(canvas))
            {
                g.Clear(Color.White);
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                g.SmoothingMode = SmoothingMode.HighQuality;
                g.DrawImage(src, 0, 0, wDots, hDots);
            }
            for (int y = 0; y < hDots; y++)
            {
                for (int x = 0; x < wDots; x++)
                {
                    Color c = canvas.GetPixel(x, y);
                    int lum = (c.R * 30 + c.G * 59 + c.B * 11) / 100;
                    if (lum >= 140) continue;
                    int bi = y * wBytes + (x / 8);
                    data[bi] = (byte)(data[bi] | (1 << (7 - (x % 8))));
                }
            }
        }
        return data;
    }

    private static int HundredthsInch(double mm)
    {
        int v = (int)Math.Round(mm / 25.4 * 100.0);
        if (v < 1) v = 1;
        return v;
    }

    private static void PrintGdi(string printerName, string imagePath, double widthMm, double heightMm, int copies)
    {
        int wH = HundredthsInch(widthMm);
        int hH = HundredthsInch(heightMm);
        Image img = Image.FromFile(imagePath);
        try
        {
            for (int i = 0; i < copies; i++)
            {
                PrintDocument pd = new PrintDocument();
                try
                {
                    pd.DocumentName = "POS Label";
                    pd.PrinterSettings.PrinterName = printerName;
                    if (!pd.PrinterSettings.IsValid)
                    {
                        string again = ResolvePrinterName(printerName);
                        pd.PrinterSettings.PrinterName = again;
                    }
                    if (!pd.PrinterSettings.IsValid)
                        throw new Exception("Printer not found or invalid: " + printerName);
                    pd.PrinterSettings.Copies = 1;
                    pd.OriginAtMargins = false;

                    PaperSize custom = new PaperSize("POSLabel", wH, hH);
                    custom.RawKind = 256;
                    try { pd.DefaultPageSettings.PaperSize = custom; }
                    catch { }

                    PaperSize matched = FindClosePaper(pd.PrinterSettings, wH, hH);
                    if (matched != null)
                    {
                        pd.DefaultPageSettings.PaperSize = matched;
                    }

                    pd.DefaultPageSettings.Landscape = false;
                    pd.DefaultPageSettings.Margins = new Margins(0, 0, 0, 0);

                    float wMm = (float)widthMm;
                    float hMm = (float)heightMm;
                    Image pageImg = img;
                    pd.PrintPage += delegate(object sender, PrintPageEventArgs e)
                    {
                        Graphics g = e.Graphics;
                        g.PageUnit = GraphicsUnit.Millimeter;
                        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                        g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                        g.SmoothingMode = SmoothingMode.HighQuality;
                        Rectangle dest = new Rectangle(0, 0, (int)Math.Ceiling(wMm), (int)Math.Ceiling(hMm));
                        g.DrawImage(pageImg, dest);
                        e.HasMorePages = false;
                    };
                    pd.Print();
                }
                finally
                {
                    pd.Dispose();
                }
            }
        }
        finally
        {
            img.Dispose();
        }
    }

    private static PaperSize FindClosePaper(PrinterSettings settings, int wH, int hH)
    {
        PaperSize best = null;
        int bestScore = int.MaxValue;
        foreach (PaperSize ps in settings.PaperSizes)
        {
            int s1 = Math.Abs(ps.Width - wH) + Math.Abs(ps.Height - hH);
            int s2 = Math.Abs(ps.Width - hH) + Math.Abs(ps.Height - wH);
            int s = s1 <= s2 ? s1 : s2;
            if (s < bestScore)
            {
                bestScore = s;
                best = ps;
            }
        }
        if (best != null && bestScore <= 8) return best;
        return null;
    }
}
