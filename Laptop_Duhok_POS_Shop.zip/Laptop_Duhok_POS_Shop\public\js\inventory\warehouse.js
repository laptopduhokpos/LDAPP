// inventory/warehouse.js — warehouse, movements
        function getMinStock(p) {
            if (db && db.settings && (db.settings.useGlobalMinStock == true || db.settings.useGlobalMinStock == 'true' || db.settings.useGlobalMinStock == 1)) {
                return (db.settings.globalMinStockThreshold !== undefined && db.settings.globalMinStockThreshold !== null) ? parseInt(db.settings.globalMinStockThreshold, 10) : 5;
            }
            return (p && (p.minStock !== undefined && p.minStock !== null && p.minStock !== '')) ? parseInt(p.minStock, 10) : 5;
        }
        window.getMinStock = getMinStock;
        function isLowStockByMin(p) { return p.trackStock && (p.qty <= getMinStock(p)); }

        function getWarehouseProductQty(p) {
            if (!p || !p.trackStock) return null;
            if (p._warehouse_id || p._qty_is_total) return parseFloat(p.qty) || 0;
            return (typeof getDisplayQty === 'function') ? getDisplayQty(p) : (parseFloat(p.qty) || 0);
        }
        /** Tracked product at qty≤0 → نەما (all items, including merged catalog). */
        function isWarehouseTrueStockout(p) {
            if (!p || !p.trackStock) return false;
            var qty = getWarehouseProductQty(p);
            return qty !== null && qty <= 0;
        }
        function isWarehouseNeverStocked(p) { return false; }
        function isProductCatalogOnly(p) { return false; }
        function productHasRealPurchaseHistory(p) { return false; }
        function productShouldShowWarehouseStockout(p) { return isWarehouseTrueStockout(p); }
        function productHasBeenPurchased(p) { return false; }
        window.getWarehouseProductQty = getWarehouseProductQty;
        window.isProductCatalogOnly = isProductCatalogOnly;
        window.productHasRealPurchaseHistory = productHasRealPurchaseHistory;
        window.productShouldShowWarehouseStockout = productShouldShowWarehouseStockout;
        window.productHasBeenPurchased = productHasBeenPurchased;
        window.isWarehouseTrueStockout = isWarehouseTrueStockout;
        window.isWarehouseNeverStocked = isWarehouseNeverStocked;

        function getDefaultWarehouseId() {
            if (!db || !db.warehouses || !db.warehouses.length) return 0;
            var def = db.warehouses.find(function(w) { return Number(w.is_default) === 1; });
            return def ? Number(def.id) : Number(db.warehouses[0].id);
        }
        window.getDefaultWarehouseId = getDefaultWarehouseId;
        /** One warehouse for viewing + selling. Never a fake total of every warehouse. */
        function getWorkingWarehouseId() {
            if (typeof isMultiWarehouseProEnabled === 'function' && !isMultiWarehouseProEnabled()) {
                return getDefaultWarehouseId();
            }
            var open = Number(db && db.open_warehouse_id) || 0;
            if (open > 0) return open;
            return getDefaultWarehouseId();
        }
        window.getWorkingWarehouseId = getWorkingWarehouseId;
        window.getOtherWarehouseStockLines = function(p, exceptWhId) {
            exceptWhId = Number(exceptWhId) || 0;
            var out = [];
            if (typeof isMultiWarehouseProEnabled === 'function' && !isMultiWarehouseProEnabled()) return out;
            if (!p || !db || !db.warehouses || db.warehouses.length < 2) return out;
            if (!exceptWhId) exceptWhId = getWorkingWarehouseId();
            for (var i = 0; i < db.warehouses.length; i++) {
                var w = db.warehouses[i];
                if (Number(w.id) === exceptWhId) continue;
                var q = getProductQtyForWarehouse(p, w.id);
                if (q > 0.000001) out.push({ id: Number(w.id), name: w.name || '', qty: q });
            }
            return out;
        };
        /** Put leftover catalog / batch qty onto the working warehouse when location rows are empty. */
        window.healWarehouseStockMemory = function() {
            return false;
        };
        window.posAfterWarehouseDataLoaded = function(reason) {
            if (typeof window.healWarehouseStockMemory === 'function') window.healWarehouseStockMemory();
            if (typeof window.invalidateWmsWarehouseCache === 'function') window.invalidateWmsWarehouseCache();
            if (typeof window.syncPosSaleWarehouseBtn === 'function') window.syncPosSaleWarehouseBtn();
            if (typeof window.scheduleFirebaseMobilePush === 'function') {
                window.scheduleFirebaseMobilePush(reason || 'warehouse_data', true);
            }
            var vwaste = document.getElementById('view-waste');
            if (vwaste && vwaste.classList.contains('active')) {
                if (typeof renderWasteList === 'function') renderWasteList();
                if (typeof renderWasteCandidates === 'function') renderWasteCandidates();
            }
        };
        function getPurchaseTargetWarehouseId() {
            var sel = document.getElementById('purchase-warehouse-select');
            if (sel && sel.value) return parseInt(sel.value, 10) || 0;
            if (typeof getActiveWarehouseChoice === 'function') {
                var saved = getActiveWarehouseChoice('purchase');
                if (saved) return saved;
            }
            return getDefaultWarehouseId();
        }
        function shouldShowPurchaseWarehouseUi() {
            return typeof canUseMultiWarehouse === 'function' && canUseMultiWarehouse();
        }
        function whNameById(id) {
            var w = (db && db.warehouses) ? db.warehouses.find(function(x) { return Number(x.id) === Number(id); }) : null;
            return w ? (w.name || '') : '';
        }
        function getProductWarehouseBreakdown(p) {
            if (!p || !db || !db.warehouses) return [];
            if (typeof isMultiWarehouseProEnabled === 'function' && !isMultiWarehouseProEnabled()) return [];
            var rows = db.warehouse_stock || [];
            return db.warehouses.map(function(w) {
                var ws = rows.find(function(r) {
                    return Number(r.product_id) === Number(p.id) && Number(r.warehouse_id) === Number(w.id);
                });
                return {
                    id: Number(w.id),
                    name: w.name || ('#' + w.id),
                    qty: ws ? (parseFloat(ws.qty) || 0) : 0,
                    isDefault: Number(w.is_default) === 1
                };
            });
        }
        function buildPurchaseProductWarehouseCompareHtml(p) {
            if (!shouldShowPurchaseWarehouseUi()) return '';
            var breakdown = getProductWarehouseBreakdown(p);
            if (!breakdown.length) return '';
            var targetId = getPurchaseTargetWarehouseId();
            var targetName = whNameById(targetId);
            var itemsHtml = breakdown.map(function(b) {
                var qtyStr = (typeof formatQtyForDisplay === 'function') ? formatQtyForDisplay(b.qty, p) : String(b.qty);
                var cls = 'purchase-wh-compare-item' + (Number(b.id) === Number(targetId) ? ' is-target' : '');
                return '<span class="' + cls + '">' + escapeHtml(b.name) + ': <b>' + escapeHtml(qtyStr) + '</b></span>';
            }).join('');
            var goesTpl = (typeof t === 'function') ? t('purchase_wh_goes_to') : 'ئەم کڕینە → «__WH__»';
            if (goesTpl === 'purchase_wh_goes_to') goesTpl = 'ئەم کڕینە → «__WH__»';
            var goesLine = goesTpl.replace('__WH__', targetName || '—');
            var label = (typeof t === 'function') ? t('purchase_wh_compare_label') : 'بەراوردی کۆگەکان';
            if (label === 'purchase_wh_compare_label') label = 'بەراوردی کۆگەکان';
            return '<div class="purchase-wh-compare-list">' +
                '<div class="purchase-wh-compare-label"><i class="fas fa-warehouse"></i> ' + escapeHtml(label) + '</div>' +
                '<div class="purchase-wh-compare-items">' + itemsHtml + '</div>' +
                '<div class="purchase-wh-target-line"><i class="fas fa-cart-arrow-down"></i> ' + escapeHtml(goesLine) + '</div>' +
                '</div>';
        }
        function getPurchaseRowWarehouseId(row) {
            if (row && row.warehouseId) return Number(row.warehouseId) || 0;
            return getPurchaseTargetWarehouseId();
        }
        function ensurePurchaseRowWarehouseId(row) {
            if (!row) return;
            if (!row.warehouseId) row.warehouseId = getPurchaseTargetWarehouseId();
        }
        function buildPurchaseCartWarehouseSelectHtml(idx, row) {
            if (!shouldShowPurchaseWarehouseUi()) return '';
            ensurePurchaseRowWarehouseId(row);
            var selectedId = getPurchaseRowWarehouseId(row);
            var list = (db && db.warehouses) ? db.warehouses : [];
            if (!list.length) return '';
            var lbl = (typeof t === 'function') ? t('purchase_wh_row_label') : 'بۆ کۆگە';
            if (lbl === 'purchase_wh_row_label') lbl = 'بۆ کۆگە';
            var opts = list.map(function(w) {
                var sel = Number(w.id) === Number(selectedId) ? ' selected' : '';
                return '<option value="' + w.id + '"' + sel + '>' + escapeHtml(w.name) + (Number(w.is_default) === 1 ? ' ★' : '') + '</option>';
            }).join('');
            return '<label class="purchase-row-wh-wrap">' +
                '<span class="purchase-row-wh-lbl"><i class="fas fa-warehouse"></i> ' + escapeHtml(lbl) + '</span>' +
                '<select class="input-std purchase-row-wh-select" id="pur_cart_' + idx + '_wh" aria-label="' + escapeHtml(lbl) + '" onchange="setPurchaseCartRowWarehouse(' + idx + ', this.value)">' + opts + '</select>' +
                '</label>';
        }
        window.setPurchaseCartRowWarehouse = function(idx, val) {
            var row = purchaseCart[idx];
            if (!row) return;
            var newWh = parseInt(val, 10) || getDefaultWarehouseId();
            var unit = row.unit || 'piece';
            var dupIdx = purchaseCart.findIndex(function(r, i) {
                return i !== idx &&
                    Number(r.productId) === Number(row.productId) &&
                    (r.unit || 'piece') === unit &&
                    Number(getPurchaseRowWarehouseId(r)) === Number(newWh);
            });
            var p = row.productRef || (db.products || []).find(function(x) { return x.id === row.productId; });
            if (dupIdx >= 0) {
                purchaseCart[dupIdx].qty = normalizeQtyForProduct(p, (purchaseCart[dupIdx].qty || 0) + (row.qty || 0));
                purchaseCart.splice(idx, 1);
            } else {
                row.warehouseId = newWh;
            }
            schedulePurchaseCartRender();
        };
        window.onPurchaseWarehouseSelectChange = function() {
            if (typeof saveActiveWarehouseChoice === 'function') {
                var sel = document.getElementById('purchase-warehouse-select');
                if (sel) saveActiveWarehouseChoice('purchase', sel.value);
            }
            if (typeof debouncedRenderPurchaseProductGrid === 'function') debouncedRenderPurchaseProductGrid();
        };
        function formatPurchaseWarehouseToast(productName, warehouseName) {
            var tpl = (typeof t === 'function') ? t('purchase_item_to_warehouse') : '';
            if (tpl && tpl !== 'purchase_item_to_warehouse') {
                return tpl.replace('__NAME__', productName).replace('__WH__', warehouseName);
            }
            return '«' + productName + '» بۆ کۆگەی «' + warehouseName + '» دەچێت';
        }
        function notifyPurchaseWarehouseAdded(p, whIdOverride) {
            if (!shouldShowPurchaseWarehouseUi() || !p || typeof showToast !== 'function') return;
            var whId = whIdOverride || getPurchaseTargetWarehouseId();
            if (!whId) return;
            var whName = whNameById(whId);
            if (!whName) return;
            var name = (p.name || '').trim() || 'ئایتم';
            showToast(formatPurchaseWarehouseToast(name, whName), 'info');
        }
        window.isMultiWarehouseProEnabled = function() {
            return typeof isPremiumSettingsFeatureEnabled === 'function'
                && isPremiumSettingsFeatureEnabled('set-enable-multi-warehouse');
        };
        window.canUseMultiWarehouse = function() {
            if (!isMultiWarehouseProEnabled()) return false;
            if (typeof currentUser === 'undefined' || !currentUser) return false;
            if (currentUser.role === 'admin') return true;
            return typeof hasPermission === 'function' && hasPermission('multi_warehouse');
        };
        window.applyOpenWarehouseFromPayload = function(data) {
            if (!db || !data) return;
            if (data.open_warehouse_id != null) db.open_warehouse_id = Number(data.open_warehouse_id) || 0;
        };
        window.anyWarehouseHasPin = function() {
            if (typeof isMultiWarehouseProEnabled === 'function' && !isMultiWarehouseProEnabled()) return false;
            return !!(db && db.warehouses && db.warehouses.some(function(w) { return Number(w.has_pin) === 1; }));
        };
        window.getSaleWarehouseId = function() {
            if (typeof isMultiWarehouseProEnabled === 'function' && !isMultiWarehouseProEnabled()) {
                if (typeof getDefaultWarehouseId === 'function') return getDefaultWarehouseId();
                return 0;
            }
            var open = Number(db && db.open_warehouse_id) || 0;
            if (open > 0) return open;
            if (window.anyWarehouseHasPin && window.anyWarehouseHasPin()) return 0;
            if (typeof getDefaultWarehouseId === 'function') return getDefaultWarehouseId();
            return 0;
        };
        window.syncPosSaleWarehouseBtn = function() {
            var btn = document.getElementById('pos-sale-wh-btn');
            if (!btn) return;
            if (typeof isMultiWarehouseProEnabled === 'function' && !isMultiWarehouseProEnabled()) {
                btn.style.display = 'none';
                return;
            }
            var list = (db && db.warehouses) ? db.warehouses : [];
            if (list.length < 2 && !(window.anyWarehouseHasPin && window.anyWarehouseHasPin())) {
                btn.style.display = 'none';
                return;
            }
            btn.style.display = 'inline-flex';
            var id = typeof getSaleWarehouseId === 'function' ? getSaleWarehouseId() : 0;
            var w = list.find(function(x) { return Number(x.id) === Number(id); });
            var lbl = document.getElementById('pos-sale-wh-label');
            var icon = btn.querySelector('.pos-sale-wh-lock i');
            if (w) {
                if (lbl) lbl.textContent = w.name || ('#' + w.id);
                btn.classList.add('is-open');
                btn.classList.remove('is-locked');
                if (icon) icon.className = 'fas fa-unlock';
                btn.title = (typeof t === 'function' ? t('wh_sale_open_hint') : '') || 'فرۆتن ژ ڤێ کۆگەهێ';
            } else {
                if (lbl) lbl.textContent = (typeof t === 'function' ? t('wh_sale_pick') : '') || 'کۆگەه ڤەکە';
                btn.classList.remove('is-open');
                btn.classList.add('is-locked');
                if (icon) icon.className = 'fas fa-lock';
                btn.title = (typeof t === 'function' ? t('wh_sale_need_unlock') : '') || 'پێش فرۆتنێ کۆگەهەکێ ڤەکە';
            }
        };
        window.closeWarehousePinModal = function() {
            var m = document.getElementById('modal-wh-pin');
            if (m) m.style.display = 'none';
            window._whPinMode = null;
            window._whPinTargetId = 0;
        };
        window.openWarehousePinModal = function(mode, whId) {
            var w = (db && db.warehouses) ? db.warehouses.find(function(x) { return Number(x.id) === Number(whId); }) : null;
            window._whPinMode = mode;
            window._whPinTargetId = Number(whId) || 0;
            var m = document.getElementById('modal-wh-pin');
            var title = document.getElementById('wh-pin-title');
            var nameEl = document.getElementById('wh-pin-name');
            var inp = document.getElementById('wh-pin-input');
            var inp2 = document.getElementById('wh-pin-input-2');
            var wrap2 = document.getElementById('wh-pin-confirm-wrap');
            var clearBtn = document.getElementById('wh-pin-clear-btn');
            if (nameEl) nameEl.textContent = w ? (w.name || '') : '';
            if (inp) inp.value = '';
            if (inp2) inp2.value = '';
            if (wrap2) wrap2.style.display = (mode === 'set') ? '' : 'none';
            if (clearBtn) clearBtn.style.display = (mode === 'set' && w && Number(w.has_pin) === 1) ? '' : 'none';
            if (title) {
                title.textContent = mode === 'set'
                    ? ((typeof t === 'function' ? t('wh_pin_set_title') : '') || 'دانانا پاسۆردێ کۆگەهێ')
                    : ((typeof t === 'function' ? t('wh_pin_unlock_title') : '') || 'ڤەکرنا کۆگەهێ');
            }
            if (m) m.style.display = 'flex';
            setTimeout(function() { try { if (inp) inp.focus(); } catch (eF) {} }, 50);
        };
        function posDigitsOnly(s) {
            var t = String(s || '');
            if (typeof convertArabicNumerals === 'function') {
                var fake = { value: t };
                convertArabicNumerals(fake);
                t = fake.value;
            }
            return t.replace(/\D/g, '');
        }
        window.submitWarehousePin = function() {
            var mode = window._whPinMode;
            var whId = Number(window._whPinTargetId) || 0;
            var pin = posDigitsOnly(document.getElementById('wh-pin-input') && document.getElementById('wh-pin-input').value);
            if (mode === 'set') {
                var pin2 = posDigitsOnly(document.getElementById('wh-pin-input-2') && document.getElementById('wh-pin-input-2').value);
                if (pin.length < 4 || pin.length > 8) {
                    alert((typeof t === 'function' ? t('wh_pin_len') : '') || 'پاسۆرد: ٤ تا ٨ ژمارە');
                    return;
                }
                if (pin !== pin2) {
                    alert((typeof t === 'function' ? t('wh_pin_mismatch') : '') || 'پاسۆرد وەک ئێک نینن');
                    return;
                }
                var fdS = new FormData();
                fdS.append('action', 'set_warehouse_pin');
                fdS.append('warehouse_id', String(whId));
                fdS.append('pin', pin);
                fetch('?action=set_warehouse_pin', { method: 'POST', body: fdS, credentials: 'same-origin' })
                    .then(function(r) { return r.json(); })
                    .then(function(res) {
                        if (res.status !== 'success') { alert(res.message || 'هەڵە'); return; }
                        var w = (db.warehouses || []).find(function(x) { return Number(x.id) === whId; });
                        if (w) w.has_pin = 1;
                        closeWarehousePinModal();
                        if (typeof showToast === 'function') showToast((typeof t === 'function' ? t('wh_pin_saved') : '') || 'پاسۆرد هاتە پاراستن', 'success');
                        if (typeof renderWmsWarehouseHub === 'function') renderWmsWarehouseHub();
                    });
                return;
            }
            window.unlockWarehouseWithPin(whId, pin);
        };
        window.clearWarehousePin = function() {
            var whId = Number(window._whPinTargetId) || 0;
            if (!whId) return;
            if (!confirm((typeof t === 'function' ? t('wh_pin_clear_confirm') : '') || 'پاسۆردێ ڤێ کۆگەهێ ژێببیت؟')) return;
            var fd = new FormData();
            fd.append('action', 'set_warehouse_pin');
            fd.append('warehouse_id', String(whId));
            fd.append('clear', '1');
            fetch('?action=set_warehouse_pin', { method: 'POST', body: fd, credentials: 'same-origin' })
                .then(function(r) { return r.json(); })
                .then(function(res) {
                    if (res.status !== 'success') { alert(res.message || 'هەڵە'); return; }
                    var w = (db.warehouses || []).find(function(x) { return Number(x.id) === whId; });
                    if (w) w.has_pin = 0;
                    closeWarehousePinModal();
                    if (typeof showToast === 'function') showToast((typeof t === 'function' ? t('wh_pin_cleared') : '') || 'پاسۆرد هاتە ژێبرن', 'success');
                    if (typeof renderWmsWarehouseHub === 'function') renderWmsWarehouseHub();
                });
        };
        window.unlockWarehouseWithPin = function(whId, pin) {
            var fd = new FormData();
            fd.append('action', 'unlock_warehouse');
            fd.append('warehouse_id', String(whId));
            if (pin) fd.append('pin', pin);
            fetch('?action=unlock_warehouse', { method: 'POST', body: fd, credentials: 'same-origin' })
                .then(function(r) { return r.json(); })
                .then(function(res) {
                    if (res.status !== 'success') { alert(res.message || 'هەڵە'); return; }
                    if (db) db.open_warehouse_id = Number(res.open_warehouse_id) || Number(whId);
                    closeWarehousePinModal();
                    var hid = document.getElementById('wms-filter-warehouse');
                    if (hid) hid.value = String(whId);
                    if (typeof invalidateWmsWarehouseCache === 'function') invalidateWmsWarehouseCache();
                    if (typeof renderWarehouse === 'function') renderWarehouse();
                    if (typeof renderWmsWarehouseHub === 'function') renderWmsWarehouseHub();
                    if (typeof syncPosSaleWarehouseBtn === 'function') syncPosSaleWarehouseBtn();
                    if (typeof refreshAllStockDisplaysFromState === 'function') refreshAllStockDisplaysFromState();
                    if (typeof showToast === 'function') {
                        var w = (db.warehouses || []).find(function(x) { return Number(x.id) === Number(whId); });
                        showToast(((typeof t === 'function' ? t('wh_unlocked') : '') || 'کۆگەه ڤەکری') + (w ? (': ' + w.name) : ''), 'success');
                    }
                });
        };
        window.lockOpenWarehouse = function() {
            var fd = new FormData();
            fd.append('action', 'lock_warehouse');
            fetch('?action=lock_warehouse', { method: 'POST', body: fd, credentials: 'same-origin' })
                .then(function(r) { return r.json(); })
                .then(function(res) {
                    if (res.status !== 'success') { alert(res.message || 'هەڵە'); return; }
                    if (db) db.open_warehouse_id = 0;
                    if (typeof renderWmsWarehouseHub === 'function') renderWmsWarehouseHub();
                    if (typeof syncPosSaleWarehouseBtn === 'function') syncPosSaleWarehouseBtn();
                    if (typeof refreshAllStockDisplaysFromState === 'function') refreshAllStockDisplaysFromState();
                    if (typeof showToast === 'function') showToast((typeof t === 'function' ? t('wh_locked') : '') || 'کۆگەه هاتە گرتن', 'info');
                });
        };
        window.requestOpenWarehouse = function(whId) {
            var w = (db && db.warehouses) ? db.warehouses.find(function(x) { return Number(x.id) === Number(whId); }) : null;
            if (!w) return;
            if (Number(w.has_pin) === 1 && Number(db.open_warehouse_id) !== Number(whId)) {
                openWarehousePinModal('unlock', whId);
                return;
            }
            unlockWarehouseWithPin(whId, '');
        };
        window.posEnsureSaleWarehouseOpen = function() {
            var id = typeof getSaleWarehouseId === 'function' ? getSaleWarehouseId() : 0;
            if (id > 0) return true;
            if (window.anyWarehouseHasPin && window.anyWarehouseHasPin()) {
                if (typeof showToast === 'function') showToast((typeof t === 'function' ? t('wh_sale_need_unlock') : '') || 'پێش فرۆتنێ کۆگەهەکێ ڤەکە ب پاسۆرد', 'error');
                else alert((typeof t === 'function' ? t('wh_sale_need_unlock') : '') || 'پێش فرۆتنێ کۆگەهەکێ ڤەکە ب پاسۆرد');
                if (typeof openPosWarehousePicker === 'function') openPosWarehousePicker();
                return false;
            }
            return true;
        };
        window.openPosWarehousePicker = function() {
            var list = (db && db.warehouses) ? db.warehouses : [];
            if (!list.length) return;
            var m = document.getElementById('modal-wh-pick');
            var box = document.getElementById('wh-pick-list');
            if (!box || !m) {
                var first = list[0];
                if (first) requestOpenWarehouse(first.id);
                return;
            }
            var openId = Number(db.open_warehouse_id) || 0;
            box.innerHTML = list.map(function(w) {
                var locked = Number(w.has_pin) === 1 && Number(w.id) !== openId;
                var isOpen = Number(w.id) === openId;
                return '<button type="button" class="btn pos-wh-pick-btn' + (isOpen ? ' is-open' : '') + '" onclick="requestOpenWarehouse(' + w.id + ');closePosWarehousePicker();">' +
                    '<i class="fas ' + (locked ? 'fa-lock' : (isOpen ? 'fa-unlock' : 'fa-warehouse')) + '"></i> ' +
                    escapeHtml(w.name || '') +
                    (isOpen ? ' ✓' : '') +
                    '</button>';
            }).join('');
            m.style.display = 'flex';
        };
        window.closePosWarehousePicker = function() {
            var m = document.getElementById('modal-wh-pick');
            if (m) m.style.display = 'none';
        };
        window.applyMultiWarehouseVisibility = function() {
            var on = canUseMultiWarehouse();
            var proOn = isMultiWarehouseProEnabled();
            document.querySelectorAll('[data-multi-wh-only]').forEach(function(el) {
                el.style.display = on ? '' : 'none';
            });
            document.querySelectorAll('[data-multi-wh-active-only]').forEach(function(el) {
                el.style.display = proOn ? '' : 'none';
            });
            document.querySelectorAll('[data-multi-wh-teaser-trigger]').forEach(function(el) {
                el.style.display = 'none';
            });
            var teaser = document.getElementById('wms-multi-wh-premium-teaser');
            var hub = document.getElementById('wms-warehouse-hub');
            if (teaser) teaser.style.display = 'none';
            if (hub) hub.style.display = proOn ? '' : 'none';
            if (typeof renderMultiWhPremiumTeaserSlots === 'function') renderMultiWhPremiumTeaserSlots(false);
            document.querySelectorAll('.perm-multi-warehouse-wrap').forEach(function(el) {
                el.style.display = proOn ? '' : 'none';
            });
            if (typeof syncPosSaleWarehouseBtn === 'function') syncPosSaleWarehouseBtn();
            if (!proOn) {
                if (hub) hub.classList.remove('is-manage-mode');
                if (typeof cancelEditWarehouse === 'function') cancelEditWarehouse();
                var hid = document.getElementById('wms-filter-warehouse');
                if (hid && hid.value !== '') {
                    hid.value = '';
                    if (typeof invalidateWmsWarehouseCache === 'function') invalidateWmsWarehouseCache();
                    if (!window._wmsHubRendering && typeof renderWarehouse === 'function') renderWarehouse();
                }
            }
        };
        window.onEnableMultiWarehouseChange = function(el) {
            if (window.db && window.db.settings) db.settings.enableMultiWarehouse = !!(el && el.checked);
            if (typeof applyMultiWarehouseVisibility === 'function') applyMultiWarehouseVisibility();
            if (typeof syncSettingsLockedPreviewCards === 'function') syncSettingsLockedPreviewCards();
            if (typeof updateToggleCards === 'function') updateToggleCards();
            if (typeof saveSettings !== 'function') return;
            saveSettings().then(function() {
                if (typeof applyMultiWarehouseVisibility === 'function') applyMultiWarehouseVisibility();
                if (typeof refreshAllStockDisplaysFromState === 'function') refreshAllStockDisplaysFromState();
                if (typeof renderWarehouse === 'function') renderWarehouse();
            }).catch(function() {});
        };
        function getMultiWhPremiumTeaserCompactHtml() {
            return '<div class="wms-mwh-teaser wms-mwh-teaser--compact card">' +
                '<div class="wms-mwh-teaser__glow" aria-hidden="true"></div>' +
                '<div class="wms-mwh-teaser__inner wms-mwh-teaser__inner--compact">' +
                    '<div class="wms-mwh-teaser__content">' +
                        '<div class="wms-mwh-teaser__badges"><span class="wms-mwh-teaser__badge-pro">FEAT</span><span class="wms-mwh-teaser__badge-price" data-pos-price="feature">$50</span></div>' +
                        '<h3 class="wms-mwh-teaser__title"><i class="fas fa-lock"></i> <span data-i18n="multi_wh_teaser_title">کۆگای فرە — بەڕێوەبردنی چەند شوێن</span></h3>' +
                        '<p class="wms-mwh-teaser__desc" data-i18n="multi_wh_teaser_desc">ئەم بەشە لە پلانی Pro ـە. چەند کۆگە دروست بکە، کاڵا بگوازەوە، وەسڵ چاپ بکە.</p>' +
                        '<button type="button" class="btn btn-brand wms-mwh-teaser__cta" onclick="if(typeof openMultiWarehousePremiumUpsell===\'function\')openMultiWarehousePremiumUpsell();"><i class="fas fa-unlock-alt"></i> <span data-i18n="multi_wh_teaser_cta">بیکڕە و چالاک بکە — $224</span></button>' +
                    '</div>' +
                '</div></div>';
        }
        window.renderMultiWhPremiumTeaserSlots = function(show) {
            var html = show ? getMultiWhPremiumTeaserCompactHtml() : '';
            document.querySelectorAll('[data-multi-wh-teaser-slot]').forEach(function(slot) {
                slot.style.display = show ? '' : 'none';
                if (show) {
                    slot.innerHTML = html;
                    if (typeof applyI18nSubtree === 'function') applyI18nSubtree(slot);
                    if (typeof applyPosPremiumPricingLabels === 'function') applyPosPremiumPricingLabels(slot);
                } else {
                    slot.innerHTML = '';
                }
            });
        };
        window.openMultiWarehousePremiumUpsell = function() {
            if (typeof showPremiumLockedPurchasePopup === 'function') {
                var title = (typeof t === 'function') ? t('settings_t_multi_warehouse') : 'کۆگای فرە (Pro)';
                showPremiumLockedPurchasePopup(title, 'set-enable-multi-warehouse');
            }
        };
        function getActiveWarehouseChoice(scope) {
            var key = 'pos_wh_' + (scope || 'default');
            try {
                var v = localStorage.getItem(key);
                if (v) return parseInt(v, 10) || 0;
            } catch (e) {}
            return getDefaultWarehouseId();
        }
        window.saveActiveWarehouseChoice = function(scope, val) {
            try { localStorage.setItem('pos_wh_' + (scope || 'default'), String(val || '')); } catch (e) {}
        };
        function getActiveWmsWarehouseId() {
            var hid = document.getElementById('wms-filter-warehouse');
            if (hid && hid.value) return parseInt(hid.value, 10) || 0;
            return 0;
        }
        /** Qty is always one warehouse — never the sum of every location (that made POS say «نەما» while the list showed extra). */
        function resolveWmsQtyWarehouseId() {
            var explicit = getActiveWmsWarehouseId();
            if (explicit) return explicit;
            return getWorkingWarehouseId();
        }
        window.resolveWmsQtyWarehouseId = resolveWmsQtyWarehouseId;
        window.getProductQtyForWarehouse = function(p, whId) {
            if (!p) return 0;
            if (typeof isMultiWarehouseProEnabled === 'function' && !isMultiWarehouseProEnabled()) {
                return getProductQtySumAllWarehouses(p);
            }
            whId = Number(whId) || 0;
            if (!whId) {
                whId = (typeof getWorkingWarehouseId === 'function' ? getWorkingWarehouseId() : 0) || getDefaultWarehouseId();
            }
            if (!whId) return parseFloat(p.qty) || 0;
            var rows = (db && db.warehouse_stock) ? db.warehouse_stock : [];
            for (var i = 0; i < rows.length; i++) {
                if (Number(rows[i].product_id) === Number(p.id) && Number(rows[i].warehouse_id) === Number(whId)) {
                    return parseFloat(rows[i].qty) || 0;
                }
            }
            return 0;
        };
        function getProductQtySumAllWarehouses(p) {
            if (!p) return 0;
            var rows = (db && db.warehouse_stock) ? db.warehouse_stock : [];
            if (!rows.length) return parseFloat(p.qty) || 0;
            var sum = 0;
            var found = false;
            for (var i = 0; i < rows.length; i++) {
                if (Number(rows[i].product_id) === Number(p.id)) {
                    sum += parseFloat(rows[i].qty) || 0;
                    found = true;
                }
            }
            return found ? sum : (parseFloat(p.qty) || 0);
        }
        window.getProductQtySumAllWarehouses = getProductQtySumAllWarehouses;
        function warehouseItemCount(whId) {
            var n = 0;
            (db.warehouse_stock || []).forEach(function(r) {
                if (Number(r.warehouse_id) === Number(whId) && (parseFloat(r.qty) || 0) > 0) n++;
            });
            return n;
        }
        function mapProductsForWarehouseView(items, whId) {
            var multiOn = typeof isMultiWarehouseProEnabled === 'function' && isMultiWarehouseProEnabled();
            var effectiveWh = multiOn ? (whId || resolveWmsQtyWarehouseId()) : 0;
            return (items || []).map(function(p) {
                var copy = Object.assign({}, p);
                if (multiOn && effectiveWh) {
                    copy.qty = getProductQtyForWarehouse(p, effectiveWh);
                    copy._warehouse_id = effectiveWh;
                    copy._qty_is_total = false;
                } else {
                    copy.qty = getProductQtySumAllWarehouses(p);
                    copy._warehouse_id = 0;
                    copy._qty_is_total = true;
                }
                return copy;
            });
        }
        function fillWarehouseSelectEl(sel, opts) {
            if (!sel) return;
            opts = opts || {};
            var list = (db && db.warehouses) ? db.warehouses.slice() : [];
            var html = list.map(function(w) {
                return '<option value="' + w.id + '">' + escapeHtml(w.name) + (Number(w.is_default) === 1 ? ' ★' : '') + '</option>';
            }).join('');
            sel.innerHTML = html || '<option value="">—</option>';
            var want = opts.selectedId || getDefaultWarehouseId();
            if (want) sel.value = String(want);
        }
        window.fillWarehouseSelects = function() {
            fillWarehouseSelectEl(document.getElementById('purchase-warehouse-select'), { selectedId: getActiveWarehouseChoice('purchase') });
            fillWarehouseSelectEl(document.getElementById('p-warehouse-select'), { selectedId: getActiveWarehouseChoice('product') });
            fillWarehouseSelectEl(document.getElementById('stocktake-warehouse-select'), { selectedId: getActiveWarehouseChoice('stocktake') });
            fillWarehouseSelectEl(document.getElementById('wh-transfer-from'), { selectedId: getActiveWarehouseChoice('transfer_from') });
            fillWarehouseSelectEl(document.getElementById('wh-transfer-to'), { selectedId: getActiveWarehouseChoice('transfer_to') });
            fillWarehouseSelectEl(document.getElementById('wh-tm-from'), { selectedId: getActiveWarehouseChoice('transfer_from') });
            fillWarehouseSelectEl(document.getElementById('wh-tm-to'), { selectedId: getActiveWarehouseChoice('transfer_to') });
            fillWhTransferProducts();
        };
        function applyProductFormStockFromQty(p, totalPieces) {
            if (!p || !p.trackStock) return;
            var uspEl = document.getElementById('p-unit-show-pack');
            var uscEl = document.getElementById('p-unit-show-carton');
            var showPack = uspEl && uspEl.value === '1';
            var showCarton = uscEl && uscEl.value === '1';
            var ppp = (p.pieces_per_pack != null && p.pieces_per_pack >= 1) ? p.pieces_per_pack : 1;
            var ppc = (p.packs_per_carton != null && p.packs_per_carton >= 1) ? p.packs_per_carton : 1;
            if (!showPack && showCarton) ppc = 1;
            if (!showPack && !showCarton) { ppp = 1; ppc = 1; }
            if (showPack && !showCarton) ppc = 1;
            var piecesPerCarton = ppp * ppc;
            var cartons = 0, packs = 0, pieces = 0;
            var modeForEdit = (typeof getProductQtyMode === 'function') ? getProductQtyMode(p) : 'piece';
            if (modeForEdit === 'kilo') {
                pieces = Math.round(Math.max(0, totalPieces) * 1000) / 1000;
            } else if (!showCarton && !showPack) {
                pieces = Math.floor(totalPieces);
            } else if (!showCarton && showPack) {
                packs = Math.floor(totalPieces / ppp);
                pieces = totalPieces % ppp;
            } else if (showCarton && !showPack) {
                cartons = Math.floor(totalPieces / piecesPerCarton);
                pieces = totalPieces % piecesPerCarton;
            } else {
                cartons = Math.floor(totalPieces / piecesPerCarton);
                var remainder = totalPieces % piecesPerCarton;
                packs = Math.floor(remainder / ppp);
                pieces = remainder % ppp;
            }
            var elC = document.getElementById('p-stock-carton');
            var elP = document.getElementById('p-stock-pack');
            var elI = document.getElementById('p-stock-piece');
            if (elC) elC.value = cartons;
            if (elP) elP.value = packs;
            if (elI) elI.value = pieces;
            if (typeof calcTotalStockFromTable === 'function') calcTotalStockFromTable();
        }
        window.onProductWarehouseChange = function() {
            var sel = document.getElementById('p-warehouse-select');
            if (sel && typeof saveActiveWarehouseChoice === 'function') saveActiveWarehouseChoice('product', sel.value);
            var pidEl = document.getElementById('p-id');
            if (!pidEl || !pidEl.value) return;
            var p = db && db.products ? db.products.find(function(x) { return x.id == pidEl.value; }) : null;
            if (!p || !p.trackStock) return;
            var whId = parseInt(sel && sel.value ? sel.value : '0', 10) || 0;
            var totalPieces = getProductQtyForWarehouse(p, whId);
            applyProductFormStockFromQty(p, totalPieces);
        };
        function fillWhTransferProducts() {
            var sel = document.getElementById('wh-transfer-product');
            var fromSel = document.getElementById('wh-transfer-from');
            if (!sel || !fromSel) return;
            var fromId = parseInt(fromSel.value, 10) || 0;
            var items = (db.products || []).filter(function(p) { return p.trackStock && getProductQtyForWarehouse(p, fromId) > 0; });
            sel.innerHTML = items.map(function(p) {
                return '<option value="' + p.id + '">' + escapeHtml(p.name || 'ئایتم') + ' (' + formatQtyForDisplay(getProductQtyForWarehouse(p, fromId), p) + ')</option>';
            }).join('') || '<option value="">کاڵا نییە</option>';
        }
        window.selectWmsWarehouseFilter = function(whId) {
            whId = Number(whId) || 0;
            if (!whId) whId = getWorkingWarehouseId() || getDefaultWarehouseId();
            var w = (db && db.warehouses) ? db.warehouses.find(function(x) { return Number(x.id) === Number(whId); }) : null;
            if (w && Number(w.has_pin) === 1 && Number(db.open_warehouse_id) !== Number(whId)) {
                requestOpenWarehouse(whId);
                return;
            }
            var hid = document.getElementById('wms-filter-warehouse');
            if (hid) hid.value = whId ? String(whId) : '';
            if (db && whId) db.open_warehouse_id = Number(whId);
            invalidateWmsWarehouseCache();
            renderWarehouse();
            if (typeof syncPosSaleWarehouseBtn === 'function') syncPosSaleWarehouseBtn();
            if (typeof refreshAllStockDisplaysFromState === 'function') refreshAllStockDisplaysFromState();
            if (w && Number(w.has_pin) !== 1 && whId) {
                var fd = new FormData();
                fd.append('action', 'unlock_warehouse');
                fd.append('warehouse_id', String(whId));
                fetch('?action=unlock_warehouse', { method: 'POST', body: fd, credentials: 'same-origin' })
                    .then(function(r) { return r.json(); })
                    .then(function(res) {
                        if (res && res.status === 'success' && db) {
                            db.open_warehouse_id = Number(res.open_warehouse_id) || Number(whId);
                        }
                    }).catch(function() {});
            }
        };
        function wmsWhIconMeta(w) {
            if (Number(w.is_default) === 1) return { icon: 'fa-star', cls: 'wms-wh-chip__ic--default' };
            var hues = ['blue', 'teal', 'violet', 'amber', 'rose', 'emerald'];
            return { icon: 'fa-warehouse', cls: 'wms-wh-chip__ic--' + hues[Number(w.id) % hues.length] };
        }
        function wmsDisplayWhName(name) {
            var n = String(name || '');
            if (typeof getCurrentLanguage === 'function' && getCurrentLanguage() === 'ar' && typeof t === 'function') {
                if (n === 'کۆگەی سەرەکی' || n === 'کوگەی سەرەکی') return t('wh_default_warehouse_name') || n;
            }
            return n;
        }
        function wmsWhChipInner(w, cnt) {
            var meta = wmsWhIconMeta(w);
            var openId = Number(db && db.open_warehouse_id) || 0;
            var isSale = openId && Number(w.id) === openId;
            var locked = Number(w.has_pin) === 1 && !isSale;
            var lockHtml = locked
                ? '<span class="wms-wh-chip__lock" aria-hidden="true"><i class="fas fa-lock"></i></span>'
                : (isSale ? '<span class="wms-wh-chip__lock wms-wh-chip__lock--open" aria-hidden="true"><i class="fas fa-unlock"></i></span>' : '');
            return '<span class="wms-wh-chip__ic ' + meta.cls + '" aria-hidden="true"><i class="fas ' + meta.icon + '"></i></span>' +
                '<span class="wms-wh-chip__lbl">' + escapeHtml(wmsDisplayWhName(w.name)) + '</span>' +
                lockHtml +
                '<span class="wms-wh-chip__cnt">' + cnt + '</span>';
        }
        function isWmsWhManageMode() {
            var hub = document.getElementById('wms-warehouse-hub');
            return !!(hub && hub.classList.contains('is-manage-mode'));
        }
        function syncWmsWhManageToggle() {
            var btn = document.getElementById('wms-wh-manage-toggle');
            var bar = document.querySelector('.wms-wh-quick-bar');
            var on = isWmsWhManageMode();
            if (btn) {
                btn.classList.toggle('is-active', on);
                btn.title = on ? 'داخستنی بەڕێوەبردن' : 'بەڕێوەبردنی کۆگاکان';
            }
            if (bar) {
                if (on) bar.removeAttribute('hidden');
                else bar.setAttribute('hidden', '');
            }
        }
        window.toggleWmsWhManageMode = function() {
            if (typeof canUseMultiWarehouse === 'function' && !canUseMultiWarehouse()) {
                if (typeof isMultiWarehouseProEnabled === 'function' && !isMultiWarehouseProEnabled() && typeof showPremiumLockedPurchasePopup === 'function') {
                    showPremiumLockedPurchasePopup('کۆگای فرە (Pro)', 'set-enable-multi-warehouse');
                } else {
                    alert((typeof t === 'function') ? t('toast_multi_wh_perm_denied') : 'مۆڵەت نییە بۆ کۆگای فرە');
                }
                return;
            }
            var hub = document.getElementById('wms-warehouse-hub');
            if (!hub) return;
            if (isWmsWhManageMode()) {
                hub.classList.remove('is-manage-mode');
                cancelEditWarehouse();
            } else {
                hub.classList.add('is-manage-mode');
                var inp = document.getElementById('wms-wh-quick-name');
                if (inp) setTimeout(function() { try { inp.focus(); } catch (eF) {} }, 80);
            }
            syncWmsWhManageToggle();
            renderWmsWarehouseHub();
        };
        function syncWmsWhQuickBarMode() {
            var editHid = document.getElementById('wms-wh-edit-id');
            var inEdit = editHid && editHid.value;
            var addIcon = document.getElementById('wms-wh-quick-add-icon');
            var addLabel = document.getElementById('wms-wh-quick-add-label');
            var cancelBtn = document.getElementById('wms-wh-cancel-edit-btn');
            var inp = document.getElementById('wms-wh-quick-name');
            if (addIcon) addIcon.className = inEdit ? 'fas fa-save' : 'fas fa-plus';
            if (addLabel) addLabel.textContent = inEdit ? 'پاراستن' : 'زیادکردن';
            if (cancelBtn) cancelBtn.style.display = inEdit ? '' : 'none';
            if (inp) inp.placeholder = inEdit ? 'ناوی کۆگە دەستکاری بکە' : 'ناوی کۆگەی نوێ';
        }
        window.cancelEditWarehouse = function() {
            var editHid = document.getElementById('wms-wh-edit-id');
            var inp = document.getElementById('wms-wh-quick-name');
            if (editHid) editHid.value = '';
            if (inp) inp.value = '';
            syncWmsWhQuickBarMode();
        };
        window.startEditWarehouse = function(whId) {
            if (typeof canUseMultiWarehouse === 'function' && !canUseMultiWarehouse()) {
                if (typeof isMultiWarehouseProEnabled === 'function' && !isMultiWarehouseProEnabled() && typeof showPremiumLockedPurchasePopup === 'function') {
                    showPremiumLockedPurchasePopup('کۆگای فرە (Pro)', 'set-enable-multi-warehouse');
                } else {
                    alert((typeof t === 'function') ? t('toast_multi_wh_perm_denied') : 'مۆڵەت نییە بۆ کۆگای فرە');
                }
                return;
            }
            var hub = document.getElementById('wms-warehouse-hub');
            if (hub && !isWmsWhManageMode()) hub.classList.add('is-manage-mode');
            syncWmsWhManageToggle();
            var w = (db && db.warehouses) ? db.warehouses.find(function(x) { return Number(x.id) === Number(whId); }) : null;
            if (!w) return;
            var editHid = document.getElementById('wms-wh-edit-id');
            var inp = document.getElementById('wms-wh-quick-name');
            if (editHid) editHid.value = String(w.id);
            if (inp) { inp.value = w.name || ''; try { inp.focus(); inp.select(); } catch (eF) {} }
            syncWmsWhQuickBarMode();
        };
        window.deleteWarehouseQuick = function(whId) {
            if (!isWmsWhManageMode()) return;
            if (typeof canUseMultiWarehouse === 'function' && !canUseMultiWarehouse()) {
                if (typeof isMultiWarehouseProEnabled === 'function' && !isMultiWarehouseProEnabled() && typeof showPremiumLockedPurchasePopup === 'function') {
                    showPremiumLockedPurchasePopup('کۆگای فرە (Pro)', 'set-enable-multi-warehouse');
                } else {
                    alert((typeof t === 'function') ? t('toast_multi_wh_perm_denied') : 'مۆڵەت نییە بۆ کۆگای فرە');
                }
                return;
            }
            var w = (db && db.warehouses) ? db.warehouses.find(function(x) { return Number(x.id) === Number(whId); }) : null;
            var wName = w ? w.name : ('#' + whId);
            if (Number(w && w.is_default) === 1) { alert('ناتوانیت کۆگەی سەرەکی بسڕیتەوە'); return; }
            if (!confirm('دڵنیایت لە سڕینەوەی کۆگەی «' + wName + '»؟\nئەگەر کاڵا تێدابێت ناسڕدرێتەوە.')) return;
            var fd = new FormData();
            fd.append('action', 'delete_warehouse');
            fd.append('id', String(whId));
            fetch('?action=delete_warehouse', { method: 'POST', body: fd }).then(function(r) { return r.json(); }).then(function(res) {
                if (res.status === 'success') {
                    if (Number(getActiveWmsWarehouseId()) === Number(whId)) selectWmsWarehouseFilter(0);
                    cancelEditWarehouse();
                    if (typeof connectToDB === 'function') connectToDB(true).then(function() { renderWmsWarehouseHub(); renderWarehouse('all'); });
                    if (typeof showToast === 'function') showToast('کۆگە سڕایەوە: ' + wName, 'success');
                } else alert(res.message || 'هەڵە');
            });
        };
        window.renderWmsWarehouseHub = function() {
            if (window._wmsHubRendering) return;
            if (!db) return;
            window._wmsHubRendering = true;
            try {
            if (!db.warehouses) db.warehouses = [];
            var list = db.warehouses.slice();
            var badge = document.getElementById('wms-wh-count-badge');
            if (badge) badge.textContent = String(list.length);
            var chips = document.getElementById('wms-wh-chips');
            var hidAuto = document.getElementById('wms-filter-warehouse');
            var canWh = typeof canUseMultiWarehouse === 'function' && canUseMultiWarehouse();
            var proOn = typeof isMultiWarehouseProEnabled === 'function' && isMultiWarehouseProEnabled();
            var manageOn = isWmsWhManageMode();
            var activeId = getActiveWmsWarehouseId();
            if (!proOn) {
                if (chips) chips.innerHTML = '';
                if (hidAuto) hidAuto.value = '';
                fillWarehouseSelects();
                if (typeof applyMultiWarehouseVisibility === 'function') applyMultiWarehouseVisibility();
                if (typeof syncPosSaleWarehouseBtn === 'function') syncPosSaleWarehouseBtn();
                return;
            }
            if (list.length > 1 && !activeId) {
                var autoId = getWorkingWarehouseId() || getDefaultWarehouseId();
                if (autoId) {
                    if (hidAuto) hidAuto.value = String(autoId);
                    activeId = autoId;
                    if (db && !Number(db.open_warehouse_id)) {
                        var autoW = list.find(function(x) { return Number(x.id) === Number(autoId); });
                        if (autoW && Number(autoW.has_pin) !== 1) db.open_warehouse_id = Number(autoId);
                    }
                }
            }
            if (chips) {
                var cntMap = {};
                (db.warehouse_stock || []).forEach(function(r) {
                    if ((parseFloat(r.qty) || 0) > 0) {
                        var rid = Number(r.warehouse_id);
                        cntMap[rid] = (cntMap[rid] || 0) + 1;
                    }
                });
                var chipsHtml = '';
                if (list.length < 2) {
                    var allCnt = (db.products || []).filter(function(p){return p.trackStock;}).length;
                    var allLbl = (typeof t === 'function') ? t('wh_filter_all') : 'هەمی';
                    chipsHtml += '<button type="button" class="wms-wh-chip' + (!activeId ? ' is-active' : '') + '" onclick="selectWmsWarehouseFilter(0)">' +
                        '<span class="wms-wh-chip__ic wms-wh-chip__ic--all" aria-hidden="true"><i class="fas fa-layer-group"></i></span>' +
                        '<span class="wms-wh-chip__lbl">' + escapeHtml(allLbl) + '</span><span class="wms-wh-chip__cnt">' + allCnt + '</span></button>';
                }
                list.forEach(function(w) {
                    var cnt = cntMap[Number(w.id)] || 0;
                    var isActive = Number(activeId) === Number(w.id);
                    var isSaleOpen = Number(db.open_warehouse_id) === Number(w.id);
                    var inner = wmsWhChipInner(w, cnt);
                    var chipCls = 'wms-wh-chip' + (isActive ? ' is-active' : '') + (isSaleOpen ? ' is-sale-open' : '') + (Number(w.has_pin) === 1 && !isSaleOpen ? ' is-locked' : '');
                    if (canWh && manageOn) {
                        var wrapCls = 'wms-wh-chip-wrap' + (isActive ? ' is-active' : '');
                        chipsHtml += '<span class="' + wrapCls + '">';
                        chipsHtml += '<button type="button" class="' + chipCls + '" onclick="selectWmsWarehouseFilter(' + w.id + ')">' + inner + '</button>';
                        chipsHtml += '<span class="wms-wh-chip-actions">';
                        chipsHtml += '<button type="button" class="wms-wh-chip-act wms-wh-chip-act--edit" title="دەستکاری" onclick="event.stopPropagation();startEditWarehouse(' + w.id + ')"><i class="fas fa-pen"></i></button>';
                        chipsHtml += '<button type="button" class="wms-wh-chip-act wms-wh-chip-act--pin" title="پاسۆرد" onclick="event.stopPropagation();openWarehousePinModal(\'set\',' + w.id + ')"><i class="fas fa-key"></i></button>';
                        if (Number(w.is_default) !== 1) {
                            chipsHtml += '<button type="button" class="wms-wh-chip-act wms-wh-chip-act--del" title="سڕینەوە" onclick="event.stopPropagation();deleteWarehouseQuick(' + w.id + ')"><i class="fas fa-trash-alt"></i></button>';
                        }
                        chipsHtml += '</span></span>';
                    } else {
                        chipsHtml += '<button type="button" class="' + chipCls + '" onclick="selectWmsWarehouseFilter(' + w.id + ')">' + inner + '</button>';
                    }
                });
                chips.innerHTML = chipsHtml;
            }
            fillWarehouseSelects();
            var fromSel = document.getElementById('wh-transfer-from');
            if (fromSel) fromSel.onchange = fillWhTransferProducts;
            if (typeof applyMultiWarehouseVisibility === 'function') applyMultiWarehouseVisibility();
            syncWmsWhManageToggle();
            syncWmsWhQuickBarMode();
            if (typeof syncPosSaleWarehouseBtn === 'function') syncPosSaleWarehouseBtn();
            } finally {
                window._wmsHubRendering = false;
            }
        };
        window.quickAddWarehouse = function() {
            if (!isWmsWhManageMode()) return;
            if (typeof canUseMultiWarehouse === 'function' && !canUseMultiWarehouse()) {
                if (typeof isMultiWarehouseProEnabled === 'function' && !isMultiWarehouseProEnabled() && typeof showPremiumLockedPurchasePopup === 'function') {
                    showPremiumLockedPurchasePopup('کۆگای فرە (Pro)', 'set-enable-multi-warehouse');
                } else {
                    alert((typeof t === 'function') ? t('toast_multi_wh_perm_denied') : 'مۆڵەت نییە بۆ کۆگای فرە');
                }
                return;
            }
            var inp = document.getElementById('wms-wh-quick-name');
            var name = inp && inp.value ? String(inp.value).trim() : '';
            if (!name) { alert('تکایە ناوی کۆگە بنووسە'); return; }
            var editHid = document.getElementById('wms-wh-edit-id');
            var editId = editHid && editHid.value ? parseInt(editHid.value, 10) : 0;
            var fd = new FormData();
            fd.append('action', 'save_warehouse');
            fd.append('name', name);
            var pinInp = document.getElementById('wms-wh-quick-pin');
            var pinVal = pinInp && pinInp.value ? String(pinInp.value).replace(/\D/g, '') : '';
            if (pinVal) fd.append('pin', pinVal);
            if (editId > 0) {
                var existing = (db.warehouses || []).find(function(x) { return Number(x.id) === editId; });
                fd.append('id', String(editId));
                fd.append('code', (existing && existing.code) ? existing.code : ('WH' + editId));
            } else {
                fd.append('code', 'WH' + Date.now());
                if ((db.warehouses || []).length === 0) fd.append('is_default', '1');
            }
            var addBtn = document.getElementById('wms-wh-quick-add-btn');
            if (addBtn) { addBtn.disabled = true; addBtn.classList.add('is-busy'); }
            fetch('?action=save_warehouse', { method: 'POST', body: fd }).then(function(r) { return r.json(); }).then(function(res) {
                if (res.status === 'success') {
                    cancelEditWarehouse();
                    if (inp) { try { inp.focus(); } catch (eF2) {} }
                    var pinInpOk = document.getElementById('wms-wh-quick-pin');
                    if (pinInpOk) pinInpOk.value = '';
                    if (typeof connectToDB === 'function') connectToDB(true).then(function() { renderWmsWarehouseHub(); renderWarehouse('all'); });
                    if (typeof showToast === 'function') showToast(editId > 0 ? ('کۆگە نوێکرایەوە: ' + name) : ('کۆگە زیادکرا: ' + name), 'success');
                } else alert(res.message || 'هەڵە');
            }).finally(function() {
                if (addBtn) { addBtn.disabled = false; addBtn.classList.remove('is-busy'); }
            });
        };
        function whFmtNum(n) {
            var v = parseFloat(n);
            if (isNaN(v)) return '0';
            return (Math.abs(v - Math.round(v)) < 0.0001) ? String(Math.round(v)) : v.toFixed(2);
        }
        function wthLinesSummary(tr, maxItems) {
            var lines = tr && tr.lines ? tr.lines : [];
            if (!lines.length) return '<span style="color:var(--text-muted);">—</span>';
            var n = maxItems || 5;
            var parts = lines.slice(0, n).map(function(ln) {
                return escapeHtml(ln.product_name || ('#' + ln.product_id)) + ' <b>×' + whFmtNum(ln.qty) + '</b>';
            });
            if (lines.length > n) parts.push('<span style="color:var(--text-muted);">+' + (lines.length - n) + ' زیاتر</span>');
            return parts.join('<br>');
        }
        function buildWhTransferDraft(fromId, toId, note, lines, res) {
            var fromW = (db && db.warehouses) ? db.warehouses.find(function(x) { return Number(x.id) === Number(fromId); }) : null;
            var toW = (db && db.warehouses) ? db.warehouses.find(function(x) { return Number(x.id) === Number(toId); }) : null;
            var detailLines = (lines || []).map(function(ln) {
                var p = (db && db.products) ? db.products.find(function(x) { return Number(x.id) === Number(ln.product_id); }) : null;
                var cost = p ? (parseFloat(p.cost) || 0) : 0;
                var qty = parseFloat(ln.qty) || 0;
                return {
                    product_id: ln.product_id,
                    product_name: p ? p.name : ('#' + ln.product_id),
                    qty: qty,
                    unit_cost: cost,
                    line_total: cost * qty
                };
            });
            var totalQty = detailLines.reduce(function(s, ln) { return s + (parseFloat(ln.qty) || 0); }, 0);
            return {
                id: res && res.id ? res.id : 0,
                transaction_id: (res && res.transaction_id) ? res.transaction_id : '',
                from_warehouse_id: fromId,
                to_warehouse_id: toId,
                from_warehouse_name: fromW ? fromW.name : whTransferWarehouseName(fromId),
                to_warehouse_name: toW ? toW.name : whTransferWarehouseName(toId),
                date: new Date().toISOString().slice(0, 19).replace('T', ' '),
                user: (currentUser && currentUser.name) ? currentUser.name : 'System',
                note: note || '',
                total_qty: totalQty,
                lines: detailLines
            };
        }
        function whTransferLinesTableHtml(tr) {
            var lines = (tr && tr.lines) ? tr.lines : [];
            if (!lines.length) {
                return '<tr><td colspan="4" style="text-align:center;padding:20px;color:var(--text-muted);">هیچ ئایتمێک نییە</td></tr>';
            }
            return lines.map(function(ln) {
                return '<tr><td>' + escapeHtml(ln.product_name || ('#' + ln.product_id)) + '</td><td style="text-align:center;">' + whFmtNum(ln.qty) + '</td><td style="text-align:center;">' + whFmtNum(ln.unit_cost) + '</td><td style="text-align:left;">' + whFmtNum(ln.line_total) + '</td></tr>';
            }).join('');
        }
        window.showWhTransferReceipt = function(tr, opts) {
            if (!tr) return;
            opts = opts || {};
            window._whTransferDetailCache = tr;
            var modal = document.getElementById('wh-transfer-detail-modal');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'wh-transfer-detail-modal';
                modal.className = 'modal-overlay wh-transfer-receipt-modal';
                modal.style.zIndex = '10007';
                document.body.appendChild(modal);
                modal.onclick = function(evt) { if (evt.target === modal) modal.style.display = 'none'; };
            }
            var linesHtml = whTransferLinesTableHtml(tr);
            var receiptNo = typeof formatWhTransferReceiptNo === 'function' ? formatWhTransferReceiptNo(tr) : (tr.transaction_id || String(tr.id));
            modal.innerHTML = '<div class="glass-card wh-transfer-receipt-card">' +
                '<div class="wh-transfer-receipt__head">' +
                    '<div><h3 class="wh-transfer-receipt__title"><i class="fas fa-file-invoice"></i> ڕاپۆرتی گواستنەوە #' + escapeHtml(receiptNo) + '</h3>' +
                    '<p class="wh-transfer-receipt__meta">' + escapeHtml(tr.date || '') + ' — ' + escapeHtml(tr.user || '') + '</p></div>' +
                    '<button type="button" class="btn btn-sm btn-danger" onclick="document.getElementById(\'wh-transfer-detail-modal\').style.display=\'none\';"><i class="fas fa-times"></i></button>' +
                '</div>' +
                '<div class="wh-transfer-receipt__route"><i class="fas fa-warehouse"></i> ' + escapeHtml(tr.from_warehouse_name || '') + ' <i class="fas fa-long-arrow-alt-left"></i> ' + escapeHtml(tr.to_warehouse_name || '') + '</div>' +
                (tr.note ? '<p class="wh-transfer-receipt__note"><i class="fas fa-sticky-note"></i> ' + escapeHtml(tr.note) + '</p>' : '') +
                '<div class="wh-transfer-receipt__table-wrap"><table class="report-table wh-transfer-receipt__table"><thead><tr><th>ئایتم</th><th>ژمارە</th><th>کرین</th><th>کۆ</th></tr></thead><tbody>' + linesHtml + '</tbody></table></div>' +
                '<div class="wh-transfer-receipt__foot">' +
                    '<span><b>کۆی گشتی:</b> ' + whFmtNum(tr.total_qty) + ' ئایتم</span>' +
                    '<div class="wh-transfer-receipt__actions">' +
                        '<button type="button" class="btn btn-dark" onclick="document.getElementById(\'wh-transfer-detail-modal\').style.display=\'none\';">داخستن</button>' +
                        '<button type="button" class="btn btn-brand" onclick="printWhTransferReport(' + (tr.id || 0) + ')"><i class="fas fa-print"></i> چاپ</button>' +
                    '</div></div></div>';
            modal.style.display = 'flex';
            if (typeof renderWhTransferHistoryPanel === 'function') renderWhTransferHistoryPanel();
            if (opts.autoPrint) {
                setTimeout(function() {
                    if (typeof printWhTransferReport === 'function') printWhTransferReport(tr.id);
                }, 450);
            }
        };
        function whTransferWarehouseName(id) {
            var w = (db && db.warehouses) ? db.warehouses.find(function(x) { return Number(x.id) === Number(id); }) : null;
            return w ? w.name : ('#' + id);
        }
        var whTransferQtyMap = {};
        var whTransferGridTimeout = null;
        function syncWhTransferQtyFromDom() {
            document.querySelectorAll('.wh-tm-qty-inp').forEach(function(inp) {
                var pid = parseInt(inp.getAttribute('data-pid'), 10) || 0;
                var q = parseFloat(inp.value) || 0;
                if (pid <= 0) return;
                if (q > 0) whTransferQtyMap[pid] = q;
                else delete whTransferQtyMap[pid];
            });
        }
        function whTransferUnitToBaseQty(p, unit, count) {
            count = parseFloat(count) || 1;
            if (typeof isWeightProduct === 'function' && isWeightProduct(p)) return count;
            var f = typeof getProductUnitFactors === 'function' ? getProductUnitFactors(p) : { piecesPerPack: 1, piecesPerCarton: 1 };
            if (unit === 'carton') return count * (f.piecesPerCarton || 1);
            if (unit === 'pack') return count * (f.piecesPerPack || 1);
            return count;
        }
        function whTransferScanAddQty(p, unit) {
            if (!p) return false;
            var fromId = parseInt((document.getElementById('wh-tm-from') || {}).value, 10) || 0;
            if (!fromId) return false;
            var avail = getProductQtyForWarehouse(p, fromId);
            if (avail <= 0) {
                if (typeof showToast === 'function') showToast('ئایتم لەم کۆگەیە بەردەست نییە', 'warning');
                return false;
            }
            var add = whTransferUnitToBaseQty(p, unit || 'piece', 1);
            var cur = parseFloat(whTransferQtyMap[p.id]) || 0;
            var next = cur + add;
            if (next > avail + 0.0001) {
                if (typeof showToast === 'function') showToast('ژمارە لە کۆگە زياترە (' + formatQtyForDisplay(avail, p) + ')', 'warning');
                next = avail;
            }
            if (next <= 0) return false;
            whTransferQtyMap[p.id] = next;
            return true;
        }
        window.whTransferQtyInput = function(pid, el) {
            var p = (db && db.products) ? db.products.find(function(x) { return Number(x.id) === Number(pid); }) : null;
            var fromId = parseInt((document.getElementById('wh-tm-from') || {}).value, 10) || 0;
            var avail = p ? getProductQtyForWarehouse(p, fromId) : 0;
            var q = parseFloat(el && el.value) || 0;
            if (q > avail + 0.0001) {
                q = avail;
                if (el) el.value = q;
                if (typeof showToast === 'function') showToast('ژمارە لە کۆگە زياترە', 'warning');
            }
            if (pid > 0 && q > 0) whTransferQtyMap[pid] = q;
            else if (pid > 0) delete whTransferQtyMap[pid];
        };
        window.handleWhTransferBarcode = function(event) {
            if (!event || event.key !== 'Enter') return;
            var modal = document.getElementById('wh-transfer-modal');
            if (!modal || modal.style.display === 'none') return;
            var input = document.getElementById('wh-tm-search');
            var val = (input && input.value) ? input.value.trim() : '';
            if (!val) return;
            var fromSel = document.getElementById('wh-tm-from');
            var toSel = document.getElementById('wh-tm-to');
            var fromId = parseInt(fromSel && fromSel.value, 10) || 0;
            var toId = parseInt(toSel && toSel.value, 10) || 0;
            if (!fromId || !toId || fromId === toId) {
                if (typeof showToast === 'function') showToast('کۆگەی سەرچاوە و مەبەست جیا بن', 'warning');
                event.preventDefault();
                return;
            }
            var candidates = (db.products || []).filter(function(p) {
                return p.trackStock && getProductQtyForWarehouse(p, fromId) > 0;
            });
            var resolved = typeof window.resolveBarcodeForTxnAdd === 'function'
                ? window.resolveBarcodeForTxnAdd(val, 'piece', { isPurchase: false, candidates: candidates })
                : null;
            if (resolved && resolved.ambiguous) {
                if (typeof showToast === 'function') showToast('پتر ژ ئێک ئایتم هاتە دیتن! ئێکێ هەلبژێرە.', 'info');
                event.preventDefault();
                return;
            }
            if (resolved && resolved.p) {
                if (whTransferScanAddQty(resolved.p, resolved.unit)) {
                    if (typeof playBeep === 'function') playBeep();
                    if (typeof showToast === 'function') showToast(resolved.p.name + ' ✓', 'success');
                }
                if (input) { input.value = ''; input.focus(); }
                renderWarehouseTransferGrid({ focusPid: resolved.p.id, highlightPid: resolved.p.id });
                event.preventDefault();
                return;
            }
            if (typeof showToast === 'function') showToast('ئایتم نەهاتە دیتن', 'warning');
            event.preventDefault();
        };
        function debouncedRenderWarehouseTransferGrid() {
            if (whTransferGridTimeout) clearTimeout(whTransferGridTimeout);
            var ms = (typeof posTxnGridDebounceMs === 'function') ? posTxnGridDebounceMs() : 120;
            whTransferGridTimeout = setTimeout(function() { renderWarehouseTransferGrid(); }, ms);
        }
        window.debouncedRenderWarehouseTransferGrid = debouncedRenderWarehouseTransferGrid;
        function ensureWhTransferModal() {
            var modal = document.getElementById('wh-transfer-modal');
            if (modal) return modal;
            modal = document.createElement('div');
            modal.id = 'wh-transfer-modal';
            modal.className = 'modal-overlay wh-transfer-modal';
            modal.style.display = 'none';
            modal.innerHTML = '<div class="glass-card wh-transfer-modal__card">' +
                '<div class="wh-transfer-modal__head">' +
                    '<h2><i class="fas fa-dolly"></i> <span data-i18n="wh_transfer_modal_title">گواستنەوەی کاڵا</span></h2>' +
                    '<button type="button" class="btn btn-sm btn-danger" onclick="document.getElementById(\'wh-transfer-modal\').style.display=\'none\';"><i class="fas fa-times"></i></button>' +
                '</div>' +
                '<div class="wh-transfer-modal__meta">' +
                    '<div><label class="wms-field-label" data-i18n="wh_transfer_from">لە کۆگە</label><select id="wh-tm-from" class="input-std" onchange="if(typeof renderWarehouseTransferGrid===\'function\')renderWarehouseTransferGrid();"></select></div>' +
                    '<div><label class="wms-field-label" data-i18n="wh_transfer_to">بۆ کۆگە</label><select id="wh-tm-to" class="input-std"></select></div>' +
                    '<div><label class="wms-field-label" data-i18n="wh_transfer_note">تێبینی</label><input type="text" id="wh-tm-note" class="input-std" placeholder="هۆکار / تێبینی"></div>' +
                '</div>' +
                '<div class="wh-transfer-modal__search wh-transfer-search-bar">' +
                    '<label class="pos-search-field" for="wh-tm-search">' +
                        '<i class="fas fa-barcode pos-search-field-icon" aria-hidden="true"></i>' +
                        '<input type="text" id="wh-tm-search" class="pos-search-input input-std" placeholder="بارکۆد / گەڕان بۆ ئایتم..." data-i18n-placeholder="wh_transfer_search_ph" autocomplete="off" ' +
                            'onkeyup="if(typeof debouncedRenderWarehouseTransferGrid===\'function\')debouncedRenderWarehouseTransferGrid()" ' +
                            'onkeydown="if(typeof handleWhTransferBarcode===\'function\')handleWhTransferBarcode(event)" ' +
                            'oninput="if(typeof convertArabicNumerals===\'function\')convertArabicNumerals(this);if(typeof debouncedRenderWarehouseTransferGrid===\'function\')debouncedRenderWarehouseTransferGrid();">' +
                    '</label>' +
                '</div>' +
                '<div class="wh-transfer-modal__grid-wrap"><table class="report-table wh-transfer-modal__table"><thead><tr><th>ئایتم</th><th>بەردەست</th><th>ژمارە</th></tr></thead><tbody id="wh-tm-grid-body"></tbody></table></div>' +
                '<div class="wh-transfer-modal__foot">' +
                    '<button type="button" class="btn btn-dark" onclick="document.getElementById(\'wh-transfer-modal\').style.display=\'none\';"><i class="fas fa-times"></i> داخستن</button>' +
                    '<button type="button" class="btn btn-brand" id="wh-tm-save-btn" onclick="if(typeof processStockTransfer===\'function\')processStockTransfer();"><i class="fas fa-check"></i> جێبەجێکردن</button>' +
                '</div></div>';
            modal.onclick = function(evt) { if (evt.target === modal) modal.style.display = 'none'; };
            document.body.appendChild(modal);
            return modal;
        }
        function fillWhTransferSelects() {
            var fromSel = document.getElementById('wh-tm-from');
            var toSel = document.getElementById('wh-tm-to');
            if (!fromSel || !toSel || typeof fillWarehouseSelectEl !== 'function') return;
            fillWarehouseSelectEl(fromSel, { selectedId: getActiveWarehouseChoice('transfer_from') || getDefaultWarehouseId() });
            var fromNow = parseInt(fromSel.value, 10) || 0;
            var savedTo = getActiveWarehouseChoice('transfer_to');
            if (!savedTo || Number(savedTo) === fromNow) {
                var other = (db.warehouses || []).find(function(w) { return Number(w.id) !== fromNow; });
                savedTo = other ? other.id : 0;
            }
            fillWarehouseSelectEl(toSel, { selectedId: savedTo || getDefaultWarehouseId() });
            if (fromSel.value && toSel.value === fromSel.value) {
                var other2 = (db.warehouses || []).find(function(w) { return String(w.id) !== String(fromSel.value); });
                if (other2) toSel.value = String(other2.id);
            }
            fromSel.onchange = function() {
                if (typeof saveActiveWarehouseChoice === 'function') saveActiveWarehouseChoice('transfer_from', fromSel.value);
                whTransferQtyMap = {};
                renderWarehouseTransferGrid();
            };
            toSel.onchange = function() {
                if (typeof saveActiveWarehouseChoice === 'function') saveActiveWarehouseChoice('transfer_to', toSel.value);
            };
        }
        window.openWhTransferModal = function() {
            if (typeof isMultiWarehouseProEnabled === 'function' && !isMultiWarehouseProEnabled()) {
                return;
            }
            if (typeof canUseMultiWarehouse === 'function' && !canUseMultiWarehouse()) {
                if (typeof showToast === 'function') {
                    showToast((typeof t === 'function') ? t('toast_multi_wh_perm_denied') : 'مۆڵەت نییە بۆ کۆگای فرە', 'error');
                } else {
                    alert((typeof t === 'function') ? t('toast_multi_wh_perm_denied') : 'مۆڵەت نییە');
                }
                return;
            }
            var stale = document.getElementById('wh-transfer-modal');
            if (stale && !stale.querySelector('.wh-transfer-search-bar')) stale.remove();
            whTransferQtyMap = {};
            var modal = ensureWhTransferModal();
            fillWhTransferSelects();
            var searchEl = document.getElementById('wh-tm-search');
            if (searchEl) searchEl.value = '';
            renderWarehouseTransferGrid();
            modal.style.display = 'flex';
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
            setTimeout(function() {
                var inp = document.getElementById('wh-tm-search');
                if (inp) inp.focus();
            }, 120);
        };
        window.renderWarehouseTransferGrid = function(opts) {
            opts = opts || {};
            var tbody = document.getElementById('wh-tm-grid-body');
            var fromSel = document.getElementById('wh-tm-from');
            if (!tbody || !fromSel || !db || !db.products) return;
            syncWhTransferQtyFromDom();
            var fromId = parseInt(fromSel.value, 10) || getDefaultWarehouseId();
            var qRaw = ((document.getElementById('wh-tm-search') || {}).value || '').trim();
            var q = qRaw.toLowerCase();
            var items = db.products.filter(function(p) {
                if (!p.trackStock) return false;
                var avail = getProductQtyForWarehouse(p, fromId);
                if (avail <= 0) return false;
                var inCart = (parseFloat(whTransferQtyMap[p.id]) || 0) > 0;
                if (inCart) return true;
                if (!q) return true;
                if (String(p.name || '').toLowerCase().indexOf(q) >= 0) return true;
                return typeof window.productMatchesBarcodeOrNameSearch === 'function' && window.productMatchesBarcodeOrNameSearch(p, qRaw);
            });
            items.sort(function(a, b) {
                var qa = parseFloat(whTransferQtyMap[a.id]) || 0;
                var qb = parseFloat(whTransferQtyMap[b.id]) || 0;
                if (qa > 0 && qb <= 0) return -1;
                if (qb > 0 && qa <= 0) return 1;
                return String(a.name || '').localeCompare(String(b.name || ''), 'ar');
            });
            if (!q && items.length > 120) items = items.slice(0, 120);
            if (!items.length) {
                var hint = q
                    ? 'هیچ ئایتمێک نەدۆزرایەوە'
                    : 'د ڤێ کۆگەهێ کاڵا نینە — کۆگەیا سەرچاوە بگوهێزە';
                tbody.innerHTML = '<tr><td colspan="3" class="wh-tm-empty-hint">' + hint + '</td></tr>';
                return;
            }
            tbody.innerHTML = items.map(function(p) {
                var avail = getProductQtyForWarehouse(p, fromId);
                var curQty = parseFloat(whTransferQtyMap[p.id]) || 0;
                var step = (typeof isWeightProduct === 'function' && isWeightProduct(p)) ? '0.01' : '1';
                var rowCls = curQty > 0 ? ' wh-tm-row--active' : '';
                if (opts.highlightPid && Number(opts.highlightPid) === Number(p.id)) rowCls += ' wh-tm-row--flash';
                return '<tr class="' + rowCls.trim() + '" data-wh-pid="' + p.id + '"><td>' + escapeHtml(p.name || 'ئایتم') +
                    (p.barcode ? '<br><small style="color:var(--text-muted);">' + escapeHtml(String(p.barcode).split(',')[0]) + '</small>' : '') +
                    '</td><td><b>' + formatQtyForDisplay(avail, p) + '</b></td>' +
                    '<td><input type="number" class="input-std wh-tm-qty-inp" min="0" max="' + avail + '" step="' + step + '" value="' + curQty + '" data-pid="' + p.id + '" style="width:100px;margin:0;" oninput="if(typeof whTransferQtyInput===\'function\')whTransferQtyInput(' + p.id + ', this);"></td></tr>';
            }).join('');
            if (opts.focusPid) {
                setTimeout(function() {
                    var row = tbody.querySelector('tr[data-wh-pid="' + opts.focusPid + '"]');
                    if (!row) return;
                    row.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
                    var inp = row.querySelector('.wh-tm-qty-inp');
                    if (inp) { inp.focus(); inp.select(); }
                    if (opts.highlightPid) {
                        setTimeout(function() { row.classList.remove('wh-tm-row--flash'); }, 1200);
                    }
                }, 30);
            }
        };
        window.processStockTransfer = function() {
            if (typeof canUseMultiWarehouse === 'function' && !canUseMultiWarehouse()) {
                alert((typeof t === 'function') ? t('toast_multi_wh_perm_denied') : 'مۆڵەت نییە');
                return;
            }
            var fromId = parseInt((document.getElementById('wh-tm-from') || {}).value, 10) || 0;
            var toId = parseInt((document.getElementById('wh-tm-to') || {}).value, 10) || 0;
            var noteEl = document.getElementById('wh-tm-note');
            var note = noteEl && noteEl.value ? String(noteEl.value).trim() : '';
            if (!fromId || !toId || fromId === toId) { alert('کۆگەی سەرچاوە و مەبەست جیا بن'); return; }
            syncWhTransferQtyFromDom();
            var lines = [];
            Object.keys(whTransferQtyMap).forEach(function(pidStr) {
                var pid = parseInt(pidStr, 10) || 0;
                var qty = parseFloat(whTransferQtyMap[pidStr]) || 0;
                if (pid > 0 && qty > 0) lines.push({ product_id: pid, qty: qty });
            });
            if (!lines.length) { alert('لانیکەم یەک ئایتم و ژمارە بنووسە'); return; }
            var saveBtn = document.getElementById('wh-tm-save-btn');
            if (saveBtn) saveBtn.disabled = true;
            var fd = new FormData();
            fd.append('action', 'save_stock_transfer');
            fd.append('from_warehouse_id', String(fromId));
            fd.append('to_warehouse_id', String(toId));
            fd.append('note', note);
            fd.append('items', JSON.stringify(lines));
            fd.append('user', (currentUser && currentUser.name) ? currentUser.name : 'System');
            fetch('?action=save_stock_transfer', { method: 'POST', body: fd }).then(function(r) { return r.json(); }).then(function(res) {
                if (res.status === 'success') {
                    whTransferQtyMap = {};
                    document.getElementById('wh-transfer-modal').style.display = 'none';
                    lines.forEach(function(ln) {
                        var pid = Number(ln.product_id);
                        var qn = parseFloat(ln.qty) || 0;
                        if (!db.warehouse_stock) db.warehouse_stock = [];
                        function bump(wh, delta) {
                            var row = db.warehouse_stock.find(function(r) {
                                return Number(r.product_id) === pid && Number(r.warehouse_id) === Number(wh);
                            });
                            if (!row) {
                                row = { warehouse_id: Number(wh), product_id: pid, qty: 0, min_stock: 5 };
                                db.warehouse_stock.push(row);
                            }
                            row.qty = (parseFloat(row.qty) || 0) + delta;
                        }
                        bump(fromId, -qn);
                        bump(toId, qn);
                    });
                    if (typeof invalidateWmsWarehouseCache === 'function') invalidateWmsWarehouseCache();
                    if (typeof refreshAllStockDisplaysFromState === 'function') refreshAllStockDisplaysFromState();
                    if (typeof renderWmsWarehouseHub === 'function') renderWmsWarehouseHub();
                    var viewWh = document.getElementById('view-warehouse');
                    if (viewWh && viewWh.classList.contains('active') && typeof renderWarehouse === 'function') renderWarehouse();
                    if (typeof connectToDB === 'function') connectToDB(true, { skipRenderOnRefresh: true });
                    if (typeof showToast === 'function') showToast('گواستنەوە سەرکەوتوو بوو — #' + (typeof formatWhTransferReceiptNo === 'function' ? formatWhTransferReceiptNo(res.transfer || res) : (res.transaction_id || '')), 'success');
                    var receipt = res.transfer || buildWhTransferDraft(fromId, toId, note, lines, res);
                    if (typeof showWhTransferReceipt === 'function') showWhTransferReceipt(receipt, { autoPrint: true });
                } else alert(res.message || 'هەڵە');
            }).finally(function() {
                if (saveBtn) saveBtn.disabled = false;
            });
        };
        function ensureWhTransferHistoryModal() {
            var modal = document.getElementById('wh-transfer-history-modal');
            if (modal) {
                modal.classList.add('hist-modal');
                return modal;
            }
            modal = document.createElement('div');
            modal.id = 'wh-transfer-history-modal';
            modal.className = 'modal-overlay hist-modal';
            modal.style.display = 'none';
            modal.style.zIndex = '10006';
            document.body.appendChild(modal);
            modal.onclick = function(evt) { if (evt.target === modal) modal.style.display = 'none'; };
            return modal;
        }
        window.openWhTransferHistoryModal = function() {
            if (!pos_multi_wh_history_allowed()) return;
            var modal = ensureWhTransferHistoryModal();
            var whOpts = '<option value="">هەموو کۆگەکان</option>';
            (db.warehouses || []).forEach(function(w) {
                whOpts += '<option value="' + w.id + '">' + escapeHtml(w.name) + '</option>';
            });
            var shellFn = (typeof window.histListShellHtml === 'function') ? window.histListShellHtml : null;
            var filtersFn = (typeof window.histFiltersWrap === 'function') ? window.histFiltersWrap : null;
            var tableFn = (typeof window.histTableWrap === 'function') ? window.histTableWrap : null;
            var filtersInner =
                '<select id="wth-warehouse" class="input-std" style="min-width:160px;" onchange="renderWhTransferHistory()">' + whOpts + '</select>' +
                '<select id="wth-date-preset" class="input-std" style="min-width:150px;" onchange="toggleWthCustomDates();renderWhTransferHistory();">' +
                    '<option value="today" selected>ئەڤرۆ</option><option value="week">٧ ڕۆژ</option><option value="month">ئەڤ مانگ</option><option value="all">هەموو دەم</option><option value="custom">دیارکراو</option>' +
                '</select>' +
                '<input type="date" id="wth-start" class="input-std" style="display:none;" onchange="renderWhTransferHistory()">' +
                '<input type="date" id="wth-end" class="input-std" style="display:none;" onchange="renderWhTransferHistory()">';
            var th = '<th>بەروار</th><th>لە</th><th>بۆ</th><th>ئایتمەکان</th><th>ژمارا وەسڵێ</th><th>کۆ</th><th>بەکارهێنەر</th><th>کردار</th>';
            if (shellFn && filtersFn && tableFn) {
                modal.innerHTML = shellFn({
                    id: 'wh-transfer-history-modal',
                    closeId: 'wh-transfer-history-modal',
                    titleI18n: 'wh_transfer_history_title',
                    titleFb: 'مێژوویا گواستنەوە',
                    icon: 'fas fa-history',
                    accent: 'brand',
                    filtersHtml: filtersFn(filtersInner),
                    bodyId: 'wth-body-wrap',
                    bodyHtml: tableFn(th, 'wth-tbody', null, 8)
                });
            } else {
                modal.innerHTML = '<div class="glass-card hist-shell" data-accent="brand">' +
                    '<div class="hist-header"><h2 class="hist-title"><i class="fas fa-history"></i> <span data-i18n="wh_transfer_history_title">مێژوویا گواستنەوە</span></h2>' +
                    '<button type="button" class="btn btn-danger btn-sm" onclick="document.getElementById(\'wh-transfer-history-modal\').style.display=\'none\';"><i class="fas fa-times"></i> <span data-i18n="btn_close">داخستن</span></button></div>' +
                    '<div class="hist-filters">' + filtersInner + '</div>' +
                    '<div class="hist-body"><table class="hist-table report-table"><thead><tr>' + th +
                    '</tr></thead><tbody id="wth-tbody"><tr><td colspan="8" style="text-align:center;padding:30px;"><i class="fas fa-spinner fa-spin"></i></td></tr></tbody></table></div></div>';
            }
            modal.style.display = 'flex';
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
            renderWhTransferHistory();
        };
        function pos_multi_wh_history_allowed() {
            if (typeof isMultiWarehouseProEnabled === 'function' && !isMultiWarehouseProEnabled()) return false;
            if (typeof canUseMultiWarehouse === 'function' && canUseMultiWarehouse()) return true;
            if (typeof hasPermission === 'function' && hasPermission('warehouse_view') && typeof isMultiWarehouseProEnabled === 'function' && isMultiWarehouseProEnabled()) return true;
            if (currentUser && currentUser.role === 'admin' && typeof isMultiWarehouseProEnabled === 'function' && isMultiWarehouseProEnabled()) return true;
            if (typeof showToast === 'function') {
                showToast((typeof t === 'function') ? t('toast_multi_wh_perm_denied') : 'مۆڵەت نییە بۆ کۆگای فرە', 'error');
            }
            return false;
        }
        window.toggleWthCustomDates = function() {
            var preset = (document.getElementById('wth-date-preset') || {}).value;
            var show = preset === 'custom';
            var s = document.getElementById('wth-start');
            var e = document.getElementById('wth-end');
            if (s) s.style.display = show ? '' : 'none';
            if (e) e.style.display = show ? '' : 'none';
        };
        function wthDateRange() {
            var preset = (document.getElementById('wth-date-preset') || {}).value || 'today';
            var today = new Date();
            var pad = function(n) { return (n < 10 ? '0' : '') + n; };
            var ymd = function(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); };
            if (preset === 'today') return { from: ymd(today), to: ymd(today) };
            if (preset === 'week') { var w = new Date(today); w.setDate(w.getDate() - 7); return { from: ymd(w), to: ymd(today) }; }
            if (preset === 'month') { var m = new Date(today.getFullYear(), today.getMonth(), 1); return { from: ymd(m), to: ymd(today) }; }
            if (preset === 'custom') {
                return { from: (document.getElementById('wth-start') || {}).value || '', to: (document.getElementById('wth-end') || {}).value || '' };
            }
            return { from: '', to: '' };
        }
        window.renderWhTransferHistory = function() {
            var tbody = document.getElementById('wth-tbody');
            if (!tbody) return;
            tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;padding:30px;"><i class="fas fa-spinner fa-spin"></i></td></tr>';
            var dr = wthDateRange();
            var whId = (document.getElementById('wth-warehouse') || {}).value || '';
            var qs = '?action=get_stock_transfer_history&limit=300';
            if (dr.from) qs += '&date_from=' + encodeURIComponent(dr.from);
            if (dr.to) qs += '&date_to=' + encodeURIComponent(dr.to);
            if (whId) qs += '&warehouse_id=' + encodeURIComponent(whId);
            fetch(qs, { credentials: 'same-origin' }).then(function(r) {
                return r.text().then(function(text) {
                    var data;
                    try { data = text ? JSON.parse(text) : {}; } catch (e) { throw new Error('invalid_json'); }
                    if (!r.ok && (!data || !data.message)) data = { status: 'error', message: 'HTTP ' + r.status };
                    return data;
                });
            }).then(function(data) {
                if (data.status !== 'success') {
                    tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--danger);">' + escapeHtml(data.message || 'هەڵە') + '</td></tr>';
                    return;
                }
                window._whTransferHistoryCache = data.transfers || [];
                var rows = window._whTransferHistoryCache;
                if (!rows.length) {
                    tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;padding:30px;color:var(--text-muted);">مێژوو نییە</td></tr>';
                    return;
                }
                tbody.innerHTML = rows.map(function(tr) {
                    var dt = tr.date ? String(tr.date).substring(0, 16) : '—';
                    var receiptNo = typeof formatWhTransferReceiptNo === 'function' ? formatWhTransferReceiptNo(tr) : (tr.transaction_id || String(tr.id || ''));
                    return '<tr>' +
                        '<td>' + escapeHtml(dt) + '</td>' +
                        '<td>' + escapeHtml(tr.from_warehouse_name || whTransferWarehouseName(tr.from_warehouse_id)) + '</td>' +
                        '<td>' + escapeHtml(tr.to_warehouse_name || whTransferWarehouseName(tr.to_warehouse_id)) + '</td>' +
                        '<td style="font-size:0.85rem;line-height:1.45;">' + wthLinesSummary(tr, 5) + '</td>' +
                        '<td><b>#' + escapeHtml(receiptNo) + '</b></td>' +
                        '<td>' + whFmtNum(tr.total_qty || 0) + '</td>' +
                        '<td>' + escapeHtml(tr.user || '—') + '</td>' +
                        '<td style="white-space:nowrap;">' +
                            '<button type="button" class="btn btn-sm btn-brand" onclick="openWhTransferDetail(' + tr.id + ')" title="ڕاپۆرت"><i class="fas fa-file-alt"></i></button> ' +
                            '<button type="button" class="btn btn-sm btn-dark" onclick="printWhTransferReport(' + tr.id + ')" title="چاپ"><i class="fas fa-print"></i></button>' +
                        '</td></tr>';
                }).join('');
            }).catch(function(err) {
                tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--danger);">پەیوەندی هەڵە — ' + escapeHtml(err && err.message === 'invalid_json' ? 'وەڵامی سێرڤەر نادروستە' : 'دووبارە هەوڵ بدەرەوە') + '</td></tr>';
            });
        };
        window.openWhTransferDetail = function(id, autoPrint) {
            fetch('?action=get_stock_transfer_detail&id=' + encodeURIComponent(id), { credentials: 'same-origin' })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (data.status !== 'success' || !data.transfer) { alert(data.message || 'نەدۆزرایەوە'); return; }
                    showWhTransferReceipt(data.transfer, { autoPrint: !!autoPrint });
                });
        };
        window.printWhTransferReport = function(id) {
            var tr = null;
            if (window._whTransferDetailCache && Number(window._whTransferDetailCache.id) === Number(id)) tr = window._whTransferDetailCache;
            if (!tr && window._whTransferHistoryCache) tr = window._whTransferHistoryCache.find(function(x) { return Number(x.id) === Number(id); });
            if (tr && tr.lines && tr.lines.length) {
                printWhTransferReportHtml(tr);
                return;
            }
            fetch('?action=get_stock_transfer_detail&id=' + encodeURIComponent(id), { credentials: 'same-origin' }).then(function(r) { return r.json(); }).then(function(data) {
                if (data.status === 'success' && data.transfer) {
                    window._whTransferDetailCache = data.transfer;
                    printWhTransferReportHtml(data.transfer);
                } else alert(data.message || 'نەدۆزرایەوە');
            });
        };
        function buildWhTransferPrintContent(tr) {
            if (!tr) return null;
            var receiptNo = typeof formatWhTransferReceiptNo === 'function' ? formatWhTransferReceiptNo(tr) : (tr.transaction_id || String(tr.id || ''));
            var locale = typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ';
            var dateStr = tr.date ? String(tr.date).substring(0, 16) : new Date().toLocaleString(locale);
            var lines = tr.lines || [];
            var totalValue = parseFloat(tr.total_value);
            if (isNaN(totalValue)) {
                totalValue = lines.reduce(function(s, ln) { return s + (parseFloat(ln.line_total) || 0); }, 0);
            }
            var fmtMoney = typeof formatCurrency === 'function' ? formatCurrency : whFmtNum;
            var summaryHtml =
                '<div style="display:flex;flex-wrap:wrap;gap:12px;margin-bottom:12px;">' +
                    '<div class="p-box" style="border-color:#2563eb;background:#eff6ff;"><h3>لە کۆگە</h3><h2 style="color:#1d4ed8;">' + escapeHtml(tr.from_warehouse_name || '—') + '</h2></div>' +
                    '<div class="p-box" style="border-color:#059669;background:#ecfdf5;"><h3>بۆ کۆگە</h3><h2 style="color:#047857;">' + escapeHtml(tr.to_warehouse_name || '—') + '</h2></div>' +
                    '<div class="p-box"><h3>کۆی ژمارە</h3><h2>' + whFmtNum(tr.total_qty || 0) + '</h2></div>' +
                    (totalValue > 0 ? '<div class="p-box"><h3>کۆی کرین</h3><h2>' + fmtMoney(totalValue) + '</h2></div>' : '') +
                '</div>' +
                '<p style="margin:0 0 8px;"><b>ژمارا وەسڵێ:</b> #' + escapeHtml(receiptNo) +
                ' &nbsp; <b>بەکارهێنەر:</b> ' + escapeHtml(tr.user || '—') + '</p>' +
                (tr.note ? '<p style="margin:0 0 8px;"><b>تێبینی:</b> ' + escapeHtml(tr.note) + '</p>' : '');
            var rowsHtml = lines.map(function(ln) {
                return '<tr><td class="row-item">' + escapeHtml(ln.product_name || ('#' + ln.product_id)) + '</td>' +
                    '<td class="row-qty" style="text-align:center;">' + whFmtNum(ln.qty) + '</td>' +
                    '<td class="row-price" style="text-align:center;">' + fmtMoney(ln.unit_cost) + '</td>' +
                    '<td class="row-price" style="text-align:left;">' + fmtMoney(ln.line_total) + '</td></tr>';
            }).join('');
            if (!rowsHtml) rowsHtml = '<tr><td colspan="4" style="text-align:center;padding:16px;color:#64748b;">هیچ ئایتمێک نییە</td></tr>';
            var tableHtml = '<div class="section-title">ئایتمە گواستراوەکان</div>' +
                '<table class="print-table" style="width:100%;border-collapse:collapse;">' +
                '<thead><tr><th>ئایتم</th><th style="text-align:center;">ژمارە</th><th style="text-align:center;">کرین</th><th style="text-align:left;">کۆ</th></tr></thead>' +
                '<tbody>' + rowsHtml + '</tbody></table>';
            return {
                title: 'وەسڵا گواستنەوەی کۆگە',
                subtitle: 'بەروار: ' + dateStr,
                summaryHtml: summaryHtml,
                tableHtml: tableHtml,
                totalValue: totalValue
            };
        }
        function buildWhTransferThermalHtml(tr, cfg, content) {
            cfg = cfg || (typeof getPrintConfig === 'function' ? getPrintConfig('stock_transfer_report') : { paper: '80mm', design: '1' });
            content = content || buildWhTransferPrintContent(tr);
            if (!content) return '';
            var receiptNo = typeof formatWhTransferReceiptNo === 'function' ? formatWhTransferReceiptNo(tr) : (tr.transaction_id || String(tr.id || ''));
            var thermalLogoHtml = typeof getThermalLogoHtml === 'function' ? getThermalLogoHtml('proforma') : '';
            var thermalFontClasses = typeof getThermalFontClasses === 'function' ? getThermalFontClasses('proforma') : '';
            var locale = typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ';
            var dateStr = tr.date ? String(tr.date).substring(0, 16) : new Date().toLocaleString(locale);
            var fmtMoney = typeof formatCurrency === 'function' ? formatCurrency : whFmtNum;
            var lines = (tr.lines || []).map(function(ln) {
                return '<tr><td class="row-item">' + escapeHtml(ln.product_name || ('#' + ln.product_id)) + '</td>' +
                    '<td class="row-qty" style="text-align:center;">' + whFmtNum(ln.qty) + '</td>' +
                    '<td class="row-price" style="text-align:left;">' + fmtMoney(ln.line_total) + '</td></tr>';
            }).join('') || '<tr><td colspan="3" style="text-align:center;">—</td></tr>';
            var cafeName = (db && db.settings && db.settings.cafeName) ? escapeHtml(db.settings.cafeName) : 'POS';
            var cafeInfo = (db && db.settings && db.settings.cafeInfo) ? escapeHtml(db.settings.cafeInfo) : '';
            return '<div class="print-thermal-container design-' + (cfg.design || '1') + thermalFontClasses + '" style="max-width:' + (cfg.paper || '80mm') + ';width:100%;">' +
                thermalLogoHtml +
                '<div class="thermal-header"><h1>' + cafeName + '</h1><p>' + cafeInfo + '</p></div>' +
                '<div class="thermal-divider"></div>' +
                '<h3 style="margin:5px 0;background:#eee;padding:5px;border-radius:4px;text-align:center;">گواستنەوەی کۆگە</h3>' +
                '<div style="text-align:center;margin:8px 0;padding:8px 4px;border:2px solid #000;border-radius:6px;font-size:1.15rem;font-weight:bold;letter-spacing:1px;">#' + escapeHtml(receiptNo) + '</div>' +
                '<div class="thermal-info"><span>بەروار:</span> <span>' + escapeHtml(dateStr) + '</span></div>' +
                '<div style="margin:6px 0;padding:8px 6px;background:#f3f4f6;border:1px dashed #ccc;border-radius:4px;text-align:center;font-size:0.9rem;line-height:1.5;">' +
                    '<div><span>لە:</span> <b>' + escapeHtml(tr.from_warehouse_name || '') + '</b></div>' +
                    '<div style="margin:2px 0;color:#64748b;">↓</div>' +
                    '<div><span>بۆ:</span> <b>' + escapeHtml(tr.to_warehouse_name || '') + '</b></div>' +
                '</div>' +
                (tr.note ? '<div class="thermal-info"><span>تێبینی:</span> <span>' + escapeHtml(tr.note) + '</span></div>' : '') +
                '<div class="thermal-divider"></div>' +
                '<table class="thermal-table print-unified-table"><thead><tr><th style="text-align:right">ئایتم</th><th style="text-align:center">ژ</th><th style="text-align:left">کۆ</th></tr></thead><tbody>' + lines + '</tbody></table>' +
                '<div class="thermal-divider" style="opacity:1;border-top:2px solid #000;"></div>' +
                '<div class="grand-total">کۆی گشتی: ' + whFmtNum(tr.total_qty || 0) + ' ئایتم' +
                    (content.totalValue > 0 ? ' — ' + fmtMoney(content.totalValue) : '') + '</div>' +
                '<div class="thermal-divider"></div>' +
                '<div class="thermal-info" style="font-weight:bold;"><span>بەکارهێنەر:</span> <span>' + escapeHtml(tr.user || 'System') + '</span></div>' +
                (db && db.settings && db.settings.invoiceNote ? '<p style="margin-top:8px;font-size:0.85rem;border:1px dashed #ccc;padding:4px;">' + escapeHtml(db.settings.invoiceNote) + '</p>' : '') +
                '<div class="thermal-footer">' + (typeof buildPosReceiptBrandFooterHtml === 'function' ? buildPosReceiptBrandFooterHtml() : '') +
                '</div></div>';
        }
        function printWhTransferReportHtml(tr) {
            if (!tr) return;
            var receiptNo = typeof formatWhTransferReceiptNo === 'function' ? formatWhTransferReceiptNo(tr) : (tr.transaction_id || String(tr.id || ''));
            if (typeof logPrintAction === 'function') {
                var summary = (tr.lines || []).map(function(ln) { return (ln.product_name || '') + '×' + whFmtNum(ln.qty); }).join(', ');
                logPrintAction('stock_transfer_report', receiptNo || tr.id || '', 'print', tr.note || '', JSON.stringify({ from: tr.from_warehouse_name, to: tr.to_warehouse_name, items: summary }));
            }
            var content = buildWhTransferPrintContent(tr);
            if (!content) return;
            var cfg = typeof getPrintConfig === 'function' ? getPrintConfig('stock_transfer_report') : { paper: '80mm', design: '1' };
            var html;
            if (typeof isA4PrintPaper === 'function' ? isA4PrintPaper(cfg.paper) : (cfg.paper === '210mm' || cfg.paper === 'A4')) {
                html = typeof buildReportHtml === 'function'
                    ? buildReportHtml(content.title, content.subtitle, content.summaryHtml, content.tableHtml)
                    : content.summaryHtml + content.tableHtml;
            } else {
                html = buildWhTransferThermalHtml(tr, cfg, content);
            }
            try {
                if (typeof routePrint === 'function') {
                    routePrint('stock_transfer_report', html, { docId: receiptNo || tr.id || '', details: 'items=' + ((tr.lines || []).length) });
                } else if (typeof printContent === 'function') {
                    printContent(html, { fast: true });
                } else {
                    var w = window.open('', '_blank', 'width=800,height=700');
                    if (!w) { alert('چاپکرن قەدەغەیە'); return; }
                    w.document.write('<html dir="rtl"><head><meta charset="utf-8"><title>گواستنەوە</title></head><body>' + html + '</body></html>');
                    w.document.close();
                    w.focus();
                    w.print();
                }
            } catch (e) {
                alert('هەڵە د چاپکرنێ دا. هیڤییە ڕێگە بە پۆپئەپ بدە یان پرێنتەر بپشکنە.');
            }
        }
        window.renderWhTransferHistoryPanel = function() {
            var box = document.getElementById('wh-transfer-history');
            if (!box) return;
            box.innerHTML = '<div style="text-align:center;padding:20px;color:var(--text-muted);"><i class="fas fa-spinner fa-spin"></i></div>';
            fetch('?action=get_stock_transfer_history&limit=15', { credentials: 'same-origin' }).then(function(r) { return r.json(); }).then(function(data) {
                if (data.status !== 'success' || !(data.transfers || []).length) {
                    box.innerHTML = '<p style="text-align:center;padding:20px;color:var(--text-muted);margin:0;">مێژوو نییە</p>';
                    return;
                }
                var rows = data.transfers;
                box.innerHTML = '<table class="report-table" style="width:100%;margin:0;"><thead><tr><th>بەروار</th><th>لە → بۆ</th><th>ئایتمەکان</th><th>کردار</th></tr></thead><tbody>' +
                    rows.map(function(tr) {
                        var dt = tr.date ? String(tr.date).substring(0, 16) : '—';
                        return '<tr><td>' + escapeHtml(dt) + '</td>' +
                            '<td>' + escapeHtml(tr.from_warehouse_name || '') + ' → ' + escapeHtml(tr.to_warehouse_name || '') + '</td>' +
                            '<td style="font-size:0.85rem;">' + wthLinesSummary(tr, 5) + '</td>' +
                            '<td style="white-space:nowrap;"><button type="button" class="btn btn-sm btn-brand" onclick="openWhTransferDetail(' + tr.id + ')"><i class="fas fa-file-alt"></i></button> ' +
                            '<button type="button" class="btn btn-sm btn-dark" onclick="printWhTransferReport(' + tr.id + ')"><i class="fas fa-print"></i></button></td></tr>';
                    }).join('') +
                    '</tbody></table>';
            }).catch(function() {
                box.innerHTML = '<p style="text-align:center;padding:20px;color:var(--danger);margin:0;">هەڵە لە بارکردن</p>';
            });
        };
        window.openWarehouseOptionsModal = function(e) {
            e = e || window.event;
            if (e) { e.preventDefault(); e.stopPropagation(); }
            ['pos-options-popover', 'purchase-options-popover', 'purchase-returns-options-popover', 'returns-options-popover'].forEach(function(id) {
                var el = document.getElementById(id);
                if (el) el.style.display = 'none';
            });
            var modal = document.getElementById('warehouse-options-popover');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'warehouse-options-popover';
                modal.style.cssText = 'position:absolute;z-index:10000;background:var(--card);border:1px solid var(--border);border-radius:12px;box-shadow:0 8px 30px rgba(0,0,0,0.15);padding:15px;min-width:320px;display:flex;flex-direction:column;gap:10px;';
                modal.innerHTML = '<div style="font-size:0.95rem;padding-bottom:10px;border-bottom:1px solid var(--border);font-weight:bold;text-align:center;"><i class="fas fa-warehouse"></i> <span data-i18n="popover_warehouse_menu_title">مینیویا کۆگە</span></div>' +
                    '<div style="display:grid;grid-template-columns:repeat(2,1fr);gap:12px;">' +
                        '<div style="cursor:pointer;display:flex;flex-direction:column;align-items:center;padding:18px 10px;border:2px solid var(--border);border-radius:14px;" onclick="document.getElementById(\'warehouse-options-popover\').style.display=\'none\';nav(\'warehouse\');">' +
                            '<i class="fas fa-warehouse" style="font-size:2rem;margin-bottom:10px;color:var(--brand);"></i><span data-i18n="popover_screen_warehouse">شاشا کۆگە</span></div>' +
                        '<div style="cursor:pointer;display:flex;flex-direction:column;align-items:center;padding:18px 10px;border:2px solid var(--border);border-radius:14px;" onclick="document.getElementById(\'warehouse-options-popover\').style.display=\'none\';openWhTransferModal();">' +
                            '<i class="fas fa-dolly" style="font-size:2rem;margin-bottom:10px;color:var(--success);"></i><span data-i18n="popover_wh_transfer">گواستنەوە</span></div>' +
                        '<div style="cursor:pointer;display:flex;flex-direction:column;align-items:center;padding:18px 10px;border:2px solid var(--border);border-radius:14px;" onclick="document.getElementById(\'warehouse-options-popover\').style.display=\'none\';openWhTransferHistoryModal();">' +
                            '<i class="fas fa-history" style="font-size:2rem;margin-bottom:10px;color:var(--warning);"></i><span data-i18n="popover_wh_transfer_history">مێژوویا گواستنەوە</span></div>' +
                        '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:18px 10px;background:var(--input-bg);border:2px dashed var(--border);border-radius:14px;opacity:0.5;"><i class="fas fa-plus"></i><span data-i18n="popover_menu_empty">ڤالا</span></div>' +
                    '</div>';
                document.body.appendChild(modal);
                document.addEventListener('click', function(evt) {
                    if (modal.style.display === 'flex' && !modal.contains(evt.target)) modal.style.display = 'none';
                });
            }
            if (modal.style.display === 'flex') { modal.style.display = 'none'; return; }
            modal.style.display = 'flex';
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
            if (e && e.currentTarget) {
                var rect = e.currentTarget.getBoundingClientRect();
                var top = rect.bottom + 5;
                var left = rect.left + (rect.width / 2) - 160;
                if (top + 280 > window.innerHeight) top = window.innerHeight - 290;
                if (left + 330 > window.innerWidth) left = window.innerWidth - 340;
                if (left < 10) left = 10;
                modal.style.top = top + 'px';
                modal.style.left = left + 'px';
            }
        };
        window.toggleWmsTransferBox = function() { if (typeof openWhTransferModal === 'function') openWhTransferModal(); };
        window.quickStockTransfer = function() { if (typeof openWhTransferModal === 'function') openWhTransferModal(); };
        window.renderWarehouseLocations = function() { nav('warehouse'); };
        window.renderWarehouseTransfers = function() {
            if (typeof applyMultiWarehouseVisibility === 'function') applyMultiWarehouseVisibility();
            if (typeof fillWarehouseSelects === 'function') fillWarehouseSelects();
            if (typeof renderWhTransferHistoryPanel === 'function') renderWhTransferHistoryPanel();
            var fromSel = document.getElementById('wh-transfer-from');
            if (fromSel && typeof renderWarehouseTransferPageGrid === 'function') {
                if (!fromSel.dataset.whPageBound) {
                    fromSel.dataset.whPageBound = '1';
                    fromSel.onchange = function() { renderWarehouseTransferPageGrid(); };
                }
                renderWarehouseTransferPageGrid();
            }
        };
        window.renderWarehouseTransferPageGrid = function() {
            var tbody = document.getElementById('wh-transfer-grid-body');
            var fromSel = document.getElementById('wh-transfer-from');
            if (!tbody || !fromSel || !db || !db.products) return;
            var fromId = parseInt(fromSel.value, 10) || getDefaultWarehouseId();
            var items = db.products.filter(function(p) {
                if (!p.trackStock) return false;
                return getProductQtyForWarehouse(p, fromId) > 0;
            });
            tbody.innerHTML = items.map(function(p) {
                var avail = getProductQtyForWarehouse(p, fromId);
                return '<tr><td>' + escapeHtml(p.name || 'ئایتم') + '</td><td><b>' + formatQtyForDisplay(avail, p) + '</b></td><td style="color:var(--text-muted);font-size:0.85rem;">لە مۆدال گواستنەوە</td></tr>';
            }).join('') || '<tr><td colspan="3" style="text-align:center;color:var(--text-muted);">کاڵا بەردەست نییە</td></tr>';
        };

        function isWmsLiteMode() {
            return (typeof isPosCpuSaveMode === 'function' && isPosCpuSaveMode());
        }
        function getWmsTablePageSize() {
            return isWmsLiteMode() ? 40 : 80;
        }
        function getWmsProductsCacheKey(allItems) {
            var len = allItems ? allItems.length : 0;
            if (!len) return '0';
            return len + '|' + String(allItems[0].id) + ':' + String(allItems[len - 1].id);
        }
        function invalidateWmsWarehouseCache() {
            window._wmsBucketsCache = null;
            window._wmsBucketsKey = '';
            window._wmsTotalsJob = null;
            window._wmsTotalsKey = '';
            window._wmsPurchasedIdsCache = null;
            window._wmsPurchasedIdsKey = '';
        }
        window.invalidateWmsWarehouseCache = invalidateWmsWarehouseCache;

        function getWmsProductBuckets(allItems, opts) {
            opts = opts || {};
            var key = getWmsProductsCacheKey(allItems);
            if (!opts.skipCache && window._wmsBucketsCache && window._wmsBucketsKey === key) return window._wmsBucketsCache;
            var lite = isWmsLiteMode();
            var len = allItems ? allItems.length : 0;
            var low = [], out = [], exp = [], inStock = [];
            for (var i = 0; i < len; i++) {
                var p = allItems[i];
                if (!p || !p.trackStock) continue;
                var q = getWarehouseProductQty(p);
                if (q === null) continue;
                if (q <= 0) {
                    out.push(p);
                    continue;
                }
                inStock.push(p);
                var minS = getMinStock(p);
                if (q <= minS) low.push(p);
                if (lite) {
                    var expVal = (p.expiry != null && p.expiry !== '') ? p.expiry : (p.expiry_date || '');
                    if (expVal && typeof productCatalogExpiryDaysLeft === 'function') {
                        var daysL = productCatalogExpiryDaysLeft(p);
                        if (daysL != null && daysL <= 60) exp.push(p);
                    }
                } else if (typeof productCatalogExpiryDaysLeft === 'function') {
                    var days = productCatalogExpiryDaysLeft(p);
                    if (days != null && days <= 60) exp.push(p);
                }
            }
            var outBuckets = { low: low, out: out, exp: exp, inStock: inStock };
            if (!opts.skipCache) {
                window._wmsBucketsCache = outBuckets;
                window._wmsBucketsKey = key;
            }
            return outBuckets;
        }

        function formatWarehouseKpiAmount(val) {
            var n = parseFloat(val) || 0;
            if (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD') {
                if (typeof formatUsdNumberPlain === 'function') return formatUsdNumberPlain(n);
                var cents = Math.round(Math.abs(n) * 100) % 100;
                return cents === 0
                    ? Math.round(n).toLocaleString('en-US')
                    : Number(n).toLocaleString('en-US', { maximumFractionDigits: 2, minimumFractionDigits: 2 });
            }
            return Number(Math.round(n)).toLocaleString('en-US');
        }

        function paintWarehouseKpiEl(el, amount) {
            if (!el) return;
            var isUsd = (typeof getActiveCurrency === 'function') && getActiveCurrency() === 'USD';
            var r = (typeof getUsdRatePerOne === 'function') ? getUsdRatePerOne() : 0;
            var txt = formatWarehouseKpiAmount(amount);
            var title = '';
            var n = parseFloat(amount) || 0;
            if (isUsd) {
                var approxIqd = (r > 0) ? Math.round(n * r) : 0;
                title = '$' + txt + (approxIqd > 0 ? ' (~ ' + Number(approxIqd).toLocaleString('en-US') + ' IQD)' : '');
            } else {
                var approxUsd = (r > 0) ? parseFloat((n / r).toFixed(2)) : 0;
                title = txt + ' IQD' + (approxUsd > 0 ? ' (~ $' + (typeof formatUsdNumberPlain === 'function' ? formatUsdNumberPlain(approxUsd) : Number(approxUsd).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 })) + ')' : '');
            }
            el.textContent = txt;
            el.setAttribute('title', title);
            el.style.visibility = 'visible';
            el.style.opacity = '1';
        }

        function setWarehouseKpiTotals(cost, sale) {
            var whCost = document.getElementById('wh-total-cost');
            var whSale = document.getElementById('wh-total-sale');
            var whProfit = document.getElementById('wh-total-profit');
            paintWarehouseKpiEl(whCost, cost);
            paintWarehouseKpiEl(whSale, sale);
            if (whProfit) {
                var _showWhProfit = (typeof canViewProfit === 'function') ? canViewProfit() : true;
                var _whProfitCard = whProfit.closest('.wms-kpi-card--profit') || whProfit.closest('.stat-card');
                if (_whProfitCard) _whProfitCard.style.display = _showWhProfit ? '' : 'none';
                paintWarehouseKpiEl(whProfit, _showWhProfit ? (sale - cost) : 0);
                if (!_showWhProfit) whProfit.textContent = '---';
            }
        }
        window.setWarehouseKpiTotals = setWarehouseKpiTotals;

        function paintInventoryValuationTotals(list) {
            var val = (typeof sumInventoryValuationNative === 'function')
                ? sumInventoryValuationNative(list)
                : { cost: 0, sale: 0 };
            setWarehouseKpiTotals(val.cost, val.sale);
            return val;
        }

        function scheduleWarehouseTotals(list) {
            if (window._wmsTotalsJob) {
                window._wmsTotalsJob.cancelled = true;
            }
            var job = { cancelled: false };
            window._wmsTotalsJob = job;
            var idx = 0;
            var chunk = isWmsLiteMode() ? 900 : 150;
            var costIqd = 0, saleIqd = 0, costUsd = 0, saleUsd = 0;
            var itemCur = (typeof inventoryItemNativeCurrency === 'function')
                ? inventoryItemNativeCurrency
                : function (p) {
                    var c = String((p && p.currency) || '').toUpperCase();
                    if (c === 'USD' || c === 'IQD') return c;
                    return ((typeof getDefaultCurrency === 'function') && getDefaultCurrency() === 'USD') ? 'USD' : 'IQD';
                };
            var unitIqd = (typeof inventoryNativeUnitIqd === 'function')
                ? inventoryNativeUnitIqd
                : function (p, kind) { return parseFloat(kind === 'sell' ? p.price : (p.cost_price || p.cost)) || 0; };
            var unitUsd = (typeof inventoryNativeUnitUsd === 'function')
                ? inventoryNativeUnitUsd
                : function (p, kind) { return parseFloat(kind === 'sell' ? p.price_usd : p.cost_usd) || 0; };
            function step() {
                if (job.cancelled) return;
                var end = Math.min(idx + chunk, list.length);
                for (; idx < end; idx++) {
                    var p = list[idx];
                    if (!p || !p.trackStock || !(parseFloat(p.qty) > 0)) continue;
                    var q = parseFloat(p.qty) || 0;
                    if (itemCur(p) === 'USD') {
                        costUsd += unitUsd(p, 'cost') * q;
                        saleUsd += unitUsd(p, 'sell') * q;
                    } else {
                        costIqd += unitIqd(p, 'cost') * q;
                        saleIqd += unitIqd(p, 'sell') * q;
                    }
                }
                if (idx < list.length) {
                    setTimeout(step, 0);
                    return;
                }
                if (!job.cancelled) {
                    var val = (typeof finalizeInventoryValuationBuckets === 'function')
                        ? finalizeInventoryValuationBuckets(costIqd, saleIqd, costUsd, saleUsd)
                        : { cost: Math.round(costIqd), sale: Math.round(saleIqd) };
                    setWarehouseKpiTotals(val.cost, val.sale);
                }
                if (window._wmsTotalsJob === job) window._wmsTotalsJob = null;
            }
            if (isWmsLiteMode()) {
                var whCost = document.getElementById('wh-total-cost');
                var whSale = document.getElementById('wh-total-sale');
                if (whCost) whCost.textContent = '…';
                if (whSale) whSale.textContent = '…';
            }
            step();
        }

        function getWmsAlertsPageSize() {
            return isWmsLiteMode() ? 4 : 6;
        }
        var WMS_ALERTS_MAX = 300;
        function renderWmsAlertsStripUI() {
            var alerts = window._wmsAlertsList || [];
            var truncated = parseInt(window._wmsAlertsTruncated, 10) || 0;
            var strip = document.getElementById('wms-alerts-strip');
            var ac = document.getElementById('wms-alerts-content');
            var nav = document.getElementById('wms-alerts-nav');
            var info = document.getElementById('wms-alerts-page-info');
            var btnP = document.getElementById('wms-alerts-prev');
            var btnN = document.getElementById('wms-alerts-next');
            if (!strip || !ac) return;
            if (!alerts.length) {
                strip.style.display = 'none';
                return;
            }
            strip.style.display = 'block';
            var per = getWmsAlertsPageSize();
            var totalPages = Math.max(1, Math.ceil(alerts.length / per));
            var page = Math.max(0, Math.min(totalPages - 1, parseInt(window._wmsAlertsPage, 10) || 0));
            window._wmsAlertsPage = page;
            var slice = alerts.slice(page * per, page * per + per);
            ac.innerHTML = slice.map(function(a) {
                var cls = 'wms-alert-chip';
                var icon = 'fa-circle';
                if (a.type === 'loss') { cls += ' wms-alert-chip--loss'; icon = 'fa-exclamation-circle'; }
                else if (a.type === 'low') { cls += ' wms-alert-chip--low'; icon = 'fa-exclamation-triangle'; }
                else { cls += ' wms-alert-chip--exp'; icon = 'fa-calendar-times'; }
                return '<div class="' + cls + '"><i class="fas ' + icon + '"></i><span>' + a.text + '</span></div>';
            }).join('');
            if (nav && info && btnP && btnN) {
                if (alerts.length > per) {
                    nav.style.display = 'flex';
                    var suffix = truncated > 0 ? (' · ' + alerts.length + '+' + truncated) : (' · ' + alerts.length);
                    info.textContent = (page + 1) + ' / ' + totalPages + suffix;
                    btnP.disabled = page <= 0;
                    btnN.disabled = page >= totalPages - 1;
                } else {
                    nav.style.display = 'none';
                }
            }
        }
        window.wmsAlertsStep = function(delta) {
            window._wmsAlertsPage = (parseInt(window._wmsAlertsPage, 10) || 0) + (parseInt(delta, 10) || 0);
            renderWmsAlertsStripUI();
        };

        function warehouseTableRowHtml(p) {
            var lite = isWmsLiteMode();
            var minS = getMinStock(p);
            var tFn = (typeof t === 'function' ? t : null);
            var lbl = function(key, fb) { return tFn ? tFn(key) : fb; };
            var qtyForStatus = getWarehouseProductQty(p);
            var elseStock = (p.trackStock && typeof getOtherWarehouseStockLines === 'function')
                ? getOtherWarehouseStockLines(p, p._warehouse_id) : [];
            var statusBadge = !p.trackStock ? wmsStatusBadgeHtml('service', lbl('wh_status_service', 'خزمەتگوزاری')) :
                (qtyForStatus !== null && qtyForStatus <= 0
                    ? (elseStock.length
                        ? wmsStatusBadgeHtml('low', 'ل کۆگەیا دی')
                        : wmsStatusBadgeHtml('out', lbl('wh_status_stockout', 'نەما')))
                    : (isLowStockByMin(p) ? wmsStatusBadgeHtml('low', lbl('wh_status_low', 'کێمبووی')) : wmsStatusBadgeHtml('ok', lbl('wh_status_ok', 'باشە'))));
            if (!lite && typeof isProductCatalogExpired === 'function' && isProductCatalogExpired(p)) statusBadge += ' ' + wmsStatusBadgeHtml('exp', lbl('wh_status_expired_badge', 'بەسەرچووی'));
            var costAboveSell = isProductCostAboveSell(p);
            if (costAboveSell) statusBadge += ' ' + wmsStatusBadgeHtml('loss', lbl('wh_status_loss', 'بهایێ کڕینێ > فرۆتنێ'));
            var whLabel = '';
            var elsewhereHtml = '';
            if (p._warehouse_id) {
                var wn = (db.warehouses || []).find(function(w) { return Number(w.id) === Number(p._warehouse_id); });
                if (wn) whLabel = '<small class="wms-qty-wh">' + escapeHtml(wn.name) + '</small>';
            }
            var qtyRaw = p.trackStock ? (parseFloat(p.qty) || 0) : 0;
            if (p.trackStock && typeof getOtherWarehouseStockLines === 'function') {
                var elseLines = getOtherWarehouseStockLines(p, p._warehouse_id);
                if (elseLines.length) {
                    elsewhereHtml = '<small class="wms-qty-else">' + elseLines.map(function(x) {
                        var qStr = (typeof formatQtyForDisplay === 'function') ? formatQtyForDisplay(x.qty, p) : String(x.qty);
                        return 'ل ' + escapeHtml(x.name) + ': ' + qStr;
                    }).join(' · ') + '</small>';
                }
            }
            var qtyDisplay = p.trackStock ? (formatQtyForDisplay(qtyRaw, p) + whLabel + elsewhereHtml) : '∞';
            var isUsd = (typeof getActiveCurrency === 'function') && getActiveCurrency() === 'USD';
            var pieceCostActive = (typeof getCatalogPieceCostActive === 'function') ? getCatalogPieceCostActive(p) : (parseFloat(p.cost) || 0);
            var pieceSellActive = (typeof getCatalogPieceSellActive === 'function') ? getCatalogPieceSellActive(p) : (parseFloat(p.price) || 0);

            var costDisplay = (typeof formatActiveCurrencyAmount === 'function') ? formatActiveCurrencyAmount(pieceCostActive) : String(pieceCostActive);
            if (!lite && p._fifoBatches && p._fifoBatches.length > 0) {
                if (p._fifoBatches.length === 1) {
                    var singleCost = isUsd ? (p._fifoBatches[0].unitCostUsd || pieceCostActive) : p._fifoBatches[0].unitCost;
                    costDisplay = (typeof formatActiveCurrencyAmount === 'function') ? formatActiveCurrencyAmount(singleCost) : String(singleCost);
                } else {
                    var tooltip = p._fifoBatches.map(function(b) {
                        var d = b.purchaseDateText || ((b.date && b.date !== 'Initial/Standard') ? new Date(b.date).toLocaleDateString('ku') : '');
                        var expPart = b.expiryDate ? (' | EXP: ' + b.expiryDate + ' (' + (b.expiryStatusText || '') + ')') : '';
                        var meta = formatFifoBatchCompanyInvoiceMeta(b, false);
                        var bCost = isUsd ? (b.unitCostUsd || pieceCostActive) : b.unitCost;
                        var bCostStr = (typeof formatActiveCurrencyAmount === 'function') ? formatActiveCurrencyAmount(bCost) : String(bCost);
                        return b.qty + ' @ ' + bCostStr + (d ? ' (' + d + ')' : '') + expPart + (meta ? ' (' + meta + ')' : '');
                    }).join(' | ');
                    costDisplay = '<span style="color:var(--brand); border-bottom:1px dashed var(--brand);" title="' + escapeHtml(tooltip) + '">' + lbl('wh_cost_mixed_batches', 'تێکەڵ (Batches)') + '</span>';
                }
            }
            if (!p.trackStock) costDisplay = (typeof formatActiveCurrencyAmount === 'function') ? formatActiveCurrencyAmount(pieceCostActive) : String(pieceCostActive);
            var sellDisplay = (typeof formatActiveCurrencyAmount === 'function') ? formatActiveCurrencyAmount(pieceSellActive) : String(pieceSellActive);

            var rowCls = 'wms-table-row';
            if (!p.trackStock) rowCls += ' wms-table-row--service';
            else if (isWarehouseTrueStockout(p) && !elseStock.length) rowCls += ' wms-table-row--out';
            else if (isWarehouseTrueStockout(p) || isLowStockByMin(p)) rowCls += ' wms-table-row--low';
            if (costAboveSell) rowCls += ' wms-table-row--loss';
            var lossHint = costAboveSell
                ? '<small class="wms-loss-hint"><i class="fas fa-exclamation-circle" aria-hidden="true"></i> ' + escapeHtml(lbl('wh_loss_hint', 'بهایێ کڕینێ لە فرۆتنێ زیاترە')) + '</small>'
                : '';
            var expDisp = (typeof getProductCatalogExpiryDisplay === 'function') ? getProductCatalogExpiryDisplay(p) : '-';
            var mfr = (p.manufacturer != null && String(p.manufacturer).trim()) ? String(p.manufacturer).trim() : '';
            var mfrDisplay = mfr ? escapeHtml(mfr) : '—';
            return '<tr class="' + rowCls + '" data-product-id="' + (p.id || '') + '" onclick="openWmsProductDetail(' + p.id + ')">' +
                '<td class="wms-td-sku"><i class="fas fa-hashtag wms-cell-ic" aria-hidden="true"></i>' + (p.id || '-') + '</td>' +
                '<td><i class="fas fa-barcode wms-cell-ic" aria-hidden="true"></i>' + escapeHtml(p.barcode || '-') + '</td>' +
                '<td class="wms-td-name"><i class="fas fa-box wms-cell-ic" aria-hidden="true"></i><b>' + escapeHtml(p.name || 'ئایتم') + '</b>' + lossHint + '</td>' +
                '<td><i class="fas fa-layer-group wms-cell-ic" aria-hidden="true"></i>' + escapeHtml(p.cat || p.category || '-') + '</td>' +
                '<td class="wms-col-manufacturer"><i class="fas fa-industry wms-cell-ic" aria-hidden="true"></i>' + mfrDisplay + '</td>' +
                '<td class="wms-td-money"><i class="fas fa-coins wms-cell-ic" aria-hidden="true"></i>' + costDisplay + '</td>' +
                '<td class="wms-td-money"><i class="fas fa-tag wms-cell-ic" aria-hidden="true"></i>' + sellDisplay + '</td>' +
                '<td class="wms-td-qty"><i class="fas fa-cubes wms-cell-ic" aria-hidden="true"></i>' + qtyDisplay + '</td>' +
                '<td><i class="fas fa-arrow-down wms-cell-ic" aria-hidden="true"></i>' + minS + '</td>' +
                '<td><i class="fas fa-calendar-alt wms-cell-ic" aria-hidden="true"></i>' + escapeHtml(expDisp) + '</td>' +
                '<td class="wms-td-status">' + statusBadge + '</td></tr>';
        }
        function buildWmsStockCellInnerHtml(p) {
            var whLabel = '';
            if (p && p._warehouse_id) {
                var wn = (db.warehouses || []).find(function(w) { return Number(w.id) === Number(p._warehouse_id); });
                if (wn) whLabel = '<small style="display:block;color:var(--brand);font-size:0.75rem;">' + escapeHtml(wn.name) + '</small>';
            }
            if (!p || !p.trackStock) return '∞';
            var qtyRaw = parseFloat(p.qty) || 0;
            return formatQtyForDisplay(qtyRaw, p) + whLabel;
        }
        window.refreshWmsStockCellForProduct = function(productId) {
            var viewWh = document.getElementById('view-warehouse');
            if (!viewWh || !viewWh.classList.contains('active') || productId == null) return;
            var row = document.querySelector('#wh-list-body tr[data-product-id="' + productId + '"]');
            if (!row) return;
            var cell = row.querySelector('.wms-td-qty');
            if (!cell) return;
            var full = window._wmsSortedList || [];
            var p = null;
            for (var i = 0; i < full.length; i++) {
                if (String(full[i].id) === String(productId)) { p = full[i]; break; }
            }
            if (!p && db && db.products) {
                var src = db.products.find(function(x) { return String(x.id) === String(productId); });
                if (src && typeof mapProductsForWarehouseView === 'function') {
                    var whId = (typeof resolveWmsQtyWarehouseId === 'function') ? resolveWmsQtyWarehouseId() : 0;
                    var mapped = mapProductsForWarehouseView([src], whId);
                    p = mapped && mapped[0] ? mapped[0] : src;
                } else {
                    p = src;
                }
            }
            if (!p) return;
            var ic = cell.querySelector('.wms-cell-ic');
            cell.innerHTML = (ic ? ic.outerHTML : '<i class="fas fa-cubes wms-cell-ic" aria-hidden="true"></i>') + buildWmsStockCellInnerHtml(p);
        };
        window.refreshWmsStockCellsFromCart = function() {
            var viewWh = document.getElementById('view-warehouse');
            if (!viewWh || !viewWh.classList.contains('active')) return;
            document.querySelectorAll('#wh-list-body tr[data-product-id]').forEach(function(row) {
                var pid = row.getAttribute('data-product-id');
                if (pid) window.refreshWmsStockCellForProduct(pid);
            });
        };
        function attachFifoBatchesForRows(rows) {
            if (isWmsLiteMode()) return;
            if (!rows || !rows.length || typeof window.getProductFifoBatches !== 'function') return;
            rows.forEach(function (p) {
                if (!p.trackStock || !(p.qty > 0)) {
                    p._fifoBatches = null;
                    return;
                }
                p._fifoBatches = window.getProductFifoBatches(p.id, p.qty);
            });
        }

        function paintWarehouseTablePage() {
            var full = window._wmsSortedList || [];
            var titleBase = window._wmsListTitle || '';
            var size = getWmsTablePageSize();
            var totalPages = Math.max(1, Math.ceil(full.length / size));
            var page = Math.max(0, Math.min(totalPages - 1, parseInt(window._wmsTablePage, 10) || 0));
            window._wmsTablePage = page;
            var renderList = full.slice(page * size, page * size + size);
            attachFifoBatchesForRows(renderList);
            var titleEl = document.getElementById('wh-list-title');
            if (titleEl) {
                var titleTxt = !full.length ? titleBase : (titleBase + ' · ' + full.length + (full.length > size ? (' · ' + (page + 1) + '/' + totalPages) : ''));
                titleEl.innerHTML = '<i class="fas fa-list-alt pos-ic" aria-hidden="true"></i> <span>' + escapeHtml(titleTxt) + '</span>';
            }
            var tbody = document.getElementById('wh-list-body');
            if (tbody) {
                if (!renderList.length) {
                    tbody.innerHTML = '<tr><td colspan="11" class="wms-table-empty"><i class="fas fa-inbox" aria-hidden="true"></i> ' + ((typeof t === 'function') ? t('wh_table_empty') : 'هیچ ئایتمێک نەدۆزرایەوە') + '</td></tr>';
                } else {
                    var rowsHtml = '';
                    for (var ri = 0; ri < renderList.length; ri++) {
                        try {
                            rowsHtml += warehouseTableRowHtml(renderList[ri]);
                        } catch (rowErr) {
                            console.warn('[WMS] row render', renderList[ri] && renderList[ri].id, rowErr);
                        }
                    }
                    tbody.innerHTML = rowsHtml || '<tr><td colspan="11" class="wms-table-empty">—</td></tr>';
                }
            }
            var nav = document.getElementById('wh-table-nav');
            var info = document.getElementById('wh-table-page-info');
            var btnP = document.getElementById('wh-table-prev');
            var btnN = document.getElementById('wh-table-next');
            if (nav && info && btnP && btnN) {
                if (full.length > size) {
                    nav.style.display = 'flex';
                    info.textContent = (page + 1) + ' / ' + totalPages + ' · ' + full.length;
                    btnP.disabled = page <= 0;
                    btnN.disabled = page >= totalPages - 1;
                } else {
                    nav.style.display = 'none';
                }
            }
        }
        window.wmsTablePageStep = function(delta) {
            window._wmsTablePage = (parseInt(window._wmsTablePage, 10) || 0) + (parseInt(delta, 10) || 0);
            paintWarehouseTablePage();
        };

        function fifoSupplyPool(pid) {
            var base = (typeof window.posGetSuppliesPool === 'function') ? window.posGetSuppliesPool() : ((db && db.supplies) || []);
            if (!pid) return base;
            var extra = (window._fifoSuppliesByProduct && window._fifoSuppliesByProduct[pid] && window._fifoSuppliesByProduct[pid].rows) || [];
            if (!extra.length) return base;
            var seen = {};
            var out = [];
            function ingest(list) {
                (list || []).forEach(function (s) {
                    if (!s) return;
                    var fp = (typeof window.posSupplyFingerprint === 'function') ? window.posSupplyFingerprint(s) : String(s.id);
                    if (!fp || seen[fp]) return;
                    seen[fp] = 1;
                    out.push(s);
                });
            }
            ingest(base);
            ingest(extra);
            return out.length ? out : base;
        }

        function resolveSupplyTxnMeta(line, pool) {
            var batchNum = String(line && line.batch_number != null ? line.batch_number : '').trim();
            var invNum = String(line && line.supplier_invoice_number != null ? line.supplier_invoice_number : '').trim();
            var company = String(line && line.company != null ? line.company : '').trim();
            var expiryDate = String(line && line.expiry_date != null ? line.expiry_date : '').trim();
            var txn = String(line && line.transaction_id || '').trim();
            if (!txn || !pool || !pool.length) {
                return { batchNum: batchNum, invNum: invNum, company: company, expiryDate: expiryDate };
            }
            for (var i = 0; i < pool.length; i++) {
                var s = pool[i];
                if (String(s.transaction_id || '').trim() !== txn) continue;
                if (!batchNum) batchNum = String(s.batch_number != null ? s.batch_number : '').trim();
                if (!invNum) invNum = String(s.supplier_invoice_number != null ? s.supplier_invoice_number : '').trim();
                if (!company) company = String(s.company != null ? s.company : '').trim();
                if (!expiryDate) expiryDate = String(s.expiry_date != null ? s.expiry_date : '').trim();
                if (batchNum && invNum && company && expiryDate) break;
            }
            return { batchNum: batchNum, invNum: invNum, company: company, expiryDate: expiryDate };
        }

        function resolveSupplyBatchNumber(line, pool) {
            return resolveSupplyTxnMeta(line, pool).batchNum;
        }

        function fifoMetaFromTxn(txnId, pool) {
            txnId = String(txnId || '').trim();
            if (!txnId || !pool || !pool.length) {
                return { batchNum: '', invNum: '', company: '', expiryDate: '', purchaseDate: '', purchaseDateText: '-' };
            }
            for (var i = 0; i < pool.length; i++) {
                var s = pool[i];
                if (String(s.transaction_id || '').trim() !== txnId) continue;
                var meta = resolveSupplyTxnMeta(s, pool);
                var purchaseDate = s.date ? new Date(s.date) : null;
                var purchaseDateText = (purchaseDate && !isNaN(purchaseDate.getTime()))
                    ? purchaseDate.toLocaleDateString(typeof getDateLocale === 'function' ? getDateLocale() : undefined)
                    : '-';
                return {
                    batchNum: meta.batchNum,
                    invNum: meta.invNum,
                    company: meta.company,
                    expiryDate: meta.expiryDate,
                    purchaseDate: s.date,
                    purchaseDateText: purchaseDateText
                };
            }
            return { batchNum: '', invNum: '', company: '', expiryDate: '', purchaseDate: '', purchaseDateText: '-' };
        }

        function fifoExpiryMeta(expiryDateRaw) {
            var today = new Date();
            today.setHours(0, 0, 0, 0);
            var expiryDateObj = expiryDateRaw ? new Date(expiryDateRaw) : null;
            var hasExpiry = !!(expiryDateObj && !isNaN(expiryDateObj.getTime()));
            var daysToExpiry = null;
            var expiryStatusText = 'No Expiry';
            if (hasExpiry) {
                expiryDateObj.setHours(0, 0, 0, 0);
                daysToExpiry = Math.ceil((expiryDateObj.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
                if (daysToExpiry < 0) expiryStatusText = 'Expired ' + Math.abs(daysToExpiry) + 'd';
                else if (daysToExpiry === 0) expiryStatusText = 'Expires Today';
                else expiryStatusText = daysToExpiry + 'd left';
            }
            return { expiryDate: expiryDateRaw || '', expiryStatusText: expiryStatusText, daysToExpiry: daysToExpiry };
        }

        function formatFifoBatchCompanyInvoiceMeta(b, forHtml) {
            if (!b) return '';
            var comp = (b.supplier && String(b.supplier).trim() && String(b.supplier).trim() !== 'N/A')
                ? String(b.supplier).trim() : '';
            var inv = (b.invNum && String(b.invNum).trim()) ? String(b.invNum).trim() : '';
            if (!inv && b.txnId && String(b.txnId).trim()) {
                inv = String(b.txnId).trim();
            }
            var batchNum = (b.batchNum && String(b.batchNum).trim()) ? String(b.batchNum).trim() : '';
            var compLbl = (typeof t === 'function') ? t('wh_fifo_company') : 'کۆمپانیا';
            var invLbl = (typeof t === 'function') ? t('wh_fifo_invoice') : 'پسوولە';
            var batchLbl = (typeof t === 'function') ? t('wh_fifo_batch') : 'وەجبە';
            var bits = [];
            if (comp) bits.push(compLbl + ': ' + comp);
            if (inv) bits.push(invLbl + ': ' + inv);
            if (batchNum) bits.push(batchLbl + ': ' + batchNum);
            if (!bits.length) return '';
            var joined = bits.join(' | ');
            return forHtml && typeof escapeHtml === 'function' ? escapeHtml(joined) : joined;
        }
        window.formatFifoBatchCompanyInvoiceMeta = formatFifoBatchCompanyInvoiceMeta;

        function buildFifoBatchRowHtml(b) {
            var dateLbl = (typeof t === 'function') ? t('wh_fifo_purchase_date') : 'بەرواری کڕین';
            var expLbl = (typeof t === 'function') ? t('wh_fifo_expiry') : 'بەسەرچوون';
            var compLbl = (typeof t === 'function') ? t('wh_fifo_company') : 'کۆمپانیا';
            var invLbl = (typeof t === 'function') ? t('wh_fifo_invoice') : 'پسوولە';
            var batchLbl = (typeof t === 'function') ? t('wh_fifo_batch') : 'وەجبە';
            var metaLine = formatFifoBatchCompanyInvoiceMeta(b, true);
            var expiryColor = 'var(--text-muted)';
            if (b.daysToExpiry != null && b.daysToExpiry < 0) expiryColor = '#ef4444';
            else if (b.daysToExpiry != null && b.daysToExpiry <= 7) expiryColor = '#f59e0b';
            var expiryPart = b.expiryDate
                ? ('<div style="font-size:0.8rem; color:' + expiryColor + ';">' + escapeHtml(expLbl) + ': ' + escapeHtml(b.expiryDate) + ' (' + escapeHtml(b.expiryStatusText || '') + ')</div>')
                : ('<div style="font-size:0.8rem; color:var(--text-muted);">' + escapeHtml(expLbl) + ': -</div>');
            var comp = (b.supplier && String(b.supplier).trim() && String(b.supplier).trim() !== 'N/A') ? String(b.supplier).trim() : '';
            var inv = (b.invNum && String(b.invNum).trim()) ? String(b.invNum).trim() : '';
            if (!inv && b.txnId && String(b.txnId).trim()) inv = String(b.txnId).trim();
            var batchNum = (b.batchNum && String(b.batchNum).trim()) ? String(b.batchNum).trim() : '';
            var detailBits = '';
            if (comp) detailBits += '<div style="font-size:0.8rem; color:var(--brand);">' + escapeHtml(compLbl) + ': ' + escapeHtml(comp) + '</div>';
            if (inv) detailBits += '<div style="font-size:0.8rem; color:var(--brand);">' + escapeHtml(invLbl) + ': ' + escapeHtml(inv) + '</div>';
            if (batchNum) detailBits += '<div style="font-size:0.8rem; color:#0E4AFF;"><i class="fas fa-layer-group"></i> ' + escapeHtml(batchLbl) + ': <b>' + escapeHtml(batchNum) + '</b></div>';
            else if (!metaLine && b.txnId) detailBits += '<div style="font-size:0.8rem; color:var(--text-muted);">' + escapeHtml(invLbl) + ': ' + escapeHtml(String(b.txnId)) + '</div>';
            var isUsd = (typeof getActiveCurrency === 'function') && getActiveCurrency() === 'USD';
            var bUnitCostDisp = isUsd
                ? (typeof formatActiveCurrencyAmount === 'function' ? formatActiveCurrencyAmount(b.unitCostUsd || 0) : ('$' + (typeof formatUsdNumberPlain === 'function' ? formatUsdNumberPlain(b.unitCostUsd || 0) : Number(b.unitCostUsd || 0).toFixed(2))))
                : (typeof formatActiveCurrencyAmount === 'function' ? formatActiveCurrencyAmount(b.unitCost || 0) : String(Math.round(b.unitCost || 0)));
            return '<div style="display:flex; justify-content:space-between; border-bottom:1px dashed var(--border); padding:8px 0; font-size:0.9rem; gap:12px;">' +
                '<span style="min-width:72px;"><b>' + escapeHtml(String(b.qty)) + '</b> دانە</span>' +
                '<span style="flex:1; text-align:left;">' +
                    '<div style="font-weight:bold;">' + bUnitCostDisp + '</div>' +
                    '<div style="font-size:0.8rem; color:var(--text-muted);">' + escapeHtml(dateLbl) + ': ' + escapeHtml(b.purchaseDateText || '-') + '</div>' +
                    expiryPart +
                    (detailBits || (metaLine ? '<div style="font-size:0.8rem; color:var(--brand);">' + metaLine + '</div>' : '')) +
                '</span></div>';
        }

        if (!window.getProductFifoBatches) {
            window.getProductFifoBatches = function (pid, currentQty) {
                if (currentQty <= 0) return [];
                var pool = fifoSupplyPool(pid);
                var purchases = pool.filter(function (s) {
                    return String(s.prodId) === String(pid)
                        && s.type !== 'return' && s.type !== 'opening'
                        && (parseFloat(s.qtyAdded) || 0) > 0;
                });
                purchases.sort(function (a, b) { return new Date(b.date) - new Date(a.date); });
                var remainingQty = currentQty;
                var batches = [];
                for (var i = 0; i < purchases.length; i++) {
                    var p = purchases[i];
                    var qAdded = parseFloat(p.qtyAdded) || 0;
                    var tCost = parseFloat(p.totalCost) || 0;
                    var uCost = qAdded > 0 ? (tCost / qAdded) : 0;
                    var take = Math.min(qAdded, remainingQty);
                    if (take <= 0) continue;
                    var txnMeta = resolveSupplyTxnMeta(p, pool);
                    var purchaseDate = p.date ? new Date(p.date) : null;
                    var purchaseDateText = (purchaseDate && !isNaN(purchaseDate.getTime()))
                        ? purchaseDate.toLocaleDateString(typeof getDateLocale === 'function' ? getDateLocale() : undefined)
                        : '-';
                    var expiryDateRaw = txnMeta.expiryDate || String(p.expiry_date || '').trim();
                    var expMeta = fifoExpiryMeta(expiryDateRaw);
                    var rBatch = (p.fx_usd_rate != null && parseFloat(p.fx_usd_rate) >= 1000) ? (parseFloat(p.fx_usd_rate) / 100) : (typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0);
                    var prodRef = (db.products || []).find(function (x) { return String(x.id) === String(pid); });
                    var uCostUsd = (prodRef && prodRef.cost_usd != null && prodRef.cost_usd !== '' && parseFloat(prodRef.cost_usd) > 0)
                        ? parseFloat(prodRef.cost_usd)
                        : ((rBatch > 0) ? (typeof roundUsdCents === 'function' ? roundUsdCents(uCost / rBatch) : parseFloat((uCost / rBatch).toFixed(2))) : 0);
                    batches.push({
                        qty: take,
                        unitCost: uCost,
                        unitCostUsd: uCostUsd,
                        date: p.date,
                        purchaseDateText: purchaseDateText,
                        supplier: txnMeta.company || p.company,
                        invNum: txnMeta.invNum || p.supplier_invoice_number,
                        txnId: p.transaction_id || '',
                        batchNum: txnMeta.batchNum,
                        expiryDate: expMeta.expiryDate,
                        expiryStatusText: expMeta.expiryStatusText,
                        daysToExpiry: expMeta.daysToExpiry
                    });
                    remainingQty -= take;
                    if (remainingQty <= 0) break;
                }
                if (remainingQty > 0) {
                    var stockRows = (window._fifoStockBatchesByProduct && window._fifoStockBatchesByProduct[pid]) || [];
                    for (var bi = 0; bi < stockRows.length && remainingQty > 0; bi++) {
                        var row = stockRows[bi];
                        var bq = parseFloat(row.qty) || 0;
                        if (bq <= 0) continue;
                        var takeB = Math.min(bq, remainingQty);
                        var txnInfo = fifoMetaFromTxn(row.transaction_id, pool);
                        var expRaw = String(row.expiry_date || txnInfo.expiryDate || '').trim();
                        var expM = fifoExpiryMeta(expRaw);
                        var created = row.created_at ? new Date(row.created_at) : null;
                        var buyText = txnInfo.purchaseDateText;
                        if ((!buyText || buyText === '-') && created && !isNaN(created.getTime())) {
                            buyText = created.toLocaleDateString(typeof getDateLocale === 'function' ? getDateLocale() : undefined);
                        }
                        var rB2 = (typeof getUsdRatePerOne === 'function') ? getUsdRatePerOne() : 0;
                        var uCost2 = parseFloat(row.unit_cost) || 0;
                        var prodRef2 = (db.products || []).find(function (x) { return String(x.id) === String(pid); });
                        var uCostUsd2 = (prodRef2 && prodRef2.cost_usd != null && prodRef2.cost_usd !== '' && parseFloat(prodRef2.cost_usd) > 0)
                            ? parseFloat(prodRef2.cost_usd)
                            : ((rB2 > 0) ? (typeof roundUsdCents === 'function' ? roundUsdCents(uCost2 / rB2) : parseFloat((uCost2 / rB2).toFixed(2))) : 0);
                        batches.push({
                            qty: takeB,
                            unitCost: uCost2,
                            unitCostUsd: uCostUsd2,
                            date: txnInfo.purchaseDate || row.created_at || '',
                            purchaseDateText: buyText,
                            supplier: txnInfo.company || '',
                            invNum: txnInfo.invNum || '',
                            txnId: row.transaction_id || '',
                            batchNum: txnInfo.batchNum || '',
                            expiryDate: expM.expiryDate,
                            expiryStatusText: expM.expiryStatusText,
                            daysToExpiry: expM.daysToExpiry
                        });
                        remainingQty -= takeB;
                    }
                }
                if (remainingQty > 0) {
                    var prod = (db.products || []).find(function (x) { return String(x.id) === String(pid); });
                    var standardCost = prod ? (typeof getCatalogPieceCostIqd === 'function' ? getCatalogPieceCostIqd(prod) : (parseFloat(prod.cost) || 0)) : 0;
                    var standardCostUsd = prod ? (typeof getCatalogPieceCostUsd === 'function' ? getCatalogPieceCostUsd(prod) : (parseFloat(prod.cost_usd) || 0)) : 0;
                    var stdExpiry = prod ? String(prod.expiry || prod.batch_min_expiry || '').trim() : '';
                    var stdExpMeta = fifoExpiryMeta(stdExpiry);
                    var stdLbl = (typeof t === 'function') ? t('wh_fifo_standard_stock') : 'کۆگەی سەرەتایی / ستاندەر';
                    batches.push({
                        qty: remainingQty,
                        unitCost: standardCost,
                        unitCostUsd: standardCostUsd,
                        date: 'Initial/Standard',
                        purchaseDateText: stdLbl,
                        supplier: 'N/A',
                        invNum: '',
                        txnId: '',
                        batchNum: '',
                        expiryDate: stdExpMeta.expiryDate,
                        expiryStatusText: stdExpMeta.expiryStatusText,
                        daysToExpiry: stdExpMeta.daysToExpiry
                    });
                }
                batches.reverse();
                return batches;
            };
        }

        var _whRenderDebounceTimer = null;
        var _whServerSearchTimer = null;
        function renderWarehouse(filter) {
            if (filter) currentWhFilter = filter;
            if (!document.getElementById('wh-list-body')) return;

            var whIn = document.getElementById('wh-search');
            var whRaw = whIn ? String(whIn.value || '').trim() : '';
            if (!whRaw && typeof posClearWarehouseServerSearch === 'function') {
                posClearWarehouseServerSearch();
            }

            var scheduleRenderNow = function () {
                if (_whRenderDebounceTimer) clearTimeout(_whRenderDebounceTimer);
                var delay = isWmsLiteMode() ? 180 : 0;
                if (delay > 0) {
                    if (window._wmsSortedList && window._wmsSortedList.length && document.getElementById('wh-list-body')) {
                        paintWarehouseTablePage();
                    }
                    _whRenderDebounceTimer = setTimeout(function () {
                        _whRenderDebounceTimer = null;
                        renderWarehouseNow();
                    }, delay);
                    return;
                }
                renderWarehouseNow();
            };

            if (whRaw && typeof posWarehouseNeedsServerSearch === 'function' && posWarehouseNeedsServerSearch(whRaw)
                && typeof posWarehouseServerSearch === 'function') {
                scheduleRenderNow();
                if (_whServerSearchTimer) clearTimeout(_whServerSearchTimer);
                var searchDelay = 300;
                _whServerSearchTimer = setTimeout(function () {
                    _whServerSearchTimer = null;
                    posWarehouseServerSearch(whRaw).then(scheduleRenderNow).catch(scheduleRenderNow);
                }, searchDelay);
                return;
            }

            if (_whServerSearchTimer) {
                clearTimeout(_whServerSearchTimer);
                _whServerSearchTimer = null;
            }
            scheduleRenderNow();
        }
        window.renderWarehouse = renderWarehouse;
        function wmsStatusBadgeHtml(kind, label) {
            var icons = { service: 'fa-concierge-bell', out: 'fa-ban', nostock: 'fa-box-open', low: 'fa-arrow-down', ok: 'fa-check-circle', exp: 'fa-calendar-times', loss: 'fa-exclamation-triangle' };
            var ic = icons[kind] || 'fa-circle';
            return '<span class="wms-status-badge wms-status-badge--' + kind + '"><i class="fas ' + ic + '" aria-hidden="true"></i> ' + escapeHtml(label) + '</span>';
        }

        function isProductCostAboveSell(p) {
            if (!p) return false;
            var isUsd = (typeof getActiveCurrency === 'function') && getActiveCurrency() === 'USD';
            var cost = isUsd
                ? ((typeof getCatalogPieceCostUsd === 'function') ? getCatalogPieceCostUsd(p) : (parseFloat(p.cost_usd) || 0))
                : ((typeof getCatalogPieceCostIqd === 'function') ? getCatalogPieceCostIqd(p) : (parseFloat(p.cost) || 0));
            var sell = isUsd
                ? ((typeof getCatalogPieceSellUsd === 'function') ? getCatalogPieceSellUsd(p) : (parseFloat(p.price_usd) || 0))
                : ((typeof getCatalogPieceSellIqd === 'function') ? getCatalogPieceSellIqd(p) : (parseFloat(p.price) || 0));
            return cost > sell;
        }

        function getWmsLossPriceItems(items) {
            var out = [];
            if (!items || !items.length) return out;
            for (var i = 0; i < items.length; i++) {
                if (isProductCostAboveSell(items[i])) out.push(items[i]);
            }
            return out;
        }

        function formatWmsCatalogCountLabel(loaded, total) {
            loaded = parseInt(loaded, 10) || 0;
            total = parseInt(total, 10) || 0;
            if (total > loaded && loaded > 0) {
                return loaded + ' لە ' + total;
            }
            return String(total > 0 ? total : loaded);
        }

        function paintWmsCatalogCountEl(el, loaded, total, partial) {
            if (!el) return;
            var showPartial = partial && total > loaded && loaded > 0;
            el.textContent = formatWmsCatalogCountLabel(loaded, total);
            el.setAttribute('dir', showPartial ? 'rtl' : 'auto');
            el.title = showPartial ? (loaded + ' لە ' + total + ' — گەڕان هەموو دادەگەڕێت') : '';
            el.style.visibility = 'visible';
        }

        function getWmsCatalogCounts() {
            var loaded = (typeof posCatalogLoadedCount === 'function')
                ? posCatalogLoadedCount()
                : ((db && Array.isArray(db.products)) ? db.products.length : 0);
            var total = (typeof posCatalogTotal === 'function') ? posCatalogTotal() : loaded;
            if (window._wmsServerStats && window._wmsServerStats.total) {
                total = Math.max(total, parseInt(window._wmsServerStats.total, 10) || 0);
            }
            var partial = (typeof posIsCatalogPartial === 'function') && posIsCatalogPartial();
            if (!partial && total > loaded) partial = loaded > 0 && loaded < total;
            return { loaded: loaded, total: total, partial: partial };
        }

        var _wmsServerStatsTimer = null;
        function scheduleWmsServerStatsRefresh() {
            if (_wmsServerStatsTimer) clearTimeout(_wmsServerStatsTimer);
            var counts = getWmsCatalogCounts();
            if (!counts.partial && !window._wmsServerStats) return;
            _wmsServerStatsTimer = setTimeout(function () {
                _wmsServerStatsTimer = null;
                if (typeof posFetchWarehouseStats !== 'function') return;
                posFetchWarehouseStats().then(function () {
                    var vwh = document.getElementById('view-warehouse');
                    if (vwh && vwh.classList.contains('active')) {
                        updateWmsKpiFromServerOrLocal(window._wmsLastBuckets || null);
                        updateWmsPartialCatalogHint();
                    }
                });
            }, counts.partial ? 80 : 400);
        }

        function updateWmsKpiFromServerOrLocal(buckets) {
            var counts = getWmsCatalogCounts();
            var stats = window._wmsServerStats;
            var loaded = counts.loaded;
            var total = counts.total;
            if (stats && stats.status === 'ok' && stats.total) {
                total = Math.max(total, parseInt(stats.total, 10) || 0);
            }
            var partial = counts.partial || (total > loaded && loaded > 0);
            var elAll = document.getElementById('wh-count-all');
            var elLow = document.getElementById('wh-count-low');
            var elOut = document.getElementById('wh-count-out');
            var elExp = document.getElementById('wh-count-exp');
            paintWmsCatalogCountEl(elAll, loaded, total, partial);
            var useServer = partial && stats && stats.status === 'ok';
            if (elLow) {
                elLow.textContent = String(useServer ? (stats.low || 0) : (buckets ? buckets.low.length : 0));
                elLow.style.visibility = 'visible';
            }
            if (elOut) {
                elOut.textContent = String(useServer ? (stats.out || 0) : (buckets ? buckets.out.length : 0));
                elOut.style.visibility = 'visible';
            }
            if (elExp) {
                elExp.textContent = String(useServer ? (stats.exp || 0) : (buckets ? buckets.exp.length : 0));
                elExp.style.visibility = 'visible';
            }
        }

        function updateWmsKpiCountEls(allItems, filteredCount, buckets) {
            window._wmsLastBuckets = buckets;
            updateWmsKpiFromServerOrLocal(buckets);
            var titleEl = document.getElementById('wh-list-title');
            if (titleEl && titleEl.dataset) {
                titleEl.dataset.whFiltered = String(filteredCount);
            }
        }

        function updateWmsPartialCatalogHint() {
            var hint = document.getElementById('wms-partial-catalog-hint');
            if (!hint) {
                var filters = document.querySelector('#view-warehouse .wms-filters-card');
                if (!filters || !filters.parentNode) return;
                hint = document.createElement('div');
                hint.id = 'wms-partial-catalog-hint';
                hint.className = 'wms-partial-hint card';
                hint.style.cssText = 'margin:8px 0;padding:10px 14px;font-size:0.9rem;color:var(--brand);background:rgba(59,130,246,0.08);border:1px solid rgba(59,130,246,0.25);border-radius:10px;';
                filters.parentNode.insertBefore(hint, filters.nextSibling);
            }
            var counts = getWmsCatalogCounts();
            if (!counts.partial) {
                hint.style.display = 'none';
                return;
            }
            hint.style.display = 'block';
            var msg = (typeof t === 'function') ? t('wh_partial_catalog_hint') : '';
            if (!msg || msg === 'wh_partial_catalog_hint') {
                msg = counts.loaded + ' لە ' + counts.total + ' کاڵا بارکراون — خۆکار هەموو دەبارکرێت تا ژمارە تەواو بێت (' + counts.total + ')';
            } else {
                msg = msg.replace('{loaded}', String(counts.loaded)).replace('{total}', String(counts.total));
            }
            hint.innerHTML = '<i class="fas fa-info-circle" aria-hidden="true"></i> ' + escapeHtml(msg)
                + ' <button type="button" class="btn btn-sm btn-brand" style="margin-right:8px;" onclick="if(typeof posEnsureFullCatalogLoaded===\'function\')posEnsureFullCatalogLoaded().then(function(){ if(typeof renderWarehouse===\'function\')renderWarehouse(); });">'
                + '<i class="fas fa-sync"></i> بارکرنا هەمی</button>';
            if (typeof posPrioritizeCatalogLoadForWarehouse === 'function') posPrioritizeCatalogLoadForWarehouse();
            if (counts.total > counts.loaded && typeof posCatalogGapFill === 'function') {
                posCatalogGapFill(counts.loaded, counts.total);
            }
            // Auto-finish when only a few SKUs remain (banner should not stick at 2303/2305)
            if (counts.total > counts.loaded && (counts.total - counts.loaded) <= 30
                && typeof posEnsureFullCatalogLoaded === 'function' && !window.__wmsAutoCatalogFinish) {
                window.__wmsAutoCatalogFinish = true;
                posEnsureFullCatalogLoaded().then(function () {
                    window.__wmsAutoCatalogFinish = false;
                    if (typeof renderWarehouse === 'function') renderWarehouse();
                }).catch(function () { window.__wmsAutoCatalogFinish = false; });
            }
            scheduleWmsServerStatsRefresh();
        }

        function buildWmsAlertsList(lowItems, expItems, lossItems, lite) {
            var alerts = [];
            var alertMax = lite ? 12 : WMS_ALERTS_MAX;
            var alertMaxLow = lite ? 5 : lowItems.length;
            var qLab = (typeof t === 'function' ? t('wh_alert_qty_label') : 'ژمارە');
            var minLab = (typeof t === 'function' ? t('wh_alert_min_label') : 'کەمترین');
            var expLab = (typeof t === 'function' ? t('wh_col_expiry') : 'بەسەرچوون');
            var lossLab = (typeof t === 'function' ? t('wh_alert_loss_label') : 'بهایێ کڕینێ > فرۆتنێ');
            var lowAlertIds = {};
            var li, pAlert;
            lossItems = lossItems || [];
            for (li = 0; li < lossItems.length && alerts.length < alertMax; li++) {
                pAlert = lossItems[li];
                lowAlertIds[String(pAlert.id)] = true;
                var costTxt = (typeof formatActiveCurrencyAmount === 'function')
                    ? formatActiveCurrencyAmount((typeof getCatalogPieceCostActive === 'function' ? getCatalogPieceCostActive(pAlert) : (pAlert.cost || 0)))
                    : formatCurrency((typeof getCatalogPieceCostIqd === 'function' ? getCatalogPieceCostIqd(pAlert) : (pAlert.cost || 0)));
                var sellTxt = (typeof formatActiveCurrencyAmount === 'function')
                    ? formatActiveCurrencyAmount((typeof getCatalogPieceSellActive === 'function' ? getCatalogPieceSellActive(pAlert) : (pAlert.price || 0)))
                    : formatCurrency((typeof getCatalogPieceSellIqd === 'function' ? getCatalogPieceSellIqd(pAlert) : (pAlert.price || 0)));
                alerts.push({ type: 'loss', text: escapeHtml(pAlert.name) + ' – ' + lossLab + ' (' + costTxt + ' > ' + sellTxt + ')' });
            }
            for (li = 0; li < lowItems.length && alerts.length < alertMaxLow; li++) {
                pAlert = lowItems[li];
                if (lowAlertIds[String(pAlert.id)]) continue;
                lowAlertIds[String(pAlert.id)] = true;
                alerts.push({ type: 'low', text: escapeHtml(pAlert.name) + ' – ' + qLab + ' ' + pAlert.qty + ' (' + minLab + ': ' + getMinStock(pAlert) + ')' });
            }
            for (li = 0; li < expItems.length && alerts.length < alertMax; li++) {
                pAlert = expItems[li];
                if (lowAlertIds[String(pAlert.id)]) continue;
                alerts.push({ type: 'exp', text: escapeHtml(pAlert.name) + ' – ' + expLab + ' ' + ((typeof getProductCatalogExpiryDisplay === 'function') ? getProductCatalogExpiryDisplay(pAlert) : '-') });
            }
            var totalAlerts = lossItems.length + lowItems.length + expItems.length;
            var built = alerts.length;
            window._wmsAlertsTruncated = totalAlerts > built ? (totalAlerts - built) : 0;
            window._wmsAlertsList = alerts;
            window._wmsAlertsPage = 0;
            renderWmsAlertsStripUI();
        }

        function isWarehouseManufacturerUiOn() {
            return typeof canUseManufacturerCompanies === 'function' && canUseManufacturerCompanies();
        }

        function applyWarehouseManufacturerUi() {
            var on = isWarehouseManufacturerUiOn();
            try {
                document.body.classList.toggle('wms-mfr-ui-off', !on);
            } catch (eBody) {}
            var sel = document.getElementById('wms-filter-manufacturer');
            if (!on && sel) {
                sel.value = '';
                try { delete sel.dataset.fillKey; } catch (eFk) {}
            }
            return on;
        }
        window.applyWarehouseManufacturerUi = applyWarehouseManufacturerUi;
        window.isWarehouseManufacturerUiOn = isWarehouseManufacturerUiOn;

        function renderWarehouseNow() {
            if (typeof renderWmsWarehouseHub === 'function') {
                var whSearchElHub = document.getElementById('wh-search');
                var typingSearch = !!(whSearchElHub && String(whSearchElHub.value || '').trim());
                if (!typingSearch) renderWmsWarehouseHub();
            }
            if (typeof updateWmsPartialCatalogHint === 'function') updateWmsPartialCatalogHint();
            var whViewId = getActiveWmsWarehouseId() || resolveWmsQtyWarehouseId();
            const allItems = mapProductsForWarehouseView(db.products || [], whViewId);
            if(!document.getElementById('wh-list-body')) return;
            var mfrUiOn = applyWarehouseManufacturerUi();

            var lite = isWmsLiteMode();
            var pKey = getWmsProductsCacheKey(allItems) + '|wh' + whViewId;

            var catSel = document.getElementById('wms-filter-cat');
            if (catSel && !catSel.dataset.filled) {
                catSel.dataset.filled = '1';
                var fillCats = function () {
                    if (!catSel || catSel.dataset.filled !== '1') return;
                    var cats = [];
                    var seen = Object.create(null);
                    (db.categories || []).forEach(function (c) {
                        var s = String(c || '').trim();
                        if (s && !seen[s]) { seen[s] = 1; cats.push(s); }
                    });
                    for (var ci = 0; ci < allItems.length; ci++) {
                        var cv = String((allItems[ci].cat || allItems[ci].category) || '').trim();
                        if (cv && !seen[cv]) { seen[cv] = 1; cats.push(cv); }
                    }
                    cats.sort();
                    var allLab = (typeof t === 'function' ? t('wh_filter_all') : 'هەمی');
                    catSel.innerHTML = '<option value="" data-i18n-opt="wh_filter_all">' + escapeHtml(allLab) + '</option>' + cats.map(function (c) {
                        return '<option value="' + escapeHtml(c) + '">' + escapeHtml(c) + '</option>';
                    }).join('');
                };
                if (lite) setTimeout(fillCats, 0);
                else fillCats();
            } else if (catSel && catSel.options && catSel.options[0] && typeof t === 'function') {
                catSel.options[0].textContent = t('wh_filter_all');
            }
            var mfrSel = document.getElementById('wms-filter-manufacturer');
            if (mfrSel && mfrUiOn) {
                var mfrCount = (window.db && window.db.manufacturers) ? window.db.manufacturers.length : 0;
                var mfrFillKey = pKey + '|mfrlist|' + mfrCount;
                if (mfrSel.dataset.fillKey !== mfrFillKey) {
                    mfrSel.dataset.fillKey = mfrFillKey;
                    var prevMfr = mfrSel.value;
                    var mfrs = [];
                    var mfrSeen = Object.create(null);
                    
                    if (window.db && window.db.manufacturers) {
                        window.db.manufacturers.forEach(function(m) {
                            var mv = String(m.name || '').trim();
                            if (mv && !mfrSeen[mv]) { mfrSeen[mv] = 1; mfrs.push(mv); }
                        });
                    }
                    
                    for (var mi = 0; mi < allItems.length; mi++) {
                        var mv = String((allItems[mi].manufacturer || '')).trim();
                        if (mv && !mfrSeen[mv]) { mfrSeen[mv] = 1; mfrs.push(mv); }
                    }
                    mfrs.sort(function (a, b) { return a.localeCompare(b, 'ku', { sensitivity: 'base' }); });
                    var allLabM = (typeof t === 'function' ? t('wh_filter_all') : 'هەمی');
                    var noneLabM = (typeof t === 'function' ? t('wh_filter_no_manufacturer') : 'بێ کۆمپانیا');
                    var mfrOpts = '<option value="">' + escapeHtml(allLabM) + '</option>' +
                        '<option value="__none__">' + escapeHtml(noneLabM) + '</option>' +
                        mfrs.map(function (m) {
                            return '<option value="' + escapeHtml(m) + '">' + escapeHtml(m) + '</option>';
                        }).join('');
                    mfrSel.innerHTML = mfrOpts;
                    if (prevMfr) {
                        var hasPrev = false;
                        for (var moi = 0; moi < mfrSel.options.length; moi++) {
                            if (mfrSel.options[moi].value === prevMfr) { hasPrev = true; break; }
                        }
                        if (hasPrev) mfrSel.value = prevMfr;
                    }
                } else if (mfrSel.options && mfrSel.options[0] && typeof t === 'function') {
                    mfrSel.options[0].textContent = t('wh_filter_all');
                    if (mfrSel.options[1]) mfrSel.options[1].textContent = t('wh_filter_no_manufacturer');
                }
            }
            var catVal = catSel ? catSel.value : '';
            var curSel = document.getElementById('wms-filter-currency');
            if (curSel && typeof t === 'function') {
                var optAllC = curSel.querySelector('option[value=""]');
                var optIqdC = curSel.querySelector('option[value="IQD"]');
                var optUsdC = curSel.querySelector('option[value="USD"]');
                if (optAllC) optAllC.textContent = t('wh_filter_currency_all') || optAllC.textContent;
                if (optIqdC) optIqdC.textContent = t('wh_filter_currency_iqd') || optIqdC.textContent;
                if (optUsdC) optUsdC.textContent = t('wh_filter_currency_usd') || optUsdC.textContent;
            }
            var curVal = curSel ? String(curSel.value || '').toUpperCase() : '';
            var mfrVal = (mfrUiOn && mfrSel) ? mfrSel.value : '';
            var whRaw = (document.getElementById('wh-search') && document.getElementById('wh-search').value) ? String(document.getElementById('wh-search').value).trim() : '';

            var kpiScope = allItems;
            if (catVal) {
                kpiScope = kpiScope.filter(function (p) { return (p.cat || p.category || '') === catVal; });
            }
            if (curVal === 'USD' || curVal === 'IQD') {
                kpiScope = kpiScope.filter(function (p) {
                    var pc = (typeof getProductBaseCurrency === 'function')
                        ? getProductBaseCurrency(p)
                        : String((p && (p.base_currency || p.currency)) || '').toUpperCase();
                    return pc === curVal;
                });
            }
            if (mfrVal === '__none__') {
                kpiScope = kpiScope.filter(function (p) { return !String(p.manufacturer || '').trim(); });
            } else if (mfrVal) {
                kpiScope = kpiScope.filter(function (p) { return String(p.manufacturer || '').trim() === mfrVal; });
            }
            if (whRaw) {
                kpiScope = kpiScope.filter(function (p) {
                    if (typeof window.productMatchesBarcodeOrNameSearch === 'function' && window.productMatchesBarcodeOrNameSearch(p, whRaw)) return true;
                    var lq2 = whRaw.toLowerCase();
                    if ((p.cat || p.category || '').toLowerCase().indexOf(lq2) !== -1) return true;
                    if (p.manufacturer && String(p.manufacturer).toLowerCase().indexOf(lq2) !== -1) return true;
                    return false;
                });
            }
            var bucketsFiltered = !!(catVal || curVal || mfrVal || whRaw);
            var buckets = getWmsProductBuckets(kpiScope, bucketsFiltered ? { skipCache: true } : {});
            var lowItems = buckets.low;
            var outItems = buckets.out;
            var expItems = buckets.exp;
            var inStockItems = buckets.inStock || [];

            var list = [];
            var title = (typeof t === 'function' ? t('wh_title_all_items') : 'هەمی ئایتم');
            if (currentWhFilter === 'instock') {
                list = inStockItems.slice();
                title = (typeof t === 'function' ? t('wh_title_instock') : 'ئایتمێن د مەخزەنێ دا');
            } else if (currentWhFilter === 'all') {
                list = kpiScope.slice();
            } else if (currentWhFilter === 'low') {
                list = lowItems.slice();
                title = (typeof t === 'function' ? t('wh_title_low') : 'ئایتمێن کێمبووی (حد أدنى)');
            } else if (currentWhFilter === 'out') {
                list = outItems.slice();
                title = (typeof t === 'function' ? t('wh_title_out') : 'ئایتمێن نەما');
            } else if (currentWhFilter === 'expired') {
                list = expItems.slice();
                title = (typeof t === 'function' ? t('wh_title_expired') : 'ئایتمێن بەسەرچووی');
            } else {
                list = kpiScope.slice();
            }

            list.sort(function (a, b) {
                var aElse = (typeof getOtherWarehouseStockLines === 'function' && getOtherWarehouseStockLines(a, a._warehouse_id).length);
                var bElse = (typeof getOtherWarehouseStockLines === 'function' && getOtherWarehouseStockLines(b, b._warehouse_id).length);
                var aOut = (isWarehouseTrueStockout(a) && !aElse) ? 1 : 0;
                var bOut = (isWarehouseTrueStockout(b) && !bElse) ? 1 : 0;
                if (aOut !== bOut) return bOut - aOut;
                return 0;
            });
            window._wmsSortedList = list;
            window._wmsListTitle = title;
            window._wmsTablePage = 0;
            if (typeof syncWmsPrintZeroToggleUi === 'function') syncWmsPrintZeroToggleUi();

            paintWarehouseTablePage();

            updateWmsKpiCountEls(bucketsFiltered ? kpiScope : allItems, list.length, buckets);

            var finishWarehouseChrome = function () {
                if (!lite && list.length <= 200 && typeof window.getProductFifoBatches === 'function') {
                    list.forEach(function (p) {
                        if (p.trackStock && p.qty > 0) {
                            var q = parseFloat(p.qty) || 0;
                            p._fifoBatches = window.getProductFifoBatches(p.id, q);
                        } else {
                            p._fifoBatches = null;
                        }
                    });
                    paintInventoryValuationTotals(list);
                } else {
                    window._wmsTotalsKey = pKey + '|' + (catVal || '') + '|' + (curVal || '') + '|' + (whRaw || '') + '|' + currentWhFilter;
                    scheduleWarehouseTotals(list);
                }
                buildWmsAlertsList(lowItems, expItems, getWmsLossPriceItems(bucketsFiltered ? kpiScope : allItems), lite);
                if (typeof posEnhanceUiIcons === 'function') {
                    try { posEnhanceUiIcons(); } catch (_eWhIc) {}
                }
            };

            if (lite) {
                list.forEach(function (p) { p._fifoBatches = null; });
                setTimeout(finishWarehouseChrome, 0);
            } else if (typeof window.posEnsureFifoSupplyPoolLoaded === 'function') {
                window.posEnsureFifoSupplyPoolLoaded().then(finishWarehouseChrome).catch(finishWarehouseChrome);
            } else {
                finishWarehouseChrome();
            }
        }
        function paintWmsProductDetailBody(p) {
            var minS = getMinStock(p);
            var body = document.getElementById('wms-product-detail-body');
            if (!body || !p) return;
            var batchesHtml = '';
            if (p.trackStock && p.qty > 0 && window.getProductFifoBatches) {
                var batches = window.getProductFifoBatches(p.id, p.qty);
                if (batches.length > 0) {
                    batchesHtml = '<div style="margin-top:10px; padding:10px; background:var(--input-bg); border-radius:8px; border:1px solid var(--border);">';
                    batchesHtml += '<strong style="color:var(--brand); display:block; margin-bottom:5px;">کۆگەهـ ل دویڤ کڕینێ (FIFO Batches):</strong>';
                    batches.forEach(function (b) { batchesHtml += buildFifoBatchRowHtml(b); });
                    batchesHtml += '</div>';
                }
            }

            var detailCost = (typeof getCatalogPieceCostActive === 'function' ? getCatalogPieceCostActive(p) : (p.cost || 0));
            var detailSell = (typeof getCatalogPieceSellActive === 'function' ? getCatalogPieceSellActive(p) : (p.price || 0));
            var detailCostFormatted = (typeof formatActiveCurrencyAmount === 'function') ? formatActiveCurrencyAmount(detailCost) : String(detailCost);
            var detailSellFormatted = (typeof formatActiveCurrencyAmount === 'function') ? formatActiveCurrencyAmount(detailSell) : String(detailSell);
            var mfrLbl = (typeof t === 'function') ? t('wh_col_manufacturer') : 'کۆمپانیا دروستکەر';
            var mfrVal = (p.manufacturer != null && String(p.manufacturer).trim()) ? String(p.manufacturer).trim() : '—';
            var mfrLine = '';
            if (typeof isWarehouseManufacturerUiOn === 'function' ? isWarehouseManufacturerUiOn() : (typeof canUseManufacturerCompanies === 'function' && canUseManufacturerCompanies())) {
                mfrLine = '<div><strong>' + escapeHtml(mfrLbl) + ':</strong> ' + escapeHtml(mfrVal) + '</div>';
            }
            var lossBanner = isProductCostAboveSell(p)
                ? '<div class="wms-detail-loss-banner"><i class="fas fa-exclamation-triangle" aria-hidden="true"></i> ' + escapeHtml((typeof t === 'function') ? t('wh_loss_hint') : 'بهایێ کڕینێ لە فرۆتنێ زیاترە') + ' (' + detailCostFormatted + ' > ' + detailSellFormatted + ')</div>'
                : '';
            
            // Format basic info
            var idHtml = p.id || '-';
            var barcodeHtml = escapeHtml(p.barcode || '-');
            var nameHtml = escapeHtml(p.name || 'ئایتم');
            var catHtml = escapeHtml(p.cat || p.category || '-');
            var unitHtml = (p.unitType || 'carton') + (p.itemsPerCarton ? ' × ' + p.itemsPerCarton : '');
            var qtyHtml = p.trackStock ? formatQtyForDisplay((p.qty || 0), p) : '∞';
            var minStockHtml = minS;
            var expiryHtml = ((typeof getProductCatalogExpiryDisplay === 'function') ? getProductCatalogExpiryDisplay(p) : '-');
            
            // Format extra details
            var discountHtml = '-';
            if (p.discountAmount > 0) {
                discountHtml = (typeof formatActiveCurrencyAmount === 'function' ? formatActiveCurrencyAmount(p.discountAmount) : formatCurrency(p.discountAmount)) + (p.discountType === 'percent' ? ' (' + p.discountAmount + '%)' : ' (بڕی جێگیر)');
            }
            var taxHtml = '-';
            if (p.taxRate > 0) taxHtml = p.taxRate + '%';
            
            var costCarton = (typeof getCatalogCartonCostActive === 'function') ? getCatalogCartonCostActive(p) : (p.costCarton || 0);
            var priceCarton = (typeof getCatalogCartonSellActive === 'function') ? getCatalogCartonSellActive(p) : (p.priceCarton || 0);
            var hasCartonPricing = p.itemsPerCarton > 1 && (costCarton > 0 || priceCarton > 0);
            
            var cartonPricingHtml = '';
            if (hasCartonPricing) {
                var costCartonDisp = (typeof formatActiveCurrencyAmount === 'function') ? formatActiveCurrencyAmount(costCarton) : String(costCarton);
                var priceCartonDisp = (typeof formatActiveCurrencyAmount === 'function') ? formatActiveCurrencyAmount(priceCarton) : String(priceCarton);
                cartonPricingHtml = '<div style="margin-top:8px; padding-top:8px; border-top:1px dashed var(--border);">' +
                    '<div><strong>کرینیێ کارتۆن:</strong> ' + costCartonDisp + '</div>' +
                    '<div><strong>فرۆتنا کارتۆن:</strong> ' + priceCartonDisp + '</div>' +
                '</div>';
            }

            body.innerHTML = lossBanner +
                '<div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:12px; line-height:1.6; font-size:1.05em;">' +
                    '<div>' +
                        '<div><strong>SKU:</strong> ' + idHtml + '</div>' +
                        '<div><strong>بارکۆد:</strong> ' + barcodeHtml + '</div>' +
                        '<div style="margin-top:4px;"><strong>ناڤ:</strong> <span style="font-size:1.1em; color:var(--brand);">' + nameHtml + '</span></div>' +
                        '<div><strong>پۆل:</strong> ' + catHtml + '</div>' +
                        mfrLine +
                    '</div>' +
                    '<div>' +
                        '<div><strong>یەکە:</strong> ' + unitHtml + '</div>' +
                        '<div><strong>کۆگەهـ (هەنوکە):</strong> <span style="font-weight:bold; font-size:1.1em;">' + qtyHtml + '</span></div>' +
                        '<div><strong>کەمترین بڕ:</strong> ' + minStockHtml + '</div>' +
                        '<div><strong>بەسەرچوون:</strong> ' + expiryHtml + '</div>' +
                    '</div>' +
                '</div>' +
                
                '<div style="background:var(--input-bg); padding:12px; border-radius:10px; border:1px solid var(--border); margin-bottom:12px; line-height:1.6; font-size:1.05em;">' +
                    '<div><strong>کرینیێ ستاندەر (کرینیێ تاک):</strong> <span class="' + (isProductCostAboveSell(p) ? 'wms-text-loss' : '') + '">' + detailCostFormatted + '</span></div>' +
                    '<div><strong>نرخێ فرۆتنێ (فرۆتنا تاک):</strong> <span class="' + (isProductCostAboveSell(p) ? 'wms-text-loss' : '') + '">' + detailSellFormatted + '</span></div>' +
                    cartonPricingHtml +
                    '<div style="margin-top:8px; padding-top:8px; border-top:1px dashed var(--border);">' +
                        '<div><strong>داشکاندن:</strong> ' + discountHtml + '</div>' +
                        '<div><strong>باج (Tax):</strong> ' + taxHtml + '</div>' +
                    '</div>' +
                '</div>' +
                
                batchesHtml +
                
                '<div style="margin-top:16px; display:flex; gap:8px; flex-wrap:wrap; justify-content:center;">' +
                '<button type="button" class="btn btn-brand btn-sm" onclick="document.getElementById(\'wms-product-modal\').style.display=\'none\'; if(typeof showItemReport===\'function\') showItemReport(' + p.id + ');" style="padding:10px 16px; font-size:1.05em;"><i class="fas fa-chart-line"></i> ڕاپۆرتی وردە و لڤینان</button>' +
                '<button type="button" class="btn btn-info btn-sm" onclick="showWmsProductPurchaseHistory(' + p.id + ');" style="padding:10px 16px; font-size:1.05em;"><i class="fas fa-history"></i> مێژویا کڕینێ (مفصل)</button>' +
                '</div>';
        }
        function openWmsProductDetail(pid) {
            var p = db.products.find(function(x){ return x.id == pid; });
            if(!p) return;
            var modal = document.getElementById('wms-product-modal');
            if (!modal) return;
            modal.style.display = 'flex';
            var body = document.getElementById('wms-product-detail-body');
            if (body) body.innerHTML = '<div style="padding:12px; color:var(--text-muted);"><i class="fas fa-spinner fa-spin"></i> ...</div>';
            var paint = function () { paintWmsProductDetailBody(p); };
            if (typeof window.posEnsureProductFifoSupplies === 'function') {
                window.posEnsureProductFifoSupplies(p.id).then(paint).catch(paint);
            } else if (typeof window.posEnsureFifoSupplyPoolLoaded === 'function') {
                window.posEnsureFifoSupplyPoolLoaded().then(paint).catch(paint);
            } else {
                paint();
            }
        }
        window.openWmsProductDetail = openWmsProductDetail;

        function showWmsProductPurchaseHistory(productId) {
            var p = db.products.find(function(x) { return x.id === productId; });
            if (!p) return;
            
            var modal = document.getElementById('wms-purchase-history-modal');
            var titleEl = document.getElementById('wms-purchase-history-title');
            var bodyEl = document.getElementById('wms-purchase-history-body');
            if (!modal || !bodyEl) return;
            modal.classList.add('hist-modal');
            var whShell = modal.querySelector('.hist-shell, .glass-card');
            if (whShell) whShell.classList.add('hist-shell');
            
            titleEl.innerHTML = escapeHtml(p.name || 'ئایتم') + ' (' + escapeHtml(p.barcode || '-') + ')';
            bodyEl.innerHTML = '<div style="text-align:center; padding:20px;"><i class="fas fa-spinner fa-spin"></i> د بارکرنێ دایە...</div>';
            modal.style.display = 'flex';
            
            var fetchAndPaint = function() {
                if (typeof window.posEnsureProductFifoSupplies === 'function') {
                    window.posEnsureProductFifoSupplies(p.id).then(function(supplies) {
                        paintSupplies(supplies);
                    }).catch(function(err) {
                        bodyEl.innerHTML = '<div style="color:var(--danger); text-align:center; padding:20px;">خەتەک چێبوو د بارکرنا مێژوویێ دا: ' + escapeHtml(err.message || String(err)) + '</div>';
                    });
                } else {
                    var localSupplies = (db.supplies || []).filter(function(s) {
                        return String(s.prodId) === String(p.id) && s.type !== 'return' && (parseFloat(s.qtyAdded) || 0) > 0;
                    });
                    paintSupplies(localSupplies);
                }
            };
            fetchAndPaint();
            
            function paintSupplies(supplies) {
                var validSupplies = (supplies || []).filter(function(s) {
                    return s.type !== 'return' && (parseFloat(s.qtyAdded) || 0) > 0;
                });
                
                if (validSupplies.length === 0) {
                    bodyEl.innerHTML = '<div style="text-align:center; padding:20px; color:var(--text-muted);">چ مێژوویا کڕینێ بۆ ڤی ئایتمی نەهاتیە دیتن.</div>';
                    return;
                }
                
                // Sort by date ascending to assign purchase order numbers
                validSupplies.sort(function(a, b) {
                    return new Date(a.date) - new Date(b.date);
                });
                
                // Assign "jara chandê ye" (purchase occurrence number)
                validSupplies.forEach(function(s, index) {
                    s._occurrenceNumber = index + 1;
                });
                
                // Now sort by date descending for display
                validSupplies.sort(function(a, b) {
                    return new Date(b.date) - new Date(a.date);
                });

                var totalPurchases = validSupplies.length;
                var totalQtyAll = 0;
                var totalCostAll = 0;
                var totalCostUsd = 0;
                validSupplies.forEach(function(s) {
                    totalQtyAll += parseFloat(s.qtyAdded) || 0;
                    var lineCost = parseFloat(s.totalCost) || 0;
                    totalCostAll += lineCost;
                    var sFx = (typeof fxUsdRateFormatOpts === 'function') ? fxUsdRateFormatOpts(s) : undefined;
                    if (typeof storedIqdToUsdDisplayAmount === 'function') {
                        totalCostUsd += storedIqdToUsdDisplayAmount(lineCost, sFx);
                    }
                });
                var totalQtyStr = (typeof formatQtyForDisplay === 'function') ? formatQtyForDisplay(totalQtyAll, p) : String(totalQtyAll);
                var totalCostFx = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD' && totalCostUsd)
                    ? { directUsd: totalCostUsd }
                    : ((typeof fxUsdRateFormatOpts === 'function' && validSupplies[0]) ? fxUsdRateFormatOpts(validSupplies[0]) : undefined);

                var statsHtml = (typeof window.histStatsHtml === 'function')
                    ? window.histStatsHtml([
                        { label: 'ژمارا کڕینان', value: totalPurchases, tone: 'accent' },
                        { label: 'کۆیا بڕی', value: totalQtyStr, tone: 'teal' },
                        { label: 'کۆیا کرینی', value: (typeof formatCurrency === 'function' ? formatCurrency(totalCostAll, totalCostFx) : String(totalCostAll)), tone: 'amber' }
                    ])
                    : ('<div class="hist-stats">' +
                        '<div class="hist-stat tone-accent"><div class="hist-stat-label">ژمارا کڕینان</div><div class="hist-stat-value">' + totalPurchases + '</div></div>' +
                        '<div class="hist-stat tone-teal"><div class="hist-stat-label">کۆیا بڕی</div><div class="hist-stat-value">' + escapeHtml(totalQtyStr) + '</div></div>' +
                        '<div class="hist-stat"><div class="hist-stat-label">کۆیا کرینی</div><div class="hist-stat-value">' + formatCurrency(totalCostAll, totalCostFx) + '</div></div></div>');

                var hasBonusCol = validSupplies.some(function(s) {
                    return (parseFloat(s.bonusQty || s.freeQty || 0) || 0) > 0;
                });
                var hasGiftCol = validSupplies.some(function(s) {
                    return (typeof window.isSupplyItemGift === 'function')
                        ? window.isSupplyItemGift(s)
                        : !!(s && (s.isGift === true || s.is_gift === 1 || s.is_gift === '1' || s.is_gift === true));
                });

                var html = statsHtml +
                    '<table class="hist-table report-table">' +
                    '<thead>' +
                        '<tr>' +
                            '<th style="text-align:center;">جارا</th>' +
                            '<th style="text-align:center;">بەروار</th>' +
                            '<th style="text-align:center;">وەسڵێ دابینکەری</th>' +
                            '<th style="text-align:center;">دابینکەر</th>' +
                            '<th style="text-align:center;">بڕ (قتع)</th>' +
                            (hasBonusCol ? '<th style="text-align:center;">بۆنوس</th>' : '') +
                            (hasGiftCol ? '<th style="text-align:center;">هدیە</th>' : '') +
                            '<th style="text-align:center;">نرخی یەکێ</th>' +
                            '<th style="text-align:center;">کۆیا کرینێ</th>' +
                        '</tr>' +
                    '</thead>' +
                    '<tbody>';
                
                validSupplies.forEach(function(s) {
                    var qtyVal = parseFloat(s.qtyAdded) || 0;
                    var qtyStr = (typeof formatQtyForDisplay === 'function') ? formatQtyForDisplay(qtyVal, p) : String(qtyVal);
                    
                    var totalCostVal = parseFloat(s.totalCost) || 0;
                    var unitCostVal = qtyVal > 0 ? (totalCostVal / qtyVal) : 0;
                    var isGiftRow = (typeof window.isSupplyItemGift === 'function')
                        ? window.isSupplyItemGift(s)
                        : !!(s && (s.isGift === true || s.is_gift === 1 || s.is_gift === '1' || s.is_gift === true));
                    var sFx = (typeof fxUsdRateFormatOpts === 'function') ? fxUsdRateFormatOpts(s) : undefined;
                    
                    var bonusQty = parseFloat(s.bonusQty || s.freeQty || 0);
                    var bonusStr = bonusQty > 0 ? ((typeof formatQtyForDisplay === 'function') ? formatQtyForDisplay(bonusQty, p) : String(bonusQty)) : '-';
                    
                    // Format dates
                    var dateStr = '-';
                    if (s.date) {
                        try {
                            var d = new Date(s.date);
                            dateStr = d.toLocaleDateString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ') + 
                                      ' ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                        } catch(e) {
                            dateStr = String(s.date);
                        }
                    }
                    
                    var companyName = (s.companyName || s.company || '').trim();
                    if (companyName === '' && s.company_id) {
                        var comp = (db.companies || []).find(function(c) { return Number(c.id) === Number(s.company_id); });
                        if (comp) companyName = comp.name;
                    }
                    if (companyName === '') companyName = 'دابینکەرێ نەناسراو';
                    
                    // Prefer supplier invoice / transaction — not internal supply row id
                    var invoiceStr = '-';
                    var invNum = String(s.supplier_invoice_number || s.invoiceId || s.bill_id || '').trim();
                    var txnId = String(s.transaction_id || s.ref_id || '').trim();
                    if (invNum) invoiceStr = invNum;
                    else if (txnId) invoiceStr = txnId.length > 12 ? ('…' + txnId.slice(-10)) : txnId;
                    
                    html += '<tr>' +
                        '<td style="text-align:center; font-weight:800; color:var(--brand);">جارا ' + s._occurrenceNumber + '</td>' +
                        '<td style="direction:ltr; text-align:center;">' + escapeHtml(dateStr) + '</td>' +
                        '<td style="font-weight:700; color:var(--brand); text-align:center;" title="' + escapeHtml(txnId || invNum || '') + '">' + escapeHtml(invoiceStr) + '</td>' +
                        '<td style="font-weight:700; text-align:center;">' + escapeHtml(companyName) + '</td>' +
                        '<td style="font-weight:800; text-align:center;">' + escapeHtml(qtyStr) + '</td>' +
                        (hasBonusCol ? ('<td style="color:var(--success); text-align:center;">' + escapeHtml(bonusStr) + '</td>') : '') +
                        (hasGiftCol ? ('<td style="text-align:center; font-weight:700; color:' + (isGiftRow ? '#ec4899' : 'var(--text-muted)') + ';">' + (isGiftRow ? 'بەڵێ' : '-') + '</td>') : '') +
                        '<td style="color:var(--brand); text-align:center; font-weight:700;">' + formatCurrency(unitCostVal, sFx) + '</td>' +
                        '<td style="font-weight:800; text-align:center;">' + formatCurrency(totalCostVal, sFx) + '</td>' +
                    '</tr>';
                });
                
                html += '</tbody></table>';
                bodyEl.innerHTML = html;
            }
        }
        window.showWmsProductPurchaseHistory = showWmsProductPurchaseHistory;

        var wmsMovTab = 'all';
        var wmsMovFetchSeq = 0;
        var wmsMovSearchTimer = null;
        var wmsMovementsCache = [];
        var wmsMovSelectedPid = 0;
        var wmsMovSelectedName = '';
        var wmsMovementTypeLabels = {
            purchase: 'کڕین',
            purchase_edit: 'دەستکارییا کرینێ',
            purchase_deletion: 'ڕەشکرنا کرینێ',
            purchase_restore: 'زڤڕاندنا کرینێ',
            customer_return: 'زڤڕاندن کریار',
            sale: 'فرۆتن',
            sale_edit: 'دەستکارییا فرۆتنێ',
            sale_void_wh: 'ڕەشکرنا فرۆتنێ',
            sale_void_restore: 'زڤڕاندنا فرۆتنێ',
            sale_restore_void: 'زڤڕاندنا وەسڵێ',
            supplier_return: 'زڤڕاندن دابینکەر',
            waste: 'تەلەف',
            stocktake: 'جەرد',
            adjustment: 'دەستکاری',
            transfer_in: 'گواستنەوە (هاتن)',
            transfer_out: 'گواستنەوە (چوون)',
            recipe_produce: 'ڕەچەتە (دروستکرن)',
            recipe_consume: 'ڕەچەتە (خەرج)'
        };
        function wmsMovTabId(tab) {
            if (tab === 'inbound') return 'in';
            if (tab === 'outbound') return 'out';
            if (tab === 'damaged') return 'damaged';
            return 'all';
        }
        function wmsMovKind() {
            if (wmsMovTab === 'inbound') return 'in';
            if (wmsMovTab === 'outbound') return 'out';
            if (wmsMovTab === 'damaged') return 'waste';
            return 'all';
        }
        function wmsQtyIsIn(m) {
            var typ = String(m.movement_type || '');
            var q = parseFloat(m.quantity) || 0;
            if (typ === 'sale' || typ === 'supplier_return' || typ === 'transfer_out' || typ === 'waste' || typ === 'purchase_deletion' || typ === 'sale_restore_void' || typ === 'recipe_consume' || typ === 'sale_void_wh') return false;
            if (typ === 'purchase' || typ === 'customer_return' || typ === 'transfer_in' || typ === 'purchase_restore' || typ === 'sale_void_restore' || typ === 'recipe_produce') return true;
            if ((typ === 'stocktake' || typ === 'adjustment' || typ === 'purchase_edit' || typ === 'sale_edit') && q > 0) return true;
            return q > 0;
        }
        function formatWmsMovQty(m) {
            var q = parseFloat(m.quantity) || 0;
            var prod = null;
            try {
                if (db && db.products) prod = db.products.find(function(p){ return p && Number(p.id) === Number(m.product_id); });
            } catch (_e) {}
            var absTxt = (typeof formatQtyForDisplay === 'function') ? formatQtyForDisplay(Math.abs(q), prod) : String(Math.abs(q));
            if (q === 0) return '0';
            return wmsQtyIsIn(m) ? ('+' + absTxt) : ('-' + absTxt);
        }
        function wmsMovHideSuggest() {
            var box = document.getElementById('wms-mov-suggest');
            if (box) { box.style.display = 'none'; box.innerHTML = ''; }
        }
        function wmsMovMatchProducts(q) {
            var list = (db && db.products) ? db.products : [];
            var ql = String(q || '').trim().toLowerCase();
            if (!ql) return list.slice(0, 8);
            return list.filter(function(p){
                if (!p) return false;
                return String(p.name || '').toLowerCase().indexOf(ql) !== -1
                    || String(p.barcode || '').toLowerCase().indexOf(ql) !== -1
                    || String(p.id || '') === ql;
            }).slice(0, 8);
        }
        function paintWmsMovSuggestions(q) {
            var box = document.getElementById('wms-mov-suggest');
            if (!box) return;
            if (q === undefined) {
                var qEl0 = document.getElementById('wms-mov-item-search');
                q = qEl0 ? String(qEl0.value || '').trim() : '';
            }
            var hits = wmsMovMatchProducts(q);
            if (!hits.length) { wmsMovHideSuggest(); return; }
            box.innerHTML = hits.map(function(p){
                var qty = (typeof formatQtyForDisplay === 'function') ? formatQtyForDisplay(p.qty || 0, p) : String(p.qty || 0);
                return '<button type="button" class="wms-mov-suggest-item" data-pid="' + escapeHtml(String(p.id)) + '" style="display:block; width:100%; text-align:right; padding:10px 12px; border:0; border-bottom:1px solid var(--border,#eee); background:transparent; cursor:pointer;">'
                    + '<strong>' + escapeHtml(p.name || '') + '</strong>'
                    + '<span style="display:block; font-size:0.8rem; color:var(--text-muted);">بارکۆد: ' + escapeHtml(p.barcode || '-') + ' · مەخزەن: ' + escapeHtml(String(qty)) + '</span>'
                    + '</button>';
            }).join('');
            box.style.display = 'block';
            box.querySelectorAll('.wms-mov-suggest-item').forEach(function(btn){
                btn.addEventListener('click', function(){
                    var pid = parseInt(btn.getAttribute('data-pid'), 10) || 0;
                    var prod = hits.find(function(x){ return Number(x.id) === pid; });
                    pickWmsMovProduct(pid, prod ? prod.name : '');
                });
            });
        }
        function pickWmsMovProduct(pid, name) {
            wmsMovSelectedPid = parseInt(pid, 10) || 0;
            wmsMovSelectedName = String(name || '');
            var qEl = document.getElementById('wms-mov-item-search');
            if (qEl) qEl.value = wmsMovSelectedName;
            wmsMovHideSuggest();
            renderWmsMovements();
        }
        function hideWmsItemLedger() {
            var ledger = document.getElementById('wms-mov-item-ledger');
            var searchEl = document.getElementById('stock-card-search');
            var productBox = document.getElementById('stock-card-product');
            if (searchEl) searchEl.value = '';
            if (ledger) ledger.style.display = 'none';
            if (productBox) productBox.style.display = 'none';
        }
        function syncWmsItemLedger(matchedProduct) {
            var pid = 0;
            if (matchedProduct && matchedProduct.id) pid = parseInt(matchedProduct.id, 10) || 0;
            if (!pid && wmsMovSelectedPid > 0) pid = wmsMovSelectedPid;
            if (!pid) {
                hideWmsItemLedger();
                return;
            }
            var searchEl = document.getElementById('stock-card-search');
            var ledger = document.getElementById('wms-mov-item-ledger');
            if (searchEl) searchEl.value = String(pid);
            if (ledger) ledger.style.display = 'block';
            loadStockCard();
        }
        function clearWmsMovProduct() {
            wmsMovSelectedPid = 0;
            wmsMovSelectedName = '';
            var qEl = document.getElementById('wms-mov-item-search');
            if (qEl) qEl.value = '';
            wmsMovHideSuggest();
            hideWmsItemLedger();
            renderWmsMovements();
        }
        function handleWmsMovSearchKey(ev) {
            if (!ev) return;
            if (ev.key === 'Escape') { wmsMovHideSuggest(); return; }
            if (ev.key !== 'Enter') return;
            ev.preventDefault();
            var qEl = document.getElementById('wms-mov-item-search');
            var q = qEl ? String(qEl.value || '').trim() : '';
            var hits = wmsMovMatchProducts(q);
            if (hits.length === 1) pickWmsMovProduct(hits[0].id, hits[0].name);
            else { wmsMovHideSuggest(); renderWmsMovements(); }
        }
        function paintWmsMovementRows(tbody, list, matchedProduct, purchaseSources) {
            var sumEl = document.getElementById('wms-mov-item-summary');
            var loc = (typeof getDateLocale === 'function') ? getDateLocale() : 'ar-IQ';
            if (sumEl) {
                if (matchedProduct && matchedProduct.id) {
                    var qtyTxt = (typeof formatQtyForDisplay === 'function')
                        ? formatQtyForDisplay(matchedProduct.qty || 0, matchedProduct)
                        : String(matchedProduct.qty || 0);
                    var last = (purchaseSources && purchaseSources.last) ? purchaseSources.last : null;
                    var companies = (purchaseSources && purchaseSources.companies) ? purchaseSources.companies : [];
                    var lastDate = '';
                    if (last && last.date) {
                        try { lastDate = new Date(last.date).toLocaleDateString(loc); } catch (_ld) { lastDate = String(last.date); }
                    }
                    var companyRows = companies.map(function(c, idx){
                        var d = '';
                        if (c.last_date) { try { d = new Date(c.last_date).toLocaleDateString(loc); } catch (_cd) { d = String(c.last_date); } }
                        var qtyC = (typeof formatQtyForDisplay === 'function') ? formatQtyForDisplay(c.qty || 0, matchedProduct) : String(c.qty || 0);
                        return '<div style="padding:6px 0; border-top:1px solid var(--border,#eee);">'
                            + (idx === 0 ? '<span style="color:var(--brand); font-weight:800;">دوماهی · </span>' : '')
                            + '<strong>' + escapeHtml(c.company || '') + '</strong>'
                            + ' · ' + escapeHtml(String(qtyC)) + ' دانە · ' + (c.count || 0) + ' جار'
                            + (c.last_invoice ? (' · پسوول ' + escapeHtml(String(c.last_invoice))) : '')
                            + (d ? (' · ' + escapeHtml(d)) : '')
                            + '</div>';
                    }).join('');
                    sumEl.style.display = 'block';
                    sumEl.innerHTML = '<div style="display:flex; flex-wrap:wrap; gap:12px; align-items:stretch;">'
                        + '<div style="flex:1; min-width:220px; padding:12px 14px; border-radius:10px; background:var(--bg-muted, rgba(0,0,0,0.04));">'
                        + '<div style="display:flex; justify-content:space-between; gap:8px; align-items:flex-start;">'
                        + '<div><strong style="font-size:1.05rem;">' + escapeHtml(matchedProduct.name || '') + '</strong>'
                        + '<div style="margin-top:4px; color:var(--text-muted); font-size:0.85rem;">مەخزەنا ئێستا: <strong style="color:var(--brand);">' + escapeHtml(qtyTxt) + '</strong> · بارکۆد: ' + escapeHtml(matchedProduct.barcode || '-')
                        + (list && list.length ? (' · ' + list.length + ' لڤین') : '') + '</div></div>'
                        + '<button type="button" class="btn btn-sm btn-outline" onclick="clearWmsMovProduct()"><i class="fas fa-times"></i> لادان</button>'
                        + '</div></div>'
                        + '<div style="flex:1.2; min-width:240px; padding:12px 14px; border-radius:10px; background:rgba(37,99,235,0.08); border:1px solid rgba(37,99,235,0.18);">'
                        + '<div style="font-size:0.8rem; color:var(--text-muted); margin-bottom:4px;">ئەگەر عاتل زڤڕی — دوماهی کرین ژ</div>'
                        + (last
                            ? ('<div style="font-size:1.15rem; font-weight:800; color:var(--brand);">' + escapeHtml(last.company || '') + '</div>'
                                + '<div style="margin-top:4px; font-size:0.85rem;">' + (last.invoice ? ('پسوول ' + escapeHtml(String(last.invoice)) + ' · ') : '') + escapeHtml(lastDate) + '</div>')
                            : '<div style="color:var(--text-muted);">هیچ کرینەک بۆ ڤی ئایتمی نەهاتیە دیتن</div>')
                        + (companyRows ? ('<div style="margin-top:10px; font-size:0.85rem;"><div style="font-weight:700; margin-bottom:4px;">هەمی کۆمپانیێن ڤی ئایتمی</div>' + companyRows + '</div>') : '')
                        + '</div></div>';
                } else {
                    sumEl.style.display = list && list.length ? 'block' : 'none';
                    if (list && list.length) {
                        sumEl.innerHTML = '<div style="padding:10px 12px; border-radius:8px; background:var(--bg-muted, rgba(0,0,0,0.04)); font-size:0.92rem;">' + list.length + ' لڤین — ئایتمێک هەلبژێرە بۆ بینینی کۆمپانیا کرینێ</div>';
                    }
                }
            }
            if (!list || !list.length) {
                tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; color:var(--text-muted);">هیچ جووڵەیەک نییە</td></tr>';
                syncWmsItemLedger(matchedProduct);
                return;
            }
            tbody.innerHTML = list.map(function(m){
                var q = parseFloat(m.quantity) || 0;
                var qStr = formatWmsMovQty(m);
                var qColor = q > 0 || wmsQtyIsIn(m) ? 'var(--success)' : 'var(--danger)';
                var dateStr = '-';
                if (m.date) {
                    try {
                        var d = new Date(m.date);
                        dateStr = d.toLocaleDateString(loc) + ' ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                    } catch (_e2) { dateStr = String(m.date); }
                }
                var company = String(m.company || '').trim();
                var noteBits = [];
                if (m.supplier_invoice) noteBits.push('پسوول ' + m.supplier_invoice);
                if (m.note) noteBits.push(m.note);
                if (m.user) noteBits.push(m.user);
                if (m.unit_cost && (typeof formatCurrency === 'function')) noteBits.push(formatCurrency(m.unit_cost));
                return '<tr><td style="direction:ltr; text-align:center; white-space:nowrap;">' + escapeHtml(dateStr) + '</td>'
                    + '<td>' + escapeHtml(m.product_name || '') + '</td>'
                    + '<td>' + escapeHtml(wmsMovementTypeLabels[m.movement_type] || m.movement_type || '') + '</td>'
                    + '<td style="font-weight:700; color:var(--brand);">' + escapeHtml(company || '—') + '</td>'
                    + '<td style="font-weight:800; text-align:center; color:' + qColor + ';">' + escapeHtml(qStr) + '</td>'
                    + '<td>' + escapeHtml(noteBits.join(' · ')) + '</td></tr>';
            }).join('');
            syncWmsItemLedger(matchedProduct);
        }
        function setWmsMovTab(tab) {
            wmsMovTab = tab || 'all';
            document.querySelectorAll('#view-warehouse-movements .wms-mov-tab').forEach(function(b){ b.classList.remove('active'); });
            var el = document.getElementById('wms-mov-tab-' + wmsMovTabId(wmsMovTab));
            if (el) el.classList.add('active');
            renderWmsMovements();
        }
        function scheduleWmsMovements() {
            var qEl = document.getElementById('wms-mov-item-search');
            var q = qEl ? String(qEl.value || '').trim() : '';
            if (wmsMovSelectedPid && q !== wmsMovSelectedName) {
                wmsMovSelectedPid = 0;
                wmsMovSelectedName = '';
            }
            paintWmsMovSuggestions(q);
            if (wmsMovSearchTimer) clearTimeout(wmsMovSearchTimer);
            wmsMovSearchTimer = setTimeout(function(){ renderWmsMovements(); }, 280);
        }
        function renderWmsMovements() {
            var tbody = document.getElementById('wms-movements-tbody');
            if (!tbody) return;
            var wrap = document.getElementById('view-warehouse-movements');
            if (wrap) {
                wrap.querySelectorAll('.wms-mov-tab').forEach(function(b){ b.classList.remove('active'); });
                var tabEl = document.getElementById('wms-mov-tab-' + wmsMovTabId(wmsMovTab));
                if (tabEl) tabEl.classList.add('active');
            }
            var startEl = document.getElementById('wms-mov-date-start');
            var endEl = document.getElementById('wms-mov-date-end');
            var qEl = document.getElementById('wms-mov-item-search');
            var q = qEl ? String(qEl.value || '').trim() : '';
            var url = '?action=get_warehouse_movement_log&t=' + Date.now()
                + '&kind=' + encodeURIComponent(wmsMovKind())
                + '&limit=800';
            if (startEl && startEl.value) url += '&date_from=' + encodeURIComponent(startEl.value);
            if (endEl && endEl.value) url += '&date_to=' + encodeURIComponent(endEl.value);
            if (wmsMovSelectedPid > 0) url += '&product_id=' + encodeURIComponent(String(wmsMovSelectedPid));
            else if (q) url += '&q=' + encodeURIComponent(q);
            var seq = ++wmsMovFetchSeq;
            tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:24px; color:var(--text-muted);"><i class="fas fa-spinner fa-spin" style="margin-left:8px;"></i> بارکردن...</td></tr>';
            fetch(url, { credentials: 'same-origin' }).then(function(r){ return r.json(); }).then(function(data){
                if (seq !== wmsMovFetchSeq) return;
                if (!data || data.status !== 'ok') {
                    tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; color:var(--danger);">هەڵە د بارکرنێ دا. دووبارە هەول بدە.</td></tr>';
                    return;
                }
                wmsMovementsCache = data.movements || [];
                paintWmsMovementRows(tbody, wmsMovementsCache, data.matched_product || null, data.purchase_sources || null);
            }).catch(function(){
                if (seq !== wmsMovFetchSeq) return;
                var list = (db && db.warehouse_movements) ? db.warehouse_movements.slice() : [];
                if (startEl && startEl.value) list = list.filter(function(m){ var d = m.date ? new Date(m.date) : null; return d && d >= new Date(startEl.value + 'T00:00:00'); });
                if (endEl && endEl.value) list = list.filter(function(m){ var d = m.date ? new Date(m.date) : null; return d && d <= new Date(endEl.value + 'T23:59:59'); });
                if (wmsMovSelectedPid > 0) list = list.filter(function(m){ return Number(m.product_id) === Number(wmsMovSelectedPid); });
                else if (q) {
                    var ql = q.toLowerCase();
                    list = list.filter(function(m){
                        return String(m.product_name || '').toLowerCase().indexOf(ql) !== -1
                            || String(m.barcode || '').toLowerCase().indexOf(ql) !== -1
                            || String(m.product_id || '') === q;
                    });
                }
                var kind = wmsMovKind();
                if (kind === 'waste') list = list.filter(function(m){ return m.movement_type === 'waste'; });
                else if (kind === 'in') list = list.filter(function(m){ return wmsQtyIsIn(m) && m.movement_type !== 'waste'; });
                else if (kind === 'out') list = list.filter(function(m){ return !wmsQtyIsIn(m) || m.movement_type === 'waste' || m.movement_type === 'sale' || m.movement_type === 'supplier_return'; });
                wmsMovementsCache = list.slice(0, 800);
                paintWmsMovementRows(tbody, wmsMovementsCache, null);
            });
        }
        window.setWmsMovTab = setWmsMovTab;
        window.scheduleWmsMovements = scheduleWmsMovements;
        window.renderWmsMovements = renderWmsMovements;
        window.pickWmsMovProduct = pickWmsMovProduct;
        window.clearWmsMovProduct = clearWmsMovProduct;
        window.handleWmsMovSearchKey = handleWmsMovSearchKey;
        window.paintWmsMovSuggestions = paintWmsMovSuggestions;
        if (!window._wmsMovSuggestDocBound) {
            window._wmsMovSuggestDocBound = true;
            document.addEventListener('click', function(ev){
                var box = document.getElementById('wms-mov-suggest');
                var wrap = ev.target && ev.target.closest ? ev.target.closest('.wms-mov-search-box') : null;
                if (box && !wrap) wmsMovHideSuggest();
            });
        }
        function loadStockCard() {
            var searchEl = document.getElementById('stock-card-search');
            var productBox = document.getElementById('stock-card-product');
            var tbody = document.getElementById('stock-card-tbody');
            if(!searchEl || !tbody) return;
            var q = (searchEl.value || '').trim();
            if(!q) {
                if(productBox) productBox.style.display = 'none';
                var ledger = document.getElementById('wms-mov-item-ledger');
                if (ledger) ledger.style.display = 'none';
                tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; color:var(--text-muted);">ئایتمێک هەلبژێرە بۆ هویرکاریا هەژمارێ</td></tr>';
                return;
            }
            if(productBox) productBox.style.display = 'none';
            tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:24px; color:var(--text-muted);"><i class="fas fa-spinner fa-spin" style="margin-left:8px;"></i> بارکردن...</td></tr>';
            var url = '?action=get_stock_movements&t=' + Date.now();
            if(/^\d+$/.test(q)) url += '&product_id=' + encodeURIComponent(q);
            else url += '&barcode=' + encodeURIComponent(q);
            fetch(url, { credentials: 'same-origin' }).then(function(r){ return r.json(); }).then(function(data){
                if(data.status !== 'ok') { tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; color:var(--danger);">هەڵە د بارکرنێ دا. دووبارە هەول بدە.</td></tr>'; return; }
                var product = data.product;
                var movements = data.movements || [];
                if(!product) {
                    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; color:var(--text-muted);">ئایتمێک بەم بارکۆد یان ژمارەیە نەدۆزرایەوە.</td></tr>';
                    return;
                }
                var nameEl = document.getElementById('stock-card-product-name');
                var metaEl = document.getElementById('stock-card-product-meta');
                var summaryEl = document.getElementById('stock-card-summary');
                if(nameEl) nameEl.textContent = product.name || '-';
                if(metaEl) metaEl.textContent = 'ID: ' + product.id + ' | بارکۆد: ' + (product.barcode || '-') + ' | پۆل: ' + (product.category || product.cat || '-') + ' | مەخزەنا ئێستا: ' + (product.qty || 0);
                var localProd = (db.products || []).find(function(x){ return x && x.id == product.id; });
                var unitFactors = (typeof getProductUnitFactors === 'function') ? getProductUnitFactors(localProd) : { piecesPerPack: 1, piecesPerCarton: 1 };
                function piecesToUnitCounts(pieces) {
                    var absPieces = Math.max(0, Math.floor(parseFloat(pieces) || 0));
                    var carton = 0;
                    var pack = 0;
                    var piece = absPieces;
                    if (unitFactors.piecesPerCarton && unitFactors.piecesPerCarton > 1) {
                        carton = Math.floor(piece / unitFactors.piecesPerCarton);
                        piece = piece - (carton * unitFactors.piecesPerCarton);
                    }
                    if (unitFactors.piecesPerPack && unitFactors.piecesPerPack > 1) {
                        pack = Math.floor(piece / unitFactors.piecesPerPack);
                        piece = piece - (pack * unitFactors.piecesPerPack);
                    }
                    return { carton: carton, pack: pack, piece: piece };
                }
                var purchased = 0, sold = 0, returned = 0, wasted = 0;
                var purchasedByUnit = { carton: 0, pack: 0, piece: 0 };
                var soldByUnit = { carton: 0, pack: 0, piece: 0 };
                var returnedByUnit = { carton: 0, pack: 0, piece: 0 };
                var supplierReturnedByUnit = { carton: 0, pack: 0, piece: 0 };
                var wasteByUnit = { carton: 0, pack: 0, piece: 0 };
                var saleCount = 0, returnCount = 0;
                var staffSet = {};
                movements.forEach(function(m){
                    if(m.movement_type === 'purchase') {
                        purchased += m.quantity;
                        var bc = piecesToUnitCounts(m.quantity);
                        purchasedByUnit.carton += bc.carton;
                        purchasedByUnit.pack += bc.pack;
                        purchasedByUnit.piece += bc.piece;
                    } else if(m.movement_type === 'sale') {
                        var absQ = Math.abs(m.quantity);
                        sold += absQ;
                        var bc = piecesToUnitCounts(absQ);
                        soldByUnit.carton += bc.carton;
                        soldByUnit.pack += bc.pack;
                        soldByUnit.piece += bc.piece;
                        saleCount++;
                    } else if(m.movement_type === 'customer_return') {
                        returned += m.quantity;
                        var bc = piecesToUnitCounts(m.quantity);
                        returnedByUnit.carton += bc.carton;
                        returnedByUnit.pack += bc.pack;
                        returnedByUnit.piece += bc.piece;
                        returnCount++;
                    } else if(m.movement_type === 'supplier_return') {
                        returned -= m.quantity;
                        var bc = piecesToUnitCounts(m.quantity);
                        supplierReturnedByUnit.carton += bc.carton;
                        supplierReturnedByUnit.pack += bc.pack;
                        supplierReturnedByUnit.piece += bc.piece;
                    } else if(m.movement_type === 'waste') {
                        var absQ = Math.abs(m.quantity);
                        wasted += absQ;
                        var bc = piecesToUnitCounts(absQ);
                        wasteByUnit.carton += bc.carton;
                        wasteByUnit.pack += bc.pack;
                        wasteByUnit.piece += bc.piece;
                    }
                    if(m.user && m.user.trim()) staffSet[m.user.trim()] = true;
                });
                var staffList = Object.keys(staffSet).join('، ') || '—';
                if(summaryEl) summaryEl.innerHTML =
                    '<div style="padding:8px; background:var(--input-bg); border-radius:8px;">' +
                        '<small>کڕین (Purchases)</small><br>' +
                        '<b>+' + purchased + '</b>' +
                        '<div style="margin-top:6px; font-size:0.85rem; color:var(--text-muted); display:flex; flex-direction:column; gap:3px;">' +
                            '<span>' + getProductUnitLabel(localProd, 'carton') + ': <b style="color:var(--text);">' + purchasedByUnit.carton + '</b></span>' +
                            '<span>' + getProductUnitLabel(localProd, 'pack') + ': <b style="color:var(--text);">' + purchasedByUnit.pack + '</b></span>' +
                            '<span>' + getProductUnitLabel(localProd, 'piece') + ': <b style="color:var(--text);">' + purchasedByUnit.piece + '</b></span>' +
                        '</div>' +
                    '</div>' +
                    '<div style="padding:8px; background:var(--input-bg); border-radius:8px;">' +
                        '<small>فرۆتن (Sales)</small><br>' +
                        '<b>-' + sold + '</b>' +
                        '<div style="margin-top:6px; font-size:0.85rem; color:var(--text-muted); display:flex; flex-direction:column; gap:3px;">' +
                            '<span>' + getProductUnitLabel(localProd, 'carton') + ': <b style="color:var(--text);">' + soldByUnit.carton + '</b></span>' +
                            '<span>' + getProductUnitLabel(localProd, 'pack') + ': <b style="color:var(--text);">' + soldByUnit.pack + '</b></span>' +
                            '<span>' + getProductUnitLabel(localProd, 'piece') + ': <b style="color:var(--text);">' + soldByUnit.piece + '</b></span>' +
                        '</div>' +
                    '</div>' +
                    '<div style="padding:8px; background:var(--input-bg); border-radius:8px;">' +
                        '<small>زڤڕاندن (Returns)</small><br>' +
                        '<b>' + returned + '</b>' +
                        '<div style="margin-top:6px; font-size:0.85rem; color:var(--text-muted); display:flex; flex-direction:column; gap:6px;">' +
                            '<div><span style="color:var(--text-muted);">کریار:</span> ' +
                                '<b style="color:var(--text);">' + getProductUnitLabel(localProd, 'carton') + ' ' + returnedByUnit.carton + ', ' + getProductUnitLabel(localProd, 'pack') + ' ' + returnedByUnit.pack + ', ' + getProductUnitLabel(localProd, 'piece') + ' ' + returnedByUnit.piece + '</b>' +
                            '</div>' +
                            '<div><span style="color:var(--text-muted);">دابینکەر:</span> ' +
                                '<b style="color:var(--text);">' + getProductUnitLabel(localProd, 'carton') + ' ' + supplierReturnedByUnit.carton + ', ' + getProductUnitLabel(localProd, 'pack') + ' ' + supplierReturnedByUnit.pack + ', ' + getProductUnitLabel(localProd, 'piece') + ' ' + supplierReturnedByUnit.piece + '</b>' +
                            '</div>' +
                        '</div>' +
                    '</div>' +
                    '<div style="padding:8px; background:var(--input-bg); border-radius:8px;">' +
                        '<small>تەلەف (Waste)</small><br>' +
                        '<b>-' + wasted + '</b>' +
                        '<div style="margin-top:6px; font-size:0.85rem; color:var(--text-muted); display:flex; flex-direction:column; gap:3px;">' +
                            '<span>' + getProductUnitLabel(localProd, 'carton') + ': <b style="color:var(--text);">' + wasteByUnit.carton + '</b></span>' +
                            '<span>' + getProductUnitLabel(localProd, 'pack') + ': <b style="color:var(--text);">' + wasteByUnit.pack + '</b></span>' +
                            '<span>' + getProductUnitLabel(localProd, 'piece') + ': <b style="color:var(--text);">' + wasteByUnit.piece + '</b></span>' +
                        '</div>' +
                    '</div>' +
                    '<div style="grid-column:1/-1; padding:10px; margin-top:8px; background:var(--card); border:1px solid var(--border); border-radius:8px; font-size:0.9rem;"><strong>سوڕا ژیانا ئایتمی (Item Lifecycle):</strong> ژمارا فرۆتنێ: ' + saleCount + '، ژمارا زڤڕاندنێ: ' + returnCount + '؛ کارمەندێن کار پێ کری: ' + staffList + '</div>';
                if(productBox) productBox.style.display = 'block';
                var typeLabels = { sale: 'فرۆتن', customer_return: 'زڤڕاندن کریار', purchase: 'کڕین', supplier_return: 'زڤڕاندن دابینکەر', waste: 'تەلەف', stocktake: 'جەرد', adjustment: 'دەستکاری' };
                tbody.innerHTML = movements.length ? movements.map(function(m){
                    var q = m.quantity || 0;
                    var qStr = (m.movement_type === 'purchase' || m.movement_type === 'customer_return' || ((m.movement_type === 'stocktake' || m.movement_type === 'adjustment') && q > 0)) ? '+' + q : String(q);
                    return '<tr><td>' + (m.date ? new Date(m.date).toLocaleString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ') : '-') + '</td><td>' + (typeLabels[m.movement_type] || m.movement_type) + '</td><td>' + qStr + '</td><td>' + formatCurrency(m.unit_cost || 0) + (m.total_value ? ' / ' + formatCurrency(m.total_value) : '') + '</td><td>' + (m.reference_type || '') + ' #' + (m.reference_id || '') + '</td><td>' + escapeHtml(m.user || '') + '</td></tr>';
                }).join('') : '<tr><td colspan="6" style="text-align:center; color:var(--text-muted);">هیچ لڤینێک تۆمارنەکراوە</td></tr>';
            }).catch(function(){
                if(tbody) tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; color:var(--danger);">هەڵە د پەیوەندیێ دا. ئینتەرنێتێ بپشکنە و دووبارە هەول بدە.</td></tr>';
            });
        }
        function renderWmsSuppliers() {
            var tbody = document.getElementById('wms-suppliers-tbody');
            if(!tbody || !db) return;
            var companies = db.companies || [];
            var supplies = db.supplies || [];
            tbody.innerHTML = companies.length ? companies.map(function(c){
                var purchaseCount = supplies.filter(function(s){ return s.company === c.name; }).length;
                return '<tr><td><b>' + escapeHtml(c.name) + '</b></td><td>' + escapeHtml(c.phone || '-') + '</td><td>' + formatCurrency(c.balance || 0, (typeof fxUsdRateFormatOptsForEntityBalance === 'function') ? fxUsdRateFormatOptsForEntityBalance(c.id, 'company', c.balance) : undefined) + '</td><td>' + purchaseCount + '</td><td><button type="button" class="btn btn-sm btn-info" onclick="nav(\'companies\'); openCompanyProfile(' + c.id + ')">مێژوو</button></td></tr>';
            }).join('') : '<tr><td colspan="5" style="text-align:center; color:var(--text-muted);">هیچ دابینکەرێک تۆمارنەکراوە.</td></tr>';
        }
        function renderWmsReports() {
            if(!db) return;
            var nativeVal = (typeof sumInventoryValuationNative === 'function')
                ? sumInventoryValuationNative(db.products || [])
                : { cost: 0 };
            var totalVal = nativeVal.cost || 0;
            var vEl = document.getElementById('wms-report-value');
            if(vEl) vEl.innerText = (typeof formatActiveCurrencyAmount === 'function') ? formatActiveCurrencyAmount(totalVal) : formatCurrency(totalVal);
            var movs = db.warehouse_movements || [];
            var inCount = movs.filter(function(m){ var q = m.quantity || 0; return m.movement_type === 'purchase' || m.movement_type === 'customer_return' || ((m.movement_type === 'stocktake' || m.movement_type === 'adjustment') && q > 0); }).length;
            var icEl = document.getElementById('wms-report-inbound-count');
            if(icEl) icEl.innerText = inCount;
            var wcEl = document.getElementById('wms-report-waste-count');
            if(wcEl) wcEl.innerText = movs.filter(function(m){ return m.movement_type === 'waste'; }).length;
            var logTbody = document.getElementById('wms-report-log-tbody');
            if(logTbody) {
                var typeLabels = wmsMovementTypeLabels || { purchase: 'کڕین', customer_return: 'زڤڕاندن کریار', sale: 'فرۆتن', supplier_return: 'زڤڕاندن دابینکەر', waste: 'تەلەف', stocktake: 'جەرد', adjustment: 'دەستکاری' };
                var entries = movs.slice(0, 150).map(function(m){
                    var typ = typeLabels[m.movement_type] || m.movement_type;
                    return '<tr><td>' + (m.date ? new Date(m.date).toLocaleString('ar-IQ') : '-') + '</td><td>' + typ + '</td><td>' + escapeHtml(m.product_name || '') + '</td><td>' + (m.quantity || 0) + '</td><td>' + escapeHtml((m.note || '') + ' ' + (m.user || '')) + '</td></tr>';
                });
                logTbody.innerHTML = entries.length ? entries.join('') : '<tr><td colspan="5">هیچ جووڵەیەک نییە</td></tr>';
            }
        }

        function renderWarehouseCategories() {
            if(!db) return;
            var products = db.products || [];
            var cats = [...new Set((db.categories || []).concat(products.map(function(p){ return p.cat || p.category || ''; }).filter(Boolean)))].filter(Boolean).sort();
            var sel = document.getElementById('wh-cat-filter');
            if(sel) {
                sel.innerHTML = '<option value="">هەمی ئایتم (All)</option>' + cats.map(function(c){ return '<option value="' + escapeHtml(c) + '">' + escapeHtml(c) + '</option>'; }).join('');
            }
            var sumEl = document.getElementById('wh-cat-summary');
            if(sumEl) sumEl.innerText = cats.length + ' پۆل، کۆی ' + products.length + ' ئایتم';
            renderWarehouseByCategory();
        }
        function renderWarehouseByCategory() {
            if(!db) return;
            var products = db.products || [];
            var catVal = (document.getElementById('wh-cat-filter') && document.getElementById('wh-cat-filter').value) || '';
            var list = catVal ? products.filter(function(p){ return (p.cat || p.category || '') === catVal; }) : products;
            var titleEl = document.getElementById('wh-cat-list-title');
            var tbody = document.getElementById('wh-cat-list-body');
            if(titleEl) titleEl.innerText = catVal ? 'ئایتمەکان بەپێی پۆلی «' + catVal + '» (' + list.length + ')' : 'هەمی ئایتم (' + list.length + ')';
            if(!tbody) return;
            tbody.innerHTML = list.length ? list.map(function(p){
                var status = !p.trackStock ? 'خزمەتگوزاری'
                    : ((parseFloat(p.qty) || 0) <= 0
                        ? ((typeof t === 'function') ? t('wh_status_stockout') : 'نەما')
                        : (p.qty <= getMinStock(p) ? 'کێمبووی' : 'باشە'));
                var qtyDisplay = p.trackStock ? (formatQtyForDisplay((p.qty || 0), p) + ' ' + getProductUnitLabel(p, 'piece')) : '∞';
                return '<tr><td><b>' + escapeHtml(p.name || 'ئایتم') + '</b></td><td>' + escapeHtml(p.cat || p.category || '-') + '</td><td>' + qtyDisplay + '</td><td>' + status + '</td></tr>';
            }).join('') : '<tr><td colspan="4" style="text-align:center; color:var(--text-muted);">هیچ ئایتمێک نییە بۆ ئەم پۆلە.</td></tr>';
        }

        function getWarehousePrinters() {
            try {
                if (db && db.settings && Array.isArray(db.settings.warehouse_printers)) return db.settings.warehouse_printers;
                var fromStorage = JSON.parse(localStorage.getItem('pos_warehouse_printers') || '[]');
                if (db && db.settings) db.settings.warehouse_printers = fromStorage;
                return fromStorage;
            } catch(e) { return []; }
        }
        function setWarehousePrinters(arr) {
            try {
                localStorage.setItem('pos_warehouse_printers', JSON.stringify(arr));
                if (db && db.settings) db.settings.warehouse_printers = arr;
            } catch(e) {}
        }
        function renderWarehousePrinters() {
            var list = document.getElementById('wh-printers-list');
            if(!list) return;
            var printers = getWarehousePrinters();
            list.innerHTML = printers.length ? printers.map(function(name, i){
                return '<li style="display:flex; align-items:center; justify-content:space-between; padding:10px 12px; background:var(--input-bg); border-radius:8px; margin-bottom:8px;"><span><i class="fas fa-print" style="margin-left:8px;"></i>' + escapeHtml(name) + '</span><button type="button" class="btn btn-sm btn-danger" onclick="removeWarehousePrinter(' + i + ')"><i class="fas fa-trash"></i></button></li>';
            }).join('') : '<li style="color:var(--text-muted); padding:8px 0;">هێشتا پرینتەر تۆمارنەکراوە.</li>';
        }
        function addWarehousePrinter() {
            var inp = document.getElementById('wh-printer-name');
            if(!inp || !inp.value.trim()) return alert('ناڤێ پرێنتەری بنڤێسە.');
            var arr = getWarehousePrinters();
            arr.push(inp.value.trim());
            setWarehousePrinters(arr);
            inp.value = '';
            renderWarehousePrinters();
            if (typeof fillLabelPrinterSelect === 'function') {
                try {
                    var lp = (db && db.settings && db.settings.labelPrint) ? db.settings.labelPrint : {};
                    fillLabelPrinterSelect(lp.printerName || '', lp.printerId || '');
                } catch (eFill) { fillLabelPrinterSelect(); }
            }
        }
        function removeWarehousePrinter(index) {
            var arr = getWarehousePrinters();
            arr.splice(index, 1);
            setWarehousePrinters(arr);
            renderWarehousePrinters();
            if (typeof fillLabelPrinterSelect === 'function') {
                try {
                    var lp2 = (db && db.settings && db.settings.labelPrint) ? db.settings.labelPrint : {};
                    fillLabelPrinterSelect(lp2.printerName || '', lp2.printerId || '');
                } catch (eFill2) { fillLabelPrinterSelect(); }
            }
        }

