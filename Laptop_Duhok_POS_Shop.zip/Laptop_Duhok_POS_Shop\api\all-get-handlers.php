<?php
// GET: version, login data, revenue, get_data bootstrap
// --- API HANDLERS ---
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_app_version') {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    echo json_encode(['status' => 'success', 'version' => POS_APP_VERSION]);
    exit;
}

/**
 * Large-shop search: customers / companies / staff — paginated, indexed SQL (not full client list).
 * GET ?action=search_entities&type=customers|companies|users&q=&limit=50&offset=0
 */
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'search_entities') {
    error_reporting(0);
    ini_set('display_errors', 0);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: private, max-age=8');
    if (empty($_SESSION['user_id'])) {
        echo json_encode(['status' => 'auth_required', 'message' => 'Login required'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }
    $type = isset($_GET['type']) ? trim((string)$_GET['type']) : 'customers';
    $q = isset($_GET['q']) ? trim((string)$_GET['q']) : '';
    $limit = (int)($_GET['limit'] ?? 50);
    if ($limit < 10) $limit = 10;
    if ($limit > 120) $limit = 120;
    $offset = max(0, (int)($_GET['offset'] ?? 0));
    $fetchN = $limit + 1;

    $table = 'customers';
    $cols = 'id, name, phone, balance, address, debt_limit, opening_balance, is_active';
    if ($type === 'companies') {
        $table = 'companies';
        $cols = 'id, name, phone, balance, address, debt_limit, opening_balance, is_active';
    } elseif ($type === 'users') {
        $table = 'users';
        $cols = 'id, name, balance, is_active';
    }

    $sql = "SELECT {$cols} FROM {$table} WHERE (is_active IS NULL OR is_active != 0)";
    $params = [];
    $types = '';
    if ($q !== '') {
        $like = '%' . $q . '%';
        if ($type === 'users') {
            $sql .= ' AND (name LIKE ? OR CAST(id AS CHAR) LIKE ?)';
            $params[] = $like;
            $params[] = $like;
            $types .= 'ss';
        } else {
            $sql .= ' AND (name LIKE ? OR phone LIKE ? OR CAST(id AS CHAR) LIKE ?)';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
            $types .= 'sss';
        }
    }
    $sql .= ' ORDER BY balance DESC, name ASC LIMIT ? OFFSET ?';
    $params[] = $fetchN;
    $params[] = $offset;
    $types .= 'ii';

    $rows = [];
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        if ($types !== '') {
            $stmt->bind_param($types, ...$params);
        }
        if ($stmt->execute()) {
            $res = $stmt->get_result();
            if ($res) {
                while ($r = $res->fetch_assoc()) {
                    $r['id'] = (int)$r['id'];
                    $r['balance'] = roundMoney($r['balance'] ?? 0);
                    if (isset($r['debt_limit'])) $r['debt_limit'] = roundMoney($r['debt_limit'] ?? 0);
                    if (isset($r['opening_balance'])) $r['opening_balance'] = roundMoney($r['opening_balance'] ?? 0);
                    $rows[] = $r;
                }
            }
        }
    }

    $hasMore = count($rows) > $limit;
    if ($hasMore) array_pop($rows);

    $total = 0;
    $resTc = @$conn->query("SELECT COUNT(*) AS c FROM {$table}");
    if ($resTc && ($rowTc = $resTc->fetch_assoc())) {
        $total = (int)($rowTc['c'] ?? 0);
    }

    echo json_encode([
        'status' => 'ok',
        'type' => $type,
        'q' => $q,
        'rows' => $rows,
        'has_more' => $hasMore,
        'offset' => $offset,
        'limit' => $limit,
        'total' => $total,
    ], JSON_UNESCAPED_UNICODE);
    exit();
}
/** Admin: pull $50 feature purchases from Supabase into local MySQL (e.g. code redeemed in owner-admin). */
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'repair_feature_entitlements') {
    header('Content-Type: application/json; charset=utf-8');
    pos_session_require_login_json();
    if (!pos_session_is_admin()) {
        pos_json_perm_denied();
    }
    if (!function_exists('pos_subscription_repair_feature_entitlements')) {
        echo json_encode(['status' => 'error', 'message' => 'Repair not available'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $repair = pos_subscription_repair_feature_entitlements($conn);
    if (empty($repair['ok'])) {
        $reason = isset($repair['reason']) ? (string)$repair['reason'] : 'remote_failed';
        $msgs = [
            'remote_failed' => 'پەیوەندی بە سێرڤەرەوە سەرکەوتوو نەبوو — ئینتەرنێت بپشکنە.',
            'no_serial' => 'ژمارەی دامەزراندن نەدۆزرایەوە.',
        ];
        echo json_encode([
            'status' => 'error',
            'reason' => $reason,
            'message' => $msgs[$reason] ?? 'هاوبەشکردن سەرکەوتوو نەبوو.',
            'entitlements' => $repair['entitlements'] ?? null,
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    echo json_encode([
        'status' => 'success',
        'message' => 'کڕینەکانی تایبەتمەندی هاتنە هاوکاتکردن.',
        'subscription_entitlements' => $repair['entitlements'] ?? null,
        'settings' => $repair['settings'] ?? null,
        'saved' => !empty($repair['saved']),
    ], JSON_UNESCAPED_UNICODE);
    exit();
}
// Public: Login screen needs user list (id, name, role only - no PINs)
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] == 'get_stock_movements') {

    header('Content-Type: application/json; charset=utf-8');
    pos_session_require_login_json();
    $canStock = pos_session_has_perm('stock_view') || pos_session_has_perm('stock_audit') || pos_session_has_perm('warehouse_view')
        || pos_session_has_perm('products_manage') || pos_session_is_privileged();
    if (!$canStock) pos_json_perm_denied();
    $product_id = isset($_GET['product_id']) ? (int)$_GET['product_id'] : 0;
    $barcode = isset($_GET['barcode']) ? trim($_GET['barcode']) : '';
    if ($barcode !== '') {
        $st = $conn->prepare("SELECT id FROM products WHERE barcode = ? LIMIT 1");
        $st->bind_param("s", $barcode);
        $st->execute();
        $rr = $st->get_result();
        if ($rr && $row = $rr->fetch_assoc()) $product_id = (int)$row['id'];
    }
    $product = null;
    $movements = [];
    if ($product_id > 0) {
        $stProd = $conn->prepare("SELECT id, name, barcode, price, cost, qty, category FROM products WHERE id = ? LIMIT 1");
        $stProd->bind_param("i", $product_id);
        $stProd->execute();
        $res = $stProd->get_result();
        if ($res && $r = $res->fetch_assoc()) {
            $r['id'] = (int)$r['id']; $r['qty'] = (float)$r['qty']; $r['price'] = (float)$r['price']; $r['cost'] = (float)$r['cost'];
            $product = $r;
        }
        $stmt = $conn->prepare("SELECT id, product_id, barcode, movement_type, quantity, unit_cost, total_value, reference_type, reference_id, date, user, note FROM stock_movements WHERE product_id = ? ORDER BY date DESC LIMIT 500");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($r = $res->fetch_assoc()) {
            $r['id'] = (int)$r['id']; $r['product_id'] = (int)$r['product_id']; $r['quantity'] = (float)$r['quantity'];
            $r['unit_cost'] = (float)$r['unit_cost']; $r['total_value'] = (float)$r['total_value']; $r['reference_id'] = (int)$r['reference_id'];
            $movements[] = $r;
        }
    }
    if (!pos_session_can_view_cost()) {
        if ($product && isset($product['cost'])) $product['cost'] = 0.0;
        foreach ($movements as &$m) {
            $m['unit_cost'] = 0.0;
            $m['total_value'] = 0.0;
        }
        unset($m);
    }
    echo json_encode(['status' => 'ok', 'product' => $product, 'movements' => $movements]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_warehouse_movement_log') {
    header('Content-Type: application/json; charset=utf-8');
    pos_session_require_login_json();
    $canStock = pos_session_has_perm('stock_view') || pos_session_has_perm('stock_audit') || pos_session_has_perm('warehouse_view')
        || pos_session_has_perm('products_manage') || pos_session_is_privileged();
    if (!$canStock) pos_json_perm_denied();

    $dateFrom = isset($_GET['date_from']) ? trim((string)$_GET['date_from']) : '';
    $dateTo = isset($_GET['date_to']) ? trim((string)$_GET['date_to']) : '';
    $q = isset($_GET['q']) ? trim((string)$_GET['q']) : '';
    $productId = isset($_GET['product_id']) ? (int)$_GET['product_id'] : 0;
    $kind = isset($_GET['kind']) ? strtolower(trim((string)$_GET['kind'])) : 'all';
    if (!in_array($kind, ['all', 'in', 'out', 'waste'], true)) $kind = 'all';
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 800;
    if ($limit < 50) $limit = 50;
    if ($limit > 2000) $limit = 2000;

    $sql = "SELECT m.id, m.product_id, m.barcode, m.movement_type, m.quantity, m.unit_cost, m.total_value,"
        . " m.reference_type, m.reference_id, m.date, m.user, m.note, m.warehouse_id, m.to_warehouse_id,"
        . " p.name AS product_name, p.qty AS product_qty, p.barcode AS product_barcode"
        . " FROM stock_movements m LEFT JOIN products p ON p.id = m.product_id WHERE 1=1";
    $types = '';
    $params = [];

    if ($dateFrom !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateFrom)) {
        $sql .= " AND m.date >= ?";
        $types .= 's';
        $params[] = $dateFrom . ' 00:00:00';
    }
    if ($dateTo !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateTo)) {
        $sql .= " AND m.date <= ?";
        $types .= 's';
        $params[] = $dateTo . ' 23:59:59';
    }
    if ($productId > 0) {
        $sql .= " AND m.product_id = ?";
        $types .= 'i';
        $params[] = $productId;
    } elseif ($q !== '') {
        $like = '%' . $q . '%';
        if (preg_match('/^\d+$/', $q)) {
            $sql .= " AND (m.product_id = ? OR m.barcode LIKE ? OR p.barcode LIKE ? OR p.name LIKE ?)";
            $types .= 'isss';
            $params[] = (int)$q;
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        } else {
            $sql .= " AND (m.barcode LIKE ? OR p.barcode LIKE ? OR p.name LIKE ?)";
            $types .= 'sss';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }
    }
    if ($kind === 'waste') {
        $sql .= " AND m.movement_type = 'waste'";
    } elseif ($kind === 'in') {
        $sql .= " AND ("
            . "m.movement_type IN ('purchase','customer_return','transfer_in','purchase_edit','purchase_restore','sale_void_restore','recipe_produce')"
            . " OR (m.movement_type IN ('stocktake','adjustment','sale_edit') AND m.quantity > 0)"
            . ")";
    } elseif ($kind === 'out') {
        $sql .= " AND ("
            . "m.movement_type IN ('sale','supplier_return','transfer_out','sale_edit','sale_void_wh','purchase_deletion','sale_restore_void','recipe_consume')"
            . " OR (m.movement_type IN ('stocktake','adjustment','purchase_edit') AND m.quantity < 0)"
            . ")";
    }
    $sql .= " ORDER BY m.date DESC, m.id DESC LIMIT " . (int)$limit;

    $movements = [];
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        if ($types !== '') {
            $stmt->bind_param($types, ...$params);
        }
        if ($stmt->execute()) {
            $res = $stmt->get_result();
            if ($res) {
                while ($r = $res->fetch_assoc()) {
                    $r['id'] = (int)$r['id'];
                    $r['product_id'] = (int)$r['product_id'];
                    $r['quantity'] = (float)$r['quantity'];
                    $r['unit_cost'] = roundMoney($r['unit_cost'] ?? 0);
                    $r['total_value'] = roundMoney($r['total_value'] ?? 0);
                    $r['reference_id'] = (int)$r['reference_id'];
                    $r['warehouse_id'] = (int)($r['warehouse_id'] ?? 1);
                    $r['to_warehouse_id'] = isset($r['to_warehouse_id']) && $r['to_warehouse_id'] !== null ? (int)$r['to_warehouse_id'] : null;
                    $r['product_qty'] = isset($r['product_qty']) ? (float)$r['product_qty'] : 0;
                    $r['company'] = '';
                    $r['supplier_invoice'] = '';
                    $movements[] = $r;
                }
            }
        }
    }

    $supplyIds = [];
    foreach ($movements as $mRow) {
        $rid = (int)($mRow['reference_id'] ?? 0);
        $rt = strtolower((string)($mRow['reference_type'] ?? ''));
        $mt = (string)($mRow['movement_type'] ?? '');
        if ($rid > 0 && ($rt === 'supply' || $rt === 'delete_supply' || in_array($mt, ['purchase', 'purchase_edit', 'purchase_restore', 'purchase_deletion'], true))) {
            $supplyIds[$rid] = 1;
        }
    }
    $supplyById = [];
    if ($supplyIds) {
        $inIds = implode(',', array_map('intval', array_keys($supplyIds)));
        $resSupMap = @$conn->query("SELECT id, company, transaction_id, supplier_invoice_number, prodId FROM supplies WHERE id IN ($inIds)");
        if ($resSupMap) {
            while ($sRow = $resSupMap->fetch_assoc()) {
                $supplyById[(int)$sRow['id']] = $sRow;
            }
        }
    }
    foreach ($movements as &$mAtt) {
        $company = '';
        $inv = '';
        $sid = (int)($mAtt['reference_id'] ?? 0);
        if ($sid > 0 && isset($supplyById[$sid])) {
            $company = trim((string)($supplyById[$sid]['company'] ?? ''));
            $inv = trim((string)($supplyById[$sid]['supplier_invoice_number'] ?? ''));
            if ($inv === '') $inv = trim((string)($supplyById[$sid]['transaction_id'] ?? ''));
        }
        if ($company === '' && ($mAtt['movement_type'] ?? '') === 'supplier_return') {
            $company = trim((string)($mAtt['note'] ?? ''));
        }
        $mAtt['company'] = $company;
        $mAtt['supplier_invoice'] = $inv;
    }
    unset($mAtt);

    $matchedProduct = null;
    $purchaseSources = [];
    $pidGuess = $productId > 0 ? $productId : 0;
    if ($pidGuess <= 0 && $q !== '') {
        if (preg_match('/^\d+$/', $q)) $pidGuess = (int)$q;
        if ($pidGuess <= 0 && $movements) $pidGuess = (int)($movements[0]['product_id'] ?? 0);
        if ($pidGuess <= 0) {
            $stFind = $conn->prepare("SELECT id FROM products WHERE barcode = ? OR name LIKE ? LIMIT 1");
            if ($stFind) {
                $likeExact = '%' . $q . '%';
                $stFind->bind_param('ss', $q, $likeExact);
                if ($stFind->execute()) {
                    $rf = $stFind->get_result();
                    if ($rf && ($rowF = $rf->fetch_assoc())) $pidGuess = (int)$rowF['id'];
                }
            }
        }
    }
    if ($pidGuess > 0) {
        $stProd = $conn->prepare("SELECT id, name, barcode, qty, category FROM products WHERE id = ? LIMIT 1");
        if ($stProd) {
            $stProd->bind_param('i', $pidGuess);
            if ($stProd->execute()) {
                $rp = $stProd->get_result();
                if ($rp && ($pr = $rp->fetch_assoc())) {
                    $matchedProduct = [
                        'id' => (int)$pr['id'],
                        'name' => $pr['name'],
                        'barcode' => $pr['barcode'],
                        'qty' => (float)$pr['qty'],
                        'category' => $pr['category'] ?? '',
                    ];
                }
            }
        }
        $stSrc = $conn->prepare("SELECT company, date, qtyAdded, transaction_id, supplier_invoice_number FROM supplies WHERE prodId = ? AND qtyAdded > 0 AND (type IS NULL OR type <> 'return') ORDER BY date DESC, id DESC LIMIT 200");
        if ($stSrc) {
            $stSrc->bind_param('i', $pidGuess);
            if ($stSrc->execute()) {
                $rsSrc = $stSrc->get_result();
                $grouped = [];
                $lastSrc = null;
                if ($rsSrc) {
                    while ($src = $rsSrc->fetch_assoc()) {
                        $cname = trim((string)($src['company'] ?? ''));
                        if ($cname === '') $cname = 'دابینکەرێ نەناسراو';
                        $invSrc = trim((string)($src['supplier_invoice_number'] ?? ''));
                        if ($invSrc === '') $invSrc = trim((string)($src['transaction_id'] ?? ''));
                        if ($lastSrc === null) {
                            $lastSrc = [
                                'company' => $cname,
                                'date' => $src['date'],
                                'invoice' => $invSrc,
                                'qty' => (float)$src['qtyAdded'],
                            ];
                        }
                        if (!isset($grouped[$cname])) {
                            $grouped[$cname] = [
                                'company' => $cname,
                                'last_date' => $src['date'],
                                'last_invoice' => $invSrc,
                                'qty' => 0.0,
                                'count' => 0,
                            ];
                        }
                        $grouped[$cname]['qty'] += (float)$src['qtyAdded'];
                        $grouped[$cname]['count']++;
                    }
                }
                $purchaseSources = [
                    'last' => $lastSrc,
                    'companies' => array_values($grouped),
                ];
                if ($matchedProduct) {
                    $matchedProduct['last_company'] = $lastSrc ? $lastSrc['company'] : '';
                    $matchedProduct['last_purchase_date'] = $lastSrc ? $lastSrc['date'] : '';
                    $matchedProduct['last_invoice'] = $lastSrc ? $lastSrc['invoice'] : '';
                }
            }
        }
    }

    if (!pos_session_can_view_cost()) {
        foreach ($movements as &$mHide) {
            $mHide['unit_cost'] = 0.0;
            $mHide['total_value'] = 0.0;
        }
        unset($mHide);
    }

    echo json_encode([
        'status' => 'ok',
        'movements' => $movements,
        'matched_product' => $matchedProduct,
        'purchase_sources' => $purchaseSources,
        'count' => count($movements),
        'kind' => $kind,
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_stocktake_history') {
    header('Content-Type: application/json; charset=utf-8');
    pos_session_require_login_json();
    $canStock = pos_session_has_perm('stock_view') || pos_session_has_perm('stock_audit') || pos_session_has_perm('warehouse_view')
        || pos_session_has_perm('products_manage') || pos_session_is_privileged();
    if (!$canStock) pos_json_perm_denied();
    if (function_exists('pos_ensure_stocktake_history_schema')) pos_ensure_stocktake_history_schema($conn);
    $hideCost = function_exists('pos_session_can_view_cost') && !pos_session_can_view_cost();
    $sessions = [];
    $res = @$conn->query("SELECT id, period, warehouse_id, date, user, note, items_changed, items_short, items_surplus, items_ok, short_qty, surplus_qty, short_value, surplus_value, net_value FROM stocktake_sessions ORDER BY date DESC, id DESC LIMIT 24");
    if ($res) {
        while ($r = $res->fetch_assoc()) {
            $r['id'] = (int)$r['id'];
            $r['warehouse_id'] = (int)$r['warehouse_id'];
            $r['items_changed'] = (int)$r['items_changed'];
            $r['items_short'] = (int)$r['items_short'];
            $r['items_surplus'] = (int)$r['items_surplus'];
            $r['items_ok'] = (int)$r['items_ok'];
            $r['short_qty'] = (float)$r['short_qty'];
            $r['surplus_qty'] = (float)$r['surplus_qty'];
            $r['short_value'] = $hideCost ? 0.0 : (float)$r['short_value'];
            $r['surplus_value'] = $hideCost ? 0.0 : (float)$r['surplus_value'];
            $r['net_value'] = $hideCost ? 0.0 : (float)$r['net_value'];
            $sessions[] = $r;
        }
    }
    echo json_encode(['status' => 'ok', 'sessions' => $sessions], JSON_UNESCAPED_UNICODE);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_stocktake_session') {
    header('Content-Type: application/json; charset=utf-8');
    pos_session_require_login_json();
    $canStock = pos_session_has_perm('stock_view') || pos_session_has_perm('stock_audit') || pos_session_has_perm('warehouse_view')
        || pos_session_has_perm('products_manage') || pos_session_is_privileged();
    if (!$canStock) pos_json_perm_denied();
    $sid = (int)($_GET['id'] ?? 0);
    if ($sid <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'جەرد نەهاتیە دیتن'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $hideCost = function_exists('pos_session_can_view_cost') && !pos_session_can_view_cost();
    $session = null;
    $st = $conn->prepare("SELECT id, period, warehouse_id, date, user, note, items_changed, items_short, items_surplus, items_ok, short_qty, surplus_qty, short_value, surplus_value, net_value FROM stocktake_sessions WHERE id = ? LIMIT 1");
    if ($st) {
        $st->bind_param('i', $sid);
        if ($st->execute()) {
            $rs = $st->get_result();
            if ($rs && ($r = $rs->fetch_assoc())) {
                $r['id'] = (int)$r['id'];
                $r['warehouse_id'] = (int)$r['warehouse_id'];
                $r['items_changed'] = (int)$r['items_changed'];
                $r['items_short'] = (int)$r['items_short'];
                $r['items_surplus'] = (int)$r['items_surplus'];
                $r['items_ok'] = (int)$r['items_ok'];
                $r['short_qty'] = (float)$r['short_qty'];
                $r['surplus_qty'] = (float)$r['surplus_qty'];
                $r['short_value'] = $hideCost ? 0.0 : (float)$r['short_value'];
                $r['surplus_value'] = $hideCost ? 0.0 : (float)$r['surplus_value'];
                $r['net_value'] = $hideCost ? 0.0 : (float)$r['net_value'];
                $session = $r;
            }
        }
    }
    $lines = [];
    if ($session) {
        $stL = $conn->prepare("SELECT product_id, product_name, system_qty, actual_qty, variance, unit_cost, value FROM stocktake_lines WHERE session_id = ? ORDER BY variance ASC, product_name ASC");
        if ($stL) {
            $stL->bind_param('i', $sid);
            if ($stL->execute()) {
                $rl = $stL->get_result();
                while ($rl && ($ln = $rl->fetch_assoc())) {
                    $ln['product_id'] = (int)$ln['product_id'];
                    $ln['system_qty'] = (float)$ln['system_qty'];
                    $ln['actual_qty'] = (float)$ln['actual_qty'];
                    $ln['variance'] = (float)$ln['variance'];
                    $ln['unit_cost'] = $hideCost ? 0.0 : (float)$ln['unit_cost'];
                    $ln['value'] = $hideCost ? 0.0 : (float)$ln['value'];
                    $lines[] = $ln;
                }
            }
        }
    }
    echo json_encode(['status' => $session ? 'ok' : 'error', 'session' => $session, 'lines' => $lines], JSON_UNESCAPED_UNICODE);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_stock_transfer_history') {
    header('Content-Type: application/json; charset=utf-8');
    pos_session_require_login_json();
    if (!pos_multi_warehouse_pro_enabled($conn)) {
        echo json_encode(['status' => 'error', 'message' => 'کۆگای فرە چالاک نییە'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    if (!pos_session_can_use_multi_warehouse($conn) && !pos_session_has_perm('warehouse_view')) {
        pos_json_perm_denied();
        exit();
    }
    $payload = pos_fetch_stock_transfer_history($conn, [
        'date_from' => $_GET['date_from'] ?? '',
        'date_to' => $_GET['date_to'] ?? '',
        'warehouse_id' => $_GET['warehouse_id'] ?? 0,
        'limit' => $_GET['limit'] ?? 300,
    ]);
    echo json_encode(array_merge(['status' => 'success'], $payload), JSON_UNESCAPED_UNICODE);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_stock_transfer_detail') {
    header('Content-Type: application/json; charset=utf-8');
    pos_session_require_login_json();
    if (!pos_multi_warehouse_pro_enabled($conn)) {
        echo json_encode(['status' => 'error', 'message' => 'کۆگای فرە چالاک نییە'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    if (!pos_session_can_use_multi_warehouse($conn) && !pos_session_has_perm('warehouse_view')) {
        pos_json_perm_denied();
        exit();
    }
    $id = (int)($_GET['id'] ?? 0);
    $detail = pos_fetch_stock_transfer_detail($conn, $id);
    if (!$detail) {
        echo json_encode(['status' => 'error', 'message' => 'گواستنەوە نەدۆزرایەوە'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    echo json_encode(['status' => 'success', 'transfer' => $detail], JSON_UNESCAPED_UNICODE);
    exit();
}

// --- Revenue Comparison Dashboard: multi-period (A,B,C,D,E,F) with optional block alignment ---
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] == 'get_revenue_comparison') {

    header('Content-Type: application/json; charset=utf-8');
    pos_session_require_login_json();
    if (!pos_session_can_reports()) pos_json_perm_denied();
    $periods = [];
    for ($i = 0; $i <= 5; $i++) {
        $s = isset($_GET["period{$i}_start"]) ? trim($_GET["period{$i}_start"]) : '';
        $e = isset($_GET["period{$i}_end"]) ? trim($_GET["period{$i}_end"]) : '';
        if ($s !== '' && $e !== '') $periods[] = [$s . ' 00:00:00', $e . ' 23:59:59'];
    }
    if (count($periods) < 2) {
        $startA = isset($_GET['startA']) ? trim($_GET['startA']) : '';
        $endA = isset($_GET['endA']) ? trim($_GET['endA']) : '';
        $startB = isset($_GET['startB']) ? trim($_GET['startB']) : '';
        $endB = isset($_GET['endB']) ? trim($_GET['endB']) : '';
        if ($startA && $endA && $startB && $endB) {
            $periods = [[$startA . ' 00:00:00', $endA . ' 23:59:59'], [$startB . ' 00:00:00', $endB . ' 23:59:59']];
        }
    }
    $granularity = isset($_GET['granularity']) ? trim($_GET['granularity']) : 'day';
    $blockDays = isset($_GET['block_days']) ? (int)$_GET['block_days'] : 0;
    if (!in_array($granularity, ['day', 'month', 'year'])) $granularity = 'day';
    if (count($periods) < 1) {
        echo json_encode(['status' => 'error', 'message' => 'Missing date range']);
        exit();
    }
    $aggByDate = function($conn, $start, $end, $granularity) {
        // Prefer stamped total_usd for USD shops; IQD total always. Period bounds should already be business-day windows from caller.
        $sql = "SELECT DATE(created_at) as dt, COALESCE(SUM(total), 0) as rev, COALESCE(SUM(total_usd), 0) as rev_usd
                FROM sales WHERE created_at >= ? AND created_at <= ? AND (is_returned IS NULL OR is_returned = 0)
                GROUP BY DATE(created_at) ORDER BY dt";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            $stmt = $conn->prepare("SELECT DATE(created_at) as dt, COALESCE(SUM(total), 0) as rev FROM sales WHERE created_at >= ? AND created_at <= ? AND (is_returned IS NULL OR is_returned = 0) GROUP BY DATE(created_at) ORDER BY dt");
        }
        if (!$stmt) return ['points' => [], 'total' => 0, 'labels' => [], 'byDate' => [], 'points_usd' => [], 'total_usd' => 0];
        $stmt->bind_param("ss", $start, $end);
        $stmt->execute();
        $res = $stmt->get_result();
        $byDay = [];
        $byDayUsd = [];
        $total = 0;
        $totalUsd = 0;
        $useUsd = function_exists('pos_is_usd_currency_system') && pos_is_usd_currency_system($conn);
        while ($row = $res->fetch_assoc()) {
            $dt = $row['dt'];
            $rev = (float)$row['rev'];
            $revUsd = isset($row['rev_usd']) ? (float)$row['rev_usd'] : 0.0;
            $total += $rev;
            $totalUsd += $revUsd;
            $key = $dt;
            if ($granularity === 'month') {
                $key = substr($dt, 0, 7);
            } elseif ($granularity === 'year') {
                $key = substr($dt, 0, 4);
            }
            if (!isset($byDay[$key])) {
                $byDay[$key] = 0;
                $byDayUsd[$key] = 0;
            }
            $byDay[$key] += $rev;
            $byDayUsd[$key] += $revUsd;
        }
        $labels = array_keys($byDay);
        sort($labels);
        $points = array_map(function($l) use ($byDay) { return $byDay[$l]; }, $labels);
        $pointsUsd = array_map(function($l) use ($byDayUsd) { return round($byDayUsd[$l] ?? 0, 2); }, $labels);
        return [
            'points' => $useUsd ? $pointsUsd : $points,
            'total' => $useUsd ? round($totalUsd, 2) : $total,
            'labels' => $labels,
            'byDate' => $useUsd ? $byDayUsd : $byDay,
            'points_iqd' => $points,
            'total_iqd' => $total,
            'points_usd' => $pointsUsd,
            'total_usd' => round($totalUsd, 2),
            'metrics_note' => 'stamped_total_usd',
        ];
    };
    $results = [];
    foreach ($periods as $p) {
        $results[] = $aggByDate($conn, $p[0], $p[1], $granularity);
    }
    $allLabels = [];
    $datas = [];
    if ($blockDays > 0 && $granularity === 'day') {
        $allLabels = array_map(function($i) { return 'Day ' . ($i + 1); }, range(0, $blockDays - 1));
        foreach ($results as $r) {
            $byDate = $r['byDate'];
            $sorted = array_keys($byDate);
            sort($sorted);
            $slice = array_slice($sorted, 0, $blockDays);
            $row = array_fill(0, $blockDays, 0.0);
            foreach ($slice as $idx => $dt) {
                if ($idx < $blockDays) $row[$idx] = (float)($byDate[$dt] ?? 0);
            }
            $datas[] = $row;
        }
    } else {
        $labelSet = [];
        foreach ($results as $r) {
            foreach ($r['labels'] as $l) $labelSet[$l] = true;
        }
        if ($granularity === 'day' && count($labelSet) > 31) {
            $n = max(array_map(function($r) { return count($r['points']); }, $results), 1);
            $allLabels = array_map(function($i) { return (string)($i + 1); }, range(0, $n - 1));
            foreach ($results as $r) {
                $datas[] = array_map('floatval', array_pad(array_values($r['points']), $n, 0));
            }
        } else {
            $allLabels = array_values(array_keys($labelSet));
            sort($allLabels);
            foreach ($results as $r) {
                $map = [];
                if (!empty($r['labels']) && !empty($r['points'])) {
                    $lbls = array_values($r['labels']);
                    $pts = array_values($r['points']);
                    $n = min(count($lbls), count($pts));
                    for ($ki = 0; $ki < $n; $ki++) {
                        $map[(string)$lbls[$ki]] = (float)$pts[$ki];
                    }
                }
                $datas[] = array_map(function($l) use ($map) { return isset($map[$l]) ? (float)$map[$l] : 0; }, $allLabels);
            }
        }
    }
    $totals = array_map(function($r) { return (float)$r['total']; }, $results);
    $out = ['status' => 'ok', 'labels' => $allLabels, 'totals' => $totals];
    foreach ($datas as $i => $d) {
        $out['data' . $i] = $d;
    }
    echo json_encode($out, JSON_UNESCAPED_UNICODE);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] == 'get_login_data') {

    header('Content-Type: application/json; charset=utf-8');
    $users = [];
    $res = $conn->query("SELECT id, name, role, hourlyRate FROM users WHERE (is_active IS NULL OR is_active = 1) ORDER BY name ASC");
    if($res) while($r=$res->fetch_assoc()) { $r['id']=(int)$r['id']; $r['hourlyRate']=(float)($r['hourlyRate']??0); $users[]=$r; }
    $settings = [];
    $sres = $conn->query("SELECT setting_value FROM settings WHERE setting_key = 'app_settings'");
    if($sres && $srow=$sres->fetch_assoc()) {
        $dec = json_decode($srow['setting_value'], true);
        if ($dec) {
            $settings = function_exists('pos_ai_sanitize_settings_for_client')
                ? pos_ai_sanitize_settings_for_client($dec)
                : $dec;
        }
    }
    
    // Inject the cloud fail-open setting into the app settings object
    if (function_exists('pos_db_get_setting_value')) {
        $settings['pos_license_force_unlocked_local'] = (pos_db_get_setting_value($conn, 'pos_license_force_unlocked_local') === '1');
        if (function_exists('pos_hydrate_client_settings_currency')) {
            pos_hydrate_client_settings_currency($settings, $conn);
        } else {
            $defCur = pos_db_get_setting_value($conn, 'default_currency');
            $defCur = is_string($defCur) ? strtoupper(trim($defCur)) : '';
            if ($defCur === 'USD' || $defCur === 'IQD') {
                $settings['defaultCurrency'] = $defCur;
                $settings['default_currency'] = $defCur;
                if (empty($settings['currencyMode'])) {
                    $settings['currencyMode'] = $defCur;
                }
            } elseif (empty($settings['defaultCurrency']) && !empty($settings['currencyMode'])) {
                $modeHyd = strtoupper((string)$settings['currencyMode']) === 'USD' ? 'USD' : 'IQD';
                $settings['defaultCurrency'] = $modeHyd;
                $settings['default_currency'] = $modeHyd;
            }
        }
    }
    echo json_encode(['status'=>'ok', 'users'=>$users, 'settings'=>$settings]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_exchange_rate_history') {

    header('Content-Type: application/json; charset=utf-8');
    if (empty($_SESSION['user_id'])) {
        echo json_encode(['status' => 'auth_required', 'message' => 'Login required'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    if (!pos_session_is_admin() && !pos_session_has_perm('set_exchange_rate') && !pos_session_has_perm('reports_view')) {
        pos_json_perm_denied();
    }
    $lim = isset($_GET['limit']) ? (int)$_GET['limit'] : 50;
    if ($lim < 1) {
        $lim = 1;
    }
    if ($lim > 200) {
        $lim = 200;
    }
    $rows = [];
    try {
        $chk = $conn->query("SHOW TABLES LIKE 'exchange_rate_history'");
        if ($chk && $chk->num_rows > 0) {
            $sql = 'SELECT id, rate_bundle, created_at, user_name, note FROM exchange_rate_history ORDER BY id DESC LIMIT ' . $lim;
            $res = $conn->query($sql);
            if ($res) {
                while ($r = $res->fetch_assoc()) {
                    $r['id'] = (int)($r['id'] ?? 0);
                    $r['rate_bundle'] = (int)($r['rate_bundle'] ?? 0);
                    $rows[] = $r;
                }
            }
        }
    } catch (Throwable $e) {
        $rows = [];
    }
    echo json_encode(['status' => 'success', 'rows' => $rows], JSON_UNESCAPED_UNICODE);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_audit_logs') {

    header('Content-Type: application/json; charset=utf-8');
    pos_session_require_login_json();
    $auditOk = pos_session_is_admin() || pos_session_has_perm('view_audit_logs');
    if (!$auditOk) {
        echo json_encode(['status' => 'denied', 'logs' => [], 'message' => 'Permission denied'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 150;
    if ($limit < 30) {
        $limit = 30;
    }
    if ($limit > 500) {
        $limit = 500;
    }
    $logs = [];
    $stmt = $conn->prepare("SELECT * FROM audit_logs ORDER BY id DESC LIMIT ?");
    if ($stmt) {
        $stmt->bind_param("i", $limit);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res) {
            while ($r = $res->fetch_assoc()) {
                $logs[] = $r;
            }
        }
        $stmt->close();
    }
    echo json_encode(['status' => 'success', 'logs' => $logs], JSON_UNESCAPED_UNICODE);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_print_log') {

    header('Content-Type: application/json; charset=utf-8');
    pos_session_require_login_json();
    $auditOk = pos_session_is_admin() || pos_session_has_perm('view_audit_logs');
    if (!$auditOk) {
        echo json_encode(['status' => 'denied', 'print_log' => [], 'message' => 'Permission denied'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 120;
    if ($limit < 20) $limit = 20;
    if ($limit > 300) $limit = 300;
    $print_log = [];
    $stmt = $conn->prepare("SELECT id, doc_type, doc_id, action, user, user_id, note, details, ip_address, created_at FROM print_log ORDER BY id DESC LIMIT ?");
    if ($stmt) {
        $stmt->bind_param('i', $limit);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res) {
            while ($r = $res->fetch_assoc()) {
                $print_log[] = $r;
            }
        }
        $stmt->close();
    }
    echo json_encode(['status' => 'success', 'print_log' => $print_log], JSON_UNESCAPED_UNICODE);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_visual_usd_rate_latest') {

    header('Content-Type: application/json; charset=utf-8');
    pos_session_require_login_json();
    $latest = pos_visual_usd_rate_history_latest($conn);
    if ($latest && (int)($latest['rate_bundle'] ?? 0) >= 10000) {
        echo json_encode(['status' => 'success', 'row' => $latest, 'rate_bundle' => (int)$latest['rate_bundle']], JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode(['status' => 'success', 'row' => null, 'rate_bundle' => 0], JSON_UNESCAPED_UNICODE);
    }
    exit();
}

/** Map one SQL products row to client JSON (shared by get_data + search_products). */
function pos_map_product_row_for_client(array $r, array $batchQtyByProduct = [], array $batchMinExpiryByProduct = [], bool $useLite = false): array {
    $r['id'] = (int)$r['id'];
    $r['price'] = roundMoney($r['price'] ?? 0);
    $r['cost'] = roundMoney($r['cost'] ?? 0);
    $r['qty'] = (float)$r['qty'];
    $r['trackStock'] = (bool)$r['trackStock'];
    $r['itemsPerCarton'] = isset($r['itemsPerCarton']) ? (int)$r['itemsPerCarton'] : 1;
    $r['takeawayPrice'] = roundMoney($r['takeawayPrice'] ?? 0);
    $r['takeawayPrice_pack'] = roundMoney($r['takeawayPrice_pack'] ?? 0);
    $r['takeawayPrice_carton'] = roundMoney($r['takeawayPrice_carton'] ?? 0);
    $r['expiry'] = normalizeProductCatalogExpiry($r['expiry'] ?? '');
    $r['wholesaleQty'] = (int)($r['wholesaleQty'] ?? 0);
    $r['wholesalePrice'] = roundMoney($r['wholesalePrice'] ?? 0);
    $r['cat'] = $r['category'];
    $r['isPinned'] = (bool)($r['isPinned'] ?? 0);
    $r['item_type'] = isset($r['item_type']) && $r['item_type'] === 'perishable' ? 'perishable' : 'constant';
    $r['pieces_per_pack'] = max(1, (int)($r['pieces_per_pack'] ?? 1));
    $r['packs_per_carton'] = max(1, (int)($r['packs_per_carton'] ?? 1));
    $r['pieces_per_carton'] = $r['pieces_per_pack'] * $r['packs_per_carton'];
    $r['barcode_pack'] = isset($r['barcode_pack']) ? trim((string)$r['barcode_pack']) : '';
    $r['barcode_carton'] = isset($r['barcode_carton']) ? trim((string)$r['barcode_carton']) : '';
    $r['price_pack'] = (isset($r['price_pack']) && $r['price_pack'] !== '' && $r['price_pack'] !== null) ? roundMoney($r['price_pack']) : null;
    $r['price_carton'] = (isset($r['price_carton']) && $r['price_carton'] !== '' && $r['price_carton'] !== null) ? roundMoney($r['price_carton']) : null;
    $r['cost_pack'] = (isset($r['cost_pack']) && $r['cost_pack'] !== '' && $r['cost_pack'] !== null) ? roundMoney($r['cost_pack']) : null;
    $r['cost_carton'] = (isset($r['cost_carton']) && $r['cost_carton'] !== '' && $r['cost_carton'] !== null) ? roundMoney($r['cost_carton']) : null;
    $r['forSale'] = !isset($r['forSale']) || (int)$r['forSale'] !== 0;
    $r['note'] = isset($r['note']) ? trim((string)$r['note']) : '';
    static $shopCurCached = null;
    if ($shopCurCached === null) {
        $shopCurCached = 'IQD';
        if (function_exists('pos_shop_default_currency_from_settings_row')) {
            global $conn;
            if (isset($conn) && $conn instanceof mysqli) {
                $shopCurCached = pos_shop_default_currency_from_settings_row($conn);
            }
        } elseif (function_exists('pos_settings_currency_mode_from_array') && function_exists('pos_load_app_settings_array')) {
            global $conn;
            if (isset($conn) && $conn) {
                $shopCurCached = pos_settings_currency_mode_from_array(pos_load_app_settings_array($conn));
            }
        }
        $shopCurCached = (strtoupper((string)$shopCurCached) === 'USD') ? 'USD' : 'IQD';
    }
    $shopCur = $shopCurCached;
    $bc = strtoupper(trim((string)($r['base_currency'] ?? '')));
    if ($bc !== 'USD' && $bc !== 'IQD') {
        $bc = strtoupper(trim((string)($r['currency'] ?? '')));
    }
    $r['base_currency'] = ($bc === 'USD' || $bc === 'IQD') ? $bc : $shopCur;
    $r['currency'] = $r['base_currency'];
    if (array_key_exists('cost_price', $r) && $r['cost_price'] !== null && $r['cost_price'] !== '' && (float)$r['cost_price'] > 0) {
        $r['cost_price'] = roundMoney($r['cost_price']);
    } else {
        $r['cost_price'] = $r['cost'];
    }
    $mappedBasePrice = (isset($r['base_price']) && $r['base_price'] !== null && $r['base_price'] !== '') ? (float)$r['base_price'] : 0.0;
    $r['base_price'] = ($mappedBasePrice > 0) ? $mappedBasePrice : (float)($r['price'] ?? 0);
    $mappedBaseCost = (isset($r['base_cost']) && $r['base_cost'] !== null && $r['base_cost'] !== '') ? (float)$r['base_cost'] : 0.0;
    $r['base_cost'] = ($mappedBaseCost > 0) ? $mappedBaseCost : (float)($r['cost'] ?? 0);
    foreach (['price_usd', 'cost_usd', 'price_pack_usd', 'price_carton_usd', 'cost_pack_usd', 'cost_carton_usd'] as $usdCol) {
        if (array_key_exists($usdCol, $r) && $r[$usdCol] !== null && $r[$usdCol] !== '') {
            $r[$usdCol] = (float)$r[$usdCol];
        }
    }
    $usp = (int)($r['unit_show_pack'] ?? 0);
    $usc = (int)($r['unit_show_carton'] ?? 0);
    if ($usp === 1) {
        $hasPackData = ($r['barcode_pack'] !== '')
            || ($r['price_pack'] !== null && (float)$r['price_pack'] > 0)
            || ($r['cost_pack'] !== null && (float)$r['cost_pack'] > 0);
        if (!$hasPackData && (int)($r['pieces_per_pack'] ?? 1) <= 1) {
            $usp = 0;
        }
    }
    if ($usc === 1) {
        $hasCartonData = ($r['barcode_carton'] !== '')
            || ($r['price_carton'] !== null && (float)$r['price_carton'] > 0)
            || ($r['cost_carton'] !== null && (float)$r['cost_carton'] > 0);
        if (!$hasCartonData && (int)($r['packs_per_carton'] ?? 1) <= 1) {
            $usc = 0;
        }
    }
    $r['unit_show_pack'] = $usp;
    $r['unit_show_carton'] = $usc;
    $r['qty_mode'] = isset($r['qty_mode']) ? strtolower(trim((string)$r['qty_mode'])) : '';
    if ($r['qty_mode'] !== 'piece' && $r['qty_mode'] !== 'kilo') {
        $legacyUnit = strtolower(trim((string)($r['unitType'] ?? '')));
        $r['qty_mode'] = (($r['unit_show_pack'] === 0 && $r['unit_show_carton'] === 0) || $legacyUnit === 'kilo') ? 'kilo' : 'piece';
    }
    $r['recipe_sale_mode'] = function_exists('pos_normalize_recipe_sale_mode')
        ? pos_normalize_recipe_sale_mode($r['recipe_sale_mode'] ?? 'auto')
        : 'auto';
    $r['metal_type'] = isset($r['metal_type']) ? strtolower(trim((string)$r['metal_type'])) : '';
    if ($r['metal_type'] !== 'gold' && $r['metal_type'] !== 'silver') $r['metal_type'] = '';
    $karatRaw = isset($r['karat']) ? (float)$r['karat'] : 0;
    // Gold karat (18/21/22/24) OR silver grade code (925/999/…)
    if ($karatRaw > 0 && ($r['metal_type'] === 'gold' || $r['metal_type'] === 'silver')) {
        $r['karat'] = $karatRaw;
    } else {
        $r['karat'] = null;
    }
    $r['weight_grams'] = isset($r['weight_grams']) ? round((float)$r['weight_grams'], 3) : 0;
    if ($r['weight_grams'] < 0) $r['weight_grams'] = 0;
    $r['making_charge'] = roundMoney($r['making_charge'] ?? 0);
    $jpm = isset($r['jewelry_price_mode']) ? strtolower(trim((string)$r['jewelry_price_mode'])) : 'fixed';
    $r['jewelry_price_mode'] = ($jpm === 'by_weight' && $r['metal_type'] !== '') ? 'by_weight' : 'fixed';
    $r['is_jewelry_set'] = !empty($r['is_jewelry_set']) && (int)$r['is_jewelry_set'] === 1;
    $r['jewelry_set_items'] = [];
    $r['unit_name_piece'] = isset($r['unit_name_piece']) ? trim((string)$r['unit_name_piece']) : '';
    $r['unit_name_pack'] = isset($r['unit_name_pack']) ? trim((string)$r['unit_name_pack']) : '';
    $r['unit_name_carton'] = isset($r['unit_name_carton']) ? trim((string)$r['unit_name_carton']) : '';
    $pid = $r['id'];
    if (isset($batchQtyByProduct[$pid])) {
        $r['batch_qty_sum'] = $batchQtyByProduct[$pid];
    }
    if (isset($batchMinExpiryByProduct[$pid])) {
        $r['batch_min_expiry'] = $batchMinExpiryByProduct[$pid];
        if (!empty($r['trackStock'])) {
            $r['expiry'] = $batchMinExpiryByProduct[$pid];
        }
    }
    if ($useLite) {
        $r = pos_trim_product_row_lite_bootstrap($r);
    }
    return $r;
}

/** Load batch qty/expiry maps for a set of product ids (or all when empty). */
function pos_load_batch_maps_for_products(mysqli $conn, array $productIds = []): array {
    $batchQtyByProduct = [];
    $batchMinExpiryByProduct = [];
    try {
        $sql = "SELECT product_id, SUM(qty) AS sq, MIN(expiry_date) AS mn_exp FROM stock_batches WHERE qty > 0.000001";
        $params = [];
        $types = '';
        if ($productIds) {
            $productIds = array_values(array_unique(array_map('intval', $productIds)));
            $productIds = array_filter($productIds, function ($id) { return $id > 0; });
            if ($productIds) {
                $placeholders = implode(',', array_fill(0, count($productIds), '?'));
                $sql .= " AND product_id IN ($placeholders)";
                $types = str_repeat('i', count($productIds));
                $params = $productIds;
            }
        }
        $sql .= ' GROUP BY product_id';
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            if ($types !== '') {
                $stmt->bind_param($types, ...$params);
            }
            if ($stmt->execute()) {
                $rb = $stmt->get_result();
                if ($rb) {
                    while ($br = $rb->fetch_assoc()) {
                        $pidB = (int)$br['product_id'];
                        $batchQtyByProduct[$pidB] = (float)$br['sq'];
                        $mn = isset($br['mn_exp']) ? (string)$br['mn_exp'] : '';
                        if ($mn !== '' && isValidYmdDate($mn)) {
                            $batchMinExpiryByProduct[$pidB] = $mn;
                        }
                    }
                }
            }
        }
    } catch (Throwable $e) { /* table may not exist */ }
    return [$batchQtyByProduct, $batchMinExpiryByProduct];
}

/** SQL WHERE fragment: exact barcode / SKU / id match (piece comma-list, pack, carton). */
function pos_product_barcode_where_sql(string $code, array &$params, string &$types): string {
    $code = trim($code);
    $params = [$code, $code, $code, $code, $code, $code, $code, $code];
    $types = 'ssssssss';
    return '(CAST(id AS CHAR) = ? OR sku = ? OR barcode = ? OR barcode_pack = ? OR barcode_carton = ?'
        . ' OR barcode LIKE CONCAT(?, \',%\') OR barcode LIKE CONCAT(\'%,\', ?) OR barcode LIKE CONCAT(\'%,\', ?, \',%\'))';
}

/** Lightweight product columns for list/search JSON (fallback to SELECT * if a shop is missing a col). */
function pos_products_list_select_expr(): string {
    return 'id, name, barcode, sku, price, cost, qty, trackStock, category, supplier, unitType, qty_mode, itemsPerCarton, forSale, isPinned, minStock, expiry, expiry_alert_days, pieces_per_pack, packs_per_carton, barcode_pack, barcode_carton, price_pack, price_carton, cost_pack, cost_carton, unit_show_pack, unit_show_carton, takeawayPrice, takeawayPrice_pack, takeawayPrice_carton, wholesaleQty, wholesalePrice, is_weight, recipe_sale_mode, unit_name_piece, unit_name_pack, unit_name_carton, base_currency, base_price, base_cost, currency, cost_price, price_usd, cost_usd, price_pack_usd, price_carton_usd, cost_pack_usd, cost_carton_usd, is_active, note, item_type, manufacturer, catalog_only, metal_type, karat, weight_grams, making_charge, jewelry_price_mode, is_jewelry_set';
}

function pos_products_stmt_fetch_all(mysqli $conn, string $sql, string $types, array $params): array {
    $rows = [];
    $stmt = $conn->prepare($sql);
    if (!$stmt && strpos($sql, pos_products_list_select_expr()) !== false) {
        $sql = str_replace(pos_products_list_select_expr(), '*', $sql);
        $stmt = $conn->prepare($sql);
    }
    if (!$stmt) {
        return $rows;
    }
    if ($types !== '') {
        $stmt->bind_param($types, ...$params);
    }
    if ($stmt->execute()) {
        $res = $stmt->get_result();
        if ($res) {
            while ($r = $res->fetch_assoc()) {
                $rows[] = $r;
            }
        }
    }
    return $rows;
}

/** Indexed exact barcode first (LIMIT 1), then pack/carton/sku, then comma-list. */
function pos_products_lookup_by_barcode(mysqli $conn, string $barcode, string $activeWhere, int $limit = 12): array {
    $barcode = trim($barcode);
    if ($barcode === '') {
        return [];
    }
    $sel = pos_products_list_select_expr();
    $rows = pos_products_stmt_fetch_all(
        $conn,
        "SELECT {$sel} FROM products WHERE {$activeWhere} AND barcode = ? LIMIT 1",
        's',
        [$barcode]
    );
    if ($rows) {
        return $rows;
    }
    $rows = pos_products_stmt_fetch_all(
        $conn,
        "SELECT {$sel} FROM products WHERE {$activeWhere} AND (sku = ? OR barcode_pack = ? OR barcode_carton = ? OR CAST(id AS CHAR) = ?) LIMIT 4",
        'ssss',
        [$barcode, $barcode, $barcode, $barcode]
    );
    if ($rows) {
        return $rows;
    }
    $bcParams = [];
    $bcTypes = '';
    $bcWhere = pos_product_barcode_where_sql($barcode, $bcParams, $bcTypes);
    $lim = max(1, min(12, $limit));
    return pos_products_stmt_fetch_all(
        $conn,
        "SELECT {$sel} FROM products WHERE {$activeWhere} AND {$bcWhere} ORDER BY isPinned DESC, id DESC LIMIT {$lim}",
        $bcTypes,
        $bcParams
    );
}

/**
 * Large shops: pinned + low stock + newest — not full catalog on first load.
 * GET ?action=search_products&q=&barcode=&limit=50&offset=0
 */
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'search_products') {
    error_reporting(0);
    ini_set('display_errors', 0);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: private, max-age=5');
    if (empty($_SESSION['user_id'])) {
        echo json_encode(['status' => 'auth_required', 'message' => 'Login required'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    checkAndAddCol($conn, 'products', 'sku', "VARCHAR(64) NOT NULL DEFAULT ''");
    checkAndAddCol($conn, 'products', 'tech_specs', 'TEXT NULL');
    $barcode = isset($_GET['barcode']) ? trim((string)$_GET['barcode']) : '';
    $q = isset($_GET['q']) ? trim((string)$_GET['q']) : '';
    $limit = (int)($_GET['limit'] ?? 60);
    if ($limit < 10) $limit = 10;
    if ($limit > 200) $limit = 200;
    $offset = max(0, (int)($_GET['offset'] ?? 0));
    $fetchN = $limit + 1;
    $lite = !empty($_GET['lite_products']);
    $rows = [];
    $sql = '';
    $params = [];
    $types = '';

    $includeInactive = !empty($_GET['include_inactive']);
    $activeWhere = $includeInactive
        ? '1=1'
        : '(is_active IS NULL OR is_active = 1)';

    $beforeId = isset($_GET['before_id']) ? (int)$_GET['before_id'] : 0;
    $useIdCursor = ($barcode === '' && $q === '' && $beforeId > 0);
    $sel = pos_products_list_select_expr();

    if ($barcode !== '') {
        $rows = pos_products_lookup_by_barcode($conn, $barcode, $activeWhere, 12);
    } elseif ($q !== '') {
        $like = '%' . $q . '%';
        $sql = "SELECT {$sel} FROM products WHERE {$activeWhere}"
            . " AND (name LIKE ? OR barcode LIKE ? OR barcode_pack LIKE ? OR barcode_carton LIKE ? OR sku LIKE ? OR CAST(id AS CHAR) LIKE ? OR IFNULL(tech_specs,'') LIKE ?)"
            . " ORDER BY isPinned DESC, name ASC LIMIT ? OFFSET ?";
        $params = [$like, $like, $like, $like, $like, $like, $like, $fetchN, $offset];
        $types = 'sssssssii';
        $rows = pos_products_stmt_fetch_all($conn, $sql, $types, $params);
    } elseif ($useIdCursor) {
        $sql = "SELECT {$sel} FROM products WHERE {$activeWhere} AND id < ?"
            . " ORDER BY id DESC LIMIT ?";
        $rows = pos_products_stmt_fetch_all($conn, $sql, 'ii', [$beforeId, $fetchN]);
    } else {
        $sql = "SELECT {$sel} FROM products WHERE {$activeWhere}"
            . " ORDER BY id DESC LIMIT ? OFFSET ?";
        $rows = pos_products_stmt_fetch_all($conn, $sql, 'ii', [$fetchN, $offset]);
    }

    // Active search empty → also look for voided/inactive SKUs (common pharmacy issue).
    $inactiveRows = [];
    if (!$includeInactive && empty($rows) && ($q !== '' || $barcode !== '')) {
        if ($barcode !== '') {
            $inactiveRows = pos_products_lookup_by_barcode($conn, $barcode, 'is_active = 0', 12);
        } else {
            $like = '%' . $q . '%';
            $sqlIn = "SELECT {$sel} FROM products WHERE is_active = 0"
                . " AND (name LIKE ? OR barcode LIKE ? OR barcode_pack LIKE ? OR barcode_carton LIKE ? OR sku LIKE ? OR CAST(id AS CHAR) LIKE ? OR IFNULL(tech_specs,'') LIKE ?)"
                . " ORDER BY id DESC LIMIT 12";
            $inactiveRows = pos_products_stmt_fetch_all($conn, $sqlIn, 'sssssss', [$like, $like, $like, $like, $like, $like, $like]);
        }
    }

    $hasMore = false;
    if ($barcode === '') {
        $hasMore = count($rows) > $limit;
        if ($hasMore) array_pop($rows);
    }

    $pids = [];
    foreach ($rows as $r) {
        $pids[] = (int)$r['id'];
    }
    foreach ($inactiveRows as $r) {
        $pids[] = (int)$r['id'];
    }
    [$batchQtyByProduct, $batchMinExpiryByProduct] = pos_load_batch_maps_for_products($conn, $pids);
    $out = [];
    foreach ($rows as $r) {
        $mapped = pos_map_product_row_for_client($r, $batchQtyByProduct, $batchMinExpiryByProduct, $lite);
        $mapped['is_active'] = !isset($r['is_active']) || (int)$r['is_active'] !== 0;
        $out[] = $mapped;
    }
    $inactiveOut = [];
    foreach ($inactiveRows as $r) {
        $mapped = pos_map_product_row_for_client($r, $batchQtyByProduct, $batchMinExpiryByProduct, $lite);
        $mapped['is_active'] = false;
        $mapped['_inactive'] = true;
        $inactiveOut[] = $mapped;
    }
    if ($out && function_exists('pos_load_jewelry_set_items_map')) {
        $setIds = [];
        foreach ($out as $pRow) {
            if (!empty($pRow['is_jewelry_set'])) $setIds[] = (int)$pRow['id'];
        }
        if ($setIds) {
            $setMap = pos_load_jewelry_set_items_map($conn, $setIds);
            foreach ($out as &$pRow) {
                $sid = (int)($pRow['id'] ?? 0);
                if ($sid && !empty($setMap[$sid])) {
                    $pRow['jewelry_set_items'] = $setMap[$sid];
                    $pRow['is_jewelry_set'] = true;
                }
            }
            unset($pRow);
        }
    }

    if (!pos_session_can_view_cost()) {
        foreach ($out as &$pRow) {
            $pRow['cost'] = roundMoney(0);
            if (array_key_exists('cost_pack', $pRow)) $pRow['cost_pack'] = null;
            if (array_key_exists('cost_carton', $pRow)) $pRow['cost_carton'] = null;
        }
        unset($pRow);
        foreach ($inactiveOut as &$pRow) {
            $pRow['cost'] = roundMoney(0);
            if (array_key_exists('cost_pack', $pRow)) $pRow['cost_pack'] = null;
            if (array_key_exists('cost_carton', $pRow)) $pRow['cost_carton'] = null;
        }
        unset($pRow);
    }

    $total = 0;
    $resTc = $conn->query("SELECT COUNT(*) AS c FROM products WHERE (is_active IS NULL OR is_active = 1)");
    if ($resTc && ($rowTc = $resTc->fetch_assoc())) {
        $total = (int)($rowTc['c'] ?? 0);
    }

    $matchTotal = count($out);
    if ($barcode !== '') {
        $matchTotal = count($out);
    } elseif ($q !== '') {
        $likeCnt = '%' . $q . '%';
        $cntRows = pos_products_stmt_fetch_all(
            $conn,
            "SELECT COUNT(*) AS c FROM products WHERE {$activeWhere}"
            . " AND (name LIKE ? OR barcode LIKE ? OR barcode_pack LIKE ? OR barcode_carton LIKE ? OR sku LIKE ? OR CAST(id AS CHAR) LIKE ? OR IFNULL(tech_specs,'') LIKE ?)",
            'sssssss',
            [$likeCnt, $likeCnt, $likeCnt, $likeCnt, $likeCnt, $likeCnt, $likeCnt]
        );
        if ($cntRows && isset($cntRows[0]['c'])) {
            $matchTotal = (int)$cntRows[0]['c'];
        }
    } elseif ($useIdCursor || $barcode === '') {
        $matchTotal = $total;
    }

    echo json_encode([
        'status' => 'ok',
        'barcode' => $barcode,
        'q' => $q,
        'rows' => $out,
        'inactive_rows' => $inactiveOut,
        'has_more' => $hasMore,
        'offset' => $offset,
        'limit' => $limit,
        'total' => $total,
        'match_total' => $matchTotal,
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

/**
 * Warehouse KPI counts from SQL — accurate even when client has partial product catalog.
 * GET ?action=warehouse_stats
 */
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'warehouse_stats') {
    error_reporting(0);
    ini_set('display_errors', 0);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: private, max-age=15');
    if (empty($_SESSION['user_id'])) {
        echo json_encode(['status' => 'auth_required'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $active = '(is_active IS NULL OR is_active = 1)';
    $total = 0;
    $out = 0;
    $low = 0;
    $res = $conn->query(
        "SELECT COUNT(*) AS total,"
        . " SUM(CASE WHEN trackStock = 1 AND qty <= 0 THEN 1 ELSE 0 END) AS out_count,"
        . " SUM(CASE WHEN trackStock = 1 AND qty > 0 AND qty <= GREATEST(COALESCE(minStock, 5), 1) THEN 1 ELSE 0 END) AS low_count"
        . " FROM products WHERE {$active}"
    );
    if ($res && ($row = $res->fetch_assoc())) {
        $total = (int)($row['total'] ?? 0);
        $out = (int)($row['out_count'] ?? 0);
        $low = (int)($row['low_count'] ?? 0);
    }
    $exp = 0;
    try {
        $expRes = $conn->query(
            "SELECT COUNT(DISTINCT p.id) AS c FROM products p"
            . " LEFT JOIN (SELECT product_id, MIN(expiry_date) AS mn FROM stock_batches WHERE qty > 0.000001 GROUP BY product_id) sb ON sb.product_id = p.id"
            . " WHERE {$active} AND p.trackStock = 1 AND ("
            . " (sb.mn IS NOT NULL AND sb.mn <> '' AND sb.mn <= DATE_ADD(CURDATE(), INTERVAL 60 DAY) AND sb.mn >= CURDATE())"
            . " OR (p.expiry IS NOT NULL AND p.expiry <> '' AND p.expiry REGEXP '^[0-9]{4}-[0-9]{2}-[0-9]{2}'"
            . " AND p.expiry <= DATE_ADD(CURDATE(), INTERVAL 60 DAY) AND p.expiry >= CURDATE())"
            . " )"
        );
        if ($expRes && ($er = $expRes->fetch_assoc())) {
            $exp = (int)($er['c'] ?? 0);
        }
    } catch (Throwable $eExp) {}
    echo json_encode([
        'status' => 'ok',
        'total' => $total,
        'low' => $low,
        'out' => $out,
        'exp' => $exp,
        'alerts' => $low + $out + $exp,
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

/** Smaller JSON for weak laptops (POS sale + stock only). */
function pos_trim_product_row_lite_bootstrap(array $r) {
    $keep = [
        'id', 'name', 'barcode', 'sku', 'price', 'cost', 'qty', 'batch_qty_sum', 'batch_min_expiry', 'trackStock', 'catalog_only', 'cat', 'category',
        'minStock', 'expiry_alert_days', 'unitType',
        'isPinned', 'forSale', 'is_weight', 'wholesaleQty', 'wholesalePrice',
        'pieces_per_pack', 'packs_per_carton', 'pieces_per_carton', 'itemsPerCarton',
        'barcode_pack', 'barcode_carton', 'price_pack', 'price_carton', 'cost_pack', 'cost_carton',
        'unit_show_pack', 'unit_show_carton', 'qty_mode', 'recipe_sale_mode',
        'unit_name_piece', 'unit_name_pack', 'unit_name_carton',
        'takeawayPrice', 'takeawayPrice_pack', 'takeawayPrice_carton',
        'base_currency', 'base_price', 'base_cost', 'currency', 'cost_price',
        'price_usd', 'cost_usd', 'price_pack_usd', 'price_carton_usd', 'cost_pack_usd', 'cost_carton_usd',
        'metal_type', 'karat', 'weight_grams', 'making_charge', 'jewelry_price_mode', 'is_jewelry_set', 'jewelry_set_items',
    ];
    $out = [];
    foreach ($keep as $k) {
        if (array_key_exists($k, $r)) {
            $out[$k] = $r[$k];
        }
    }
    if (!empty($r['note'])) {
        $out['note'] = $r['note'];
    }
    if (!empty($r['expiry'])) {
        $out['expiry'] = $r['expiry'];
    }
    if (isset($r['item_type']) && $r['item_type'] === 'perishable') {
        $out['item_type'] = 'perishable';
    }
    return $out;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] == 'get_data') {

    error_reporting(0); ini_set('display_errors', 0); // Prevent HTML errors in JSON
    header('Content-Type: application/json; charset=utf-8');
    header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
    header("Pragma: no-cache");
    // Must match SPA: connectToDB() only loads get_login_data when status is auth_required (not 401/error).
    if (empty($_SESSION['user_id'])) {
        echo json_encode(['status' => 'auth_required', 'message' => 'Login required'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    // Unlock session early — long get_data must not block get_sales_history / other GETs
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }
    $fetchMode = 'full';
    if (!empty($_GET['bootstrap'])) $fetchMode = 'bootstrap';
    elseif (!empty($_GET['secondary_extended'])) $fetchMode = 'secondary_extended';
    elseif (!empty($_GET['secondary_heavy'])) $fetchMode = 'secondary_heavy';
    elseif (!empty($_GET['secondary'])) $fetchMode = 'secondary';
    $wantBootstrap = ($fetchMode === 'full' || $fetchMode === 'bootstrap');
    $wantSecondary = ($fetchMode === 'full' || $fetchMode === 'secondary');
    $wantSecondaryHeavy = ($fetchMode === 'full' || $fetchMode === 'secondary_heavy');
    $wantSecondaryExtended = ($fetchMode === 'full' || $fetchMode === 'secondary_extended');
    $liteSecondary = !empty($_GET['lite_secondary']);
    $shopHealth = ['sales_count' => 0, 'products_count' => 0, 'customers_count' => 0, 'companies_count' => 0, 'supplies_count' => 0];
    $serverLargeShop = false;
    // Secondary payloads: skip 5× COUNT(*) (very slow on large shops after Ctrl+Shift+R login)
    $skipShopHealthCounts = in_array($fetchMode, ['secondary', 'secondary_heavy', 'secondary_extended'], true);
    if ($skipShopHealthCounts) {
        $liteSecondary = true;
        $serverLargeShop = true;
    } else {
        // Bootstrap: prefer short-lived cache to avoid recounting every hard refresh
        $healthFromCache = false;
        try {
            if (function_exists('pos_db_get_setting_value')) {
                $hcRaw = pos_db_get_setting_value($conn, 'pos_shop_health_cache_v1');
                if (is_string($hcRaw) && $hcRaw !== '') {
                    $hc = json_decode($hcRaw, true);
                    if (is_array($hc) && isset($hc['ts'], $hc['health']) && (time() - (int)$hc['ts']) < 600 && is_array($hc['health'])) {
                        $shopHealth = array_merge($shopHealth, $hc['health']);
                        $healthFromCache = true;
                    }
                }
            }
        } catch (Throwable $eHc) {}
        if (!$healthFromCache) {
            $resShopHc = $conn->query(
                'SELECT (SELECT COUNT(*) FROM sales) AS sc, '
                . '(SELECT COUNT(*) FROM products WHERE is_active IS NULL OR is_active = 1) AS pc, '
                . '(SELECT COUNT(*) FROM customers WHERE is_active IS NULL OR is_active = 1) AS cc, '
                . '(SELECT COUNT(*) FROM companies WHERE is_active IS NULL OR is_active = 1) AS coc, '
                . '(SELECT COUNT(*) FROM supplies) AS supc'
            );
            if ($resShopHc && ($hrShop = $resShopHc->fetch_assoc())) {
                $shopHealth['sales_count'] = (int)($hrShop['sc'] ?? 0);
                $shopHealth['products_count'] = (int)($hrShop['pc'] ?? 0);
                $shopHealth['customers_count'] = (int)($hrShop['cc'] ?? 0);
                $shopHealth['companies_count'] = (int)($hrShop['coc'] ?? 0);
                $shopHealth['supplies_count'] = (int)($hrShop['supc'] ?? 0);
                try {
                    if (function_exists('pos_db_set_setting_value')) {
                        pos_db_set_setting_value($conn, 'pos_shop_health_cache_v1', json_encode([
                            'ts' => time(),
                            'health' => $shopHealth,
                        ], JSON_UNESCAPED_UNICODE));
                    }
                } catch (Throwable $eSet) {}
            }
        }
        $serverLargeShop = ($shopHealth['products_count'] >= 1000)
            || ($shopHealth['sales_count'] >= 2500)
            || ($shopHealth['customers_count'] >= 350)
            || ($shopHealth['companies_count'] >= 120)
            || ($shopHealth['supplies_count'] >= 1500);
        if ($serverLargeShop) {
            $liteSecondary = true;
        }
    }
    $extOffset = max(0, (int)($_GET['offset'] ?? 0));
    $extLimit = (int)($_GET['limit'] ?? 3000);
    if ($extLimit < 200) $extLimit = 200;
    if ($extLimit > 8000) $extLimit = 8000;
    $extSection = isset($_GET['section']) ? trim((string)$_GET['section']) : 'all';

    $data = ['products'=>[], 'sales'=>[], 'expenses'=>[], 'expenses_deleted'=>[], 'companies'=>[], 'manufacturers'=>[], 'users'=>[], 'tables'=>[], 'settings'=>[], 'supplies'=>[], 'ledger'=>[], 'customers'=>[], 'customer_ledger'=>[], 'installment_plans'=>[], 'installment_items'=>[], 'waste'=>[], 'recipes'=>[], 'shifts'=>[], 'returns'=>[], 'purchase_returns'=>[], 'deliveries'=>[], 'drivers'=>[], 'logs'=>[], 'warehouses'=>[], 'warehouse_stock'=>[], 'stock_transfers'=>[], 'session_user'=>null];
    
    $liteProducts = !empty($_GET['lite_products']);
    $catalogTier = isset($_GET['catalog_tier']) ? strtolower(trim((string)$_GET['catalog_tier'])) : 'weak';
    if (!in_array($catalogTier, ['weak', 'standard', 'full'], true)) {
        $catalogTier = 'weak';
    }
    $batchQtyByProduct = [];
    $batchMinExpiryByProduct = [];
    if ($wantBootstrap) {
        try {
            $rb = $conn->query("SELECT product_id, SUM(qty) AS sq, MIN(expiry_date) AS mn_exp FROM stock_batches WHERE qty > 0.000001 GROUP BY product_id");
            if ($rb) {
                while ($br = $rb->fetch_assoc()) {
                    $pidB = (int)$br['product_id'];
                    $batchQtyByProduct[$pidB] = (float)$br['sq'];
                    $mn = isset($br['mn_exp']) ? (string)$br['mn_exp'] : '';
                    if ($mn !== '' && isValidYmdDate($mn)) {
                        $batchMinExpiryByProduct[$pidB] = $mn;
                    }
                }
            }
        } catch (Throwable $e) { /* table may not exist */ }
    }
    if ($wantBootstrap) {
    if (function_exists('pos_multi_warehouse_pro_enabled')
        && !pos_multi_warehouse_pro_enabled($conn)
        && function_exists('pos_collapse_extra_warehouse_stock_into_default')) {
        pos_collapse_extra_warehouse_stock_into_default($conn);
    }
    if (function_exists('pos_heal_reactivate_inactive_with_stock')) {
        pos_heal_reactivate_inactive_with_stock($conn);
    }
    $bootstrapProductCount = 0;
    $resPc = $conn->query("SELECT COUNT(*) as c FROM products WHERE (is_active IS NULL OR is_active = 1)");
    if ($resPc && ($rowPc = $resPc->fetch_assoc())) {
        $bootstrapProductCount = (int)($rowPc['c'] ?? 0);
    }
    $useLiteProductRows = $liteProducts || ($bootstrapProductCount >= 1000);
    $usePartialCatalog = $serverLargeShop && $fetchMode === 'bootstrap' && $bootstrapProductCount >= 1000 && $catalogTier !== 'full';
    checkAndAddCol($conn, 'products', 'sku', "VARCHAR(64) NOT NULL DEFAULT ''");
    $partialBootstrapLimit = 450;
    if ($catalogTier === 'standard') {
        $partialBootstrapLimit = min(1200, $bootstrapProductCount);
    }
    if ($usePartialCatalog) {
        $selBoot = function_exists('pos_products_list_select_expr') ? pos_products_list_select_expr() : '*';
        $res = $conn->query(
            "SELECT {$selBoot} FROM products WHERE (is_active IS NULL OR is_active = 1)"
            . " ORDER BY isPinned DESC, id DESC LIMIT " . (int)$partialBootstrapLimit
        );
        if (!$res) {
            $res = $conn->query(
                "SELECT * FROM products WHERE (is_active IS NULL OR is_active = 1)"
                . " ORDER BY isPinned DESC, id DESC LIMIT " . (int)$partialBootstrapLimit
            );
        }
    } else {
        $selBoot = function_exists('pos_products_list_select_expr') ? pos_products_list_select_expr() : '*';
        $res = $conn->query("SELECT {$selBoot} FROM products WHERE (is_active IS NULL OR is_active = 1) ORDER BY id DESC");
        if (!$res) {
            $res = $conn->query("SELECT * FROM products WHERE (is_active IS NULL OR is_active = 1) ORDER BY id DESC");
        }
    }
    if($res) while($r=$res->fetch_assoc()) {
        $data['products'][] = pos_map_product_row_for_client($r, $batchQtyByProduct, $batchMinExpiryByProduct, $useLiteProductRows);
    }
    if (!empty($data['products']) && function_exists('pos_load_jewelry_set_items_map')) {
        $setIds = [];
        foreach ($data['products'] as $pRow) {
            if (!empty($pRow['is_jewelry_set'])) $setIds[] = (int)$pRow['id'];
        }
        if ($setIds) {
            $setMap = pos_load_jewelry_set_items_map($conn, $setIds);
            foreach ($data['products'] as &$pRow) {
                $sid = (int)($pRow['id'] ?? 0);
                if ($sid && !empty($setMap[$sid])) {
                    $pRow['jewelry_set_items'] = $setMap[$sid];
                    $pRow['is_jewelry_set'] = true;
                }
            }
            unset($pRow);
        }
    }
    if ($usePartialCatalog) {
        $data['catalog_partial'] = true;
        $data['catalog_total'] = $bootstrapProductCount;
        $data['catalog_loaded'] = count($data['products']);
    }
    $data['catalog_tier'] = $catalogTier;
    }
    
    if ($wantSecondary) {
    // Fetch Sales (Reduced Limit for Performance) — items only for recent days (smaller JSON on weak devices)
    $salesItemDays = ($liteSecondary || $serverLargeShop) ? 1 : 3;
    $salesItemCutoff = date('Y-m-d', strtotime('-' . (int)$salesItemDays . ' days'));
    $salesLimit = ($liteSecondary || $serverLargeShop) ? 150 : 200;
    if (function_exists('pos_ensure_sales_warehouse_column')) {
        pos_ensure_sales_warehouse_column($conn);
    }
    $res = $conn->query("SELECT id, total, discount, items_json, created_at, cashier, payment_method, customer_id, customer_type, is_returned, transaction_id, fx_usd_rate, fx_currency_mode, remaining_debt, debt_amount, payment_due_at, warehouse_id FROM sales ORDER BY id DESC LIMIT " . (int)$salesLimit);
    if($res) while($r=$res->fetch_assoc()) {
        $r['id']=(int)$r['id']; $r['total']=roundMoney($r['total']??0); $r['discount']=roundMoney($r['discount']??0);
        $r['remaining_debt'] = roundMoney($r['remaining_debt'] ?? ($r['debt_amount'] ?? 0));
        $r['debt_amount'] = roundMoney($r['debt_amount'] ?? 0);
        $r['warehouse_id'] = (int)($r['warehouse_id'] ?? 0);
        if (isset($r['payment_due_at']) && $r['payment_due_at'] === '') $r['payment_due_at'] = null;
        $saleDay = isset($r['created_at']) ? substr((string)$r['created_at'], 0, 10) : '';
        if ($saleDay !== '' && $saleDay >= $salesItemCutoff) {
            $r['items'] = json_decode($r['items_json'] ?? '[]');
        } else {
            $r['items'] = [];
        }
        unset($r['items_json']);
        if (!is_array($r['items'])) $r['items'] = [];
        $r['is_returned'] = (int)($r['is_returned'] ?? 0);
        if(isset($r['created_at']) && !isset($r['date'])) $r['date'] = $r['created_at'];
        // Skip N+1 customer name lookups on lite secondary (login speed)
        if (!$liteSecondary && function_exists('pos_attach_sale_customer_field')) {
            pos_attach_sale_customer_field($conn, $r);
        }
        $data['sales'][]=$r;
    }
    if (!empty($data['sales']) && function_exists('pos_attach_sales_warehouse')) {
        pos_attach_sales_warehouse($conn, $data['sales']);
    }
    
    // Fetch Expenses (Reduced Limit)
    $res = $conn->query("SELECT * FROM expenses ORDER BY id DESC LIMIT 200");
    if($res) while($r=$res->fetch_assoc()) { $r['id']=(int)$r['id']; $r['amount']=roundMoney($r['amount']??0); $data['expenses'][]=$r; }

    // Recent supplies on secondary (lite too) so daily summary / KPI can count کڕین before heavy fetch
    // Skip when this same request also runs secondary_heavy (avoids duplicate rows)
    if (empty($wantSecondaryHeavy)) {
        $suppliesLiteLimit = $liteSecondary ? 250 : 400;
        $resSupLite = $conn->query("SELECT * FROM supplies ORDER BY id DESC LIMIT " . (int)$suppliesLiteLimit);
        if ($resSupLite) {
            while ($r = $resSupLite->fetch_assoc()) {
                $r['id'] = (int)$r['id'];
                $r['qtyAdded'] = (float)$r['qtyAdded'];
                $r['totalCost'] = roundMoney($r['totalCost'] ?? 0);
                $r['prodId'] = (int)$r['prodId'];
                $data['supplies'][] = $r;
            }
        }
    }

    if (pos_session_can_manage_expenses()) {
        $resDel = $conn->query("SELECT * FROM expenses_archive WHERE archive_reason = 'deleted' ORDER BY archived_at DESC LIMIT 100");
        if ($resDel) {
            while ($r = $resDel->fetch_assoc()) {
                $r['id'] = (int)$r['id'];
                $r['amount'] = roundMoney($r['amount'] ?? 0);
                $data['expenses_deleted'][] = $r;
            }
        }
    }
    }

    if ($wantBootstrap) {
    $usePartialCompanies = $serverLargeShop && $fetchMode === 'bootstrap' && $shopHealth['companies_count'] >= 120 && $catalogTier !== 'full';
    $companiesLimit = ($catalogTier === 'standard') ? 200 : 80;
    if ($usePartialCompanies) {
        $res = $conn->query(
            "SELECT * FROM companies WHERE (is_active IS NULL OR is_active = 1)"
            . " ORDER BY balance DESC, name ASC LIMIT " . (int)$companiesLimit
        );
    } else {
        $res = $conn->query("SELECT * FROM companies WHERE (is_active IS NULL OR is_active = 1)");
    }
    if($res) while($r=$res->fetch_assoc()) { $r['id']=(int)$r['id']; $r['balance']=roundMoney($r['balance']??0); $data['companies'][]=$r; }
    if ($usePartialCompanies) {
        $data['companies_partial'] = true;
        $data['companies_total'] = $shopHealth['companies_count'];
        $data['companies_loaded'] = count($data['companies']);
    }
    $resMfr = $conn->query("SELECT id, name, phone, note FROM manufacturers WHERE (is_active IS NULL OR is_active = 1) ORDER BY name ASC");
    if ($resMfr) {
        while ($rm = $resMfr->fetch_assoc()) {
            $data['manufacturers'][] = [
                'id' => (int)$rm['id'],
                'name' => trim((string)($rm['name'] ?? '')),
                'phone' => trim((string)($rm['phone'] ?? '')),
                'note' => trim((string)($rm['note'] ?? ''))
            ];
        }
    }
    }

    if ($wantSecondary) {
    // Fetch Ledger
    $res = $conn->query("SELECT * FROM ledger ORDER BY id DESC LIMIT 200");
    if($res) while($r=$res->fetch_assoc()) { $r['id']=(int)$r['id']; $r['companyId']=(int)$r['companyId']; $r['amount']=roundMoney($r['amount']??0); $data['ledger'][]=$r; }
    }

    if ($wantBootstrap) {
    // Fetch Tables (New)
    $res = $conn->query("SELECT * FROM tables");
    if($res->num_rows == 0) {
        // Safety Net: If no tables exist, create defaults immediately
        $conn->query("INSERT INTO tables (name, items_json) VALUES ('Table 1', '[]'), ('Table 2', '[]')");
        $res = $conn->query("SELECT * FROM tables");
    }
    if($res) while($r=$res->fetch_assoc()) { 
        $r['id']=(int)$r['id']; 
        $r['items'] = json_decode($r['items_json'] ?? '[]'); 
        if(!is_array($r['items'])) $r['items'] = []; 
        $r['isTakeaway']=(bool)($r['isTakeaway'] ?? 0);
        $r['has_new_items']=(bool)($r['has_new_items'] ?? 0);
        $data['tables'][]=$r; 
    }

    // Fetch Users (exclude voided)
    $res = $conn->query("SELECT * FROM users WHERE (is_active IS NULL OR is_active = 1)");
    // SECURITY FIX: Do NOT send PIN to frontend
    if($res) while($r=$res->fetch_assoc()) { 
        $r['id']=(int)$r['id']; 
        $r['hourlyRate']=roundMoney($r['hourlyRate']??0); 
        $r['balance']=roundMoney($r['balance']??0); 
        $r['permissions'] = json_decode($r['permissions'] ?? '[]', true); 
        // Allow PIN export for Admin to support Backup/Restore
        if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
            unset($r['pin']); 
        }
        $data['users'][]=$r; 
    }

    // Fetch Shifts
    $shiftLimit = ($fetchMode === 'bootstrap') ? 100 : 1000;
    $res = $conn->query("SELECT * FROM shifts ORDER BY id DESC LIMIT " . (int)$shiftLimit);
    if($res) while($r=$res->fetch_assoc()) { $r['id']=(int)$r['id']; $r['userId']=(int)$r['userId']; $r['hourlyRate']=roundMoney($r['hourlyRate']??0); $data['shifts'][]=$r; }

    // Fetch Customers
    $usePartialCustomers = $serverLargeShop && $fetchMode === 'bootstrap' && $shopHealth['customers_count'] >= 350 && $catalogTier !== 'full';
    $customersLimit = ($catalogTier === 'standard') ? 280 : 100;
    if ($usePartialCustomers) {
        $res = $conn->query(
            "SELECT * FROM customers WHERE (is_active IS NULL OR is_active = 1)"
            . " ORDER BY balance DESC, name ASC LIMIT " . (int)$customersLimit
        );
    } else {
        $res = $conn->query("SELECT * FROM customers WHERE (is_active IS NULL OR is_active = 1) ORDER BY name ASC");
    }
    if($res) while($r=$res->fetch_assoc()) { $r['id']=(int)$r['id']; $r['balance']=roundMoney($r['balance']??0); $data['customers'][]=$r; }
    if ($usePartialCustomers) {
        $data['customers_partial'] = true;
        $data['customers_total'] = $shopHealth['customers_count'];
        $data['customers_loaded'] = count($data['customers']);
    }

    $instBoot = pos_fetch_installment_data($conn);
    $data['installment_plans'] = $instBoot['installment_plans'];
    $data['installment_items'] = $instBoot['installment_items'];

    try {
        if (function_exists('pos_ensure_drivers_schema')) pos_ensure_drivers_schema($conn);
        $resDrvBoot = $conn->query("SELECT id, name, phone, note FROM drivers WHERE (is_active IS NULL OR is_active = 1) ORDER BY name ASC");
        if ($resDrvBoot) {
            $data['drivers'] = [];
            while ($rd = $resDrvBoot->fetch_assoc()) {
                $data['drivers'][] = [
                    'id' => (int)($rd['id'] ?? 0),
                    'name' => trim((string)($rd['name'] ?? '')),
                    'phone' => trim((string)($rd['phone'] ?? '')),
                    'note' => trim((string)($rd['note'] ?? '')),
                ];
            }
        }
    } catch (Throwable $eDrvBoot) { /* drivers table may not exist */ }
    $data['deliveries'] = function_exists('pos_fetch_deliveries_compact')
        ? pos_fetch_deliveries_compact($conn, 200, 0)
        : [];
    }

    if ($wantSecondary) {
    // Fetch Customer Ledger (Reduced Limit)
    $res = $conn->query("SELECT * FROM customer_ledger ORDER BY id DESC LIMIT 200");
    if($res) while($r=$res->fetch_assoc()) { $r['id']=(int)$r['id']; $r['target_id']=(int)$r['target_id']; $r['amount']=roundMoney($r['amount']??0); $data['customer_ledger'][]=$r; }

    $instData = pos_fetch_installment_data($conn);
    $data['installment_plans'] = $instData['installment_plans'];
    $data['installment_items'] = $instData['installment_items'];

    // Fetch Waste
    $res = $conn->query("SELECT * FROM waste ORDER BY id DESC LIMIT 200");
    if($res) while($r=$res->fetch_assoc()) { $r['id']=(int)$r['id']; $r['prodId']=(int)$r['prodId']; $r['qty']=(float)$r['qty']; $r['cost']=roundMoney($r['cost']??0); $data['waste'][]=$r; }

    // Fetch Returns
    $res = $conn->query("SELECT * FROM returns ORDER BY id DESC LIMIT 200");
    if($res) while($r=$res->fetch_assoc()) { 
        $r['id']=(int)$r['id']; $r['total']=roundMoney($r['total']??0); 
        $r['items'] = json_decode($r['items_json'] ?? '[]'); 
        $data['returns'][]=$r; 
    }
    // Fetch Purchase Returns (زڤراندنا کەرەستان بۆ کۆمپانیێ)
    $data['purchase_returns'] = [];
    try {
        $res = $conn->query("SELECT * FROM purchase_returns ORDER BY id DESC LIMIT 200");
        if($res) while($r=$res->fetch_assoc()) {
            $r['id']=(int)$r['id']; $r['company_id']=(int)$r['company_id']; $r['total']=roundMoney($r['total']??0);
            $r['items'] = json_decode($r['items_json'] ?? '[]');
            $data['purchase_returns'][]=$r;
        }
    } catch (Throwable $e) { /* table may not exist yet */ }

    if (!$wantBootstrap) {
    $data['deliveries'] = function_exists('pos_fetch_deliveries_compact')
        ? pos_fetch_deliveries_compact($conn, 200, 0)
        : [];
    try {
        if (function_exists('pos_ensure_drivers_schema')) pos_ensure_drivers_schema($conn);
        $resDrv = $conn->query("SELECT id, name, phone, note FROM drivers WHERE (is_active IS NULL OR is_active = 1) ORDER BY name ASC");
        if ($resDrv) {
            $data['drivers'] = [];
            while ($rd = $resDrv->fetch_assoc()) {
                $data['drivers'][] = [
                    'id' => (int)($rd['id'] ?? 0),
                    'name' => trim((string)($rd['name'] ?? '')),
                    'phone' => trim((string)($rd['phone'] ?? '')),
                    'note' => trim((string)($rd['note'] ?? ''))
                ];
            }
        }
    } catch (Throwable $eDrv) { /* table may not exist yet */ }
    }
    // Fetch Recipes
    $res = $conn->query("SELECT * FROM recipes");
    if($res) while($r=$res->fetch_assoc()) { $r['id']=(int)$r['id']; $r['product_id']=(int)$r['product_id']; $r['ingredient_id']=(int)$r['ingredient_id']; $r['qty']=(float)$r['qty']; $data['recipes'][]=$r; }

    // Audit / print logs: loaded on demand (get_audit_logs / get_print_log) — not on every sync/login.

    // Multi-warehouse locations + per-location stock
    $data['warehouses'] = function_exists('pos_fetch_warehouses_public')
        ? pos_fetch_warehouses_public($conn)
        : [];
    $data['open_warehouse_id'] = function_exists('pos_session_open_warehouse_id')
        ? pos_session_open_warehouse_id()
        : 0;
    if (function_exists('pos_multi_warehouse_pro_enabled') && !pos_multi_warehouse_pro_enabled($conn)
        && function_exists('pos_default_warehouse_id')) {
        $data['open_warehouse_id'] = pos_default_warehouse_id($conn);
    }
    if (function_exists('pos_heal_single_warehouse_stock_bulk')) {
        pos_heal_single_warehouse_stock_bulk($conn);
    }
    if (function_exists('pos_repair_warehouse_qty_desync')) {
        pos_repair_warehouse_qty_desync($conn);
    }
    if (function_exists('pos_heal_reactivate_inactive_with_stock')) {
        pos_heal_reactivate_inactive_with_stock($conn);
    }
    $data['warehouse_stock'] = [];
    $resWs = $conn->query("SELECT warehouse_id, product_id, qty, min_stock FROM warehouse_stock");
    if ($resWs) while ($r = $resWs->fetch_assoc()) {
        $data['warehouse_stock'][] = [
            'warehouse_id' => (int)$r['warehouse_id'],
            'product_id' => (int)$r['product_id'],
            'qty' => (float)$r['qty'],
            'min_stock' => (int)($r['min_stock'] ?? 5),
        ];
    }

    }

    if ($wantSecondaryHeavy) {
    $suppliesLimit = $liteSecondary ? 600 : 1800;
    $res = $conn->query("SELECT * FROM supplies ORDER BY id DESC LIMIT " . (int)$suppliesLimit);
    if($res) while($r=$res->fetch_assoc()) { $r['id']=(int)$r['id']; $r['qtyAdded']=(float)$r['qtyAdded']; $r['totalCost']=roundMoney($r['totalCost']??0); $r['prodId']=(int)$r['prodId']; $data['supplies'][]=$r; }

    $data['warehouse_movements'] = [];
    $whMoveLimit = $liteSecondary ? 180 : 280;
    $res = $conn->query("SELECT m.id, m.product_id, m.barcode, m.movement_type, m.quantity, m.unit_cost, m.total_value, m.reference_type, m.reference_id, m.date, m.user, m.note, m.warehouse_id, m.to_warehouse_id, p.name AS product_name FROM stock_movements m LEFT JOIN products p ON p.id = m.product_id ORDER BY m.date DESC LIMIT " . (int)$whMoveLimit);
    if($res) while($r=$res->fetch_assoc()) {
        $r['id']=(int)$r['id']; $r['product_id']=(int)$r['product_id']; $r['quantity']=(float)$r['quantity'];
        $r['unit_cost']=roundMoney($r['unit_cost']??0); $r['total_value']=roundMoney($r['total_value']??0); $r['reference_id']=(int)$r['reference_id'];
        $r['warehouse_id'] = (int)($r['warehouse_id'] ?? 1);
        $r['to_warehouse_id'] = isset($r['to_warehouse_id']) && $r['to_warehouse_id'] !== null ? (int)$r['to_warehouse_id'] : null;
        $data['warehouse_movements'][]=$r;
    }

    $data['stock_transfers'] = [];
    $resTr = $conn->query("SELECT t.id, t.from_warehouse_id, t.to_warehouse_id, t.status, t.transaction_id, t.total_qty, t.date, t.`user`, t.note FROM stock_transfers t ORDER BY t.date DESC LIMIT 120");
    if ($resTr) while ($r = $resTr->fetch_assoc()) {
        $r['id'] = (int)$r['id'];
        $r['from_warehouse_id'] = (int)$r['from_warehouse_id'];
        $r['to_warehouse_id'] = (int)$r['to_warehouse_id'];
        $r['total_qty'] = (float)$r['total_qty'];
        $data['stock_transfers'][] = $r;
    }
    }

    if ($wantSecondaryExtended) {
    $fetchSupplies = ($extSection === 'all' || $extSection === 'supplies');
    $fetchMovements = ($extSection === 'all' || $extSection === 'warehouse');
    $fetchExpenses = ($extSection === 'all' || $extSection === 'expenses');
    $fetchReturns = ($extSection === 'all' || $extSection === 'returns');
    $data['extended_meta'] = [
        'section' => $extSection,
        'offset' => $extOffset,
        'limit' => $extLimit,
        'has_more' => false,
    ];
    if ($fetchSupplies) {
        $stmtSup = $conn->prepare("SELECT * FROM supplies ORDER BY id DESC LIMIT ? OFFSET ?");
        if ($stmtSup) {
            $fetchN = $extLimit + 1;
            $stmtSup->bind_param('ii', $fetchN, $extOffset);
            if ($stmtSup->execute()) {
                $resSup = $stmtSup->get_result();
                $rowsSup = [];
                if ($resSup) {
                    while ($r = $resSup->fetch_assoc()) {
                        $r['id'] = (int)$r['id'];
                        $r['qtyAdded'] = (float)$r['qtyAdded'];
                        $r['totalCost'] = roundMoney($r['totalCost'] ?? 0);
                        $r['prodId'] = (int)$r['prodId'];
                        $rowsSup[] = $r;
                    }
                }
                if (count($rowsSup) > $extLimit) {
                    array_pop($rowsSup);
                    $data['extended_meta']['has_more'] = true;
                }
                $data['supplies'] = $rowsSup;
                $data['extended_meta']['loaded'] = count($rowsSup);
            }
        }
    }
    if ($fetchMovements) {
        $whExtLimit = min($extLimit, 3000);
        $stmtWh = $conn->prepare("SELECT m.id, m.product_id, m.barcode, m.movement_type, m.quantity, m.unit_cost, m.total_value, m.reference_type, m.reference_id, m.date, m.user, m.note, m.warehouse_id, m.to_warehouse_id, p.name AS product_name FROM stock_movements m LEFT JOIN products p ON p.id = m.product_id ORDER BY m.date DESC LIMIT ? OFFSET ?");
        if ($stmtWh) {
            $fetchNWh = $whExtLimit + 1;
            $stmtWh->bind_param('ii', $fetchNWh, $extOffset);
            if ($stmtWh->execute()) {
                $resWh = $stmtWh->get_result();
                $rowsWh = [];
                if ($resWh) {
                    while ($r = $resWh->fetch_assoc()) {
                        $r['id'] = (int)$r['id'];
                        $r['product_id'] = (int)$r['product_id'];
                        $r['quantity'] = (float)$r['quantity'];
                        $r['unit_cost'] = roundMoney($r['unit_cost'] ?? 0);
                        $r['total_value'] = roundMoney($r['total_value'] ?? 0);
                        $r['reference_id'] = (int)$r['reference_id'];
                        $r['warehouse_id'] = (int)($r['warehouse_id'] ?? 1);
                        $r['to_warehouse_id'] = isset($r['to_warehouse_id']) && $r['to_warehouse_id'] !== null ? (int)$r['to_warehouse_id'] : null;
                        $rowsWh[] = $r;
                    }
                }
                if (count($rowsWh) > $whExtLimit) {
                    array_pop($rowsWh);
                    $data['extended_meta']['has_more'] = true;
                }
                $data['warehouse_movements'] = $rowsWh;
            }
        }
    }
    if ($fetchExpenses) {
        $stmtEx = $conn->prepare("SELECT * FROM expenses ORDER BY id DESC LIMIT ? OFFSET ?");
        if ($stmtEx) {
            $fetchNEx = $extLimit + 1;
            $stmtEx->bind_param('ii', $fetchNEx, $extOffset);
            if ($stmtEx->execute()) {
                $resEx = $stmtEx->get_result();
                $rowsEx = [];
                if ($resEx) {
                    while ($r = $resEx->fetch_assoc()) {
                        $r['id'] = (int)$r['id'];
                        $r['amount'] = roundMoney($r['amount'] ?? 0);
                        $rowsEx[] = $r;
                    }
                }
                if (count($rowsEx) > $extLimit) {
                    array_pop($rowsEx);
                    $data['extended_meta']['has_more'] = true;
                }
                $data['expenses'] = $rowsEx;
            }
        }
    }
    if ($fetchReturns) {
        $stmtRet = $conn->prepare("SELECT * FROM returns ORDER BY id DESC LIMIT ? OFFSET ?");
        if ($stmtRet) {
            $fetchNRet = $extLimit + 1;
            $stmtRet->bind_param('ii', $fetchNRet, $extOffset);
            if ($stmtRet->execute()) {
                $resRet = $stmtRet->get_result();
                $rowsRet = [];
                if ($resRet) {
                    while ($r = $resRet->fetch_assoc()) {
                        $r['id'] = (int)$r['id'];
                        $r['total'] = roundMoney($r['total'] ?? 0);
                        $r['items'] = json_decode($r['items_json'] ?? '[]');
                        unset($r['items_json']);
                        $rowsRet[] = $r;
                    }
                }
                if (count($rowsRet) > $extLimit) {
                    array_pop($rowsRet);
                    $data['extended_meta']['has_more'] = true;
                }
                $data['returns'] = $rowsRet;
            }
        }
    }
    }

    if ($wantBootstrap) {
    // Fetch Categories
    $cats = [];
    $res = $conn->query("SELECT name FROM categories UNION SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND category != ''");
    if($res) while($r=$res->fetch_row()) { $cats[]=$r[0]; }
    $data['categories'] = $cats;

    // Fetch Settings
    $settings_res = $conn->query("SELECT setting_value FROM settings WHERE setting_key = 'app_settings'");
    if($settings_res && $s_row = $settings_res->fetch_assoc()) {
        $decoded_settings = json_decode($s_row['setting_value'], true);
        if (json_last_error() === JSON_ERROR_NONE) {
            $data['settings'] = function_exists('pos_ai_sanitize_settings_for_client')
                ? pos_ai_sanitize_settings_for_client($decoded_settings)
                : $decoded_settings;
        }
    }
    
    // Inject the cloud fail-open setting into the app settings object
    if (isset($data['settings']) && is_array($data['settings']) && function_exists('pos_db_get_setting_value')) {
        $data['settings']['pos_license_force_unlocked_local'] = (pos_db_get_setting_value($conn, 'pos_license_force_unlocked_local') === '1');
        if (function_exists('pos_hydrate_client_settings_currency')) {
            pos_hydrate_client_settings_currency($data['settings'], $conn);
        } else {
            $defCur = pos_db_get_setting_value($conn, 'default_currency');
            $defCur = is_string($defCur) ? strtoupper(trim($defCur)) : '';
            if ($defCur === 'USD' || $defCur === 'IQD') {
                $data['settings']['defaultCurrency'] = $defCur;
                $data['settings']['default_currency'] = $defCur;
                if (empty($data['settings']['currencyMode'])) {
                    $data['settings']['currencyMode'] = $defCur;
                }
            } elseif (empty($data['settings']['defaultCurrency']) && !empty($data['settings']['currencyMode'])) {
                $modeHyd = strtoupper((string)$data['settings']['currencyMode']) === 'USD' ? 'USD' : 'IQD';
                $data['settings']['defaultCurrency'] = $modeHyd;
                $data['settings']['default_currency'] = $modeHyd;
            }
        }
    }

    // 7. Today's Stats — exclusively from pos_get_financial_metrics_core (business-day window).
    $todayStart = date('Y-m-d') . ' 00:00:00';
    if (isset($decoded_settings) && is_array($decoded_settings) && function_exists('pos_business_day_start_datetime')) {
        $todayStart = pos_business_day_start_datetime($decoded_settings);
    } elseif (isset($data['settings']) && is_array($data['settings']) && function_exists('pos_business_day_start_datetime')) {
        $todayStart = pos_business_day_start_datetime($data['settings']);
    }

    try {
        $tomorrowStart = (new DateTimeImmutable($todayStart))->modify('+1 day')->format('Y-m-d H:i:s');
    } catch (Throwable $e) {
        $tomorrowStart = date('Y-m-d', strtotime($todayStart . ' +1 day')) . ' 00:00:00';
    }

    $data['today_stats'] = [
        'sales' => 0,
        'count' => 0,
        'expenses' => 0,
        'returns' => 0,
        'purchases' => 0,
        'purchases_cash' => 0,
        'purchases_debt' => 0,
    ];
    if (function_exists('pos_enrich_today_stats_finance')) {
        $data['today_stats'] = pos_enrich_today_stats_finance($conn, $data['today_stats'], $todayStart, $tomorrowStart);
    }
    $data['session_user'] = pos_session_user_for_client();
    $data['db_health'] = $shopHealth;
    if ($serverLargeShop) {
        $data['large_shop'] = true;
    }
    }

    if ($wantSecondary) {
    // 8. UNIFIED LEDGER & TREASURY (Zero Leakage)
    $treasury = 0;
    $ledger = [];
    $res = $conn->query("SELECT * FROM ledger ORDER BY id DESC LIMIT 500");
    if($res) while($r=$res->fetch_assoc()) { 
        $r['id']=(int)$r['id']; 
        $r['amount']=roundMoney($r['amount']??0);
        $ledger[]=$r; 
    }
    
    // Calculate Total Treasury (cash drawer balance from ledger)
    $treasurySql = function_exists('pos_ledger_treasury_net_sql') ? pos_ledger_treasury_net_sql() : "SUM(CASE WHEN type IN ('sale', 'debt_payment_in', 'return_to_supplier') THEN amount WHEN type IN ('expense', 'purchase', 'debt_payment', 'refund', 'waste', 'void_sale') THEN -amount ELSE 0 END)";
    $resT = $conn->query("SELECT {$treasurySql} as bal FROM ledger");
    if($resT && $rowT=$resT->fetch_assoc()) {
        $treasury = roundMoney($rowT['bal'] ?? 0);
    }
    
    $data['treasury'] = $treasury;
    $data['unified_ledger'] = $ledger;

    // Zero Loss: Capital & profit report (stock value + treasury + receivables - payables)
    $stockPair = function_exists('pos_inventory_stock_value_pair')
        ? pos_inventory_stock_value_pair($conn)
        : ['iqd' => 0.0, 'usd' => 0.0];
    if (!function_exists('pos_inventory_stock_value_pair')) {
        $resStock = $conn->query("SELECT SUM(qty * cost) as v FROM products WHERE trackStock = 1");
        if ($resStock && $row = $resStock->fetch_assoc()) $stockPair['iqd'] = roundMoney($row['v'] ?? 0);
    }
    $stockValue = roundMoney($stockPair['iqd'] ?? 0);
    $receivables = 0;
    $resC = $conn->query("SELECT COALESCE(SUM(balance), 0) as v FROM customers WHERE is_active != 0 AND balance > 0");
    if ($resC && $row = $resC->fetch_assoc()) $receivables += (float)($row['v'] ?? 0);
    $resU = $conn->query("SELECT COALESCE(SUM(balance), 0) as v FROM users WHERE is_active != 0 AND balance > 0");
    if ($resU && $row = $resU->fetch_assoc()) $receivables += (float)($row['v'] ?? 0);
    $receivables = roundMoney($receivables);
    $payables = 0;
    $resComp = $conn->query("SELECT COALESCE(SUM(balance), 0) as v FROM companies WHERE is_active != 0 AND balance > 0");
    if ($resComp && $row = $resComp->fetch_assoc()) $payables = roundMoney($row['v'] ?? 0);
    $capital = $stockValue + $treasury + $receivables - $payables;
    $data['capital_report'] = [
        'stock_value' => $stockValue,
        'stock_value_usd' => isset($stockPair['usd']) ? (float)$stockPair['usd'] : null,
        'treasury' => $treasury,
        'receivables' => $receivables,
        'payables' => $payables,
        'capital' => $capital
    ];
    }

    if (!pos_session_can_view_profit()) {
        $data['capital_report'] = [];
        $data['treasury'] = 0;
        $data['unified_ledger'] = [];
        $data['ledger'] = [];
        foreach ($data['waste'] as &$w) {
            if (isset($w['cost'])) $w['cost'] = roundMoney(0);
        }
        unset($w);
        foreach ($data['supplies'] as &$s) {
            if (isset($s['totalCost'])) $s['totalCost'] = roundMoney(0);
        }
        unset($s);
        foreach ($data['warehouse_movements'] as &$wm) {
            $wm['unit_cost'] = roundMoney(0);
            $wm['total_value'] = roundMoney(0);
        }
        unset($wm);
    }

    if (!pos_session_can_view_cost()) {
        foreach ($data['products'] as &$pRow) {
            $pRow['cost'] = roundMoney(0);
            if (array_key_exists('cost_pack', $pRow)) $pRow['cost_pack'] = null;
            if (array_key_exists('cost_carton', $pRow)) $pRow['cost_carton'] = null;
        }
        unset($pRow);
    }

    if (!pos_session_can_view_expenses()) {
        $data['expenses'] = [];
        $data['expenses_deleted'] = [];
        if (isset($data['today_stats']['expenses'])) $data['today_stats']['expenses'] = roundMoney(0);
    }

    if (!pos_session_can_reports() && !pos_session_is_privileged()) {
        if (isset($data['today_stats'])) {
            if (!pos_session_has_perm('pos_access')) {
                $data['today_stats']['sales'] = roundMoney(0);
                $data['today_stats']['count'] = 0;
            } else {
                $data['today_stats']['sales'] = roundMoney(0);
            }
            $data['today_stats']['returns'] = roundMoney(0);
            if (!pos_session_can_view_expenses()) {
                $data['today_stats']['expenses'] = roundMoney(0);
            }
        }
    }

    if (function_exists('pos_ensure_license_serial')) {
        $data['license_serial'] = (string) pos_ensure_license_serial($conn);
    }
    if (function_exists('pos_ensure_license_security_code')) {
        $data['license_security_code'] = (string) pos_ensure_license_security_code($conn);
    }
    if (function_exists('pos_subscription_sync_tier')) {
        if ($fetchMode === 'bootstrap') {
            $tier = function_exists('pos_subscription_tier_normalize')
                ? pos_subscription_tier_normalize($data['settings']['subscription_tier'] ?? 'free')
                : 'free';
        } else {
            $tier = pos_subscription_sync_tier($conn);
        }
        $data['subscription_tier'] = $tier;
        if ($fetchMode !== 'bootstrap' && function_exists('pos_subscription_fetch_entitlements_remote') && !empty($data['license_serial'])) {
            $ent = pos_subscription_fetch_entitlements_remote((string)$data['license_serial']);
            if (!empty($ent['ok'])) {
                $data['subscription_entitlements'] = $ent;
                if (!empty($data['settings']) && is_array($data['settings']) && function_exists('pos_subscription_merge_entitlements_into_settings')) {
                    $data['settings'] = pos_subscription_merge_entitlements_into_settings($data['settings'], $ent);
                }
            }
        }
        if (!empty($data['settings']) && is_array($data['settings'])) {
            $data['settings']['subscription_tier'] = $tier;
        }
    }

    echo json_encode($data, JSON_UNESCAPED_UNICODE); exit();
}
