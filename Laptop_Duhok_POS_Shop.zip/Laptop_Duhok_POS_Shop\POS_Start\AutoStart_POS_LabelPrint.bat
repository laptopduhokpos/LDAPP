@echo off
chcp 65001 >nul
title POS Label Print Agent (AutoStart)
cd /d "%~dp0.."
start "" powershell.exe -WindowStyle Hidden -NoProfile -ExecutionPolicy Bypass -File "%cd%\api\tools\pos_label_print_agent.ps1"
exit
