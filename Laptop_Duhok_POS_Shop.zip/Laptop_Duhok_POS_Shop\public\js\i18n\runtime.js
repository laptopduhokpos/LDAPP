// POS i18n runtime — loads i18n-badini.js + i18n-ar.js first (see main.js)
        // --- i18n: Language switch (Badini / Arabic). db.settings.language = 'badini' | 'ar'. ---
        window.LANGS = {
            badini: window.POS_I18N_BADINI || {},
            ar: window.POS_I18N_AR || {}
        };
        function normalizeLanguageDictionaries() { /* Custom clean dicts */ }
        normalizeLanguageDictionaries();
        var __i18nMissingKeyCache = {};
        /** Normalize UI language token from storage or settings; null if unknown. */
        function normalizePosLanguageValue(raw) {
            if (raw == null || raw === '') return null;
            var L = String(raw).trim().toLowerCase();
            if (L === 'ar' || L === 'arabic' || L === 'arab' || L === 'عربي' || L === 'عربی') return 'ar';
            if (L === 'badini' || L === 'ckb' || L === 'ku' || L === 'kurdi' || L === 'kurdish' || L === 'sorani') return 'badini';
            return null;
        }
        function getCurrentLanguage() {
            if (typeof localStorage !== 'undefined') {
                var lsNorm = normalizePosLanguageValue(localStorage.getItem('pos_language'));
                if (lsNorm) return lsNorm;
            }
            var dbRaw = (typeof db !== 'undefined' && db && db.settings && db.settings.language != null && db.settings.language !== '')
                ? db.settings.language : '';
            var dbNorm = normalizePosLanguageValue(dbRaw);
            if (dbNorm) return dbNorm;
            return 'badini';
        }
        /** Display-layer: normalize stored expense / ledger note tokens for the active UI language. */
        function translateExpenseNoteForUi(note) {
            if (note == null || note === '') return '';
            var lang = (typeof getCurrentLanguage === 'function') ? getCurrentLanguage() : 'badini';
            var s = String(note);
            if (lang === 'ar') {
                s = s.replace(/^کڕین\s*\(\s*نەقد\s*\)\s*ژ\s+/g, 'المشتريات (نقداً) من ');
                s = s.replace(/^کڕین:\s*/g, 'المشتريات: ');
                s = s.replace(/\sژ\s/g, ' من ');
                s = s.replace(/وەسڵ\s*#/g, 'وصل #');
                s = s.replace(/\(\s*کاش\s*\)/g, '(نقداً)');
                s = s.replace(/\(\s*نەقد\s*\)/g, '(نقداً)');
                s = s.replace(/\(\s*قەرز\s*\)/g, '(دين)');
                s = s.replace(/\|\s*items\s*=/gi, ' | أصناف=');
                s = s.replace(/\|\s*supplier_inv\s*=/gi, ' | فاتورة_المورد=');
                s = s.replace(/^مووچە:\s*/g, 'راتب: ');
                s = s.replace(/^Expense:\s*Salary:\s*/gi, 'راتب: ');
                s = s.replace(/^Expense:\s*Advance:\s*/gi, 'سلفة: ');
                s = s.replace(/^Salary:\s*/gi, 'راتب: ');
                s = s.replace(/^نزبا:\s*/g, 'سلفة: ');
                s = s.replace(/^Advance:\s*/gi, 'سلفة: ');
                s = s.replace(/^Expense:\s*/i, 'مصروف: ');
                s = s.replace(/\|\s*amount\s*=/gi, ' | المبلغ=');
                s = s.replace(/\|\s*before\s*=/gi, ' | قبل=');
                s = s.replace(/\|\s*after\s*=/gi, ' | بعد=');
                s = s.replace(/\|\s*by\s*=/gi, ' | بواسطة=');
                s = s.replace(/\bSystem\b/g, 'النظام');
                s = s.replace(/تسديد دين\s*:\s*تسديد دين/gi, 'تسديد دين');
                s = s.replace(/دانەڤا قەرزی\s*\(\s*Company Payment\s*\)\s*:\s*/gi, 'تسديد دين شركة: ');
                s = s.replace(/\(\s*Company Payment\s*\)/gi, '');
                return s;
            }
            if (lang === 'badini') {
                s = s.replace(/\|\s*amount\s*=/gi, ' | بڕ=');
                s = s.replace(/\|\s*before\s*=/gi, ' | پێشوو=');
                s = s.replace(/\|\s*after\s*=/gi, ' | دوای=');
                s = s.replace(/\|\s*by\s*=/gi, ' | لەلایەن=');
                s = s.replace(/\bSystem\b/g, 'سیستەم');
                s = s.replace(/^Expense:\s*Salary:\s*/gi, 'مووچە: ');
                s = s.replace(/^Expense:\s*Advance:\s*/gi, 'نزبا: ');
                s = s.replace(/^Salary:\s*/gi, 'مووچە: ');
                s = s.replace(/^Advance:\s*/gi, 'نزبا: ');
                s = s.replace(/^Expense:\s*/i, 'مەزاختن: ');
                s = s.replace(/دانەڤا قەرزی\s*\(\s*Company Payment\s*\)\s*:\s*/gi, 'دانەڤا قەرزی کۆمپانیا: ');
                s = s.replace(/\(\s*Company Payment\s*\)/gi, '(دانەڤا قەرزی کۆمپانیا)');
                return s;
            }
            return s;
        }
        if (typeof window !== 'undefined') window.translateExpenseNoteForUi = translateExpenseNoteForUi;

        /** Sorani → Badini cleanup (display layer only). */
        function normalizeBadiniDialect(text) {
            if (typeof text !== 'string' || !text) return text;
            return text
                .replace(/گواستنەوەی/g, 'ڤەگوهارتنا')
                .replace(/گواستنەوە/g, 'ڤەگوهارتن')
                .replace(/زڤڕاندنەوە/g, 'زڤڕاندن')
                .replace(/پاشەکەوت/g, 'پاراستن')
                .replace(/پاشگەزبوونەوە/g, 'پاشگەزبوون')
                .replace(/سڕینەوە/g, 'ژێبرن')
                .replace(/نوێ/g, 'نوی')
                .replace(/پێداچوونەوە/g, 'پێداچوون')
                .replace(/\u0641\u0631\u06C6\u0634\u062A\u0646/g, '\u0641\u0631\u06C6\u062A\u0646');
        }

        /** Strip Kurdish / English clutter from Arabic UI strings. */
        function sanitizeArabicDisplay(text) {
            if (typeof text !== 'string' || !text) return text;
            var out = text;
            out = out.replace(/\s*\([^)]*[A-Za-z][^)]*\)/g, ' ');
            out = out.replace(/\s*\([^)]*[ێۆەڵڤڕ][^)]*\)/g, ' ');
            out = out.replace(/\s*\/\s*[^/\u0600-\u06FF]+/g, '');
            out = out.replace(/[ێۆەڵڤڕ]/g, '');
            out = out.replace(/\s{2,}/g, ' ').trim();
            return out;
        }

        function t(key) {
            var lang = (typeof getCurrentLanguage === 'function') ? getCurrentLanguage() : 'badini';
            var map = (typeof window.LANGS !== 'undefined' && window.LANGS[lang]) ? window.LANGS[lang] : window.LANGS.badini;
            if (!map) map = window.LANGS.badini;
            // Strict language mode: never fallback to the other language map.
            var val = (map && map[key]) || '';
            if (val) {
                if (lang === 'ar') return sanitizeArabicDisplay(val);
                if (lang === 'badini') return normalizeBadiniDialect(val);
                return val;
            }
            var missKey = lang + '::' + key;
            if (!__i18nMissingKeyCache[missKey]) {
                __i18nMissingKeyCache[missKey] = true;
                // Keep UI fallback without noisy console warnings in production.
            }
            return key;
        }
        window.t = t;
        function arT(key, fallback) {
            if (typeof getCurrentLanguage === 'function' && getCurrentLanguage() === 'ar' && typeof t === 'function') {
                var v = t(key);
                if (v && v !== key) return v;
            }
            return fallback;
        }
        window.arT = arT;
        function buildUiLangMap(lang, manualPairs) {
            var toAr = (lang === 'ar');
            var map = {};
            (manualPairs || []).forEach(function(p) {
                if (!Array.isArray(p) || p.length < 2) return;
                if (toAr) map[p[0]] = p[1];
                else map[p[1]] = p[0];
            });
            try {
                if (window.LANGS && window.LANGS.badini && window.LANGS.ar) {
                    Object.keys(window.LANGS.badini).forEach(function(k) {
                        var b = window.LANGS.badini[k];
                        var a = window.LANGS.ar[k];
                        if (!b || !a) return;
                        b = String(b).trim();
                        a = String(a).trim();
                        if (!b || !a || b === a) return;
                        if (b.length < 5 || a.length < 5) return;
                        if (toAr) map[b] = a;
                        else map[a] = b;
                    });
                }
            } catch (e) {}
            var sortedKeys = Object.keys(map).sort(function(a, b) { return b.length - a.length; });
            return { map: map, sortedKeys: sortedKeys };
        }
        function replaceWithUiLangMap(text, mapObj) {
            if (typeof text !== 'string' || !text) return text;
            if (!mapObj || !Array.isArray(mapObj.sortedKeys)) return text;
            var out = text;
            mapObj.sortedKeys.forEach(function(k) {
                if (out.indexOf(k) !== -1) out = out.split(k).join(mapObj.map[k]);
            });
            return out;
        }
        function stripMixedSuffixes(text, lang) {
            if (typeof text !== 'string' || !text) return text;
            var out = text;
            // Remove bilingual helper suffixes like "X (English)" or "X (كوردي)"
            out = out.replace(/\s+\((?:[A-Za-z][^)]{0,60})\)\s*/g, ' ');
            // Normalize A / B cases by selecting selected-language side when known.
            if (window.LANGS && window.LANGS.badini && window.LANGS.ar) {
                var keys = Object.keys(window.LANGS.badini);
                keys.forEach(function(k) {
                    var b = String(window.LANGS.badini[k] || '').trim();
                    var a = String(window.LANGS.ar[k] || '').trim();
                    if (!b || !a || b === a) return;
                    var preferred = (lang === 'ar') ? a : b;
                    var other = (lang === 'ar') ? b : a;
                    var variants = [
                        b + ' / ' + a, a + ' / ' + b,
                        b + ' (' + a + ')', a + ' (' + b + ')',
                        b + ' - ' + a, a + ' - ' + b
                    ];
                    variants.forEach(function(v) {
                        if (out.indexOf(v) !== -1) out = out.split(v).join(preferred);
                    });
                    var withOtherParens = preferred + ' (' + other + ')';
                    if (out.indexOf(withOtherParens) !== -1) out = out.split(withOtherParens).join(preferred);
                });
            }
            return out.replace(/\s{2,}/g, ' ').trim();
        }
        function localizeHardcodedUiText(root) {
            if (!root || !root.querySelectorAll) return;
            var lang = (typeof getCurrentLanguage === 'function') ? getCurrentLanguage() : 'badini';
            var pairs = [
                ['زڤڕاندنا بەشەکێ', 'إرجاع جزئي'],
                ['زەکات', 'الزكاة'],
                ['هەڤسەنگییا ئەڤرۆ', 'تسوية الجلسة'],
                ['دەرامەتێ زەکاتێ', 'الثروة الخاضعة للزكاة'],
                ['کوژمێ زەکاتێ (٢.٥٪)', 'مبلغ الزكاة (٢.٥٪)'],
                ['هەژمارکرنا زەکاتێ ل سەر بنەمایێ داتایا دارایی ب ڕێژەیا ٢.٥٪', 'حساب مبلغ الزكاة المستحق بناءً على البيانات المالية.'],
                ['زەکات دهێتە دان دەمێ دەرامەت دگەهیتە نیسابێ. بۆ پتر پێزانینان پرسیارا مامۆستایێ ئایینی بکە.', 'تُخرج الزكاة إذا بلغت الثروة النصاب.'],
                ['پارێ چاڤەڕێکری', 'الرصيد المتوقع'],
                ['پارێ ل بەر دەست', 'النقد الفعلي'],
                ['پارێ د قاسێ دا بنڤیسە بۆ هەڤبەرکرنێ دگەل پارێ چاڤەڕێکری.', 'أدخل النقد الفعلي لغرض المطابقة.'],
                ['دراڤێ چالاک', 'العملة النشطة'],
                ['دەستنیشانکرنا دراڤی و بهایێ دۆلاری بۆ نیشاندانا بهایان د سیستەمی دا.', 'تحديد العملة النشطة وسعر الصرف.'],
                ['هویرکاری', 'تفاصيل'],
                ['هەڤبەرکرنا داهاتی', 'مقارنة الدخل'],
                ['ل سەر تە', 'المستحقة'],
                ['مای', 'المتبقي'],
                ['هاتیە دان', 'المدفوع'],
                ['ڕێڕەو', 'شريط المسار'],
                ['نیشاندان یان ڤەشارتنا ڕێڕەوی', 'إظهار شريط المسار أو إخفاؤه'],
                ['بشکوکێ لیستا سەرەکی', 'القائمة العائمة'],
                ['نیشاندان یان ڤەشارتنا بشکوکێ مێنیۆیێ.', 'إظهار القائمة العائمة أو إخفاؤها.'],
                ['لیستا کەناری', 'القائمة الجانبية'],
                ['نیشاندان یان ڤەشارتنا لیستا کەناری', 'إظهار القائمة الجانبية أو إخفاؤها بالكامل'],
                ['بەشێن مێنیۆیێ', 'أقسام القائمة'],
                ['ڕێکخستنا لیستا سەرەکی', 'تخصيص القائمة'],
                ['تۆمارا چاپێ و ژێبرنێ', 'سجل الطباعة العام'],
                ['چاڤدێرییا مامەڵە و چاپکرنێ. کلیکێ ل سەر ڕێزێ بکە بۆ دیتن و دووبارە چاپکرنێ.', 'مراقبة كافة عمليات الطباعة والحذف المباشر.'],
                ['کڕینا بلەز', 'مشتريات سريعة'],
                ['ڕێکخستنێن چاپێ', 'إعدادات الطباعة'],
                ['ڕێکخستنا لۆگۆ و دیزاینا پسوولەیێن 80mm و 60mm.', 'التحكم بقوالب فواتير 80mm و 60mm.'],
                ['ڕێکخستنێن پسوولەیێ', 'إعدادات الفاتورة'],
                ['کۆمپانیا و دابینکەر', 'الموردين والشركات'],
                ['کۆگەه', 'المخزن'],
                ['زێدەکرنا ئایتمان', 'المنتجات'],
                ['مەزاختن', 'المصروفات'],
                ['ڕاپۆرت', 'التقارير'],
                ['ڕێکخستن', 'الإعدادات'],
                ['کارمەند', 'الموظفين'],
                ['ڕێڤەبرنا کارمەندان', 'إدارة الموظفين'],
                ['ڕۆژمێر', 'التقويم'],
                ['ڕۆژمێرا کاران', 'تقويم العمليات'],
                ['ئاگەهداری', 'الإشعارات'],
                ['کڕین', 'المشتريات'],
                ['زڤڕاندنا کڕینێ', 'إرجاع المشتريات'],
                ['گەهاندن', 'التوصيل'],
                ['تەلەف', 'الهدر'],
                ['ڕەچەتە', 'الوصفات'],
                ['پاراستن و گرتنا شیفتی', 'حفظ وإغلاق الجلسة'],
                ['تێبینی بەری چاپێ', 'ملاحظة قبل الطباعة'],
                ['دراڤ', 'العملة'],
                ['دینار عێراقی', 'دينار عراقي'],
                ['هەڤبەرکرن', 'مقارنة'],
                ['زمان', 'اللغة'],
                ['زمانێ سیستەمی دیار بکە د ناڤبەرا بادینی و عەرەبی فۆسحا دا.', 'اختر لغة الواجهة بين البدينية والعربية الفصحى.'],
                ['بادینی', 'البادينية'],
                ['عەرەبی', 'العربية'],
                ['تەزامونا موبایلێ (Mobile Sync)', 'مزامنة الهاتف المحمول'],
                ['POS بە بەرنامەی مۆبایلی بەڕێوەبەر دەبەستێت — فرۆشتن، کاڵا و ئامار لە مۆبایلدا ببینە.', 'يربط نقطة البيع بتطبيق المدير على الجوال — شاهد المبيعات والمخزون والإحصاءات من هاتفك.'],
                ['تەنها هنارتن — داتای ناو سیستەم ناگۆڕدرێت.', 'إرسال فقط — لا يُعدَّل البرنامج المحلي.'],
                ['ئیمێلەکا نوی فەکە (Connect New)', 'ربط حساب جديد'],
                ['بگرە (Logout)', 'تسجيل الخروج'],
                ['پەیوەندی هەیە', 'متصل'],
                ['پەیوەندی نینە', 'غير متصل'],
                ['مەزنکرن و بچویککرن', 'التكبير والتصغير'],
                ['قەبارێ نڤیسینێ د سیستەمی دا دیار بکە. دێ هێتە پاراستن بۆ جارێن دی.', 'تعديل حجم واجهة المستخدم.'],
                ['بهایێ 100$ (دینار بۆ فەقەی 100 دۆلار)', 'سعر 100 دولار'],
                ['پاشگەزبوون', 'إلغاء'],
                ['دراڤێ فایلی:', 'عملة الملف:'],
                ['داخستن', 'إغلاق'],
                ['پاراستن', 'حفظ'],
                ['چاپکرن', 'طباعة'],
                ['نویکرن', 'تحديث'],
                ['لێگەڕیان', 'بحث'],
                ['بەروار', 'التاريخ'],
                ['کڕیار', 'العميل'],
                ['کاشێر', 'الكاشير'],
                ['قەرز', 'دين'],
                ['کاش', 'نقد'],
                ['کۆیا گشتی', 'المجموع الإجمالي'],
                ['کۆیا سافی', 'الصافي'],
                ['داشکاندن', 'الخصم'],
                ['ئایتم', 'الصنف'],
                ['ژمارە', 'الكمية'],
                // Avoid short keys like بها / کۆ — they match inside بهایێ / بارکۆد / کۆگەهێ and garble Arabic UI.
                ['چێشتخانە', 'المطبخ'],
                ['پسوولە', 'فاتورة'],
                ['مێژوو', 'السجل'],
                ['ڕاپۆرت', 'التقرير'],
                ['کۆمپانیا', 'الموردون'],
                ['کارمەند', 'الموظفون'],
                ['شاشا فرۆتنێ', 'شاشة المبيعات'],
                ['سەبەتە', 'السلة'],
                ['سەبەتە بەتاڵە', 'السلة فارغة'],
                ['کاڵاکان', 'الأصناف'],
                ['هەمی', 'الكل'],
                ['پڕفرۆشترین', 'الأكثر مبيعاً'],
                ['لێگەریان / بارکۆد...', 'بحث / باركود...'],
                ['پوختەی ئەڤرۆ، شیکاری ٧ ڕۆژ، و سەبەتەی چالاک', 'ملخص اليوم، تحليل ٧ أيام، والسلات النشطة'],
                ['دارایی', 'مالي'],
                ['گرێدایە (MySQL)', 'متصل (MySQL)'],
                ['کریار', 'العميل'],
                ['کۆم', 'المجموع'],
                ['ئایتم', 'الصنف'],
                ['نرخ', 'السعر'],
                ['ژمارە', 'الكمية'],
                ['داشـ', 'خصـ'],
                ['کۆیا پێش داشکاندن', 'المجموع قبل الخصم'],
                ['کۆی دەین', 'إجمالي الدين'],
                ['دەینی کەڤن', 'دين سابق'],
                ['کاڵایەک لە لیستەکە هەڵبژێرە بۆ دەستپێکردن', 'اختر صنفاً من القائمة للبدء'],
                ['هیچ کاڵایەک نەدۆزرایەوە', 'لم يُعثر على أصناف'],
                ['بارکۆد یان ناو بنووسە، یان پۆلێکی تر هەڵبژێرە', 'اكتب باركوداً أو اسماً، أو اختر تصنيفاً آخر'],
                ['لێگەریان / بارکۆد...', 'بحث / باركود...'],
                ['🔍 لێگەڕیان / Barcode...', '🔍 بحث / باركود...'],
                ['سەفەری', 'للأخذ'],
                ['Print', 'طباعة'],
                ['Clear', 'حذف'],
                ['Hold', 'حفظ الطلب'],
                ['Kitchen', 'المطبخ'],
                ['Close', 'إغلاق'],
                ['Close expand', 'إغلاق'],
                ['Business Day', 'يوم العمل'],
                ['Disconnected', 'غير متصل'],
                ['فرۆتنا ئەڤرۆ', 'مبيعات اليوم'],
                ['فرۆشتنەکان', 'مبيعات اليوم'],
                ['قازانج', 'صافي الربح'],
                ['ژمارا پسوولاان', 'عدد الفواتير'],
                ['ڕەوشا دارایی', 'المركز المالي'],
                ['سەرمایێ کۆگەهێ', 'أصول المخزون'],
                ['قەرێن کۆمپانیان', 'ديون والتزامات على المحل'],
                ['سەرمایێ گشتی', 'صافي الثروة'],
                ['شیکاریا فرۆتنێ (٧ رۆژ)', 'تحليل المبيعات (٧ أيام)'],
                ['مێزێن بکار', 'الطاولات النشطة'],
                ['ئامادە', 'جاهز'],
                ['ناڤێ کڕیاری — کلیک بکە بۆ هەموو لیست', 'اسم العميل — انقر لعرض القائمة'],
                ['پارێ دای', 'المبلغ المدفوع'],
                ['ژمارەی ئایتم لە سەبەتە', 'عدد الأصناف في السلة'],
                ['پاککردنەوە', 'إفراغ'],
                ['فروشتن', 'بيع'],
                ['ژێبرن', 'حذف'],
                ['هەگرتن', 'حفظ الطلب'],
                ['لیست', 'فاتورة'],
                ['چێشتخانە', 'المطبخ'],
                ['کۆگاکان', 'المخازن'],
                ['هەموو', 'الكل'],
                ['کۆگەی سەرەکی', 'المستودع الرئيسي'],
                ['شاشا سەرەکی', 'لوحة التحكم'],
                ['فرۆتن', 'بيع'],
                ['زڤڕاندن', 'مرتجع'],
                ['دانەڤا قەرزی', 'تسديد الدين'],
                ['وەرگرتنا پارەی', 'استلام الدفعة'],
                ['مێژوویا کڕینێ', 'سجل المشتريات'],
                ['پێداچوون', 'دفتر'],
                ['پوختە', 'ملخص'],
                ['چالاک', 'نشط'],
                ['سەرەکی', 'الرئيسية'],
                ['کڕین', 'شراء'],
                ['دکان', 'المتجر'],
                ['ناڤ', 'الاسم'],
                ['تەلەفۆن', 'الهاتف'],
                ['ناڤنیشان', 'العنوان'],
                ['ڕێڤەبرنا کەلوپەلێن بلەز', 'إدارة الأصناف السريعة'],
                ['ئەرشیفێ پسوولەیان (چاپ/تۆمار)', 'أرشيف الوصولات (طباعة/سجل)'],
                ['نیشاندانا پەنجەرەیا پارەدانێ ب شێوەیێ ئۆتۆماتیکی', 'إظهار نافذة الدفع تلقائياً'],
                ['ڤەشارتنا تورا کەلوپەلان / تەنێ بکارئینانا بارکۆدی', 'إخفاء شبكة الأصناف / وضع الباركود فقط'],
                ['کەلوپەلێن بلەز', 'أصناف سريعة'],
                ['وەسڵێن کۆمپانیایێ (هویرکاریێن دروست)', 'وصولات الشركة (تفاصيل دقيقة)'],
                ['لێگەڕیان ب ژمارا لڤینێ / ژمارا پسوولەیێ / جۆر...', 'بحث برقم الحركة / رقم الفاتورة / النوع...'],
                ['هویرکاری', 'التفاصيل'],
                ['دەستنیشانکرن', 'تحديد'],
                ['ڕێڤەبرن', 'إدارة'],
                ['ناسناما', 'المرجع'],
                ['ڕەوشا پەیوەندیێ ب داتابەیسێ ڤە', 'حالة الاتصال بقاعدة البيانات'],
                ['کوژم', 'المبلغ'],
                ['لێگەڕیان: ژمارا پسوولەیێ، مێز، ناڤێ کەلوپەلی...', 'بحث: رقم الفاتورة، المائدة، اسم الصنف...'],
                ['نڤێسنا دەستی', 'إدخال يدوي'],
                ['🧾 پسوولە (وەسڵ)', '🧾 الوصولات'],
                ['جۆر', 'النوع'],
                ['📜 مێژوویا فرۆتنێ', '📜 سجل المبيعات'],
                ['زڤڕاندی (زڤڕاندن)', 'المرجوة'],
                ['زڤڕاندن', 'إرجاع'],
                ['ب تەمامی', 'بالكامل'],
                ['لێگەڕیان د ئەرشیفێ پسوولەیان دا...', 'بحث في أرشيف الوصولات...'],
                ['ژمارا پسوولەیێ/لڤینێ', 'رقم الوصل/الحركة'],
                ['بکارهێنەر', 'المستخدم'],
                ['کۆگەه', 'المستودع'],
                ['نموونە: 100000', 'مثال: 100000'],
                ['و بهایێ دۆلاری بۆ نیشاندانا بهایان د سیستەمی دا.', 'وسعر الصرف لعرض الأسعار في البرنامج.'],
                ['جوداهی', 'الفرق'],
                ['🗂️ ئەرشیفێ پسوولەیان', '🗂️ أرشيف الوصولات'],
                ['کڕیار (Customers)', 'العملاء'],
                ['داشکاندن (%)', 'الخصم (%)'],
                ['دیزاین', 'التصميم'],
                ['Cost (تاک)', 'Cost (مفرد)'],
                ['د.ع', 'د.ع'],
                ['لینک (URL):', 'الرابط:'],
                ['ناردن (Auto)', 'إرسال'],
                ['مۆدا دەستکاریێ: کلیک بکە بۆ چوونەژوورە و هەڵبژاردنا بەشێن ڤەشارتنی (Edit mode)', 'وضع تعديل: انقر للدخول واختيار الأقسام المخفية'],
                ['کار (ئەمر)', 'أوامر'],
                ['ناڤێ کەلوپەلی', 'اسم الصنف'],
                ['تێبینی', 'ملاحظة'],
                ['پارێ دەستپێکێ', 'رصيد الافتتاح'],
                ['A4: دیزاین ١', 'A4: تصميم ١'],
                ['💰 دارایی', '💰 مالية'],
                ['📉 داشکاندن', '📉 الخصم'],
                ['ڕێڤەبەر (admin)', 'مدير'],
                ['بانک/کارت (Bank/Card)', 'بنك/بطاقة'],
                ['شاشا کڕیاری', 'شاشة العميل'],
                ['نرخ (IQD)', 'السعر'],
                ['نیشانی دراو (USD/IQD)', 'عملة العرض'],
                ['123456789012 یان P00001', '123456789012 أو P00001'],
                ['📦 ئایتم', '📦 صنف'],
                ['دیزاین ١', 'تصميم ١'],
                ['دیزاین ٢', 'تصميم ٢'],
                ['تاک', 'مفرد'],
                ['هەڤسەنگییا ئەڤرۆ', 'تسوية نهاية الجلسة'],
                ['دەستنیشانکرنا دراڤی و بهایێ دۆلاری بۆ نیشاندانا بهایان د سیستەمی دا.', 'تحديد العملة النشطة وسعر الصرف لعرض الأسعار في البرنامج.'],
                ['زەکات (Zakat)', 'الزكاة'],
                ['هەژمارکرنا زەکاتێ ل سەر بنەمایێ داتایا دارایی ب ڕێژەیا ٢.٥٪', 'حساب مبلغ الزكاة المستحق بناءً على البيانات المالية، نسبة ٢.٥٪'],
                ['زەکات دهێتە دان دەمێ دەرامەت دگەهیتە نیسابێ. بۆ پتر پێزانینان پرسیارا مامۆستایێ ئایینی بکە.', 'تُخرج الزكاة إذا بلغت الثروة النصاب. للاستشارة الشرعية راجع مفتياً.'],
                ['پارێ د قاسێ دا بنڤیسە بۆ هەڤبەرکرنێ دگەل پارێ چاڤەڕێکری.', 'أدخل النقد الفعلي في الصندوق لمقارنته مع الرصيد المتوقع.'],
                ['هەڤبەرکرنا داهاتی', 'مقارنة الدخل'],
                ['نیشاندان یان ڤەشارتنا ڕێڕەوی', 'إظهار شريط المسار أو إخفاؤه'],
                ['بشکوکێ لیستا سەرەکی', 'زر القائمة العائم'],
                ['نیشاندان یان ڤەشارتنا بشکوکێ مێنیۆیێ.', 'إظهار أو إخفاء زر القائمة (☰) العائم. يجب أن تبقى وسيلة تنقل واحدة ظاهرة على الأقل.'],
                ['نیشاندان یان ڤەشارتنا لیستا کەناری', 'إظهار أو إخفاء القائمة الجانبية بالكامل'],
                ['ڕێکخستنا لیستا سەرەکی', 'تخصيص القائمة (إظهار/إخفاء أقسام)'],
                ['تۆمارا گشتی یا چاپێ و ژێبرنێ', 'سجل عام للطباعة والحذف'],
                ['چاڤدێرییا مامەڵە و چاپکرنێ. کلیکێ ل سەر ڕێزێ بکە بۆ دیتن و دووبارە چاپکرنێ.', 'مراقبة كافة عمليات الطباعة والحذف المباشر.'],
                ['کڕینا بلەز', 'مشتريات سريعة'],
                ['ڕێکخستنێن چاپێ و دیزاینێ', 'إعدادات الطباعة والتصميم'],
                ['ڕێکخستنا لۆگۆ و دیزاینا پسوولەیێن 80mm و 60mm.', 'التحكم بالشعار وقوالب فواتير 80mm و 60mm.'],
                ['ڕێکخستنێن پسوولەیێ', 'إعدادات الفاتورة'],
                ['کۆمپانیا و دابینکەر', 'الشركات والموردون'],
                ['کۆگەه', 'المخزون'],
                ['تەلەف', 'الهدر'],
                ['دراڤ', 'العملة'],
                ['دینار عێراقی', 'دينار عراقي'],
                ['زمان', 'اللغة'],
                ['زمانێ سیستەمی دیار بکە د ناڤبەرا بادینی و عەرەبی فۆسحا دا.', 'تبديل لغة الواجهة بين البادينية والعربية الفصحى.'],
                ['مەزنکرن و بچویککرن', 'التكبير والتصغير'],
                ['قەبارێ نڤیسینێ د سیستەمی دا دیار بکە. دێ هێتە پاراستن بۆ جارێن دی.', 'تکبیر و تصغیر داخل التطبيق (70%–150%). القیمة تُحفظ تلقائياً وتُطبَّق عند إعادة فتح التطبيق.'],
                ['بهایێ 100$ (دینار بۆ فەقەی 100 دۆلار)', 'سعر الصرف: 100 دولار = ___ دينار'],
                ['دەمێ چاپکرنێ', 'وقت الطباعة'],
                ['چ کۆمپانی دیارنەکرینە.', 'لا توجد شركة محددة.'],
                ['چ وەسڵ بۆ ڤێ کۆمپانیێ نینن.', 'لا توجد وصولات لهذه الشركة.'],
                ['چ ئەرشیف بۆ ڤێ کۆمپانیێ نینن.', 'لا يوجد أرشيف وصولات مرتبط بهذه الشركة.'],
                ['کڕین ب قەرز', 'شراء دين'],
                ['دانەڤا قەرزی', 'تسديد دين'],
                ['وەرگرتنا قەرزی', 'استلام دين'],
                ['زڤڕاندنا کڕینێ', 'إرجاع مشتريات'],
                ['کڕین ب کاش', 'شراء نقدي'],
                ['وەسڵا زڤڕاندنا کڕینێ', 'وصل إرجاع مشتريات'],
                ['هویرکاریا کڕینێ', 'تفصيل شراء'],
                ['هویرکاریا زڤڕاندنێ', 'تفصيل إرجاع'],
                ['لڤین', 'حركة'],
                ['کڕین (قەرز)', 'كين (دين)'],
                ['پێداچوون/جەرد', 'كشف حساب'],
                ['مێژوو', 'السجل'],
                ['داتایێن کۆگەهی', 'بيانات المستودع'],
                ['کۆم بهایێ کۆگەهی', 'قيمة مستودع الشركة'],
                ['قەرزێ مای', 'الرصيد المتبقي'],
                ['مێژوویا کڕین و داخازیان', 'سجل المشتريات والطلبات'],
                ['پێداچوون/جەردێ پارەدان و قەرزان', 'كشف حساب الديون والدفعات'],
                ['چاپ (پێداچوون/جەردێ پارەدان و قەرزان)', 'طباعة (كشف حساب الديون والدفعات)'],
                ['کارتێ ئایتمی:', 'بطاقة صنف:'],
                ['پیشاندان ل POS', 'إظهار في نقطة البيع'],
                ['Partner', 'شريك'],
                ['نوسینەکان و حفظ', 'الخيارات والحفظ'],
                ['پێویست بە وەسفات (ئەگەر موادی وەسفات نەبێ، مەفرۆشە)', 'مرتبط بوصفة (إن نقصت مكونات الوصفة فلا يُباع)'],
                ['پوختەیا دارایی، کۆگەه، قازانج و کارمەندان', 'ملخص مالي، مخزون، أرباح وموظفون'],
                ['بارکردنا ڕاپۆرت...', 'جاري تحميل التقرير...'],
                ['چاپی PDF', 'طباعة PDF'],
                ['دەرکردن بۆ Excel', 'تصدير Excel'],
                ['فلتەر', 'تصفية'],
                ['ئەمڕۆ', 'اليوم'],
                ['هەفتە', 'أسبوع'],
                ['مانگ', 'شهر'],
                ['ساڵ', 'سنة'],
                ['هەموو کارمەندان', 'جميع الموظفين'],
                ['هەموو پۆلەکان', 'جميع التصنيفات'],
                ['هەموو دابینکەران', 'جميع الموردين'],
                ['نوێکردنەوە', 'تحديث'],
                ['مەتریکسا دارایی', 'المصفوفة المالية'],
                ['بابەت', 'البند'],
                ['ژمارا وەسڵان', 'عدد الفواتير'],
                ['کۆی بهای', 'إجمالي القيمة'],
                ['نەقد وەرگرت', 'النقد المحصل'],
                ['قەرزی ماوە', 'الدين المتبقي'],
                ['سەندووق (قاسە)', 'الصندوق (نقد)'],
                ['بەهایا کۆگەه', 'قيمة المخزون'],
                ['ل سەر بنەمای نرخی کرین', 'بناءً على سعر التكلفة'],
                ['قازانجێ سافی', 'صافي الربح'],
                ['جوملە / سەفەری', 'جملة / سفري'],
                ['کۆی فرۆتنا جوملە/سەفەری', 'إجمالي مبيعات الجملة/السفري'],
                ['دیاری', 'هدايا'],
                ['کۆی دیاری پێدراو (ژمارە:', 'إجمالي الهدايا (العدد:'],
                ['ئاگاداریا کۆگەه', 'تنبيهات المخزون'],
                ['شیکاریا فرۆتنێ', 'تحليل المبيعات'],
                ['باشترین فرۆتن', 'الأكثر مبيعاً'],
                ['کارایی کارمەندان', 'أداء الموظفين'],
                ['قەرزێ کریاران (دەوێن من)', 'ديون العملاء (لنا)'],
                ['قەرزێ دابینکەران (دەوێن ئێمە)', 'ديون الموردين (علينا)'],
                ['زڤڕاندنا فرۆشتن', 'مرتجعات المبيعات'],
                ['زڤڕاندنا کەرەستان', 'مرتجعات المشتريات'],
                ['پارەدانێن کریاران', 'مدفوعات العملاء'],
                ['پارەدان بۆ دابینکەران', 'مدفوعات الموردين'],
                ['چوونەژوور', 'وارد'],
                ['چوونەدەر', 'صادر'],
                ['قازانجێ فرۆتنێ:', 'ربح المبيعات:'],
                ['قازانجێ زڤڕاندن:', 'ربح المرتجعات:'],
                ['ئۆپەراسیۆنی:', 'التشغيلي:'],
                ['جوملە', 'جملة'],
                ['هیچ بەرهەمێک ل ئاستێ کەم یان تەواو نینە', 'لا توجد أصناف منخفضة أو نافدة'],
                ['تەواو بوو', 'نفد'],
                ['هەڵە د بارکرنا ڕاپۆرتێ دا', 'خطأ في تحميل التقرير'],
                ['سەرەتا ڕاپۆرتێ باربکە', 'حمّل التقرير أولاً'],
                ['فایلا Excel/CSV یا پێدڤیە', 'تم تصدير الملف'],
                ['بەهایا مەخزەن', 'قيمة المخزون'],
                ['باشترین فرۆتنەکان', 'الأكثر مبيعاً'],
                ['ستافێ لاپتوب دهوک', 'طاقم Laptop Duhok'],
                ['وەشان / الإصدار:', 'الإصدار:'],
                ['ئەڤ سیستەمە ژلایێ ستافێ لاپتوب دهوک ڤە هاتیە دانان و دروستکرن.', 'تم تصميم وتطوير هذا النظام بواسطة طاقم Laptop Duhok.'],
                ['ئەم یێ ئامادەینە بۆ دروستکرنا ئەپلیکەیشنان، وێبسایتان و سیستەمێن پێشکەفتی.', 'نحن مستعدون لتطوير التطبيقات والمواقع والأنظمة المتقدمة.'],
                ['ئەگەر هەر ئاریشەک یان کێماسیەک د سیستەمی دا هەبیت، هیڤیە مە ئاگەهدار بکەن.', 'إذا واجهت أي مشكلة أو نقص في النظام، يرجى إبلاغنا.']
            ];
            var mapObj = buildUiLangMap(lang, pairs);
            var replaceText = function(text) {
                var out = replaceWithUiLangMap(text, mapObj);
                out = stripMixedSuffixes(out, lang);
                if (lang === 'ar' && typeof sanitizeArabicDisplay === 'function') out = sanitizeArabicDisplay(out);
                return out;
            };
            var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
                acceptNode: function(node) {
                    var p = node.parentElement || (node.parentNode && node.parentNode.nodeType === 1 ? node.parentNode : null);
                    if (p && (p.closest('#view-print-design') || p.closest('#company-profile-modal') || p.closest('#customer-profile-modal') || p.closest('#opening-balance-modal') || p.closest('#user-profile-modal') || p.closest('#view-staff') || p.closest('#payment-modal') || p.closest('#purchase-payment-modal') || p.closest('#pos-products') || p.closest('#returns-products') || p.closest('#purchase-products') || p.closest('#purchase-returns-products') || p.closest('#wh-products-grid') || p.closest('#products-recent-tbody') || p.closest('.unified-product-card') || p.closest('.p-card') || p.closest('.pos-entity-pick-panel') || p.closest('[data-no-i18n]') || p.closest('[data-i18n],[data-i18n-placeholder],[data-i18n-title],[data-i18n-opt]') || p.tagName === 'SCRIPT' || p.tagName === 'STYLE')) {
                        return NodeFilter.FILTER_REJECT;
                    }
                    return NodeFilter.FILTER_ACCEPT;
                }
            });
            var nodes = [];
            while (walker.nextNode()) nodes.push(walker.currentNode);
            nodes.forEach(function(n) {
                var v = n && n.nodeValue ? n.nodeValue : '';
                if (!v || !v.trim()) return;
                var mapped = replaceText(v);
                if (mapped !== v) n.nodeValue = mapped;
            });
            root.querySelectorAll('input[placeholder], textarea[placeholder]').forEach(function(el) {
                if (el.closest && (el.closest('#view-print-design') || el.closest('#company-profile-modal') || el.closest('#customer-profile-modal') || el.closest('#opening-balance-modal') || el.closest('#user-profile-modal') || el.closest('#view-staff') || el.closest('#payment-modal') || el.closest('#purchase-payment-modal'))) return;
                var ph = el.getAttribute('placeholder');
                if (el.hasAttribute('data-i18n-placeholder')) return;
                if (ph) el.setAttribute('placeholder', replaceText(ph));
            });
            root.querySelectorAll('[title]').forEach(function(el) {
                if (el.closest && (el.closest('#view-print-design') || el.closest('#company-profile-modal') || el.closest('#customer-profile-modal') || el.closest('#opening-balance-modal') || el.closest('#user-profile-modal') || el.closest('#view-staff') || el.closest('#payment-modal') || el.closest('#purchase-payment-modal'))) return;
                var tv = el.getAttribute('title');
                if (el.hasAttribute('data-i18n-title')) return;
                if (tv) el.setAttribute('title', replaceText(tv));
            });
        }
        function localizeCriticalArabicSections() {
            var ids = ['view-home', 'view-pos', 'view-debt'];
            ids.forEach(function(id) {
                var el = document.getElementById(id);
                if (el && typeof localizeHardcodedUiText === 'function') localizeHardcodedUiText(el);
            });
        }
        var __isRelocalizing = false;
        var __langRelocalizeTimer = null;
        function scheduleHardcodedRelocalize() {
            if (__isRelocalizing) return;
            if (__langRelocalizeTimer) clearTimeout(__langRelocalizeTimer);
            __langRelocalizeTimer = setTimeout(function() {
                if (__isRelocalizing) return;
                __isRelocalizing = true;
                try {
                    // Optimization: Only relocalize the current active view or main content if possible
                    var mainWrap = document.getElementById('main-content') || document.body;
                    if (typeof localizeHardcodedUiText === 'function') localizeHardcodedUiText(mainWrap);
                    if (typeof localizeCriticalArabicSections === 'function') localizeCriticalArabicSections();
                } catch(e) {}
                __isRelocalizing = false;
            }, 400); // Increased debounce to prevent flickering
        }
        function initLanguageMutationObserver() {
            try {
                if (typeof window.isPosCpuSaveMode === 'function' && window.isPosCpuSaveMode()) return;
                if (window.__posLanguageObserver) return;
                if (typeof MutationObserver === 'undefined') return;
                
                // Optimization: If the user is in Kurdish (Badini) mode, the MutationObserver is unnecessary
                // because the templates are natively Kurdish. This prevents unnecessary processing or flashes.
                var lang = (typeof getCurrentLanguage === 'function') ? getCurrentLanguage() : 'badini';
                if (lang === 'badini') return;

                var obs = new MutationObserver(function(mutations) {
                    if (__isRelocalizing) return;
                    var shouldRun = false;
                    for (var i = 0; i < mutations.length; i++) {
                        var m = mutations[i];
                        if (m.type === 'childList' && (m.addedNodes && m.addedNodes.length)) { shouldRun = true; break; }
                        if (m.type === 'characterData') {
                            // Only trigger if the text is NOT already localized
                            var target = m.target;
                            var val = (target && target.nodeValue) ? target.nodeValue.trim() : '';
                            if (val) shouldRun = true;
                            break;
                        }
                    }
                    if (shouldRun) scheduleHardcodedRelocalize();
                });
                obs.observe(document.body, { childList: true, subtree: true, characterData: true });
                window.__posLanguageObserver = obs;
            } catch(e) {}
        }
        function posLanguageApplyScopes(options) {
            options = options || {};
            var scopes = [];
            if (options.scopeLogin) {
                var loginOnly = document.getElementById('login-screen');
                if (loginOnly) return [loginOnly];
            }
            var weak = (typeof window.isPosCpuSaveMode === 'function' && window.isPosCpuSaveMode());
            if (weak) {
                var loginEl = document.getElementById('login-screen');
                if (loginEl && loginEl.style.display !== 'none') scopes.push(loginEl);
                var startupEl = document.getElementById('startup-screen');
                if (startupEl && startupEl.style.display !== 'none') scopes.push(startupEl);
                var boot = document.getElementById('app-boot-loader');
                if (boot && boot.style.display === 'flex') scopes.push(boot);
                var aw = document.querySelector('.workspace.active');
                if (aw) scopes.push(aw);
                var side = document.querySelector('.sidebar');
                if (side) scopes.push(side);
                var rside = document.getElementById('right-sidebar');
                if (rside) scopes.push(rside);
                if (!scopes.length) {
                    var wrap = document.getElementById('app-content-wrap');
                    scopes.push(wrap || document.body);
                }
            } else {
                scopes.push(document);
            }
            return scopes;
        }

        function posI18nResolved(key, currentText) {
            if (!key || typeof t !== 'function') return '';
            var val = t(key);
            if (val && val !== key) return val;
            var fb = (currentText || '').trim();
            if (fb && fb !== key) return fb;
            return val || '';
        }
        function posI18nSetText(el, val) {
            if (!el || val == null || val === '') return;
            var hasIcon = el.querySelector && el.querySelector('i.fas, i.far, i.fab, i.fa-solid, i.fa-regular, i.fa-brands');
            if (hasIcon) {
                var span = el.querySelector('span:not(.nav-item-drag-handle):not(.quick-access-drag-handle)');
                if (span && !(span.querySelector && span.querySelector('i'))) {
                    span.textContent = val;
                    return;
                }
                var lastText = null;
                for (var i = el.childNodes.length - 1; i >= 0; i--) {
                    if (el.childNodes[i].nodeType === 3 && String(el.childNodes[i].nodeValue || '').trim()) {
                        lastText = el.childNodes[i];
                        break;
                    }
                }
                if (lastText) lastText.nodeValue = ' ' + val;
                return;
            }
            el.textContent = val;
        }
        function applyI18nInRoot(root) {
            if (!root || !root.querySelectorAll) return;
            root.querySelectorAll('[data-i18n]').forEach(function(el) {
                var key = el.getAttribute('data-i18n');
                var val = posI18nResolved(key, el.textContent);
                if (val) posI18nSetText(el, val);
            });
            root.querySelectorAll('[data-i18n-placeholder]').forEach(function(el) {
                var key = el.getAttribute('data-i18n-placeholder');
                var val = posI18nResolved(key, el.getAttribute('placeholder') || '');
                if (val) el.placeholder = val;
            });
            root.querySelectorAll('[data-i18n-opt]').forEach(function(el) {
                var key = el.getAttribute('data-i18n-opt');
                var val = posI18nResolved(key, el.textContent);
                if (val) el.textContent = val;
            });
            root.querySelectorAll('[data-i18n-title]').forEach(function(el) {
                var key = el.getAttribute('data-i18n-title');
                var val = posI18nResolved(key, el.getAttribute('title') || '');
                if (val) el.title = val;
            });
            root.querySelectorAll('[data-i18n-aria-label]').forEach(function(el) {
                var keyA = el.getAttribute('data-i18n-aria-label');
                var val = posI18nResolved(keyA, el.getAttribute('aria-label') || '');
                if (val) el.setAttribute('aria-label', val);
            });
        }

        function applyLanguageLangToggleButtons(lang) {
            var btnBadini = document.getElementById('btn-lang-badini');
            var btnAr = document.getElementById('btn-lang-ar');
            if (!btnBadini || !btnAr) return;
            var iconB = btnBadini.querySelector('i.fa-check-circle');
            var iconA = btnAr.querySelector('i.fa-check-circle');
            if (lang === 'ar') {
                btnBadini.className = 'btn btn-outline'; btnBadini.style.border = '2px solid var(--border)'; btnBadini.style.background = 'transparent';
                if (iconB) iconB.style.display = 'none';
                btnAr.className = 'btn btn-primary'; btnAr.style.border = ''; btnAr.style.background = '';
                if (iconA) iconA.style.display = '';
            } else {
                btnBadini.className = 'btn btn-primary'; btnBadini.style.border = ''; btnBadini.style.background = '';
                if (iconB) iconB.style.display = '';
                btnAr.className = 'btn btn-outline'; btnAr.style.border = '2px solid var(--border)'; btnAr.style.background = 'transparent';
                if (iconA) iconA.style.display = 'none';
            }
        }

        function applyLanguage(options) {
            options = options || {};
            var lang = (typeof getCurrentLanguage === 'function') ? getCurrentLanguage() : 'badini';
            if (typeof db !== 'undefined' && db && db.settings) {
                db.settings.language = lang;
            }
            if (lang === 'badini' && window.__posLanguageObserver) {
                try {
                    window.__posLanguageObserver.disconnect();
                    window.__posLanguageObserver = null;
                } catch (eObsDisc) {}
            }
            document.documentElement.lang = (lang === 'ar') ? 'ar' : 'ku';
            document.documentElement.setAttribute('dir', 'rtl');
            document.documentElement.setAttribute('data-pos-language', lang);

            var weak = (typeof window.isPosCpuSaveMode === 'function' && window.isPosCpuSaveMode());
            if (!options.force && window.__posLastAppliedLang === lang && !options.scopeLogin) {
                applyLanguageLangToggleButtons(lang);
                return;
            }
            window.__posLastAppliedLang = lang;

            posLanguageApplyScopes(options).forEach(applyI18nInRoot);
            applyLanguageLangToggleButtons(lang);

            var workingWs = document.querySelector('.workspace.active');
            var userWorking = !!(workingWs && workingWs.id && workingWs.id.indexOf('view-') === 0
                && workingWs.id !== 'view-home' && typeof currentUser !== 'undefined' && currentUser);
            var deferNav = weak && options.deferNav !== false;
            var paintNav = function () {
                if (!userWorking && typeof renderHomeView === 'function') renderHomeView();
                if (typeof renderRightSidebar === 'function') renderRightSidebar();
                if (typeof renderMainNav === 'function') renderMainNav();
            };
            if (!options.skipNavPaint && !userWorking) {
                if (deferNav) {
                    var navMs = options.deferNavMs;
                    if (navMs == null) {
                        navMs = (options.scopeLogin && typeof posLoginDeferMs === 'function') ? posLoginDeferMs(180) : 400;
                    }
                    setTimeout(paintNav, navMs);
                } else {
                    paintNav();
                }
            }

            if (lang === 'ar') {
                var arRoot = weak ? (document.querySelector('.workspace.active') || document.getElementById('login-screen') || document.body) : document.body;
                if (typeof localizeHardcodedUiText === 'function') localizeHardcodedUiText(arRoot);
                ['view-pos', 'view-dash', 'view-home', 'view-warehouse', 'view-settings'].forEach(function (vid) {
                    var el = document.getElementById(vid);
                    if (el && typeof localizeHardcodedUiText === 'function') localizeHardcodedUiText(el);
                });
                if (!weak && typeof localizeCriticalArabicSections === 'function') localizeCriticalArabicSections();
                if (!weak && typeof enforceTranslatedCoreMenus === 'function') enforceTranslatedCoreMenus();
                if (!weak) scheduleHardcodedRelocalize();
                if (!weak && !(typeof window.isPosCpuSaveMode === 'function' && window.isPosCpuSaveMode())) {
                    if (typeof initLanguageMutationObserver === 'function') initLanguageMutationObserver();
                }
                try {
                    var cpAr = document.getElementById('company-profile-modal');
                    if (cpAr && cpAr.style.display === 'flex' && typeof applyCompanyProfileUi === 'function') applyCompanyProfileUi();
                    var rwAr = document.getElementById('modal-restore-warning');
                    if (rwAr && rwAr.style.display === 'flex' && typeof applySettingsStaticUi === 'function') applySettingsStaticUi(rwAr);
                    var dbAr = document.getElementById('modal-db-manage');
                    if (dbAr && dbAr.style.display === 'flex' && typeof applySettingsStaticUi === 'function') applySettingsStaticUi(dbAr);
                } catch (eCpProfAr) {}
            }
            if (lang === 'badini') {
                try {
                    var vsetBd = document.getElementById('view-settings');
                    if (vsetBd && vsetBd.classList.contains('active') && typeof applySettingsStaticUi === 'function') applySettingsStaticUi();
                    var cpBd = document.getElementById('company-profile-modal');
                    if (cpBd && cpBd.style.display === 'flex' && typeof applyCompanyProfileUi === 'function') applyCompanyProfileUi();
                } catch (eMegaBd) {}
            }
            if (typeof updateCurrencyLockUI === 'function') updateCurrencyLockUI();
            var settingsActive = document.getElementById('view-settings') && document.getElementById('view-settings').classList.contains('active');
            if (!weak || settingsActive) {
                if (typeof applyProductFormFieldLabels === 'function' && db && db.settings) applyProductFormFieldLabels();
                if (typeof refreshBusinessDayStartHourControlState === 'function') refreshBusinessDayStartHourControlState();
                if (typeof applyPremiumSettingsUI === 'function') applyPremiumSettingsUI();
            }
            try {
                var vp = document.getElementById('view-products');
                if (vp && vp.classList.contains('active') && typeof renderProducts === 'function') {
                    var pinp = document.getElementById('products-search-input');
                    renderProducts(pinp ? (pinp.value || '') : '');
                }
            } catch (eProdLang) {}
            try {
                var vwh = document.getElementById('view-warehouse');
                if (vwh && vwh.classList.contains('active')) {
                    if (typeof renderWmsWarehouseHub === 'function') renderWmsWarehouseHub();
                    if (typeof renderWarehouse === 'function') renderWarehouse();
                }
            } catch (eWhLang) {}
            try {
                var vc = document.getElementById('view-companies');
                if (vc && vc.classList.contains('active')) {
                    if (typeof renderCompaniesView === 'function') renderCompaniesView();
                    else if (typeof renderCompanies === 'function') renderCompanies();
                }
            } catch (eCompLang) {}
            try {
                var vdash = document.getElementById('view-dash');
                if (vdash && vdash.classList.contains('active')) {
                    if (typeof renderSalesChart === 'function') renderSalesChart();
                    if (typeof updateStats === 'function') updateStats();
                }
            } catch (eDashChartLang) {}
            try {
                var vpos = document.getElementById('view-pos');
                if (vpos && vpos.classList.contains('active')) {
                    if (typeof renderPOSCategories === 'function') renderPOSCategories();
                    var posSearch = document.getElementById('pos-barcode-input');
                    if (typeof renderPOSMenu === 'function') renderPOSMenu(posSearch ? (posSearch.value || '') : '');
                    if (typeof renderBill === 'function') renderBill();
                }
            } catch (ePosLang) {}
            try {
                var stEl = document.getElementById('right-sidebar-status');
                if (stEl && typeof updateSaveStatus === 'function') {
                    updateSaveStatus(!stEl.classList.contains('disconnected'));
                }
            } catch (eDbStatusLang) {}
            try {
                var vexp = document.getElementById('view-expenses');
                if (vexp && vexp.classList.contains('active') && typeof renderExpenses === 'function') renderExpenses();
            } catch (eExpLang) {}
            try {
                var vdel = document.getElementById('view-delivery');
                if (vdel && vdel.classList.contains('active') && typeof renderDeliveries === 'function') renderDeliveries();
            } catch (eDelLang) {}
            try {
                var vwaste = document.getElementById('view-waste');
                if (vwaste && vwaste.classList.contains('active')) {
                    if (typeof renderWasteList === 'function') renderWasteList();
                    if (typeof renderWasteCandidates === 'function') renderWasteCandidates();
                }
            } catch (eWasteLang) {}
            try {
                var vcal = document.getElementById('view-calendar');
                if (vcal && vcal.classList.contains('active') && typeof renderWorkCalendar === 'function') {
                    renderWorkCalendar();
                }
            } catch (eCalLang) {}
            try {
                var vst = document.getElementById('view-staff');
                if (vst && vst.classList.contains('active')) {
                    if (typeof refreshStaffRoleSelects === 'function') refreshStaffRoleSelects();
                    if (typeof renderUsers === 'function') renderUsers();
                    if (typeof renderShifts === 'function') renderShifts();
                }
            } catch (eStaffLang) {}
            try {
                var vset = document.getElementById('view-settings');
                if (vset && vset.classList.contains('active')) {
                    if (typeof renderHomeIconsSettings === 'function') renderHomeIconsSettings();
                    if (typeof updateFirebaseSyncUI === 'function') updateFirebaseSyncUI();
                    if (typeof applySettingsAboutUi === 'function') applySettingsAboutUi();
                    if (typeof applySettingsStaticUi === 'function') applySettingsStaticUi();
                }
            } catch (eSettingsLang) {}
            try {
                var vnot = document.getElementById('view-notifications');
                if (vnot && vnot.classList.contains('active') && typeof renderNotifications === 'function') renderNotifications();
            } catch (eNotLang) {}
            try {
                var upModal = document.getElementById('user-profile-modal');
                if (upModal && upModal.style.display === 'flex') {
                    var eid = document.getElementById('edit-u-id');
                    if (eid && eid.value && typeof openUserProfile === 'function') {
                        openUserProfile(parseInt(eid.value, 10));
                    }
                }
            } catch (eProfileLang) {}
            try {
                var cpModalLang = document.getElementById('company-profile-modal');
                if (cpModalLang && cpModalLang.style.display === 'flex' && currentViewingCompanyId && typeof openCompanyProfile === 'function') {
                    openCompanyProfile(currentViewingCompanyId);
                }
            } catch (eCompProfLang) {}
            try {
                var custModalLang = document.getElementById('customer-profile-modal');
                if (custModalLang && custModalLang.style.display === 'flex' && typeof currentViewingCustomerId !== 'undefined' && currentViewingCustomerId && typeof openCustomerProfile === 'function') {
                    openCustomerProfile(currentViewingCustomerId);
                }
            } catch (eCustProfLang) {}
            try {
                var payModalLang = document.getElementById('payment-modal');
                if (payModalLang && payModalLang.style.display === 'flex') {
                    var pg = payModalLang.querySelector('.pay-modal-glass');
                    if (pg && typeof applyI18nSubtree === 'function') applyI18nSubtree(pg);
                    if (typeof applyCurrencyModeUiText === 'function') applyCurrencyModeUiText();
                }
            } catch (ePayModalLang) {}
            try {
                var ppayModalLang = document.getElementById('purchase-payment-modal');
                if (ppayModalLang && ppayModalLang.style.display === 'flex') {
                    var ppg = ppayModalLang.querySelector('.pay-modal-glass');
                    if (ppg && typeof applyI18nSubtree === 'function') applyI18nSubtree(ppg);
                    if (typeof applyCurrencyModeUiText === 'function') applyCurrencyModeUiText();
                }
            } catch (ePPayModalLang) {}
            try {
                var fbModal = document.getElementById('firebase-cashier-auth-modal');
                if (fbModal && fbModal.style.display === 'flex' && typeof window.applyI18nSubtree === 'function') {
                    var fbCard = document.getElementById('firebase-cashier-auth-card');
                    if (fbCard) window.applyI18nSubtree(fbCard);
                }
            } catch (eFbModalLang) {}
            try {
                var vPrintDesign = document.getElementById('view-print-design');
                if (vPrintDesign && vPrintDesign.classList.contains('active')) {
                    if (typeof db !== 'undefined' && db && db.settings && typeof applyPrintDesignSettings === 'function') {
                        applyPrintDesignSettings();
                    } else if (typeof renderPrintersList === 'function') {
                        renderPrintersList();
                    }
                    if (typeof updateReceiptPreview === 'function') updateReceiptPreview();
                }
            } catch (ePrintDesignLang) {}
            try {
                if (typeof renderBreadcrumb === 'function') renderBreadcrumb();
            } catch (eBreadcrumbLang) {}
            try {
                if (typeof applyI18nSubtree === 'function') applyI18nSubtree(document.body);
            } catch (eFinalI18n) {}
        }
        function applyI18nSubtree(root) {
            if (!root || !root.querySelectorAll) return;
            applyI18nInRoot(root);
            if (typeof applyPosPremiumPricingLabels === 'function') applyPosPremiumPricingLabels(root);
            if (typeof updateProductFormAlternatePriceHeader === 'function') updateProductFormAlternatePriceHeader();
        }
        if (typeof window !== 'undefined') window.applyI18nSubtree = applyI18nSubtree;
        /** Startup screen is visible before connectToDB — localize from localStorage immediately. */
        function applyStartupScreenLanguageEarly() {
            try {
                var L = (typeof getCurrentLanguage === 'function') ? getCurrentLanguage() : 'badini';
                if (typeof document !== 'undefined' && document.documentElement) {
                    document.documentElement.lang = (L === 'ar') ? 'ar' : 'ku';
                    document.documentElement.setAttribute('data-pos-language', L);
                }
                var st = typeof document !== 'undefined' ? document.getElementById('startup-screen') : null;
                if (st && typeof applyI18nSubtree === 'function') applyI18nSubtree(st);
                var lg = typeof document !== 'undefined' ? document.getElementById('login-screen') : null;
                if (lg && typeof applyI18nSubtree === 'function') applyI18nSubtree(lg);
            } catch (eEarlyLang) {}
        }
        if (typeof document !== 'undefined') {
            document.addEventListener('DOMContentLoaded', applyStartupScreenLanguageEarly);
            if (document.readyState !== 'loading') applyStartupScreenLanguageEarly();
        }
        function enforceTranslatedCoreMenus() {
            var lang = (typeof getCurrentLanguage === 'function') ? getCurrentLanguage() : ((typeof db !== 'undefined' && db && db.settings && db.settings.language) ? db.settings.language : 'badini');
            var targetIds = [
                'products', 'purchase', 'purchase-returns', 'warehouse', 'companies', 'delivery',
                'expenses', 'waste', 'recipes', 'calendar', 'notifications',
                'staff', 'settings', 'print-design', 'print-history'
            ];
            targetIds.forEach(function(id) {
                var label = (typeof getBreadcrumbLabel === 'function') ? getBreadcrumbLabel(id) : id;
                var navKey = (typeof getNavLabelI18nKey === 'function') ? getNavLabelI18nKey(id) : ('nav_' + id.replace(/-/g, '_'));
                // Main left nav
                var navEl = document.getElementById('nav-' + id);
                if (navEl) {
                    var txt = navEl.querySelector('span[data-i18n="' + navKey + '"]') || navEl.querySelector('span[data-i18n]') || navEl.querySelector('span:not(.nav-item-drag-handle)');
                    if (txt) txt.textContent = label;
                }
                // Right sidebar shortcuts (label span before optional badge)
                var rightItem = document.querySelector('.right-nav-item[data-nav="' + id + '"]');
                var rightEl = rightItem ? rightItem.querySelector('span[data-i18n="' + navKey + '"]') : null;
                if (!rightEl && rightItem) {
                    rightEl = rightItem.querySelector('.quick-access-drag-handle + span[data-i18n]');
                }
                if (!rightEl && rightItem) {
                    rightEl = rightItem.querySelector('.quick-access-drag-handle + span');
                }
                if (rightEl) rightEl.textContent = label;
                // Home dashboard cards
                var homeCard = document.querySelector('#home-grid-container .home-card[data-nav="' + id + '"] span[data-i18n="' + navKey + '"]');
                if (!homeCard) homeCard = document.querySelector('#home-grid-container .home-card[data-nav="' + id + '"] .quick-access-drag-handle + span');
                if (homeCard) homeCard.textContent = label;
            });
            // Enforce one-language-only titles for both Arabic and Badini.
            var idsToKeys = [
                ['view-products', 'view_products_title'],
                ['view-purchase', 'view_purchase_title'],
                ['view-purchase-returns', 'view_purchase_returns_title'],
                ['view-warehouse', 'view_warehouse_title'],
                ['view-companies', 'view_companies_title'],
                ['view-delivery', 'view_delivery_title'],
                ['view-expenses', 'view_expenses_title'],
                ['view-calendar', 'nav_calendar'],
                ['view-notifications', 'nav_notifications'],
                ['view-staff', 'nav_staff'],
                ['view-settings', 'settings_title'],
                ['view-print-design', 'nav_print_design'],
                ['view-print-history', 'view_print_history_title'],
                ['view-waste', 'nav_waste'],
                ['view-recipes', 'nav_recipes']
            ];
            idsToKeys.forEach(function(pair) {
                var root = document.getElementById(pair[0]);
                if (!root) return;
                var h = root.querySelector('h1, h2, h3');
                if (h && typeof t === 'function') {
                    var span = h.querySelector('[data-i18n="' + pair[1] + '"]');
                    if (span) {
                        span.textContent = t(pair[1]);
                    } else {
                        var icon = h.querySelector('i');
                        var iconHtml = icon ? icon.outerHTML + ' ' : '';
                        h.innerHTML = iconHtml + '<span data-i18n="' + pair[1] + '">' + t(pair[1]) + '</span>';
                    }
                }
            });
        }
        function setUILanguage(lang) {
            if (lang !== 'badini' && lang !== 'ar') return;
            var currentLang = (typeof getCurrentLanguage === 'function') ? getCurrentLanguage() : null;
            if (currentLang === lang) return;
            if (typeof db !== 'undefined' && db && db.settings) db.settings.language = lang;
            try { localStorage.setItem('pos_language', lang); } catch(e) {}
            document.documentElement.lang = (lang === 'ar') ? 'ar' : 'ku';
            document.documentElement.setAttribute('dir', 'rtl');
            document.documentElement.setAttribute('data-pos-language', lang);
            if (typeof applyLanguage === 'function') applyLanguage();
            if (typeof showToast === 'function') {
                showToast((lang === 'ar')
                    ? 'تم تفعيل العربية لواجهة النظام (بدون إعادة تحميل الصفحة).'
                    : 'زمانەکە گۆڕدرا بۆ بادینی.');
            }
            try {
                if (typeof renderBreadcrumb === 'function') renderBreadcrumb();
                if (typeof updateStats === 'function') updateStats();
            } catch (eSync) {}
            if (typeof saveSettings === 'function') {
                try { saveSettings(); } catch(e) {}
            }
        }
        /** Return locale for date/number formatting based on current UI language (for print & reports). */
        function getDateLocale() {
            var lang = (typeof getCurrentLanguage === 'function') ? getCurrentLanguage() : 'badini';
            return (lang === 'ar') ? 'ar-IQ' : 'ku';
        }
        /** Profile / shift tables: 24h time so Latin AM/PM does not appear in RTL UI. */
        function formatProfileTime(d, locale) {
            if (!(d instanceof Date) || isNaN(d.getTime())) return '';
            var tz = (typeof window.POS_TIMEZONE === 'string') ? window.POS_TIMEZONE : 'Asia/Baghdad';
            return d.toLocaleTimeString(locale, { timeZone: tz, hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
        }
        function formatProfileDate(d, locale) {
            if (!(d instanceof Date) || isNaN(d.getTime())) return '';
            var tz = (typeof window.POS_TIMEZONE === 'string') ? window.POS_TIMEZONE : 'Asia/Baghdad';
            return d.toLocaleDateString(locale, { timeZone: tz, year: 'numeric', month: 'short', day: 'numeric' });
        }
        function formatProfileDateTime(d, locale) {
            if (!(d instanceof Date) || isNaN(d.getTime())) return '';
            if (typeof window.formatPosDateTime === 'function') return window.formatPosDateTime(d, locale);
            return formatProfileDate(d, locale) + ' ' + formatProfileTime(d, locale);
        }
        window.getDateLocale = getDateLocale;
        window.formatProfileDateTime = formatProfileDateTime;
        window.formatProfileTime = formatProfileTime;
        window.formatProfileDate = formatProfileDate;
        function runLanguageIsolationAudit(root) {
            try {
                var lang = getCurrentLanguage();
                var target = root || document.body;
                if (!target) return { scanned: 0, mixed: 0 };
                var sourceMap = buildUiLangMap(lang, []);
                var keys = sourceMap.sortedKeys || [];
                var mixed = 0;
                var scanned = 0;
                var walker = document.createTreeWalker(target, NodeFilter.SHOW_TEXT, null);
                while (walker.nextNode()) {
                    var node = walker.currentNode;
                    var txt = (node && node.nodeValue) ? String(node.nodeValue) : '';
                    if (!txt || !txt.trim()) continue;
                    scanned++;
                    if (txt.indexOf(' / ') !== -1 || /.+\(.+\)/.test(txt)) mixed++;
                    for (var i = 0; i < keys.length; i++) {
                        if (txt.indexOf(keys[i]) !== -1) break;
                    }
                }
                try {
                    if (localStorage.getItem('pos_lang_audit') === '1') {
                        console.info('[language-audit]', { lang: lang, scanned: scanned, mixed: mixed });
                    }
                } catch(e) {}
                return { lang: lang, scanned: scanned, mixed: mixed };
            } catch (e) {
                return { scanned: 0, mixed: 0, error: String(e && e.message || e) };
            }
        }
        window.applyLanguage = applyLanguage;
        window.setUILanguage = setUILanguage;
        window.runLanguageIsolationAudit = runLanguageIsolationAudit;
        // Ensure backend can return language-specific responses and capture return invoice refs.
        (function patchFetchLanguagePropagation() {
            try {
                if (window.__posFetchPatched) return;
                var _fetch = window.fetch.bind(window);
                window.fetch = function(input, init) {
                    var finalInput = input;
                    var finalInit = init;
                    var requestAction = '';
                    try {
                        // Never mutate Request objects or non-plain init: pass-through is safest.
                        var isStringInput = typeof input === 'string';
                        var isPlainInit = !!init && Object.prototype.toString.call(init) === '[object Object]';
                        var req = isPlainInit ? Object.assign({}, init) : init;
                        var method = ((req && req.method) || (input && input.method) || 'GET').toUpperCase();
                        var url = isStringInput ? input : '';
                        if (url && typeof url === 'string' && /localhost:\d+/i.test(url)) {
                            url = url.replace(/https?:\/\/localhost(?=:\d+)/gi, function (m) {
                                return /^https:/i.test(m) ? 'https://127.0.0.1' : 'http://127.0.0.1';
                            });
                            finalInput = url;
                        }

                        // Language patch for same-app URLs only.
                        var lang = getCurrentLanguage();
                        var sameApp = isStringInput && (url.indexOf('?action=') !== -1 || url.indexOf('api/all.php') !== -1 || url === '' || url.indexOf(window.location.origin) === 0 || url.indexOf('/') === 0);
                        if (sameApp) {
                            if (method === 'GET' && url) {
                                var hasLang = /([?&])language=/.test(url);
                                if (!hasLang) url += (url.indexOf('?') >= 0 ? '&' : '?') + 'language=' + encodeURIComponent(lang);
                                finalInput = url;
                            } else if (req && req.body && typeof FormData !== 'undefined' && req.body instanceof FormData) {
                                if (!req.body.has('language')) req.body.append('language', lang);
                            }
                        }
                        if (sameApp && isPlainInit && req && typeof Headers !== 'undefined') {
                            try {
                                var _dk = window.__posDeviceKey || '';
                                try { if (!_dk && localStorage) _dk = localStorage.getItem('pos_client_device_key') || ''; } catch (_eDk) {}
                                if (_dk) {
                                    var _posDevHdr = new Headers(req.headers || undefined);
                                    if (!_posDevHdr.has('X-POS-Device-Key')) _posDevHdr.set('X-POS-Device-Key', _dk);
                                    req.headers = _posDevHdr;
                                }
                            } catch (_ePosDevH) { /* noop */ }
                        }

                        // Returns patch for save_return form payloads.
                        if (req && req.body && typeof FormData !== 'undefined' && req.body instanceof FormData && req.body.get('action') === 'save_return') {
                            var viewReturnsNew = document.getElementById('view-returns-new');
                            if (viewReturnsNew && viewReturnsNew.classList.contains('active')) {
                                var invEl = document.getElementById('returns-new-invoice-ref');
                                if (invEl && invEl.value) {
                                    if (!req.body.has('sale_id') || !req.body.get('sale_id')) req.body.set('sale_id', invEl.value.trim());
                                    var note = req.body.get('note') || '';
                                    if (note.indexOf('[Ref:') === -1) req.body.set('note', '[Ref: ' + invEl.value.trim() + '] ' + note);
                                }
                                var debtSel = document.getElementById('returns-debt-select');
                                if (debtSel && debtSel.value) {
                                    var parts = debtSel.value.split('_');
                                    if (parts.length === 2) {
                                        if (!req.body.has('target_type')) req.body.append('target_type', parts[0]); else req.body.set('target_type', parts[0]);
                                        if (!req.body.has('target_id')) req.body.append('target_id', parts[1]); else req.body.set('target_id', parts[1]);
                                        if (!req.body.has('sale_id') || !req.body.get('sale_id')) {
                                            if (!req.body.has('payment_method')) req.body.append('payment_method', 'debt'); else req.body.set('payment_method', 'debt');
                                        }
                                    }
                                }
                            }
                        }

                        // FX snapshot: persist settings usdRate/currencyMode on financial writes (see api/all.php).
                        if (req && req.body && typeof FormData !== 'undefined' && req.body instanceof FormData) {
                            var fxAct = req.body.get('action');
                            requestAction = String(fxAct || '');
                            if (fxAct === 'save_return' || fxAct === 'save_supply' || fxAct === 'save_purchase_return' || fxAct === 'process_payment' || fxAct === 'save_purchase_invoice' || fxAct === 'save_expense' || fxAct === 'update_expense' || fxAct === 'save_waste' || fxAct === 'save_ledger') {
                                if (typeof db !== 'undefined' && db && db.settings) {
                                    var fxR = Math.round(Number(db.settings.usdRate) || 0);
                                    if (fxAct === 'save_return' && req.body.get('sale_id') && db.sales) {
                                        var sidFx = parseInt(req.body.get('sale_id'), 10) || 0;
                                        if (sidFx > 0) {
                                            var sFx = db.sales.find(function(s) { return parseInt(s.id, 10) === sidFx; });
                                            if (sFx && sFx.fx_usd_rate != null) {
                                                var snapFx = Math.round(Number(sFx.fx_usd_rate) || 0);
                                                if (snapFx >= 1000) fxR = snapFx;
                                            }
                                        }
                                    }
                                    if (fxR > 0 && !req.body.has('fx_usd_rate')) req.body.append('fx_usd_rate', String(fxR));
                                    var fxCm = db.settings.currencyMode;
                                    if ((fxCm === 'USD' || fxCm === 'IQD') && !req.body.has('fx_currency_mode')) req.body.append('fx_currency_mode', fxCm);
                                }
                            }
                        }

                        finalInit = req;
                    } catch (e) {
                        finalInput = input;
                        finalInit = init;
                    }
                    function shouldAutoRefreshAfterSuccess(act) {
                        if (!act) return false;
                        if (act === 'update_table_items' || act === 'update_customer_display' || act === 'logout') return false;
                        return /^(save_|update_|delete_|void_|return_)/.test(act) || act === 'process_payment';
                    }
                    function queueServerRefresh() {
                        if (window.__posAutoRefreshTimer) clearTimeout(window.__posAutoRefreshTimer);
                        var _fastLan = (typeof isPosFastLanSync === 'function' && isPosFastLanSync());
                        var _isProductWrite = /^(save_product|update_product)$/.test(requestAction);
                        var _delay = (_fastLan || _isProductWrite)
                            ? 50
                            : ((typeof posAfterWriteRefreshDelayMs === 'function')
                                ? posAfterWriteRefreshDelayMs(requestAction)
                                : ((typeof posAutoRefreshDelayMs === 'function') ? posAutoRefreshDelayMs() : 140));
                        var _useLightSync = _fastLan || _isProductWrite || ((typeof isPosCpuSaveMode === 'function' && isPosCpuSaveMode())
                            && (typeof posAfterWriteRefreshDelayMs === 'function')
                            && _delay <= 500);
                        if (_useLightSync) {
                            window.__posAutoRefreshTimer = setTimeout(function () {
                                window.__posAutoRefreshTimer = null;
                                if (typeof syncLiveData === 'function') syncLiveData(false);
                            }, _delay);
                            return;
                        }
                        if (typeof isPosCpuSaveMode === 'function' && isPosCpuSaveMode()) {
                            window.__posAutoRefreshTimer = setTimeout(function () {
                                window.__posAutoRefreshTimer = null;
                                if (typeof syncLiveData === 'function') syncLiveData(false);
                            }, _delay);
                            return;
                        }
                        if (typeof connectToDB !== 'function') return;
                        window.__posAutoRefreshTimer = setTimeout(function () {
                            window.__posAutoRefreshTimer = null;
                            connectToDB(true, { skipRenderOnRefresh: true });
                        }, _delay);
                    }

                    function clonePosFetchInit(init) {
                        if (!init) return undefined;
                        var out = {};
                        Object.keys(init).forEach(function (k) { out[k] = init[k]; });
                        if (init.body && typeof FormData !== 'undefined' && init.body instanceof FormData) {
                            var fd = new FormData();
                            init.body.forEach(function (v, k) { fd.append(k, v); });
                            out.body = fd;
                        }
                        return out;
                    }
                    var isWriteAction = shouldAutoRefreshAfterSuccess(requestAction);
                    var retryInit = isWriteAction ? clonePosFetchInit(finalInit) : null;
                    function posWriteFetchOnce(init) {
                        return (typeof init === 'undefined') ? _fetch(finalInput) : _fetch(finalInput, init);
                    }
                    function posIsTransientFetchError(err) {
                        var msg = err && (err.message || err.name) ? String(err.message || err.name) : '';
                        return /Failed to fetch|NetworkError|TypeError|abort/i.test(msg);
                    }
                    var fetchPromise = posWriteFetchOnce(finalInit);
                    if (retryInit) {
                        fetchPromise = fetchPromise.catch(function (err) {
                            if (!posIsTransientFetchError(err)) throw err;
                            if (retryInit.body && typeof FormData !== 'undefined' && retryInit.body instanceof FormData) {
                                if (!retryInit.body.has('save_retry')) retryInit.body.append('save_retry', '1');
                            }
                            return new Promise(function (resolve) { setTimeout(resolve, 400); }).then(function () {
                                return posWriteFetchOnce(retryInit);
                            }).catch(function (err2) {
                                if (!posIsTransientFetchError(err2)) throw err2;
                                return new Promise(function (resolve) { setTimeout(resolve, 800); }).then(function () {
                                    return posWriteFetchOnce(clonePosFetchInit(retryInit) || retryInit);
                                });
                            });
                        });
                    }
                    if (!shouldAutoRefreshAfterSuccess(requestAction)) return fetchPromise;
                    return fetchPromise.then(function(resp) {
                        try {
                            resp.clone().json().then(function(payload) {
                                if (payload && payload.status === 'success') queueServerRefresh();
                            }).catch(function() {});
                        } catch (e) {}
                        return resp;
                    });
                };
                window.__posFetchPatched = true;
            } catch (e) {}
        })();

        /** Display name for header/sidebar: show "مدير" instead of "Manager". */
        function getUserDisplayLabel(u) {
            if (!u) return '';
            var n = (u.name === 'Manager') ? 'مدير' : (u.name || '');
            return n + ' (' + (u.role || '') + ')';
        }

        function addToPrice(amount) {
            const input = document.getElementById('p-price');
            if (!input) return;
            var current = (typeof productFormParseNumericField === 'function')
                ? (productFormParseNumericField('p-price') || 0)
                : (parseFloat(String(input.value || '').replace(/,/g, '')) || 0);
            var add = amount;
            if (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD') {
                var r = typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0;
                add = r > 0 ? (amount / r) : 0;
            }
            input.value = productFormFormatDerivedField(current + add);
        }

