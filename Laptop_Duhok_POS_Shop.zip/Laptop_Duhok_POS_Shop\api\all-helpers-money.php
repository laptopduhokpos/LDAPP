<?php
// Money, installment, product price helpers
// --- HELPER: Safe numeric - prevents NaN/Invalid in calculations ---
function safeFloat($v, $default = 0) { $f = (float)$v; return (is_nan($f) || !is_finite($f)) ? (float)$default : $f; }
function safeInt($v, $default = 0) { $i = (int)$v; return ($i < 0 && $v > 0) ? (int)$default : $i; }
/**
 * Money normalization using integer math on string input.
 * IQD internal precision: 3 decimals (1 IQD = 1000 minor units).
 * This removes float rounding drift in repeated calculations.
 */
function moneyToMinor($value, $scale = 3) {
    $s = trim((string)$value);
    if ($s === '') return 0;
    $s = str_replace(',', '', $s);
    if (!preg_match('/^-?\d+(\.\d+)?$/', $s)) {
        $s = preg_replace('/[^0-9\.\-]/', '', $s);
        if ($s === '' || $s === '-' || $s === '.' || $s === '-.') return 0;
    }
    $neg = false;
    if (strpos($s, '-') === 0) {
        $neg = true;
        $s = substr($s, 1);
    }
    $parts = explode('.', $s, 2);
    $intPart = preg_replace('/\D/', '', $parts[0] ?? '0');
    if ($intPart === '') $intPart = '0';
    $fracRaw = isset($parts[1]) ? preg_replace('/\D/', '', $parts[1]) : '';
    $frac = substr(str_pad($fracRaw, $scale, '0'), 0, $scale);
    $base = 1;
    for ($i = 0; $i < $scale; $i++) $base *= 10;
    $minor = ((int)$intPart * $base) + (int)$frac;
    return $neg ? -$minor : $minor;
}

function moneyFromMinor($minor, $scale = 3) {
    $m = (int)$minor;
    $neg = $m < 0;
    if ($neg) $m = -$m;
    $base = 1;
    for ($i = 0; $i < $scale; $i++) $base *= 10;
    $intPart = intdiv($m, $base);
    $frac = $m % $base;
    $fracStr = str_pad((string)$frac, $scale, '0', STR_PAD_LEFT);
    return ($neg ? '-' : '') . $intPart . '.' . $fracStr;
}

function normalizeMoney($value, $scale = 3) {
    return moneyFromMinor(moneyToMinor($value, $scale), $scale);
}

function moneyMinorToMajor($minor, $scale = 3) {
    return (float) moneyFromMinor((int)$minor, $scale);
}

// Legacy API name kept for compatibility in codebase.
function roundMoney($v) { return (float) normalizeMoney($v, 3); }

function pos_pieces_in_sale_unit(array $p, $saleUnit) {
    if ($saleUnit === 'piece' || $saleUnit === '' || $saleUnit === null) return 1.0;
    $ppp = max(1, (int)($p['pieces_per_pack'] ?? 1));
    $ppc = max(1, (int)($p['packs_per_carton'] ?? 1));
    if ($saleUnit === 'carton') {
        if (!empty($p['itemsPerCarton'])) return max(1.0, (float)$p['itemsPerCarton']);
        return (float)($ppp * $ppc);
    }
    if ($saleUnit === 'pack') return (float)$ppp;
    return 1.0;
}

function pos_is_usd_currency_system($conn = null) {
    if ($conn === null) {
        global $conn;
    }
    if (!function_exists('pos_load_app_settings_array') || !function_exists('pos_settings_currency_mode_from_array')) {
        return false;
    }
    if (!$conn) {
        return false;
    }
    $settings = pos_load_app_settings_array($conn);
    return pos_settings_currency_mode_from_array($settings) === 'USD';
}

function pos_is_iqd_currency_system($conn = null) {
    return !pos_is_usd_currency_system($conn);
}

function pos_fx_rate_per_one_for_cogs() {
    if (function_exists('pos_load_app_settings_array') && function_exists('pos_settings_usd_rate_per_one_from_array')) {
        static $cached = null;
        if ($cached !== null) {
            return $cached;
        }
        global $conn;
        $settings = (isset($conn) && $conn) ? pos_load_app_settings_array($conn) : [];
        $cached = (float)pos_settings_usd_rate_per_one_from_array($settings);
        return $cached;
    }
    return 1500.0;
}

/** Kept for old callers. Never converts — IQD and USD stay isolated. */
function pos_iqd_cost_lift_from_usd($costIqd, $costUsd = 0, $ratePerOne = 0, $linePrice = 0) {
    return (float)$costIqd;
}

function pos_catalog_cost_for_sale_unit(array $p, $saleUnit) {
    $pieceCost = (float)($p['cost'] ?? 0);
    if ($saleUnit === 'piece' || $saleUnit === '' || $saleUnit === null) {
        return $pieceCost;
    }
    // Free / gift remaining stock (piece cost 0) stays 0 for pack/carton — do not
    // fall back to a stale cost_pack / cost_carton from an older paid purchase.
    if ($pieceCost <= 0) {
        return 0.0;
    }
    $mult = pos_pieces_in_sale_unit($p, $saleUnit);
    $unitField = $saleUnit === 'carton' ? (float)($p['cost_carton'] ?? 0) : (float)($p['cost_pack'] ?? 0);
    $fromPiece = $pieceCost * $mult;
    if ($fromPiece > 0 && $unitField > 0) {
        $diff = $unitField - $fromPiece;
        if ($diff >= 0 && $diff < max(1.0, $mult)) {
            return $unitField;
        }
        return $fromPiece;
    }
    return $fromPiece > 0 ? $fromPiece : $unitField;
}

/**
 * Buy price the merchant typed for this sale unit.
 * Used as a floor when FIFO runs out (oversell / 0 cartons in stock).
 * Gift remaining stock (piece cost 0) stays 0.
 */
function pos_entered_catalog_cost_for_sale_unit(array $p, $saleUnit) {
    $pieceCost = (float)($p['cost'] ?? 0);
    if ($pieceCost <= 0) {
        return 0.0;
    }
    $su = (string)$saleUnit;
    if ($su === 'carton') {
        $c = (float)($p['cost_carton'] ?? 0);
        if ($c > 0) {
            return $c;
        }
    } elseif ($su === 'pack') {
        $c = (float)($p['cost_pack'] ?? 0);
        if ($c > 0) {
            return $c;
        }
    }
    return pos_catalog_cost_for_sale_unit($p, $su);
}

/** True when stamped COGS is only leftover warehouse pieces at piece cost — not a full pack/carton. */
function pos_sale_line_looks_like_partial_piece_cogs($unitCost, $lineQty, $pieceCost, $needPieces) {
    $pieceCost = (float)$pieceCost;
    $lineQty = (float)$lineQty;
    $needPieces = (float)$needPieces;
    $unitCost = (float)$unitCost;
    if ($pieceCost <= 0.00001 || $lineQty <= 0 || $needPieces <= 1.000001) {
        return false;
    }
    $cogs = $unitCost * $lineQty;
    $covered = $cogs / $pieceCost;
    if ($covered >= ($needPieces - 0.5)) {
        return false;
    }
    $n = (int)round($covered);
    if ($n < 0) {
        return false;
    }
    $tol = max(1.0, $pieceCost * 0.05);
    return abs($cogs - ($pieceCost * $n)) <= $tol;
}

/** True when the sale line stored a numeric cost, including explicit 0 (free gift lot). */
function pos_sale_line_has_explicit_cost(array $it) {
    if (!array_key_exists('cost', $it)) {
        return false;
    }
    $v = $it['cost'];
    if ($v === null || $v === '') {
        return false;
    }
    return is_numeric($v);
}

/**
 * COGS per sale line from stored IQD cost only. No USD, no rate.
 * Explicit 0 (bonus / free gift purchase lot) is valid and must not fall back to catalog.
 */
function pos_resolve_sale_line_cost(array $it, array $productsById) {
    $saleUnit = isset($it['saleUnit']) ? (string)$it['saleUnit'] : 'piece';
    $pid = isset($it['id']) ? (int)$it['id'] : 0;
    $p = ($pid > 0 && isset($productsById[$pid])) ? $productsById[$pid] : null;
    $catalog = $p ? pos_catalog_cost_for_sale_unit($p, $saleUnit) : 0.0;
    if (pos_sale_line_has_explicit_cost($it)) {
        return (float)$it['cost'];
    }
    return $catalog;
}

function pos_fifo_json_flags() {
    $flags = JSON_UNESCAPED_UNICODE;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
        $flags |= JSON_INVALID_UTF8_SUBSTITUTE;
    }
    return $flags;
}

/**
 * Newest-first purchase layers for a product (includes gift rows with totalCost = 0).
 * @return array<int, array{qty:float,totalCost:float,type:string}>
 */
function pos_fifo_purchase_layers_newest_first(mysqli $conn, $pid) {
    $pid = (int)$pid;
    if ($pid <= 0) {
        return [];
    }
    $layers = [];
    try {
        $st = $conn->prepare('SELECT qtyAdded, totalCost, `type` FROM supplies WHERE prodId = ? AND qtyAdded > 0 ORDER BY `date` DESC, id DESC');
        if ($st) {
            $st->bind_param('i', $pid);
            $st->execute();
            $res = $st->get_result();
            while ($res && ($r = $res->fetch_assoc())) {
                $typ = strtolower(trim((string)($r['type'] ?? '')));
                if ($typ === 'return' || $typ === 'supplier_return') {
                    continue;
                }
                $q = (float)($r['qtyAdded'] ?? 0);
                if ($q <= 0) {
                    continue;
                }
                $layers[] = [
                    'qty' => $q,
                    'totalCost' => (float)($r['totalCost'] ?? 0),
                    'type' => $typ,
                ];
            }
        }
    } catch (Throwable $e) {
        $layers = [];
    }
    return $layers;
}

/**
 * Remaining inventory lots oldest-first (FIFO). Gift lots keep unitCost = 0.
 * @return array<int, array{rem:float,unitCost:float}>
 */
function pos_fifo_remaining_layers($newestFirst, $remainingQty, $catalogPieceCost) {
    $left = max(0.0, (float)$remainingQty);
    $taken = [];
    if ($left <= 0.000001) {
        return $taken;
    }
    foreach ((array)$newestFirst as $L) {
        if ($left <= 0.000001) {
            break;
        }
        $q = (float)($L['qty'] ?? 0);
        if ($q <= 0) {
            continue;
        }
        $take = min($q, $left);
        $uc = $q > 0 ? ((float)($L['totalCost'] ?? 0) / $q) : 0.0;
        $taken[] = ['rem' => $take, 'unitCost' => $uc];
        $left -= $take;
    }
    if ($left > 0.000001) {
        $taken[] = ['rem' => $left, 'unitCost' => max(0.0, (float)$catalogPieceCost)];
    }
    return array_reverse($taken);
}

function pos_fifo_consume_layers(array &$layers, $pieces) {
    $left = max(0.0, (float)$pieces);
    $cost = 0.0;
    foreach ($layers as &$b) {
        if ($left <= 0.000001) {
            break;
        }
        $rem = (float)($b['rem'] ?? 0);
        if ($rem <= 0.000001) {
            continue;
        }
        $take = min($left, $rem);
        $cost += $take * (float)($b['unitCost'] ?? 0);
        $b['rem'] = $rem - $take;
        $left -= $take;
    }
    unset($b);
    return ['cost' => $cost, 'left' => $left];
}

/**
 * Stamp each sale line with remaining FIFO / gift-lot cost (0 for free bonus units).
 * $qtyAddBackByPid = pieces to add to products.qty (sale-edit: old invoice already deducted).
 * @param string|array $itemsJson
 * @param array<int,float>|null $qtyAddBackByPid
 * @return string|array
 */
function pos_stamp_sale_items_inventory_cogs(mysqli $conn, $itemsJson, $qtyAddBackByPid = null) {
    $asString = !is_array($itemsJson);
    $items = $asString ? json_decode((string)$itemsJson, true) : $itemsJson;
    if (!is_array($items) || !$items) {
        return $itemsJson;
    }
    $pids = [];
    foreach ($items as $it) {
        if (!is_array($it) || !empty($it['isManualItem'])) {
            continue;
        }
        $pid = (int)($it['id'] ?? 0);
        if ($pid > 0) {
            $pids[$pid] = true;
        }
    }
    if (!$pids) {
        return $itemsJson;
    }
    $idList = implode(',', array_map('intval', array_keys($pids)));
    $prodMeta = [];
    $res = $conn->query("SELECT id, cost, cost_usd, cost_pack, cost_carton, base_cost, base_currency, qty, pieces_per_pack, packs_per_carton, itemsPerCarton FROM products WHERE id IN ($idList)");
    if ($res) {
        while ($r = $res->fetch_assoc()) {
            $prodMeta[(int)$r['id']] = $r;
        }
    }
    $layersByPid = [];
    foreach ($prodMeta as $pid => $p) {
        $onHand = (float)($p['qty'] ?? 0);
        $addBack = is_array($qtyAddBackByPid) ? (float)($qtyAddBackByPid[$pid] ?? 0) : 0.0;
        $remaining = max(0.0, $onHand + $addBack);
        $layersByPid[$pid] = pos_fifo_remaining_layers(
            pos_fifo_purchase_layers_newest_first($conn, $pid),
            $remaining,
            (float)($p['cost'] ?? 0)
        );
    }
    foreach ($items as &$it) {
        if (!is_array($it) || !empty($it['isManualItem'])) {
            continue;
        }
        $pid = (int)($it['id'] ?? 0);
        if ($pid <= 0) {
            continue;
        }
        $lineQty = pos_sale_item_line_qty($it);
        if ($lineQty <= 0) {
            continue;
        }
        if (empty($layersByPid[$pid])) {
            $pmEmpty = $prodMeta[$pid] ?? null;
            if ($pmEmpty) {
                $suEmpty = isset($it['saleUnit']) ? (string)$it['saleUnit'] : 'piece';
                $enteredEmpty = pos_entered_catalog_cost_for_sale_unit($pmEmpty, $suEmpty);
                if ($enteredEmpty > 0) {
                    $it['cost'] = function_exists('roundMoney') ? roundMoney($enteredEmpty) : round($enteredEmpty, 2);
                }
            }
            continue;
        }
        $pieces = pos_sale_item_pieces($it);
        if ($pieces <= 0) {
            continue;
        }
        $got = pos_fifo_consume_layers($layersByPid[$pid], $pieces);
        $cogs = (float)($got['cost'] ?? 0);
        $unitCost = function_exists('roundMoney') ? roundMoney($cogs / $lineQty) : round($cogs / $lineQty, 2);
        // Oversell (0 cartons / not enough pieces): leftover is not a gift. Floor to typed pack/carton cost.
        if ((float)($got['left'] ?? 0) > 0.000001 && !empty($prodMeta[$pid])) {
            $su = isset($it['saleUnit']) ? (string)$it['saleUnit'] : 'piece';
            $entered = pos_entered_catalog_cost_for_sale_unit($prodMeta[$pid], $su);
            if ($entered > $unitCost) {
                $unitCost = function_exists('roundMoney') ? roundMoney($entered) : round($entered, 2);
            }
        }
        $it['cost'] = $unitCost;
        // Prefer catalog USD cost so reports never re-ratio IQD COGS through a later FX rate.
        $pm = $prodMeta[$pid] ?? null;
        if ($pm) {
            $costUsd = null;
            if (isset($pm['cost_usd']) && $pm['cost_usd'] !== null && $pm['cost_usd'] !== '' && is_numeric($pm['cost_usd'])) {
                $costUsd = (float)$pm['cost_usd'];
            } elseif (isset($pm['base_cost']) && strtoupper((string)($pm['base_currency'] ?? '')) === 'USD'
                && $pm['base_cost'] !== null && $pm['base_cost'] !== '' && is_numeric($pm['base_cost'])) {
                $costUsd = (float)$pm['base_cost'];
            }
            if ($costUsd !== null && $costUsd >= 0) {
                $it['cost_usd'] = $costUsd;
                $it['base_cost'] = $costUsd;
                $it['base_currency'] = 'USD';
            }
        }
    }
    unset($it);
    if (!$asString) {
        return $items;
    }
    $out = json_encode($items, pos_fifo_json_flags());
    return ($out !== false) ? $out : $itemsJson;
}

/** Whole IQD for paid amounts on installments. */
function pos_installment_money_iqd($v) {
    return (float) round((float) $v, 0);
}

/** Iraqi cash step for scheduled installment amounts (250 IQD notes). */
function pos_installment_iqd_step() {
    return 250;
}

function pos_round_iqd_step($amount, $step = null) {
    $step = $step ?? pos_installment_iqd_step();
    $step = max(1, (int) $step);
    return (float) (round((float) $amount / $step) * $step);
}

/** Scheduled installment amount — multiple of 250 IQD. */
function pos_installment_schedule_amount_iqd($v) {
    return pos_round_iqd_step((float) $v, pos_installment_iqd_step());
}

/**
 * Split total into practical IQD installments (×250).
 * Regular months use rounded equal share; first installment absorbs the remainder.
 */
function pos_split_installment_practical_iqd($total, $months) {
    $total = (int) round((float) $total);
    $months = max(1, (int) $months);
    if ($total <= 0) {
        return [];
    }
    if ($months === 1) {
        return [(float) $total];
    }
    $step = pos_installment_iqd_step();
    $base = $total / $months;
    $regular = pos_round_iqd_step($base, $step);
    if ($regular <= 0) {
        $regular = (float) $step;
    }
    $first = $total - ($regular * ($months - 1));
    if ($first <= 0) {
        $regular = (float) (ceil($base / $step) * $step);
        $first = $total - ($regular * ($months - 1));
    }
    $amounts = [$first];
    for ($i = 1; $i < $months; $i++) {
        $amounts[] = $regular;
    }
    return $amounts;
}

/** @deprecated alias */
function pos_split_installment_whole_iqd($total, $months) {
    return pos_split_installment_practical_iqd($total, $months);
}

function pos_plan_installment_amounts_need_rebalance($conn, $planId) {
    $planId = (int) $planId;
    $res = $conn->query("SELECT amount FROM customer_installment_items WHERE plan_id = $planId");
    if (!$res) return false;
    $step = pos_installment_iqd_step();
    while ($r = $res->fetch_assoc()) {
        $a = pos_installment_money_iqd($r['amount'] ?? 0);
        if ($a <= 0) continue;
        if (fmod($a, $step) > 0.001) return true;
    }
    return false;
}

/** Rebalance active plan rows to ×250 IQD; first installment holds any remainder. */
function pos_rebalance_installment_plan_practical_iqd($conn, $planId) {
    $planId = (int) $planId;
    $resP = $conn->query("SELECT id, total_amount, months FROM customer_installment_plans WHERE id = $planId LIMIT 1");
    if (!$resP || !($plan = $resP->fetch_assoc())) return;
    $total = pos_installment_money_iqd($plan['total_amount'] ?? 0);
    $months = max(1, (int) ($plan['months'] ?? 0));
    $amounts = pos_split_installment_practical_iqd($total, $months);
    if (count($amounts) !== $months) return;

    $stmt = $conn->prepare("UPDATE customer_installment_items SET amount = ? WHERE plan_id = ? AND installment_no = ?");
    if (!$stmt) return;
    for ($i = 0; $i < $months; $i++) {
        $no = $i + 1;
        $amt = pos_installment_schedule_amount_iqd($amounts[$i]);
        $stmt->bind_param('dii', $amt, $planId, $no);
        $stmt->execute();
    }
    $regular = $months > 1 ? pos_installment_schedule_amount_iqd($amounts[1]) : pos_installment_schedule_amount_iqd($amounts[0]);
    $stmtPlan = $conn->prepare("UPDATE customer_installment_plans SET total_amount = ?, monthly_amount = ? WHERE id = ?");
    if ($stmtPlan) {
        $stmtPlan->bind_param('ddi', $total, $regular, $planId);
        $stmtPlan->execute();
    }
    $conn->query("UPDATE customer_installment_items SET status = 'paid' WHERE plan_id = $planId AND paid_amount >= amount AND amount > 0");
    $conn->query("UPDATE customer_installment_items SET status = 'partial' WHERE plan_id = $planId AND paid_amount > 0 AND paid_amount < amount");
}

/** Normalize legacy fractional / non-250 installment amounts in DB. */
function pos_normalize_installment_whole_iqd_in_db($conn) {
    try {
        $conn->query("UPDATE customer_installment_items SET paid_amount = ROUND(paid_amount, 0)");
        $conn->query("UPDATE customer_installment_plans SET total_amount = ROUND(total_amount, 0)");
        $res = $conn->query("SELECT id FROM customer_installment_plans WHERE status = 'active'");
        if ($res) {
            while ($row = $res->fetch_assoc()) {
                $pid = (int) ($row['id'] ?? 0);
                if ($pid > 0 && pos_plan_installment_amounts_need_rebalance($conn, $pid)) {
                    pos_rebalance_installment_plan_practical_iqd($conn, $pid);
                }
            }
        }
        pos_update_installment_overdue_status($conn);
    } catch (Throwable $e) { /* tables may not exist */ }
}

/** Mark pending/partial installment items as overdue when past due date. */
function pos_update_installment_overdue_status($conn, $planId = 0) {
    $today = date('Y-m-d');
    if ($planId > 0) {
        $pid = (int)$planId;
        $conn->query("UPDATE customer_installment_items SET status = 'overdue' WHERE plan_id = $pid AND status IN ('pending','partial') AND due_date < '$today'");
        return;
    }
    $conn->query("UPDATE customer_installment_items i
        INNER JOIN customer_installment_plans p ON p.id = i.plan_id
        SET i.status = 'overdue'
        WHERE p.status = 'active' AND i.status IN ('pending','partial') AND i.due_date < '$today'");
}

/** Sum of unpaid installment amounts on active plans for a customer. */
function pos_customer_installment_committed_remaining($conn, $customerId, $excludePlanId = 0) {
    $customerId = (int) $customerId;
    $excludePlanId = (int) $excludePlanId;
    if ($customerId <= 0) return 0.0;
    $sql = "SELECT COALESCE(SUM(GREATEST(i.amount - i.paid_amount, 0)), 0) AS rem
        FROM customer_installment_items i
        INNER JOIN customer_installment_plans p ON p.id = i.plan_id
        WHERE p.customer_id = $customerId AND p.status = 'active'";
    if ($excludePlanId > 0) {
        $sql .= " AND p.id <> $excludePlanId";
    }
    $res = $conn->query($sql);
    if (!$res || !($row = $res->fetch_assoc())) return 0.0;
    return pos_installment_money_iqd($row['rem'] ?? 0);
}

/** Mark active plans completed when all items are paid. */
function pos_check_installment_plans_completion($conn, $customerId) {
    $customerId = (int) $customerId;
    if ($customerId <= 0) return;
    $res = $conn->query("SELECT id FROM customer_installment_plans WHERE customer_id = $customerId AND status = 'active'");
    if (!$res) return;
    while ($row = $res->fetch_assoc()) {
        $planId = (int) ($row['id'] ?? 0);
        if ($planId <= 0) continue;
        $chk = $conn->query("SELECT COUNT(*) AS c FROM customer_installment_items WHERE plan_id = $planId AND status <> 'paid'");
        if ($chk && ($cr = $chk->fetch_assoc()) && (int) ($cr['c'] ?? 0) === 0) {
            $conn->query("UPDATE customer_installment_plans SET status = 'completed' WHERE id = $planId");
        }
    }
}

/** Apply customer debt payment to sales.remaining_debt (specific sale or FIFO). Returns applied amount. */
function pos_apply_customer_sale_debt_payment($conn, $customerId, $amount, $saleId = 0) {
    $customerId = (int)$customerId;
    $amount = roundMoney((float)$amount);
    $saleId = (int)$saleId;
    if ($customerId <= 0 || $amount <= 0 || !$conn) {
        return 0.0;
    }
    if (function_exists('pos_ensure_payment_due_schema')) {
        pos_ensure_payment_due_schema($conn);
    }
    $remainingPay = $amount;
    $applied = 0.0;

    $rows = [];
    if ($saleId > 0) {
        $stmt = $conn->prepare(
            "SELECT id, remaining_debt FROM sales "
            . "WHERE id = ? AND customer_id = ? AND customer_type IN ('customer','customers') "
            . "AND remaining_debt > 0 LIMIT 1"
        );
        if ($stmt) {
            $stmt->bind_param('ii', $saleId, $customerId);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($res) {
                while ($r = $res->fetch_assoc()) {
                    $rows[] = $r;
                }
            }
        }
    } else {
        $stmt = $conn->prepare(
            "SELECT id, remaining_debt FROM sales "
            . "WHERE customer_id = ? AND customer_type IN ('customer','customers') "
            . "AND (is_returned IS NULL OR is_returned = 0) "
            . "AND remaining_debt > 0 ORDER BY created_at ASC, id ASC"
        );
        if ($stmt) {
            $stmt->bind_param('i', $customerId);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($res) {
                while ($r = $res->fetch_assoc()) {
                    $rows[] = $r;
                }
            }
        }
    }

    $stUp = $conn->prepare("UPDATE sales SET remaining_debt = ?, payment_due_at = IF(? <= 0.0001, NULL, payment_due_at) WHERE id = ?");
    if (!$stUp) {
        return 0.0;
    }
    foreach ($rows as $row) {
        if ($remainingPay <= 0.0001) {
            break;
        }
        $sid = (int)($row['id'] ?? 0);
        $owed = roundMoney((float)($row['remaining_debt'] ?? 0));
        if ($sid <= 0 || $owed <= 0.0001) {
            continue;
        }
        $take = roundMoney(min($remainingPay, $owed));
        $newRem = roundMoney(max(0, $owed - $take));
        $stUp->bind_param('ddi', $newRem, $newRem, $sid);
        $stUp->execute();
        $remainingPay = roundMoney($remainingPay - $take);
        $applied = roundMoney($applied + $take);
    }
    return $applied;
}

/**
 * Undo v3.13.7–3.13.9 heal that put current balance onto the oldest invoices.
 * Customer.balance stays the truth; remaining sits on the newest credit invoices.
 */
function pos_repair_reopened_old_customer_debts($conn) {
    if (!$conn) {
        return 0;
    }
    $changed = 0;
    $rc = @$conn->query('SELECT id, balance FROM customers');
    if (!$rc) {
        return 0;
    }
    $stRows = $conn->prepare(
        "SELECT id, remaining_debt, debt_amount, payment_method, total FROM sales "
        . "WHERE customer_id = ? AND customer_type IN ('customer','customers') "
        . "AND (is_returned IS NULL OR is_returned = 0) "
        . "AND (payment_method IN ('debt','split') OR COALESCE(debt_amount,0) > 0.0001 OR COALESCE(remaining_debt,0) > 0.0001) "
        . "ORDER BY created_at DESC, id DESC"
    );
    $stUp = $conn->prepare(
        "UPDATE sales SET remaining_debt = ?, payment_due_at = IF(? <= 0.0001, NULL, payment_due_at) WHERE id = ?"
    );
    if (!$stRows || !$stUp) {
        return 0;
    }
    while ($c = $rc->fetch_assoc()) {
        $cid = (int)($c['id'] ?? 0);
        $left = roundMoney((float)($c['balance'] ?? 0));
        if ($cid <= 0) {
            continue;
        }
        if ($left < 0) {
            $left = 0.0;
        }
        $stRows->bind_param('i', $cid);
        $stRows->execute();
        $res = $stRows->get_result();
        if (!$res) {
            continue;
        }
        while ($row = $res->fetch_assoc()) {
            $sid = (int)($row['id'] ?? 0);
            if ($sid <= 0) {
                continue;
            }
            $da = roundMoney((float)($row['debt_amount'] ?? 0));
            $cur = roundMoney((float)($row['remaining_debt'] ?? 0));
            $pm = strtolower(trim((string)($row['payment_method'] ?? '')));
            $cap = $da;
            if ($cap <= 0.0001 && $cur > 0.0001) {
                $cap = $cur;
            }
            if ($cap <= 0.0001 && ($pm === 'debt' || $pm === 'split')) {
                $cap = roundMoney((float)($row['total'] ?? 0));
            }
            $newRem = ($left > 0.0001 && $cap > 0.0001) ? roundMoney(min($left, $cap)) : 0.0;
            if (abs($newRem - $cur) > 0.0001) {
                $stUp->bind_param('ddi', $newRem, $newRem, $sid);
                $stUp->execute();
                $changed++;
            }
            $left = roundMoney($left - $newRem);
        }
    }
    return $changed;
}

/** Delete extra customer rows that share name+phone and have no sales/ledger. */
function pos_ensure_old_debt_repair_v2($conn) {
    if (!$conn) {
        return;
    }
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    $flag = null;
    try {
        if (function_exists('pos_db_get_setting_value')) {
            $flag = pos_db_get_setting_value($conn, 'pos_legacy_debt_repair_v2');
        }
    } catch (Throwable $e) {}
    if ($flag === '1' || $flag === 1 || $flag === true) {
        return;
    }
    try {
        pos_repair_reopened_old_customer_debts($conn);
        pos_delete_empty_duplicate_customers($conn);
        if (function_exists('pos_db_set_setting_value')) {
            pos_db_set_setting_value($conn, 'pos_legacy_debt_repair_v2', '1');
        }
        if (function_exists('touchLastUpdate')) {
            touchLastUpdate($conn);
        }
    } catch (Throwable $e) {}
}

function pos_delete_empty_duplicate_customers($conn) {
    if (!$conn) {
        return 0;
    }
    $removed = 0;
    $sql = "SELECT LOWER(TRIM(name)) AS n, TRIM(phone) AS p, GROUP_CONCAT(id ORDER BY id) AS ids, COUNT(*) AS c "
        . "FROM customers WHERE TRIM(IFNULL(phone,'')) <> '' GROUP BY LOWER(TRIM(name)), TRIM(phone) HAVING c > 1";
    $res = @$conn->query($sql);
    if (!$res) {
        return 0;
    }
    while ($g = $res->fetch_assoc()) {
        $ids = array_values(array_filter(array_map('intval', explode(',', (string)($g['ids'] ?? '')))));
        if (count($ids) < 2) {
            continue;
        }
        $keeper = $ids[0];
        for ($i = 1; $i < count($ids); $i++) {
            $extra = $ids[$i];
            $salesN = 0;
            $ledN = 0;
            $qs = $conn->query('SELECT COUNT(*) AS c FROM sales WHERE customer_id = ' . $extra . " AND customer_type IN ('customer','customers')");
            if ($qs && ($sr = $qs->fetch_assoc())) {
                $salesN = (int)($sr['c'] ?? 0);
            }
            $ql = $conn->query("SELECT COUNT(*) AS c FROM customer_ledger WHERE target_id = " . $extra . " AND target_type = 'customer'");
            if ($ql && ($lr = $ql->fetch_assoc())) {
                $ledN = (int)($lr['c'] ?? 0);
            }
            if ($salesN > 0 || $ledN > 0) {
                continue;
            }
            $conn->query('DELETE FROM customers WHERE id = ' . $extra . ' LIMIT 1');
            if ($conn->affected_rows > 0) {
                $removed++;
            }
        }
        unset($keeper);
    }
    return $removed;
}

/** Sum remaining_debt for a company purchase transaction_id. */
function pos_company_invoice_remaining_debt($conn, $transactionId) {
    $transactionId = trim((string)$transactionId);
    if ($transactionId === '' || !$conn) {
        return 0.0;
    }
    if (function_exists('pos_ensure_payment_due_schema')) {
        pos_ensure_payment_due_schema($conn);
    }
    $stmt = $conn->prepare(
        "SELECT COALESCE(SUM(COALESCE(remaining_debt, CASE WHEN type IN ('credit','split') THEN totalCost ELSE 0 END)), 0) AS rem "
        . "FROM supplies WHERE transaction_id = ? AND type IN ('credit','split')"
    );
    if (!$stmt) {
        return 0.0;
    }
    $stmt->bind_param('s', $transactionId);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res ? $res->fetch_assoc() : null;
    return roundMoney((float)($row['rem'] ?? 0));
}

/**
 * Apply company debt payment to supplies.remaining_debt for one invoice (transaction_id)
 * or FIFO across open credit purchases. Returns applied amount.
 */
function pos_apply_company_invoice_debt_payment($conn, $companyName, $amount, $transactionId = '') {
    $companyName = trim((string)$companyName);
    $amount = roundMoney((float)$amount);
    $transactionId = trim((string)$transactionId);
    if ($companyName === '' || $amount <= 0 || !$conn) {
        return 0.0;
    }
    if (function_exists('pos_ensure_payment_due_schema')) {
        pos_ensure_payment_due_schema($conn);
    }
    $remainingPay = $amount;
    $applied = 0.0;

    if ($transactionId !== '') {
        $stmt = $conn->prepare(
            "SELECT id, COALESCE(remaining_debt, totalCost) AS rem FROM supplies "
            . "WHERE transaction_id = ? AND company = ? AND type IN ('credit','split') "
            . "AND COALESCE(remaining_debt, totalCost) > 0 ORDER BY id ASC"
        );
        if (!$stmt) {
            return 0.0;
        }
        $stmt->bind_param('ss', $transactionId, $companyName);
    } else {
        $stmt = $conn->prepare(
            "SELECT id, COALESCE(remaining_debt, totalCost) AS rem FROM supplies "
            . "WHERE company = ? AND type IN ('credit','split') "
            . "AND COALESCE(remaining_debt, totalCost) > 0 ORDER BY date ASC, id ASC"
        );
        if (!$stmt) {
            return 0.0;
        }
        $stmt->bind_param('s', $companyName);
    }
    $stmt->execute();
    $res = $stmt->get_result();
    if (!$res) {
        return 0.0;
    }

    $stUp = $conn->prepare("UPDATE supplies SET remaining_debt = ? WHERE id = ?");
    if (!$stUp) {
        return 0.0;
    }

    while ($remainingPay > 0.0001 && ($row = $res->fetch_assoc())) {
        $sid = (int)($row['id'] ?? 0);
        $owed = roundMoney((float)($row['rem'] ?? 0));
        if ($sid <= 0 || $owed <= 0.0001) {
            continue;
        }
        $take = roundMoney(min($remainingPay, $owed));
        $newRem = roundMoney(max(0, $owed - $take));
        $stUp->bind_param('di', $newRem, $sid);
        $stUp->execute();
        $remainingPay = roundMoney($remainingPay - $take);
        $applied = roundMoney($applied + $take);
    }

    if ($transactionId !== '') {
        $chk = $conn->prepare(
            "SELECT COALESCE(SUM(COALESCE(remaining_debt, 0)), 0) AS rem FROM supplies "
            . "WHERE transaction_id = ? AND type IN ('credit','split')"
        );
        if ($chk) {
            $chk->bind_param('s', $transactionId);
            $chk->execute();
            $chkRow = $chk->get_result()->fetch_assoc();
            $left = roundMoney((float)($chkRow['rem'] ?? 0));
            if ($left <= 0.0001) {
                $stClear = $conn->prepare("UPDATE supplies SET payment_due_at = NULL WHERE transaction_id = ?");
                if ($stClear) {
                    $stClear->bind_param('s', $transactionId);
                    $stClear->execute();
                }
            }
        }
    }

    return $applied;
}

/** Apply a debt payment amount to active installment items (FIFO by due_date across all plans). */
function pos_apply_installment_payment($conn, $customerId, $amount, $ledgerId = 0) {
    $customerId = (int)$customerId;
    $amount = pos_installment_money_iqd($amount);
    if ($amount <= 0 || $customerId <= 0) return;
    if (!pos_installments_pro_enabled($conn)) return;
    pos_update_installment_overdue_status($conn);

    $remaining = $amount;
    $now = date('Y-m-d H:i:s');
    $stmtItems = $conn->prepare("SELECT i.id, i.amount, i.paid_amount, i.plan_id
        FROM customer_installment_items i
        INNER JOIN customer_installment_plans p ON p.id = i.plan_id
        WHERE p.customer_id = ? AND p.status = 'active'
        AND i.status IN ('pending','overdue','partial')
        ORDER BY i.due_date ASC, i.installment_no ASC, i.plan_id ASC");
    if (!$stmtItems) return;
    $stmtItems->bind_param('i', $customerId);
    $stmtItems->execute();
    $itemsRes = $stmtItems->get_result();
    if (!$itemsRes) return;

    $stmtUpdPaid = $conn->prepare("UPDATE customer_installment_items SET paid_amount = ?, status = ?, paid_at = ?, ledger_id = ? WHERE id = ?");
    $stmtUpdPartial = $conn->prepare("UPDATE customer_installment_items SET paid_amount = ?, status = ? WHERE id = ?");
    if (!$stmtUpdPaid || !$stmtUpdPartial) return;

    while ($remaining > 0 && ($item = $itemsRes->fetch_assoc())) {
        $itemId = (int)$item['id'];
        $itemAmt = pos_installment_schedule_amount_iqd($item['amount'] ?? 0);
        $paidSoFar = pos_installment_money_iqd($item['paid_amount'] ?? 0);
        $owed = pos_installment_money_iqd($itemAmt - $paidSoFar);
        if ($owed <= 0) continue;
        $apply = pos_installment_money_iqd(min($remaining, $owed));
        $newPaid = pos_installment_money_iqd($paidSoFar + $apply);
        $newStatus = ($newPaid >= $itemAmt) ? 'paid' : 'partial';
        if ($newStatus === 'paid') {
            $ledgerVal = ($ledgerId > 0) ? (int)$ledgerId : 0;
            $stmtUpdPaid->bind_param('dssii', $newPaid, $newStatus, $now, $ledgerVal, $itemId);
            $stmtUpdPaid->execute();
        } else {
            $stmtUpdPartial->bind_param('dsi', $newPaid, $newStatus, $itemId);
            $stmtUpdPartial->execute();
        }
        $remaining = pos_installment_money_iqd($remaining - $apply);
    }

    pos_check_installment_plans_completion($conn, $customerId);
}

function pos_fetch_installment_data($conn) {
    if (!pos_installments_pro_enabled($conn)) {
        return ['installment_plans' => [], 'installment_items' => []];
    }
    pos_normalize_installment_whole_iqd_in_db($conn);
    pos_update_installment_overdue_status($conn);
    $plans = [];
    $items = [];
    $resP = $conn->query("SELECT * FROM customer_installment_plans ORDER BY id DESC LIMIT 500");
    if ($resP) {
        while ($r = $resP->fetch_assoc()) {
            $r['id'] = (int)$r['id'];
            $r['customer_id'] = (int)$r['customer_id'];
            $r['total_amount'] = pos_installment_money_iqd($r['total_amount'] ?? 0);
            $r['monthly_amount'] = pos_installment_schedule_amount_iqd($r['monthly_amount'] ?? 0);
            $r['months'] = (int)($r['months'] ?? 0);
            $plans[] = $r;
        }
    }
    $resI = $conn->query("SELECT * FROM customer_installment_items ORDER BY plan_id DESC, installment_no ASC LIMIT 5000");
    if ($resI) {
        while ($r = $resI->fetch_assoc()) {
            $r['id'] = (int)$r['id'];
            $r['plan_id'] = (int)$r['plan_id'];
            $r['installment_no'] = (int)($r['installment_no'] ?? 0);
            $r['amount'] = pos_installment_schedule_amount_iqd($r['amount'] ?? 0);
            $r['paid_amount'] = pos_installment_money_iqd($r['paid_amount'] ?? 0);
            $r['ledger_id'] = isset($r['ledger_id']) ? (int)$r['ledger_id'] : 0;
            $items[] = $r;
        }
    }
    return ['installment_plans' => $plans, 'installment_items' => $items];
}

function pos_parse_history_date_ymd($raw, $fallbackYmd) {
    $s = trim((string)$raw);
    return preg_match('/^\d{4}-\d{2}-\d{2}$/', $s) ? $s : $fallbackYmd;
}

/** Sale cart line qty in sale units (piece/pack/carton count). */
function pos_sale_item_line_qty(array $item): float {
    $q = (float)($item['qty'] ?? $item['count'] ?? 1);
    return $q > 0 ? $q : 0;
}

/** Pieces deducted for a sale line (matches process_payment unit math). */
function pos_sale_item_pieces(array $item): float {
    $qty = pos_sale_item_line_qty($item);
    if ($qty <= 0) return 0;
    $mult = 1;
    $su = isset($item['saleUnit']) ? (string)$item['saleUnit'] : 'piece';
    if ($su !== 'piece') {
        $ppp = max(1, (int)($item['pieces_per_pack'] ?? 1));
        $ppc = max(1, (int)($item['packs_per_carton'] ?? 1));
        $piecesPerCarton = $ppp * $ppc;
        if ($piecesPerCarton <= 1 && isset($item['itemsPerCarton']) && (int)$item['itemsPerCarton'] > 1) {
            $piecesPerCarton = (int)$item['itemsPerCarton'];
        }
        if ($su === 'carton') $mult = $piecesPerCarton;
        elseif ($su === 'pack') $mult = $ppp;
    }
    return $qty * $mult;
}

/**
 * Recalculate historical sale-line `cost` from purchase FIFO at each sale time.
 * Fixes shops where pack/carton/stale catalog costs corrupted profit on old invoices.
 * Also refreshes catalog piece/pack/carton from the latest purchase per product.
 *
 * @return array{sales_scanned:int,sales_updated:int,lines_fixed:int,products_synced:int,archive_updated:int}
 */
function pos_repair_historical_sale_cogs($conn) {
    @set_time_limit(0);
    $out = [
        'sales_scanned' => 0,
        'sales_updated' => 0,
        'lines_fixed' => 0,
        'products_synced' => 0,
        'archive_updated' => 0,
    ];
    if (!$conn) return $out;

    $products = [];
    $resP = $conn->query('SELECT id, cost, cost_pack, cost_carton, pieces_per_pack, packs_per_carton, itemsPerCarton FROM products');
    if ($resP) {
        while ($r = $resP->fetch_assoc()) {
            $pid = (int)$r['id'];
            $ppp = max(1, (int)($r['pieces_per_pack'] ?? 1));
            $ppc = max(1, (int)($r['packs_per_carton'] ?? 1));
            $ipc = (int)($r['itemsPerCarton'] ?? 0);
            $products[$pid] = [
                'cost' => (float)($r['cost'] ?? 0),
                'cost_pack' => (float)($r['cost_pack'] ?? 0),
                'cost_carton' => (float)($r['cost_carton'] ?? 0),
                'ppp' => $ppp,
                'ppc' => $ppc,
                'pieces_per_pack' => $ppp,
                'packs_per_carton' => $ppc,
                'itemsPerCarton' => $ipc,
                'piecesPerCarton' => ($ipc > 1) ? $ipc : ($ppp * $ppc),
            ];
        }
    }

    // FIFO batches per product (piece unit cost).
    $allBatches = []; // pid => list of [t, rem, unitCost]
    $resS = $conn->query("SELECT prodId, qtyAdded, totalCost, `date`, `type`, is_gift
        FROM supplies
        WHERE qtyAdded > 0
        ORDER BY `date` ASC, id ASC");
    if (!$resS) {
        $resS = $conn->query("SELECT prodId, qtyAdded, totalCost, `date`, `type`
            FROM supplies
            WHERE qtyAdded > 0
            ORDER BY `date` ASC, id ASC");
    }
    if ($resS) {
        while ($r = $resS->fetch_assoc()) {
            $typ = strtolower(trim((string)($r['type'] ?? '')));
            if ($typ === 'return' || $typ === 'opening' || $typ === 'supplier_return') continue;
            $pid = (int)$r['prodId'];
            $q = (float)$r['qtyAdded'];
            if ($q <= 0) continue;
            $tc = (float)($r['totalCost'] ?? 0);
            $t = strtotime((string)($r['date'] ?? '')) ?: 0;
            $isGift = !empty($r['is_gift']);
            if (!isset($allBatches[$pid])) $allBatches[$pid] = [];
            $allBatches[$pid][] = [
                't' => $t,
                'rem' => $q,
                'unitCost' => $isGift ? 0.0 : ($q > 0 ? ($tc / $q) : 0),
            ];
        }
    }

    $live = []; // pid => active FIFO queue
    $cursor = []; // pid => next index in allBatches
    foreach ($allBatches as $pid => $_rows) {
        $live[$pid] = [];
        $cursor[$pid] = 0;
    }

    $releaseUntil = function ($pid, $t) use (&$live, &$cursor, &$allBatches) {
        if (!isset($allBatches[$pid])) return;
        $n = count($allBatches[$pid]);
        $i = $cursor[$pid] ?? 0;
        while ($i < $n && $allBatches[$pid][$i]['t'] <= $t) {
            $live[$pid][] = [
                'rem' => $allBatches[$pid][$i]['rem'],
                'unitCost' => $allBatches[$pid][$i]['unitCost'],
            ];
            $i++;
        }
        $cursor[$pid] = $i;
    };

    $consume = function ($pid, $pieces) use (&$live) {
        $left = max(0.0, (float)$pieces);
        $cost = 0.0;
        $from = 0.0;
        if (!isset($live[$pid])) $live[$pid] = [];
        while ($left > 0.000001 && count($live[$pid]) > 0) {
            $b = &$live[$pid][0];
            if (($b['rem'] ?? 0) <= 0.000001) {
                array_shift($live[$pid]);
                unset($b);
                continue;
            }
            $take = min($left, (float)$b['rem']);
            $cost += $take * (float)($b['unitCost'] ?? 0);
            $b['rem'] -= $take;
            $left -= $take;
            $from += $take;
            if ($b['rem'] <= 0.000001) {
                array_shift($live[$pid]);
            }
            unset($b);
        }
        return ['cost' => $cost, 'from' => $from, 'left' => $left];
    };

    $linePieces = function (array $it, $pid) use ($products) {
        if (empty($it['pieces_per_pack']) && isset($products[$pid])) {
            $it['pieces_per_pack'] = $products[$pid]['ppp'];
            $it['packs_per_carton'] = $products[$pid]['ppc'];
            $it['itemsPerCarton'] = $products[$pid]['piecesPerCarton'];
        }
        return pos_sale_item_pieces($it);
    };

    // Waste consumes stock layers (no sale update).
    $resW = $conn->query('SELECT prodId, qty, `date` FROM waste ORDER BY `date` ASC, id ASC');
    $wasteEvents = [];
    if ($resW) {
        while ($r = $resW->fetch_assoc()) {
            $wasteEvents[] = [
                'kind' => 'waste',
                't' => strtotime((string)($r['date'] ?? '')) ?: 0,
                'pid' => (int)$r['prodId'],
                'pieces' => abs((float)($r['qty'] ?? 0)),
            ];
        }
    }

    $processSaleRow = function ($table, $id, $createdAt, $itemsJson) use (
        &$out, $conn, $releaseUntil, $consume, $linePieces, $products
    ) {
        $out['sales_scanned']++;
        $items = json_decode((string)$itemsJson, true);
        if (!is_array($items) || !count($items)) return;
        $t = strtotime((string)$createdAt) ?: 0;
        $changed = false;
        $fixed = 0;
        foreach ($items as &$it) {
            if (!is_array($it)) continue;
            $pid = (int)($it['id'] ?? 0);
            if ($pid <= 0) continue;
            $releaseUntil($pid, $t);
            $lineQty = pos_sale_item_line_qty($it);
            if ($lineQty <= 0) continue;
            $pieces = $linePieces($it, $pid);
            if ($pieces <= 0) continue;
            $got = $consume($pid, $pieces);
            $cogs = (float)$got['cost'];
            $su = isset($it['saleUnit']) ? (string)$it['saleUnit'] : 'piece';
            if ($got['left'] > 0.000001 && isset($products[$pid])) {
                $fifoUnit = $lineQty > 0 ? ($cogs / $lineQty) : 0.0;
                $entered = pos_entered_catalog_cost_for_sale_unit($products[$pid], $su);
                if ($entered > $fifoUnit) {
                    $cogs = $entered * $lineQty;
                } else {
                    $fb = (float)$products[$pid]['cost'];
                    if ($fb > 0) $cogs += $fb * (float)$got['left'];
                }
            }
            $newUnit = roundMoney($cogs / $lineQty);
            $oldUnit = isset($it['cost']) ? (float)$it['cost'] : 0.0;
            if (abs($oldUnit - $newUnit) >= 0.5) {
                $it['cost'] = $newUnit;
                $changed = true;
                $fixed++;
            }
        }
        unset($it);
        if (!$changed) return;
        $newJson = json_encode($items, JSON_UNESCAPED_UNICODE);
        if ($newJson === false) return;
        $st = $conn->prepare("UPDATE `{$table}` SET items_json = ? WHERE id = ?");
        if (!$st) return;
        $st->bind_param('si', $newJson, $id);
        if ($st->execute()) {
            $out['sales_updated']++;
            $out['lines_fixed'] += $fixed;
            if ($table === 'sales_archive') $out['archive_updated']++;
        }
    };

    // Merge sales + waste timeline by time (sales drive updates; waste only consumes).
    $saleEvents = [];
    $resSales = $conn->query('SELECT id, created_at, items_json FROM sales ORDER BY created_at ASC, id ASC');
    if ($resSales) {
        while ($r = $resSales->fetch_assoc()) {
            $saleEvents[] = [
                'kind' => 'sale',
                'table' => 'sales',
                't' => strtotime((string)($r['created_at'] ?? '')) ?: 0,
                'id' => (int)$r['id'],
                'created_at' => $r['created_at'],
                'items_json' => $r['items_json'],
            ];
        }
    }
    $hasArchive = false;
    try {
        $chk = $conn->query("SHOW TABLES LIKE 'sales_archive'");
        $hasArchive = ($chk && $chk->num_rows > 0);
    } catch (Throwable $e) {}
    if ($hasArchive) {
        $resA = $conn->query('SELECT id, created_at, items_json FROM sales_archive ORDER BY created_at ASC, id ASC');
        if ($resA) {
            while ($r = $resA->fetch_assoc()) {
                $saleEvents[] = [
                    'kind' => 'sale',
                    'table' => 'sales_archive',
                    't' => strtotime((string)($r['created_at'] ?? '')) ?: 0,
                    'id' => (int)$r['id'],
                    'created_at' => $r['created_at'],
                    'items_json' => $r['items_json'],
                ];
            }
        }
    }

    $timeline = array_merge($wasteEvents, $saleEvents);
    usort($timeline, function ($a, $b) {
        if ($a['t'] !== $b['t']) return $a['t'] <=> $b['t'];
        if ($a['kind'] === $b['kind']) return 0;
        // Waste before sale on same second (stock already gone).
        if ($a['kind'] === 'waste') return -1;
        if ($b['kind'] === 'waste') return 1;
        return 0;
    });

    foreach ($timeline as $ev) {
        if ($ev['kind'] === 'waste') {
            $pid = (int)$ev['pid'];
            if ($pid <= 0 || $ev['pieces'] <= 0) continue;
            $releaseUntil($pid, $ev['t']);
            $consume($pid, $ev['pieces']);
            continue;
        }
        $processSaleRow($ev['table'], $ev['id'], $ev['created_at'], $ev['items_json']);
    }

    // Sync catalog costs from latest non-return purchase (piece cost).
    $lastBuy = [];
    $resLast = $conn->query("SELECT prodId, qtyAdded, totalCost, `date`, `type`
        FROM supplies WHERE qtyAdded > 0 ORDER BY `date` DESC, id DESC");
    if ($resLast) {
        while ($r = $resLast->fetch_assoc()) {
            $typ = strtolower(trim((string)($r['type'] ?? '')));
            if ($typ === 'return' || $typ === 'opening') continue;
            $pid = (int)$r['prodId'];
            if (isset($lastBuy[$pid])) continue;
            $q = (float)$r['qtyAdded'];
            if ($q <= 0) continue;
            $lastBuy[$pid] = (float)$r['totalCost'] / $q;
        }
    }
    foreach ($lastBuy as $pid => $pieceCost) {
        if ($pieceCost <= 0) continue;
        if (function_exists('pos_apply_product_cost_for_unit')) {
            pos_apply_product_cost_for_unit($conn, $pid, 'piece', $pieceCost, 'IQD', 0);
            $out['products_synced']++;
        }
    }

    return $out;
}

/**
 * Lightweight gift/zero-lot COGS repair for past negative-stock sales.
 * Safe on daily-summary / calendar GET (throttled). Does NOT run full FIFO rewrite.
 *
 * @return array{ran:bool,gifts:int,sales_updated:int,lines_fixed:int,pieces_filled:float,skipped?:string}
 */
function pos_maybe_repair_gift_sale_cogs($conn) {
    $empty = ['ran' => false, 'gifts' => 0, 'sales_updated' => 0, 'lines_fixed' => 0, 'pieces_filled' => 0.0];
    if (!$conn) {
        return $empty + ['skipped' => 'no_conn'];
    }
    try {
        $fpRows = [];
        $hasGiftCol = false;
        try {
            $chk = $conn->query("SHOW COLUMNS FROM supplies LIKE 'is_gift'");
            $hasGiftCol = ($chk && $chk->num_rows > 0);
        } catch (Throwable $e) {}
        $sql = $hasGiftCol
            ? "SELECT id, prodId, qtyAdded, totalCost, `date`, is_gift, `type` FROM supplies WHERE qtyAdded > 0 AND (is_gift = 1 OR totalCost <= 0.00001) ORDER BY `date` ASC, id ASC"
            : "SELECT id, prodId, qtyAdded, totalCost, `date`, 0 AS is_gift, `type` FROM supplies WHERE qtyAdded > 0 AND totalCost <= 0.00001 ORDER BY `date` ASC, id ASC";
        $res = $conn->query($sql);
        if (!$res) {
            return $empty + ['skipped' => 'query'];
        }
        while ($r = $res->fetch_assoc()) {
            $typ = strtolower(trim((string)($r['type'] ?? '')));
            if ($typ === 'return' || $typ === 'opening' || $typ === 'supplier_return') {
                continue;
            }
            $fpRows[] = ((int)$r['id']) . ':' . ((int)$r['prodId']) . ':' . ((float)$r['qtyAdded']) . ':' . ((float)$r['totalCost']);
        }
        if (!$fpRows) {
            return $empty + ['skipped' => 'no_gifts'];
        }
        $fp = md5(implode('|', $fpRows));
        $stGet = $conn->prepare("SELECT setting_value FROM settings WHERE setting_key = 'gift_neg_cogs_repair_fp' LIMIT 1");
        $prev = '';
        if ($stGet) {
            $stGet->execute();
            $gr = $stGet->get_result();
            if ($gr && ($row = $gr->fetch_assoc())) {
                $prev = (string)($row['setting_value'] ?? '');
            }
        }
        // Re-run when gift lots change; otherwise at most once per 10 minutes.
        if ($prev === $fp) {
            $stTs = $conn->prepare("SELECT setting_value FROM settings WHERE setting_key = 'gift_neg_cogs_repair_at' LIMIT 1");
            $lastAt = 0;
            if ($stTs) {
                $stTs->execute();
                $tr = $stTs->get_result();
                if ($tr && ($row = $tr->fetch_assoc())) {
                    $lastAt = (int)$row['setting_value'];
                }
            }
            if ($lastAt > 0 && (time() - $lastAt) < 600) {
                return $empty + ['skipped' => 'throttled'];
            }
        }

        $out = ['ran' => true, 'gifts' => 0, 'sales_updated' => 0, 'lines_fixed' => 0, 'pieces_filled' => 0.0];
        $res2 = $conn->query($sql);
        while ($res2 && ($g = $res2->fetch_assoc())) {
            $typ = strtolower(trim((string)($g['type'] ?? '')));
            if ($typ === 'return' || $typ === 'opening' || $typ === 'supplier_return') {
                continue;
            }
            $pid = (int)($g['prodId'] ?? 0);
            $pcs = (float)($g['qtyAdded'] ?? 0);
            if ($pid <= 0 || $pcs <= 0.000001) {
                continue;
            }
            $isGift = !empty($g['is_gift']);
            $tc = (float)($g['totalCost'] ?? 0);
            if (!$isGift && $tc > 0.00001) {
                continue;
            }
            $unit = ($pcs > 0 && $tc > 0.00001) ? ($tc / $pcs) : 0.0;
            $before = (string)($g['date'] ?? '');
            $one = pos_apply_lot_cogs_to_prior_sales($conn, $pid, $pcs, $unit, [
                'force_cover' => true,
                'only_reduce' => true,
                'before_date' => $before,
            ]);
            $out['gifts']++;
            $out['sales_updated'] += (int)($one['sales_updated'] ?? 0);
            $out['lines_fixed'] += (int)($one['lines_fixed'] ?? 0);
            $out['pieces_filled'] += (float)($one['pieces_filled'] ?? 0);
        }
        $now = (string)time();
        $stSave = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('gift_neg_cogs_repair_fp', ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
        if ($stSave) {
            $stSave->bind_param('s', $fp);
            $stSave->execute();
        }
        $stSave2 = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('gift_neg_cogs_repair_at', ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
        if ($stSave2) {
            $stSave2->bind_param('s', $now);
            $stSave2->execute();
        }
        if (($out['sales_updated'] ?? 0) > 0 && function_exists('touchLastUpdate')) {
            touchLastUpdate($conn);
        }
        return $out;
    } catch (Throwable $e) {
        return $empty + ['skipped' => 'error'];
    }
}

/**
 * Lift pack/carton lines that FIFO priced as leftover pieces only (oversell → fake profit).
 * Example: 1 carton buy 65,000 with 195 pieces in stock was stamped ~29,684 (195×181).
 *
 * @return array{ran:bool,sales_updated:int,lines_fixed:int,skipped?:string}
 */
function pos_maybe_repair_partial_unit_sale_cogs($conn) {
    $empty = ['ran' => false, 'sales_updated' => 0, 'lines_fixed' => 0];
    if (!$conn) {
        return $empty + ['skipped' => 'no_conn'];
    }
    try {
        $stTs = $conn->prepare("SELECT setting_value FROM settings WHERE setting_key = 'partial_unit_cogs_repair_at' LIMIT 1");
        $lastAt = 0;
        if ($stTs) {
            $stTs->execute();
            $tr = $stTs->get_result();
            if ($tr && ($row = $tr->fetch_assoc())) {
                $lastAt = (int)$row['setting_value'];
            }
        }
        if ($lastAt > 0 && (time() - $lastAt) < 120) {
            return $empty + ['skipped' => 'throttled'];
        }

        $products = [];
        $resP = $conn->query('SELECT id, cost, cost_pack, cost_carton, pieces_per_pack, packs_per_carton, itemsPerCarton FROM products');
        if ($resP) {
            while ($r = $resP->fetch_assoc()) {
                $products[(int)$r['id']] = $r;
            }
        }
        if (!$products) {
            return $empty + ['skipped' => 'no_products'];
        }

        $tables = ['sales'];
        try {
            $chk = $conn->query("SHOW TABLES LIKE 'sales_archive'");
            if ($chk && $chk->num_rows > 0) {
                $tables[] = 'sales_archive';
            }
        } catch (Throwable $e) {}

        $out = ['ran' => true, 'sales_updated' => 0, 'lines_fixed' => 0];
        foreach ($tables as $table) {
            $res = $conn->query("SELECT id, items_json FROM `{$table}` WHERE items_json LIKE '%saleUnit%' ORDER BY id DESC LIMIT 400");
            if (!$res) {
                continue;
            }
            while ($row = $res->fetch_assoc()) {
                $items = json_decode((string)($row['items_json'] ?? ''), true);
                if (!is_array($items) || !$items) {
                    continue;
                }
                $changed = false;
                $fixed = 0;
                foreach ($items as &$it) {
                    if (!is_array($it) || !empty($it['isManualItem'])) {
                        continue;
                    }
                    $su = isset($it['saleUnit']) ? (string)$it['saleUnit'] : 'piece';
                    if ($su !== 'carton' && $su !== 'pack') {
                        continue;
                    }
                    $pid = (int)($it['id'] ?? 0);
                    if ($pid <= 0 || empty($products[$pid])) {
                        continue;
                    }
                    $p = $products[$pid];
                    $lineQty = pos_sale_item_line_qty($it);
                    if ($lineQty <= 0) {
                        continue;
                    }
                    if (empty($it['pieces_per_pack'])) {
                        $it['pieces_per_pack'] = max(1, (int)($p['pieces_per_pack'] ?? 1));
                        $it['packs_per_carton'] = max(1, (int)($p['packs_per_carton'] ?? 1));
                        $it['itemsPerCarton'] = (int)($p['itemsPerCarton'] ?? 0);
                    }
                    $need = pos_sale_item_pieces($it);
                    $oldUnit = isset($it['cost']) ? (float)$it['cost'] : 0.0;
                    $entered = pos_entered_catalog_cost_for_sale_unit($p, $su);
                    $pieceCost = (float)($p['cost'] ?? 0);
                    if ($entered <= $oldUnit + 0.5 || $pieceCost <= 0) {
                        continue;
                    }
                    if (!pos_sale_line_looks_like_partial_piece_cogs($oldUnit, $lineQty, $pieceCost, $need)) {
                        continue;
                    }
                    $it['cost'] = function_exists('roundMoney') ? roundMoney($entered) : round($entered, 2);
                    $changed = true;
                    $fixed++;
                }
                unset($it);
                if (!$changed) {
                    continue;
                }
                $flags = function_exists('pos_fifo_json_flags') ? pos_fifo_json_flags() : JSON_UNESCAPED_UNICODE;
                $newJson = json_encode($items, $flags);
                if ($newJson === false) {
                    continue;
                }
                $id = (int)$row['id'];
                $up = $conn->prepare("UPDATE `{$table}` SET items_json = ? WHERE id = ?");
                if (!$up) {
                    continue;
                }
                $up->bind_param('si', $newJson, $id);
                if ($up->execute()) {
                    $out['sales_updated']++;
                    $out['lines_fixed'] += $fixed;
                }
            }
        }

        $now = (string)time();
        $stSave = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('partial_unit_cogs_repair_at', ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
        if ($stSave) {
            $stSave->bind_param('s', $now);
            $stSave->execute();
        }
        if (($out['sales_updated'] ?? 0) > 0 && function_exists('touchLastUpdate')) {
            touchLastUpdate($conn);
        }
        return $out;
    } catch (Throwable $e) {
        return $empty + ['skipped' => 'error'];
    }
}

/**
 * Rewrite COGS on newest prior sale lines for a restock lot.
 *
 * @param array{force_cover?:bool,only_reduce?:bool,before_date?:string} $opts
 * @return array{sales_updated:int,lines_fixed:int,pieces_filled:float}
 */
function pos_apply_lot_cogs_to_prior_sales($conn, $pid, $piecesIn, $pieceUnitCost, $opts = []) {
    $out = ['sales_updated' => 0, 'lines_fixed' => 0, 'pieces_filled' => 0.0];
    $pid = (int)$pid;
    $piecesIn = (float)$piecesIn;
    $pieceUnitCost = max(0.0, (float)$pieceUnitCost);
    $opts = is_array($opts) ? $opts : [];
    $forceCover = !empty($opts['force_cover']);
    $onlyReduce = !empty($opts['only_reduce']);
    $beforeDate = isset($opts['before_date']) ? trim((string)$opts['before_date']) : '';
    if (!$conn || $pid <= 0 || $piecesIn <= 0.000001) {
        return $out;
    }
    $meta = null;
    try {
        $st = $conn->prepare('SELECT qty, trackStock, cost, pieces_per_pack, packs_per_carton, itemsPerCarton FROM products WHERE id = ? LIMIT 1');
        if ($st) {
            $st->bind_param('i', $pid);
            $st->execute();
            $meta = $st->get_result()->fetch_assoc();
        }
    } catch (Throwable $e) {
        return $out;
    }
    if (!$meta || empty($meta['trackStock'])) {
        return $out;
    }

    $cover = $piecesIn;
    if (!$forceCover) {
        $qtyAfter = (float)($meta['qty'] ?? 0);
        $qtyBefore = $qtyAfter - $piecesIn;
        if ($qtyBefore >= -0.000001) {
            return $out;
        }
        $cover = min($piecesIn, -$qtyBefore);
    }
    if ($cover <= 0.000001) {
        return $out;
    }

    $ppp = max(1, (int)($meta['pieces_per_pack'] ?? 1));
    $ppc = max(1, (int)($meta['packs_per_carton'] ?? 1));
    $ipc = (int)($meta['itemsPerCarton'] ?? 0);
    $piecesPerCarton = ($ipc > 1) ? $ipc : ($ppp * $ppc);
    $rm = function_exists('roundMoney') ? 'roundMoney' : null;

    $linePieces = function (array $it) use ($ppp, $ppc, $piecesPerCarton) {
        if (empty($it['pieces_per_pack'])) {
            $it['pieces_per_pack'] = $ppp;
            $it['packs_per_carton'] = $ppc;
            $it['itemsPerCarton'] = $piecesPerCarton;
        }
        return pos_sale_item_pieces($it);
    };

    $tables = ['sales'];
    try {
        $chk = $conn->query("SHOW TABLES LIKE 'sales_archive'");
        if ($chk && $chk->num_rows > 0) {
            $tables[] = 'sales_archive';
        }
    } catch (Throwable $e) {}

    $likeNum = '%"id":' . $pid . '%';
    $likeNumSp = '%"id": ' . $pid . '%';
    $likeStr = '%"id":"' . $pid . '"%';
    $rows = [];
    foreach ($tables as $table) {
        $sql = "SELECT id, created_at, items_json FROM `{$table}` WHERE items_json LIKE ? OR items_json LIKE ? OR items_json LIKE ? ORDER BY created_at DESC, id DESC";
        $st = $conn->prepare($sql);
        if (!$st) {
            continue;
        }
        $st->bind_param('sss', $likeNum, $likeNumSp, $likeStr);
        $st->execute();
        $res = $st->get_result();
        while ($res && ($r = $res->fetch_assoc())) {
            if ($beforeDate !== '') {
                $saleTs = strtotime((string)($r['created_at'] ?? '')) ?: 0;
                $lotTs = strtotime($beforeDate) ?: 0;
                // Sale must be at/before the restock lot (negative stock then filled).
                if ($lotTs > 0 && $saleTs > $lotTs) {
                    continue;
                }
            }
            $r['_table'] = $table;
            $rows[] = $r;
        }
    }
    usort($rows, function ($a, $b) {
        $ta = strtotime((string)($a['created_at'] ?? '')) ?: 0;
        $tb = strtotime((string)($b['created_at'] ?? '')) ?: 0;
        if ($ta !== $tb) {
            return $tb <=> $ta;
        }
        return ((int)($b['id'] ?? 0)) <=> ((int)($a['id'] ?? 0));
    });

    $left = $cover;
    foreach ($rows as $row) {
        if ($left <= 0.000001) {
            break;
        }
        $items = json_decode((string)($row['items_json'] ?? ''), true);
        if (!is_array($items) || !$items) {
            continue;
        }
        $changed = false;
        $fixed = 0;
        for ($i = count($items) - 1; $i >= 0 && $left > 0.000001; $i--) {
            $it = $items[$i];
            if (!is_array($it) || !empty($it['isManualItem'])) {
                continue;
            }
            if ((int)($it['id'] ?? 0) !== $pid) {
                continue;
            }
            $pcs = $linePieces($it);
            if ($pcs <= 0.000001) {
                continue;
            }
            $lineQty = pos_sale_item_line_qty($it);
            if ($lineQty <= 0.000001) {
                continue;
            }
            $take = min($left, $pcs);
            $oldUnit = isset($it['cost']) ? (float)$it['cost'] : 0.0;
            // only_reduce: lower expensive oversold COGS toward this lot; ALSO fill zero-cost oversell holes.
            if ($onlyReduce && $oldUnit > 0.005 && $oldUnit <= ($pieceUnitCost + 0.005)) {
                continue;
            }
            $oldCogs = $oldUnit * $lineQty;
            $share = $take / $pcs;
            $newCogs = $oldCogs - ($oldCogs * $share) + ($pieceUnitCost * $take);
            $newUnit = $rm ? $rm($newCogs / $lineQty) : round($newCogs / $lineQty, 3);
            if (abs($newUnit - $oldUnit) < 0.005) {
                continue;
            }
            // Allow raising from ~0 (negative-stock oversell stamp) to paid lot cost.
            if ($onlyReduce && $oldUnit > 0.005 && $newUnit > $oldUnit + 0.005) {
                continue;
            }
            $items[$i]['cost'] = $newUnit;
            if (isset($it['cost_usd']) || isset($it['base_cost'])) {
                // Drop stale USD stamp so reports re-lock from IQD + sale FX.
                unset($items[$i]['cost_usd']);
            }
            $changed = true;
            $fixed++;
            $left -= $take;
            $out['pieces_filled'] += $take;
        }
        if (!$changed) {
            continue;
        }
        $flags = function_exists('pos_fifo_json_flags') ? pos_fifo_json_flags() : JSON_UNESCAPED_UNICODE;
        $newJson = json_encode($items, $flags);
        if ($newJson === false) {
            continue;
        }
        $table = (string)$row['_table'];
        $id = (int)$row['id'];
        $up = $conn->prepare("UPDATE `{$table}` SET items_json = ? WHERE id = ?");
        if (!$up) {
            continue;
        }
        $up->bind_param('si', $newJson, $id);
        if ($up->execute()) {
            $out['sales_updated']++;
            $out['lines_fixed'] += $fixed;
        }
    }
    return $out;
}

/**
 * After a purchase restocks a product that was sold into negative qty, rewrite
 * COGS on the oversold sale lines using this lot's piece cost (0 for free gift).
 * Call AFTER products.qty has been increased. Covers only the hole this lot fills.
 *
 * @return array{sales_updated:int,lines_fixed:int,pieces_filled:float}
 */
function pos_restock_negative_inventory_sale_cogs($conn, $pid, $piecesIn, $pieceUnitCost) {
    return pos_apply_lot_cogs_to_prior_sales($conn, $pid, $piecesIn, $pieceUnitCost, [
        'force_cover' => false,
        'only_reduce' => true,
    ]);
}

/** Run after a purchase line has increased products.qty (gift lot cost may be 0). */
function pos_after_purchase_stock_in_cogs($conn, $pid, $pieces, $totalCost) {
    try {
        if (!function_exists('pos_restock_negative_inventory_sale_cogs')) {
            return;
        }
        $pcs = (float)$pieces;
        $pid = (int)$pid;
        if ($pid <= 0 || $pcs <= 0.000001) {
            return;
        }
        $unit = $pcs > 0 ? ((float)$totalCost / $pcs) : 0.0;
        pos_restock_negative_inventory_sale_cogs($conn, $pid, $pcs, $unit);
    } catch (Throwable $e) {
        return;
    }
}

function pos_sale_items_subtotal(array $items): float {
    $sum = 0.0;
    foreach ($items as $it) {
        if (!is_array($it) || !empty($it['isGift'])) continue;
        $q = pos_sale_item_line_qty($it);
        $price = roundMoney((float)($it['price'] ?? 0));
        $sum += roundMoney($price * $q);
    }
    return roundMoney($sum);
}

/** Scale split-payment columns when invoice total changes (history line edit). */
function pos_sale_scale_split_amounts(array $row, float $newTotal): array {
    $oldTotal = roundMoney((float)($row['total'] ?? 0));
    if ($oldTotal <= 0) {
        return [
            'paid_amount' => $newTotal,
            'paid_cash' => $newTotal,
            'paid_bank' => 0.0,
            'bank_amount' => 0.0,
            'debt_amount' => 0.0,
            'remaining_debt' => 0.0,
            'received_amount' => $newTotal,
        ];
    }
    $ratio = $newTotal / $oldTotal;
    $paidCash = roundMoney((float)($row['paid_cash'] ?? 0) * $ratio);
    $paidBank = roundMoney((float)($row['paid_bank'] ?? ($row['bank_amount'] ?? 0)) * $ratio);
    $remainingDebt = roundMoney((float)($row['remaining_debt'] ?? ($row['debt_amount'] ?? 0)) * $ratio);
    $sum = roundMoney($paidCash + $paidBank + $remainingDebt);
    if (abs($sum - $newTotal) >= 0.02) {
        $remainingDebt = roundMoney(max(0, $newTotal - $paidCash - $paidBank));
    }
    $paidAmount = roundMoney($paidCash + $paidBank);
    return [
        'paid_amount' => $paidAmount,
        'paid_cash' => $paidCash,
        'paid_bank' => $paidBank,
        'bank_amount' => $paidBank,
        'debt_amount' => $remainingDebt,
        'remaining_debt' => $remainingDebt,
        'received_amount' => $paidAmount,
    ];
}

function pos_attach_sale_customer_field(mysqli $conn, array &$r): void {
    $cid = (int)($r['customer_id'] ?? 0);
    if ($cid > 0 && empty($r['customer'])) {
        $name = pos_resolve_sale_customer_name($conn, $cid, (string)($r['customer_type'] ?? 'customer'));
        if ($name !== '') {
            $r['customer'] = $name;
        }
    }
}

function pos_resolve_sale_customer_name(mysqli $conn, int $customerId, string $customerType = 'customer'): string {
    if ($customerId <= 0) {
        return '';
    }
    $ctype = strtolower(trim($customerType));
    if ($ctype === 'customers') {
        $ctype = 'customer';
    }
    if ($ctype === 'user') {
        $stmt = $conn->prepare('SELECT name FROM users WHERE id = ? LIMIT 1');
    } else {
        $stmt = $conn->prepare('SELECT name FROM customers WHERE id = ? LIMIT 1');
    }
    if (!$stmt) {
        return '';
    }
    $stmt->bind_param('i', $customerId);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res && ($row = $res->fetch_assoc())) {
        return trim((string)($row['name'] ?? ''));
    }
    return '';
}

function pos_format_sale_history_row(array $r, ?mysqli $conn = null) {
    $r['id'] = (int)($r['id'] ?? 0);
    $r['total'] = roundMoney($r['total'] ?? 0);
    $r['discount'] = roundMoney($r['discount'] ?? 0);
    $itemsJson = $r['items_json'] ?? '[]';
    unset($r['items_json']);
    $decoded = json_decode($itemsJson, true);
    $r['items'] = is_array($decoded) ? $decoded : [];
    $r['is_returned'] = (int)($r['is_returned'] ?? 0);
    if (isset($r['created_at']) && !isset($r['date'])) {
        $r['date'] = $r['created_at'];
    }
    // Skip per-row DB lookup here — callers batch via pos_attach_sale_customers_batch
    if ($conn && !empty($r['_attach_customer_now'])) {
        unset($r['_attach_customer_now']);
        pos_attach_sale_customer_field($conn, $r);
    }
    return $r;
}

/** Resolve customer names for many sale rows in 1–2 queries (avoids N+1). */
function pos_attach_sale_customers_batch(mysqli $conn, array &$sales): void {
    if (!$sales) {
        return;
    }
    $custIds = [];
    $userIds = [];
    foreach ($sales as $r) {
        $cid = (int)($r['customer_id'] ?? 0);
        if ($cid <= 0 || !empty($r['customer'])) {
            continue;
        }
        $ctype = strtolower(trim((string)($r['customer_type'] ?? 'customer')));
        if ($ctype === 'customers') {
            $ctype = 'customer';
        }
        if ($ctype === 'user') {
            $userIds[$cid] = true;
        } else {
            $custIds[$cid] = true;
        }
    }
    $custMap = [];
    $userMap = [];
    if ($custIds) {
        $ids = array_keys($custIds);
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $types = str_repeat('i', count($ids));
        $stmt = $conn->prepare("SELECT id, name FROM customers WHERE id IN ({$placeholders})");
        if ($stmt) {
            $stmt->bind_param($types, ...$ids);
            if ($stmt->execute()) {
                $res = $stmt->get_result();
                if ($res) {
                    while ($row = $res->fetch_assoc()) {
                        $custMap[(int)$row['id']] = trim((string)($row['name'] ?? ''));
                    }
                }
            }
        }
    }
    if ($userIds) {
        $ids = array_keys($userIds);
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $types = str_repeat('i', count($ids));
        $stmt = $conn->prepare("SELECT id, name FROM users WHERE id IN ({$placeholders})");
        if ($stmt) {
            $stmt->bind_param($types, ...$ids);
            if ($stmt->execute()) {
                $res = $stmt->get_result();
                if ($res) {
                    while ($row = $res->fetch_assoc()) {
                        $userMap[(int)$row['id']] = trim((string)($row['name'] ?? ''));
                    }
                }
            }
        }
    }
    foreach ($sales as &$r) {
        $cid = (int)($r['customer_id'] ?? 0);
        if ($cid <= 0 || !empty($r['customer'])) {
            continue;
        }
        $ctype = strtolower(trim((string)($r['customer_type'] ?? 'customer')));
        if ($ctype === 'customers') {
            $ctype = 'customer';
        }
        if ($ctype === 'user') {
            if (!empty($userMap[$cid])) {
                $r['customer'] = $userMap[$cid];
            }
        } elseif (!empty($custMap[$cid])) {
            $r['customer'] = $custMap[$cid];
        }
    }
    unset($r);
}

/**
 * Paginated sales history (sales + optional archive). Date range required; capped row count.
 *
 * @return array{sales: array, date_from: string, date_to: string, limit: int, offset: int, has_more: bool}
 */
function pos_fetch_sales_history_rows(mysqli $conn, array $opts) {
    $today = date('Y-m-d');
    $defaultFrom = date('Y-m-d', strtotime('-90 days'));
    $dateFrom = pos_parse_history_date_ymd($opts['date_from'] ?? '', $defaultFrom);
    $dateTo = pos_parse_history_date_ymd($opts['date_to'] ?? '', $today);
    if ($dateFrom > $dateTo) {
        $tmp = $dateFrom;
        $dateFrom = $dateTo;
        $dateTo = $tmp;
    }

    $limit = (int)($opts['limit'] ?? 200);
    if ($limit < 20) $limit = 20;
    if ($limit > 10000) $limit = 10000;
    $offset = max(0, (int)($opts['offset'] ?? 0));
    $includeArchive = !isset($opts['include_archive']) || (int)$opts['include_archive'] !== 0;
    $cashier = isset($opts['cashier']) ? trim((string)$opts['cashier']) : '';
    $q = trim((string)($opts['q'] ?? ''));
    $customer_id = isset($opts['customer_id']) ? trim((string)$opts['customer_id']) : '';
    $customer_type = isset($opts['customer_type']) ? trim((string)$opts['customer_type']) : '';

    $dtStart = $dateFrom . ' 00:00:00';
    $dtEnd = $dateTo . ' 23:59:59';

    $tables = ['sales'];
    if ($includeArchive) {
        $tables[] = 'sales_archive';
    }

    $cols = 'id, total, discount, items_json, created_at, cashier, payment_method, customer_id, customer_type, is_returned, transaction_id, fx_usd_rate, fx_currency_mode';
    $parts = [];
    $params = [];
    $types = '';

    foreach ($tables as $table) {
        $sql = "SELECT {$cols} FROM {$table} WHERE created_at >= ? AND created_at <= ?";
        $params[] = $dtStart;
        $params[] = $dtEnd;
        $types .= 'ss';
        if ($cashier !== '') {
            $sql .= ' AND cashier = ?';
            $params[] = $cashier;
            $types .= 's';
        }
        if ($customer_id !== '') {
            $sql .= ' AND customer_id = ?';
            $params[] = $customer_id;
            $types .= 's';
        }
        if ($customer_type !== '') {
            $sql .= ' AND customer_type = ?';
            $params[] = $customer_type;
            $types .= 's';
        }
        if ($q !== '') {
            if (ctype_digit($q)) {
                $sql .= ' AND id = ?';
                $params[] = (int)$q;
                $types .= 'i';
            } else {
                $like = '%' . $q . '%';
                $sql .= ' AND (cashier LIKE ? OR items_json LIKE ?)';
                $params[] = $like;
                $params[] = $like;
                $types .= 'ss';
            }
        }
        $parts[] = $sql;
    }

    $union = implode(' UNION ALL ', $parts);
    $fetchLimit = $limit + 1;
    $sql = "SELECT * FROM ({$union}) u ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?";
    $params[] = $fetchLimit;
    $params[] = $offset;
    $types .= 'ii';

    $sales = [];
    $sqlError = '';
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        $sqlError = (string)($conn->error ?: 'prepare_failed');
    } else {
        $stmt->bind_param($types, ...$params);
        if (!$stmt->execute()) {
            $sqlError = (string)($stmt->error ?: 'execute_failed');
        } else {
            $res = $stmt->get_result();
            if ($res) {
                while ($row = $res->fetch_assoc()) {
                    $sales[] = pos_format_sale_history_row($row, null);
                }
            }
        }
    }

    // If UNION with archive fails (schema/migration drift), retry sales table only.
    if ($sqlError !== '' && count($tables) > 1) {
        $sales = [];
        $sqlError = '';
        $parts = [];
        $params = [];
        $types = '';
        $table = 'sales';
        $sql = "SELECT {$cols} FROM {$table} WHERE created_at >= ? AND created_at <= ?";
        $params[] = $dtStart;
        $params[] = $dtEnd;
        $types .= 'ss';
        if ($cashier !== '') {
            $sql .= ' AND cashier = ?';
            $params[] = $cashier;
            $types .= 's';
        }
        if ($customer_id !== '') {
            $sql .= ' AND customer_id = ?';
            $params[] = $customer_id;
            $types .= 's';
        }
        if ($customer_type !== '') {
            $sql .= ' AND customer_type = ?';
            $params[] = $customer_type;
            $types .= 's';
        }
        if ($q !== '') {
            if (ctype_digit($q)) {
                $sql .= ' AND id = ?';
                $params[] = (int)$q;
                $types .= 'i';
            } else {
                $like = '%' . $q . '%';
                $sql .= ' AND (cashier LIKE ? OR items_json LIKE ?)';
                $params[] = $like;
                $params[] = $like;
                $types .= 'ss';
            }
        }
        $fetchLimit = $limit + 1;
        $sql .= ' ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?';
        $params[] = $fetchLimit;
        $params[] = $offset;
        $types .= 'ii';
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param($types, ...$params);
            if ($stmt->execute()) {
                $res = $stmt->get_result();
                if ($res) {
                    while ($row = $res->fetch_assoc()) {
                        $sales[] = pos_format_sale_history_row($row, null);
                    }
                }
            } else {
                $sqlError = (string)($stmt->error ?: 'execute_failed');
            }
        } else {
            $sqlError = (string)($conn->error ?: 'prepare_failed');
        }
    }

    $hasMore = count($sales) > $limit;
    if ($hasMore) {
        array_pop($sales);
    }

    if ($sqlError === '' && $sales) {
        pos_attach_sale_customers_batch($conn, $sales);
        if (function_exists('pos_attach_sales_history_adjustment_meta')) {
            pos_attach_sales_history_adjustment_meta($conn, $sales);
        }
    }

    return [
        'sales' => $sales,
        'date_from' => $dateFrom,
        'date_to' => $dateTo,
        'limit' => $limit,
        'offset' => $offset,
        'has_more' => $hasMore,
        'error' => $sqlError !== '' ? $sqlError : null,
    ];
}

function pos_fetch_sale_record_by_id(mysqli $conn, $id) {
    $id = (int)$id;
    if ($id <= 0) {
        return null;
    }
    foreach (['sales', 'sales_archive'] as $table) {
        $stmt = $conn->prepare("SELECT * FROM {$table} WHERE id = ? LIMIT 1");
        if (!$stmt) {
            continue;
        }
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res && ($row = $res->fetch_assoc())) {
            $row['_source'] = $table;
            return pos_format_sale_history_row($row, $conn);
        }
    }
    return null;
}

/** Record cash leaving the drawer for a purchase (expenses only — ledger purchase entry is separate). */
/** Sequential purchase invoice id (000001…) — not TXPI_LOCAL_/uniqid. */
function allocateNextPurchaseTransactionId($conn) {
    $max = 0;
    $tables = [
        "SELECT transaction_id FROM supplies WHERE transaction_id IS NOT NULL AND transaction_id != ''",
        "SELECT transaction_id FROM ledger WHERE transaction_id IS NOT NULL AND transaction_id != ''",
        "SELECT transaction_id FROM expenses WHERE transaction_id IS NOT NULL AND transaction_id != '' AND type = 'purchase'",
    ];
    foreach ($tables as $sql) {
        $res = $conn->query($sql);
        if (!$res) continue;
        while ($row = $res->fetch_assoc()) {
            $tid = trim((string)($row['transaction_id'] ?? ''));
            if (preg_match('/^\d{1,12}$/', $tid)) {
                $n = (int)$tid;
                if ($n > $max) $max = $n;
            }
        }
    }
    return str_pad((string)($max + 1), 6, '0', STR_PAD_LEFT);
}

/** Lowercase + numeric padding variants for matching purchase invoice refs (supplier # or internal txn id). */
function pos_purchase_invoice_ref_variants(string $ref): array {
    $ref = trim($ref);
    $out = [];
    if ($ref === '') {
        return $out;
    }
    $out[] = mb_strtolower($ref, 'UTF-8');
    if (preg_match('/^\d{1,12}$/', $ref)) {
        $n = (int)$ref;
        $out[] = (string)$n;
        $out[] = str_pad((string)$n, 6, '0', STR_PAD_LEFT);
    }
    return array_values(array_unique(array_filter($out, static function ($v) {
        return $v !== '';
    })));
}

function pos_supply_row_invoice_ref_variants(array $row): array {
    $out = [];
    $sup = trim((string)($row['supplier_invoice_number'] ?? ''));
    if ($sup !== '') {
        $out[] = mb_strtolower($sup, 'UTF-8');
    }
    $tid = trim((string)($row['transaction_id'] ?? ''));
    if ($tid !== '') {
        $out[] = mb_strtolower($tid, 'UTF-8');
        if (preg_match('/^\d{1,12}$/', $tid)) {
            $n = (int)$tid;
            $out[] = (string)$n;
            $out[] = str_pad((string)$n, 6, '0', STR_PAD_LEFT);
        }
    }
    return array_values(array_unique(array_filter($out, static function ($v) {
        return $v !== '';
    })));
}

function pos_supply_row_matches_invoice_ref(array $row, array $userVariants): bool {
    if (!$userVariants) {
        return true;
    }
    $rowVars = pos_supply_row_invoice_ref_variants($row);
    foreach ($userVariants as $uv) {
        if (in_array($uv, $rowVars, true)) {
            return true;
        }
    }
    return false;
}

/**
 * Resolve user-entered purchase return ref to canonical supplier invoice + transaction id.
 * Accepts supplier invoice # or internal POS purchase id (e.g. 45 / 000045).
 *
 * @return array{supplier_invoice_number:string,transaction_id:string,canonical:string}|null
 */
function pos_resolve_purchase_supplier_invoice_ref(mysqli $conn, string $companyName, string $userRef): ?array {
    $companyName = trim($companyName);
    $userRef = trim($userRef);
    if ($companyName === '' || $userRef === '') {
        return null;
    }
    $userVariants = pos_purchase_invoice_ref_variants($userRef);
    $stmt = $conn->prepare(
        "SELECT supplier_invoice_number, transaction_id FROM supplies
         WHERE company = ? AND COALESCE(type, '') NOT IN ('return', 'opening') AND qtyAdded > 0"
    );
    if (!$stmt) {
        return null;
    }
    $stmt->bind_param('s', $companyName);
    $stmt->execute();
    $res = $stmt->get_result();
    if (!$res) {
        return null;
    }
    $byTxn = [];
    while ($row = $res->fetch_assoc()) {
        if (!pos_supply_row_matches_invoice_ref($row, $userVariants)) {
            continue;
        }
        $txn = trim((string)($row['transaction_id'] ?? ''));
        $sup = trim((string)($row['supplier_invoice_number'] ?? ''));
        if ($txn === '' && $sup === '') {
            continue;
        }
        $key = $txn !== '' ? $txn : ('sup:' . $sup);
        $byTxn[$key] = [
            'supplier_invoice_number' => $sup,
            'transaction_id' => $txn,
        ];
    }
    if (!$byTxn) {
        return null;
    }
    $pick = reset($byTxn);
    $canonical = $pick['supplier_invoice_number'] !== '' ? $pick['supplier_invoice_number'] : $pick['transaction_id'];
    if ($canonical === '') {
        return null;
    }
    $pick['canonical'] = $canonical;
    return $pick;
}

function insertCashPurchaseExpense($conn, $amount, $note, $user, $date, $txnId) {
    $amount = roundMoney($amount);
    if ($amount <= 0) return 0;
    $type = 'purchase';
    $stmt = $conn->prepare("INSERT INTO expenses (note, amount, `date`, user, type, transaction_id) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sdssss", $note, $amount, $date, $user, $type, $txnId);
    $stmt->execute();
    $id = (int)$stmt->insert_id;
    if (function_exists('pos_expense_stamp_fx')) {
        pos_expense_stamp_fx($conn, $id, 'IQD');
    }
    return $id;
}

/**
 * Resolve how an original supplier invoice was paid (cash / credit / split).
 * Used by purchase returns so cash purchases do not reduce company debt balance.
 * Matches by transaction_id and/or supplier_invoice_number (credit returns often
 * resolve canonical ref to txn id when supplier invoice # was empty).
 */
function pos_purchase_invoice_context(mysqli $conn, string $companyName, string $supplierInvoiceNumber, string $purchaseTransactionId = ''): array {
    $ctx = [
        'payment_type' => 'cash',
        'transaction_id' => '',
        'invoice_total' => 0.0,
        'debt_ratio' => 0.0,
        'cash_ratio' => 1.0,
    ];
    $companyName = trim($companyName);
    $supplierInvoiceNumber = trim($supplierInvoiceNumber);
    $purchaseTransactionId = trim($purchaseTransactionId);
    if ($companyName === '') return $ctx;

    $row = null;
    // Prefer exact purchase transaction id when known (most reliable for credit/split).
    if ($purchaseTransactionId !== '') {
        $stmt = $conn->prepare(
            "SELECT type, transaction_id, SUM(totalCost) AS invoice_total
             FROM supplies
             WHERE company = ? AND transaction_id = ?
               AND qtyAdded > 0 AND COALESCE(type, '') NOT IN ('return', 'opening')
             GROUP BY transaction_id, type
             ORDER BY invoice_total DESC LIMIT 1"
        );
        if ($stmt) {
            $stmt->bind_param('ss', $companyName, $purchaseTransactionId);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($res) $row = $res->fetch_assoc();
        }
    }
    if (!$row && $supplierInvoiceNumber !== '') {
        $stmt = $conn->prepare(
            "SELECT type, transaction_id, SUM(totalCost) AS invoice_total
             FROM supplies
             WHERE company = ?
               AND qtyAdded > 0 AND COALESCE(type, '') NOT IN ('return', 'opening')
               AND (
                    (supplier_invoice_number != '' AND supplier_invoice_number = ?)
                    OR (transaction_id != '' AND transaction_id = ?)
               )
             GROUP BY transaction_id, type
             ORDER BY invoice_total DESC LIMIT 1"
        );
        if ($stmt) {
            $stmt->bind_param('sss', $companyName, $supplierInvoiceNumber, $supplierInvoiceNumber);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($res) $row = $res->fetch_assoc();
        }
    }
    if (!$row) return $ctx;

    $payType = strtolower(trim((string)($row['type'] ?? 'cash')));
    if ($payType === '' || $payType === 'purchase') $payType = 'cash';
    if ($payType === 'fib' || $payType === 'bank' || $payType === 'bankcard') $payType = 'fib';
    $txnId = trim((string)($row['transaction_id'] ?? ''));
    $invoiceTotal = roundMoney((float)($row['invoice_total'] ?? 0));
    $ctx['payment_type'] = in_array($payType, ['cash', 'credit', 'split', 'fib'], true) ? $payType : 'cash';
    $ctx['transaction_id'] = $txnId;
    $ctx['invoice_total'] = $invoiceTotal;

    $debtRatio = 0.0;
    if ($ctx['payment_type'] === 'credit') {
        $debtRatio = 1.0;
    } elseif ($ctx['payment_type'] === 'fib') {
        $debtRatio = 0.0;
    } elseif ($ctx['payment_type'] === 'split' && $txnId !== '') {
        $stNet = $conn->prepare("SELECT COALESCE(SUM(CASE WHEN type = 'credit_purchase' THEN amount ELSE 0 END), 0) AS cr, COALESCE(SUM(CASE WHEN type = 'payment' THEN amount ELSE 0 END), 0) AS paid FROM ledger WHERE transaction_id = ?");
        if ($stNet) {
            $stNet->bind_param('s', $txnId);
            $stNet->execute();
            $netRow = $stNet->get_result()->fetch_assoc();
            $debtNet = roundMoney(max(0, (float)($netRow['cr'] ?? 0) - (float)($netRow['paid'] ?? 0)));
            if ($invoiceTotal > 0) $debtRatio = min(1.0, $debtNet / $invoiceTotal);
        }
    }
    $ctx['debt_ratio'] = $debtRatio;
    $ctx['cash_ratio'] = max(0.0, 1.0 - $debtRatio);
    if ($ctx['payment_type'] === 'fib') {
        $ctx['cash_ratio'] = 0.0;
    }
    return $ctx;
}

/** Cash purchase return — money received back from supplier (reduces purchase expenses). */
function insertPurchaseReturnCashRefund($conn, $amount, $note, $user, $date, $txnId) {
    $amount = roundMoney($amount);
    if ($amount <= 0) return 0;
    $negAmount = -$amount;
    $type = 'purchase_return';
    $stmt = $conn->prepare("INSERT INTO expenses (note, amount, `date`, user, type, transaction_id) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param('sdssss', $note, $negAmount, $date, $user, $type, $txnId);
    $stmt->execute();
    $id = (int)$stmt->insert_id;
    if (function_exists('pos_expense_stamp_fx')) {
        pos_expense_stamp_fx($conn, $id, 'IQD');
    }
    return $id;
}

/**
 * Apply purchase-return money effects: debt reduction only when original invoice had debt.
 *
 * @return array{payment_type:string,debt_adjusted:float,cash_refunded:float,company_balance:float}
 */
function pos_apply_purchase_return_financials(mysqli $conn, int $companyId, string $companyName, float $grandTotal, string $date, string $txnId, string $supplierInvoiceNumber, string $user, int $itemCount, string $purchaseTransactionId = ''): array {
    $ctx = pos_purchase_invoice_context($conn, $companyName, $supplierInvoiceNumber, $purchaseTransactionId);
    $grandTotal = roundMoney($grandTotal);
    $debtAmt = roundMoney($grandTotal * (float)$ctx['debt_ratio']);
    $cashAmt = roundMoney($grandTotal - $debtAmt);
    if (($ctx['payment_type'] ?? '') === 'fib') {
        $debtAmt = 0.0;
        $cashAmt = 0.0;
    }

    if ($debtAmt > 0 && $companyId > 0) {
        $stmtComp = $conn->prepare('UPDATE companies SET balance = balance - ? WHERE id = ?');
        $stmtComp->bind_param('di', $debtAmt, $companyId);
        $stmtComp->execute();
    }

    $ledgerNote = 'زڤڕاندن بۆ کۆمپانیا';
    if ($supplierInvoiceNumber !== '') $ledgerNote .= ' | پسوول=' . $supplierInvoiceNumber;
    if ($purchaseTransactionId !== '') $ledgerNote .= ' | کڕین=' . $purchaseTransactionId;
    $ledgerNote .= ' | items=' . $itemCount;
    if ($cashAmt > 0 && $debtAmt > 0) {
        $ledgerNote .= ' | قەرز=' . $debtAmt . ' | نەقد=' . $cashAmt;
    } elseif ($cashAmt > 0) {
        $ledgerNote .= ' | نەقد (کاش)';
    } elseif ($debtAmt > 0) {
        $ledgerNote .= ' | قەرز=' . $debtAmt;
    }

    // Ledger amount must match debt effect only — cash returns use expenses, not debt ledger.
    if ($debtAmt > 0 && $companyId > 0) {
        $stmtL = $conn->prepare("INSERT INTO ledger (companyId, type, amount, date, note, transaction_id) VALUES (?, 'return_to_supplier', ?, ?, ?, ?)");
        $stmtL->bind_param('idsss', $companyId, $debtAmt, $date, $ledgerNote, $txnId);
        $stmtL->execute();
    }

    if ($cashAmt > 0) {
        $refNote = 'زڤڕاندنا کڕینێ (نەقد): ' . $companyName;
        if ($supplierInvoiceNumber !== '') $refNote .= ' | پسوول=' . $supplierInvoiceNumber;
        insertPurchaseReturnCashRefund($conn, $cashAmt, $refNote, $user, $date, $txnId);
    }

    $companyBalance = 0.0;
    if ($companyId > 0) {
        $stBal = $conn->prepare('SELECT balance FROM companies WHERE id = ? LIMIT 1');
        if ($stBal) {
            $stBal->bind_param('i', $companyId);
            $stBal->execute();
            $balRow = $stBal->get_result()->fetch_assoc();
            if ($balRow) $companyBalance = roundMoney((float)($balRow['balance'] ?? 0));
        }
    }

    return [
        'payment_type' => (string)$ctx['payment_type'],
        'debt_adjusted' => $debtAmt,
        'cash_refunded' => $cashAmt,
        'company_balance' => $companyBalance,
    ];
}

/**
 * How much of a sales return should reduce customer debt vs cash refund.
 * DEBT-FIRST (anti cash-drain): unpaid remaining_debt is cleared before any drawer cash-out.
 *
 * Fraud test: sale $1000 = $400 cash + $600 debt; return $500 → debt_adjusted=$500, cash_refunded=$0.
 *
 * @return array{payment_type:string,effective_payment_method:string,sale_total:float,debt_ratio:float,debt_adjusted:float,cash_refunded:float,fib_refunded:float,target_id:int,target_type:string,open_debt:float}
 */
function pos_sale_return_financials(mysqli $conn, int $saleId, float $returnTotal): array {
    $out = [
        'payment_type' => 'cash',
        'effective_payment_method' => 'cash',
        'sale_total' => 0.0,
        'debt_ratio' => 0.0,
        'debt_adjusted' => 0.0,
        'cash_refunded' => 0.0,
        'fib_refunded' => 0.0,
        'target_id' => 0,
        'target_type' => '',
        'open_debt' => 0.0,
    ];
    if ($saleId <= 0) return $out;

    $stmt = $conn->prepare("SELECT total, payment_method, customer_id, customer_type, paid_amount, debt_amount, paid_cash, paid_bank, remaining_debt FROM sales WHERE id = ? LIMIT 1");
    if (!$stmt) return $out;
    $stmt->bind_param('i', $saleId);
    $stmt->execute();
    $res = $stmt->get_result();
    if (!$res || !($row = $res->fetch_assoc())) return $out;

    $saleTotal = roundMoney((float)($row['total'] ?? 0));
    if ($saleTotal <= 0) return $out;

    $returnTotal = roundMoney($returnTotal);
    $payMethod = strtolower(trim((string)($row['payment_method'] ?? 'cash')));
    if (in_array($payMethod, ['bank', 'bankcard', 'card'], true)) $payMethod = 'fib';
    $paidCash = roundMoney((float)($row['paid_cash'] ?? 0));
    $paidBank = roundMoney((float)($row['paid_bank'] ?? 0));
    $paidAmt = roundMoney((float)($row['paid_amount'] ?? 0));
    $debtAmtSale = roundMoney((float)($row['debt_amount'] ?? 0));
    $remainingDebt = isset($row['remaining_debt']) && $row['remaining_debt'] !== null && $row['remaining_debt'] !== ''
        ? roundMoney((float)$row['remaining_debt'])
        : null;

    // Open unpaid debt on this invoice (prefer live remaining_debt).
    if ($remainingDebt !== null) {
        $openDebt = max(0.0, $remainingDebt);
    } elseif ($payMethod === 'debt') {
        $openDebt = max(0.0, $saleTotal);
    } elseif ($payMethod === 'split' && $debtAmtSale > 0) {
        $openDebt = max(0.0, $debtAmtSale);
    } else {
        $cashPaid = $paidAmt > 0 ? $paidAmt : roundMoney($paidCash + $paidBank);
        $openDebt = max(0.0, roundMoney($saleTotal - $cashPaid));
    }

    // Pure FIB sale: no cash drawer refund from physical float.
    if ($payMethod === 'fib') {
        $debtAdjusted = 0.0;
        $cashRefunded = 0.0;
        $fibRefunded = $returnTotal;
        $debtRatio = 0.0;
    } else {
        // Debt-first: never pay cash while unpaid invoice debt still covers the return.
        $debtAdjusted = roundMoney(min($returnTotal, $openDebt));
        $nonDebt = roundMoney(max(0.0, $returnTotal - $debtAdjusted));
        $cashRefunded = $nonDebt;
        $fibRefunded = 0.0;
        if ($paidCash + $paidBank > 0.001 && $nonDebt > 0.001) {
            $cashShare = $paidCash / ($paidCash + $paidBank);
            $cashRefunded = roundMoney($nonDebt * $cashShare);
            $fibRefunded = roundMoney($nonDebt - $cashRefunded);
        }
        $debtRatio = $returnTotal > 0.0001 ? min(1.0, $debtAdjusted / $returnTotal) : 0.0;
    }

    $effectiveMethod = $debtRatio >= 0.999 ? 'debt' : ($payMethod === 'fib' ? 'fib' : ($debtRatio <= 0.001 ? ($fibRefunded > 0.001 && $cashRefunded <= 0.001 ? 'fib' : 'cash') : 'split'));

    $targetId = (int)($row['customer_id'] ?? 0);
    $targetType = trim((string)($row['customer_type'] ?? 'customer'));
    if ($targetType === 'customers') $targetType = 'customer';
    if ($targetType === '') $targetType = 'customer';

    $out['payment_type'] = in_array($payMethod, ['cash', 'debt', 'split', 'fib'], true) ? $payMethod : 'cash';
    $out['effective_payment_method'] = $effectiveMethod;
    $out['sale_total'] = $saleTotal;
    $out['debt_ratio'] = $debtRatio;
    $out['debt_adjusted'] = $debtAdjusted;
    $out['cash_refunded'] = $cashRefunded;
    $out['fib_refunded'] = $fibRefunded;
    $out['target_id'] = $targetId;
    $out['target_type'] = $targetType;
    $out['open_debt'] = $openDebt;
    return $out;
}

function pos_parse_return_target_from_post(array $post): array {
    $targetId = isset($post['target_id']) ? (int)$post['target_id'] : 0;
    $targetType = isset($post['target_type']) ? trim((string)$post['target_type']) : '';
    if ($targetId <= 0 && !empty($post['target_id'])) {
        $raw = trim((string)$post['target_id']);
        if (preg_match('/^(customer|user)_(\d+)$/i', $raw, $m)) {
            $targetId = (int)$m[2];
            $targetType = strtolower($m[1]) === 'user' ? 'user' : 'customer';
        }
    }
    if ($targetType === 'customers') $targetType = 'customer';
    return ['target_id' => $targetId, 'target_type' => $targetType];
}

/** Company supplier debt paid — cash reduces drawer; FIB/bank uses debt_payment_fib (excluded from drawer). */
function insertCompanyDebtPaymentExpense($conn, $amount, $note, $user, $date, $txnId, $companyId = 0, $paymentChannel = 'cash') {
    $amount = roundMoney($amount);
    if ($amount <= 0) return 0;
    $channel = function_exists('pos_normalize_debt_pay_channel')
        ? pos_normalize_debt_pay_channel($paymentChannel)
        : (strtolower(trim((string)$paymentChannel)) === 'fib' ? 'fib' : 'cash');
    $type = ($channel === 'fib') ? 'debt_payment_fib' : 'debt_payment';
    $companyId = (int)$companyId;
    $stmt = $conn->prepare("INSERT INTO expenses (note, amount, `date`, user, type, transaction_id, company_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sdssssi", $note, $amount, $date, $user, $type, $txnId, $companyId);
    $stmt->execute();
    $id = (int)$stmt->insert_id;
    if (function_exists('pos_expense_stamp_fx')) {
        pos_expense_stamp_fx($conn, $id, 'IQD');
    }
    return $id;
}

/** Normalize debt collection channel for drawer accounting. */
function pos_normalize_debt_pay_channel($raw) {
    $p = strtolower(trim((string)$raw));
    if (in_array($p, ['fib', 'bank', 'bank_transfer', 'banktransfer', 'bankcard', 'card'], true)) {
        return 'fib';
    }
    return 'cash';
}

/** True when a customer_ledger payment row is physical cash (drawer). */
function pos_customer_debt_payment_is_cash(array $cl) {
    $pm = strtolower(trim((string)($cl['payment_method'] ?? '')));
    if ($pm !== '') {
        return pos_normalize_debt_pay_channel($pm) === 'cash';
    }
    $ty = strtolower(trim((string)($cl['type'] ?? '')));
    if ($ty === 'debt_payment_in_fib' || $ty === 'payment_fib') {
        return false;
    }
    $note = (string)($cl['note'] ?? '');
    if (preg_match('/کانال:\s*FIB|channel:\s*fib|\(FIB\)/iu', $note)) {
        return false;
    }
    return true;
}

/** Cash supplies without a linked purchase expense (legacy rows). */
function sumLegacyCashSuppliesNotInExpenses($conn, $dateFrom, $dateTo) {
    $q = "SELECT COALESCE(SUM(s.totalCost),0) AS t FROM supplies s
        WHERE s.type = 'cash' AND s.date >= ? AND s.date <= ?
        AND (s.transaction_id IS NULL OR s.transaction_id = ''
          OR NOT EXISTS (SELECT 1 FROM expenses e WHERE e.transaction_id = s.transaction_id AND e.type = 'purchase'))";
    $st = $conn->prepare($q);
    $st->bind_param("ss", $dateFrom, $dateTo);
    $st->execute();
    $row = $st->get_result()->fetch_assoc();
    return roundMoney($row['t'] ?? 0);
}

/** Same as client getUsdRatePerOne: raw usdRate in settings, divided by 100 when >= 100. */
function pos_settings_usd_rate_per_one_from_array($settings) {
    if (!is_array($settings)) {
        return 1500.0;
    }
    $raw = isset($settings['usdRate']) ? (float)$settings['usdRate'] : 150000;
    if ($raw <= 0) {
        $raw = 150000;
    }
    return $raw >= 100 ? ($raw / 100.0) : $raw;
}

function pos_normalize_currency_mode($mode) {
    $m = strtoupper(trim((string)$mode));
    return ($m === 'USD') ? 'USD' : 'IQD';
}

/**
 * Single source of truth for IQD <-> USD.
 * Same currency: IQD integer, USD 2 decimals.
 * USD -> IQD: round (no decimals). IQD -> USD: 2 decimals.
 * $rate is IQD per 1 USD.
 */
function pos_convert_currency($amount, $fromCurrency, $toCurrency, $rate = 0) {
    $from = pos_normalize_currency_mode($fromCurrency);
    $to = pos_normalize_currency_mode($toCurrency);
    $a = (float)$amount;
    if (!is_finite($a)) {
        $a = 0.0;
    }
    $r = (float)$rate;
    if ($r <= 0) {
        global $conn;
        $r = pos_current_expense_exchange_rate(isset($conn) ? $conn : null);
    }
    if ($from === $to) {
        return ($from === 'USD') ? round($a, 2) : (float)round($a);
    }
    if ($r <= 0) {
        return 0.0;
    }
    if ($from === 'USD' && $to === 'IQD') {
        return (float)round($a * $r);
    }
    return round($a / $r, 2);
}

function convertCurrency($amount, $fromCurrency, $toCurrency, $rate = 0) {
    return pos_convert_currency($amount, $fromCurrency, $toCurrency, $rate);
}

/** Frozen row rate only (IQD per 1 USD). Returns 0 when unstamped — never live shop rate. */
function pos_row_frozen_rate_per_one($row) {
    if (!is_array($row)) {
        return 0.0;
    }
    $er = (float)($row['exchange_rate'] ?? 0);
    if ($er >= 10000) {
        return $er / 100.0;
    }
    if ($er > 0) {
        return $er;
    }
    $fx = (float)($row['fx_usd_rate'] ?? 0);
    if ($fx >= 100) {
        return $fx / 100.0;
    }
    if ($fx > 0) {
        return $fx;
    }
    return 0.0;
}

/** Frozen row rate (IQD per 1 USD). Prefers exchange_rate, then fx_usd_rate bundle. Live only if row has no stamp. */
function pos_row_exchange_rate_per_one($row, $conn = null) {
    $frozen = pos_row_frozen_rate_per_one(is_array($row) ? $row : null);
    if ($frozen > 0) {
        return $frozen;
    }
    return pos_current_expense_exchange_rate($conn);
}

/**
 * IQD → USD for reports: never re-ratio USD-origin money through today's live rate.
 * Prefer stored USD hint; proportional total_usd for partial amounts; else frozen row rate.
 * When a row is provided without stamps, returns 0 (refuses live debt/COGS re-ratio).
 */
function pos_stored_iqd_to_usd($iqdAmount, $row = null, $usdHint = null, $conn = null) {
    if ($usdHint !== null && $usdHint !== '' && is_numeric($usdHint)) {
        return round((float)$usdHint, 2);
    }
    $iqd = (float)$iqdAmount;
    if (!is_finite($iqd)) {
        $iqd = 0.0;
    }
    if (is_array($row) && isset($row['total_usd']) && $row['total_usd'] !== '' && $row['total_usd'] !== null && is_numeric($row['total_usd'])) {
        $totalUsd = (float)$row['total_usd'];
        $rowTotal = null;
        if (isset($row['total']) && $row['total'] !== '' && $row['total'] !== null && is_numeric($row['total'])) {
            $rowTotal = (float)$row['total'];
        } elseif (isset($row['total_iqd']) && $row['total_iqd'] !== '' && $row['total_iqd'] !== null && is_numeric($row['total_iqd'])) {
            $rowTotal = (float)$row['total_iqd'];
        }
        if ($rowTotal !== null && $rowTotal > 0.0000001) {
            return round($iqd * ($totalUsd / $rowTotal), 2);
        }
        // Only treat as full-invoice USD when converting the whole total (legacy callers).
        if (abs($iqd - $totalUsd) < 0.0001 || abs($iqd) < 0.0000001) {
            return round($totalUsd, 2);
        }
    }
    if (is_array($row)) {
        $rate = pos_row_frozen_rate_per_one($row);
        if ($rate > 0) {
            return round($iqd / $rate, 2);
        }
        // Row context without frozen FX: do not apply live shop rate (locks debts).
        return 0.0;
    }
    $rate = pos_current_expense_exchange_rate($conn);
    if ($rate <= 0) {
        return 0.0;
    }
    return round($iqd / $rate, 2);
}

/** Row transaction currency (fx_currency_mode / currency), else shop mode. */
function pos_row_fx_currency_mode($row, $conn = null) {
    if (is_array($row)) {
        $m = strtoupper(trim((string)($row['fx_currency_mode'] ?? ($row['currency'] ?? ''))));
        if ($m === 'USD' || $m === 'IQD') {
            return $m;
        }
    }
    return (function_exists('pos_is_usd_currency_system') && pos_is_usd_currency_system($conn)) ? 'USD' : 'IQD';
}

function pos_current_expense_exchange_rate($conn = null) {
    $rate = 1500.0;
    try {
        if ($conn && function_exists('pos_load_app_settings_array')) {
            $settings = pos_load_app_settings_array($conn);
            if (function_exists('pos_settings_usd_rate_per_one_from_array')) {
                $rate = (float)pos_settings_usd_rate_per_one_from_array($settings);
            }
        }
    } catch (Throwable $e) {}
    if ($rate <= 0) {
        $rate = 1500.0;
    }
    return $rate;
}

function pos_expense_stamp_fx($conn, $id, $currency = 'IQD', $ratePerOne = null) {
    $id = (int)$id;
    if ($id <= 0 || !$conn) {
        return false;
    }
    if (function_exists('pos_ensure_expense_currency_columns')) {
        pos_ensure_expense_currency_columns($conn);
    }
    $currency = pos_normalize_currency_mode($currency);
    $rate = ($ratePerOne !== null && (float)$ratePerOne > 0) ? (float)$ratePerOne : pos_current_expense_exchange_rate($conn);
    try {
        $st = $conn->prepare("UPDATE expenses SET currency = ?, exchange_rate = ? WHERE id = ?");
        if (!$st) {
            return false;
        }
        $st->bind_param("sdi", $currency, $rate, $id);
        return (bool)$st->execute();
    } catch (Throwable $e) {
        return false;
    }
}

function pos_expense_amount_iqd($row) {
    $amt = (float)($row['amount'] ?? 0);
    $cur = pos_normalize_currency_mode($row['currency'] ?? 'IQD');
    if ($cur === 'IQD') {
        return function_exists('roundMoney') ? roundMoney($amt) : round($amt, 2);
    }
    $rate = function_exists('pos_row_frozen_rate_per_one')
        ? pos_row_frozen_rate_per_one($row)
        : (float)($row['exchange_rate'] ?? 0);
    if (!($rate > 0)) {
        return function_exists('roundMoney') ? roundMoney($amt) : round($amt, 2);
    }
    return pos_convert_currency($amt, $cur, 'IQD', $rate);
}

function pos_expense_amount_usd($row) {
    $amt = (float)($row['amount'] ?? 0);
    $cur = pos_normalize_currency_mode($row['currency'] ?? 'IQD');
    if ($cur === 'USD') {
        return round($amt, 2);
    }
    $rate = function_exists('pos_row_frozen_rate_per_one')
        ? pos_row_frozen_rate_per_one($row)
        : 0.0;
    if ($rate > 0) {
        return round($amt / $rate, 2);
    }
    // No frozen stamp — refuse live shop rate (locks debts/expenses across FX changes).
    return function_exists('pos_stored_iqd_to_usd')
        ? pos_stored_iqd_to_usd($amt, is_array($row) ? $row : null, null, null)
        : 0.0;
}

function pos_sql_expense_amount_iqd($alias = '') {
    $p = ($alias !== '') ? ($alias . '.') : '';
    return "(CASE WHEN UPPER(TRIM(IFNULL({$p}currency,''))) = 'USD'"
        . " THEN ROUND({$p}amount * IF({$p}exchange_rate > 0.000001, {$p}exchange_rate, 1500))"
        . " ELSE {$p}amount END)";
}

function pos_catalog_product_count($conn) {
    if (!$conn) {
        return 0;
    }
    try {
        $res = $conn->query('SELECT COUNT(*) AS c FROM products');
        if ($res && ($row = $res->fetch_assoc())) {
            return (int)($row['c'] ?? 0);
        }
    } catch (Throwable $e) {}
    return 0;
}

function pos_shop_currency_locked_by_catalog($conn) {
    return pos_catalog_product_count($conn) > 0;
}

function pos_settings_default_currency_from_array($settings) {
    if (!is_array($settings)) {
        return 'IQD';
    }
    $d = strtoupper(trim((string)($settings['defaultCurrency'] ?? $settings['default_currency'] ?? '')));
    if ($d === 'USD' || $d === 'IQD') {
        return $d;
    }
    return pos_normalize_currency_mode($settings['currencyMode'] ?? 'IQD');
}

function pos_apply_default_currency_to_settings_array(array &$settings, $mode = null) {
    $cur = pos_settings_default_currency_from_array($settings);
    if ($mode !== null && $mode !== '') {
        $cur = pos_normalize_currency_mode($mode);
    }
    $settings['defaultCurrency'] = $cur;
    $settings['default_currency'] = $cur;
    $settings['currencyMode'] = $cur;
    return $cur;
}

function pos_persist_default_currency_row($conn, $mode) {
    $cur = pos_normalize_currency_mode($mode);
    if ($conn && function_exists('pos_db_set_setting_value')) {
        pos_db_set_setting_value($conn, 'default_currency', $cur);
    }
    return $cur;
}

/** Persist IQD-per-1-USD as settings.exchange_rate. Never rewrites products/sales/expenses. */
function pos_persist_exchange_rate_row($conn, $ratePerOne) {
    $r = (float)$ratePerOne;
    if ($r >= 10000) {
        $r = $r / 100.0;
    }
    if ($r <= 0) {
        return 0.0;
    }
    $r = round($r, 2);
    if ($conn && function_exists('pos_db_set_setting_value')) {
        pos_db_set_setting_value($conn, 'exchange_rate', number_format($r, 2, '.', ''));
    }
    return $r;
}

function pos_apply_exchange_rate_to_settings_array(array &$settings, $ratePerOne = null) {
    if ($ratePerOne === null && function_exists('pos_settings_usd_rate_per_one_from_array')) {
        $ratePerOne = pos_settings_usd_rate_per_one_from_array($settings);
    }
    $r = (float)$ratePerOne;
    if ($r >= 10000) {
        $r = $r / 100.0;
    }
    if ($r <= 0) {
        $r = 1500.0;
    }
    $settings['exchange_rate'] = round($r, 2);
    return $settings['exchange_rate'];
}

function pos_hydrate_client_settings_currency(array &$settings, $conn) {
    if (!$conn || !function_exists('pos_db_get_setting_value')) {
        return;
    }
    $defCur = pos_db_get_setting_value($conn, 'default_currency');
    $defCur = is_string($defCur) ? strtoupper(trim($defCur)) : '';
    if ($defCur === 'USD' || $defCur === 'IQD') {
        $settings['defaultCurrency'] = $defCur;
        $settings['default_currency'] = $defCur;
        if (empty($settings['currencyMode'])) {
            $settings['currencyMode'] = $defCur;
        }
    } elseif (empty($settings['defaultCurrency']) && !empty($settings['currencyMode'])) {
        $modeHyd = strtoupper((string)$settings['currencyMode']) === 'USD' ? 'USD' : 'IQD';
        $settings['defaultCurrency'] = $modeHyd;
        $settings['default_currency'] = $modeHyd;
    }
    $erRow = pos_db_get_setting_value($conn, 'exchange_rate');
    if ($erRow !== null && (float)$erRow > 0) {
        $settings['exchange_rate'] = round((float)$erRow, 2);
    } else {
        pos_apply_exchange_rate_to_settings_array($settings);
    }
}

function pos_settings_currency_mode_from_array($settings) {
    return pos_settings_default_currency_from_array($settings);
}

/** Apply sell price from purchase cart row (piece / pack / carton). */
function pos_apply_product_sell_price_for_unit($conn, $pid, $unit, $sellIqd, $currencyMode = 'IQD', $usdRatePerOne = 0) {
    $pid = (int)$pid;
    if ($pid <= 0) return;
    $sellIqd = roundMoney(max(0, (float)$sellIqd));
    $unit = in_array($unit, ['carton', 'pack', 'piece'], true) ? $unit : 'piece';
    $prodCur = $currencyMode;
    try {
        $stCur = $conn->prepare('SELECT base_currency FROM products WHERE id = ? LIMIT 1');
        if ($stCur) {
            $stCur->bind_param('i', $pid);
            $stCur->execute();
            $cr = $stCur->get_result()->fetch_assoc();
            if ($cr) {
                $prodCur = pos_product_base_currency_from_row($cr, $currencyMode);
            }
        }
    } catch (Throwable $e) {}
    $isUsd = pos_normalize_currency_mode($prodCur) === 'USD' && (float)$usdRatePerOne > 0;
    if ($unit === 'carton') {
        if ($isUsd) {
            $usd = pos_round_usd_catalog_store($sellIqd / (float)$usdRatePerOne);
            $st = $conn->prepare("UPDATE products SET price_carton=?, price_carton_usd=? WHERE id=?");
            if ($st) { $st->bind_param("ddi", $sellIqd, $usd, $pid); $st->execute(); }
        } else {
            $st = $conn->prepare("UPDATE products SET price_carton=? WHERE id=?");
            if ($st) { $st->bind_param("di", $sellIqd, $pid); $st->execute(); }
        }
        return;
    }
    if ($unit === 'pack') {
        if ($isUsd) {
            $usd = pos_round_usd_catalog_store($sellIqd / (float)$usdRatePerOne);
            $st = $conn->prepare("UPDATE products SET price_pack=?, price_pack_usd=? WHERE id=?");
            if ($st) { $st->bind_param("ddi", $sellIqd, $usd, $pid); $st->execute(); }
        } else {
            $st = $conn->prepare("UPDATE products SET price_pack=? WHERE id=?");
            if ($st) { $st->bind_param("di", $sellIqd, $pid); $st->execute(); }
        }
        return;
    }
    if ($isUsd) {
        $usd = pos_round_usd_catalog_store($sellIqd / (float)$usdRatePerOne);
        $st = $conn->prepare("UPDATE products SET price=?, price_usd=? WHERE id=?");
        if ($st) { $st->bind_param("ddi", $sellIqd, $usd, $pid); $st->execute(); }
    } else {
        $st = $conn->prepare("UPDATE products SET price=? WHERE id=?");
        if ($st) { $st->bind_param("di", $sellIqd, $pid); $st->execute(); }
    }
    if (function_exists('pos_product_sync_base_fields')) {
        pos_product_sync_base_fields($conn, $pid);
    }
}

/** Apply purchase cost from purchase cart row (piece / pack / carton) — becomes catalog کرین.
 * Always syncs piece + pack + carton together so selling any unit uses the latest batch cost. */
function pos_apply_product_cost_for_unit($conn, $pid, $unit, $costIqd, $currencyMode = 'IQD', $usdRatePerOne = 0, $allowZero = false) {
    $pid = (int)$pid;
    if ($pid <= 0) return;
    $costIqd = roundMoney(max(0, (float)$costIqd));
    if ($costIqd <= 0 && !$allowZero) return;
    $unit = in_array($unit, ['carton', 'pack', 'piece'], true) ? $unit : 'piece';
    $prodCur = $currencyMode;
    $ppp = 1;
    $ppc = 1;
    try {
        $stF = $conn->prepare('SELECT pieces_per_pack, packs_per_carton, base_currency FROM products WHERE id = ? LIMIT 1');
        if ($stF) {
            $stF->bind_param('i', $pid);
            $stF->execute();
            $fr = $stF->get_result()->fetch_assoc();
            if ($fr) {
                $ppp = max(1, (int)($fr['pieces_per_pack'] ?? 1));
                $ppc = max(1, (int)($fr['packs_per_carton'] ?? 1));
                $prodCur = pos_product_base_currency_from_row($fr, $currencyMode);
            }
        }
    } catch (Throwable $e) {}
    $isUsd = pos_normalize_currency_mode($prodCur) === 'USD' && (float)$usdRatePerOne > 0;

    // Purchased unit keeps the amount actually paid; other units derive without floor leftover.
    if ($unit === 'carton') {
        $mult = max(1, $ppp * $ppc);
        $cartonCost = roundMoney($costIqd);
        $pieceCost = roundMoney($costIqd / $mult);
        $packCost = roundMoney($pieceCost * $ppp);
        $cartonCost = roundMoney($costIqd);
    } elseif ($unit === 'pack') {
        $packCost = roundMoney($costIqd);
        $pieceCost = roundMoney($costIqd / max(1, $ppp));
        $cartonCost = roundMoney($pieceCost * $ppp * $ppc);
        $packCost = roundMoney($costIqd);
    } else {
        $pieceCost = roundMoney($costIqd);
        $packCost = roundMoney($pieceCost * $ppp);
        $cartonCost = roundMoney($pieceCost * $ppp * $ppc);
    }
    if (!($pieceCost > 0)) {
        $pieceCost = roundMoney($costIqd);
    }
    if (!($packCost > 0)) {
        $packCost = $pieceCost;
    }
    if (!($cartonCost > 0)) {
        $cartonCost = roundMoney($pieceCost * $ppp * $ppc);
    }

    if ($isUsd) {
        $pieceUsd = pos_round_usd_catalog_store($pieceCost / (float)$usdRatePerOne);
        $packUsd = pos_round_usd_catalog_store($packCost / (float)$usdRatePerOne);
        $cartonUsd = pos_round_usd_catalog_store($cartonCost / (float)$usdRatePerOne);
        $st = $conn->prepare('UPDATE products SET cost=?, cost_usd=?, cost_pack=?, cost_pack_usd=?, cost_carton=?, cost_carton_usd=? WHERE id=?');
        if ($st) {
            $st->bind_param('ddddddi', $pieceCost, $pieceUsd, $packCost, $packUsd, $cartonCost, $cartonUsd, $pid);
            $st->execute();
        }
        if (function_exists('pos_product_sync_base_fields')) {
            pos_product_sync_base_fields($conn, $pid);
        }
        return;
    }

    $st = $conn->prepare('UPDATE products SET cost=?, cost_pack=?, cost_carton=? WHERE id=?');
    if ($st) {
        $st->bind_param('dddi', $pieceCost, $packCost, $cartonCost, $pid);
        $st->execute();
    }
    if (function_exists('pos_product_sync_base_fields')) {
        pos_product_sync_base_fields($conn, $pid);
    }
}

/**
 * Blend a stock-in (including free gift at cost 0) into remaining weighted-average catalog cost.
 * Call AFTER qty has already been increased. Gift lots must pull catalog cost down (to 0 if only gifts remain).
 */
function pos_apply_product_wac_after_stock_in($conn, $pid, $addPieces, $addTotalCost, $currencyMode = 'IQD', $usdRatePerOne = 0) {
    $pid = (int)$pid;
    $addPieces = (float)$addPieces;
    if ($pid <= 0 || $addPieces <= 0) {
        return;
    }
    $qtyAfter = 0.0;
    $oldCost = 0.0;
    try {
        $st = $conn->prepare('SELECT qty, cost FROM products WHERE id = ? LIMIT 1');
        if ($st) {
            $st->bind_param('i', $pid);
            $st->execute();
            $row = $st->get_result()->fetch_assoc();
            if ($row) {
                $qtyAfter = (float)($row['qty'] ?? 0);
                $oldCost = (float)($row['cost'] ?? 0);
            }
        }
    } catch (Throwable $e) {
        return;
    }
    $qtyBefore = $qtyAfter - $addPieces;
    $addTotal = max(0.0, (float)$addTotalCost);
    $cover = ($qtyBefore < -0.000001) ? min($addPieces, -$qtyBefore) : 0.0;
    $oldPos = max(0.0, $qtyBefore);
    $newPos = max(0.0, $qtyAfter);
    $addIntoInv = max(0.0, $addPieces - $cover);
    $unitAdd = $addPieces > 0.000001 ? ($addTotal / $addPieces) : 0.0;
    $addCostIntoInv = $unitAdd * $addIntoInv;
    if ($newPos > 0.000001) {
        $wac = ($oldPos * $oldCost + $addCostIntoInv) / $newPos;
    } else {
        $wac = $unitAdd;
    }
    pos_apply_product_cost_for_unit($conn, $pid, 'piece', $wac, $currencyMode, $usdRatePerOne, true);
}

/**
 * Append a row to exchange_rate_history when the table exists (schema v11+).
 */
function pos_exchange_rate_history_append($conn, $rateBundle, $userName = '', $note = '') {
    $rateBundle = (int)$rateBundle;
    if ($rateBundle < 10000) {
        return false;
    }
    try {
        $chk = $conn->query("SHOW TABLES LIKE 'exchange_rate_history'");
        if (!$chk || $chk->num_rows === 0) {
            return false;
        }
    } catch (Throwable $e) {
        return false;
    }
    $un = substr((string)$userName, 0, 100);
    $nt = substr((string)$note, 0, 255);
    try {
        $stmt = $conn->prepare("INSERT INTO exchange_rate_history (rate_bundle, user_name, note) VALUES (?, ?, ?)");
        if (!$stmt) {
            return false;
        }
        $stmt->bind_param("iss", $rateBundle, $un, $nt);
        return (bool)$stmt->execute();
    } catch (Throwable $e) {
        return false;
    }
}

function pos_ensure_visual_usd_rate_history_table($conn) {
    try {
        $sql = "CREATE TABLE IF NOT EXISTS visual_usd_rate_history (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            rate_bundle INT UNSIGNED NOT NULL,
            user_name VARCHAR(100) NOT NULL DEFAULT '',
            note VARCHAR(255) NOT NULL DEFAULT '',
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_created_at (created_at),
            KEY idx_rate_bundle (rate_bundle)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        return (bool)$conn->query($sql);
    } catch (Throwable $e) {
        return false;
    }
}

function pos_visual_usd_rate_history_append($conn, $rateBundle, $userName = '', $note = '') {
    $rateBundle = (int)$rateBundle;
    if ($rateBundle < 10000) {
        return false;
    }
    if (!pos_ensure_visual_usd_rate_history_table($conn)) {
        return false;
    }
    $un = substr((string)$userName, 0, 100);
    $nt = substr((string)$note, 0, 255);
    try {
        $stmt = $conn->prepare("INSERT INTO visual_usd_rate_history (rate_bundle, user_name, note) VALUES (?, ?, ?)");
        if (!$stmt) {
            return false;
        }
        $stmt->bind_param("iss", $rateBundle, $un, $nt);
        return (bool)$stmt->execute();
    } catch (Throwable $e) {
        return false;
    }
}

function pos_visual_usd_rate_history_latest($conn) {
    if (!pos_ensure_visual_usd_rate_history_table($conn)) {
        return null;
    }
    try {
        $res = $conn->query("SELECT id, rate_bundle, created_at, user_name, note FROM visual_usd_rate_history ORDER BY id DESC LIMIT 1");
        if ($res && ($row = $res->fetch_assoc())) {
            $row['id'] = (int)($row['id'] ?? 0);
            $row['rate_bundle'] = (int)($row['rate_bundle'] ?? 0);
            return $row;
        }
    } catch (Throwable $e) {
        return null;
    }
    return null;
}

function pos_load_app_settings_array($conn) {
    $out = [];
    $sres = $conn->query("SELECT setting_value FROM settings WHERE setting_key = 'app_settings' LIMIT 1");
    if ($sres && ($srow = $sres->fetch_assoc())) {
        $dec = json_decode($srow['setting_value'] ?? '{}', true);
        if (is_array($dec)) {
            $out = $dec;
        }
    }
    $rowCur = null;
    if (function_exists('pos_db_get_setting_value')) {
        $rowCur = pos_db_get_setting_value($conn, 'default_currency');
    }
    $rowCur = is_string($rowCur) ? strtoupper(trim($rowCur)) : '';
    if ($rowCur === 'USD' || $rowCur === 'IQD') {
        $out['defaultCurrency'] = $rowCur;
        $out['default_currency'] = $rowCur;
        if (empty($out['currencyMode'])) {
            $out['currencyMode'] = $rowCur;
        }
    } else {
        $mode = function_exists('pos_settings_default_currency_from_array')
            ? pos_settings_default_currency_from_array($out)
            : pos_normalize_currency_mode($out['currencyMode'] ?? 'IQD');
        $out['defaultCurrency'] = $mode;
        $out['default_currency'] = $mode;
    }
    return $out;
}

/** Pro / Pro Plus or à la carte FEAT — entitled to turn multi-warehouse ON. */
function pos_multi_warehouse_entitled(mysqli $conn): bool {
    $settings = pos_load_app_settings_array($conn);
    if (!is_array($settings)) {
        $settings = [];
    }
    $tier = pos_subscription_tier_from_settings($settings);
    if ($tier === 'pro' || $tier === 'pro_plus') {
        return true;
    }
    $pf = $settings['purchasedFeatures'] ?? null;
    if (is_array($pf) && (!empty($pf['enableMultiWarehouse']) || !empty($pf['enablemultiwarehouse']))) {
        return true;
    }
    $pu = $settings['premiumFeatureUnlocks'] ?? null;
    if (is_array($pu) && !empty($pu['enableMultiWarehouse'])) {
        return true;
    }
    return false;
}

/** Entitled + settings toggle: multiple warehouses, transfers, warehouse pickers. */
function pos_multi_warehouse_pro_enabled(mysqli $conn): bool {
    $settings = pos_load_app_settings_array($conn);
    if (empty($settings['enableMultiWarehouse'])) {
        return false;
    }
    return pos_multi_warehouse_entitled($conn);
}

/** Customer installment plans (قست) — Pro / Pro Plus or à la carte FEAT ($75). */
function pos_installments_pro_enabled(mysqli $conn): bool {
    if (!$conn || !function_exists('pos_load_app_settings_array')) {
        return false;
    }
    $settings = pos_load_app_settings_array($conn);
    if (!is_array($settings)) {
        $settings = [];
    }
    $tier = pos_subscription_tier_from_settings($settings);
    if ($tier === 'pro' || $tier === 'pro_plus') {
        return true;
    }
    $pf = $settings['purchasedFeatures'] ?? null;
    if (is_array($pf) && (!empty($pf['enableCustomerInstallments']) || !empty($pf['enablecustomerinstallments']))) {
        return true;
    }
    $pu = $settings['premiumFeatureUnlocks'] ?? null;
    if (is_array($pu) && !empty($pu['enableCustomerInstallments'])) {
        return true;
    }
    if (!empty($settings['enableCustomerInstallments'])) {
        $unlocks = is_array($pu) ? $pu : [];
        $purchased = is_array($pf) ? $pf : [];
        if (!empty($unlocks['enableCustomerInstallments']) || !empty($purchased['enableCustomerInstallments'])) {
            return true;
        }
    }
    return false;
}

function pos_installments_pro_required_json(mysqli $conn): void {
    $price = function_exists('pos_premium_feature_price_usd')
        ? pos_premium_feature_price_usd('enableCustomerInstallments')
        : (defined('POS_PREMIUM_INSTALLMENTS_PRICE_USD') ? (int) POS_PREMIUM_INSTALLMENTS_PRICE_USD : 75);
    echo json_encode([
        'status' => 'error',
        'message' => 'قستی کریار — چالاک بکە بە FEAT ($' . $price . ') یان Pro ($224)',
        'pro_required' => true,
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

function pos_session_can_use_multi_warehouse(mysqli $conn): bool {
    if (!pos_multi_warehouse_pro_enabled($conn)) {
        return false;
    }
    if (pos_session_is_admin()) {
        return true;
    }
    return pos_session_has_perm('multi_warehouse');
}

function pos_resolve_product_warehouse_id_for_save(mysqli $conn, int $postedWhId): int {
    if (pos_multi_warehouse_pro_enabled($conn) && pos_session_can_use_multi_warehouse($conn) && $postedWhId > 0) {
        return pos_resolve_warehouse_id($conn, $postedWhId);
    }
    return pos_default_warehouse_id($conn);
}

/** Sequential transfer receipt number (000001 …), like purchase invoices. */
function pos_format_stock_transfer_number(int $id, ?string $transactionId = null): string {
    $tid = trim((string)($transactionId ?? ''));
    if ($tid !== '' && preg_match('/^\d{1,12}$/', $tid)) {
        return str_pad($tid, 6, '0', STR_PAD_LEFT);
    }
    if ($tid !== '' && !preg_match('/^TXF/i', $tid)) {
        return $tid;
    }
    if ($id > 0) {
        return str_pad((string)$id, 6, '0', STR_PAD_LEFT);
    }
    return $tid !== '' ? $tid : '000000';
}

/** Stock transfer history rows with warehouse names and line items. */
function pos_fetch_stock_transfer_lines_map(mysqli $conn, array $transferIds): array {
    $map = [];
    if (empty($transferIds)) return $map;
    $ids = array_values(array_unique(array_filter(array_map('intval', $transferIds), static function ($x) {
        return $x > 0;
    })));
    if (empty($ids)) return $map;
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $types = str_repeat('i', count($ids));
    $sql = "SELECT l.transfer_id, l.product_id, l.qty, l.unit_cost, p.name AS product_name
            FROM stock_transfer_lines l
            LEFT JOIN products p ON p.id = l.product_id
            WHERE l.transfer_id IN ($placeholders)
            ORDER BY l.id ASC";
    $st = $conn->prepare($sql);
    if (!$st) return $map;
    $st->bind_param($types, ...$ids);
    $st->execute();
    $res = $st->get_result();
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $tid = (int)($row['transfer_id'] ?? 0);
            if ($tid <= 0) continue;
            if (!isset($map[$tid])) $map[$tid] = [];
            $map[$tid][] = [
                'product_id' => (int)($row['product_id'] ?? 0),
                'product_name' => (string)($row['product_name'] ?? ''),
                'qty' => roundMoney((float)($row['qty'] ?? 0)),
                'unit_cost' => roundMoney((float)($row['unit_cost'] ?? 0)),
                'line_total' => roundMoney((float)($row['qty'] ?? 0) * (float)($row['unit_cost'] ?? 0)),
            ];
        }
    }
    return $map;
}

function pos_fetch_stock_transfer_history(mysqli $conn, array $opts = []): array {
    $today = date('Y-m-d');
    $dateFrom = pos_parse_history_date_ymd($opts['date_from'] ?? '', date('Y-m-d', strtotime('-365 days')));
    $dateTo = pos_parse_history_date_ymd($opts['date_to'] ?? '', $today);
    if ($dateFrom > $dateTo) {
        $tmp = $dateFrom;
        $dateFrom = $dateTo;
        $dateTo = $tmp;
    }
    $warehouseId = (int)($opts['warehouse_id'] ?? 0);
    $limit = (int)($opts['limit'] ?? 300);
    if ($limit < 20) $limit = 20;
    if ($limit > 500) $limit = 500;
    $dtStart = $dateFrom . ' 00:00:00';
    $dtEnd = $dateTo . ' 23:59:59';

    $sql = "SELECT t.id, t.from_warehouse_id, t.to_warehouse_id, t.status, t.transaction_id, t.total_qty, t.date, t.`user`, t.note,
                   wf.name AS from_warehouse_name, wt.name AS to_warehouse_name
            FROM stock_transfers t
            LEFT JOIN warehouses wf ON wf.id = t.from_warehouse_id
            LEFT JOIN warehouses wt ON wt.id = t.to_warehouse_id
            WHERE t.date >= ? AND t.date <= ?";
    $types = 'ss';
    $params = [$dtStart, $dtEnd];
    if ($warehouseId > 0) {
        $sql .= " AND (t.from_warehouse_id = ? OR t.to_warehouse_id = ?)";
        $types .= 'ii';
        $params[] = $warehouseId;
        $params[] = $warehouseId;
    }
    $sql .= " ORDER BY t.date DESC, t.id DESC LIMIT ?";
    $types .= 'i';
    $params[] = $limit;

    $rows = [];
    $st = $conn->prepare($sql);
    if ($st) {
        $st->bind_param($types, ...$params);
        $st->execute();
        $res = $st->get_result();
        if ($res) {
            while ($r = $res->fetch_assoc()) {
                $rows[] = $r;
            }
        }
    }
    $ids = array_map(static function ($r) {
        return (int)($r['id'] ?? 0);
    }, $rows);
    $linesMap = pos_fetch_stock_transfer_lines_map($conn, $ids);
    $out = [];
    foreach ($rows as $r) {
        $tid = (int)($r['id'] ?? 0);
        $lines = $linesMap[$tid] ?? [];
        $lineTotalValue = 0.0;
        foreach ($lines as $ln) {
            $lineTotalValue += (float)($ln['line_total'] ?? 0);
        }
        $out[] = [
            'id' => $tid,
            'transaction_id' => pos_format_stock_transfer_number($tid, (string)($r['transaction_id'] ?? '')),
            'from_warehouse_id' => (int)($r['from_warehouse_id'] ?? 0),
            'to_warehouse_id' => (int)($r['to_warehouse_id'] ?? 0),
            'from_warehouse_name' => (string)($r['from_warehouse_name'] ?? ''),
            'to_warehouse_name' => (string)($r['to_warehouse_name'] ?? ''),
            'status' => (string)($r['status'] ?? ''),
            'total_qty' => roundMoney((float)($r['total_qty'] ?? 0)),
            'total_value' => roundMoney($lineTotalValue),
            'date' => (string)($r['date'] ?? ''),
            'user' => (string)($r['user'] ?? ''),
            'note' => (string)($r['note'] ?? ''),
            'lines' => $lines,
            'line_count' => count($lines),
        ];
    }
    return [
        'transfers' => $out,
        'date_from' => $dateFrom,
        'date_to' => $dateTo,
    ];
}

function pos_fetch_stock_transfer_detail(mysqli $conn, int $transferId): ?array {
    if ($transferId <= 0) return null;
    $st = $conn->prepare("SELECT t.id, t.from_warehouse_id, t.to_warehouse_id, t.status, t.transaction_id, t.total_qty, t.date, t.`user`, t.note,
                                 wf.name AS from_warehouse_name, wt.name AS to_warehouse_name
                          FROM stock_transfers t
                          LEFT JOIN warehouses wf ON wf.id = t.from_warehouse_id
                          LEFT JOIN warehouses wt ON wt.id = t.to_warehouse_id
                          WHERE t.id = ? LIMIT 1");
    if (!$st) return null;
    $st->bind_param('i', $transferId);
    $st->execute();
    $r = $st->get_result()->fetch_assoc();
    if (!$r) return null;
    $linesMap = pos_fetch_stock_transfer_lines_map($conn, [$transferId]);
    $lines = $linesMap[$transferId] ?? [];
    $lineTotalValue = 0.0;
    foreach ($lines as $ln) {
        $lineTotalValue += (float)($ln['line_total'] ?? 0);
    }
    $id = (int)$r['id'];
    return [
        'id' => $id,
        'transaction_id' => pos_format_stock_transfer_number($id, (string)($r['transaction_id'] ?? '')),
        'from_warehouse_id' => (int)($r['from_warehouse_id'] ?? 0),
        'to_warehouse_id' => (int)($r['to_warehouse_id'] ?? 0),
        'from_warehouse_name' => (string)($r['from_warehouse_name'] ?? ''),
        'to_warehouse_name' => (string)($r['to_warehouse_name'] ?? ''),
        'status' => (string)($r['status'] ?? ''),
        'total_qty' => roundMoney((float)($r['total_qty'] ?? 0)),
        'total_value' => roundMoney($lineTotalValue),
        'date' => (string)($r['date'] ?? ''),
        'user' => (string)($r['user'] ?? ''),
        'note' => (string)($r['note'] ?? ''),
        'lines' => $lines,
    ];
}

/** Max user accounts allowed: free 3, Pro 5, Pro Plus 99; secret menu override only on free tier. */
function pos_max_staff_allowed_from_settings(array $settings): int {
    $tier = function_exists('pos_subscription_tier_from_settings')
        ? pos_subscription_tier_from_settings($settings)
        : 'free';
    if ($tier !== 'free') {
        return function_exists('pos_max_staff_for_tier') ? pos_max_staff_for_tier($tier) : ($tier === 'pro_plus' ? 99 : 5);
    }
    if (isset($settings['maxStaffAllowed'])) {
        $n = (int)$settings['maxStaffAllowed'];
        if ($n >= 1 && $n <= 999) {
            return $n;
        }
    }
    if (!empty($settings['unlockStaffBeyondFive'])) {
        return 99;
    }
    return 3;
}

/** Max completed sales per business day (default 5). Secret menu → maxDailySalesAllowed. */
function pos_max_daily_sales_allowed_from_settings(array $settings): int {
    if (isset($settings['maxDailySalesAllowed'])) {
        $n = (int)$settings['maxDailySalesAllowed'];
        if ($n >= 1 && $n <= 99999) {
            return $n;
        }
    }
    return 5;
}

function pos_business_day_start_datetime(array $settings): string {
    $startHour = isset($settings['businessDayStartHour']) ? (int)$settings['businessDayStartHour'] : 0;
    if ($startHour < 0) {
        $startHour = 0;
    }
    if ($startHour > 23) {
        $startHour = 23;
    }
    $now = new DateTime('now');
    $boundary = DateTime::createFromFormat('Y-m-d H:i:s', $now->format('Y-m-d') . sprintf(' %02d:00:00', $startHour));
    if (!$boundary) {
        return $now->format('Y-m-d') . ' 00:00:00';
    }
    if ($now < $boundary) {
        $boundary->modify('-1 day');
    }
    return $boundary->format('Y-m-d H:i:s');
}

/**
 * Inclusive calendar dates → [startDt, endExclusiveDt] using businessDayStartHour (matches daily/month stats).
 * @return array{0:string,1:string,start_hour:int}
 */
function pos_business_day_range_datetimes($fromYmd, $toYmd, array $settings = []) {
    $fromYmd = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$fromYmd) ? (string)$fromYmd : date('Y-m-d');
    $toYmd = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$toYmd) ? (string)$toYmd : $fromYmd;
    if ($fromYmd > $toYmd) {
        $tmp = $fromYmd;
        $fromYmd = $toYmd;
        $toYmd = $tmp;
    }
    $startHour = isset($settings['businessDayStartHour']) ? (int)$settings['businessDayStartHour'] : 0;
    if ($startHour < 0) {
        $startHour = 0;
    }
    if ($startHour > 23) {
        $startHour = 23;
    }
    $sh = sprintf('%02d:00:00', $startHour);
    $startDt = $fromYmd . ' ' . $sh;
    try {
        $endExclusive = (new DateTimeImmutable($toYmd))->modify('+1 day')->format('Y-m-d') . ' ' . $sh;
    } catch (Throwable $e) {
        $endExclusive = date('Y-m-d', strtotime($toYmd . ' +1 day')) . ' ' . $sh;
    }
    return [$startDt, $endExclusive, $startHour];
}

/** Stamp returns.total_usd (and optional total_iqd) after INSERT — mirrors sale dual totals. */
function pos_return_stamp_dual_totals($conn, $returnId, $totalIqd, $fxRateBundle = 0, $ratePerOne = null) {
    $returnId = (int)$returnId;
    if ($returnId <= 0 || !$conn) {
        return false;
    }
    if (function_exists('checkAndAddCol')) {
        checkAndAddCol($conn, 'returns', 'total_usd', 'DECIMAL(18,6) NULL DEFAULT NULL');
        checkAndAddCol($conn, 'returns', 'total_iqd', 'DECIMAL(18,3) NULL DEFAULT NULL');
        checkAndAddCol($conn, 'returns', 'exchange_rate', 'DECIMAL(18,6) NULL DEFAULT NULL');
    }
    $rate = 0.0;
    if ($ratePerOne !== null && (float)$ratePerOne > 0) {
        $rate = (float)$ratePerOne;
    } else {
        $bundle = (float)$fxRateBundle;
        if ($bundle >= 100) {
            $rate = $bundle / 100.0;
        } elseif ($bundle > 0) {
            $rate = $bundle;
        } else {
            $rate = function_exists('pos_current_expense_exchange_rate')
                ? (float)pos_current_expense_exchange_rate($conn)
                : 1500.0;
        }
    }
    $totalIqd = function_exists('pos_convert_currency')
        ? pos_convert_currency($totalIqd, 'IQD', 'IQD', $rate)
        : round((float)$totalIqd, 2);
    $totalUsd = function_exists('pos_convert_currency')
        ? pos_convert_currency($totalIqd, 'IQD', 'USD', $rate)
        : ($rate > 0 ? round($totalIqd / $rate, 2) : 0.0);
    try {
        $st = $conn->prepare('UPDATE `returns` SET total_iqd = ?, total_usd = ?, exchange_rate = ? WHERE id = ?');
        if (!$st) {
            return false;
        }
        $st->bind_param('dddi', $totalIqd, $totalUsd, $rate, $returnId);
        return (bool)$st->execute();
    } catch (Throwable $e) {
        return false;
    }
}

function pos_count_sales_since_business_day_start($conn, array $settings): int {
    $from = pos_business_day_start_datetime($settings);
    $stmt = $conn->prepare('SELECT COUNT(*) AS c FROM sales WHERE created_at >= ?');
    if (!$stmt) {
        return 0;
    }
    $stmt->bind_param('s', $from);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res && ($row = $res->fetch_assoc())) {
        return (int)($row['c'] ?? 0);
    }
    return 0;
}

/**
 * Debt notebook fields (opening balance, debt limit): UI sends amounts in the shop's display currency.
 * DB stores canonical IQD (same as sales totals). When currencyMode is USD, multiply by USD→IQD rate.
 */
function pos_debt_form_amounts_to_stored_iqd($conn, $openingIn, $limitIn) {
    $opening = roundMoney((float)$openingIn);
    $limit = roundMoney((float)$limitIn);
    if ($opening < 0) {
        $opening = 0;
    }
    if ($limit < 0) {
        $limit = 0;
    }
    $settings = pos_load_app_settings_array($conn);
    if (pos_settings_currency_mode_from_array($settings) === 'USD') {
        $r = pos_settings_usd_rate_per_one_from_array($settings);
        if ($r > 0) {
            $opening = roundMoney($opening * $r);
            $limit = roundMoney($limit * $r);
        }
    }
    return [$opening, $limit];
}

/** Parse optional USD catalog field from POST; empty / missing => null. */
function pos_post_usd_decimal_optional($key) {
    if (!isset($_POST[$key])) {
        return null;
    }
    $s = trim((string)$_POST[$key]);
    if ($s === '') {
        return null;
    }
    $s = str_replace(',', '', $s);
    if (!is_numeric($s)) {
        return null;
    }
    $n = (float)$s;
    if (!is_finite($n)) {
        return null;
    }
    return round($n, 6);
}

/** Store USD reference with bounded precision. */
function pos_round_usd_catalog_store($n) {
    $n = (float)$n;
    if (!is_finite($n)) {
        return null;
    }
    return round($n, 6);
}

function pos_product_base_currency_from_row($row, $fallbackMode = 'IQD') {
    $c = strtoupper(trim((string)($row['base_currency'] ?? '')));
    if ($c !== 'USD' && $c !== 'IQD') {
        $c = strtoupper(trim((string)($row['currency'] ?? '')));
    }
    if ($c === 'USD' || $c === 'IQD') {
        return $c;
    }
    $fb = strtoupper(trim((string)$fallbackMode));
    return ($fb === 'USD') ? 'USD' : 'IQD';
}

function pos_usd_value_looks_like_iqd_snapshot($usdVal, $iqdVal, $ratePerOne) {
    $u = (float)$usdVal;
    $i = (float)$iqdVal;
    $r = (float)$ratePerOne;
    if (!($u > 0) || !($r > 0)) {
        return false;
    }
    if ($i > 0 && abs($u - $i) / max(abs($i), 1.0) < 0.02) {
        return true;
    }
    if ($i > 0 && $u >= ($r * 10) && abs(($u * $r) - $i) / max(abs($i), 1.0) < 0.05) {
        return true;
    }
    return false;
}

function pos_product_base_amount_from_row($row, $baseKey, $usdKey, $iqdKey, $fallbackMode = 'IQD', $ratePerOne = 0) {
    $cur = pos_product_base_currency_from_row($row, $fallbackMode);
    $iqdCol = (float)($row[$iqdKey] ?? 0);
    $raw = null;
    if (isset($row[$baseKey]) && $row[$baseKey] !== null && $row[$baseKey] !== '') {
        $candidate = (float)$row[$baseKey];
        if (is_finite($candidate) && $candidate > 0) {
            $raw = $candidate;
        }
    }
    if ($raw === null && $cur === 'USD' && isset($row[$usdKey]) && $row[$usdKey] !== null && $row[$usdKey] !== '') {
        $usdCand = (float)$row[$usdKey];
        if (is_finite($usdCand) && $usdCand > 0) {
            $raw = $usdCand;
        }
    }
    $r = (float)$ratePerOne;
    if ($cur === 'USD') {
        if ($raw !== null && is_finite($raw) && $raw > 0) {
            if ($r > 0 && pos_usd_value_looks_like_iqd_snapshot($raw, $iqdCol, $r)) {
                return pos_round_usd_catalog_store($raw / $r);
            }
            return $raw;
        }
        if ($r > 0 && $iqdCol > 0) {
            return pos_round_usd_catalog_store($iqdCol / $r);
        }
        return 0.0;
    }
    if ($raw !== null && is_finite($raw)) {
        return $raw;
    }
    return $iqdCol;
}

/** Runtime IQD from fixed base. Never writes to DB. */
function pos_product_amount_iqd($row, $baseKey, $usdKey, $iqdKey, $ratePerOne, $fallbackMode = 'IQD') {
    $base = pos_product_base_amount_from_row($row, $baseKey, $usdKey, $iqdKey, $fallbackMode, $ratePerOne);
    $cur = pos_product_base_currency_from_row($row, $fallbackMode);
    $r = (float)$ratePerOne;
    if ($cur === 'USD' && $r <= 0) {
        return roundMoney((float)($row[$iqdKey] ?? 0));
    }
    return pos_convert_currency($base, $cur, 'IQD', $r);
}

/** Runtime USD from fixed base. Never writes to DB. */
function pos_product_amount_usd($row, $baseKey, $usdKey, $iqdKey, $ratePerOne, $fallbackMode = 'IQD') {
    $base = pos_product_base_amount_from_row($row, $baseKey, $usdKey, $iqdKey, $fallbackMode, $ratePerOne);
    $cur = pos_product_base_currency_from_row($row, $fallbackMode);
    $r = (float)$ratePerOne;
    if ($cur === 'IQD' && $r <= 0) {
        return 0.0;
    }
    return pos_convert_currency($base, $cur, 'USD', $r);
}

function pos_product_write_base_fields($conn, $pid, $baseCurrency, $basePrice, $baseCost) {
    $pid = (int)$pid;
    if ($pid <= 0 || !$conn) {
        return false;
    }
    $baseCurrency = pos_normalize_currency_mode($baseCurrency);
    $basePrice = (float)$basePrice;
    $baseCost = (float)$baseCost;
    if (!is_finite($basePrice)) {
        $basePrice = 0.0;
    }
    if (!is_finite($baseCost)) {
        $baseCost = 0.0;
    }
    try {
        $st = $conn->prepare("UPDATE products SET base_currency=?, base_price=?, base_cost=?, currency=? WHERE id=?");
        if ($st) {
            $st->bind_param("sddsi", $baseCurrency, $basePrice, $baseCost, $baseCurrency, $pid);
            $ok = (bool)$st->execute();
        } else {
            $st = $conn->prepare("UPDATE products SET base_currency=?, base_price=?, base_cost=? WHERE id=?");
            if (!$st) {
                return false;
            }
            $st->bind_param("sddi", $baseCurrency, $basePrice, $baseCost, $pid);
            $ok = (bool)$st->execute();
        }
        if ($ok) {
            @$conn->query("UPDATE products SET cost_price = COALESCE(cost, 0) WHERE id = " . $pid);
        }
        return $ok;
    } catch (Throwable $e) {
        return false;
    }
}

function pos_product_sync_base_fields($conn, $pid) {
    $pid = (int)$pid;
    if ($pid <= 0 || !$conn) {
        return false;
    }
    try {
        $st = $conn->prepare("SELECT price, cost, price_usd, cost_usd, base_currency, base_price, base_cost FROM products WHERE id=? LIMIT 1");
        if (!$st) {
            return false;
        }
        $st->bind_param("i", $pid);
        $st->execute();
        $res = $st->get_result();
        $row = $res ? $res->fetch_assoc() : null;
        if (!$row) {
            return false;
        }
        $mode = pos_product_base_currency_from_row($row, '');
        if ($mode !== 'USD' && $mode !== 'IQD') {
            $mode = (function_exists('pos_is_usd_currency_system') && pos_is_usd_currency_system($conn)) ? 'USD' : 'IQD';
        }
        $rate = 0.0;
        if (function_exists('pos_current_expense_exchange_rate')) {
            $rate = (float)pos_current_expense_exchange_rate($conn);
        } elseif ($mode === 'USD' && function_exists('pos_load_app_settings_array') && function_exists('pos_settings_usd_rate_per_one_from_array')) {
            $rate = (float)pos_settings_usd_rate_per_one_from_array(pos_load_app_settings_array($conn));
        }
        $existingPrice = (isset($row['base_price']) && $row['base_price'] !== null && $row['base_price'] !== '')
            ? (float)$row['base_price'] : null;
        $existingCost = (isset($row['base_cost']) && $row['base_cost'] !== null && $row['base_cost'] !== '')
            ? (float)$row['base_cost'] : null;
        if ($mode === 'USD') {
            $bp = (isset($row['price_usd']) && $row['price_usd'] !== null && $row['price_usd'] !== '')
                ? (float)$row['price_usd']
                : (($existingPrice !== null && $existingPrice > 0) ? $existingPrice
                    : (($rate > 0) ? pos_round_usd_catalog_store((float)($row['price'] ?? 0) / $rate) : 0.0));
            $bc = (isset($row['cost_usd']) && $row['cost_usd'] !== null && $row['cost_usd'] !== '')
                ? (float)$row['cost_usd']
                : (($existingCost !== null && $existingCost > 0) ? $existingCost
                    : (($rate > 0) ? pos_round_usd_catalog_store((float)($row['cost'] ?? 0) / $rate) : 0.0));
            return pos_product_write_base_fields($conn, $pid, 'USD', $bp, $bc);
        }
        $bpIqd = (float)($row['price'] ?? 0);
        $bcIqd = (float)($row['cost'] ?? 0);
        if (!($bpIqd > 0) && $existingPrice !== null) {
            $bpIqd = $existingPrice;
        }
        if (!($bcIqd > 0) && $existingCost !== null) {
            $bcIqd = $existingCost;
        }
        return pos_product_write_base_fields($conn, $pid, 'IQD', $bpIqd, $bcIqd);
    } catch (Throwable $e) {
        return false;
    }
}

/**
 * Stamp locked sale price / currency / rate onto cart JSON so reports never re-convert.
 */
function pos_lock_sale_items_fx($itemsJson, $fxRateBundle, $fxMode) {
    $items = is_array($itemsJson) ? $itemsJson : json_decode((string)$itemsJson, true);
    if (!is_array($items)) {
        return is_string($itemsJson) ? $itemsJson : json_encode($itemsJson);
    }
    $mode = pos_normalize_currency_mode($fxMode);
    $bundle = (int)$fxRateBundle;
    if ($bundle < 1000) {
        $bundle = 0;
    }
    $ratePerOne = ($bundle >= 100) ? ($bundle / 100.0) : 0.0;
    foreach ($items as &$it) {
        if (!is_array($it)) {
            continue;
        }
        $lockedIqd = isset($it['price']) ? (float)$it['price'] : 0.0;
        $it['sale_price'] = $lockedIqd;
        $it['sale_currency'] = $mode;
        if ($bundle > 0) {
            $it['sale_exchange_rate'] = $bundle;
            $it['fx_usd_rate'] = $bundle;
        }
        $it['fx_currency_mode'] = $mode;
        if ($mode === 'USD') {
            $usd = null;
            if (isset($it['bill_unit_usd']) && $it['bill_unit_usd'] !== '' && is_numeric($it['bill_unit_usd'])) {
                $usd = (float)$it['bill_unit_usd'];
            } elseif ($ratePerOne > 0 && $lockedIqd > 0) {
                $usd = pos_round_usd_catalog_store($lockedIqd / $ratePerOne);
                $it['bill_unit_usd'] = $usd;
            }
            if ($usd !== null) {
                $it['sale_price_usd'] = $usd;
            }
            if ($ratePerOne > 0 && empty($it['fx_rate_per_one'])) {
                $it['fx_rate_per_one'] = $ratePerOne;
            }
        }
    }
    unset($it);
    $flags = JSON_UNESCAPED_UNICODE;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
        $flags |= JSON_INVALID_UTF8_SUBSTITUTE;
    }
    $out = json_encode($items, $flags);
    return ($out !== false) ? $out : (is_string($itemsJson) ? $itemsJson : '{}');
}

/**
 * Intentionally a no-op. Changing the global exchange rate must never rewrite catalog prices.
 * Conversion happens only at display / checkout from base_price + base_currency.
 */
function pos_reprice_products_iqd_from_usd($conn, $ratePerOne) {
    return;
}

function pos_inventory_native_currency_from_row($row, $fallbackMode = 'IQD') {
    $c = strtoupper(trim((string)($row['currency'] ?? '')));
    if ($c === 'USD' || $c === 'IQD') {
        return $c;
    }
    $fb = strtoupper(trim((string)$fallbackMode));
    return ($fb === 'USD') ? 'USD' : 'IQD';
}

function pos_inventory_native_unit_from_row($row, $keys) {
    if (!is_array($row) || !is_array($keys)) {
        return 0.0;
    }
    foreach ($keys as $k) {
        if (!array_key_exists($k, $row) || $row[$k] === null || $row[$k] === '') {
            continue;
        }
        $n = (float)$row[$k];
        if (is_finite($n) && $n > 0) {
            return $n;
        }
    }
    foreach ($keys as $k) {
        if (!array_key_exists($k, $row) || $row[$k] === null || $row[$k] === '') {
            continue;
        }
        $n = (float)$row[$k];
        if (is_finite($n)) {
            return $n;
        }
    }
    return 0.0;
}

/**
 * Inventory cost/sell value by summing each item in its native currency.
 * IQD items: qty * cost_price / price (no FX). USD items: qty * cost_usd / price_usd.
 * Shop IQD total converts the USD bucket once (sumUsd * rate). Shop USD total converts
 * the IQD bucket once (sumIqd / rate). 100% native catalogs do not drift when the rate changes.
 * Never writes products.
 * @return array{iqd:float,usd:float,sale_iqd:float,sale_usd:float}
 */
function pos_inventory_stock_value_pair($conn) {
    $costIqd = 0.0;
    $costUsd = 0.0;
    $saleIqd = 0.0;
    $saleUsd = 0.0;
    $rate = function_exists('pos_current_expense_exchange_rate') ? (float)pos_current_expense_exchange_rate($conn) : 1500.0;
    if ($rate <= 0) {
        $rate = 1500.0;
    }
    $fallback = (function_exists('pos_is_usd_currency_system') && pos_is_usd_currency_system($conn)) ? 'USD' : 'IQD';
    $sqlFull = 'SELECT qty, cost, cost_price, cost_usd, price, price_usd, base_cost, base_price, base_currency, currency FROM products WHERE trackStock = 1';
    $sqlMin = 'SELECT qty, cost, cost_usd, base_cost, base_currency, currency FROM products WHERE trackStock = 1';
    try {
        $res = @$conn->query($sqlFull);
        if (!$res) {
            $res = $conn->query($sqlMin);
        }
        if ($res) {
            while ($r = $res->fetch_assoc()) {
                $qty = (float)($r['qty'] ?? 0);
                if ($qty <= 0) {
                    continue;
                }
                $cur = pos_inventory_native_currency_from_row($r, $fallback);
                if ($cur === 'USD') {
                    $costUsd += $qty * pos_inventory_native_unit_from_row($r, ['cost_usd', 'base_cost']);
                    $saleUsd += $qty * pos_inventory_native_unit_from_row($r, ['price_usd', 'base_price']);
                } else {
                    $costIqd += $qty * pos_inventory_native_unit_from_row($r, ['cost_price', 'cost', 'base_cost']);
                    $saleIqd += $qty * pos_inventory_native_unit_from_row($r, ['price', 'base_price']);
                }
            }
        }
    } catch (Throwable $e) {}
    $roundIqd = function ($n) {
        return function_exists('roundMoney') ? roundMoney($n) : round($n);
    };
    $roundUsd = function ($n) {
        return function_exists('pos_round_usd_catalog_store')
            ? (float)pos_round_usd_catalog_store($n)
            : round((float)$n, 2);
    };
    $iqd = $roundIqd($costIqd + ($rate > 0 ? $costUsd * $rate : 0.0));
    $usd = $roundUsd($costUsd + ($rate > 0 ? $costIqd / $rate : 0.0));
    return [
        'iqd' => $iqd,
        'usd' => $usd,
        'sale_iqd' => $roundIqd($saleIqd + ($rate > 0 ? $saleUsd * $rate : 0.0)),
        'sale_usd' => $roundUsd($saleUsd + ($rate > 0 ? $saleIqd / $rate : 0.0)),
    ];
}

function pos_stamp_table_fx($conn, $table, $id, $currency = 'IQD', $ratePerOne = null) {
    $id = (int)$id;
    $allowed = ['supplies' => 1, 'customer_ledger' => 1, 'customers' => 1, 'companies' => 1];
    if ($id <= 0 || !$conn || !isset($allowed[$table])) {
        return false;
    }
    if (function_exists('pos_ensure_txn_fx_columns')) {
        pos_ensure_txn_fx_columns($conn);
    }
    if ($table === 'supplies' && function_exists('pos_ensure_fx_engine_schema')) {
        pos_ensure_fx_engine_schema($conn);
    }
    $currency = function_exists('pos_normalize_currency_mode') ? pos_normalize_currency_mode($currency) : 'IQD';
    $rate = ($ratePerOne !== null && (float)$ratePerOne > 0)
        ? (float)$ratePerOne
        : (function_exists('pos_current_expense_exchange_rate') ? pos_current_expense_exchange_rate($conn) : 1500.0);
    try {
        $st = $conn->prepare("UPDATE `{$table}` SET currency = ?, exchange_rate = ? WHERE id = ?");
        if (!$st) {
            return false;
        }
        $st->bind_param('sdi', $currency, $rate, $id);
        $ok = (bool)$st->execute();
        if ($ok && $table === 'supplies') {
            @$conn->query("UPDATE supplies SET total_amount = COALESCE(totalCost, 0) WHERE id = " . $id);
        }
        return $ok;
    } catch (Throwable $e) {
        return false;
    }
}

/**
 * Stamp dual IQD/USD sale totals after INSERT. Does not rewrite `total` / `paid_amount`.
 */
function pos_sale_stamp_dual_totals($conn, $saleId, $totalIqd, $paidIqd, $fxRateBundle = 0, $ratePerOne = null) {
    $saleId = (int)$saleId;
    if ($saleId <= 0 || !$conn) {
        return false;
    }
    if (function_exists('pos_ensure_fx_engine_schema')) {
        pos_ensure_fx_engine_schema($conn);
    }
    $rate = 0.0;
    if ($ratePerOne !== null && (float)$ratePerOne > 0) {
        $rate = (float)$ratePerOne;
    } else {
        $bundle = (float)$fxRateBundle;
        if ($bundle >= 100) {
            $rate = $bundle / 100.0;
        } elseif ($bundle > 0) {
            $rate = $bundle;
        } else {
            $rate = function_exists('pos_current_expense_exchange_rate')
                ? (float)pos_current_expense_exchange_rate($conn)
                : 1500.0;
        }
    }
    $totalIqd = pos_convert_currency($totalIqd, 'IQD', 'IQD', $rate);
    $paidIqd = pos_convert_currency($paidIqd, 'IQD', 'IQD', $rate);
    $totalUsd = pos_convert_currency($totalIqd, 'IQD', 'USD', $rate);
    $paidUsd = pos_convert_currency($paidIqd, 'IQD', 'USD', $rate);
    try {
        $st = $conn->prepare("UPDATE sales SET total_iqd = ?, total_usd = ?, paid_iqd = ?, paid_usd = ?, exchange_rate = ? WHERE id = ?");
        if (!$st) {
            return false;
        }
        $st->bind_param('dddddi', $totalIqd, $totalUsd, $paidIqd, $paidUsd, $rate, $saleId);
        return (bool)$st->execute();
    } catch (Throwable $e) {
        return false;
    }
}

/**
 * Net cash effect on قاسە from unified ledger rows (positive = cash in drawer).
 * Keep in sync with client getFinancialMetrics cash in/out buckets.
 */
function pos_ledger_treasury_net_sql(): string
{
    return "SUM(CASE
        WHEN type IN ('sale', 'debt_payment_in', 'return_to_supplier') THEN amount
        WHEN type IN ('expense', 'purchase', 'debt_payment', 'refund', 'waste', 'void_sale') THEN -amount
        ELSE 0
    END)";
}

/** Cash / debt / FIB parts of one sale row (IQD stored amounts, no FX). */
function pos_sale_row_payment_split(array $s) {
    $total = function_exists('roundMoney') ? roundMoney($s['total'] ?? 0) : (float) ($s['total'] ?? 0);
    $pm = strtolower(trim((string) ($s['payment_method'] ?? '')));
    $debtAmt = function_exists('roundMoney') ? roundMoney($s['debt_amount'] ?? 0) : (float) ($s['debt_amount'] ?? 0);
    $bankAmt = function_exists('roundMoney')
        ? roundMoney($s['bank_amount'] ?? ($s['paid_bank'] ?? 0))
        : (float) ($s['bank_amount'] ?? ($s['paid_bank'] ?? 0));
    if ($pm === 'debt') {
        return ['cash' => 0.0, 'debt' => $total, 'fib' => 0.0];
    }
    if ($pm === 'fib' || $pm === 'bank' || $pm === 'bankcard' || $pm === 'card') {
        return ['cash' => 0.0, 'debt' => 0.0, 'fib' => $total];
    }
    $paidCash = array_key_exists('paid_cash', $s) && $s['paid_cash'] !== null && $s['paid_cash'] !== ''
        ? (function_exists('roundMoney') ? roundMoney($s['paid_cash']) : (float) $s['paid_cash'])
        : null;
    $paidAmt = array_key_exists('paid_amount', $s) && $s['paid_amount'] !== null && $s['paid_amount'] !== ''
        ? (function_exists('roundMoney') ? roundMoney($s['paid_amount']) : (float) $s['paid_amount'])
        : null;
    $cash = 0.0;
    if ($paidCash !== null && $paidCash > 0) {
        $cash = $paidCash;
    } elseif ($paidCash !== null && $paidCash <= 0 && ($pm === 'split' || $debtAmt > 0 || $bankAmt > 0)) {
        $cash = 0.0;
    } elseif ($paidAmt !== null && $paidAmt > 0) {
        $cash = max(0.0, $paidAmt - $bankAmt);
    } elseif ($paidAmt !== null && $paidAmt <= 0 && ($pm === 'split' || $debtAmt > 0 || $bankAmt > 0)) {
        $cash = 0.0;
    } else {
        $cash = max(0.0, $total - $debtAmt - $bankAmt);
    }
    return ['cash' => $cash, 'debt' => $debtAmt, 'fib' => $bankAmt];
}

function pos_items_cogs_from_json($itemsJson) {
    $items = $itemsJson;
    if (is_string($itemsJson)) {
        $items = json_decode($itemsJson, true);
    } elseif (is_object($itemsJson)) {
        $items = json_decode(json_encode($itemsJson), true);
    }
    if (!is_array($items)) {
        return 0.0;
    }
    $cogs = 0.0;
    foreach ($items as $it) {
        if (is_object($it)) {
            $it = (array) $it;
        }
        if (!is_array($it)) {
            continue;
        }
        $cost = (float) ($it['cost'] ?? 0);
        $raw = $it['qty'] ?? ($it['count'] ?? 1);
        $q = is_numeric($raw) ? (float) $raw : 1.0;
        if ($q <= 0) {
            $q = 1.0;
        }
        $cogs += $cost * $q;
    }
    return function_exists('roundMoney') ? roundMoney($cogs) : $cogs;
}

/** Raw USD COGS from line cost_usd stamps (never FX re-ratio). Null if no line has cost_usd. */
function pos_items_cogs_usd_from_json($itemsJson) {
    $items = $itemsJson;
    if (is_string($itemsJson)) {
        $items = json_decode($itemsJson, true);
    } elseif (is_object($itemsJson)) {
        $items = json_decode(json_encode($itemsJson), true);
    }
    if (!is_array($items)) {
        return null;
    }
    $cogs = 0.0;
    $saw = false;
    foreach ($items as $it) {
        if (is_object($it)) {
            $it = (array) $it;
        }
        if (!is_array($it)) {
            continue;
        }
        if (!array_key_exists('cost_usd', $it) || $it['cost_usd'] === '' || $it['cost_usd'] === null || !is_numeric($it['cost_usd'])) {
            continue;
        }
        $saw = true;
        $raw = $it['qty'] ?? ($it['count'] ?? 1);
        $q = is_numeric($raw) ? (float) $raw : 1.0;
        if ($q <= 0) {
            $q = 1.0;
        }
        $cogs += ((float)$it['cost_usd']) * $q;
    }
    return $saw ? round($cogs, 2) : null;
}

/**
 * SINGLE SOURCE OF TRUTH — financial metrics for a date range.
 * Mirrors public/js/modules/utils.js getFinancialMetrics() math.
 *
 * Currency immutability:
 * - USD fields: stamped total_usd / cost_usd / proportional slices, else frozen row FX only (never live).
 * - IQD fields: canonical stored IQD amounts.
 *
 * @param mysqli $conn
 * @param string $startDate Inclusive start (Y-m-d or Y-m-d H:i:s)
 * @param string $endDateExclusive Exclusive end
 * @param string $currencyMode Preferred display mode USD|IQD (both iqd + usd always returned)
 * @param array $filters Optional: cashier (string), user_name (string), see_shop_wide (bool)
 * @return array
 */
function pos_get_financial_metrics_core(mysqli $conn, $startDate, $endDateExclusive, $currencyMode = 'IQD', $filters = []) {
    $rm = function_exists('roundMoney') ? 'roundMoney' : static function ($v) { return round((float)$v, 2); };
    $mode = strtoupper(trim((string)$currencyMode));
    if ($mode !== 'USD' && $mode !== 'IQD') {
        $mode = (function_exists('pos_is_usd_currency_system') && pos_is_usd_currency_system($conn)) ? 'USD' : 'IQD';
    }
    $rs = $conn->real_escape_string((string)$startDate);
    $re = $conn->real_escape_string((string)$endDateExclusive);
    $filters = is_array($filters) ? $filters : [];
    $seeShopWide = !empty($filters['see_shop_wide']);
    $cashier = trim((string)($filters['cashier'] ?? ($filters['user_name'] ?? '')));
    $cashierEsc = $conn->real_escape_string($cashier);
    $saleCashierSql = (!$seeShopWide && $cashier !== '')
        ? " AND cashier = '{$cashierEsc}' "
        : '';
    $expUserSql = (!$seeShopWide && $cashier !== '')
        ? " AND `user` = '{$cashierEsc}' "
        : '';

    $toUsd = static function ($iqd, $row = null, $usdHint = null) use ($conn) {
        return function_exists('pos_stored_iqd_to_usd')
            ? (float)pos_stored_iqd_to_usd($iqd, is_array($row) ? $row : null, $usdHint, $conn)
            : 0.0;
    };

    $out = [
        'currency_mode' => $mode,
        'start' => (string)$startDate,
        'end_exclusive' => (string)$endDateExclusive,
        // IQD (canonical storage)
        'totalSales' => 0.0,
        'cashSales' => 0.0,
        'debtSales' => 0.0,
        'fibSales' => 0.0,
        'totalReturns' => 0.0,
        'totalReturnsCost' => 0.0,
        'cashRefunds' => 0.0,
        'totalCogs' => 0.0,
        'opExpenses' => 0.0,
        'cashPurchases' => 0.0,
        'fibPurchases' => 0.0,
        'totalPurchases' => 0.0,
        'debtPurchases' => 0.0,
        'companyDebtPayments' => 0.0,
        'companyDebtPaymentsFib' => 0.0,
        'debtPaymentsIn' => 0.0,
        'debtPaymentsInFib' => 0.0,
        'purchaseReturnsIn' => 0.0,
        'totalPurchaseReturns' => 0.0,
        'wasteLoss' => 0.0,
        'wasteCount' => 0,
        'saleCount' => 0,
        'giftsCount' => 0,
        'totalGiftsValue' => 0.0,
        'grossProfit' => 0.0,
        'netProfit' => 0.0,
        'cashMovement' => 0.0,
        'opening' => 0.0,
        'cashDrawer' => 0.0,
        'customerDebtOutstanding' => 0.0,
        'supplierDebtOutstanding' => 0.0,
        'last_receipt_id' => null,
        // Locked raw USD
        'totalSalesUsd' => 0.0,
        'cashSalesUsd' => 0.0,
        'debtSalesUsd' => 0.0,
        'fibSalesUsd' => 0.0,
        'totalReturnsUsd' => 0.0,
        'totalReturnsCostUsd' => 0.0,
        'cashRefundsUsd' => 0.0,
        'totalCogsUsd' => 0.0,
        'opExpensesUsd' => 0.0,
        'cashPurchasesUsd' => 0.0,
        'fibPurchasesUsd' => 0.0,
        'totalPurchasesUsd' => 0.0,
        'debtPurchasesUsd' => 0.0,
        'companyDebtPaymentsUsd' => 0.0,
        'companyDebtPaymentsFibUsd' => 0.0,
        'debtPaymentsInUsd' => 0.0,
        'debtPaymentsInFibUsd' => 0.0,
        'purchaseReturnsInUsd' => 0.0,
        'totalPurchaseReturnsUsd' => 0.0,
        'wasteLossUsd' => 0.0,
        'totalGiftsValueUsd' => 0.0,
        'grossProfitUsd' => 0.0,
        'netProfitUsd' => 0.0,
        'cashMovementUsd' => 0.0,
        'customerDebtOutstandingUsd' => 0.0,
        'supplierDebtOutstandingUsd' => 0.0,
    ];

    // --- Sales ---
    $lastId = 0;
    $sqlSales = "SELECT id, total, total_usd, payment_method, paid_amount, paid_cash, debt_amount, bank_amount, paid_bank, remaining_debt, items_json, fx_usd_rate, exchange_rate, fx_currency_mode, customer_id
        FROM sales WHERE created_at >= '{$rs}' AND created_at < '{$re}' AND (is_returned IS NULL OR is_returned = 0) {$saleCashierSql}";
    $res = @$conn->query($sqlSales);
    if (!$res) {
        $res = $conn->query("SELECT id, total, payment_method, paid_amount, paid_cash, debt_amount, bank_amount, items_json, fx_usd_rate, exchange_rate
            FROM sales WHERE created_at >= '{$rs}' AND created_at < '{$re}' AND (is_returned IS NULL OR is_returned = 0) {$saleCashierSql}");
    }
    if ($res) {
        while ($s = $res->fetch_assoc()) {
            $sid = (int)($s['id'] ?? 0);
            if ($sid > $lastId) {
                $lastId = $sid;
            }
            $out['saleCount']++;
            $saleIqd = (float)($s['total'] ?? 0);
            $out['totalSales'] += $saleIqd;
            $out['totalSalesUsd'] += $toUsd($saleIqd, $s, $s['total_usd'] ?? null);
            $split = pos_sale_row_payment_split($s);
            $out['cashSales'] += $split['cash'];
            $out['debtSales'] += $split['debt'];
            $out['fibSales'] += $split['fib'];
            $saleUsd = (isset($s['total_usd']) && is_numeric($s['total_usd'])) ? (float)$s['total_usd'] : null;
            $cashHint = ($saleUsd !== null && $saleIqd > 0) ? ($split['cash'] / $saleIqd) * $saleUsd : null;
            $debtHint = ($saleUsd !== null && $saleIqd > 0) ? ($split['debt'] / $saleIqd) * $saleUsd : null;
            $fibHint = ($saleUsd !== null && $saleIqd > 0) ? ($split['fib'] / $saleIqd) * $saleUsd : null;
            $out['cashSalesUsd'] += $toUsd($split['cash'], $s, $cashHint);
            $out['debtSalesUsd'] += $toUsd($split['debt'], $s, $debtHint);
            $out['fibSalesUsd'] += $toUsd($split['fib'], $s, $fibHint);
            $lineCogs = pos_items_cogs_from_json($s['items_json'] ?? '[]');
            $out['totalCogs'] += $lineCogs;
            $cogsUsdHint = function_exists('pos_items_cogs_usd_from_json')
                ? pos_items_cogs_usd_from_json($s['items_json'] ?? '[]')
                : null;
            $out['totalCogsUsd'] += $toUsd($lineCogs, $s, $cogsUsdHint);
            // Gifts from items
            $items = json_decode((string)($s['items_json'] ?? '[]'), true);
            if (is_array($items)) {
                foreach ($items as $it) {
                    if (!is_array($it) || empty($it['isGift'])) {
                        continue;
                    }
                    $q = isset($it['qty']) && is_numeric($it['qty']) ? (float)$it['qty'] : (isset($it['count']) && is_numeric($it['count']) ? (float)$it['count'] : 1.0);
                    if ($q <= 0) {
                        $q = 1.0;
                    }
                    $giftIqd = ((float)($it['price'] ?? 0)) * $q;
                    $out['totalGiftsValue'] += $giftIqd;
                    $giftHint = (isset($it['bill_unit_usd']) && is_numeric($it['bill_unit_usd']))
                        ? ((float)$it['bill_unit_usd'] * $q)
                        : null;
                    $out['totalGiftsValueUsd'] += $toUsd($giftIqd, $s, $giftHint);
                    $out['giftsCount'] += $q;
                }
            }
        }
    }
    $out['last_receipt_id'] = $lastId > 0 ? $lastId : null;

    // --- Returns ---
    $retSql = "SELECT total, total_usd, payment_method, items_json, fx_usd_rate, fx_currency_mode, exchange_rate FROM `returns` WHERE `date` >= '{$rs}' AND `date` < '{$re}'";
    if (!$seeShopWide && $cashier !== '') {
        $retSql .= " AND cashier = '{$cashierEsc}' ";
    }
    $rret = @$conn->query($retSql);
    if ($rret) {
        while ($r = $rret->fetch_assoc()) {
            $retIqd = (float)($r['total'] ?? 0);
            $out['totalReturns'] += $retIqd;
            $out['totalReturnsUsd'] += $toUsd($retIqd, $r, $r['total_usd'] ?? null);
            $pm = strtolower((string)($r['payment_method'] ?? ''));
            if ($pm !== 'debt' && $pm !== 'fib' && $pm !== 'bank' && $pm !== 'bankcard' && $pm !== 'card') {
                $out['cashRefunds'] += $retIqd;
                $out['cashRefundsUsd'] += $toUsd($retIqd, $r, $r['total_usd'] ?? null);
            }
            $rc = pos_items_cogs_from_json($r['items_json'] ?? '[]');
            $out['totalReturnsCost'] += $rc;
            $rcHint = function_exists('pos_items_cogs_usd_from_json') ? pos_items_cogs_usd_from_json($r['items_json'] ?? '[]') : null;
            $out['totalReturnsCostUsd'] += $toUsd($rc, $r, $rcHint);
        }
    }

    // --- Operational expenses ---
    $rexp = @$conn->query("SELECT amount, currency, exchange_rate, type, note, transaction_id FROM expenses WHERE `date` >= '{$rs}' AND `date` < '{$re}' {$expUserSql}");
    if ($rexp) {
        while ($e = $rexp->fetch_assoc()) {
            $ty = strtolower(trim((string)($e['type'] ?? '')));
            if ($ty === 'purchase' || $ty === 'purchase_return' || $ty === 'debt_payment' || $ty === 'debt_payment_fib') {
                continue;
            }
            if ($ty !== '' && $ty !== 'operational') {
                continue;
            }
            $iqd = function_exists('pos_expense_amount_iqd') ? (float)pos_expense_amount_iqd($e) : (float)($e['amount'] ?? 0);
            $usd = function_exists('pos_expense_amount_usd') ? (float)pos_expense_amount_usd($e) : $toUsd($iqd, $e);
            $out['opExpenses'] += $iqd;
            $out['opExpensesUsd'] += $usd;
        }
    }

    // --- Cash purchases (expenses.type=purchase) ---
    $rcp = @$conn->query("SELECT amount, currency, exchange_rate, transaction_id FROM expenses WHERE `date` >= '{$rs}' AND `date` < '{$re}' AND type = 'purchase' {$expUserSql}");
    if ($rcp) {
        while ($e = $rcp->fetch_assoc()) {
            $iqd = function_exists('pos_expense_amount_iqd') ? (float)pos_expense_amount_iqd($e) : (float)($e['amount'] ?? 0);
            $usd = function_exists('pos_expense_amount_usd') ? (float)pos_expense_amount_usd($e) : $toUsd($iqd, $e);
            $out['cashPurchases'] += $iqd;
            $out['cashPurchasesUsd'] += $usd;
        }
    }

    // --- Supplies: total purchases + FIB + supplier outstanding ---
    $rsup = @$conn->query("SELECT prodId, qtyAdded, totalCost, remaining_debt, type, company, fx_usd_rate, fx_currency_mode, exchange_rate, transaction_id
        FROM supplies WHERE `date` >= '{$rs}' AND `date` < '{$re}'
        AND COALESCE(type,'') NOT IN ('return','opening')
        AND qtyAdded > 0
        AND company IS NOT NULL AND TRIM(company) != ''
        AND LOWER(TRIM(company)) NOT LIKE 'direct store'");
    if ($rsup) {
        while ($s = $rsup->fetch_assoc()) {
            $costIqd = (float)($s['totalCost'] ?? 0);
            $out['totalPurchases'] += $costIqd;
            $out['totalPurchasesUsd'] += $toUsd($costIqd, $s);
            $ty = strtolower((string)($s['type'] ?? ''));
            if ($ty === 'fib' || $ty === 'bank' || $ty === 'bankcard') {
                $out['fibPurchases'] += $costIqd;
                $out['fibPurchasesUsd'] += $toUsd($costIqd, $s);
            }
            // Supplier debt outstanding on credit/split lines (range-scoped activity)
            if ($ty === 'credit' || $ty === 'split') {
                $rem = isset($s['remaining_debt']) && $s['remaining_debt'] !== '' && $s['remaining_debt'] !== null
                    ? max(0.0, (float)$s['remaining_debt'])
                    : max(0.0, $costIqd);
                if ($rem > 0.0001) {
                    $out['supplierDebtOutstanding'] += $rem;
                    $out['supplierDebtOutstandingUsd'] += $toUsd($rem, $s);
                }
            }
        }
    }
    $out['debtPurchases'] = max(0.0, $out['totalPurchases'] - $out['cashPurchases'] - $out['fibPurchases']);
    $out['debtPurchasesUsd'] = max(0.0, $out['totalPurchasesUsd'] - $out['cashPurchasesUsd'] - $out['fibPurchasesUsd']);

    // --- Company debt payments (cash only in drawer; FIB tracked separately) ---
    $rcd = @$conn->query("SELECT amount, currency, exchange_rate, transaction_id, note, type FROM expenses WHERE `date` >= '{$rs}' AND `date` < '{$re}' AND type IN ('debt_payment','debt_payment_fib') {$expUserSql}");
    if ($rcd) {
        while ($e = $rcd->fetch_assoc()) {
            $note = (string)($e['note'] ?? '');
            if (preg_match('/پێشەکی بۆ وەسڵ|split payment|کڕین \(نەقد\)|Bulk Invoice|وەسڵ #/iu', $note)) {
                continue;
            }
            $iqd = function_exists('pos_expense_amount_iqd') ? (float)pos_expense_amount_iqd($e) : (float)($e['amount'] ?? 0);
            $usd = function_exists('pos_expense_amount_usd') ? (float)pos_expense_amount_usd($e) : $toUsd($iqd, $e);
            $ety = strtolower(trim((string)($e['type'] ?? 'debt_payment')));
            if ($ety === 'debt_payment_fib') {
                $out['companyDebtPaymentsFib'] += $iqd;
                $out['companyDebtPaymentsFibUsd'] += $usd;
            } else {
                $out['companyDebtPayments'] += $iqd;
                $out['companyDebtPaymentsUsd'] += $usd;
            }
        }
    }

    // --- Customer debt payments in (cash → drawer; FIB excluded from drawer) ---
    // Prefer COALESCE(date, created_at) when available — matches get_daily_detail pools.
    $clTs = (function_exists('pos_table_date_column_sql'))
        ? pos_table_date_column_sql($conn, 'customer_ledger', '')
        : '`date`';
    $rcl = @$conn->query("SELECT amount, currency, exchange_rate, target_id, receipt_id, transaction_id, payment_method, type, note FROM customer_ledger WHERE ({$clTs}) >= '{$rs}' AND ({$clTs}) < '{$re}' AND type IN ('payment','pay')");
    if (!$rcl) {
        $rcl = @$conn->query("SELECT amount, currency, exchange_rate, target_id, receipt_id, transaction_id, type, note FROM customer_ledger WHERE ({$clTs}) >= '{$rs}' AND ({$clTs}) < '{$re}' AND type IN ('payment','pay')");
    }
    if (!$rcl) {
        $rcl = @$conn->query("SELECT amount, currency, exchange_rate, target_id, receipt_id, transaction_id, type, note FROM customer_ledger WHERE `date` >= '{$rs}' AND `date` < '{$re}' AND type IN ('payment','pay')");
    }
    if ($rcl) {
        while ($cl = $rcl->fetch_assoc()) {
            $amt = abs((float)($cl['amount'] ?? 0));
            $u = $toUsd($amt, $cl);
            if (!($u > 0) && $amt > 0 && !empty($cl['target_id'])) {
                $tid = (int)$cl['target_id'];
                $stSale = $conn->prepare("SELECT total, total_usd, exchange_rate, fx_usd_rate FROM sales WHERE customer_id = ? AND (total_usd IS NOT NULL OR exchange_rate IS NOT NULL OR fx_usd_rate IS NOT NULL) ORDER BY id DESC LIMIT 1");
                if ($stSale) {
                    $stSale->bind_param('i', $tid);
                    $stSale->execute();
                    $saleFx = $stSale->get_result()->fetch_assoc();
                    if ($saleFx) {
                        $u = $toUsd($amt, $saleFx);
                    }
                }
            }
            $isCash = function_exists('pos_customer_debt_payment_is_cash')
                ? pos_customer_debt_payment_is_cash($cl)
                : true;
            if ($isCash) {
                $out['debtPaymentsIn'] += $amt;
                $out['debtPaymentsInUsd'] += $u;
            } else {
                $out['debtPaymentsInFib'] += $amt;
                $out['debtPaymentsInFibUsd'] += $u;
            }
        }
    } else {
        // Fallback: ledger types when customer_ledger unavailable
        $rlIn = @$conn->query("SELECT amount, type FROM ledger WHERE `date` >= '{$rs}' AND `date` < '{$re}' AND type IN ('debt_payment_in','debt_payment_in_fib')");
        if ($rlIn) {
            while ($l = $rlIn->fetch_assoc()) {
                $amt = abs((float)($l['amount'] ?? 0));
                if (strtolower((string)($l['type'] ?? '')) === 'debt_payment_in_fib') {
                    $out['debtPaymentsInFib'] += $amt;
                } else {
                    $out['debtPaymentsIn'] += $amt;
                }
            }
        }
    }

    // --- Purchase returns ---
    $rpr = @$conn->query("SELECT total, cash_refunded, fx_usd_rate, fx_currency_mode, exchange_rate FROM purchase_returns WHERE `date` >= '{$rs}' AND `date` < '{$re}'");
    if ($rpr) {
        while ($pr = $rpr->fetch_assoc()) {
            $disp = (float)($pr['total'] ?? 0);
            $out['totalPurchaseReturns'] += $disp;
            $out['totalPurchaseReturnsUsd'] += $toUsd($disp, $pr);
            $cashPart = (isset($pr['cash_refunded']) && $pr['cash_refunded'] !== '' && $pr['cash_refunded'] !== null)
                ? (float)$pr['cash_refunded']
                : $disp;
            $out['purchaseReturnsIn'] += $cashPart;
            $out['purchaseReturnsInUsd'] += $toUsd($cashPart, $pr);
        }
    }

    // --- Waste ---
    $rw = @$conn->query("SELECT amount FROM ledger WHERE type = 'waste' AND `date` >= '{$rs}' AND `date` < '{$re}'");
    if ($rw) {
        while ($w = $rw->fetch_assoc()) {
            $amt = (float)($w['amount'] ?? 0);
            $out['wasteLoss'] += $amt;
            $out['wasteLossUsd'] += $toUsd($amt, $w);
            $out['wasteCount']++;
        }
    }

    // --- Customer outstanding debt (open sales remaining) — snapshot at query time for shop, not only period ---
    // Period-scoped: remaining_debt on sales created in range (matches "debt sales remaining" view for reports).
    $rrem = @$conn->query("SELECT remaining_debt, total, total_usd, paid_amount, paid_usd, exchange_rate, fx_usd_rate, fx_currency_mode
        FROM sales WHERE created_at >= '{$rs}' AND created_at < '{$re}' AND (is_returned IS NULL OR is_returned = 0)
        AND COALESCE(remaining_debt,0) > 0 {$saleCashierSql}");
    if ($rrem) {
        while ($s = $rrem->fetch_assoc()) {
            $rem = max(0.0, (float)($s['remaining_debt'] ?? 0));
            if ($rem <= 0) {
                continue;
            }
            $out['customerDebtOutstanding'] += $rem;
            $total = (float)($s['total'] ?? 0);
            $hint = null;
            if ($total > 0 && isset($s['total_usd']) && is_numeric($s['total_usd'])) {
                $hint = $rem * ((float)$s['total_usd'] / $total);
            }
            $out['customerDebtOutstandingUsd'] += $toUsd($rem, $s, $hint);
        }
    }

    // --- Opening / drawer ---
    $day = substr((string)$startDate, 0, 10);
    $dayEsc = $conn->real_escape_string($day);
    $rsh = @$conn->query("SELECT opening_balance FROM shifts WHERE startTime >= '{$dayEsc} 00:00:00' AND startTime < DATE_ADD('{$dayEsc}', INTERVAL 1 DAY) ORDER BY startTime ASC LIMIT 1");
    if ($rsh && ($sh = $rsh->fetch_assoc())) {
        $out['opening'] = (float)($sh['opening_balance'] ?? 0);
    }

    $out['grossProfit'] = ($out['totalSales'] - $out['totalReturns']) - ($out['totalCogs'] - $out['totalReturnsCost']);
    $out['netProfit'] = $out['grossProfit'] - $out['opExpenses'] - $out['wasteLoss'];
    $out['cashMovement'] = ($out['cashSales'] + $out['debtPaymentsIn'] + $out['purchaseReturnsIn'])
        - ($out['opExpenses'] + $out['cashPurchases'] + $out['companyDebtPayments'] + $out['cashRefunds']);
    $out['cashDrawer'] = $out['opening'] + $out['cashMovement'];

    $out['grossProfitUsd'] = ($out['totalSalesUsd'] - $out['totalReturnsUsd']) - ($out['totalCogsUsd'] - $out['totalReturnsCostUsd']);
    $out['netProfitUsd'] = $out['grossProfitUsd'] - $out['opExpensesUsd'] - $out['wasteLossUsd'];
    $out['cashMovementUsd'] = ($out['cashSalesUsd'] + $out['debtPaymentsInUsd'] + $out['purchaseReturnsInUsd'])
        - ($out['opExpensesUsd'] + $out['cashPurchasesUsd'] + $out['companyDebtPaymentsUsd'] + $out['cashRefundsUsd']);
    // Opening is IQD-stored without a USD stamp — drawer USD = locked movement only (matches JS period drawer).
    $out['cashDrawerUsd'] = round((float)$out['cashMovementUsd'], 2);

    // Round IQD via roundMoney when available
    foreach ([
        'totalSales','cashSales','debtSales','fibSales','totalReturns','totalReturnsCost','cashRefunds','totalCogs',
        'opExpenses','cashPurchases','fibPurchases','totalPurchases','debtPurchases','companyDebtPayments','companyDebtPaymentsFib','debtPaymentsIn',
        'debtPaymentsInFib','purchaseReturnsIn','totalPurchaseReturns','wasteLoss','totalGiftsValue','grossProfit','netProfit','cashMovement',
        'opening','cashDrawer','customerDebtOutstanding','supplierDebtOutstanding'
    ] as $k) {
        $out[$k] = $rm($out[$k]);
    }
    foreach ([
        'totalSalesUsd','cashSalesUsd','debtSalesUsd','fibSalesUsd','totalReturnsUsd','totalReturnsCostUsd','cashRefundsUsd',
        'totalCogsUsd','opExpensesUsd','cashPurchasesUsd','fibPurchasesUsd','totalPurchasesUsd','debtPurchasesUsd',
        'companyDebtPaymentsUsd','companyDebtPaymentsFibUsd','debtPaymentsInUsd','debtPaymentsInFibUsd','purchaseReturnsInUsd','totalPurchaseReturnsUsd','wasteLossUsd',
        'totalGiftsValueUsd','grossProfitUsd','netProfitUsd','cashMovementUsd','cashDrawerUsd',
        'customerDebtOutstandingUsd','supplierDebtOutstandingUsd'
    ] as $k) {
        $out[$k] = round((float)$out[$k], 2);
    }
    return $out;
}

/**
 * Merge core engine fields into get_daily_detail card_stats (IQD + locked USD).
 */
function pos_financial_metrics_to_daily_card_stats(array $m, array $cardStats = []) {
    $rm = function_exists('roundMoney') ? 'roundMoney' : static function ($v) { return round((float)$v, 2); };
    $coreSales = (float)($m['totalSales'] ?? 0);
    $poolSales = (float)($cardStats['sales_total'] ?? 0);
    // Cashier-scope mismatch can yield an empty core while pools still have invoices — keep pool cards.
    if ($coreSales <= 0.0001 && $poolSales > 0.0001) {
        $cardStats['metrics_engine'] = 'pos_daily_detail_card_stats';
        return $cardStats;
    }
    $cardStats['sales_total'] = $rm($m['totalSales'] ?? ($cardStats['sales_total'] ?? 0));
    $cardStats['cash_sales'] = $rm($m['cashSales'] ?? ($cardStats['cash_sales'] ?? 0));
    $cardStats['debt_sales'] = $rm($m['debtSales'] ?? ($cardStats['debt_sales'] ?? 0));
    $cardStats['fib_sales'] = $rm($m['fibSales'] ?? ($cardStats['fib_sales'] ?? 0));
    $cardStats['sale_count'] = (int)($m['saleCount'] ?? ($cardStats['sale_count'] ?? 0));
    $cardStats['total_cogs'] = $rm($m['totalCogs'] ?? ($cardStats['total_cogs'] ?? 0));
    $cardStats['returns_cogs'] = $rm($m['totalReturnsCost'] ?? ($cardStats['returns_cogs'] ?? 0));
    $cardStats['returns_total'] = $rm($m['totalReturns'] ?? ($cardStats['returns_total'] ?? 0));
    $cardStats['cash_refunds'] = $rm($m['cashRefunds'] ?? ($cardStats['cash_refunds'] ?? 0));
    $cardStats['op_expenses'] = $rm($m['opExpenses'] ?? ($cardStats['op_expenses'] ?? 0));
    $cardStats['waste_loss'] = $rm($m['wasteLoss'] ?? ($cardStats['waste_loss'] ?? 0));
    $cardStats['debt_payments_in'] = $rm($m['debtPaymentsIn'] ?? ($cardStats['debt_payments_in'] ?? 0));
    $cardStats['debt_payments_in_fib'] = $rm($m['debtPaymentsInFib'] ?? ($cardStats['debt_payments_in_fib'] ?? 0));
    $cardStats['company_debt_payments'] = $rm($m['companyDebtPayments'] ?? ($cardStats['company_debt_payments'] ?? 0));
    $cardStats['purchases_cash'] = $rm($m['cashPurchases'] ?? ($cardStats['purchases_cash'] ?? 0));
    $cardStats['purchases_fib'] = $rm($m['fibPurchases'] ?? ($cardStats['purchases_fib'] ?? 0));
    $cardStats['purchases_total'] = $rm($m['totalPurchases'] ?? ($cardStats['purchases_total'] ?? 0));
    $cardStats['purchases_debt'] = $rm($m['debtPurchases'] ?? max(0, ($cardStats['purchases_total'] ?? 0) - ($cardStats['purchases_cash'] ?? 0) - ($cardStats['purchases_fib'] ?? 0)));
    $cardStats['net_profit'] = $rm($m['netProfit'] ?? ($cardStats['net_profit'] ?? 0));
    $cardStats['cash_movement'] = $rm($m['cashMovement'] ?? ($cardStats['cash_movement'] ?? 0));
    $cardStats['cash_drawer'] = $rm($m['cashDrawer'] ?? ($cardStats['cash_drawer'] ?? 0));
    $cardStats['opening'] = $rm($m['opening'] ?? ($cardStats['opening'] ?? 0));
    $cardStats['sales_usd'] = round((float)($m['totalSalesUsd'] ?? 0), 2);
    $cardStats['cash_sales_usd'] = round((float)($m['cashSalesUsd'] ?? 0), 2);
    $cardStats['debt_sales_usd'] = round((float)($m['debtSalesUsd'] ?? 0), 2);
    $cardStats['fib_sales_usd'] = round((float)($m['fibSalesUsd'] ?? 0), 2);
    $cardStats['expenses_usd'] = round((float)($m['opExpensesUsd'] ?? 0), 2);
    $cardStats['returns_usd'] = round((float)($m['totalReturnsUsd'] ?? 0), 2);
    $cardStats['total_cogs_usd'] = round((float)($m['totalCogsUsd'] ?? 0), 2);
    $cardStats['net_profit_usd'] = round((float)($m['netProfitUsd'] ?? 0), 2);
    $cardStats['cash_movement_usd'] = round((float)($m['cashMovementUsd'] ?? 0), 2);
    $cardStats['cash_drawer_usd'] = round((float)($m['cashDrawerUsd'] ?? 0), 2);
    $cardStats['purchases_total_usd'] = round((float)($m['totalPurchasesUsd'] ?? 0), 2);
    $cardStats['purchases_cash_usd'] = round((float)($m['cashPurchasesUsd'] ?? 0), 2);
    $cardStats['purchases_fib_usd'] = round((float)($m['fibPurchasesUsd'] ?? 0), 2);
    $cardStats['company_debt_payments_usd'] = round((float)($m['companyDebtPaymentsUsd'] ?? 0), 2);
    $cardStats['debt_payments_in_usd'] = round((float)($m['debtPaymentsInUsd'] ?? 0), 2);
    $cardStats['debt_payments_in_fib_usd'] = round((float)($m['debtPaymentsInFibUsd'] ?? 0), 2);
    $cardStats['customer_debt_outstanding'] = $rm($m['customerDebtOutstanding'] ?? 0);
    $cardStats['customer_debt_outstanding_usd'] = round((float)($m['customerDebtOutstandingUsd'] ?? 0), 2);
    $cardStats['supplier_debt_outstanding'] = $rm($m['supplierDebtOutstanding'] ?? 0);
    $cardStats['supplier_debt_outstanding_usd'] = round((float)($m['supplierDebtOutstandingUsd'] ?? 0), 2);
    $cardStats['metrics_engine'] = 'pos_get_financial_metrics_core';
    return $cardStats;
}

/**
 * Map core metrics → today_stats / dashboard keys.
 */
function pos_financial_metrics_to_today_stats(array $m, array $stats = []) {
    $rm = function_exists('roundMoney') ? 'roundMoney' : static function ($v) { return round((float)$v, 2); };
    $stats['sales'] = $rm($m['totalSales'] ?? ($stats['sales'] ?? 0));
    $stats['cash_sales'] = $rm($m['cashSales'] ?? 0);
    $stats['debt_sales'] = $rm($m['debtSales'] ?? 0);
    $stats['fib_sales'] = $rm($m['fibSales'] ?? 0);
    $stats['returns'] = $rm($m['totalReturns'] ?? 0);
    $stats['cash_refunds'] = $rm($m['cashRefunds'] ?? 0);
    $stats['debt_payments_in'] = $rm($m['debtPaymentsIn'] ?? 0);
    $stats['debt_payments_in_fib'] = $rm($m['debtPaymentsInFib'] ?? 0);
    $stats['count'] = (int)($m['saleCount'] ?? ($stats['count'] ?? 0));
    $stats['sale_count'] = (int)($m['saleCount'] ?? ($stats['sale_count'] ?? 0));
    $stats['total_cogs'] = $rm($m['totalCogs'] ?? 0);
    $stats['expenses'] = $rm($m['opExpenses'] ?? ($stats['expenses'] ?? 0));
    $stats['purchases_cash'] = $rm($m['cashPurchases'] ?? 0);
    $stats['purchases_total'] = $rm($m['totalPurchases'] ?? 0);
    $stats['net_profit'] = $rm($m['netProfit'] ?? 0);
    $stats['cash_movement'] = $rm($m['cashMovement'] ?? 0);
    $stats['opening'] = $rm($m['opening'] ?? 0);
    $stats['cash_drawer'] = $rm($m['cashDrawer'] ?? 0);
    $stats['last_receipt_id'] = $m['last_receipt_id'] ?? null;
    $stats['sales_usd'] = round((float)($m['totalSalesUsd'] ?? 0), 2);
    $stats['cash_sales_usd'] = round((float)($m['cashSalesUsd'] ?? 0), 2);
    $stats['debt_sales_usd'] = round((float)($m['debtSalesUsd'] ?? 0), 2);
    $stats['expenses_usd'] = round((float)($m['opExpensesUsd'] ?? 0), 2);
    $stats['returns_usd'] = round((float)($m['totalReturnsUsd'] ?? 0), 2);
    $stats['total_cogs_usd'] = round((float)($m['totalCogsUsd'] ?? 0), 2);
    $stats['net_profit_usd'] = round((float)($m['netProfitUsd'] ?? 0), 2);
    $stats['cash_movement_usd'] = round((float)($m['cashMovementUsd'] ?? 0), 2);
    $stats['cash_drawer_usd'] = round((float)($m['cashDrawerUsd'] ?? 0), 2);
    $stats['purchases_total_usd'] = round((float)($m['totalPurchasesUsd'] ?? 0), 2);
    $stats['purchases_cash_usd'] = round((float)($m['cashPurchasesUsd'] ?? 0), 2);
    $stats['fib_sales_usd'] = round((float)($m['fibSalesUsd'] ?? 0), 2);
    $stats['company_debt_payments'] = $rm($m['companyDebtPayments'] ?? 0);
    $stats['company_debt_payments_usd'] = round((float)($m['companyDebtPaymentsUsd'] ?? 0), 2);
    $stats['company_debt_payments_fib'] = $rm($m['companyDebtPaymentsFib'] ?? 0);
    $stats['company_debt_payments_fib_usd'] = round((float)($m['companyDebtPaymentsFibUsd'] ?? 0), 2);
    $stats['customer_debt_outstanding'] = $rm($m['customerDebtOutstanding'] ?? 0);
    $stats['customer_debt_outstanding_usd'] = round((float)($m['customerDebtOutstandingUsd'] ?? 0), 2);
    $stats['supplier_debt_outstanding'] = $rm($m['supplierDebtOutstanding'] ?? 0);
    $stats['supplier_debt_outstanding_usd'] = round((float)($m['supplierDebtOutstandingUsd'] ?? 0), 2);
    $stats['metrics_engine'] = 'pos_get_financial_metrics_core';
    return $stats;
}

/**
 * Add cash/debt/profit/drawer fields to today_stats via the unified financial engine.
 */
function pos_enrich_today_stats_finance(mysqli $conn, array $stats, $rangeStart, $rangeEndExclusive) {
    $mode = (function_exists('pos_is_usd_currency_system') && pos_is_usd_currency_system($conn)) ? 'USD' : 'IQD';
    $core = pos_get_financial_metrics_core($conn, $rangeStart, $rangeEndExclusive, $mode, [
        'see_shop_wide' => true,
    ]);
    return pos_financial_metrics_to_today_stats($core, $stats);
}
