@echo off
call "%~dp0POS_Start\AutoStart_POS_LabelPrint.bat"
