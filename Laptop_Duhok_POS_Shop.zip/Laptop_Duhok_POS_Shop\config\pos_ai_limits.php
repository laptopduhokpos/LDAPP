<?php
/**
 * Shop AI — monthly point quotas + purchasable limit packs (Supabase codes).
 * Basic: 150 points / 30 days · Pro: 300 points / 30 days.
 * Bonus packs redeemed via admin-generated codes (any tier).
 */
if (!defined('POS_AI_PERIOD_DAYS')) {
    define('POS_AI_PERIOD_DAYS', 30);
}
if (!defined('POS_AI_PERIOD_LIMIT_FREE')) {
    define('POS_AI_PERIOD_LIMIT_FREE', 150);
}
if (!defined('POS_AI_PERIOD_LIMIT_PRO')) {
    define('POS_AI_PERIOD_LIMIT_PRO', 300);
}
if (!defined('POS_AI_DAILY_LIMIT_FREE')) {
    define('POS_AI_DAILY_LIMIT_FREE', POS_AI_PERIOD_LIMIT_FREE);
}
if (!defined('POS_AI_DAILY_LIMIT_PRO')) {
    define('POS_AI_DAILY_LIMIT_PRO', POS_AI_PERIOD_LIMIT_PRO);
}
if (!defined('POS_AI_COST_SHORT_MIN')) {
    define('POS_AI_COST_SHORT_MIN', 8);
}
if (!defined('POS_AI_COST_SHORT_MAX')) {
    define('POS_AI_COST_SHORT_MAX', 15);
}
if (!defined('POS_AI_COST_MEDIUM_MIN')) {
    define('POS_AI_COST_MEDIUM_MIN', 16);
}
if (!defined('POS_AI_COST_MEDIUM_MAX')) {
    define('POS_AI_COST_MEDIUM_MAX', 25);
}
if (!defined('POS_AI_COST_LONG_MIN')) {
    define('POS_AI_COST_LONG_MIN', 26);
}
if (!defined('POS_AI_COST_LONG_MAX')) {
    define('POS_AI_COST_LONG_MAX', 38);
}
if (!defined('POS_AI_TIER_SHORT_MAX_CHARS')) {
    define('POS_AI_TIER_SHORT_MAX_CHARS', 500);
}
if (!defined('POS_AI_TIER_MEDIUM_MAX_CHARS')) {
    define('POS_AI_TIER_MEDIUM_MAX_CHARS', 1500);
}

if (!function_exists('pos_ai_pack_catalog')) {
    /** @return array<int,array<string,mixed>> */
    function pos_ai_pack_catalog(): array {
        static $cache = null;
        if (is_array($cache)) {
            return $cache;
        }
        $raw = defined('POS_AI_PACK_CATALOG_JSON') ? POS_AI_PACK_CATALOG_JSON : '[]';
        $decoded = json_decode($raw, true);
        $cache = is_array($decoded) ? $decoded : [];
        return $cache;
    }
}

if (!function_exists('pos_ai_period_anchor_ts')) {
    function pos_ai_period_anchor_ts(): int {
        return strtotime('2020-01-01 00:00:00');
    }
}

if (!function_exists('pos_ai_current_period_start')) {
    function pos_ai_current_period_start(?string $todayYmd = null): string {
        $todayYmd = $todayYmd ?: date('Y-m-d');
        $todayTs = strtotime($todayYmd . ' 00:00:00');
        $anchor = pos_ai_period_anchor_ts();
        $daysSince = (int) floor(max(0, $todayTs - $anchor) / 86400);
        $periodDays = max(1, (int) POS_AI_PERIOD_DAYS);
        $periodIndex = (int) floor($daysSince / $periodDays);
        return date('Y-m-d', $anchor + ($periodIndex * $periodDays * 86400));
    }
}

if (!function_exists('pos_ai_next_period_start')) {
    function pos_ai_next_period_start(?string $periodStartYmd = null): string {
        $start = $periodStartYmd ?: pos_ai_current_period_start();
        $periodDays = max(1, (int) POS_AI_PERIOD_DAYS);
        return date('Y-m-d', strtotime($start . ' +' . $periodDays . ' days'));
    }
}

if (!function_exists('pos_ai_apply_period_config')) {
    /**
     * Align quota payload with app period config (e.g. 30-day window).
     * Fixes stale Supabase rows still returning ai_period_days = 7.
     *
     * @param array<string,mixed> $q
     * @return array<string,mixed>
     */
    function pos_ai_apply_period_config(array $q): array {
        $cfgDays = max(1, (int) POS_AI_PERIOD_DAYS);
        $remoteDays = max(0, (int)($q['period_days'] ?? 0));
        if ($remoteDays === $cfgDays) {
            if (!isset($q['period_label']) || (string)$q['period_label'] === 'week') {
                $q['period_label'] = $cfgDays >= 28 ? 'month' : 'period';
            }
            return $q;
        }
        $q['period_days'] = $cfgDays;
        $q['period_label'] = $cfgDays >= 28 ? 'month' : 'period';
        $start = pos_ai_current_period_start();
        $q['period_start'] = $start;
        $q['resets_on'] = pos_ai_next_period_start($start);
        return $q;
    }
}

if (!function_exists('pos_ai_period_limit_for_tier')) {
    function pos_ai_period_limit_for_tier(string $tier): int {
        if (function_exists('pos_subscription_tier_normalize')) {
            $tier = pos_subscription_tier_normalize($tier);
        } else {
            $t = strtolower(trim($tier));
            $tier = ($t === 'pro' || $t === 'pro_plus') ? $t : 'free';
        }
        if ($tier === 'pro' || $tier === 'pro_plus') {
            return (int) POS_AI_PERIOD_LIMIT_PRO;
        }
        return (int) POS_AI_PERIOD_LIMIT_FREE;
    }
}

if (!function_exists('pos_ai_daily_limit_for_tier')) {
    function pos_ai_daily_limit_for_tier(string $tier): int {
        return pos_ai_period_limit_for_tier($tier);
    }
}

if (!function_exists('pos_ai_min_turn_cost')) {
    function pos_ai_min_turn_cost(): int {
        return (int) POS_AI_COST_SHORT_MIN;
    }
}

if (!function_exists('pos_ai_max_turn_cost')) {
    function pos_ai_max_turn_cost(): int {
        return (int) POS_AI_COST_LONG_MAX;
    }
}

if (!function_exists('pos_ai_compute_turn_cost')) {
    function pos_ai_compute_turn_cost(string $question, string $answer): array {
        $qLen = mb_strlen(trim($question));
        $aLen = mb_strlen(trim($answer));
        $total = $qLen + $aLen;

        if ($total <= (int) POS_AI_TIER_SHORT_MAX_CHARS) {
            $tier = 'short';
            $min = (int) POS_AI_COST_SHORT_MIN;
            $max = (int) POS_AI_COST_SHORT_MAX;
            $span = max(1, (int) POS_AI_TIER_SHORT_MAX_CHARS);
            $pos = max(0, $total);
        } elseif ($total <= (int) POS_AI_TIER_MEDIUM_MAX_CHARS) {
            $tier = 'medium';
            $min = (int) POS_AI_COST_MEDIUM_MIN;
            $max = (int) POS_AI_COST_MEDIUM_MAX;
            $span = max(1, (int) POS_AI_TIER_MEDIUM_MAX_CHARS - (int) POS_AI_TIER_SHORT_MAX_CHARS);
            $pos = max(0, $total - (int) POS_AI_TIER_SHORT_MAX_CHARS);
        } else {
            $tier = 'long';
            $min = (int) POS_AI_COST_LONG_MIN;
            $max = (int) POS_AI_COST_LONG_MAX;
            $span = 2000;
            $pos = min($span, max(0, $total - (int) POS_AI_TIER_MEDIUM_MAX_CHARS));
        }

        $ratio = min(1.0, $pos / $span);
        $cost = (int) round($min + $ratio * ($max - $min));
        $cost = max($min, min($max, $cost));

        return [
            'cost' => $cost,
            'tier' => $tier,
            'chars' => $total,
            'q_len' => $qLen,
            'a_len' => $aLen,
        ];
    }
}

if (!function_exists('pos_ai_tier_from_conn')) {
    function pos_ai_tier_from_conn(mysqli $conn): string {
        if (!function_exists('pos_ai_load_settings_row')) {
            return 'free';
        }
        $settings = pos_ai_load_settings_row($conn);
        if (function_exists('pos_subscription_tier_from_settings')) {
            return pos_subscription_tier_from_settings($settings);
        }
        if (function_exists('pos_subscription_tier_normalize')) {
            return pos_subscription_tier_normalize($settings['subscription_tier'] ?? 'free');
        }
        return 'free';
    }
}

if (!function_exists('pos_ai_load_period_usage')) {
    /** @return array{period_start:string,count:int,bonus_limit:int} */
    function pos_ai_load_period_usage(mysqli $conn): array {
        $periodStart = pos_ai_current_period_start();
        $settings = function_exists('pos_ai_load_settings_row') ? pos_ai_load_settings_row($conn) : [];
        $raw = $settings['ai_period_usage'] ?? $settings['ai_daily_usage'] ?? null;
        if (!is_array($raw) || (string)($raw['period_start'] ?? $raw['day'] ?? '') !== $periodStart) {
            return ['period_start' => $periodStart, 'count' => 0, 'bonus_limit' => 0];
        }
        return [
            'period_start' => $periodStart,
            'count' => max(0, (int)($raw['count'] ?? 0)),
            'bonus_limit' => max(0, (int)($raw['bonus_limit'] ?? 0)),
        ];
    }
}

if (!function_exists('pos_ai_save_period_usage')) {
    function pos_ai_save_period_usage(mysqli $conn, array $usage): void {
        if (!function_exists('pos_ai_load_settings_row')) {
            return;
        }
        $settings = pos_ai_load_settings_row($conn);
        $settings['ai_period_usage'] = [
            'period_start' => (string)($usage['period_start'] ?? pos_ai_current_period_start()),
            'count' => max(0, (int)($usage['count'] ?? 0)),
            'bonus_limit' => max(0, (int)($usage['bonus_limit'] ?? 0)),
        ];
        unset($settings['ai_daily_usage']);
        $json = json_encode($settings, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
        if ($json === false) {
            return;
        }
        $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('app_settings', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        if ($stmt) {
            $stmt->bind_param('ss', $json, $json);
            $stmt->execute();
            $stmt->close();
        }
    }
}

if (!function_exists('pos_ai_usage_snapshot')) {
    function pos_ai_usage_snapshot(mysqli $conn): array {
        $tier = pos_ai_tier_from_conn($conn);
        if (function_exists('pos_ai_supabase_quota_snapshot')) {
            $remote = pos_ai_supabase_quota_snapshot($conn);
            if (is_array($remote)) {
                return $remote;
            }
        }

        $baseLimit = pos_ai_period_limit_for_tier($tier);
        $usage = pos_ai_load_period_usage($conn);
        $bonus = (int)($usage['bonus_limit'] ?? 0);
        $limit = $baseLimit + $bonus;
        $used = $usage['count'];
        $remaining = max(0, $limit - $used);
        $pct = $limit > 0 ? min(100.0, round(($used / $limit) * 100, 1)) : 100.0;
        $periodStart = (string)$usage['period_start'];
        $periodDays = max(1, (int) POS_AI_PERIOD_DAYS);
        return [
            'tier' => $tier,
            'base_limit' => $baseLimit,
            'bonus_limit' => $bonus,
            'limit' => $limit,
            'used' => $used,
            'remaining' => $remaining,
            'exhausted' => $used >= $limit,
            'pct' => $pct,
            'resets_on' => pos_ai_next_period_start($periodStart),
            'period_start' => $periodStart,
            'period_days' => $periodDays,
            'min_cost' => pos_ai_min_turn_cost(),
            'max_cost' => pos_ai_max_turn_cost(),
            'source' => 'local',
            'vendor_gemini' => true,
        ];
    }
}

if (!function_exists('pos_ai_limit_exceeded_message')) {
    function pos_ai_limit_exceeded_message(array $snap): string {
        $tier = (string)($snap['tier'] ?? 'free');
        $limit = (int)($snap['limit'] ?? POS_AI_PERIOD_LIMIT_FREE);
        $days = (int)($snap['period_days'] ?? POS_AI_PERIOD_DAYS);
        $resets = (string)($snap['resets_on'] ?? '');
        $resetLine = $resets !== '' ? ' نوێدەبێتەوە لە ' . $resets . ' (هەر ' . $days . ' ڕۆژان).' : ' هەر ' . $days . ' ڕۆژان نوێدەبێتەوە.';
        if ($tier === 'pro' || $tier === 'pro_plus') {
            return 'سنوورا ' . $days . ' ڕۆژانە تەواو بوو (' . $limit . ' خاڵ).' . $resetLine . ' کۆدی زیادکرن بنووسە یان پەیوەندی ب پشتیوانی.';
        }
        return 'سنوورا ' . $days . ' ڕۆژانە تەواو بوو (' . $limit . ' خاڵ). کۆدی زیادکرن بنووسە یان Pro بکرە (' . (int) POS_AI_PERIOD_LIMIT_PRO . ' خاڵ/' . $days . ' ڕۆژ).' . $resetLine;
    }
}

if (!function_exists('pos_ai_consume_quota')) {
    function pos_ai_consume_quota(mysqli $conn, int $cost): array {
        $requested = max(pos_ai_min_turn_cost(), min(pos_ai_max_turn_cost(), $cost));
        if (function_exists('pos_ai_supabase_consume')) {
            $remote = pos_ai_supabase_consume($conn, $requested);
            if (!empty($remote['ok'])) {
                return $remote;
            }
        }

        $snap = pos_ai_usage_snapshot($conn);
        if ($snap['remaining'] <= 0) {
            return ['ok' => false, 'snapshot' => $snap, 'cost' => 0, 'requested_cost' => $requested];
        }
        $deduct = min($requested, (int)$snap['remaining']);
        $usage = pos_ai_load_period_usage($conn);
        $usage['count'] = (int)$usage['count'] + $deduct;
        pos_ai_save_period_usage($conn, $usage);
        return [
            'ok' => true,
            'snapshot' => pos_ai_usage_snapshot($conn),
            'cost' => $deduct,
            'requested_cost' => $requested,
        ];
    }
}

if (!function_exists('pos_ai_check_quota_available')) {
    function pos_ai_check_quota_available(mysqli $conn, ?int $minNeeded = null): array {
        $minNeeded = $minNeeded ?? pos_ai_min_turn_cost();
        $snap = pos_ai_usage_snapshot($conn);
        if (!empty($snap['exhausted']) || (int)$snap['remaining'] < $minNeeded) {
            return [
                'ok' => false,
                'snapshot' => $snap,
                'message' => pos_ai_limit_exceeded_message($snap),
            ];
        }
        return ['ok' => true, 'snapshot' => $snap];
    }
}

if (!defined('POS_AI_PACK_CATALOG_JSON')) {
    define('POS_AI_PACK_CATALOG_JSON', json_encode([
        ['pack_key' => 'ai100', 'pack_points' => 100, 'gift_points' => 70, 'bonus_points' => 170, 'price_usd' => 4, 'label_ku' => '+١٠٠ خاڵ', 'label_ar' => '+١٠٠ نقطة'],
        ['pack_key' => 'ai200', 'pack_points' => 200, 'gift_points' => 150, 'bonus_points' => 350, 'price_usd' => 8, 'label_ku' => '+٢٠٠ خاڵ', 'label_ar' => '+٢٠٠ نقطة'],
        ['pack_key' => 'ai400', 'pack_points' => 400, 'gift_points' => 250, 'bonus_points' => 650, 'price_usd' => 12, 'label_ku' => '+٤٠٠ خاڵ', 'label_ar' => '+٤٠٠ نقطة'],
    ], JSON_UNESCAPED_UNICODE));
}
