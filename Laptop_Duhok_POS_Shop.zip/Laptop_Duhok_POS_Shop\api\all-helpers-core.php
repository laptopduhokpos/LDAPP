<?php
// Session, i18n, stock-batch helpers
function getRequestedLanguage() {
    $raw = '';
    if (isset($_REQUEST['language'])) $raw = strtolower(trim((string)$_REQUEST['language']));
    if ($raw === '' && isset($_SERVER['HTTP_X_POS_LANGUAGE'])) $raw = strtolower(trim((string)$_SERVER['HTTP_X_POS_LANGUAGE']));
    return ($raw === 'ar') ? 'ar' : 'badini';
}

function translateKnownPhrase($text, $lang) {
    if (!is_string($text) || $text === '') return $text;
    static $pairs = [
        ['پین کۆد خەلەتە', 'رمز الدخول غير صحيح'],
        ['بەروار نەهاتیە دیارکرن', 'حقل التاريخ مطلوب'],
        ['چ شیفتێن ڤەکری نینن', 'لا توجد وردية مفتوحة'],
        ['ID یا کارمەندی پێدڤیە', 'معرف المستخدم مطلوب'],
        ['مێز نەهاتە دیتن', 'الطاولة غير موجودة'],
        ['ID یا لڤینێ پێدڤیە', 'رقم العملية مفقود'],
        ['داتایێن ئایتمان د دروست نینن', 'تنسيق العناصر غير صالح'],
        ['چ فایل نەهاتینە بارکرن', 'لم يتم رفع ملف'],
        ['نەشێت فایلی بخوێنیت', 'تعذر قراءة الملف'],
        ['فایل یێ ڤالایە', 'الملف فارغ'],
        ['داتا نەدروستە', 'بيانات غير صالحة'],
        ['نەشێی ژێببەی چونکە لڤینێن دارایی (کڕین) هەنە.', 'لا يمكن الحذف لوجود حركات مالية مرتبطة (مشتريات).'],
        ['نەشێی ژێببەی چونکە تەلەف هەنە.', 'لا يمكن الحذف لوجود حركات تلف مرتبطة.'],
        ['نەشێی ژێببەی چونکە مێژوویا لڤینان هەیە.', 'لا يمكن الحذف لوجود سجل حركات.'],
        ['نەشێی ژێببەی چونکە لڤینێن دارایی هەنە.', 'لا يمكن الحذف لوجود حركات مرتبطة.'],
        ['نەشێی ژێببەی چونکە لڤینێن دەفتەری هەنە.', 'لا يمكن الحذف لوجود قيود دفتر.'],
        ['نەشێی ژێببەی چونکە شیفت هەنە.', 'لا يمكن الحذف لوجود جلسات.'],
        ['نەشێی ژێببەی چونکە قەرز هەنە.', 'لا يمكن الحذف لوجود قيود دين.'],
        ['نەشێی ڕێڤەبەری ژ کار بێخی', 'لا يمكن تعطيل المدير'],
        ['وەسڵا سەرەکی نەهاتە دیتن.', 'الفاتورة الأصلية غير موجودة.'],
        ['وەسڵا سەرەکی یا ژێبریە و نەشێی زڤڕاندنێ ل سەر تۆمار بکەی.', 'الفاتورة الأصلية ملغاة ولا يمكن تسجيل مرتجع عليها.'],
        ['بڕێ زڤڕاندنێ نەشێت ژ بڕێ وەسڵا سەرەکی ($origTotal) مەزنتر بیت.', 'مبلغ المرتجع لا يمكن أن يتجاوز مبلغ الفاتورة الأصلية ($origTotal).'],
        ['ژمارا ئایتمێ زڤڕاندنی ژ ژمارا وەسڵا سەرەکی پترە.', 'كمية المرتجع للصنف تتجاوز الكمية في الفاتورة الأصلية.']
    ];
    foreach ($pairs as $p) {
        $b = $p[0];
        $a = $p[1];
        if ($lang === 'ar' && $text === $b) return $a;
        if ($lang !== 'ar' && $text === $a) return $b;
    }
    // Remove mixed suffixes "X (Y)" for strict one-language output.
    if ($lang === 'ar') {
        $text = preg_replace('/\s+\([^)A-Za-z]{0,10}[A-Za-z][^)]{0,60}\)\s*/u', ' ', $text);
    } else {
        $text = preg_replace('/\s+\([^)]*\p{Arabic}+[^)]*\)\s*/u', ' ', $text);
    }
    return trim(preg_replace('/\s{2,}/', ' ', $text));
}

function localizeJsonPayload($payload, $lang) {
    if (is_array($payload)) {
        foreach ($payload as $k => $v) {
            if (is_string($v) && in_array((string)$k, ['message', 'error', 'warning', 'label', 'title', 'hint', 'note'], true)) {
                $payload[$k] = translateKnownPhrase($v, $lang);
            } else {
                $payload[$k] = localizeJsonPayload($v, $lang);
            }
        }
        return $payload;
    }
    return $payload;
}

function posJsonOutputFilter($buffer) {
    $raw = (string)$buffer;
    $trimmed = ltrim($raw, "\x00..\x20\xEF\xBB\xBF");
    // Drop BOM / PHP notices before the JSON payload so display_errors cannot break clients.
    // Prefer real API payloads ({"status":...} or [{...}]) — avoid slicing on random "[" in warnings.
    if ($trimmed !== '' && ($trimmed[0] ?? '') !== '{' && ($trimmed[0] ?? '') !== '[') {
        if (preg_match('/\{\s*"status"\s*:/', $trimmed, $m, PREG_OFFSET_CAPTURE)) {
            $trimmed = substr($trimmed, (int)$m[0][1]);
        } elseif (preg_match('/\[\s*\{/', $trimmed, $m, PREG_OFFSET_CAPTURE)) {
            $trimmed = substr($trimmed, (int)$m[0][1]);
        } else {
            return $raw;
        }
    }
    if ($trimmed === '' || (($trimmed[0] ?? '') !== '{' && ($trimmed[0] ?? '') !== '[')) {
        return $raw;
    }
    
    // Skip translation for large payloads (> 100KB) to drastically improve performance
    if (strlen($trimmed) > 102400) return $trimmed;
    
    $decoded = json_decode($trimmed, true);
    if (json_last_error() !== JSON_ERROR_NONE || !is_array($decoded)) return $trimmed;
    $lang = getRequestedLanguage();
    $localized = localizeJsonPayload($decoded, $lang);
    return json_encode($localized, JSON_UNESCAPED_UNICODE);
}

if (!function_exists('checkAndAddCol')) {
    function checkAndAddCol($conn, $table, $column, $definition) {
        // Runtime schema changes are disabled for concurrency safety.
        // Migrations are handled centrally in config/migrations.php.
        return;
    }
}

/**
 * Legacy DBs may still have DECIMAL(10,2) on debt fields; USD→IQD storage can exceed that (e.g. high limits × FX).
 * Idempotent ALTERs; runs once per request (static). Migrations should widen too; this covers stuck schema_version.
 */
/** Normalize payment-term unit from form/API (minute|hour|day|month|year). */
function pos_normalize_payment_term_unit($unit) {
    $u = strtolower(trim((string)$unit));
    if (in_array($u, ['minute', 'minutes', 'min'], true)) return 'minute';
    if (in_array($u, ['hour', 'hours', 'h'], true)) return 'hour';
    if (in_array($u, ['month', 'months'], true)) return 'month';
    if (in_array($u, ['year', 'years', 'y'], true)) return 'year';
    return 'day';
}

/** Compute payment due datetime from term value+unit; 0 value => null (no deadline). */
function pos_compute_payment_due_at($value, $unit, $fromDate = null) {
    $v = max(0, (int)$value);
    if ($v <= 0) {
        return null;
    }
    $u = pos_normalize_payment_term_unit($unit);
    try {
        $dt = ($fromDate !== null && $fromDate !== '') ? new DateTime((string)$fromDate) : new DateTime('now');
    } catch (Throwable $e) {
        $dt = new DateTime('now');
    }
    switch ($u) {
        case 'minute':
            $dt->modify('+' . $v . ' minutes');
            break;
        case 'hour':
            $dt->modify('+' . $v . ' hours');
            break;
        case 'month':
            $dt->modify('+' . $v . ' months');
            break;
        case 'year':
            $dt->modify('+' . $v . ' years');
            break;
        default:
            $dt->modify('+' . $v . ' days');
            break;
    }
    return $dt->format('Y-m-d H:i:s');
}

/** Resolve payment term from POST, optionally falling back to customer/company profile. */
function pos_resolve_payment_term_from_post($conn, $entityType, $entityId) {
    $value = max(0, (int)($_POST['payment_term_value'] ?? 0));
    $unit = pos_normalize_payment_term_unit($_POST['payment_term_unit'] ?? 'day');
    if ($value <= 0 && $entityId > 0) {
        $table = ($entityType === 'company') ? 'companies' : 'customers';
        $stmt = $conn->prepare("SELECT payment_term_value, payment_term_unit FROM {$table} WHERE id = ? LIMIT 1");
        if ($stmt) {
            $stmt->bind_param('i', $entityId);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($res && ($row = $res->fetch_assoc())) {
                $value = max(0, (int)($row['payment_term_value'] ?? 0));
                $unit = pos_normalize_payment_term_unit($row['payment_term_unit'] ?? 'day');
            }
        }
    }
    return [$value, $unit];
}

/** True when entity has at least one overdue payment_due_at on open credit lines. */
function pos_entity_has_overdue_payment_due($conn, $entityType, $entityId, $entityName = '') {
    $entityId = (int)$entityId;
    $now = date('Y-m-d H:i:s');
    if ($entityType === 'customer' && $entityId > 0) {
        $stmt = $conn->prepare(
            "SELECT 1 FROM sales WHERE customer_id = ? AND customer_type IN ('customer','customers') "
            . "AND remaining_debt > 0 AND payment_due_at IS NOT NULL AND payment_due_at < ? LIMIT 1"
        );
        if ($stmt) {
            $stmt->bind_param('is', $entityId, $now);
            $stmt->execute();
            $res = $stmt->get_result();
            return ($res && $res->num_rows > 0);
        }
    }
    if ($entityType === 'company' && $entityId > 0) {
        $stmt = $conn->prepare(
            "SELECT 1 FROM supplies s INNER JOIN companies c ON s.company = c.name "
            . "WHERE c.id = ? AND s.type IN ('credit','split') AND s.payment_due_at IS NOT NULL AND s.payment_due_at < ? LIMIT 1"
        );
        if ($stmt) {
            $stmt->bind_param('is', $entityId, $now);
            $stmt->execute();
            $res = $stmt->get_result();
            return ($res && $res->num_rows > 0);
        }
    }
    return false;
}

/**
 * Overdue check for toast at payment time.
 * We intentionally do NOT require remaining_debt > 0 so that cashier
 * still gets a warning when paying an already-overdue invoice (even if it becomes cleared now).
 */
function pos_entity_has_overdue_payment_due_for_toast($conn, $entityType, $entityId, $entityName = '') {
    $entityId = (int)$entityId;
    $now = date('Y-m-d H:i:s');

    if ($entityType === 'customer' && $entityId > 0) {
        $stmt = $conn->prepare(
            "SELECT 1 FROM sales WHERE customer_id = ? AND customer_type IN ('customer','customers') "
            . "AND payment_due_at IS NOT NULL AND payment_due_at < ? "
            . "AND (debt_amount > 0 OR remaining_debt > 0) LIMIT 1"
        );
        if ($stmt) {
            $stmt->bind_param('is', $entityId, $now);
            $stmt->execute();
            $res = $stmt->get_result();
            return ($res && $res->num_rows > 0);
        }
    }

    if ($entityType === 'company' && $entityId > 0) {
        $stmt = $conn->prepare(
            "SELECT 1 FROM supplies s "
            . "INNER JOIN companies c ON s.company = c.name "
            . "WHERE c.id = ? AND s.type IN ('credit','split') "
            . "AND s.payment_due_at IS NOT NULL AND s.payment_due_at < ? LIMIT 1"
        );
        if ($stmt) {
            $stmt->bind_param('is', $entityId, $now);
            $stmt->execute();
            $res = $stmt->get_result();
            return ($res && $res->num_rows > 0);
        }
    }

    return false;
}

/** Soft warning payload for overdue payment deadline (no «debt» wording). */
function pos_build_payment_due_warning($entityName) {
    $name = trim((string)$entityName);
    if ($name === '') {
        $name = '—';
    }
    return [
        'message' => "وەختێ پارەدانا {$name} هات — مەوعدێ ویە",
        'entity_name' => $name,
    ];
}

function pos_ensure_wide_debt_money_columns($conn) {
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    $mods = [
        'companies' => ['balance', 'debt_limit', 'opening_balance'],
        'customers' => ['balance', 'debt_limit', 'opening_balance'],
        'users' => ['balance'],
    ];
    foreach ($mods as $table => $cols) {
        foreach ($cols as $col) {
            try {
                $conn->query("ALTER TABLE `" . $conn->real_escape_string($table) . "` MODIFY COLUMN `" . $conn->real_escape_string($col) . "` DECIMAL(18,3) DEFAULT 0");
            } catch (Throwable $e) {
            }
        }
    }
}

// Helper: compute piece counts per product from cart items.
// Used during checkout to revert/update stock when table items are involved.
// Must be defined before any handlers that call it (e.g. process_payment).
function cartItemsToPieceCounts($cartItems) {
    global $conn;
    $counts = [];
    if (!is_array($cartItems)) return $counts;

    foreach ($cartItems as $prod) {
        $pid = (int)($prod['id'] ?? 0);
        if (!$pid) continue;

        $pieces = 0.0;
        if (function_exists('pos_sale_item_pieces')) {
            $pieces = (float)pos_sale_item_pieces($prod);
        } else {
            $lineQty = 1.0;
            if (isset($prod['count']) && (float)$prod['count'] > 0) {
                $lineQty = (float)$prod['count'];
            } elseif (isset($prod['qty']) && (float)$prod['qty'] > 0 && (float)$prod['qty'] <= 1000) {
                $lineQty = normalizeQtyForProductData($prod, (float)$prod['qty']);
                if ($lineQty <= 0 && (float)$prod['qty'] > 0) {
                    $lineQty = (float)$prod['qty'];
                }
            }
            if ($lineQty <= 0) $lineQty = 1.0;

            $mult = 1;
            $saleUnit = $prod['saleUnit'] ?? 'piece';
            if ($saleUnit !== 'piece') {
                $ppp = isset($prod['pieces_per_pack']) ? max(1, (int)$prod['pieces_per_pack']) : 1;
                $ppc = isset($prod['packs_per_carton']) ? max(1, (int)$prod['packs_per_carton']) : 1;
                $piecesPerCarton = $ppp * $ppc;
                if ($piecesPerCarton <= 1 && isset($prod['itemsPerCarton']) && (int)$prod['itemsPerCarton'] > 1) {
                    $piecesPerCarton = (int)$prod['itemsPerCarton'];
                }
                if ($saleUnit === 'carton') $mult = $piecesPerCarton;
                elseif ($saleUnit === 'pack') $mult = $ppp;
            }
            $pieces = $mult * $lineQty;
        }
        if ($pieces <= 0) continue;

        // Jewelry set → expand into member pieces (set SKU itself usually has trackStock=0)
        $jewMembers = [];
        if (!empty($prod['jewelry_set_items']) && is_array($prod['jewelry_set_items'])) {
            foreach ($prod['jewelry_set_items'] as $m) {
                if (!is_array($m)) continue;
                $mid = (int)($m['product_id'] ?? ($m['id'] ?? 0));
                if ($mid <= 0) continue;
                $mq = isset($m['qty']) ? max(0.001, (float)$m['qty']) : 1;
                $jewMembers[$mid] = ($jewMembers[$mid] ?? 0) + $mq;
            }
        } elseif ((!empty($prod['is_jewelry_set']) || !empty($prod['jewelry_set_items']))
            && isset($conn) && ($conn instanceof mysqli)
            && function_exists('pos_get_jewelry_set_qty_map')) {
            $jewMembers = pos_get_jewelry_set_qty_map($conn, $pid);
        }
        if (!empty($jewMembers)) {
            foreach ($jewMembers as $mid => $perSet) {
                $mid = (int)$mid;
                if ($mid <= 0 || (float)$perSet <= 0) continue;
                if (!isset($counts[$mid])) $counts[$mid] = 0;
                $counts[$mid] += ((float)$perSet * $pieces);
            }
            continue;
        }

        // Only track stock products
        $track = $prod['trackStock'] ?? null;
        if (!($track === true || $track == 1 || $track === '1')) continue;

        if (!isset($counts[$pid])) $counts[$pid] = 0;
        $counts[$pid] += $pieces;
    }

    return $counts;
}

/**
 * FX snapshot for INSERT: same encoding as app_settings usdRate (getUsdRatePerOne = rate/100).
 * Returns strings for mysqli bind: empty rate string becomes SQL NULL via CAST(NULLIF(?, '') AS UNSIGNED).
 */
/**
 * Locked FX from an original sale row (returns must never use today's rate).
 * Bundle encoding matches app_settings usdRate (IQD per 100 USD).
 */
function pos_fx_snapshot_from_sale_row($row) {
    $out = ['rate' => '', 'mode' => ''];
    if (!is_array($row)) {
        return $out;
    }
    $mode = strtoupper(trim((string)($row['fx_currency_mode'] ?? '')));
    if ($mode !== 'USD' && $mode !== 'IQD') {
        $mode = '';
    }
    $bundle = (int)($row['fx_usd_rate'] ?? 0);
    $er = (float)($row['exchange_rate'] ?? 0);
    if ($bundle < 1000 && $er > 0) {
        $bundle = ($er >= 10000) ? (int)round($er) : (int)round($er * 100);
    }
    if ($bundle >= 1000 && $bundle <= 50000000) {
        $out['rate'] = (string)$bundle;
    }
    $out['mode'] = $mode;
    return $out;
}

function fxSnapshotBindStringsFromPost() {
    if (function_exists('pos_is_iqd_currency_system') && pos_is_iqd_currency_system()) {
        return ['rate' => '', 'mode' => 'IQD'];
    }
    $raw = isset($_POST['fx_usd_rate']) ? (int)$_POST['fx_usd_rate'] : 0;
    if ($raw < 1000 || $raw > 50000000) {
        $raw = 0;
    }
    $mode = isset($_POST['fx_currency_mode']) ? strtoupper(trim((string)$_POST['fx_currency_mode'])) : '';
    if ($mode !== 'USD' && $mode !== 'IQD') {
        $mode = '';
    }
    if ($mode === 'IQD') {
        return ['rate' => '', 'mode' => 'IQD'];
    }
    return [
        'rate' => $raw > 0 ? (string)$raw : '',
        'mode' => $mode,
    ];
}

function fxSnapshotBindStringsFromConnection($conn) {
    $out = ['rate' => '', 'mode' => ''];
    $res = $conn->query("SELECT setting_value FROM settings WHERE setting_key = 'app_settings' LIMIT 1");
    if (!$res || !($row = $res->fetch_assoc())) {
        return $out;
    }
    $dec = json_decode($row['setting_value'] ?? '{}', true);
    if (!is_array($dec)) {
        return $out;
    }
    $raw = isset($dec['usdRate']) ? (int)$dec['usdRate'] : 0;
    if ($raw < 1000 || $raw > 50000000) {
        $raw = 0;
    }
    $mode = isset($dec['currencyMode']) ? strtoupper(trim((string)$dec['currencyMode'])) : '';
    if ($mode !== 'USD' && $mode !== 'IQD') {
        $mode = '';
    }
    if ($mode === 'IQD') {
        $out['mode'] = 'IQD';
        $out['rate'] = '';
        return $out;
    }
    $out['rate'] = $raw > 0 ? (string)$raw : '';
    $out['mode'] = $mode;
    return $out;
}

function returnItemsToPieceCounts($cartItems) {
    $counts = [];
    if (!is_array($cartItems)) return $counts;
    foreach ($cartItems as $prod) {
        $pid = (int)($prod['id'] ?? 0);
        if (!$pid) continue;
        $track = $prod['trackStock'] ?? null;
        if (!($track === true || $track == 1 || $track === '1')) continue;
        $qtyInCart = normalizeQtyForProductData($prod, isset($prod['qty']) ? $prod['qty'] : 1);
        if ($qtyInCart <= 0) continue;
        $mult = 1;
        $saleUnit = $prod['saleUnit'] ?? 'piece';
        if ($saleUnit !== 'piece') {
            $ppp = isset($prod['pieces_per_pack']) ? max(1, (int)$prod['pieces_per_pack']) : 1;
            $ppc = isset($prod['packs_per_carton']) ? max(1, (int)$prod['packs_per_carton']) : 1;
            $piecesPerCarton = $ppp * $ppc;
            if ($piecesPerCarton <= 1 && isset($prod['itemsPerCarton']) && (int)$prod['itemsPerCarton'] > 1) {
                $piecesPerCarton = (int)$prod['itemsPerCarton'];
            }
            if ($saleUnit === 'carton') $mult = $piecesPerCarton;
            elseif ($saleUnit === 'pack') $mult = $ppp;
        }
        if (!isset($counts[$pid])) $counts[$pid] = 0;
        $counts[$pid] += ($qtyInCart * $mult);
    }
    return $counts;
}

function sortedNumericKeys($arr) {
    $keys = array_map('intval', array_keys((array)$arr));
    sort($keys, SORT_NUMERIC);
    return $keys;
}

function subtractPieceCountsFromSaleItems($items, $subtractCounts) {
    if (!is_array($items) || !is_array($subtractCounts)) return is_array($items) ? $items : [];
    $remaining = $subtractCounts;
    $out = [];
    foreach ($items as $item) {
        $pid = (int)($item['id'] ?? 0);
        if (!$pid) { $out[] = $item; continue; }
        $rowQty = normalizeQtyForProductData($item, isset($item['qty']) ? $item['qty'] : 1.0);
        $saleUnit = $item['saleUnit'] ?? 'piece';
        $mult = 1.0;
        if ($saleUnit !== 'piece') {
            $ppp = isset($item['pieces_per_pack']) ? max(1, (int)$item['pieces_per_pack']) : 1;
            $ppc = isset($item['packs_per_carton']) ? max(1, (int)$item['packs_per_carton']) : 1;
            $piecesPerCarton = $ppp * $ppc;
            if ($piecesPerCarton <= 1 && isset($item['itemsPerCarton']) && (int)$item['itemsPerCarton'] > 1) {
                $piecesPerCarton = (int)$item['itemsPerCarton'];
            }
            if ($saleUnit === 'carton') $mult = $piecesPerCarton;
            elseif ($saleUnit === 'pack') $mult = $ppp;
        }
        $rowPieces = $rowQty * $mult;
        $need = isset($remaining[$pid]) ? (float)$remaining[$pid] : 0.0;
        if ($need <= 0) {
            $out[] = $item;
            continue;
        }
        $take = min($need, $rowPieces);
        $leftPieces = $rowPieces - $take;
        $remaining[$pid] = $need - $take;
        if ($leftPieces <= 0) continue;
        $newQty = (float)($leftPieces / $mult);
        if ($newQty <= 0) continue;
        $item['qty'] = $newQty;
        $out[] = $item;
    }
    return $out;
}

function saleRowQtyForReturnsValidation($item) {
    if (!is_array($item)) return 1.0;
    if (isset($item['count']) && (float)$item['count'] > 0) return (float)$item['count'];
    if (isset($item['sold_qty']) && (float)$item['sold_qty'] > 0) return (float)$item['sold_qty'];
    if (isset($item['qty_sold']) && (float)$item['qty_sold'] > 0) return (float)$item['qty_sold'];
    if (isset($item['quantity']) && (float)$item['quantity'] > 0) return (float)$item['quantity'];
    // Legacy fallback only for realistic ranges; avoid using huge stock qty values.
    if (isset($item['qty']) && (float)$item['qty'] > 0 && (float)$item['qty'] <= 1000) return (float)$item['qty'];
    return 1.0;
}
function isWeightProductData($prod) {
    if (!is_array($prod)) return false;
    if (!empty($prod['is_weight']) && ($prod['is_weight'] === true || $prod['is_weight'] == 1 || $prod['is_weight'] === '1')) {
        return true;
    }
    $qtyMode = strtolower(trim((string)($prod['qty_mode'] ?? $prod['measure_mode'] ?? '')));
    if ($qtyMode === 'kilo') return true;
    if ($qtyMode === 'piece') return false;
    // Legacy fallback only for old records that don't have qty_mode.
    $showPack = (int)($prod['unit_show_pack'] ?? 1) === 1;
    $showCarton = (int)($prod['unit_show_carton'] ?? 1) === 1;
    if (!$showPack && !$showCarton) return true;
    $unitType = strtolower(trim((string)($prod['unitType'] ?? $prod['unit_type'] ?? '')));
    return ($unitType === 'kilo' || $unitType === 'kg');
}
function normalizeQtyForProductData($prod, $qtyRaw, $allowNegative = false) {
    $qty = (float)$qtyRaw;
    if ($qty <= 0 && !$allowNegative) return 0.0;
    if (isWeightProductData($prod)) return round($qty, 3);
    return (float)($qty < 0 ? ceil($qty) : floor($qty));
}

/**
 * Save jewelry set members (earrings, bracelet…). Creates/updates member products + links.
 * @param mysqli $conn
 * @param int $setProductId
 * @param string|array $membersJson
 * @param int $isJewelrySet
 */
function pos_save_jewelry_set_items($conn, $setProductId, $membersJson, $isJewelrySet = 1) {
    $setProductId = (int)$setProductId;
    if ($setProductId <= 0 || !($conn instanceof mysqli)) return;
    $conn->query("CREATE TABLE IF NOT EXISTS jewelry_set_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        set_product_id INT NOT NULL,
        member_product_id INT NOT NULL,
        qty DECIMAL(14,3) NOT NULL DEFAULT 1,
        label VARCHAR(100) NOT NULL DEFAULT '',
        sort_order INT NOT NULL DEFAULT 0,
        INDEX idx_jew_set (set_product_id),
        INDEX idx_jew_member (member_product_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $del = $conn->prepare("DELETE FROM jewelry_set_items WHERE set_product_id = ?");
    if ($del) {
        $del->bind_param("i", $setProductId);
        $del->execute();
    }
    if (!(int)$isJewelrySet) return;

    $parentMetal = '';
    $parentKarat = null;
    $pst = $conn->prepare("SELECT metal_type, karat FROM products WHERE id = ? LIMIT 1");
    if ($pst) {
        $pst->bind_param('i', $setProductId);
        $pst->execute();
        $prow = $pst->get_result()->fetch_assoc();
        if ($prow) {
            $parentMetal = strtolower(trim((string)($prow['metal_type'] ?? '')));
            if ($parentMetal !== 'gold' && $parentMetal !== 'silver') $parentMetal = '';
            if (($parentMetal === 'gold' || $parentMetal === 'silver') && $prow['karat'] !== null && $prow['karat'] !== '') {
                $parentKarat = round((float)$prow['karat'], 2);
            }
        }
    }

    $members = is_array($membersJson) ? $membersJson : json_decode((string)$membersJson, true);
    if (!is_array($members) || !count($members)) return;

    $sort = 0;
    foreach ($members as $m) {
        if (!is_array($m)) continue;
        $label = isset($m['label']) ? substr(trim((string)$m['label']), 0, 100) : 'پارچە';
        $mName = isset($m['name']) ? trim((string)$m['name']) : '';
        $mBarcode = isset($m['barcode']) ? trim((string)$m['barcode']) : '';
        $mWeight = isset($m['weight_grams']) ? round((float)$m['weight_grams'], 3) : 0;
        $mPrice = isset($m['price']) ? roundMoney($m['price']) : 0;
        $mCost = isset($m['cost']) ? roundMoney($m['cost']) : 0;
        if ($mCost < 0) $mCost = 0;
        $mQty = isset($m['qty']) ? max(0.001, (float)$m['qty']) : 1;
        $memberId = isset($m['product_id']) ? (int)$m['product_id'] : (isset($m['id']) ? (int)$m['id'] : 0);
        if ($mName === '' && $mBarcode === '' && $memberId <= 0) continue;
        if ($mName === '') $mName = $label !== '' ? $label : ('پارچە ' . ($sort + 1));
        if ($mBarcode === '') {
            $mBarcode = 'JS' . $setProductId . 'M' . ($sort + 1) . substr((string)time(), -4);
        }

        if ($memberId > 0) {
            $upd = $conn->prepare("UPDATE products SET name=?, barcode=?, price=?, cost=?, weight_grams=?, metal_type=?, karat=?, forSale=1, trackStock=1, is_jewelry_set=0 WHERE id=?");
            if ($upd) {
                $karatBind = ($parentKarat !== null) ? (float)$parentKarat : 0.0;
                // s name, s barcode, d price, d cost, d weight, s metal, d karat, i id
                $upd->bind_param("ssdddsdi", $mName, $mBarcode, $mPrice, $mCost, $mWeight, $parentMetal, $karatBind, $memberId);
                $upd->execute();
            }
        } else {
            // Reuse existing product with same barcode if present
            $find = $conn->prepare("SELECT id FROM products WHERE barcode = ? LIMIT 1");
            if ($find) {
                $find->bind_param("s", $mBarcode);
                $find->execute();
                $fres = $find->get_result();
                if ($fres && ($frow = $fres->fetch_assoc())) {
                    $memberId = (int)$frow['id'];
                    if ($memberId !== $setProductId) {
                        $upd = $conn->prepare("UPDATE products SET name=?, price=?, cost=?, weight_grams=?, metal_type=?, karat=?, forSale=1, trackStock=1, is_jewelry_set=0 WHERE id=?");
                        if ($upd) {
                            $karatBind = ($parentKarat !== null) ? (float)$parentKarat : 0.0;
                            // s name, d price, d cost, d weight, s metal, d karat, i id
                            $upd->bind_param("sdddsdi", $mName, $mPrice, $mCost, $mWeight, $parentMetal, $karatBind, $memberId);
                            $upd->execute();
                        }
                    }
                }
            }
            if ($memberId <= 0) {
                $ins = $conn->prepare("INSERT INTO products (name, barcode, price, cost, qty, category, supplier, trackStock, forSale, weight_grams, metal_type, karat, unitType, qty_mode, is_jewelry_set) VALUES (?, ?, ?, ?, 0, ?, 'Direct Store', 1, 1, ?, ?, ?, 'carton', 'piece', 0)");
                if ($ins) {
                    $cat = 'سێت';
                    $karatBind = ($parentKarat !== null) ? (float)$parentKarat : 0.0;
                    // s name, s barcode, d price, d cost, s cat, d weight, s metal, d karat
                    $ins->bind_param("ssddsdsd", $mName, $mBarcode, $mPrice, $mCost, $cat, $mWeight, $parentMetal, $karatBind);
                    if ($ins->execute()) {
                        $memberId = (int)$conn->insert_id;
                    }
                }
            }
        }
        if ($memberId <= 0 || $memberId === $setProductId) continue;
        $link = $conn->prepare("INSERT INTO jewelry_set_items (set_product_id, member_product_id, qty, label, sort_order) VALUES (?, ?, ?, ?, ?)");
        if ($link) {
            $link->bind_param("iidsi", $setProductId, $memberId, $mQty, $label, $sort);
            $link->execute();
        }
        $sort++;
    }

    // Set itself is sold as one SKU; stock lives on member pieces
    $conn->query("UPDATE products SET trackStock = 0, forSale = 1 WHERE id = " . (int)$setProductId);
}

/** member_product_id => qty_per_set for one set product */
function pos_get_jewelry_set_qty_map(mysqli $conn, int $setProductId): array {
    $out = [];
    if ($setProductId <= 0) return $out;
    try {
        $st = $conn->prepare("SELECT member_product_id, qty FROM jewelry_set_items WHERE set_product_id = ?");
        if (!$st) return $out;
        $st->bind_param('i', $setProductId);
        $st->execute();
        $res = $st->get_result();
        if (!$res) return $out;
        while ($row = $res->fetch_assoc()) {
            $mid = (int)$row['member_product_id'];
            if ($mid <= 0) continue;
            $q = max(0.001, (float)$row['qty']);
            $out[$mid] = ($out[$mid] ?? 0) + $q;
        }
    } catch (Throwable $e) {
        return [];
    }
    return $out;
}

/** Load set members for one or many set product ids. Returns map set_id => [members]. */
function pos_load_jewelry_set_items_map(mysqli $conn, array $setIds = []): array {
    $out = [];
    try {
        $sql = "SELECT j.set_product_id, j.member_product_id, j.qty, j.label, j.sort_order,
                       p.name AS member_name, p.barcode AS member_barcode, p.price AS member_price, p.cost AS member_cost,
                       p.weight_grams AS member_weight, p.metal_type AS member_metal, p.karat AS member_karat
                FROM jewelry_set_items j
                LEFT JOIN products p ON p.id = j.member_product_id";
        if ($setIds) {
            $setIds = array_values(array_filter(array_map('intval', $setIds)));
            if (!$setIds) return $out;
            $ph = implode(',', array_fill(0, count($setIds), '?'));
            $sql .= " WHERE j.set_product_id IN ($ph)";
            $stmt = $conn->prepare($sql . " ORDER BY j.sort_order ASC, j.id ASC");
            if (!$stmt) return $out;
            $types = str_repeat('i', count($setIds));
            $stmt->bind_param($types, ...$setIds);
            $stmt->execute();
            $res = $stmt->get_result();
        } else {
            $res = $conn->query($sql . " ORDER BY j.sort_order ASC, j.id ASC");
        }
        if (!$res) return $out;
        while ($row = $res->fetch_assoc()) {
            $sid = (int)$row['set_product_id'];
            if (!isset($out[$sid])) $out[$sid] = [];
            $out[$sid][] = [
                'product_id' => (int)$row['member_product_id'],
                'qty' => (float)$row['qty'],
                'label' => (string)($row['label'] ?? ''),
                'name' => (string)($row['member_name'] ?? ''),
                'barcode' => (string)($row['member_barcode'] ?? ''),
                'price' => roundMoney($row['member_price'] ?? 0),
                'cost' => roundMoney($row['member_cost'] ?? 0),
                'weight_grams' => isset($row['member_weight']) ? round((float)$row['member_weight'], 3) : 0,
                'metal_type' => (string)($row['member_metal'] ?? ''),
                'karat' => $row['member_karat'] !== null ? (float)$row['member_karat'] : null,
            ];
        }
    } catch (Throwable $e) {
        return $out;
    }
    return $out;
}

function isValidYmdDate($d) {
    if (!is_string($d) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $d)) return false;
    $t = strtotime($d);
    if ($t === false) return false;
    return date('Y-m-d', $t) === $d;
}

/**
 * Backup/restore: accept YYYY-MM-DD and common DD-MM-YYYY; reject garbage years (e.g. 33943).
 */
function pos_sanitize_expiry_for_restore($raw) {
    $raw = trim((string)$raw);
    if ($raw === '' || $raw === '0' || preg_match('/^0000-00-00/', $raw)) return '';
    if (isValidYmdDate($raw)) return $raw;
    if (preg_match('/^(\d{1,2})[-\/\.](\d{1,2})[-\/\.](\d{2,4})$/', $raw, $m)) {
        $d = (int)$m[1];
        $mo = (int)$m[2];
        $y = (int)$m[3];
        if ($y < 100) {
            $y += ($y >= 70) ? 1900 : 2000;
        }
        if ($y >= 1900 && $y <= 2100 && checkdate($mo, $d, $y)) {
            return sprintf('%04d-%02d-%02d', $y, $mo, $d);
        }
    }
    if (preg_match('/^(\d{4})[-\/\.](\d{1,2})[-\/\.](\d{1,2})$/', $raw, $m)) {
        $y = (int)$m[1];
        $mo = (int)$m[2];
        $d = (int)$m[3];
        if ($y >= 1900 && $y <= 2100 && checkdate($mo, $d, $y)) {
            return sprintf('%04d-%02d-%02d', $y, $mo, $d);
        }
    }
    return '';
}

/** products.expiry: empty / 0 / invalid → no expiry (not expired). */
function normalizeProductCatalogExpiry($expiry) {
    $expiry = trim((string)$expiry);
    if ($expiry === '' || $expiry === '0' || preg_match('/^0000-00-00/', $expiry)) return '';
    if (isValidYmdDate($expiry)) return $expiry;
    if (function_exists('pos_sanitize_expiry_for_restore')) {
        return pos_sanitize_expiry_for_restore($expiry);
    }
    return '';
}

/** True only when product already has expiry batches (not item_type — clothing etc. stay optional). */
function productUsesExpiryTracking($conn, $productId) {
    $productId = (int)$productId;
    if ($productId <= 0) return false;
    static $cache = [];
    if (array_key_exists($productId, $cache)) return $cache[$productId];
    $uses = false;
    $st2 = $conn->prepare("SELECT 1 FROM supplies WHERE prodId = ? AND expiry_date IS NOT NULL AND expiry_date != '' LIMIT 1");
    if ($st2) {
        $st2->bind_param("i", $productId);
        $st2->execute();
        if ($st2->get_result()->fetch_assoc()) $uses = true;
    }
    if (!$uses) {
        $st3 = $conn->prepare("SELECT 1 FROM stock_batches WHERE product_id = ? AND qty > 0 LIMIT 1");
        if ($st3) {
            $st3->bind_param("i", $productId);
            $st3->execute();
            if ($st3->get_result()->fetch_assoc()) $uses = true;
        }
    }
    $cache[$productId] = $uses;
    return $uses;
}

function upsertStockBatchPurchase($conn, $productId, $expiryDate, $qty, $unitCost, $sourceType, $sourceId, $txnId) {
    $productId = (int)$productId;
    $qty = (float)$qty;
    if ($productId <= 0 || $qty <= 0 || !isValidYmdDate($expiryDate)) return;
    $unitCost = (float)$unitCost;
    $sourceType = (string)$sourceType;
    $sourceId = (int)$sourceId;
    $txnId = (string)$txnId;
    $stmt = $conn->prepare("SELECT id, qty FROM stock_batches WHERE product_id = ? AND expiry_date = ? LIMIT 1 FOR UPDATE");
    if (!$stmt) return;
    $stmt->bind_param("is", $productId, $expiryDate);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res && ($row = $res->fetch_assoc())) {
        $newQty = (float)$row['qty'] + $qty;
        $id = (int)$row['id'];
        $up = $conn->prepare("UPDATE stock_batches SET qty = ?, unit_cost = ? WHERE id = ?");
        if ($up) { $up->bind_param("ddi", $newQty, $unitCost, $id); $up->execute(); }
    } else {
        $ins = $conn->prepare("INSERT INTO stock_batches (product_id, expiry_date, qty, unit_cost, source_type, source_id, transaction_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
        if ($ins) { $ins->bind_param("isddsis", $productId, $expiryDate, $qty, $unitCost, $sourceType, $sourceId, $txnId); $ins->execute(); }
    }
}

/** FEFO consume one pass. Updates $left / $touched / $hadBatchRows by reference. */
function pos_consume_positive_stock_batches_pass($conn, $productId, &$left, &$touched, &$hadBatchRows, $eps) {
    $productId = (int)$productId;
    $q = $conn->prepare("SELECT id, qty FROM stock_batches WHERE product_id = ? AND qty > 0 ORDER BY expiry_date ASC, id ASC FOR UPDATE");
    if (!$q) return;
    $q->bind_param("i", $productId);
    $q->execute();
    $res = $q->get_result();
    while ($res && ($row = $res->fetch_assoc())) {
        $hadBatchRows = true;
        if ($left <= $eps) break;
        $bid = (int)$row['id'];
        $bqty = (float)$row['qty'];
        if ($bqty <= 0) continue;
        $take = min($left, $bqty);
        $newQty = $bqty - $take;
        $u = $conn->prepare("UPDATE stock_batches SET qty = ? WHERE id = ?");
        if ($u) { $u->bind_param("di", $newQty, $bid); $u->execute(); $touched = true; }
        $left -= $take;
    }
}

function consumeStockBatchesFefo($conn, $productId, $requiredQty, $txnId, $saleId, $productName = '') {
    $productId = (int)$productId;
    $requiredQty = (float)$requiredQty;
    $productName = is_string($productName) ? trim($productName) : '';
    if ($productId <= 0 || $requiredQty <= 0) return;
    $left = $requiredQty;
    $eps = 0.000001;
    $touched = false;
    $hadBatchRows = false;
    pos_consume_positive_stock_batches_pass($conn, $productId, $left, $touched, $hadBatchRows, $eps);
    // Backward compatibility: legacy products may have aggregate qty but no batch rows yet.
    // In that case, don't block sale; rely on products.qty / warehouse check already done by caller.
    if (!$hadBatchRows) return;

    $settings = pos_load_app_settings_array($conn);
    $allowNegativeStock = !empty($settings['allowNegativeStock']) && ($settings['allowNegativeStock'] === true || $settings['allowNegativeStock'] === 'true' || $settings['allowNegativeStock'] == 1);
    if ($allowNegativeStock) {
        return;
    }

    // Warehouse/product qty already passed; batch ledger often lags (phones, table cart, old sales).
    // Backfill the gap then consume — do not block a sale the shop already has stock for.
    if ($left > $eps && function_exists('pos_backfill_batch_gap_for_product')) {
        pos_backfill_batch_gap_for_product($conn, $productId, $left);
        pos_consume_positive_stock_batches_pass($conn, $productId, $left, $touched, $hadBatchRows, $eps);
    }

    if ($left > $eps) {
        $label = $productName !== '' ? $productName : ('product #' . $productId);
        $batchShort = (float)$left;
        throw new Exception(
            "stock_not_enough_batches: {$label} [product_id={$productId}] " .
            "(pieces required: {$requiredQty}, missing in stock_batches: {$batchShort})"
        );
    }
    if (!$touched) return;
    pos_sync_product_expiry_from_batches($conn, $productId);
}

/** Sum sellable qty in stock_batches (FEFO ledger). Null when product has no batch rows. */
function pos_sum_stock_batch_qty($conn, $productId) {
    $productId = (int)$productId;
    if ($productId <= 0) return null;
    $chk = $conn->prepare("SELECT 1 FROM stock_batches WHERE product_id = ? LIMIT 1");
    if (!$chk) return null;
    $chk->bind_param("i", $productId);
    $chk->execute();
    if (!$chk->get_result()->fetch_assoc()) return null;
    $stmt = $conn->prepare("SELECT COALESCE(SUM(qty), 0) AS sq FROM stock_batches WHERE product_id = ? AND qty > 0");
    if (!$stmt) return null;
    $stmt->bind_param("i", $productId);
    $stmt->execute();
    $res = $stmt->get_result();
    if (!$res || !($row = $res->fetch_assoc())) return 0.0;
    return (float)$row['sq'];
}

/** Nearest expiry among batches with qty>0 (FEFO alert date). Empty string if none. */
function pos_batch_min_expiry_for_product($conn, $productId) {
    $productId = (int)$productId;
    if ($productId <= 0) return '';
    $stmt = $conn->prepare("SELECT MIN(expiry_date) AS mn FROM stock_batches WHERE product_id = ? AND qty > 0.000001");
    if (!$stmt) return '';
    $stmt->bind_param("i", $productId);
    $stmt->execute();
    $res = $stmt->get_result();
    if (!$res || !($row = $res->fetch_assoc()) || empty($row['mn'])) return '';
    $d = (string)$row['mn'];
    return isValidYmdDate($d) ? $d : '';
}

/** products.expiry = oldest in-stock batch date (UI hint only; ledger stays per batch). */
function pos_sync_product_expiry_from_batches($conn, $productId) {
    $productId = (int)$productId;
    if ($productId <= 0) return;
    $minExp = pos_batch_min_expiry_for_product($conn, $productId);
    $stmt = $conn->prepare("UPDATE products SET expiry = ? WHERE id = ?");
    if ($stmt) {
        $stmt->bind_param("si", $minExp, $productId);
        $stmt->execute();
    }
}

/** SQL fragment: product row is a real stockout (نەما), matching client isWarehouseTrueStockout(). */
function pos_sql_product_true_stockout(string $alias = 'p'): string {
    $a = preg_replace('/[^a-zA-Z0-9_]/', '', $alias) ?: 'p';
    $purchase = "EXISTS (SELECT 1 FROM supplies s WHERE s.prodId = {$a}.id"
        . " AND COALESCE(s.type, '') NOT IN ('return', 'opening') AND s.qtyAdded > 0)"
        . " OR EXISTS (SELECT 1 FROM stock_movements wm WHERE wm.product_id = {$a}.id"
        . " AND LOWER(COALESCE(wm.movement_type, '')) = 'purchase' AND wm.quantity > 0)";
    return "{$a}.trackStock = 1 AND {$a}.qty <= 0"
        . " AND (COALESCE({$a}.catalog_only, 0) = 0 OR ({$purchase}))";
}

/**
 * One-shot: merged catalog rows (bulk import, never create_product) at qty=0 → catalog_only=1.
 * Shop form items keep catalog_only=0 (create_product in audit_logs).
 */
function pos_backfill_catalog_only_merged($conn) {
    if (!$conn || !($conn instanceof mysqli)) return;
    if (function_exists('pos_db_get_setting_value') && pos_db_get_setting_value($conn, 'catalog_only_backfill_v1') === '1') {
        return;
    }
    if (function_exists('checkAndAddCol')) {
        checkAndAddCol($conn, 'products', 'catalog_only', 'TINYINT(1) NOT NULL DEFAULT 0');
    }
    $purchase = "EXISTS (SELECT 1 FROM supplies s WHERE s.prodId = p.id"
        . " AND COALESCE(s.type, '') NOT IN ('return', 'opening') AND s.qtyAdded > 0)"
        . " OR EXISTS (SELECT 1 FROM stock_movements wm WHERE wm.product_id = p.id"
        . " AND LOWER(COALESCE(wm.movement_type, '')) = 'purchase' AND wm.quantity > 0)";
    $shopCreated = "EXISTS (SELECT 1 FROM audit_logs al WHERE al.entity_type = 'product'"
        . " AND al.entity_id = p.id AND al.action_type IN ('create_product', 'edit_product'))";
    @$conn->query(
        "UPDATE products p SET catalog_only = 1"
        . " WHERE p.trackStock = 1 AND p.qty <= 0 AND COALESCE(p.catalog_only, 0) = 0"
        . " AND NOT ({$purchase}) AND NOT ({$shopCreated})"
    );
    if (function_exists('pos_db_set_setting_value')) {
        pos_db_set_setting_value($conn, 'catalog_only_backfill_v1', '1');
    }
}

/** Merged catalog import: catalog_only=1 until first real purchase. Shop save/purchase clears it. */
function pos_clear_product_catalog_only($conn, $productId) {
    if (!$conn || !($conn instanceof mysqli)) return;
    $productId = (int)$productId;
    if ($productId <= 0) return;
    if (function_exists('checkAndAddCol')) {
        checkAndAddCol($conn, 'products', 'catalog_only', 'TINYINT(1) NOT NULL DEFAULT 0');
    }
    $stmt = $conn->prepare('UPDATE products SET catalog_only = 0 WHERE id = ?');
    if ($stmt) {
        $stmt->bind_param('i', $productId);
        $stmt->execute();
    }
}

/** Batch qty at a specific expiry (purchase history edits). */
function pos_purchase_line_batch_qty($conn, $productId, $expiryDate) {
    $productId = (int)$productId;
    $expiryDate = trim((string)$expiryDate);
    if ($productId <= 0 || !isValidYmdDate($expiryDate)) return 0.0;
    $stmt = $conn->prepare('SELECT qty FROM stock_batches WHERE product_id = ? AND expiry_date = ? LIMIT 1');
    if (!$stmt) return 0.0;
    $stmt->bind_param('is', $productId, $expiryDate);
    $stmt->execute();
    $res = $stmt->get_result();
    if (!$res || !($row = $res->fetch_assoc())) return 0.0;
    return (float)($row['qty'] ?? 0);
}

/** Move purchase-line batch qty from one expiry date to another. */
function pos_migrate_purchase_line_expiry_batch($conn, $productId, $supplyId, $txnId, $oldExpiry, $newExpiry, $qty, $unitCost) {
    $productId = (int)$productId;
    $supplyId = (int)$supplyId;
    $qty = (float)$qty;
    $unitCost = (float)$unitCost;
    $txnId = (string)$txnId;
    $oldExpiry = trim((string)$oldExpiry);
    $newExpiry = trim((string)$newExpiry);
    if ($productId <= 0 || $qty <= 0.0001 || $oldExpiry === $newExpiry) return;
    if ($oldExpiry !== '' && isValidYmdDate($oldExpiry)) {
        $st = $conn->prepare('UPDATE stock_batches SET qty = GREATEST(0, qty - ?) WHERE product_id = ? AND expiry_date = ?');
        if ($st) {
            $st->bind_param('dis', $qty, $productId, $oldExpiry);
            $st->execute();
        }
    }
    if ($newExpiry !== '' && isValidYmdDate($newExpiry)) {
        upsertStockBatchPurchase($conn, $productId, $newExpiry, $qty, $unitCost, 'purchase_edit', $supplyId, $txnId);
        pos_sync_product_expiry_from_batches($conn, $productId);
    } elseif (productUsesExpiryTracking($conn, $productId)) {
        pos_sync_product_expiry_from_batches($conn, $productId);
    }
}

/** Adjust batch qty for a purchase-line edit (same expiry). */
function pos_adjust_purchase_line_batch_qty($conn, $productId, $expiryDate, $qtyDelta, $unitCost, $supplyId, $txnId) {
    $productId = (int)$productId;
    $supplyId = (int)$supplyId;
    $qtyDelta = (float)$qtyDelta;
    $expiryDate = trim((string)$expiryDate);
    $txnId = (string)$txnId;
    if ($productId <= 0 || !isValidYmdDate($expiryDate) || abs($qtyDelta) < 0.0001) return;
    if ($qtyDelta > 0) {
        upsertStockBatchPurchase($conn, $productId, $expiryDate, $qtyDelta, (float)$unitCost, 'purchase_edit', $supplyId, $txnId);
    } else {
        $st = $conn->prepare('UPDATE stock_batches SET qty = GREATEST(0, qty + ?) WHERE product_id = ? AND expiry_date = ?');
        if ($st) {
            $st->bind_param('dis', $qtyDelta, $productId, $expiryDate);
            $st->execute();
        }
    }
    if (productUsesExpiryTracking($conn, $productId)) {
        pos_sync_product_expiry_from_batches($conn, $productId);
    }
}

/** First-time stock with expiry → stock_batches row (qty tied to that date, not product name). */
function pos_ensure_initial_stock_batch($conn, $productId, $qty, $unitCost, $expiryDate, $sourceId = 0) {
    $productId = (int)$productId;
    $qty = (float)$qty;
    if ($productId <= 0 || $qty <= 0 || !isValidYmdDate($expiryDate)) return;
    $unitCost = (float)$unitCost;
    $txnId = 'INIT-' . $productId . '-' . uniqid();
    upsertStockBatchPurchase($conn, $productId, $expiryDate, $qty, $unitCost, 'initial_stock', (int)$sourceId, $txnId);
    pos_sync_product_expiry_from_batches($conn, $productId);
}

/** When products.qty exceeds batch sum (cart/table sync drift), backfill batch ledger instead of zeroing stock. */
function pos_backfill_batch_gap_for_product($conn, $productId, $gapQty) {
    $productId = (int)$productId;
    $gapQty = (float)$gapQty;
    if ($productId <= 0 || $gapQty <= 0.000001) return;
    $unitCost = 0.0;
    $expiry = '2099-12-31';
    $stmt = $conn->prepare("SELECT cost, expiry FROM products WHERE id = ? LIMIT 1");
    if ($stmt) {
        $stmt->bind_param("i", $productId);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res && ($row = $res->fetch_assoc())) {
            $unitCost = (float)($row['cost'] ?? 0);
            $expRaw = normalizeProductCatalogExpiry($row['expiry'] ?? '');
            if ($expRaw !== '') $expiry = $expRaw;
        }
    }
    $txn = 'GAP-' . $productId . '-' . uniqid('', true);
    upsertStockBatchPurchase($conn, $productId, $expiry, $gapQty, $unitCost, 'qty_reconcile', 0, $txn);
    pos_sync_product_expiry_from_batches($conn, $productId);
}

/** Sellable qty = warehouse / products.qty; backfill stock_batches when ledger lags (phones, table cart, legacy). */
function pos_reconcile_product_qty_with_batches($conn, $productId, $productQty) {
    $batchSum = pos_sum_stock_batch_qty($conn, $productId);
    if ($batchSum === null) return (float)$productQty;
    $pq = (float)$productQty;
    if ($pq > $batchSum + 0.000001) {
        pos_backfill_batch_gap_for_product($conn, (int)$productId, $pq - $batchSum);
        return $pq;
    }
    return $pq;
}

// Ensure clean output for JSON: clear any existing buffers and start one to catch stray output
while (ob_get_level()) ob_end_clean();
if (extension_loaded('zlib') && !ini_get('zlib.output_compression') && isset($_SERVER['HTTP_ACCEPT_ENCODING']) && strpos($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip') !== false) {
    ob_start('ob_gzhandler');
}
ob_start('posJsonOutputFilter');
if (function_exists('pos_api_cors_apply_headers')) {
    pos_api_cors_apply_headers();
}

/** @return array<string,mixed>|null */
function pos_session_user_row() {
    return (isset($_SESSION['user']) && is_array($_SESSION['user'])) ? $_SESSION['user'] : null;
}
function pos_session_user_name() {
    if (isset($_SESSION['user_name']) && (string)$_SESSION['user_name'] !== '') {
        return (string)$_SESSION['user_name'];
    }
    $u = pos_session_user_row();
    if ($u && isset($u['name']) && (string)$u['name'] !== '') {
        return (string)$u['name'];
    }
    return 'System';
}
/** Session user for API payloads — permissions always decoded to array. */
function pos_session_user_for_client() {
    $u = pos_session_user_row();
    if (!$u) return null;
    if (isset($u['permissions']) && is_string($u['permissions'])) {
        $u['permissions'] = json_decode($u['permissions'], true);
    }
    if (!isset($u['permissions']) || !is_array($u['permissions'])) {
        $u['permissions'] = [];
    }
    return $u;
}
function pos_session_role() {
    return isset($_SESSION['user_role']) ? (string)$_SESSION['user_role'] : '';
}
function pos_session_is_admin() {
    return pos_session_role() === 'admin';
}
/** Admin or store manager: trusted for full operational/financial payloads (aligns with get_sync_data limits). */
function pos_session_is_privileged() {
    $r = pos_session_role();
    return $r === 'admin' || $r === 'manager';
}
/** Shop FX (settings + POS visual rate): Admin / Manager only. Cashiers cannot change it. */
function pos_session_can_set_exchange_rate() {
    return pos_session_is_privileged();
}
function pos_session_has_perm($perm) {
    if (pos_session_is_admin()) return true;
    $u = pos_session_user_row();
    if (!$u) return false;
    $list = $u['permissions'] ?? null;
    if (!is_array($list)) return false;
    return in_array((string)$perm, $list, true);
}
function pos_session_require_login_json() {
    if (empty($_SESSION['user_id'])) {

        header('Content-Type: application/json; charset=utf-8');
        http_response_code(401);
        echo json_encode(['status' => 'error', 'message' => 'Login required'], JSON_UNESCAPED_UNICODE);
        exit();
    }
}
function pos_json_perm_denied() {

    header('Content-Type: application/json; charset=utf-8');
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Permission denied'], JSON_UNESCAPED_UNICODE);
    exit();
}
function pos_session_can_reports() {
    return pos_session_is_privileged() || pos_session_has_perm('reports_view');
}
function pos_session_can_view_profit() {
    return pos_session_is_privileged() || pos_session_has_perm('view_profit');
}
/** Product cost / کرین — privileged, explicit view_cost, or legacy view_profit. */
function pos_session_can_view_cost() {
    return pos_session_is_privileged()
        || pos_session_has_perm('view_cost')
        || pos_session_has_perm('view_profit');
}
function pos_session_can_view_expenses() {
    return pos_session_is_privileged() || pos_session_has_perm('view_expenses');
}
function pos_session_can_manage_expenses() {
    return pos_session_is_privileged() || pos_session_has_perm('expenses_manage');
}
function pos_session_can_manage_waste() {
    return pos_session_is_privileged() || pos_session_has_perm('waste_manage');
}

function pos_map_delivery_row_compact(array $r) {
    $r['id'] = (int)($r['id'] ?? 0);
    $r['total'] = function_exists('roundMoney') ? roundMoney($r['total'] ?? 0) : (float)($r['total'] ?? 0);
    $r['delivery_cost'] = function_exists('roundMoney') ? roundMoney($r['delivery_cost'] ?? 0) : (float)($r['delivery_cost'] ?? 0);
    $r['customer_id'] = (int)($r['customer_id'] ?? 0);
    $r['driver_id'] = (int)($r['driver_id'] ?? 0);
    $r['sale_id'] = (int)($r['sale_id'] ?? 0);
    if (!isset($r['items']) || !is_array($r['items'])) {
        $r['items'] = [];
    }
    unset($r['items_json']);
    return $r;
}

/** Compact deliveries (no items_json) so profile history and bootstrap stay fast and reliable. */
function pos_fetch_deliveries_compact($conn, $limit = 200, $driverId = 0) {
    $rows = [];
    if (!$conn) {
        return $rows;
    }
    $limit = max(1, min(500, (int)$limit));
    $driverId = (int)$driverId;
    if ($driverId > 0 && function_exists('pos_fetch_deliveries_for_driver')) {
        return pos_fetch_deliveries_for_driver($conn, $driverId, $limit);
    }
    $sql = "SELECT id, customer_name, phone, address, driver, driver_phone, delivery_cost, total, status, `date`, note, customer_id, driver_id, sale_id, settled_at FROM deliveries";
    $sql .= " ORDER BY id DESC LIMIT " . $limit;
    try {
        $res = $conn->query($sql);
        if ($res) {
            while ($r = $res->fetch_assoc()) {
                $rows[] = pos_map_delivery_row_compact($r);
            }
        }
    } catch (Throwable $e) { /* table may not exist */ }
    return $rows;
}

/** All deliveries for one driver: by driver_id, or legacy rows that only stored the name. */
function pos_fetch_deliveries_for_driver($conn, $driverId, $limit = 400) {
    $rows = [];
    if (!$conn) {
        return $rows;
    }
    $driverId = (int)$driverId;
    if ($driverId <= 0) {
        return $rows;
    }
    $limit = max(1, min(500, (int)$limit));
    $escName = '';
    try {
        $resN = $conn->query('SELECT name FROM drivers WHERE id = ' . $driverId . ' LIMIT 1');
        if ($resN && ($rowN = $resN->fetch_assoc())) {
            $escName = $conn->real_escape_string(trim((string)($rowN['name'] ?? '')));
        }
    } catch (Throwable $eN) { /* ignore */ }

    $sql = 'SELECT id, customer_name, phone, address, driver, driver_phone, delivery_cost, total, status, `date`, note, customer_id, driver_id, sale_id, settled_at
            FROM deliveries
            WHERE driver_id = ' . $driverId;
    if ($escName !== '') {
        $sql .= " OR driver = '" . $escName . "'";
    }
    $sql .= ' ORDER BY id DESC LIMIT ' . $limit;
    try {
        $res = $conn->query($sql);
        $seen = [];
        if ($res) {
            while ($r = $res->fetch_assoc()) {
                $mapped = pos_map_delivery_row_compact($r);
                $sid = (int)($mapped['id'] ?? 0);
                if ($sid && isset($seen[$sid])) {
                    continue;
                }
                if ($sid) {
                    $seen[$sid] = true;
                }
                $rows[] = $mapped;
            }
        }
    } catch (Throwable $eQ) { /* table may not exist */ }
    return $rows;
}

/** Laptop/phone spec JSON on products (CPU, RAM, GPU, screen…). Empty string clears. */
function pos_normalize_tech_specs($raw) {
    $decoded = [];
    if (is_array($raw)) {
        $decoded = $raw;
    } elseif (is_string($raw) && trim($raw) !== '') {
        $tmp = json_decode($raw, true);
        if (is_array($tmp)) {
            $decoded = $tmp;
        }
    }
    $keys = ['cpu', 'ram', 'storage', 'gpu', 'screen', 'summary', 'extra'];
    $out = [];
    foreach ($keys as $k) {
        if (!isset($decoded[$k])) {
            continue;
        }
        $v = trim((string)$decoded[$k]);
        if ($v === '') {
            continue;
        }
        if (function_exists('mb_substr')) {
            $v = mb_substr($v, 0, 160, 'UTF-8');
        } else {
            $v = substr($v, 0, 160);
        }
        $out[$k] = $v;
    }
    if (!$out) {
        return '';
    }
    $json = json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    return is_string($json) ? $json : '';
}

function pos_save_product_tech_specs($conn, $id, $raw) {
    $id = (int)$id;
    if (!$conn || $id <= 0) {
        return;
    }
    if (function_exists('checkAndAddCol')) {
        checkAndAddCol($conn, 'products', 'tech_specs', 'TEXT NULL');
    }
    $json = pos_normalize_tech_specs($raw);
    $stmt = $conn->prepare('UPDATE products SET tech_specs = ? WHERE id = ?');
    if (!$stmt) {
        return;
    }
    $stmt->bind_param('si', $json, $id);
    $stmt->execute();
}

function pos_tech_specs_clip($s, $n) {
    $s = preg_replace('/\s+/u', ' ', (string)$s);
    $s = trim((string)$s);
    if ($s === '') {
        return '';
    }
    if (function_exists('mb_strlen') && mb_strlen($s, 'UTF-8') > $n) {
        return rtrim(mb_substr($s, 0, $n, 'UTF-8'));
    }
    if (strlen($s) > $n) {
        return rtrim(substr($s, 0, $n));
    }
    return $s;
}

function pos_tech_specs_empty_arr() {
    return [
        'cpu' => '', 'ram' => '', 'storage' => '', 'gpu' => '',
        'screen' => '', 'summary' => '', 'extra' => '', 'title' => '',
    ];
}

function pos_looks_like_dumped_tech_specs($name) {
    return (bool)preg_match('/\b(CPU|RAM|GPU|SIZE|SCREEN|SSD|STORAGE)\s*[:：]/iu', (string)$name);
}

function pos_tech_specs_has_content_arr($specs) {
    if (!is_array($specs)) {
        return false;
    }
    foreach (['cpu', 'ram', 'storage', 'gpu', 'screen', 'summary', 'extra'] as $k) {
        if (!empty($specs[$k])) {
            return true;
        }
    }
    return false;
}

function pos_split_head_title_summary($head) {
    $head = pos_tech_specs_clip($head, 240);
    if ($head === '') {
        return ['title' => '', 'summary' => ''];
    }
    if (strpos($head, '|') === false) {
        return ['title' => $head, 'summary' => ''];
    }
    $words = explode(' ', $head);
    $firstPipe = -1;
    for ($i = 0, $n = count($words); $i < $n; $i++) {
        if (strpos($words[$i], '|') !== false) {
            $firstPipe = $i;
            break;
        }
    }
    if ($firstPipe < 0) {
        return ['title' => $head, 'summary' => ''];
    }
    if ($firstPipe > 0 && preg_match('/^\d+TH$/i', $words[$firstPipe - 1])) {
        $firstPipe -= 1;
    }
    return [
        'title' => trim(implode(' ', array_slice($words, 0, $firstPipe))),
        'summary' => trim(implode(' ', array_slice($words, $firstPipe))),
    ];
}

function pos_split_ram_storage($ram) {
    $ram = pos_tech_specs_clip($ram, 160);
    if ($ram === '') {
        return ['ram' => '', 'storage' => ''];
    }
    if (!preg_match('/\b(SSD|HDD|NVME|STORAGE|ROM)\b/i', $ram)) {
        return ['ram' => $ram, 'storage' => ''];
    }
    $parts = preg_split('/\s*[-–—]\s+/u', $ram);
    if (is_array($parts) && count($parts) >= 2) {
        $left = trim($parts[0]);
        $right = trim(implode(' - ', array_slice($parts, 1)));
        if ($left !== '' && $right !== '') {
            return ['ram' => $left, 'storage' => $right];
        }
    }
    return ['ram' => $ram, 'storage' => ''];
}

/** Parse dumped laptop/phone name (CPU:/RAM:/GPU:/SIZE:) into fields. Grocery names unchanged. */
function pos_parse_tech_specs_from_text($text) {
    $out = pos_tech_specs_empty_arr();
    $s = pos_tech_specs_clip($text, 2000);
    if ($s === '') {
        return $out;
    }
    $aliases = [
        'CPU' => 'cpu', 'PROCESSOR' => 'cpu',
        'RAM' => 'ram', 'MEMORY' => 'ram',
        'GPU' => 'gpu', 'VGA' => 'gpu',
        'SIZE' => 'screen', 'SCREEN' => 'screen', 'DISPLAY' => 'screen',
        'SSD' => 'storage', 'HDD' => 'storage', 'STORAGE' => 'storage', 'ROM' => 'storage',
        'BATTERY' => 'extra', 'CAMERA' => 'extra', 'CAM' => 'extra',
    ];
    $re = '/\b(CPU|PROCESSOR|RAM|MEMORY|GPU|VGA|SIZE|SCREEN|DISPLAY|SSD|HDD|STORAGE|ROM|BATTERY|CAMERA|CAM)\s*[:：]\s*/iu';
    if (!preg_match_all($re, $s, $m, PREG_OFFSET_CAPTURE)) {
        $out['title'] = pos_tech_specs_clip($s, 160);
        return $out;
    }
    $hits = [];
    foreach ($m[0] as $i => $full) {
        $hits[] = [
            'alias' => strtoupper((string)$m[1][$i][0]),
            'start' => (int)$full[1],
            'valueStart' => (int)$full[1] + strlen((string)$full[0]),
        ];
    }
    $n = count($hits);
    for ($i = 0; $i < $n; $i++) {
        $end = ($i + 1 < $n) ? $hits[$i + 1]['start'] : strlen($s);
        $val = pos_tech_specs_clip(substr($s, $hits[$i]['valueStart'], $end - $hits[$i]['valueStart']), 160);
        $dest = $aliases[$hits[$i]['alias']] ?? '';
        if ($dest === '' || $val === '') {
            continue;
        }
        if ($dest === 'extra') {
            $out['extra'] = $out['extra'] !== '' ? ($out['extra'] . ' · ' . $val) : $val;
        } elseif ($dest === 'storage' && $out['storage'] !== '') {
            $out['extra'] = $out['extra'] !== '' ? ($out['extra'] . ' · ' . $val) : $val;
        } elseif ($out[$dest] === '') {
            $out[$dest] = $val;
        }
    }
    if ($out['ram'] !== '' && $out['storage'] === '') {
        $rs = pos_split_ram_storage($out['ram']);
        $out['ram'] = $rs['ram'];
        $out['storage'] = $rs['storage'];
    }
    $head = pos_tech_specs_clip(substr($s, 0, $hits[0]['start']), 240);
    $hs = pos_split_head_title_summary($head);
    $out['title'] = $hs['title'];
    if ($out['summary'] === '') {
        $out['summary'] = $hs['summary'];
    }
    if ($out['title'] === '') {
        $out['title'] = $head;
    }
    return $out;
}

/**
 * One-shot catalog split: dumped CPU/RAM/GPU/SIZE in product name → tech_specs + short title.
 * Does not touch qty / warehouse.
 *
 * @return array{ok:bool,reason?:string,items:array<int,array{id:int,name:string,tech_specs:string}>,count:int}
 */
function pos_migrate_dumped_tech_specs_from_names($conn) {
    $empty = ['ok' => false, 'items' => [], 'count' => 0];
    if (!$conn) {
        $empty['reason'] = 'db';
        return $empty;
    }
    if (function_exists('pos_can_use_tech_specs') && !pos_can_use_tech_specs($conn)) {
        $empty['reason'] = 'locked';
        return $empty;
    }
    if (function_exists('checkAndAddCol')) {
        checkAndAddCol($conn, 'products', 'tech_specs', 'TEXT NULL');
    }
    $res = $conn->query("SELECT id, name, IFNULL(tech_specs,'') AS tech_specs FROM products");
    if (!$res) {
        $empty['reason'] = 'query';
        return $empty;
    }
    $stmt = $conn->prepare('UPDATE products SET name = ?, tech_specs = ? WHERE id = ?');
    if (!$stmt) {
        $empty['reason'] = 'prepare';
        return $empty;
    }
    $updated = [];
    while ($row = $res->fetch_assoc()) {
        $id = (int)$row['id'];
        $oldName = (string)($row['name'] ?? '');
        if ($id <= 0 || !pos_looks_like_dumped_tech_specs($oldName)) {
            continue;
        }
        $parsed = pos_parse_tech_specs_from_text($oldName);
        if (!pos_tech_specs_has_content_arr($parsed)) {
            continue;
        }
        $existing = [];
        $raw = trim((string)($row['tech_specs'] ?? ''));
        if ($raw !== '' && $raw !== '{}') {
            $tmp = json_decode($raw, true);
            if (is_array($tmp)) {
                $existing = $tmp;
            }
        }
        $merged = [];
        foreach (['cpu', 'ram', 'storage', 'gpu', 'screen', 'summary', 'extra'] as $k) {
            $v = '';
            if (!empty($existing[$k])) {
                $v = pos_tech_specs_clip((string)$existing[$k], 160);
            } elseif (!empty($parsed[$k])) {
                $v = pos_tech_specs_clip((string)$parsed[$k], 160);
            }
            if ($v !== '') {
                $merged[$k] = $v;
            }
        }
        $json = $merged ? json_encode($merged, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : '';
        if (!is_string($json)) {
            $json = '';
        }
        $newName = $oldName;
        if (!empty($parsed['title'])) {
            $newName = pos_tech_specs_clip((string)$parsed['title'], 255);
        }
        if ($newName === $oldName && $json === $raw) {
            continue;
        }
        $stmt->bind_param('ssi', $newName, $json, $id);
        if ($stmt->execute()) {
            $updated[] = ['id' => $id, 'name' => $newName, 'tech_specs' => $json];
        }
    }
    $stmt->close();
    return ['ok' => true, 'items' => $updated, 'count' => count($updated)];
}
