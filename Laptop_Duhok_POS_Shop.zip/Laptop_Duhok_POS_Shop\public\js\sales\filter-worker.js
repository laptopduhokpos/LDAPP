/**
 * Web Worker bridge for POS menu filter (phase 4).
 */
(function () {
    'use strict';

    var _worker = null;
    var _reqSeq = 0;
    var _inflight = null;

    function workerUrl() {
        var v = (typeof window.POS_APP_VERSION !== 'undefined') ? window.POS_APP_VERSION : '1';
        return 'public/js/workers/pos-filter.worker.js?v=' + encodeURIComponent(String(v));
    }

    function getWorker() {
        if (_worker) return _worker;
        try {
            _worker = new Worker(workerUrl());
        } catch (e) {
            _worker = null;
        }
        return _worker;
    }

    function shouldUseWorker(cacheLen, q) {
        if (!cacheLen || cacheLen < 700) return false;
        if (!String(q || '').trim()) return false;
        if (typeof window.isPosLargeShopMode === 'function' && window.isPosLargeShopMode()) return true;
        if (typeof window.isPosLargeCatalogMode === 'function' && window.isPosLargeCatalogMode()) return true;
        return cacheLen >= 1200;
    }

    function packEntries(cache) {
        return cache.map(function (e) {
            var p = e.p;
            return {
                id: p.id,
                forSale: !(p.forSale === false || p.forSale === 0 || p.forSale === '0' || p.forSale === 'false'),
                cat: p.cat,
                lowerName: e.lowerName,
                normName: e.normName,
                lowerBarcode: e.lowerBarcode,
                lowerSku: e.lowerSku,
                normSku: e.normSku,
                packOk: !(p.unit_show_pack != null && Number(p.unit_show_pack) === 0),
                cartonOk: !(p.unit_show_carton != null && Number(p.unit_show_carton) === 0)
            };
        });
    }

    function filterViaWorker(cache, q, category, unitFilter) {
        var w = getWorker();
        if (!w) {
            return Promise.resolve(null);
        }
        var reqId = ++_reqSeq;
        if (_inflight && _inflight.reject) {
            try { _inflight.reject({ cancelled: true }); } catch (eIgn) {}
        }
        return new Promise(function (resolve, reject) {
            _inflight = { reqId: reqId, reject: reject };
            function onMsg(ev) {
                if (!ev.data || ev.data.reqId !== reqId) return;
                w.removeEventListener('message', onMsg);
                w.removeEventListener('error', onErr);
                _inflight = null;
                var idSet = Object.create(null);
                (ev.data.ids || []).forEach(function (id) { idSet[String(id)] = true; });
                var out = [];
                for (var i = 0; i < cache.length; i++) {
                    if (idSet[String(cache[i].p.id)]) out.push(cache[i].p);
                }
                resolve(out);
            }
            function onErr() {
                w.removeEventListener('message', onMsg);
                w.removeEventListener('error', onErr);
                _inflight = null;
                resolve(null);
            }
            w.addEventListener('message', onMsg);
            w.addEventListener('error', onErr);
            w.postMessage({
                reqId: reqId,
                entries: packEntries(cache),
                q: q,
                category: category,
                unit: unitFilter || 'piece'
            });
        });
    }

    window.posFilterWorkerShouldUse = shouldUseWorker;
    window.posFilterViaWorker = filterViaWorker;
})();
