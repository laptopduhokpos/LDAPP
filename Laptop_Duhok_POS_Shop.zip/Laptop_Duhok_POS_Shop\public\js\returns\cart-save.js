// returns/cart-save.js — sales-return barcode, cart, save
window.handleReturnsBarcode = function(e) {
    if (e.key !== 'Enter') return;
    var val = String(e.target.value || '').trim();
    if (!val) return;

    var customerSelTop = document.getElementById('returns-debt-select');
    var customerSelBottom = document.getElementById('returns-debt-customer');
    var customerSel = (customerSelTop && customerSelTop.value) ? customerSelTop : (customerSelBottom || customerSelTop);
    if (!customerSel) customerSel = customerSelBottom;
    var customerVal = customerSel ? customerSel.value : '';
    var customerName = null;
    var customerId = null;
    var isSpecificCustomer = false;

    if (customerVal && customerVal.startsWith('customer_')) {
        customerId = parseInt(customerVal.split('_')[1], 10);
        var cust = (window.db.customers || []).find(function(c) { return c.id === customerId; });
        if (cust) customerName = cust.name;
        isSpecificCustomer = true;
    } else if (customerVal && customerVal.startsWith('user_')) {
        customerId = parseInt(customerVal.split('_')[1], 10);
        var usr = (window.db.users || []).find(function(u) { return u.id === customerId; });
        if (usr) customerName = usr.name;
        isSpecificCustomer = true;
    } else if (customerVal && customerVal !== '' && !isNaN(parseInt(customerVal, 10))) {
        customerId = parseInt(customerVal, 10);
        var cust2 = (window.db.customers || []).find(function(c) { return c.id === customerId; });
        if (cust2) customerName = cust2.name;
        isSpecificCustomer = true;
        if (customerSelBottom && customerSelBottom.value !== customerVal) customerSelBottom.value = customerVal;
    } else if (customerVal && customerVal !== '') {
        isSpecificCustomer = true;
        if (customerSel.options && customerSel.options[customerSel.selectedIndex]) {
            customerName = customerSel.options[customerSel.selectedIndex].text.replace(' (Customer)', '').replace(' (Staff)', '').split(' - ')[0].trim();
        }
    }

    var invInput2 = document.getElementById('returns-new-invoice-ref') || document.getElementById('sales-return-invoice-ref');
    var invRaw2 = invInput2 && invInput2.value ? String(invInput2.value).trim() : '';
    var invId2 = invRaw2 ? resolveReturnsInvoiceToSaleId(invRaw2) : null;

    if (invRaw2 && invId2 == null) {
        if (window.showToast) window.showToast(rt('returns_invoice_not_found', 'لم يُعثر على وصل بهذا الرقم.'), 'warning');
        e.preventDefault();
        return;
    }

    var hasFilters = isSpecificCustomer || (invId2 != null) || !!window.returnsManualMode;
    if (!hasFilters) {
        if (window.showToast) window.showToast(rt('returns_need_filter', 'هیڤیە کریارەکێ یان ژمارا وەسڵێ هەڵبژێرە.'), 'warning');
        e.preventDefault();
        return;
    }

    var soldItems = {};
    getSalesListForReturns().forEach(function(sale) {
        var match = false;
        if (invId2 != null && Number(sale.id) === invId2) match = true;
        else if (invId2 == null && isSpecificCustomer) {
            if (sale.customer_id == customerId) match = true;
            else if (sale.customer === customerName) match = true;
        }
        let items = getParsedItems(sale);
        if (match && items.length) {
            items.forEach(function(item) {
                var pid = getSaleLineProductId(item);
                if (!pid) return;
                if (!soldItems[pid]) soldItems[pid] = emptyReturnsSoldEntry(item);
                var mult = 1;
                var factors = (typeof getProductUnitFactors === 'function') ? getProductUnitFactors(item) : { piecesPerPack: 1, piecesPerCarton: 1 };
                if (item.saleUnit === 'carton') mult = factors.piecesPerCarton || 1;
                else if (item.saleUnit === 'pack') mult = factors.piecesPerPack || 1;
                var soldLineQty = Math.max(1, getSaleRowSoldQty(item));
                soldItems[pid].qty += (mult * soldLineQty);
                noteReturnsSoldLinePrice(soldItems[pid], item, mult);
            });
        }
    });

    if (window.db.returns) {
        window.db.returns.forEach(function(ret) {
            var match = false;
            if (invId2 != null && Number(ret.sale_id) === invId2) match = true;
            else if (invId2 == null && isSpecificCustomer) {
                if (ret.target_id == customerId) match = true;
            }
            let retItems = getParsedItems(ret);
            if (match && retItems.length) {
                retItems.forEach(function(item) {
                    var pid = getSaleLineProductId(item);
                    if (!pid) return;
                    if (soldItems[pid]) {
                        var mult = 1;
                        var factors = (typeof getProductUnitFactors === 'function') ? getProductUnitFactors(item) : { piecesPerPack: 1, piecesPerCarton: 1 };
                        if (item.saleUnit === 'carton') mult = factors.piecesPerCarton || 1;
                        else if (item.saleUnit === 'pack') mult = factors.piecesPerPack || 1;
                        var returnedLineQty2 = Math.max(1, parseFloat(item.qty) || 1);
                        soldItems[pid].qty -= (mult * returnedLineQty2);
                    }
                });
            }
        });
    }

    var unit = window.returnsActiveUnit || 'piece';
    var eligible = (window.db.products || []).filter(function(p) {
        if (p.forSale === false) return false;
        if (!window.returnsManualMode && !(soldItems[String(p.id)] && soldItems[String(p.id)].qty > 0)) return false;
        return true;
    });

    var resolved = typeof window.resolveBarcodeForTxnAdd === 'function'
        ? window.resolveBarcodeForTxnAdd(val, unit, { isPurchase: false, candidates: eligible })
        : null;
    if (resolved && resolved.ambiguous) {
        if (window.showToast) window.showToast(rt('returns_ambiguous_scan', 'پتر ژ ئێک ئایتم هاتە دیتن! یەکێ هەڵبژێرە.'), 'info');
        e.preventDefault();
        return;
    }
    if (resolved && resolved.p) {
        var found = resolved.p;
        var foundUnit = resolved.unit;
        if (typeof window.productMatchesUnitFilter === 'function' && !window.productMatchesUnitFilter(found, foundUnit, false)) {
            if (window.showToast) window.showToast(rt('returns_unit_not_defined', 'ئەم یەکەیە بۆ ئەم ئایتمە پێناسە نەکراوە.'), 'warning');
            e.preventDefault();
            return;
        }
        var sData = soldItems[String(found.id)];
        var activePrice = window.returnsManualMode
            ? getReturnsPriceForUnit(found, foundUnit, null)
            : getReturnsPriceForUnit(found, foundUnit, sData);
        addToReturnsCartWithUnitFallback(found.id, foundUnit, activePrice);
        e.target.value = '';
        renderReturnsMenu();
        e.preventDefault();
        return;
    }
    if (window.showToast) window.showToast(rt('toast_error', 'ئەڤ کەرەستە نەهاتیە فرۆشتن یان بارکۆد/ناڤ نەدۆزرایەوە.'), 'warning');
    e.preventDefault();
};

window.getReturnsAvailablePieces = function(productId) {
    if (!window.db || !window.db.products) return 0;
    if (window.returnsManualMode) return Infinity;
    
    // Check if we have a customer or invoice filter
    const customerSelTop2 = document.getElementById('returns-debt-select');
    const customerSelBottom2 = document.getElementById('returns-debt-customer');
    const customerSel = (customerSelTop2 && customerSelTop2.value) ? customerSelTop2 : customerSelBottom2;
    const customerVal = customerSel ? customerSel.value : '';
    let customerName = null;
    let customerId = null;
    let isSpecificCustomer = false;
    
    if (customerVal && customerVal.startsWith('customer_')) {
        customerId = parseInt(customerVal.split('_')[1], 10);
        let cust = (window.db.customers || []).find(c => c.id === customerId);
        if (cust) customerName = cust.name;
        isSpecificCustomer = true;
    } else if (customerVal && customerVal.startsWith('user_')) {
        customerId = parseInt(customerVal.split('_')[1], 10);
        let usr = (window.db.users || []).find(u => u.id === customerId);
        if (usr) customerName = usr.name;
        isSpecificCustomer = true;
    } else if (customerVal && customerVal !== '' && !isNaN(parseInt(customerVal, 10))) {
        customerId = parseInt(customerVal, 10);
        let cust = (window.db.customers || []).find(c => c.id === customerId);
        if (cust) customerName = cust.name;
        isSpecificCustomer = true;
    } else if (customerVal && customerVal !== '') {
        isSpecificCustomer = true;
        if (customerSel.options && customerSel.options[customerSel.selectedIndex]) {
            customerName = customerSel.options[customerSel.selectedIndex].text.replace(' (Customer)', '').replace(' (Staff)', '').split(' - ')[0].trim();
        }
    }

    const invInput3 = document.getElementById('returns-new-invoice-ref') || document.getElementById('sales-return-invoice-ref');
    const invRaw3 = invInput3 && invInput3.value ? String(invInput3.value).trim() : '';
    const invId3 = invRaw3 ? resolveReturnsInvoiceToSaleId(invRaw3) : null;

    if (!isSpecificCustomer && invId3 == null) return Infinity; // No filter, no limit (standard return)

    let unitsInInvoice = 0;
    let totalSoldPieces = 0;
    getSalesListForReturns().forEach(sale => {
        let match = false;
        if (invId3 != null && Number(sale.id) === invId3) match = true;
        else if (invId3 == null && isSpecificCustomer) {
            if (sale.customer_id == customerId) match = true;
            else if (sale.customer === customerName) match = true;
        }

        let items = sale.items;
        if (typeof items === 'string') {
            try { items = JSON.parse(items); } catch(e) { items = []; }
        }
        if (match && items && Array.isArray(items)) {
            items.forEach(item => {
                let unitObj = (typeof getProductUnitFactors === 'function') ? getProductUnitFactors(item) : { piecesPerPack: 1, piecesPerCarton: 1 };
                let mult = 1;
                if (item.saleUnit === 'carton') mult = unitObj.piecesPerCarton || 1;
                else if (item.saleUnit === 'pack') mult = unitObj.piecesPerPack || 1;
                if (getSaleLineProductId(item) === String(productId)) {
                    const soldLineQty = Math.max(1, getSaleRowSoldQty(item));
                    const soldPieces = (mult * soldLineQty);
                    totalSoldPieces += soldPieces;
                    if (invId3 != null) unitsInInvoice += soldPieces;
                }
            });
        }
    });

    if (window.db.returns) {
         window.db.returns.forEach(ret => {
             let match = false;
             if (invId3 != null && Number(ret.sale_id) === invId3) match = true;
             else if (invId3 == null && isSpecificCustomer) {
                 if (ret.target_id == customerId) match = true;
             }
             
             let retItems = getParsedItems(ret);
             if (match && retItems.length) {
                 retItems.forEach(item => {
                     if (getSaleLineProductId(item) === String(productId)) {
                         let factors = (typeof getProductUnitFactors === 'function') ? getProductUnitFactors(item) : { piecesPerPack: 1, piecesPerCarton: 1 };
                         let mult = 1;
                         if (item.saleUnit === 'carton') mult = factors.piecesPerCarton || 1;
                         else if (item.saleUnit === 'pack') mult = factors.piecesPerPack || 1;
                        const returnedLineQty = Math.max(1, parseFloat(item.qty) || 1);
                        totalSoldPieces -= (mult * returnedLineQty);
                     }
                 });
             }
         });
    }

    const unreturnedForInvoice = Math.max(0, totalSoldPieces);
    let maxAllowed = unreturnedForInvoice;
    if (invId3 != null) {
        maxAllowed = Math.min(Math.max(0, unitsInInvoice), unreturnedForInvoice);
    }
    const rs = window._returnsSessionAvailability || {};
    if (invId3 != null && Number(rs.sale_id || 0) === Number(invId3) && rs.byProduct && rs.byProduct[String(productId)]) {
        const entry = rs.byProduct[String(productId)];
        const remaining = parseFloat(entry.remaining_pieces);
        if (!isNaN(remaining)) {
            maxAllowed = Math.min(maxAllowed, Math.max(0, remaining));
        } else {
            const fromSession = parseInt(entry.max_allowed_pieces, 10);
            if (!isNaN(fromSession)) maxAllowed = Math.min(maxAllowed, Math.max(0, fromSession));
        }
    }
    return Math.max(0, maxAllowed);
};

window.notifyReturnsQtyLimit = function(productName, maxQty, unit) {
    var unitLbl = unit || '';
    var msg = 'ناتوانیت زیاتر لە بڕی فرۆشراو بگەڕێنیتەوە.\n' +
        (productName || 'ئایتم') + ': کەمترین ' + String(Math.max(0, maxQty)) + ' ' + unitLbl;
    if (window.showToast) window.showToast('⚠️ ' + msg.replace('\n', ' — '), 'warning');
};

window.addToReturnsCartWithUnitFallback = function(productId, unit, customPrice) {
    var dbRef = window.db || (typeof db !== 'undefined' ? db : null);
    if (!dbRef || !dbRef.products) return false;
    var p = dbRef.products.find(function(x) { return String(x.id) === String(productId); });
    if (!p) return false;
    var tryUnits = [unit || 'piece', 'piece', 'pack', 'carton'].filter(function(u, i, arr) {
        return u && arr.indexOf(u) === i;
    });
    var i, u, existing, maxQty, tmpRow;
    for (i = 0; i < tryUnits.length; i++) {
        u = tryUnits[i];
        existing = (window.returnsCart || []).find(function(x) {
            return String(x.productId) === String(productId) && x.unit === u;
        });
        if (existing) {
            maxQty = window.getReturnsMaxQtyForItemRow(existing, existing.id);
            if ((parseFloat(existing.qty) || 0) < maxQty) {
                var keepPrice = (u === unit && customPrice !== undefined) ? customPrice : undefined;
                window.addToReturnsCart(productId, u, keepPrice);
                return true;
            }
            continue;
        }
        tmpRow = { productId: p.id, unit: u, qty: 0, id: '' };
        maxQty = window.getReturnsMaxQtyForItemRow(tmpRow, '');
        if (maxQty >= 1) {
            var priceArg = (u === unit && customPrice !== undefined) ? customPrice : undefined;
            window.addToReturnsCart(productId, u, priceArg);
            if (u !== unit && window.showToast) {
                window.showToast('یەکەی ' + getReturnsUnitLabel(p, u) + ' هەڵبژێردرا (بڕی ماوە بۆ ' + getReturnsUnitLabel(p, unit) + ' نەگونجا).', 'info');
            }
            return true;
        }
    }
    window.notifyReturnsQtyLimit(p.name, 0, unit || 'piece');
    return false;
};

window.handleReturnsProductCardClick = function(cardEl) {
    if (!cardEl) return;
    var pid = cardEl.getAttribute('data-product-id');
    if (!pid) return;
    var unit = cardEl.getAttribute('data-sale-unit') || window.returnsActiveUnit || 'piece';
    var price = parseFloat(cardEl.getAttribute('data-sale-price') || '0');
    window.addToReturnsCartWithUnitFallback(pid, unit, isNaN(price) ? undefined : price);
};

window.getReturnsMaxQtyForItemRow = function(item, excludeRowId) {
    if (!item) return 0;
    if (window.returnsManualMode) return Number.MAX_SAFE_INTEGER;
    const p = (window.db && window.db.products || []).find(function(x) { return String(x.id) === String(item.productId); });
    const factors = (typeof getProductUnitFactors === 'function') ? getProductUnitFactors(p) : { piecesPerPack: 1, piecesPerCarton: 1 };
    let piecesPerUnit = 1;
    if (item.unit === 'carton') piecesPerUnit = factors.piecesPerCarton || 1;
    else if (item.unit === 'pack') piecesPerUnit = factors.piecesPerPack || 1;
    piecesPerUnit = Math.max(1, parseInt(piecesPerUnit, 10) || 1);

    let availablePieces = window.getReturnsAvailablePieces(item.productId);
    let usedByOtherRows = 0;
    (window.returnsCart || []).forEach(function(x) {
        if (String(x.productId) !== String(item.productId)) return;
        if (excludeRowId && String(x.id) === String(excludeRowId)) return;
        usedByOtherRows += (x.totalPieces || x.qty || 0);
    });
    const remainingPiecesForThisRow = Math.max(0, availablePieces - usedByOtherRows);
    return Math.max(0, Math.floor(remainingPiecesForThisRow / piecesPerUnit));
};

window.addToReturnsCart = function(productId, unit, customPrice) {
    var dbRef = window.db || (typeof db !== 'undefined' ? db : null);
    if(!dbRef) return;
    if (!window.returnsCart) window.returnsCart = [];
    
    const p = dbRef.products.find(x => String(x.id) === String(productId));
    if(!p) return;
    
    const factors = (typeof getProductUnitFactors === 'function') ? getProductUnitFactors(p) : { piecesPerPack: 1, piecesPerCarton: 1 };
    let pc = parseFloat(p.cost) || 0;
    let pp = parseFloat(p.price) || 0;
    let price = customPrice !== undefined ? customPrice : pp;
    let cost = pc;

    if (unit === 'carton') {
        if (customPrice === undefined) price = (p.price_carton != null && parseFloat(p.price_carton) > 0) ? parseFloat(p.price_carton) : (pp * (factors.piecesPerCarton || 1));
        cost = (p.cost_carton != null && parseFloat(p.cost_carton) > 0) ? parseFloat(p.cost_carton) : (pc * (factors.piecesPerCarton || 1));
    } else if (unit === 'pack') {
        if (customPrice === undefined) price = (p.price_pack != null && parseFloat(p.price_pack) > 0) ? parseFloat(p.price_pack) : (pp * (factors.piecesPerPack || 1));
        cost = (p.cost_pack != null && parseFloat(p.cost_pack) > 0) ? parseFloat(p.cost_pack) : (pc * (factors.piecesPerPack || 1));
    }
    cost = Math.floor(cost);
    let piecesPerUnit = 1;
    if (unit === 'carton') piecesPerUnit = factors.piecesPerCarton || 1;
    else if (unit === 'pack') piecesPerUnit = factors.piecesPerPack || 1;

    let existing = window.returnsCart.find(x => String(x.productId) === String(productId) && x.unit === unit);
    if (existing && !window.returnsManualMode) {
        var maxForExisting = window.getReturnsMaxQtyForItemRow(existing, existing.id);
        if ((parseFloat(existing.qty) || 0) >= maxForExisting) {
            window.notifyReturnsQtyLimit(existing.name, maxForExisting, existing.unit || '');
            return;
        }
    }
    if (!existing && !window.returnsManualMode) {
        const tmpRow = { productId: p.id, unit: unit, qty: 0, id: '' };
        var maxForNew = window.getReturnsMaxQtyForItemRow(tmpRow, '');
        if (maxForNew < 1) {
            window.notifyReturnsQtyLimit(p.name, 0, unit || '');
            return;
        }
    }

    var subtotal, pct;
    if(existing) {
        existing.qty = normalizeReturnsQty(p, (existing.qty || 0) + 1);
        pct = (existing.discountPercent != null ? existing.discountPercent : 0) / 100;
        subtotal = existing.qty * price;
        existing.total = roundReturnsMoney(subtotal * (1 - pct));
        existing.totalCost = existing.qty * cost;
        existing.totalPieces = existing.qty * piecesPerUnit;
    } else {
        window.returnsCart.push({
            id: 'RET-' + Date.now() + Math.floor(Math.random()*1000),
            productId: p.id,
            name: p.name,
            unit: unit,
            saleUnit: unit,
            qty: normalizeReturnsQty(p, 1),
            price: price,
            cost: cost,
            discountPercent: 0,
            total: price,
            totalCost: cost,
            totalPieces: piecesPerUnit,
            pieces_per_pack: factors.ppp,
            packs_per_carton: factors.ppc,
            itemsPerCarton: factors.piecesPerCarton
        });
    }
    renderReturnsCart();
    scheduleReturnsRealtimeSync();
};

window.removeReturnsCartItem = function(id) {
    window.returnsCart = window.returnsCart.filter(x => x.id !== id);
    renderReturnsCart();
    scheduleReturnsRealtimeSync();
};

window.updateReturnsCartQty = function(id, val) {
    let item = window.returnsCart.find(x => x.id === id);
    if(item) {
        const p = window.db.products.find(x => String(x.id) === String(item.productId));
        let q = normalizeReturnsQty(p, val);
        if(isNaN(q) || q <= 0) {
            window.returnsCart = window.returnsCart.filter(x => x.id !== id);
            renderReturnsCart();
            scheduleReturnsRealtimeSync();
            return;
        }
        const factors = (typeof getProductUnitFactors === 'function') ? getProductUnitFactors(p) : { piecesPerPack: 1, piecesPerCarton: 1 };
        let piecesPerUnit = 1;
        if (item.unit === 'carton') piecesPerUnit = factors.piecesPerCarton || 1;
        else if (item.unit === 'pack') piecesPerUnit = factors.piecesPerPack || 1;

        // STRICT VALIDATION: hard cap at sold quantity
        if (!window.returnsManualMode) {
            var maxQty = window.getReturnsMaxQtyForItemRow(item, id);
            if (q > maxQty) {
                window.notifyReturnsQtyLimit(item.name, maxQty, item.unit || '');
                q = maxQty;
            }
        }
        if (q <= 0) {
            window.returnsCart = window.returnsCart.filter(x => x.id !== id);
            renderReturnsCart();
            scheduleReturnsRealtimeSync();
            return;
        }

        item.qty = q;
        var pct = ((item.discountPercent != null ? item.discountPercent : 0) / 100);
        item.total = roundReturnsMoney((q * (item.price || 0)) * (1 - pct));
        item.totalCost = q * (item.cost || 0);
        item.totalPieces = q * piecesPerUnit;
    }
    renderReturnsCart();
    scheduleReturnsRealtimeSync();
};
window.openReturnsCartQtyPrompt = function(id, currentQty) {
    var opener = window.openManualQtyPrompt;
    if (typeof opener !== 'function') return;
    opener(null, currentQty, function(v) {
        window.updateReturnsCartQty(id, v);
    });
};

window.updateReturnsCartDiscount = function(id, value) {
    var item = window.returnsCart.find(x => x.id === id);
    if(!item) return;
    var pct = Math.min(100, Math.max(0, parseFloat(value) || 0));
    item.discountPercent = pct;
    var subtotal = (item.qty || 0) * (item.price || 0);
    item.total = roundReturnsMoney(subtotal * (1 - pct / 100));
    renderReturnsCart();
};

window.updateReturnsCartPrice = function(id, value, rerender) {
    var item = window.returnsCart.find(x => x.id === id);
    if(!item) return;
    if (typeof rerender === 'undefined') rerender = true;
    var entered = Math.max(0, parseFloat(value) || 0);
    var p = Math.max(0, returnsDisplayToIqd(entered));
    item.price = p;
    var pct = (item.discountPercent != null ? item.discountPercent : 0) / 100;
    item.total = roundReturnsMoney(((item.qty || 0) * p) * (1 - pct));
    if (rerender) {
        renderReturnsCart();
        return;
    }
    var grandTotal = 0;
    window.returnsCart.forEach(function(r) {
        grandTotal += r.total || 0;
    });
    var rowTotalEl = document.querySelector('[data-returns-row-total="' + id + '"]');
    if (rowTotalEl) rowTotalEl.textContent = returnsFormatMoney(item.total || 0);
    var elTotal = document.getElementById('returns-bill-total');
    if (elTotal) elTotal.textContent = returnsFormatMoney(grandTotal);
    var elCash = document.getElementById('returns-cash-deducted');
    if (elCash) elCash.textContent = returnsFormatMoney(grandTotal);
    if (typeof window.updateReturnsDebtSummary === 'function') window.updateReturnsDebtSummary();
};

window.editReturnsCartPrice = function(id) {
    let item = window.returnsCart.find(x => x.id === id);
    if(!item) return;
    const defaultPrice = returnsIqdToDisplay(item.price || 0);
    let newPrice = prompt(isReturnsUsdMode() ? ("بهایێ نوی بنڤێسە $ (Price for " + item.name + "):") : ("بهایێ نوی بنڤێسە (Price for " + item.name + "):"), defaultPrice);
    if(newPrice !== null) {
        let entered = parseFloat(newPrice);
        if(!isNaN(entered) && entered >= 0) {
            let p = Math.max(0, returnsDisplayToIqd(entered));
            item.price = p;
            var pct = (item.discountPercent != null ? item.discountPercent : 0) / 100;
            item.total = roundReturnsMoney((item.qty * p) * (1 - pct));
            renderReturnsCart();
        }
    }
};

window.clearReturnsCart = function() {
    window.returnsCart = [];
    renderReturnsCart();
    scheduleReturnsRealtimeSync();
};

window.populateReturnsCustomers = function() {
    let opts = '<option value="">' + escapeHtml(rt('returns_select_payment', '')) + '</option>';
    if(window.db && window.db.customers) {
        window.db.customers.forEach(c => {
            opts += `<option value="${c.id}">${escapeHtml(c.name)} - ${escapeHtml(rt('returns_customer_debt_suffix', ''))} ${window.formatCurrency(c.balance || 0)}</option>`;
        });
    }

    // Populate top selector (in left panel)
    const selTop = document.getElementById('returns-debt-select');
    if (selTop) {
        selTop.innerHTML = '<option value="">' + escapeHtml(rt('returns_select_customer', '')) + '</option>';
        if(window.db && window.db.customers) {
            window.db.customers.forEach(c => {
                const opt = document.createElement('option');
                opt.value = c.id;
                opt.textContent = (c.name || '') + ' - ' + rt('returns_customer_debt_suffix', '') + ' ' + window.formatCurrency(c.balance || 0);
                selTop.appendChild(opt);
            });
        }
    }

    // Populate bottom selector (in bill panel)
    const sel = document.getElementById('returns-debt-customer');
    if(sel) {
        sel.innerHTML = opts;
        sel.addEventListener('change', renderReturnsCart);
    }
    var loaded = window._returnsLoadedSale || window.pendingReturnFromSale;
    if (loaded) selectReturnsCustomerFromSale(loaded);
};

window.renderReturnsCart = function(force) {
    var forceNow = force === true || arguments[0] === true;
    var _deb = forceNow ? 0 : ((typeof window.posTxnCartRenderDebounceMs === 'function') ? window.posTxnCartRenderDebounceMs() : 0);
    if (_deb > 0) {
        if (_returnsCartRenderTimer) clearTimeout(_returnsCartRenderTimer);
        _returnsCartRenderTimer = setTimeout(function () {
            _returnsCartRenderTimer = null;
            renderReturnsCartNow(true);
        }, _deb);
        return;
    }
    renderReturnsCartNow(forceNow);
};

function renderReturnsCartNow() {
    const list = document.getElementById('returns-bill-rows');
    if(!list) return;
    
    let totalReturnAmount = 0;
    let totalCostReturn = 0;
    let totalItems = 0;
    
    let netCost = 0;
    let totalPieces = 0;
    let html = '';
    
    window.returnsCart.forEach(item => {
        var pct = (item.discountPercent != null ? item.discountPercent : 0) / 100;
        var subtotal = (item.qty || 0) * (item.price || 0);
        var rowTotal = roundReturnsMoney(subtotal * (1 - pct));
        item.total = rowTotal;
        totalReturnAmount += rowTotal;
        totalCostReturn += item.totalCost;
        totalItems += item.qty;
        totalPieces += (item.totalPieces || item.qty);
        
        var unitIcon = (typeof window.getPosUnitIconHtml === 'function')
            ? window.getPosUnitIconHtml(item.unit || 'piece', true)
            : '';
        
        var discVal = item.discountPercent != null ? item.discountPercent : 0;
        var maxQtyForRow = window.getReturnsMaxQtyForItemRow(item, item.id);
        var plusDisabled = (!window.returnsManualMode && (parseFloat(item.qty) || 0) >= maxQtyForRow);
        var itemProd = (window.db && window.db.products) ? window.db.products.find(function(x) { return String(x.id) === String(item.productId); }) : null;
        var isWeightQty = isReturnsWeightProduct(itemProd);
        var qtyStep = '0.001';
        var qtyDelta = isWeightQty ? 0.25 : 1;
        var qtyVal = formatReturnsQtyInput(item.qty || 0, itemProd || item);
        var kiloQtyChips = '';
        if (typeof window.renderKiloQtyPresetChips === 'function') {
            kiloQtyChips = window.renderKiloQtyPresetChips(itemProd || item, function(v) {
                return "updateReturnsCartQty('" + item.id + "', " + v + ")";
            });
        }
        html += `
        <div class="returns-cart-row returns-cart-row-slim">
            <span class="returns-row-name" title="${escapeHtml(item.name)}">${unitIcon}${escapeHtml(item.name)}</span>
            <input type="number" class="returns-row-disc" min="0" max="100" step="0.5" value="${discVal}" oninput="updateReturnsCartDiscount('${item.id}', this.value)" onchange="updateReturnsCartDiscount('${item.id}', this.value)" onblur="updateReturnsCartDiscount('${item.id}', this.value)" onfocus="this.select()" title="داشکاندن">
            <input type="number" class="returns-row-price" min="0" step="${isReturnsUsdMode() ? '0.000001' : '0.01'}" value="${returnsIqdToDisplay(item.price || 0)}" oninput="updateReturnsCartPrice('${item.id}', this.value, false)" onchange="updateReturnsCartPrice('${item.id}', this.value, true)" onblur="updateReturnsCartPrice('${item.id}', this.value, true)" onfocus="this.select()" title="${isReturnsUsdMode() ? '$ (USD)' : 'نرخ'}">
            <div class="returns-row-qty-wrap">
                <button type="button" onclick="updateReturnsCartQty('${item.id}', ${Math.max(0, (item.qty || 0) - qtyDelta)})"><i class="fas fa-minus"></i></button>
                <input type="number" min="0" max="${window.returnsManualMode ? '' : maxQtyForRow}" step="${qtyStep}" inputmode="decimal" readonly value="${qtyVal}" onclick="openReturnsCartQtyPrompt('${item.id}', ${item.qty || 0}); return false;" onchange="updateReturnsCartQty('${item.id}', this.value)" onblur="updateReturnsCartQty('${item.id}', this.value)" oninput="updateReturnsCartQty('${item.id}', this.value)" onfocus="this.select()">
                <button type="button" onclick="updateReturnsCartQty('${item.id}', ${(item.qty || 0) + qtyDelta})" ${plusDisabled ? 'disabled title="گەهیشت ئەعلى بڕی مجاز"' : ''} style="${plusDisabled ? 'opacity:0.5;cursor:not-allowed;' : ''}"><i class="fas fa-plus"></i></button>
                ${kiloQtyChips}
            </div>
            <span class="returns-row-total" data-returns-row-total="${item.id}">${returnsFormatMoney(rowTotal)}</span>
            <button type="button" class="returns-row-del" onclick="removeReturnsCartItem('${item.id}')" title="سڕینەوە"><i class="fas fa-times"></i></button>
        </div>`;
    });
    
    list.innerHTML = html || '<div class="returns-empty-state"><i class="fas fa-shopping-basket"></i><span>' + rt('bill_empty', 'السلة فارغة') + '</span></div>';
    list.querySelectorAll('.returns-cart-row').forEach(function (row) {
        stampReturnsTxnMobileCartLabels(row);
    });
    
    // Update Summaries
    const elTotal = document.getElementById('returns-bill-total');
    if(elTotal) elTotal.textContent = returnsFormatMoney(totalReturnAmount);
    
    const selDebtCustomer = document.getElementById('returns-debt-customer');
    let isDebtReturn = selDebtCustomer && selDebtCustomer.value !== "";
    
    const elCash = document.getElementById('returns-cash-deducted');
    if(elCash) elCash.textContent = returnsFormatMoney(totalReturnAmount);
    
    const elProfit = document.getElementById('returns-profit-lost');
    if(elProfit) elProfit.textContent = returnsFormatMoney(totalReturnAmount - totalCostReturn);
    
    const elStock = document.getElementById('returns-stock-added');
    if(elStock) {
        let text = totalPieces + ' ' + getReturnsUnitLabel(null, 'piece') + ' (Base Units)';
        elStock.textContent = text;
    }
    if (typeof window.updateReturnsDebtSummary === 'function') window.updateReturnsDebtSummary();
    if (typeof window.updateTxnPeekBar === 'function') window.updateTxnPeekBar('returns-new');
    var _skipBounce = typeof window.isPosTxnLiteMode === 'function' && window.isPosTxnLiteMode();
    if (!_skipBounce && typeof window.bounceTxnSheet === 'function' && window.returnsCart && window.returnsCart.length) window.bounceTxnSheet('returns');
}

window.debouncedRenderReturnsMenu = function(val) {
    if(window._retMenuTimeout) clearTimeout(window._retMenuTimeout);
    var _mMs = (typeof window.posTxnMenuDebounceMs === 'function') ? window.posTxnMenuDebounceMs() : 300;
    window._retMenuTimeout = setTimeout(() => { renderReturnsMenu(val); }, _mMs);
};

function parseReturnsTargetId(raw) {
    var s = String(raw || '').trim();
    if (!s) return { id: 0, type: '' };
    if (s.indexOf('customer_') === 0) return { id: parseInt(s.split('_')[1], 10) || 0, type: 'customer' };
    if (s.indexOf('user_') === 0) return { id: parseInt(s.split('_')[1], 10) || 0, type: 'user' };
    return { id: parseInt(s, 10) || 0, type: 'customer' };
}

window.getSaleReturnFinancialSplit = function getSaleReturnFinancialSplit(returnTotal, sale) {
    var roundM = typeof roundMoney === 'function' ? roundMoney : function(x) { return Math.round(Number(x) * 1000) / 1000; };
    var total = roundM(Math.max(0, Number(returnTotal) || 0));
    if (!sale) return { paymentType: 'cash', debtAdjusted: 0, cashRefunded: total, fibRefunded: 0, effectivePaymentMethod: 'cash', openDebt: 0 };
    var saleTotal = roundM(Math.max(0, parseFloat(sale.total) || 0));
    var payMethod = String(sale.payment_method || 'cash').toLowerCase();
    if (payMethod === 'bank' || payMethod === 'bankcard' || payMethod === 'card') payMethod = 'fib';
    var paidCash = roundM(parseFloat(sale.paid_cash != null ? sale.paid_cash : 0) || 0);
    var paidBank = roundM(parseFloat(sale.paid_bank != null ? sale.paid_bank : (sale.bank_amount != null ? sale.bank_amount : 0)) || 0);
    var paidAmt = roundM(parseFloat(sale.paid_amount != null ? sale.paid_amount : (sale.cash_paid != null ? sale.cash_paid : 0)) || 0);
    var debtAmt = roundM(parseFloat(sale.debt_amount != null ? sale.debt_amount : (sale.debt_added != null ? sale.debt_added : 0)) || 0);
    var remaining = (sale.remaining_debt != null && sale.remaining_debt !== '')
        ? roundM(parseFloat(sale.remaining_debt) || 0)
        : null;
    var openDebt;
    if (remaining != null) openDebt = Math.max(0, remaining);
    else if (payMethod === 'debt') openDebt = Math.max(0, saleTotal);
    else if (payMethod === 'split' && debtAmt > 0) openDebt = Math.max(0, debtAmt);
    else {
        var cashPaid = paidAmt > 0 ? paidAmt : roundM(paidCash + paidBank);
        openDebt = Math.max(0, roundM(saleTotal - cashPaid));
    }
    var debtAdjusted = 0;
    var cashRefunded = total;
    var fibRefunded = 0;
    if (payMethod === 'fib') {
        debtAdjusted = 0;
        cashRefunded = 0;
        fibRefunded = total;
    } else {
        // Debt-first: clear unpaid remaining before any drawer cash-out.
        debtAdjusted = roundM(Math.min(total, openDebt));
        var nonDebt = roundM(Math.max(0, total - debtAdjusted));
        cashRefunded = nonDebt;
        if (paidCash + paidBank > 0.001 && nonDebt > 0.001) {
            var cashShare = paidCash / (paidCash + paidBank);
            cashRefunded = roundM(nonDebt * cashShare);
            fibRefunded = roundM(nonDebt - cashRefunded);
        }
    }
    var debtRatio = total > 0.0001 ? Math.min(1, debtAdjusted / total) : 0;
    var effectivePaymentMethod = debtRatio >= 0.999 ? 'debt' : (payMethod === 'fib' ? 'fib' : (debtRatio <= 0.001 ? 'cash' : 'split'));
    return { paymentType: payMethod, debtAdjusted: debtAdjusted, cashRefunded: cashRefunded, fibRefunded: fibRefunded, effectivePaymentMethod: effectivePaymentMethod, openDebt: openDebt };
}

window.updateReturnsDebtSummary = function() {
    const selTop = document.getElementById('returns-debt-select');
    const selFooter = document.getElementById('returns-debt-customer');
    if (selTop && selTop.value && selFooter) selFooter.value = selTop.value;
    const sel = (selTop && selTop.value) ? selTop : selFooter;
    const custId = sel && sel.value ? String(sel.value).trim() : '';
    const parsed = parseReturnsTargetId(custId);
    let oldDebt = 0;
    if (sel && sel.selectedOptions && sel.selectedOptions[0] && sel.selectedOptions[0].dataset && sel.selectedOptions[0].dataset.oldDebt) {
        oldDebt = parseFloat(sel.selectedOptions[0].dataset.oldDebt) || 0;
    } else if (parsed.id && window.db) {
        const customer = (window.db.customers || []).find(function(c) { return String(c.id) === String(parsed.id); });
        if (customer) oldDebt = parseFloat(customer.balance) || 0;
        else {
            const user = (window.db.users || []).find(function(u) { return String(u.id) === String(parsed.id); });
            if (user) oldDebt = parseFloat(user.balance) || 0;
        }
    }
    let totalReturn = 0;
    window.returnsCart.forEach(function(item) { totalReturn += item.total || 0; });
    var saleId = (typeof getCurrentReturnsSaleId === 'function') ? getCurrentReturnsSaleId() : null;
    var sale = saleId && window.db && window.db.sales ? window.db.sales.find(function(s) { return String(s.id) === String(saleId); }) : null;
    var split = getSaleReturnFinancialSplit(totalReturn, sale);
    var debtEffect = split.debtAdjusted;
    const newDebt = Math.max(0, oldDebt - debtEffect);
    const sym = (typeof getCurrencySymbol === 'function' ? getCurrencySymbol() : '') || '';
    const fmt = (typeof window.formatCurrency === 'function' ? window.formatCurrency : function(x) { return String(x); });
    const elOld = document.getElementById('returns-old-debt');
    const elTotalRet = document.getElementById('returns-total-return');
    const elNew = document.getElementById('returns-new-debt');
    if (elOld) elOld.textContent = fmt(oldDebt) + ' ' + sym;
    if (elTotalRet) {
        elTotalRet.textContent = split.cashRefunded > 0 && split.debtAdjusted > 0
            ? (fmt(split.cashRefunded) + ' نەقد + ' + fmt(split.debtAdjusted) + ' قەرز')
            : (fmt(totalReturn) + ' ' + sym);
    }
    if (elNew) {
        elNew.textContent = split.debtAdjusted <= 0 && split.cashRefunded > 0
            ? (fmt(oldDebt) + ' ' + sym + ' (قەرز ناگۆڕێت)')
            : (fmt(newDebt) + ' ' + sym);
        var compactRet = document.getElementById('returns-new-debt-compact');
        if (compactRet) compactRet.textContent = elNew.textContent;
    }
};

window.toggleReturnsDebtDetails = function(forceOpen) {
    var body = document.getElementById('returns-debt-expanded-rows');
    var btn = document.getElementById('btn-toggle-returns-debt');
    if (!body) return;
    var isCollapsed = body.classList.contains('is-collapsed');
    var shouldOpen = typeof forceOpen === 'boolean' ? forceOpen : isCollapsed;
    body.classList.toggle('is-collapsed', !shouldOpen);
    if (btn) {
        btn.setAttribute('aria-expanded', shouldOpen ? 'true' : 'false');
        var icon = btn.querySelector('.txn-details-chevron');
        if (icon) {
            icon.className = shouldOpen ? 'fas fa-chevron-up txn-details-chevron' : 'fas fa-chevron-down txn-details-chevron';
        }
    }
};

window.processReturnsCart = function() {
    if (typeof window.collapseTxnSheet === 'function') window.collapseTxnSheet('returns-new');
    if(window.returnsCart.length === 0) {
        if(window.showToast) window.showToast(rt('bill_empty', 'السلة فارغة'), 'warning');
        return; 
    }

    const invoiceRefInput = document.getElementById('returns-new-invoice-ref');
    const invoiceRef = invoiceRefInput ? invoiceRefInput.value.trim() : '';

    if (!invoiceRef && !window.returnsManualMode) {
        if (typeof window.isTxnMobileViewport === 'function' && window.isTxnMobileViewport()) {
            if (typeof window.highlightTxnMetaFields === 'function') {
                window.highlightTxnMetaFields('returns-new', ['returns-new-invoice-ref']);
            }
        }
        if(window.showToast) window.showToast('پێدڤیە ژمارا پسوولا فرۆتنێ بنڤیسی!', 'error');
        if(invoiceRefInput) invoiceRefInput.focus();
        return;
    }
    if (typeof window.clearTxnMetaErrors === 'function') window.clearTxnMetaErrors('returns-new');

    const doSubmit = () => {
        let totalReturnAmount = 0;
        window.returnsCart.forEach(item => {
            totalReturnAmount += item.total;
        });

        const debtSelTop = document.getElementById('returns-debt-select');
        const debtSelFooter = document.getElementById('returns-debt-customer');
        if (debtSelTop && debtSelTop.value && debtSelFooter) debtSelFooter.value = debtSelTop.value;
        const debtCustId = (debtSelTop && debtSelTop.value) ? debtSelTop.value : (debtSelFooter ? debtSelFooter.value : '');
        const note = document.getElementById('returns-note') ? document.getElementById('returns-note').value.trim() : '';

        // Prepare items for backend
        const itemsForBackend = window.returnsCart.map(item => {
            const p = (window.db && window.db.products) ? window.db.products.find(x => String(x.id) === String(item.productId)) : null;
            return {
                id: item.productId,
                name: item.name,
                qty: item.qty,
                price: item.price,
                cost: item.cost,
                saleUnit: item.unit,
                trackStock: p ? p.trackStock : true,
                pieces_per_pack: p ? (p.piecesPerPack || p.pieces_per_pack || 1) : 1,
                packs_per_carton: p ? (p.piecesPerCarton / (p.piecesPerPack || 1) || p.packs_per_carton || 1) : 1
            };
        });

        const saleId = window.returnsManualMode ? null : getCurrentReturnsSaleId();
        const syncPromise = (typeof window.syncReturnsRealtimeStock === 'function' && saleId) ? window.syncReturnsRealtimeStock(true) : Promise.resolve({ status: 'skip' });
        syncPromise.then(syncRes => {
            if (syncRes && syncRes.status === 'error') return;
            const formData = new FormData();
            formData.append('action', 'save_return');
            formData.append('total', totalReturnAmount);
            formData.append('items', JSON.stringify(itemsForBackend));
            formData.append('cashier', window.currentUser ? window.currentUser.name : 'System');
            if (saleId) formData.append('sale_id', String(saleId));
            
            let finalNote = note || rt('return_btn', 'مرتجع');
            if (invoiceRef) {
                finalNote = `ژمارا پسوولێ: ${invoiceRef} | ` + finalNote;
            }
            formData.append('note', finalNote);
            formData.append('invoice_ref', invoiceRef);
            formData.append('is_manual_return', window.returnsManualMode ? '1' : '0');
            formData.append('return_source', window.returnsManualMode ? 'manual_no_receipt' : 'invoice_linked');
            formData.append('manual_warning_ack', window.returnsManualMode ? '1' : '0');
            var parsedTarget = parseReturnsTargetId(debtCustId);
            var linkedSale = null;
            if (saleId) {
                if (typeof getRememberedReturnsSale === 'function') linkedSale = getRememberedReturnsSale(saleId);
                if (!linkedSale && window._returnsLoadedSale && String(window._returnsLoadedSale.id) === String(saleId)) {
                    linkedSale = window._returnsLoadedSale;
                }
                if (!linkedSale && window.db && window.db.sales) {
                    linkedSale = window.db.sales.find(function(s) { return String(s.id) === String(saleId); });
                }
            }
            var finSplit = getSaleReturnFinancialSplit(totalReturnAmount, linkedSale);
            var payMethodSend = finSplit.effectivePaymentMethod;
            var targetIdSend = 0;
            var targetTypeSend = '';
            if (linkedSale && (parseInt(linkedSale.customer_id, 10) || 0) > 0) {
                targetIdSend = parseInt(linkedSale.customer_id, 10) || 0;
                targetTypeSend = linkedSale.customer_type || 'customer';
            } else if (parsedTarget.id > 0) {
                targetIdSend = parsedTarget.id;
                targetTypeSend = parsedTarget.type || 'customer';
                if (!linkedSale) payMethodSend = 'debt';
            } else {
                payMethodSend = 'cash';
            }
            formData.append('payment_method', payMethodSend);
            if (saleId && linkedSale) {
                var fxBundle = Math.round(Number(linkedSale.fx_usd_rate) || 0);
                if (!(fxBundle >= 1000) && linkedSale.exchange_rate != null) {
                    var erOne = Number(linkedSale.exchange_rate);
                    if (isFinite(erOne) && erOne > 0) {
                        fxBundle = (erOne >= 10000) ? Math.round(erOne) : Math.round(erOne * 100);
                    }
                }
                if (fxBundle >= 1000) formData.append('fx_usd_rate', String(fxBundle));
                var fxMode = String(linkedSale.fx_currency_mode || '').toUpperCase();
                if (fxMode === 'USD' || fxMode === 'IQD') formData.append('fx_currency_mode', fxMode);
            }
            if (targetIdSend > 0) {
                formData.append('target_id', String(targetIdSend));
                formData.append('target_type', targetTypeSend || 'customer');
            }

            fetch('?action=save_return', { method: 'POST', body: formData })
            .then(r => r.json())
            .then(res => {
                if(res.status === 'success') {
                    if(window.showToast) window.showToast(rt('toast_saved', 'تم الحفظ'), 'success');
                    
                    const newRet = {
                        id: res.id,
                        total: totalReturnAmount,
                        items: itemsForBackend,
                        cashier: window.currentUser ? window.currentUser.name : 'System',
                        note: note || rt('return_btn', 'مرتجع'),
                        date: new Date().toISOString(),
                        sale_id: saleId || null,
                        is_manual_return: window.returnsManualMode ? 1 : 0,
                        payment_method: res.payment_method || payMethodSend,
                        fx_usd_rate: (linkedSale && linkedSale.fx_usd_rate != null) ? Math.round(Number(linkedSale.fx_usd_rate)) : null,
                        fx_currency_mode: (linkedSale && linkedSale.fx_currency_mode) ? String(linkedSale.fx_currency_mode).toUpperCase() : null,
                        exchange_rate: (linkedSale && linkedSale.exchange_rate != null) ? Number(linkedSale.exchange_rate) : null,
                        debt_adjusted: res.debt_adjusted != null ? res.debt_adjusted : finSplit.debtAdjusted,
                        cash_refunded: res.cash_refunded != null ? res.cash_refunded : finSplit.cashRefunded,
                        target_id: targetIdSend,
                        target_type: targetTypeSend
                    };
                    if(window.db && window.db.returns) window.db.returns.unshift(newRet);
                    if (res.customer_balance != null && targetIdSend > 0 && window.db) {
                        var cust = (window.db.customers || []).find(function(c) { return Number(c.id) === Number(targetIdSend); });
                        if (cust) cust.balance = parseFloat(res.customer_balance) || 0;
                        var usr = (window.db.users || []).find(function(u) { return Number(u.id) === Number(targetIdSend); });
                        if (usr) usr.balance = parseFloat(res.customer_balance) || 0;
                    } else if (targetIdSend > 0 && (res.debt_adjusted || 0) > 0 && window.db) {
                        var cust2 = (window.db.customers || []).find(function(c) { return Number(c.id) === Number(targetIdSend); });
                        if (cust2) cust2.balance = (parseFloat(cust2.balance) || 0) - (parseFloat(res.debt_adjusted) || 0);
                        var usr2 = (window.db.users || []).find(function(u) { return Number(u.id) === Number(targetIdSend); });
                        if (usr2) usr2.balance = (parseFloat(usr2.balance) || 0) - (parseFloat(res.debt_adjusted) || 0);
                    }

                    clearReturnsCart();
                    if (typeof clearReturnsInvoiceLoad === 'function') clearReturnsInvoiceLoad(false);
                    if (typeof window.collapseTxnSheet === 'function') window.collapseTxnSheet('returns');
                    if (typeof renderAll === 'function') renderAll(); 
                    if (typeof updateStats === 'function') updateStats();
                    
                    if (window.db && window.db.settings && window.db.settings.autoPrint) {
                        if (window.printReturnReceipt) window.printReturnReceipt(res.id);
                    }
                } else {
                    if(window.showToast) window.showToast(rt('toast_error', 'خطأ') + ': ' + (res.message || rt('toast_save_failed', 'فشل الحفظ')), 'error');
                }
            })
            .catch(err => {
                console.error('Return Error:', err);
                if(window.showToast) window.showToast(rt('toast_save_failed', 'پاراستن سەرنەکەفت'), 'error');
            });
        });
    };

    if (typeof window.posConfirm === 'function') {
        const title = rt('confirm_returns_title', 'پشتڕاستکرنا زڤڕاندنێ');
        let msg = rt('confirm_clear_cart', 'هەموو ئایتەمەکانی ئەم وەسڵە دەسڕدرێنەوە.');
        if (window.returnsManualMode) {
            msg = rt('confirm_returns_manual_warning', 'ئاگاداری: ئەڤ زڤڕاندنە بەبێ وەسڵە و دێ وەک Manual Return تۆمار بیت. هەمی ئایتمێن د سەبەتێ دا دێ هێنە تۆمارکرن.');
        }
        window.posConfirm({
            title: title,
            message: msg,
            tone: window.returnsManualMode ? 'warn' : 'info',
            confirmText: rt('confirm_returns_btn', 'بەڵێ، تۆمار بکە'),
            icon: 'fa-undo'
        }).then(confirmed => {
            if (confirmed) doSubmit();
        });
    } else {
        if (window.returnsManualMode) {
            if(!confirm('ئاگاداری: ئەڤ زڤڕاندنە بەبێ وەسڵە و دێ وەک Manual Return تۆمار بیت.')) return;
        }
        if(!confirm(rt('confirm_clear_cart', 'حذف الطلب؟'))) return;
        doSubmit();
    }
};


/** Sales-return product grid — one listener (weak laptops). */
(function bindReturnsProductGridClicks() {
    if (window.__returnsProductGridClickDelegate) return;
    window.__returnsProductGridClickDelegate = true;
    var lastTap = { key: '', at: 0 };
    function activateReturnCard(card, e) {
        if (!card) return;
        var pid = card.getAttribute('data-product-id');
        if (!pid) return;
        var key = pid + '|' + (card.getAttribute('data-sale-unit') || 'piece');
        var now = Date.now();
        if (lastTap.key === key && (now - lastTap.at) < 350) return;
        lastTap = { key: key, at: now };
        if (e) {
            e.preventDefault();
            e.stopPropagation();
        }
        if (typeof window.handleReturnsProductCardClick === 'function') {
            window.handleReturnsProductCardClick(card);
        } else if (typeof window.addToReturnsCartWithUnitFallback === 'function') {
            var unit = card.getAttribute('data-sale-unit') || 'piece';
            var price = parseFloat(card.getAttribute('data-sale-price') || '0');
            window.addToReturnsCartWithUnitFallback(pid, unit, isNaN(price) ? undefined : price);
        }
    }
    document.addEventListener('click', function (e) {
        var t = e.target;
        if (!t || !t.closest) return;
        var card = t.closest('#returns-products .txn-product-card--sales-return');
        if (!card) return;
        activateReturnCard(card, e);
    }, false);
})();

// Hook into app logic to initialize
function hookReturnsNav() {
    if (typeof window.nav === 'function' && !window._returnsHooked) {
        window._returnsHooked = true;
        
        // Ensure 'returns-new' is in the navigation order so it appears everywhere
        try {
            if (typeof renderMainNav === 'function') renderMainNav();
            if (typeof renderHomeView === 'function') renderHomeView();
            if (typeof renderRightSidebar === 'function') renderRightSidebar();
            if (typeof renderHomeIconsSettings === 'function') renderHomeIconsSettings();
        } catch(e) { console.error('Error updating nav order:', e); }

        const oldNav = window.nav;
        window.nav = function(arg) {
            oldNav(arg);
            if(arg === 'returns-new') {
                initReturnsScreen();
            }
        };
    } else if (!window._returnsHooked) {
        setTimeout(hookReturnsNav, 300);
    }
}
hookReturnsNav();
