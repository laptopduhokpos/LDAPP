<?php
/** Minimal CORS / OPTIONS for API (browser preflight). */
if (!function_exists('pos_api_cors_apply_headers')) {
    function pos_api_cors_apply_headers() {
        if (headers_sent()) {
            return;
        }
        $origin = isset($_SERVER['HTTP_ORIGIN']) ? trim((string)$_SERVER['HTTP_ORIGIN']) : '';
        if ($origin !== '') {
            header('Access-Control-Allow-Origin: ' . $origin);
            header('Vary: Origin');
            header('Access-Control-Allow-Credentials: true');
        } else {
            header('Access-Control-Allow-Origin: *');
        }
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
        $reqHdr = isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']) ? trim((string)$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']) : '';
        if ($reqHdr !== '') {
            header('Access-Control-Allow-Headers: ' . $reqHdr);
        } else {
            header('Access-Control-Allow-Headers: Content-Type, X-Requested-With, X-Debug-Session-Id, X-POS-Language, X-POS-Mobile-Pin, Authorization, Accept, Accept-Language');
        }
        header('Access-Control-Max-Age: 86400');
    }
}

if (!function_exists('pos_api_cors_handle_options_and_exit')) {
    function pos_api_cors_handle_options_and_exit() {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'OPTIONS') {
            return false;
        }
        pos_api_cors_apply_headers();
        header('Content-Length: 0');
        http_response_code(204);
        return true;
    }
}
