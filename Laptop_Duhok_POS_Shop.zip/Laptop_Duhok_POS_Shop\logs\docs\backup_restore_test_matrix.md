# Full Backup/Restore Test Matrix

## Scope
Validate that `export_full_backup` ZIP packages can restore full POS state on a different machine with no data loss.

## Pre-check
- Ensure source system has representative data in all modules (sales, purchases, returns, settings, logs, users, customers, stock movements).
- Ensure filesystem assets exist (if used): `uploads`, `public/uploads`, `public/images`, `assets`, `logs`.

## Test Cases

1. **Export ZIP package**
   - Action: run backup from admin UI (`Export ZIP`) or API (`?action=export_full_backup&zip=1`).
   - Expect:
     - Downloaded file is `.zip`.
     - ZIP contains `manifest.json` and `database/full_backup.json`.
     - ZIP contains `files/...` entries when assets exist.

2. **Manifest integrity**
   - Action: inspect `manifest.json`.
   - Expect:
     - `format` is `full_zip_package_v2`.
     - `database.sha256` present.
     - `table_counts` present for all exported tables.
     - Optional `files` list has `path`, `size`, `sha256`.

3. **Restore on target machine**
   - Action: upload ZIP in restore UI.
   - Expect:
     - Response status success.
     - Response includes `mode=package`.
     - Response includes `restored_tables`, `restored_files`, and `table_counts`.
     - App reloads and can log in with restored users.

4. **Data parity checks**
   - Action: compare source and target for key tables.
   - Expect:
     - Matching row counts for `sales`, `supplies`, `returns`, `purchase_returns`, `users`, `customers`, `settings`, `audit_logs`.
     - Financial totals in dashboards/reports are unchanged.

5. **Filesystem parity checks**
   - Action: verify restored file assets open correctly (logos, uploads, documents).
   - Expect:
     - Files are present and readable in expected paths.

6. **Corruption guard**
   - Action: modify ZIP contents (tamper `database/full_backup.json` or file bytes) then restore.
   - Expect:
     - Restore fails with integrity/checksum error.
     - Existing DB state remains unchanged.

7. **Legacy compatibility**
   - Action: restore old JSON backup and old ZIP-with-single-JSON backup.
   - Expect:
     - Restore succeeds via legacy path.

## Pass Criteria
- Full restore succeeds on clean target machine.
- Table counts and critical business data match source.
- Filesystem assets restored.
- Tampered backup is rejected safely.
