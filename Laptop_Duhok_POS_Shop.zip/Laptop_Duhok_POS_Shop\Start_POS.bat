@echo off
call "%~dp0POS_Start\Start_POS.bat"
