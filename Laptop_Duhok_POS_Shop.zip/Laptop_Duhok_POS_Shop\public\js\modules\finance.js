/**
 * Finance: debt, expenses, ledger.
 * Logic currently lives in app.js; can be moved here gradually.
 */
import { state } from './state.js';

// Placeholder: payDebt, renderDebtView, etc. remain in app.js.
