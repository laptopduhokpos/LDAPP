<?php
// POST: license, users, shifts
    $adminOnlyPostActions = ['add_user', 'update_user', 'delete_user', 'void_user', 'delete_all_users', 'save_settings', 'secret_set_currency_mode', 'secret_set_next_sale_id'];
    if (in_array($act, $adminOnlyPostActions, true)) {
        pos_session_require_login_json();
        if ($act === 'update_user') {
            if (!pos_session_is_admin() && !pos_session_has_perm('edit_staff')) pos_json_perm_denied();
        } else {
            if (!pos_session_is_admin()) pos_json_perm_denied();
        }
    }

    if ($act === 'redeem_activation_code') {
        pos_session_require_login_json();
        $serial = function_exists('pos_ensure_license_serial') ? (string)pos_ensure_license_serial($conn) : '';
        $code = trim((string)($_POST['code'] ?? ''));
        if ($serial === '' || strlen($serial) < 4) {
            echo json_encode(['status' => 'error', 'message' => 'ژمارەی دامەزراندن نەدۆزرایەوە.'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        if ($code === '') {
            echo json_encode(['status' => 'error', 'message' => 'کۆدی چالاککردن پێویستە.'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        if (!function_exists('pos_supabase_redeem_activation_code_remote')) {
            echo json_encode(['status' => 'error', 'message' => 'ڕێکخستنی سێرڤەر تەواو نییە.'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $r = pos_supabase_redeem_activation_code_remote($serial, $code);
        if (empty($r['ok'])) {
            $reason = isset($r['reason']) ? (string)$r['reason'] : 'error';
            $reasonMsgs = [
                'invalid_input' => 'کۆد یان سێریاڵ نادروستە.',
                'code_not_found' => 'کۆدی چالاککردن نەدۆزرایەوە.',
                'code_revoked' => 'ئەم کۆدە هەڵوەشاوە.',
                'code_already_used' => 'ئەم کۆدە پێشتر بەکارهاتووە.',
                'invalid_feature_key' => 'کۆدی تایبەتمەندی نادروستە.',
            ];
            echo json_encode([
                'status' => 'error',
                'reason' => $reason,
                'message' => $reasonMsgs[$reason] ?? 'چالاککردن سەرکەوتوو نەبوو.',
            ], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $productType = isset($r['product_type']) ? (string)$r['product_type'] : 'subscription';
        $tier = function_exists('pos_subscription_tier_normalize')
            ? pos_subscription_tier_normalize($r['tier'] ?? 'free')
            : 'free';
        if ($productType === 'feature') {
            if (function_exists('pos_subscription_save_tier_to_settings')) {
                pos_subscription_save_tier_to_settings($conn, $tier);
            }
            $fkey = isset($r['feature_key']) ? (string)$r['feature_key'] : '';
            if ($fkey !== '' && function_exists('pos_subscription_persist_purchased_feature')) {
                pos_subscription_persist_purchased_feature($conn, $fkey);
            }
            $featureLabels = [
                'enableTakeaway' => 'سیستەمێ جوملە',
                'takeawayAsWholesale' => 'سیستەمێ جوملە',
                'enableWholesale' => 'فرۆتنا ب کۆم',
                'showItemNoteIcon' => 'تێبینی لەسەر ئایتم',
                'showTables' => 'مێزەکان',
                'enableGift' => 'دیاری',
                'enableManualSale' => 'فرۆشتنی دەستی',
                'enableRecipe' => 'ڕەچەتە',
                'unlockStaffBeyondFive' => 'زیاتر لە ٥ کارمەند',
                'fabMenu' => 'مێنوی FAB',
                'enableDelivery' => 'گەیاندن',
                'requireOpeningBalancePrompt' => 'باڵانسی کردنەوەی شێفت',
                'requireEndShiftReconcilePrompt' => 'کۆتایی شێفت',
                'allowNegativeStock' => 'کۆگای نەرێنی',
                'enableMoneyRounding' => 'گەڕاندنی پارە',
                'showPaymentModal' => 'پەنجەرەی پارەدان',
                'enableMultiWarehouse' => 'کۆگای فرە',
                'showPrintNotePopup' => 'تێبینی پێش چاپ',
                'enableCustomerInstallments' => 'قستی کریار',
                'manufacturerSlot' => 'پاکێتا کۆمپانیا دروستکەر (تا ١٠٠ · $50 یەکجار)',
                'enablePurchaseBatch' => 'ژمارا وەجبێ (کڕین)',
                'enableTechSpecs' => 'مواسفات لاپتۆب / مۆبایل',
                'enableSaleFollowup' => 'پەیوەندیا پشتی فرۆتنێ (واتسئاپ)',
            ];
            $featPrice = function_exists('pos_premium_feature_price_usd')
                ? pos_premium_feature_price_usd($fkey)
                : (defined('POS_PREMIUM_FEATURE_PRICE_USD') ? (int) POS_PREMIUM_FEATURE_PRICE_USD : 50);
            $label = $featureLabels[$fkey] ?? $fkey;
            $payload = [
                'status' => 'success',
                'product_type' => 'feature',
                'feature_key' => $fkey,
                'tier' => $tier,
                'entitlements' => isset($r['entitlements']) && is_array($r['entitlements']) ? $r['entitlements'] : null,
            ];
            if ($fkey === 'manufacturerSlot' && function_exists('pos_load_app_settings_array') && function_exists('pos_manufacturer_slots_purchased')) {
                $st = pos_load_app_settings_array($conn);
                $packMax = defined('POS_MANUFACTURER_PACK_MAX') ? (int)POS_MANUFACTURER_PACK_MAX : 100;
                $payload['manufacturer_slots_purchased'] = $packMax;
                $payload['message'] = 'پاکێتا کۆمپانیا دروستکەر چالاک کرا — تا ' . $packMax . ' کۆمپانیا ($' . $featPrice . ' یەکجار).';
            } else {
                $payload['message'] = 'تایبەتمەندی چالاک کرا: ' . $label . ' ($' . $featPrice . ') — Pro پێویست نییە.';
            }
            echo json_encode($payload, JSON_UNESCAPED_UNICODE);
            exit();
        }
        if (function_exists('pos_subscription_save_tier_to_settings')) {
            pos_subscription_save_tier_to_settings($conn, $tier);
        }
        echo json_encode([
            'status' => 'success',
            'product_type' => 'subscription',
            'tier' => $tier,
            'entitlements' => isset($r['entitlements']) && is_array($r['entitlements']) ? $r['entitlements'] : null,
            'message' => $tier === 'pro_plus' ? 'Pro Plus چالاک کرا.' : 'Pro چالاک کرا.',
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if($act == 'send_pos_notification') {

        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        if (!pos_session_is_admin()) pos_json_perm_denied();

        $title = trim((string)($_POST['title'] ?? ''));
        $message = trim((string)($_POST['message'] ?? ''));
        $type = trim((string)($_POST['type'] ?? 'info'));
        $createdBy = trim((string)($_POST['created_by'] ?? 'Admin'));
        $targetType = trim((string)($_POST['target_type'] ?? 'global'));
        $targetDeviceId = trim((string)($_POST['target_device_id'] ?? ''));

        if ($title === '' || $message === '') {
            echo json_encode(["status"=>"error", "message"=>"title and message are required"]); exit();
        }
        if (!in_array($type, ['info', 'success', 'warning', 'error'], true)) $type = 'info';
        if (!in_array($targetType, ['global', 'device'], true)) $targetType = 'global';
        if ($targetType === 'device' && $targetDeviceId === '') {
            echo json_encode(["status"=>"error", "message"=>"target_device_id is required for device target"]); exit();
        }

        $conn->query("CREATE TABLE IF NOT EXISTS pos_notifications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(140) NOT NULL,
            message TEXT NOT NULL,
            type VARCHAR(20) NOT NULL DEFAULT 'info',
            target_type VARCHAR(20) NOT NULL DEFAULT 'global',
            target_device_id VARCHAR(120) NULL,
            created_by VARCHAR(120) NULL,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_pos_notif_target (target_type, target_device_id),
            INDEX idx_pos_notif_active (is_active, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $sql = "INSERT INTO pos_notifications (title, message, type, target_type, target_device_id, created_by, is_active, created_at)
                VALUES (?, ?, ?, ?, ?, ?, 1, NOW())";
        $stmt = $conn->prepare($sql);
        if (!$stmt) { echo json_encode(["status"=>"error", "message"=>"prepare failed"]); exit(); }
        $targetDeviceVal = ($targetType === 'device') ? substr($targetDeviceId, 0, 120) : null;
        $title = substr($title, 0, 140);
        $createdBy = substr($createdBy, 0, 120);
        $stmt->bind_param("ssssss", $title, $message, $type, $targetType, $targetDeviceVal, $createdBy);
        if (!$stmt->execute()) { echo json_encode(["status"=>"error", "message"=>$stmt->error]); exit(); }
        echo json_encode(["status"=>"success", "id"=>(int)$stmt->insert_id]); exit();
    }

    if($act == 'mark_pos_notifications_read') {

        header('Content-Type: application/json; charset=utf-8');
        $deviceId = trim((string)($_POST['device_id'] ?? ''));
        $rawIds = trim((string)($_POST['notification_ids'] ?? ''));
        if ($deviceId === '' || $rawIds === '') {
            echo json_encode(["status"=>"error", "message"=>"device_id and notification_ids are required"]); exit();
        }
        $deviceId = substr($deviceId, 0, 120);
        $rawParts = array_filter(array_map('trim', explode(',', $rawIds)), static function ($v) { return $v !== ''; });
        $uuidIds = [];
        $localIds = [];
        foreach ($rawParts as $part) {
            if (preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $part)) {
                $uuidIds[] = $part;
            } else {
                $n = (int)$part;
                if ($n > 0) $localIds[] = $n;
            }
        }

        if (!empty($uuidIds)) {
            $serial = function_exists('pos_ensure_license_serial') ? trim((string)pos_ensure_license_serial($conn)) : '';
            if ($serial !== '' && strlen($serial) >= 4 && function_exists('pos_supabase_mark_user_notifications_read_remote')) {
                pos_supabase_mark_user_notifications_read_remote($serial, $deviceId, $uuidIds);
            }
        }

        if (!empty($localIds)) {
            $conn->query("CREATE TABLE IF NOT EXISTS pos_notification_reads (
                id INT AUTO_INCREMENT PRIMARY KEY,
                notification_id INT NOT NULL,
                device_id VARCHAR(120) NOT NULL,
                read_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uq_notification_device (notification_id, device_id),
                INDEX idx_device_read (device_id, read_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

            $stmt = $conn->prepare("INSERT IGNORE INTO pos_notification_reads (notification_id, device_id, read_at) VALUES (?, ?, NOW())");
            if ($stmt) {
                foreach ($localIds as $nid) {
                    $stmt->bind_param("is", $nid, $deviceId);
                    $stmt->execute();
                }
            }
        }

        if (empty($uuidIds) && empty($localIds)) {
            echo json_encode(["status"=>"success"]); exit();
        }
        echo json_encode(["status"=>"success"]); exit();
    }
    
    if($act == 'login') {
        if (session_status() === PHP_SESSION_NONE && !headers_sent()) {
            session_start();
        }
        $pin = $_POST['pin'] ?? '';
        $uid = isset($_POST['userId']) ? (int)$_POST['userId'] : 0;

        if($uid > 0) {
            $stmt = $conn->prepare("SELECT id, name, role, hourlyRate, permissions FROM users WHERE id = ? AND pin = ?");
            $stmt->bind_param("is", $uid, $pin);
        } else {
            $stmt = $conn->prepare("SELECT id, name, role, hourlyRate, permissions FROM users WHERE pin = ?");
            $stmt->bind_param("s", $pin);
        }
        $stmt->execute();
        $res = $stmt->get_result();
        if($row = $res->fetch_assoc()) {
            if (session_status() === PHP_SESSION_NONE) { session_start(); }
            $_SESSION['user_id'] = (int)$row['id'];
            $_SESSION['user_name'] = $row['name'];
            $_SESSION['user_role'] = $row['role'];
            $_SESSION['user'] = $row;
            // FIX: Decode permissions immediately
            $row['permissions'] = json_decode($row['permissions'] ?? '[]', true);
            logAction($conn, $row['name'], 'login', 'User logged in successfully', (int)$row['id']);
            echo json_encode(["status"=>"success", "user"=>$row]); exit();
        } else {
            logAction($conn, 'Unknown', 'login_failed', "Failed login attempt (PIN)");
            echo json_encode(["status"=>"error", "message"=>"Invalid PIN"]); exit();
        }
        exit();
    }
    
    if($act == 'logout') {
        $_SESSION = [];
        if (ini_get("session.use_cookies")) { $p = session_get_cookie_params(); setcookie(session_name(), '', time()-42000, $p["path"], $p["domain"], $p["secure"], $p["httponly"]); }
        session_destroy();
        echo json_encode(["status"=>"success"]);
        exit();
    }

    // system_reset is handled early (after session_start) so response is always JSON
    
    // هەمی کارێن دی پێدڤی ب چوونەژوور هەیە
    // --- NEW: SHIFT HANDLERS ---
    if($act == 'start_shift') {
        $userId = (int)$_POST['userId'];
        $name = $_POST['name'];
        $rate = (float)$_POST['rate'];
        $openingIn = isset($_POST['opening_balance']) ? (float)$_POST['opening_balance'] : 0;
        list($opening,) = pos_debt_form_amounts_to_stored_iqd($conn, $openingIn, 0);
        $date = date('Y-m-d H:i:s');
        $shiftId = round(microtime(true) * 10000); // Create a large unique ID

        // First, ensure no other open shifts for this user (prepared statement)
        $stmt2 = $conn->prepare("UPDATE shifts SET endTime = NOW() WHERE userId = ? AND endTime IS NULL");
        $stmt2->bind_param("i", $userId);
        $stmt2->execute();

        $stmt = $conn->prepare("INSERT INTO shifts (id, userId, userName, startTime, hourlyRate, opening_balance) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sissdd", $shiftId, $userId, $name, $date, $rate, $opening);
        if($stmt->execute()) {
            echo json_encode(["status"=>"success", "id"=>$shiftId, "startTime"=>$date, "opening_balance"=>$opening]); exit();
        } else {
            echo json_encode(["status"=>"error", "message"=>$stmt->error]); exit();
        }
        exit();
    }

    if($act == 'get_shift_expected') {
        try {
            $userId = (int)($_POST['userId'] ?? 0);
            if ($userId <= 0) { echo json_encode(["status"=>"error", "message"=>"ID یا کارمەندی پێدڤیە"]); exit(); }
            $stmt = $conn->prepare("SELECT id, startTime, opening_balance FROM shifts WHERE userId = ? AND endTime IS NULL ORDER BY startTime DESC LIMIT 1");
            if (!$stmt) { echo json_encode(["status"=>"error", "message"=>"DB error: " . $conn->error]); exit(); }
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $res = $stmt->get_result();
            if(!$res || !$row = $res->fetch_assoc()) { echo json_encode(["status"=>"error", "message"=>"چ شیفتێن ڤەکری نینن"]); exit(); }
            $start = $row['startTime'];
            $opening = (float)$row['opening_balance'];
            $end = date('Y-m-d H:i:s');
            $ledgerNetSql = function_exists('pos_ledger_treasury_net_sql') ? pos_ledger_treasury_net_sql() : "SUM(CASE WHEN type IN ('sale','debt_payment_in','return_to_supplier') THEN amount WHEN type IN ('expense','purchase','debt_payment','refund','waste','void_sale') THEN -amount ELSE 0 END)";
            $stmtSum = $conn->prepare("SELECT 
                SUM(CASE WHEN type IN ('sale','debt_payment_in','return_to_supplier') THEN amount ELSE 0 END) as pos_in,
                SUM(CASE WHEN type IN ('expense','purchase','debt_payment','refund','waste','void_sale') THEN amount ELSE 0 END) as pos_out,
                {$ledgerNetSql} as net 
                FROM ledger WHERE date >= ? AND date <= ?");
            if (!$stmtSum) { echo json_encode(["status"=>"error", "message"=>"DB error: " . $conn->error]); exit(); }
            $stmtSum->bind_param("ss", $start, $end);
            $stmtSum->execute();
            $sumRes = $stmtSum->get_result();
            $net = 0;
            $posIn = 0;
            $posOut = 0;
            if ($sumRes && ($r = $sumRes->fetch_assoc())) {
                if (isset($r['net']) && $r['net'] !== null) $net = (float)$r['net'];
                if (isset($r['pos_in']) && $r['pos_in'] !== null) $posIn = (float)$r['pos_in'];
                if (isset($r['pos_out']) && $r['pos_out'] !== null) $posOut = (float)$r['pos_out'];
            }
            
            $stmtBank = $conn->prepare("SELECT COALESCE(SUM(paid_bank), 0) as bank_total FROM sales WHERE created_at >= ? AND created_at <= ?");
            if ($stmtBank) {
                $stmtBank->bind_param("ss", $start, $end);
                $stmtBank->execute();
                $bankRes = $stmtBank->get_result();
                if ($bankRes && ($b = $bankRes->fetch_assoc()) && isset($b['bank_total'])) {
                    $net -= (float)$b['bank_total'];
                }
            }

            $expected = $opening + $net;
            $original_expected = $expected;
            if ($expected < 0) {
                $expected = 0; // Prevent negative expected balance in database
            }
            echo json_encode(["status"=>"ok", "opening_balance"=>$opening, "expected"=>$expected, "original_expected"=>$original_expected, "shift_id"=>$row['id'], "startTime"=>$start, "pos_in"=>$posIn, "pos_out"=>$posOut]);
        } catch (Throwable $e) {
            echo json_encode(["status"=>"error", "message"=>"هەڵە د سێرڤەری دا: " . $e->getMessage()]);
        }
        exit();
    }

    if($act == 'end_shift') {
        $userId = (int)$_POST['userId'];
        $date = date('Y-m-d H:i:s');
        $fastClose = isset($_POST['fast_close']) && (string)$_POST['fast_close'] === '1';
        $closingActual = null;
        if (!$fastClose && isset($_POST['closing_balance_actual'])) {
            list($closingActual,) = pos_debt_form_amounts_to_stored_iqd($conn, (float)$_POST['closing_balance_actual'], 0);
        }
        $reconciledBy = isset($_POST['reconciled_by']) ? trim($_POST['reconciled_by']) : '';
        
        $stmt = $conn->prepare("SELECT id, startTime, opening_balance FROM shifts WHERE userId = ? AND endTime IS NULL ORDER BY startTime DESC LIMIT 1");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $res = $stmt->get_result();
        if(!$res || !$row = $res->fetch_assoc()) { 
            echo json_encode(["status"=>"success", "expected"=>0, "shortage"=>0, "surplus"=>0, "already_closed"=>true]); 
            exit(); 
        }
        $shiftId = $row['id'];

        if ($fastClose) {
            $stmt = $conn->prepare("UPDATE shifts SET endTime = ? WHERE id = ?");
            $stmt->bind_param("ss", $date, $shiftId);
            if ($stmt->execute()) {
                echo json_encode(["status"=>"success", "expected"=>0, "shortage"=>0, "surplus"=>0, "fast_close"=>true]);
                exit();
            }
            echo json_encode(["status"=>"error", "message"=>$stmt->error]);
            exit();
        }

        $start = $row['startTime'];
        $opening = (float)$row['opening_balance'];
        
        $ledgerNetSql = function_exists('pos_ledger_treasury_net_sql') ? pos_ledger_treasury_net_sql() : "SUM(CASE WHEN type IN ('sale','debt_payment_in','return_to_supplier') THEN amount WHEN type IN ('expense','purchase','debt_payment','refund','waste','void_sale') THEN -amount ELSE 0 END)";
        $stmtSum = $conn->prepare("SELECT {$ledgerNetSql} as net FROM ledger WHERE date >= ? AND date <= ?");
        $stmtSum->bind_param("ss", $start, $date);
        $stmtSum->execute();
        $sumRes = $stmtSum->get_result();
        $net = 0;
        if ($sumRes && ($r = $sumRes->fetch_assoc()) && isset($r['net']) && $r['net'] !== null) {
            $net = (float)$r['net'];
        }
        
        $stmtBank = $conn->prepare("SELECT COALESCE(SUM(paid_bank), 0) as bank_total FROM sales WHERE created_at >= ? AND created_at <= ?");
        if ($stmtBank) {
            $stmtBank->bind_param("ss", $start, $date);
            $stmtBank->execute();
            $bankRes = $stmtBank->get_result();
            if ($bankRes && ($b = $bankRes->fetch_assoc()) && isset($b['bank_total'])) {
                $net -= (float)$b['bank_total'];
            }
        }

        $expected = $opening + $net;
        if ($expected < 0) {
            $expected = 0; // Prevent negative expected balance in database
        }
        
        $shortage = 0; $surplus = 0;
        if($closingActual !== null) {
            $shortage = $expected > $closingActual ? $expected - $closingActual : 0;
            $surplus = $closingActual > $expected ? $closingActual - $expected : 0;
            $stmt = $conn->prepare("UPDATE shifts SET endTime = ?, closing_balance_expected = ?, closing_balance_actual = ?, shortage = ?, surplus = ?, reconciled_by = ? WHERE id = ?");
            $stmt->bind_param("sddddss", $date, $expected, $closingActual, $shortage, $surplus, $reconciledBy, $shiftId);
        } else {
            $stmt = $conn->prepare("UPDATE shifts SET endTime = ? WHERE id = ?");
            $stmt->bind_param("ss", $date, $shiftId);
        }
        if($stmt->execute()) {
            echo json_encode(["status"=>"success", "expected"=>$expected, "shortage"=>$shortage, "surplus"=>$surplus]); 
            exit();
        } else {
            echo json_encode(["status"=>"error", "message"=>$stmt->error]);
            exit();
        }
    }

    if($act == 'save_product') {
        
        header('Content-Type: application/json; charset=utf-8');
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_write_close();
        }
        if (function_exists('pos_ensure_product_catalog_columns')) {
            pos_ensure_product_catalog_columns($conn);
        }

        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        $sku = isset($_POST['sku']) ? trim((string)$_POST['sku']) : '';
        if (strlen($sku) > 64) {
            $sku = substr($sku, 0, 64);
        }
        $name = isset($_POST['name']) ? trim($_POST['name']) : '';
        
        // Jewelry defaults ONLY when shop is in jewelry mode — never alter market/restaurant products
        $isJewelryShop = false;
        if (function_exists('pos_load_app_settings_array')) {
            $stArrJew = pos_load_app_settings_array($conn);
            $isJewelryShop = (isset($stArrJew['systemMode']) && strtolower(trim((string)$stArrJew['systemMode'])) === 'jewelry');
        }

        $barcode = isset($_POST['barcode']) ? trim($_POST['barcode']) : '';
        $price = roundMoney(isset($_POST['price']) ? $_POST['price'] : 0);
        // Optional name: allow empty name when barcode + price provided (client checkbox «بێ ناو»)
        if (!$isJewelryShop && $name === '') {
            if ($barcode !== '' && (float)$price > 0) {
                $priceLbl = function_exists('formatMoneyDisplay')
                    ? formatMoneyDisplay($price)
                    : rtrim(rtrim(number_format((float)$price, 3, '.', ''), '0'), '.');
                $name = $barcode . ' · ' . $priceLbl;
            } else {
                echo json_encode(["status"=>"error", "message"=>"ناڤێ ئایتمی ئیجبارییە — یان بارکۆد و نرخ بنووسە بۆ بێ ناو."]);
                exit();
            }
        }
        if (function_exists('pos_can_use_tech_specs') && pos_can_use_tech_specs($conn)
            && function_exists('pos_looks_like_dumped_tech_specs') && pos_looks_like_dumped_tech_specs($name)
            && function_exists('pos_parse_tech_specs_from_text')) {
            $parsedDump = pos_parse_tech_specs_from_text($name);
            if (function_exists('pos_tech_specs_has_content_arr') && pos_tech_specs_has_content_arr($parsedDump)) {
                if (!empty($parsedDump['title']) && function_exists('pos_tech_specs_clip')) {
                    $name = pos_tech_specs_clip((string)$parsedDump['title'], 255);
                }
                $postedSpecs = trim((string)($_POST['tech_specs'] ?? ''));
                if ($postedSpecs === '' || $postedSpecs === '{}') {
                    $payloadDump = [];
                    foreach (['cpu', 'ram', 'storage', 'gpu', 'screen', 'summary', 'extra'] as $sk) {
                        if (!empty($parsedDump[$sk])) {
                            $payloadDump[$sk] = $parsedDump[$sk];
                        }
                    }
                    if ($payloadDump) {
                        $_POST['tech_specs'] = json_encode($payloadDump, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                    }
                }
            }
        }
        $cost = roundMoney(isset($_POST['cost']) ? $_POST['cost'] : 0);
        $qty = isset($_POST['qty']) ? $_POST['qty'] : 0;
        $cat = isset($_POST['category']) ? $_POST['category'] : '';
        $supp = isset($_POST['supplier']) ? $_POST['supplier'] : '';
        $manufacturer = isset($_POST['manufacturer']) ? trim((string)$_POST['manufacturer']) : '';
        if (strlen($manufacturer) > 100) $manufacturer = substr($manufacturer, 0, 100);
        $track = isset($_POST['trackStock']) ? $_POST['trackStock'] : 0;
        $minStock = isset($_POST['minStock']) && $_POST['minStock'] !== '' ? (int)$_POST['minStock'] : 5;
        if ($minStock < 0) $minStock = 5;
        $expiry_alert_days = isset($_POST['expiry_alert_days']) && $_POST['expiry_alert_days'] !== '' ? (int)$_POST['expiry_alert_days'] : 30;
        if ($expiry_alert_days <= 0) $expiry_alert_days = 30;
        $metal_type = isset($_POST['metal_type']) ? strtolower(trim((string)$_POST['metal_type'])) : '';
        if ($metal_type !== 'gold' && $metal_type !== 'silver') $metal_type = '';
        $karat = null;
        if (($metal_type === 'gold' || $metal_type === 'silver') && isset($_POST['karat']) && $_POST['karat'] !== '') {
            $karat = round((float)$_POST['karat'], 2);
            if ($karat <= 0) $karat = null;
        }
        $weight_grams = isset($_POST['weight_grams']) ? round((float)$_POST['weight_grams'], 3) : 0;
        if ($weight_grams < 0) $weight_grams = 0;
        $making_charge = isset($_POST['making_charge']) ? roundMoney($_POST['making_charge']) : 0;
        if ($making_charge < 0) $making_charge = 0;
        $jewelry_price_mode = isset($_POST['jewelry_price_mode']) ? strtolower(trim((string)$_POST['jewelry_price_mode'])) : 'fixed';
        if ($jewelry_price_mode !== 'by_weight' && $jewelry_price_mode !== 'fixed') $jewelry_price_mode = 'fixed';
        // Jewelry defaults ONLY when shop is in jewelry mode — never alter market/restaurant products
        if (!$isJewelryShop) {
            $metal_type = '';
            $karat = null;
            $weight_grams = 0.0;
            $making_charge = 0.0;
            $jewelry_price_mode = 'fixed';
            $is_jewelry_set = 0;
        } else {
            // Jewelry shop safety: grams without metal → silver; grams+metal → by_weight unless explicitly fixed
            if ($weight_grams > 0 && $metal_type === '') {
                $metal_type = 'silver';
            }
            if ($metal_type !== '' && $weight_grams > 0) {
                $postedMode = isset($_POST['jewelry_price_mode']) ? strtolower(trim((string)$_POST['jewelry_price_mode'])) : '';
                if ($postedMode !== 'fixed') {
                    $jewelry_price_mode = 'by_weight';
                } else {
                    $jewelry_price_mode = 'fixed';
                }
            }
            if ($metal_type === '') $jewelry_price_mode = 'fixed';
            $is_jewelry_set = (!empty($_POST['is_jewelry_set']) && (int)$_POST['is_jewelry_set'] === 1) ? 1 : 0;
        }
        if ($is_jewelry_set) {
            $track = 0;
            if (isset($_POST['jewelry_set_price']) && $_POST['jewelry_set_price'] !== '') {
                $setPricePost = roundMoney($_POST['jewelry_set_price']);
                if ($setPricePost > 0) {
                    $price = $setPricePost;
                }
            }
        }
        $unitType = isset($_POST['unitType']) ? $_POST['unitType'] : 'carton';
        $qty_mode = isset($_POST['qty_mode']) ? strtolower(trim((string)$_POST['qty_mode'])) : '';
        if ($qty_mode !== 'piece' && $qty_mode !== 'kilo') {
            $qty_mode = ($unitType === 'kilo') ? 'kilo' : 'piece';
        }
        $qty = normalizeQtyForProductData(['qty_mode' => $qty_mode], $qty);
        $expiry = normalizeProductCatalogExpiry($_POST['expiry'] ?? '');
        $takeawayPrice = roundMoney(isset($_POST['takeawayPrice']) ? $_POST['takeawayPrice'] : 0);
        $takeawayPricePack = roundMoney(isset($_POST['takeawayPrice_pack']) ? $_POST['takeawayPrice_pack'] : 0);
        $takeawayPriceCarton = roundMoney(isset($_POST['takeawayPrice_carton']) ? $_POST['takeawayPrice_carton'] : 0);
        $wholesaleQty = isset($_POST['wholesaleQty']) ? (int)$_POST['wholesaleQty'] : 0;
        $wholesalePrice = roundMoney(isset($_POST['wholesalePrice']) ? $_POST['wholesalePrice'] : 0);
        $itemType = isset($_POST['item_type']) && in_array($_POST['item_type'], ['perishable', 'constant']) ? $_POST['item_type'] : 'constant';
        $user = $_POST['user'] ?? 'System'; // Track who is editing
        // Multi-level units
        $pieces_per_pack = isset($_POST['pieces_per_pack']) ? max(1, (int)$_POST['pieces_per_pack']) : 1;
        $packs_per_carton = isset($_POST['packs_per_carton']) ? max(1, (int)$_POST['packs_per_carton']) : 1;
        $barcode_pack = isset($_POST['barcode_pack']) ? trim($_POST['barcode_pack']) : '';
        $barcode_carton = isset($_POST['barcode_carton']) ? trim($_POST['barcode_carton']) : '';
        $price_pack = (isset($_POST['price_pack']) && $_POST['price_pack'] !== '') ? roundMoney($_POST['price_pack']) : null;
        $price_carton = (isset($_POST['price_carton']) && $_POST['price_carton'] !== '') ? roundMoney($_POST['price_carton']) : null;
        $cost_pack = (isset($_POST['cost_pack']) && $_POST['cost_pack'] !== '') ? roundMoney($_POST['cost_pack']) : null;
        $cost_carton = (isset($_POST['cost_carton']) && $_POST['cost_carton'] !== '') ? roundMoney($_POST['cost_carton']) : null;
        $unit_show_pack = array_key_exists('unit_show_pack', $_POST) ? (((int)$_POST['unit_show_pack']) ? 1 : 0) : 1;
        $unit_show_carton = array_key_exists('unit_show_carton', $_POST) ? (((int)$_POST['unit_show_carton']) ? 1 : 0) : 1;
        $unit_name_piece = isset($_POST['unit_name_piece']) ? trim((string)$_POST['unit_name_piece']) : '';
        $unit_name_pack = isset($_POST['unit_name_pack']) ? trim((string)$_POST['unit_name_pack']) : '';
        $unit_name_carton = isset($_POST['unit_name_carton']) ? trim((string)$_POST['unit_name_carton']) : '';
        $forSale = !isset($_POST['forSale']) || (int)$_POST['forSale'] !== 0 ? 1 : 0;
        $note = isset($_POST['note']) ? substr(trim((string)$_POST['note']), 0, 255) : '';
        if (strlen($unit_name_piece) > 100) $unit_name_piece = substr($unit_name_piece, 0, 100);
        if (strlen($unit_name_pack) > 100) $unit_name_pack = substr($unit_name_pack, 0, 100);
        if (strlen($unit_name_carton) > 100) $unit_name_carton = substr($unit_name_carton, 0, 100);

        if ($is_jewelry_set) {
            $track = 0;
            $unit_show_pack = 0;
            $unit_show_carton = 0;
            $pieces_per_pack = 1;
            $packs_per_carton = 1;
            $barcode_pack = '';
            $barcode_carton = '';
            $price_pack = null;
            $price_carton = null;
            $cost_pack = null;
            $cost_carton = null;
        }

        if (!$unit_show_pack) {
            $barcode_pack = '';
            $price_pack = null;
            $cost_pack = null;
            if (!$unit_show_carton) {
                $pieces_per_pack = 1;
            }
        }
        if (!$unit_show_carton) {
            $barcode_carton = '';
            $price_carton = null;
            $cost_carton = null;
            $packs_per_carton = 1;
        }
        if (!$unit_show_pack && !$unit_show_carton) {
            $pieces_per_pack = 1;
            $packs_per_carton = 1;
        }
        if (!$unit_show_pack && $unit_show_carton) {
            $packs_per_carton = 1;
        }
        if ($unit_show_pack && !$unit_show_carton) {
            $packs_per_carton = 1;
        }
        if ($qty_mode === 'kilo') {
            $unit_show_pack = 0;
            $unit_show_carton = 0;
            $pieces_per_pack = 1;
            $packs_per_carton = 1;
            $unitType = 'kilo';
            if ($unit_name_piece === '') $unit_name_piece = 'كيلو';
        } else {
            $unitType = 'carton';
        }
        $pieces_per_pack = max(1, (int)$pieces_per_pack);
        $packs_per_carton = max(1, (int)$packs_per_carton);
        $itemsPerCarton = $pieces_per_pack * $packs_per_carton;

        $appSettings = pos_load_app_settings_array($conn);
        $currencyMode = pos_settings_currency_mode_from_array($appSettings);
        $usdRatePerOne = pos_settings_usd_rate_per_one_from_array($appSettings);
        $price_usd = null;
        $cost_usd = null;
        $price_pack_usd = null;
        $price_carton_usd = null;
        $cost_pack_usd = null;
        $cost_carton_usd = null;
        $baseCurrency = pos_normalize_currency_mode(isset($_POST['base_currency']) ? $_POST['base_currency'] : $currencyMode);
        $writeUsdFields = ($baseCurrency === 'USD' && $usdRatePerOne > 0);
        if ($writeUsdFields) {
            $price_usd = pos_post_usd_decimal_optional('price_usd');
            $postedBasePriceEarly = function_exists('pos_post_usd_decimal_optional') ? pos_post_usd_decimal_optional('base_price') : null;
            if ($postedBasePriceEarly !== null && $postedBasePriceEarly > 0) {
                $price_usd = $postedBasePriceEarly;
            }
            if ($price_usd !== null && $usdRatePerOne > 0 && function_exists('pos_usd_value_looks_like_iqd_snapshot')
                && pos_usd_value_looks_like_iqd_snapshot($price_usd, (float)$price, $usdRatePerOne)) {
                $price_usd = pos_round_usd_catalog_store((float)$price_usd / $usdRatePerOne);
            }
            if ($price_usd === null) {
                $price_usd = pos_round_usd_catalog_store((float)$price / $usdRatePerOne);
            }
            $cost_usd = pos_post_usd_decimal_optional('cost_usd');
            if ($cost_usd === null) {
                $cost_usd = pos_round_usd_catalog_store((float)$cost / $usdRatePerOne);
            }
            if ($unit_show_pack) {
                $price_pack_usd = pos_post_usd_decimal_optional('price_pack_usd');
                if ($price_pack_usd === null && $price_pack !== null) {
                    $price_pack_usd = pos_round_usd_catalog_store((float)$price_pack / $usdRatePerOne);
                }
                $cost_pack_usd = pos_post_usd_decimal_optional('cost_pack_usd');
                if ($cost_pack_usd === null && $cost_pack !== null) {
                    $cost_pack_usd = pos_round_usd_catalog_store((float)$cost_pack / $usdRatePerOne);
                }
            }
            if ($unit_show_carton) {
                $price_carton_usd = pos_post_usd_decimal_optional('price_carton_usd');
                if ($price_carton_usd === null && $price_carton !== null) {
                    $price_carton_usd = pos_round_usd_catalog_store((float)$price_carton / $usdRatePerOne);
                }
                $cost_carton_usd = pos_post_usd_decimal_optional('cost_carton_usd');
                if ($cost_carton_usd === null && $cost_carton !== null) {
                    $cost_carton_usd = pos_round_usd_catalog_store((float)$cost_carton / $usdRatePerOne);
                }
            }
            if ($price_usd !== null) {
                $price = (int)round((float)$price_usd * $usdRatePerOne);
            }
            if ($cost_usd !== null) {
                $cost = (int)round((float)$cost_usd * $usdRatePerOne);
            }
            if ($unit_show_pack && $price_pack_usd !== null) {
                $price_pack = (int)round((float)$price_pack_usd * $usdRatePerOne);
            }
            if ($unit_show_carton && $price_carton_usd !== null) {
                $price_carton = (int)round((float)$price_carton_usd * $usdRatePerOne);
            }
            if ($unit_show_pack && $cost_pack_usd !== null) {
                $cost_pack = (int)round((float)$cost_pack_usd * $usdRatePerOne);
            }
            if ($unit_show_carton && $cost_carton_usd !== null) {
                $cost_carton = (int)round((float)$cost_carton_usd * $usdRatePerOne);
            }
        } else {
            $price = (int)round((float)$price);
            $cost = (int)round((float)$cost);
            if ($price_pack !== null && $price_pack !== '') $price_pack = (int)round((float)$price_pack);
            if ($price_carton !== null && $price_carton !== '') $price_carton = (int)round((float)$price_carton);
            if ($cost_pack !== null && $cost_pack !== '') $cost_pack = (int)round((float)$cost_pack);
            if ($cost_carton !== null && $cost_carton !== '') $cost_carton = (int)round((float)$cost_carton);
        }

        $postedBasePrice = function_exists('pos_post_usd_decimal_optional') ? pos_post_usd_decimal_optional('base_price') : null;
        $postedBaseCost = function_exists('pos_post_usd_decimal_optional') ? pos_post_usd_decimal_optional('base_cost') : null;
        if ($baseCurrency === 'USD') {
            $basePrice = ($price_usd !== null) ? (float)$price_usd : (($postedBasePrice !== null) ? (float)$postedBasePrice : 0);
            $baseCost = ($cost_usd !== null) ? (float)$cost_usd : (($postedBaseCost !== null) ? (float)$postedBaseCost : 0);
            if ($price_usd === null) $price_usd = $basePrice;
            if ($cost_usd === null) $cost_usd = $baseCost;
        } else {
            $basePrice = $postedBasePrice !== null ? (float)$postedBasePrice : (float)$price;
            $baseCost = $postedBaseCost !== null ? (float)$postedBaseCost : (float)$cost;
        }
        
        $debtWarning = null;
        $conn->begin_transaction();
        try {
            if($id > 0) {
                $oldStmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
                $oldStmt->bind_param("i", $id);
                $oldStmt->execute();
                $oldRes = $oldStmt->get_result();
                $old = $oldRes ? $oldRes->fetch_assoc() : null;
                $changes = [];
                if ($old) {
                    $tb = static function ($x) {
                        return trim((string)($x ?? ''));
                    };
                    if (abs((float)$old['price'] - (float)$price) > 0.01) {
                        $changes[] = "نرخ: " . number_format((float)$old['price']) . " → " . number_format((float)$price);
                    }
                    if (abs((float)$old['cost'] - (float)$cost) > 0.01) {
                        $changes[] = "کرین: " . number_format((float)$old['cost']) . " → " . number_format((float)$cost);
                    }
                    $trackOld = !empty($old['trackStock']);
                    $trackNew = !empty($track);
                    if ($trackOld !== $trackNew) {
                        $changes[] = $trackNew ? 'Stock tracking ON' : 'Stock tracking OFF';
                    }
                    if (($trackOld || $trackNew) && abs((float)$old['qty'] - (float)$qty) > 0.0001) {
                        $changes[] = "کۆگە: {$old['qty']} → $qty";
                    }
                    if (($old['name'] ?? '') != $name) {
                        $changes[] = "ناڤ گۆڕا";
                    }
                    if ($tb($old['barcode'] ?? '') !== $tb($barcode)) {
                        $changes[] = "Barcode changed";
                    }
                    if ($tb($old['sku'] ?? '') !== $tb($sku)) {
                        $changes[] = "SKU changed";
                    }
                    if ($tb($old['category'] ?? '') !== $tb($cat)) {
                        $changes[] = "Category changed";
                    }
                    if ($tb($old['supplier'] ?? '') !== $tb($supp)) {
                        $changes[] = "Supplier changed";
                    }
                    if ($tb($old['manufacturer'] ?? '') !== $tb($manufacturer)) {
                        $changes[] = "Manufacturer changed";
                    }
                    if ($tb($old['expiry'] ?? '') !== $tb($expiry)) {
                        $changes[] = "Expiry changed";
                    }
                    $qtyModeOld = isset($old['qty_mode']) ? strtolower(trim((string)$old['qty_mode'])) : '';
                    if ($qtyModeOld !== $qty_mode) {
                        $changes[] = "Qty mode: {$qtyModeOld} -> {$qty_mode}";
                    }
                    if (abs((float)($old['takeawayPrice'] ?? 0) - (float)$takeawayPrice) > 0.01) {
                        $changes[] = "Takeaway price updated";
                    }
                    if (abs((float)($old['takeawayPrice_pack'] ?? 0) - (float)$takeawayPricePack) > 0.01
                        || abs((float)($old['takeawayPrice_carton'] ?? 0) - (float)$takeawayPriceCarton) > 0.01) {
                        $changes[] = "Takeaway unit prices updated";
                    }
                    if ((int)($old['wholesaleQty'] ?? 0) !== (int)$wholesaleQty || abs((float)($old['wholesalePrice'] ?? 0) - (float)$wholesalePrice) > 0.01) {
                        $changes[] = "Wholesale settings changed";
                    }
                    $itemTypeOld = isset($old['item_type']) ? $old['item_type'] : 'constant';
                    if ($itemTypeOld !== $itemType) {
                        $changes[] = "Item type: {$itemTypeOld} -> {$itemType}";
                    }
                    if ((int)($old['pieces_per_pack'] ?? 1) !== (int)$pieces_per_pack || (int)($old['packs_per_carton'] ?? 1) !== (int)$packs_per_carton) {
                        $changes[] = "Unit conversion changed";
                    }
                    if ($tb($old['barcode_pack'] ?? '') !== $tb($barcode_pack) || $tb($old['barcode_carton'] ?? '') !== $tb($barcode_carton)) {
                        $changes[] = "Pack/Carton barcode changed";
                    }
                    if ((int)($old['unit_show_pack'] ?? 1) !== (int)$unit_show_pack || (int)($old['unit_show_carton'] ?? 1) !== (int)$unit_show_carton) {
                        $changes[] = "Pack/Carton visibility changed";
                    }
                    $ppOld = isset($old['price_pack']) ? (float)$old['price_pack'] : null;
                    $pcOld = isset($old['price_carton']) ? (float)$old['price_carton'] : null;
                    $ppNew = $price_pack !== null ? (float)$price_pack : null;
                    $pcNew = $price_carton !== null ? (float)$price_carton : null;
                    if (($ppOld === null && $ppNew !== null) || ($ppOld !== null && $ppNew === null)
                        || ($ppOld !== null && $ppNew !== null && abs($ppOld - $ppNew) > 0.01)
                        || ($pcOld === null && $pcNew !== null) || ($pcOld !== null && $pcNew === null)
                        || ($pcOld !== null && $pcNew !== null && abs($pcOld - $pcNew) > 0.01)) {
                        $changes[] = "Pack/Carton prices changed";
                    }
                    if ((int)($old['minStock'] ?? 5) !== (int)$minStock || (int)($old['expiry_alert_days'] ?? 30) !== (int)$expiry_alert_days) {
                        $changes[] = "Alerts/min stock changed";
                    }
                }
                $stmt = $conn->prepare("UPDATE products SET name=?, barcode=?, sku=?, price=?, cost=?, qty=?, category=?, supplier=?, manufacturer=?, trackStock=?, unitType=?, itemsPerCarton=?, forSale=?, takeawayPrice=?, takeawayPrice_pack=?, takeawayPrice_carton=?, expiry=?, wholesaleQty=?, wholesalePrice=?, item_type=?, pieces_per_pack=?, packs_per_carton=?, barcode_pack=?, barcode_carton=?, price_pack=?, price_carton=?, cost_pack=?, cost_carton=?, unit_show_pack=?, unit_show_carton=?, unit_name_piece=?, unit_name_pack=?, unit_name_carton=?, note=?, price_usd=?, cost_usd=?, price_pack_usd=?, price_carton_usd=?, cost_pack_usd=?, cost_carton_usd=? WHERE id=?");
                if(!$stmt) throw new Exception($conn->error);
                $price_pack_val = $price_pack !== null ? $price_pack : 0; $price_carton_val = $price_carton !== null ? $price_carton : 0;
                $cost_pack_val = $cost_pack !== null ? $cost_pack : 0; $cost_carton_val = $cost_carton !== null ? $cost_carton : 0;
                $stmt->bind_param("sssdddsssisiiiiiisdsiissddddiissssddddddi", $name, $barcode, $sku, $price, $cost, $qty, $cat, $supp, $manufacturer, $track, $unitType, $itemsPerCarton, $forSale, $takeawayPrice, $takeawayPricePack, $takeawayPriceCarton, $expiry, $wholesaleQty, $wholesalePrice, $itemType, $pieces_per_pack, $packs_per_carton, $barcode_pack, $barcode_carton, $price_pack_val, $price_carton_val, $cost_pack_val, $cost_carton_val, $unit_show_pack, $unit_show_carton, $unit_name_piece, $unit_name_pack, $unit_name_carton, $note, $price_usd, $cost_usd, $price_pack_usd, $price_carton_usd, $cost_pack_usd, $cost_carton_usd, $id);
                if(!$stmt->execute()) throw new Exception("Update Failed: " . $stmt->error);
                $modeStmt = $conn->prepare("UPDATE products SET qty_mode = ?, unitType = ? WHERE id = ?");
                if ($modeStmt) {
                    $modeStmt->bind_param("ssi", $qty_mode, $unitType, $id);
                    $modeStmt->execute();
                }
                $metaStmt = $conn->prepare("UPDATE products SET minStock = ?, expiry_alert_days = ? WHERE id = ?");
                if ($metaStmt) {
                    $metaStmt->bind_param("iii", $minStock, $expiry_alert_days, $id);
                    $metaStmt->execute();
                }
                $jewStmt = $conn->prepare("UPDATE products SET metal_type = ?, karat = ?, weight_grams = ?, making_charge = ?, jewelry_price_mode = ?, is_jewelry_set = ? WHERE id = ?");
                if ($jewStmt) {
                    $karat_bind = ($karat !== null) ? (float)$karat : 0.0;
                    $jewStmt->bind_param("sdddsii", $metal_type, $karat_bind, $weight_grams, $making_charge, $jewelry_price_mode, $is_jewelry_set, $id);
                    $jewStmt->execute();
                }
                if (function_exists('pos_save_jewelry_set_items')) {
                    pos_save_jewelry_set_items($conn, (int)$id, $_POST['jewelry_set_members'] ?? '[]', $is_jewelry_set);
                }
                if (function_exists('pos_save_product_tech_specs') && array_key_exists('tech_specs', $_POST)
                    && (!function_exists('pos_can_use_tech_specs') || pos_can_use_tech_specs($conn))) {
                    pos_save_product_tech_specs($conn, (int)$id, $_POST['tech_specs']);
                }
                $jewelrySetItemsOut = [];
                if ($is_jewelry_set && function_exists('pos_load_jewelry_set_items_map')) {
                    $mapOut = pos_load_jewelry_set_items_map($conn, [(int)$id]);
                    $jewelrySetItemsOut = $mapOut[(int)$id] ?? [];
                }
                if ($track) {
                    $whId = pos_resolve_product_warehouse_id_for_save($conn, (int)($_POST['warehouse_id'] ?? 0));
                    pos_set_warehouse_stock($conn, $whId, $id, (float)$qty);
                }
                if (function_exists('pos_clear_product_catalog_only')) {
                    pos_clear_product_catalog_only($conn, (int)$id);
                }
                if (function_exists('pos_product_write_base_fields')) {
                    pos_product_write_base_fields($conn, (int)$id, $baseCurrency, $basePrice, $baseCost);
                }
                if ($old) {
                    $logDetails = !empty($changes)
                        ? ("گۆڕین لە ئایتم «{$name}»: " . implode(" | ", $changes))
                        : ("پاشەکەوتکرا ئایتم «{$name}»");
                    $snapOld = $old ? [
                        'name' => $old['name'] ?? '',
                        'price' => $old['price'] ?? 0,
                        'cost' => $old['cost'] ?? 0,
                        'qty' => $old['qty'] ?? 0,
                        'barcode' => $old['barcode'] ?? '',
                        'sku' => $old['sku'] ?? '',
                        'category' => $old['category'] ?? '',
                        'supplier' => $old['supplier'] ?? '',
                        'manufacturer' => $old['manufacturer'] ?? '',
                    ] : null;
                    $snapNew = ['name'=>$name,'price'=>$price,'cost'=>$cost,'qty'=>$qty,'barcode'=>$barcode,'sku'=>$sku,'category'=>$cat,'supplier'=>$supp,'manufacturer'=>$manufacturer];
                    $oldVal = $snapOld !== null ? json_encode($snapOld, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE) : null;
                    $newVal = json_encode($snapNew, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
                    try {
                        logAction($conn, $user, 'edit_product', $logDetails, null, 'product', $id, $oldVal, $newVal);
                    } catch (Exception $e) {
                    }
                }
                touchLastUpdate($conn);
                $conn->commit();
                echo json_encode([
                    "status" => "success",
                    "id" => $id,
                    "action" => "update",
                    "is_jewelry_set" => (bool)$is_jewelry_set,
                    "jewelry_set_items" => $jewelrySetItemsOut,
                    "price" => $price,
                    "base_price" => $basePrice,
                    "base_cost" => $baseCost,
                    "base_currency" => $baseCurrency,
                    "trackStock" => (int)$track,
                ]); exit();
            } else {
                // Duplicate check: same name or same barcode (if barcode given) — do not allow before save
                $dupStmt = $conn->prepare("SELECT id, name, barcode, supplier FROM products WHERE (? != '' AND name = ? AND supplier = ?) OR (? != '' AND barcode = ? AND supplier = ?) LIMIT 8");
                $dupStmt->bind_param("ssssss", $name, $name, $supp, $barcode, $barcode, $supp);
                $dupStmt->execute();
                $dupRes = $dupStmt->get_result();
                if ($dupRes && $dupRes->num_rows > 0) {
                    $existingSameId = 0;
                    while ($dupRow = $dupRes->fetch_assoc()) {
                        $sameName = trim((string)($dupRow['name'] ?? '')) === $name;
                        $sameBc = $barcode !== '' && trim((string)($dupRow['barcode'] ?? '')) === $barcode;
                        $sameSupp = trim((string)($dupRow['supplier'] ?? '')) === $supp;
                        if ($sameName && $sameBc && $sameSupp) {
                            $existingSameId = (int)($dupRow['id'] ?? 0);
                            break;
                        }
                    }
                    if ($existingSameId > 0) {
                        $conn->commit();
                        echo json_encode([
                            "status" => "success",
                            "id" => $existingSameId,
                            "action" => "insert",
                            "idempotent" => true,
                            "is_jewelry_set" => (bool)$is_jewelry_set,
                            "jewelry_set_items" => [],
                            "price" => $price,
                            "base_price" => $basePrice,
                            "base_cost" => $baseCost,
                            "base_currency" => $baseCurrency,
                            "trackStock" => (int)$track,
                        ], JSON_UNESCAPED_UNICODE);
                        exit();
                    }
                    $conn->rollback();
                    echo json_encode(["status"=>"error", "message"=>"ئایتمەک ب هەمان ناڤ یان بارکۆد هەیە. ناڤ یان بارکۆدی ب گوهۆڕە."]);
                    exit();
                }
                $stmt = $conn->prepare("INSERT INTO products (name, barcode, sku, price, cost, qty, category, supplier, manufacturer, trackStock, unitType, itemsPerCarton, forSale, takeawayPrice, takeawayPrice_pack, takeawayPrice_carton, expiry, wholesaleQty, wholesalePrice, item_type, pieces_per_pack, packs_per_carton, barcode_pack, barcode_carton, price_pack, price_carton, cost_pack, cost_carton, unit_show_pack, unit_show_carton, unit_name_piece, unit_name_pack, unit_name_carton, note, price_usd, cost_usd, price_pack_usd, price_carton_usd, cost_pack_usd, cost_carton_usd) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                if(!$stmt) throw new Exception($conn->error);
                $price_pack_val = $price_pack !== null ? $price_pack : 0; $price_carton_val = $price_carton !== null ? $price_carton : 0;
                $cost_pack_val = $cost_pack !== null ? $cost_pack : 0; $cost_carton_val = $cost_carton !== null ? $cost_carton : 0;
                $stmt->bind_param("sssdddsssisiiiiiisdsiissddddiissssdddddd", $name, $barcode, $sku, $price, $cost, $qty, $cat, $supp, $manufacturer, $track, $unitType, $itemsPerCarton, $forSale, $takeawayPrice, $takeawayPricePack, $takeawayPriceCarton, $expiry, $wholesaleQty, $wholesalePrice, $itemType, $pieces_per_pack, $packs_per_carton, $barcode_pack, $barcode_carton, $price_pack_val, $price_carton_val, $cost_pack_val, $cost_carton_val, $unit_show_pack, $unit_show_carton, $unit_name_piece, $unit_name_pack, $unit_name_carton, $note, $price_usd, $cost_usd, $price_pack_usd, $price_carton_usd, $cost_pack_usd, $cost_carton_usd);
                if(!$stmt->execute()) throw new Exception("Insert Failed: " . $stmt->error);
                $newId = $stmt->insert_id;
                $modeStmt = $conn->prepare("UPDATE products SET qty_mode = ?, unitType = ? WHERE id = ?");
                if ($modeStmt) {
                    $modeStmt->bind_param("ssi", $qty_mode, $unitType, $newId);
                    $modeStmt->execute();
                }
                $metaStmt = $conn->prepare("UPDATE products SET minStock = ?, expiry_alert_days = ? WHERE id = ?");
                if ($metaStmt) {
                    $metaStmt->bind_param("iii", $minStock, $expiry_alert_days, $newId);
                    $metaStmt->execute();
                }
                $jewStmt = $conn->prepare("UPDATE products SET metal_type = ?, karat = ?, weight_grams = ?, making_charge = ?, jewelry_price_mode = ?, is_jewelry_set = ? WHERE id = ?");
                if ($jewStmt) {
                    $karat_bind = ($karat !== null) ? (float)$karat : 0.0;
                    $jewStmt->bind_param("sdddsii", $metal_type, $karat_bind, $weight_grams, $making_charge, $jewelry_price_mode, $is_jewelry_set, $newId);
                    $jewStmt->execute();
                }
                if (function_exists('pos_save_jewelry_set_items')) {
                    pos_save_jewelry_set_items($conn, (int)$newId, $_POST['jewelry_set_members'] ?? '[]', $is_jewelry_set);
                }
                if (function_exists('pos_save_product_tech_specs') && array_key_exists('tech_specs', $_POST)
                    && (!function_exists('pos_can_use_tech_specs') || pos_can_use_tech_specs($conn))) {
                    pos_save_product_tech_specs($conn, (int)$newId, $_POST['tech_specs']);
                }
                $jewelrySetItemsOut = [];
                if ($is_jewelry_set && function_exists('pos_load_jewelry_set_items_map')) {
                    $mapOut = pos_load_jewelry_set_items_map($conn, [(int)$newId]);
                    $jewelrySetItemsOut = $mapOut[(int)$newId] ?? [];
                }
                if ($track && (float)$qty > 0) {
                    $whId = pos_resolve_product_warehouse_id_for_save($conn, (int)($_POST['warehouse_id'] ?? 0));
                    pos_set_warehouse_stock($conn, $whId, (int)$newId, (float)$qty);
                }
                if ($track && (float)$qty > 0 && $expiry !== '' && isValidYmdDate($expiry)) {
                    $pieceCost = ((float)$qty > 0) ? ((float)$cost) : 0;
                    pos_ensure_initial_stock_batch($conn, (int)$newId, (float)$qty, $pieceCost, $expiry, (int)$newId);
                }
                if (function_exists('pos_clear_product_catalog_only')) {
                    pos_clear_product_catalog_only($conn, (int)$newId);
                }
                if (function_exists('pos_product_write_base_fields')) {
                    pos_product_write_base_fields($conn, (int)$newId, $baseCurrency, $basePrice, $baseCost);
                }
                try {
                    logAction(
                        $conn,
                        $user,
                        'create_product',
                        "ئایتمێ نوێ زیادکرا: «{$name}» | نرخ: " . number_format((float)$price) . " | کۆگە: {$qty}",
                        null,
                        'product',
                        $newId,
                        null,
                        json_encode(['name'=>$name,'price'=>$price,'cost'=>$cost,'qty'=>$qty,'barcode'=>$barcode,'category'=>$cat], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE)
                    );
                } catch (Exception $e) {
                }
                touchLastUpdate($conn);
                $conn->commit();
                echo json_encode([
                    "status" => "success",
                    "id" => $newId,
                    "action" => "insert",
                    "is_jewelry_set" => (bool)$is_jewelry_set,
                    "jewelry_set_items" => $jewelrySetItemsOut,
                    "price" => $price,
                    "base_price" => $basePrice,
                    "base_cost" => $baseCost,
                    "base_currency" => $baseCurrency,
                    "trackStock" => (int)$track,
                ]); exit();
            }
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(["status"=>"error", "message"=>$e->getMessage()]); exit();
        }
        exit();
    }

    if ($act === 'split_dumped_tech_specs') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        if (!function_exists('pos_can_use_tech_specs') || !pos_can_use_tech_specs($conn)) {
            echo json_encode(['status' => 'error', 'message' => 'مواسفات تەفعیل نەکریە.', 'count' => 0, 'items' => []], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $result = function_exists('pos_migrate_dumped_tech_specs_from_names')
            ? pos_migrate_dumped_tech_specs_from_names($conn)
            : ['ok' => false, 'items' => [], 'count' => 0];
        if (empty($result['ok'])) {
            echo json_encode([
                'status' => 'error',
                'message' => 'جوداکرنا مواصفات سەرنەکەفت.',
                'count' => 0,
                'items' => [],
            ], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $count = (int)($result['count'] ?? 0);
        if ($count > 0 && function_exists('touchLastUpdate')) {
            touchLastUpdate($conn);
        }
        if ($count > 0 && function_exists('logAction')) {
            $user = function_exists('pos_session_user_name') ? pos_session_user_name() : 'System';
            $postedUser = trim((string)($_POST['user'] ?? ''));
            if ($postedUser !== '') {
                $user = $postedUser;
            }
            try {
                logAction($conn, $user, 'split_tech_specs', 'مواسفات ژ ناڤێ ئایتمان هاتنە جوداکرن: ' . $count, null, 'product', null);
            } catch (Exception $eLog) {
            }
        }
        echo json_encode([
            'status' => 'success',
            'count' => $count,
            'items' => $result['items'] ?? [],
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
