// settings/printers.js — printers, currency, telegram
        function getOpenPdsDoc() {
            var open = document.querySelector('#pds-cards-grid .pds-card.open');
            if (open && open.getAttribute('data-doc')) return open.getAttribute('data-doc');
            var moreOpen = document.querySelector('.pds-cards-more .pds-card.open');
            if (moreOpen && moreOpen.getAttribute('data-doc')) return moreOpen.getAttribute('data-doc');
            return 'pos_sale';
        }
        function getPdsFormPrintConfig(doc) {
            var paperEl = document.getElementById('pds-' + doc + '-paper');
            var designEl = document.getElementById('pds-' + doc + '-design');
            var paper = pdsMigratePaperValue(paperEl ? paperEl.value : '80mm');
            var design = designEl ? String(designEl.value || '') : '7';
            if (doc === 'proforma' && design === 'same_pos_sale') return getPdsFormPrintConfig('pos_sale');
            if (doc === 'pos_sale' || doc === 'proforma') {
                var norm = (doc === 'proforma') ? normalizeProformaPrintConfig(paper, design) : normalizePosSalePrintConfig(paper, design);
                return { paper: norm.paper, design: norm.design };
            }
            var auto = pdsAutoDesignForPaper(doc, paper);
            return { paper: paper, design: auto || design || '1' };
        }
        function withPdsPreviewIdentity(run) {
            if (!db.settings) db.settings = {};
            var map = [
                ['cafeName', 'set-cafe-name'],
                ['cafeInfo', 'set-cafe-info'],
                ['cafePhone', 'set-cafe-phone'],
                ['cafeAddress', 'set-cafe-address'],
                ['footer', 'set-cafe-footer'],
                ['invoiceNote', 'set-invoice-note'],
                ['customNote', 'set-custom-note']
            ];
            var snap = {};
            map.forEach(function(pair) {
                var key = pair[0];
                snap[key] = db.settings[key];
                var el = document.getElementById(pair[1]);
                if (el && String(el.value || '').trim()) db.settings[key] = String(el.value).trim();
            });
            try { return run(); } finally {
                map.forEach(function(pair) { db.settings[pair[0]] = snap[pair[0]]; });
            }
        }
        function buildPdsPreviewSampleGrouped() {
            var tf = typeof t === 'function';
            var n1 = tf ? (t('pds_preview_item_1') || 'قهوه') : 'قهوه';
            var n2 = tf ? (t('pds_preview_item_2') || 'چای') : 'چای';
            return {
                a: { id: 1, name: n1, count: 2, qty: 2, price: 5000, sub: 10000, note: '', isGift: false, saleUnit: 'piece' },
                b: { id: 2, name: n2, count: 1, qty: 1, price: 5000, sub: 5000, note: '', isGift: false, saleUnit: 'piece' }
            };
        }
        function buildPdsPreviewSampleData(doc) {
            var grouped = buildPdsPreviewSampleGrouped();
            var items = Object.values(grouped).map(function(g) {
                return { id: g.id, name: g.name || 'ئایتم', price: g.price, qty: g.qty, note: g.note, isGift: g.isGift, saleUnit: g.saleUnit || 'piece' };
            });
            var subTotal = 15000;
            var total = 15000;
            var tf = typeof t === 'function';
            var cashier = (typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : 'Admin';
            if (doc === 'proforma') {
                return {
                    grouped: grouped,
                    subTotal: subTotal,
                    sale: {
                        id: 'P-1',
                        date: new Date().toISOString(),
                        table: tf ? (t('pds_preview_table') || 'مێز ٣') : 'مێز ٣',
                        tableName: tf ? (t('pds_preview_table') || 'مێز ٣') : 'مێز ٣',
                        items: items,
                        total: total,
                        discount: 0,
                        discountPercent: 0,
                        subtotal: subTotal
                    }
                };
            }
            return {
                grouped: grouped,
                subTotal: subTotal,
                sale: {
                    id: 12345,
                    date: new Date().toISOString(),
                    items: items,
                    total: total,
                    discount: 0,
                    discountPercent: 0,
                    subtotal: subTotal,
                    cash_paid: total,
                    paid_amount: total,
                    debt_added: 0,
                    debt_amount: 0,
                    previous_debt: 0,
                    total_outstanding_debt: 0,
                    payment_method: 'cash',
                    customer: tf ? (t('print_customer_general') || 'گشتی') : 'گشتی',
                    cashier: cashier
                }
            };
        }
        function getPdsDocPreviewTitle(doc) {
            var tf = typeof t === 'function';
            var key = 'pds_card_' + doc.replace(/_([a-z])/g, function(_, c) { return '_' + c; }) + '_title';
            if (doc === 'pos_sale') key = 'pds_card_pos_sale_title';
            if (doc === 'return_receipt') key = 'pds_card_return_title';
            if (doc === 'delivery_slip') key = 'pds_card_delivery_title';
            if (doc === 'purchase_invoice') key = 'pds_card_purchase_invoice_title';
            if (tf) {
                var tr = t(key);
                if (tr && tr !== key) return tr;
            }
            var card = document.querySelector('.pds-card[data-doc="' + doc + '"] .pds-card-title');
            return card ? card.textContent.trim() : doc;
        }
        function pdsPreviewLabel(key, fallback) {
            if (typeof t !== 'function') return fallback;
            var v = t(key);
            return (v && v !== key) ? v : fallback;
        }
        function buildPdsReportPreviewContent(doc) {
            var loc = typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ';
            var today = new Date().toLocaleDateString(loc);
            var title = getPdsDocPreviewTitle(doc);
            var subtitle = pdsPreviewLabel('print_date', 'بەروار') + ': ' + today;
            var summaryHtml = '';
            var tableHtml = '';
            if (doc === 'daily_monthly_report') {
                summaryHtml = '<div class="p-box" style="border-color:#0E4AFF;flex:1 1 45%;"><h3>' + pdsPreviewLabel('print_total_sales', 'کۆی فرۆشتن') + '</h3><h2 style="color:#0E4AFF;">' + formatCurrency(1250000) + '</h2></div>' +
                    '<div class="p-box" style="flex:1 1 45%;"><h3>' + pdsPreviewLabel('print_net_total', 'کۆی سافی') + '</h3><h2>' + formatCurrency(980000) + '</h2></div>';
                tableHtml = '<div class="section-title">' + title + '</div><table class="print-table"><thead><tr><th>' + pdsPreviewLabel('print_date', 'بەروار') + '</th><th>' + pdsPreviewLabel('print_total_sales', 'فرۆشتن') + '</th><th>' + pdsPreviewLabel('print_expenses', 'مەسروفات') + '</th><th>' + pdsPreviewLabel('print_net_total', 'سافی') + '</th></tr></thead><tbody>' +
                    '<tr><td>' + today + '</td><td>' + formatCurrency(450000) + '</td><td>' + formatCurrency(85000) + '</td><td>' + formatCurrency(365000) + '</td></tr>' +
                    '<tr><td>' + today + '</td><td>' + formatCurrency(380000) + '</td><td>' + formatCurrency(62000) + '</td><td>' + formatCurrency(318000) + '</td></tr></tbody></table>';
            } else if (doc === 'expenses_report') {
                tableHtml = '<div class="section-title">' + title + '</div><table class="print-table"><thead><tr><th>' + pdsPreviewLabel('print_date', 'بەروار') + '</th><th>' + pdsPreviewLabel('gh_th_note', 'تێبینی') + '</th><th>' + pdsPreviewLabel('print_amount_iqd', 'بڕ') + '</th></tr></thead><tbody>' +
                    '<tr><td>' + today + '</td><td>' + pdsPreviewLabel('pds_preview_expense_1', 'کرێی دوکان') + '</td><td>' + formatCurrency(250000) + '</td></tr>' +
                    '<tr><td>' + today + '</td><td>' + pdsPreviewLabel('pds_preview_expense_2', 'کارەبا') + '</td><td>' + formatCurrency(75000) + '</td></tr></tbody></table>';
            } else if (doc === 'debt_list') {
                tableHtml = '<div class="section-title">' + title + '</div><table class="print-table"><thead><tr><th>' + pdsPreviewLabel('print_customer', 'کڕیار') + '</th><th>' + pdsPreviewLabel('print_phone', 'تەلەفۆن') + '</th><th>' + pdsPreviewLabel('pds_preview_debt_col', 'قەرز') + '</th></tr></thead><tbody>' +
                    '<tr><td>' + pdsPreviewLabel('pds_preview_customer_1', 'کڕیار ١') + '</td><td>0750xxxxxxx</td><td>' + formatCurrency(120000) + '</td></tr>' +
                    '<tr><td>' + pdsPreviewLabel('pds_preview_customer_2', 'کڕیار ٢') + '</td><td>0751xxxxxxx</td><td>' + formatCurrency(85000) + '</td></tr></tbody></table>';
            } else if (doc === 'customer_ledger') {
                tableHtml = '<div class="section-title">' + title + '</div><table class="print-table"><thead><tr><th>' + pdsPreviewLabel('print_date', 'بەروار') + '</th><th>' + pdsPreviewLabel('print_customer', 'کڕیار') + '</th><th>' + pdsPreviewLabel('pds_preview_debt_col', 'قەرز') + '</th></tr></thead><tbody>' +
                    '<tr><td>' + today + '</td><td>' + pdsPreviewLabel('pds_preview_customer_1', 'کڕیار ١') + '</td><td>' + formatCurrency(120000) + '</td></tr></tbody></table>';
            } else if (doc === 'company_ledger') {
                tableHtml = '<div class="section-title">' + title + '</div><table class="print-table"><thead><tr><th>' + pdsPreviewLabel('pds_preview_company', 'کۆمپانیا') + '</th><th>' + pdsPreviewLabel('pds_preview_in', 'هاتن') + '</th><th>' + pdsPreviewLabel('pds_preview_out', 'چوون') + '</th><th>' + pdsPreviewLabel('pds_preview_balance', 'باڵانس') + '</th></tr></thead><tbody>' +
                    '<tr><td>' + pdsPreviewLabel('pds_preview_company_1', 'کۆمپانیا ١') + '</td><td>' + formatCurrency(500000) + '</td><td>' + formatCurrency(200000) + '</td><td>' + formatCurrency(300000) + '</td></tr></tbody></table>';
            } else if (doc === 'inventory_report') {
                tableHtml = '<div class="section-title">' + title + '</div><table class="print-table"><thead><tr><th>' + pdsPreviewLabel('print_item', 'ئایتم') + '</th><th>' + pdsPreviewLabel('print_qty', 'ژمارە') + '</th><th>' + pdsPreviewLabel('pds_preview_stock_status', 'دۆخ') + '</th></tr></thead><tbody>' +
                    '<tr><td>' + pdsPreviewLabel('pds_preview_item_1', 'قهوه') + '</td><td>48</td><td>' + pdsPreviewLabel('pds_preview_stock_ok', 'باش') + '</td></tr>' +
                    '<tr><td>' + pdsPreviewLabel('pds_preview_item_2', 'چای') + '</td><td>5</td><td style="color:#dc2626;">' + pdsPreviewLabel('pds_preview_stock_low', 'کەم') + '</td></tr></tbody></table>';
            } else if (doc === 'stock_movement_log') {
                tableHtml = '<div class="section-title">' + title + '</div><table class="print-table"><thead><tr><th>' + pdsPreviewLabel('print_date', 'بەروار') + '</th><th>' + pdsPreviewLabel('print_item', 'ئایتم') + '</th><th>' + pdsPreviewLabel('pds_preview_move_type', 'جۆر') + '</th><th>' + pdsPreviewLabel('print_qty', 'ژمارە') + '</th></tr></thead><tbody>' +
                    '<tr><td>' + today + '</td><td>' + pdsPreviewLabel('pds_preview_item_1', 'قهوه') + '</td><td>' + pdsPreviewLabel('pds_preview_move_in', 'هاتن') + '</td><td>+24</td></tr>' +
                    '<tr><td>' + today + '</td><td>' + pdsPreviewLabel('pds_preview_item_2', 'چای') + '</td><td>' + pdsPreviewLabel('pds_preview_move_out', 'چوون') + '</td><td>-3</td></tr></tbody></table>';
            } else if (doc === 'stock_transfer_report') {
                tableHtml = '<div class="section-title">' + title + '</div><table class="print-table"><thead><tr><th>' + pdsPreviewLabel('pds_preview_from', 'لە') + '</th><th>' + pdsPreviewLabel('pds_preview_to', 'بۆ') + '</th><th>' + pdsPreviewLabel('print_item', 'ئایتم') + '</th><th>' + pdsPreviewLabel('print_qty', 'ژمارە') + '</th></tr></thead><tbody>' +
                    '<tr><td>' + pdsPreviewLabel('pds_preview_wh_main', 'کۆگەی سەرەکی') + '</td><td>' + pdsPreviewLabel('pds_preview_wh_branch', 'لقی ٢') + '</td><td>' + pdsPreviewLabel('pds_preview_item_1', 'قهوه') + '</td><td>12</td></tr></tbody></table>';
            } else if (doc === 'delivery_slip') {
                tableHtml = '<table class="print-table"><thead><tr><th>' + pdsPreviewLabel('print_date', 'بەروار') + '</th><th>' + pdsPreviewLabel('print_customer', 'کڕیار') + '</th><th>' + pdsPreviewLabel('pds_preview_status', 'دۆخ') + '</th><th>' + pdsPreviewLabel('print_net_total', 'کۆ') + '</th></tr></thead><tbody>' +
                    '<tr><td>' + today + '</td><td>' + pdsPreviewLabel('pds_preview_customer_1', 'کڕیار ١') + '</td><td>' + pdsPreviewLabel('pds_preview_delivered', 'گەیاندرا') + '</td><td>' + formatCurrency(45000) + '</td></tr></tbody></table>';
            } else {
                tableHtml = '<div class="section-title">' + title + '</div><table class="print-table"><thead><tr><th>' + pdsPreviewLabel('print_item', 'ئایتم') + '</th><th>' + pdsPreviewLabel('print_qty', 'ژمارە') + '</th><th>' + pdsPreviewLabel('print_price', 'نرخ') + '</th></tr></thead><tbody>' +
                    Object.values(buildPdsPreviewSampleGrouped()).map(function(g) {
                        return '<tr><td>' + escapeHtml(g.name || 'ئایتم') + '</td><td>' + g.qty + '</td><td>' + formatCurrency(g.sub) + '</td></tr>';
                    }).join('') + '</tbody></table>';
            }
            return { title: title, subtitle: subtitle, summaryHtml: summaryHtml, tableHtml: tableHtml };
        }
        function buildPdsReportPreviewHtml(doc, cfg) {
            var content = buildPdsReportPreviewContent(doc);
            if (typeof buildFlexibleReportPrintHtml === 'function') {
                return buildFlexibleReportPrintHtml(doc, content.title, content.subtitle, content.summaryHtml, content.tableHtml, cfg);
            }
            if (isA4PrintPaper(cfg.paper) && typeof buildReportHtml === 'function') {
                return buildReportHtml(content.title, content.subtitle, content.summaryHtml, content.tableHtml);
            }
            if (typeof buildProformaStyleListDocumentHtml === 'function') {
                return buildProformaStyleListDocumentHtml(content.title, content.subtitle, adaptTableHtmlForThermalList(content.tableHtml), cfg);
            }
            return content.tableHtml;
        }
        function buildPdsPurchasePreviewHtml(doc, cfg) {
            if (!isA4PrintPaper(cfg.paper) || typeof buildCompanyPurchaseA4Html !== 'function') {
                if (typeof buildPosSaleReceiptHtml === 'function') {
                    var sample = buildPdsPreviewSampleData('pos_sale');
                    return buildPosSaleReceiptHtml(sample.sale, sample.grouped, { subTotal: sample.subTotal, discount: 0, discountPercent: 0, posCfg: cfg });
                }
                return '';
            }
            var tf = typeof t === 'function';
            var grouped = buildPdsPreviewSampleGrouped();
            var validRows = Object.values(grouped).map(function(g) {
                return { productName: g.name || 'ئایتم', qty: g.count, costPerUnit: g.price, productRef: null, unit: 'piece', isGift: false };
            });
            var company = {
                id: 1,
                name: tf ? (t('pds_preview_company_1') || 'کۆمپانیا ١') : 'کۆمپانیا ١',
                contact: '07501234567'
            };
            return buildCompanyPurchaseA4Html(validRows, company, 'cash', cfg, {
                supplierInvoiceNumber: 'INV-001',
                internalId: 'TX-001'
            }, { isReturn: doc === 'purchase_return' });
        }
        function buildPdsSalePreviewHtml(doc, cfg) {
            var sample = buildPdsPreviewSampleData(doc === 'proforma' ? 'proforma' : 'pos_sale');
            var sale = sample.sale;
            var grouped = sample.grouped;
            var subTotal = sample.subTotal;
            var html = '';
            if (doc === 'proforma') {
                if (isA4PrintPaper(cfg.paper) && typeof buildPosSaleA4Html === 'function') {
                    sale.customer = (typeof t === 'function') ? (t('print_pre_bill') || 'ژمێریاری') : 'ژمێریاری';
                    html = buildPosSaleA4Html(sale, cfg);
                } else if (typeof buildPosSaleReceiptHtml === 'function') {
                    html = buildPosSaleReceiptHtml(sale, grouped, { docKind: 'proforma', subTotal: subTotal, discount: 0, discountPercent: 0, posCfg: cfg });
                }
                return html;
            }
            if (isA4PrintPaper(cfg.paper) && typeof buildPosSaleA4Html === 'function') {
                html = buildPosSaleA4Html(sale, cfg);
            } else if (typeof buildPosSaleReceiptHtml === 'function') {
                html = buildPosSaleReceiptHtml(sale, grouped, { subTotal: subTotal, discount: 0, discountPercent: 0, posCfg: cfg });
            }
            return html;
        }
        function buildPdsDesignPreviewHtml(doc, cfg) {
            cfg = cfg || getPdsFormPrintConfig(doc);
            var html = '';
            if (doc === 'kitchen_slip') {
                var cafe = (db.settings && db.settings.cafeName) ? db.settings.cafeName : 'POS';
                var items = Object.values(buildPdsPreviewSampleGrouped()).map(function(g) {
                    return '<div style="padding:6px 0;border-bottom:1px dashed #ccc;font-size:1.05rem;"><b>x' + g.count + '</b> ' + escapeHtml(g.name || 'ئایتم') + '</div>';
                }).join('');
                html = '<div class="print-thermal-container" style="max-width:80mm;width:100%;padding:12px;font-family:\'Rudaw\',sans-serif;direction:rtl;text-align:center;">' +
                    '<h2 style="margin:0 0 8px;font-size:1.1rem;">' + escapeHtml(cafe) + '</h2>' +
                    '<p style="margin:0 0 10px;font-weight:bold;">' + getPdsDocPreviewTitle('kitchen_slip') + '</p>' +
                    '<div style="text-align:right;margin-top:8px;">' + items + '</div></div>';
            } else if (PDS_REPORT_DOC_TYPES.indexOf(doc) >= 0) {
                html = buildPdsReportPreviewHtml(doc, cfg);
            } else if (doc === 'purchase_invoice' || doc === 'purchase_return') {
                html = buildPdsPurchasePreviewHtml(doc, cfg);
            } else if (doc === 'proforma') {
                html = buildPdsSalePreviewHtml('proforma', cfg);
            } else if (PDS_SALE_PREVIEW_DOCS.indexOf(doc) >= 0) {
                html = buildPdsSalePreviewHtml('pos_sale', cfg);
            }
            if (html && typeof finalizePrintHtmlWithNote === 'function') html = finalizePrintHtmlWithNote(html, '');
            if (html && typeof ensurePosReceiptBrandInHtml === 'function') html = ensurePosReceiptBrandInHtml(html);
            return html || '';
        }
        function pdsFormatPreviewMeta(doc, cfg) {
            var tf = typeof t === 'function';
            var docLabel = getPdsDocPreviewTitle(doc);
            var paperLabel = isA4PrintPaper(cfg.paper) ? 'A4' : '80mm';
            var designLabel = '';
            if (doc === 'pos_sale' || doc === 'proforma' || (PDS_SALE_PREVIEW_DOCS.indexOf(doc) >= 0 && doc !== 'proforma')) {
                if (isA4PrintPaper(cfg.paper)) {
                    designLabel = cfg.design === '2' ? (tf ? t('pds_d_a4_2') : 'A4: ٢') : (cfg.design === '8' ? (tf ? t('pds_d_a4_3') : 'A4: ٣') : (tf ? t('pds_d_a4_1') : 'A4: ١'));
                } else {
                    designLabel = '80mm';
                }
            } else if (PDS_REPORT_DOC_TYPES.indexOf(doc) >= 0) {
                designLabel = isA4PrintPaper(cfg.paper) ? 'A4' : '80mm';
            }
            return docLabel + ' · ' + paperLabel + (designLabel && designLabel !== paperLabel ? (' · ' + designLabel) : '');
        }
        var _pdsPreviewLastHtml = '';
        var _pdsPreviewState = { doc: 'pos_sale', cfg: null };
        function pdsGetPreviewVariants(doc) {
            var tf = typeof t === 'function';
            if (doc === 'pos_sale' || doc === 'proforma') {
                return [
                    { paper: '80mm', design: '7', label: tf ? (t('pds_paper_sel_80') || '٨٠ مم') : '80mm' },
                    { paper: '210mm', design: '1', label: tf ? (t('pds_d_a4_1') || 'A4: ١') : 'A4: ١' },
                    { paper: '210mm', design: '2', label: tf ? (t('pds_d_a4_2') || 'A4: ٢') : 'A4: ٢' },
                    { paper: '210mm', design: '8', label: tf ? (t('pds_d_a4_3') || 'A4: ٣') : 'A4: ٣' }
                ];
            }
            if (doc === 'purchase_invoice' || doc === 'purchase_return') {
                return [
                    { paper: '80mm', design: '3', label: tf ? (t('pds_paper_sel_80') || '٨٠ مم') : '80mm' },
                    { paper: '210mm', design: '1', label: tf ? (t('pds_d_a4_1') || 'A4: ١') : 'A4: ١' },
                    { paper: '210mm', design: '2', label: tf ? (t('pds_d_a4_2') || 'A4: ٢') : 'A4: ٢' },
                    { paper: '210mm', design: '8', label: tf ? (t('pds_d_a4_3') || 'A4: ٣') : 'A4: ٣' }
                ];
            }
            if (PDS_REPORT_DOC_TYPES.indexOf(doc) >= 0 || PDS_SALE_PREVIEW_DOCS.indexOf(doc) >= 0 || doc === 'kitchen_slip') {
                return [
                    { paper: '80mm', design: '3', label: tf ? (t('pds_paper_sel_80') || '٨٠ مم') : '80mm' },
                    { paper: '210mm', design: '1', label: 'A4' }
                ];
            }
            return [];
        }
        function pdsRenderPreviewVariantBar(doc, cfg) {
            var bar = document.getElementById('pds-design-preview-variants');
            if (!bar) return;
            var variants = pdsGetPreviewVariants(doc);
            if (!variants.length) {
                bar.style.display = 'none';
                bar.innerHTML = '';
                return;
            }
            bar.style.display = 'flex';
            bar.innerHTML = variants.map(function(v) {
                var active = (cfg.paper === v.paper || (isA4PrintPaper(cfg.paper) && isA4PrintPaper(v.paper))) && String(cfg.design) === String(v.design);
                return '<button type="button" class="btn btn-sm ' + (active ? 'btn-brand active' : 'btn-secondary') + '" data-paper="' + v.paper + '" data-design="' + v.design + '">' + escapeHtml(v.label) + '</button>';
            }).join('');
            bar.querySelectorAll('button[data-paper]').forEach(function(btn) {
                btn.onclick = function() {
                    var nextCfg = { paper: btn.getAttribute('data-paper'), design: btn.getAttribute('data-design') };
                    pdsRenderDesignPreview(_pdsPreviewState.doc, nextCfg);
                };
            });
        }
        function pdsRenderDesignPreview(doc, cfg) {
            cfg = cfg || getPdsFormPrintConfig(doc);
            _pdsPreviewState = { doc: doc, cfg: cfg };
            var html = buildPdsDesignPreviewHtml(doc, cfg);
            if (!html) return false;
            _pdsPreviewLastHtml = html;
            var body = document.getElementById('pds-design-preview-body');
            var meta = document.getElementById('pds-design-preview-meta');
            if (body) body.innerHTML = html;
            if (meta) meta.textContent = pdsFormatPreviewMeta(doc, cfg);
            pdsRenderPreviewVariantBar(doc, cfg);
            return true;
        }
        function openPdsDesignPreview(doc) {
            doc = doc || getOpenPdsDoc();
            withPdsPreviewIdentity(function() {
                var cfg = getPdsFormPrintConfig(doc);
                if (!pdsRenderDesignPreview(doc, cfg)) {
                    if (typeof showToast === 'function') showToast((typeof t === 'function' ? t('pds_preview_error') : 'پێشبینین سەرنەکەوت'), true);
                    return;
                }
                var modal = document.getElementById('pds-design-preview-modal');
                if (!modal) return;
                modal.style.display = 'flex';
                document.body.style.overflow = 'hidden';
                if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
            });
        }
        function closePdsDesignPreview() {
            var modal = document.getElementById('pds-design-preview-modal');
            if (modal) modal.style.display = 'none';
            document.body.style.overflow = '';
        }
        function printPdsDesignPreview() {
            if (!_pdsPreviewLastHtml) return;
            var doc = getOpenPdsDoc();
            if (typeof printContent === 'function') printContent(_pdsPreviewLastHtml, { docType: doc });
            else if (typeof showToast === 'function') showToast((typeof t === 'function' ? t('pds_toast_test_print_hint') : ''));
        }
        function pdsEnsurePreviewButtons() {
            var docTypes = ['pos_sale', 'proforma', 'kitchen_slip', 'return_receipt', 'delivery_slip', 'inventory_report', 'stock_movement_log', 'stock_transfer_report', 'debt_list', 'company_ledger', 'customer_ledger', 'expenses_report', 'daily_monthly_report', 'purchase_invoice', 'purchase_return'];
            docTypes.forEach(function(doc) {
                var opts = document.getElementById('pds-options-' + doc);
                if (!opts || opts.querySelector('.pds-preview-design-btn')) return;
                var btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'btn btn-info btn-sm pds-preview-design-btn';
                btn.innerHTML = '<i class="fas fa-eye"></i> <span data-i18n="pds_preview_design_btn">پێشبینینی دیزاین</span>';
                btn.onclick = function(e) {
                    e.stopPropagation();
                    openPdsDesignPreview(doc);
                };
                opts.appendChild(btn);
            });
            if (typeof applyI18nSubtree === 'function') {
                var grid = document.getElementById('pds-cards-grid');
                if (grid) applyI18nSubtree(grid);
                var more = document.querySelector('.pds-cards-more');
                if (more) applyI18nSubtree(more);
            }
        }
        if (typeof window !== 'undefined') {
            window.getOpenPdsDoc = getOpenPdsDoc;
            window.openPdsDesignPreview = openPdsDesignPreview;
            window.closePdsDesignPreview = closePdsDesignPreview;
            window.printPdsDesignPreview = printPdsDesignPreview;
        }
        function applyPrintNotePremiumUI() {
            var can = typeof canUsePrintNotes === 'function' && canUsePrintNotes();
            var el = document.getElementById('setting-show-print-note-popup');
            var card = document.getElementById('pds-print-note-premium-card');
            var hint = document.getElementById('pds-print-note-pro-hint');
            if (!db || !db.settings) return;
            if (!can) db.settings.showPrintNotePopup = false;
            if (el) {
                el.disabled = !can;
                el.checked = !!(can && db.settings.showPrintNotePopup !== false);
            }
            if (card) card.classList.toggle('pds-print-note--locked', !can);
            if (hint) hint.style.display = can ? 'none' : '';
            if (typeof updatePrintNotePopupQuickButtonState === 'function') updatePrintNotePopupQuickButtonState();
        }
        function savePrintNotePopupSetting() {
            var el = document.getElementById('setting-show-print-note-popup');
            if (!db.settings) db.settings = {};
            if (typeof canUsePrintNotes === 'function' && !canUsePrintNotes()) {
                if (el) el.checked = false;
                db.settings.showPrintNotePopup = false;
                if (typeof showPremiumLockedPurchasePopup === 'function') {
                    var noteTitle = (typeof t === 'function') ? t('pds_print_note_title') : 'تێبینی پێش چاپ';
                    showPremiumLockedPurchasePopup(noteTitle, 'setting-show-print-note-popup');
                }
                if (typeof updatePrintNotePopupQuickButtonState === 'function') updatePrintNotePopupQuickButtonState();
                return;
            }
            db.settings.showPrintNotePopup = el ? el.checked : false;
            if (typeof updatePrintNotePopupQuickButtonState === 'function') updatePrintNotePopupQuickButtonState();
            if (typeof saveSettings === 'function') saveSettings().catch(function() {});
        }
        if (typeof window !== 'undefined') {
            window.savePrintNotePopupSetting = savePrintNotePopupSetting;
            window.applyPrintNotePremiumUI = applyPrintNotePremiumUI;
        }
        function saveOpeningBalancePromptSetting() {
            var el = document.getElementById('set-require-opening-balance-prompt');
            if (!db || !db.settings) return;
            if (typeof isPremiumFeatureUnlocked === 'function' && !isPremiumFeatureUnlocked('set-require-opening-balance-prompt')) {
                if (el) el.checked = false;
                db.settings.requireOpeningBalancePrompt = false;
                return;
            }
            db.settings.requireOpeningBalancePrompt = el ? !!el.checked : true;
            if (typeof saveSettings === 'function') saveSettings().catch(function() {});
        }
        if (typeof window !== 'undefined') window.saveOpeningBalancePromptSetting = saveOpeningBalancePromptSetting;
        function saveEndShiftReconcilePromptSetting() {
            var el = document.getElementById('set-require-end-shift-reconcile-prompt');
            if (!db || !db.settings) return;
            if (typeof isPremiumFeatureUnlocked === 'function' && !isPremiumFeatureUnlocked('set-require-end-shift-reconcile-prompt')) {
                if (el) el.checked = false;
                db.settings.requireEndShiftReconcilePrompt = false;
                return;
            }
            db.settings.requireEndShiftReconcilePrompt = el ? !!el.checked : true;
            if (typeof saveSettings === 'function') saveSettings().catch(function() {});
        }
        if (typeof window !== 'undefined') window.saveEndShiftReconcilePromptSetting = saveEndShiftReconcilePromptSetting;
        function togglePdsCard(docType) {
            const cards = document.querySelectorAll('.pds-card');
            const card = document.querySelector('.pds-card[data-doc="' + docType + '"]');
            if (!card) return;
            const isOpen = card.classList.contains('open');
            cards.forEach(c => c.classList.remove('open'));
            if (!isOpen) card.classList.add('open');
        }
        function toggleNewPrinterIpField() {
            var connEl = document.getElementById('new-printer-connection');
            var wrap = document.getElementById('new-printer-ip-wrap');
            if (wrap && connEl) wrap.style.display = (connEl.value === 'network') ? 'block' : 'none';
        }
        function renderPrintersList(skipLabel) {
            var wrap = document.getElementById('printers-cards-wrap');
            var emptyMsg = document.getElementById('printers-empty-msg');
            var printers = getPrinters();
            var tf = (typeof t === 'function');
            var connLabel = function(connectionType) {
                if (!tf) return connectionType === 'network' ? 'IP' : (connectionType === 'usb' ? 'USB' : 'سیستەم');
                if (connectionType === 'network') return t('pds_opt_ip_network');
                if (connectionType === 'usb') return t('pds_opt_usb');
                return t('pds_opt_system_default');
            };
            var statusLabel = function(st) {
                if (!tf) return (st === 'active') ? 'چالاک' : 'ناچالاک';
                return (st === 'active') ? t('pds_opt_active') : t('pds_opt_inactive');
            };
            var testBtn = tf ? t('pds_printer_test_print') : 'چاپ';
            var testTitle = tf ? t('pds_printer_test_print_title') : '';
            var defOptLabel = tf ? (t('pds_printer_routing_default') || '') : '— بنەڕەتی سیستەم';
            if (wrap) {
                wrap.innerHTML = printers.length ? printers.map(function(p) {
                    var conn = connLabel(p.connectionType);
                    var ip = (p.connectionType === 'network' && p.ipAddress) ? escapeHtml(p.ipAddress) : '';
                    var status = statusLabel(p.status);
                    var safeId = escapeHtml(p.id);
                    var paper = p.paperSize || '80mm';
                    return '<div class="printer-card">' +
                        '<div class="printer-card-name"><i class="fas fa-print"></i> ' + escapeHtml(p.name) + '</div>' +
                        '<div class="printer-card-meta">' +
                        '<span><i class="fas fa-file-alt"></i> ' + escapeHtml(paper) + '</span>' +
                        '<span><i class="fas fa-link"></i> ' + conn + (ip ? ' — ' + ip : '') + '</span>' +
                        '<span><i class="fas fa-toggle-on"></i> ' + status + '</span>' +
                        '</div>' +
                        '<div class="printer-card-actions">' +
                        '<button type="button" class="btn btn-info btn-sm" onclick="testPrintPrinter(\'' + safeId + '\')" title="' + escapeHtml(testTitle) + '"><i class="fas fa-print"></i> ' + escapeHtml(testBtn) + '</button>' +
                        '<button type="button" class="btn btn-danger btn-sm" onclick="removePrinter(\'' + safeId + '\')"><i class="fas fa-trash"></i></button>' +
                        '</div></div>';
                }).join('') : '';
            }
            if (emptyMsg) emptyMsg.style.display = printers.length ? 'none' : 'block';
            var opts = '<option value="">' + defOptLabel + '</option>';
            var allPrinters = collectDefinedPrinterOptions();
            allPrinters.forEach(function(p) {
                var val = p.id || p.name;
                var label = p.name;
                if (p.offline) label += ' (Offline)';
                opts += '<option value="' + escapeHtml(val) + '">' + escapeHtml(label) + '</option>';
            });
            document.querySelectorAll('.pds-printer-select').forEach(function(sel) { 
                var cur = sel.value;
                if (!cur && db && db.settings && db.settings.printerRouting) {
                    var match = sel.id.match(/^pds-(.+)-printer$/);
                    if (match && db.settings.printerRouting[match[1]]) {
                        cur = db.settings.printerRouting[match[1]];
                    }
                }
                sel.innerHTML = opts; 
                if (cur) sel.value = cur;
                
                // If it STILL couldn't be selected (e.g. printer not in list yet), add it temporarily
                if (cur && sel.value !== cur) {
                    var keep = document.createElement('option');
                    keep.value = cur;
                    keep.textContent = cur;
                    sel.appendChild(keep);
                    sel.value = cur;
                }
            });
            if (!skipLabel && typeof fillLabelPrinterSelect === 'function') {
                var lp = (typeof getLabelPrintSettings === 'function') ? getLabelPrintSettings() : ((db && db.settings && db.settings.labelPrint) ? db.settings.labelPrint : {});
                fillLabelPrinterSelect(lp.printerName || '', lp.printerId || '');
            }
            try {
                var _vpdI = document.getElementById('view-print-design');
                if (_vpdI && typeof applyI18nSubtree === 'function') applyI18nSubtree(_vpdI);
            } catch (ePri18n) {}
        }
        function testPrintPrinter(printerId) {
            var nameEl = document.getElementById('set-cafe-name');
            var infoEl = document.getElementById('set-cafe-info');
            var tf = (typeof t === 'function');
            var storeName = (nameEl && nameEl.value.trim()) || (db.settings && db.settings.cafeName) || (tf ? t('pds_preview_store_fallback') : '');
            var storeInfo = (infoEl && infoEl.value.trim()) || (db.settings && db.settings.cafeInfo) || '';
            var tpLine = tf ? t('pds_printer_test_print') : 'Test Print';
            var tpFoot = tf ? t('pds_test_print_footer_note') : '';
        var testHtml = '<div style="text-align:center; padding:24px; font-family:\'Rudaw\',sans-serif; direction:rtl;">' +
                '<h2 style="margin:0 0 8px 0;">' + escapeHtml(storeName) + '</h2>' +
                (storeInfo ? '<p style="margin:0 0 16px 0; font-size:0.9rem; color:#666;">' + escapeHtml(storeInfo) + '</p>' : '') +
                '<hr style="border:none; border-top:1px dashed #ccc; margin:16px 0;">' +
                '<p style="margin:0; font-weight:bold;">' + escapeHtml(tpLine) + '</p>' +
                '<p style="margin:8px 0 0 0; font-size:0.85rem; color:#666;">' + new Date().toLocaleString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ') + '</p>' +
                '<hr style="border:none; border-top:1px dashed #ccc; margin:16px 0;">' +
                '<p style="margin:0; font-size:0.8rem;">' + escapeHtml(tpFoot) + '</p></div>';
            if (typeof printContent === 'function') printContent(testHtml);
            else window.print();
            if (typeof showToast === 'function') showToast(tf ? t('pds_toast_test_print_hint') : '');
        }
        function addPrinterFromForm() {
            var nameEl = document.getElementById('new-printer-name');
            var paperEl = document.getElementById('new-printer-paper');
            var connEl = document.getElementById('new-printer-connection');
            var statusEl = document.getElementById('new-printer-status');
            var ipEl = document.getElementById('new-printer-ip');
            var targetEl = document.getElementById('new-printer-target');
            if (!nameEl || !nameEl.value.trim()) { if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('pds_toast_printer_name_required') : '', true); return; }
            if (!db.settings) db.settings = {};
            if (!db.settings.printers) db.settings.printers = [];
            if (!db.settings.printerRouting) db.settings.printerRouting = {};
            var id = 'p' + Date.now();
            var conn = (connEl && connEl.value) || 'system';
            var rec = {
                id: id,
                name: nameEl.value.trim(),
                paperSize: (paperEl && paperEl.value) || '80mm',
                connectionType: conn,
                status: (statusEl && statusEl.value) || 'active'
            };
            if (conn === 'network' && ipEl && ipEl.value.trim()) rec.ipAddress = ipEl.value.trim();
            db.settings.printers.push(rec);
            var target = targetEl && targetEl.value ? targetEl.value.trim() : '';
            if (target) db.settings.printerRouting[target] = id;
            nameEl.value = '';
            if (paperEl) paperEl.value = '80mm';
            if (connEl) connEl.value = 'system';
            if (statusEl) statusEl.value = 'active';
            if (ipEl) ipEl.value = '';
            if (targetEl) targetEl.value = '';
            toggleNewPrinterIpField();
            renderPrintersList();
            applyPrintDesignSettings();
            saveSettings().then(function() { if (typeof showToast === 'function') showToast('پرێنتەر هاتە زێدەکرن'); }).catch(function() {});
        }
        function removePrinter(id) {
            if (!db.settings || !db.settings.printers) return;
            if (!confirm('دڵنیای تە دڤێت ڤی پرێنتەری ژێ ببەی؟')) return;
            db.settings.printers = db.settings.printers.filter(function(p) { return p.id !== id; });
            var routing = db.settings.printerRouting || {};
            Object.keys(routing).forEach(function(k) { if (routing[k] === id) delete routing[k]; });
            renderPrintersList();
            applyPrintDesignSettings();
            saveSettings().then(function() { if (typeof showToast === 'function') showToast('پرێنتەر هاتە ژێبرن'); }).catch(function() {});
        }
        function saveReceiptPreviewToggles() {
            if (!db.settings) db.settings = {};
            var showLogo = document.getElementById('pds-preview-show-logo');
            var showDate = document.getElementById('pds-preview-show-date');
            var showQr = document.getElementById('pds-preview-show-qr');
            db.settings.receiptPreviewToggles = {
                showLogo: showLogo ? showLogo.checked : true,
                showDate: showDate ? showDate.checked : true,
                showQr: showQr ? showQr.checked : false
            };
            saveSettings().catch(function() {});
        }
        function applyReceiptPreviewToggles() {
            var t = (db && db.settings && db.settings.receiptPreviewToggles) ? db.settings.receiptPreviewToggles : { showLogo: true, showDate: true, showQr: false };
            var logoEl = document.getElementById('pds-preview-show-logo');
            var dateEl = document.getElementById('pds-preview-show-date');
            var qrEl = document.getElementById('pds-preview-show-qr');
            if (logoEl) logoEl.checked = t.showLogo !== false;
            if (dateEl) dateEl.checked = t.showDate !== false;
            if (qrEl) qrEl.checked = !!t.showQr;
        }
        function updateReceiptPreview() {
            var prvToggles = (db && db.settings && db.settings.receiptPreviewToggles) ? db.settings.receiptPreviewToggles : { showLogo: true, showDate: true, showQr: false };
            var tf = (typeof t === 'function');
            var previewName = document.getElementById('pds-preview-name');
            var previewInfo = document.getElementById('pds-preview-info');
            var previewFooter = document.getElementById('pds-preview-footer');
            var nameVal = (document.getElementById('set-cafe-name') && document.getElementById('set-cafe-name').value.trim()) || (db.settings && db.settings.cafeName) || (tf ? t('pds_preview_store_fallback') : '');
            var phoneVal = (document.getElementById('set-cafe-phone') && document.getElementById('set-cafe-phone').value.trim()) || (db.settings && db.settings.cafePhone) || '';
            var addrVal = (document.getElementById('set-cafe-address') && document.getElementById('set-cafe-address').value.trim()) || (db.settings && db.settings.cafeAddress) || '';
            var infoVal = (document.getElementById('set-cafe-info') && document.getElementById('set-cafe-info').value.trim()) || (db.settings && db.settings.cafeInfo) || '';
            var footerVal = (document.getElementById('set-cafe-footer') && document.getElementById('set-cafe-footer').value.trim()) || (db.settings && db.settings.footer) || (tf ? t('pds_ph_footer') : '');
            var previewLogo = document.getElementById('pds-preview-logo');
            var previewDate = document.getElementById('pds-preview-date');
            var previewQr = document.getElementById('pds-preview-qr');
            var previewEl = document.getElementById('pds-receipt-preview');
            var paperSel = document.getElementById('pds-preview-paper');
            var previewDocEl = document.getElementById('pds-preview-doc');
            var previewDoc = (previewDocEl && previewDocEl.value) ? previewDocEl.value : 'pos_sale';
            var docPaperEl = document.getElementById('pds-' + previewDoc + '-paper');
            var docDesignEl = document.getElementById('pds-' + previewDoc + '-design');
            var previewPaper = (docPaperEl && docPaperEl.value) ? docPaperEl.value : (paperSel ? paperSel.value : '80mm');
            var previewDesign = (docDesignEl && docDesignEl.value) ? docDesignEl.value : '3';
            if (previewDoc === 'proforma' && previewDesign === 'same_pos_sale') {
                var psD = document.getElementById('pds-pos_sale-design');
                var psP = document.getElementById('pds-pos_sale-paper');
                if (psD) previewDesign = psD.value;
                if (psP) previewPaper = psP.value;
            }
            if (docPaperEl && paperSel && paperSel.value !== previewPaper) paperSel.value = previewPaper;
            var norm = (previewDoc === 'proforma')
                ? normalizeProformaPrintConfig(previewPaper, previewDesign)
                : normalizePosSalePrintConfig(previewPaper, previewDesign);
            previewPaper = norm.paper;
            previewDesign = norm.design;
            if (previewEl) {
                previewEl.classList.remove('preview-60mm', 'preview-80mm', 'preview-a4', 'preview-58mm');
                previewEl.classList.remove('design-1', 'design-2', 'design-3', 'design-4', 'design-5', 'design-6', 'design-7', 'design-8');
                previewEl.classList.remove('thermal-font-header-small', 'thermal-font-header-large', 'thermal-font-body-small', 'thermal-font-body-large', 'thermal-font-footer-small', 'thermal-font-footer-large');
                if (previewPaper === '60mm') previewEl.classList.add('preview-60mm');
                else if (previewPaper === '58mm') previewEl.classList.add('preview-58mm');
                else if (isA4PrintPaper(previewPaper)) previewEl.classList.add('preview-a4');
                else previewEl.classList.add('preview-80mm');
                previewEl.classList.add('design-' + previewDesign);
                var fontClasses = typeof getThermalFontClasses === 'function' ? getThermalFontClasses(previewDoc) : '';
                if (fontClasses) fontClasses.trim().split(/\s+/).forEach(function (c) { if (c) previewEl.classList.add(c); });
            }
            if (previewName) previewName.innerText = nameVal + (previewDoc === 'proforma' ? (' — ' + ((typeof t === 'function') ? t('print_pre_bill') : 'ژمێریاری')) : '');
            if (previewInfo) {
                var lines = [];
                if (phoneVal) lines.push(phoneVal);
                if (addrVal) lines.push(addrVal);
                if (infoVal) lines.push(infoVal);
                var emptyInfo = tf ? t('pds_preview_info_empty') : '—';
                previewInfo.innerText = lines.join(' — ') || emptyInfo;
            }
            if (previewFooter) previewFooter.innerText = footerVal;
            if (previewLogo) {
                var logoUrl = (typeof getPosShopLogoUrl === 'function') ? getPosShopLogoUrl() : ((db && db.settings && db.settings.logo) ? db.settings.logo : '');
                var thermalOpts = (typeof getThermalReceiptOptions === 'function') ? getThermalReceiptOptions(previewDoc) : null;
                var showLogo = prvToggles.showLogo !== false && (thermalOpts ? thermalOpts.logoPosition !== 'none' : true) && !!logoUrl;
                previewLogo.style.display = showLogo ? '' : 'none';
                var align = (thermalOpts && thermalOpts.logoPosition === 'right') ? 'right' : (thermalOpts && thermalOpts.logoPosition === 'left') ? 'left' : 'center';
                previewLogo.style.textAlign = align;
                previewLogo.innerHTML = (showLogo && logoUrl) ? '<img src="' + logoUrl + '" style="max-width:120px; max-height:50px; object-fit:contain; display:block; margin:' + (align === 'center' ? '0 auto' : (align === 'right' ? '0 0 0 auto' : '0 auto 0 0')) + ';">' : '';
            }
            if (previewDate) {
                previewDate.style.display = prvToggles.showDate !== false ? 'block' : 'none';
                previewDate.innerText = new Date().toLocaleDateString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ') + ' ' + new Date().toLocaleTimeString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ', { hour: '2-digit', minute: '2-digit' });
            }
            if (previewQr) {
                previewQr.style.display = prvToggles.showQr ? 'block' : 'none';
                previewQr.innerHTML = prvToggles.showQr ? '<div style="width:60px; height:60px; margin:0 auto; background:#f1f5f9; border:1px dashed #cbd5e1; border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:0.7rem; color:#64748b;"><i class="fas fa-qrcode" style="font-size:1.5rem;"></i></div><small style="display:block; margin-top:4px; color:var(--text-muted);">QR</small>' : '';
            }
        }
        function handleLogoUploadWithResize(input) {
            if (!input || !input.files.length) return;
            resizeImageFileToLogoDataUrl(input.files[0], { maxW: 720, maxH: 280 }).then(function(dataUrl) {
                if (db && db.settings) db.settings.logo = dataUrl;
                var prev = document.getElementById('pds-logo-preview');
                var wrap = document.getElementById('pds-logo-preview-wrap');
                if (prev) { prev.src = dataUrl; prev.style.display = ''; }
                if (wrap) wrap.style.display = 'inline-block';
                if (typeof syncHomeShopLogo === 'function') syncHomeShopLogo();
                if (typeof applyPrintSettings === 'function') applyPrintSettings();
                if (typeof refreshLabelLogoPreview === 'function') refreshLabelLogoPreview();
            }).catch(function() {
                alert("هەڵە د خاندنا وێنەی دا.");
            });
        }

        /** Primary barcode as shown in لیستا هەمی ئایتمان (first code if comma-separated). */
        function getProductListPrimaryBarcode(product) {
            if (!product || product.barcode == null || product.barcode === '') return '';
            return String(product.barcode).split(',')[0].trim();
        }

        function parseListBarcodeNumber(barcodeStr) {
            if (!barcodeStr) return 0;
            var b = String(barcodeStr).trim();
            var m = b.match(/^P?0*(\d{1,12})$/i);
            return m ? parseInt(m[1], 10) : 0;
        }

        function formatListBarcodeNumber(n, padLen) {
            var num = parseInt(n, 10);
            if (!num || num < 0 || isNaN(num)) return '';
            var len = padLen || 6;
            if (len < 4) len = 4;
            if (len > 8) len = 8;
            return String(num).padStart(len, '0');
        }

        function registerProductBarcodeNumber(used, raw) {
            if (!raw) return;
            String(raw).split(',').forEach(function(part) {
                var n = parseListBarcodeNumber(part.trim());
                if (n > 0) used[n] = true;
            });
        }

        /** Next barcode aligned with لیستا هەمی ئایتمان (list column), not random/long. */
        function getNextCleanProductBarcode() {
            var padLen = 6;
            var maxNum = 0;
            if (typeof db !== 'undefined' && db && db.products) {
                db.products.forEach(function(p) {
                    var listBc = getProductListPrimaryBarcode(p);
                    var n = parseListBarcodeNumber(listBc);
                    if (n > maxNum) {
                        maxNum = n;
                        padLen = Math.max(padLen, String(n).length);
                    }
                    var pid = parseInt(p.id, 10);
                    if (pid > 0) {
                        if (pid > maxNum) maxNum = pid;
                        padLen = Math.max(padLen, String(pid).length);
                    }
                });
            }

            var idEl = document.getElementById('p-id');
            var editId = idEl && idEl.value ? parseInt(idEl.value, 10) : 0;
            if (editId > 0 && !isNaN(editId) && db && db.products) {
                var existing = db.products.find(function(x) { return String(x.id) === String(editId); });
                if (existing) {
                    var listBarcode = getProductListPrimaryBarcode(existing);
                    if (listBarcode) return listBarcode;
                    return formatListBarcodeNumber(editId, padLen);
                }
            }

            var used = {};
            if (db && db.products) {
                db.products.forEach(function(p) {
                    registerProductBarcodeNumber(used, getProductListPrimaryBarcode(p));
                    registerProductBarcodeNumber(used, p.barcode_pack);
                    registerProductBarcodeNumber(used, p.barcode_carton);
                    var pid = parseInt(p.id, 10);
                    if (pid > 0) used[pid] = true;
                });
            }
            var next = maxNum + 1;
            while (used[next]) next++;
            return formatListBarcodeNumber(next, padLen);
        }

        function autoGenerateProductBarcode() {
            var barcodeEl = document.getElementById('p-barcode');
            if (!barcodeEl) return;
            var code = getNextCleanProductBarcode();
            barcodeEl.value = code;
            if (typeof syncBarcodeToPieceCell === 'function') syncBarcodeToPieceCell();
            var toastMsg = (typeof t === 'function' ? t('product_barcode_auto_list') : 'بارکۆد (هاوشێوەی لیست): {c}').replace(/\{c\}/g, code);
            if (typeof showToast === 'function') showToast(toastMsg, 'success');
        }

        window.getProductListPrimaryBarcode = getProductListPrimaryBarcode;
        window.getNextCleanProductBarcode = getNextCleanProductBarcode;

        /** Sync main barcode ↔ piece row in units table (تاک). */
        function getPieceBarcodeCellEl() {
            return document.getElementById('p-barcode-piece') || document.getElementById('p-barcode-display');
        }
        function syncBarcodeToPieceCell() {
            var barcodeEl = document.getElementById('p-barcode');
            var pieceEl = getPieceBarcodeCellEl();
            if (!pieceEl) return;
            var val = (barcodeEl && barcodeEl.value) ? barcodeEl.value.trim() : '';
            if (pieceEl.tagName === 'INPUT' || pieceEl.tagName === 'TEXTAREA') {
                if (document.activeElement !== pieceEl) pieceEl.value = val;
            } else {
                pieceEl.textContent = val || '—';
            }
            syncInheritedLevelBarcodes();
        }
        function syncBarcodeFromPieceCell() {
            var barcodeEl = document.getElementById('p-barcode');
            var pieceEl = getPieceBarcodeCellEl();
            if (!barcodeEl || !pieceEl) return;
            if (pieceEl.tagName !== 'INPUT' && pieceEl.tagName !== 'TEXTAREA') return;
            if (document.activeElement === barcodeEl) return;
            barcodeEl.value = pieceEl.value || '';
            syncInheritedLevelBarcodes();
        }
        function isQdBarcodeField(el) {
            return !!(el && String(el.id || '').indexOf('qd-') === 0);
        }
        function getPieceBarcodeValueForEl(el) {
            if (isQdBarcodeField(el)) {
                var qPiece = document.getElementById('qd-piece-barcode-ref');
                if (qPiece && (qPiece.tagName === 'INPUT' || qPiece.tagName === 'TEXTAREA') && document.activeElement === qPiece) {
                    return String(qPiece.value || '').trim();
                }
                var qIn = document.getElementById('qd-barcode-input');
                if (qIn && !qIn.classList.contains('is-hidden')) return String(qIn.value || '').trim();
                var qDisp = document.getElementById('qd-barcode-display');
                if (qDisp) return String(qDisp.dataset.val || qDisp.textContent || '').replace(/^—$/, '').trim();
                if (qPiece) {
                    if (qPiece.tagName === 'INPUT' || qPiece.tagName === 'TEXTAREA') return String(qPiece.value || '').trim();
                    return String(qPiece.textContent || '').replace(/^—$/, '').trim();
                }
                return '';
            }
            var barcodeEl = document.getElementById('p-barcode');
            var pieceEl = getPieceBarcodeCellEl();
            if (pieceEl && (pieceEl.tagName === 'INPUT' || pieceEl.tagName === 'TEXTAREA') && document.activeElement === pieceEl) {
                return String(pieceEl.value || '').trim();
            }
            if (barcodeEl) return String(barcodeEl.value || '').trim();
            if (pieceEl) {
                if (pieceEl.tagName === 'INPUT' || pieceEl.tagName === 'TEXTAREA') return String(pieceEl.value || '').trim();
                return String(pieceEl.textContent || '').replace(/^—$/, '').trim();
            }
            return '';
        }
        function setLevelBarcodeInherited(el, inherited) {
            if (!el) return;
            el.classList.toggle('p-barcode-inherited', !!inherited);
            el.dataset.barcodeInherited = inherited ? '1' : '0';
            if (inherited) {
                var tip = (typeof t === 'function') ? t('product_form_barcode_inherited_tooltip') : '';
                el.title = (tip && tip !== 'product_form_barcode_inherited_tooltip') ? tip : 'بارکۆدا تاکە';
            } else if (el.getAttribute('data-i18n-title') !== 'product_form_barcode_tooltip') {
                el.removeAttribute('title');
            }
        }
        function resetLevelBarcodeField(el) {
            if (!el) return;
            el.value = '';
            el.dataset.barcodeManual = '0';
            setLevelBarcodeInherited(el, false);
        }
        function applyInheritedToField(el) {
            if (!el) return;
            var pieceVal = getPieceBarcodeValueForEl(el);
            var focused = document.activeElement === el;
            var cur = String(el.value || '').trim();
            var manual = el.dataset.barcodeManual === '1';
            if (manual && cur && cur !== pieceVal) {
                setLevelBarcodeInherited(el, false);
                return;
            }
            if (manual) el.dataset.barcodeManual = '0';
            if (!pieceVal) {
                if (!focused) el.value = '';
                setLevelBarcodeInherited(el, false);
                return;
            }
            if (focused) {
                setLevelBarcodeInherited(el, cur === pieceVal);
                return;
            }
            el.value = pieceVal;
            el.dataset.barcodeManual = '0';
            setLevelBarcodeInherited(el, true);
        }
        function syncInheritedLevelBarcodesFrom(sourceEl) {
            var ids = isQdBarcodeField(sourceEl)
                ? ['qd-barcode-pack', 'qd-barcode-carton']
                : ['p-barcode-pack', 'p-barcode-carton'];
            ids.forEach(function(id) { applyInheritedToField(document.getElementById(id)); });
        }
        function syncInheritedLevelBarcodes() {
            syncInheritedLevelBarcodesFrom(document.getElementById('p-barcode') || document.getElementById('p-barcode-piece'));
        }
        function qdSyncInheritedLevelBarcodes() {
            syncInheritedLevelBarcodesFrom(document.getElementById('qd-piece-barcode-ref') || document.getElementById('qd-barcode-input'));
        }
        function hydrateInheritedLevelBarcodes() {
            var pieceVal = getPieceBarcodeValueForEl(document.getElementById('p-barcode-pack'));
            ['p-barcode-pack', 'p-barcode-carton'].forEach(function(id) {
                var el = document.getElementById(id);
                if (!el) return;
                var cur = String(el.value || '').trim();
                el.dataset.barcodeManual = (cur && cur !== pieceVal) ? '1' : '0';
            });
            syncInheritedLevelBarcodes();
        }
        function onLevelBarcodeInput(el) {
            if (!el) return;
            var pieceVal = getPieceBarcodeValueForEl(el);
            var cur = String(el.value || '').trim();
            if (!cur) {
                el.dataset.barcodeManual = '0';
                setLevelBarcodeInherited(el, false);
                return;
            }
            if (pieceVal && cur === pieceVal) {
                el.dataset.barcodeManual = '0';
                setLevelBarcodeInherited(el, true);
                return;
            }
            el.dataset.barcodeManual = '1';
            setLevelBarcodeInherited(el, false);
        }
        function onLevelBarcodeBlur(el) {
            if (!el) return;
            var pieceVal = getPieceBarcodeValueForEl(el);
            var cur = String(el.value || '').trim();
            if (!cur && pieceVal) {
                el.dataset.barcodeManual = '0';
                el.value = pieceVal;
                setLevelBarcodeInherited(el, true);
                return;
            }
            if (pieceVal && cur === pieceVal) {
                el.dataset.barcodeManual = '0';
                setLevelBarcodeInherited(el, true);
                return;
            }
            if (cur) {
                el.dataset.barcodeManual = '1';
                setLevelBarcodeInherited(el, false);
            }
        }
        if (typeof window !== 'undefined') {
            window.syncBarcodeToPieceCell = syncBarcodeToPieceCell;
            window.syncBarcodeFromPieceCell = syncBarcodeFromPieceCell;
            window.syncInheritedLevelBarcodes = syncInheritedLevelBarcodes;
            window.qdSyncInheritedLevelBarcodes = qdSyncInheritedLevelBarcodes;
            window.hydrateInheritedLevelBarcodes = hydrateInheritedLevelBarcodes;
            window.onLevelBarcodeInput = onLevelBarcodeInput;
            window.onLevelBarcodeBlur = onLevelBarcodeBlur;
            window.resetLevelBarcodeField = resetLevelBarcodeField;
        }

        function handleProductFormEnter(e) {
            // Only handle keys when products view is active and focus is inside the product form (prevents freeze when form is hidden or on other views)
            var viewProducts = document.getElementById('view-products');
            var productFormCard = document.getElementById('product-form-card');
            if (!viewProducts || !viewProducts.classList.contains('active') || !productFormCard || !e.target || !e.target.closest || !e.target.closest('#product-form-card')) return;

            var focusables = getProductFormFocusables();
            var idx = focusables.length ? focusables.indexOf(e.target) : -1;

            // Tab: next field (same order as focusables); Shift+Tab: previous. Enforces 100% keyboard flow.
            if (e.key === 'Tab' && !e.altKey && !e.ctrlKey && !e.metaKey) {
                e.preventDefault();
                if (focusables.length === 0) return;
                if (e.shiftKey) {
                    var prevIdx = idx <= 0 ? focusables.length - 1 : idx - 1;
                    var el = focusables[prevIdx];
                    if (el) { el.focus(); if (el.tagName === 'INPUT' && el.type !== 'date' && el.type !== 'checkbox' && el.select) el.select(); }
                } else {
                    if (idx >= focusables.length - 1) {
                        if (typeof isProductFormAllSteps === 'function' && isProductFormAllSteps() && document.getElementById('btn-save-prod')) {
                            document.getElementById('btn-save-prod').click();
                        } else {
                            var step = typeof getCurrentProductFormStep === 'function' ? getCurrentProductFormStep() : 1;
                            if (step === 1 && document.getElementById('btn-step1-next')) document.getElementById('btn-step1-next').click();
                            else if (step === 2 && document.getElementById('btn-save-prod')) document.getElementById('btn-save-prod').click();
                        }
                    } else {
                        var nextEl = focusables[idx + 1];
                        nextEl.focus(); if (nextEl.tagName === 'INPUT' && nextEl.type !== 'date' && nextEl.type !== 'checkbox' && nextEl.select) nextEl.select();
                    }
                }
                return;
            }

            // Alt+Enter: on step 1, custom flow (barcode/name → conversions → table → expiry → save); category area unchanged (mouse)
            if (e.altKey && e.key === 'Enter') {
                e.preventDefault();
                var stepAlt = typeof getCurrentProductFormStep === 'function' ? getCurrentProductFormStep() : 1;
                if (stepAlt === 1 && e.target && e.target.closest && !e.target.closest('#layout-category-btns')) {
                    var flow = typeof productFormGetKeyboardFlowElements === 'function' ? productFormGetKeyboardFlowElements() : [];
                    var tid = e.target.id;
                    if (tid === 'p-barcode' || tid === 'p-barcode-piece' || tid === 'p-sku' || tid === 'p-name') {
                        if (flow.length) productFormFocusSelect(flow[0]);
                        return;
                    }
                    var fidx = flow.indexOf(e.target);
                    if (fidx !== -1) {
                        if (fidx < flow.length - 1) productFormFocusSelect(flow[fidx + 1]);
                        else productFormFocusSelect(document.getElementById('p-barcode'));
                        return;
                    }
                }
                if (focusables.length === 0) return;
                if (idx === -1) return;
                if (idx < focusables.length - 1) {
                    var nextEl2 = focusables[idx + 1];
                    nextEl2.focus();
                    if (nextEl2.tagName === 'INPUT' && nextEl2.type !== 'date' && nextEl2.type !== 'checkbox' && nextEl2.select) nextEl2.select();
                } else {
                    if (typeof isProductFormAllSteps === 'function' && isProductFormAllSteps() && document.getElementById('btn-save-prod')) {
                        document.getElementById('btn-save-prod').click();
                    } else {
                        var step = typeof getCurrentProductFormStep === 'function' ? getCurrentProductFormStep() : 1;
                        if (step === 1 && document.getElementById('btn-step1-next')) document.getElementById('btn-step1-next').click();
                        else if (step === 2 && document.getElementById('btn-save-prod')) document.getElementById('btn-save-prod').click();
                    }
                }
                return;
            }

            // Enter: prevent form submit / accidental save (barcode scanner sends Enter after scan)
            if (e.key === 'Enter') {
                e.preventDefault();
                if (e.target.id === 'p-barcode') {
                    var skuNext = document.getElementById('p-sku');
                    if (skuNext) { skuNext.focus(); return; }
                    var nameEl = document.getElementById('p-name');
                    if (nameEl) nameEl.focus();
                    return;
                }
                if (e.target.id === 'p-sku') {
                    var nameElSku = document.getElementById('p-name');
                    if (nameElSku) nameElSku.focus();
                    return;
                }
                // Zero Loss: ل دەما لێدانا Enter لسەر خانەیێن کرینێ، کرینێن دی حیساب بکە و بچە خانەیا دووڤدا
                if (e.target.id === 'p-cost-carton' || e.target.id === 'p-cost-pack') {
                    if (typeof syncCostFromLevel === 'function') syncCostFromLevel();
                    var focusables = getProductFormFocusables();
                    var idx = focusables.indexOf(e.target);
                    if (idx > -1 && idx < focusables.length - 1) {
                        var nextEl = focusables[idx + 1];
                        if (nextEl) { nextEl.focus(); if (nextEl.select) nextEl.select(); }
                    }
                    return;
                }

                if (e.target.id === 'btn-step1-next') return;
                if (e.target.id === 'btn-save-prod-step1' || e.target.id === 'btn-save-prod') { saveProduct(); return; }
                // Do not call saveProduct() on Enter from other fields — prevents barcode scanner from triggering save
                return;
            }

            // Arrow Keys for Quick Pricing (Price Field Only) - keep Left/Right for add price
            if (e.target.id === 'p-price') {
                if (e.key === 'ArrowRight') { e.preventDefault(); if (typeof addToPrice === 'function') addToPrice(250); return; }
                if (e.key === '/') { e.preventDefault(); if (typeof addToPrice === 'function') addToPrice(500); return; }
                if (e.key === 'ArrowLeft') { e.preventDefault(); if (typeof addToPrice === 'function') addToPrice(1000); return; }
            }

            // Arrow Key Navigation (Up/Down/Left/Right) between all focusable elements in current step
            if (e.key === 'ArrowDown' || e.key === 'ArrowUp' || e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
                var focusables = getProductFormFocusables();
                if (focusables.length === 0) return;
                var idx = focusables.indexOf(e.target);
                if (idx === -1) return;
                var dir = (e.key === 'ArrowDown' || e.key === 'ArrowRight') ? 1 : -1;
                var nextIdx = idx + dir;
                if (nextIdx < 0) nextIdx = focusables.length - 1;
                if (nextIdx >= focusables.length) nextIdx = 0;
                e.preventDefault();
                var el = focusables[nextIdx];
                el.focus();
                if (el.tagName === 'INPUT' && el.type !== 'date' && el.type !== 'checkbox' && el.select) el.select();
            }
        }

        function renderRecentItems() {
            const container = document.getElementById('recent-items-body');
            const card = document.getElementById('recent-items-card');
            if(recentAddedItems.length === 0) { card.style.display = 'none'; return; }
            card.style.display = 'block';
            container.innerHTML = recentAddedItems.map(function(p) {
                var si = typeof getCatalogPieceSellIqd === 'function' ? getCatalogPieceSellIqd(p) : p.price;
                var ci = typeof getCatalogPieceCostIqd === 'function' ? getCatalogPieceCostIqd(p) : p.cost;
                var sec = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'IQD' && typeof formatApproxUsdFromIqd === 'function')
                    ? function(iq) { return ' <small style="opacity:0.85">(~ $' + formatApproxUsdFromIqd(iq) + ')</small>'; }
                    : function() { return ''; };
                return '<tr><td><b>' + escapeHtml(p.name) + '</b></td><td>' + escapeHtml(p.barcode || '-') + '</td><td>' + formatCurrency(si) + sec(si) + '</td><td>' + formatCurrency(ci) + sec(ci) + '</td><td>' + (p.trackStock ? formatQtyForDisplay((p.qty || 0), p) : '∞') + '</td></tr>';
            }).join('');
        }

        function posStopLiveSync() {
            if (window.__posLiveSyncInterval) {
                clearInterval(window.__posLiveSyncInterval);
                window.__posLiveSyncInterval = null;
            }
            if (window.__posLanTickTimer) {
                clearTimeout(window.__posLanTickTimer);
                window.__posLanTickTimer = null;
            }
        }

        function posRestartLiveSync() {
            posStopLiveSync();
            if (typeof startAutoRefresh === 'function') startAutoRefresh();
        }
        window.posStopLiveSync = posStopLiveSync;
        window.posRestartLiveSync = posRestartLiveSync;

        function startLanTickSync() {
            if (typeof syncLiveData === 'function') syncLiveData(false);
            var runTick = function () {
                if (!db) {
                    window.__posLanTickTimer = setTimeout(runTick, 250);
                    return;
                }
                var _sv = document.getElementById('view-settings');
                if (_sv && _sv.classList.contains('active')) {
                    window.__posLanTickTimer = setTimeout(runTick, 400);
                    return;
                }
                var qs = 'action=get_sync_tick&t=' + Date.now();
                var url = (typeof window.posRouterUrl === 'function') ? window.posRouterUrl(qs) : ('?' + qs);
                fetch(url, { credentials: 'same-origin', cache: 'no-store' })
                    .then(function (r) { return r.json(); })
                    .then(function (data) {
                        if (data && data.status === 'auth_required') {
                            currentUser = null;
                            var loginEl = document.getElementById('login-screen');
                            if (loginEl) loginEl.style.display = 'flex';
                            return;
                        }
                        var st = parseFloat(data && data.server_time) || 0;
                        if (st > (parseFloat(lastSyncTime) || 0)) {
                            if (typeof syncLiveData === 'function') syncLiveData(false);
                        } else if (typeof updateSaveStatus === 'function') {
                            updateSaveStatus(true);
                        }
                    })
                    .catch(function () {
                        if (typeof updateSaveStatus === 'function') updateSaveStatus(false);
                    })
                    .then(function () {
                        window.__posLanTickTimer = setTimeout(runTick, 200);
                    });
            };
            window.__posLanTickTimer = setTimeout(runTick, 200);
        }

        function startAutoRefresh() {
            posStopLiveSync();
            if (typeof isPosFastLanSync === 'function' && isPosFastLanSync()) {
                startLanTickSync();
                return;
            }
            if (typeof shouldPosUseLongPoll === 'function' && !shouldPosUseLongPoll()) {
                var ms = (typeof posLiveSyncDelayMs === 'function') ? posLiveSyncDelayMs() : 60000;
                if (typeof syncLiveData === 'function') syncLiveData(false);
                window.__posLiveSyncInterval = setInterval(function () {
                    var _sv = document.getElementById('view-settings');
                    if (_sv && _sv.classList.contains('active')) return;
                    if (typeof syncLiveData === 'function') syncLiveData(false);
                }, ms);
                return;
            }
            if (typeof syncLiveData === 'function') syncLiveData(true);
        }

        // --- DATA SAFETY ---
        window.onbeforeunload = function() {
            // No local save needed
        };

        var _billRenderRaf = null;
        var _billRenderTimer = null;
        var _tabSnapshotTimer = null;
        window._posScanIndex = null;

        function _normalizeScanIndexCode(raw) {
            return typeof normalizeBarcodeSearchInput === 'function'
                ? normalizeBarcodeSearchInput(raw)
                : String(raw || '').trim().toLowerCase();
        }

        /** Remove one product's barcode entries from the scan index (O(codes for that product)). */
        function unregisterProductFromScanIndex(productId) {
            var idx = window._posScanIndex;
            if (!idx || !idx.exact) return;
            if (!idx.byId) idx.byId = Object.create(null);
            var pid = String(productId);
            var codes = idx.byId[pid];
            if (codes && codes.length) {
                codes.forEach(function (code) {
                    var arr = idx.exact[code];
                    if (!arr || !arr.length) return;
                    var next = arr.filter(function (e) { return String(e.id) !== pid; });
                    if (next.length) idx.exact[code] = next;
                    else delete idx.exact[code];
                });
            }
            delete idx.byId[pid];
        }

        /**
         * Incrementally add/update ONE product in the POS barcode scan index.
         * Prefer this over rebuildPosScanIndex() after product save.
         */
        function registerProductInScanIndex(p) {
            if (!p || p.id == null) return;
            if (!window._posScanIndex || !window._posScanIndex.exact) {
                window._posScanIndex = { exact: Object.create(null), byId: Object.create(null) };
            }
            if (!window._posScanIndex.byId) window._posScanIndex.byId = Object.create(null);
            unregisterProductFromScanIndex(p.id);
            var exact = window._posScanIndex.exact;
            var pid = String(p.id);
            var codesForId = [];
            var packOff = p.unit_show_pack != null && Number(p.unit_show_pack) === 0;
            var cartonOff = p.unit_show_carton != null && Number(p.unit_show_carton) === 0;
            function pushCode(raw, unit) {
                var nv = _normalizeScanIndexCode(raw);
                if (!nv) return;
                if (!exact[nv]) exact[nv] = [];
                exact[nv].push({ id: p.id, unit: unit, p: p });
                if (codesForId.indexOf(nv) === -1) codesForId.push(nv);
            }
            String(p.barcode || '').split(',').forEach(function (c) {
                var t = c.trim();
                if (t) pushCode(t, 'piece');
            });
            if (!packOff && p.barcode_pack) {
                String(p.barcode_pack).split(',').forEach(function (c) {
                    var t = c.trim();
                    if (t) pushCode(t, 'pack');
                });
            }
            if (!cartonOff && p.barcode_carton) {
                String(p.barcode_carton).split(',').forEach(function (c) {
                    var t = c.trim();
                    if (t) pushCode(t, 'carton');
                });
            }
            if (p.sku) pushCode(String(p.sku).trim(), 'piece');
            window._posScanIndex.byId[pid] = codesForId;
        }

        function rebuildPosScanIndex() {
            var exact = Object.create(null);
            var byId = Object.create(null);
            window._posScanIndex = { exact: exact, byId: byId };
            if (!db || !Array.isArray(db.products)) return;
            db.products.forEach(function (p) {
                if (!p || p.id == null) return;
                var packOff = p.unit_show_pack != null && Number(p.unit_show_pack) === 0;
                var cartonOff = p.unit_show_carton != null && Number(p.unit_show_carton) === 0;
                var codesForId = [];
                function pushCode(raw, unit) {
                    var nv = _normalizeScanIndexCode(raw);
                    if (!nv) return;
                    if (!exact[nv]) exact[nv] = [];
                    exact[nv].push({ id: p.id, unit: unit, p: p });
                    if (codesForId.indexOf(nv) === -1) codesForId.push(nv);
                }
                String(p.barcode || '').split(',').forEach(function (c) {
                    var t = c.trim();
                    if (t) pushCode(t, 'piece');
                });
                if (!packOff && p.barcode_pack) {
                    String(p.barcode_pack).split(',').forEach(function (c) {
                        var t = c.trim();
                        if (t) pushCode(t, 'pack');
                    });
                }
                if (!cartonOff && p.barcode_carton) {
                    String(p.barcode_carton).split(',').forEach(function (c) {
                        var t = c.trim();
                        if (t) pushCode(t, 'carton');
                    });
                }
                if (p.sku) pushCode(String(p.sku).trim(), 'piece');
                byId[String(p.id)] = codesForId;
            });
        }
        window.rebuildPosScanIndex = rebuildPosScanIndex;
        window.registerProductInScanIndex = registerProductInScanIndex;
        window.unregisterProductFromScanIndex = unregisterProductFromScanIndex;

        function scheduleSave() {
            // Edit mode: cart is saved via replace_sale_cart — do not sync table to SQL (would double-deduct stock).
            if (window._posEditingSale && window._posEditingSale.id) return;
            // Save ACTIVE TABLE items to SQL strictly sequentially (debounced — UI stays instant)
            if(activeTableId) {
                const t = (typeof findActivePosTable === 'function') ? findActivePosTable() : db.tables.find(x => x.id === activeTableId);
                if(t) {
                    if(saveTimeout) clearTimeout(saveTimeout);
                    var _saveDebounce = (typeof posCartSaveDebounceMs === 'function') ? posCartSaveDebounceMs() : 350;
                    saveTimeout = setTimeout(() => {
                        saveTimeout = null;
                        window._isCartSaving = true;
                        cartSaveQueue.push({
                            id: t.id,
                            items: JSON.stringify(t.items),
                            warehouse_id: (typeof getSaleWarehouseId === 'function' ? getSaleWarehouseId() : 0) || (typeof getWorkingWarehouseId === 'function' ? getWorkingWarehouseId() : 0) || 0
                        });
                        processCartSaveQueue();
                    }, _saveDebounce);
                }
            }
        }

        window.flushCartSaveNow = function flushCartSaveNow() {
            if (window._posEditingSale && window._posEditingSale.id) return Promise.resolve();
            if (!activeTableId || !db || !db.tables) return Promise.resolve();
            var t = (typeof findActivePosTable === 'function') ? findActivePosTable() : db.tables.find(function (x) { return x.id === activeTableId; });
            if (!t) return Promise.resolve();
            if (saveTimeout) { clearTimeout(saveTimeout); saveTimeout = null; }
            cartSaveQueue.push({
                id: t.id,
                items: JSON.stringify(t.items),
                warehouse_id: (typeof getSaleWarehouseId === 'function' ? getSaleWarehouseId() : 0) || (typeof getWorkingWarehouseId === 'function' ? getWorkingWarehouseId() : 0) || 0
            });
            processCartSaveQueue();
            return new Promise(function (resolve) {
                var tries = 0;
                var iv = setInterval(function () {
                    tries++;
                    if (!isSavingCartNetwork && cartSaveQueue.length === 0 && !window._isCartSaving) {
                        clearInterval(iv);
                        resolve();
                    } else if (tries > 80) {
                        clearInterval(iv);
                        resolve();
                    }
                }, 50);
            });
        };

        function scheduleRenderBill() {
            var _deb = (typeof posTxnCartRenderDebounceMs === 'function') ? posTxnCartRenderDebounceMs() : 0;
            if (_deb > 0) {
                if (_billRenderTimer) clearTimeout(_billRenderTimer);
                _billRenderTimer = setTimeout(function () {
                    _billRenderTimer = null;
                    if (typeof renderBill === 'function') renderBill();
                }, _deb);
                return;
            }
            if (_billRenderRaf) return;
            _billRenderRaf = requestAnimationFrame(function () {
                _billRenderRaf = null;
                if (typeof renderBill === 'function') renderBill();
            });
        }
        window.scheduleRenderBill = scheduleRenderBill;

        function scheduleTabSnapshot() {
            if (_tabSnapshotTimer) clearTimeout(_tabSnapshotTimer);
            var _tabMs = (typeof isPosTxnLiteMode === 'function' && isPosTxnLiteMode()) ? 650
                : ((typeof isPosTxnViewActive === 'function' && isPosTxnViewActive()) ? 350
                : ((typeof isPosCpuSaveMode === 'function' && isPosCpuSaveMode()) ? 500 : 400));
            _tabSnapshotTimer = setTimeout(function () {
                _tabSnapshotTimer = null;
                if (typeof saveActivePosTabSnapshot === 'function') saveActivePosTabSnapshot();
            }, _tabMs);
        }

        function cancelPendingPosTabSnapshot() {
            if (_tabSnapshotTimer) {
                clearTimeout(_tabSnapshotTimer);
                _tabSnapshotTimer = null;
            }
        }
        window.cancelPendingPosTabSnapshot = cancelPendingPosTabSnapshot;

        function refreshStockForProduct(productId) {
            if (productId == null || !db || !db.products) return;
            var prod = db.products.find(function (p) { return String(p.id) === String(productId); });
            if (!prod || typeof updateProductCardQty !== 'function') return;
            var displayQty = typeof getDisplayQty === 'function' ? getDisplayQty(prod) : (prod.qty || 0);
            updateProductCardQty(prod.id, displayQty, prod.trackStock);
            if (typeof refreshWmsStockCellForProduct === 'function') refreshWmsStockCellForProduct(prod.id);
        }

        /** Server rejected cart save (e.g. insufficient stock). Active table items are not merged in syncLiveData — reload this table + qty from DB so UI matches reality. */
        function revertLocalTableCartToServerAfterStockReject(tableId) {
            var tid = parseInt(tableId, 10);
            if (!tid || !db || !db.tables) return Promise.resolve();
            return fetch('?action=get_data&t=' + Date.now(), { credentials: 'same-origin' })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (!data || data.status === 'auth_required') return;
                    if (data.tables && Array.isArray(data.tables)) {
                        var srv = data.tables.find(function(t) { return t.id == tid; });
                        var localTbl = db.tables.find(function(t) { return t.id == tid; });
                        if (srv && localTbl) {
                            localTbl.items = Array.isArray(srv.items) ? srv.items.slice() : [];
                            if (localTbl.id === activeTableId) {
                                if (typeof renderBill === 'function') renderBill();
                                if (typeof saveActivePosTabSnapshot === 'function') saveActivePosTabSnapshot();
                            }
                        }
                    }
                    if (data.products && Array.isArray(data.products)) {
                        data.products.forEach(function(sp) {
                            var p = db.products.find(function(x) { return String(x.id) === String(sp.id); });
                            if (p && sp.trackStock) {
                                var syncedQty = normalizeQtyForProduct(p, sp.qty, db.settings.allowNegativeStock);
                                p.qty = db.settings.allowNegativeStock ? (syncedQty || 0) : Math.max(0, syncedQty || 0);
                            }
                        });
                        if (typeof refreshAllStockDisplaysFromState === 'function') refreshAllStockDisplaysFromState();
                    }
                })
                .catch(function() {});
        }

        function processCartSaveQueue() {
            if (isSavingCartNetwork || cartSaveQueue.length === 0) return;
            isSavingCartNetwork = true;
            
            const payload = cartSaveQueue.pop(); 
            cartSaveQueue = []; // Clear queue, we only need the latest state
            const saveGen = window._cartSaveGen || 0;
            
            const formData = new FormData();
            formData.append('action', 'update_table_items');
            formData.append('id', payload.id);
            formData.append('items', payload.items);
            formData.append('warehouse_id', String(payload.warehouse_id || 0));
            
            fetch('?action=update_table_items', { method: 'POST', body: formData })
                .then(function(r) { return r.json().catch(function() { return {}; }); })
                .then(function(res) {
                    isSavingCartNetwork = false;
                    if (saveGen !== (window._cartSaveGen || 0)) {
                        if (cartSaveQueue.length > 0) processCartSaveQueue();
                        else window._isCartSaving = false;
                        return;
                    }
                    if (res.status === 'error' && res.message === 'stock_not_enough') {
                        var avN = parseFloat(res.available);
                        if (isNaN(avN)) avN = 0;
                        var avStr = (Math.abs(avN - Math.round(avN)) < 0.0001) ? String(Math.round(avN)) : String(avN);
                        var nm = String(res.product_name || '').trim();
                        if (typeof showToast === 'function') {
                            showToast(
                                '⚠️ کۆگە تێر نینە'
                                + (nm ? ' — ' + nm : '')
                                + ' (بەردەست: ' + avStr + '). ژمارە د سەبەتێ کێم بکە.',
                                'warning'
                            );
                        }
                        revertLocalTableCartToServerAfterStockReject(payload.id);
                    }
                    if (cartSaveQueue.length > 0) processCartSaveQueue();
                    else window._isCartSaving = false;
                })
                .catch(function(err) {
                    isSavingCartNetwork = false;
                    if (saveGen !== (window._cartSaveGen || 0)) {
                        if (cartSaveQueue.length > 0) processCartSaveQueue();
                        else window._isCartSaving = false;
                        return;
                    }
                    if (cartSaveQueue.length > 0) processCartSaveQueue();
                    else window._isCartSaving = false;
                });
        }

        /** IQD total for 100 USD bundle; same integer as settings.usdRate (per-1-USD * 100). Smartly handles missing zeros, per-dollar, and extra-zero entries. */
        function normalizeUsdBundleRateFromInput(val) {
            var raw = Math.round(parseFloat(val));
            if (!isFinite(raw) || raw <= 0) raw = 150000;
            if (raw >= 50 && raw < 500) {
                // e.g. 150 or 170 -> missing 3 zeros
                raw = raw * 1000;
            } else if (raw >= 500 && raw < 10000) {
                // e.g. 1500 or 1700 -> single USD rate (missing 2 zeros)
                raw = raw * 100;
            } else if (raw >= 10000 && raw < 50000) {
                // e.g. 15000 or 17000 -> missing 1 zero!
                raw = raw * 10;
            } else if (raw > 500000 && raw <= 5000000) {
                // e.g. 1500000 or 1700000 -> 1 extra zero
                raw = Math.round(raw / 10);
            } else if (raw > 5000000 && raw <= 50000000) {
                // e.g. 15000000 -> 2 extra zeros
                raw = Math.round(raw / 100);
            }
            if (raw < 10000) raw = 10000;
            return raw;
        }

        function updateExchangeRateLivePreview() {
            var inp = document.getElementById('set-exchange-rate');
            var prevEl = document.getElementById('set-exchange-rate-live-preview');
            if (!inp || !prevEl) return;
            var raw = Math.round(parseFloat(inp.value));
            if (!isFinite(raw) || raw <= 0) {
                prevEl.innerHTML = '';
                return;
            }
            var bundle = normalizeUsdBundleRateFromInput(raw);
            var perOne = bundle / 100;
            var isAr = (document.documentElement && document.documentElement.lang === 'ar');

            var warningHtml = '';
            if (raw >= 50 && raw < 500) {
                // Missing 3 zeros (e.g. 150 -> 150000)
                var txt = isAr
                    ? '⚠️ تنبيه: ناقص ٣ أصفار! تم التعديل إلى ' + bundle.toLocaleString('en-US') + ' دينار لكل 100$ ($1 = ' + perOne.toLocaleString('en-US') + ' دينار).'
                    : '⚠️ ئاگاداری: ۳ سفر کێمن! هاتە ڕاستڤەکرن بۆ ' + bundle.toLocaleString('en-US') + ' دینار بۆ 100$ ($1 = ' + perOne.toLocaleString('en-US') + ' دینار).';
                warningHtml = '<div style="margin-top:4px; font-size:0.84rem; color:#b45309; background:#fef3c7; border:1px solid #fde68a; padding:3px 8px; border-radius:6px; display:inline-block; font-weight:700;">' + txt + '</div>';
            } else if (raw >= 500 && raw < 10000) {
                // Single dollar rate entered (e.g. 1500 -> 150000)
                var txt = isAr
                    ? 'ℹ️ تنبيه: تم إدخال سعر دولار واحد ($1 = ' + raw.toLocaleString('en-US') + ') — تم التحويل إلى ' + bundle.toLocaleString('en-US') + ' دينار لكل 100$.'
                    : 'ℹ️ ئاگاداری: تە نرخی ۱ دۆلار لێدایە ($1 = ' + raw.toLocaleString('en-US') + ') — هاتە گوهۆڕین بۆ ' + bundle.toLocaleString('en-US') + ' دینار بۆ 100 دۆلار.';
                warningHtml = '<div style="margin-top:4px; font-size:0.84rem; color:#1d4ed8; background:#eff6ff; border:1px solid #bfdbfe; padding:3px 8px; border-radius:6px; display:inline-block; font-weight:700;">' + txt + '</div>';
            } else if (raw >= 10000 && raw < 50000) {
                // Missing 1 zero (e.g. 15000 -> 150000)
                var txt = isAr
                    ? '⚠️ تنبيه: ناقص صفر واحد! تم التعديل إلى ' + bundle.toLocaleString('en-US') + ' دينار لكل 100$ ($1 = ' + perOne.toLocaleString('en-US') + ' دينار).'
                    : '⚠️ ئاگاداری: سفرەک کێمە! ژمارە هاتە ڕاستڤەکرن بۆ ' + bundle.toLocaleString('en-US') + ' دینار بۆ 100$ ($1 = ' + perOne.toLocaleString('en-US') + ' دینار).';
                warningHtml = '<div style="margin-top:4px; font-size:0.84rem; color:#b45309; background:#fef3c7; border:1px solid #fde68a; padding:3px 8px; border-radius:6px; display:inline-block; font-weight:700;">' + txt + '</div>';
            } else if (raw > 500000 && raw <= 5000000) {
                // Extra zero (e.g. 1500000 -> 150000)
                var txt = isAr
                    ? '⚠️ تنبيه: تم إدخال صفر إضافي! تم الحذف إلى ' + bundle.toLocaleString('en-US') + ' دينار لكل 100$ ($1 = ' + perOne.toLocaleString('en-US') + ' دينار).'
                    : '⚠️ ئاگاداری: سفرەکێ زێدە لێدایە! هاتە کێمکرن بۆ ' + bundle.toLocaleString('en-US') + ' دینار بۆ 100$ ($1 = ' + perOne.toLocaleString('en-US') + ' دینار).';
                warningHtml = '<div style="margin-top:4px; font-size:0.84rem; color:#dc2626; background:#fee2e2; border:1px solid #fecaca; padding:3px 8px; border-radius:6px; display:inline-block; font-weight:700;">' + txt + '</div>';
            } else if (raw > 5000000 && raw <= 50000000) {
                // Extra 2 zeros
                var txt = isAr
                    ? '⚠️ تنبيه: تم إدخال أصفار إضافية! تم الحذف إلى ' + bundle.toLocaleString('en-US') + ' دينار لكل 100$.'
                    : '⚠️ ئاگاداری: دوو سفرێن زێدە لێداینە! هاتنە لابردن بۆ ' + bundle.toLocaleString('en-US') + ' دینار بۆ 100$.';
                warningHtml = '<div style="margin-top:4px; font-size:0.84rem; color:#dc2626; background:#fee2e2; border:1px solid #fecaca; padding:3px 8px; border-radius:6px; display:inline-block; font-weight:700;">' + txt + '</div>';
            }

            prevEl.innerHTML = '<div style="display:flex; flex-direction:column; gap:3px;">'
                + '<div><i class="fas fa-calculator" style="margin-left:4px;"></i> <b>100$ = ' + bundle.toLocaleString('en-US') + ' دینار</b> <span style="opacity:0.8; font-size:0.85rem;">(1$ = ' + perOne.toLocaleString('en-US') + ' دینار)</span></div>'
                + warningHtml
                + '</div>';
        }
        window.updateExchangeRateLivePreview = updateExchangeRateLivePreview;

        function onExchangeRateInputBlur() {
            var inp = document.getElementById('set-exchange-rate');
            if (!inp) return;
            var raw = Math.round(parseFloat(inp.value));
            if (!isFinite(raw) || raw <= 0) return;
            var bundle = normalizeUsdBundleRateFromInput(raw);
            if (bundle > 0 && bundle !== raw) {
                inp.value = bundle;
                updateExchangeRateLivePreview();
            }
        }
        window.onExchangeRateInputBlur = onExchangeRateInputBlur;

        // --- CURRENCY SETTINGS ---
        function applyShopDefaultCurrency(mode) {
            mode = String(mode || '').toUpperCase() === 'USD' ? 'USD' : 'IQD';
            if (!db) return mode;
            if (!db.settings) db.settings = {};
            db.settings.currencyMode = mode;
            db.settings.defaultCurrency = mode;
            db.settings.default_currency = mode;
            try {
                localStorage.setItem('pos_currency_mode', mode);
                localStorage.setItem('pos_default_currency', mode);
            } catch (eLs) {}
            return mode;
        }
        function ensureValidCurrencyMode() {
            if (!db || !db.settings) return;
            var d = String(db.settings.currencyMode || db.settings.defaultCurrency || db.settings.default_currency || 'IQD').toUpperCase();
            applyShopDefaultCurrency(d);
        }
        /** IQD/USD shop mode locks after the first catalog item. Delete all items to unlock. */
        function isCurrencyModeLocked() {
            if (!db) return false;
            if (db.settings && db.settings.currencyBaseLocked === true) return true;
            var n = parseInt(db._db_health && db._db_health.products_count, 10);
            if (Number.isFinite(n) && n > 0) return true;
            if (db.products && db.products.length > 0) return true;
            return false;
        }
        /** Exchange rate stays live so mixed IQD/USD carts can convert. */
        function isIqdExchangeRateLocked() {
            return false;
        }
        function canEditShopExchangeRate() {
            try {
                if (typeof canEditExchangeRate === 'function') return !!canEditExchangeRate();
            } catch (e) {}
            return false;
        }
        function syncExchangeRateLockUI() {
            var locked = !canEditShopExchangeRate();
            var rate = 150000;
            if (db && db.settings && Number(db.settings.usdRate) > 0) {
                rate = Math.round(Number(db.settings.usdRate));
            }
            var inp = document.getElementById('set-exchange-rate');
            if (inp) {
                if (!inp.value || !isFinite(parseFloat(inp.value))) inp.value = String(rate);
                inp.disabled = !!locked;
                inp.readOnly = !!locked;
                inp.style.cursor = locked ? 'not-allowed' : '';
                inp.style.opacity = locked ? '0.72' : '';
                inp.style.background = locked ? '#f1f5f9' : '';
                if (locked) inp.title = (typeof t === 'function') ? t('exchange_rate_iqd_locked') : '';
                else inp.removeAttribute('title');
            }
            var lockHint = document.getElementById('set-exchange-rate-iqd-lock');
            if (lockHint) {
                lockHint.style.display = locked ? 'block' : 'none';
                if (typeof t === 'function') lockHint.textContent = t('exchange_rate_iqd_locked');
            }
            var secretInp = document.getElementById('secret-exchange-rate');
            if (secretInp) {
                secretInp.disabled = !!locked;
                secretInp.readOnly = !!locked;
                secretInp.style.cursor = locked ? 'not-allowed' : '';
                secretInp.style.opacity = locked ? '0.72' : '';
            }
            var secretSave = document.getElementById('secret-exchange-rate-save');
            if (secretSave) secretSave.disabled = !!locked;
            var modalInp = document.getElementById('modal-usd-rate-input');
            if (modalInp) {
                modalInp.disabled = !!locked;
                modalInp.readOnly = !!locked;
            }
        }
        if (typeof window !== 'undefined') {
            window.applyShopDefaultCurrency = applyShopDefaultCurrency;
            window.ensureValidCurrencyMode = ensureValidCurrencyMode;
            window.isCurrencyModeLocked = isCurrencyModeLocked;
            window.isIqdExchangeRateLocked = isIqdExchangeRateLocked;
            window.syncExchangeRateLockUI = syncExchangeRateLockUI;
        }
        function syncProductsCatalogCurrencyRadiosFromDb() {
            window._syncingCatalogCurrencyRadios = true;
            try {
                ensureValidCurrencyMode();
                var mode = (typeof getActiveCurrency === 'function') ? getActiveCurrency() : 'IQD';
                var iqdP = document.getElementById('products-catalog-currency-iqd');
                var usdP = document.getElementById('products-catalog-currency-usd');
                if (iqdP) iqdP.checked = (mode === 'IQD');
                if (usdP) usdP.checked = (mode === 'USD');
            } catch (e) {}
            finally {
                window._syncingCatalogCurrencyRadios = false;
            }
        }
        function applyProductsCatalogCurrency() {
            if (window._syncingCatalogCurrencyRadios) return;
            if (!db || !db.settings) return;
            if (typeof isCurrencyModeLocked === 'function' && isCurrencyModeLocked()) return;
            var iqdP = document.getElementById('products-catalog-currency-iqd');
            var usdP = document.getElementById('products-catalog-currency-usd');
            applyShopDefaultCurrency((iqdP && iqdP.checked) ? 'IQD' : 'USD');
            saveSettings().then(function() {
                showToast('✅ ' + (typeof t === 'function' ? t('toast_catalog_currency_saved') : 'Saved'));
                if (typeof refreshAfterCurrencySettingsSave === 'function') refreshAfterCurrencySettingsSave();
            }).catch(function(e) {
                showToast('❌ ' + (e && e.message ? e.message : 'Save failed'), true);
            });
        }
        window.applyProductsCatalogCurrency = applyProductsCatalogCurrency;
        function getProductFormCurrency() {
            var usdR = document.getElementById('p-base-currency-usd');
            if (usdR && usdR.checked) return 'USD';
            var iqdR = document.getElementById('p-base-currency-iqd');
            if (iqdR && iqdR.checked) return 'IQD';
            return (typeof getDefaultCurrency === 'function') ? getDefaultCurrency() : ((typeof getActiveCurrency === 'function') ? getActiveCurrency() : 'IQD');
        }
        function setProductFormCurrency(cur, skipConvert) {
            cur = String(cur || '').toUpperCase() === 'USD' ? 'USD' : 'IQD';
            var iqdR = document.getElementById('p-base-currency-iqd');
            var usdR = document.getElementById('p-base-currency-usd');
            if (iqdR) iqdR.checked = (cur === 'IQD');
            if (usdR) usdR.checked = (cur === 'USD');
            if (typeof applyProductFormMoneyKind === 'function') applyProductFormMoneyKind(cur);
            if (!skipConvert && typeof applyMoneyInputFields === 'function') applyMoneyInputFields();
        }
        function applyProductFormMoneyKind(cur) {
            cur = cur || getProductFormCurrency();
            var usd = cur === 'USD';
            var ids = ['p-price', 'p-cost', 'p-takeaway-price', 'p-price-pack', 'p-cost-pack', 'p-takeaway-price-pack',
                'p-price-carton', 'p-cost-carton', 'p-takeaway-price-carton', 'p-wholesale-price', 'p-jewelry-price', 'p-jewelry-set-price'];
            ids.forEach(function(id) {
                var el = document.getElementById(id);
                if (!el) return;
                el.classList.add('pos-money-input');
                el.dataset.moneyInputKind = usd ? 'usd' : 'int';
                el.placeholder = usd ? '0.00' : '0';
                el.title = usd ? '$ (USD)' : 'د.ع (IQD)';
            });
        }
        function onProductFormCurrencyChange() {
            if (typeof applyProductFormMoneyKind === 'function') applyProductFormMoneyKind();
            if (typeof applyMoneyInputFields === 'function') applyMoneyInputFields();
        }
        if (typeof window !== 'undefined') {
            window.getProductFormCurrency = getProductFormCurrency;
            window.setProductFormCurrency = setProductFormCurrency;
            window.onProductFormCurrencyChange = onProductFormCurrencyChange;
            window.applyProductFormMoneyKind = applyProductFormMoneyKind;
        }
        function updateCurrencyLockUI() {
            var locked = typeof isCurrencyModeLocked === 'function' && isCurrencyModeLocked();
            var row = document.getElementById('settings-base-currency-row');
            var iqdRadio = document.getElementById('set-currency-iqd');
            var usdRadio = document.getElementById('set-currency-usd');
            var rateRow = document.getElementById('settings-exchange-rate-row');
            var mode = (typeof getActiveCurrency === 'function') ? getActiveCurrency() : 'IQD';
            if (row) row.style.display = '';
            if (iqdRadio) {
                iqdRadio.disabled = !!locked;
                iqdRadio.checked = (mode === 'IQD');
            }
            if (usdRadio) {
                usdRadio.disabled = !!locked;
                usdRadio.checked = (mode === 'USD');
            }
            if (rateRow) rateRow.style.display = '';
            var blurb = document.getElementById('currency-settings-blurb');
            if (blurb && typeof t === 'function') {
                blurb.textContent = t(locked ? 'currency_blurb_locked' : 'currency_blurb_unlocked');
            }
            var hint = document.getElementById('settings-currency-catalog-hint');
            if (hint && typeof t === 'function') {
                hint.textContent = t(locked ? 'inventory_base_currency_locked' : 'currency_unlock_until_first_product');
            }
            var invUn = document.getElementById('products-catalog-currency-unlocked-block');
            var invLk = document.getElementById('products-catalog-currency-locked-block');
            if (invUn && invLk) {
                invUn.style.display = locked ? 'none' : 'block';
                invLk.style.display = locked ? 'block' : 'none';
                if (!locked) syncProductsCatalogCurrencyRadiosFromDb();
            }
            if (typeof applyCurrencyModeUiText === 'function') applyCurrencyModeUiText();
            if (typeof syncExchangeRateLockUI === 'function') syncExchangeRateLockUI();
        }
        function getMoneyInputKind() {
            return (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD') ? 'usd' : 'int';
        }
        function parseMoneyInputToIqd(val) {
            if (typeof productFormInputToIqd === 'function') return productFormInputToIqd(val);
            var n = parseFloat(String(val == null ? '' : val).replace(/,/g, '').trim());
            return isFinite(n) ? n : 0;
        }
        /** Parse a money field: IQD for storage + frozen USD unit when in USD mode. */
        function buildCartLineMoneyFromInput(val) {
            var price = parseMoneyInputToIqd(val);
            var out = { price: price };
            var u = typeof productFormParseUsdRaw === 'function' ? productFormParseUsdRaw(val) : NaN;
            var formUsd = (typeof getMoneyInputKind === 'function' && getMoneyInputKind() === 'usd');
            if (formUsd && isFinite(u) && u >= 0) out.bill_unit_usd = u;
            else {
                var rLine = typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0;
                if (rLine > 0 && price > 0) out.bill_unit_usd = parseFloat((price / rLine).toFixed(6));
            }
            return out;
        }
        function iqdToMoneyInputDisplay(iqd) {
            if (typeof productFormMoneyIqdToInput === 'function') return productFormMoneyIqdToInput(iqd);
            return String(Math.round(parseFloat(iqd) || 0));
        }
        function manualQuickItemIqdToDisplay(iqd) {
            return iqdToMoneyInputDisplay(iqd);
        }
        function buildManualLineFromStoredIqd(name, iqdPrice) {
            var price = (typeof roundMoney === 'function') ? roundMoney(parseFloat(iqdPrice) || 0) : Math.round(parseFloat(iqdPrice) || 0);
            var line = { name: name, price: price };
            var r = typeof getPosFrozenFxRatePerOne === 'function' ? getPosFrozenFxRatePerOne(null) : (typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0);
            if (r > 0) {
                line.bill_unit_usd = (typeof storedIqdToUsdAmount === 'function')
                    ? storedIqdToUsdAmount(price, r)
                    : parseFloat((price / r).toFixed(6));
                line.fx_rate_per_one = r;
            }
            return line;
        }
        var POS_MONEY_INPUT_IDS = [
            'manual-item-price', 'manual-item-cost', 'manual-modal-new-price', 'manual-modal-new-cost', 'settings-quick-item-price',
            'qd-price', 'qd-cost', 'qd-price-pack', 'qd-cost-pack', 'qd-price-carton', 'qd-cost-carton',
            'p-price', 'p-cost', 'p-takeaway-price',
            'p-price-pack', 'p-cost-pack', 'p-takeaway-price-pack',
            'p-price-carton', 'p-cost-carton', 'p-takeaway-price-carton',
            'p-wholesale-price', 'p-jewelry-price', 'p-jewelry-set-price',
            'opening-balance-input', 'e-amount', 'pcd-amount',
            'del-delivery-cost', 'c-opening-balance', 'new-cust-opening-balance',
            'cc-edit-opening-balance', 'cc-edit-debt-limit', 'c-debt-limit', 'new-cust-debt-limit',
            'pos-customer-paid', 'pos-expand-customer-paid', 'reconcile-actual'
        ];
        function resolveMoneyInputFormatKind(el) {
            if (!el) return null;
            if (el.dataset && el.dataset.moneyInputKind) return el.dataset.moneyInputKind;
            var payFmtKind = {
                'pay-received': 'iqd', 'pay-usd-input': 'usd',
                'ppay-received': 'iqd', 'ppay-usd-input': 'usd',
                'pay-debt-amount': null, 'pay-bank-card-amount': null,
                'ppay-debt-amount': null, 'ppay-bank-card-amount': null,
                'purchase-supplier-paid': null
            };
            if (el.id && payFmtKind[el.id] != null) return payFmtKind[el.id];
            if (el.id === 'purchase-supplier-paid') {
                return (typeof getPurchasePaymentInputKind === 'function') ? getPurchasePaymentInputKind() : getMoneyInputKind();
            }
            if (el.id === 'pay-debt-amount' || el.id === 'pay-bank-card-amount') return getMoneyInputKind();
            if (el.id === 'ppay-debt-amount' || el.id === 'ppay-bank-card-amount') return getMoneyInputKind();
            if (el.classList && el.classList.contains('pos-money-input')) return getMoneyInputKind();
            if (el.id && POS_MONEY_INPUT_IDS.indexOf(el.id) >= 0) {
                if (el.id.indexOf('p-') === 0) {
                    return (typeof getProductFormCurrency === 'function' && getProductFormCurrency() === 'USD') ? 'usd' : 'int';
                }
                if (el.id === 'e-amount') {
                    var expCur = document.getElementById('e-currency');
                    if (expCur && String(expCur.value || '').toUpperCase() === 'USD') return 'usd';
                    if (expCur && String(expCur.value || '').toUpperCase() === 'IQD') return 'int';
                }
                return getMoneyInputKind();
            }
            return null;
        }
        function applyMoneyInputFields(scope) {
            var root = scope || document;
            var usd = getMoneyInputKind() === 'usd';
            var tf = (typeof t === 'function');
            function T(k, fb) { if (!tf) return fb; var s = t(k); return (s && s !== k) ? s : fb; }
            var titleTxt = usd ? '$ (USD)' : T('money_input_iqd', 'د.ع (IQD)');
            var ph = usd ? '0.00' : '0';
            POS_MONEY_INPUT_IDS.forEach(function(id) {
                if (/^p-/.test(id) || id.indexOf('p-') === 0) return;
                if (id === 'e-amount') return;
                var el = root.getElementById ? root.getElementById(id) : document.getElementById(id);
                if (!el) return;
                el.classList.add('pos-money-input');
                el.dataset.moneyInputKind = usd ? 'usd' : 'int';
                el.setAttribute('inputmode', 'decimal');
                el.setAttribute('dir', 'ltr');
                if (el.type === 'number') el.type = 'text';
                if (!el.dataset.placeholderIqd) el.dataset.placeholderIqd = el.placeholder || '0';
                el.placeholder = usd ? '0.00' : (el.dataset.placeholderIqd || '0');
                el.title = titleTxt;
            });
            if (typeof applyProductFormMoneyKind === 'function') applyProductFormMoneyKind();
            root.querySelectorAll && root.querySelectorAll('.pos-money-input').forEach(function(el) {
                if (el.id && String(el.id).indexOf('p-') === 0) return;
                if (el.id === 'e-amount') return;
                el.dataset.moneyInputKind = usd ? 'usd' : 'int';
                el.title = titleTxt;
            });
            if (typeof syncExpenseAmountInputKind === 'function') syncExpenseAmountInputKind();
            var manualLbl = document.querySelector('label[for="manual-item-price"] [data-i18n="manual_item_price"]');
            if (manualLbl) manualLbl.textContent = usd ? T('manual_item_price_usd', 'بها ($)') : T('manual_item_price', 'بها (دینار)');
            if (typeof syncCcEditMoneyFieldLabels === 'function') syncCcEditMoneyFieldLabels();
            if (typeof syncDuhokPaperUsdInputHints === 'function') syncDuhokPaperUsdInputHints();
        }
        if (typeof window !== 'undefined') {
            window.getMoneyInputKind = getMoneyInputKind;
            window.parseMoneyInputToIqd = parseMoneyInputToIqd;
            window.buildCartLineMoneyFromInput = buildCartLineMoneyFromInput;
            window.iqdToMoneyInputDisplay = iqdToMoneyInputDisplay;
            window.manualQuickItemIqdToDisplay = manualQuickItemIqdToDisplay;
            window.buildManualLineFromStoredIqd = buildManualLineFromStoredIqd;
            window.applyMoneyInputFields = applyMoneyInputFields;
            window.resolveMoneyInputFormatKind = resolveMoneyInputFormatKind;
        }
        function applyCurrencyModeUiText() {
            var isUsdMode = (typeof getActiveCurrency === 'function') ? (getActiveCurrency() === 'USD') : false;
            var tf = (typeof t === 'function');
            function T(k, fb) { if (!tf) return fb; var s = t(k); return (s && s !== k) ? s : fb; }
            var payDebtLabel = document.getElementById('pay-debt-amount-label');
            var payBankLabel = document.getElementById('pay-bank-amount-label');
            var payReceivedLabel = document.getElementById('pay-received-label');
            var ppayDebtLabel = document.getElementById('ppay-debt-amount-label');
            var ppayBankLabel = document.getElementById('ppay-bank-amount-label');
            var ppayReceivedLabel = document.getElementById('ppay-received-label');
            var payToggleIqd = document.getElementById('pay-toggle-iqd');
            var ppayToggleIqd = document.getElementById('ppay-toggle-iqd');
            if (payDebtLabel) payDebtLabel.textContent = isUsdMode ? T('payment_debt_amount_lbl_usd', 'بڕی قەرز – $') : T('payment_debt_amount_lbl_iqd', 'بڕی قەرز – د.ع');
            if (payBankLabel) payBankLabel.textContent = isUsdMode ? T('payment_bank_amount_lbl_usd', 'FIB – $') : T('payment_bank_amount_lbl_iqd', 'FIB – د.ع');
            if (payReceivedLabel) payReceivedLabel.textContent = isUsdMode ? T('payment_received_lbl_usd', 'پارەی وەرگیراو – $') : T('payment_received_lbl_iqd', 'پارەی وەرگیراو – د.ع');
            if (ppayDebtLabel) ppayDebtLabel.textContent = isUsdMode ? T('payment_debt_amount_lbl_usd', 'بڕی قەرز – $') : T('payment_debt_amount_lbl_iqd', 'بڕی قەرز – د.ع');
            if (ppayBankLabel) ppayBankLabel.textContent = isUsdMode ? T('payment_bank_amount_lbl_usd', 'FIB – $') : T('payment_bank_amount_lbl_iqd', 'FIB – د.ع');
            if (ppayReceivedLabel) ppayReceivedLabel.textContent = isUsdMode ? T('payment_received_lbl_usd', 'پارەی وەرگیراو – $') : T('payment_received_lbl_iqd', 'پارەی وەرگیراو – د.ع');
            if (payToggleIqd) payToggleIqd.style.display = '';
            if (ppayToggleIqd) ppayToggleIqd.style.display = '';
            var purchasePaidInput = document.getElementById('purchase-supplier-paid');
            if (purchasePaidInput) {
                purchasePaidInput.placeholder = isUsdMode
                    ? T('purchase_supplier_paid_ph_usd', 'پارێ دای ($)')
                    : T('purchase_supplier_paid_ph_iqd', 'پارێ دای (د.ع)');
                purchasePaidInput.title = purchasePaidInput.placeholder;
                if (purchasePaidInput.value && typeof formatPaymentInputElement === 'function') {
                    formatPaymentInputElement(purchasePaidInput, isUsdMode ? 'usd' : 'int');
                }
            }
            if (typeof applyMoneyInputFields === 'function') applyMoneyInputFields();
            if (typeof enforceUsdNoIqdText === 'function') enforceUsdNoIqdText();
        }
        function sanitizeIqdTextForUsd(input) {
            var s = String(input == null ? '' : input);
            if (!s) return s;
            // Preserve intentional IQD on dual-currency print lines: "$ 240 · 366,000 د.ع"
            var preserved = [];
            s = s.replace(/(\$\s*[\d,]+(?:\.\d+)?\s*[·•]\s*[\d,]+(?:\.\d+)?)\s*د\.?\s*ع/gi, function(m) {
                preserved.push(m);
                return '\uE000IQD' + (preserved.length - 1) + '\uE001';
            });
            // FX line on A4: "$1 = 1,550 د.ع" — rate is dinar, never "$"
            s = s.replace(/(\$\s*1\s*=\s*[\d,]+(?:\.\d+)?)\s*د\.?\s*ع/gi, function(m) {
                preserved.push(m);
                return '\uE000IQD' + (preserved.length - 1) + '\uE001';
            });
            s = s.replace(/(<(?:div|span)[^>]*(?:\ba4-iqd-hint\b|\ba4-pay-iqd-hint\b|\ba4-d1-total-iqd\b|\bpos-total-iqd-hint\b|data-allow-iqd\s*=\s*["']1["'])[^>]*>)([\s\S]*?)(<\/(?:div|span)>)/gi, function(m, open, inner, close) {
                preserved.push(inner);
                return open + '\uE000IQD' + (preserved.length - 1) + '\uE001' + close;
            });
            s = s.replace(/IQD\s*0/gi, '0');
            s = s.replace(/0\s*IQD/gi, '0');
            s = s.replace(/\(\s*IQD\s*\)/gi, '($)');
            s = s.replace(/\bUSD\s*\/\s*IQD\b/gi, 'USD/$');
            s = s.replace(/\bIQD\b/gi, '$');
            s = s.replace(/د\.?\s*ع/gi, '$');
            s = s.replace(/دينار(?:\s*عراقي)?/gi, '$');
            s = s.replace(/دینار(?:\s*عێراقی)?/g, '$');
            for (var i = 0; i < preserved.length; i++) {
                s = s.split('\uE000IQD' + i + '\uE001').join(preserved[i]);
            }
            return s;
        }
        function enforceUsdNoIqdText(scope) {
            try {
                if (!(typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD')) return;
                var root = scope || document.body;
                if (!root) return;
                var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
                var node;
                while ((node = walker.nextNode())) {
                    if (!node || !node.nodeValue) continue;
                    var parentTag = node.parentNode && node.parentNode.nodeName ? String(node.parentNode.nodeName).toLowerCase() : '';
                    if (parentTag === 'script' || parentTag === 'style') continue;
                    if (node.parentNode && node.parentNode.closest && node.parentNode.closest('[data-allow-iqd="1"], .a4-iqd-hint, .a4-pay-iqd-hint, .a4-d1-total-iqd, .a4-d1-meta-line, .pos-total-iqd-hint, #printable-area, .print-a4-container, .print-thermal-container')) continue;
                    if (node.parentNode && node.parentNode.closest && (
                        node.parentNode.closest('#settings-exchange-rate-row') ||
                        node.parentNode.closest('#basket-usd-visual-rate') ||
                        node.parentNode.closest('#usd-rate-modal') ||
                        node.parentNode.closest('#products-catalog-currency-panel') ||
                        node.parentNode.closest('#settings-base-currency-row')
                    )) continue;
                    var cleaned = sanitizeIqdTextForUsd(node.nodeValue);
                    if (cleaned !== node.nodeValue) node.nodeValue = cleaned;
                }
                root.querySelectorAll('[title],[placeholder],[aria-label]').forEach(function(el) {
                    if (el.closest && el.closest('[data-allow-iqd="1"], .a4-iqd-hint, .a4-pay-iqd-hint, .a4-d1-total-iqd, .a4-d1-meta-line, .pos-total-iqd-hint, #printable-area, .print-a4-container, .print-thermal-container')) return;
                    if (el.closest && (
                        el.closest('#settings-exchange-rate-row') ||
                        el.closest('#basket-usd-visual-rate') ||
                        el.closest('#usd-rate-modal') ||
                        el.closest('#products-catalog-currency-panel') ||
                        el.closest('#settings-base-currency-row')
                    )) return;
                    ['title', 'placeholder', 'aria-label'].forEach(function(attr) {
                        var oldV = el.getAttribute(attr);
                        if (oldV == null || oldV === '') return;
                        var newV = sanitizeIqdTextForUsd(oldV);
                        if (newV !== oldV) el.setAttribute(attr, newV);
                    });
                });
            } catch (e) {}
        }
        function applyCurrencyFromLocalStorage() {
            if (!db || !db.settings) return;
            try {
                if (db.settings.usdRate != null && Number(db.settings.usdRate) > 0) {
                    var normServer = (typeof normalizeUsdBundleRateFromInput === 'function')
                        ? normalizeUsdBundleRateFromInput(db.settings.usdRate)
                        : ((typeof normalizeUsdBundleRate === 'function') ? normalizeUsdBundleRate(db.settings.usdRate) : Math.round(Number(db.settings.usdRate)));
                    db.settings.usdRate = normServer;
                    try { localStorage.setItem('pos_usd_rate', String(normServer)); } catch (_e) {}
                } else {
                    var rate = localStorage.getItem('pos_usd_rate');
                    if (rate !== null && rate !== '') {
                        var r = parseInt(rate, 10);
                        if (!isNaN(r) && r > 0) {
                            var norm = (typeof normalizeUsdBundleRateFromInput === 'function')
                                ? normalizeUsdBundleRateFromInput(r)
                                : ((typeof normalizeUsdBundleRate === 'function') ? normalizeUsdBundleRate(r) : r);
                            db.settings.usdRate = norm;
                            try { localStorage.setItem('pos_usd_rate', String(norm)); } catch (_e2) {}
                        }
                    }
                }
                var serverMode = String(db.settings.currencyMode || '').toUpperCase();
                if (serverMode === 'USD' || serverMode === 'IQD') {
                    localStorage.setItem('pos_currency_mode', serverMode);
                    if (typeof ensureValidCurrencyMode === 'function') ensureValidCurrencyMode();
                    return;
                }
                if (typeof isCurrencyModeLocked === 'function' && isCurrencyModeLocked()) return;
                var mode = localStorage.getItem('pos_currency_mode');
                if (mode === 'IQD' || mode === 'USD') db.settings.currencyMode = mode;
                if (typeof ensureValidCurrencyMode === 'function') ensureValidCurrencyMode();
            } catch (e) {}
        }
        if (typeof window !== 'undefined') window.applyCurrencyFromLocalStorage = applyCurrencyFromLocalStorage;

        function applyCurrencySettings() {
            if (!db || !db.settings) return;
            var rateInput = document.getElementById('set-exchange-rate');
            var usdRadio = document.getElementById('set-currency-usd');
            var iqdRadio = document.getElementById('set-currency-iqd');
            var prevMode = String((db.settings && db.settings.currencyMode) || 'IQD').toUpperCase();
            if (typeof isCurrencyModeLocked === 'function' && !isCurrencyModeLocked()) {
                if (usdRadio && usdRadio.checked) applyShopDefaultCurrency('USD');
                else if (iqdRadio && iqdRadio.checked) applyShopDefaultCurrency('IQD');
            }
            ensureValidCurrencyMode();
            var nextMode = String((db.settings && db.settings.currencyMode) || 'IQD').toUpperCase();
            var canRate = (typeof canEditShopExchangeRate === 'function') ? canEditShopExchangeRate() : false;
            if (rateInput && canRate) {
                db.settings.usdRate = normalizeUsdBundleRateFromInput(rateInput.value);
            } else if (!db.settings.usdRate) {
                db.settings.usdRate = 150000;
            }
            try {
                localStorage.setItem('pos_usd_rate', String(db.settings.usdRate));
                localStorage.setItem('pos_currency_mode', db.settings.currencyMode || 'IQD');
                localStorage.setItem('pos_default_currency', db.settings.defaultCurrency || db.settings.currencyMode || 'IQD');
            } catch (e) {}
            saveSettings().then(function() {
                var toastKey = (prevMode !== nextMode) ? 'toast_catalog_currency_saved' : 'toast_exchange_rate_saved';
                showToast('✅ ' + (typeof t === 'function' ? t(toastKey) : 'Saved'));
                if (typeof refreshAfterCurrencySettingsSave === 'function') refreshAfterCurrencySettingsSave();
            }).catch(function(e) { showToast('❌ ' + (e.message || 'خطأ في الحفظ'), true); });
        }

        /** Catalog: IQD columns in DB; in USD mode optional *_usd columns are canonical and IQD is derived at current rate. @see docs/currency_model.md */
        function productFormMoneyIqdToInput(iqd) {
            var n = parseFloat(iqd);
            if (!isFinite(n)) return '';
            var display;
            var kind;
            var shopCur = (typeof getActiveCurrency === 'function') ? getActiveCurrency() : 'IQD';
            if (shopCur === 'USD') {
                var r = typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0;
                if (!r || r <= 0) {
                    display = Math.round(n);
                    kind = 'int';
                } else {
                    display = parseFloat((n / r).toFixed(2));
                    kind = 'usd';
                }
            } else {
                display = Math.round(n);
                kind = 'int';
            }
            if (typeof formatPaymentAmountNumber === 'function') {
                return formatPaymentAmountNumber(display, kind);
            }
            return String(display);
        }
        function productFormMoneyOptionalIqdToInput(iqd) {
            if (iqd === '' || iqd === null || iqd === undefined) return '';
            var n = parseFloat(iqd);
            if (!isFinite(n) || n === 0) return '';
            return productFormMoneyIqdToInput(n);
        }
        function productFormInputToIqd(val, currency) {
            var raw = String(val == null ? '' : val).replace(/,/g, '').trim();
            if (raw === '') return 0;
            var n = parseFloat(raw);
            if (!isFinite(n)) return 0;
            var cur = currency
                ? String(currency).toUpperCase()
                : ((typeof getActiveCurrency === 'function') ? getActiveCurrency() : 'IQD');
            if (cur === 'USD') {
                var r = typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0;
                if (!r || r <= 0) return Math.round(n);
                return Math.round(n * r);
            }
            return Math.round(n);
        }
        /** Parse a money field typed as USD (no FX multiply). */
        function productFormParseUsdRaw(val) {
            var raw = String(val == null ? '' : val).replace(/,/g, '').trim();
            if (raw === '') return NaN;
            var n = parseFloat(raw);
            return isFinite(n) ? n : NaN;
        }
        function updateProductFormFxHints() {
            try {
                var r = typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0;
                function hintFor(iqdFromField, elId) {
                    var el = document.getElementById(elId);
                    if (!el || !r || r <= 0) return;
                    if (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'IQD') {
                        var iq = typeof iqdFromField === 'function' ? iqdFromField() : 0;
                        el.title = (iq > 0 && typeof formatApproxUsdFromIqd === 'function') ? ('≈ $' + formatApproxUsdFromIqd(iq) + ' USD') : '';
                    } else {
                        var usdV = typeof productFormParseUsdRaw === 'function' ? productFormParseUsdRaw(el.value) : NaN;
                        if (usdV > 0 && isFinite(usdV)) {
                            var iq2 = Math.round(usdV * r);
                            el.title = '≈ ' + (typeof formatCurrency === 'function' ? formatCurrency(iq2) : String(iq2)) + ' IQD';
                        } else el.title = '';
                    }
                }
                hintFor(function() { return typeof productFormInputToIqd === 'function' ? productFormInputToIqd((document.getElementById('p-price') && document.getElementById('p-price').value) || 0) : 0; }, 'p-price');
                hintFor(function() { return typeof productFormInputToIqd === 'function' ? productFormInputToIqd((document.getElementById('p-cost') && document.getElementById('p-cost').value) || 0) : 0; }, 'p-cost');
            } catch (err) {}
        }
        function refreshAfterCurrencySettingsSave() {
            try {
                localStorage.setItem('pos_usd_rate', String(db.settings.usdRate));
                localStorage.setItem('pos_currency_mode', db.settings.currencyMode || 'IQD');
                localStorage.setItem('pos_default_currency', db.settings.defaultCurrency || db.settings.currencyMode || 'IQD');
            } catch (e) {}
            var rateInput = document.getElementById('set-exchange-rate');
            if (rateInput) rateInput.value = Math.round(db.settings.usdRate || 150000);
            if (typeof updateExchangeRateLivePreview === 'function') updateExchangeRateLivePreview();
            if (typeof fillJewelryRateInputs === 'function') fillJewelryRateInputs();
            if (typeof syncJewelryUiVisibility === 'function') syncJewelryUiVisibility();
            if (typeof applyPrintSettings === 'function') applyPrintSettings();
            if (typeof updateCurrencyLockUI === 'function') updateCurrencyLockUI();
            if (typeof updateUSDBadge === 'function') updateUSDBadge();
            if (typeof applyProductFormCurrencyDefaultForNewItem === 'function') applyProductFormCurrencyDefaultForNewItem();
            if (typeof connectToDB === 'function') {
                connectToDB(true).then(function() {
                    if (typeof renderAll === 'function') renderAll();
                }).catch(function() {
                    if (typeof renderAll === 'function') renderAll();
                });
            } else if (typeof posEnsureCatalogLoaded === 'function') {
                posEnsureCatalogLoaded().then(function() {
                    if (typeof renderAll === 'function') renderAll();
                }).catch(function() {
                    if (typeof renderAll === 'function') renderAll();
                });
            } else {
                if (typeof renderAll === 'function') renderAll();
            }
        }
        /** Form input string: prefer stored base_price / USD when present, else IQD→display conversion. */
        function productFormDisplayMoneyInput(prod, iqdField, usdField) {
            var formCur = (typeof getProductFormCurrency === 'function') ? getProductFormCurrency() : ((prod && prod.base_currency) ? String(prod.base_currency).toUpperCase() : ((typeof getActiveCurrency === 'function') ? getActiveCurrency() : 'IQD'));
            if (formCur === 'USD' && prod) {
                var baseKey = (iqdField === 'price') ? 'base_price' : ((iqdField === 'cost') ? 'base_cost' : '');
                if (baseKey && String(prod.base_currency || '').toUpperCase() === 'USD' && prod[baseKey] != null && prod[baseKey] !== '' && !isNaN(parseFloat(prod[baseKey]))) {
                    var bx = parseFloat(prod[baseKey]);
                    if (isFinite(bx) && bx > 0) {
                        bx = parseFloat(bx.toFixed(2));
                        return (typeof formatPaymentAmountNumber === 'function') ? formatPaymentAmountNumber(bx, 'usd') : String(bx);
                    }
                }
                if (usdField) {
                    var u = prod[usdField];
                    if (u != null && u !== '' && !isNaN(parseFloat(u))) {
                        var x = parseFloat(u);
                        if (!isFinite(x)) return '';
                        x = parseFloat(x.toFixed(2));
                        return (typeof formatPaymentAmountNumber === 'function') ? formatPaymentAmountNumber(x, 'usd') : String(x);
                    }
                }
            }
            var iq = 0;
            if (prod && (iqdField === 'price' || iqdField === 'cost') && String(prod.base_currency || '').toUpperCase() === 'IQD') {
                var bIqd = (iqdField === 'price') ? prod.base_price : prod.base_cost;
                if (bIqd != null && bIqd !== '' && !isNaN(parseFloat(bIqd)) && parseFloat(bIqd) > 0) {
                    iq = parseFloat(bIqd);
                }
            }
            if (!(iq > 0) && prod && prod[iqdField] != null) iq = Number(prod[iqdField]) || 0;
            if (formCur === 'USD') {
                var rDisp = typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0;
                var usdDisp = rDisp > 0 ? (iq / rDisp) : 0;
                usdDisp = parseFloat(usdDisp.toFixed(2));
                return (typeof formatPaymentAmountNumber === 'function') ? formatPaymentAmountNumber(usdDisp, 'usd') : String(usdDisp);
            }
            return (typeof formatPaymentAmountNumber === 'function') ? formatPaymentAmountNumber(Math.round(iq), 'int') : String(Math.round(iq || 0));
        }
        /** Round a value derived inside the product form (same display unit as the inputs). */
        function productFormFormatDerivedField(n) {
            if (!isFinite(n)) return '';
            var formCur = (typeof getProductFormCurrency === 'function') ? getProductFormCurrency() : ((typeof getActiveCurrency === 'function') ? getActiveCurrency() : 'IQD');
            if (formCur === 'USD') {
                n = Math.round(n * 100) / 100;
                return (typeof formatPaymentAmountNumber === 'function') ? formatPaymentAmountNumber(n, 'usd') : String(n);
            }
            n = Math.round(n);
            return (typeof formatPaymentAmountNumber === 'function') ? formatPaymentAmountNumber(n, 'int') : String(n);
        }

        // --- TELEGRAM & SETTINGS ---
        function savePrintSettings() {
            if(!db.settings) db.settings = {};
            const rateInput = document.getElementById('set-exchange-rate');
            var canRate = (typeof canEditShopExchangeRate === 'function') ? canEditShopExchangeRate() : false;
            if (rateInput && canRate && !(typeof isIqdExchangeRateLocked === 'function' && isIqdExchangeRateLocked())) {
                db.settings.usdRate = normalizeUsdBundleRateFromInput(rateInput.value);
            } else if (!db.settings.usdRate) {
                db.settings.usdRate = 150000;
            }
            if (typeof applyJewelryRateSettings === 'function') applyJewelryRateSettings(false);
            var usdR = document.getElementById('set-currency-usd');
            var iqdR = document.getElementById('set-currency-iqd');
            if (usdR && iqdR && typeof isCurrencyModeLocked === 'function' && !isCurrencyModeLocked()) {
                if (typeof applyShopDefaultCurrency === 'function') {
                    applyShopDefaultCurrency(iqdR.checked ? 'IQD' : 'USD');
                } else {
                    db.settings.currencyMode = iqdR.checked ? 'IQD' : 'USD';
                }
            }
            ensureValidCurrencyMode();
            
            const enableWholesale = document.getElementById('set-enable-wholesale');
            if(enableWholesale) db.settings.enableWholesale = enableWholesale.checked;
            
            const enableManual = document.getElementById('set-enable-manual-price');
            if(enableManual) db.settings.enableManualPrice = enableManual.checked;
            const enableManualSale = document.getElementById('set-enable-manual-sale');
            if (enableManualSale) db.settings.enableManualSale = enableManualSale.checked;

            const sortOutOfStockBottom = document.getElementById('set-sort-out-of-stock-bottom');
            if (sortOutOfStockBottom) db.settings.sortOutOfStockToBottom = sortOutOfStockBottom.checked;

            const showReturn = document.getElementById('set-show-return-button');
            if(showReturn) db.settings.showReturnButton = showReturn.checked;

            const showStockOnPos = document.getElementById('set-show-stock-on-pos');
            if(showStockOnPos) db.settings.showStockOnPos = showStockOnPos.checked;
            const hideWhStockWarn = document.getElementById('set-hide-warehouse-stock-warn');
            if (hideWhStockWarn) db.settings.hideWarehouseStockWarn = hideWhStockWarn.checked;
            const showBothCur = document.getElementById('set-show-both-currencies');
            if (showBothCur) db.settings.showBothCurrencies = showBothCur.checked;

            // Telegram Settings
            const tgToken = document.getElementById('tg-bot-token');
            const tgChatId = document.getElementById('tg-chat-id');
            const tgInterval = document.getElementById('set-tg-interval');
            
            if(tgToken) db.settings.tgToken = tgToken.value.trim();
            if(tgChatId) db.settings.tgChatId = tgChatId.value.trim();
            var setLabMin2 = document.getElementById('set-label-min-stock-alert');
            var setLabEx2 = document.getElementById('set-label-expiry-alert-days');
            if (setLabMin2) db.settings.labelProductMinStockAlert = setLabMin2.value.trim();
            if (setLabEx2) db.settings.labelProductExpiryAlertDays = setLabEx2.value.trim();

            var useGlobalMinStockEl = document.getElementById('set-use-global-min-stock');
            if (useGlobalMinStockEl) db.settings.useGlobalMinStock = useGlobalMinStockEl.checked;
            var globalMinStockThresholdEl = document.getElementById('set-global-min-stock-threshold');
            if (globalMinStockThresholdEl) db.settings.globalMinStockThreshold = parseInt(globalMinStockThresholdEl.value, 10) || 0;
            
            saveSettings().then(() => {
                if (typeof persistSystemFeaturesToStorage === 'function') persistSystemFeaturesToStorage();
                if (typeof applyUserPermissions === 'function') applyUserPermissions();
                if (typeof renderRightSidebar === 'function') renderRightSidebar();
                var homeEl = document.getElementById('home-grid-container');
                if (homeEl && typeof renderHomeView === 'function') renderHomeView();
                showToast("✅ " + (typeof t === 'function' ? t('toast_saved') : 'ڕێکخستن هاتنە پاراستن!'));
                try {
                    localStorage.setItem('pos_usd_rate', String(db.settings.usdRate));
                    localStorage.setItem('pos_currency_mode', db.settings.currencyMode || 'IQD');
                    localStorage.setItem('pos_default_currency', db.settings.defaultCurrency || db.settings.currencyMode || 'IQD');
                } catch (eLs) {}
                if (typeof connectToDB === 'function') {
                    connectToDB(true).then(function() {
                        if (typeof renderAll === 'function') renderAll();
                    }).catch(function() {
                        if (typeof renderAll === 'function') renderAll();
                    });
                } else {
                    renderAll();
                }
                if (typeof updateUSDBadge === 'function') updateUSDBadge();
                if (typeof updateCurrencyLockUI === 'function') updateCurrencyLockUI();
                if (typeof applyProductFormFieldLabels === 'function') applyProductFormFieldLabels();
                try {
                    var viewP = document.getElementById('view-products');
                    var pidEl = document.getElementById('p-id');
                    if (viewP && viewP.classList.contains('active') && pidEl && String(pidEl.value || '').trim() !== '' && typeof editProd === 'function') {
                        editProd(parseInt(pidEl.value, 10));
                    }
                } catch (eRf) {}
            }).catch(e => showToast("❌ " + e.message, true));
        }

        async function manualTelegramSend() {
            const msg = prompt("نامەیەک بنڤیسە بۆ ناردن (Telegram):");
            if(msg) {
                await sendTelegramNotification("📢 **Manual Message**\n\n" + msg);
                alert("نامە هاتە ناردن!");
            }
        }

        async function sendTelegramNotification(msg) {
            const token = db.settings.tgToken;
            const chatId = db.settings.tgChatId;
            if(!token || !chatId) {
                // Return silently instead of alerting, so it doesn't block the UI
                return;
            }
            if (db.settings.tgPaused === true) {
                // Telegram sending is paused via the quick toggle button
                return;
            }

            // Obfuscate Telegram API URL to prevent false positive antivirus detection
            const tgHost = atob('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3Jn');
            const method = atob('c2VuZE1lc3NhZ2U=');
            const url = `${tgHost}/bot${token}/${method}`;
            const payload = { chat_id: chatId, text: msg, parse_mode: 'Markdown' };

            try {
                fetch(url, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify(payload)
                }).then(res => res.json()).then(d => {
                     if(!d.ok) console.error("Telegram Error:", d);
                }).catch(e => console.error("Telegram Net Error:", e));
            } catch(e) { console.error("Telegram Exception:", e); }
        }

        async function saveToDisk() {
            // Placeholder
        }
        
        function saveSettings() {
            if (!db || !db.settings) return;
            const formData = new FormData();
            formData.append('action', 'save_settings');
            formData.append('settings', JSON.stringify(db.settings));
            
            // Also ensure pos_license_force_unlocked_local is synced to server-side settings table if changed
            if (db.settings.pos_license_force_unlocked_local != null) {
                formData.append('pos_license_force_unlocked_local', db.settings.pos_license_force_unlocked_local ? '1' : '0');
            }

            return apiJson('?action=save_settings', { method: 'POST', body: formData })
                .then(function(data) {
                    if (data.status !== 'success') throw new Error(data.message && data.message !== 'Unknown' ? data.message : (typeof t === 'function' ? t('toast_save_failed') : "هەڵە د پاراستنێ دا (Save failed)."));
                    if (data.warehouses_collapsed && typeof connectToDB === 'function') {
                        connectToDB(true).then(function() {
                            if (typeof applyMultiWarehouseVisibility === 'function') applyMultiWarehouseVisibility();
                            if (typeof posAfterWarehouseDataLoaded === 'function') posAfterWarehouseDataLoaded('multi_wh_off');
                            if (typeof refreshAllStockDisplaysFromState === 'function') refreshAllStockDisplaysFromState();
                            if (typeof renderWarehouse === 'function') renderWarehouse();
                        }).catch(function() {});
                    }
                    return data;
                });
        }

function updateSaveStatus(connected) {
            var dot = document.getElementById('save-status-dot');
            var txt = document.getElementById('save-status-text');
            if (connected) {
                if (dot) dot.style.color = 'var(--success)';
                if (txt) txt.innerText = (typeof t === 'function') ? t('sidebar_db_connected') : 'گرێدایە (MySQL)';
            }
            var st = document.getElementById('right-sidebar-status');
            var stTxt = document.getElementById('right-sidebar-status-text');
            if (st) st.classList.toggle('disconnected', !connected);
            if (stTxt) {
                stTxt.innerText = connected
                    ? ((typeof t === 'function') ? t('sidebar_db_connected') : 'گرێدایە (MySQL)')
                    : ((typeof t === 'function') ? t('sidebar_db_disconnected') : 'پەیوەندی نینە');
                stTxt.setAttribute('data-i18n', connected ? 'sidebar_db_connected' : 'sidebar_db_disconnected');
            }
        }


        function createDefaultDB() {
            db = { 
                tables: [], products: [], companies: [], supplies: [], 
                sales: [], expenses: [], logs: [], archive: [], ledger: [],
                users: [],
                shifts: [],
                settings: { cafeName: "لپتۆپ دهۆک - لاب توب دهوك", cafeInfo: "", footer: "سوپاس بۆ سەردانتان - شكراً لزيارتكم", logo: "", paperWidth: "80mm", tgToken: "", tgChatId: "", autoPrint: true, enableTakeaway: false, systemMode: 'market', showTables: true, enableDelivery: true, enableKitchen: false, enableRecipe: false, businessSetupDone: true, useBarcode: true, theme: 'light', enableDebt: true, showStockOnPos: true, showCustomerName: true, showItemNoteIcon: true, settingsPin: "2026", language: 'badini', labelProductMinStockAlert: 'حد تنبيه الكمية', labelProductExpiryAlertDays: 'تنبيه قبل الانتهاء (يوم)', businessDayStartHour: 0, currencyMode: 'IQD' },
                categories: ["General", "Drinks", "Food", "Snacks"]
            };
            db.tables.push({id: 1, name: 'T1', items:[]}, {id:2, name:'T2', items:[]});
        }

        function _settingsStaticT(key, fb) {
            if (typeof getCurrentLanguage === 'function' && getCurrentLanguage() === 'ar' && typeof t === 'function') {
                var v = t(key);
                if (v && v !== key) return v;
            }
            return fb;
        }
        function applySettingsStaticUi(root) {
            if (!root) root = document.getElementById('view-settings');
            if (!root) return;
            root.querySelectorAll('[data-settings-i18n]').forEach(function(el) {
                var key = el.getAttribute('data-settings-i18n');
                if (!key) return;
                var fb = el.getAttribute('data-settings-fb');
                if (!fb) {
                    fb = (el.textContent || '').trim();
                    if (fb) el.setAttribute('data-settings-fb', fb);
                }
                el.textContent = _settingsStaticT(key, fb);
            });
            root.querySelectorAll('[data-settings-i18n-placeholder]').forEach(function(el) {
                var key = el.getAttribute('data-settings-i18n-placeholder');
                if (!key) return;
                var fb = el.getAttribute('data-settings-fb') || el.getAttribute('placeholder') || '';
                if (fb && !el.getAttribute('data-settings-fb')) el.setAttribute('data-settings-fb', fb);
                el.setAttribute('placeholder', _settingsStaticT(key, fb));
            });
            if (!root.id || root.id === 'view-settings' || root.closest('#view-settings')) {
                if (typeof renderSettingsChangelog === 'function') renderSettingsChangelog();
            }
        }
        function renderSettingsChangelog() {
            var listEl = document.getElementById('settings-changelog-list');
            var countEl = document.getElementById('settings-changelog-count');
            if (!listEl || !window.POS_CHANGELOG || !window.POS_CHANGELOG.length) return;
            var all = window.POS_CHANGELOG;
            var lang = (typeof getCurrentLanguage === 'function' && getCurrentLanguage() === 'ar') ? 'ar' : 'badini';
            var curVer = (typeof window.getPosAppVersion === 'function') ? String(window.getPosAppVersion()) : String(window.POS_APP_VERSION || '');
            var esc = (typeof escapeHtml === 'function') ? escapeHtml : function(s) { return String(s == null ? '' : s); };
            var currentBadge = _settingsStaticT('settings_changelog_current', 'ئێستا');
            if (countEl) {
                var countTpl = _settingsStaticT('settings_changelog_count', '{n} وەشان');
                countEl.textContent = countTpl.replace('{n}', String(all.length));
            }
            listEl.innerHTML = all.map(function(entry) {
                var items = (entry.items && entry.items[lang]) ? entry.items[lang] : ((entry.items && entry.items.badini) ? entry.items.badini : (entry.items || []));
                if (!Array.isArray(items)) items = [];
                var isCurrent = curVer && String(entry.version) === curVer;
                var lis = items.map(function(item) {
                    var plain = (typeof posChangelogPlainText === 'function') ? posChangelogPlainText(item, lang) : item;
                    return '<li>' + esc(plain) + '</li>';
                }).join('');
                return '<div class="settings-changelog-entry' + (isCurrent ? ' is-current' : '') + '">' +
                    '<button type="button" class="settings-changelog-toggle" onclick="toggleSettingsChangelogEntry(this)" aria-expanded="false">' +
                    '<i class="fas fa-chevron-down settings-changelog-chevron" aria-hidden="true"></i>' +
                    '<span class="settings-changelog-ver-pill">v' + esc(entry.version) + '</span>' +
                    (isCurrent ? '<span class="settings-changelog-badge">' + esc(currentBadge) + '</span>' : '') +
                    (entry.date ? '<span class="settings-changelog-date">' + esc(entry.date) + '</span>' : '') +
                    '</button>' +
                    (lis ? '<div class="settings-changelog-body"><ul class="settings-changelog-items">' + lis + '</ul></div>' : '') +
                    '</div>';
            }).join('');
            var currentEntry = listEl.querySelector('.settings-changelog-entry.is-current');
            if (currentEntry) {
                currentEntry.classList.add('is-open');
                var curBtn = currentEntry.querySelector('.settings-changelog-toggle');
                if (curBtn) curBtn.setAttribute('aria-expanded', 'true');
            }
        }
        function toggleSettingsChangelogEntry(btn) {
            if (!btn) return;
            var entry = btn.closest('.settings-changelog-entry');
            if (!entry) return;
            var willOpen = !entry.classList.contains('is-open');
            var list = document.getElementById('settings-changelog-list');
            if (list) {
                list.querySelectorAll('.settings-changelog-entry').forEach(function(e) {
                    e.classList.remove('is-open');
                    var b = e.querySelector('.settings-changelog-toggle');
                    if (b) b.setAttribute('aria-expanded', 'false');
                });
            }
            if (willOpen) {
                entry.classList.add('is-open');
                btn.setAttribute('aria-expanded', 'true');
                try { entry.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } catch (e) {}
            }
        }
        function openSettingsChangelogModal() {
            var modal = document.getElementById('settings-changelog-modal');
            if (modal) modal.style.display = 'flex';
            if (typeof applySettingsStaticUi === 'function') applySettingsStaticUi(modal);
            if (typeof renderSettingsChangelog === 'function') renderSettingsChangelog();
        }
        function closeSettingsChangelogModal() {
            var modal = document.getElementById('settings-changelog-modal');
            if (modal) modal.style.display = 'none';
        }
        window.openSettingsChangelogModal = openSettingsChangelogModal;
        window.closeSettingsChangelogModal = closeSettingsChangelogModal;
        window.renderSettingsChangelog = renderSettingsChangelog;
        window.toggleSettingsChangelogEntry = toggleSettingsChangelogEntry;
        window.applySettingsStaticUi = applySettingsStaticUi;
        window.applySettingsAboutUi = applySettingsStaticUi;
        function openRestoreWarningModal() {
            var modal = document.getElementById('modal-restore-warning');
            if (!modal) return;
            if (typeof applySettingsStaticUi === 'function') applySettingsStaticUi(modal);
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
            modal.style.display = 'flex';
        }
        async function confirmRestoreThenPickFile() {
            var currencyEl = document.getElementById('restore-currency-choice');
            var currLabel = (currencyEl && currencyEl.value === 'USD') ? 'دولار ($)' : 'دینار عێراقی (IQD)';
            var tr = (typeof t === 'function') ? t : function () { return ''; };
            if (typeof posConfirmDataRestore === 'function') {
                var ok = await posConfirmDataRestore({
                    source: tr('confirm_data_restore_source_file') || 'گەڕاندنەوە لە فایل',
                    currencyLabel: currLabel
                });
                if (!ok) return;
            }
            var modal = document.getElementById('modal-restore-warning');
            if (modal) modal.style.display = 'none';
            window._posRestoreSkipConfirmOnce = true;
            var inp = document.getElementById('restore-input');
            if (inp) inp.click();
        }
        async function confirmRestoreMysqlDataPickFile() {
            var tr = (typeof t === 'function') ? t : function () { return ''; };
            if (typeof posConfirmDataRestore === 'function') {
                var ok = await posConfirmDataRestore({
                    source: tr('confirm_data_restore_source_mysql') || 'گەڕاندنەوەی mysql/data بۆ XAMPP',
                    detail: '١) XAMPP → Stop MySQL\n٢) دواتر فایل هەڵبژێرە'
                });
                if (!ok) return;
            }
            window._posRestoreMysqlSkipConfirmOnce = true;
            var inp = document.getElementById('restore-mysql-data-input');
            if (inp) inp.click();
        }
        window.openRestoreWarningModal = openRestoreWarningModal;
        window.confirmRestoreThenPickFile = confirmRestoreThenPickFile;
        window.confirmRestoreMysqlDataPickFile = confirmRestoreMysqlDataPickFile;
        function openDbManageModal() {
            var modal = document.getElementById('modal-db-manage');
            if (!modal) return;
            if (typeof applySettingsStaticUi === 'function') applySettingsStaticUi(modal);
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
            modal.style.display = 'flex';
            if (typeof loadLocalBackupsList === 'function') loadLocalBackupsList();
            if (typeof posRefreshFlashBackupUi === 'function') posRefreshFlashBackupUi(true);
            if (typeof refreshMobileBackupPinUi === 'function') refreshMobileBackupPinUi();
        }
        window.openDbManageModal = openDbManageModal;

