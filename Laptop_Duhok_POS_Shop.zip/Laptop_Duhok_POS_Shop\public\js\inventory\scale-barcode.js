/**
 * EAN-13 electronic scale barcode parser (prefix 2, PLU, embedded total price).
 * Example: 2000001002902 → PLU 1, total price 290 IQD.
 */
(function () {
    function normalizeDigits(raw) {
        if (typeof window.normalizeBarcodeSearchInput === 'function') {
            return window.normalizeBarcodeSearchInput(raw);
        }
        return String(raw == null ? '' : raw).trim().replace(/[^\d]/g, '');
    }

    function normalizePlu(code) {
        var s = String(code == null ? '' : code).trim();
        if (!s || !/^\d+$/.test(s)) return '';
        var n = parseInt(s, 10);
        if (!isFinite(n) || n < 0) return '';
        return String(n);
    }

    /**
     * @param {string} raw - Scanned barcode
     * @returns {{ isScale: false, raw: string } | { isScale: true, raw: string, itemCode: number, itemCodeRaw: string, totalPrice: number }}
     */
    function parseEan13ScaleBarcode(raw) {
        var digits = normalizeDigits(raw);
        if (!digits) {
            return { isScale: false, raw: String(raw == null ? '' : raw).trim() };
        }
        if (digits.length !== 13 || !/^\d{13}$/.test(digits)) {
            return { isScale: false, raw: digits };
        }
        if (digits.charAt(0) !== '2') {
            return { isScale: false, raw: digits };
        }
        var itemCodeRaw = digits.slice(1, 7);
        var itemCode = parseInt(itemCodeRaw, 10);
        var totalPrice = parseInt(digits.slice(7, 12), 10);
        if (!isFinite(itemCode) || itemCode < 0 || !isFinite(totalPrice) || totalPrice < 0) {
            return { isScale: false, raw: digits };
        }
        return {
            isScale: true,
            raw: digits,
            itemCode: itemCode,
            itemCodeRaw: itemCodeRaw,
            totalPrice: totalPrice
        };
    }

    function productBarcodeMatchesPlu(product, pluNorm) {
        if (!product || !pluNorm) return false;
        var raw = String(product.barcode || '').trim();
        if (!raw) return false;
        var parts = raw.split(',');
        for (var i = 0; i < parts.length; i++) {
            var seg = normalizePlu(parts[i].trim());
            if (seg && seg === pluNorm) return true;
        }
        return false;
    }

    /**
     * Find catalog product by scale PLU (stored in barcode field).
     * @param {number|string} itemCode - Parsed PLU integer
     * @returns {object|null}
     */
    function findProductByScalePlu(itemCode) {
        var pluNorm = normalizePlu(itemCode);
        if (!pluNorm) return null;
        var dbRef = typeof window.db !== 'undefined' ? window.db : null;
        if (!dbRef || !Array.isArray(dbRef.products)) return null;
        var found = null;
        for (var i = 0; i < dbRef.products.length; i++) {
            var p = dbRef.products[i];
            if (!p || p.id == null) continue;
            if (productBarcodeMatchesPlu(p, pluNorm)) {
                if (found) return null;
                found = p;
            }
        }
        return found;
    }

    window.parseEan13ScaleBarcode = parseEan13ScaleBarcode;
    window.findProductByScalePlu = findProductByScalePlu;
    window.normalizeScalePlu = normalizePlu;
})();
