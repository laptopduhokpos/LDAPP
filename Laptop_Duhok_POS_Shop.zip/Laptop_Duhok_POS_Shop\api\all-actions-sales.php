<?php
// POST: stocktake, checkout, returns
    // --- WMS: Apply stocktake (update product qty + insert stock_movements for audit) ---
    if($act == 'apply_stocktake') {
        if (function_exists('pos_ensure_stocktake_history_schema')) pos_ensure_stocktake_history_schema($conn);
        $itemsJson = isset($_POST['items']) ? $_POST['items'] : '';
        $items = json_decode($itemsJson, true);
        $user = $_POST['user'] ?? (isset($_SESSION['user']) ? $_SESSION['user'] : 'System');
        $warehouseId = pos_resolve_product_warehouse_id_for_save($conn, (int)($_POST['warehouse_id'] ?? 0));
        $period = strtolower(trim((string)($_POST['period'] ?? 'spot')));
        if (!in_array($period, ['monthly', 'yearly', 'spot'], true)) $period = 'spot';
        $note = trim((string)($_POST['note'] ?? ''));
        if (function_exists('mb_substr')) $note = mb_substr($note, 0, 240);
        else $note = substr($note, 0, 240);
        $itemsOk = (int)($_POST['items_ok'] ?? 0);
        if (!is_array($items) || empty($items)) {
            echo json_encode(['status' => 'error', 'message' => 'چ گوهۆڕین نینن.']);
            exit();
        }
        $date = date('Y-m-d H:i:s');
        $updated = 0;
        $shortQty = 0.0;
        $surplusQty = 0.0;
        $shortValue = 0.0;
        $surplusValue = 0.0;
        $nShort = 0;
        $nSurplus = 0;
        $conn->begin_transaction();
        try {
            $sessionId = 0;
            $stSess = $conn->prepare("INSERT INTO stocktake_sessions (period, warehouse_id, date, user, note, items_changed, items_short, items_surplus, items_ok, short_qty, surplus_qty, short_value, surplus_value, net_value) VALUES (?, ?, ?, ?, ?, 0, 0, 0, ?, 0, 0, 0, 0, 0)");
            if ($stSess) {
                $stSess->bind_param('sisssi', $period, $warehouseId, $date, $user, $note, $itemsOk);
                if ($stSess->execute()) $sessionId = (int)$conn->insert_id;
            }
            $stmtProd = $conn->prepare("SELECT id, name, cost, barcode, qty_mode, unitType, unit_show_pack, unit_show_carton FROM products WHERE id = ? AND trackStock = 1 LIMIT 1");
            $stLine = $conn->prepare("INSERT INTO stocktake_lines (session_id, product_id, product_name, system_qty, actual_qty, variance, unit_cost, value) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            foreach ($items as $row) {
                $pid = (int)($row['product_id'] ?? $row['id'] ?? 0);
                $actualRaw = ($row['actual_qty'] ?? $row['actual'] ?? 0);
                $systemRaw = ($row['system_qty'] ?? $row['system'] ?? 0);
                if ($pid <= 0) continue;
                $stmtProd->bind_param("i", $pid);
                $stmtProd->execute();
                $res = $stmtProd->get_result();
                $prod = $res ? $res->fetch_assoc() : null;
                if (!$prod) continue;
                $actual = normalizeQtyForProductData($prod, $actualRaw);
                $system = normalizeQtyForProductData($prod, $systemRaw);
                if ($actual < 0) continue;
                if ($actual === $system) continue;
                if (!pos_set_warehouse_stock($conn, $warehouseId, $pid, $actual)) continue;
                $updated++;
                $cost = $prod ? (float)$prod['cost'] : 0;
                $barcode = $prod ? trim($prod['barcode'] ?? '') : '';
                $qtyDiff = $actual - $system;
                $lineValue = roundMoney($cost * abs($qtyDiff));
                if ($qtyDiff < 0) {
                    $shortQty += abs($qtyDiff);
                    $shortValue += $lineValue;
                    $nShort++;
                } else {
                    $surplusQty += $qtyDiff;
                    $surplusValue += $lineValue;
                    $nSurplus++;
                }
                insertStockMovement($conn, $pid, $barcode, 'stocktake', $qtyDiff, $cost, $lineValue, 'stocktake', $sessionId, $date, $user, 'جرد / Stocktake', $warehouseId);
                if ($stLine && $sessionId > 0) {
                    $pname = (string)($prod['name'] ?? '');
                    $stLine->bind_param('iisddddd', $sessionId, $pid, $pname, $system, $actual, $qtyDiff, $cost, $lineValue);
                    $stLine->execute();
                }
            }
            $netValue = roundMoney($surplusValue - $shortValue);
            $shortValue = roundMoney($shortValue);
            $surplusValue = roundMoney($surplusValue);
            if ($sessionId > 0) {
                $upSess = $conn->prepare("UPDATE stocktake_sessions SET items_changed=?, items_short=?, items_surplus=?, short_qty=?, surplus_qty=?, short_value=?, surplus_value=?, net_value=? WHERE id=?");
                if ($upSess) {
                    $upSess->bind_param('iiidddddi', $updated, $nShort, $nSurplus, $shortQty, $surplusQty, $shortValue, $surplusValue, $netValue, $sessionId);
                    $upSess->execute();
                }
            }
            touchLastUpdate($conn);
            $conn->commit();
            $hideCost = function_exists('pos_session_can_view_cost') && !pos_session_can_view_cost();
            echo json_encode([
                'status' => 'ok',
                'updated' => $updated,
                'session_id' => $sessionId,
                'period' => $period,
                'short_qty' => $shortQty,
                'surplus_qty' => $surplusQty,
                'short_value' => $hideCost ? 0 : $shortValue,
                'surplus_value' => $hideCost ? 0 : $surplusValue,
                'net_value' => $hideCost ? 0 : $netValue,
                'items_short' => $nShort,
                'items_surplus' => $nSurplus,
            ], JSON_UNESCAPED_UNICODE);
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
        exit();
    }

    if($act == 'process_payment') {
        if (function_exists('pos_ensure_payment_due_schema')) pos_ensure_payment_due_schema($conn);
        $totalMinor = max(0, moneyToMinor($_POST['total'] ?? 0));
        $discMinor = max(0, moneyToMinor($_POST['discount'] ?? 0));
        $total = moneyMinorToMajor($totalMinor);
        $disc = moneyMinorToMajor($discMinor);
        $items = $_POST['items']; 
        $cashier = trim($_POST['cashier'] ?? '');
        // if($total <= 0) { echo json_encode(["status"=>"error", "message"=>"کۆی گشتیێ وەسڵێ نابیت سفر بیت"]); exit(); }
        $payMethod = isset($_POST['method']) ? strtolower(trim((string)$_POST['method'])) : 'cash';
        $targetId = isset($_POST['targetId']) ? (int)$_POST['targetId'] : 0;
        $targetType = isset($_POST['targetType']) ? $_POST['targetType'] : ''; // 'customer' or 'user'
        if ($payMethod === 'bankcard' || $payMethod === 'bank' || $payMethod === 'card') {
            $payMethod = 'fib';
        }
        
        // Split payment amounts (used only when payMethod === 'split')
        $cashPortionMinor = 0;      // "cash" part entered by cashier
        $bankCardPortionMinor = 0;  // FIB / bank part entered by cashier
        $debtPortionMinor = 0;      // "debt" part entered by cashier
        
        // Applied amounts (what we actually record to ledger/balance)
        $cashAppliedMinor = 0;
        $bankCardAppliedMinor = 0;
        $debtAppliedMinor = 0;
        $receivedAmountMinor = 0;
        
        $debtWarning = null;
        $paymentDueWarning = null;
        $paymentDueAt = null;
        
        if($payMethod === 'cash') {
            $cashPortionMinor = $totalMinor;
        } else if($payMethod === 'debt') {
            $debtPortionMinor = $totalMinor;
        } else if($payMethod === 'fib') {
            $bankCardPortionMinor = $totalMinor;
        } else if($payMethod === 'split') {
            $allocJson = $_POST['split_allocations'] ?? ($_POST['split_methods'] ?? '');
            $alloc = [];
            if(is_string($allocJson) && trim($allocJson) !== '') {
                $decoded = json_decode($allocJson, true);
                if(is_array($decoded)) $alloc = $decoded;
            }
            
            $cashPortionMinor = max(0, moneyToMinor($alloc['cash'] ?? 0));
            $bankCardPortionMinor = max(0, moneyToMinor($alloc['bank'] ?? ($alloc['bank_card'] ?? 0)));
            $debtPortionMinor = max(0, moneyToMinor($alloc['debt'] ?? 0));
            $receivedAmountMinor = max(0, moneyToMinor($_POST['received_amount'] ?? ($alloc['received_amount'] ?? ($alloc['cash'] ?? 0))));
            $inputTotalMinor = $cashPortionMinor + $bankCardPortionMinor + $debtPortionMinor;
            if($inputTotalMinor < $totalMinor) {

                header('Content-Type: application/json; charset=utf-8');
                echo json_encode(['status' => 'error', 'message' => 'Split payment remaining balance is not covered by cash/bank/debt amounts'], JSON_UNESCAPED_UNICODE);
                exit();
            }
            // Allow overpay (change) safely: never book more than invoice total into sale income/debt.
            // Priority: keep bank applied first, reduce cash by overpay amount (change usually from cash).
            $cashAppliedMinor = $cashPortionMinor;
            $bankCardAppliedMinor = $bankCardPortionMinor;
            $debtAppliedMinor = $debtPortionMinor;
            if($inputTotalMinor > $totalMinor) {
                $overpayMinor = $inputTotalMinor - $totalMinor;
                if($cashAppliedMinor >= $overpayMinor) {
                    $cashAppliedMinor -= $overpayMinor;
                } else {
                    $overpayMinor -= $cashAppliedMinor;
                    $cashAppliedMinor = 0;
                    $bankCardAppliedMinor = max(0, $bankCardAppliedMinor - $overpayMinor);
                }
                $appliedCoveredMinor = $cashAppliedMinor + $bankCardAppliedMinor;
                $debtAppliedMinor = max(0, $totalMinor - $appliedCoveredMinor);
            }
        }
        // For non-split methods, applied = full total for the selected portion.
        if($payMethod === 'cash') {
            $cashAppliedMinor = $totalMinor;
            $bankCardAppliedMinor = 0;
            $debtAppliedMinor = 0;
            $receivedAmountMinor = $totalMinor;
        } else if($payMethod === 'debt') {
            $cashAppliedMinor = 0;
            $bankCardAppliedMinor = 0;
            $debtAppliedMinor = $totalMinor;
            $receivedAmountMinor = 0;
        } else if($payMethod === 'fib') {
            $cashAppliedMinor = 0;
            $bankCardAppliedMinor = $totalMinor;
            $debtAppliedMinor = 0;
            $receivedAmountMinor = 0;
        }
        if ($payMethod === 'split' && $bankCardAppliedMinor > 0 && $cashAppliedMinor <= 0 && $debtAppliedMinor <= 0) {
            $payMethod = 'fib';
        }
        
        if($debtAppliedMinor > 0 && $targetId <= 0) {

            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['status' => 'error', 'message' => 'Debt portion requires a valid targetId'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $date = date('Y-m-d H:i:s');
        
        // Unified Transaction ID for all related accounting entries
        $txnId = 'TX' . str_replace('.', '', uniqid('', true)) . bin2hex(random_bytes(4));
        $saleRequestKey = trim((string)($_POST['request_key'] ?? ($_POST['idempotency_key'] ?? ($_POST['client_request_id'] ?? ''))));
        if ($saleRequestKey !== '' && strlen($saleRequestKey) > 80) {
            $saleRequestKey = substr($saleRequestKey, 0, 80);
        }

        $saleWhRes = function_exists('pos_sale_warehouse_id_or_error')
            ? pos_sale_warehouse_id_or_error($conn, (int)($_POST['warehouse_id'] ?? 0))
            : ['ok' => true, 'id' => (function_exists('pos_resolve_warehouse_id') ? pos_resolve_warehouse_id($conn, $_POST['warehouse_id'] ?? 0) : 0)];
        if (empty($saleWhRes['ok'])) {
            echo json_encode(["status"=>"error", "message"=>(string)($saleWhRes['message'] ?? 'کۆگەه ڤەنەکریە')], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $saleWarehouseId = (int)($saleWhRes['id'] ?? 0);
        if (function_exists('pos_ensure_sales_warehouse_column')) {
            pos_ensure_sales_warehouse_column($conn);
        }
        if (function_exists('pos_ensure_sales_checkout_columns')) {
            pos_ensure_sales_checkout_columns($conn);
        }
        if ($saleWarehouseId > 0 && function_exists('pos_stamp_sale_items_warehouse')) {
            $items = pos_stamp_sale_items_warehouse($conn, $items, $saleWarehouseId);
        }

        // Preferred idempotency path: explicit request key from client.
        if ($saleRequestKey !== '') {
            $stmtReqDup = $conn->prepare("SELECT id, created_at FROM sales WHERE sale_request_key = ? LIMIT 1");
            if ($stmtReqDup) {
                $stmtReqDup->bind_param("s", $saleRequestKey);
                $stmtReqDup->execute();
                $resReqDup = $stmtReqDup->get_result();
                if ($resReqDup && $resReqDup->num_rows > 0) {
                    $existing = $resReqDup->fetch_assoc();
                    echo json_encode(["status"=>"success", "id"=>$existing['id'], "date"=>$existing['created_at'], "duplicate"=>true]);
                    exit();
                }
            }
        }
        $checkTime = date('Y-m-d H:i:s', strtotime('-90 seconds'));
        $stmtDup = $conn->prepare("SELECT id, created_at FROM sales WHERE cashier = ? AND total = ? AND created_at >= ? AND items_json = ? LIMIT 1");
        if ($stmtDup) {
            $stmtDup->bind_param("sdss", $cashier, $total, $checkTime, $items);
            $stmtDup->execute();
            $resDup = $stmtDup->get_result();
            if($resDup && $resDup->num_rows > 0) {
                $existing = $resDup->fetch_assoc();
                echo json_encode(["status"=>"success", "id"=>$existing['id'], "date"=>$existing['created_at'], "duplicate"=>true]);
                exit();
            }
        }
        
        // VALIDATION: Ensure items JSON is valid
        if(json_decode($items) === null) { echo json_encode(["status"=>"error", "message"=>"Invalid Items Data"]); exit(); }

        // Start Transaction (Ensure Sale + Stock Update happen together)
        $conn->begin_transaction();
        try {
            $paidAmount = moneyMinorToMajor($cashAppliedMinor + $bankCardAppliedMinor);
            $debtAmountCol = moneyMinorToMajor($debtAppliedMinor);
            $bankAmountCol = moneyMinorToMajor($bankCardAppliedMinor);
            $paidCashCol = moneyMinorToMajor($cashAppliedMinor);
            $paidBankCol = moneyMinorToMajor($bankCardAppliedMinor);
            $remainingDebtCol = moneyMinorToMajor($debtAppliedMinor);
            $totalBillCol = $total;
            $taxDiscountCol = $disc;
            $receivedAmountCol = moneyMinorToMajor($receivedAmountMinor);
            $fxSnap = fxSnapshotBindStringsFromPost();
            $fxRateBind = $fxSnap['rate'];
            $fxModeBind = $fxSnap['mode'];
            if (function_exists('pos_lock_sale_items_fx')) {
                $items = pos_lock_sale_items_fx($items, $fxRateBind, $fxModeBind);
            }
            if (function_exists('pos_stamp_sale_items_inventory_cogs')) {
                $items = pos_stamp_sale_items_inventory_cogs($conn, $items);
            }
            $saleInsertSql = "INSERT INTO sales (total, discount, items_json, created_at, cashier, payment_method, customer_id, customer_type, transaction_id, sale_request_key, paid_amount, debt_amount, bank_amount, received_amount, total_bill, tax_discount, paid_cash, paid_bank, remaining_debt, warehouse_id, fx_usd_rate, fx_currency_mode) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CAST(NULLIF(?, '') AS UNSIGNED), NULLIF(?, ''))";
            $saleId = 0;
            for ($saleInsertTry = 0; $saleInsertTry < 2; $saleInsertTry++) {
                $stmt = $conn->prepare($saleInsertSql);
                if(!$stmt) throw new Exception("Prepare failed: " . $conn->error);
                $stmt->bind_param("ddssssisssdddddddddiss", $total, $disc, $items, $date, $cashier, $payMethod, $targetId, $targetType, $txnId, $saleRequestKey, $paidAmount, $debtAmountCol, $bankAmountCol, $receivedAmountCol, $totalBillCol, $taxDiscountCol, $paidCashCol, $paidBankCol, $remainingDebtCol, $saleWarehouseId, $fxRateBind, $fxModeBind);
                if($stmt->execute()) {
                    $saleId = (int)$stmt->insert_id;
                    break;
                }
                $insertErrNo = (int)$stmt->errno;
                $insertErr = $stmt->error;
                if($insertErrNo === 1062 && $saleRequestKey !== '') {
                    $stmtExisting = $conn->prepare("SELECT id, created_at FROM sales WHERE sale_request_key = ? LIMIT 1");
                    if ($stmtExisting) {
                        $stmtExisting->bind_param("s", $saleRequestKey);
                        $stmtExisting->execute();
                        $resExisting = $stmtExisting->get_result();
                        if ($resExisting && ($existing = $resExisting->fetch_assoc())) {
                            $conn->rollback();
                            echo json_encode(["status"=>"success", "id"=>$existing['id'], "date"=>$existing['created_at'], "duplicate"=>true]); exit();
                        }
                    }
                }
                if($insertErrNo === 1062 && $saleInsertTry === 0) {
                    $txnId = 'TX' . str_replace('.', '', uniqid('', true)) . bin2hex(random_bytes(4));
                    usleep(70000);
                    continue;
                }
                throw new Exception("Insert Sales failed: " . $insertErr);
            }
            if($saleId <= 0) throw new Exception("Insert Sales failed: could not create invoice ID");
            if (function_exists('pos_sale_stamp_dual_totals')) {
                pos_sale_stamp_dual_totals($conn, $saleId, $totalBillCol, $paidAmount, $fxRateBind);
            }
            
            // Sanitization
            // $items = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $items); // REMOVED: Breaks UTF-8
            $cartItems = json_decode($items, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                 throw new Exception("JSON Decode Error: " . json_last_error_msg());
            }
            $counts = [];
            $giftCounts = [];
            $itemCosts = [];
            $itemBarcodes = [];
            $ingredientCounts = [];
            $productMetaCache = [];
            if (is_array($cartItems)) {
                // One batched product meta lookup instead of N prepares per line
                $metaIds = [];
                foreach ($cartItems as $_ci) {
                    if (!is_array($_ci) || !empty($_ci['isManualItem'])) continue;
                    $_mid = (int)($_ci['id'] ?? 0);
                    if ($_mid <= 0) continue;
                    $needsMeta = !isset($_ci['trackStock'])
                        || !isset($_ci['pieces_per_pack'])
                        || !isset($_ci['packs_per_carton'])
                        || !isset($_ci['barcode']);
                    if ($needsMeta) $metaIds[$_mid] = true;
                }
                if (!empty($metaIds)) {
                    $idList = implode(',', array_map('intval', array_keys($metaIds)));
                    $resBatch = $conn->query("SELECT id, trackStock, barcode, pieces_per_pack, packs_per_carton, itemsPerCarton, name, price, price_pack, price_carton, qty_mode, unitType, unit_show_pack, unit_show_carton, is_weight, recipe_sale_mode FROM products WHERE id IN ($idList)");
                    if ($resBatch) {
                        while ($rowMeta = $resBatch->fetch_assoc()) {
                            $productMetaCache[(int)$rowMeta['id']] = $rowMeta;
                        }
                    }
                }
                foreach ($cartItems as $prod) {
                    $pid = (int)$prod['id'];

                    // Enrich missing stock metadata from products table (older clients / partial payloads)
                    if ($pid > 0 && empty($prod['isManualItem'])) {
                        $needsMeta = !isset($prod['trackStock'])
                            || !isset($prod['pieces_per_pack'])
                            || !isset($prod['packs_per_carton'])
                            || !isset($prod['barcode']);
                        if ($needsMeta && !empty($productMetaCache[$pid]) && is_array($productMetaCache[$pid])) {
                            foreach (['trackStock', 'barcode', 'pieces_per_pack', 'packs_per_carton', 'itemsPerCarton', 'recipe_sale_mode'] as $metaKey) {
                                if (!isset($prod[$metaKey]) && array_key_exists($metaKey, $productMetaCache[$pid])) {
                                    $prod[$metaKey] = $productMetaCache[$pid][$metaKey];
                                }
                            }
                        }
                    }
                    
                    // Sale qty in base pieces; recipe uses pre-produced stock when available, else ingredients.
                    $mult = 1;
                    if (isset($prod['saleUnit']) && $prod['saleUnit'] !== 'piece') {
                        $ppp = isset($prod['pieces_per_pack']) ? max(1, (int)$prod['pieces_per_pack']) : 1;
                        $ppc = isset($prod['packs_per_carton']) ? max(1, (int)$prod['packs_per_carton']) : 1;
                        $piecesPerCarton = $ppp * $ppc;
                        if ($piecesPerCarton <= 1 && isset($prod['itemsPerCarton']) && (int)$prod['itemsPerCarton'] > 1) {
                            $piecesPerCarton = (int)$prod['itemsPerCarton'];
                        }
                        if ($prod['saleUnit'] === 'carton') $mult = $piecesPerCarton;
                        elseif ($prod['saleUnit'] === 'pack') $mult = $ppp;
                    }
                    $rawLineQty = isset($prod['qty']) ? (float)$prod['qty'] : (isset($prod['count']) ? (float)$prod['count'] : 1.0);
                    $countForThisRow = normalizeQtyForProductData($prod, $rawLineQty);
                    if ($countForThisRow <= 0 && $rawLineQty > 0) {
                        $countForThisRow = round($rawLineQty, 3);
                    }
                    if ($countForThisRow < 0) $countForThisRow = 0;
                    $salePieces = $mult * ($countForThisRow > 0 ? $countForThisRow : 1);

                    $recipeSaleMode = isset($prod['recipeSaleMode']) ? (string)$prod['recipeSaleMode'] : '';
                    if ($recipeSaleMode === '' && !empty($productMetaCache[$pid]['recipe_sale_mode'])) {
                        $recipeSaleMode = (string)$productMetaCache[$pid]['recipe_sale_mode'];
                    }
                    if ($recipeSaleMode === '' && !empty($prod['recipe_sale_mode'])) {
                        $recipeSaleMode = (string)$prod['recipe_sale_mode'];
                    }
                    $recipeSaleMode = function_exists('pos_normalize_recipe_sale_mode')
                        ? pos_normalize_recipe_sale_mode($recipeSaleMode)
                        : 'auto';

                    $deductionPlan = pos_recipe_deduction_plan($conn, $pid, (float)$salePieces, $saleWarehouseId, $recipeSaleMode);
                    if (!empty($deductionPlan['finished']) && $deductionPlan['finished'] > 0.0000001) {
                        if (!isset($counts[$pid])) {
                            $counts[$pid] = 0;
                            $itemBarcodes[$pid] = isset($prod['barcode']) ? $prod['barcode'] : '';
                        }
                        $counts[$pid] += (float)$deductionPlan['finished'];
                        if (!empty($prod['isGift'])) {
                            if (!isset($giftCounts[$pid])) $giftCounts[$pid] = 0;
                            $giftCounts[$pid] += (float)$deductionPlan['finished'];
                        }
                        $costForThisRow = (isset($prod['cost']) ? (float)$prod['cost'] : 0);
                        if (!isset($itemCosts[$pid])) $itemCosts[$pid] = 0;
                        $itemCosts[$pid] += ($costForThisRow * $countForThisRow);
                    }
                    if (!empty($deductionPlan['ingredients']) && is_array($deductionPlan['ingredients'])) {
                        foreach ($deductionPlan['ingredients'] as $ingId => $ingQty) {
                            $iid = (int)$ingId;
                            if ($iid <= 0 || (float)$ingQty <= 0) continue;
                            if (!isset($ingredientCounts[$iid])) $ingredientCounts[$iid] = 0;
                            $ingredientCounts[$iid] += (float)$ingQty;
                        }
                    }

                    // Jewelry set: deduct member pieces (earrings, bracelet…) when selling the set SKU
                    if (function_exists('pos_get_jewelry_set_qty_map')) {
                        $jewMembers = pos_get_jewelry_set_qty_map($conn, $pid);
                        if (!empty($jewMembers)) {
                            foreach ($jewMembers as $mid => $perSet) {
                                $mid = (int)$mid;
                                if ($mid <= 0 || (float)$perSet <= 0) continue;
                                if (!isset($ingredientCounts[$mid])) $ingredientCounts[$mid] = 0;
                                $ingredientCounts[$mid] += ((float)$perSet * (float)$salePieces);
                            }
                            // Stock lives on members — do not also deduct the set SKU
                            if (isset($counts[$pid])) unset($counts[$pid]);
                        }
                    }

                    // SECURITY: Log under-price sales and manual price overrides for owner audit
                    if ($pid > 0 && empty($prod['isManualItem'])) {
                        if (!isset($productMetaCache[$pid]) || !is_array($productMetaCache[$pid]) || !array_key_exists('price', $productMetaCache[$pid])) {
                            if (!isset($productMetaCache[$pid])) {
                                $productMetaCache[$pid] = null;
                            }
                            $stmtPriceMeta = $conn->prepare("SELECT name, price, price_pack, price_carton FROM products WHERE id = ? LIMIT 1");
                            if ($stmtPriceMeta) {
                                $stmtPriceMeta->bind_param("i", $pid);
                                $stmtPriceMeta->execute();
                                $resPm = $stmtPriceMeta->get_result();
                                if ($resPm && ($rowPm = $resPm->fetch_assoc())) {
                                    $productMetaCache[$pid] = is_array($productMetaCache[$pid])
                                        ? array_merge($productMetaCache[$pid], $rowPm)
                                        : $rowPm;
                                }
                            }
                        }
                        $metaPm = $productMetaCache[$pid] ?? null;
                        if (is_array($metaPm)) {
                            $saleUnitPm = isset($prod['saleUnit']) ? (string)$prod['saleUnit'] : 'piece';
                            $catalogPrice = (float)($metaPm['price'] ?? 0);
                            if ($saleUnitPm === 'pack' && !empty($metaPm['price_pack']) && (float)$metaPm['price_pack'] > 0) {
                                $catalogPrice = (float)$metaPm['price_pack'];
                            } elseif ($saleUnitPm === 'carton' && !empty($metaPm['price_carton']) && (float)$metaPm['price_carton'] > 0) {
                                $catalogPrice = (float)$metaPm['price_carton'];
                            }
                            $soldPrice = (float)($prod['price'] ?? 0);
                            $pname = trim((string)($prod['name'] ?? ($metaPm['name'] ?? '')));
                            if ($pname === '') {
                                $pname = "ID {$pid}";
                            }
                            $isManual = !empty($prod['isManualPrice'])
                                && ($prod['isManualPrice'] === true || $prod['isManualPrice'] === 1
                                    || $prod['isManualPrice'] === 'true' || $prod['isManualPrice'] === '1');
                            if ($catalogPrice > 0 && $soldPrice + 0.5 < $catalogPrice) {
                                $diff = roundMoney($catalogPrice - $soldPrice);
                                logAction(
                                    $conn,
                                    $cashier,
                                    'alert_underprice_sale',
                                    "فرۆشتن ب نرخێ کەمتر: «{$pname}» | کتڵۆگ: " . number_format($catalogPrice) . " | فرۆشرا: " . number_format($soldPrice) . " | کەمبوون: " . number_format($diff),
                                    null,
                                    'product',
                                    $pid
                                );
                            } elseif ($isManual) {
                                logAction(
                                    $conn,
                                    $cashier,
                                    'manual_price_sale',
                                    "نرخێ دەستی لە فرۆشتن: «{$pname}» | کتڵۆگ: " . number_format($catalogPrice) . " | فرۆشرا: " . number_format($soldPrice),
                                    null,
                                    'product',
                                    $pid
                                );
                            }
                        }
                    }
                }
                // Zero Loss: For direct sales (no table), deduct stock here. For table orders stock was already deducted in update_table_items.
                $tableId = (int)($_POST['table_id'] ?? 0);
                
                // --- FIX: Guarantee correct stock deduction regardless of race conditions ---
                if ($tableId > 0) {
                    $stmtT = $conn->prepare("SELECT items_json FROM tables WHERE id = ? FOR UPDATE");
                    if ($stmtT) {
                        $stmtT->bind_param("i", $tableId);
                        $stmtT->execute();
                        $resT = $stmtT->get_result();
                        if ($resT && $rowT = $resT->fetch_assoc()) {
                            $oldItems = json_decode($rowT['items_json'], true);
                            if (is_array($oldItems)) {
                                $oldCounts = cartItemsToPieceCounts($oldItems);
                                foreach ($oldCounts as $pid => $qtyToRevert) {
                                    $qtyToRevert = (float)$qtyToRevert;
                                    if ($qtyToRevert <= 0) continue;
                                    pos_delta_warehouse_stock($conn, $saleWarehouseId, (int)$pid, $qtyToRevert);
                                }
                            }
                        }
                    }
                }

                if (!empty($counts)) {
                    $settings = pos_load_app_settings_array($conn);
                    $allowNegativeStock = !empty($settings['allowNegativeStock']) && ($settings['allowNegativeStock'] === true || $settings['allowNegativeStock'] === 'true' || $settings['allowNegativeStock'] == 1);
                    $sortedProductIds = sortedNumericKeys($counts);
                    foreach ($sortedProductIds as $pid) {
                        $required = (float)($counts[$pid] ?? 0);
                        if ($required <= 0) continue;
                        $stmtP = $conn->prepare("SELECT qty, name FROM products WHERE id = ? AND trackStock = 1 FOR UPDATE");
                        $stmtP->bind_param("i", $pid);
                        $stmtP->execute();
                        $resP = $stmtP->get_result();
                        if (!$resP || !$p = $resP->fetch_assoc()) continue;
                        $available = pos_heal_warehouse_stock_from_product($conn, $saleWarehouseId, (int)$pid);
                        if (!$allowNegativeStock && ($available + 0.000001) < $required) {
                            $name = $p['name'] ?? ('#' . $pid);
                            throw new Exception("stock_not_enough:" . $name . " (available: $available, required: $required)");
                        }
                        if (function_exists('pos_reconcile_product_qty_with_batches')) {
                            pos_reconcile_product_qty_with_batches($conn, (int)$pid, (float)$available);
                        }
                        pos_adjust_tracked_stock($conn, (int)$pid, -$required, $saleWarehouseId);
                        $pname = isset($p['name']) ? (string)$p['name'] : '';
                        consumeStockBatchesFefo($conn, (int)$pid, (float)$required, $txnId, $saleId, $pname);
                    }
                }
                foreach($counts as $pid => $qty) {
                    $totalCost = isset($itemCosts[$pid]) ? $itemCosts[$pid] : 0;
                    $bc = isset($itemBarcodes[$pid]) ? $itemBarcodes[$pid] : '';
                    $avgUnitCost = ($qty > 0) ? ($totalCost / $qty) : 0;
                    $giftPcs = (float)($giftCounts[$pid] ?? 0);
                    $moveNote = '';
                    if ($giftPcs > 0.0001 && abs($giftPcs - (float)$qty) < 0.0001) {
                        $moveNote = 'دیاری / بەلاش';
                    } elseif ($giftPcs > 0.0001) {
                        $moveNote = 'تێدا دیاری: ' . $giftPcs;
                    }
                    insertStockMovement($conn, $pid, $bc, 'sale', -$qty, $avgUnitCost, $totalCost, 'sale', $saleId, $date, $cashier, $moveNote, $saleWarehouseId);
                }
                foreach($ingredientCounts as $pid => $qty) {
                    pos_adjust_tracked_stock($conn, (int)$pid, -(float)$qty, $saleWarehouseId);
                    // Keep batch ledger consistent with stock deduction for recipe ingredients (FEFO).
                    $stmtIngMeta = $conn->prepare("SELECT name FROM products WHERE id = ? LIMIT 1");
                    if ($stmtIngMeta) {
                        $pidInt = (int)$pid;
                        $stmtIngMeta->bind_param("i", $pidInt);
                        $stmtIngMeta->execute();
                        $resIngMeta = $stmtIngMeta->get_result();
                        $ingName = ($resIngMeta && ($rIng = $resIngMeta->fetch_assoc())) ? (string)($rIng['name'] ?? '') : '';
                        consumeStockBatchesFefo($conn, $pidInt, (float)$qty, $txnId, $saleId, $ingName);
                    }
                }
            }

            // DEBT LOGIC
            if($remainingDebtCol > 0 && $targetId > 0) {
            // SECURITY: Validate Target Type
            if($targetType !== 'customer' && $targetType !== 'user') {
                throw new Exception("Invalid debt target type");
            }
            
                $table = ($targetType == 'user') ? 'users' : 'customers';
                $debtAmount = $remainingDebtCol;
                $targetId = (int)$targetId;
                $stmtB = $conn->prepare("UPDATE " . ($table === 'users' ? 'users' : 'customers') . " SET balance = balance + ? WHERE id = ?");
                $stmtB->bind_param("di", $debtAmount, $targetId);
                $stmtB->execute();
                
                $note = "کڕین (وەسڵ): " . date('Y-m-d H:i');
                $receiptIdStr = (string)$saleId;
                $stmt = $conn->prepare("INSERT INTO customer_ledger (target_id, target_type, type, amount, date, note, transaction_id, receipt_id) VALUES (?, ?, 'sale', ?, ?, ?, ?, ?)");
                $stmt->bind_param("isdssss", $targetId, $targetType, $debtAmount, $date, $note, $txnId, $receiptIdStr);
                $stmt->execute();
                if (function_exists('pos_stamp_table_fx')) {
                    pos_stamp_table_fx($conn, 'customer_ledger', (int)$conn->insert_id, 'IQD');
                }

                if ($targetType === 'customer') {
                    $warnStmt = $conn->prepare("SELECT name, balance, debt_limit FROM customers WHERE id = ? LIMIT 1");
                    if ($warnStmt) {
                        $warnStmt->bind_param("i", $targetId);
                        $warnStmt->execute();
                        $warnRes = $warnStmt->get_result();
                        if ($warnRes && ($warnRow = $warnRes->fetch_assoc())) {
                            $curBal = roundMoney((float)($warnRow['balance'] ?? 0));
                            $debtLimit = roundMoney((float)($warnRow['debt_limit'] ?? 0));
                            if ($debtLimit > 0 && $curBal > $debtLimit) {
                                $debtWarning = [
                                    "customer_id" => (int)$targetId,
                                    "customer_name" => (string)($warnRow['name'] ?? ''),
                                    "current_balance" => $curBal,
                                    "debt_limit" => $debtLimit,
                                    "message" => "ئاگاداری: قەرزێ کریاری ژ سنوورا دیارکری دەرکەتیە."
                                ];
                            }
                        }
                    }
                }
            }

            if ($remainingDebtCol > 0 && $targetId > 0) {
                $ptVal = max(0, (int)($_POST['payment_term_value'] ?? 0));
                $ptUnit = pos_normalize_payment_term_unit($_POST['payment_term_unit'] ?? 'day');
                if ($ptVal <= 0 && ($targetType === 'customer' || $targetType === 'customers')) {
                    list($ptVal, $ptUnit) = pos_resolve_payment_term_from_post($conn, 'customer', $targetId);
                }
                $paymentDueAt = pos_compute_payment_due_at($ptVal, $ptUnit, $date);
                if ($paymentDueAt) {
                    $stDue = $conn->prepare("UPDATE sales SET payment_due_at = ? WHERE id = ?");
                    if ($stDue) {
                        $stDue->bind_param('si', $paymentDueAt, $saleId);
                        $stDue->execute();
                    }
                    // Remember term on customer profile when missing (so cards can show remaining time).
                    if (($targetType === 'customer' || $targetType === 'customers') && $ptVal > 0) {
                        $stTerm = $conn->prepare(
                            "UPDATE customers SET payment_term_value = ?, payment_term_unit = ? "
                            . "WHERE id = ? AND (payment_term_value IS NULL OR payment_term_value <= 0)"
                        );
                        if ($stTerm) {
                            $stTerm->bind_param('isi', $ptVal, $ptUnit, $targetId);
                            $stTerm->execute();
                        }
                    }
                }
            }

            // Ledger entries for cash vs FIB vs debt portions (FIB does not enter the cash drawer)
            $cashLedgerAmount = moneyMinorToMajor($cashAppliedMinor);
            $bankLedgerAmount = moneyMinorToMajor($bankCardAppliedMinor);
            $stmtL = $conn->prepare("INSERT INTO ledger (transaction_id, type, amount, related_id, note, date) VALUES (?, ?, ?, ?, ?, ?)");
            if(!$stmtL) {
                 file_put_contents('pos_debug.log', "Prepare Ledger Failed: " . $conn->error . "\n", FILE_APPEND);
                 throw new Exception("Prepare Ledger Failed: " . $conn->error);
            }

            // 1) Cash portion (physical drawer)
            if($cashLedgerAmount > 0) {
                $ledgerType = 'sale';
                $ledgerNote = "Sale #$saleId (cash)";
                $ledgerAmount = $cashLedgerAmount;
                $stmtL->bind_param("ssdiss", $txnId, $ledgerType, $ledgerAmount, $saleId, $ledgerNote, $date);
                if(!$stmtL->execute()) throw new Exception("Insert Ledger failed: " . $stmtL->error);
                
                if ($targetId > 0 && in_array($targetType, ['customer', 'user', 'customers'], true)) {
                    $cLedgerType = ($targetType === 'user') ? 'user' : 'customer';
                    $cNote = "فرۆتن (نەقد/کاش) " . date('Y-m-d H:i');
                    $receiptIdStr = (string)$saleId;
                    $stmtCL = $conn->prepare("INSERT INTO customer_ledger (target_id, target_type, type, amount, date, note, transaction_id, receipt_id) VALUES (?, ?, 'sale_cash', ?, ?, ?, ?, ?)");
                    $stmtCL->bind_param("isdssss", $targetId, $cLedgerType, $cashLedgerAmount, $date, $cNote, $txnId, $receiptIdStr);
                    $stmtCL->execute();
                }
            }

            // 1b) FIB portion (not cash drawer)
            if($bankLedgerAmount > 0) {
                $ledgerType = 'sale_fib';
                $ledgerNote = "Sale #$saleId (FIB)";
                $ledgerAmount = $bankLedgerAmount;
                $stmtL->bind_param("ssdiss", $txnId, $ledgerType, $ledgerAmount, $saleId, $ledgerNote, $date);
                if(!$stmtL->execute()) throw new Exception("Insert Ledger failed: " . $stmtL->error);
            }

            // 2) Debt portion
            if($remainingDebtCol > 0) {
                $ledgerType = 'sale_credit';
                $ledgerNote = "Sale #$saleId (debt)";
                $ledgerAmount = $remainingDebtCol;
                $stmtL->bind_param("ssdiss", $txnId, $ledgerType, $ledgerAmount, $saleId, $ledgerNote, $date);
                if(!$stmtL->execute()) throw new Exception("Insert Ledger failed: " . $stmtL->error);
            }

            if($cashLedgerAmount <= 0 && $remainingDebtCol <= 0 && $bankLedgerAmount <= 0) {
                throw new Exception("Split payment produced zero ledger amount");
            }

            if ($targetType === 'customer' && $targetId > 0 && pos_entity_has_overdue_payment_due_for_toast($conn, 'customer', $targetId)) {
                $warnName = '';
                $stWN = $conn->prepare("SELECT name FROM customers WHERE id = ? LIMIT 1");
                if ($stWN) {
                    $stWN->bind_param('i', $targetId);
                    $stWN->execute();
                    $resWN = $stWN->get_result();
                    if ($resWN && ($rowWN = $resWN->fetch_assoc())) {
                        $warnName = (string)($rowWN['name'] ?? '');
                    }
                }
                $paymentDueWarning = pos_build_payment_due_warning($warnName);
            }

            $conn->commit();
            touchLastUpdate($conn);
            // Table clear is best-effort after commit (sale money already durable via sale_request_key).
            $tableId = (int)($_POST['table_id'] ?? 0);
            if ($tableId > 0) {
                try {
                    $stmtClear = $conn->prepare("UPDATE tables SET items_json = '[]', has_new_items = 0 WHERE id = ?");
                    if ($stmtClear) { $stmtClear->bind_param("i", $tableId); $stmtClear->execute(); }
                    touchLastUpdate($conn);
                } catch (Throwable $eClear) { /* non-fatal UX cleanup */ }
            }

            $stockResponse = [];
            $affectedStockIds = array_unique(array_merge(
                array_map('intval', array_keys($counts)),
                array_map('intval', array_keys($ingredientCounts))
            ));
            $affectedStockIds = array_values(array_filter($affectedStockIds, function($id) { return $id > 0; }));
            if (!empty($affectedStockIds)) {
                $idList = implode(',', $affectedStockIds);
                $resStockOut = $conn->query("SELECT id, qty FROM products WHERE id IN ($idList)");
                $catalogById = [];
                if ($resStockOut) {
                    while ($rowStock = $resStockOut->fetch_assoc()) {
                        $catalogById[(int)$rowStock['id']] = (float)$rowStock['qty'];
                    }
                }
                foreach ($affectedStockIds as $sid) {
                    $whQty = function_exists('pos_warehouse_product_qty')
                        ? pos_warehouse_product_qty($conn, $saleWarehouseId, (int)$sid)
                        : (float)($catalogById[$sid] ?? 0);
                    $stockResponse[] = [
                        'id' => (int)$sid,
                        'qty' => (float)($catalogById[$sid] ?? $whQty),
                        'warehouse_id' => (int)$saleWarehouseId,
                        'warehouse_qty' => $whQty,
                    ];
                }
            }

            echo json_encode([
                "status"=>"success",
                "id"=>$saleId,
                "date"=>$date,
                "debt_warning"=>$debtWarning,
                "payment_due_warning"=>$paymentDueWarning,
                "payment_due_at"=>$paymentDueAt,
                "payment_term_value"=> isset($ptVal) ? (int)$ptVal : 0,
                "payment_term_unit"=> isset($ptUnit) ? $ptUnit : 'day',
                "total_bill"=>$totalBillCol,
                "tax_discount"=>$taxDiscountCol,
                "paid_cash"=>$paidCashCol,
                "paid_bank"=>$paidBankCol,
                "remaining_debt"=>$remainingDebtCol,
                "paid_amount"=>$paidAmount,
                "debt_amount"=>$debtAmountCol,
                "bank_amount"=>$bankAmountCol,
                "received_amount"=>$receivedAmountCol,
                "stock"=>$stockResponse
            ], JSON_UNESCAPED_UNICODE); exit();
        } catch (Throwable $e) {
            $conn->rollback();
            @file_put_contents('pos_debug.log', date('Y-m-d H:i:s') . " - ERROR process_payment: " . $e->getMessage() . "\n", FILE_APPEND);
            echo json_encode(["status"=>"error", "message" => $e->getMessage()]); exit();
        }
    }

    if($act == 'adjust_return_cart_realtime') {
        $saleId = (int)($_POST['sale_id'] ?? 0);
        $itemsJson = $_POST['items'] ?? '[]';
        $cartItems = json_decode($itemsJson, true);
        if (!is_array($cartItems)) $cartItems = [];
        if ($saleId <= 0) {
            echo json_encode(["status"=>"success", "sale_id"=>0, "available_by_product"=>[]]); exit();
        }

        if (!isset($_SESSION['returns_rt']) || !is_array($_SESSION['returns_rt'])) $_SESSION['returns_rt'] = [];
        $rtKey = (string)$saleId;
        try {
            $stmtSale = $conn->prepare("SELECT items_json FROM sales WHERE id = ? LIMIT 1");
            $stmtSale->bind_param("i", $saleId);
            $stmtSale->execute();
            $resSale = $stmtSale->get_result();
            if (!$resSale || !($saleRow = $resSale->fetch_assoc())) {
                throw new Exception("وەسڵا فرۆتنێ نەهاتە دیتن.");
            }
            $baseItems = json_decode($saleRow['items_json'] ?? '[]', true);
            if (!is_array($baseItems)) $baseItems = [];
            $newCounts = returnItemsToPieceCounts($cartItems);

            $baseCounts = cartItemsToPieceCounts($baseItems);
            $dbReturnedCounts = [];
            $stmtPrev = $conn->prepare("SELECT items_json FROM returns WHERE sale_id = ?");
            $stmtPrev->bind_param("i", $saleId);
            $stmtPrev->execute();
            $resPrev = $stmtPrev->get_result();
            while ($retRow = $resPrev->fetch_assoc()) {
                $retItems = json_decode($retRow['items_json'] ?? '[]', true);
                $retCounts = returnItemsToPieceCounts($retItems);
                foreach ($retCounts as $pid => $qty) {
                    $dbReturnedCounts[$pid] = ($dbReturnedCounts[$pid] ?? 0) + (float)$qty;
                }
            }

            $availableByProduct = [];
            $allPids = array_unique(array_merge(array_keys($baseCounts), array_keys($dbReturnedCounts), array_keys($newCounts)));
            foreach ($allPids as $pid) {
                $pid = (int)$pid;
                if ($pid <= 0) continue;
                $unitsInInvoice = max(0, (float)($baseCounts[$pid] ?? 0));
                $unreturnedForInvoice = max(0, $unitsInInvoice - (float)($dbReturnedCounts[$pid] ?? 0));
                $maxAllowed = min($unitsInInvoice, $unreturnedForInvoice);
                $inCartNow = max(0, (float)($newCounts[$pid] ?? 0));
                $remaining = max(0, $maxAllowed - $inCartNow);
                $availableByProduct[(string)$pid] = [
                    'units_in_invoice' => $unitsInInvoice,
                    'unreturned_pieces' => $unreturnedForInvoice,
                    'max_allowed_pieces' => $maxAllowed,
                    'in_cart_pieces' => $inCartNow,
                    'remaining_pieces' => $remaining
                ];
            }

            foreach ($newCounts as $pid => $q) {
                $pid = (int)$pid;
                if ($pid <= 0) continue;
                $maxAllowed = (float)($availableByProduct[(string)$pid]['max_allowed_pieces'] ?? 0);
                if ((float)$q > $maxAllowed) {
                    throw new Exception("ژمارا زڤڕاندنێ ژ بڕێ فرۆتی یا ماوە پترە.");
                }
            }

            $_SESSION['returns_rt'][$rtKey] = [
                'current_counts' => $newCounts,
                'available_by_product' => $availableByProduct,
                'updated_at' => time()
            ];
            echo json_encode([
                "status"=>"success",
                "sale_id"=>$saleId,
                "available_by_product"=>$availableByProduct
            ]); exit();
        } catch (Exception $e) {
            echo json_encode(["status"=>"error", "message"=>$e->getMessage()]); exit();
        }
    }

    if($act == 'save_return') {
        checkAndAddCol($conn, 'returns', 'sale_id', "INT DEFAULT NULL");
        checkAndAddCol($conn, 'returns', 'payment_method', "VARCHAR(50) DEFAULT 'cash'");
        checkAndAddCol($conn, 'returns', 'target_id', "INT DEFAULT 0");
        checkAndAddCol($conn, 'returns', 'target_type', "VARCHAR(50) DEFAULT ''");

        $total = roundMoney((float)($_POST['total'] ?? 0));
        $items = $_POST['items'] ?? '[]';
        $cashier = trim($_POST['cashier'] ?? 'System');
        $note = trim($_POST['note'] ?? '');
        $saleId = !empty($_POST['sale_id']) ? (int)$_POST['sale_id'] : null;
        $payMethod = isset($_POST['payment_method']) ? trim((string)$_POST['payment_method']) : 'cash';
        $targetParsed = pos_parse_return_target_from_post($_POST);
        $targetId = (int)$targetParsed['target_id'];
        $targetType = (string)$targetParsed['target_type'];
        $date = date('Y-m-d H:i:s');
        $returnWarehouseId = pos_resolve_warehouse_id($conn, $_POST['warehouse_id'] ?? 0);
        if ($saleId > 0 && function_exists('pos_sale_row_warehouse_id')) {
            $stWhSale = $conn->prepare("SELECT id, items_json, warehouse_id FROM sales WHERE id = ? LIMIT 1");
            if ($stWhSale) {
                $stWhSale->bind_param('i', $saleId);
                $stWhSale->execute();
                $whSaleRow = $stWhSale->get_result()->fetch_assoc();
                if ($whSaleRow) {
                    $returnWarehouseId = pos_sale_row_warehouse_id($conn, $whSaleRow);
                }
            }
        }

        $returnFin = ($saleId > 0) ? pos_sale_return_financials($conn, $saleId, $total) : null;
        if ($returnFin && $saleId > 0) {
            $payMethod = (string)$returnFin['effective_payment_method'];
            if ((int)$returnFin['target_id'] > 0) {
                $targetId = (int)$returnFin['target_id'];
                $targetType = (string)$returnFin['target_type'];
            }
        }

        // Zero Loss: when linked to original invoice, validate return does not exceed sale
        if ($saleId > 0) {
            $stmtSale = $conn->prepare("SELECT total, items_json, is_returned FROM sales WHERE id = ? LIMIT 1");
            $stmtSale->bind_param("i", $saleId);
            $stmtSale->execute();
            $resSale = $stmtSale->get_result();
            if ($resSale && $orig = $resSale->fetch_assoc()) {
                if (!empty($orig['is_returned'])) {
                    echo json_encode(["status"=>"error", "message"=>"وەسڵا سەرەکی یا ژێبریە و نەشێی زڤڕاندنێ ل سەر تۆمار بکەی."]); exit();
                }
                $origTotal = roundMoney((float)$orig['total']);
                if ($total > $origTotal) {
                    echo json_encode(["status"=>"error", "message"=>"بڕێ زڤڕاندنێ نەشێت ژ بڕێ وەسڵا سەرەکی ($origTotal) مەزنتر بیت."]); exit();
                }
                $cartItems = json_decode($items, true);
                if (is_array($cartItems)) {
                    $origItems = json_decode($orig['items_json'], true);
                    $origCounts = [];
                    if (is_array($origItems)) {
                        foreach ($origItems as $op) {
                            $pid = (int)($op['id'] ?? 0);
                            if (!$pid) continue;
                            $mult = 1;
                            if (isset($op['saleUnit']) && $op['saleUnit'] !== 'piece') {
                                $ppp = isset($op['pieces_per_pack']) ? max(1, (int)$op['pieces_per_pack']) : 1;
                                $ppc = isset($op['packs_per_carton']) ? max(1, (int)$op['packs_per_carton']) : 1;
                                if (isset($op['saleUnit']) && $op['saleUnit'] === 'carton') $mult = $ppp * $ppc;
                                elseif (isset($op['saleUnit']) && $op['saleUnit'] === 'pack') $mult = $ppp;
                            }
                            $q = saleRowQtyForReturnsValidation($op);
                            $origCounts[$pid] = ($origCounts[$pid] ?? 0) + $q * $mult;
                        }
                    }
                    $stmtPrev = $conn->prepare("SELECT items_json FROM returns WHERE sale_id = ?");
                    $stmtPrev->bind_param("i", $saleId);
                    $stmtPrev->execute();
                    $resPrev = $stmtPrev->get_result();
                    while ($row = $resPrev->fetch_assoc()) {
                        $prevItems = json_decode($row['items_json'], true);
                        if (!is_array($prevItems)) continue;
                        foreach ($prevItems as $pp) {
                            $pid = (int)($pp['id'] ?? 0);
                            if (!$pid) continue;
                            $mult = 1;
                            if (isset($pp['saleUnit']) && $pp['saleUnit'] !== 'piece') {
                                $ppp = isset($pp['pieces_per_pack']) ? max(1, (int)$pp['pieces_per_pack']) : 1;
                                $ppc = isset($pp['packs_per_carton']) ? max(1, (int)$pp['packs_per_carton']) : 1;
                                if (isset($pp['saleUnit']) && $pp['saleUnit'] === 'carton') $mult = $ppp * $ppc;
                                elseif (isset($pp['saleUnit']) && $pp['saleUnit'] === 'pack') $mult = $ppp;
                            }
                            $q = normalizeQtyForProductData($pp, isset($pp['qty']) ? $pp['qty'] : 1);
                            $origCounts[$pid] = ($origCounts[$pid] ?? 0) - ($q * $mult);
                        }
                    }
                    foreach ($cartItems as $prod) {
                        $pid = (int)($prod['id'] ?? 0);
                        if (!$pid) continue;
                        $mult = 1;
                        if (isset($prod['saleUnit']) && $prod['saleUnit'] !== 'piece') {
                            $ppp = isset($prod['pieces_per_pack']) ? max(1, (int)$prod['pieces_per_pack']) : 1;
                            $ppc = isset($prod['packs_per_carton']) ? max(1, (int)$prod['packs_per_carton']) : 1;
                            if (isset($prod['saleUnit']) && $prod['saleUnit'] === 'carton') $mult = $ppp * $ppc;
                            elseif (isset($prod['saleUnit']) && $prod['saleUnit'] === 'pack') $mult = $ppp;
                        }
                        $q = normalizeQtyForProductData($prod, isset($prod['qty']) ? $prod['qty'] : 1);
                        $returnPieces = $q * $mult;
                        $allowed = isset($origCounts[$pid]) ? (float)$origCounts[$pid] : 0;
                        if ($returnPieces > $allowed) {
                            echo json_encode(["status"=>"error", "message"=>"ژمارا ئایتمێ زڤڕاندنی ژ ژمارا وەسڵا سەرەکی پترە."]); exit();
                        }
                    }
                }
            }
        }

        $fxRetSnap = fxSnapshotBindStringsFromPost();
        $fxRetRate = $fxRetSnap['rate'];
        $fxRetMode = $fxRetSnap['mode'];
        // Invoice-linked return: always lock FX to the original sale, never today's shop rate.
        if ($saleId > 0) {
            $stSaleFx = $conn->prepare('SELECT fx_usd_rate, fx_currency_mode, exchange_rate FROM sales WHERE id = ? LIMIT 1');
            if ($stSaleFx) {
                $stSaleFx->bind_param('i', $saleId);
                $stSaleFx->execute();
                $saleFxRow = $stSaleFx->get_result()->fetch_assoc();
                if ($saleFxRow && function_exists('pos_fx_snapshot_from_sale_row')) {
                    $lockedFx = pos_fx_snapshot_from_sale_row($saleFxRow);
                    if ($lockedFx['rate'] !== '') {
                        $fxRetRate = $lockedFx['rate'];
                    }
                    if ($lockedFx['mode'] !== '') {
                        $fxRetMode = $lockedFx['mode'];
                    }
                }
            }
        }

        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("INSERT INTO `returns` (total, items_json, date, cashier, note, sale_id, payment_method, target_id, target_type, fx_usd_rate, fx_currency_mode) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CAST(NULLIF(?, '') AS UNSIGNED), NULLIF(?, ''))");
            if ($stmt) {
                $stmt->bind_param("dssssisisss", $total, $items, $date, $cashier, $note, $saleId, $payMethod, $targetId, $targetType, $fxRetRate, $fxRetMode);
                if (!$stmt->execute()) throw new Exception("Execute failed: " . $stmt->error);
                $returnId = (int)$stmt->insert_id;
            } else {
                // Fallback if schema alter failed
                $stmt = $conn->prepare("INSERT INTO `returns` (total, items_json, date, cashier, note) VALUES (?, ?, ?, ?, ?)");
                if (!$stmt) throw new Exception("Prepare failed: " . $conn->error);
                $stmt->bind_param("dssss", $total, $items, $date, $cashier, $note);
                if (!$stmt->execute()) throw new Exception("Execute failed: " . $stmt->error);
                $returnId = (int)$stmt->insert_id;
            }

            $cartItems = json_decode($items, true);
            $counts = [];
            $itemCosts = [];
            $itemBarcodes = [];
            if (is_array($cartItems)) {
                foreach ($cartItems as $prod) {
                    $pid = (int)($prod['id'] ?? 0);
                    if (!$pid) continue;
                    $countInCart = normalizeQtyForProductData($prod, isset($prod['qty']) ? $prod['qty'] : (isset($prod['count']) ? $prod['count'] : 1));
                    $mult = 1;
                    if (isset($prod['saleUnit']) && $prod['saleUnit'] !== 'piece') {
                        $ppp = isset($prod['pieces_per_pack']) ? max(1, (int)$prod['pieces_per_pack']) : 1;
                        $ppc = isset($prod['packs_per_carton']) ? max(1, (int)$prod['packs_per_carton']) : 1;
                        $piecesPerCarton = $ppp * $ppc;
                        
                        if ($piecesPerCarton <= 1 && isset($prod['itemsPerCarton']) && (int)$prod['itemsPerCarton'] > 1) {
                            $piecesPerCarton = (int)$prod['itemsPerCarton'];
                        }
                        
                        if ($prod['saleUnit'] === 'carton') $mult = $piecesPerCarton;
                        elseif ($prod['saleUnit'] === 'pack') $mult = $ppp;
                    }
                    $totalPieces = $mult * $countInCart;

                    $jewMembers = [];
                    if (!empty($prod['jewelry_set_items']) && is_array($prod['jewelry_set_items'])) {
                        foreach ($prod['jewelry_set_items'] as $m) {
                            if (!is_array($m)) continue;
                            $mid = (int)($m['product_id'] ?? ($m['id'] ?? 0));
                            if ($mid <= 0) continue;
                            $mq = isset($m['qty']) ? max(0.001, (float)$m['qty']) : 1;
                            $jewMembers[$mid] = ($jewMembers[$mid] ?? 0) + $mq;
                        }
                    } elseif (function_exists('pos_get_jewelry_set_qty_map')) {
                        $jewMembers = pos_get_jewelry_set_qty_map($conn, $pid);
                    }
                    if (!empty($jewMembers)) {
                        foreach ($jewMembers as $mid => $perSet) {
                            $mid = (int)$mid;
                            if ($mid <= 0 || (float)$perSet <= 0) continue;
                            if (!isset($counts[$mid])) {
                                $counts[$mid] = 0;
                                $itemBarcodes[$mid] = '';
                            }
                            $counts[$mid] += ((float)$perSet * $totalPieces);
                        }
                        continue;
                    }

                    if (isset($prod['trackStock']) && ($prod['trackStock'] === true || $prod['trackStock'] == 1 || $prod['trackStock'] === "1")) {
                        if (!isset($counts[$pid])) { 
                            $counts[$pid] = 0; 
                            $itemBarcodes[$pid] = isset($prod['barcode']) ? $prod['barcode'] : ''; 
                        }
                        $counts[$pid] += $totalPieces;

                        // Correctly sum costs
                        if (!isset($itemCosts[$pid])) $itemCosts[$pid] = 0;
                        $costPerUnitInCart = isset($prod['cost']) ? (float)$prod['cost'] : 0;
                        $itemCosts[$pid] += ($costPerUnitInCart * $countInCart);
                    }
                }
                foreach ($counts as $pid => $qty) {
                    $qty = (float)$qty;
                    pos_adjust_tracked_stock($conn, (int)$pid, $qty, $returnWarehouseId);
                    $totalCost = isset($itemCosts[$pid]) ? $itemCosts[$pid] : 0;
                    $bc = isset($itemBarcodes[$pid]) ? $itemBarcodes[$pid] : '';
                    $avgUnitCost = ($qty > 0) ? ($totalCost / $qty) : 0;
                    insertStockMovement($conn, $pid, $bc, 'customer_return', $qty, $avgUnitCost, $totalCost, 'return', $returnId, $date, $cashier, $note ?: '', $returnWarehouseId);
                }
            }

            $debtRefund = 0.0;
            $cashRefund = roundMoney($total);
            $fibRefund = 0.0;
            if ($returnFin && $saleId > 0) {
                $debtRefund = roundMoney((float)$returnFin['debt_adjusted']);
                $cashRefund = roundMoney((float)$returnFin['cash_refunded']);
                $fibRefund = roundMoney((float)($returnFin['fib_refunded'] ?? 0));
            } elseif ($payMethod === 'debt' && $targetId > 0) {
                $debtRefund = roundMoney($total);
                $cashRefund = 0.0;
            } elseif ($payMethod === 'fib') {
                $cashRefund = 0.0;
                $fibRefund = roundMoney($total);
            } elseif ((!$saleId || $saleId <= 0) && $targetId > 0 && in_array($targetType, ['customer', 'user', 'customers'], true)) {
                // Unlinked return: debt-first against open customer balance (prevents cash-drawer drain).
                $tblOpen = ($targetType === 'user') ? 'users' : 'customers';
                $stOpen = $conn->prepare("SELECT balance FROM $tblOpen WHERE id = ? LIMIT 1 FOR UPDATE");
                $openBal = 0.0;
                if ($stOpen) {
                    $stOpen->bind_param('i', $targetId);
                    $stOpen->execute();
                    $ob = $stOpen->get_result()->fetch_assoc();
                    if ($ob) {
                        $openBal = roundMoney((float)($ob['balance'] ?? 0));
                    }
                }
                if ($openBal > 0.0001) {
                    $debtRefund = roundMoney(min($total, $openBal));
                    $cashRefund = roundMoney(max(0.0, $total - $debtRefund));
                    if ($debtRefund >= $total - 0.0001) {
                        $payMethod = 'debt';
                    } elseif ($debtRefund > 0.0001) {
                        $payMethod = 'split';
                    }
                    // INSERT already stored original method — persist debt-first outcome for drawer/metrics.
                    if ($returnId > 0) {
                        $stPm = $conn->prepare("UPDATE `returns` SET payment_method = ? WHERE id = ?");
                        if ($stPm) {
                            $stPm->bind_param('si', $payMethod, $returnId);
                            $stPm->execute();
                        }
                    }
                }
            }

            // Stamp locked total_usd on the return row (parity with sales dual totals).
            if ($returnId > 0 && function_exists('pos_return_stamp_dual_totals')) {
                pos_return_stamp_dual_totals($conn, $returnId, $total, $fxRetRate);
            }

            $txnId = uniqid('TXR');
            $receiptId = (string)$returnId;
            $ledgerType = ($targetType === 'user') ? 'user' : 'customer';

            if ($debtRefund > 0 && $targetId > 0 && in_array($targetType, ['customer', 'user', 'customers'], true)) {
                $tbl = ($targetType === 'user') ? 'users' : 'customers';
                $stmtBal = $conn->prepare("UPDATE $tbl SET balance = balance - ? WHERE id = ?");
                $stmtBal->bind_param('di', $debtRefund, $targetId);
                $stmtBal->execute();

                $retNote = 'زڤڕاندن (قەرز) ' . ($saleId ? "وەسڵ #$saleId" : '') . ($cashRefund > 0 ? " | نەقد=$cashRefund" : '') . ($note ? " — $note" : '');
                $stmtCL = $conn->prepare("INSERT INTO customer_ledger (target_id, target_type, type, amount, date, note, receipt_id) VALUES (?, ?, 'return', ?, ?, ?, ?)");
                $negDebt = -$debtRefund;
                $stmtCL->bind_param('isdsss', $targetId, $ledgerType, $negDebt, $date, $retNote, $receiptId);
                $stmtCL->execute();

                // Unlinked: also peel oldest open invoice remaining_debt (FIFO), matching pay_debt.
                if ((!$saleId || $saleId <= 0) && $targetType !== 'user' && function_exists('pos_apply_customer_sale_debt_payment')) {
                    pos_apply_customer_sale_debt_payment($conn, $targetId, $debtRefund, 0);
                }
            }

            // Keep invoice remaining_debt in sync with debt-first return (prevents FIFO / balance drift).
            if ($saleId > 0 && $debtRefund > 0.0001) {
                $stRem = $conn->prepare("UPDATE sales SET remaining_debt = GREATEST(0, ROUND(COALESCE(remaining_debt,0) - ?, 2)), payment_due_at = IF(GREATEST(0, COALESCE(remaining_debt,0) - ?) <= 0.0001, NULL, payment_due_at) WHERE id = ? AND (is_returned IS NULL OR is_returned = 0)");
                if ($stRem) {
                    $stRem->bind_param('ddi', $debtRefund, $debtRefund, $saleId);
                    $stRem->execute();
                }
            }

            if ($cashRefund > 0) {
                if ($targetId > 0 && in_array($targetType, ['customer', 'user', 'customers'], true)) {
                    $retNoteCash = 'زڤڕاندن (نەقد) ' . ($saleId ? "وەسڵ #$saleId" : '') . ($note ? " — $note" : '');
                    $stmtCL = $conn->prepare("INSERT INTO customer_ledger (target_id, target_type, type, amount, date, note, receipt_id) VALUES (?, ?, 'return_cash', ?, ?, ?, ?)");
                    $negCash = -$cashRefund;
                    $stmtCL->bind_param('isdsss', $targetId, $ledgerType, $negCash, $date, $retNoteCash, $receiptId);
                    $stmtCL->execute();
                }

                $ledgerNote = 'Refund ' . ($saleId ? "(Sale #$saleId) " : '') . ($note ?: 'No specific reason');
                if ($debtRefund > 0) $ledgerNote .= " | cash=$cashRefund";
                $stmtL = $conn->prepare("INSERT INTO ledger (transaction_id, type, amount, note, date) VALUES (?, 'refund', ?, ?, ?)");
                $stmtL->bind_param('sdss', $txnId, $cashRefund, $ledgerNote, $date);
                $stmtL->execute();
            }

            if ($fibRefund > 0) {
                $fibNote = 'Refund FIB ' . ($saleId ? "(Sale #$saleId) " : '') . ($note ?: 'No specific reason');
                $stmtFib = $conn->prepare("INSERT INTO ledger (transaction_id, type, amount, note, date) VALUES (?, 'refund_fib', ?, ?, ?)");
                $stmtFib->bind_param('sdss', $txnId, $fibRefund, $fibNote, $date);
                $stmtFib->execute();
            }

            $newBalance = null;
            if ($targetId > 0 && in_array($targetType, ['customer', 'user', 'customers'], true)) {
                $tbl = ($targetType === 'user') ? 'users' : 'customers';
                $stBal = $conn->prepare("SELECT balance FROM $tbl WHERE id = ? LIMIT 1");
                if ($stBal) {
                    $stBal->bind_param('i', $targetId);
                    $stBal->execute();
                    $balRow = $stBal->get_result()->fetch_assoc();
                    if ($balRow) $newBalance = roundMoney((float)($balRow['balance'] ?? 0));
                }
            }

            if ($saleId > 0 && isset($_SESSION['returns_rt']) && is_array($_SESSION['returns_rt'])) {
                unset($_SESSION['returns_rt'][(string)$saleId]);
            }
            $conn->commit();
            touchLastUpdate($conn);
            $resp = [
                'status' => 'success',
                'id' => $returnId,
                'payment_method' => $payMethod,
                'debt_adjusted' => $debtRefund,
                'cash_refunded' => $cashRefund,
                'fib_refunded' => $fibRefund,
            ];
            if ($newBalance !== null) $resp['customer_balance'] = $newBalance;
            if ($returnFin) {
                $resp['sale_payment_type'] = $returnFin['payment_type'];
            }
            echo json_encode($resp); exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(["status"=>"error", "message" => $e->getMessage()]); exit();
        }
    }

    if ($act === 'update_sale_line') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        if (!pos_session_is_privileged() && !pos_session_has_perm('returns_manage')) {
            pos_json_perm_denied();
        }

        $saleId = (int)($_POST['sale_id'] ?? 0);
        $itemIndex = (int)($_POST['item_index'] ?? -1);
        $newQtyRaw = (float)($_POST['qty'] ?? 0);
        $newLineTotal = roundMoney((float)($_POST['line_total'] ?? 0));
        $newDateInput = trim((string)($_POST['date'] ?? ''));
        $user = trim((string)($_POST['user'] ?? 'System'));

        if ($saleId <= 0 || $itemIndex < 0) {
            echo json_encode(['status' => 'error', 'message' => 'وەسڵ یان ئایتم نادروستە'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        if ($newQtyRaw <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'ژمارە دڤێت گەورەتر بیت لە ٠'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        if ($newLineTotal < 0) {
            echo json_encode(['status' => 'error', 'message' => 'کۆ نابیت نەرێنی'], JSON_UNESCAPED_UNICODE);
            exit();
        }

        $conn->begin_transaction();
        try {
            $st = $conn->prepare('SELECT * FROM sales WHERE id = ? FOR UPDATE');
            if (!$st) throw new Exception('Database error');
            $st->bind_param('i', $saleId);
            $st->execute();
            $res = $st->get_result();
            $row = $res ? $res->fetch_assoc() : null;
            if (!$row) throw new Exception('وەسڵ نەهاتە دیتن');
            if ((int)($row['is_returned'] ?? 0) === 1) throw new Exception('وەسڵ زڤڕاندنە — دەستکاری ناکرێت');

            if (!pos_session_is_privileged()) {
                $name = pos_session_user_name();
                if (($row['cashier'] ?? '') !== $name) {
                    throw new Exception('دەستگەیشتن قەدەغەیە');
                }
            }

            $items = json_decode((string)($row['items_json'] ?? '[]'), true);
            if (!is_array($items) || !isset($items[$itemIndex]) || !is_array($items[$itemIndex])) {
                throw new Exception('ئایتم نەهاتە دیتن');
            }
            $oldItem = $items[$itemIndex];
            if (!empty($oldItem['isGift'])) throw new Exception('دەستکارییا هدیە ناکرێت');

            $pid = (int)($oldItem['id'] ?? 0);
            $prodMeta = [
                'qty_mode' => null,
                'unitType' => null,
                'unit_show_pack' => null,
                'unit_show_carton' => null,
            ];
            if ($pid > 0) {
                $stP = $conn->prepare('SELECT qty_mode, unitType, unit_show_pack, unit_show_carton, trackStock, qty AS prod_qty, name, barcode FROM products WHERE id = ? LIMIT 1');
                if ($stP) {
                    $stP->bind_param('i', $pid);
                    $stP->execute();
                    $pRow = $stP->get_result()->fetch_assoc();
                    if ($pRow) {
                        $prodMeta = array_merge($prodMeta, $pRow);
                    }
                }
            }
            $newQty = normalizeQtyForProductData($prodMeta, $newQtyRaw);
            if ($newQty <= 0) throw new Exception('ژمارەیا دروست نییە');

            $oldDateStr = trim((string)($row['created_at'] ?? ''));
            $oldDateYmd = '';
            if (preg_match('/^(\d{4}-\d{2}-\d{2})/', $oldDateStr, $mOld)) {
                $oldDateYmd = $mOld[1];
            } elseif ($oldDateStr !== '') {
                $ts = strtotime($oldDateStr);
                if ($ts !== false) $oldDateYmd = date('Y-m-d', $ts);
            }
            if ($oldDateYmd === '') $oldDateYmd = date('Y-m-d');
            if ($newDateInput === '') {
                $conn->rollback();
                echo json_encode(['status' => 'error', 'message' => 'بەروار پێدڤیە'], JSON_UNESCAPED_UNICODE);
                exit();
            }
            $newDateYmd = pos_parse_history_date_ymd($newDateInput, $oldDateYmd);
            $timePart = '12:00:00';
            if (preg_match('/(\d{2}:\d{2}:\d{2})/', $oldDateStr, $mTime)) {
                $timePart = $mTime[1];
            }
            $newDateTime = $newDateYmd . ' ' . $timePart;
            $dateChanged = ($newDateYmd !== $oldDateYmd);

            $newUnitPrice = $newQty > 0 ? roundMoney($newLineTotal / $newQty) : 0;
            $items[$itemIndex]['qty'] = $newQty;
            $items[$itemIndex]['count'] = $newQty;
            $items[$itemIndex]['price'] = $newUnitPrice;
            if (array_key_exists('sale_unit', $_POST)) {
                $su = strtolower(trim((string)$_POST['sale_unit']));
                if (in_array($su, ['piece', 'pack', 'carton'], true)) {
                    $items[$itemIndex]['saleUnit'] = $su;
                }
            }

            $oldLineTotal = roundMoney((float)($oldItem['price'] ?? 0) * pos_sale_item_line_qty($oldItem));
            $oldTotal = roundMoney((float)($row['total'] ?? 0));
            $discount = roundMoney((float)($row['discount'] ?? 0));
            $newSubTotal = pos_sale_items_subtotal($items);
            $newTotal = roundMoney(max(0, $newSubTotal - $discount));
            $totalDelta = roundMoney($newTotal - $oldTotal);
            $lineTotalDelta = roundMoney($newLineTotal - $oldLineTotal);

            $payMethod = strtolower(trim((string)($row['payment_method'] ?? 'cash')));
            if ($payMethod === '') $payMethod = 'cash';
            $txnId = trim((string)($row['transaction_id'] ?? ''));
            $targetId = (int)($row['customer_id'] ?? 0);
            $targetType = trim((string)($row['customer_type'] ?? 'customer'));
            if ($targetType === 'customers') $targetType = 'customer';

            $oldPieces = pos_sale_item_pieces($oldItem);
            $newPieces = pos_sale_item_pieces($items[$itemIndex]);
            $pieceDelta = round((float)($newPieces - $oldPieces), 4);
            $trackStock = !empty($prodMeta['trackStock']);
            $stockSkipped = false;

            if (abs($pieceDelta) < 0.0001 && abs($lineTotalDelta) < 0.01 && !$dateChanged) {
                $conn->commit();
                echo json_encode([
                    'status' => 'success',
                    'unchanged' => true,
                    'sale' => pos_fetch_sale_record_by_id($conn, $saleId),
                    'sale_total' => $newTotal,
                ], JSON_UNESCAPED_UNICODE);
                exit();
            }

            if ($trackStock && $pieceDelta > 0.0001) {
                $avail = (float)($prodMeta['prod_qty'] ?? 0);
                if ($avail + 0.0001 < $pieceDelta) {
                    $stockSkipped = true;
                    $pieceDelta = 0;
                }
            }

            $splitCols = null;
            if ($payMethod === 'split') {
                $splitCols = pos_sale_scale_split_amounts($row, $newTotal);
            } elseif ($payMethod === 'cash') {
                $splitCols = [
                    'paid_amount' => $newTotal,
                    'paid_cash' => $newTotal,
                    'paid_bank' => 0.0,
                    'bank_amount' => 0.0,
                    'debt_amount' => 0.0,
                    'remaining_debt' => 0.0,
                    'received_amount' => $newTotal,
                ];
            } elseif ($payMethod === 'debt') {
                $splitCols = [
                    'paid_amount' => 0.0,
                    'paid_cash' => 0.0,
                    'paid_bank' => 0.0,
                    'bank_amount' => 0.0,
                    'debt_amount' => $newTotal,
                    'remaining_debt' => $newTotal,
                    'received_amount' => 0.0,
                ];
            }

            $itemsJson = json_encode($items, JSON_UNESCAPED_UNICODE);
            if ($itemsJson === false) throw new Exception('Invalid items JSON');

            if ($splitCols) {
                $stmtUp = $conn->prepare('UPDATE sales SET total = ?, items_json = ?, created_at = ?, paid_amount = ?, debt_amount = ?, bank_amount = ?, received_amount = ?, paid_cash = ?, paid_bank = ?, remaining_debt = ? WHERE id = ?');
                if (!$stmtUp) throw new Exception('Database error');
                $stmtUp->bind_param(
                    'dssdddddddi',
                    $newTotal,
                    $itemsJson,
                    $newDateTime,
                    $splitCols['paid_amount'],
                    $splitCols['debt_amount'],
                    $splitCols['bank_amount'],
                    $splitCols['received_amount'],
                    $splitCols['paid_cash'],
                    $splitCols['paid_bank'],
                    $splitCols['remaining_debt'],
                    $saleId
                );
            } else {
                $stmtUp = $conn->prepare('UPDATE sales SET total = ?, items_json = ?, created_at = ? WHERE id = ?');
                if (!$stmtUp) throw new Exception('Database error');
                $stmtUp->bind_param('dssi', $newTotal, $itemsJson, $newDateTime, $saleId);
            }
            $stmtUp->execute();

            if ($dateChanged && $txnId !== '') {
                $stLedDt = $conn->prepare('UPDATE ledger SET date = ? WHERE transaction_id = ?');
                if ($stLedDt) {
                    $stLedDt->bind_param('ss', $newDateTime, $txnId);
                    $stLedDt->execute();
                }
                $stClDt = $conn->prepare('UPDATE customer_ledger SET date = ? WHERE transaction_id = ?');
                if ($stClDt) {
                    $stClDt->bind_param('ss', $newDateTime, $txnId);
                    $stClDt->execute();
                }
            }

            $cashLedgerAmt = $newTotal;
            $debtLedgerAmt = 0.0;
            if ($payMethod === 'split' && $splitCols) {
                $cashLedgerAmt = roundMoney((float)$splitCols['paid_cash'] + (float)$splitCols['paid_bank']);
                $debtLedgerAmt = roundMoney((float)$splitCols['remaining_debt']);
            } elseif ($payMethod === 'debt') {
                $cashLedgerAmt = 0.0;
                $debtLedgerAmt = $newTotal;
            }

            if ($txnId !== '' && abs($totalDelta) >= 0.01) {
                if ($cashLedgerAmt > 0) {
                    $stLC = $conn->prepare("UPDATE ledger SET amount = ? WHERE transaction_id = ? AND type = 'sale' LIMIT 1");
                    if ($stLC) {
                        $stLC->bind_param('ds', $cashLedgerAmt, $txnId);
                        $stLC->execute();
                    }
                }
                if ($debtLedgerAmt > 0) {
                    $stLD = $conn->prepare("UPDATE ledger SET amount = ? WHERE transaction_id = ? AND type = 'sale_credit' LIMIT 1");
                    if ($stLD) {
                        $stLD->bind_param('ds', $debtLedgerAmt, $txnId);
                        $stLD->execute();
                    }
                }
            }

            $customerBalanceOut = null;
            if ($targetId > 0 && abs($totalDelta) >= 0.01) {
                $debtDelta = 0.0;
                if ($payMethod === 'debt') {
                    $debtDelta = $totalDelta;
                } elseif ($payMethod === 'split' && $splitCols) {
                    $oldDebt = roundMoney((float)($row['remaining_debt'] ?? ($row['debt_amount'] ?? 0)));
                    $debtDelta = roundMoney((float)$splitCols['remaining_debt'] - $oldDebt);
                }
                if (abs($debtDelta) >= 0.01) {
                    $balTable = ($targetType === 'user') ? 'users' : 'customers';
                    $stBal = $conn->prepare("UPDATE {$balTable} SET balance = balance + ? WHERE id = ?");
                    if ($stBal) {
                        $stBal->bind_param('di', $debtDelta, $targetId);
                        $stBal->execute();
                    }
                    if ($txnId !== '') {
                        $stClAmt = $conn->prepare("UPDATE customer_ledger SET amount = ? WHERE transaction_id = ? AND type = 'sale' LIMIT 1");
                        if ($stClAmt && $payMethod === 'debt') {
                            $stClAmt->bind_param('ds', $newTotal, $txnId);
                            $stClAmt->execute();
                        }
                    }
                    $stBalOut = $conn->prepare("SELECT balance FROM {$balTable} WHERE id = ? LIMIT 1");
                    if ($stBalOut) {
                        $stBalOut->bind_param('i', $targetId);
                        $stBalOut->execute();
                        $balOutRow = $stBalOut->get_result()->fetch_assoc();
                        if ($balOutRow) $customerBalanceOut = roundMoney((float)($balOutRow['balance'] ?? 0));
                    }
                }
            }

            if ($trackStock && abs($pieceDelta) >= 0.0001 && !$stockSkipped && $pid > 0) {
                $saleWh = function_exists('pos_sale_row_warehouse_id') ? pos_sale_row_warehouse_id($conn, $row) : pos_resolve_warehouse_id($conn, 0);
                pos_adjust_tracked_stock($conn, $pid, -$pieceDelta, $saleWh);
                $bc = trim((string)($prodMeta['barcode'] ?? ''));
                $unitCost = $newQty > 0 ? roundMoney($newLineTotal / $newPieces) : 0;
                $costDelta = roundMoney($newLineTotal - $oldLineTotal);
                insertStockMovement($conn, $pid, $bc, 'sale_edit', -$pieceDelta, $unitCost, $costDelta, 'sale', $saleId, date('Y-m-d H:i:s'), $user, 'دەستکارییا فرۆشتن #' . $saleId, $saleWh);
                if ($pieceDelta > 0 && function_exists('consumeStockBatchesFefo')) {
                    consumeStockBatchesFefo($conn, $pid, $pieceDelta, $txnId, $saleId, (string)($prodMeta['name'] ?? ''));
                }
            }

            try {
                $oSnap = pos_sale_edit_line_snap($oldItem);
                $nSnap = pos_sale_edit_line_snap($items[$itemIndex]);
                $parts = [];
                if (abs((float)$oSnap['qty'] - (float)$nSnap['qty']) >= 0.0001 || (string)$oSnap['saleUnit'] !== (string)$nSnap['saleUnit']) {
                    $parts[] = 'ژمارە ' . pos_sale_edit_fmt_qty($oSnap['qty']) . ' ' . pos_sale_edit_unit_label((string)$oSnap['saleUnit'])
                        . '→' . pos_sale_edit_fmt_qty($nSnap['qty']) . ' ' . pos_sale_edit_unit_label((string)$nSnap['saleUnit']);
                }
                if (abs((float)$oSnap['price'] - (float)$nSnap['price']) >= 0.01) {
                    $parts[] = 'نرخ ' . pos_sale_edit_fmt_money($oSnap['price']) . '→' . pos_sale_edit_fmt_money($nSnap['price']);
                }
                if ($dateChanged) {
                    $parts[] = 'بەروار ' . $oldDateYmd . '→' . $newDateYmd;
                }
                $changeLine = 'گۆڕا: ' . $nSnap['name'] . (empty($parts) ? '' : (' — ' . implode(' · ', $parts)));
                $detailsText = 'دەستکارییا فرۆشتن #' . $saleId . ' | ' . $changeLine . ' | total ' . $oldTotal . '→' . $newTotal . ($stockSkipped ? ' | stock_skip' : '');
                $oldJson = json_encode(['total' => $oldTotal, 'items' => [$oSnap], 'changes' => [$changeLine]], JSON_UNESCAPED_UNICODE);
                $newJson = json_encode(['total' => $newTotal, 'items' => [$nSnap]], JSON_UNESCAPED_UNICODE);
                logAction($conn, $user, 'sale_line_edit', $detailsText, null, 'sale', $saleId, $oldJson ?: null, $newJson ?: null);
            } catch (Throwable $e) {}

            $conn->commit();
            touchLastUpdate($conn);
            echo json_encode([
                'status' => 'success',
                'sale' => pos_fetch_sale_record_by_id($conn, $saleId),
                'sale_total' => $newTotal,
                'customer_balance' => $customerBalanceOut,
                'customer_id' => $targetId,
                'customer_type' => $targetType,
                'stock_skipped' => $stockSkipped,
            ], JSON_UNESCAPED_UNICODE);
            exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
            exit();
        }
    }

    if ($act === 'delete_sale_line') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        if (!pos_session_is_privileged() && !pos_session_has_perm('returns_manage')) {
            pos_json_perm_denied();
        }

        $saleId = (int)($_POST['sale_id'] ?? 0);
        $itemIndex = (int)($_POST['item_index'] ?? -1);
        $user = trim((string)($_POST['user'] ?? 'System'));

        if ($saleId <= 0 || $itemIndex < 0) {
            echo json_encode(['status' => 'error', 'message' => 'وەسڵ یان ئایتم نادروستە'], JSON_UNESCAPED_UNICODE);
            exit();
        }

        $conn->begin_transaction();
        try {
            $st = $conn->prepare('SELECT * FROM sales WHERE id = ? FOR UPDATE');
            if (!$st) throw new Exception('Database error');
            $st->bind_param('i', $saleId);
            $st->execute();
            $row = $st->get_result()->fetch_assoc();
            if (!$row) throw new Exception('وەسڵ نەهاتە دیتن');
            if ((int)($row['is_returned'] ?? 0) === 1) throw new Exception('وەسڵ زڤڕاندنە — دەستکاری ناکرێت');
            if (!pos_session_is_privileged()) {
                $name = pos_session_user_name();
                if (($row['cashier'] ?? '') !== $name) throw new Exception('دەستگەیشتن قەدەغەیە');
            }

            $items = json_decode((string)($row['items_json'] ?? '[]'), true);
            if (!is_array($items) || !isset($items[$itemIndex]) || !is_array($items[$itemIndex])) {
                throw new Exception('ئایتم نەهاتە دیتن');
            }
            $oldItem = $items[$itemIndex];
            if (!empty($oldItem['isGift'])) throw new Exception('سڕینەوەی هدیە ناکرێت — دەستکاری بکە');

            $pid = (int)($oldItem['id'] ?? 0);
            $oldPieces = pos_sale_item_pieces($oldItem);
            $oldLineTotal = roundMoney((float)($oldItem['price'] ?? 0) * pos_sale_item_line_qty($oldItem));
            $oldTotal = roundMoney((float)($row['total'] ?? 0));
            $discount = roundMoney((float)($row['discount'] ?? 0));
            $isLastItem = count($items) <= 1;

            $payMethod = strtolower(trim((string)($row['payment_method'] ?? 'cash')));
            if ($payMethod === '') $payMethod = 'cash';
            $txnId = trim((string)($row['transaction_id'] ?? ''));
            $targetId = (int)($row['customer_id'] ?? 0);
            $targetType = trim((string)($row['customer_type'] ?? 'customer'));
            if ($targetType === 'customers') $targetType = 'customer';

            // Restore stock for removed line
            if ($pid > 0 && $oldPieces > 0.0001) {
                $stP = $conn->prepare('SELECT trackStock, barcode, name FROM products WHERE id = ? LIMIT 1');
                $prodMeta = null;
                if ($stP) {
                    $stP->bind_param('i', $pid);
                    $stP->execute();
                    $prodMeta = $stP->get_result()->fetch_assoc();
                }
                if ($prodMeta && !empty($prodMeta['trackStock'])) {
                    $saleWh = function_exists('pos_sale_row_warehouse_id') ? pos_sale_row_warehouse_id($conn, $row) : pos_resolve_warehouse_id($conn, 0);
                    pos_adjust_tracked_stock($conn, $pid, $oldPieces, $saleWh);
                    $bc = trim((string)($prodMeta['barcode'] ?? ''));
                    $unitCost = $oldPieces > 0 ? roundMoney($oldLineTotal / $oldPieces) : 0;
                    insertStockMovement($conn, $pid, $bc, 'sale_edit', $oldPieces, $unitCost, -$oldLineTotal, 'sale', $saleId, date('Y-m-d H:i:s'), $user, ($isLastItem ? 'سڕینەوەی تەواوی فرۆشتن #' : 'سڕینەوەی ئایتم لە فرۆشتن #') . $saleId, $saleWh);
                }
            }

            // Last remaining item → soft-void entire sale (keep row for undo / traces)
            if ($isLastItem) {
                $debtToReverse = 0.0;
                if ($payMethod === 'debt') {
                    $debtToReverse = $oldTotal;
                } elseif ($payMethod === 'split') {
                    $debtToReverse = roundMoney((float)($row['remaining_debt'] ?? ($row['debt_amount'] ?? 0)));
                }
                if ($targetId > 0 && abs($debtToReverse) >= 0.01) {
                    $balTable = ($targetType === 'user') ? 'users' : 'customers';
                    $neg = -$debtToReverse;
                    $stBal = $conn->prepare("UPDATE {$balTable} SET balance = balance + ? WHERE id = ?");
                    if ($stBal) { $stBal->bind_param('di', $neg, $targetId); $stBal->execute(); }
                    $noteVoid = "Voided Sale #$saleId";
                    $stmtCL = $conn->prepare("INSERT INTO customer_ledger (target_id, target_type, type, amount, date, note) VALUES (?, ?, 'void', ?, NOW(), ?)");
                    if ($stmtCL) {
                        $stmtCL->bind_param('isds', $targetId, $targetType, $debtToReverse, $noteVoid);
                        $stmtCL->execute();
                    }
                }

                // Reverse cash / credit ledger portions without deleting original sale rows
                $cashAmt = 0.0;
                $creditLedgerAmt = 0.0;
                $stmtCash = $conn->prepare("SELECT COALESCE(SUM(amount),0) as amt FROM ledger WHERE type = 'sale' AND related_id = ?");
                if ($stmtCash) {
                    $stmtCash->bind_param('i', $saleId);
                    $stmtCash->execute();
                    $resCash = $stmtCash->get_result();
                    if ($resCash && ($rowCash = $resCash->fetch_assoc())) {
                        $cashAmt = roundMoney((float)($rowCash['amt'] ?? 0));
                    }
                }
                $stmtCredit = $conn->prepare("SELECT COALESCE(SUM(amount),0) as amt FROM ledger WHERE type = 'sale_credit' AND related_id = ?");
                if ($stmtCredit) {
                    $stmtCredit->bind_param('i', $saleId);
                    $stmtCredit->execute();
                    $resCredit = $stmtCredit->get_result();
                    if ($resCredit && ($rowCredit = $resCredit->fetch_assoc())) {
                        $creditLedgerAmt = roundMoney((float)($rowCredit['amt'] ?? 0));
                    }
                }
                if ($cashAmt > 0) {
                    $txnV = uniqid('TXV');
                    $amtV = $cashAmt;
                    $dateV = date('Y-m-d H:i:s');
                    $noteV = "Voided Sale #$saleId";
                    $stmtL = $conn->prepare("INSERT INTO ledger (transaction_id, type, amount, note, date) VALUES (?, 'void_sale', ?, ?, ?)");
                    if ($stmtL) { $stmtL->bind_param('sdss', $txnV, $amtV, $noteV, $dateV); $stmtL->execute(); }
                }
                if ($creditLedgerAmt > 0) {
                    $txnV2 = uniqid('TXVCR');
                    $amtV2 = $creditLedgerAmt;
                    $dateV2 = date('Y-m-d H:i:s');
                    $noteV2 = "Voided Credit Sale #$saleId";
                    $stmtLC = $conn->prepare("INSERT INTO ledger (transaction_id, type, amount, note, date) VALUES (?, 'void_sale_credit', ?, ?, ?)");
                    if ($stmtLC) { $stmtLC->bind_param('sdss', $txnV2, $amtV2, $noteV2, $dateV2); $stmtLC->execute(); }
                }

                $stVoid = $conn->prepare('UPDATE sales SET is_returned = 1 WHERE id = ?');
                if (!$stVoid) throw new Exception('Database error');
                $stVoid->bind_param('i', $saleId);
                $stVoid->execute();

                try {
                    $snap = [
                        'id' => (int)$saleId,
                        'total' => (float)$oldTotal,
                        'cashier' => (string)($row['cashier'] ?? ''),
                        'payment_method' => (string)$payMethod,
                        'customer_id' => (int)$targetId,
                        'customer_type' => (string)$targetType,
                        'items' => $items,
                        'kind' => 'sale_void_last_line',
                    ];
                    $oldJson = json_encode($snap, JSON_UNESCAPED_UNICODE);
                    $detailsText = 'ژێبرنا وەسڵێ (دوایین ئایتم) #' . $saleId . ' — شینوار پاراستینە بۆ پەشیمانبوونێ';
                    logAction($conn, $user, 'void_sale', $detailsText, null, 'sale', $saleId, $oldJson ?: null, null);
                } catch (Throwable $e) {}

                $conn->commit();
                touchLastUpdate($conn);
                echo json_encode([
                    'status' => 'success',
                    'sale_deleted' => true,
                    'sale_voided' => true,
                    'voided' => true,
                    'sale_id' => $saleId,
                    'customer_id' => $targetId,
                    'customer_type' => $targetType,
                ], JSON_UNESCAPED_UNICODE);
                exit();
            }

            array_splice($items, $itemIndex, 1);
            $newSubTotal = pos_sale_items_subtotal($items);
            $newTotal = roundMoney(max(0, $newSubTotal - $discount));
            $totalDelta = roundMoney($newTotal - $oldTotal);

            $splitCols = null;
            if ($payMethod === 'split') {
                $splitCols = pos_sale_scale_split_amounts($row, $newTotal);
            } elseif ($payMethod === 'cash') {
                $splitCols = [
                    'paid_amount' => $newTotal, 'paid_cash' => $newTotal, 'paid_bank' => 0.0,
                    'bank_amount' => 0.0, 'debt_amount' => 0.0, 'remaining_debt' => 0.0, 'received_amount' => $newTotal,
                ];
            } elseif ($payMethod === 'debt') {
                $splitCols = [
                    'paid_amount' => 0.0, 'paid_cash' => 0.0, 'paid_bank' => 0.0,
                    'bank_amount' => 0.0, 'debt_amount' => $newTotal, 'remaining_debt' => $newTotal, 'received_amount' => 0.0,
                ];
            }

            $itemsJson = json_encode(array_values($items), JSON_UNESCAPED_UNICODE);
            if ($itemsJson === false) throw new Exception('Invalid items JSON');

            if ($splitCols) {
                $stmtUp = $conn->prepare('UPDATE sales SET total = ?, items_json = ?, paid_amount = ?, debt_amount = ?, bank_amount = ?, received_amount = ?, paid_cash = ?, paid_bank = ?, remaining_debt = ? WHERE id = ?');
                if (!$stmtUp) throw new Exception('Database error');
                $stmtUp->bind_param(
                    'dsdddddddi',
                    $newTotal, $itemsJson,
                    $splitCols['paid_amount'], $splitCols['debt_amount'], $splitCols['bank_amount'],
                    $splitCols['received_amount'], $splitCols['paid_cash'], $splitCols['paid_bank'],
                    $splitCols['remaining_debt'], $saleId
                );
            } else {
                $stmtUp = $conn->prepare('UPDATE sales SET total = ?, items_json = ? WHERE id = ?');
                if (!$stmtUp) throw new Exception('Database error');
                $stmtUp->bind_param('dsi', $newTotal, $itemsJson, $saleId);
            }
            $stmtUp->execute();

            $cashLedgerAmt = $newTotal;
            $debtLedgerAmt = 0.0;
            if ($payMethod === 'split' && $splitCols) {
                $cashLedgerAmt = roundMoney((float)$splitCols['paid_cash'] + (float)$splitCols['paid_bank']);
                $debtLedgerAmt = roundMoney((float)$splitCols['remaining_debt']);
            } elseif ($payMethod === 'debt') {
                $cashLedgerAmt = 0.0;
                $debtLedgerAmt = $newTotal;
            }
            if ($txnId !== '' && abs($totalDelta) >= 0.01) {
                if ($cashLedgerAmt > 0) {
                    $stLC = $conn->prepare("UPDATE ledger SET amount = ? WHERE transaction_id = ? AND type = 'sale' LIMIT 1");
                    if ($stLC) { $stLC->bind_param('ds', $cashLedgerAmt, $txnId); $stLC->execute(); }
                }
                if ($debtLedgerAmt > 0) {
                    $stLD = $conn->prepare("UPDATE ledger SET amount = ? WHERE transaction_id = ? AND type = 'sale_credit' LIMIT 1");
                    if ($stLD) { $stLD->bind_param('ds', $debtLedgerAmt, $txnId); $stLD->execute(); }
                }
            }

            $customerBalanceOut = null;
            if ($targetId > 0 && abs($totalDelta) >= 0.01) {
                $debtDelta = 0.0;
                if ($payMethod === 'debt') {
                    $debtDelta = $totalDelta;
                } elseif ($payMethod === 'split' && $splitCols) {
                    $oldDebt = roundMoney((float)($row['remaining_debt'] ?? ($row['debt_amount'] ?? 0)));
                    $debtDelta = roundMoney((float)$splitCols['remaining_debt'] - $oldDebt);
                }
                if (abs($debtDelta) >= 0.01) {
                    $balTable = ($targetType === 'user') ? 'users' : 'customers';
                    $stBal = $conn->prepare("UPDATE {$balTable} SET balance = balance + ? WHERE id = ?");
                    if ($stBal) { $stBal->bind_param('di', $debtDelta, $targetId); $stBal->execute(); }
                    if ($txnId !== '' && $payMethod === 'debt') {
                        $stClAmt = $conn->prepare("UPDATE customer_ledger SET amount = ? WHERE transaction_id = ? AND type = 'sale' LIMIT 1");
                        if ($stClAmt) { $stClAmt->bind_param('ds', $newTotal, $txnId); $stClAmt->execute(); }
                    }
                    $stBalOut = $conn->prepare("SELECT balance FROM {$balTable} WHERE id = ? LIMIT 1");
                    if ($stBalOut) {
                        $stBalOut->bind_param('i', $targetId);
                        $stBalOut->execute();
                        $balOutRow = $stBalOut->get_result()->fetch_assoc();
                        if ($balOutRow) $customerBalanceOut = roundMoney((float)($balOutRow['balance'] ?? 0));
                    }
                }
            }

            try {
                $oSnap = pos_sale_edit_line_snap($oldItem);
                $changeLine = 'سڕا: ' . $oSnap['name'] . ' — ' . pos_sale_edit_fmt_qty($oSnap['qty']) . ' '
                    . pos_sale_edit_unit_label((string)$oSnap['saleUnit']) . ' · ' . pos_sale_edit_fmt_money($oSnap['line_total']);
                $detailsText = 'سڕینەوەی ئایتم لە فرۆشتن #' . $saleId . ' | ' . $changeLine . ' | total ' . $oldTotal . '→' . $newTotal;
                $oldJson = json_encode(['total' => $oldTotal, 'items' => [$oSnap], 'changes' => [$changeLine]], JSON_UNESCAPED_UNICODE);
                $newJson = json_encode(['total' => $newTotal, 'items' => []], JSON_UNESCAPED_UNICODE);
                logAction($conn, $user, 'sale_line_delete', $detailsText, null, 'sale', $saleId, $oldJson ?: null, $newJson ?: null);
            } catch (Throwable $e) {}

            $conn->commit();
            touchLastUpdate($conn);
            echo json_encode([
                'status' => 'success',
                'sale' => pos_fetch_sale_record_by_id($conn, $saleId),
                'sale_total' => $newTotal,
                'customer_balance' => $customerBalanceOut,
                'customer_id' => $targetId,
                'customer_type' => $targetType,
            ], JSON_UNESCAPED_UNICODE);
            exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
            exit();
        }
    }

    if ($act === 'add_sale_line') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        if (!pos_session_is_privileged() && !pos_session_has_perm('returns_manage')) {
            pos_json_perm_denied();
        }

        $saleId = (int)($_POST['sale_id'] ?? 0);
        $productId = (int)($_POST['product_id'] ?? 0);
        $newQtyRaw = (float)($_POST['qty'] ?? 0);
        $newLineTotal = roundMoney((float)($_POST['line_total'] ?? 0));
        $saleUnit = strtolower(trim((string)($_POST['sale_unit'] ?? 'piece')));
        if (!in_array($saleUnit, ['piece', 'pack', 'carton'], true)) $saleUnit = 'piece';
        $user = trim((string)($_POST['user'] ?? 'System'));

        if ($saleId <= 0 || $productId <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'وەسڵ یان کاڵا نادروستە'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        if ($newQtyRaw <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'ژمارە دڤێت گەورەتر بیت لە ٠'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        if ($newLineTotal < 0) {
            echo json_encode(['status' => 'error', 'message' => 'کۆ نابیت نەرێنی'], JSON_UNESCAPED_UNICODE);
            exit();
        }

        $conn->begin_transaction();
        try {
            $st = $conn->prepare('SELECT * FROM sales WHERE id = ? FOR UPDATE');
            if (!$st) throw new Exception('Database error');
            $st->bind_param('i', $saleId);
            $st->execute();
            $row = $st->get_result()->fetch_assoc();
            if (!$row) throw new Exception('وەسڵ نەهاتە دیتن');
            if ((int)($row['is_returned'] ?? 0) === 1) throw new Exception('وەسڵ زڤڕاندنە — دەستکاری ناکرێت');
            if (!pos_session_is_privileged()) {
                $name = pos_session_user_name();
                if (($row['cashier'] ?? '') !== $name) throw new Exception('دەستگەیشتن قەدەغەیە');
            }

            $stP = $conn->prepare('SELECT id, name, barcode, price, cost, qty AS prod_qty, trackStock, qty_mode, unitType, unit_show_pack, unit_show_carton, pieces_per_pack, packs_per_carton, itemsPerCarton FROM products WHERE id = ? AND (is_active IS NULL OR is_active = 1) LIMIT 1');
            if (!$stP) throw new Exception('Database error');
            $stP->bind_param('i', $productId);
            $stP->execute();
            $prod = $stP->get_result()->fetch_assoc();
            if (!$prod) throw new Exception('کاڵا نەهاتە دیتن');

            $newQty = normalizeQtyForProductData($prod, $newQtyRaw);
            if ($newQty <= 0) throw new Exception('ژمارەیا دروست نییە');
            $newUnitPrice = $newQty > 0 ? roundMoney($newLineTotal / $newQty) : 0;

            $newItem = [
                'id' => (int)$prod['id'],
                'name' => (string)($prod['name'] ?? ''),
                'barcode' => (string)($prod['barcode'] ?? ''),
                'qty' => $newQty,
                'count' => $newQty,
                'price' => $newUnitPrice,
                'cost' => roundMoney((float)($prod['cost'] ?? 0)),
                'saleUnit' => $saleUnit,
                'pieces_per_pack' => max(1, (int)($prod['pieces_per_pack'] ?? 1)),
                'packs_per_carton' => max(1, (int)($prod['packs_per_carton'] ?? 1)),
                'itemsPerCarton' => max(1, (int)($prod['itemsPerCarton'] ?? 1)),
            ];
            $newPieces = pos_sale_item_pieces($newItem);

            $items = json_decode((string)($row['items_json'] ?? '[]'), true);
            if (!is_array($items)) $items = [];
            $items[] = $newItem;

            $oldTotal = roundMoney((float)($row['total'] ?? 0));
            $discount = roundMoney((float)($row['discount'] ?? 0));
            $newSubTotal = pos_sale_items_subtotal($items);
            $newTotal = roundMoney(max(0, $newSubTotal - $discount));
            $totalDelta = roundMoney($newTotal - $oldTotal);

            $payMethod = strtolower(trim((string)($row['payment_method'] ?? 'cash')));
            if ($payMethod === '') $payMethod = 'cash';
            $txnId = trim((string)($row['transaction_id'] ?? ''));
            $targetId = (int)($row['customer_id'] ?? 0);
            $targetType = trim((string)($row['customer_type'] ?? 'customer'));
            if ($targetType === 'customers') $targetType = 'customer';

            $stockSkipped = false;
            $trackStock = !empty($prod['trackStock']);
            if ($trackStock && $newPieces > 0.0001) {
                $avail = (float)($prod['prod_qty'] ?? 0);
                if ($avail + 0.0001 < $newPieces) {
                    $stockSkipped = true;
                }
            }

            $splitCols = null;
            if ($payMethod === 'split') {
                $splitCols = pos_sale_scale_split_amounts($row, $newTotal);
            } elseif ($payMethod === 'cash') {
                $splitCols = [
                    'paid_amount' => $newTotal, 'paid_cash' => $newTotal, 'paid_bank' => 0.0,
                    'bank_amount' => 0.0, 'debt_amount' => 0.0, 'remaining_debt' => 0.0, 'received_amount' => $newTotal,
                ];
            } elseif ($payMethod === 'debt') {
                $splitCols = [
                    'paid_amount' => 0.0, 'paid_cash' => 0.0, 'paid_bank' => 0.0,
                    'bank_amount' => 0.0, 'debt_amount' => $newTotal, 'remaining_debt' => $newTotal, 'received_amount' => 0.0,
                ];
            }

            $itemsJson = json_encode(array_values($items), JSON_UNESCAPED_UNICODE);
            if ($itemsJson === false) throw new Exception('Invalid items JSON');

            if ($splitCols) {
                $stmtUp = $conn->prepare('UPDATE sales SET total = ?, items_json = ?, paid_amount = ?, debt_amount = ?, bank_amount = ?, received_amount = ?, paid_cash = ?, paid_bank = ?, remaining_debt = ? WHERE id = ?');
                if (!$stmtUp) throw new Exception('Database error');
                $stmtUp->bind_param(
                    'dsdddddddi',
                    $newTotal, $itemsJson,
                    $splitCols['paid_amount'], $splitCols['debt_amount'], $splitCols['bank_amount'],
                    $splitCols['received_amount'], $splitCols['paid_cash'], $splitCols['paid_bank'],
                    $splitCols['remaining_debt'], $saleId
                );
            } else {
                $stmtUp = $conn->prepare('UPDATE sales SET total = ?, items_json = ? WHERE id = ?');
                if (!$stmtUp) throw new Exception('Database error');
                $stmtUp->bind_param('dsi', $newTotal, $itemsJson, $saleId);
            }
            $stmtUp->execute();

            $cashLedgerAmt = $newTotal;
            $debtLedgerAmt = 0.0;
            if ($payMethod === 'split' && $splitCols) {
                $cashLedgerAmt = roundMoney((float)$splitCols['paid_cash'] + (float)$splitCols['paid_bank']);
                $debtLedgerAmt = roundMoney((float)$splitCols['remaining_debt']);
            } elseif ($payMethod === 'debt') {
                $cashLedgerAmt = 0.0;
                $debtLedgerAmt = $newTotal;
            }
            if ($txnId !== '' && abs($totalDelta) >= 0.01) {
                if ($cashLedgerAmt > 0) {
                    $stLC = $conn->prepare("UPDATE ledger SET amount = ? WHERE transaction_id = ? AND type = 'sale' LIMIT 1");
                    if ($stLC) { $stLC->bind_param('ds', $cashLedgerAmt, $txnId); $stLC->execute(); }
                }
                if ($debtLedgerAmt > 0) {
                    $stLD = $conn->prepare("UPDATE ledger SET amount = ? WHERE transaction_id = ? AND type = 'sale_credit' LIMIT 1");
                    if ($stLD) { $stLD->bind_param('ds', $debtLedgerAmt, $txnId); $stLD->execute(); }
                }
            }

            $customerBalanceOut = null;
            if ($targetId > 0 && abs($totalDelta) >= 0.01) {
                $debtDelta = 0.0;
                if ($payMethod === 'debt') {
                    $debtDelta = $totalDelta;
                } elseif ($payMethod === 'split' && $splitCols) {
                    $oldDebt = roundMoney((float)($row['remaining_debt'] ?? ($row['debt_amount'] ?? 0)));
                    $debtDelta = roundMoney((float)$splitCols['remaining_debt'] - $oldDebt);
                }
                if (abs($debtDelta) >= 0.01) {
                    $balTable = ($targetType === 'user') ? 'users' : 'customers';
                    $stBal = $conn->prepare("UPDATE {$balTable} SET balance = balance + ? WHERE id = ?");
                    if ($stBal) { $stBal->bind_param('di', $debtDelta, $targetId); $stBal->execute(); }
                    if ($txnId !== '' && $payMethod === 'debt') {
                        $stClAmt = $conn->prepare("UPDATE customer_ledger SET amount = ? WHERE transaction_id = ? AND type = 'sale' LIMIT 1");
                        if ($stClAmt) { $stClAmt->bind_param('ds', $newTotal, $txnId); $stClAmt->execute(); }
                    }
                    $stBalOut = $conn->prepare("SELECT balance FROM {$balTable} WHERE id = ? LIMIT 1");
                    if ($stBalOut) {
                        $stBalOut->bind_param('i', $targetId);
                        $stBalOut->execute();
                        $balOutRow = $stBalOut->get_result()->fetch_assoc();
                        if ($balOutRow) $customerBalanceOut = roundMoney((float)($balOutRow['balance'] ?? 0));
                    }
                }
            }

            if ($trackStock && !$stockSkipped && $newPieces > 0.0001) {
                $saleWh = function_exists('pos_sale_row_warehouse_id') ? pos_sale_row_warehouse_id($conn, $row) : pos_resolve_warehouse_id($conn, 0);
                pos_adjust_tracked_stock($conn, $productId, -$newPieces, $saleWh);
                $bc = trim((string)($prod['barcode'] ?? ''));
                $unitCost = $newPieces > 0 ? roundMoney($newLineTotal / $newPieces) : 0;
                insertStockMovement($conn, $productId, $bc, 'sale_edit', -$newPieces, $unitCost, $newLineTotal, 'sale', $saleId, date('Y-m-d H:i:s'), $user, 'زیادکردنی ئایتم بۆ فرۆشتن #' . $saleId, $saleWh);
                if (function_exists('consumeStockBatchesFefo')) {
                    consumeStockBatchesFefo($conn, $productId, $newPieces, $txnId, $saleId, (string)($prod['name'] ?? ''));
                }
            }

            try {
                $nSnap = pos_sale_edit_line_snap($newItem);
                $changeLine = 'زیادکرا: ' . $nSnap['name'] . ' — ' . pos_sale_edit_fmt_qty($nSnap['qty']) . ' '
                    . pos_sale_edit_unit_label((string)$nSnap['saleUnit']) . ' · ' . pos_sale_edit_fmt_money($nSnap['line_total']);
                $detailsText = 'زیادکردنی ئایتم بۆ فرۆشتن #' . $saleId . ' | ' . $changeLine . ' | total ' . $oldTotal . '→' . $newTotal . ($stockSkipped ? ' | stock_skip' : '');
                $oldJson = json_encode(['total' => $oldTotal, 'items' => [], 'changes' => [$changeLine]], JSON_UNESCAPED_UNICODE);
                $newJson = json_encode(['total' => $newTotal, 'items' => [$nSnap]], JSON_UNESCAPED_UNICODE);
                logAction($conn, $user, 'sale_line_add', $detailsText, null, 'sale', $saleId, $oldJson ?: null, $newJson ?: null);
            } catch (Throwable $e) {}

            $conn->commit();
            touchLastUpdate($conn);
            echo json_encode([
                'status' => 'success',
                'sale' => pos_fetch_sale_record_by_id($conn, $saleId),
                'sale_total' => $newTotal,
                'customer_balance' => $customerBalanceOut,
                'customer_id' => $targetId,
                'customer_type' => $targetType,
                'stock_skipped' => $stockSkipped,
            ], JSON_UNESCAPED_UNICODE);
            exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
            exit();
        }
    }

    /**
     * Replace all items on an existing sale from the POS basket (edit mode).
     * Keeps sale id + created_at — does NOT insert a new sales row.
     */
    if ($act === 'replace_sale_cart') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        if (!pos_session_is_privileged() && !pos_session_has_perm('returns_manage')) {
            pos_json_perm_denied();
        }

        $saleId = (int)($_POST['sale_id'] ?? 0);
        $itemsRaw = $_POST['items'] ?? '[]';
        $discountIn = roundMoney((float)($_POST['discount'] ?? 0));
        $user = trim((string)($_POST['user'] ?? 'System'));
        if ($user === '') {
            $user = pos_session_user_name() ?: 'System';
        }

        if ($saleId <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'وەسڵ نادروستە'], JSON_UNESCAPED_UNICODE);
            exit();
        }

        $newItemsIn = json_decode(is_string($itemsRaw) ? $itemsRaw : '[]', true);
        if (!is_array($newItemsIn) || count($newItemsIn) === 0) {
            echo json_encode(['status' => 'error', 'message' => 'سەبەتە بەتاڵە — ناتوانیت وەسڵێ بێ ئایتم پارێزیت'], JSON_UNESCAPED_UNICODE);
            exit();
        }

        $conn->begin_transaction();
        try {
            $st = $conn->prepare('SELECT * FROM sales WHERE id = ? FOR UPDATE');
            if (!$st) {
                throw new Exception('Database error');
            }
            $st->bind_param('i', $saleId);
            $st->execute();
            $row = $st->get_result()->fetch_assoc();
            if (!$row) {
                throw new Exception('وەسڵ نەهاتە دیتن');
            }
            if ((int)($row['is_returned'] ?? 0) === 1) {
                throw new Exception('وەسڵ زڤڕاندنە — دەستکاری ناکرێت');
            }
            if (!pos_session_is_privileged()) {
                $name = pos_session_user_name();
                if (($row['cashier'] ?? '') !== $name) {
                    throw new Exception('دەستگەیشتن قەدەغەیە');
                }
            }

            $oldItems = json_decode((string)($row['items_json'] ?? '[]'), true);
            if (!is_array($oldItems)) {
                $oldItems = [];
            }

            $saleWh = function_exists('pos_sale_row_warehouse_id') ? pos_sale_row_warehouse_id($conn, $row) : pos_resolve_warehouse_id($conn, 0);
            $stockSkipped = false;

            // Net piece delta per product (avoid restore+re-consume FEFO which fails after original sale)
            $oldPiecesByPid = [];
            foreach ($oldItems as $oldItem) {
                if (!is_array($oldItem)) {
                    continue;
                }
                $pid = (int)($oldItem['id'] ?? 0);
                if ($pid <= 0) {
                    continue;
                }
                $pcs = pos_sale_item_pieces($oldItem);
                if ($pcs <= 0.0001) {
                    continue;
                }
                if (!isset($oldPiecesByPid[$pid])) {
                    $oldPiecesByPid[$pid] = 0.0;
                }
                $oldPiecesByPid[$pid] += $pcs;
            }

            // Build normalized new items first (no stock yet)
            $newItems = [];
            $newPiecesByPid = [];
            $giftPiecesByPid = [];
            $prodMetaByPid = [];
            foreach ($newItemsIn as $raw) {
                if (!is_array($raw)) {
                    continue;
                }
                $pid = (int)($raw['id'] ?? 0);
                $qtyRaw = (float)($raw['qty'] ?? ($raw['count'] ?? 0));
                $unitPrice = roundMoney((float)($raw['price'] ?? 0));
                $saleUnit = strtolower(trim((string)($raw['saleUnit'] ?? ($raw['sale_unit'] ?? 'piece'))));
                if (!in_array($saleUnit, ['piece', 'pack', 'carton'], true)) {
                    $saleUnit = 'piece';
                }
                $isGift = !empty($raw['isGift']);
                $isManual = !empty($raw['isManualItem']);
                $name = trim((string)($raw['name'] ?? ''));

                $prod = null;
                if ($pid > 0) {
                    if (isset($prodMetaByPid[$pid])) {
                        $prod = $prodMetaByPid[$pid];
                    } else {
                        $stP = $conn->prepare('SELECT id, name, barcode, price, cost, qty AS prod_qty, trackStock, qty_mode, unitType, unit_show_pack, unit_show_carton, pieces_per_pack, packs_per_carton, itemsPerCarton FROM products WHERE id = ? LIMIT 1');
                        if ($stP) {
                            $stP->bind_param('i', $pid);
                            $stP->execute();
                            $prod = $stP->get_result()->fetch_assoc();
                            if ($prod) {
                                $prodMetaByPid[$pid] = $prod;
                            }
                        }
                    }
                }

                if ($prod) {
                    $qty = normalizeQtyForProductData($prod, $qtyRaw);
                } else {
                    $qty = $qtyRaw;
                }
                if ($qty <= 0 && !$isGift) {
                    throw new Exception('ژمارەیا ئایتم نادروستە: ' . ($name !== '' ? $name : ('#' . $pid)));
                }
                if ($name === '' && $prod) {
                    $name = (string)($prod['name'] ?? '');
                }
                if ($name === '') {
                    $name = 'ئایتم';
                }

                $item = [
                    'id' => $pid > 0 ? $pid : null,
                    'name' => $name,
                    'barcode' => (string)($raw['barcode'] ?? ((is_array($prod) ? ($prod['barcode'] ?? '') : ''))),
                    'qty' => $qty,
                    'count' => $qty,
                    'price' => $unitPrice,
                    'cost' => roundMoney((float)($raw['cost'] ?? ((is_array($prod) ? ($prod['cost'] ?? 0) : 0)))),
                    'saleUnit' => $saleUnit,
                    'pieces_per_pack' => max(1, (int)($raw['pieces_per_pack'] ?? ((is_array($prod) ? ($prod['pieces_per_pack'] ?? 1) : 1)))),
                    'packs_per_carton' => max(1, (int)($raw['packs_per_carton'] ?? ((is_array($prod) ? ($prod['packs_per_carton'] ?? 1) : 1)))),
                    'itemsPerCarton' => max(1, (int)($raw['itemsPerCarton'] ?? ((is_array($prod) ? ($prod['itemsPerCarton'] ?? 1) : 1)))),
                ];
                if ($isGift) {
                    $item['isGift'] = true;
                }
                if ($isManual) {
                    $item['isManualItem'] = true;
                    $item['trackStock'] = false;
                }
                if (isset($raw['bill_unit_usd'])) {
                    $item['bill_unit_usd'] = $raw['bill_unit_usd'];
                }
                if (isset($raw['fx_rate_per_one']) && is_numeric($raw['fx_rate_per_one'])) {
                    $item['fx_rate_per_one'] = (float)$raw['fx_rate_per_one'];
                }
                if (!empty($raw['note'])) {
                    $item['note'] = (string)$raw['note'];
                }

                $newPieces = pos_sale_item_pieces($item);
                /** Gifts still deduct stock (free sale) — keep catalog price for gift-value reports */
                $trackStock = $prod && !empty($prod['trackStock']) && empty($item['isManualItem']);
                if ($trackStock && $pid > 0 && $newPieces > 0.0001) {
                    if (!isset($newPiecesByPid[$pid])) {
                        $newPiecesByPid[$pid] = 0.0;
                    }
                    $newPiecesByPid[$pid] += $newPieces;
                    if ($isGift) {
                        if (!isset($giftPiecesByPid[$pid])) {
                            $giftPiecesByPid[$pid] = 0.0;
                        }
                        $giftPiecesByPid[$pid] += $newPieces;
                    }
                }

                $newItems[] = $item;
            }

            if (count($newItems) === 0) {
                throw new Exception('سەبەتە بەتاڵە');
            }

            if (function_exists('pos_stamp_sale_items_inventory_cogs')) {
                $newItems = pos_stamp_sale_items_inventory_cogs($conn, $newItems, $oldPiecesByPid);
                if (!is_array($newItems)) {
                    $decodedStamp = json_decode((string)$newItems, true);
                    if (is_array($decodedStamp)) {
                        $newItems = $decodedStamp;
                    }
                }
            }

            // Apply net stock deltas only
            $allPids = array_unique(array_merge(array_keys($oldPiecesByPid), array_keys($newPiecesByPid)));
            foreach ($allPids as $pid) {
                $pid = (int)$pid;
                $oldPcs = (float)($oldPiecesByPid[$pid] ?? 0);
                $newPcs = (float)($newPiecesByPid[$pid] ?? 0);
                $delta = round($newPcs - $oldPcs, 4);
                if (abs($delta) < 0.0001) {
                    continue;
                }
                $prod = $prodMetaByPid[$pid] ?? null;
                if (!$prod) {
                    $stP = $conn->prepare('SELECT id, name, barcode, qty AS prod_qty, trackStock FROM products WHERE id = ? LIMIT 1');
                    if ($stP) {
                        $stP->bind_param('i', $pid);
                        $stP->execute();
                        $prod = $stP->get_result()->fetch_assoc();
                    }
                }
                if (!$prod || empty($prod['trackStock'])) {
                    continue;
                }
                    if ($delta > 0.0001) {
                    $avail = (float)($prod['prod_qty'] ?? 0);
                    // Available stock already excludes old sale pieces — adding delta needs room for the increase only
                    if ($avail + 0.0001 < $delta) {
                        $stockSkipped = true;
                        continue;
                    }
                    pos_adjust_tracked_stock($conn, $pid, -$delta, $saleWh);
                    $bc = trim((string)($prod['barcode'] ?? ''));
                    $giftNote = !empty($giftPiecesByPid[$pid]) ? ' · دیاری/بەلاش' : '';
                    insertStockMovement($conn, $pid, $bc, 'sale_edit', -$delta, 0, 0, 'sale', $saleId, date('Y-m-d H:i:s'), $user, 'تەعدیل وەسڵ — زیادکرنا کۆگە #' . $saleId . $giftNote, $saleWh);
                    if (function_exists('consumeStockBatchesFefo')) {
                        try {
                            $txnIdTmp = trim((string)($row['transaction_id'] ?? ''));
                            consumeStockBatchesFefo($conn, $pid, $delta, $txnIdTmp, $saleId, (string)($prod['name'] ?? ''));
                        } catch (Throwable $eFefo) {
                            // Product qty already adjusted; don't fail whole invoice edit on FEFO shortage
                            $stockSkipped = true;
                        }
                    }
                } else {
                    $restore = abs($delta);
                    pos_adjust_tracked_stock($conn, $pid, $restore, $saleWh);
                    $bc = trim((string)($prod['barcode'] ?? ''));
                    insertStockMovement($conn, $pid, $bc, 'sale_edit', $restore, 0, 0, 'sale', $saleId, date('Y-m-d H:i:s'), $user, 'تەعدیل وەسڵ — گەڕاندنا کۆگە #' . $saleId, $saleWh);
                }
            }

            $oldTotal = roundMoney((float)($row['total'] ?? 0));
            $discount = max(0, $discountIn);
            $newSubTotal = pos_sale_items_subtotal($newItems);
            $newTotal = roundMoney(max(0, $newSubTotal - $discount));
            $totalDelta = roundMoney($newTotal - $oldTotal);

            $payMethod = strtolower(trim((string)($row['payment_method'] ?? 'cash')));
            if ($payMethod === '') {
                $payMethod = 'cash';
            }
            $txnId = trim((string)($row['transaction_id'] ?? ''));
            $targetId = (int)($row['customer_id'] ?? 0);
            $targetType = trim((string)($row['customer_type'] ?? 'customer'));
            if ($targetType === 'customers') {
                $targetType = 'customer';
            }

            $splitCols = null;
            if ($payMethod === 'split') {
                $splitCols = pos_sale_scale_split_amounts($row, $newTotal);
            } elseif ($payMethod === 'cash') {
                $splitCols = [
                    'paid_amount' => $newTotal, 'paid_cash' => $newTotal, 'paid_bank' => 0.0,
                    'bank_amount' => 0.0, 'debt_amount' => 0.0, 'remaining_debt' => 0.0, 'received_amount' => $newTotal,
                ];
            } elseif ($payMethod === 'debt') {
                $splitCols = [
                    'paid_amount' => 0.0, 'paid_cash' => 0.0, 'paid_bank' => 0.0,
                    'bank_amount' => 0.0, 'debt_amount' => $newTotal, 'remaining_debt' => $newTotal, 'received_amount' => 0.0,
                ];
            }

            $itemsJson = json_encode(array_values($newItems), JSON_UNESCAPED_UNICODE);
            if ($itemsJson === false) {
                throw new Exception('Invalid items JSON');
            }

            // Preserve created_at — only update items/total/discount/payment breakdown
            if ($splitCols) {
                $stmtUp = $conn->prepare('UPDATE sales SET total = ?, discount = ?, items_json = ?, paid_amount = ?, debt_amount = ?, bank_amount = ?, received_amount = ?, paid_cash = ?, paid_bank = ?, remaining_debt = ? WHERE id = ?');
                if (!$stmtUp) {
                    throw new Exception('Database error');
                }
                $stmtUp->bind_param(
                    'ddsdddddddi',
                    $newTotal,
                    $discount,
                    $itemsJson,
                    $splitCols['paid_amount'],
                    $splitCols['debt_amount'],
                    $splitCols['bank_amount'],
                    $splitCols['received_amount'],
                    $splitCols['paid_cash'],
                    $splitCols['paid_bank'],
                    $splitCols['remaining_debt'],
                    $saleId
                );
            } else {
                $stmtUp = $conn->prepare('UPDATE sales SET total = ?, discount = ?, items_json = ? WHERE id = ?');
                if (!$stmtUp) {
                    throw new Exception('Database error');
                }
                $stmtUp->bind_param('ddsi', $newTotal, $discount, $itemsJson, $saleId);
            }
            $stmtUp->execute();

            $cashLedgerAmt = $newTotal;
            $debtLedgerAmt = 0.0;
            if ($payMethod === 'split' && $splitCols) {
                $cashLedgerAmt = roundMoney((float)$splitCols['paid_cash'] + (float)$splitCols['paid_bank']);
                $debtLedgerAmt = roundMoney((float)$splitCols['remaining_debt']);
            } elseif ($payMethod === 'debt') {
                $cashLedgerAmt = 0.0;
                $debtLedgerAmt = $newTotal;
            }
            if ($txnId !== '' && abs($totalDelta) >= 0.01) {
                if ($cashLedgerAmt > 0 || $payMethod === 'cash' || $payMethod === 'split') {
                    $stLC = $conn->prepare("UPDATE ledger SET amount = ? WHERE transaction_id = ? AND type = 'sale' LIMIT 1");
                    if ($stLC) {
                        $stLC->bind_param('ds', $cashLedgerAmt, $txnId);
                        $stLC->execute();
                    }
                }
                if ($debtLedgerAmt > 0 || $payMethod === 'debt' || $payMethod === 'split') {
                    $stLD = $conn->prepare("UPDATE ledger SET amount = ? WHERE transaction_id = ? AND type = 'sale_credit' LIMIT 1");
                    if ($stLD) {
                        $stLD->bind_param('ds', $debtLedgerAmt, $txnId);
                        $stLD->execute();
                    }
                }
            }

            $customerBalanceOut = null;
            if ($targetId > 0 && abs($totalDelta) >= 0.01) {
                $debtDelta = 0.0;
                if ($payMethod === 'debt') {
                    $debtDelta = $totalDelta;
                } elseif ($payMethod === 'split' && $splitCols) {
                    $oldDebt = roundMoney((float)($row['remaining_debt'] ?? ($row['debt_amount'] ?? 0)));
                    $debtDelta = roundMoney((float)$splitCols['remaining_debt'] - $oldDebt);
                }
                if (abs($debtDelta) >= 0.01) {
                    $balTable = ($targetType === 'user') ? 'users' : 'customers';
                    $stBal = $conn->prepare("UPDATE {$balTable} SET balance = balance + ? WHERE id = ?");
                    if ($stBal) {
                        $stBal->bind_param('di', $debtDelta, $targetId);
                        $stBal->execute();
                    }
                    if ($txnId !== '' && $payMethod === 'debt') {
                        $stClAmt = $conn->prepare("UPDATE customer_ledger SET amount = ? WHERE transaction_id = ? AND type = 'sale' LIMIT 1");
                        if ($stClAmt) {
                            $stClAmt->bind_param('ds', $newTotal, $txnId);
                            $stClAmt->execute();
                        }
                    }
                    $stBalGet = $conn->prepare("SELECT balance FROM {$balTable} WHERE id = ? LIMIT 1");
                    if ($stBalGet) {
                        $stBalGet->bind_param('i', $targetId);
                        $stBalGet->execute();
                        $br = $stBalGet->get_result()->fetch_assoc();
                        if ($br) {
                            $customerBalanceOut = roundMoney((float)($br['balance'] ?? 0));
                        }
                    }
                }
            }

            try {
                $editDiff = pos_build_sale_cart_edit_diff($oldItems, $newItems, $oldTotal, $newTotal, roundMoney((float)($row['discount'] ?? 0)), $discount);
                $changeLines = $editDiff['lines'];
                $detailsText = 'تەعدیل وەسڵ ژ سەبەتێ #' . $saleId . ' | total ' . $oldTotal . '→' . $newTotal;
                if ($stockSkipped) {
                    $detailsText .= ' | stock_skip';
                }
                if (!empty($changeLines)) {
                    $detailsText .= ' | ' . implode(' · ', $changeLines);
                }
                $oldJson = json_encode([
                    'total' => $oldTotal,
                    'discount' => roundMoney((float)($row['discount'] ?? 0)),
                    'items' => $editDiff['old_items'],
                    'changes' => $changeLines,
                ], JSON_UNESCAPED_UNICODE);
                $newJson = json_encode([
                    'total' => $newTotal,
                    'discount' => $discount,
                    'items' => $editDiff['new_items'],
                ], JSON_UNESCAPED_UNICODE);
                logAction($conn, $user, 'sale_cart_replace', $detailsText, null, 'sale', $saleId, $oldJson ?: null, $newJson ?: null);
            } catch (Throwable $e) {
            }

            $conn->commit();
            touchLastUpdate($conn);
            echo json_encode([
                'status' => 'success',
                'id' => $saleId,
                'sale' => pos_fetch_sale_record_by_id($conn, $saleId),
                'sale_total' => $newTotal,
                'created_at' => $row['created_at'] ?? null,
                'customer_balance' => $customerBalanceOut,
                'customer_id' => $targetId,
                'customer_type' => $targetType,
                'stock_skipped' => $stockSkipped,
                'edited' => true,
            ], JSON_UNESCAPED_UNICODE);
            exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
            exit();
        }
    }

    if($act == 'return_supply_to_company') {
        $compRaw = $_POST['company']; 
        $compEscaped = $conn->real_escape_string($compRaw);
        $pid = (int)$_POST['prodId']; 
        $name = $_POST['itemName'];
        $qty = (float)$_POST['qtyAdded']; 
        $cost = roundMoney((float)$_POST['totalCost']); 
        $date = date('Y-m-d H:i:s');
        $txnId = uniqid('TXR');
        
        $conn->begin_transaction();
        try {
            $stmtP = $conn->prepare("SELECT qty, trackStock, qty_mode, unitType, unit_show_pack, unit_show_carton FROM products WHERE id = ?");
            $stmtP->bind_param("i", $pid);
            $stmtP->execute();
            $res = $stmtP->get_result();
            if($res && $p=$res->fetch_assoc()) {
                $qty = normalizeQtyForProductData($p, $qty);
                if ($qty <= 0) throw new Exception("Invalid quantity");
                if($p['trackStock'] && $p['qty'] < $qty) throw new Exception("Stock not sufficient");
                
                $stmt = $conn->prepare("INSERT INTO supplies (company, prodId, itemName, qtyAdded, totalCost, date, type, transaction_id) VALUES (?, ?, ?, ?, ?, ?, 'return', ?)");
                if(!$stmt) throw new Exception($conn->error);
                $negQty = -$qty;
                $stmt->bind_param("sisidss", $compRaw, $pid, $name, $negQty, $cost, $date, $txnId);
                if(!$stmt->execute()) throw new Exception($stmt->error);
                
                if($p['trackStock']) {
                    $stmtStk = $conn->prepare("UPDATE products SET qty = qty - ? WHERE id = ?");
                    $stmtStk->bind_param("di", $qty, $pid);
                    if(!$stmtStk->execute()) throw new Exception($stmtStk->error);
                }
                
                $cost = roundMoney($cost);
                $stmtComp = $conn->prepare("UPDATE companies SET balance = balance - ? WHERE name = ?");
                $stmtComp->bind_param("ds", $cost, $compRaw);
                if(!$stmtComp->execute()) throw new Exception($stmtComp->error);
                
                $stmtC = $conn->prepare("SELECT id FROM companies WHERE name = ?");
                $stmtC->bind_param("s", $compRaw);
                $stmtC->execute();
                $resC = $stmtC->get_result();
                if($resC && $cRow=$resC->fetch_assoc()) {
                    $note = "زڤڕاندن بۆ کۆمپانیا: $name ($qty)";
                    $stmtL = $conn->prepare("INSERT INTO ledger (companyId, type, amount, date, note, transaction_id) VALUES (?, 'return_to_supplier', ?, ?, ?, ?)");
                    if(!$stmtL) throw new Exception($conn->error);
                    $stmtL->bind_param("idsss", $cRow['id'], $cost, $date, $note, $txnId);
                    if(!$stmtL->execute()) throw new Exception($stmtL->error);
                }
                $unitCost = $qty != 0 ? $cost / $qty : 0;
                insertStockMovement($conn, $pid, '', 'supplier_return', -$qty, $unitCost, $cost, 'supply_return', 0, $date, $user ?? 'System', $compRaw);
                $conn->commit();
                echo json_encode(["status"=>"success"]); exit();
            } else throw new Exception("Product not found");
        } catch (Exception $e) { $conn->rollback(); echo json_encode(["status"=>"error", "message" => $e->getMessage()]); exit(); }
    }

    if ($act === 'mark_sale_followup') {
        header('Content-Type: application/json; charset=utf-8');
        if (function_exists('pos_ensure_sale_followup_schema')) {
            pos_ensure_sale_followup_schema($conn);
        }
        $saleId = (int)($_POST['sale_id'] ?? 0);
        $stepKey = preg_replace('/[^0-9mhd]/', '', strtolower((string)($_POST['step_key'] ?? '')));
        if ($saleId <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'sale_id required'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        if ($stepKey === '') {
            $stepKey = '10d';
        }
        $now = date('Y-m-d H:i:s');
        $ids = [$saleId];
        $extra = $_POST['sale_ids'] ?? '';
        if (is_string($extra) && $extra !== '') {
            foreach (explode(',', $extra) as $one) {
                $n = (int)$one;
                if ($n > 0) {
                    $ids[] = $n;
                }
            }
        }
        $ids = array_values(array_unique($ids));
        $stIns = $conn->prepare('INSERT IGNORE INTO sale_followup_sends (sale_id, step_key, sent_at) VALUES (?, ?, ?)');
        if ($stIns) {
            foreach ($ids as $sid) {
                $stIns->bind_param('iss', $sid, $stepKey, $now);
                $stIns->execute();
            }
        }
        $settings = function_exists('pos_followup_load_app_settings') ? pos_followup_load_app_settings($conn) : [];
        $schedule = function_exists('pos_parse_followup_schedule') ? pos_parse_followup_schedule($settings) : [];
        $stepCount = max(1, count($schedule));
        foreach ($ids as $sid) {
            $cnt = 0;
            $stC = $conn->prepare('SELECT COUNT(*) AS n FROM sale_followup_sends WHERE sale_id = ?');
            if ($stC) {
                $stC->bind_param('i', $sid);
                if ($stC->execute()) {
                    $cr = $stC->get_result();
                    if ($cr && ($crow = $cr->fetch_assoc())) {
                        $cnt = (int)$crow['n'];
                    }
                }
            }
            if ($cnt >= $stepCount) {
                $stDone = $conn->prepare('UPDATE sales SET followup_sent_at = ? WHERE id = ? AND followup_sent_at IS NULL');
                if ($stDone) {
                    $stDone->bind_param('si', $now, $sid);
                    $stDone->execute();
                }
            }
        }
        echo json_encode(['status' => 'success', 'sale_id' => $saleId, 'step_key' => $stepKey], JSON_UNESCAPED_UNICODE);
        exit();
    }
