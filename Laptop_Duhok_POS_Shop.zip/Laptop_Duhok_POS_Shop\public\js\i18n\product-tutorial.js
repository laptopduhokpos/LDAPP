/**
 * Product add-item spotlight tutorial — فێرکردنا زێدەکرنا ئایتمان.
 * Overlay mounts on document.body (fixes zoom/transform clipping inside #app-zoom-inner).
 */
(function () {
    'use strict';

    var EAST_DIGITS = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];

    var STEPS = [
        { target: '#p-name', titleKey: 'product_tutorial_step1_title', hintKey: 'product_tutorial_step1_hint', advance: 'input' },
        { target: '#p-barcode', titleKey: 'product_tutorial_step2_title', hintKey: 'product_tutorial_step2_hint', advance: 'input' },
        { target: '#layout-category-btns', titleKey: 'product_tutorial_step3_title', hintKey: 'product_tutorial_step3_hint', advance: 'category' },
        { mode: 'visual', visual: 'units', target: '#p-add-unit-levels-row', titleKey: 'product_tutorial_step4_title', hintKey: 'product_tutorial_step4_hint', advance: 'manual' },
        { target: '#p-add-unit-levels-row', titleKey: 'product_tutorial_step5_title', hintKey: 'product_tutorial_step5_hint', advance: 'unit-levels' },
        { conv: 'ppp', titleKey: 'product_tutorial_step6_title', hintKey: 'product_tutorial_step6_hint', advance: 'input' },
        { conv: 'ppc', titleKey: 'product_tutorial_step7_title', hintKey: 'product_tutorial_step7_hint', advance: 'input', skipIfHidden: true },
        { target: '#p-ml-row-piece', visual: 'piece', titleKey: 'product_tutorial_step8_title', hintKey: 'product_tutorial_step8_hint', advance: 'row-piece' },
        { target: '#p-ml-row-pack', visual: 'pack', titleKey: 'product_tutorial_step9_title', hintKey: 'product_tutorial_step9_hint', advance: 'row-pack' },
        { target: '#p-ml-row-carton', visual: 'carton', titleKey: 'product_tutorial_step10_title', hintKey: 'product_tutorial_step10_hint', advance: 'row-carton' },
        { target: '.product-form-expiry-block', titleKey: 'product_tutorial_step11_title', hintKey: 'product_tutorial_step11_hint', advance: 'expiry' },
        { target: '#btn-save-prod-step1', titleKey: 'product_tutorial_step12_title', hintKey: 'product_tutorial_step12_hint', advance: 'save' }
    ];

    var state = {
        active: false,
        stepIndex: 0,
        overlay: null,
        mountAnchor: null,
        ring: null,
        tooltip: null,
        visual: null,
        visualCaption: null,
        badge: null,
        progressEl: null,
        titleEl: null,
        hintEl: null,
        successEl: null,
        resizeObs: null,
        scrollParents: [],
        onScroll: null,
        onKey: null,
        advanceHandler: null,
        unitLevelsDone: { pack: false, carton: false }
    };

    function t(key, fallback) {
        if (typeof window.t === 'function') {
            var v = window.t(key);
            if (v && v !== key) return v;
        }
        return fallback || key;
    }

    function qs(sel, root) {
        return (root || document).querySelector(sel);
    }

    function toBadgeNum(n) {
        return String(n).split('').map(function (c) { return EAST_DIGITS[+c]; }).join('');
    }

    function isVisible(el) {
        if (!el || !el.getBoundingClientRect) return false;
        var r = el.getBoundingClientRect();
        if (r.width < 1 || r.height < 1) return false;
        var st = window.getComputedStyle(el);
        if (st.display === 'none' || st.visibility === 'hidden' || st.opacity === '0') return false;
        return true;
    }

    function prepUnitLevels() {
        if (typeof window.productFormAddPackLevel === 'function') window.productFormAddPackLevel();
        if (typeof window.productFormAddCartonLevel === 'function') window.productFormAddCartonLevel();
        state.unitLevelsDone.pack = true;
        state.unitLevelsDone.carton = true;
    }

    function resolveConvField(kind) {
        var two = qs('#conversion-two-fields');
        if (two && isVisible(two)) {
            var el = kind === 'ppp' ? qs('#p-pieces-per-pack') : qs('#p-packs-per-carton');
            return el && isVisible(el) ? el : null;
        }
        if (kind === 'ppp') {
            var solo = qs('#conv-wrap-carton-only');
            if (solo && isVisible(solo)) {
                var o = qs('#p-pieces-per-carton-only');
                return o && isVisible(o) ? o : null;
            }
            var single = qs('#conversion-one-field');
            if (single && isVisible(single)) {
                var s = qs('#p-pieces-per-carton-single');
                return s && isVisible(s) ? s : null;
            }
            var ppp = qs('#p-pieces-per-pack');
            return ppp && isVisible(ppp) ? ppp : null;
        }
        var ppc = qs('#p-packs-per-carton');
        return ppc && isVisible(ppc) ? ppc : null;
    }

    function resolveTarget(step) {
        if (step.conv) return resolveConvField(step.conv);
        if (!step.target) return null;
        var el = qs(step.target);
        if (!el) return null;
        if (step.target === '#btn-save-prod-step1') {
            if (isVisible(el)) return el;
            var alt = qs('#btn-save-prod');
            return alt && isVisible(alt) ? alt : el;
        }
        if (step.target === '#p-ml-row-pack' || step.target === '#p-ml-row-carton') {
            prepUnitLevels();
            return isVisible(el) ? el : el;
        }
        return isVisible(el) ? el : el;
    }

    function getVisualPanelWidth() {
        if (!state.visual || !state.visual.classList.contains('is-active')) return 0;
        var r = state.visual.getBoundingClientRect();
        return r.width > 0 ? r.right + 12 : 0;
    }

    function getScrollParents(el) {
        var list = [];
        var node = el && el.parentElement;
        while (node && node !== document.body) {
            var st = window.getComputedStyle(node);
            if (/(auto|scroll|overlay)/.test(st.overflow + st.overflowY + st.overflowX)) {
                list.push(node);
            }
            node = node.parentElement;
        }
        return list;
    }

    function mountOverlayOnBody() {
        if (!state.overlay || state.mountAnchor) return;
        var parent = state.overlay.parentNode;
        if (!parent) return;
        state.mountAnchor = document.createComment('pos-product-tutorial-mount');
        parent.insertBefore(state.mountAnchor, state.overlay);
        document.body.appendChild(state.overlay);
    }

    function unmountOverlayFromBody() {
        if (!state.overlay || !state.mountAnchor || !state.mountAnchor.parentNode) return;
        state.mountAnchor.parentNode.insertBefore(state.overlay, state.mountAnchor.nextSibling);
        state.mountAnchor.parentNode.removeChild(state.mountAnchor);
        state.mountAnchor = null;
    }

    function setVisualPanel(step) {
        if (!state.visual) return;
        var show = step && (step.mode === 'visual' || step.visual);
        if (!show) {
            state.visual.hidden = true;
            state.visual.setAttribute('aria-hidden', 'true');
            state.visual.classList.remove('is-active');
            if (state.overlay) state.overlay.classList.remove('pos-spotlight-tutorial--with-visual');
            return;
        }
        state.visual.hidden = false;
        state.visual.setAttribute('aria-hidden', 'false');
        state.visual.classList.add('is-active');
        if (state.overlay) state.overlay.classList.add('pos-spotlight-tutorial--with-visual');

        state.visual.querySelectorAll('.pos-tutorial-visual-card').forEach(function (card) {
            card.classList.remove('is-highlight');
        });
        var unit = step.visual || 'units';
        if (unit === 'units') {
            state.visual.querySelectorAll('.pos-tutorial-visual-card').forEach(function (c) {
                c.classList.add('is-highlight');
            });
        } else {
            var card = state.visual.querySelector('.pos-tutorial-visual-card[data-unit="' + unit + '"]');
            if (card) card.classList.add('is-highlight');
        }

        if (state.visualCaption) {
            var capKey = step.visual === 'piece' ? 'product_tutorial_visual_caption_piece'
                : step.visual === 'pack' ? 'product_tutorial_visual_caption_pack'
                : step.visual === 'carton' ? 'product_tutorial_visual_caption_carton'
                : 'product_tutorial_visual_caption_units';
            state.visualCaption.textContent = t(capKey, '');
        }
    }

    function positionSpotlight(target, step) {
        if (!state.overlay) return;

        var visualReserve = getVisualPanelWidth();

        if (step && step.mode === 'visual' && target && isVisible(target)) {
            if (state.ring) state.ring.style.display = '';
            state.overlay.querySelectorAll('.pos-spotlight-dim').forEach(function (d) {
                d.style.display = '';
            });
            positionSpotlightRect(target.getBoundingClientRect(), visualReserve, 10);
            if (state.tooltip) {
                var tr = target.getBoundingClientRect();
                placeTooltipNear(tr.bottom, tr.left, tr.right, visualReserve);
            }
            return;
        }

        if (step && step.mode === 'visual' && !target) {
            if (state.ring) state.ring.style.display = 'none';
            state.overlay.querySelectorAll('.pos-spotlight-dim').forEach(function (d) {
                d.style.display = 'none';
            });
            document.querySelectorAll('.pos-spotlight-target').forEach(function (n) {
                n.classList.remove('pos-spotlight-target');
            });
            if (state.tooltip) {
                state.tooltip.style.top = '50%';
                state.tooltip.style.left = 'auto';
                state.tooltip.style.right = Math.max(16, visualReserve) + 'px';
                state.tooltip.style.transform = 'translateY(-50%)';
            }
            return;
        }

        if (!target) return;

        if (state.ring) state.ring.style.display = '';
        state.overlay.querySelectorAll('.pos-spotlight-dim').forEach(function (d) {
            d.style.display = '';
        });

        positionSpotlightRect(target.getBoundingClientRect(), visualReserve, 8);
        target.classList.add('pos-spotlight-target');
        document.querySelectorAll('.pos-spotlight-target').forEach(function (n) {
            if (n !== target) n.classList.remove('pos-spotlight-target');
        });

        var rect = target.getBoundingClientRect();
        placeTooltipNear(rect.bottom, rect.left, rect.right, visualReserve);

        try {
            target.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'smooth' });
        } catch (_e) {}
    }

    function positionSpotlightRect(rect, visualReserve, pad) {
        pad = pad || 8;
        var top = Math.max(0, rect.top - pad);
        var left = Math.max(0, rect.left - pad);
        var right = Math.min(window.innerWidth, rect.right + pad);
        var bottom = Math.min(window.innerHeight, rect.bottom + pad);
        var holeW = Math.max(0, right - left);
        var holeH = Math.max(0, bottom - top);

        state.overlay.querySelectorAll('.pos-spotlight-dim').forEach(function (dim) {
            dim.style.display = '';
        });

        var dimTop = state.overlay.querySelector('[data-dim="top"]');
        var dimLeft = state.overlay.querySelector('[data-dim="left"]');
        var dimRight = state.overlay.querySelector('[data-dim="right"]');
        var dimBottom = state.overlay.querySelector('[data-dim="bottom"]');

        if (dimTop) {
            dimTop.style.top = '0';
            dimTop.style.left = '0';
            dimTop.style.width = '100%';
            dimTop.style.height = top + 'px';
        }
        if (dimLeft) {
            dimLeft.style.top = top + 'px';
            dimLeft.style.height = holeH + 'px';
            if (visualReserve > 0 && left > visualReserve) {
                dimLeft.style.left = visualReserve + 'px';
                dimLeft.style.width = Math.max(0, left - visualReserve) + 'px';
            } else if (visualReserve > 0 && left <= visualReserve) {
                dimLeft.style.display = 'none';
            } else {
                dimLeft.style.left = '0';
                dimLeft.style.width = left + 'px';
            }
        }
        if (dimRight) {
            dimRight.style.top = top + 'px';
            dimRight.style.left = right + 'px';
            dimRight.style.width = Math.max(0, window.innerWidth - right) + 'px';
            dimRight.style.height = holeH + 'px';
        }
        if (dimBottom) {
            dimBottom.style.top = bottom + 'px';
            dimBottom.style.left = '0';
            dimBottom.style.width = '100%';
            dimBottom.style.height = Math.max(0, window.innerHeight - bottom) + 'px';
        }

        if (state.ring) {
            state.ring.style.top = top + 'px';
            state.ring.style.left = left + 'px';
            state.ring.style.width = holeW + 'px';
            state.ring.style.height = holeH + 'px';
        }
    }

    function placeTooltipNear(bottom, left, right, visualReserve) {
        if (!state.tooltip) return;
        state.tooltip.style.transform = '';
        var tt = state.tooltip;
        var ttRect = tt.getBoundingClientRect();
        var preferBelow = bottom + ttRect.height + 16 < window.innerHeight;
        var ty = preferBelow ? bottom + 12 : Math.max(12, bottom - ttRect.height - 80);
        var minX = Math.max(12, visualReserve + 8);
        var tx = Math.min(Math.max(minX, left), window.innerWidth - ttRect.width - 12);
        tt.style.top = ty + 'px';
        tt.style.left = tx + 'px';
        tt.style.right = 'auto';
    }

    function detachAdvance() {
        if (state.advanceHandler) {
            document.removeEventListener('input', state.advanceHandler, true);
            document.removeEventListener('change', state.advanceHandler, true);
            document.removeEventListener('click', state.advanceHandler, true);
            state.advanceHandler = null;
        }
    }

    function rowHasInput(row) {
        if (!row) return false;
        var inputs = row.querySelectorAll('input[type="text"], input[type="number"]');
        for (var i = 0; i < inputs.length; i++) {
            if (String(inputs[i].value || '').trim().length > 0) return true;
        }
        return false;
    }

    function updateProgress(index) {
        if (state.badge) state.badge.textContent = toBadgeNum(index + 1);
        if (state.progressEl) {
            state.progressEl.textContent = toBadgeNum(index + 1) + ' / ' + toBadgeNum(STEPS.length);
        }
    }

    function goToStep(index) {
        if (!state.active) return;
        detachAdvance();

        if (index >= STEPS.length) {
            showSuccess();
            return;
        }

        state.stepIndex = index;
        var step = STEPS[index];

        if (step.skipIfHidden) {
            var probe = resolveTarget(step);
            if (!probe || (step.conv && !isVisible(probe))) {
                goToStep(index + 1);
                return;
            }
        }

        if (step.conv || step.target === '#p-ml-row-pack' || step.target === '#p-ml-row-carton') {
            prepUnitLevels();
        }

        var target = null;
        if (step.mode === 'visual') {
            target = resolveTarget(step);
            if (!target || !isVisible(target)) target = qs('#layout-step1-unit-levels') || qs('#stock-cost-section');
        } else if (step.mode !== 'visual') {
            target = resolveTarget(step);
        }

        if (!target && step.mode !== 'visual') {
            goToStep(index + 1);
            return;
        }

        if (step.advance === 'unit-levels') {
            var packOn = typeof window.productFormIsPackRowVisible === 'function' && window.productFormIsPackRowVisible();
            var cartonOn = typeof window.productFormIsCartonRowVisible === 'function' && window.productFormIsCartonRowVisible();
            if (packOn) state.unitLevelsDone.pack = true;
            if (cartonOn) state.unitLevelsDone.carton = true;
            if (state.unitLevelsDone.pack && state.unitLevelsDone.carton) {
                prepUnitLevels();
            }
        }

        updateProgress(index);
        if (state.titleEl) state.titleEl.textContent = t(step.titleKey, '');
        if (state.hintEl) state.hintEl.textContent = t(step.hintKey, '');

        setVisualPanel(step);
        requestAnimationFrame(function () {
            if (!state.active) return;
            positionSpotlight(target, step);
        });

        var stepIdx = index;
        state.advanceHandler = function (ev) {
            if (!state.active || state.stepIndex !== stepIdx) return;
            var cur = step.mode === 'visual' ? target : resolveTarget(step);

            if (step.advance === 'input') {
                if (ev.type === 'input' && cur && (ev.target === cur || (cur.contains && cur.contains(ev.target)))) {
                    if (String(cur.value || '').trim().length > 0) {
                        setTimeout(function () { goToStep(stepIdx + 1); }, 260);
                    }
                }
            } else if (step.advance === 'category') {
                if (ev.type === 'click') {
                    var pill = ev.target && ev.target.closest ? ev.target.closest('#p-cat-pills .product-cat-pill, #p-cat-pills button') : null;
                    var addBtn = ev.target && ev.target.closest ? ev.target.closest('#layout-category-btns .btn-info') : null;
                    if (pill || addBtn) setTimeout(function () { goToStep(stepIdx + 1); }, 300);
                }
            } else if (step.advance === 'unit-levels') {
                if (ev.type === 'click') {
                    if (ev.target && ev.target.closest && ev.target.closest('#btn-unit-pack-toggle')) {
                        setTimeout(function () {
                            var btn = document.getElementById('btn-unit-pack-toggle');
                            if (btn && btn.classList.contains('is-on')) state.unitLevelsDone.pack = true;
                        }, 40);
                    }
                    if (ev.target && ev.target.closest && ev.target.closest('#btn-unit-carton-toggle')) {
                        setTimeout(function () {
                            var btn = document.getElementById('btn-unit-carton-toggle');
                            if (btn && btn.classList.contains('is-on')) state.unitLevelsDone.carton = true;
                        }, 40);
                    }
                    if (state.unitLevelsDone.pack && state.unitLevelsDone.carton) {
                        prepUnitLevels();
                        setTimeout(function () { goToStep(stepIdx + 1); }, 320);
                    }
                }
            } else if (step.advance === 'row-piece' || step.advance === 'row-pack' || step.advance === 'row-carton') {
                if (ev.type === 'input' && cur && cur.contains && cur.contains(ev.target) && rowHasInput(cur)) {
                    setTimeout(function () { goToStep(stepIdx + 1); }, 320);
                }
            } else if (step.advance === 'expiry') {
                if (ev.type === 'input' && ev.target && ev.target.id === 'p-expiry') {
                    if (String(ev.target.value || '').trim().length >= 8) {
                        setTimeout(function () { goToStep(stepIdx + 1); }, 260);
                    }
                }
            } else if (step.advance === 'save') {
                if (ev.type === 'click' && cur && (ev.target === cur || (cur.contains && cur.contains(ev.target)))) {
                    setTimeout(function () { goToStep(stepIdx + 1); }, 380);
                }
            }
        };

        if (step.advance === 'input' || step.advance === 'row-piece' || step.advance === 'row-pack' || step.advance === 'row-carton' || step.advance === 'expiry') {
            document.addEventListener('input', state.advanceHandler, true);
        }
        if (step.advance === 'category' || step.advance === 'unit-levels' || step.advance === 'save') {
            document.addEventListener('click', state.advanceHandler, true);
        }

        setTimeout(function () {
            if (!state.active) return;
            if (step.advance === 'unit-levels' && state.unitLevelsDone.pack && state.unitLevelsDone.carton) {
                return;
            }
            if (target && target.focus && step.advance !== 'unit-levels' && step.advance !== 'save') {
                try { target.focus({ preventScroll: true }); } catch (_f) {}
            }
        }, 400);
    }

    function showSuccess() {
        detachAdvance();
        document.querySelectorAll('.pos-spotlight-target').forEach(function (n) {
            n.classList.remove('pos-spotlight-target');
        });
        if (state.tooltip) state.tooltip.style.display = 'none';
        if (state.ring) state.ring.style.display = 'none';
        if (state.visual) {
            state.visual.hidden = true;
            state.visual.classList.remove('is-active');
        }
        if (state.overlay) state.overlay.classList.remove('pos-spotlight-tutorial--with-visual');
        state.overlay.querySelectorAll('.pos-spotlight-dim').forEach(function (d) {
            d.style.display = 'none';
        });
        if (state.successEl) {
            state.successEl.style.display = 'flex';
            if (typeof window.applyI18nSubtree === 'function') window.applyI18nSubtree(state.successEl);
        }
    }

    function bindResize() {
        state.onScroll = function () {
            if (!state.active) return;
            var step = STEPS[state.stepIndex];
            if (!step) return;
            var target = step.mode === 'visual' ? resolveTarget(step) : resolveTarget(step);
            positionSpotlight(target, step);
        };
        window.addEventListener('resize', state.onScroll, { passive: true });
        window.addEventListener('scroll', state.onScroll, true);
        state.scrollParents = [];
        var card = qs('#product-form-card');
        if (card) {
            state.scrollParents = getScrollParents(card);
            state.scrollParents.forEach(function (p) {
                p.addEventListener('scroll', state.onScroll, { passive: true });
            });
        }
        if (typeof ResizeObserver !== 'undefined') {
            state.resizeObs = new ResizeObserver(state.onScroll);
            var form = qs('#product-form-card');
            if (form) state.resizeObs.observe(form);
            if (state.visual) state.resizeObs.observe(state.visual);
        }
    }

    function unbindResize() {
        if (state.onScroll) {
            window.removeEventListener('resize', state.onScroll);
            window.removeEventListener('scroll', state.onScroll, true);
            state.scrollParents.forEach(function (p) {
                p.removeEventListener('scroll', state.onScroll);
            });
            state.onScroll = null;
        }
        if (state.resizeObs) {
            state.resizeObs.disconnect();
            state.resizeObs = null;
        }
    }

    function closeTutorial() {
        state.active = false;
        detachAdvance();
        unbindResize();
        document.querySelectorAll('.pos-spotlight-target').forEach(function (n) {
            n.classList.remove('pos-spotlight-target');
        });
        if (state.overlay) {
            state.overlay.style.display = 'none';
            state.overlay.hidden = true;
            state.overlay.setAttribute('aria-hidden', 'true');
            state.overlay.classList.remove('pos-spotlight-tutorial--with-visual');
        }
        unmountOverlayFromBody();
        if (state.visual) {
            state.visual.hidden = true;
            state.visual.classList.remove('is-active');
        }
        if (state.tooltip) {
            state.tooltip.style.display = '';
            state.tooltip.style.transform = '';
        }
        if (state.ring) state.ring.style.display = '';
        if (state.successEl) state.successEl.style.display = 'none';
        if (state.overlay) {
            state.overlay.querySelectorAll('.pos-spotlight-dim').forEach(function (d) {
                d.style.display = '';
            });
        }
        if (state.onKey) {
            document.removeEventListener('keydown', state.onKey);
            state.onKey = null;
        }
        state.unitLevelsDone = { pack: false, carton: false };
    }

    function ensureProductsView(cb) {
        var view = qs('#view-products');
        if (!view) return false;
        if (!view.classList.contains('active') && typeof window.nav === 'function') {
            window.nav('products');
        }
        if (typeof window.productFormGoToStep === 'function') {
            window.productFormGoToStep(1);
        }
        setTimeout(cb, 120);
        return true;
    }

    function wireControls() {
        var skipBtn = qs('#pos-product-tutorial-skip');
        var nextBtn = qs('#pos-product-tutorial-next');
        var closeBtn = qs('#pos-product-tutorial-close');
        if (skipBtn && !skipBtn._wired) {
            skipBtn._wired = true;
            skipBtn.addEventListener('click', function (e) {
                e.preventDefault();
                e.stopPropagation();
                closeTutorial();
            });
        }
        if (nextBtn && !nextBtn._wired) {
            nextBtn._wired = true;
            nextBtn.addEventListener('click', function (e) {
                e.preventDefault();
                e.stopPropagation();
                if (!state.active) return;
                goToStep(state.stepIndex + 1);
            });
        }
        if (closeBtn && !closeBtn._wired) {
            closeBtn._wired = true;
            closeBtn.addEventListener('click', function (e) {
                e.preventDefault();
                closeTutorial();
            });
        }
    }

    function posProductTutorialStart() {
        if (!ensureProductsView(function () { posProductTutorialStartCore(); })) return;
    }

    function posProductTutorialStartCore() {
        state.overlay = qs('#pos-product-tutorial-overlay');
        if (!state.overlay) return;

        wireControls();
        mountOverlayOnBody();

        state.ring = qs('#pos-product-tutorial-ring');
        state.tooltip = qs('#pos-product-tutorial-tooltip');
        state.visual = qs('#pos-product-tutorial-visual');
        state.visualCaption = qs('#pos-product-tutorial-visual-caption');
        state.badge = qs('#pos-product-tutorial-badge');
        state.progressEl = qs('#pos-product-tutorial-progress');
        state.titleEl = qs('#pos-product-tutorial-title');
        state.hintEl = qs('#pos-product-tutorial-hint');
        state.successEl = qs('#pos-product-tutorial-success');
        state.unitLevelsDone = { pack: false, carton: false };

        state.active = true;
        state.overlay.hidden = false;
        state.overlay.style.display = 'block';
        state.overlay.setAttribute('aria-hidden', 'false');
        if (state.successEl) state.successEl.style.display = 'none';
        if (state.tooltip) state.tooltip.style.display = 'flex';

        if (typeof window.applyI18nSubtree === 'function') {
            window.applyI18nSubtree(state.overlay);
        }

        bindResize();

        state.onKey = function (ev) {
            if (!state.active) return;
            if (ev.key === 'Escape') closeTutorial();
        };
        document.addEventListener('keydown', state.onKey);

        goToStep(0);
    }

    window.posProductTutorialStart = posProductTutorialStart;
    window.posProductTutorialClose = closeTutorial;
})();
