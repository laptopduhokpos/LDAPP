    <!-- MAIN CONTENT + RIGHT SIDEBAR -->
    <div id="app-content-wrap" class="app-content-wrap">
    <div id="app-boot-loader" class="app-boot-loader" role="status" aria-live="polite" aria-busy="true">
        <div class="app-boot-loader__bg" aria-hidden="true"></div>
        <div class="app-boot-loader__card">
            <div class="app-boot-loader__logo-wrap">
                <div class="app-boot-loader__logo-glow" aria-hidden="true"></div>
                <img class="app-boot-loader__logo" src="<?php echo htmlspecialchars($pos_default_logo_url, ENT_QUOTES, 'UTF-8'); ?>" alt="" onerror="this.style.display='none'; this.nextElementSibling.classList.add('is-visible');">
                <i class="fas fa-cash-register app-boot-loader__logo-fallback" aria-hidden="true"></i>
            </div>
            <div class="app-boot-loader__spinner" aria-hidden="true"></div>
            <p class="app-boot-loader__title">Laptop Duhok POS</p>
            <p class="app-boot-loader__text" data-i18n="app_boot_loading">بارکرنا سیستەم...</p>
            <p class="app-boot-loader__sub" data-i18n="app_boot_sub">هیڤییە چاڤەڕێ بە</p>
        </div>
    </div>
    <div class="main-content">
        <div id="connection-warning">🔴 پەیوەندیا فایلی پچڕیا! هیڤیە Refresh بکە و فایلی هەڵبژێرە.</div>
        <div id="lan-localhost-warn" role="alert" style="display:none; margin:8px 12px 0; padding:10px 14px; border-radius:10px; background:#fef2f2; color:#991b1b; border:1px solid #fecaca; font-weight:700; text-align:center;"></div>

        <!-- TOP HEADER BAR: End Shift (left) + Breadcrumb (<span data-i18n="breadcrumb">ڕێڕەو</span>) -->
        <div id="top-header-bar" class="top-header-bar no-print">
            <div class="top-header-end-shift-wrap">
                <button type="button" class="btn btn-danger btn-icon-only btn-end-shift" title="ب دوماهی ئینانا دەوامی (End Shift)" onclick="if(typeof endShift==='function') endShift();"><i class="fas fa-power-off"></i></button>
            </div>
            <div id="breadcrumb-bar" class="breadcrumb-bar-inner" title="دۆخێ دەستکاریێ: کلیک بکە بۆ چوونەژوور و هەلبژارتنا بەشێن ڤەشارتی (Edit mode)"></div>
            <div class="top-header-brand" aria-label="System brand">
                <img id="top-header-logo" class="top-header-logo" src="<?php echo htmlspecialchars($pos_default_logo_url, ENT_QUOTES, 'UTF-8'); ?>" alt="Laptop Duhok Logo" onerror="this.style.display='none';">
                <span class="top-header-brand-text">Laptop Duhok POS <span class="pos-header-version" data-pos-app-version style="opacity:0.85;font-weight:600;font-size:0.85em;">v<?php echo htmlspecialchars(POS_APP_VERSION, ENT_QUOTES, 'UTF-8'); ?></span></span>
                <span id="top-header-tier-badge" class="top-header-tier-badge" style="display:none;" aria-hidden="true"><i class="fas fa-crown"></i> <span id="top-header-tier-label"></span></span>
                <span id="lan-terminal-badge" style="display:none; align-items:center; gap:6px; margin-inline-start:8px; padding:3px 9px; border-radius:999px; background:#ecfdf5; color:#047857; font-size:0.78rem; font-weight:700; white-space:nowrap;"><i class="fas fa-network-wired" aria-hidden="true"></i> فرعی</span>
                <!-- LIVE USB SYNC INDICATOR -->
                <div id="top-header-usb-status" class="top-header-usb-status" title="بارودۆخێ فلاش (USB Backup)" onclick="if(typeof openDbManageModal==='function')openDbManageModal();">
                    <i class="fab fa-usb usb-icon" aria-hidden="true"></i>
                    <span id="top-header-usb-text" class="usb-text">فلاش</span>
                    <div class="usb-pulse" aria-hidden="true"></div>
                </div>
            </div>
        </div>

