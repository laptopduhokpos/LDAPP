/**
 * Laptop / phone spec fields — parse from a dumped item name and print neatly on labels.
 * Grocery products with no CPU:/RAM: stay unchanged.
 */
(function () {
    var KEYS = ['cpu', 'ram', 'storage', 'gpu', 'screen', 'summary', 'extra'];
    var LABEL_ALIASES = {
        CPU: 'cpu',
        PROCESSOR: 'cpu',
        RAM: 'ram',
        MEMORY: 'ram',
        GPU: 'gpu',
        VGA: 'gpu',
        SIZE: 'screen',
        SCREEN: 'screen',
        DISPLAY: 'screen',
        SSD: 'storage',
        HDD: 'storage',
        STORAGE: 'storage',
        ROM: 'storage',
        BATTERY: 'extra',
        CAMERA: 'extra',
        CAM: 'extra'
    };

    function clip(s, n) {
        s = String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
        if (!s) return '';
        if (s.length > n) s = s.slice(0, n).trim();
        return s;
    }

    function emptySpecs() {
        return { cpu: '', ram: '', storage: '', gpu: '', screen: '', summary: '', extra: '', title: '' };
    }

    function normalizeTechSpecs(raw) {
        var out = emptySpecs();
        if (!raw) return out;
        var obj = raw;
        if (typeof raw === 'string') {
            var t = raw.trim();
            if (!t) return out;
            if (t.charAt(0) === '{') {
                try { obj = JSON.parse(t); } catch (e) { return out; }
            } else {
                return parseTechSpecsFromText(t);
            }
        }
        if (typeof obj !== 'object' || !obj) return out;
        KEYS.forEach(function (k) {
            if (obj[k] != null) out[k] = clip(obj[k], 160);
        });
        if (obj.title != null) out.title = clip(obj.title, 160);
        return out;
    }

    function techSpecsHasContent(specs) {
        if (!specs) return false;
        return !!(specs.cpu || specs.ram || specs.storage || specs.gpu || specs.screen || specs.summary || specs.extra);
    }

    function splitHeadTitleSummary(head) {
        head = clip(head, 240);
        if (!head) return { title: '', summary: '' };
        if (head.indexOf('|') < 0) return { title: head, summary: '' };
        var words = head.split(' ');
        var firstPipe = -1;
        for (var i = 0; i < words.length; i++) {
            if (words[i].indexOf('|') >= 0) {
                firstPipe = i;
                break;
            }
        }
        if (firstPipe < 0) return { title: head, summary: '' };
        if (firstPipe > 0 && /^\d+TH$/i.test(words[firstPipe - 1])) firstPipe -= 1;
        return {
            title: words.slice(0, firstPipe).join(' ').trim(),
            summary: words.slice(firstPipe).join(' ').trim()
        };
    }

    function splitRamStorage(ram) {
        ram = clip(ram, 160);
        if (!ram) return { ram: '', storage: '' };
        if (!/\b(SSD|HDD|NVME|STORAGE|ROM)\b/i.test(ram)) return { ram: ram, storage: '' };
        var parts = ram.split(/\s*[-–—]\s+/);
        if (parts.length >= 2) {
            var left = parts[0].trim();
            var right = parts.slice(1).join(' - ').trim();
            if (left && right) return { ram: left, storage: right };
        }
        return { ram: ram, storage: '' };
    }

    function parseTechSpecsFromText(text) {
        var out = emptySpecs();
        var s = String(text || '').replace(/\s+/g, ' ').trim();
        if (!s) return out;
        var labelRe = /\b(CPU|PROCESSOR|RAM|MEMORY|GPU|VGA|SIZE|SCREEN|DISPLAY|SSD|HDD|STORAGE|ROM|BATTERY|CAMERA|CAM)\s*[:：]\s*/ig;
        var hits = [];
        var m;
        while ((m = labelRe.exec(s)) !== null) {
            hits.push({
                alias: String(m[1] || '').toUpperCase(),
                start: m.index,
                valueStart: m.index + m[0].length
            });
        }
        if (!hits.length) {
            out.title = clip(s, 160);
            return out;
        }
        for (var i = 0; i < hits.length; i++) {
            var end = (i + 1 < hits.length) ? hits[i + 1].start : s.length;
            var val = clip(s.slice(hits[i].valueStart, end), 160);
            var dest = LABEL_ALIASES[hits[i].alias];
            if (!dest || !val) continue;
            if (dest === 'extra') {
                out.extra = out.extra ? (out.extra + ' · ' + val) : val;
            } else if (dest === 'storage' && out.storage) {
                out.extra = out.extra ? (out.extra + ' · ' + val) : val;
            } else if (!out[dest]) {
                out[dest] = val;
            }
        }
        if (out.ram && !out.storage) {
            var rs = splitRamStorage(out.ram);
            out.ram = rs.ram;
            out.storage = rs.storage;
        }
        var head = clip(s.slice(0, hits[0].start), 240);
        var hs = splitHeadTitleSummary(head);
        out.title = hs.title;
        if (!out.summary) out.summary = hs.summary;
        if (!out.title) out.title = head;
        return out;
    }

    function looksLikeDumpedSpecs(name) {
        return /\b(CPU|RAM|GPU|SIZE|SCREEN|SSD|STORAGE)\s*[:：]/i.test(String(name || ''));
    }

    function techSpecsFeatureOn() {
        return typeof canUseTechSpecs === 'function' && canUseTechSpecs();
    }

    function resolveProductTechSpecs(prod) {
        prod = prod || {};
        var stored = normalizeTechSpecs(prod.tech_specs);
        var fromName = parseTechSpecsFromText(prod.name || '');
        var out = emptySpecs();
        KEYS.forEach(function (k) {
            out[k] = stored[k] || fromName[k] || '';
        });
        out.title = stored.title || fromName.title || clip(prod.name, 160);
        if (!techSpecsHasContent(out) && !looksLikeDumpedSpecs(prod.name)) {
            out.title = clip(prod.name, 160);
        }
        return out;
    }

    function getProductLabelTitle(prod) {
        if (!techSpecsFeatureOn()) return clip(prod && prod.name, 160);
        var specs = resolveProductTechSpecs(prod);
        if (specs.title) return specs.title;
        return clip(prod && prod.name, 160);
    }

    function ramStoragePrintValue(specs) {
        var ram = clip(specs && specs.ram, 160);
        var st = clip(specs && specs.storage, 160);
        if (ram && st) {
            if (ram.toLowerCase().indexOf(st.toLowerCase()) >= 0) return ram;
            return ram + ' - ' + st;
        }
        return ram || st;
    }

    function getProductTechSpecLines(prod) {
        if (!techSpecsFeatureOn()) {
            return { specs: emptySpecs(), lines: [], summary: '' };
        }
        var specs = resolveProductTechSpecs(prod);
        var lines = [];
        function add(label, val) {
            val = clip(val, 80);
            if (!val) return;
            lines.push({ label: label, value: val });
        }
        add('CPU', specs.cpu);
        add('RAM', ramStoragePrintValue(specs));
        add('GPU', specs.gpu);
        add('SIZE', specs.screen);
        if (specs.extra) add('', specs.extra);
        return { specs: specs, lines: lines, summary: clip(specs.summary, 80) };
    }

    function readTechSpecsFromForm() {
        function v(id) {
            var el = document.getElementById(id);
            return el ? clip(el.value, 160) : '';
        }
        return {
            title: '',
            summary: v('p-spec-summary'),
            cpu: v('p-spec-cpu'),
            ram: v('p-spec-ram'),
            storage: v('p-spec-storage'),
            gpu: v('p-spec-gpu'),
            screen: v('p-spec-screen'),
            extra: v('p-spec-extra')
        };
    }

    function fillTechSpecsForm(specs) {
        specs = normalizeTechSpecs(specs);
        function set(id, val) {
            var el = document.getElementById(id);
            if (el) el.value = val || '';
        }
        set('p-spec-summary', specs.summary);
        set('p-spec-cpu', specs.cpu);
        set('p-spec-ram', specs.ram);
        set('p-spec-storage', specs.storage);
        set('p-spec-gpu', specs.gpu);
        set('p-spec-screen', specs.screen);
        set('p-spec-extra', specs.extra);
        syncTechSpecsBoxOpen();
    }

    function clearTechSpecsForm() {
        fillTechSpecsForm(emptySpecs());
        var box = document.getElementById('p-tech-specs-box');
        if (box) box.open = false;
    }

    function syncTechSpecsBoxOpen() {
        var box = document.getElementById('p-tech-specs-box');
        if (!box) return;
        if (techSpecsHasContent(readTechSpecsFromForm())) box.open = true;
    }

    function applyTechSpecsParseFromName() {
        if (!techSpecsFeatureOn()) return emptySpecs();
        var nameEl = document.getElementById('p-name');
        var raw = nameEl ? String(nameEl.value || '') : '';
        var parsed = parseTechSpecsFromText(raw);
        if (!techSpecsHasContent(parsed) && !parsed.title) {
            if (typeof showToast === 'function') {
                showToast('مواسفات (CPU / RAM / GPU) د ناڤێ ئایتمی دا نەهاتنە دیتن.', 'warning');
            }
            return parsed;
        }
        fillTechSpecsForm(parsed);
        if (parsed.title && nameEl && looksLikeDumpedSpecs(raw)) {
            nameEl.value = parsed.title;
        }
        if (typeof showToast === 'function') {
            showToast('مواسفات هاتنە جوداکرن — ناڤێ ئایتمی کورت بهێلە.', 'success');
        }
        return parsed;
    }

    function collectTechSpecsForSave(name) {
        name = String(name || '');
        if (!techSpecsFeatureOn()) {
            return { name: name, json: '', specs: emptySpecs() };
        }
        var fromForm = readTechSpecsFromForm();
        var parsed = parseTechSpecsFromText(name);
        var specs = fromForm;
        if (!techSpecsHasContent(fromForm) && techSpecsHasContent(parsed)) {
            specs = parsed;
            fillTechSpecsForm(parsed);
        }
        if (techSpecsHasContent(specs) && looksLikeDumpedSpecs(name) && parsed.title) {
            name = parsed.title;
            var nameEl = document.getElementById('p-name');
            if (nameEl) nameEl.value = name;
        }
        var payload = {};
        KEYS.forEach(function (k) {
            if (specs[k]) payload[k] = specs[k];
        });
        return { name: name, specs: payload, json: Object.keys(payload).length ? JSON.stringify(payload) : '' };
    }

    var _techSpecsSplitInFlight = null;

    function applySplitTechSpecsToLocalCatalog(items) {
        if (!items || !items.length) return;
        var byId = {};
        items.forEach(function (u) {
            if (u && u.id != null) byId[String(u.id)] = u;
        });
        var catalogDb = (window.db && Array.isArray(window.db.products)) ? window.db
            : ((typeof db !== 'undefined' && db && Array.isArray(db.products)) ? db : null);
        if (catalogDb && Array.isArray(catalogDb.products)) {
            catalogDb.products.forEach(function (p) {
                if (!p || p.id == null) return;
                var u = byId[String(p.id)];
                if (!u) return;
                if (u.name) p.name = u.name;
                p.tech_specs = u.tech_specs || '';
            });
        }
        var idEl = document.getElementById('p-id');
        var openId = idEl ? String(idEl.value || '').trim() : '';
        if (openId && byId[openId]) {
            var cur = byId[openId];
            var nameEl = document.getElementById('p-name');
            if (nameEl && cur.name) nameEl.value = cur.name;
            if (typeof fillTechSpecsForm === 'function' && cur.tech_specs) fillTechSpecsForm(cur.tech_specs);
        }
        if (typeof renderProducts === 'function') {
            try { renderProducts(); } catch (eRend) {}
        }
    }

    function migrateDumpedTechSpecsFromNames(opts) {
        opts = opts || {};
        if (!techSpecsFeatureOn()) {
            return Promise.resolve({ status: 'skipped' });
        }
        if (_techSpecsSplitInFlight) return _techSpecsSplitInFlight;
        var fd = new FormData();
        fd.append('action', 'split_dumped_tech_specs');
        if (typeof currentUser !== 'undefined' && currentUser && currentUser.name) {
            fd.append('user', currentUser.name);
        }
        var call = (typeof apiJson === 'function')
            ? apiJson('?action=split_dumped_tech_specs', { method: 'POST', body: fd, credentials: 'same-origin' })
            : fetch('?action=split_dumped_tech_specs', { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); });
        _techSpecsSplitInFlight = call.then(function (data) {
            if (!data || data.status !== 'success') return data;
            applySplitTechSpecsToLocalCatalog(data.items || []);
            var n = parseInt(data.count, 10) || 0;
            if (opts.toast !== false && n > 0 && typeof showToast === 'function') {
                var msg = (typeof t === 'function') ? t('tech_specs_auto_split_done') : '';
                if (!msg || msg === 'tech_specs_auto_split_done') {
                    msg = n + ' ئایتم: مواصفات ژ ناڤی هاتنە جوداکرن.';
                } else {
                    msg = msg.replace(/\{n\}/g, String(n));
                }
                showToast(msg, 'success');
            }
            return data;
        }).catch(function () {
            return { status: 'error' };
        }).then(function (data) {
            _techSpecsSplitInFlight = null;
            return data;
        });
        return _techSpecsSplitInFlight;
    }

    function onPremiumTechSpecsToggle(el) {
        if (!el) return;
        if (window.db && window.db.settings) window.db.settings.enableTechSpecs = !!el.checked;
        if (typeof applyProductFormPremiumFeatureFields === 'function') applyProductFormPremiumFeatureFields();
        if (typeof syncSettingsLockedPreviewCards === 'function') syncSettingsLockedPreviewCards();
        if (typeof updateToggleCards === 'function') updateToggleCards();
        if (typeof saveSettings === 'function') {
            try { saveSettings().catch(function () {}); } catch (eSave) {}
        }
    }

    var _techSpecsTapCount = 0;
    var _techSpecsTapTimer = null;

    function techSpecsSplitConfirmMessage() {
        var msg = (typeof t === 'function') ? t('tech_specs_auto_split_confirm') : '';
        if (!msg || msg === 'tech_specs_auto_split_confirm') {
            msg = 'تە دڤێت ئوتۆ ناڤێ ئایتمان ژ مواصفات جودا ببیت؟\n\nئایتمێن CPU / RAM / GPU د ناڤی دا: ناڤ دێ کورت ببیت و مواصفات دێ چنە خانەیان.\n\nئەگەر سوپەرمارکێت بیت — نەخێر.';
        }
        return msg;
    }

    function askTechSpecsAutoSplit() {
        if (typeof canUseTechSpecs !== 'function' || !canUseTechSpecs()) {
            if (typeof showToast === 'function') {
                var need = (typeof t === 'function') ? t('tech_specs_auto_split_need_on') : '';
                if (!need || need === 'tech_specs_auto_split_need_on') {
                    need = 'سەرەتا سووچێ مواصفات ڤەکە، پاشان ١٠ جار ل ناڤێ کارتێ بدە.';
                }
                showToast(need, 'warning');
            }
            return;
        }
        var title = (typeof t === 'function') ? t('tech_specs_auto_split_confirm_title') : '';
        if (!title || title === 'tech_specs_auto_split_confirm_title') {
            title = 'جوداکرنا ناڤ ژ مواصفات';
        }
        var ask = (typeof posConfirm === 'function')
            ? posConfirm({
                title: title,
                message: techSpecsSplitConfirmMessage(),
                icon: 'fa-microchip',
                tone: 'info'
            })
            : Promise.resolve(window.confirm(techSpecsSplitConfirmMessage()));
        Promise.resolve(ask).then(function (ok) {
            if (!ok) return;
            migrateDumpedTechSpecsFromNames({ toast: true });
        }).catch(function () {});
    }

    function onTechSpecsTitleTap(ev) {
        if (ev) {
            ev.preventDefault();
            ev.stopPropagation();
        }
        _techSpecsTapCount += 1;
        if (_techSpecsTapTimer) clearTimeout(_techSpecsTapTimer);
        _techSpecsTapTimer = setTimeout(function () { _techSpecsTapCount = 0; }, 2200);
        if (_techSpecsTapCount < 10) return;
        _techSpecsTapCount = 0;
        askTechSpecsAutoSplit();
    }

    function bindTechSpecsSplitGesture() {
        var lab = document.querySelector('label[for="premium-tech-specs"]');
        if (!lab) return;
        var el = lab.querySelector('.stc-content') || lab;
        if (!el || el.getAttribute('data-tech-specs-tap') === '1') return;
        el.setAttribute('data-tech-specs-tap', '1');
        el.style.cursor = 'pointer';
        el.addEventListener('click', onTechSpecsTitleTap);
    }

    if (typeof window !== 'undefined') {
        window.parseTechSpecsFromText = parseTechSpecsFromText;
        window.normalizeTechSpecs = normalizeTechSpecs;
        window.techSpecsHasContent = techSpecsHasContent;
        window.resolveProductTechSpecs = resolveProductTechSpecs;
        window.getProductLabelTitle = getProductLabelTitle;
        window.getProductTechSpecLines = getProductTechSpecLines;
        window.readTechSpecsFromForm = readTechSpecsFromForm;
        window.fillTechSpecsForm = fillTechSpecsForm;
        window.clearTechSpecsForm = clearTechSpecsForm;
        window.syncTechSpecsBoxOpen = syncTechSpecsBoxOpen;
        window.applyTechSpecsParseFromName = applyTechSpecsParseFromName;
        window.collectTechSpecsForSave = collectTechSpecsForSave;
        window.looksLikeDumpedSpecs = looksLikeDumpedSpecs;
        window.migrateDumpedTechSpecsFromNames = migrateDumpedTechSpecsFromNames;
        window.onPremiumTechSpecsToggle = onPremiumTechSpecsToggle;
        window.bindTechSpecsSplitGesture = bindTechSpecsSplitGesture;
        window.askTechSpecsAutoSplit = askTechSpecsAutoSplit;
    }
    if (typeof document !== 'undefined') {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', function () {
                bindTechSpecsSplitGesture();
            });
        } else {
            setTimeout(bindTechSpecsSplitGesture, 0);
        }
    }
})();
