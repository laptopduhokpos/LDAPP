<?php
// GET: customer display, notifications
// --- NEW: CUSTOMER DISPLAY STATE HANDLER (GET) ---
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] == 'get_customer_display_state') {

    $res = $conn->query("SELECT setting_value FROM settings WHERE setting_key = 'customer_display_state'");
    if($res && $row = $res->fetch_assoc()) {
        echo json_encode(["status"=>"success", "data"=>json_decode($row['setting_value'])]); exit();
    } else { echo json_encode(["status"=>"empty"]); exit(); }
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] == 'get_pos_notifications') {

    header('Content-Type: application/json; charset=utf-8');

    $deviceId = isset($_GET['device_id']) ? trim((string)$_GET['device_id']) : '';
    if ($deviceId === '') {
        echo json_encode(['status' => 'error', 'message' => 'device_id is required']);
        exit();
    }
    $deviceId = substr($deviceId, 0, 120);

    $rows = [];
    $usedSupabase = false;
    $serial = function_exists('pos_ensure_license_serial') ? trim((string)pos_ensure_license_serial($conn)) : '';
    if ($serial !== '' && strlen($serial) >= 4 && function_exists('pos_supabase_fetch_user_notifications_remote')) {
        $remote = pos_supabase_fetch_user_notifications_remote($serial, $deviceId);
        if (!empty($remote['ok'])) {
            $usedSupabase = true;
            if (!empty($remote['notifications']) && is_array($remote['notifications'])) {
                foreach ($remote['notifications'] as $n) {
                    if (!is_array($n)) continue;
                    $rows[] = [
                        'id' => (string)($n['id'] ?? ''),
                        'title' => (string)($n['title'] ?? ''),
                        'message' => (string)($n['message'] ?? ''),
                        'type' => (string)($n['type'] ?? 'info'),
                        'created_by' => (string)($n['created_by'] ?? 'Admin'),
                        'target_type' => (string)($n['target_type'] ?? 'global'),
                        'target_device_id' => null,
                        'created_at' => (string)($n['created_at'] ?? ''),
                        'source' => 'supabase',
                    ];
                }
            }
        }
    }

    if (!$usedSupabase) {
        $conn->query("CREATE TABLE IF NOT EXISTS pos_notifications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(140) NOT NULL,
            message TEXT NOT NULL,
            type VARCHAR(20) NOT NULL DEFAULT 'info',
            target_type VARCHAR(20) NOT NULL DEFAULT 'global',
            target_device_id VARCHAR(120) NULL,
            created_by VARCHAR(120) NULL,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_pos_notif_target (target_type, target_device_id),
            INDEX idx_pos_notif_active (is_active, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $conn->query("CREATE TABLE IF NOT EXISTS pos_notification_reads (
            id INT AUTO_INCREMENT PRIMARY KEY,
            notification_id INT NOT NULL,
            device_id VARCHAR(120) NOT NULL,
            read_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_notification_device (notification_id, device_id),
            INDEX idx_device_read (device_id, read_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $sql = "SELECT n.id, n.title, n.message, n.type, n.created_by, n.target_type, n.target_device_id, n.created_at
                FROM pos_notifications n
                LEFT JOIN pos_notification_reads r ON r.notification_id = n.id AND r.device_id = ?
                WHERE n.is_active = 1
                  AND (n.target_type = 'global' OR (n.target_type = 'device' AND n.target_device_id = ?))
                  AND r.id IS NULL
                ORDER BY n.created_at DESC
                LIMIT 25";
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("ss", $deviceId, $deviceId);
            $stmt->execute();
            $res = $stmt->get_result();
            while ($res && $r = $res->fetch_assoc()) {
                $r['source'] = 'local';
                $rows[] = $r;
            }
        }
    }

    echo json_encode(['status' => 'success', 'notifications' => $rows]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] == 'get_pos_notifications_admin') {

    header('Content-Type: application/json; charset=utf-8');
    pos_session_require_login_json();
    if (!pos_session_is_admin()) pos_json_perm_denied();

    $conn->query("CREATE TABLE IF NOT EXISTS pos_notifications (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(140) NOT NULL,
        message TEXT NOT NULL,
        type VARCHAR(20) NOT NULL DEFAULT 'info',
        target_type VARCHAR(20) NOT NULL DEFAULT 'global',
        target_device_id VARCHAR(120) NULL,
        created_by VARCHAR(120) NULL,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_pos_notif_target (target_type, target_device_id),
        INDEX idx_pos_notif_active (is_active, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $res = $conn->query("SELECT id, title, message, type, target_type, target_device_id, created_by, created_at
                         FROM pos_notifications
                         WHERE is_active = 1
                         ORDER BY created_at DESC
                         LIMIT 60");
    $rows = [];
    if ($res) while ($r = $res->fetch_assoc()) $rows[] = $r;
    echo json_encode(['status' => 'success', 'notifications' => $rows]);
    exit();
}
