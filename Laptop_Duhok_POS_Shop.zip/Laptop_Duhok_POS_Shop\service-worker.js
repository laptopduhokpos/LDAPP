/**
 * POS PWA — offline vendor (icons/fonts) cache-first; app assets network-first.
 * Bump CACHE_NAME when changing caching logic.
 */
const CACHE_NAME = 'pos-cache-v13-exp-pds-ico';

function swBasePath() {
    var p = self.location.pathname || '/';
    if (p.indexOf('service-worker.js') !== -1) {
        return p.replace(/service-worker\.js.*$/, '');
    }
    return p.endsWith('/') ? p : (p + '/');
}

const OFFLINE_VENDOR = [
    'public/css/pos-00-fonts.css',
    'public/fonts/rudaw/Rudaw-Regular.ttf',
    'public/fonts/rudaw/Rudaw-Bold.ttf',
    'public/vendor/fontawesome/css/all.min.css',
    'public/vendor/fontawesome/webfonts/fa-solid-900.woff2',
    'public/vendor/fontawesome/webfonts/fa-regular-400.woff2',
    'public/vendor/fontawesome/webfonts/fa-brands-400.woff2'
];

function precacheUrls() {
    var base = swBasePath();
    return OFFLINE_VENDOR.map(function (rel) {
        return new URL(rel, self.location.origin + base).href;
    });
}

self.addEventListener('install', function (event) {
    self.skipWaiting();
    event.waitUntil(
        caches.open(CACHE_NAME).then(function (cache) {
            return Promise.all(
                precacheUrls().map(function (url) {
                    return cache.add(url).catch(function () { return null; });
                })
            );
        })
    );
});

function networkFirstThenCache(request) {
    return fetch(request, { cache: 'no-cache' }).then(function (response) {
        if (response && response.status === 200 && response.type === 'basic') {
            var copy = response.clone();
            caches.open(CACHE_NAME).then(function (cache) {
                cache.put(request, copy);
            });
        }
        return response;
    }).catch(function () {
        return caches.match(request);
    });
}

function cacheFirst(request) {
    return caches.match(request).then(function (cached) {
        if (cached) return cached;
        return fetch(request).then(function (response) {
            if (response && response.status === 200) {
                var copy = response.clone();
                caches.open(CACHE_NAME).then(function (cache) {
                    cache.put(request, copy);
                });
            }
            return response;
        });
    });
}

function isOfflineVendorRequest(url) {
    var path = url.pathname || '';
    return path.indexOf('/public/vendor/fontawesome/') !== -1
        || path.indexOf('/public/fonts/rudaw/') !== -1
        || path.indexOf('/public/css/pos-00-fonts.css') !== -1;
}

self.addEventListener('fetch', function (event) {
    if (event.request.method !== 'GET') {
        return;
    }

    if (event.request.url.indexOf('api/all.php') !== -1 || event.request.url.indexOf('action=') !== -1) {
        return;
    }

    var url;
    try {
        url = new URL(event.request.url);
    } catch (e) {
        return;
    }

    if (isOfflineVendorRequest(url)) {
        event.respondWith(cacheFirst(event.request));
        return;
    }

    var isNavigate = event.request.mode === 'navigate' || event.request.destination === 'document';
    if (isNavigate) {
        event.respondWith(
            fetch(event.request, { cache: 'no-store' }).catch(function () {
                return caches.match(event.request);
            })
        );
        return;
    }

    var isPhp = /\.php(\?|$)/i.test(url.pathname + url.search);
    if (isPhp && url.origin === self.location.origin) {
        event.respondWith(
            fetch(event.request, { cache: 'no-store' }).catch(function () {
                return caches.match(event.request);
            })
        );
        return;
    }

    var isSameOrigin = url.origin === self.location.origin;
    var isAppAsset = isSameOrigin && /\.(?:js|mjs|css)$/i.test(url.pathname);

    if (isAppAsset) {
        event.respondWith(networkFirstThenCache(event.request));
        return;
    }

    if (isSameOrigin) {
        event.respondWith(networkFirstThenCache(event.request));
        return;
    }

    event.respondWith(
        fetch(event.request, { cache: 'no-cache' }).catch(function () {
            return caches.match(event.request);
        })
    );
});

self.addEventListener('activate', function (event) {
    var cacheWhitelist = [CACHE_NAME];
    event.waitUntil(
        caches.keys().then(function (cacheNames) {
            return Promise.all(
                cacheNames.map(function (name) {
                    if (cacheWhitelist.indexOf(name) === -1) {
                        return caches.delete(name);
                    }
                })
            );
        }).then(function () {
            return self.clients.claim();
        })
    );
});
