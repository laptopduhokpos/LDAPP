// POS reports - users, staff profiles, shifts
        // --- USER & SHIFT MANAGEMENT ---
        function toggleUserPermissions(applyTemplate) {
            const roleEl = document.getElementById('new-u-role');
            const box = document.getElementById('user-permissions-box');
            if (!roleEl || !box) return;
            const role = roleEl.value;
            box.style.display = (role !== 'admin') ? 'block' : 'none';
            if (applyTemplate && typeof applyRoleTemplate === 'function') applyRoleTemplate(role, 'new');
        }
        
        function toggleEditPermissions(applyTemplate) {
            const roleEl = document.getElementById('edit-u-role');
            const container = document.getElementById('edit-perms-container');
            if (!roleEl || !container) return;
            const role = roleEl.value;
            container.style.display = (role !== 'admin') ? 'block' : 'none';
            if (applyTemplate && typeof applyRoleTemplate === 'function') applyRoleTemplate(role, 'edit');
        }

        function permLabel(key) {
            if (!key) return '';
            var k = 'perm_' + key;
            if (typeof t === 'function') {
                var s = t(k);
                if (s && s !== k) return s;
            }
            return key;
        }
        function refreshStaffRoleSelects() {
            var pairs = [['admin','role_option_admin'],['manager','role_option_manager'],['supervisor','role_option_supervisor'],['cashier','role_option_cashier'],['stock_manager','role_option_stock_manager'],['inventory_clerk','role_option_inventory_clerk'],['accountant','role_option_accountant'],['finance_viewer','role_option_finance_viewer'],['sales_rep','role_option_sales_rep'],['sales_viewer','role_option_sales_viewer'],['waiter','role_option_waiter']];
            ['new-u-role','edit-u-role'].forEach(function(selId) {
                var sel = document.getElementById(selId);
                if (!sel) return;
                pairs.forEach(function(pr) {
                    var opt = sel.querySelector('option[value="' + pr[0] + '"]');
                    if (opt && typeof t === 'function') opt.textContent = t(pr[1]);
                });
            });
        }
        function getRoleBadgeStyle(role) {
            const styles = {
                admin: 'background:rgba(239,68,68,0.2); color:#ef4444;',
                manager: 'background:rgba(139,92,246,0.2); color:#8b5cf6;',
                supervisor: 'background:rgba(99,102,241,0.2); color:#6366f1;',
                cashier: 'background:rgba(16,185,129,0.2); color:#10b981;',
                stock_manager: 'background:rgba(245,158,11,0.2); color:#f59e0b;',
                inventory_clerk: 'background:rgba(249,115,22,0.2); color:#f97316;',
                accountant: 'background:rgba(14,165,233,0.2); color:#0ea5e9;',
                finance_viewer: 'background:rgba(6,182,212,0.2); color:#06b6d4;',
                sales_rep: 'background:rgba(34,197,94,0.2); color:#22c55e;',
                sales_viewer: 'background:rgba(148,163,184,0.25); color:#94a3b8;',
                waiter: 'background:rgba(168,85,247,0.2); color:#a855f7;'
            };
            return styles[role] || 'background:var(--input-bg); color:var(--text-muted);';
        }
        function getRoleLabel(role) {
            var k = 'role_short_' + role;
            if (typeof t === 'function') {
                var s = t(k);
                if (s && s !== k) return s;
            }
            var fb = { admin: 'ڕێڤەبەر', manager: 'بەڕێوەبەر', supervisor: 'سەرپەرشتیار', cashier: 'کارمەند', stock_manager: 'کۆگە', inventory_clerk: 'کۆگە', accountant: 'ژمێریار', finance_viewer: 'دارایی', sales_rep: 'فرۆشیار', sales_viewer: 'بینەر', waiter: 'گارصۆن' };
            return fb[role] || role;
        }
        function isProtectedAdminStaff(u) {
            if (!u) return false;
            var id = parseInt(u.id, 10);
            var name = String(u.name || '').trim().toLowerCase();
            return id === 1 || name === 'manager';
        }
        function fillStaffEditRoleFields(u) {
            if (!u) return;
            var idEl = document.getElementById('edit-u-id');
            var nameEl = document.getElementById('edit-u-name');
            var roleEl = document.getElementById('edit-u-role');
            var rateEl = document.getElementById('edit-u-rate');
            if (idEl) idEl.value = u.id;
            if (nameEl) nameEl.value = u.name || '';
            if (typeof refreshStaffRoleSelects === 'function') refreshStaffRoleSelects();
            if (roleEl) {
                var locked = isProtectedAdminStaff(u);
                roleEl.value = locked ? 'admin' : (u.role || 'cashier');
                if (!roleEl.value) roleEl.value = locked ? 'admin' : 'cashier';
                roleEl.disabled = !!locked;
            }
            if (rateEl && u.hourlyRate != null) rateEl.value = u.hourlyRate;
        }

        function getStaffPeriodBounds(year, monthIndex) {
            return {
                start: new Date(year, monthIndex, 1, 0, 0, 0, 0),
                end: new Date(year, monthIndex + 1, 0, 23, 59, 59, 999)
            };
        }

        function formatStaffMonthLabel(year, monthIndex, locale) {
            var monthPrefix = (typeof t === 'function') ? t('profile_label_month') : 'مانگ:';
            try {
                var name = new Date(year, monthIndex, 1).toLocaleDateString(locale || 'ar-IQ', { month: 'long', year: 'numeric' });
                return monthPrefix + ' ' + name;
            } catch (e) {
                return monthPrefix + ' ' + year + '-' + String(monthIndex + 1).padStart(2, '0');
            }
        }

        function formatStaffDayLabel(date, locale) {
            if (!(date instanceof Date) || isNaN(date.getTime())) return '';
            var dayPrefix = (typeof t === 'function') ? t('profile_label_day') : 'ڕۆژ:';
            try {
                var tz = (typeof window.POS_TIMEZONE === 'string') ? window.POS_TIMEZONE : 'Asia/Baghdad';
                var name = date.toLocaleDateString(locale || 'ar-IQ', {
                    timeZone: tz,
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                });
                return dayPrefix + ' ' + name;
            } catch (e) {
                return dayPrefix + ' ' + (typeof formatProfileDate === 'function' ? formatProfileDate(date, locale) : date.toLocaleDateString(locale));
            }
        }
        window.formatStaffDayLabel = formatStaffDayLabel;

        function renderStaffPayExpenseTables(user, locale) {
            var loc = locale || ((typeof getDateLocale === 'function') ? getDateLocale() : 'ar-IQ');
            var rows = (typeof listStaffPayExpenses === 'function')
                ? listStaffPayExpenses((typeof db !== 'undefined' && db && db.expenses) ? db.expenses : [], user && user.name)
                : [];
            var kindOf = (typeof staffPayExpenseKind === 'function') ? staffPayExpenseKind : function() { return ''; };
            var salaryRows = [];
            var advanceRows = [];
            var salarySum = 0;
            var advanceSum = 0;
            rows.forEach(function (e) {
                var amtIqd = (typeof expenseAmountIqd === 'function') ? expenseAmountIqd(e) : (parseFloat(e.amount) || 0);
                if (kindOf(e.note) === 'advance') {
                    advanceRows.push(e);
                    advanceSum += amtIqd;
                } else {
                    salaryRows.push(e);
                    salarySum += amtIqd;
                }
            });
            function rowHtml(e) {
                var nShown = (typeof translateExpenseNoteForUi === 'function') ? translateExpenseNoteForUi(e.note) : (e.note || '');
                var amt = (typeof formatExpenseAmountDisplay === 'function')
                    ? formatExpenseAmountDisplay(e)
                    : formatCurrency((typeof expenseAmountIqd === 'function') ? expenseAmountIqd(e) : e.amount);
                return '<tr><td>' + formatProfileDate(parseSQLDate(e.date), loc) + '</td><td>' + escapeHtml(nShown) + '</td><td style="color:#dc2626;font-weight:700;">' + amt + '</td></tr>';
            }
            function emptyHtml(key, fallback) {
                return '<tr><td colspan="3" style="text-align:center;color:var(--text-muted);padding:12px;">' +
                    escapeHtml((typeof t === 'function') ? t(key) : fallback) + '</td></tr>';
            }
            var salHtml = salaryRows.length
                ? salaryRows.map(rowHtml).join('')
                : emptyHtml('profile_ov_salary_empty', 'هیچ مووچەیەک تۆمار نەبووە.');
            var advHtml = advanceRows.length
                ? advanceRows.map(rowHtml).join('')
                : emptyHtml('profile_ov_advance_empty', 'هیچ نزبایەک تۆمار نەبووە.');
            var salList = document.getElementById('up-ov-salary-list');
            var advList = document.getElementById('up-ov-advance-list');
            var finSal = document.getElementById('up-fin-salary-list');
            var finAdv = document.getElementById('up-fin-advance-list');
            var fin = document.getElementById('up-expenses-list');
            if (salList) salList.innerHTML = salHtml;
            if (advList) advList.innerHTML = advHtml;
            if (finSal) finSal.innerHTML = salHtml;
            if (finAdv) finAdv.innerHTML = advHtml;
            if (fin) fin.innerHTML = (salaryRows.concat(advanceRows).length ? salaryRows.concat(advanceRows).map(rowHtml).join('') : emptyHtml('profile_ov_pay_empty', 'هیچ نزبایەک یان مووچەیەک تۆمار نەبووە.'));
            var sym = (typeof getCurrencySymbol === 'function') ? (' ' + getCurrencySymbol()) : '';
            var salCard = document.getElementById('up-salary-paid-card');
            var advCard = document.getElementById('up-advance-paid-card');
            var cashEl = document.getElementById('up-cash-paid');
            if (salCard) salCard.innerText = formatCurrency(salarySum) + sym;
            if (advCard) advCard.innerText = formatCurrency(advanceSum) + sym;
            if (cashEl) cashEl.innerText = formatCurrency(salarySum + advanceSum) + sym;
        }
        window.renderStaffPayExpenseTables = renderStaffPayExpenseTables;

        /** Aggregate staff work: shifts, hours, salary, sales in [start, end]. */
        function computeStaffWorkStats(user, startDate, endDate) {
            if (!user) return { hours: 0, salary: 0, sales: 0, saleCount: 0, shiftCount: 0, shiftRows: [], saleRows: [], advance: 0, salaryPaid: 0 };
            var startMs = startDate.getTime();
            var endMs = endDate.getTime();
            var hours = 0;
            var salary = 0;
            var shiftCount = 0;
            var shiftRows = [];
            (db.shifts || []).forEach(function(s) {
                if (String(s.userId) !== String(user.id)) return;
                var st = parseSQLDate(s.startTime);
                var en = s.endTime ? parseSQLDate(s.endTime) : new Date();
                if (!st || isNaN(st.getTime())) return;
                var effStart = Math.max(st.getTime(), startMs);
                var effEnd = Math.min(en.getTime(), endMs);
                if (effEnd <= effStart) return;
                var hrs = (effEnd - effStart) / (1000 * 60 * 60);
                var rate = s.hourlyRate || user.hourlyRate || 0;
                var shiftSalary = Math.round(hrs * rate);
                hours += hrs;
                salary += shiftSalary;
                shiftCount++;
                shiftRows.push({
                    start: new Date(effStart),
                    end: new Date(effEnd),
                    hours: hrs,
                    salary: shiftSalary,
                    inProgress: !s.endTime
                });
            });
            var saleRows = [];
            var salesTotal = 0;
            (typeof getAllSales === 'function' ? getAllSales() : (db.sales || [])).forEach(function(sale) {
                if (sale.cashier !== user.name) return;
                var sd = parseSQLDate(sale.date || sale.created_at);
                if (!sd || isNaN(sd.getTime())) return;
                var t = sd.getTime();
                if (t < startMs || t > endMs) return;
                var amt = parseFloat(sale.total) || 0;
                salesTotal += amt;
                saleRows.push({ date: sd, total: amt, id: sale.id });
            });
            saleRows.sort(function(a, b) { return b.date - a.date; });
            shiftRows.sort(function(a, b) { return b.start - a.start; });
            var payStart = new Date(startMs);
            var payEnd = new Date(endMs);
            var expList = (typeof db !== 'undefined' && db && db.expenses) ? db.expenses : [];
            var advance = (typeof sumStaffPayExpenses === 'function')
                ? sumStaffPayExpenses(expList, 'advance', user.name, payStart, payEnd)
                : 0;
            var salaryPaid = (typeof sumStaffPayExpenses === 'function')
                ? sumStaffPayExpenses(expList, 'salary', user.name, payStart, payEnd)
                : 0;
            return {
                hours: hours,
                salary: salary,
                sales: salesTotal,
                saleCount: saleRows.length,
                shiftCount: shiftCount,
                shiftRows: shiftRows,
                saleRows: saleRows,
                advance: advance,
                salaryPaid: salaryPaid
            };
        }
        window.computeStaffWorkStats = computeStaffWorkStats;

        function renderStaffProfilePeriodStats(user, locale) {
            var now = new Date();
            var thisMonth = getStaffPeriodBounds(now.getFullYear(), now.getMonth());
            var prevMonthDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
            var prevMonth = getStaffPeriodBounds(prevMonthDate.getFullYear(), prevMonthDate.getMonth());
            var todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
            var todayEnd = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);
            var yesterday = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
            var yBounds = {
                start: new Date(yesterday.getFullYear(), yesterday.getMonth(), yesterday.getDate(), 0, 0, 0, 0),
                end: new Date(yesterday.getFullYear(), yesterday.getMonth(), yesterday.getDate(), 23, 59, 59, 999)
            };

            var thisStats = computeStaffWorkStats(user, thisMonth.start, thisMonth.end);
            var prevStats = computeStaffWorkStats(user, prevMonth.start, prevMonth.end);
            var todayStats = computeStaffWorkStats(user, todayStart, todayEnd);
            var yStats = computeStaffWorkStats(user, yBounds.start, yBounds.end);
            var hoursWord = (typeof t === 'function') ? t('profile_hours_unit') : 'h';

            function setText(id, val) {
                var el = document.getElementById(id);
                if (el) el.textContent = val;
            }

            function renderDayDetailList(containerId, stats, emptyKey) {
                var list = document.getElementById(containerId);
                if (!list) return;
                var rows = [];
                stats.shiftRows.forEach(function(row) {
                    var startLbl = typeof formatProfileTime === 'function' ? formatProfileTime(row.start, locale) : row.start.toLocaleTimeString(locale);
                    var endLbl = row.inProgress
                        ? ((typeof t === 'function') ? t('profile_shift_in_progress') : 'چالاک')
                        : (typeof formatProfileTime === 'function' ? formatProfileTime(row.end, locale) : row.end.toLocaleTimeString(locale));
                    var shiftLbl = (typeof t === 'function') ? t('profile_yesterday_shift_row') : 'شیفت';
                    rows.push('<div class="staff-profile-yesterday-row"><span><b>' + escapeHtml(shiftLbl) + '</b> <small>' + escapeHtml(startLbl) + ' – ' + escapeHtml(endLbl) + '</small></span><span>' + row.hours.toFixed(1) + ' ' + escapeHtml(hoursWord) + '</span></div>');
                });
                stats.saleRows.slice(0, 15).forEach(function(row) {
                    var timeLbl = typeof formatProfileTime === 'function' ? formatProfileTime(row.date, locale) : row.date.toLocaleTimeString(locale);
                    var saleLbl = (typeof t === 'function') ? t('profile_yesterday_sale_row') : 'فرۆتن';
                    rows.push('<div class="staff-profile-yesterday-row"><span><b>' + escapeHtml(saleLbl) + '</b> <small>#' + escapeHtml(String(row.id || '')) + ' · ' + escapeHtml(timeLbl) + '</small></span><span>' + formatCurrency(row.total) + '</span></div>');
                });
                if (!rows.length) {
                    var emptyMsg = (typeof t === 'function') ? t(emptyKey) : '';
                    rows.push('<p style="padding:10px;color:var(--text-muted);margin:0;text-align:center;">' + escapeHtml(emptyMsg || '—') + '</p>');
                }
                list.innerHTML = rows.join('');
            }

            setText('up-month-this-label', formatStaffMonthLabel(now.getFullYear(), now.getMonth(), locale));
            setText('up-month-prev-label', formatStaffMonthLabel(prevMonthDate.getFullYear(), prevMonthDate.getMonth(), locale));
            setText('up-today-label', formatStaffDayLabel(now, locale));
            setText('up-yesterday-label', formatStaffDayLabel(yesterday, locale));

            setText('up-month-this-hours', thisStats.hours.toFixed(1) + ' ' + hoursWord);
            setText('up-month-this-sales', formatCurrency(thisStats.sales));
            setText('up-month-this-shifts', String(thisStats.shiftCount));
            setText('up-month-this-salary', formatCurrency(thisStats.salary));
            setText('up-month-this-advance', formatCurrency(thisStats.advance || 0));
            setText('up-month-this-salary-paid', formatCurrency(thisStats.salaryPaid || 0));

            setText('up-month-prev-hours', prevStats.hours.toFixed(1) + ' ' + hoursWord);
            setText('up-month-prev-sales', formatCurrency(prevStats.sales));
            setText('up-month-prev-shifts', String(prevStats.shiftCount));
            setText('up-month-prev-salary', formatCurrency(prevStats.salary));
            setText('up-month-prev-advance', formatCurrency(prevStats.advance || 0));
            setText('up-month-prev-salary-paid', formatCurrency(prevStats.salaryPaid || 0));

            setText('up-today-hours', todayStats.hours.toFixed(1) + ' ' + hoursWord);
            setText('up-today-sales', formatCurrency(todayStats.sales));
            setText('up-today-invoices', String(todayStats.saleCount));
            setText('up-today-shifts', String(todayStats.shiftCount));

            setText('up-yesterday-hours', yStats.hours.toFixed(1) + ' ' + hoursWord);
            setText('up-yesterday-sales', formatCurrency(yStats.sales));
            setText('up-yesterday-invoices', String(yStats.saleCount));
            setText('up-yesterday-shifts', String(yStats.shiftCount));

            renderDayDetailList('up-today-detail-list', todayStats, 'profile_today_no_work');
            renderDayDetailList('up-yesterday-detail-list', yStats, 'profile_yesterday_no_work');

            initStaffProfileRangeDefaults();
            if (window._staffProfileActiveUser && window._staffProfileActiveUser.id === user.id) {
                applyStaffProfileRange(false);
            }
        }

        function initStaffProfileRangeDefaults() {
            var now = new Date();
            var fromEl = document.getElementById('up-range-from');
            var toEl = document.getElementById('up-range-to');
            if (!fromEl || !toEl) return;
            if (!fromEl.value) {
                fromEl.value = now.getFullYear() + '-01';
            }
            if (!toEl.value) {
                var m = String(now.getMonth() + 1).padStart(2, '0');
                toEl.value = now.getFullYear() + '-' + m;
            }
        }

        function parseStaffMonthInput(val) {
            if (!val || !String(val).trim()) return null;
            var parts = String(val).trim().split('-');
            if (parts.length < 2) return null;
            var y = parseInt(parts[0], 10);
            var mo = parseInt(parts[1], 10) - 1;
            if (isNaN(y) || isNaN(mo) || mo < 0 || mo > 11) return null;
            return { year: y, month: mo };
        }

        function formatStaffRangeLabel(fromYm, toYm, locale) {
            var prefix = (typeof t === 'function') ? t('profile_range_period') : 'مەودا:';
            var fromLbl = formatStaffMonthLabel(fromYm.year, fromYm.month, locale);
            var toLbl = formatStaffMonthLabel(toYm.year, toYm.month, locale);
            return prefix + ' ' + fromLbl.replace(/^[^:]+:\s*/, '') + ' → ' + toLbl.replace(/^[^:]+:\s*/, '');
        }

        function renderStaffProfileCustomRange(user, fromYm, toYm, locale) {
            if (!user || !fromYm || !toYm) return;
            var startMonth = fromYm;
            var endMonth = toYm;
            if (startMonth.year > endMonth.year || (startMonth.year === endMonth.year && startMonth.month > endMonth.month)) {
                var swap = startMonth;
                startMonth = endMonth;
                endMonth = swap;
            }
            var start = new Date(startMonth.year, startMonth.month, 1, 0, 0, 0, 0);
            var end = new Date(endMonth.year, endMonth.month + 1, 0, 23, 59, 59, 999);

            var totalStats = computeStaffWorkStats(user, start, end);
            var hoursWord = (typeof t === 'function') ? t('profile_hours_unit') : 'h';

            function setText(id, val) {
                var el = document.getElementById(id);
                if (el) el.textContent = val;
            }

            setText('up-range-label', formatStaffRangeLabel(startMonth, endMonth, locale));
            setText('up-range-hours', totalStats.hours.toFixed(1) + ' ' + hoursWord);
            setText('up-range-sales', formatCurrency(totalStats.sales));
            setText('up-range-invoices', String(totalStats.saleCount));
            setText('up-range-shifts', String(totalStats.shiftCount));
            setText('up-range-salary', formatCurrency(totalStats.salary));
            setText('up-range-advance', formatCurrency(totalStats.advance || 0));
            setText('up-range-salary-paid', formatCurrency(totalStats.salaryPaid || 0));

            var monthRows = [];
            var yearTotals = {};
            var cursor = new Date(startMonth.year, startMonth.month, 1);
            var endCursor = new Date(endMonth.year, endMonth.month, 1);
            while (cursor.getTime() <= endCursor.getTime()) {
                var y = cursor.getFullYear();
                var mo = cursor.getMonth();
                var bounds = getStaffPeriodBounds(y, mo);
                var st = computeStaffWorkStats(user, bounds.start, bounds.end);
                var monthName = formatStaffMonthLabel(y, mo, locale).replace(/^[^:]+:\s*/, '');
                monthRows.push({ y: y, mo: mo, monthName: monthName, stats: st });
                if (!yearTotals[y]) yearTotals[y] = { hours: 0, sales: 0, shifts: 0, salary: 0, invoices: 0, advance: 0, salaryPaid: 0 };
                yearTotals[y].hours += st.hours;
                yearTotals[y].sales += st.sales;
                yearTotals[y].shifts += st.shiftCount;
                yearTotals[y].salary += st.salary;
                yearTotals[y].invoices += st.saleCount;
                yearTotals[y].advance += st.advance || 0;
                yearTotals[y].salaryPaid += st.salaryPaid || 0;
                cursor = new Date(y, mo + 1, 1);
            }

            var tbody = document.getElementById('up-range-monthly-body');
            if (tbody) {
                if (!monthRows.length || (totalStats.hours === 0 && totalStats.sales === 0 && totalStats.shiftCount === 0 && !(totalStats.advance > 0) && !(totalStats.salaryPaid > 0))) {
                    tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:16px;">' +
                        escapeHtml((typeof t === 'function') ? t('profile_range_empty') : 'لەم مەودایەدا هیچ ئیشێک تۆمار نەبوو.') + '</td></tr>';
                } else {
                    tbody.innerHTML = monthRows.map(function(row) {
                        return '<tr><td>' + row.y + '</td><td>' + escapeHtml(row.monthName) + '</td>' +
                            '<td>' + row.stats.hours.toFixed(1) + ' ' + escapeHtml(hoursWord) + '</td>' +
                            '<td>' + formatCurrency(row.stats.sales) + '</td>' +
                            '<td>' + row.stats.shiftCount + '</td>' +
                            '<td>' + formatCurrency(row.stats.salary) + '</td>' +
                            '<td>' + formatCurrency(row.stats.advance || 0) + '</td>' +
                            '<td>' + formatCurrency(row.stats.salaryPaid || 0) + '</td></tr>';
                    }).join('');
                }
            }

            var yearKeys = Object.keys(yearTotals).sort(function(a, b) { return Number(b) - Number(a); });
            var yearWrap = document.getElementById('up-range-yearly-wrap');
            var yearGrid = document.getElementById('up-range-yearly-grid');
            if (yearWrap && yearGrid) {
                if (yearKeys.length > 1) {
                    yearWrap.style.display = 'block';
                    yearGrid.innerHTML = yearKeys.map(function(yk) {
                        var yt = yearTotals[yk];
                        return '<div class="staff-profile-range-year-card"><span>' + escapeHtml(yk) + '</span>' +
                            '<strong>' + formatCurrency(yt.sales) + '</strong>' +
                            '<small style="color:var(--text-muted);display:block;margin-top:4px;">' +
                            yt.hours.toFixed(1) + ' ' + escapeHtml(hoursWord) + ' · ' + yt.shifts + ' ' +
                            escapeHtml((typeof t === 'function') ? t('profile_period_shifts') : 'شیفت') +
                            '</small></div>';
                    }).join('');
                } else {
                    yearWrap.style.display = 'none';
                    yearGrid.innerHTML = '';
                }
            }
        }

        function applyStaffProfileRange(showToastOnError) {
            var user = window._staffProfileActiveUser;
            if (!user) return;
            var fromVal = document.getElementById('up-range-from') && document.getElementById('up-range-from').value;
            var toVal = document.getElementById('up-range-to') && document.getElementById('up-range-to').value;
            var fromYm = parseStaffMonthInput(fromVal);
            var toYm = parseStaffMonthInput(toVal);
            if (!fromYm || !toYm) {
                if (showToastOnError !== false && typeof showToast === 'function') {
                    showToast('تکایە مانگی دەستپێک و کۆتایی هەڵبژێرە', 'warning');
                }
                return;
            }
            var locale = (typeof getDateLocale === 'function') ? getDateLocale() : 'ar-IQ';
            renderStaffProfileCustomRange(user, fromYm, toYm, locale);
        }
        window.applyStaffProfileRange = applyStaffProfileRange;

        function renderUsers() {
            if (typeof refreshStaffRoleSelects === 'function') refreshStaffRoleSelects();
            const list = document.getElementById('users-list') || document.getElementById('users-grid');
            if (!list) return;
            if(!db.users || db.users.length === 0) {
                var emptyMsg = (typeof t === 'function') ? t('staff_list_empty') : 'چ کارمەند نینن.';
                list.innerHTML = '<p class="staff-users-empty-msg">' + escapeHtml(emptyMsg) + '</p>';
                return;
            }
            var searchEl = document.getElementById('staff-search');
            var q = searchEl && searchEl.value ? String(searchEl.value).trim().toLowerCase() : '';
            var users = db.users;
            if (q) {
                users = users.filter(function(u) {
                    var name = String(u && u.name ? u.name : '').toLowerCase();
                    var role = String(u && u.role ? u.role : '').toLowerCase();
                    return name.indexOf(q) >= 0 || role.indexOf(q) >= 0;
                });
            }
            if (!users.length) {
                var noneMsg = (typeof t === 'function') ? t('staff_list_empty') : 'چ کارمەند نینن.';
                list.innerHTML = '<p class="staff-users-empty-msg">' + escapeHtml(noneMsg) + '</p>';
                return;
            }
            const allSales = typeof getAllSales === 'function' ? getAllSales() : (db.sales || []);
            list.innerHTML = users.map(u => {
                const isAdmin = u.role === 'admin';
                const isActive = u.is_active !== undefined ? u.is_active : 1;
                const roleBadge = `<span class="staff-role-badge" style="${getRoleBadgeStyle(u.role)}">${getRoleLabel(u.role)}</span>`;
                var activeLab = (typeof t === 'function') ? t('staff_status_active') : '● چالاک';
                var inactLab = (typeof t === 'function') ? t('staff_status_inactive') : '○ ناچالاک';
                const statusBadge = isActive ? '<span class="staff-status-badge is-active">' + escapeHtml(activeLab) + '</span>' : '<span class="staff-status-badge is-inactive">' + escapeHtml(inactLab) + '</span>';
                const avatarColors = { admin: '#ef4444', manager: '#8b5cf6', supervisor: '#6366f1', cashier: '#10b981', stock_manager: '#f59e0b', inventory_clerk: '#f97316', accountant: '#0ea5e9', finance_viewer: '#06b6d4', sales_rep: '#22c55e', sales_viewer: '#94a3b8', waiter: '#a855f7' };
                const avatarColor = avatarColors[u.role] || '#3b82f6';
                const totalSales = allSales.filter(s => s.cashier === u.name).reduce((a,b) => a + (b.total || 0), 0);
                var monthStats = typeof computeStaffWorkStats === 'function'
                    ? computeStaffWorkStats(u, getStaffPeriodBounds(new Date().getFullYear(), new Date().getMonth()).start, getStaffPeriodBounds(new Date().getFullYear(), new Date().getMonth()).end)
                    : { sales: 0, hours: 0 };
                var monthName = formatStaffMonthLabel(new Date().getFullYear(), new Date().getMonth(), (typeof getDateLocale === 'function') ? getDateLocale() : 'ar-IQ');
                var monthSalesLbl = monthName + ' · ' + ((typeof t === 'function') ? t('staff_card_month_sales') : 'فرۆتن');
                var monthHoursLbl = monthName + ' · ' + ((typeof t === 'function') ? t('staff_card_month_hours') : 'کاتژمێر');
                var hoursWordCard = (typeof t === 'function') ? t('profile_hours_unit') : 'h';
                let permsBadges = '';
                if(!isAdmin && u.permissions && u.permissions.length > 0) {
                    permsBadges = `<div class="staff-perms-badges">` + u.permissions.slice(0,4).map(p => `<span class="staff-perm-chip">${escapeHtml(permLabel(p))}</span>`).join('') + (u.permissions.length > 4 ? '<span class="staff-perm-chip-more">+' + (u.permissions.length-4) + '</span>' : '') + `</div>`;
                }
                return `
                <div class="staff-user-card" onclick="openUserProfile(${u.id})">
                    ${u.role !== 'admin' ? `<button class="staff-user-remove-btn" onclick="event.stopPropagation(); removeUser(${u.id})"><i class="fas fa-trash-alt"></i></button>` : ''}
                    <div class="staff-user-avatar" style="--staff-avatar:${avatarColor};">
                        ${u.name.charAt(0).toUpperCase()}
                    </div>
                    <h3 class="staff-user-name">${escapeHtml(u.name)}</h3>
                    <div class="staff-user-role">${roleBadge}</div>
                    <div class="staff-user-status">${statusBadge}</div>
                    ${permsBadges}
                    <div class="staff-user-stats">
                        <div class="staff-user-stat-row"><span>${escapeHtml((typeof t === 'function') ? t('staff_card_rate') : 'مووچە/کات:')}</span> <span class="staff-user-stat-value">${formatCurrency(u.hourlyRate)}</span></div>
                        <div class="staff-user-stat-row"><span>${escapeHtml((typeof t === 'function') ? t('staff_card_total_sales') : 'کۆی فرۆتن:')}</span> <span class="staff-user-stat-value is-sales">${formatCurrency(totalSales)}</span></div>
                        <div class="staff-user-stat-row"><span>${escapeHtml(monthSalesLbl)}</span> <span class="staff-user-stat-value is-sales">${formatCurrency(monthStats.sales)}</span></div>
                        <div class="staff-user-stat-row"><span>${escapeHtml(monthHoursLbl)}</span> <span class="staff-user-stat-value">${monthStats.hours.toFixed(1)} ${escapeHtml(hoursWordCard)}</span></div>
                    </div>
                </div>`;
            }).join('');

            var newRoleEl = document.getElementById('new-u-role');
            if (newRoleEl && !newRoleEl.dataset.permsSeeded) {
                newRoleEl.dataset.permsSeeded = '1';
                if (!newRoleEl.value || newRoleEl.value === 'admin') newRoleEl.value = 'cashier';
                if (typeof toggleUserPermissions === 'function') toggleUserPermissions(true);
            }
        }

        function switchUserTab(tabName) {
            const modal = document.getElementById('user-profile-modal');
            if(!modal) return;
            modal.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            modal.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            
            const tabPanel = document.getElementById('tab-' + tabName);
            const b = document.getElementById('tab-btn-' + tabName);
            if(tabPanel) tabPanel.classList.add('active');
            if(b) b.classList.add('active');
            if (tabName === 'u-settings' && typeof refreshStaffRoleSelects === 'function') refreshStaffRoleSelects();
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
        }

        function openUserProfile(id) {
            // SECURITY FIX: Prevent non-admins from viewing other user profiles
            if (currentUser && currentUser.role !== 'admin' && currentUser.id != id) {
                alert("⛔ تۆ بتنێ دشێی پڕۆفایلا خۆ ببینی.\n(You can only view your own profile.)");
                return;
            }

            const u = db.users.find(x => x.id == id);
            if (!u) { console.error("User not found: " + id); return; }
            window._staffProfileActiveUser = u;
            fillStaffEditRoleFields(u);

            var _upModalEarly = document.getElementById('user-profile-modal');
            if (_upModalEarly) {
                _upModalEarly.setAttribute('lang', ((typeof getCurrentLanguage === 'function') && getCurrentLanguage() === 'ar') ? 'ar' : 'ku');
                _upModalEarly.style.display = 'flex';
                var _nameEarly = document.getElementById('up-name-display');
                var _roleEarly = document.getElementById('up-role-display');
                if (_nameEarly) _nameEarly.innerText = u.name || '';
                if (_roleEarly) _roleEarly.innerText = typeof getRoleLabel === 'function' ? getRoleLabel(u.role) : (u.role || '');
                if (typeof switchUserTab === 'function') switchUserTab('u-overview');
            }

            var _paintProfile = function () {
            try {
                var _dateLocProf = (typeof getDateLocale === 'function') ? getDateLocale() : 'ar-IQ';
                var _hoursWord = (typeof t === 'function') ? t('profile_hours_unit') : 'h';
            
            // Populate Fields
            document.getElementById('edit-u-pin').value = ""; // Clear PIN for security
            fillStaffEditRoleFields(u);
            document.getElementById('up-name-display').innerText = u.name;
            document.getElementById('up-role-display').innerText = getRoleLabel(u.role);
            
            // Calculate Stats
            let totalSales = 0;
            let totalHours = 0;
            let totalSalary = 0;
            
            // Use getAllSales to include archived data
            totalSales = getAllSales().filter(s => s.cashier === u.name).reduce((a,b) => a + b.total, 0);
            
            const shiftsList = document.getElementById('up-shifts-list');
            shiftsList.innerHTML = '';
            if(db.shifts) {
                const userShifts = db.shifts.filter(s => s.userId === u.id).sort((a,b) => new Date(b.startTime) - new Date(a.startTime));
                userShifts.forEach(s => {
                    const start = new Date(s.startTime);
                    const end = s.endTime ? new Date(s.endTime) : new Date();
                    const hrs = (end - start) / (1000 * 60 * 60);
                    totalHours += hrs;
                    const shiftSalary = Math.round(hrs * (s.hourlyRate || u.hourlyRate || 0));
                    totalSalary += shiftSalary;
                    var _inProg = (typeof t === 'function') ? t('profile_shift_in_progress') : '';
                    var _endCell = s.endTime
                        ? formatProfileTime(end, _dateLocProf)
                        : ('<span style="color:green">' + escapeHtml(_inProg) + '</span>');
                    shiftsList.innerHTML += `<tr>
                        <td>${formatProfileDate(start, _dateLocProf)}</td>
                        <td>${formatProfileTime(start, _dateLocProf)}</td>
                        <td>${_endCell}</td>
                        <td>${hrs.toFixed(1)} ${_hoursWord}</td>
                        <td>${formatCurrency(shiftSalary)}</td>
                    </tr>`;
                });
            }
            
            document.getElementById('up-total-sales').innerText = formatCurrency(totalSales) + " " + getCurrencySymbol();
            document.getElementById('up-total-hours').innerText = totalHours.toFixed(1) + " " + _hoursWord;
            document.getElementById('up-est-salary').innerText = formatCurrency(totalSalary) + " " + getCurrencySymbol();
            document.getElementById('up-current-debt').innerText = formatCurrency(u.balance || 0) + " " + getCurrencySymbol();
            if (typeof renderStaffPayExpenseTables === 'function') {
                renderStaffPayExpenseTables(u, _dateLocProf);
            }

            if (typeof renderStaffProfilePeriodStats === 'function') {
                renderStaffProfilePeriodStats(u, _dateLocProf);
            }

            const debtList = document.getElementById('up-debt-items-list');
            debtList.innerHTML = '';
            // Find sales where customer_id == u.id AND customer_type == 'user'
            const userSales = getAllSales().filter(s => s.customer_id == u.id && s.customer_type === 'user');
            userSales.forEach(s => {
                const itemNames = s.items ? s.items.map(i => i.name).join(', ') : ((typeof t === 'function') ? t('profile_unknown_label') : '—');
                debtList.innerHTML += `<tr><td>${formatProfileDate(parseSQLDate(s.date || s.created_at), _dateLocProf)}</td><td>${escapeHtml(itemNames)}</td><td style="color:red">${formatCurrency(s.total, typeof fxUsdRateFormatOpts === 'function' ? fxUsdRateFormatOpts(s) : undefined)}</td></tr>`;
            });

            function renderUserProfileActivity(userRow) {
                const actList = document.getElementById('up-activity-list');
                if (!actList) return;
                actList.innerHTML = '';
                if (!db.logs || !db.logs.length) return;
                var logs = db.logs.filter(function(l) { return l.user === userRow.name; }).slice(0, 100);
                var byDay = {};
                logs.forEach(function(l) {
                    var dKey = typeof getBusinessDate === 'function'
                        ? getBusinessDate(new Date(l.created_at))
                        : String(l.created_at || '').slice(0, 10);
                    if (!byDay[dKey]) byDay[dKey] = [];
                    byDay[dKey].push(l);
                });
                var dayKeys = Object.keys(byDay).sort(function(a, b) { return b.localeCompare(a); });
                dayKeys.forEach(function(dKey) {
                    var dayDate = parseSQLDate(dKey + 'T12:00:00');
                    var dayTitle = (typeof formatStaffDayLabel === 'function' && dayDate && !isNaN(dayDate.getTime()))
                        ? formatStaffDayLabel(dayDate, _dateLocProf)
                        : ((typeof t === 'function') ? t('profile_label_day') : 'ڕۆژ:') + ' ' + dKey;
                    actList.innerHTML += '<div class="staff-profile-period-badge" style="margin:10px 12px 6px;display:block;">' + escapeHtml(dayTitle) + ' (' + byDay[dKey].length + ')</div>';
                    byDay[dKey].forEach(function(l) {
                        actList.innerHTML += '<div style="padding:10px; border-bottom:1px solid var(--border);">' +
                            '<small style="color:var(--text-muted)">' + formatProfileDateTime(new Date(l.created_at), _dateLocProf) + '</small><br>' +
                            '<b>' + escapeHtml(l.action_type) + '</b>: ' + escapeHtml(l.details) +
                            '</div>';
                    });
                });
            }
            const actList = document.getElementById('up-activity-list');
            if (actList) {
                if ((!db.logs || !db.logs.length) && typeof window.refreshAuditLogs === 'function') {
                    actList.innerHTML = '<div style="padding:12px; color:var(--text-muted); text-align:center;"><i class="fas fa-spinner fa-spin"></i></div>';
                    window.refreshAuditLogs(function() { renderUserProfileActivity(u); });
                } else {
                    renderUserProfileActivity(u);
                }
            }

            // Performance Chart (skip on weak laptops — Chart.js blocks UI and looks like a white freeze)
            const ctx = document.getElementById('userPerformanceChart');
            if (ctx && typeof Chart !== 'undefined' && !(typeof isPosCpuSaveMode === 'function' && isPosCpuSaveMode())) {
                try {
                    if (window.userPerfChart) {
                        window.userPerfChart.destroy();
                        window.userPerfChart = null;
                    }
                    
                    // Calculate last 7 days sales for this user
                    const labels = [];
                    const dataPoints = [];
                    for(let i=6; i>=0; i--) {
                        const d = new Date(); d.setDate(d.getDate() - i);
                        const dateStr = getBusinessDate(d);
                        labels.push(d.toLocaleDateString(_dateLocProf, { weekday: 'short' }));
                        
                        // Use parseSQLDate for safety on iPad/Safari
                        const dayTotal = getAllSales()
                            .filter(s => s.cashier === u.name && getBusinessDate(parseSQLDate(s.date || s.created_at)) === dateStr)
                            .reduce((sum, s) => sum + s.total, 0);
                        dataPoints.push(dayTotal);
                    }

                    var _chartAnim = (typeof window !== 'undefined' && window.POS_CHART_ANIMATIONS === false);
                    window.userPerfChart = new Chart(ctx, {
                        type: 'bar',
                        data: { labels: labels, datasets: [{ label: (typeof t === 'function') ? t('staff_chart_daily_sales') : 'فرۆتنا ڕۆژانە', data: dataPoints, backgroundColor: '#0E4AFF', borderRadius: 5 }] },
                        options: { responsive: true, maintainAspectRatio: false, animation: _chartAnim ? false : undefined, scales: { y: { beginAtZero: true } } }
                    });
                } catch(err) { console.error("Chart error:", err); }
            }

            // Set Permissions (saved per user — do not reset to role template on open)
            let perms = u.permissions || [];
            if (typeof perms === 'string') {
                try { perms = JSON.parse(perms); } catch (_e) { perms = []; }
            }
            if (!Array.isArray(perms)) perms = [];
            if (typeof canonicalizePermissionList === 'function') perms = canonicalizePermissionList(perms);
            u.permissions = perms;
            document.querySelectorAll('.edit-perm-chk').forEach(cb => {
                cb.checked = perms.indexOf(cb.value) >= 0;
            });
            const editPermsBox = document.getElementById('edit-perms-container');
            if (editPermsBox) editPermsBox.style.display = (u.role !== 'admin') ? 'block' : 'none';
            
            switchUserTab('u-overview');
            var _upModal = document.getElementById('user-profile-modal');
            if (_upModal) {
                if (typeof applyI18nSubtree === 'function') applyI18nSubtree(_upModal);
                _upModal.style.display = 'flex';
            }

            } catch (e) {
                console.error("Error opening profile:", e);
                alert("هەڵەیەک ڕوویدا د ڤەکرنا پڕۆفایلی دا: " + e.message);
            }
            };

            if (typeof isPosCpuSaveMode === 'function' && isPosCpuSaveMode()) {
                setTimeout(_paintProfile, 0);
            } else {
                _paintProfile();
            }
        }

        function resolveCurrentUserId() {
            if (!currentUser) return null;
            if (currentUser.id != null && currentUser.id !== '') return currentUser.id;
            if (currentUser.user_id != null && currentUser.user_id !== '') return currentUser.user_id;
            if (currentUser.uid != null && currentUser.uid !== '') return currentUser.uid;
            if (db && Array.isArray(db.users) && currentUser.name) {
                var byName = db.users.find(function(u){ return u && u.name === currentUser.name; });
                if (byName && byName.id != null) return byName.id;
            }
            return null;
        }

        function openCurrentUserProfile() {
            var uid = resolveCurrentUserId();
            if (uid == null || uid === '') {
                if (typeof showToast === 'function') showToast('نەتوانرا ناسنامەی بەکارهێنەر بدۆزرێتەوە.', 'warning');
                return;
            }
            openUserProfile(uid);
        }

        function posStaffPinDigits(raw) {
            return String(raw || '').replace(/\D+/g, '').slice(0, 4);
        }
        function posStaffPinAlert() {
            var msg = (typeof t === 'function' ? t('staff_pin_max') : '') || 'کۆدێ نهێنی: تەنها ٤ ژمارە';
            if (msg === 'staff_pin_max') msg = 'کۆدێ نهێنی: تەنها ٤ ژمارە';
            alert(msg);
        }

        function saveUserProfile() {
            const id = parseInt(document.getElementById('edit-u-id').value);
            const pinEl = document.getElementById('edit-u-pin');
            const pinRaw = pinEl ? String(pinEl.value || '') : '';
            if (String(pinRaw).replace(/\D+/g, '').length > 4) {
                posStaffPinAlert();
                if (pinEl) pinEl.value = posStaffPinDigits(pinRaw);
                return;
            }
            const pin = posStaffPinDigits(pinRaw);
            if (pinEl) pinEl.value = pin;
            const existing = db.users.find(function(x) { return x && x.id === id; });
            var role = document.getElementById('edit-u-role').value;
            if (isProtectedAdminStaff(existing) || isProtectedAdminStaff({ id: id, name: document.getElementById('edit-u-name').value })) {
                role = 'admin';
                var roleLock = document.getElementById('edit-u-role');
                if (roleLock) {
                    roleLock.value = 'admin';
                    roleLock.disabled = true;
                }
            }
            if (role !== 'admin' && existing && existing.role === 'admin') {
                var otherAdmin = db.users.some(function(x) { return x && x.id !== id && x.role === 'admin'; });
                if (!otherAdmin) {
                    alert('نابیت ڕێڤەبەر نەمینیت. دڤێت ل قەدێ کەسەک ڕێڤەبەر بمینیت.');
                    return;
                }
            }

            // Security Check: If changing Admin PIN or Role to Admin, require Secret PIN 
            if ((role === 'admin' || db.users.find(u=>u.id===id)?.role === 'admin') && pin !== "") {
                if (!verifySecretPin("گوهۆڕینا پین کۆدێ ڕێڤەبەری")) return;
            }

            const name = document.getElementById('edit-u-name').value;
            const rate = parseFloat(document.getElementById('edit-u-rate').value) || 0;
            
            const perms = [];
            if(role !== 'admin') {
                document.querySelectorAll('.edit-perm-chk:checked').forEach(cb => perms.push(cb.value));
                if (typeof canonicalizePermissionList === 'function') {
                    const canon = canonicalizePermissionList(perms);
                    perms.length = 0;
                    canon.forEach(function(p) { perms.push(p); });
                }
                if (perms.length === 0 && typeof getRoleTemplate === 'function') {
                    getRoleTemplate(role).forEach(function(p) { perms.push(p); });
                }
            }

            const formData = new FormData();
            formData.append('action', 'update_user');
            formData.append('id', id);
            formData.append('name', name);
            formData.append('pin', pin);
            formData.append('role', role);
            formData.append('rate', rate);
            formData.append('permissions', JSON.stringify(perms));

            fetch('?action=update_user', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                if(data.status === 'success') {
                    alert("✅ پڕۆفایل هاتە نویکرن.");
                    document.getElementById('user-profile-modal').style.display = 'none';
                    
                    // Update local data
                    const u = db.users.find(x => x.id === id);
                    if(u) {
                        u.name = name;
                        u.role = role;
                        u.hourlyRate = rate;
                        u.permissions = perms;
                    }
                    
                    // FIX: Update currentUser if it's the same user (Immediate Effect)
                    if(currentUser && currentUser.id === id) {
                        currentUser.name = name;
                        currentUser.role = role;
                        currentUser.hourlyRate = rate;
                        currentUser.permissions = perms;
                        document.getElementById('user-display').innerText = typeof getUserDisplayLabel === 'function' ? getUserDisplayLabel(currentUser) : (currentUser.name + " (" + currentUser.role + ")");
                        var _su = document.getElementById('right-sidebar-user-name'); if(_su) _su.innerText = typeof getUserDisplayLabel === 'function' ? getUserDisplayLabel(currentUser) : (currentUser.name + " (" + currentUser.role + ")");
                        applyUserPermissions();
                    }

                    // Force re-render to show changes immediately
                    renderUsers();
                } else alert('❌ ' + (data.message || 'هەڵە لە نوێکردنەوەدا.'));
            })
            .catch(err => alert('❌ هەڵە: ' + (err.message || 'پەیوەندی')));
        }

        function addUser() {
            const name = document.getElementById('new-u-name').value;
            const pinEl = document.getElementById('new-u-pin');
            const pinRaw = pinEl ? String(pinEl.value || '') : '';
            if (String(pinRaw).replace(/\D+/g, '').length > 4) {
                posStaffPinAlert();
                if (pinEl) pinEl.value = posStaffPinDigits(pinRaw);
                return;
            }
            const pin = posStaffPinDigits(pinRaw);
            if (pinEl) pinEl.value = pin;
            const rate = parseFloat(document.getElementById('new-u-rate').value) || 0;
            const role = document.getElementById('new-u-role').value || 'cashier';
            
            const perms = [];
            if(role !== 'admin') {
                document.querySelectorAll('.perm-chk:checked').forEach(cb => perms.push(cb.value));
                if (typeof canonicalizePermissionList === 'function') {
                    const canon = canonicalizePermissionList(perms);
                    perms.length = 0;
                    canon.forEach(function(p) { perms.push(p); });
                }
                if (perms.length === 0 && typeof getRoleTemplate === 'function') {
                    getRoleTemplate(role).forEach(function(p) { perms.push(p); });
                }
            }

            if(!name || !pin) return alert("Missing Info");

            var _staffCap = (typeof getPosMaxStaffAllowed === 'function') ? getPosMaxStaffAllowed() : 3;
            if (Array.isArray(db.users) && db.users.length >= _staffCap) {
                if (typeof showStaffCapPurchasePopup === 'function') showStaffCapPurchasePopup();
                return;
            }
            
            const formData = new FormData();
            formData.append('action', 'add_user');
            formData.append('name', name);
            formData.append('pin', pin);
            formData.append('role', role);
            formData.append('rate', rate);
            formData.append('permissions', JSON.stringify(perms));
            
            fetch('?action=add_user', { method: 'POST', body: formData })
            .then(res=>res.json())
            .then(data => {
                if(data.status === 'success') {
                    db.users.push({ id: data.id, name, pin, role, hourlyRate: rate, permissions: data.permissions });
                    document.getElementById('new-u-name').value = '';
                    document.getElementById('new-u-pin').value = '';
                    document.getElementById('new-u-rate').value = '';
                    document.querySelectorAll('.perm-chk').forEach(cb => cb.checked = false);
                    if (typeof cancelUserEdit === 'function') cancelUserEdit();
                    renderUsers();
                    if (typeof showToast === 'function') showToast('✅ کارمەند زیادکرا.');
                } else if (data.code === 'staff_cap_exceeded' || (data.message && String(data.message).indexOf('سنوور') >= 0)) {
                    if (data.subscription_tier) {
                        db.subscription_tier = String(data.subscription_tier);
                        if (db.settings) db.settings.subscription_tier = db.subscription_tier;
                    }
                    if (typeof showStaffCapPurchasePopup === 'function') {
                        showStaffCapPurchasePopup(data.message || '');
                    }
                } else alert('❌ ' + (data.message || 'هەڵە د تۆمارکرنێ دا.'));
            })
            .catch(err => alert('❌ هەڵە: ' + (err.message || 'پەیوەندی')));
        }

        function saveUser() {
            addUser();
        }

        function cancelUserEdit() {
            var n = document.getElementById('new-u-name');
            var p = document.getElementById('new-u-pin');
            var r = document.getElementById('new-u-rate');
            var role = document.getElementById('new-u-role');
            if (n) n.value = '';
            if (p) p.value = '';
            if (r) r.value = '';
            if (role) role.value = 'cashier';
            if (typeof toggleUserPermissions === 'function') toggleUserPermissions(true);
        }

        function removeUser(id) {
            var targetUser = (db.users || []).find(function(u) { return u.id == id; });
            var userName = targetUser ? targetUser.name : 'کارمەند';
            var msgConfirm = "دڵنیای ژ ژێبرنا کارمەندی (" + userName + ")؟";
            if (!confirm(msgConfirm)) return;

            function executeDelete(secretPin, force) {
                const formData = new FormData();
                formData.append('action', 'delete_user');
                formData.append('id', id);
                if (secretPin) formData.append('secret_pin', secretPin);
                if (force) formData.append('force', '1');

                fetch('?action=delete_user', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.status === 'success') {
                        db.users = (db.users || []).filter(u => u.id !== id);
                        renderUsers();
                        if (typeof showToast === 'function') showToast('✅ کارمەند (' + userName + ') ب یەکجاری هاتە ژێبرن.');
                    } else if (data.code === 'require_secret_pin' || data.code === 'has_debt') {
                        var promptMsg = "🔒 یاسایا توند یا ژێبرنێ:\n" + (data.message || '') + "\n\nهیڤیە ژمارا نهێنی (Secret PIN) لێدە بۆ ژێبرنا ئێکجارەکی:";
                        var pinEntered = prompt(promptMsg);
                        if (pinEntered !== null && pinEntered.trim() !== '') {
                            executeDelete(pinEntered.trim(), true);
                        }
                    } else if (data.message && confirm(data.message + '\n\nئەرێ تە دڤێت ژ کار بێخی (ناچالاک بکەی) ل شوینا ژێبرنێ؟')) {
                        const fd = new FormData();
                        fd.append('action', 'void_user');
                        fd.append('id', id);
                        fd.append('user', currentUser ? currentUser.name : 'System');
                        fetch('?action=void_user', { method: 'POST', body: fd })
                        .then(r => r.json())
                        .then(d => {
                            if (d.status === 'success') {
                                if (typeof connectToDB === 'function') connectToDB(true);
                                else {
                                    if (targetUser) targetUser.is_active = 0;
                                    renderUsers();
                                }
                            }
                        });
                    } else if (data.message) {
                        if (typeof showToast === 'function') showToast(data.message, 'error');
                        else alert(data.message);
                    }
                })
                .catch(err => {
                    alert('هەڵەیەک ڕوویدا: ' + (err.message || 'پەیوەندی سەرنەکەوت'));
                });
            }

            executeDelete('', false);
        }

        function deleteAllUsers() {
            var c1 = (typeof t === 'function') ? t('staff_delete_all_confirm1') : 'دڵنیای؟ هەمی کارمەند دێ هێنە ژێبرن (تەنێ Manager دێ مینیت).';
            var c2 = (typeof t === 'function') ? t('staff_delete_all_confirm2') : 'تەکەزکرنا دووێ: هەمی دێ هێنە ژێبرن!';
            var okA = (typeof t === 'function') ? t('staff_delete_all_ok') : '✅ هەمی کارمەند هاتنە ژێبرن.';
            if(confirm(c1)) {
                if(confirm(c2)) {
                    const formData = new FormData();
                    formData.append('action', 'delete_all_users');
                    fetch('?action=delete_all_users', { method: 'POST', body: formData })
                    .then(res => res.json())
                    .then(data => {
                        if(data.status === 'success') {
                            alert(okA);
                            renderUsers();
                        }
                    });
                }
            }
        }

        function showTransferGuide() {
            alert(
                "📋 ڕێبەرییا ڤەگوهاستنێ (Transfer Guide):\n\n" +
                "⚠️ تێبینی: بێی بەرنامێ (XAMPP) سیستەم ل لاپتۆپێ نوی کار ناکەت!\n\n" +
                "تۆ پێدڤی ب ٢ فایلانە:\n" +
                "1️⃣ بەرنامە (LAPTOP DUHOK POS).\n" +
                "2️⃣ فایلێ داتایان: (Backup...json) ژ دوگما 'Export JSON'.\n\n" +
                "📂 چەوا ل لاپتۆپێ نوی دابنم؟\n" +
                "١. بەرنامێ XAMPP دابەزێنە و (Apache + MySQL) پێ بکە.\n" +
                "٢. بەرنامێ LAPTOP DUHOK POS بکە د ناڤ فولدەرا (C:/xampp/htdocs).\n" +
                "٣. سیستەمی ڤەکە، پاشان ل Settings دوگما 'Restore' لێدە و فایلێ Backup...json هەلبژێرە.\n\n" +
                "✅ ب ڤێ چەندێ بەرنامە و هەمی داتا دێ ڤەگەڕێن."
            );
        }

        function renderShifts() {
            const tbody = document.getElementById('shifts-body');
            if (!tbody) return;
            var _sloc = (typeof getDateLocale === 'function') ? getDateLocale() : 'ar-IQ';
            var todayStr = typeof getBusinessDate === 'function' ? getBusinessDate(new Date()) : '';
            var now = new Date();
            var thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1).getTime();

            let shifts = (db.shifts || []).slice().sort(function(a, b) {
                return parseSQLDate(b.startTime) - parseSQLDate(a.startTime);
            });

            if(currentUser && currentUser.role !== 'admin') {
                shifts = shifts.filter(s => s.userId === currentUser.id);
            }

            var todayShifts = shifts.filter(function(s) {
                return todayStr && typeof getBusinessDate === 'function' && getBusinessDate(parseSQLDate(s.startTime)) === todayStr;
            });
            var monthShifts = shifts.filter(function(s) {
                return parseSQLDate(s.startTime).getTime() >= thisMonthStart;
            });
            var displayShifts = todayShifts.length ? todayShifts : monthShifts.slice(0, 25);
            if (!displayShifts.length) displayShifts = shifts.slice(0, 20);

            var periodLabelEl = document.getElementById('staff-shifts-period-label');
            if (periodLabelEl) {
                if (todayShifts.length) {
                    periodLabelEl.textContent = typeof formatStaffDayLabel === 'function'
                        ? formatStaffDayLabel(new Date(), _sloc)
                        : ((typeof t === 'function') ? t('profile_label_day') : 'ڕۆژ:') + ' ' + todayStr;
                } else {
                    periodLabelEl.textContent = formatStaffMonthLabel(now.getFullYear(), now.getMonth(), _sloc);
                }
            }
            
            tbody.innerHTML = displayShifts.map(s => {
                const start = parseSQLDate(s.startTime);
                const end = s.endTime ? parseSQLDate(s.endTime) : new Date();
                
                // Calculate Duration (Hours)
                const durationHrs = (end - start) / (1000 * 60 * 60);
                
                // Calculate Salary
                const rate = s.hourlyRate || 0;
                const salary = Math.round(durationHrs * rate);

                // Calculate Sales during this shift
                // Filter sales by cashier name and time range
                const shiftSales = db.sales.filter(sale => sale.cashier === s.userName && new Date(sale.date) >= start && new Date(sale.date) <= end)
                                           .reduce((sum, sale) => sum + sale.total, 0);

                var inProg = (typeof t === 'function') ? t('profile_shift_in_progress') : '';
                var startStr = (typeof formatProfileTime === 'function') ? formatProfileTime(start, _sloc) : start.toLocaleTimeString(_sloc);
                var endStr = s.endTime
                    ? ((typeof formatProfileTime === 'function') ? formatProfileTime(end, _sloc) : end.toLocaleTimeString(_sloc))
                    : ('<span style="color:green">' + escapeHtml(inProg) + '</span>');
                return `<tr>
                    <td><b>${escapeHtml(s.userName)}</b></td>
                    <td>${startStr}</td>
                    <td>${endStr}</td>
                    <td style="color:var(--info); font-weight:bold;">${formatCurrency(shiftSales)}</td>
                    <td style="color:var(--success); font-weight:bold;">${formatCurrency(salary)} ${getCurrencySymbol()}</td>
                </tr>`;
            }).join('');

            try {
                var sl = document.getElementById('shifts-list');
                if (sl && typeof applyI18nSubtree === 'function') applyI18nSubtree(sl);
            } catch (eShiftI18n) {}
        }
        
