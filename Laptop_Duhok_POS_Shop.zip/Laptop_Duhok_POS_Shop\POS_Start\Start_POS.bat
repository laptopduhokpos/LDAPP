@echo off
chcp 65001 >nul
REM POS root = parent of this folder
cd /d "%~dp0.."
start "POS Label Print Agent" powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%cd%\api\tools\pos_label_print_agent.ps1"
timeout /t 2 /nobreak >nul
start "" "%~dp0LaptopDuhokPOS.exe"
exit
