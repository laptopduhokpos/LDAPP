<?php
/**
 * کلیلی Gemini — تەنها لێرە (دکاندار نابینێت).
 * لە pos_ai_local.php.example کۆپی بکە ئەگەر ئەم فایلە نییە.
 */
if (!defined('POS_GEMINI_API_KEY')) {
    define('POS_GEMINI_API_KEY', 'AQ.Ab8RN6JFRx66JbAAd0_HApLKWd9mQtHNB224XxiRNlxAhVECLw');
}
if (!defined('POS_GEMINI_MODEL')) {
    define('POS_GEMINI_MODEL', 'gemini-2.5-flash');
}
