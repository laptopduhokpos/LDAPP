// sync/delivery.js — delivery
        // --- DELIVERY SYSTEM ---
        function activeDeliveryDrivers() {
            return (db && Array.isArray(db.drivers) ? db.drivers : []).filter(function (d) {
                return d && (d.is_active == null || Number(d.is_active) !== 0);
            });
        }
        function fillDeliverySelects() {
            var custSel = document.getElementById('del-customer-id');
            var drvSel = document.getElementById('del-driver-id');
            var pickC = (typeof t === 'function') ? t('del_customer_pick') : 'کریار — هەلبژێرە';
            var pickD = (typeof t === 'function') ? t('del_driver_pick') : 'سایێق — هەلبژێرە';
            if (custSel) {
                var keepC = String(custSel.value || '0');
                var optsC = '<option value="0">' + escapeHtml(pickC) + '</option>';
                (db.customers || []).slice().sort(function (a, b) {
                    return String(a.name || '').localeCompare(String(b.name || ''));
                }).forEach(function (c) {
                    if (!c || !c.id) return;
                    optsC += '<option value="' + c.id + '">' + escapeHtml(c.name || '') + '</option>';
                });
                custSel.innerHTML = optsC;
                if (keepC && keepC !== '0') custSel.value = keepC;
            }
            if (drvSel) {
                var keepD = String(drvSel.value || '0');
                try {
                    var stored = sessionStorage.getItem('pos_last_driver_id');
                    if ((!keepD || keepD === '0') && stored) keepD = stored;
                } catch (_eD) {}
                var optsD = '<option value="0">' + escapeHtml(pickD) + '</option>';
                activeDeliveryDrivers().forEach(function (d) {
                    optsD += '<option value="' + d.id + '">' + escapeHtml(d.name || '') + (d.phone ? ' — ' + escapeHtml(d.phone) : '') + '</option>';
                });
                drvSel.innerHTML = optsD;
                if (keepD && keepD !== '0') drvSel.value = keepD;
                if (typeof onDeliveryDriverChange === 'function') onDeliveryDriverChange();
            }
            if (typeof fillPosCartDriverSelect === 'function') fillPosCartDriverSelect();
        }
        window.onDeliveryCustomerChange = function () {
            var sel = document.getElementById('del-customer-id');
            var id = sel ? parseInt(sel.value, 10) : 0;
            var c = (db.customers || []).find(function (x) { return x && Number(x.id) === id; });
            if (!c) return;
            var n = document.getElementById('del-cust-name');
            var p = document.getElementById('del-phone');
            var a = document.getElementById('del-address');
            if (n) n.value = c.name || '';
            if (p) p.value = c.phone || '';
            if (a) a.value = c.address || '';
        };
        window.onDeliveryDriverChange = function () {
            var sel = document.getElementById('del-driver-id');
            var id = sel ? parseInt(sel.value, 10) : 0;
            var d = activeDeliveryDrivers().find(function (x) { return x && Number(x.id) === id; });
            var n = document.getElementById('del-driver-name');
            var p = document.getElementById('del-driver-phone');
            if (n) n.value = d ? (d.name || '') : '';
            if (p) p.value = d ? (d.phone || '') : '';
        };
        window.openDeliveryModal = function(fromPos) {
            var modal = document.getElementById('delivery-modal');
            if (!modal) return;
            fillDeliverySelects();
            modal.style.display = 'flex';
            if (fromPos && activeTableId) {
                var table = db.tables.find(function (t) { return t.id === activeTableId; });
                if (table) {
                    var total = (typeof roundMoney === 'function' ? roundMoney : function (x) { return x; })(table.items.reduce(function (a, b) {
                        var u = typeof getBillLineUnitIqd === 'function' ? getBillLineUnitIqd(b) : (parseFloat(b.price) || 0);
                        return a + u * (typeof getItemQty === 'function' ? getItemQty(b) : (b.qty || 1));
                    }, 0));
                    document.getElementById('del-total').dataset.base = total;
                    document.getElementById('del-total').value = total;
                    document.getElementById('del-note').value = 'POS: ' + (table.name || '');
                }
                var posCust = document.getElementById('pos-customer-name');
                var posName = posCust ? String(posCust.value || '').trim() : '';
                if (posName) {
                    var match = (db.customers || []).find(function (c) { return c && String(c.name) === posName; });
                    if (match) {
                        var cs = document.getElementById('del-customer-id');
                        if (cs) cs.value = String(match.id);
                        if (typeof onDeliveryCustomerChange === 'function') onDeliveryCustomerChange();
                    } else {
                        document.getElementById('del-cust-name').value = posName;
                    }
                }
            } else {
                document.getElementById('del-total').dataset.base = 0;
            }
        };
        window.openDriverModal = function () {
            var modal = document.getElementById('driver-modal');
            if (!modal) return;
            document.getElementById('drv-edit-id').value = '0';
            document.getElementById('drv-name').value = '';
            document.getElementById('drv-phone').value = '';
            document.getElementById('drv-note').value = '';
            renderDriversManageList();
            modal.style.display = 'flex';
        };
        function renderDriversManageList() {
            var box = document.getElementById('drivers-manage-list');
            if (!box) return;
            var list = activeDeliveryDrivers();
            if (!list.length) {
                box.innerHTML = '<p class="delivery-empty-state">' + escapeHtml((typeof t === 'function') ? t('del_empty_drivers') : 'چ سایێق نینن.') + '</p>';
                return;
            }
            box.innerHTML = list.map(function (d) {
                return '<div class="delivery-driver-manage-row">' +
                    '<div><b>' + escapeHtml(d.name || '') + '</b><div class="delivery-meta-line">' + escapeHtml(d.phone || '') + '</div></div>' +
                    '<div class="delivery-card-actions">' +
                    '<button type="button" class="btn btn-sm btn-dark" onclick="editDriver(' + d.id + ')"><i class="fas fa-pen"></i></button>' +
                    '<button type="button" class="btn btn-sm btn-danger" onclick="deleteDriver(' + d.id + ')"><i class="fas fa-trash"></i></button>' +
                    '</div></div>';
            }).join('');
        }
        window.editDriver = function (id) {
            var d = activeDeliveryDrivers().find(function (x) { return Number(x.id) === Number(id); });
            if (!d) return;
            var pageId = document.getElementById('drv-page-edit-id');
            if (pageId) {
                pageId.value = String(d.id);
                var n = document.getElementById('drv-page-name');
                var p = document.getElementById('drv-page-phone');
                var note = document.getElementById('drv-page-note');
                if (n) n.value = d.name || '';
                if (p) p.value = d.phone || '';
                if (note) note.value = d.note || '';
                var saveBtn = document.getElementById('drv-page-save-btn');
                var cancelBtn = document.getElementById('drv-page-cancel-btn');
                if (saveBtn) saveBtn.innerHTML = '<i class="fas fa-save"></i> <span>' + escapeHtml((typeof t === 'function') ? t('del_driver_save') : 'پاراستن') + '</span>';
                if (cancelBtn) cancelBtn.style.display = '';
                var addBox = document.getElementById('drivers-add-box');
                if (addBox && typeof addBox.scrollIntoView === 'function') addBox.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
                if (n && typeof n.focus === 'function') n.focus();
                return;
            }
            var modal = document.getElementById('driver-modal');
            if (modal) {
                document.getElementById('drv-edit-id').value = String(d.id);
                document.getElementById('drv-name').value = d.name || '';
                document.getElementById('drv-phone').value = d.phone || '';
                document.getElementById('drv-note').value = d.note || '';
                modal.style.display = 'flex';
            }
        };
        window.cancelDriverPageEdit = function () {
            var pageId = document.getElementById('drv-page-edit-id');
            if (pageId) pageId.value = '0';
            var n = document.getElementById('drv-page-name');
            var p = document.getElementById('drv-page-phone');
            var note = document.getElementById('drv-page-note');
            if (n) n.value = '';
            if (p) p.value = '';
            if (note) note.value = '';
            var saveBtn = document.getElementById('drv-page-save-btn');
            var cancelBtn = document.getElementById('drv-page-cancel-btn');
            if (saveBtn) saveBtn.innerHTML = '<i class="fas fa-user-plus"></i> <span>' + escapeHtml((typeof t === 'function') ? t('debt_add_btn') : 'زێدەکرن') + '</span>';
            if (cancelBtn) cancelBtn.style.display = 'none';
        };
        window.saveDriverFromPage = function () {
            var id = parseInt((document.getElementById('drv-page-edit-id') || {}).value, 10) || 0;
            var name = String((document.getElementById('drv-page-name') || {}).value || '').trim();
            var phone = String((document.getElementById('drv-page-phone') || {}).value || '').trim();
            var note = String((document.getElementById('drv-page-note') || {}).value || '').trim();
            postSaveDriver(id, name, phone, note, true);
        };
        function postSaveDriver(id, name, phone, note, fromPage) {
            if (!name) {
                if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('del_need_driver_name') : 'ناڤێ سایێقی پێدڤیە', 'error');
                return;
            }
            var fd = new FormData();
            fd.append('action', id > 0 ? 'update_driver' : 'save_driver');
            if (id > 0) fd.append('id', String(id));
            fd.append('name', name);
            fd.append('phone', phone);
            fd.append('note', note);
            fetch('?action=' + (id > 0 ? 'update_driver' : 'save_driver'), { method: 'POST', body: fd, credentials: 'same-origin' })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    if (data.status !== 'success') {
                        if (typeof showToast === 'function') showToast(data.message || 'هەڵە', 'error');
                        return;
                    }
                    if (!db.drivers) db.drivers = [];
                    if (id > 0) {
                        var existing = db.drivers.find(function (x) { return Number(x.id) === id; });
                        if (existing) {
                            existing.name = name;
                            existing.phone = phone;
                            existing.note = note;
                        }
                    } else {
                        db.drivers.push({ id: data.id, name: name, phone: phone, note: note, is_active: 1 });
                        try { sessionStorage.setItem('pos_last_driver_id', String(data.id)); } catch (_eNewDrv) {}
                    }
                    var modalId = document.getElementById('drv-edit-id');
                    var modalN = document.getElementById('drv-name');
                    var modalP = document.getElementById('drv-phone');
                    var modalNote = document.getElementById('drv-note');
                    if (modalId) modalId.value = '0';
                    if (modalN) modalN.value = '';
                    if (modalP) modalP.value = '';
                    if (modalNote) modalNote.value = '';
                    if (fromPage && typeof cancelDriverPageEdit === 'function') cancelDriverPageEdit();
                    renderDriversManageList();
                    fillDeliverySelects();
                    renderDeliveries();
                    if (window.currentViewingDriverId && typeof openDriverProfile === 'function') {
                        openDriverProfile(window.currentViewingDriverId);
                    }
                })
                .catch(function () {
                    if (typeof showToast === 'function') showToast('هەڵە', 'error');
                });
        }
        window.saveDriver = function () {
            var id = parseInt((document.getElementById('drv-edit-id') || {}).value, 10) || 0;
            var name = String((document.getElementById('drv-name') || {}).value || '').trim();
            var phone = String((document.getElementById('drv-phone') || {}).value || '').trim();
            var note = String((document.getElementById('drv-note') || {}).value || '').trim();
            postSaveDriver(id, name, phone, note, false);
        };
        window.deleteDriver = function (id) {
            var msg = (typeof t === 'function') ? t('del_confirm_delete_driver') : 'ئەڤ سایێقە بهێتە ژێبرن؟';
            var goDel = function () {
                var fd = new FormData();
                fd.append('action', 'delete_driver');
                fd.append('id', String(id));
                fetch('?action=delete_driver', { method: 'POST', body: fd, credentials: 'same-origin' })
                    .then(function (r) { return r.json(); })
                    .then(function (data) {
                        if (data.status !== 'success') {
                            if (typeof showToast === 'function') showToast(data.message || 'هەڵە', 'error');
                            return;
                        }
                        var d = (db.drivers || []).find(function (x) { return Number(x.id) === Number(id); });
                        if (d) d.is_active = 0;
                        if (Number(window.currentViewingDriverId) === Number(id) && typeof closeDriverProfile === 'function') closeDriverProfile();
                        renderDriversManageList();
                        fillDeliverySelects();
                        renderDeliveries();
                    });
            };
            if (typeof posConfirm === 'function') {
                posConfirm({
                    title: (typeof t === 'function') ? t('del_btn_drivers') : 'سایێق',
                    message: msg,
                    tone: 'danger',
                    icon: 'fa-user-times',
                    confirmText: (typeof t === 'function') ? t('exp_btn_delete') : 'ژێبرن'
                }).then(function (ok) { if (ok) goDel(); });
            } else {
                if (!confirm(msg)) return;
                goDel();
            }
        };

        window.calcDeliveryTotal = function() {
            const base = parseFloat(document.getElementById('del-total').dataset.base) || 0;
            const cost = (typeof parseMoneyInputToIqd === 'function')
                ? parseMoneyInputToIqd(document.getElementById('del-delivery-cost').value || '0')
                : (parseFloat(document.getElementById('del-delivery-cost').value) || 0);
            if(base > 0) {
                document.getElementById('del-total').value = base + cost;
            }
        }

        window.sellFromPosAsDelivery = function () {
            var table = db && db.tables ? db.tables.find(function (t) { return t.id === activeTableId; }) : null;
            if (!table || !table.items || table.items.length === 0) {
                var emptyMsg = (typeof t === 'function') ? t('pos_empty_cart') : '';
                if (!emptyMsg || emptyMsg === 'pos_empty_cart') emptyMsg = 'سەبەتە بەتاڵە!';
                if (typeof showToast === 'function') showToast(emptyMsg, true);
                else alert(emptyMsg);
                return;
            }
            if (typeof fillDeliverySelects === 'function') fillDeliverySelects();
            if (typeof fillPosCartDriverSelect === 'function') fillPosCartDriverSelect();
            var drivers = activeDeliveryDrivers();
            if (!drivers.length) {
                var noDrv = (typeof t === 'function') ? t('del_empty_drivers') : 'چ سایێق نینن. دوگمەی سایێق بکە.';
                if (typeof showToast === 'function') showToast(noDrv, 'info');
                if (typeof openDriverModal === 'function') openDriverModal();
                return;
            }
            var cartDrv = document.getElementById('pos-cart-driver-id');
            var driverId = cartDrv ? (parseInt(cartDrv.value, 10) || 0) : 0;
            if (!driverId) {
                var pickDrv = (typeof t === 'function') ? t('del_need_driver_pick') : 'سایێق هەلبژێرە';
                if (typeof showToast === 'function') showToast(pickDrv, 'error');
                else alert(pickDrv);
                if (cartDrv) cartDrv.focus();
                return;
            }
            var custName = (typeof getPosCustomerNameValue === 'function') ? getPosCustomerNameValue() : '';
            if (!custName) {
                var posCust = document.getElementById('pos-customer-name');
                custName = posCust ? String(posCust.value || '').trim() : '';
            }
            if (!custName) {
                var expCust = document.getElementById('pos-expand-customer-name');
                custName = expCust ? String(expCust.value || '').trim() : '';
            }
            var modalDrv = document.getElementById('del-driver-id');
            if (modalDrv) modalDrv.value = String(driverId);
            if (typeof onDeliveryDriverChange === 'function') onDeliveryDriverChange();
            var match = (db.customers || []).find(function (c) { return c && String(c.name) === custName; });
            var cs = document.getElementById('del-customer-id');
            if (match && cs) {
                cs.value = String(match.id);
                if (typeof onDeliveryCustomerChange === 'function') onDeliveryCustomerChange();
            } else {
                var nEl = document.getElementById('del-cust-name');
                if (nEl) nEl.value = custName;
                if (cs) cs.value = '0';
            }
            var roundFn = typeof roundMoney === 'function' ? roundMoney : function (x) { return x; };
            var total = 0;
            if (typeof computePosCartTotals === 'function') {
                var cartTot = computePosCartTotals(table);
                total = roundFn((cartTot && cartTot.finalIqd != null) ? cartTot.finalIqd : 0);
            } else {
                var subIqd = (table.items || []).reduce(function (a, b) {
                    var u = typeof getBillLineUnitIqd === 'function' ? getBillLineUnitIqd(b) : (parseFloat(b.price) || 0);
                    return a + u * (typeof getItemQty === 'function' ? getItemQty(b) : (b.qty || 1));
                }, 0);
                var discIqd = parseFloat(table.manualDiscount);
                if (isNaN(discIqd)) discIqd = 0;
                total = roundFn(subIqd - discIqd);
            }
            if (!(total > 0)) total = 0;
            var totEl = document.getElementById('del-total');
            if (totEl) {
                totEl.dataset.base = String(total);
                totEl.value = String(total);
            }
            var costEl = document.getElementById('del-delivery-cost');
            if (costEl) costEl.value = '';
            var noteEl = document.getElementById('del-note');
            if (noteEl) noteEl.value = 'POS: ' + (table.name || '');
            if (typeof window.collapseTxnSheet === 'function') window.collapseTxnSheet('pos');
            if (typeof window.saveDelivery === 'function') window.saveDelivery();
        };

        window.saveDelivery = function() {
            const cust = String((document.getElementById('del-cust-name') || {}).value || '').trim();
            const phone = String((document.getElementById('del-phone') || {}).value || '').trim();
            const addr = String((document.getElementById('del-address') || {}).value || '').trim();
            const driverId = parseInt((document.getElementById('del-driver-id') || {}).value, 10) || 0;
            const customerId = parseInt((document.getElementById('del-customer-id') || {}).value, 10) || 0;
            if (typeof onDeliveryDriverChange === 'function') onDeliveryDriverChange();
            const driver = String((document.getElementById('del-driver-name') || {}).value || '').trim();
            const driverPhone = document.getElementById('del-driver-phone').value;
            const deliveryCost = (typeof parseMoneyInputToIqd === 'function')
                ? parseMoneyInputToIqd(document.getElementById('del-delivery-cost').value || '0')
                : (parseFloat(document.getElementById('del-delivery-cost').value) || 0);
            const total = parseFloat(document.getElementById('del-total').value) || 0;
            const note = document.getElementById('del-note').value;

            if (!driverId || !driver) {
                var need = (typeof t === 'function') ? t('del_need_driver_pick') : 'سایێق هەلبژێرە';
                if (typeof window.posAlert === 'function') window.posAlert({ message: need, tone: 'danger' });
                else if (typeof showToast === 'function') showToast(need, 'error');
                else alert(need);
                return;
            }

            const formData = new FormData();
            formData.append('action', 'save_delivery');
            formData.append('customer', cust);
            formData.append('phone', phone);
            formData.append('address', addr);
            formData.append('driver', driver);
            formData.append('driver_phone', driverPhone);
            formData.append('driver_id', String(driverId));
            formData.append('customer_id', String(customerId));
            formData.append('delivery_cost', deliveryCost);
            formData.append('total', total);
            formData.append('note', note);
            try { sessionStorage.setItem('pos_last_driver_id', String(driverId)); } catch (_eS) {}

            if(activeTableId) {
                const table = db.tables.find(t => t.id === activeTableId);
                if(table && table.items.length > 0) {
                    formData.append('items', JSON.stringify(table.items));
                    formData.append('table_id', activeTableId);
                }
            }

            fetch('?action=save_delivery', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                if(data.status === 'success') {
                    var activeTbl = activeTableId ? db.tables.find(t => t.id === activeTableId) : null;
                    const items = (activeTbl && Array.isArray(activeTbl.items)) ? activeTbl.items : [];
                    if(!db.deliveries) db.deliveries = [];
                    db.deliveries.push({
                        id: data.id,
                        customer_name: cust,
                        phone: phone,
                        address: addr,
                        driver: data.driver || driver,
                        driver_phone: data.driver_phone || driverPhone,
                        driver_id: driverId,
                        customer_id: customerId,
                        delivery_cost: deliveryCost,
                        total: total,
                        status: 'pending',
                        date: data.date,
                        note: note,
                        items: items
                    });
                    if (window._posDriverDeliveryCache) {
                        var ckNew = String(driverId);
                        if (!window._posDriverDeliveryCache[ckNew]) window._posDriverDeliveryCache[ckNew] = [];
                        window._posDriverDeliveryCache[ckNew].unshift(db.deliveries[db.deliveries.length - 1]);
                    }
                    document.getElementById('delivery-modal').style.display = 'none';
                    document.getElementById('del-cust-name').value = '';
                    document.getElementById('del-phone').value = '';
                    document.getElementById('del-address').value = '';
                    document.getElementById('del-driver-name').value = '';
                    document.getElementById('del-driver-phone').value = '';
                    document.getElementById('del-delivery-cost').value = '';
                    document.getElementById('del-total').value = '';
                    document.getElementById('del-note').value = '';
                    var cidEl = document.getElementById('del-customer-id');
                    if (cidEl) cidEl.value = '0';

                    if(activeTableId) {
                        const table = db.tables.find(t => t.id === activeTableId);
                        if (table) {
                            table.items = [];
                            if (typeof clearPosCartDiscount === 'function') clearPosCartDiscount(table);
                            else delete table.manualDiscount;
                            scheduleSave();
                            renderBill();
                        }
                    }

                    renderDeliveries();
                    if (typeof window.posAlert === 'function') window.posAlert({ message: (typeof t === 'function') ? t('del_toast_sent') : 'گەهاندن هاتە ناردن!', tone: 'success' });
                    else if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('del_toast_sent') : 'گەهاندن هاتە ناردن!');
                    else alert((typeof t === 'function') ? t('del_toast_sent') : 'گەهاندن هاتە ناردن!');
                } else if (data && data.message) {
                    if (typeof showToast === 'function') showToast(data.message, 'error');
                }
            });
        }

        function deliveryCustomerLabel(d) {
            var n = String((d && d.customer_name) || '').trim();
            if (n) return n;
            var ph = String((d && d.phone) || '').trim();
            if (ph) return ph;
            var note = String((d && d.note) || '').trim();
            if (note) return note;
            if (d && d.id != null) return '#' + String(d.id);
            return (typeof t === 'function') ? t('del_no_customer') : 'بێ ناڤ';
        }
        window.deliveryCustomerLabel = deliveryCustomerLabel;
        function deliveriesForDriver(driver) {
            if (!driver) return [];
            var id = Number(driver.id) || 0;
            var name = String(driver.name || '').trim();
            var nameNorm = (typeof normalizeForSearch === 'function') ? normalizeForSearch(name) : name.toLowerCase();
            var phoneDigits = String(driver.phone || '').replace(/\D/g, '');
            var fromDb = (db.deliveries || []).filter(function (d) {
                return deliveryBelongsToDriver(d, id, name, nameNorm, phoneDigits);
            });
            var cached = (window._posDriverDeliveryCache && window._posDriverDeliveryCache[String(id)]) || [];
            if (!cached.length) return fromDb;
            var byId = {};
            cached.forEach(function (d) {
                if (d && d.id != null) byId[String(d.id)] = d;
            });
            fromDb.forEach(function (d) {
                if (!d || d.id == null) return;
                var k = String(d.id);
                if (!byId[k]) byId[k] = d;
            });
            return Object.keys(byId).map(function (k) { return byId[k]; });
        }
        function deliveryBelongsToDriver(d, id, name, nameNorm, phoneDigits) {
            if (!d) return false;
            var did = Number(d.driver_id) || 0;
            if (id > 0 && did > 0 && did === id) return true;
            var dname = String(d.driver || '').trim();
            if (name && dname && dname === name) return true;
            if (nameNorm && dname && typeof normalizeForSearch === 'function' && normalizeForSearch(dname) === nameNorm) return true;
            if (phoneDigits && phoneDigits.length >= 7) {
                var dph = String(d.driver_phone || '').replace(/\D/g, '');
                if (dph && (dph === phoneDigits || dph.slice(-10) === phoneDigits.slice(-10))) return true;
            }
            return false;
        }
        function deliveryIsPending(d) {
            return String((d && d.status) || '').toLowerCase() === 'pending';
        }
        function mergeDriverDeliveriesFromServer(rows, driverId) {
            if (!Array.isArray(rows)) rows = [];
            if (!db.deliveries) db.deliveries = [];
            if (!window._posDriverDeliveryCache) window._posDriverDeliveryCache = {};
            var key = String(Number(driverId) || 0);
            if (key !== '0') window._posDriverDeliveryCache[key] = rows.slice();
            rows.forEach(function (srvD) {
                if (!srvD || srvD.id == null) return;
                if (Array.isArray(srvD.items)) { /* ok */ }
                else if (srvD.items_json) {
                    try { srvD.items = JSON.parse(srvD.items_json); } catch (_eJ) { srvD.items = []; }
                }
                if (typeof window.posMergeDeliveryRow === 'function') window.posMergeDeliveryRow(db.deliveries, srvD);
                else {
                    var sid = Number(srvD.id);
                    var idx = db.deliveries.findIndex(function (x) { return x && Number(x.id) === sid; });
                    if (idx > -1) db.deliveries[idx] = Object.assign({}, db.deliveries[idx], srvD);
                    else db.deliveries.push(srvD);
                }
            });
        }
        function parseDriverDeliveriesPayload(txt) {
            if (!txt) return null;
            var data = null;
            try { data = JSON.parse(txt); } catch (_e1) { data = null; }
            if (!data) {
                var i = txt.indexOf('{');
                var j = txt.lastIndexOf('}');
                if (i >= 0 && j > i) {
                    try { data = JSON.parse(txt.slice(i, j + 1)); } catch (_e2) { data = null; }
                }
            }
            return data;
        }
        function fetchDriverDeliveries(driver, cb) {
            var id = Number(driver && driver.id) || 0;
            if (id <= 0) {
                if (typeof cb === 'function') cb(false, []);
                return;
            }
            if (!window._posDriverDeliveryInflight) window._posDriverDeliveryInflight = {};
            window._posDriverDeliveryInflight[String(id)] = true;
            window._posDeliveryFetchBusy = (window._posDeliveryFetchBusy || 0) + 1;
            var qs = 'action=get_driver_deliveries&id=' + encodeURIComponent(String(id)) + '&t=' + Date.now();
            var urls = [];
            if (typeof window.posRouterUrl === 'function') urls.push(window.posRouterUrl(qs));
            urls.push('?' + qs);
            urls.push('index.php?' + qs);
            var seenUrl = {};
            urls = urls.filter(function (u) {
                if (!u || seenUrl[u]) return false;
                seenUrl[u] = 1;
                return true;
            });
            var done = function (ok, rows) {
                window._posDeliveryFetchBusy = Math.max(0, (window._posDeliveryFetchBusy || 1) - 1);
                if (window._posDriverDeliveryInflight) delete window._posDriverDeliveryInflight[String(id)];
                if (typeof cb === 'function') cb(!!ok, Array.isArray(rows) ? rows : []);
            };
            var attempt = function (i) {
                if (i >= urls.length) {
                    done(false, []);
                    return;
                }
                fetch(urls[i], { credentials: 'same-origin', cache: 'no-store' })
                    .then(function (r) { return r.text(); })
                    .then(function (txt) {
                        var data = parseDriverDeliveriesPayload(txt);
                        var rows = (data && Array.isArray(data.deliveries)) ? data.deliveries : [];
                        var ok = !!(data && (data.status === 'ok' || data.status === 'success') && Array.isArray(data.deliveries));
                        if (ok) {
                            mergeDriverDeliveriesFromServer(rows, id);
                            done(true, rows);
                            return;
                        }
                        attempt(i + 1);
                    })
                    .catch(function () { attempt(i + 1); });
            };
            attempt(0);
        }
        function collectDriverDeliveries(driver) {
            if (!driver) return [];
            var id = Number(driver.id) || 0;
            var name = String(driver.name || '').trim();
            var byId = {};
            var add = function (arr) {
                (arr || []).forEach(function (d) {
                    if (!d || d.id == null) return;
                    byId[String(d.id)] = d;
                });
            };
            add(window._posDriverDeliveryCache && window._posDriverDeliveryCache[String(id)]);
            add((db && db.deliveries) ? db.deliveries.filter(function (d) {
                if (!d) return false;
                if (id && Number(d.driver_id) === id) return true;
                var dn = String(d.driver || '').trim();
                return name && dn && dn === name;
            }) : []);
            return Object.keys(byId).map(function (k) { return byId[k]; });
        }
        function escDrvTxt(s) {
            return String(s == null ? '' : s)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;');
        }
        function paintDriverHistoryFromRows(rows) {
            var box = document.getElementById('drv-p-history-list');
            if (!box) return;
            try {
                var statusFilterEl = document.getElementById('drv-p-history-status');
                var statusFilter = statusFilterEl ? String(statusFilterEl.value || '').toLowerCase() : '';
                var list = [];
                (rows || []).forEach(function (d) {
                    if (!d) return;
                    var st = String(d.status || '').toLowerCase().trim();
                    if (st === 'pending') return;
                    if (!st && !d.settled_at) return;
                    if (statusFilter && st !== statusFilter) return;
                    list.push(d);
                });
                list.sort(function (a, b) { return (Number(b.id) || 0) - (Number(a.id) || 0); });
                if (!list.length) {
                    box.innerHTML = '<div class="drv-empty-picto"><i class="fas fa-box-open"></i><div>چ مێژوو نینە</div></div>';
                    return;
                }
                var html = '<div class="drv-hist-count"><i class="fas fa-list"></i> ' + list.length + '</div>';
                var i;
                for (i = 0; i < list.length; i++) {
                    var d = list[i];
                    var st = String(d.status || '').toLowerCase().trim();
                    var stLabel = st === 'delivered' ? 'گەهشت' : (st === 'refused' ? 'رەفس' : (st === 'cancelled' ? 'هەلوەشاندی' : (st || '—')));
                    var stIco = st === 'delivered' ? 'fa-check' : (st === 'refused' ? 'fa-undo' : 'fa-times');
                    var stClass = st === 'delivered' ? 'ok' : (st === 'refused' ? 'warn' : 'bad');
                    var title = String(d.customer_name || d.phone || d.note || ('#' + d.id)).trim();
                    var when = String(d.settled_at || d.date || '');
                    var amt = d.total != null ? String(d.total) : '0';
                    try {
                        if (typeof formatCurrency === 'function') amt = String(formatCurrency(d.total, d.formatFxOpts) || amt);
                    } catch (_eA) {}
                    html += '<div class="drv-hist-card drv-hist-card--' + stClass + '">' +
                        '<div class="drv-hist-ico" title="' + escDrvTxt(stLabel) + '"><i class="fas ' + stIco + '"></i></div>' +
                        '<div class="drv-hist-body">' +
                        '<div class="drv-hist-top"><b>#' + escDrvTxt(d.id) + ' · ' + escDrvTxt(title) + '</b>' +
                        '<span class="drv-hist-badge drv-hist-badge--' + stClass + '"><i class="fas ' + stIco + '"></i> ' + escDrvTxt(stLabel) + '</span></div>' +
                        '<div class="drv-hist-meta"><i class="fas fa-clock"></i> ' + escDrvTxt(when) + '</div>' +
                        '<div class="drv-hist-amt"><i class="fas fa-coins"></i> ' + escDrvTxt(amt) + '</div>' +
                        '</div></div>';
                }
                box.innerHTML = html;
            } catch (_err) {
                box.innerHTML = '<div class="drv-empty-picto"><i class="fas fa-triangle-exclamation"></i><div>هەڵە د نیشاندانا مێژوویێ دا</div></div>';
            }
        }
        function loadDriverHistoryNow(driver) {
            var drv = driver || activeDeliveryDrivers().find(function (x) { return Number(x.id) === Number(window.currentViewingDriverId); });
            var box = document.getElementById('drv-p-history-list');
            var localRows = collectDriverDeliveries(drv);
            if (localRows.length) paintDriverHistoryFromRows(localRows);
            else if (box) box.innerHTML = '<div style="padding:24px;text-align:center;color:#334155;font-weight:700;"><i class="fas fa-spinner fa-spin"></i> بارکرن...</div>';
            if (!drv) return;
            fetchDriverDeliveries(drv, function (ok, rows) {
                if (Number(window.currentViewingDriverId) !== Number(drv.id)) return;
                var use = (ok && rows && rows.length) ? rows : collectDriverDeliveries(drv);
                paintDriverHistoryFromRows(use);
                renderDriverProfileActive((use || []).filter(function (d) { return deliveryIsPending(d); }));
            });
        }
        function maybePrefetchDriverHistories() {
            var v = document.getElementById('view-delivery');
            if (!v || !v.classList.contains('active')) return;
            var modal = document.getElementById('driver-profile-modal');
            if (modal && modal.style.display === 'flex') return;
            if (window._posDeliveryPrefetchStarted) return;
            window._posDeliveryPrefetchStarted = true;
            var drivers = (typeof activeDeliveryDrivers === 'function') ? activeDeliveryDrivers().slice(0, 6) : [];
            var i = 0;
            var next = function () {
                if (document.getElementById('driver-profile-modal') && document.getElementById('driver-profile-modal').style.display === 'flex') {
                    setTimeout(next, 800);
                    return;
                }
                if (i >= drivers.length) return;
                var d = drivers[i++];
                if (!d || (window._posDriverDeliveryCache && (window._posDriverDeliveryCache[String(d.id)] || []).length)) {
                    setTimeout(next, 0);
                    return;
                }
                fetchDriverDeliveries(d, function () { setTimeout(next, 150); });
            };
            setTimeout(next, 400);
        }
        function deliveryActionButtonsHtml(d) {
            var btnArr = (typeof t === 'function') ? t('del_btn_arrived') : 'گەهشت';
            var btnRefs = (typeof t === 'function') ? t('del_btn_refs') : 'رەفس';
            var btnCan = (typeof t === 'function') ? t('del_btn_cancel') : 'هەلوەشاندن';
            var slipTh = (typeof t === 'function') ? t('del_btn_slip_thermal') : 'Thermal';
            var slipA4 = (typeof t === 'function') ? t('del_btn_slip_a4') : 'A4';
            return '<div class="delivery-card-actions drv-picto-actions">' +
                '<button type="button" class="btn btn-success drv-act-btn" onclick="updateDeliveryStatus(' + d.id + ', \'delivered\')" title="' + escapeHtml(btnArr) + '"><i class="fas fa-check"></i></button>' +
                '<button type="button" class="btn btn-warning drv-act-btn" onclick="updateDeliveryStatus(' + d.id + ', \'refused\')" title="' + escapeHtml(btnRefs) + '"><i class="fas fa-undo"></i></button>' +
                '<button type="button" class="btn btn-danger drv-act-btn" onclick="updateDeliveryStatus(' + d.id + ', \'cancelled\')" title="' + escapeHtml(btnCan) + '"><i class="fas fa-times"></i></button>' +
                '<button type="button" class="btn btn-dark drv-act-btn" onclick="printDeliverySlip(' + d.id + ')" title="' + escapeHtml(slipTh) + '"><i class="fas fa-receipt"></i></button>' +
                '<button type="button" class="btn btn-info drv-act-btn" onclick="printDeliverySlipA4(' + d.id + ')" title="' + escapeHtml(slipA4) + '"><i class="fas fa-file-alt"></i></button>' +
                '</div>';
        }
        function bindDriverCardActions(container) {
            if (!container || container._drvBound) return;
            container._drvBound = true;
            container.addEventListener('click', function (ev) {
                var btn = ev.target.closest('[data-drv-action]');
                if (btn) {
                    ev.preventDefault();
                    ev.stopPropagation();
                    var id = parseInt(btn.getAttribute('data-drv-id'), 10);
                    var act = btn.getAttribute('data-drv-action');
                    if (act === 'profile') openDriverProfile(id);
                    else if (act === 'edit') editDriver(id);
                    else if (act === 'delete') deleteDriver(id);
                    return;
                }
                var card = ev.target.closest('.txn-entity-card[data-drv-id]');
                if (card) openDriverProfile(card.getAttribute('data-drv-id'));
            });
        }

        function renderDeliveries() {
            if (typeof ensureDateFilterToday === 'function') ensureDateFilterToday('delivery');
            if (!db.deliveries) db.deliveries = [];
            if (!db.drivers) db.drivers = [];
            var modalOpen = document.getElementById('driver-profile-modal');
            if (window.currentViewingDriverId && modalOpen && modalOpen.style.display === 'flex') {
                renderDriverProfileLists();
                return;
            }
            var grid = document.getElementById('drivers-grid');
            if (!grid) return;

            var drivers = activeDeliveryDrivers();
            var allActive = db.deliveries.filter(function (d) { return deliveryIsPending(d); });
            var holdTotal = allActive.reduce(function (s, d) { return s + (parseFloat(d.total) || 0); }, 0);
            var todayStr = new Date().toISOString().slice(0, 10);
            var refsToday = db.deliveries.filter(function (d) {
                return d.status === 'refused' && String(d.settled_at || d.date || '').slice(0, 10) === todayStr;
            }).length;

            var prevSearch = '';
            var wasSearchFocus = false;
            try {
                var si = document.getElementById('drv-search-input');
                if (si) prevSearch = si.value;
                wasSearchFocus = !!(document.activeElement && document.activeElement.id === 'drv-search-input');
            } catch (_eS) {}
            var T = (typeof t === 'function' ? t : function (k) { return k; });
            var searchTerm = String(prevSearch || '').toLowerCase();

            var html = '<div style="grid-column: 1 / -1; display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; margin-bottom: 20px;">' +
                '<div class="card drv-kpi-card" style="background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); border: 1px solid #334155; padding: 15px; margin:0;">' +
                '<h4 style="color:#94a3b8; margin:0 0 5px 0;"><i class="fas fa-money-bill-wave" style="margin-left:6px;"></i> ' + escapeHtml(T('del_kpi_driver_cash')) + '</h4>' +
                '<h1 style="color:#38bdf8; margin:0;">' + (typeof formatCurrency === 'function' ? formatCurrency(holdTotal) : holdTotal) + '</h1></div>' +
                '<div class="card drv-kpi-card" style="background:var(--card); border:1px solid var(--border); padding:15px; margin:0;">' +
                '<h4 style="color:var(--text-muted); margin:0 0 5px 0;"><i class="fas fa-truck" style="margin-left:6px;color:#d97706;"></i> ' + escapeHtml(T('del_kpi_active')) + '</h4>' +
                '<h1 style="color:#d97706; margin:0;">' + allActive.length + '</h1></div>' +
                '<div class="card drv-kpi-card" style="background:var(--card); border:1px solid var(--border); padding:15px; margin:0;">' +
                '<h4 style="color:var(--text-muted); margin:0 0 5px 0;"><i class="fas fa-undo" style="margin-left:6px;color:#dc2626;"></i> ' + escapeHtml(T('del_kpi_refs_today')) + '</h4>' +
                '<h1 style="color:#dc2626; margin:0;">' + refsToday + '</h1></div>' +
                '</div>';

            html += '<div style="grid-column:1 / -1; display:flex; gap:10px; margin-bottom:15px; flex-wrap:wrap;">' +
                '<div style="flex:1; position:relative;">' +
                '<i class="fas fa-search" style="position:absolute; right:15px; top:15px; color:var(--text-muted);"></i>' +
                '<input type="text" id="drv-search-input" class="input-std" placeholder="' + String(T('debt_search_placeholder')).replace(/"/g, '&quot;') + '" style="margin:0; padding-right:40px;" onkeyup="if(window._drvSearchTimer)clearTimeout(window._drvSearchTimer);window._drvSearchTimer=setTimeout(function(){renderDeliveries();},120)">' +
                '</div></div>';

            var filtered = drivers.filter(function (dr) {
                if (!searchTerm) return true;
                var name = String(dr.name || '').toLowerCase();
                var phone = String(dr.phone || '');
                var idRaw = String(dr.id != null ? dr.id : '');
                return name.indexOf(searchTerm) !== -1 || phone.indexOf(searchTerm) !== -1 || idRaw.indexOf(searchTerm) !== -1;
            });

            if (!filtered.length) {
                html += '<p class="delivery-empty-state" style="grid-column:1/-1;">' + escapeHtml(T('del_empty_drivers')) + '</p>';
            } else {
                html += filtered.map(function (dr) {
                    var mine = deliveriesForDriver(dr);
                    var pending = mine.filter(function (d) { return deliveryIsPending(d); });
                    var hold = pending.reduce(function (s, d) { return s + (parseFloat(d.total) || 0); }, 0);
                    var busy = pending.length > 0;
                    var statusColor = busy ? '#d97706' : '#10b981';
                    var statusText = busy ? (pending.length + ' ' + T('del_kpi_active')) : T('drv_card_idle');
                    return '<div class="card txn-entity-card" data-drv-id="' + dr.id + '" style="padding:0; overflow:hidden; border:1px solid var(--border); cursor:pointer;">' +
                        '<div style="padding:15px; display:flex; justify-content:space-between; align-items:center; background:var(--input-bg);">' +
                        '<div style="display:flex; align-items:center; gap:12px;">' +
                        '<div class="drv-card-avatar" style="width:52px; height:52px; border-radius:50%; background:' + statusColor + '22; color:' + statusColor + '; display:flex; align-items:center; justify-content:center; font-size:1.4rem;"><i class="fas fa-motorcycle"></i></div>' +
                        '<div><h3 style="margin:0; font-size:1rem; display:flex; align-items:center; gap:6px; flex-wrap:wrap;">' +
                        '<span>' + escapeHtml(dr.name || '') + '</span>' +
                        '<span style="background:rgba(217,119,6,0.15); color:#c2410c; padding:1px 7px; border-radius:6px; font-size:0.72rem; font-weight:700; direction:ltr;">#' + escapeHtml(String(dr.id)) + '</span></h3>' +
                        '<small style="color:var(--text-muted); display:block;"><i class="fas fa-phone" style="margin-left:4px;"></i> ' + escapeHtml(dr.phone || T('debt_no_phone')) + '</small>' +
                        (dr.note ? '<small style="color:var(--text-muted); display:block;"><i class="fas fa-sticky-note" style="margin-left:4px;"></i> ' + escapeHtml(dr.note) + '</small>' : '') +
                        '</div></div>' +
                        '<div style="text-align:right;"><h3 style="margin:0; color:' + statusColor + ';"><i class="fas fa-coins" style="font-size:0.85rem;margin-left:4px;"></i> ' + (typeof formatCurrency === 'function' ? formatCurrency(hold) : hold) + '</h3>' +
                        '<small style="color:' + statusColor + '; font-weight:bold;"><i class="fas ' + (busy ? 'fa-truck' : 'fa-check') + '"></i> ' + escapeHtml(statusText) + '</small></div></div>' +
                        (busy ? '<div style="height:4px; background:var(--border); width:100%;"><div style="height:100%; background:' + statusColor + '; width:' + Math.min(100, pending.length * 25) + '%;"></div></div>' : '') +
                        '<div class="page-action-row" style="padding:10px; display:flex; gap:5px; background:var(--card);">' +
                        '<div class="page-actions-standard" style="display:flex; gap:5px; width:100%;">' +
                        '<button type="button" class="btn btn-sm btn-info" style="flex:1;" data-drv-action="profile" data-drv-id="' + dr.id + '" title="' + escapeHtml(T('drv_btn_profile')) + '"><i class="fas fa-user"></i> ' + escapeHtml(T('drv_btn_profile')) + '</button>' +
                        '<button type="button" class="btn btn-sm btn-warning" style="min-width:42px;" data-drv-action="edit" data-drv-id="' + dr.id + '" title="' + escapeHtml(T('debt_btn_edit') || 'دەستکاری') + '"><i class="fas fa-edit"></i></button>' +
                        '<button type="button" class="btn btn-sm btn-danger" style="min-width:42px;" data-drv-action="delete" data-drv-id="' + dr.id + '" title="' + escapeHtml(T('btn_delete') || 'ژێبرن') + '"><i class="fas fa-trash"></i></button>' +
                        '</div></div></div>';
                }).join('');
            }
            grid.innerHTML = html;
            bindDriverCardActions(grid);
            var searchInput = document.getElementById('drv-search-input');
            if (searchInput) {
                searchInput.value = prevSearch;
                if (wasSearchFocus) {
                    try {
                        searchInput.focus();
                        var pos = prevSearch.length;
                        searchInput.setSelectionRange(pos, pos);
                    } catch (_eF) {}
                }
            }
            if (window.currentViewingDriverId && document.getElementById('driver-profile-modal') && document.getElementById('driver-profile-modal').style.display === 'flex') {
                renderDriverProfileLists();
            }
            maybePrefetchDriverHistories();
        }
        window.renderDeliveries = renderDeliveries;

        window.currentViewingDriverId = 0;
        function openDriverProfile(id) {
            var drv = activeDeliveryDrivers().find(function (x) { return Number(x.id) === Number(id); });
            if (!drv) {
                if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('del_empty_drivers') : 'سایێق نەهاتە دیتن', 'error');
                return;
            }
            window.currentViewingDriverId = Number(drv.id);
            var modal = document.getElementById('driver-profile-modal');
            if (!modal) return;
            var nameEl = document.getElementById('drv-p-name');
            var idEl = document.getElementById('drv-p-id');
            var phoneEl = document.getElementById('drv-p-phone');
            var noteEl = document.getElementById('drv-p-note');
            if (nameEl) nameEl.textContent = drv.name || '';
            if (idEl) idEl.textContent = drv.id != null ? ('#' + String(drv.id)) : '';
            if (phoneEl) phoneEl.textContent = drv.phone || '';
            if (noteEl) noteEl.textContent = drv.note || '';
            modal.style.display = 'flex';
            modal.style.zIndex = '2100';
            switchDriverTab('drv-active');
            renderDriverProfileLists();
            loadDriverHistoryNow(drv);
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
        }
        function closeDriverProfile() {
            var modal = document.getElementById('driver-profile-modal');
            if (modal) modal.style.display = 'none';
            window.currentViewingDriverId = 0;
            renderDeliveries();
        }
        function switchDriverTab(tabName) {
            document.querySelectorAll('#driver-profile-modal .tab-content').forEach(function (c) { c.classList.remove('active'); });
            document.querySelectorAll('#driver-profile-modal .tab-btn').forEach(function (b) { b.classList.remove('active'); });
            var pane = document.getElementById('tab-' + tabName);
            var btn = document.getElementById('tab-btn-' + tabName);
            if (pane) pane.classList.add('active');
            if (btn) btn.classList.add('active');
            if (tabName === 'drv-history' && window.currentViewingDriverId) loadDriverHistoryNow();
        }
        function renderDriverProfileLists() {
            var drv = activeDeliveryDrivers().find(function (x) { return Number(x.id) === Number(window.currentViewingDriverId); });
            if (!drv) return;
            var mine = collectDriverDeliveries(drv);
            var pending = mine.filter(function (d) { return deliveryIsPending(d); }).sort(function (a, b) { return (Number(b.id) || 0) - (Number(a.id) || 0); });
            var hold = pending.reduce(function (s, d) { return s + (parseFloat(d.total) || 0); }, 0);
            var holdEl = document.getElementById('drv-p-hold');
            var cntEl = document.getElementById('drv-p-active-count');
            if (holdEl) holdEl.textContent = (typeof formatCurrency === 'function' ? formatCurrency(hold) : hold) + ' ' + ((typeof getCurrencySymbol === 'function') ? getCurrencySymbol() : '');
            if (cntEl) cntEl.textContent = pending.length + ' ' + ((typeof t === 'function') ? t('del_kpi_active') : 'چالاک');
            renderDriverProfileActive(pending);
            paintDriverHistoryFromRows(mine);
        }
        function renderDriverProfileActive(pending) {
            var box = document.getElementById('drv-p-active-list');
            if (!box) return;
            var emptyA = (typeof t === 'function') ? t('del_empty_active') : 'چ گەهاندنێن چالاک نینن.';
            if (!pending || !pending.length) {
                var hintHist = (typeof t === 'function') ? t('del_empty_active_hint') : 'گەهاندنێن تەواوبووی ل تابا مێژوو.';
                box.innerHTML = '<div class="drv-empty-picto"><i class="fas fa-truck"></i><div>' + escapeHtml(emptyA) + '</div>' +
                    '<div style="margin-top:8px;font-size:0.9rem;opacity:.8;"><i class="fas fa-clock-rotate-left"></i> ' + escapeHtml(hintHist) + '</div></div>';
                return;
            }
            var fmtAmt = function (n, opts) {
                try {
                    if (typeof formatCurrency === 'function') return formatCurrency(n, opts);
                } catch (_eF) {}
                return String(n != null ? n : '');
            };
            box.innerHTML = pending.map(function (d) {
                return '<div class="drv-hist-card drv-hist-card--warn">' +
                    '<div class="drv-hist-ico" title="چالاک"><i class="fas fa-truck"></i></div>' +
                    '<div class="drv-hist-body">' +
                    '<div class="drv-hist-top"><b><i class="fas fa-user"></i> ' + escapeHtml(deliveryCustomerLabel(d)) + '</b>' +
                    '<span class="drv-hist-amt"><i class="fas fa-coins"></i> ' + fmtAmt(d.total, d.formatFxOpts) + '</span></div>' +
                    '<div class="drv-hist-meta"><i class="fas fa-phone"></i> ' + escapeHtml(d.phone || '') + (d.address ? ' · <i class="fas fa-location-dot"></i> ' + escapeHtml(d.address) : '') + '</div>' +
                    deliveryActionButtonsHtml(d) +
                    '</div></div>';
            }).join('');
        }
        function renderDriverProfileHistory(mine, inflight) {
            var box = document.getElementById('drv-p-history-list');
            if (!box) return;
            var statusFilterEl = document.getElementById('drv-p-history-status');
            var statusFilter = statusFilterEl ? String(statusFilterEl.value || '') : '';
            var stDel = (typeof t === 'function') ? t('del_status_delivered') : 'گەهشت';
            var stCan = (typeof t === 'function') ? t('del_status_cancelled') : 'هەلوەشاندی';
            var stRef = (typeof t === 'function') ? t('del_status_refused') : 'رەفس';
            var dl = typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ';
            var history = (mine || []).filter(function (d) {
                if (!d || deliveryIsPending(d)) return false;
                var st = String(d.status || '').toLowerCase();
                if (statusFilter && st !== statusFilter) return false;
                return true;
            }).sort(function (a, b) { return (Number(b.id) || 0) - (Number(a.id) || 0); });
            if (!history.length && inflight) {
                var loading = (typeof t === 'function') ? t('del_profile_loading') : 'داتا دهێتە بارکرن...';
                box.innerHTML = '<p class="delivery-empty-state"><i class="fas fa-spinner fa-spin"></i> ' + escapeHtml(loading) + '</p>';
                return;
            }
            var emptyHist = (typeof t === 'function') ? t('del_empty_history') : 'چ مێژوو نینە.';
            if (!emptyHist || emptyHist === 'del_empty_history') emptyHist = (typeof t === 'function') ? t('del_print_empty') : 'هیچ گەهاندنێک نییە';
            var fmtAmtH = function (n, opts) {
                try {
                    if (typeof formatCurrency === 'function') return formatCurrency(n, opts);
                } catch (_eFh) {}
                return String(n != null ? n : '0');
            };
            if (!history.length) {
                box.innerHTML = '<p class="delivery-empty-state">' + escapeHtml(emptyHist) + '</p>';
                return;
            }
            var html = '';
            var i;
            for (i = 0; i < history.length; i++) {
                var d = history[i];
                var st = String(d.status || '').toLowerCase();
                var stLabel = st === 'delivered' ? stDel : (st === 'refused' ? stRef : stCan);
                var stClass = st === 'delivered' ? 'ok' : (st === 'refused' ? 'warn' : 'bad');
                var when = '';
                try {
                    var rawWhen = d.settled_at || d.date;
                    var dt = (typeof parseSQLDate === 'function') ? parseSQLDate(rawWhen) : new Date(rawWhen);
                    when = (dt && !isNaN(dt.getTime())) ? dt.toLocaleString(dl) : String(rawWhen || '');
                } catch (_eW) { when = String(d.date || d.settled_at || ''); }
                var amt = fmtAmtH(d.total, d.formatFxOpts);
                html += '<div class="delivery-history-row drv-hist-row">' +
                    '<div class="delivery-history-head">' +
                    '<b>#' + escapeHtml(String(d.id || '')) + ' · ' + escapeHtml(deliveryCustomerLabel(d)) + '</b>' +
                    '<span class="delivery-history-status drv-hist-badge drv-hist-badge--' + stClass + '">' + escapeHtml(stLabel) + '</span></div>' +
                    '<div class="delivery-history-meta">' + escapeHtml(when) + '</div>' +
                    '<div class="delivery-history-total">' + escapeHtml(amt) + '</div></div>';
            }
            box.innerHTML = html;
        }
        window.openDriverProfile = openDriverProfile;
        window.closeDriverProfile = closeDriverProfile;
        window.switchDriverTab = switchDriverTab;
        window.renderDriverProfileLists = renderDriverProfileLists;
        window.renderDriverProfileHistory = function () {
            loadDriverHistoryNow();
        };
        window.setDriverHistoryFilter = function (st) {
            var sel = document.getElementById('drv-p-history-status');
            if (sel) sel.value = String(st || '');
            document.querySelectorAll('#driver-profile-modal .drv-picto-btn').forEach(function (b) {
                b.classList.toggle('active', String(b.getAttribute('data-st') || '') === String(st || ''));
            });
            loadDriverHistoryNow();
        };
        window.openDeliveryForCurrentDriver = function () {
            var id = window.currentViewingDriverId;
            if (!id) return;
            try { sessionStorage.setItem('pos_last_driver_id', String(id)); } catch (_e) {}
            if (typeof fillDeliverySelects === 'function') fillDeliverySelects();
            var sel = document.getElementById('del-driver-id');
            if (sel) sel.value = String(id);
            if (typeof onDeliveryDriverChange === 'function') onDeliveryDriverChange();
            if (typeof openDeliveryModal === 'function') openDeliveryModal();
        };
        window.editDriverFromProfile = function () {
            var id = window.currentViewingDriverId;
            closeDriverProfile();
            if (id && typeof editDriver === 'function') editDriver(id);
        };

        function restoreDeliveryItemsLocal(d) {
            if (!d || !Array.isArray(d.items)) return;
            d.items.forEach(function (item) {
                const p = db.products.find(function (prod) { return prod.id === item.id; });
                if (p && p.trackStock) {
                    var f = typeof getProductUnitFactors === 'function' ? getProductUnitFactors(item) : { piecesPerPack: 1, piecesPerCarton: 1 };
                    var pToAdd = 1;
                    if (item.saleUnit === 'carton') pToAdd = f.piecesPerCarton || 1;
                    else if (item.saleUnit === 'pack') pToAdd = f.piecesPerPack || 1;
                    else pToAdd = (typeof getItemQty === 'function') ? getItemQty(item) : (item.qty || 1);
                    p.qty += pToAdd;
                }
            });
        }

        window.updateDeliveryStatus = function(id, status) {
            var msgDel = (typeof t === 'function') ? t('del_confirm_delivered_pay') : 'گەهشت — نەقد یان FIB؟';
            if (!msgDel || msgDel === 'del_confirm_delivered_pay') {
                msgDel = (typeof t === 'function') ? t('del_confirm_delivered') : 'گەهشتە دەستێ کریاری؟';
            }
            var msgCan = (typeof t === 'function') ? t('del_confirm_cancel') : 'دڵنیای ژ هەلوەشاندنێ؟';
            var msgRef = (typeof t === 'function') ? t('del_confirm_refs') : 'رەفس — مادە زڤڕیتە کۆگەهێ؟';
            var titleDel = (typeof t === 'function') ? t('del_btn_arrived') : 'گەهشت';
            var titleRef = (typeof t === 'function') ? t('del_btn_refs') : 'رەفس';
            var titleCan = (typeof t === 'function') ? t('del_btn_cancel') : 'هەلوەشاندن';
            var title = status === 'delivered' ? titleDel : (status === 'refused' ? titleRef : titleCan);
            var msg = status === 'delivered' ? msgDel : (status === 'refused' ? msgRef : msgCan);
            var dRow = (db.deliveries || []).find(function (x) { return Number(x.id) === Number(id); });
            if (dRow) {
                var who = (typeof deliveryCustomerLabel === 'function') ? deliveryCustomerLabel(dRow) : String(dRow.customer_name || '').trim();
                var amt = (typeof formatCurrency === 'function') ? formatCurrency(dRow.total, dRow.formatFxOpts) : String(dRow.total || '');
                var bits = [];
                if (who) bits.push(who);
                if (amt) bits.push(amt);
                if (bits.length) msg = msg + '\n' + bits.join(' · ');
            }
            var tone = status === 'delivered' ? 'info' : (status === 'refused' ? 'warn' : 'danger');
            var icon = status === 'delivered' ? 'fa-truck' : (status === 'refused' ? 'fa-undo' : 'fa-times-circle');
            var cashLbl = (typeof t === 'function') ? t('del_pay_cash') : 'نەقد';
            var fibLbl = (typeof t === 'function') ? t('del_pay_fib') : 'FIB';
            if (!cashLbl || cashLbl === 'del_pay_cash') cashLbl = (typeof t === 'function') ? t('payment_tab_cash') : 'نەقد';
            if (!fibLbl || fibLbl === 'del_pay_fib') fibLbl = 'FIB';
            var go = function (payMethod) { applyDeliveryStatusUpdate(id, status, payMethod); };
            if (typeof posConfirm === 'function') {
                var opts = {
                    title: title,
                    message: msg,
                    tone: tone,
                    icon: icon,
                    confirmText: title,
                    cancelText: (typeof t === 'function') ? t('btn_cancel') : 'پاشگەزبوون'
                };
                if (status === 'delivered') {
                    opts.choices = [
                        { id: 'cash', label: cashLbl, className: 'btn-success' },
                        { id: 'fib', label: fibLbl, className: 'btn-brand' }
                    ];
                }
                posConfirm(opts).then(function (choice) {
                    if (!choice) return;
                    if (status !== 'delivered') {
                        go('');
                        return;
                    }
                    var pay = (choice === 'fib' || choice === 'bank' || choice === 'card') ? 'fib' : 'cash';
                    go(pay);
                });
            } else {
                if (!confirm(msg)) return;
                go(status === 'delivered' ? 'cash' : '');
            }
        };
        function applyDeliveryStatusUpdate(id, status, payMethod) {
            var method = (payMethod === 'fib' || payMethod === 'bank' || payMethod === 'card') ? 'fib' : 'cash';
            const formData = new FormData();
            formData.append('action', 'update_delivery');
            formData.append('id', id);
            formData.append('status', status);
            if (status === 'delivered') formData.append('payment_method', method);
            fetch('?action=update_delivery', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                if(data.status === 'success') {
                    const d = db.deliveries.find(x => Number(x.id) === Number(id));
                    if(d) {
                        d.status = status;
                        if (data.settled_at) d.settled_at = data.settled_at;
                        if (data.sale_id) d.sale_id = data.sale_id;
                    }
                    var cacheMap = window._posDriverDeliveryCache || {};
                    Object.keys(cacheMap).forEach(function (ck) {
                        (cacheMap[ck] || []).forEach(function (row) {
                            if (row && Number(row.id) === Number(id)) {
                                row.status = status;
                                if (data.settled_at) row.settled_at = data.settled_at;
                                if (data.sale_id) row.sale_id = data.sale_id;
                            }
                        });
                    });

                    if(status === 'delivered' && data.sale_id && d) {
                        var settledMethod = (data.payment_method === 'fib') ? 'fib' : method;
                        if (!db.sales) db.sales = [];
                        db.sales.push({
                            id: data.sale_id,
                            total: d.total,
                            items: d.items,
                            date: data.date,
                            cashier: 'Driver: ' + d.driver,
                            discount: 0,
                            payment_method: settledMethod,
                            paid_cash: settledMethod === 'fib' ? 0 : d.total,
                            paid_bank: settledMethod === 'fib' ? d.total : 0,
                            bank_amount: settledMethod === 'fib' ? d.total : 0,
                            paid_amount: d.total,
                            customer_id: d.customer_id || 0
                        });
                        if (typeof updateStats === 'function') updateStats();
                    }
                    if (status === 'cancelled' || status === 'refused') {
                        restoreDeliveryItemsLocal(d);
                    }

                    renderDeliveries();
                    var wh = document.getElementById('view-warehouse');
                    if (wh && wh.classList.contains('active') && typeof renderWarehouse === 'function') renderWarehouse();
                } else if (data && data.message) {
                    if (typeof showToast === 'function') showToast(data.message, 'error');
                }
            });
        }

        window.printDeliverySlip = function(id) {
            const d = db.deliveries.find(x => x.id === id);
            if(!d) return;
            const dc = getPrintConfig('delivery_slip');
            const thermalFontClasses = typeof getThermalFontClasses === 'function' ? getThermalFontClasses() : '';
            let html = `
            <div class="print-thermal-container design-${dc.design || '1'}${thermalFontClasses}" style="max-width: ${dc.paper}; width: 100%; font-family: 'Rudaw', sans-serif; direction:rtl;">
                <div style="text-align:center; border-bottom: 1px solid #000; padding-bottom: 10px; margin-bottom: 10px;">
                    <h2 style="margin:0; font-size:1.4rem;">${typeof t === 'function' ? t('print_delivery_slip') : 'پسوولەیا بەریدانێ'}</h2>
                    ${d.delivery_cost > 0 ? `<p style="margin:5px 0; font-weight:bold;">${typeof t === 'function' ? t('view_delivery_title') : 'گەهاندن'}: ${formatCurrency(d.delivery_cost)}</p>` : ''}
                    <h3 style="margin:5px 0; background:#000; color:white; padding:5px; border-radius:5px;">${formatCurrency(d.total, d.formatFxOpts)} ${getCurrencySymbol()}</h3>
                </div>

                <div style="text-align:right; margin-bottom: 10px; border-bottom: 1px dotted #000; padding-bottom: 5px;">
                    <div style="font-size:0.8rem; color:#555;">${typeof t === 'function' ? t('print_customer') : 'کریار'}:</div>
                    <div style="font-weight:bold; font-size:1.1rem;">${escapeHtml(deliveryCustomerLabel(d))}</div>
                    <div>📞 ${escapeHtml(d.phone)}</div>
                    <div>📍 ${escapeHtml(d.address)}</div>
                </div>

                <div style="text-align:right; margin-bottom: 10px; border-bottom: 1px dotted #000; padding-bottom: 5px;">
                    <div style="font-size:0.8rem; color:#555;">${typeof t === 'function' ? t('print_driver') : 'زانیاریێن شۆفێری'}</div>
                    <div style="font-weight:bold; font-size:1.1rem;">🚗 ${escapeHtml(d.driver)}</div>
                    <div>📞 ${escapeHtml(d.driver_phone || '-')}</div>
                </div>

                ${d.note ? `
                <div style="text-align:center; margin-bottom: 10px; padding: 5px; font-style:italic;">
                    <b>${typeof t === 'function' ? escapeHtml(t('del_slip_note_label')) : 'تێبینی:'}</b> ${escapeHtml(d.note)}
                </div>` : ''}

                <div style="text-align:center; font-size:0.8rem; margin-top: 15px;">
                    <p>${new Date(d.date).toLocaleString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ')}</p>
                    <p>${typeof t === 'function' ? escapeHtml(t('del_slip_thanks')) : '*** سوپاس بۆ هەوە ***'}</p>
                    ${typeof buildPosReceiptBrandFooterHtml === 'function' ? buildPosReceiptBrandFooterHtml() : ''}
                </div>
            </div>`;
            routePrint('delivery_slip', html, { docId: String(d.id || ''), details: 'delivery-slip' });
        }
        window.printDeliverySlipA4 = function (id) {
            if (typeof printDeliverySlip === 'function') printDeliverySlip(id);
        };

