/**
 * POS → Supabase mobile sync (dual-write with Firebase during migration).
 * Requires: supabase_mobile_config.js, firebase_cashier_sync.js (payload hook).
 */
(function () {
    if (window.__posSupabaseMobileSyncLoaded) return;
    window.__posSupabaseMobileSyncLoaded = true;

    var LS_SB_LAST = "pos_supabase_mobile_last_sync_ms";
    var LS_SB_ERR = "pos_supabase_mobile_last_err";
    var sbClient = null;
    var sbLoadPromise = null;

    function cfg() {
        return window.POS_SUPABASE_MOBILE || null;
    }

    function enabled() {
        var c = cfg();
        return !!(c && c.enabled && c.url && c.anonKey);
    }

    function loadClient() {
        if (!enabled()) return Promise.reject(new Error("supabase_mobile_disabled"));
        if (sbClient) return Promise.resolve(sbClient);
        if (sbLoadPromise) return sbLoadPromise;
        sbLoadPromise = import("https://esm.sh/@supabase/supabase-js@2.49.1")
            .then(function (mod) {
                var c = cfg();
                sbClient = mod.createClient(c.url, c.anonKey, {
                    auth: {
                        persistSession: true,
                        autoRefreshToken: true,
                        detectSessionInUrl: false
                    }
                });
                return sbClient;
            })
            .catch(function (err) {
                sbLoadPromise = null;
                throw err;
            });
        return sbLoadPromise;
    }

    function stripFirestoreFields(obj) {
        if (!obj || typeof obj !== "object") return obj;
        if (Array.isArray(obj)) return obj.map(stripFirestoreFields);
        var out = {};
        Object.keys(obj).forEach(function (k) {
            var v = obj[k];
            if (v && typeof v === "object" && v._methodName === "serverTimestamp") {
                out[k] = new Date().toISOString();
            } else if (v && typeof v === "object" && typeof v.toDate === "function") {
                out[k] = v.toDate().toISOString();
            } else {
                out[k] = stripFirestoreFields(v);
            }
        });
        return out;
    }

    window.posSupabaseMobileSignIn = function (email, password) {
        var em = String(email || "").trim().toLowerCase();
        return loadClient().then(function (client) {
            return client.auth.signInWithPassword({ email: em, password: password || "" });
        });
    };

    window.posSupabaseMobileSignOut = function () {
        if (!sbClient) return Promise.resolve();
        return sbClient.auth.signOut();
    };

    window.pushSupabaseMobileSnapshot = function (ctx) {
        if (!enabled() || !ctx || !ctx.channelId) {
            return Promise.resolve({ skipped: true, reason: "disabled" });
        }
        return loadClient()
            .then(function (client) {
                return client.auth.getSession().then(function (res) {
                    var session = res && res.data && res.data.session;
                    var em = ctx.channelId;
                    if (!session || !session.user || String(session.user.email || "").toLowerCase() !== em) {
                        return { skipped: true, reason: "not_authed" };
                    }
                    var jobs = [];
                    if (ctx.dashPayload) {
                        jobs.push(
                            client.from("pos_mobile_dashboard").upsert(
                                {
                                    channel_id: em,
                                    data: stripFirestoreFields(ctx.dashPayload)
                                },
                                { onConflict: "channel_id" }
                            )
                        );
                    }
                    if (ctx.detailPayload && ctx.businessDate) {
                        jobs.push(
                            client.from("pos_mobile_daily_detail").upsert(
                                {
                                    channel_id: em,
                                    day_key: ctx.businessDate,
                                    data: stripFirestoreFields(ctx.detailPayload)
                                },
                                { onConflict: "channel_id,day_key" }
                            )
                        );
                    }
                    if (ctx.invPayload) {
                        jobs.push(
                            client.from("pos_mobile_inventory").upsert(
                                {
                                    channel_id: em,
                                    data: stripFirestoreFields(ctx.invPayload)
                                },
                                { onConflict: "channel_id" }
                            )
                        );
                    }
                    if (ctx.debtPayload) {
                        jobs.push(
                            client.from("pos_mobile_debt").upsert(
                                {
                                    channel_id: em,
                                    data: stripFirestoreFields(ctx.debtPayload)
                                },
                                { onConflict: "channel_id" }
                            )
                        );
                    }
                    if (!jobs.length) return { skipped: true, reason: "no_payload" };
                    return Promise.all(jobs).then(function (results) {
                        var err = null;
                        (results || []).forEach(function (r) {
                            if (r && r.error) err = r.error;
                        });
                        if (err) throw err;
                        var now = Date.now();
                        try {
                            localStorage.setItem(LS_SB_LAST, String(now));
                            localStorage.removeItem(LS_SB_ERR);
                        } catch (e) {}
                        return { ok: true };
                    });
                });
            })
            .catch(function (err) {
                try {
                    localStorage.setItem(LS_SB_ERR, String(err && err.message ? err.message : err));
                } catch (e) {}
                return { ok: false, error: err };
            });
    };

    /** Called from firebase login — same email/password as Firebase mobile account */
    window.posSupabaseMobileMirrorFirebaseLogin = function (email, password) {
        if (!enabled()) return Promise.resolve({ skipped: true });
        return window.posSupabaseMobileSignIn(email, password).catch(function () {
            return { ok: false };
        });
    };

    window.posSupabaseMobileMirrorFirebaseLogout = function () {
        return window.posSupabaseMobileSignOut().catch(function () {});
    };
})();
