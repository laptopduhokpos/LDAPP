// sales/qty-cart.js — qty, cart totals, product grid
        var getDefaultUnitLabel = window.getDefaultUnitLabel;
        var getProductUnitLabel = window.getProductUnitLabel;
        function getProductByIdSafe(productId) {
            var pid = normalizeProductId(productId);
            if (isNaN(pid) || !db || !Array.isArray(db.products)) return null;
            return db.products.find(function(p) { return normalizeProductId(p.id) === pid; }) || null;
        }
        function productHasRecipe(productId) {
            if (productId == null || !db || !Array.isArray(db.recipes)) return false;
            return db.recipes.some(function(r) { return String(r.product_id) === String(productId); });
        }
        function normalizeRecipeSaleMode(mode) {
            var m = String(mode || 'auto').toLowerCase().trim();
            return (m === 'direct' || m === 'manufacture' || m === 'auto') ? m : 'auto';
        }
        function getRecipeSaleModeLabel(mode) {
            mode = normalizeRecipeSaleMode(mode);
            if (mode === 'direct') {
                return (typeof t === 'function') ? t('recipe_sale_mode_direct_short') : 'راستەوخو';
            }
            if (mode === 'manufacture') {
                return (typeof t === 'function') ? t('recipe_sale_mode_manufacture_short') : 'دروستکردن';
            }
            return (typeof t === 'function') ? t('recipe_sale_mode_auto_short') : 'خۆکار';
        }
        window.productHasRecipe = productHasRecipe;
        window.normalizeRecipeSaleMode = normalizeRecipeSaleMode;
        window.getRecipeSaleModeLabel = getRecipeSaleModeLabel;

        function getSaleItemUnitSuffix(item, opts) {
            opts = opts || {};
            var unit = (item && item.saleUnit) ? item.saleUnit : 'piece';
            var prod = (item && item.productRef) ? item.productRef : getProductByIdSafe(item ? item.id : null);
            var res = '';
            if (!opts.skipUnitSuffix && unit !== 'piece') {
                res += ' (' + getProductUnitLabel(prod, unit) + ')';
            }
            if (!opts.skipPriceTypeLabel && prod && item && !item.isGift) {
                var twP = 0;
                if (unit === 'carton' && prod.takeawayPrice_carton) twP = Number(prod.takeawayPrice_carton);
                else if (unit === 'pack' && prod.takeawayPrice_pack) twP = Number(prod.takeawayPrice_pack);
                else if (prod.takeawayPrice) twP = Number(prod.takeawayPrice);
                
                if (twP > 0 && item.price != null) {
                    var lineIqd = typeof getBillLineUnitIqd === 'function' ? getBillLineUnitIqd(item) : (Number(item.price) || 0);
                    if (Math.round(lineIqd) === Math.round(twP)) {
                        var altLbl = (db.settings && db.settings.takeawayAsWholesale)
                            ? ((typeof t === 'function') ? t('settings_jumla_mode_jumla') : 'جوملە')
                            : ((typeof t === 'function') ? t('settings_jumla_mode_sefari') : 'سەفەری');
                        res += ' <span style="font-size:0.85em; font-weight:bold; color:var(--brand);">(' + altLbl + ')</span>';
                    }
                }
                if (item.isWholesale && prod && (Number(prod.wholesalePrice) || 0) > 0) {
                    var lineIqdW = typeof getBillLineUnitIqd === 'function' ? getBillLineUnitIqd(item) : (Number(item.price) || 0);
                    if (Math.round(lineIqdW) === Math.round(Number(prod.wholesalePrice))) {
                        res += ' <span style="font-size:0.85em; font-weight:bold; color:var(--brand);">(جوملە)</span>';
                    }
                }
            }
            if (!opts.skipRecipeModeLabel && item && item.id != null && typeof productHasRecipe === 'function' && productHasRecipe(item.id)) {
                var rMode = normalizeRecipeSaleMode(item.recipeSaleMode || (prod && prod.recipe_sale_mode));
                res += ' <span style="font-size:0.85em; font-weight:bold; color:#64748b;">(' + getRecipeSaleModeLabel(rMode) + ')</span>';
            }
            return res;
        }
        function getSaleItemPlainName(itemOrName) {
            var name = (itemOrName && typeof itemOrName === 'object') ? String(itemOrName.name || '') : String(itemOrName || '');
            return name.replace(/<[^>]*>/g, '').replace(/\s+/g, ' ').trim();
        }
        function formatSaleItemNameHtml(item, opts) {
            var plain = getSaleItemPlainName(item);
            var html = escapeHtml(plain);
            if (item && typeof getSaleItemUnitSuffix === 'function') html += getSaleItemUnitSuffix(item, opts);
            if (item && typeof jewelryMetaLabel === 'function') {
                var jMeta = jewelryMetaLabel(item);
                if (jMeta) html += ' <span style="font-size:0.82em;color:#a67c00;">[' + escapeHtml(jMeta) + ']</span>';
            }
            if (item && item.isGift) {
                html += ' <span style="font-size:0.85em;font-weight:bold;">(دیاری)</span>';
            }
            return html;
        }
        if (typeof window !== 'undefined') {
            window.getSaleItemPlainName = getSaleItemPlainName;
            window.formatSaleItemNameHtml = formatSaleItemNameHtml;
        }
        function isWeightProduct(prod) {
            if (!prod || typeof prod !== 'object') return false;
            if (typeof getProductQtyMode === 'function') return getProductQtyMode(prod) === 'kilo';
            var showPack = Number(prod.unit_show_pack || 0) === 1;
            var showCarton = Number(prod.unit_show_carton || 0) === 1;
            return !showPack && !showCarton;
        }
        function getItemQty(item) {
            if (!item || typeof item !== 'object') return 1;
            var raw = item.qty !== undefined && item.qty !== null ? item.qty : item.count;
            var q = Number(raw);
            return (!isNaN(q) && q > 0) ? q : 1;
        }
        function normalizeQtyForProduct(prod, qtyRaw, allowNegative) {
            var n = parseFloat(qtyRaw);
            if (isNaN(n)) return 0;
            if (n < 0 && !allowNegative) return 0;
            if (isWeightProduct(prod)) return Math.round(n * 1000) / 1000;
            return n < 0 ? Math.ceil(n) : Math.floor(n);
        }
        function getKiloQtyPresets() {
            return [0.25, 0.5, 0.75, 1];
        }
        function applyKiloPresetToQty(prod, qtyRaw) {
            return normalizeQtyForProduct(prod, qtyRaw);
        }
        function renderKiloQtyPresetChips(prod, onPickBuilder) {
            if (!isWeightProduct(prod) || typeof onPickBuilder !== 'function') return '';
            return '<div class="kilo-qty-presets" style="display:flex; gap:4px; margin-top:4px; flex-wrap:wrap;">' + getKiloQtyPresets().map(function(v) {
                var clickJs = onPickBuilder(v);
                return '<button type="button" style="border:1px solid var(--border); background:var(--card); color:var(--text); border-radius:6px; padding:2px 6px; font-size:11px; cursor:pointer;" onclick="' + clickJs + '">' + v.toFixed(2) + '</button>';
            }).join('') + '</div>';
        }
        window.getKiloQtyPresets = getKiloQtyPresets;
        window.applyKiloPresetToQty = applyKiloPresetToQty;
        window.renderKiloQtyPresetChips = renderKiloQtyPresetChips;
        function formatQtyForDisplay(qty, prodOrItem) {
            var n = Number(qty);
            if (!isFinite(n)) n = 0;
            var prod = (prodOrItem && prodOrItem.productRef) ? prodOrItem.productRef : prodOrItem;
            // Always show decimals if they exist, otherwise show integer
            if (n % 1 !== 0 || isWeightProduct(prod)) {
                return String(parseFloat(n.toFixed(3)));
            }
            return String(Math.round(n));
        }
        function formatQtyForInput(qty, prodOrItem) {
            var n = Number(qty);
            if (!isFinite(n) || n < 0) n = 0;
            var prod = (prodOrItem && prodOrItem.productRef) ? prodOrItem.productRef : prodOrItem;
            if (isWeightProduct(prod) || n % 1 !== 0) {
                return parseFloat(n.toFixed(3)).toString();
            }
            return String(Math.round(n));
        }
        function parseQtyPromptValue(value) {
            var n = parseFloat(String(value == null ? '' : value).trim());
            if (!isFinite(n) || n < 0) return null;
            return n;
        }
        function parsePosPromptMoneyValue(value) {
            if (typeof parseCcEditMoneyField === 'function') {
                return Math.max(0, parseCcEditMoneyField(value));
            }
            var kind = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD') ? 'usd' : 'iqd';
            if (typeof parseAmountInput === 'function') return Math.max(0, parseAmountInput(value, kind));
            var n = parseFloat(String(value == null ? '' : value).replace(/,/g, '').trim());
            return (isFinite(n) && n >= 0) ? n : 0;
        }
        function formatPosPromptMoneyValue(value) {
            var n = parsePosPromptMoneyValue(value);
            var usd = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
            if (usd) return (n % 1 !== 0) ? String(parseFloat(n.toFixed(2))) : String(Math.round(n));
            return String(Math.round(n));
        }
        function getPosQtyPromptStep() {
            if (window._posQtyPromptMode === 'money') {
                return (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD') ? 1 : 1000;
            }
            return 1;
        }
        function renderPosQtyPromptQuickButtons(mode) {
            var container = document.getElementById('pos-qty-prompt-quick');
            if (!container) return;
            if (mode === 'money') {
                var usd = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
                var presets = usd ? [0, 50, 100, 500] : [0, 50000, 100000, 500000];
                container.innerHTML = presets.map(function(v) {
                    var label = (typeof formatCurrency === 'function') ? formatCurrency(v) : String(v);
                    return '<button type="button" class="btn btn-dark pos-qty-quick-btn" onclick="setPosQtyPromptValue(' + v + ')">' + label + '</button>';
                }).join('');
                return;
            }
            container.innerHTML = ''
                + '<button type="button" class="btn btn-dark pos-qty-quick-btn" onclick="adjustPosQtyPrompt(-0.25)">−0.25</button>'
                + '<button type="button" class="btn btn-dark pos-qty-quick-btn" onclick="adjustPosQtyPrompt(0.25)">+0.25</button>'
                + '<button type="button" class="btn btn-dark pos-qty-quick-btn" onclick="setPosQtyPromptValue(0.5)">0.5</button>'
                + '<button type="button" class="btn btn-dark pos-qty-quick-btn" onclick="setPosQtyPromptValue(1)">1</button>';
        }
        function syncPosQtyPromptStepLabels() {
            var step = getPosQtyPromptStep();
            var minus = document.getElementById('pos-qty-step-minus');
            var plus = document.getElementById('pos-qty-step-plus');
            var iconWrap = document.getElementById('pos-qty-prompt-icon-wrap');
            var iconI = document.getElementById('pos-qty-prompt-icon-i');
            var modal = document.getElementById('pos-qty-prompt-modal');
            var isMoney = window._posQtyPromptMode === 'money';
            if (minus) minus.textContent = '−' + (isMoney && step >= 1000 ? (step / 1000) + 'K' : step);
            if (plus) plus.textContent = '+' + (isMoney && step >= 1000 ? (step / 1000) + 'K' : step);
            if (iconI) iconI.className = 'fas ' + (isMoney ? 'fa-coins' : 'fa-balance-scale');
            if (iconWrap && modal) modal.classList.toggle('pos-qty-prompt-modal--money', isMoney);
        }
        function resetPosQtyPromptMode() {
            window._posQtyPromptMode = 'qty';
            renderPosQtyPromptQuickButtons('qty');
            syncPosQtyPromptStepLabels();
        }
        window.posQtyPromptStepDown = function() { adjustPosQtyPrompt(-getPosQtyPromptStep()); };
        window.posQtyPromptStepUp = function() { adjustPosQtyPrompt(getPosQtyPromptStep()); };
        function openPosQtyPromptInternal(title, hint, defaultVal, onApply, mode) {
            var modal = document.getElementById('pos-qty-prompt-modal');
            var input = document.getElementById('pos-qty-prompt-input');
            if (!modal || !input) return false;
            window._posQtyPromptMode = mode === 'money' ? 'money' : 'qty';
            renderPosQtyPromptQuickButtons(window._posQtyPromptMode);
            syncPosQtyPromptStepLabels();
            var titleEl = document.getElementById('pos-qty-prompt-title');
            var hintEl = document.getElementById('pos-qty-prompt-hint');
            if (titleEl) titleEl.textContent = title || '';
            if (hintEl) hintEl.textContent = hint || '';
            window._posQtyPromptCallback = onApply;
            input.value = defaultVal;
            modal.style.display = 'flex';
            input.onkeydown = function(e) {
                if (e.key === 'Enter') { e.preventDefault(); window.confirmPosQtyPrompt(); }
                if (e.key === 'Escape') { e.preventDefault(); window.cancelPosQtyPrompt(); }
            };
            setTimeout(function() { input.focus(); input.select(); }, 50);
            return true;
        }
        window.openManualQtyPrompt = function(title, currentQty, onApply) {
            var defaultVal = formatQtyForInput(currentQty);
            var modal = document.getElementById('pos-qty-prompt-modal');
            var input = document.getElementById('pos-qty-prompt-input');
            if (!modal || !input) {
                var raw = prompt(title || 'Enter quantity', defaultVal);
                if (raw === null) return false;
                var parsedFallback = parseQtyPromptValue(raw);
                if (parsedFallback === null) return false;
                if (typeof onApply === 'function') onApply(parsedFallback);
                return true;
            }
            var displayTitle = title;
            if (!displayTitle && typeof t === 'function') displayTitle = t('pos_qty_prompt_title');
            if (!displayTitle) displayTitle = 'ژمارە بنووسە';
            var displayHint = (typeof t === 'function') ? t('pos_qty_prompt_hint') : 'تا ٣ ژمارە دوای فاریزە (نموونە: ١.٢٥٠)';
            return openPosQtyPromptInternal(displayTitle, displayHint, defaultVal, onApply, 'qty');
        };
        window.openPosMoneyPrompt = function(opts) {
            opts = opts || {};
            var tFn = function(k, fb) {
                if (typeof t !== 'function') return fb || k;
                var v = t(k);
                return (v && v !== k) ? v : (fb || k);
            };
            var title = opts.title || tFn('pos_money_prompt_title', 'بڕی پارە بنووسە');
            var hint = opts.hint || tFn('pos_money_prompt_hint', 'ژمارە بنووسە یان دوگمەکان بەکاربێنە');
            var defaultVal = formatPosPromptMoneyValue(opts.value != null ? opts.value : 0);
            var modal = document.getElementById('pos-qty-prompt-modal');
            if (!modal) {
                var raw = prompt(title, defaultVal);
                if (raw === null) return false;
                if (typeof opts.onApply === 'function') opts.onApply(parsePosPromptMoneyValue(raw));
                return true;
            }
            return openPosQtyPromptInternal(title, hint, defaultVal, opts.onApply, 'money');
        };
        window.cancelPosQtyPrompt = function() {
            var modal = document.getElementById('pos-qty-prompt-modal');
            if (modal) modal.style.display = 'none';
            window._posQtyPromptCallback = null;
            window._posEntityMoneyPickerOpen = false;
            resetPosQtyPromptMode();
        };
        window.confirmPosQtyPrompt = function() {
            var modal = document.getElementById('pos-qty-prompt-modal');
            var input = document.getElementById('pos-qty-prompt-input');
            if (!input) return;
            var isMoney = window._posQtyPromptMode === 'money';
            var parsed = isMoney ? parsePosPromptMoneyValue(input.value) : parseQtyPromptValue(input.value);
            if (parsed === null) {
                if (typeof showToast === 'function') {
                    showToast((typeof t === 'function')
                        ? t(isMoney ? 'pos_money_prompt_invalid' : 'pos_qty_prompt_invalid')
                        : 'ژمارەیا نادروست', 'warning');
                }
                input.focus();
                input.select();
                return;
            }
            if (modal) modal.style.display = 'none';
            var cb = window._posQtyPromptCallback;
            window._posQtyPromptCallback = null;
            resetPosQtyPromptMode();
            if (typeof cb === 'function') cb(parsed);
        };
        window.adjustPosQtyPrompt = function(delta) {
            var input = document.getElementById('pos-qty-prompt-input');
            if (!input) return;
            if (window._posQtyPromptMode === 'money') {
                var cur = parsePosPromptMoneyValue(input.value);
                var next = Math.max(0, cur + delta);
                input.value = formatPosPromptMoneyValue(next);
                input.focus();
                return;
            }
            var n = parseQtyPromptValue(input.value);
            if (n === null) n = 0;
            n = Math.max(0, parseFloat((n + delta).toFixed(3)));
            input.value = (n % 1 !== 0) ? parseFloat(n.toFixed(3)).toString() : String(Math.round(n));
            input.focus();
        };
        window.setPosQtyPromptValue = function(value) {
            var input = document.getElementById('pos-qty-prompt-input');
            if (!input) return;
            if (window._posQtyPromptMode === 'money') {
                input.value = formatPosPromptMoneyValue(value);
                input.focus();
                input.select();
                return;
            }
            var n = parseQtyPromptValue(value);
            if (n === null) n = 0;
            input.value = (n % 1 !== 0) ? parseFloat(n.toFixed(3)).toString() : String(Math.round(n));
            input.focus();
            input.select();
        };
        if (typeof document !== 'undefined') {
            var bootQtyQuick = function() {
                if (typeof renderPosQtyPromptQuickButtons === 'function') renderPosQtyPromptQuickButtons('qty');
            };
            if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bootQtyQuick);
            else bootQtyQuick();
        }

        window.openPosEntityNamePrompt = function(opts) {
            opts = opts || {};
            var modal = document.getElementById('pos-entity-name-modal');
            var nameInput = document.getElementById('pos-entity-name-input');
            var phoneInput = document.getElementById('pos-entity-phone-input');
            var addressInput = document.getElementById('pos-entity-address-input');
            var openingInput = document.getElementById('pos-entity-opening-input');
            var limitInput = document.getElementById('pos-entity-limit-input');
            var debtRow = document.getElementById('pos-entity-debt-row');
            var contactSection = document.getElementById('pos-entity-contact-section');
            var contactRow = document.getElementById('pos-entity-contact-row');
            var cardEl = modal ? modal.querySelector('.pos-entity-name-card') : null;
            var titleEl = document.getElementById('pos-entity-name-title');
            var hintEl = document.getElementById('pos-entity-name-hint');
            var nameLabelEl = document.getElementById('pos-entity-name-label');
            var addressLabelEl = document.getElementById('pos-entity-address-label');
            var iconWrap = document.getElementById('pos-entity-name-icon');
            var onConfirm = opts.onConfirm;
            var defaultValue = opts.defaultValue != null ? String(opts.defaultValue) : '';
            var entityType = opts.entityType === 'table' ? 'table'
                : (opts.entityType === 'supplier' ? 'supplier'
                : (opts.entityType === 'manufacturer' ? 'manufacturer'
                : (opts.entityType === 'category' ? 'category' : 'customer')));
            var title = opts.title;
            var hint = opts.hint;
            var placeholder = opts.placeholder;
            var iconClass = opts.icon || (entityType === 'table' ? 'fa-chair'
                : (entityType === 'supplier' ? 'fa-building'
                : (entityType === 'manufacturer' ? 'fa-industry'
                : (entityType === 'category' ? 'fa-tags' : 'fa-user-plus'))));
            var iconTone = opts.iconTone || entityType;
            var tFn = function(k, fb) {
                if (typeof t !== 'function') return fb || k;
                var v = t(k);
                return (v && v !== k) ? v : (fb || k);
            };
            if (!title) {
                if (entityType === 'table') title = tFn('pos_entity_table_title', 'زێدەکرنا مێزێ نوێ');
                else if (entityType === 'supplier') title = tFn('pos_entity_supplier_title', 'زێدەکرنا دابینکەر / کۆمپانیێ نوێ');
                else if (entityType === 'manufacturer') title = tFn('pos_entity_manufacturer_title', 'زێدەکرنا کۆمپانیا دروستکەر');
                else if (entityType === 'category') title = tFn('pos_entity_category_title', 'زێدەکرنا پۆلێ نوێ');
                else title = tFn('pos_entity_customer_title', 'زێدەکرنا کڕیارێ نوێ');
            }
            if (!hint) {
                if (entityType === 'table') hint = tFn('pos_entity_table_hint', 'ناڤێ مێزێ بنووسە — نموونە: مێز ٥، VIP');
                else if (entityType === 'supplier') hint = tFn('pos_entity_supplier_hint', 'ناڤ، تەلەفۆن، ناڤنیشان و داتایێن قەرز بنووسە.');
                else if (entityType === 'manufacturer') hint = tFn('pos_entity_manufacturer_hint', 'ناڤ، تەلەفۆن و تێبینی بنووسە — جیا لە کۆمپانیای کڕین.');
                else if (entityType === 'category') hint = tFn('pos_entity_category_hint', 'ناڤێ پۆلێ بنووسە — دواتر دێ هەڵبژێردرێت بۆ ئەڤ ئایتمی.');
                else hint = tFn('pos_entity_customer_hint', 'ناڤ، تەلەفۆن، ناڤنیشان و داتایێن قەرز بنووسە.');
            }
            if (!placeholder) {
                if (entityType === 'table') placeholder = tFn('pos_entity_table_placeholder', 'نموونە: مێز ٥');
                else if (entityType === 'supplier') placeholder = tFn('pos_entity_supplier_placeholder', 'ناڤ...');
                else if (entityType === 'manufacturer') placeholder = tFn('pos_entity_manufacturer_placeholder', 'نموونە: Samsung');
                else if (entityType === 'category') placeholder = tFn('pos_entity_category_placeholder', 'نموونە: خواردن، جلوبرگ');
                else placeholder = tFn('pos_entity_customer_placeholder', 'ناڤ...');
            }
            if (!modal || !nameInput) {
                var raw = prompt(title, defaultValue);
                if (raw === null || !String(raw).trim()) return false;
                if (typeof onConfirm === 'function') {
                    if (entityType === 'manufacturer') onConfirm({ name: String(raw).trim(), phone: '', note: '' });
                    else if (entityType === 'category' || entityType === 'table') onConfirm({ name: String(raw).trim() });
                    else onConfirm({ name: String(raw).trim(), phone: '', address: '', opening_balance: 0, debt_limit: 0 });
                }
                return true;
            }
            window._posEntityPromptType = entityType;
            if (titleEl) titleEl.textContent = title;
            if (hintEl) hintEl.textContent = hint;
            if (nameLabelEl) {
                if (entityType === 'table') nameLabelEl.textContent = tFn('pos_entity_table_label', 'ناڤێ مێز');
                else if (entityType === 'supplier') nameLabelEl.textContent = tFn('comp_name_ph', 'ناڤێ کۆمپانیێ');
                else if (entityType === 'manufacturer') nameLabelEl.textContent = tFn('mfr_name_ph', 'ناوی کۆمپانیا دروستکەر');
                else if (entityType === 'category') nameLabelEl.textContent = tFn('product_form_label_category', 'پۆل');
                else nameLabelEl.textContent = tFn('debt_new_name_ph', 'ناڤێ کریاری');
            }
            if (addressLabelEl) {
                if (entityType === 'manufacturer') {
                    addressLabelEl.textContent = tFn('mfr_note_ph', 'تێبینی (ئارەزوومەندانە)');
                } else {
                    addressLabelEl.textContent = tFn('debt_new_address_ph', 'ناڤنیشان');
                }
            }
            if (debtRow) {
                var hideDebt = entityType === 'manufacturer' || entityType === 'category' || entityType === 'table';
                debtRow.classList.toggle('is-hidden', hideDebt);
                if (hideDebt) debtRow.setAttribute('hidden', 'hidden');
                else debtRow.removeAttribute('hidden');
            }
            if (contactSection) contactSection.classList.toggle('is-hidden', entityType === 'category' || entityType === 'table');
            if (cardEl) {
                cardEl.className = 'glass-card pos-entity-name-card pos-entity-name-card--' + iconTone;
            }
            if (iconWrap) {
                iconWrap.className = 'pos-entity-name-icon pos-entity-name-icon--' + iconTone;
                iconWrap.innerHTML = '<i class="fas ' + iconClass + '"></i>';
            }
            nameInput.placeholder = placeholder;
            nameInput.value = defaultValue;
            if (phoneInput) phoneInput.value = '';
            if (addressInput) {
                addressInput.value = '';
                addressInput.placeholder = entityType === 'manufacturer'
                    ? tFn('mfr_note_ph', 'تێبینی (ئارەزوومەندانە)')
                    : tFn('debt_new_address_ph', 'ناڤنیشان');
            }
            if (openingInput) openingInput.value = '0';
            if (limitInput) limitInput.value = '0';
            var ptValEl = document.getElementById('pos-entity-payment-term-value');
            var ptUnitEl = document.getElementById('pos-entity-payment-term-unit');
            if (ptValEl) ptValEl.value = '0';
            if (ptUnitEl) ptUnitEl.value = 'day';
            if (entityType !== 'manufacturer' && entityType !== 'category' && entityType !== 'table') {
                if (typeof syncPosEntityPromptMoneyPlaceholders === 'function') syncPosEntityPromptMoneyPlaceholders();
                if (typeof syncPosEntityMoneyStepLabels === 'function') syncPosEntityMoneyStepLabels();
                if (typeof renderPosEntityMoneyQuickButtons === 'function') renderPosEntityMoneyQuickButtons();
            }
            window._posEntityNamePromptCallback = onConfirm;
            modal.style.display = 'flex';
            var entityInputs = [nameInput];
            if (entityType !== 'category' && entityType !== 'table') {
                entityInputs.push(phoneInput, addressInput);
            }
            if (entityType !== 'manufacturer' && entityType !== 'category' && entityType !== 'table') {
                entityInputs.push(openingInput, limitInput);
            }
            entityInputs = entityInputs.filter(Boolean);
            entityInputs.forEach(function(el) {
                el.onkeydown = function(e) {
                    if (e.key === 'Enter') { e.preventDefault(); window.confirmPosEntityNamePrompt(); }
                    if (e.key === 'Escape') { e.preventDefault(); window.cancelPosEntityNamePrompt(); }
                };
            });
            setTimeout(function() { nameInput.focus(); nameInput.select(); }, 50);
            return true;
        };
        window.syncPosEntityPromptMoneyPlaceholders = function() {
            var usd = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
            var unit = usd ? '$' : 'IQD';
            var tFn = function(k, fb) {
                if (typeof t !== 'function') return fb || k;
                var v = t(k);
                return (v && v !== k) ? v : (fb || k);
            };
            var obLbl = document.getElementById('pos-entity-opening-label');
            var dlLbl = document.getElementById('pos-entity-limit-label');
            var obIn = document.getElementById('pos-entity-opening-input');
            var dlIn = document.getElementById('pos-entity-limit-input');
            if (obLbl) obLbl.textContent = tFn('debt_new_opening_ph', 'دەینی کەڤن') + ' (' + unit + ')';
            if (dlLbl) dlLbl.textContent = tFn('debt_new_limit_ph', 'سنووری قەرز') + ' (' + unit + ')';
            if (obIn) obIn.placeholder = '0';
            if (dlIn) dlIn.placeholder = '0';
        };
        window.getPosEntityMoneyStep = function() {
            return (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD') ? 1 : 1000;
        };
        window.syncPosEntityMoneyStepLabels = function() {
            var step = (typeof getPosEntityMoneyStep === 'function') ? getPosEntityMoneyStep() : 1000;
            var usd = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
            var minusOpening = document.getElementById('pos-entity-opening-minus');
            var plusOpening = document.getElementById('pos-entity-opening-plus');
            var minusLimit = document.getElementById('pos-entity-limit-minus');
            var plusLimit = document.getElementById('pos-entity-limit-plus');
            var stepLabel = usd ? String(step) : ((step >= 1000) ? (step / 1000) + 'K' : String(step));
            if (minusOpening) minusOpening.textContent = '−' + stepLabel;
            if (plusOpening) plusOpening.textContent = '+' + stepLabel;
            if (minusLimit) minusLimit.textContent = '−' + stepLabel;
            if (plusLimit) plusLimit.textContent = '+' + stepLabel;
        };
        window.renderPosEntityMoneyQuickButtons = function() {
            var usd = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
            var presets = usd ? [0, 50, 100, 500] : [0, 50000, 100000, 500000];
            ['opening', 'limit'].forEach(function(field) {
                var wrap = document.getElementById('pos-entity-' + field + '-quick');
                if (!wrap) return;
                wrap.innerHTML = presets.map(function(v) {
                    var label = (typeof formatCurrency === 'function') ? formatCurrency(v) : String(v);
                    return '<button type="button" class="pos-entity-money-chip" onclick="setPosEntityMoneyField(\'' + field + '\',' + v + ')">' + label + '</button>';
                }).join('');
            });
        };
        window.adjustPosEntityMoneyField = function(field, sign) {
            var input = document.getElementById(field === 'limit' ? 'pos-entity-limit-input' : 'pos-entity-opening-input');
            if (!input) return;
            var step = (typeof getPosEntityMoneyStep === 'function') ? getPosEntityMoneyStep() : 1000;
            var cur = parsePosPromptMoneyValue(input.value);
            var next = Math.max(0, cur + (step * (sign < 0 ? -1 : 1)));
            input.value = formatPosPromptMoneyValue(next);
            input.focus();
        };
        window.setPosEntityMoneyField = function(field, value) {
            var input = document.getElementById(field === 'limit' ? 'pos-entity-limit-input' : 'pos-entity-opening-input');
            if (!input) return;
            input.value = formatPosPromptMoneyValue(value);
            input.focus();
        };
        window.collectPosEntityPromptData = function() {
            var nameInput = document.getElementById('pos-entity-name-input');
            var phoneInput = document.getElementById('pos-entity-phone-input');
            var addressInput = document.getElementById('pos-entity-address-input');
            var openingInput = document.getElementById('pos-entity-opening-input');
            var limitInput = document.getElementById('pos-entity-limit-input');
            var entityType = window._posEntityPromptType || 'customer';
            var parseMoney = parsePosPromptMoneyValue;
            var base = {
                name: String(nameInput && nameInput.value || '').trim(),
                phone: String(phoneInput && phoneInput.value || '').trim()
            };
            if (entityType === 'manufacturer') {
                base.note = String(addressInput && addressInput.value || '').trim();
                return base;
            }
            if (entityType === 'category' || entityType === 'table') {
                return { name: base.name };
            }
            base.address = String(addressInput && addressInput.value || '').trim();
            base.opening_balance = parseMoney(openingInput && openingInput.value);
            base.debt_limit = parseMoney(limitInput && limitInput.value);
            var ptValEl = document.getElementById('pos-entity-payment-term-value');
            var ptUnitEl = document.getElementById('pos-entity-payment-term-unit');
            base.payment_term_value = Math.max(0, parseInt(ptValEl && ptValEl.value, 10) || 0);
            base.payment_term_unit = (typeof normalizePaymentTermUnit === 'function')
                ? normalizePaymentTermUnit(ptUnitEl && ptUnitEl.value)
                : 'day';
            return base;
        };
        window.cancelPosEntityNamePrompt = function() {
            var modal = document.getElementById('pos-entity-name-modal');
            if (modal) modal.style.display = 'none';
            window._posEntityNamePromptCallback = null;
            window._posEntityPromptType = null;
        };
        window.confirmPosEntityNamePrompt = function() {
            var modal = document.getElementById('pos-entity-name-modal');
            var data = (typeof collectPosEntityPromptData === 'function') ? collectPosEntityPromptData() : { name: '' };
            if (!data.name) {
                if (typeof showToast === 'function') {
                    showToast((typeof t === 'function') ? t('pos_entity_name_empty') : 'تکایە ناڤ بنووسە', 'warning');
                }
                var nameInput = document.getElementById('pos-entity-name-input');
                if (nameInput) nameInput.focus();
                return;
            }
            if (data.name.length < 2) {
                if (typeof showToast === 'function') {
                    showToast((typeof t === 'function') ? t('pos_entity_name_short') : 'ناڤ گەلەک کورتە — لانی کەم ٢ پیت', 'warning');
                }
                var nameEl = document.getElementById('pos-entity-name-input');
                if (nameEl) nameEl.focus();
                return;
            }
            if (modal) modal.style.display = 'none';
            var cb = window._posEntityNamePromptCallback;
            window._posEntityNamePromptCallback = null;
            window._posEntityPromptType = null;
            if (typeof cb === 'function') cb(data);
        };

        window.normalizePaymentTermUnit = function(unit) {
            var u = String(unit || 'day').toLowerCase().trim();
            if (u === 'minute' || u === 'minutes' || u === 'min') return 'minute';
            if (u === 'hour' || u === 'hours' || u === 'h') return 'hour';
            if (u === 'month' || u === 'months') return 'month';
            if (u === 'year' || u === 'years' || u === 'y') return 'year';
            return 'day';
        };

        window.readPaymentTermInputs = function(prefix) {
            var valEl = document.getElementById(prefix + '-payment-due-value');
            var unitEl = document.getElementById(prefix + '-payment-due-unit');
            return {
                value: Math.max(0, parseInt(valEl && valEl.value, 10) || 0),
                unit: normalizePaymentTermUnit(unitEl && unitEl.value)
            };
        };

        window.applyPaymentTermInputs = function(prefix, value, unit) {
            var valEl = document.getElementById(prefix + '-payment-due-value');
            var unitEl = document.getElementById(prefix + '-payment-due-unit');
            if (valEl) valEl.value = String(Math.max(0, parseInt(value, 10) || 0));
            if (unitEl) unitEl.value = normalizePaymentTermUnit(unit);
        };

        window.togglePaymentDueRow = function(prefix, visible) {
            var rowEl = document.getElementById(prefix + '-payment-due-row');
            if (rowEl) rowEl.style.display = visible ? '' : 'none';
        };

        window.readProfilePaymentTerm = function(valueId, unitId) {
            var vEl = document.getElementById(valueId);
            var uEl = document.getElementById(unitId);
            return {
                value: Math.max(0, parseInt(vEl && vEl.value, 10) || 0),
                unit: normalizePaymentTermUnit(uEl && uEl.value)
            };
        };

        window.appendPaymentTermToFormData = function(fd, prefixOrValueId, unitId) {
            var pt;
            if (unitId) {
                pt = readProfilePaymentTerm(prefixOrValueId, unitId);
            } else {
                pt = readPaymentTermInputs(prefixOrValueId);
            }
            fd.append('payment_term_value', String(pt.value));
            fd.append('payment_term_unit', pt.unit);
        };

        window.parsePaymentDueTs = function(raw) {
            if (raw == null || raw === '') return null;
            if (typeof raw === 'number' && isFinite(raw)) return raw;
            var s = String(raw).trim();
            if (!s) return null;
            // MySQL "YYYY-MM-DD HH:MM:SS" → ISO-ish for reliable Date parse
            if (/^\d{4}-\d{2}-\d{2} /.test(s)) s = s.replace(' ', 'T');
            var ts = new Date(s).getTime();
            return isNaN(ts) ? null : ts;
        };

        window.getPaymentDueStatus = function(obj) {
            if (!obj || !obj.payment_due_at) return 'ok';
            var due = (typeof parsePaymentDueTs === 'function') ? parsePaymentDueTs(obj.payment_due_at) : new Date(obj.payment_due_at).getTime();
            if (due == null || isNaN(due)) return 'ok';
            var now = Date.now();
            if (due < now) return 'overdue';
            if (due - now <= 86400000) return 'due_soon';
            return 'ok';
        };

        window.entityHasOverduePaymentDue = function(entityType, entity) {
            if (!entity) return false;
            if (entityType === 'customer') {
                var sales = (typeof db !== 'undefined' && db && Array.isArray(db.sales)) ? db.sales : [];
                for (var i = 0; i < sales.length; i++) {
                    var s = sales[i];
                    if (!s || String(s.customer_id) !== String(entity.id)) continue;
                    if ((parseFloat(s.remaining_debt) || 0) <= 0) continue;
                    if (getPaymentDueStatus(s) === 'overdue') return true;
                }
                return false;
            }
            if (entityType === 'company') {
                var supplies = (typeof db !== 'undefined' && db && Array.isArray(db.supplies)) ? db.supplies : [];
                var name = String(entity.name || '').trim();
                var seen = Object.create(null);
                for (var j = 0; j < supplies.length; j++) {
                    var sup = supplies[j];
                    if (!sup || String(sup.company || '').trim() !== name) continue;
                    var tid = String(sup.transaction_id || '');
                    if (!tid || seen[tid]) continue;
                    seen[tid] = true;
                    var st = String(sup.type || '').toLowerCase();
                    if (st !== 'credit' && st !== 'split') continue;
                    if (getPaymentDueStatus(sup) === 'overdue') return true;
                }
                return false;
            }
            return false;
        };

        window.entityPaymentDueBadgeStatus = function(entityType, entity) {
            if (!entity) return 'ok';
            if (entityHasOverduePaymentDue(entityType, entity)) return 'overdue';
            if (entityType === 'customer') {
                var sales = (typeof db !== 'undefined' && db && Array.isArray(db.sales)) ? db.sales : [];
                for (var i = 0; i < sales.length; i++) {
                    var s = sales[i];
                    if (!s || String(s.customer_id) !== String(entity.id)) continue;
                    if ((parseFloat(s.remaining_debt) || 0) <= 0) continue;
                    if (getPaymentDueStatus(s) === 'due_soon') return 'due_soon';
                }
            } else if (entityType === 'company') {
                var supplies = (typeof db !== 'undefined' && db && Array.isArray(db.supplies)) ? db.supplies : [];
                var name = String(entity.name || '').trim();
                var seen = Object.create(null);
                for (var j = 0; j < supplies.length; j++) {
                    var sup = supplies[j];
                    if (!sup || String(sup.company || '').trim() !== name) continue;
                    var tid = String(sup.transaction_id || '');
                    if (!tid || seen[tid]) continue;
                    seen[tid] = true;
                    var st = String(sup.type || '').toLowerCase();
                    if (st !== 'credit' && st !== 'split') continue;
                    if (getPaymentDueStatus(sup) === 'due_soon') return 'due_soon';
                }
            }
            return 'ok';
        };

        window.formatPaymentDueWarning = function(name) {
            var templ = (typeof t === 'function' && t('payment_due_overdue') !== 'payment_due_overdue')
                ? t('payment_due_overdue')
                : 'وەختێ پارەدانا {name} هات — مەوعدێ ویە';
            return templ.replace(/\{name\}/g, String(name || ''));
        };

        window.maybeToastPaymentDueOverdue = function(entityType, entity) {
            if (!entity || !entityHasOverduePaymentDue(entityType, entity)) return;
            if (typeof showToast === 'function') {
                showToast('⚠️ ' + formatPaymentDueWarning(entity.name), 'warning');
            }
        };

        window.applyEntityPaymentTermToTxn = function(prefix, entity, force) {
            if (!entity) return;
            var entVal = Math.max(0, parseInt(entity.payment_term_value, 10) || 0);
            var entUnit = entity.payment_term_unit || 'day';
            // Never wipe a term the cashier already typed — only prefill from profile when empty.
            if (!force) {
                var cur = (typeof readPaymentTermInputs === 'function')
                    ? readPaymentTermInputs(prefix)
                    : { value: 0, unit: 'day' };
                if (cur.value > 0) return;
                if (entVal <= 0) return;
            }
            applyPaymentTermInputs(prefix, entVal, entUnit);
        };

        window.computePaymentDueAtIso = function(value, unit, fromDate) {
            var v = Math.max(0, parseInt(value, 10) || 0);
            if (v <= 0) return null;
            var u = normalizePaymentTermUnit(unit);
            var base = fromDate ? new Date(fromDate) : new Date();
            if (isNaN(base.getTime())) base = new Date();
            if (u === 'minute') base.setMinutes(base.getMinutes() + v);
            else if (u === 'hour') base.setHours(base.getHours() + v);
            else if (u === 'month') base.setMonth(base.getMonth() + v);
            else if (u === 'year') base.setFullYear(base.getFullYear() + v);
            else base.setDate(base.getDate() + v);
            return base.toISOString();
        };

        window.resolveTxnPaymentTerm = function(prefix, entity) {
            var pt = (typeof readPaymentTermInputs === 'function') ? readPaymentTermInputs(prefix) : { value: 0, unit: 'day' };
            if (pt.value <= 0 && entity) {
                pt.value = Math.max(0, parseInt(entity.payment_term_value, 10) || 0);
                pt.unit = normalizePaymentTermUnit(entity.payment_term_unit || 'day');
            }
            return pt;
        };

        window.renderPaymentDueBadgeHtml = function(entityType, entity) {
            var info = (typeof getEntityPaymentDueInfo === 'function') ? getEntityPaymentDueInfo(entityType, entity) : null;
            if (!info || !info.dueAt) return '';
            var st = info.status || 'ok';
            var cls = st === 'overdue' ? 'payment-due-badge payment-due-badge--overdue'
                : (st === 'due_soon' ? 'payment-due-badge payment-due-badge--soon' : 'payment-due-badge payment-due-badge--ok');
            var text = info.label || ((typeof t === 'function' && t('payment_due_label') !== 'payment_due_label') ? t('payment_due_label') : 'مەوعدێ پارەدانێ');
            return '<span class="' + cls + '">' + (typeof escapeHtml === 'function' ? escapeHtml(text) : text) + '</span>';
        };

        window.getEntityEarliestPaymentDueAt = function(entityType, entity) {
            if (!entity) return null;
            var earliest = null;
            var termVal = Math.max(0, parseInt(entity.payment_term_value, 10) || 0);
            var termUnit = (typeof normalizePaymentTermUnit === 'function')
                ? normalizePaymentTermUnit(entity.payment_term_unit || 'day')
                : 'day';

            function considerDue(dueRaw, saleBaseDate) {
                var ts = null;
                if (dueRaw) {
                    ts = (typeof parsePaymentDueTs === 'function')
                        ? parsePaymentDueTs(dueRaw)
                        : new Date(dueRaw).getTime();
                    if (ts != null && isNaN(ts)) ts = null;
                }
                if (ts == null && termVal > 0 && saleBaseDate && typeof computePaymentDueAtIso === 'function') {
                    var iso = computePaymentDueAtIso(termVal, termUnit, saleBaseDate);
                    if (iso) {
                        ts = (typeof parsePaymentDueTs === 'function')
                            ? parsePaymentDueTs(iso)
                            : new Date(iso).getTime();
                        if (ts != null && isNaN(ts)) ts = null;
                    }
                }
                if (ts == null) return;
                if (earliest == null || ts < earliest) earliest = ts;
            }

            function saleHasOpenCredit(s) {
                if (!s) return false;
                var rem = parseFloat(s.remaining_debt);
                if (!isNaN(rem)) return rem > 0.0001;
                var debtAmt = parseFloat(s.debt_amount != null ? s.debt_amount : s.debt_added);
                if (!isNaN(debtAmt) && debtAmt > 0.0001) return true;
                var m = String(s.payment_method || '').toLowerCase();
                return m === 'debt' || m === 'credit';
            }

            if (entityType === 'customer') {
                var sales = (typeof db !== 'undefined' && db && Array.isArray(db.sales)) ? db.sales : [];
                var entName = String(entity.name || '').trim().toLowerCase();
                for (var i = 0; i < sales.length; i++) {
                    var s = sales[i];
                    if (!s) continue;
                    var idMatch = entity.id != null && String(s.customer_id) === String(entity.id);
                    var nameMatch = entName && String(s.customer || s.customer_name || '').trim().toLowerCase() === entName;
                    if (!idMatch && !nameMatch) continue;
                    if (!saleHasOpenCredit(s)) continue;
                    considerDue(s.payment_due_at, s.date || s.created_at);
                }
            } else if (entityType === 'company') {
                var supplies = (typeof db !== 'undefined' && db && Array.isArray(db.supplies)) ? db.supplies : [];
                var name = String(entity.name || '').trim();
                var seen = Object.create(null);
                for (var j = 0; j < supplies.length; j++) {
                    var sup = supplies[j];
                    if (!sup || String(sup.company || '').trim() !== name) continue;
                    var tid = String(sup.transaction_id || '');
                    if (!tid || seen[tid]) continue;
                    seen[tid] = true;
                    var st = String(sup.type || '').toLowerCase();
                    if (st !== 'credit' && st !== 'split') continue;
                    considerDue(sup.payment_due_at, sup.date);
                }
            }
            return earliest;
        };

        window.getEntityPaymentDueInfo = function(entityType, entity) {
            if (!entity) return null;
            var dueTs = (typeof getEntityEarliestPaymentDueAt === 'function') ? getEntityEarliestPaymentDueAt(entityType, entity) : null;
            var bal = parseFloat(entity.balance) || 0;
            var termVal = Math.max(0, parseInt(entity.payment_term_value, 10) || 0);
            var tFn = function(k, fb) {
                if (typeof t !== 'function') return fb;
                var v = t(k);
                return (v && v !== k) ? v : fb;
            };
            if (dueTs != null) {
                var now = Date.now();
                var status = 'ok';
                if (dueTs < now) status = 'overdue';
                else if (dueTs - now <= 86400000) status = 'due_soon';
                var rem = (typeof formatPaymentDueRemaining === 'function') ? formatPaymentDueRemaining(dueTs) : '';
                var prefix = tFn('payment_due_remaining_label', 'وەختێ مایی');
                return {
                    dueAt: dueTs,
                    status: status,
                    remaining: rem,
                    label: rem ? (prefix + ': ' + rem) : rem
                };
            }
            // No due date yet, but profile has a default term and open balance — show configured term.
            if (bal > 0.0001 && termVal > 0) {
                var unit = (typeof normalizePaymentTermUnit === 'function')
                    ? normalizePaymentTermUnit(entity.payment_term_unit || 'day')
                    : 'day';
                var unitLbl = tFn('payment_term_unit_' + unit, unit);
                return {
                    dueAt: null,
                    status: 'ok',
                    remaining: '',
                    label: tFn('payment_due_label', 'مەوعدێ پارەدانێ') + ': ' + termVal + ' ' + unitLbl
                };
            }
            return null;
        };

        window.formatPaymentDueRemaining = function(dueTs) {
            if (dueTs == null || isNaN(dueTs)) return '';
            var now = Date.now();
            var diff = dueTs - now;
            var tFn = function(k, fb) {
                if (typeof t !== 'function') return fb;
                var v = t(k);
                return (v && v !== k) ? v : fb;
            };
            if (diff <= 0) {
                return tFn('payment_due_time_passed', 'وەخت هات');
            }
            var totalMin = Math.floor(diff / 60000);
            var days = Math.floor(totalMin / (60 * 24));
            var hours = Math.floor((totalMin % (60 * 24)) / 60);
            var mins = totalMin % 60;
            var parts = [];
            if (days > 0) parts.push(days + ' ' + tFn('payment_term_unit_day', 'ڕۆژ'));
            if (hours > 0) parts.push(hours + ' ' + tFn('payment_term_unit_hour', 'دەمژمێر'));
            if (mins > 0 || parts.length === 0) parts.push(mins + ' ' + tFn('payment_term_unit_minute', 'خولەک'));
            // Keep card readable: max 2 units
            if (parts.length > 2) parts = parts.slice(0, 2);
            var left = tFn('payment_due_remaining_suffix', 'مایە');
            return parts.join(' ') + ' ' + left;
        };

        window.renderPaymentDueRemainingRowHtml = function(entityType, entity) {
            var info = (typeof getEntityPaymentDueInfo === 'function') ? getEntityPaymentDueInfo(entityType, entity) : null;
            if (!info || !info.label) return '';
            var color = info.status === 'overdue' ? '#dc2626' : (info.status === 'due_soon' ? '#d97706' : 'var(--brand)');
            var esc = (typeof escapeHtml === 'function') ? escapeHtml : function(s) { return String(s == null ? '' : s); };
            return '<div style="padding:6px 12px; background:var(--card); border-top:1px dashed var(--border); font-size:0.82rem; color:var(--text-muted);">'
                + '<i class="fas fa-hourglass-half" style="margin-left:4px;color:' + color + ';"></i> '
                + '<span style="color:' + color + ';font-weight:700;">' + esc(info.label) + '</span>'
                + '</div>';
        };

        /** Conversion factors: pieces per pack (>=1), packs per carton (>=1). Single source for all unit math. */
        /** معامل التحويل بين الوحدات (کارتۆن، پاکێت، تاک). مصدر واحد: pieces_per_pack × packs_per_carton أو itemsPerCarton للمنتجات القديمة. */
        function getProductUnitFactors(prod) {
            if (!prod) return { ppp: 1, ppc: 1, piecesPerPack: 1, piecesPerCarton: 1 };
            var ppp = (prod.pieces_per_pack != null && prod.pieces_per_pack >= 1) ? prod.pieces_per_pack : 1;
            var ppc = (prod.packs_per_carton != null && prod.packs_per_carton >= 1) ? prod.packs_per_carton : 1;
            var piecesPerCarton = ppp * ppc;
            if ((piecesPerCarton <= 1) && (prod.itemsPerCarton != null && prod.itemsPerCarton >= 1)) {
                piecesPerCarton = prod.itemsPerCarton;
                ppp = 1;
                ppc = Math.max(1, Math.floor(piecesPerCarton));
            }
            return { ppp: ppp, ppc: ppc, piecesPerPack: Math.max(1, ppp), piecesPerCarton: Math.max(1, piecesPerCarton) };
        }
        /** Returns the selling price for the given unit (carton/pack/piece). Used by addToBill and recalcBulkPrices. */
        function getPriceForUnit(prod, unit, table) {
            if (!prod) return 0;
            // Jewelry by gram: live price from today's metal rate × saved weight + making
            if ((typeof isJewelryByWeightProduct === 'function') && isJewelryByWeightProduct(prod)
                && (typeof computeProductJewelryPrice === 'function')) {
                var uJew = (unit == null || unit === '') ? 'piece' : String(unit);
                var w = Number(prod.weight_grams) || 0;
                if (w > 0) {
                    if (uJew === 'pack') {
                        var fJ = typeof getProductUnitFactors === 'function' ? getProductUnitFactors(prod) : { piecesPerPack: 1 };
                        w = w * (fJ.piecesPerPack || 1);
                    } else if (uJew === 'carton') {
                        var fJc = typeof getProductUnitFactors === 'function' ? getProductUnitFactors(prod) : { piecesPerCarton: 1 };
                        w = w * (fJc.piecesPerCarton || 1);
                    }
                    var live = computeProductJewelryPrice(prod, w);
                    if (live > 0) return live;
                }
            }
            var f = typeof getProductUnitFactors === 'function' ? getProductUnitFactors(prod) : { piecesPerPack: 1, piecesPerCarton: 1 };
            var piecePrice = typeof catalogIqdFromUsdField === 'function' ? catalogIqdFromUsdField(prod, 'price_usd', 'price') : (Number(prod.price) || 0);
            if (!isFinite(piecePrice) || piecePrice < 0) piecePrice = 0;
            var u = (unit == null || unit === '') ? 'piece' : String(unit);
            
            if (isAlternatePricingActive(table)) {
                if (u === 'carton' && (Number(prod.takeawayPrice_carton) || 0) > 0) return Number(prod.takeawayPrice_carton);
                if (u === 'pack' && (Number(prod.takeawayPrice_pack) || 0) > 0) return Number(prod.takeawayPrice_pack);
                if (u === 'piece' && (Number(prod.takeawayPrice) || 0) > 0) return Number(prod.takeawayPrice);
            }

            if (u === 'carton') {
                var pc = typeof catalogIqdFromUsdField === 'function' ? catalogIqdFromUsdField(prod, 'price_carton_usd', 'price_carton') : Number(prod.price_carton);
                if (isFinite(pc) && pc > 0) return pc;
                return piecePrice * (f.piecesPerCarton || 1);
            }
            if (u === 'pack') {
                var pp = typeof catalogIqdFromUsdField === 'function' ? catalogIqdFromUsdField(prod, 'price_pack_usd', 'price_pack') : Number(prod.price_pack);
                if (isFinite(pp) && pp > 0) return pp;
                return piecePrice * (f.piecesPerPack || 1);
            }
            return piecePrice;
        }
        /** True when cart/sale line is a free gift (not charged on grand total). */
        function isPosCartLineGift(item) {
            if (!item) return false;
            var g = item.isGift;
            return !!(g && g !== 0 && g !== '0' && g !== 'false' && g !== false);
        }
        try { window.isPosCartLineGift = isPosCartLineGift; } catch (_eGift) {}
        /** Resolve one cart line to real USD + IQD. Recovers IQD-as-USD and double FX. */
        function resolveCartLineMoney(item) {
            if (!item || (typeof isPosCartLineGift === 'function' ? isPosCartLineGift(item) : !!item.isGift)) {
                return { iqd: 0, usd: 0 };
            }
            var rate = typeof getPosFrozenFxRatePerOne === 'function' ? getPosFrozenFxRatePerOne(item) : (typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0);
            var storedIqd = Number(item.price);
            if (!isFinite(storedIqd) || storedIqd < 0) storedIqd = 0;
            var storedUsd = parseFloat(item.bill_unit_usd);
            if (!isFinite(storedUsd) || storedUsd < 0) storedUsd = 0;
            var looksMix = (typeof usdValueLooksLikeIqdSnapshot === 'function' && rate > 0)
                ? usdValueLooksLikeIqdSnapshot(storedUsd, storedIqd, rate)
                : (storedUsd > 0 && storedIqd > 0 && Math.abs(storedUsd - storedIqd) / Math.max(storedIqd, 1) < 0.02);
            if (looksMix && rate > 0 && storedUsd > 0) {
                return { iqd: Math.round(storedUsd), usd: parseFloat((storedUsd / rate).toFixed(6)) };
            }
            if (storedUsd > 0 && storedIqd > 0) return { iqd: Math.round(storedIqd), usd: storedUsd };
            if (storedUsd > 0 && rate > 0) return { iqd: Math.round(storedUsd * rate), usd: storedUsd };
            if (storedIqd > 0 && rate > 0) return { iqd: Math.round(storedIqd), usd: parseFloat((storedIqd / rate).toFixed(6)) };
            if (!item.isManualPrice && !item.isManualItem) {
                var prod = typeof getProductByIdSafe === 'function' ? getProductByIdSafe(item.id) : null;
                if (prod) {
                    var u = item.saleUnit || 'piece';
                    var catUsd = (typeof getCatalogBillUnitUsdAtAdd === 'function') ? getCatalogBillUnitUsdAtAdd(prod, u, null) : 0;
                    var catIqd = (typeof getPriceForUnit === 'function') ? getPriceForUnit(prod, u, null) : (Number(prod.price) || 0);
                    if (catUsd > 0 || catIqd > 0) {
                        if (!(catUsd > 0) && rate > 0 && catIqd > 0) catUsd = parseFloat((catIqd / rate).toFixed(6));
                        if (!(catIqd > 0) && rate > 0 && catUsd > 0) catIqd = Math.round(catUsd * rate);
                        return { iqd: Math.round(catIqd) || 0, usd: catUsd || 0 };
                    }
                }
            }
            return { iqd: Math.round(storedIqd) || 0, usd: storedUsd || 0 };
        }
        try { window.resolveCartLineMoney = resolveCartLineMoney; } catch (_eRcl) {}
        /** IQD for one bill line: stored item.price is canonical. Do not re-convert frozen USD at today's rate (that rewrites debt on edit). */
        function getBillLineUnitIqd(item) {
            if (!item) return 0;
            if (isPosCartLineGift(item)) return 0;
            if (typeof resolveCartLineMoney === 'function') {
                var m = resolveCartLineMoney(item);
                if (m && isFinite(m.iqd)) return m.iqd;
            }
            var stored = Number(item.price);
            if (isFinite(stored)) return stored;
            if (item.bill_unit_usd != null && item.bill_unit_usd !== '' && !isNaN(parseFloat(item.bill_unit_usd))) {
                var r = typeof getPosFrozenFxRatePerOne === 'function' ? getPosFrozenFxRatePerOne(item) : (typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0);
                if (r > 0) {
                    if (typeof usdAmountToStoredIqd === 'function') return usdAmountToStoredIqd(parseFloat(item.bill_unit_usd), r);
                    return Math.round(parseFloat(item.bill_unit_usd) * r);
                }
            }
            return 0;
        }
        try { window.getBillLineUnitIqd = getBillLineUnitIqd; } catch (_eGli) {}
        /** Value passed into cart row onclick handlers so qty/price/remove still match after FX change (USD frozen = bill_unit_usd). */
        function getCartLineMatchPrice(item) {
            if (!item) return 0;
            var money = (typeof resolveCartLineMoney === 'function') ? resolveCartLineMoney(item) : null;
            if (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD') {
                if (money && money.usd > 0) return Number(money.usd);
                if (item.bill_unit_usd != null && item.bill_unit_usd !== '' && !isNaN(parseFloat(item.bill_unit_usd)))
                    return Number(item.bill_unit_usd);
            }
            if (money && money.iqd > 0) return Number(money.iqd);
            return Number(item.price) || 0;
        }
        function getPosRoundMoney() {
            return typeof roundMoney === 'function' ? roundMoney : function(x) { return Math.round(Number(x) || 0); };
        }
        function sumCartItemsSubtotalIqd(items) {
            var rm = getPosRoundMoney();
            return rm((items || []).reduce(function(sum, item) {
                if (isPosCartLineGift(item)) return sum;
                var u = typeof getBillLineUnitIqd === 'function' ? getBillLineUnitIqd(item) : (Number(item.price) || 0);
                return sum + u * getItemQty(item);
            }, 0));
        }
        function sumCartItemsSubtotalUsd(items) {
            var rate = typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0;
            return (items || []).reduce(function(s, item) {
                if (isPosCartLineGift(item)) return s;
                var q = getItemQty(item);
                if (typeof resolveCartLineMoney === 'function') {
                    var m = resolveCartLineMoney(item);
                    return s + (Number(m.usd) || 0) * q;
                }
                if (item.bill_unit_usd != null && item.bill_unit_usd !== '' && !isNaN(parseFloat(item.bill_unit_usd)))
                    return s + parseFloat(item.bill_unit_usd) * q;
                return s + ((rate > 0) ? (((Number(item.price) || 0) * q) / rate) : 0);
            }, 0);
        }
        /**
         * Invoice/print amounts from the basket (frozen bill_unit_usd + visual IQD rate).
         * Do not use warehouse FX to re-derive customer-facing USD/IQD — that skews stock pricing.
         */
        function getSaleBasketVisualRate100(sale) {
            if (sale && sale.basket_visual_rate_100 != null && sale.basket_visual_rate_100 !== '') {
                var stored = Math.round(Number(sale.basket_visual_rate_100));
                if (isFinite(stored) && stored > 0) return stored;
            }
            if (typeof getEffectiveVisualUsdRate100 === 'function') {
                var eff = getEffectiveVisualUsdRate100();
                if (eff > 0) return eff;
            }
            if (typeof getBasketVisualRate100Value === 'function') {
                var typed = getBasketVisualRate100Value();
                if (typed > 0) return typed;
            }
            if (typeof loadBasketVisualRate100Value === 'function') {
                var saved = loadBasketVisualRate100Value();
                if (saved > 0) return saved;
            }
            return 0;
        }
        function resolveSaleBasketPrintMoney(sale, items) {
            sale = sale || {};
            items = items || sale.items || [];
            if (typeof items === 'string') {
                try { items = JSON.parse(items); } catch (_eItems) { items = []; }
            }
            if (!Array.isArray(items)) items = [];
            var qtyFn = typeof getItemQty === 'function' ? getItemQty : function(it) {
                return parseFloat(it && (it.qty != null ? it.qty : it.count)) || 0;
            };
            var usdGross = 0;
            var hasLineUsd = false;
            items.forEach(function(it) {
                if (!it || (typeof isPosCartLineGift === 'function' ? isPosCartLineGift(it) : !!it.isGift)) return;
                var q = qtyFn(it);
                if (!(q > 0)) return;
                if (typeof resolveCartLineMoney === 'function') {
                    var lm = resolveCartLineMoney(it);
                    if (lm && lm.usd > 0) {
                        hasLineUsd = true;
                        usdGross += lm.usd * q;
                        return;
                    }
                }
                if (it.bill_unit_usd != null && it.bill_unit_usd !== '' && !isNaN(parseFloat(it.bill_unit_usd))) {
                    hasLineUsd = true;
                    usdGross += parseFloat(it.bill_unit_usd) * q;
                }
            });
            var totalIqd = Math.round(parseFloat(sale.total) || 0);
            var discIqd = Math.round(parseFloat(sale.discount) || 0);
            var subIqd = totalIqd + discIqd;
            var usdNet = usdGross;
            if (sale.total_usd != null && sale.total_usd !== '' && !isNaN(parseFloat(sale.total_usd))) {
                usdNet = parseFloat(sale.total_usd);
                hasLineUsd = true;
            } else if (hasLineUsd && subIqd > 0 && discIqd > 0 && usdGross > 0) {
                usdNet = usdGross * (totalIqd / subIqd);
            }
            var visual100 = getSaleBasketVisualRate100(sale);
            var visualPerOne = visual100 > 0 ? (visual100 / 100) : 0;
            var usdCanonical = false;
            try {
                var fxMode = String(sale.fx_currency_mode || sale.sale_currency || '').toUpperCase();
                if (fxMode === 'USD') usdCanonical = true;
                else if (fxMode === 'IQD') usdCanonical = false;
                else if (typeof isUsdMoneySystem === 'function') usdCanonical = isUsdMoneySystem();
                else if (typeof getActiveCurrency === 'function') usdCanonical = getActiveCurrency() === 'USD';
            } catch (_eUsdCan) {}
            // IQD shops: never rebuild dinar from rounded USD ($31.33 × 1500 = 46,995 instead of 47,000).
            var basketIqd = totalIqd;
            if (usdCanonical) {
                if (sale.basket_iqd != null && sale.basket_iqd !== '' && !isNaN(parseFloat(sale.basket_iqd))) {
                    basketIqd = Math.round(parseFloat(sale.basket_iqd));
                } else if (visualPerOne > 0 && usdNet > 0) {
                    basketIqd = Math.round(usdNet * visualPerOne);
                }
            }
            return {
                hasBasketUsd: hasLineUsd && usdNet > 0,
                usdNet: usdNet > 0 ? usdNet : 0,
                basketIqd: basketIqd,
                visualRate100: visual100,
                visualPerOne: visualPerOne
            };
        }
        function attachSaleBasketPrintFields(sale, items) {
            if (!sale) return sale;
            var m = resolveSaleBasketPrintMoney(sale, items || sale.items);
            if (m.hasBasketUsd) sale.total_usd = m.usdNet;
            if (m.basketIqd > 0) sale.basket_iqd = m.basketIqd;
            if (m.visualRate100 > 0) sale.basket_visual_rate_100 = m.visualRate100;
            try {
                if (typeof getActiveCurrency === 'function') sale.fx_currency_mode = getActiveCurrency();
            } catch (_eMode) {}
            return sale;
        }
        if (typeof window !== 'undefined') {
            window.getSaleBasketVisualRate100 = getSaleBasketVisualRate100;
            window.resolveSaleBasketPrintMoney = resolveSaleBasketPrintMoney;
            window.attachSaleBasketPrintFields = attachSaleBasketPrintFields;
        }
        function getCartDiscountIqd(table, subtotalIqd) {
            var rm = getPosRoundMoney();
            if (!table) return 0;
            var sub = Number(subtotalIqd) || 0;
            if (!isFinite(sub) || sub < 0) sub = 0;
            var d = 0;
            if (table.manualDiscount !== undefined && table.manualDiscount !== null) {
                d = rm(parseFloat(table.manualDiscount));
            } else {
                var discountInputEl = document.getElementById('pos-discount');
                var discountInput = discountInputEl ? discountInputEl.value : '';
                if (discountInput && !isNaN(discountInput)) {
                    var pct = parseFloat(discountInput);
                    if (!isFinite(pct) || pct < 0) pct = 0;
                    if (pct > 100) pct = 100;
                    if (pct >= 0 && pct <= 100) d = rm(sub * (pct / 100));
                }
            }
            if (!isFinite(d) || d < 0) d = 0;
            if (d > sub) d = sub;
            return d;
        }
        /** Keep fixed bill discount from exceeding paid (non-gift) subtotal after gift toggles. */
        function clampPosCartManualDiscount(table) {
            if (!table || table.manualDiscount === undefined || table.manualDiscount === null) return;
            var disc = parseFloat(table.manualDiscount);
            if (!isFinite(disc) || disc < 0) {
                table.manualDiscount = 0;
                return;
            }
            var paid = typeof sumCartItemsSubtotalIqd === 'function' ? sumCartItemsSubtotalIqd(table.items) : 0;
            if (!isFinite(paid) || paid < 0) paid = 0;
            if (disc > paid) table.manualDiscount = paid;
        }
        try { window.clampPosCartManualDiscount = clampPosCartManualDiscount; } catch (_eClamp) {}
        function computePosCartTotals(table) {
            if (!table) return { subtotalIqd: 0, discountIqd: 0, finalIqd: 0, itemsCount: 0, subtotalUsd: 0, finalUsd: 0 };
            var rm = getPosRoundMoney();
            if (typeof clampPosCartManualDiscount === 'function') clampPosCartManualDiscount(table);
            var subtotalIqd = sumCartItemsSubtotalIqd(table.items);
            if (!isFinite(subtotalIqd) || subtotalIqd < 0) subtotalIqd = 0;
            var discountIqd = getCartDiscountIqd(table, subtotalIqd);
            if (!isFinite(discountIqd) || discountIqd < 0) discountIqd = 0;
            var finalIqd = rm(subtotalIqd - discountIqd);
            if (!isFinite(finalIqd) || finalIqd < 0) finalIqd = 0;
            var itemsCount = (table.items || []).reduce(function(c, it) { return c + getItemQty(it); }, 0);
            var subtotalUsd = sumCartItemsSubtotalUsd(table.items);
            if (!isFinite(subtotalUsd) || subtotalUsd < 0) subtotalUsd = 0;
            var finalUsd = 0;
            if (subtotalIqd > 0 && subtotalUsd > 0) {
                finalUsd = subtotalUsd * (finalIqd / subtotalIqd);
            } else if (subtotalUsd > 0 && discountIqd <= 0) {
                finalUsd = subtotalUsd;
            }
            if (!isFinite(finalUsd) || finalUsd < 0) finalUsd = 0;
            return { subtotalIqd: subtotalIqd, discountIqd: discountIqd, finalIqd: finalIqd, itemsCount: itemsCount, subtotalUsd: subtotalUsd, finalUsd: finalUsd };
        }
        try { window.computePosCartTotals = computePosCartTotals; } catch (_eCpt) {}
        function formatPosMoneyDisplay(iqdAmount, usdOverride) {
            var n = Number(iqdAmount) || 0;
            if (!isFinite(n) || n < 0) n = 0;
            var isUSD = typeof getDefaultCurrency === 'function' ? (getDefaultCurrency() === 'USD') : (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
            var rate = typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0;
            var usd = (usdOverride != null && !isNaN(usdOverride)) ? Number(usdOverride) : 0;
            if (!isFinite(usd) || usd < 0) usd = 0;
            if (usd > 0 && n > 0 && rate > 0 && typeof usdValueLooksLikeIqdSnapshot === 'function' && usdValueLooksLikeIqdSnapshot(usd, n, rate)) {
                usd = (typeof convertCurrency === 'function') ? convertCurrency(usd, 'IQD', 'USD', rate) : parseFloat((usd / rate).toFixed(6));
                n = (typeof convertCurrency === 'function') ? convertCurrency(usd, 'USD', 'IQD', rate) : Math.round(usd * rate);
            }
            if (isUSD) {
                if (!(usd > 0) && n > 0) {
                    usd = (typeof convertCurrency === 'function') ? convertCurrency(n, 'IQD', 'USD', rate) : (rate > 0 ? (n / rate) : 0);
                }
                if (typeof formatUsdAmount === 'function') return formatUsdAmount(usd);
                if (typeof formatUsdNumberPlain === 'function') return '$' + formatUsdNumberPlain(usd);
                return '$' + Number(usd).toLocaleString('en-US', { maximumFractionDigits: 2, minimumFractionDigits: 0 });
            }
            if (typeof formatIqdAmount === 'function') return formatIqdAmount(n);
            return (typeof formatCurrency === 'function') ? formatCurrency(n) : String(Math.round(n));
        }
        function formatPosLineSubtotal(iqdSubtotal, lineItem, lineQty) {
            if (lineItem && (typeof isPosCartLineGift === 'function' ? isPosCartLineGift(lineItem) : !!lineItem.isGift)) {
                var giftLbl = (typeof t === 'function') ? t('pos_gift_label') : 'دیاری';
                return '<span class="pos-line-gift-amt" title="' + (typeof escapeHtml === 'function' ? escapeHtml(giftLbl) : giftLbl) + '">' + (typeof escapeHtml === 'function' ? escapeHtml(giftLbl) : giftLbl) + ' · 0</span>';
            }
            var qty = lineQty != null ? Number(lineQty) : (lineItem ? getItemQty(lineItem) : 1);
            var iqdLine = Number(iqdSubtotal) || 0;
            var usdLine = 0;
            if (lineItem && typeof resolveCartLineMoney === 'function') {
                var lm = resolveCartLineMoney(lineItem);
                iqdLine = (Number(lm.iqd) || 0) * qty;
                usdLine = (Number(lm.usd) || 0) * qty;
            } else if (lineItem && lineItem.bill_unit_usd != null && lineItem.bill_unit_usd !== '' && !isNaN(parseFloat(lineItem.bill_unit_usd))) {
                usdLine = parseFloat(lineItem.bill_unit_usd) * qty;
            }
            var rateLine = 0;
            if (typeof getEffectiveVisualUsdRate100 === 'function') {
                var vis100 = getEffectiveVisualUsdRate100();
                if (vis100 >= 10000) rateLine = vis100 / 100;
            }
            if (!(rateLine > 0) && typeof getUsdRatePerOne === 'function') rateLine = getUsdRatePerOne();
            var usdForDual = usdLine;
            var iqdShop = true;
            try {
                if (typeof isUsdMoneySystem === 'function') iqdShop = !isUsdMoneySystem();
                else if (typeof getActiveCurrency === 'function') iqdShop = getActiveCurrency() !== 'USD';
            } catch (_eIqdLine) {}
            if (iqdShop && rateLine > 0 && iqdLine > 0) {
                usdForDual = (typeof convertCurrency === 'function')
                    ? convertCurrency(iqdLine, 'IQD', 'USD', rateLine)
                    : (iqdLine / rateLine);
            } else if (lineItem && typeof getPosFrozenFxRatePerOne === 'function') {
                var frozen = getPosFrozenFxRatePerOne(lineItem);
                if (frozen > 0) rateLine = frozen;
            }
            if (typeof formatDualCurrencyLines === 'function') {
                var dual = formatDualCurrencyLines(iqdLine, usdForDual, rateLine);
                if (!dual.secondary) {
                    return '<span class="pos-line-money">' + dual.primary + '</span>';
                }
                return '<span class="pos-line-money"><span class="pos-line-money-usd">' + dual.usd + '</span><span class="pos-line-money-iqd" data-allow-iqd="1">' + dual.iqd + '</span></span>';
            }
            return formatPosMoneyDisplay(iqdLine, usdLine);
        }
        function itemMatchesCartGroup(item, prodId, note, matchPrice, saleUnit, isGift = false) {
            saleUnit = saleUnit || 'piece';
            if (String(item.id) !== String(prodId)) return false;
            if ((item.note || '') !== (note || '')) return false;
            if ((item.saleUnit || 'piece') !== saleUnit) return false;
            if (!!item.isGift !== !!isGift) return false;
            var mp = Number(matchPrice);
            var money = (typeof resolveCartLineMoney === 'function') ? resolveCartLineMoney(item) : null;
            if (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD') {
                var usd = (money && money.usd > 0) ? Number(money.usd) : parseFloat(item.bill_unit_usd);
                if (isFinite(usd) && usd > 0) return Math.abs(usd - mp) < 1e-8 || Math.abs(Number(item.bill_unit_usd) - mp) < 1e-8;
            }
            if (money && isFinite(money.iqd)) return Number(money.iqd) === mp || Number(item.price) === mp;
            return Number(item.price) === mp;
        }
        /** Frozen catalog USD per sale unit at cart add (canonical *_usd fields; one-time IQD/r only if USD missing). */
        function getCatalogBillUnitUsdAtAdd(prod, saleUnit, table) {
            if (!prod) return 0;
            var u = (saleUnit == null || saleUnit === '') ? 'piece' : String(saleUnit);
            var r = typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0;
            
            if (isAlternatePricingActive(table)) {
                if (u === 'carton' && (Number(prod.takeawayPrice_carton) || 0) > 0) return (r > 0 ? Number(prod.takeawayPrice_carton) / r : 0);
                if (u === 'pack' && (Number(prod.takeawayPrice_pack) || 0) > 0) return (r > 0 ? Number(prod.takeawayPrice_pack) / r : 0);
                if (u === 'piece' && (Number(prod.takeawayPrice) || 0) > 0) return (r > 0 ? Number(prod.takeawayPrice) / r : 0);
            }

            var f = typeof getProductUnitFactors === 'function' ? getProductUnitFactors(prod) : { piecesPerPack: 1, piecesPerCarton: 1 };
            if (u === 'carton') {
                if (typeof catalogUsdFromBaseField === 'function') {
                    var usdC = catalogUsdFromBaseField(prod, 'price_carton_usd', 'price_carton');
                    if (usdC > 0) return usdC;
                }
                var uusd = parseFloat(prod.price_carton_usd);
                if (isFinite(uusd) && uusd > 0) return uusd;
                var iqdC = typeof getPriceForUnit === 'function' ? getPriceForUnit(prod, 'carton', table) : 0;
                return (r > 0 && iqdC > 0) ? (iqdC / r) : 0;
            }
            if (u === 'pack') {
                if (typeof catalogUsdFromBaseField === 'function') {
                    var usdP = catalogUsdFromBaseField(prod, 'price_pack_usd', 'price_pack');
                    if (usdP > 0) return usdP;
                }
                var uusdP = parseFloat(prod.price_pack_usd);
                if (isFinite(uusdP) && uusdP > 0) return uusdP;
                var iqdP = typeof getPriceForUnit === 'function' ? getPriceForUnit(prod, 'pack', table) : 0;
                return (r > 0 && iqdP > 0) ? (iqdP / r) : 0;
            }
            if (typeof getCatalogPieceSellUsd === 'function') {
                var pieceUsd = getCatalogPieceSellUsd(prod);
                if (pieceUsd > 0) return pieceUsd;
            }
            var pu = parseFloat(prod.price_usd);
            if (isFinite(pu) && pu > 0) return pu;
            var iqd0 = typeof getPriceForUnit === 'function' ? getPriceForUnit(prod, 'piece', table) : (Number(prod.price) || 0);
            return (r > 0 && iqd0 > 0) ? (iqd0 / r) : 0;
        }
        try { window.getCatalogBillUnitUsdAtAdd = getCatalogBillUnitUsdAtAdd; } catch (_eGcu) {}
        /** Wholesale unit in USD (wholesalePrice stored as IQD in DB). */
        function getCatalogWholesaleBillUnitUsd(prod) {
            if (!prod) return 0;
            var wp = parseFloat(prod.wholesalePrice);
            if (!isFinite(wp) || wp <= 0) return 0;
            var r = typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0;
            return (r > 0) ? parseFloat((wp / r).toFixed(6)) : 0;
        }
        /** Normalize product id for comparison (number or NaN for non-product items like manual 'M123'). */
        function normalizeProductId(id) {
            if (id == null) return NaN;
            var n = Number(id);
            return (typeof id === 'string' && id.charAt(0) === 'M') ? NaN : (isNaN(n) ? NaN : n);
        }
        /** Convert cart items for one product to total pieces (piece/pack/carton). Used for display formula: server qty - in-cart = shown. */
        function getPiecesInTableItems(productId, items) {
            if (!items || !items.length) return 0;
            var pid = normalizeProductId(productId);
            if (isNaN(pid)) return 0;
            var prod = db.products && db.products.find(function(p) { return normalizeProductId(p.id) === pid; });
            if (!prod) return 0;
            var f = getProductUnitFactors(prod);
            var sum = 0;
            items.forEach(function(item) {
                if (normalizeProductId(item.id) !== pid) return;
                var u = item.saleUnit || 'piece';
                var qty = getItemQty(item);
                if (u === 'carton') sum += f.piecesPerCarton * qty;
                else if (u === 'pack') sum += f.piecesPerPack * qty;
                else sum += qty;
            });
            return sum;
        }

        /** الرصيد المعروض = رصيد المخزن الحقيقي ناقصاً المحجوز في كل السلال النشطة (جميع الطاولات). مصدر واحد — لا تغيير لـ product.qty. */
        /** Pieces sellable now: warehouse/default WH qty when ahead; batch cap only when batch is the limit. */
        function getSellablePieceQty(product) {
            if (!product || !product.trackStock) return product ? (product.qty || 0) : 0;
            var whId = 0;
            if (typeof getSaleWarehouseId === 'function') whId = getSaleWarehouseId();
            if (!whId && typeof getWorkingWarehouseId === 'function') whId = getWorkingWarehouseId();
            if (!whId && typeof getDefaultWarehouseId === 'function') whId = getDefaultWarehouseId();
            if (whId && typeof getProductQtyForWarehouse === 'function') {
                return getProductQtyForWarehouse(product, whId);
            }
            return parseFloat(product.qty) || 0;
        }
        window.getSellablePieceQty = getSellablePieceQty;

        function getReservedPiecesInCart(items, productId) {
            var reserved = 0;
            if (!items || !Array.isArray(items)) return 0;
            items.forEach(function (item) {
                var qty = typeof getItemQty === 'function' ? getItemQty(item) : (Number(item.qty || item.count) || 1);
                if (!(qty > 0)) return;

                // Direct line for this product
                if (String(item.id) === String(productId) && item.trackStock !== false) {
                    var mult = 1;
                    if (item.saleUnit === 'carton') {
                        var ppp = item.pieces_per_pack || 1;
                        var ppc = item.packs_per_carton || 1;
                        mult = ppp * ppc;
                        if (mult <= 1 && item.itemsPerCarton > 1) mult = item.itemsPerCarton;
                    } else if (item.saleUnit === 'pack') {
                        mult = item.pieces_per_pack || 1;
                    }
                    reserved += (mult * qty);
                }

                // Jewelry set in cart reserves member pieces (گووهار/رستە…)
                var setMembers = item.jewelry_set_items;
                if ((!setMembers || !setMembers.length) && item.is_jewelry_set && typeof getJewelrySetMembers === 'function') {
                    var setProd = (typeof db !== 'undefined' && db.products)
                        ? db.products.find(function (p) { return String(p.id) === String(item.id); })
                        : null;
                    if (setProd) setMembers = getJewelrySetMembers(setProd);
                }
                if (setMembers && setMembers.length) {
                    setMembers.forEach(function (m) {
                        var mid = m.product_id != null ? m.product_id : m.id;
                        if (String(mid) !== String(productId)) return;
                        var need = Math.max(0.001, parseFloat(m.qty) || 1);
                        reserved += need * qty;
                    });
                }
            });
            return reserved;
        }

        function getDisplayQty(product) {
            if (!product) return 0;
            var enforceJewelry = (typeof jewelryEnforcesStock === 'function' && jewelryEnforcesStock(product));
            if (!product.trackStock && !enforceJewelry) return parseFloat(product.qty) || 0;
            return typeof getPosAvailablePieces === 'function'
                ? getPosAvailablePieces(product)
                : (parseFloat(product.qty) || 0);
        }

        /** تحويل القطع المتاحة إلى قيمة عرض حسب الوحدة المختارة (کارتۆن/پاکێت/تاک). دقة كاملة باستخدام getProductUnitFactors. */
        function getDisplayQtyInSelectedUnit(product) {
            if (!product) return { value: 0, hasStock: false };
            var enforceJewelry = (typeof jewelryEnforcesStock === 'function' && jewelryEnforcesStock(product));
            var jewelrySet = (typeof isJewelrySetProduct === 'function' && isJewelrySetProduct(product));
            if (jewelrySet && typeof jewelrySetAvailableCompleteSets === 'function') {
                var setsLeft = jewelrySetAvailableCompleteSets(product);
                var isNegSet = (db && db.settings && (db.settings.allowNegativeStock == true || db.settings.allowNegativeStock == 'true' || db.settings.allowNegativeStock == 1));
                return {
                    value: setsLeft,
                    hasStock: isNegSet ? true : setsLeft > 0,
                    totalPieces: setsLeft
                };
            }
            if (!product.trackStock && !enforceJewelry) return { value: '\u221E', hasStock: true };
            var pieces = typeof getDisplayQty === 'function' ? getDisplayQty(product) : (product.qty || 0);
            var unit = typeof posSelectedUnit !== 'undefined' ? posSelectedUnit : 'piece';
            var f = getProductUnitFactors(product);
            var value;
            var isNegAllowed = (db && db.settings && (db.settings.allowNegativeStock == true || db.settings.allowNegativeStock == 'true' || db.settings.allowNegativeStock == 1));
            
            if (unit === 'carton') value = f.piecesPerCarton > 0 ? (pieces < 0 ? Math.ceil(pieces / f.piecesPerCarton) : Math.floor(pieces / f.piecesPerCarton)) : 0;
            else if (unit === 'pack') value = f.piecesPerPack > 0 ? (pieces < 0 ? Math.ceil(pieces / f.piecesPerPack) : Math.floor(pieces / f.piecesPerPack)) : 0;
            else value = (isWeightProduct(product) || (pieces % 1 !== 0)) ? (isNegAllowed ? pieces : Math.max(0, pieces)) : (isNegAllowed ? Math.ceil(pieces) : Math.max(0, Math.floor(pieces)));
            
            var hasStock;
            if (isNegAllowed) {
                hasStock = true;
            } else if (productBarcodesAreShared(product) === 'shared' && (unit === 'pack' || unit === 'carton')) {
                hasStock = pieces >= getPosPiecesNeededForUnit(unit, product);
            } else {
                hasStock = pieces > 0;
            }
            return { value: value, hasStock: hasStock, totalPieces: pieces };
        }

        /** Update only the qty badge (and card state) for one product card. Targeted DOM update — no re-render, zero flicker. */
        function updateProductCardQty(productId, qty, trackStock) {
            var container = document.getElementById('pos-products');
            if (!container) return;
            var card = container.querySelector('.p-card[data-product-id="' + productId + '"]');
            if (!card) return;
            var badge = card.querySelector('.qty-badge');
            if (!badge) return;
            var prod = db.products && db.products.find(function(p) { return String(p.id) === String(productId); });
            var displayVal;
            var hasStock;
            if (!trackStock) {
                displayVal = '\u221E';
                hasStock = true;
            } else if (typeof getDisplayQtyInSelectedUnit === 'function' && prod) {
                var unitDisplay = getDisplayQtyInSelectedUnit(prod);
                displayVal = unitDisplay.value;
                hasStock = (db.settings.allowNegativeStock == true || db.settings.allowNegativeStock == 'true' || db.settings.allowNegativeStock == 1) ? true : unitDisplay.hasStock;
            } else {
                displayVal = qty;
                hasStock = (db.settings.allowNegativeStock == true || db.settings.allowNegativeStock == 'true' || db.settings.allowNegativeStock == 1) ? true : qty > 0;
            }
            var finalDisplay = trackStock
                ? posQtyBadgeLabel(prod, hasStock, displayVal)
                : '\u221E';
            var unitSuffix = (trackStock && typeof getProductUnitLabel === 'function' && prod)
                ? (' ' + getProductUnitLabel(prod, (typeof posSelectedUnit !== 'undefined' ? posSelectedUnit : 'piece')))
                : '';
            badge.textContent = finalDisplay + unitSuffix;
            if (trackStock) { badge.style.background = hasStock ? '' : 'rgba(239, 68, 68, 0.85)'; } else { badge.style.background = 'rgba(16, 185, 129, 0.8)'; }
            if (typeof isShowStockOnPosEnabled === 'function' ? !isShowStockOnPosEnabled() : (db && db.settings && (db.settings.showStockOnPos === false || db.settings.showStockOnPos === 'false' || db.settings.showStockOnPos === 0))) {
                badge.style.display = 'none';
            } else {
                badge.style.display = 'flex';
            }
            card.classList.remove('unified-card-disabled');
            if (!card.getAttribute('data-pos-add')) card.setAttribute('data-pos-add', '1');
        }

        /** مصدر واحد: الواجهة تُحدَّث من معادلة ثابتة فقط. الكمية المعروضة = (رصيد DB) - (مجموع القطع في كل السلال). لا تحديث يدوي — أي تغيير في السلة يمر من هنا. Sync is synchronous so numbers stay accurate. */
        function refreshAllStockDisplaysFromState() {
            var container = document.getElementById('pos-products');
            var viewPos = document.getElementById('view-pos');
            if (typeof isPosCpuSaveMode === 'function' && isPosCpuSaveMode()) {
                if (!viewPos || !viewPos.classList.contains('active')) return;
            }
            
            // Build a quick lookup map for products to avoid O(N^2) performance issues
            var prodMap = {};
            if (db && db.products) {
                for (var i = 0; i < db.products.length; i++) {
                    prodMap[db.products[i].id] = db.products[i];
                }
            }

            if (container && viewPos && viewPos.classList.contains('active')) {
                if (container.classList.contains('pos-virtual-active') && typeof posVirtualMenuRepaint === 'function') {
                    posVirtualMenuRepaint();
                    return;
                }
                /* POS active: update every visible card from current state (DOM-only, no productIds list). */
                container.querySelectorAll('.p-card[data-product-id]').forEach(function(card) {
                    var pid = parseInt(card.getAttribute('data-product-id'), 10);
                    if (isNaN(pid)) return;
                    var prod = prodMap[pid];
                    if (prod && typeof updateProductCardQty === 'function') {
                        var displayQty = typeof getDisplayQty === 'function' ? getDisplayQty(prod) : (prod.qty || 0);
                        updateProductCardQty(pid, displayQty, prod.trackStock);
                    }
                });
                return;
            }
            var productIds = {};
            if (db.tables && db.tables.length) {
                db.tables.forEach(function(t) {
                    (t.items || []).forEach(function(item) {
                        if (item.id != null) productIds[item.id] = true;
                    });
                });
            }
            if (container) {
                container.querySelectorAll('.p-card[data-product-id]').forEach(function(card) {
                    var pid = parseInt(card.getAttribute('data-product-id'), 10);
                    if (!isNaN(pid)) productIds[pid] = true;
                });
            }
            for (var id in productIds) {
                var pid = parseInt(id, 10);
                var prod = prodMap[pid];
                if (prod && typeof updateProductCardQty === 'function') {
                    var displayQty = typeof getDisplayQty === 'function' ? getDisplayQty(prod) : (prod.qty || 0);
                    updateProductCardQty(pid, displayQty, prod.trackStock);
                }
            }
        }

        /** Cart UI update. fast:true = patch existing row + total instantly; SQL save stays in the background. */
        function patchPosCartLineFast(productId, saleUnit) {
            var container = document.getElementById('bill-rows');
            var table = (typeof findActivePosTable === 'function') ? findActivePosTable() : null;
            if (!container || !table || !Array.isArray(table.items)) return false;
            if (container.querySelector('.pos-empty-state')) return false;
            if (!table.items.length) {
                var leftover = container.querySelectorAll('.bill-row[data-pos-cart-pid="' + String(productId) + '"]');
                if (!leftover.length) return false;
                for (var li = 0; li < leftover.length; li++) leftover[li].remove();
                return true;
            }
            var rows = container.querySelectorAll('.bill-row[data-pos-cart-pid="' + String(productId) + '"]');
            var row = null;
            if (saleUnit) {
                for (var ri = 0; ri < rows.length; ri++) {
                    if ((rows[ri].getAttribute('data-pos-cart-unit') || 'piece') === saleUnit
                        && rows[ri].getAttribute('data-pos-cart-gift') !== '1') {
                        row = rows[ri];
                        break;
                    }
                }
            } else if (rows.length === 1) {
                row = rows[0];
            }
            if (!row) return false;
            var unit = row.getAttribute('data-pos-cart-unit') || 'piece';
            var gift = row.getAttribute('data-pos-cart-gift') === '1';
            var count = 0;
            var subtotal = 0;
            var sample = null;
            for (var i = 0; i < table.items.length; i++) {
                var it = table.items[i];
                if (!it || String(it.id) !== String(productId)) continue;
                if ((it.saleUnit || 'piece') !== unit) continue;
                if (!!it.isGift !== gift) continue;
                var q = (typeof getItemQty === 'function') ? getItemQty(it) : (Number(it.qty) || Number(it.count) || 1);
                var unitIqd = (typeof getBillLineUnitIqd === 'function') ? getBillLineUnitIqd(it) : (Number(it.price) || 0);
                count += q;
                subtotal += unitIqd * q;
                sample = it;
            }
            if (!sample || !(count > 0)) {
                row.remove();
                return true;
            }
            var qtyInput = row.querySelector('.returns-row-qty-wrap input.pos-cart-input');
            if (qtyInput) {
                qtyInput.value = (typeof formatQtyForInput === 'function') ? formatQtyForInput(count) : String(count);
            }
            var totalEl = row.querySelector('.returns-row-total');
            if (totalEl && typeof formatPosLineSubtotal === 'function') {
                totalEl.innerHTML = formatPosLineSubtotal(subtotal, sample, count);
            }
            return true;
        }
        window.patchPosCartLineFast = patchPosCartLineFast;

        function onCartChanged(opts) {
            opts = opts || {};
            var _txnLite = typeof isPosTxnLiteMode === 'function' && isPosTxnLiteMode();
            var liveTable = (typeof findActivePosTable === 'function') ? findActivePosTable() : null;
            var cartEmpty = !liveTable || !Array.isArray(liveTable.items) || liveTable.items.length === 0;
            var canFast = !opts.forceRender && opts.productId != null && (opts.fast === true || _txnLite) && !opts.removed && !cartEmpty;
            if (canFast) {
                var patched = false;
                if (typeof patchPosCartLineFast === 'function') {
                    patched = patchPosCartLineFast(opts.productId, opts.saleUnit);
                }
                if (!patched && typeof appendPosCartLineFast === 'function') {
                    patched = appendPosCartLineFast(opts.productId, opts.saleUnit);
                }
                if (patched) {
                    if (typeof renderBillTotal === 'function') renderBillTotal();
                    if (typeof refreshStockForProduct === 'function') {
                        refreshStockForProduct(opts.productId);
                    }
                    setTimeout(function () {
                        if (typeof scheduleSave === 'function') scheduleSave();
                        if (typeof scheduleRecalcBulkPrices === 'function') scheduleRecalcBulkPrices();
                        if (typeof scheduleTabSnapshot === 'function') scheduleTabSnapshot();
                    }, 0);
                    return;
                }
            }
            if (typeof scheduleSave === 'function') scheduleSave();
            if (typeof scheduleRecalcBulkPrices === 'function') scheduleRecalcBulkPrices();
            if (typeof renderBill === 'function') renderBill();
            if (opts.productId != null && typeof refreshStockForProduct === 'function') {
                refreshStockForProduct(opts.productId);
            } else if (typeof refreshAllStockDisplaysFromState === 'function') {
                refreshAllStockDisplaysFromState();
            }
            var viewWh = document.getElementById('view-warehouse');
            if (viewWh && viewWh.classList.contains('active')) {
                if (typeof refreshWmsStockCellForProduct === 'function' && opts.productId != null) {
                    refreshWmsStockCellForProduct(opts.productId);
                } else if (typeof refreshWmsStockCellsFromCart === 'function') {
                    refreshWmsStockCellsFromCart();
                }
            }
            scheduleTabSnapshot();
        }

        function refreshStockDependentViews() {
            var viewPos = document.getElementById('view-pos');
            if (viewPos && viewPos.classList.contains('active') && typeof renderPOSMenu === 'function') {
                renderPOSMenu(getCurrentPOSSearch(), true);
            }
            var viewProducts = document.getElementById('view-products');
            if (viewProducts && viewProducts.classList.contains('active') && typeof renderProducts === 'function') {
                var prodInput = document.getElementById('products-search-input');
                renderProducts(prodInput ? prodInput.value : '');
            }
            var viewWarehouse = document.getElementById('view-warehouse');
            if (viewWarehouse && viewWarehouse.classList.contains('active') && typeof renderWarehouse === 'function') {
                renderWarehouse();
            }
        }

        /* --- POS MULTI-ORDER TABS (ORDER 1, ORDER 2, ...) --- */
        const POS_MAX_TABS = (typeof POS_CART_TABS_HARD_MAX !== 'undefined') ? POS_CART_TABS_HARD_MAX : 8;
        let posTabs = [];
        let activePosTabIndex = 0;
        let posTabsActiveTableId = null;

        function createEmptyPosTab(orderNumber) {
            return {
                orderNumber: orderNumber || 1,
                items: [],
                manualDiscount: null,
                discountInput: '',
                customerName: '',
                isTakeaway: false,
                takeawayVisible: false
            };
        }

        function initPosTabs() {
            const viewPos = document.getElementById('view-pos');
            const container = document.getElementById('pos-tabs-container');
            if (!viewPos || !container) return;

            // Respect settings toggle
            const multiEnabled = db && db.settings ? (db.settings.enableMultiCartTabs !== false) : true;
            container.style.display = multiEnabled ? 'flex' : 'none';
            if (!multiEnabled) return;

            if (!db || !db.tables) return;
            if (!activeTableId && typeof ensureDefaultCart === 'function') {
                ensureDefaultCart();
            }

            if (!activeTableId) return;

            if (String(posTabsActiveTableId) !== String(activeTableId)) {
                let loaded = false;
                try {
                    const saved = localStorage.getItem('pos_tabs_state_' + activeTableId);
                    if (saved) {
                        const parsed = JSON.parse(saved);
                        if (parsed && Array.isArray(parsed.tabs) && parsed.tabs.length > 0) {
                            posTabs = parsed.tabs.map(function (tab) {
                                if (!tab || typeof tab !== 'object') return createEmptyPosTab(1);
                                if (tab.items && typeof tab.items === 'object' && !Array.isArray(tab.items)) {
                                    tab.items = Object.keys(tab.items).map(function (k) { return tab.items[k]; });
                                }
                                if (!Array.isArray(tab.items)) tab.items = [];
                                return tab;
                            });
                            activePosTabIndex = (typeof parsed.activeIndex === 'number') ? parsed.activeIndex : 0;
                            if (activePosTabIndex < 0) activePosTabIndex = 0;
                            if (activePosTabIndex >= posTabs.length) activePosTabIndex = 0;
                            posTabsActiveTableId = activeTableId;
                            loaded = true;
                            var tabSnap = posTabs[activePosTabIndex];
                            if (!tabSnap) {
                                posTabs[activePosTabIndex] = createEmptyPosTab(activePosTabIndex + 1);
                                tabSnap = posTabs[activePosTabIndex];
                            }
                            applyPosTabSnapshot(tabSnap);
                        }
                    }
                } catch(e) {}

                if (!loaded) {
                    posTabs = [];
                    activePosTabIndex = 0;
                    posTabsActiveTableId = activeTableId;
                    var tableSeed = (typeof findActivePosTable === 'function') ? findActivePosTable() : db.tables.find(function (t) { return String(t.id) === String(activeTableId); });
                    var firstTab = createEmptyPosTab(1);
                    if (tableSeed && Array.isArray(tableSeed.items) && tableSeed.items.length > 0) {
                        firstTab.items = tableSeed.items.map(function (i) { return Object.assign({}, i); });
                    }
                    posTabs.push(firstTab);
                    applyPosTabSnapshot(firstTab);
                }
            }

            if (!Array.isArray(posTabs) || posTabs.length === 0) {
                posTabs = [];
                posTabs.push(createEmptyPosTab(1));
                activePosTabIndex = 0;
                applyPosTabSnapshot(posTabs[0]);
            }

            var _maxCarts = (typeof getPosMaxCartTabsAllowed === 'function') ? getPosMaxCartTabsAllowed() : 2;
            if (typeof activePosTabIndex === 'number' && activePosTabIndex >= _maxCarts) {
                activePosTabIndex = 0;
                if (posTabs[0] && typeof applyPosTabSnapshot === 'function') applyPosTabSnapshot(posTabs[0]);
            }

            renderPosTabsUI();
            if (typeof renderBill === 'function') renderBill();
        }

        function renderPosTabsUI() {
            const container = document.getElementById('pos-tabs-container');
            const viewPos = document.getElementById('view-pos');
            if (!container || !viewPos || !viewPos.classList.contains('active')) return;

            const multiEnabled = db && db.settings ? (db.settings.enableMultiCartTabs !== false) : true;
            container.style.display = multiEnabled ? 'flex' : 'none';
            if (!multiEnabled) return;

            container.innerHTML = '';

            const safeTabs = posTabs || [];
            const activeIndex = typeof activePosTabIndex === 'number' ? activePosTabIndex : 0;
            const maxAllowed = (typeof getPosMaxCartTabsAllowed === 'function') ? getPosMaxCartTabsAllowed() : 2;
            const invoiceWord = (typeof t === 'function') ? t('pos_cart_tab_label') : 'فاتورا';
            const slotCount = POS_MAX_TABS;
            let html = '';

            for (var idx = 0; idx < slotCount; idx++) {
                const tab = safeTabs[idx] || null;
                const isLocked = idx >= maxAllowed;
                const isActive = !isLocked && idx === activeIndex;
                const itemCount = tab && Array.isArray(tab.items) ? tab.items.length : 0;
                const hasItems = itemCount > 0;
                const isLast = idx === safeTabs.length - 1;
                const label = invoiceWord + ' ' + (idx + 1);
                const counterText = itemCount > 99 ? '99+' : String(itemCount);
                const lockTitle = (typeof t === 'function') ? t('cart_tabs_cap_upgrade_feature').replace(/\{max\}/g, String(maxAllowed)) : 'Pro';
                html += '<button type="button" class="pos-tab pos-tab-slot-' + (idx + 1) + (isActive ? ' pos-tab-active' : '') + (isLocked ? ' pos-tab-locked' : '') + '"'
                    + (isLocked ? ' data-tab-locked-index="' + idx + '"' : ' data-tab-index="' + idx + '"')
                    + ' title="' + escapeHtml(isLocked ? lockTitle : label) + '">'
                    + '<span class="pos-tab-label"><i class="fas fa-' + (isLocked ? 'lock' : 'file-invoice') + '"></i> ' + escapeHtml(label) + '</span>'
                    + (hasItems && !isLocked ? '<span class="pos-tab-counter">' + counterText + '</span>' : '')
                    + (hasItems && isLast && safeTabs.length > 1 && !isLocked ? '<button type="button" class="pos-tab-clear" data-tab-delete-index="' + idx + '" tabindex="-1" title="ژێبرن"><i class="fas fa-times"></i></button>' : '')
                    + '</button>';
            }

            if (safeTabs.length < maxAllowed && safeTabs.length < POS_MAX_TABS) {
                const placeholderIndex = safeTabs.length;
                var newLabel = invoiceWord + ' ' + (placeholderIndex + 1);
                html += '<button type="button" class="pos-tab pos-tab-faded" data-tab-new-index="' + placeholderIndex + '" title="' + escapeHtml(newLabel) + '"><span><i class="fas fa-plus"></i> ' + escapeHtml((typeof t === 'function') ? t('pos_cart_tab_new') : 'نوێ') + '</span></button>';
            }

            container.innerHTML = html;

            // --- UPDATE BILL HEADER WITH TAB NAME ---
            const activeTableEl = document.getElementById('pos-active-table');
            if (activeTableEl && activeTableId) {
                const table = db.tables.find(t => t.id === activeTableId);
                if (table) {
                    const tabNum = activeIndex + 1;
                    let tabColor = 'var(--brand)';
                    if (tabNum === 2) tabColor = '#15803d'; // Green
                    if (tabNum === 3) tabColor = '#ea580c'; // Orange
                    if (tabNum === 4) tabColor = '#b91c1c'; // Red
                    
                    activeTableEl.innerHTML = `🛒 ${escapeHtml(table.name)} <span style="background:${tabColor}; color:white; padding:4px 12px; border-radius:12px; font-size:0.95em; margin-right:12px; font-weight:900; box-shadow:0 4px 10px rgba(0,0,0,0.3); border:2px solid rgba(255,255,255,0.2); display:inline-block; transform:translateY(-2px);">📝 فاتورا ${tabNum}</span>`;
                }
            }

            container.querySelectorAll('[data-tab-index]').forEach(function (btn) {
                btn.onclick = function () {
                    const idx = parseInt(this.getAttribute('data-tab-index'), 10);
                    switchPosTab(idx);
                };
            });

            container.querySelectorAll('[data-tab-locked-index]').forEach(function (btn) {
                btn.onclick = function () {
                    if (typeof showCartTabsCapPurchasePopup === 'function') showCartTabsCapPurchasePopup();
                };
            });

            container.querySelectorAll('[data-tab-new-index]').forEach(function (btn) {
                btn.onclick = function () {
                    const idx = parseInt(this.getAttribute('data-tab-new-index'), 10);
                    if (typeof isPosCartTabAllowed === 'function' && !isPosCartTabAllowed(idx)) {
                        if (typeof showCartTabsCapPurchasePopup === 'function') showCartTabsCapPurchasePopup();
                        return;
                    }
                    createAndSwitchToPosTab(idx);
                };
            });

            container.querySelectorAll('[data-tab-delete-index]').forEach(function (btn) {
                btn.onclick = function (e) {
                    e.stopPropagation();
                    const idx = parseInt(this.getAttribute('data-tab-delete-index'), 10);
                    deletePosTab(idx);
                };
            });
        }

        function saveActivePosTabSnapshot() {
            const viewPos = document.getElementById('view-pos');
            if (!viewPos || !viewPos.classList.contains('active')) return;
            if (!db || !db.tables) return;
            if (!activeTableId) return;
            if (!posTabsActiveTableId) posTabsActiveTableId = activeTableId;
            if (posTabsActiveTableId != null && String(posTabsActiveTableId) !== String(activeTableId)) return;

            const table = (typeof findActivePosTable === 'function') ? findActivePosTable() : db.tables.find(function (t) { return String(t.id) === String(activeTableId); });
            if (!table) return;

            if (!Array.isArray(posTabs)) posTabs = [];
            if (typeof activePosTabIndex !== 'number') activePosTabIndex = 0;
            if (!posTabs[activePosTabIndex]) {
                posTabs[activePosTabIndex] = createEmptyPosTab(activePosTabIndex + 1);
            }

            const discountInputEl = document.getElementById('pos-discount');
            const customerNameEl = document.getElementById('pos-customer-name');
            const badge = document.getElementById('pos-takeaway-badge');

            const tab = posTabs[activePosTabIndex];
            tab.items = Array.isArray(table.items) ? table.items.map(function (i) { return Object.assign({}, i); }) : [];
            tab.manualDiscount = (table.manualDiscount !== undefined && table.manualDiscount !== null) ? table.manualDiscount : null;
            tab.discountInput = discountInputEl ? discountInputEl.value : '';
            const custName = customerNameEl ? String(customerNameEl.value || '').trim() : '';
            tab.customerName = custName;
            tab.customerId = custName ? ((customerNameEl && customerNameEl.getAttribute('data-customer-id')) || window.__posActiveCustomerId || null) : null;
            tab.isTakeaway = !!table.isTakeaway;
            tab.takeawayVisible = badge ? (badge.style.display !== 'none') : false;

            try {
                localStorage.setItem('pos_tabs_state_' + posTabsActiveTableId, JSON.stringify({
                    tabs: posTabs,
                    activeIndex: activePosTabIndex
                }));
            } catch(e) {}
        }
        window.saveActivePosTabSnapshot = saveActivePosTabSnapshot;

        window.clearActivePosTabAfterSale = function() {
            if (typeof cancelPendingPosTabSnapshot === 'function') cancelPendingPosTabSnapshot();
            if (!Array.isArray(posTabs)) posTabs = [];
            if (typeof activePosTabIndex !== 'number') activePosTabIndex = 0;
            if (posTabs[activePosTabIndex]) {
                posTabs[activePosTabIndex].items = [];
                posTabs[activePosTabIndex].manualDiscount = null;
                posTabs[activePosTabIndex].discountInput = '';
                posTabs[activePosTabIndex].customerName = '';
                posTabs[activePosTabIndex].customerId = null;
            }
            var table = (typeof findActivePosTable === 'function') ? findActivePosTable() : null;
            if (table) {
                table.items = [];
                if (typeof clearPosCartDiscount === 'function') clearPosCartDiscount(table);
            }
            if (typeof window.clearPosCustomerCheckoutState === 'function') {
                window.clearPosCustomerCheckoutState({ skipToggle: true });
            } else {
                window.__posActiveCustomerId = null;
                [
                    'pos-customer-name', 'pos-expand-customer-name',
                    'pos-customer-paid', 'pos-expand-customer-paid',
                    'pos-customer-phone', 'pos-expand-customer-phone'
                ].forEach(function (id) {
                    var el = document.getElementById(id);
                    if (!el) return;
                    el.value = '';
                    if (el.removeAttribute) el.removeAttribute('data-customer-id');
                });
            }
            try {
                var tid = posTabsActiveTableId || activeTableId;
                if (tid) {
                    localStorage.setItem('pos_tabs_state_' + tid, JSON.stringify({
                        tabs: posTabs,
                        activeIndex: activePosTabIndex
                    }));
                }
            } catch (eClr) {}
            if (typeof renderPosTabsUI === 'function') renderPosTabsUI();
        };

        function applyPosTabSnapshot(tab) {
            if (!tab || !db || !db.tables) return;
            if (!activeTableId) return;

            const table = (typeof findActivePosTable === 'function') ? findActivePosTable() : db.tables.find(function (t) { return String(t.id) === String(activeTableId); });
            if (!table) return;

            table.items = Array.isArray(tab.items) ? tab.items.map(function (i) { return Object.assign({}, i); }) : [];

            if (tab.manualDiscount !== null && tab.manualDiscount !== undefined) {
                table.manualDiscount = tab.manualDiscount;
            } else {
                delete table.manualDiscount;
            }

            const discountInputEl = document.getElementById('pos-discount');
            const customerNameEl = document.getElementById('pos-customer-name');
            const expandNameEl = document.getElementById('pos-expand-customer-name');
            const badge = document.getElementById('pos-takeaway-badge');

            if (discountInputEl) discountInputEl.value = tab.discountInput || '';
            const custName = tab.customerName ? String(tab.customerName).trim() : '';
            const custId = (custName && tab.customerId) ? tab.customerId : null;
            if (customerNameEl) {
                customerNameEl.value = custName;
                if (custId) {
                    customerNameEl.setAttribute('data-customer-id', custId);
                } else {
                    customerNameEl.removeAttribute('data-customer-id');
                }
            }
            if (expandNameEl) {
                expandNameEl.value = custName;
                if (custId) {
                    expandNameEl.setAttribute('data-customer-id', custId);
                } else {
                    expandNameEl.removeAttribute('data-customer-id');
                }
            }
            window.__posActiveCustomerId = custId;
            if (typeof window.updatePosCustomerClearBtnState === 'function') window.updatePosCustomerClearBtnState();
            if (typeof toggleCreditButton === 'function') toggleCreditButton();
            if (typeof calculateDebtRemaining === 'function') calculateDebtRemaining();

            table.isTakeaway = !!tab.isTakeaway;
            if (badge) badge.style.display = tab.takeawayVisible ? 'inline-block' : 'none';

            lastTableState = "";
            if (typeof onCartChanged === 'function') onCartChanged({ forceRender: true });
            if (typeof renderBill === 'function') renderBill();
        }

        function switchPosTab(targetIndex) {
            if (!Array.isArray(posTabs)) posTabs = [];
            if (typeof targetIndex !== 'number') return;
            if (targetIndex < 0 || targetIndex >= POS_MAX_TABS) return;
            if (typeof isPosCartTabAllowed === 'function' && !isPosCartTabAllowed(targetIndex)) {
                if (typeof showCartTabsCapPurchasePopup === 'function') showCartTabsCapPurchasePopup();
                return;
            }

            if (!activeTableId && typeof ensureDefaultCart === 'function') {
                ensureDefaultCart();
            }
            if (!activeTableId) return;

            if (!posTabsActiveTableId) {
                posTabsActiveTableId = activeTableId;
            }
            if (String(posTabsActiveTableId) !== String(activeTableId)) {
                posTabs = [];
                activePosTabIndex = 0;
                posTabsActiveTableId = activeTableId;
            }

            if (typeof cancelPendingPosTabSnapshot === 'function') cancelPendingPosTabSnapshot();
            saveActivePosTabSnapshot();

            if (!posTabs[targetIndex]) {
                posTabs[targetIndex] = createEmptyPosTab(targetIndex + 1);
            }

            activePosTabIndex = targetIndex;
            applyPosTabSnapshot(posTabs[targetIndex]);
            
            try {
                localStorage.setItem('pos_tabs_state_' + posTabsActiveTableId, JSON.stringify({
                    tabs: posTabs,
                    activeIndex: activePosTabIndex
                }));
            } catch(e) {}
            
            renderPosTabsUI();
            if (typeof renderBill === 'function') renderBill();
            if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('pos', { clear: false, delay: 40 });
        }

        function createAndSwitchToPosTab(index) {
            if (!Array.isArray(posTabs)) posTabs = [];
            if (index < 0 || index >= POS_MAX_TABS) return;
            if (typeof isPosCartTabAllowed === 'function' && !isPosCartTabAllowed(index)) {
                if (typeof showCartTabsCapPurchasePopup === 'function') showCartTabsCapPurchasePopup();
                return;
            }

            if (!activeTableId && typeof ensureDefaultCart === 'function') ensureDefaultCart();
            if (!activeTableId) return;

            if (!posTabsActiveTableId) posTabsActiveTableId = activeTableId;
            if (String(posTabsActiveTableId) !== String(activeTableId)) {
                posTabs = [];
                activePosTabIndex = 0;
                posTabsActiveTableId = activeTableId;
            }

            if (typeof cancelPendingPosTabSnapshot === 'function') cancelPendingPosTabSnapshot();
            saveActivePosTabSnapshot();

            posTabs[index] = createEmptyPosTab(index + 1);
            activePosTabIndex = index;
            applyPosTabSnapshot(posTabs[index]);

            try {
                localStorage.setItem('pos_tabs_state_' + posTabsActiveTableId, JSON.stringify({
                    tabs: posTabs,
                    activeIndex: activePosTabIndex
                }));
            } catch (e) {}

            renderPosTabsUI();
            if (typeof renderBill === 'function') renderBill();
            if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('pos', { clear: false, delay: 40 });
        }

        function deletePosTab(index) {
            if (!Array.isArray(posTabs)) posTabs = [];
            if (index < 0 || index >= posTabs.length) return;
            // Sequential deletion: only allow deleting the last tab
            if (index !== posTabs.length - 1) return;

            // Remove last tab and clear its snapshot data implicitly
            posTabs.pop();

            if (posTabs.length === 0) {
                // Always keep at least one empty cart
                posTabs.push(createEmptyPosTab(1));
                activePosTabIndex = 0;
            } else if (activePosTabIndex >= posTabs.length) {
                // If we deleted the active last tab, move focus to previous
                activePosTabIndex = posTabs.length - 1;
            }

            // Apply currently active tab snapshot to live cart
            if (posTabs[activePosTabIndex]) {
                applyPosTabSnapshot(posTabs[activePosTabIndex]);
            }
            
            try {
                localStorage.setItem('pos_tabs_state_' + posTabsActiveTableId, JSON.stringify({
                    tabs: posTabs,
                    activeIndex: activePosTabIndex
                }));
            } catch(e) {}
            
            renderPosTabsUI();
            if (typeof renderBill === 'function') renderBill();
            if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('pos', { clear: false, delay: 40 });
        }

        let lastRenderedPosMenuQ = null;
        let lastRenderedPosMenuCategory = null;
        let lastRenderedPosMenuUnit = null;
        let lastRenderedPosMenuDisplayLimit = null;
        let posMenuDisplayLimit = 50;

        function getPosMenuPageSize() {
            return (typeof posMaxPosMenuProducts === 'function') ? posMaxPosMenuProducts() : 50;
        }

        function invalidatePosMenuListCache() {
            window._posSearchCache = null;
            window._posSearchCacheGen = '';
            window._posMenuListCache = null;
            window._posMenuListCacheKey = '';
        }
        window.invalidatePosMenuListCache = invalidatePosMenuListCache;

        function buildPosProductSearchCache() {
            const products = (db && db.products) ? db.products : [];
            const gen = products.length + ':' + (products.length ? products[products.length - 1].id : 0);
            if (window._posSearchCacheGen === gen && window._posSearchCache) return window._posSearchCache;
            window._posSearchCache = products.map(function (p) {
                return {
                    p: p,
                    normName: normalizeForSearch(p.name),
                    lowerName: (p.name || '').toLowerCase(),
                    lowerBarcode: p.barcode ? String(p.barcode).toLowerCase() : '',
                    lowerSku: p.sku ? String(p.sku).toLowerCase() : '',
                    normSku: p.sku ? normalizeForSearch(String(p.sku)) : ''
                };
            });
            window._posSearchCacheGen = gen;
            window._posMenuListCache = null;
            window._posMenuListCacheKey = '';
            return window._posSearchCache;
        }

        function posMenuSortProducts(list) {
            return list.sort(function (a, b) {
                if (db && db.settings && (db.settings.sortOutOfStockToBottom == true || db.settings.sortOutOfStockToBottom == 'true' || db.settings.sortOutOfStockToBottom == 1)) {
                    var aHasStock = a.trackStock ? (typeof getDisplayQty === 'function' ? getDisplayQty(a) : (a.qty || 0)) > 0 : true;
                    var bHasStock = b.trackStock ? (typeof getDisplayQty === 'function' ? getDisplayQty(b) : (b.qty || 0)) > 0 : true;
                    if (aHasStock && !bHasStock) return -1;
                    if (!aHasStock && bHasStock) return 1;
                }
                if (a.isPinned && !b.isPinned) return -1;
                if (!a.isPinned && b.isPinned) return 1;
                return b.id - a.id;
            });
        }

        function filterPosMenuFromCache(cache, q, category, unitFilter) {
            const lowerQ = (q || '').toLowerCase();
            const normQ = normalizeForSearch(q || '');
            const isSearch = lowerQ.length > 0;
            const out = [];
            const catTrim = String(category || '').trim();
            for (let i = 0; i < cache.length; i++) {
                const e = cache[i];
                const p = e.p;
                if (!isProductForSale(p)) continue;
                if (catTrim && catTrim !== 'all' && String(p.cat || '').trim() !== catTrim) continue;
                if (isSearch) {
                    const matches = (typeof productMatchesBarcodeOrNameSearch === 'function')
                        ? productMatchesBarcodeOrNameSearch(p, q)
                        : (e.lowerName.includes(lowerQ) || e.normName.includes(normQ)
                            || (e.lowerBarcode && e.lowerBarcode.includes(lowerQ))
                            || (e.lowerSku && (e.lowerSku.includes(lowerQ) || e.normSku.includes(normQ))));
                    if (!matches) continue;
                } else {
                    if (typeof productMatchesUnitFilter === 'function' && !productMatchesUnitFilter(p, unitFilter)) continue;
                }
                out.push(p);
            }
            return out;
        }

        function getPosMenuFullList(q, category, unitFilter) {
            const unit = unitFilter || 'piece';
            const cache = buildPosProductSearchCache();
            const _maxPos = getPosMenuPageSize();
            const lowerQ = (q || '').toLowerCase();
            const normQ = normalizeForSearch(q || '');

            if (category === 'top_selling' && (typeof isPosCpuSaveMode === 'function' && isPosCpuSaveMode())) {
                category = 'all';
            }
            if (category === 'top_selling') {
                if (typeof window._cachedTopSellingCounts === 'undefined') window._cachedTopSellingCounts = null;
                if (typeof window._cachedTopSellingSalesLength === 'undefined') window._cachedTopSellingSalesLength = -1;
                const allSales = getAllSales();
                if (!window._cachedTopSellingCounts || window._cachedTopSellingSalesLength !== allSales.length) {
                    const counts = {};
                    allSales.forEach(function (s) {
                        if (s.items) s.items.forEach(function (i) { counts[i.id] = (counts[i.id] || 0) + 1; });
                    });
                    window._cachedTopSellingCounts = counts;
                    window._cachedTopSellingSalesLength = allSales.length;
                }
                const counts = window._cachedTopSellingCounts;
                const isSearchActiveTop = lowerQ.length > 0;
                const topList = [];
                for (let i = 0; i < cache.length; i++) {
                    const e = cache[i];
                    const p = e.p;
                    if (!isProductForSale(p) || !(counts[p.id] > 0)) continue;
                    const matchesName = !isSearchActiveTop || (typeof productMatchesBarcodeOrNameSearch === 'function'
                        ? productMatchesBarcodeOrNameSearch(p, q)
                        : (e.lowerName.includes(lowerQ) || e.normName.includes(normQ)
                            || (e.lowerBarcode && e.lowerBarcode.includes(lowerQ))
                            || (e.lowerSku && (e.lowerSku.includes(lowerQ) || e.normSku.includes(normQ)))));
                    const matchesUnit = isSearchActiveTop ? true : (typeof productMatchesUnitFilter === 'function' ? productMatchesUnitFilter(p, unit) : true);
                    if (matchesName && matchesUnit) topList.push(p);
                }
                return topList.sort(function (a, b) {
                    if (db && db.settings && (db.settings.sortOutOfStockToBottom == true || db.settings.sortOutOfStockToBottom == 'true' || db.settings.sortOutOfStockToBottom == 1)) {
                        var aHasStock = a.trackStock ? (typeof getDisplayQty === 'function' ? getDisplayQty(a) : (a.qty || 0)) > 0 : true;
                        var bHasStock = b.trackStock ? (typeof getDisplayQty === 'function' ? getDisplayQty(b) : (b.qty || 0)) > 0 : true;
                        if (aHasStock && !bHasStock) return -1;
                        if (!aHasStock && bHasStock) return 1;
                    }
                    return (counts[b.id] || 0) - (counts[a.id] || 0);
                }).slice(0, Math.min(30, _maxPos));
            }

            const listCacheKey = String(category) + '|' + unit + '|' + cache.length;
            if (!lowerQ && window._posMenuListCache && window._posMenuListCacheKey === listCacheKey) {
                return window._posMenuListCache;
            }
            let list = filterPosMenuFromCache(cache, q, category, unit);
            if (lowerQ && typeof window.posFilterWorkerShouldUse === 'function' && window.posFilterWorkerShouldUse(cache.length, q)) {
                var wKey = String(q) + '|' + String(category) + '|' + String(unit);
                if (window._posWorkerFilterKey === wKey && Array.isArray(window._posWorkerFilterList)) {
                    list = window._posWorkerFilterList.slice();
                } else if (typeof window.posFilterViaWorker === 'function') {
                    window.posFilterViaWorker(cache, q, category, unit).then(function (filtered) {
                        if (!Array.isArray(filtered)) return;
                        window._posWorkerFilterKey = wKey;
                        window._posWorkerFilterList = filtered;
                        if (filtered.length && typeof posMenuSortProducts === 'function') {
                            window._posWorkerFilterList = posMenuSortProducts(filtered);
                        }
                        if (lastRenderedPosMenuQ === q && lastRenderedPosMenuCategory === category) {
                            renderPOSMenu(q, true);
                        }
                    });
                }
            } else if (!lowerQ) {
                window._posWorkerFilterKey = '';
                window._posWorkerFilterList = null;
            }
            if (lowerQ && typeof posGetServerMenuSearchRows === 'function') {
                var serverRows = posGetServerMenuSearchRows();
                if (serverRows && serverRows.length) {
                    var seenIds = Object.create(null);
                    list.forEach(function (p) { if (p && p.id != null) seenIds[String(p.id)] = true; });
                    serverRows.forEach(function (p) {
                        if (!p || p.id == null || seenIds[String(p.id)]) return;
                        if (!isProductForSale(p)) return;
                        if (category !== 'all' && p.cat !== category) return;
                        if (typeof productMatchesBarcodeOrNameSearch === 'function' && !productMatchesBarcodeOrNameSearch(p, q)) return;
                        if (!lowerQ && typeof productMatchesUnitFilter === 'function' && !productMatchesUnitFilter(p, unit)) return;
                        seenIds[String(p.id)] = true;
                        list.push(p);
                    });
                }
            }
            if (!lowerQ) {
                list = posMenuSortProducts(list);
                window._posMenuListCache = list;
                window._posMenuListCacheKey = listCacheKey;
            } else {
                list = posMenuSortProducts(list);
            }
            return list;
        }

        function resetPosMenuDisplayLimit() {
            posMenuDisplayLimit = getPosMenuPageSize();
            window._posWorkerFilterKey = '';
            window._posWorkerFilterList = null;
        }

        function loadMorePOSMenuProducts() {
            var q = (typeof getCurrentPOSSearch === 'function') ? getCurrentPOSSearch() : (lastRenderedPosMenuQ || '');
            var searchTrim = String(q || '').trim();
            if (!searchTrim && typeof posIsCatalogPartial === 'function' && posIsCatalogPartial()
                && typeof posFetchProductPage === 'function' && typeof posUpsertProducts === 'function') {
                var offset = (typeof posCatalogServerOffset === 'function') ? posCatalogServerOffset() : (Array.isArray(db.products) ? db.products.length : 0);
                var step = getPosMenuPageSize();
                posFetchProductPage(offset, step).then(function (data) {
                    if (!data || data.status !== 'ok' || !Array.isArray(data.rows) || !data.rows.length) {
                        var stepLocal = getPosMenuPageSize();
                        posMenuDisplayLimit = (posMenuDisplayLimit || stepLocal) + stepLocal;
                        renderPOSMenu(q, 'loadMore');
                        return;
                    }
                    posUpsertProducts(data.rows);
                    if (typeof posAdvanceCatalogServerOffset === 'function') posAdvanceCatalogServerOffset(data.rows.length);
                    posMenuDisplayLimit = (posMenuDisplayLimit || step) + data.rows.length;
                    renderPOSMenu(q, 'loadMore');
                });
                return;
            }
            var step = getPosMenuPageSize();
            posMenuDisplayLimit = (posMenuDisplayLimit || step) + step;
            renderPOSMenu(q, 'loadMore');
        }
        window.loadMorePOSMenuProducts = loadMorePOSMenuProducts;

        function isPosCardToolsVisible() {
            if (typeof window._posCardToolsVisible === 'boolean') return window._posCardToolsVisible;
            try {
                window._posCardToolsVisible = sessionStorage.getItem('posCardToolsVisible') === '1';
            } catch (e0) {
                window._posCardToolsVisible = false;
            }
            return !!window._posCardToolsVisible;
        }
        window.isPosCardToolsVisible = isPosCardToolsVisible;

        function updatePosCardToolsBtn() {
            var btn = document.getElementById('btn-pos-card-tools');
            if (!btn) return;
            var on = isPosCardToolsVisible();
            btn.classList.toggle('is-active', on);
            btn.setAttribute('aria-pressed', on ? 'true' : 'false');
            var tip = (typeof t === 'function')
                ? (on ? t('pos_card_tools_on') : t('pos_card_tools_off'))
                : (on ? 'پین + کرین: کارا' : 'پین + کرین: کوژاندن — شاشە سادە');
            btn.title = tip;
            btn.setAttribute('aria-label', tip);
        }
        window.updatePosCardToolsBtn = updatePosCardToolsBtn;

        function togglePosCardTools() {
            window._posCardToolsVisible = !isPosCardToolsVisible();
            try {
                sessionStorage.setItem('posCardToolsVisible', window._posCardToolsVisible ? '1' : '0');
            } catch (e1) {}
            updatePosCardToolsBtn();
            if (typeof hidePosCostTip === 'function') hidePosCostTip();
            if (typeof renderPOSMenu === 'function') {
                var q = (typeof getCurrentPOSSearch === 'function')
                    ? getCurrentPOSSearch()
                    : ((document.getElementById('pos-barcode-input') || {}).value || '');
                renderPOSMenu(q, true);
            }
        }
        window.togglePosCardTools = togglePosCardTools;

        function getPosProductCostForUnit(p, unit) {
            if (!p) return 0;
            var u = unit || (typeof posSelectedUnit !== 'undefined' ? posSelectedUnit : 'piece');
            var costPiece = typeof catalogIqdFromUsdField === 'function' ? catalogIqdFromUsdField(p, 'cost_usd', 'cost') : (Number(p.cost) || 0);
            if (isNaN(costPiece) || costPiece < 0) costPiece = 0;
            var costForUnit = costPiece;
            var fCost = typeof getProductUnitFactors === 'function' ? getProductUnitFactors(p) : { piecesPerPack: 1, piecesPerCarton: 1 };
            if (u === 'carton') {
                var costC = typeof catalogIqdFromUsdField === 'function' ? catalogIqdFromUsdField(p, 'cost_carton_usd', 'cost_carton') : Number(p.cost_carton);
                costForUnit = (!isNaN(costC) && costC > 0) ? costC : (costPiece * (fCost.piecesPerCarton || 1));
            } else if (u === 'pack') {
                var costPk = typeof catalogIqdFromUsdField === 'function' ? catalogIqdFromUsdField(p, 'cost_pack_usd', 'cost_pack') : Number(p.cost_pack);
                costForUnit = (!isNaN(costPk) && costPk > 0) ? costPk : (costPiece * (fCost.piecesPerPack || 1));
            }
            return costForUnit > 0 ? costForUnit : 0;
        }
        window.getPosProductCostForUnit = getPosProductCostForUnit;

        function hidePosCostTip() {
            var tip = document.getElementById('pos-cost-hover-tip');
            if (tip && tip.parentNode) tip.parentNode.removeChild(tip);
            window.__posCostTipActiveBtn = null;
            window.__posCostTipSticky = false;
            if (window.__posCostTipOutsideBound) {
                try { document.removeEventListener('pointerdown', hidePosCostTipOutside, true); } catch (e0) {}
                window.__posCostTipOutsideBound = false;
            }
        }
        window.hidePosCostTip = hidePosCostTip;

        function hidePosCostTipOutside(e) {
            var tip = document.getElementById('pos-cost-hover-tip');
            var btn = window.__posCostTipActiveBtn;
            if (!tip) return;
            if (btn && e && e.target && (btn === e.target || btn.contains(e.target))) return;
            if (e && e.target && (tip === e.target || tip.contains(e.target))) return;
            hidePosCostTip();
        }
        window.hidePosCostTipOutside = hidePosCostTipOutside;

        function placePosCostTip(tip, btn) {
            if (!tip || !btn) return;
            tip.style.zIndex = String(Math.max(600000, (parseInt(window._posOverlayZ, 10) || 25000) + 50));
            tip.style.visibility = 'hidden';
            tip.style.display = 'block';
            var rect = btn.getBoundingClientRect();
            var tipW = tip.offsetWidth || 180;
            var tipH = tip.offsetHeight || 48;
            var left = rect.left + (rect.width / 2) - (tipW / 2);
            var top = rect.top - tipH - 8;
            if (left < 6) left = 6;
            if (left + tipW > window.innerWidth - 6) left = window.innerWidth - tipW - 6;
            if (top < 6) top = rect.bottom + 8;
            tip.style.left = Math.round(left) + 'px';
            tip.style.top = Math.round(top) + 'px';
            tip.style.visibility = 'visible';
        }
        window.placePosCostTip = placePosCostTip;

        function ensurePosCostTipEl() {
            var tip = document.getElementById('pos-cost-hover-tip');
            if (!tip) {
                tip = document.createElement('div');
                tip.id = 'pos-cost-hover-tip';
                tip.className = 'pos-cost-hover-tip';
                tip.setAttribute('role', 'tooltip');
                document.body.appendChild(tip);
            }
            return tip;
        }
        window.ensurePosCostTipEl = ensurePosCostTipEl;

        function bindPosCostTipOutside() {
            if (window.__posCostTipOutsideBound) return;
            window.__posCostTipOutsideBound = true;
            setTimeout(function () {
                document.addEventListener('pointerdown', hidePosCostTipOutside, true);
            }, 0);
        }
        window.bindPosCostTipOutside = bindPosCostTipOutside;

        function showPosCostTip(btn, evt) {
            try {
                if (evt && evt.stopPropagation) evt.stopPropagation();
                if (evt && evt.cancelable && evt.type === 'pointerdown') evt.preventDefault();
            } catch (e0) {}
            if (!btn) return;
            if (typeof canViewCost === 'function' && !canViewCost()) return;
            var pid = btn.getAttribute('data-product-id');
            var prods = (window.db && Array.isArray(db.products)) ? db.products : [];
            var p = null;
            for (var i = 0; i < prods.length; i++) {
                if (String(prods[i].id) === String(pid)) { p = prods[i]; break; }
            }
            var costLabel = (typeof t === 'function') ? t('pos_card_cost') : 'کرین';
            var unit = typeof posSelectedUnit !== 'undefined' ? posSelectedUnit : 'piece';
            var costVal = p ? getPosProductCostForUnit(p, unit) : 0;
            var unitLabel = (p && typeof getProductUnitLabel === 'function') ? getProductUnitLabel(p, unit) : '';
            var amt = costVal > 0 ? (typeof formatCurrency === 'function' ? formatCurrency(costVal) : String(costVal)) : '—';
            var msg = costLabel + (unitLabel ? ' (' + unitLabel + ')' : '') + ': ' + amt;

            var tip = ensurePosCostTipEl();
            tip.classList.remove('is-sticky');
            tip.textContent = msg;
            window.__posCostTipSticky = false;
            window.__posCostTipActiveBtn = btn;
            placePosCostTip(tip, btn);
        }
        window.showPosCostTip = showPosCostTip;

        function posQtyBadgeLabel(p, hasStock, displayQty) {
            if (!p || !p.trackStock) return '\u221E';
            var n = parseFloat(displayQty) || 0;
            if (n > 0.000001) {
                return (typeof formatQtyForDisplay === 'function') ? formatQtyForDisplay(n, p) : String(n);
            }
            var elseLines = (typeof getOtherWarehouseStockLines === 'function')
                ? getOtherWarehouseStockLines(p, (typeof getSaleWarehouseId === 'function' ? getSaleWarehouseId() : 0))
                : [];
            if (elseLines.length) {
                var x = elseLines[0];
                var qn = (typeof formatQtyForDisplay === 'function') ? formatQtyForDisplay(x.qty, p) : String(x.qty);
                return 'ل ' + (x.name || 'کۆگەه') + ': ' + qn;
            }
            return (typeof formatQtyForDisplay === 'function') ? formatQtyForDisplay(0, p) : '0';
        }

        function buildPosProductCardHtml(p, activeTable) {
            const unitDisplay = typeof getDisplayQtyInSelectedUnit === 'function' ? getDisplayQtyInSelectedUnit(p) : { value: p.trackStock ? (p.qty || 0) : '\u221E', hasStock: !p.trackStock || (p.qty || 0) > 0 };
            const displayQty = unitDisplay.value;
            const isNegAllowed = (db.settings.allowNegativeStock == true || db.settings.allowNegativeStock == 'true' || db.settings.allowNegativeStock == 1);
            const hasStock = isNegAllowed ? true : unitDisplay.hasStock;
            var priceCarton = (typeof getPriceForUnit === 'function') ? getPriceForUnit(p, 'carton', activeTable) : (parseFloat(p.price_carton) || p.price || 0);
            var pricePack = (typeof getPriceForUnit === 'function') ? getPriceForUnit(p, 'pack', activeTable) : (parseFloat(p.price_pack) || p.price || 0);
            var pricePiece = (typeof getPriceForUnit === 'function') ? getPriceForUnit(p, 'piece', activeTable) : (p.price || 0);
            const pinBtn = isPosCardToolsVisible()
                ? ('<div class="pos-pin-btn' + (p.isPinned ? ' pinned' : '') + '" onclick="event.stopPropagation(); toggleProductPin(' + p.id + ', ' + (p.isPinned ? 0 : 1) + ')" title="' + (p.isPinned ? 'Unpin' : 'Pin') + '"><i class="fas fa-thumbtack" style="' + (p.isPinned ? 'transform:rotate(-45deg);' : '') + '"></i></div>')
                : '';
            var canSeeCost = isPosCardToolsVisible() && ((typeof canViewCost === 'function') ? canViewCost() : (currentUser && currentUser.role === 'admin'));
            var costBtn = '';
            if (canSeeCost) {
                var costTip = (typeof t === 'function') ? t('pos_card_cost_hold') : 'کرین — دەست ل سەر بهێڵە';
                costBtn = '<button type="button" class="pos-cost-btn" data-product-id="' + p.id + '"' +
                    ' onpointerenter="showPosCostTip(this,event)"' +
                    ' onpointerleave="hidePosCostTip()"' +
                    ' onpointerdown="showPosCostTip(this,event)"' +
                    ' onpointerup="hidePosCostTip()"' +
                    ' onpointercancel="hidePosCostTip()"' +
                    ' onclick="event.stopPropagation();event.preventDefault();"' +
                    ' title="' + escapeHtml(costTip) + '" aria-label="' + escapeHtml(costTip) + '">' +
                    '<i class="fas fa-coins" aria-hidden="true"></i></button>';
            }
            const qtyBadgeText = p.trackStock
                ? posQtyBadgeLabel(p, hasStock, displayQty)
                : '∞';
            const unitSuffix = (p.trackStock && typeof getProductUnitLabel === 'function') ? (' ' + getProductUnitLabel(p, (typeof posSelectedUnit !== 'undefined' ? posSelectedUnit : 'piece'))) : '';
            const badgeDisplayValue = (typeof isShowStockOnPosEnabled === 'function' ? !isShowStockOnPosEnabled() : (db && db.settings && (db.settings.showStockOnPos === false || db.settings.showStockOnPos === 'false' || db.settings.showStockOnPos === 0))) ? 'none' : 'flex';
            const qtyBadgeStyle = p.trackStock && !hasStock ? 'background:rgba(239, 68, 68, 0.85);' : (p.trackStock ? '' : 'background:rgba(16, 185, 129, 0.8);');
            const qtyBadge = p.trackStock
                ? '<div class="qty-badge" style="display:' + badgeDisplayValue + ';' + qtyBadgeStyle + '">' + qtyBadgeText + unitSuffix + '</div>'
                : '<div class="qty-badge" style="background:rgba(16, 185, 129, 0.8); display:' + badgeDisplayValue + ';">∞' + unitSuffix + '</div>';
            const disabledClass = '';
            const pid = p.id;
            var activeUnit = typeof posSelectedUnit !== 'undefined' ? posSelectedUnit : 'piece';
            var activePrice = activeUnit === 'carton' ? priceCarton : (activeUnit === 'pack' ? pricePack : pricePiece);
            var unitLabel = getProductUnitLabel(p, activeUnit);
            var usdCard = (typeof getCatalogBillUnitUsdAtAdd === 'function') ? getCatalogBillUnitUsdAtAdd(p, activeUnit, activeTable) : 0;
            var priceLine = unitLabel + ': ' + (activePrice > 0 ? formatCurrency(activePrice) : '-');
            if (activePrice > 0 && typeof formatDualCurrencyLines === 'function') {
                var rCard = typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0;
                if (!(usdCard > 0) && rCard > 0) usdCard = activePrice / rCard;
                var dualCard = formatDualCurrencyLines(activePrice, usdCard, rCard);
                priceLine = unitLabel + ': ' + (dualCard.secondary ? (dualCard.usd + ' · ' + dualCard.iqd) : dualCard.primary);
            }
            if ((typeof isJewelryByWeightProduct === 'function') && isJewelryByWeightProduct(p)
                && (typeof jewelryMetaLabel === 'function')) {
                var jewMeta = jewelryMetaLabel(p);
                if (jewMeta) priceLine = jewMeta + ' · ' + priceLine;
            }
            var cardIcon = activeUnit === 'carton' ? 'fa-box' : (activeUnit === 'pack' ? 'fa-boxes' : 'fa-cube');
            var clickAttr = ' data-pos-add="1"';
            var catKey = String(p.cat || p.category || '');
            return '<div class="unified-product-card p-card pos-sale-card' + disabledClass + '" data-product-id="' + pid + '" data-pos-cat="' + escapeHtml(catKey) + '" data-sale-unit="' + escapeHtml(activeUnit) + '" role="button" tabindex="0"' + clickAttr + '>' +
                pinBtn +
                costBtn +
                qtyBadge +
                '<div class="unified-card-header"><div class="unified-card-icon"><i class="fas ' + cardIcon + '"></i></div><div class="unified-card-barcode">' + escapeHtml((p.barcode || '').substring(0, 12) || '---') + '</div></div>' +
                '<div class="unified-card-name">' + escapeHtml(p.name || 'ئایتم') + '</div>' +
                '<div class="unified-card-price">' + escapeHtml(priceLine) + '</div>' +
                '<div class="unified-card-cta"><i class="fas fa-plus-circle"></i> ' + escapeHtml((typeof t === 'function') ? t('unified_card_cta_sell') : 'کلیک بکە بۆ فرۆتن') + '</div>' +
                '</div>';
        }

        function renderPOSMenuLoadMoreHtml(remaining) {
            var step = getPosMenuPageSize();
            var label = (typeof t === 'function') ? t('pos_load_more_products') : ('پیشاندانا ' + step + ' تر');
            if (label.indexOf('{n}') >= 0) label = label.replace(/\{n\}/g, String(step));
            return '<div id="pos-products-load-more-wrap" class="pos-products-load-more-wrap">' +
                '<button type="button" class="btn btn-outline pos-products-load-more-btn" onclick="loadMorePOSMenuProducts()">' +
                '<i class="fas fa-chevron-down" aria-hidden="true"></i> ' + escapeHtml(label) +
                (remaining > 0 ? ' <span class="pos-products-load-more-remaining">(' + remaining + ')</span>' : '') +
                '</button></div>';
        }

        function getPosMenuBadgeTotal(q, fullListLen) {
            var total = fullListLen;
            var searchActive = String(q || '').trim().length > 0;
            if (!searchActive && typeof posIsCatalogPartial === 'function' && posIsCatalogPartial()
                && typeof posCatalogTotal === 'function') {
                total = Math.max(total, posCatalogTotal());
            }
            return total;
        }

        function updatePosMenuCountBadge(q, fullList) {
            var countBadge = document.getElementById('pos-products-count');
            if (!countBadge) return;
            var fullLen = Array.isArray(fullList) ? fullList.length : (Number(fullList) || 0);
            var shownLen = fullLen;
            var badgeTotal = getPosMenuBadgeTotal(q, fullLen);
            if (shownLen > posMenuDisplayLimit) shownLen = posMenuDisplayLimit;
            var showTotal = badgeTotal > shownLen ? badgeTotal : fullLen;
            if (showTotal > shownLen) {
                var cntTpl = (typeof t === 'function') ? t('pos_products_shown_count') : '{shown} لە {total}';
                countBadge.textContent = cntTpl.replace('{shown}', String(shownLen)).replace('{total}', String(showTotal));
                countBadge.setAttribute('dir', 'rtl');
            } else {
                countBadge.textContent = String(shownLen);
                countBadge.removeAttribute('dir');
            }
        }

        function applyPosCardCategoryVisibility(cat) {
            if (typeof renderPOSMenu === 'function') {
                renderPOSMenu(typeof getCurrentPOSSearch === 'function' ? getCurrentPOSSearch() : '', true);
            }
            return 1;
        }
        window.applyPosCardCategoryVisibility = applyPosCardCategoryVisibility;

        function applyPosCategoryFilterInstant(cat, q) {
            if (typeof renderPOSMenu === 'function') {
                renderPOSMenu(q || '', true);
                return true;
            }
            return false;
        }
        window.applyPosCategoryFilterInstant = applyPosCategoryFilterInstant;

        function renderPOSMenu(q = '', force = false) {
            const container = document.getElementById('pos-products');
            if (!container) return;
            var unitFilter = typeof posSelectedUnit !== 'undefined' ? posSelectedUnit : 'piece';
            var isLoadMore = (force === 'loadMore');
            var filterChanged = q !== lastRenderedPosMenuQ || activeCategory !== lastRenderedPosMenuCategory || unitFilter !== lastRenderedPosMenuUnit;
            if (filterChanged) resetPosMenuDisplayLimit();
            
            // Skip re-rendering if nothing changed (prevents lag after barcode scan)
            if (!force && !filterChanged && posMenuDisplayLimit === lastRenderedPosMenuDisplayLimit && container.children.length > 0) {
                return;
            }
            var prevDisplayLimit = lastRenderedPosMenuDisplayLimit;
            lastRenderedPosMenuQ = q;
            lastRenderedPosMenuCategory = activeCategory;
            lastRenderedPosMenuUnit = unitFilter;
            lastRenderedPosMenuDisplayLimit = posMenuDisplayLimit;

            const fullList = getPosMenuFullList(q, activeCategory, unitFilter);

            var list = fullList.slice(0, posMenuDisplayLimit);
            var badgeTotal = getPosMenuBadgeTotal(q, fullList.length);
            var hasMore = fullList.length > list.length;
            var remaining = fullList.length - list.length;
            if (!String(q || '').trim() && typeof posIsCatalogPartial === 'function' && posIsCatalogPartial()
                && typeof posCatalogTotal === 'function' && posCatalogTotal() > fullList.length) {
                hasMore = true;
                remaining = Math.max(remaining, badgeTotal - list.length);
            }

            var countBadge = document.getElementById('pos-products-count');
            if (countBadge) {
                var showTotal = badgeTotal > list.length ? badgeTotal : fullList.length;
                if (showTotal > list.length) {
                    var cntTpl = (typeof t === 'function') ? t('pos_products_shown_count') : '{shown} لە {total}';
                    countBadge.textContent = cntTpl.replace('{shown}', String(list.length)).replace('{total}', String(showTotal));
                    countBadge.setAttribute('dir', 'rtl');
                } else {
                    countBadge.textContent = String(list.length);
                    countBadge.removeAttribute('dir');
                }
            }

            if (!list.length) {
                container.removeAttribute('data-pos-cat-pool');
                if (typeof posVirtualMenuUnmount === 'function') posVirtualMenuUnmount(container);
                var emptyProdTitle = (typeof t === 'function') ? t('pos_empty_products_title') : 'هیچ کاڵایەک نەدۆزرایەوە';
                var emptyProdHint = (typeof t === 'function') ? t('pos_empty_products_hint') : 'بارکۆد یان ناو بنووسە، یان پۆلێکی تر هەڵبژێرە';
                container.innerHTML = '<div class="pos-empty-state pos-empty-products">' +
                    '<div class="pos-empty-state-icon"><i class="fas fa-search"></i></div>' +
                    '<p class="pos-empty-state-title">' + escapeHtml(emptyProdTitle) + '</p>' +
                    '<p class="pos-empty-state-hint">' + escapeHtml(emptyProdHint) + '</p>' +
                    '</div>';
                return;
            }
            
            var activeTable = (typeof activeTableId !== 'undefined' && db.tables) ? db.tables.find(function(t) { return t.id === activeTableId; }) : null;
            var loadMoreHtml = hasMore ? renderPOSMenuLoadMoreHtml(remaining) : '';

            if (isLoadMore && !filterChanged && prevDisplayLimit > 0 && posMenuDisplayLimit > prevDisplayLimit) {
                var useVirtualLoad = (typeof posVirtualMenuShouldUse === 'function' && posVirtualMenuShouldUse(list.length));
                if (!useVirtualLoad) {
                    var moreSlice = fullList.slice(prevDisplayLimit, posMenuDisplayLimit);
                    var loadWrap = document.getElementById('pos-products-load-more-wrap');
                    if (loadWrap) loadWrap.remove();
                    if (moreSlice.length) {
                        container.insertAdjacentHTML('beforeend', moreSlice.map(function (p) { return buildPosProductCardHtml(p, activeTable); }).join(''));
                    }
                    if (hasMore) container.insertAdjacentHTML('beforeend', loadMoreHtml);
                    return;
                }
            }

            if (typeof posVirtualMenuShouldUse === 'function' && posVirtualMenuShouldUse(list.length)
                && typeof posVirtualMenuRender === 'function') {
                container.removeAttribute('data-pos-cat-pool');
                var nearEndFired = false;
                posVirtualMenuRender(container, list, {
                    buildCard: function (p) { return buildPosProductCardHtml(p, activeTable); },
                    loadMoreHtml: loadMoreHtml,
                    onNearEnd: hasMore ? function () {
                        if (nearEndFired) return;
                        nearEndFired = true;
                        loadMorePOSMenuProducts();
                    } : null
                });
                return;
            }

            if (typeof posVirtualMenuUnmount === 'function') posVirtualMenuUnmount(container);
            container.removeAttribute('data-pos-cat-pool');
            container.innerHTML = list.map(function (p) { return buildPosProductCardHtml(p, activeTable); }).join('') + loadMoreHtml;
        }
        
