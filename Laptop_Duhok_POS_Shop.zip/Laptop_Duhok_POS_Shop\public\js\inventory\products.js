// inventory/products.js — products, recipe, barcode, edit
        // --- PRODUCT MANAGEMENT ---
        var PRODUCT_FORM_TRACK_STOCK_KEY = 'product_form_track_stock';

        function getProductFormTrackStockPref() {
            try {
                var v = localStorage.getItem(PRODUCT_FORM_TRACK_STOCK_KEY);
                if (v === '0' || v === 'false') return false;
                if (v === '1' || v === 'true') return true;
                v = localStorage.getItem('pos_product_form_track_stock');
                if (v === '0' || v === 'false') return false;
                if (v === '1' || v === 'true') return true;
            } catch (e) {}
            return true;
        }
        window.getProductFormTrackStockPref = getProductFormTrackStockPref;

        function setProductFormTrackStockPref(track) {
            try {
                localStorage.setItem(PRODUCT_FORM_TRACK_STOCK_KEY, track ? '1' : '0');
            } catch (e) {}
        }
        window.setProductFormTrackStockPref = setProductFormTrackStockPref;

        function applyProductFormTrackStockPrefForNewItem() {
            var idEl = document.getElementById('p-id');
            if (idEl && idEl.value) return;
            var trackEl = document.getElementById('p-track');
            if (!trackEl) return;
            trackEl.checked = getProductFormTrackStockPref();
            toggleStockInputs();
        }
        window.applyProductFormTrackStockPrefForNewItem = applyProductFormTrackStockPrefForNewItem;

        function applyProductFormCurrencyDefaultForNewItem() {
            var idEl = document.getElementById('p-id');
            if (idEl && String(idEl.value || '').trim()) return;
            if (typeof setProductFormCurrency !== 'function') return;
            var defCur = 'IQD';
            try {
                if (typeof getDefaultCurrency === 'function') defCur = String(getDefaultCurrency() || 'IQD').toUpperCase();
                else if (typeof getActiveCurrency === 'function') defCur = String(getActiveCurrency() || 'IQD').toUpperCase();
            } catch (eCur) {}
            if (defCur !== 'USD') defCur = 'IQD';
            setProductFormCurrency(defCur, true);
        }
        window.applyProductFormCurrencyDefaultForNewItem = applyProductFormCurrencyDefaultForNewItem;

        function onProductFormTrackStockChange() {
            var el = document.getElementById('p-track');
            if (el) setProductFormTrackStockPref(!!el.checked);
            toggleStockInputs();
        }
        window.onProductFormTrackStockChange = onProductFormTrackStockChange;
        window.onProductTrackStockChange = onProductFormTrackStockChange;

        function productFormToggleTrackStock() {
            var el = document.getElementById('p-track');
            if (!el) return;
            el.checked = !el.checked;
            onProductFormTrackStockChange();
        }
        window.productFormToggleTrackStock = productFormToggleTrackStock;

        function toggleStockInputs() {
            var trackEl = document.getElementById('p-track');
            var isTracked = !!(trackEl && trackEl.checked);
            var stockSection = document.getElementById('stock-cost-section');
            var jewelryMode = (typeof isJewelryMode === 'function' && isJewelryMode());
            var jewelryPiece = (typeof isJewelryPieceEntryMode === 'function' && isJewelryPieceEntryMode());
            if (stockSection) {
                // Metal jewelry: simple fields. Piece jewelry (watches): show unit table.
                if (jewelryMode && !jewelryPiece) {
                    stockSection.style.display = 'none';
                } else {
                    stockSection.style.display = '';
                }
                stockSection.classList.toggle('no-stock-track', !isTracked);
            }
            var unitLevels = document.getElementById('layout-step1-unit-levels');
            if (unitLevels && jewelryMode) unitLevels.style.display = 'none';
            var expiryBlock = document.getElementById('layout-optional-expiry');
            if (expiryBlock && jewelryMode) expiryBlock.style.display = 'none';
            var minStockWrap = document.getElementById('p-min-stock-wrap');
            if (minStockWrap) minStockWrap.style.display = isTracked ? '' : 'none';
            var stockPreview = document.getElementById('p-total-stock-preview');
            if (stockPreview) stockPreview.style.display = (isTracked && (!jewelryMode || jewelryPiece)) ? '' : 'none';
            if (!isTracked) {
                ['p-stock-piece', 'p-stock-pack', 'p-stock-carton'].forEach(function(id) {
                    var el = document.getElementById(id);
                    if (el) el.value = '0';
                });
                if (stockPreview) stockPreview.innerHTML = '';
            } else if (typeof calcTotalStockFromTable === 'function') {
                calcTotalStockFromTable();
            }
            if (typeof syncProductUnitLevelSwitch === 'function') {
                syncProductUnitLevelSwitch('btn-unit-stock-toggle', isTracked);
            }
        }
        window.toggleStockInputs = toggleStockInputs;

        var PRODUCT_STOCK_QTY_IDS = [
            'p-stock-piece', 'p-stock-pack', 'p-stock-carton', 'p-jewelry-stock'
        ];
        var QUICK_DEFINE_STOCK_QTY_IDS = [
            'qd-stock-piece', 'qd-stock-pack', 'qd-stock-carton'
        ];
        var _productStockManualUnlocked = false;
        var _productStockUnlockTarget = null;

        function isEditingExistingProduct() {
            var idEl = document.getElementById('p-id');
            return !!(idEl && String(idEl.value || '').trim());
        }
        function applyStockQtyFieldLock(el, locked) {
            if (!el) return;
            el.readOnly = !!locked;
            el.classList.toggle('is-stock-qty-locked', !!locked);
            if (locked) {
                el.setAttribute('title', (typeof t === 'function') ? t('product_stock_lock_title') : 'کلیک: ئاگەهداری — عەدەد ژ کڕین بگوهۆڕە');
            } else {
                el.removeAttribute('title');
            }
        }
        function unlockQuickDefineStockQty() {
            QUICK_DEFINE_STOCK_QTY_IDS.forEach(function (id) {
                applyStockQtyFieldLock(document.getElementById(id), false);
            });
        }
        function setProductStockQtyLocked(locked) {
            _productStockManualUnlocked = !locked;
            PRODUCT_STOCK_QTY_IDS.forEach(function (id) {
                applyStockQtyFieldLock(document.getElementById(id), !!locked);
            });
            unlockQuickDefineStockQty();
            var hints = document.querySelectorAll('.product-stock-lock-hint');
            hints.forEach(function (hint) {
                if (hint.closest && hint.closest('#quick-define-modal')) {
                    hint.style.display = 'none';
                    return;
                }
                hint.style.display = locked ? '' : 'none';
            });
        }
        function lockProductStockQty() {
            setProductStockQtyLocked(true);
        }
        function unlockProductStockQty() {
            setProductStockQtyLocked(false);
        }
        function isWarehouseStockWarnHidden() {
            var s = (typeof db !== 'undefined' && db && db.settings) ? db.settings : (window.db && window.db.settings);
            if (!s) return false;
            return s.hideWarehouseStockWarn === true || s.hideWarehouseStockWarn === 'true' || s.hideWarehouseStockWarn === 1 || s.hideWarehouseStockWarn === '1';
        }
        function syncProductStockQtyLockForForm() {
            if (isWarehouseStockWarnHidden() || !isEditingExistingProduct()) unlockProductStockQty();
            else lockProductStockQty();
        }
        function onHideWarehouseStockWarnChange() {
            var el = document.getElementById('set-hide-warehouse-stock-warn');
            if (typeof db !== 'undefined' && db && db.settings) {
                db.settings.hideWarehouseStockWarn = !!(el && el.checked);
            } else if (window.db && window.db.settings) {
                window.db.settings.hideWarehouseStockWarn = !!(el && el.checked);
            }
            closeProductStockWarnModal();
            syncProductStockQtyLockForForm();
            if (typeof updateToggleCards === 'function') updateToggleCards();
            if (typeof saveSettings === 'function') {
                try { saveSettings().catch(function () {}); } catch (_eS) {}
            }
        }
        function closeProductStockWarnModal() {
            var m = document.getElementById('modal-product-stock-warn');
            if (m) m.style.display = 'none';
        }
        function openProductStockWarnModal(targetEl) {
            _productStockUnlockTarget = targetEl || null;
            var m = document.getElementById('modal-product-stock-warn');
            if (m) {
                m.style.display = 'flex';
                if (typeof applyI18nSubtree === 'function') {
                    try { applyI18nSubtree(m); } catch (_eI) {}
                }
            }
        }
        function productStockGoToPurchase() {
            closeProductStockWarnModal();
            if (window._productEditFromPurchase && typeof window.closePurchaseProductEditModal === 'function') {
                window.closePurchaseProductEditModal({});
                return;
            }
            if (typeof nav === 'function') nav('purchase');
        }
        function productStockAllowManual() {
            closeProductStockWarnModal();
            setProductStockQtyLocked(false);
            var el = _productStockUnlockTarget;
            _productStockUnlockTarget = null;
            if (el) {
                setTimeout(function () {
                    try {
                        el.focus();
                        if (el.select) el.select();
                    } catch (_eF) {}
                }, 30);
            }
        }
        function isProductStockQtyInput(el) {
            return !!(el && el.id && PRODUCT_STOCK_QTY_IDS.indexOf(el.id) >= 0);
        }
        function shouldWarnOnProductStockQty(el) {
            if (!isProductStockQtyInput(el)) return false;
            if (isWarehouseStockWarnHidden()) return false;
            if (_productStockManualUnlocked) return false;
            return isEditingExistingProduct();
        }
        function bindProductStockQtyGuard() {
            if (window._productStockGuardBound) return;
            window._productStockGuardBound = true;
            document.addEventListener('focusin', function (e) {
                var el = e.target;
                if (!shouldWarnOnProductStockQty(el)) return;
                try { el.blur(); } catch (_eB) {}
                openProductStockWarnModal(el);
            }, true);
            document.addEventListener('keydown', function (e) {
                var el = e.target;
                if (!shouldWarnOnProductStockQty(el)) return;
                if (e.key === 'Tab' || e.key === 'Escape') return;
                e.preventDefault();
                openProductStockWarnModal(el);
            }, true);
            syncProductStockQtyLockForForm();
        }
        if (typeof document !== 'undefined') {
            if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bindProductStockQtyGuard);
            else bindProductStockQtyGuard();
        }
        window.lockProductStockQty = lockProductStockQty;
        window.unlockProductStockQty = unlockProductStockQty;
        window.syncProductStockQtyLockForForm = syncProductStockQtyLockForForm;
        window.unlockQuickDefineStockQty = unlockQuickDefineStockQty;
        window.setProductStockQtyLocked = setProductStockQtyLocked;
        window.isWarehouseStockWarnHidden = isWarehouseStockWarnHidden;
        window.onHideWarehouseStockWarnChange = onHideWarehouseStockWarnChange;
        window.openProductStockWarnModal = openProductStockWarnModal;
        window.closeProductStockWarnModal = closeProductStockWarnModal;
        window.productStockGoToPurchase = productStockGoToPurchase;
        window.productStockAllowManual = productStockAllowManual;

        function toggleSupplierInput() {
            const checkedRadio = document.querySelector('input[name="p-source"]:checked');
            const source = checkedRadio ? checkedRadio.value : 'direct';
            const wrapper = document.getElementById('supplier-select-wrapper');
            if(wrapper) {
                if(source === 'company') { 
                    wrapper.style.display = 'block'; 
                } else { 
                    wrapper.style.display = 'none'; 
                    var pSupp = document.getElementById('p-supplier'); if(pSupp) pSupp.value = ""; 
                }
            }
        }

        function calcUnitCost() {
            var f = productFormGetConversionFactors();
            var totalBuyCost = (typeof productFormParseNumericField === 'function')
                ? (productFormParseNumericField('p-cost-carton') || 0)
                : (parseFloat(String((document.getElementById('p-cost-carton') && document.getElementById('p-cost-carton').value) || '').replace(/,/g, '')) || 0);
            if (f.piecesPerCarton > 0 && totalBuyCost > 0) {
                document.getElementById('p-cost').value = productFormFormatDerivedField(totalBuyCost / f.piecesPerCarton);
            }
        }

        function selectProductCategory(name) {
            var el = document.getElementById('p-cat');
            if (!el || name == null || name === '') return;
            el.value = String(name).trim();
            if (typeof updateProductCategoryPillsUI === 'function') updateProductCategoryPillsUI();
        }

        function clearProductCategoryField() {
            var el = document.getElementById('p-cat');
            if (!el) return;
            el.value = '';
            if (typeof updateProductCategoryPillsUI === 'function') updateProductCategoryPillsUI();
        }

        function updateProductCategoryPillsUI() {
            var input = document.getElementById('p-cat');
            var wrap = document.getElementById('p-cat-pills');
            var clearBtn = document.getElementById('btn-p-cat-clear');
            if (!input) return;
            var v = (input.value || '').trim();
            if (wrap) wrap.style.display = v ? 'none' : '';
            if (clearBtn) clearBtn.style.display = v ? '' : 'none';
        }

        function handleProductCategoryFieldKeydown(e) {
            if (!e || !e.target || e.target.id !== 'p-cat') return;
            if (e.key === 'Backspace' || e.key === 'Delete') {
                e.preventDefault();
                clearProductCategoryField();
            }
        }

        function renderCategorySelect() {
            var catInput = document.getElementById('p-cat');
            var pillsWrap = document.getElementById('p-cat-pills');
            if (!catInput || !db) return;
            var prev = (catInput.value || '').trim();
            var fromDb = db.categories || [];
            var fromProducts = (db.products || []).map(function (p) {
                return String((p && (p.cat != null ? p.cat : p.category)) || '').trim();
            }).filter(Boolean);
            var cats = [...new Set(fromDb.concat(fromProducts))].filter(Boolean).sort(function (a, b) {
                return String(a).localeCompare(String(b), undefined, { sensitivity: 'base' });
            });
            if (pillsWrap) {
                pillsWrap.innerHTML = '';
                cats.forEach(function (c) {
                    var btn = document.createElement('button');
                    btn.type = 'button';
                    btn.className = 'btn btn-sm product-cat-pill';
                    btn.textContent = c;
                    btn.addEventListener('click', function () {
                        selectProductCategory(c);
                    });
                    pillsWrap.appendChild(btn);
                });
            }
            if (prev && cats.indexOf(prev) !== -1) catInput.value = prev;
            else catInput.value = '';
            if (typeof updateProductCategoryPillsUI === 'function') updateProductCategoryPillsUI();
        }

        function saveNewCategory(name) {
            if (!name || !String(name).trim()) return;
            name = String(name).trim();
            const formData = new FormData();
            formData.append('action', 'add_category');
            formData.append('name', name);
            fetch('?action=add_category', { method: 'POST', body: formData })
            .then(function () {
                if (db && db.categories && !db.categories.includes(name)) {
                    db.categories.push(name);
                }
                renderCategorySelect();
                if (typeof populateQdCategorySelect === 'function') populateQdCategorySelect(name);
                setTimeout(function () {
                    var el = document.getElementById('p-cat');
                    if (el) el.value = name;
                    if (typeof updateProductCategoryPillsUI === 'function') updateProductCategoryPillsUI();
                }, 100);
                if (typeof connectToDB === 'function') connectToDB(true);
                if (typeof showToast === 'function') showToast('✅ پۆل هاتە زێدەکرن!');
            })
            .catch(function (err) {
                if (typeof showToast === 'function') showToast('❌ هەڵە: ' + (err && err.message ? err.message : err), 'error');
            });
        }

        function addCategory() {
            if (typeof openPosEntityNamePrompt === 'function') {
                openPosEntityNamePrompt({
                    entityType: 'category',
                    icon: 'fa-tags',
                    iconTone: 'category',
                    onConfirm: function (data) { saveNewCategory(data && data.name); }
                });
                return;
            }
            const newCat = prompt("ناڤێ پۆلێنا نوی (New Category Name):");
            if (newCat && newCat.trim() !== "") saveNewCategory(newCat.trim());
        }

        function renameCategory(currentCat, trimmedNewName) {
            const formData = new FormData();
            formData.append('action', 'rename_category');
            formData.append('oldName', currentCat);
            formData.append('newName', trimmedNewName);
            fetch('?action=rename_category', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    var msg = data.merged ? '✅ پۆلەکان یەکگرتن، ئایتمەکان تێکەڵکران!' : '✅ ناو هاتە گوهۆڕین!';
                    if (typeof showToast === 'function') showToast(msg, 'success');
                    else alert(msg);
                    if (db && db.categories) {
                        var idx = db.categories.indexOf(currentCat);
                        if (idx > -1) {
                            if (data.merged) db.categories.splice(idx, 1);
                            else db.categories[idx] = trimmedNewName;
                        }
                    }
                    if (db && db.products) {
                        db.products.forEach(function(p) {
                            if (p.cat === currentCat) p.cat = trimmedNewName;
                            if (p.category === currentCat) p.category = trimmedNewName;
                        });
                    }
                    renderCategorySelect();
                    setTimeout(function () {
                        var el = document.getElementById('p-cat');
                        if (el) el.value = trimmedNewName;
                        if (typeof updateProductCategoryPillsUI === 'function') updateProductCategoryPillsUI();
                    }, 100);
                    var searchVal = (document.getElementById('products-search-input') && document.getElementById('products-search-input').value) || '';
                    if (typeof renderProducts === 'function') renderProducts(searchVal);
                    if (typeof connectToDB === 'function') connectToDB(true);
                } else {
                    var errMsg = '❌ ' + (data.message || 'هەڵە ل گوهۆڕینا ناڤی پۆلێ');
                    if (typeof showToast === 'function') showToast(errMsg, 'error');
                    else alert(errMsg);
                }
            })
            .catch(function(err) {
                if (typeof showToast === 'function') showToast('❌ هەڵە: ' + (err && err.message ? err.message : err), 'error');
            });
        }

        function deleteCategory(currentCat) {
            const formData = new FormData();
            formData.append('action', 'delete_category');
            formData.append('name', currentCat);
            fetch('?action=delete_category', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    if (typeof showToast === 'function') showToast('✅ پۆلێن هاتە ژێبرن!', 'success');
                    else alert('✅ پۆلێن هاتە ژێبرن!');
                    if (db && db.categories) {
                        var idx = db.categories.indexOf(currentCat);
                        if (idx > -1) db.categories.splice(idx, 1);
                    }
                    if (db && db.products) {
                        db.products.forEach(function(p) {
                            if (p.cat === currentCat) p.cat = '';
                            if (p.category === currentCat) p.category = '';
                        });
                    }
                    var el = document.getElementById('p-cat');
                    if (el) el.value = '';
                    renderCategorySelect();
                    if (typeof updateProductCategoryPillsUI === 'function') updateProductCategoryPillsUI();
                    var searchVal = (document.getElementById('products-search-input') && document.getElementById('products-search-input').value) || '';
                    if (typeof renderProducts === 'function') renderProducts(searchVal);
                    if (typeof connectToDB === 'function') connectToDB(true);
                } else if (typeof showToast === 'function') {
                    showToast('❌ ' + (data.message || 'هەڵە'), 'error');
                }
            })
            .catch(function(err) {
                if (typeof showToast === 'function') showToast('❌ هەڵە: ' + (err && err.message ? err.message : err), 'error');
            });
        }

        window.closePosCategoryManageModal = function closePosCategoryManageModal() {
            var modal = document.getElementById('pos-category-manage-modal');
            if (modal) modal.style.display = 'none';
            window._posCategoryManageName = null;
            if (typeof posCategoryManageHideDeleteConfirm === 'function') posCategoryManageHideDeleteConfirm();
        };

        window.openPosCategoryManageModal = function openPosCategoryManageModal(catName) {
            var modal = document.getElementById('pos-category-manage-modal');
            var nameEl = document.getElementById('pos-category-manage-name');
            if (!modal || !catName) return false;
            window._posCategoryManageName = String(catName).trim();
            if (nameEl) nameEl.textContent = '«' + window._posCategoryManageName + '»';
            if (typeof posCategoryManageHideDeleteConfirm === 'function') posCategoryManageHideDeleteConfirm();
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
            modal.style.display = 'flex';
            return true;
        };

        window.posCategoryManageChooseRename = function posCategoryManageChooseRename() {
            var currentCat = window._posCategoryManageName;
            if (!currentCat) return;
            closePosCategoryManageModal();
            var tFn = function(k, fb) {
                if (typeof t !== 'function') return fb || k;
                var v = t(k);
                return (v && v !== k) ? v : (fb || k);
            };
            if (typeof openPosEntityNamePrompt === 'function') {
                openPosEntityNamePrompt({
                    entityType: 'category',
                    icon: 'fa-pen',
                    iconTone: 'category',
                    defaultValue: currentCat,
                    title: tFn('pos_category_manage_rename_title', 'گوهۆڕینا ناڤێ پۆل'),
                    hint: tFn('pos_category_manage_rename_hint', 'ناڤێ نوێ بنووسە.'),
                    onConfirm: function(data) {
                        var newName = data && data.name ? String(data.name).trim() : '';
                        if (newName && newName !== currentCat) renameCategory(currentCat, newName);
                    }
                });
                return;
            }
            var newName = prompt(tFn('pos_category_manage_rename_hint', 'ناڤێ نوێ:'), currentCat);
            if (newName && newName.trim() !== currentCat) renameCategory(currentCat, newName.trim());
        };

        window.posCategoryManageShowDeleteConfirm = function posCategoryManageShowDeleteConfirm() {
            var currentCat = window._posCategoryManageName;
            var panel = document.getElementById('pos-category-delete-panel');
            var actions = document.getElementById('pos-category-manage-actions');
            var warning = document.getElementById('pos-category-delete-warning');
            var footer = document.querySelector('#pos-category-manage-modal .pos-category-manage-footer');
            if (!currentCat || !panel) return;
            var tFn = function(k, fb) {
                if (typeof t !== 'function') return fb || k;
                var v = t(k);
                return (v && v !== k) ? v : (fb || k);
            };
            var tpl = tFn('pos_category_manage_delete_warn', 'دڵنیایت لە ژێبرنا پۆلێ «{name}»؟ ئایتمەکانی وێ بێ پۆل دەمێننەوە.');
            if (warning) warning.textContent = tpl.replace('{name}', currentCat);
            panel.classList.remove('is-hidden');
            panel.removeAttribute('hidden');
            if (actions) actions.style.display = 'none';
            if (footer) footer.style.display = 'none';
        };

        window.posCategoryManageHideDeleteConfirm = function posCategoryManageHideDeleteConfirm() {
            var panel = document.getElementById('pos-category-delete-panel');
            var actions = document.getElementById('pos-category-manage-actions');
            var footer = document.querySelector('#pos-category-manage-modal .pos-category-manage-footer');
            if (panel) {
                panel.classList.add('is-hidden');
                panel.setAttribute('hidden', 'hidden');
            }
            if (actions) actions.style.display = '';
            if (footer) footer.style.display = '';
        };

        window.posCategoryManageConfirmDelete = function posCategoryManageConfirmDelete() {
            var currentCat = window._posCategoryManageName;
            if (!currentCat) return;
            closePosCategoryManageModal();
            deleteCategory(currentCat);
        };

        function manageCategory() {
            const catInput = document.getElementById('p-cat');
            const currentCat = (catInput && catInput.value) ? catInput.value.trim() : '';
            if (!currentCat) {
                if (typeof showToast === 'function') showToast('⚠️ چ پۆلێن نەهاتینە هەڵبژارتن!', 'warning');
                else alert('چ پۆلێن نەهاتینە هەڵبژارتن!');
                return;
            }
            if (typeof openPosCategoryManageModal === 'function' && openPosCategoryManageModal(currentCat)) return;

            const choice = prompt(`ڕێڤەبرنا پۆلێنا '${currentCat}':

1. گوهۆڕینا ناڤی (Rename)
2. ژێبرن (Delete)

ژمارە 1 یان 2 بنڤیسە:`);
            if (choice === '1') {
                const newName = prompt('ناڤێ نوی (New Name):', currentCat);
                if (newName && newName.trim() !== currentCat) renameCategory(currentCat, newName.trim());
            } else if (choice === '2') {
                if (confirm(`دڵنیای ژ ژێبرنا پۆلێنا '${currentCat}'؟
ئایتمێن وێ دێ بێ پۆلێن مینن.`)) deleteCategory(currentCat);
            }
        }

        function getProductQtyMode(prod) {
            if (prod && typeof prod === 'object') {
                var explicit = String(prod.qty_mode || prod.measure_mode || '').toLowerCase().trim();
                if (explicit === 'kilo' || explicit === 'piece') return explicit;
                var showPack = Number(prod.unit_show_pack || 0) === 1;
                var showCarton = Number(prod.unit_show_carton || 0) === 1;
                if (!showPack && !showCarton) return 'kilo';
            }
            return 'piece';
        }
        function getProductFormQtyMode() {
            var kiloEl = document.getElementById('p-mode-kilo');
            if (kiloEl && kiloEl.checked) return 'kilo';
            return 'piece';
        }
        function setProductFormQtyMode(mode) {
            var targetMode = (mode === 'kilo') ? 'kilo' : 'piece';
            var pieceEl = document.getElementById('p-mode-piece');
            var kiloEl = document.getElementById('p-mode-kilo');
            if (pieceEl) pieceEl.checked = targetMode === 'piece';
            if (kiloEl) kiloEl.checked = targetMode === 'kilo';
            var usp = document.getElementById('p-unit-show-pack');
            var usc = document.getElementById('p-unit-show-carton');
            var pieceName = document.getElementById('p-unit-name-piece');
            if (targetMode === 'kilo') {
                if (usp) usp.value = '0';
                if (usc) usc.value = '0';
                if (pieceName && !String(pieceName.value || '').trim()) pieceName.value = 'كيلو';
                var packName = document.getElementById('p-unit-name-pack');
                var cartonName = document.getElementById('p-unit-name-carton');
                if (packName && !String(packName.value || '').trim()) packName.value = 'كيلو 2';
                if (cartonName && !String(cartonName.value || '').trim()) cartonName.value = 'كيلو 3';
            } else {
                if (usp) usp.value = '1';
                if (usc) usc.value = '1';
            }
            if (typeof applyProductUnitLevelUI === 'function') applyProductUnitLevelUI();
            if (typeof updateUnitLabels === 'function') updateUnitLabels();
            if (typeof renderCustomMeasureUnitChips === 'function') renderCustomMeasureUnitChips();
        }
        function updateUnitLabels() {
            var type = getProductFormQtyMode();
            var lblPer = document.getElementById('lbl-per-carton');
            var lblCost = document.getElementById('lbl-total-cost');
            var lblPack = document.getElementById('lbl-stock-pack');
            var lblUnit = document.getElementById('lbl-stock-unit');
            if(lblPer) {
                if(type === 'kilo') { lblPer.innerText = "وەزن ب کیلۆ"; }
                else { lblPer.innerText = "دانە د کارتۆنی دا"; }
            }
            if(lblCost) {
                if(type === 'kilo') lblCost.innerText = "بهایێ کیلۆیێ (گشتی)";
                else lblCost.innerText = "بهایێ کارتۆنی (گشتی)";
            }
            if(lblPack) { lblPack.innerText = (type === 'kilo') ? "مەخزەن (کیلۆ - ئاستەکان)" : "مەخزەن (کارتۆن)"; }
            if(lblUnit) { lblUnit.innerText = (type === 'kilo') ? "کیلۆ" : "دانە (فەرد)"; }
        }

        function calcTotalStock() {
            if(typeof calcTotalStockFromTable === 'function') { calcTotalStockFromTable(); return; }
            var cartons = 0, packs = 0, loose = 0, perCarton = 1, ppp = 1;
            var elC = document.getElementById('p-stock-carton'); var elP = document.getElementById('p-stock-pack'); var elL = document.getElementById('p-stock-piece');
            if(elC) cartons = parseInt(elC.value, 10) || 0;
            if(elP) packs = parseInt(elP.value, 10) || 0;
            if(elL) loose = parseInt(elL.value, 10) || 0;
            ppp = parseInt(document.getElementById('p-pieces-per-pack').value, 10) || 1;
            var ppc = parseInt(document.getElementById('p-packs-per-carton').value, 10) || 1;
            perCarton = ppp * ppc;
            var total = (cartons * perCarton) + (packs * ppp) + loose;
            
            const type = getProductFormQtyMode();
            let unitName = "دانە";
            if(type === 'kilo') unitName = "کیلۆ";
            
            if(total > 0) document.getElementById('p-total-stock-preview').innerText = `کۆیا گشتی: ${total} ${unitName}`;
            else document.getElementById('p-total-stock-preview').innerText = "";
        }

        /** Single source of truth for piece/pack/carton conversion used by cost sync and stock preview. */
        function productFormGetConversionFactors() {
            var unitStructure = (document.getElementById('p-unit-structure') && document.getElementById('p-unit-structure').value) || 'carton_pack_piece';
            var vp = typeof productFormIsPackRowVisible === 'function' && productFormIsPackRowVisible();
            var vc = typeof productFormIsCartonRowVisible === 'function' && productFormIsCartonRowVisible();
            var ppp = typeof productFormEffectivePpp === 'function' ? productFormEffectivePpp() : (parseInt((document.getElementById('p-pieces-per-pack') && document.getElementById('p-pieces-per-pack').value) || 1, 10) || 1);
            var ppcEl = document.getElementById('p-packs-per-carton');
            var ppc = ppcEl ? (parseInt(ppcEl.value, 10) || 1) : 1;
            if (unitStructure === 'carton_piece') {
                ppp = 1;
                var singleEl = document.getElementById('p-pieces-per-carton-single');
                var singleVal = singleEl ? parseInt(singleEl.value, 10) : NaN;
                if (isFinite(singleVal) && singleVal >= 1) {
                    ppc = singleVal;
                } else if (!vp && vc) {
                    var soloEl = document.getElementById('p-pieces-per-carton-only');
                    ppc = soloEl ? (parseInt(soloEl.value, 10) || ppc) : ppc;
                }
            }
            if (!vp && vc) ppc = 1;
            if (!vp && !vc) {
                ppc = 1;
                ppp = 1;
            }
            return {
                unitStructure: unitStructure,
                vp: vp,
                vc: vc,
                ppp: Math.max(1, ppp),
                ppc: Math.max(1, ppc),
                piecesPerCarton: Math.max(1, ppp * ppc)
            };
        }

        function calcMultiLevelCarton() {
            var f = productFormGetConversionFactors();
            var el = document.getElementById('p-pieces-per-carton-preview');
            if (el) el.innerText = 'دانە ل کارتۆنی دا (Pieces per Carton): ' + f.piecesPerCarton;
        }

        function productFormIsPackRowVisible() {
            var h = document.getElementById('p-unit-show-pack');
            return !!(h && h.value === '1');
        }
        function productFormIsCartonRowVisible() {
            var h = document.getElementById('p-unit-show-carton');
            return !!(h && h.value === '1');
        }

        /** Visible focusable for product form keyboard flow (respects hidden layout / unit rows). */
        function productFormFieldVisibleForFlow(el) {
            if (!el || el.disabled) return false;
            if (el.type === 'hidden') return false;
            return el.offsetParent !== null;
        }

        /**
         * Alt+Enter flow on step 1: conversion fields (if shown) → piece row → pack row → carton row → expiry → save (step 1).
         */
        function productFormGetKeyboardFlowElements() {
            var list = [];
            var vp = typeof productFormIsPackRowVisible === 'function' && productFormIsPackRowVisible();
            var vc = typeof productFormIsCartonRowVisible === 'function' && productFormIsCartonRowVisible();
            function pushId(id) {
                var el = document.getElementById(id);
                if (productFormFieldVisibleForFlow(el)) list.push(el);
            }
            pushId('p-pieces-per-pack');
            pushId('p-packs-per-carton');
            pushId('p-pieces-per-carton-only');
            pushId('p-pieces-per-carton-single');
            pushId('p-barcode-piece');
            pushId('p-cost');
            pushId('p-price');
            pushId('p-stock-piece');
            if (vp) {
                pushId('p-barcode-pack');
                pushId('p-cost-pack');
                pushId('p-price-pack');
                pushId('p-stock-pack');
            }
            if (vc) {
                pushId('p-barcode-carton');
                pushId('p-cost-carton');
                pushId('p-price-carton');
                pushId('p-stock-carton');
            }
            pushId('p-expiry-enabled');
            if (typeof productFormExpiryEnabled === 'function' && productFormExpiryEnabled()) pushId('p-expiry');
            var saveBtn = document.getElementById('btn-save-prod-step1');
            if (productFormFieldVisibleForFlow(saveBtn)) list.push(saveBtn);
            return list;
        }

        function productFormFocusSelect(el) {
            if (!el) return;
            el.focus();
            if (el.tagName === 'INPUT' && el.type !== 'date' && el.type !== 'checkbox' && el.select) {
                try { el.select(); } catch (err) {}
            }
        }

        /** Pieces per pack when pack row on; pieces per carton when carton-only (no pack row). */
        function productFormEffectivePpp() {
            var vp = typeof productFormIsPackRowVisible === 'function' && productFormIsPackRowVisible();
            var vc = typeof productFormIsCartonRowVisible === 'function' && productFormIsCartonRowVisible();
            var elPack = document.getElementById('p-pieces-per-pack');
            var elSolo = document.getElementById('p-pieces-per-carton-only');
            if (vp && elPack) return Math.max(1, parseInt(elPack.value, 10) || 1);
            if (!vp && vc && elSolo) return Math.max(1, parseInt(elSolo.value, 10) || 1);
            if (elPack) return Math.max(1, parseInt(elPack.value, 10) || 1);
            return 1;
        }
        function syncProductUnitLevelSwitch(btnId, isOn) {
            var btn = document.getElementById(btnId);
            if (!btn) return;
            btn.classList.toggle('is-on', !!isOn);
            btn.setAttribute('aria-checked', isOn ? 'true' : 'false');
        }
        function productFormTogglePackLevel() {
            if (typeof productFormIsPackRowVisible === 'function' && productFormIsPackRowVisible()) {
                productFormRemovePackLevel();
            } else {
                productFormAddPackLevel();
            }
        }
        function productFormToggleCartonLevel() {
            if (typeof productFormIsCartonRowVisible === 'function' && productFormIsCartonRowVisible()) {
                productFormRemoveCartonLevel();
            } else {
                productFormAddCartonLevel();
            }
        }
        window.productFormTogglePackLevel = productFormTogglePackLevel;
        window.productFormToggleCartonLevel = productFormToggleCartonLevel;
        function applyProductUnitLevelUI() {
            var qtyMode = (typeof getProductFormQtyMode === 'function') ? getProductFormQtyMode() : 'piece';
            var showP = document.getElementById('p-unit-show-pack');
            var showC = document.getElementById('p-unit-show-carton');
            var vp = !!(showP && showP.value === '1');
            var vc = !!(showC && showC.value === '1');
            var rowP = document.getElementById('p-ml-row-pack');
            var rowC = document.getElementById('p-ml-row-carton');
            if (rowP) rowP.style.display = vp ? '' : 'none';
            if (rowC) rowC.style.display = vc ? '' : 'none';
            var wPpp = document.getElementById('conv-wrap-ppp');
            var wPpc = document.getElementById('conv-wrap-ppc');
            var wSolo = document.getElementById('conv-wrap-carton-only');
            var convGrid = document.getElementById('conversion-two-fields');
            if (wPpp) wPpp.style.display = (qtyMode === 'kilo') ? 'none' : (vp ? '' : 'none');
            if (wPpc) wPpc.style.display = (qtyMode === 'kilo') ? 'none' : ((vp && vc) ? '' : 'none');
            if (wSolo) wSolo.style.display = (qtyMode === 'kilo') ? 'none' : ((!vp && vc) ? '' : 'none');
            if (convGrid) convGrid.style.display = (qtyMode === 'kilo') ? 'none' : (vp ? 'grid' : 'none');
            syncProductUnitLevelSwitch('btn-unit-pack-toggle', vp);
            syncProductUnitLevelSwitch('btn-unit-carton-toggle', vc);
            ['p-stock-piece', 'p-stock-pack', 'p-stock-carton'].forEach(function(id) {
                var el = document.getElementById(id);
                if (!el) return;
                if (qtyMode === 'kilo') {
                    el.step = '0.001';
                    el.min = '0';
                } else {
                    el.step = '1';
                    el.min = '0';
                }
            });
            if (!vp && vc) {
                var soloSync = document.getElementById('p-pieces-per-carton-only');
                var pppSync = document.getElementById('p-pieces-per-pack');
                var ppcSync = document.getElementById('p-packs-per-carton');
                if (soloSync && pppSync) pppSync.value = soloSync.value || pppSync.value || '1';
                if (ppcSync) ppcSync.value = '1';
            }
            if (typeof calcMultiLevelCarton === 'function') calcMultiLevelCarton();
            if (typeof calcTotalStockFromTable === 'function') calcTotalStockFromTable();
            if (typeof syncCostFromLevel === 'function') syncCostFromLevel();
            if (typeof syncInheritedLevelBarcodes === 'function') syncInheritedLevelBarcodes();
        }
        function productFormAddPackLevel() {
            var vc = typeof productFormIsCartonRowVisible === 'function' && productFormIsCartonRowVisible();
            var vp = typeof productFormIsPackRowVisible === 'function' && productFormIsPackRowVisible();
            var solo = document.getElementById('p-pieces-per-carton-only');
            var pppEl = document.getElementById('p-pieces-per-pack');
            if (vc && !vp && solo && pppEl) {
                pppEl.value = solo.value || '1';
            }
            var h = document.getElementById('p-unit-show-pack');
            if (h) h.value = '1';
            var qtyMode = (typeof getProductFormQtyMode === 'function') ? getProductFormQtyMode() : 'piece';
            if (qtyMode === 'kilo') {
                var packName = document.getElementById('p-unit-name-pack');
                if (packName && !String(packName.value || '').trim()) packName.value = 'كيلو 2';
            }
            applyProductUnitLevelUI();
        }
        function productFormRemovePackLevel() {
            var vc = typeof productFormIsCartonRowVisible === 'function' && productFormIsCartonRowVisible();
            var solo = document.getElementById('p-pieces-per-carton-only');
            var pppEl = document.getElementById('p-pieces-per-pack');
            if (vc && solo && pppEl) {
                solo.value = pppEl.value || '1';
            }
            var h = document.getElementById('p-unit-show-pack');
            if (h) h.value = '0';
            if (typeof resetLevelBarcodeField === 'function') resetLevelBarcodeField(document.getElementById('p-barcode-pack'));
            else if (document.getElementById('p-barcode-pack')) document.getElementById('p-barcode-pack').value = '';
            if (document.getElementById('p-cost-pack')) document.getElementById('p-cost-pack').value = '';
            if (document.getElementById('p-price-pack')) document.getElementById('p-price-pack').value = '';
            if (document.getElementById('p-stock-pack')) document.getElementById('p-stock-pack').value = '0';
            var ppcEl = document.getElementById('p-packs-per-carton');
            if (ppcEl && typeof productFormIsCartonRowVisible === 'function' && productFormIsCartonRowVisible()) ppcEl.value = '1';
            applyProductUnitLevelUI();
        }
        function productFormAddCartonLevel() {
            var h = document.getElementById('p-unit-show-carton');
            if (h) h.value = '1';
            var vp = typeof productFormIsPackRowVisible === 'function' && productFormIsPackRowVisible();
            var solo = document.getElementById('p-pieces-per-carton-only');
            var pppEl = document.getElementById('p-pieces-per-pack');
            if (!vp && solo && pppEl && (!solo.value || solo.value === '1')) {
                solo.value = pppEl.value || '1';
            }
            var qtyMode = (typeof getProductFormQtyMode === 'function') ? getProductFormQtyMode() : 'piece';
            if (qtyMode === 'kilo') {
                var cartonName = document.getElementById('p-unit-name-carton');
                if (cartonName && !String(cartonName.value || '').trim()) cartonName.value = 'كيلو 3';
            }
            applyProductUnitLevelUI();
        }
        function productFormRemoveCartonLevel() {
            var h = document.getElementById('p-unit-show-carton');
            if (h) h.value = '0';
            if (typeof resetLevelBarcodeField === 'function') resetLevelBarcodeField(document.getElementById('p-barcode-carton'));
            else if (document.getElementById('p-barcode-carton')) document.getElementById('p-barcode-carton').value = '';
            if (document.getElementById('p-cost-carton')) document.getElementById('p-cost-carton').value = '';
            if (document.getElementById('p-price-carton')) document.getElementById('p-price-carton').value = '';
            if (document.getElementById('p-stock-carton')) document.getElementById('p-stock-carton').value = '0';
            var ppcEl = document.getElementById('p-packs-per-carton');
            if (ppcEl) ppcEl.value = '1';
            var soloEl = document.getElementById('p-pieces-per-carton-only');
            if (soloEl) soloEl.value = '1';
            applyProductUnitLevelUI();
        }
        function setUnitStructure(structure) {
            var usEl = document.getElementById('p-unit-structure');
            if (usEl) usEl.value = 'carton_pack_piece';
            var convOne = document.getElementById('conversion-one-field');
            if (convOne) convOne.style.display = 'none';
            var pppEl = document.getElementById('p-pieces-per-pack');
            var ppcEl = document.getElementById('p-packs-per-carton');
            if (pppEl) pppEl.value = pppEl.value || '1';
            if (ppcEl) ppcEl.value = ppcEl.value || '1';
            var singleInput = document.getElementById('p-pieces-per-carton-single');
            if (singleInput) singleInput.value = '';
            if (typeof applyProductUnitLevelUI === 'function') applyProductUnitLevelUI();
        }

        function applyCartonPieceConversion() {
            var single = document.getElementById('p-pieces-per-carton-single');
            var val = single ? (parseInt(single.value, 10) || 1) : 1;
            // In carton_piece mode, pack=1, carton=val -> pieces_per_carton = val
            document.getElementById('p-pieces-per-pack').value = '1';
            document.getElementById('p-packs-per-carton').value = val;
            var solo = document.getElementById('p-pieces-per-carton-only');
            if (solo) solo.value = String(val);
            calcMultiLevelCarton();
            syncCostFromLevel('p-pieces-per-carton-single');
            if (typeof calcTotalStockFromTable === 'function') calcTotalStockFromTable();
        }

        var PRODUCT_FORM_ALL_STEPS_KEY = 'product_form_all_steps';

        function isProductFormAllStepsPref() {
            try { return localStorage.getItem(PRODUCT_FORM_ALL_STEPS_KEY) === '1'; } catch (e) {}
            return false;
        }

        function isProductFormAllSteps() {
            var card = document.getElementById('product-form-card');
            return !!(card && card.classList.contains('is-all-steps'));
        }

        function applyProductFormAllStepsUi() {
            var card = document.getElementById('product-form-card');
            var on = !!(card && card.classList.contains('is-all-steps'));
            var btn = document.getElementById('btn-product-form-all-steps');
            if (btn) {
                btn.classList.toggle('is-on', on);
                btn.setAttribute('aria-pressed', on ? 'true' : 'false');
            }
            if (!on || !card) return;
            var s1 = document.getElementById('product-form-step-1');
            var s2 = document.getElementById('product-form-step-2');
            var d1 = document.getElementById('step-dot-1');
            var d2 = document.getElementById('step-dot-2');
            if (s1) s1.classList.add('active');
            if (s2) s2.classList.add('active');
            if (d1) { d1.classList.add('active'); d1.classList.remove('done'); }
            if (d2) { d2.classList.add('active'); d2.classList.remove('done'); }
        }

        function initProductFormAllStepsFromPref() {
            var card = document.getElementById('product-form-card');
            if (!card) return;
            card.classList.toggle('is-all-steps', isProductFormAllStepsPref());
            applyProductFormAllStepsUi();
        }

        function toggleProductFormAllSteps() {
            var next = !isProductFormAllStepsPref();
            try { localStorage.setItem(PRODUCT_FORM_ALL_STEPS_KEY, next ? '1' : '0'); } catch (e) {}
            var card = document.getElementById('product-form-card');
            if (card) card.classList.toggle('is-all-steps', next);
            if (next) {
                applyProductFormAllStepsUi();
                if (typeof applyJewelryProductFormSteps === 'function') applyJewelryProductFormSteps();
                if (card && typeof window.applyI18nSubtree === 'function') window.applyI18nSubtree(card);
                if (typeof applyProductFormFieldLabels === 'function' && typeof db !== 'undefined' && db && db.settings) applyProductFormFieldLabels();
            } else {
                productFormGoToStep(1);
            }
        }

        function getCurrentProductFormStep() {
            var ae = document.activeElement;
            if (ae && ae.closest) {
                if (ae.closest('#product-form-step-2')) return 2;
                if (ae.closest('#product-form-step-1')) return 1;
            }
            for (var i = 1; i <= 2; i++) {
                var el = document.getElementById('product-form-step-' + i);
                if (el && el.classList.contains('active')) return i;
            }
            return 1;
        }

        function getProductFormFocusables() {
            var card = document.getElementById('product-form-card');
            var container = (card && card.classList.contains('is-all-steps'))
                ? card
                : document.getElementById('product-form-step-' + getCurrentProductFormStep());
            if (!container) return [];
            var nodes = container.querySelectorAll('input:not([type="hidden"]), select, button, [tabindex="0"]');
            var arr = [];
            nodes.forEach(function(el) {
                if (el.closest && el.closest('#layout-step-indicator')) return;
                if (el.offsetParent !== null && !el.disabled && (el.type !== 'hidden')) arr.push(el);
            });
            return arr;
        }

        function productFormGoToStep(step) {
            if (step < 1) step = 1;
            if (step > 2) step = 2;
            var card = document.getElementById('product-form-card');
            if (card && (card.classList.contains('is-all-steps') || isProductFormAllStepsPref())) {
                card.classList.add('is-all-steps');
                applyProductFormAllStepsUi();
                var target = document.getElementById('product-form-step-' + step);
                if (target && typeof target.scrollIntoView === 'function') {
                    try { target.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); } catch (e) {}
                }
                if (step === 2 && typeof syncBarcodeToPieceCell === 'function') syncBarcodeToPieceCell();
                if (typeof applyJewelryProductFormSteps === 'function') applyJewelryProductFormSteps();
                if (card && typeof window.applyI18nSubtree === 'function') window.applyI18nSubtree(card);
                if (typeof applyProductFormFieldLabels === 'function' && typeof db !== 'undefined' && db && db.settings) applyProductFormFieldLabels();
                return;
            }
            for (var i = 1; i <= 2; i++) {
                var el = document.getElementById('product-form-step-' + i);
                var dot = document.getElementById('step-dot-' + i);
                if (el) el.classList.toggle('active', i === step);
                if (dot) {
                    dot.classList.remove('active', 'done');
                    if (i < step) dot.classList.add('done');
                    else if (i === step) dot.classList.add('active');
                }
            }
            if (step === 2 && typeof syncBarcodeToPieceCell === 'function') syncBarcodeToPieceCell();
            if (typeof applyJewelryProductFormSteps === 'function') applyJewelryProductFormSteps();
            var focusables = getProductFormFocusables();
            if (focusables.length > 0) {
                focusables[0].focus();
                if (focusables[0].tagName === 'INPUT' && focusables[0].type !== 'date' && focusables[0].select) focusables[0].select();
            }
            var pfc = document.getElementById('product-form-card');
            if (pfc && typeof window.applyI18nSubtree === 'function') window.applyI18nSubtree(pfc);
            if (typeof applyProductFormFieldLabels === 'function' && typeof db !== 'undefined' && db && db.settings) applyProductFormFieldLabels();
        }

        var PRODUCT_LAYOUT_ITEMS = [
            { id: 'layout-step-indicator', label: 'نیشاندێرێ قۆناغان (١٢ + فلتر + ڕێکخستن + مساح)' },
            { id: 'layout-step2', label: 'قۆناغ ١ - زانیاریێن سەرەتایی' },
            { id: 'layout-section-titles', label: '  └ ناونیشانێن بەشان (سەرەوە)' },
            { id: 'layout-labels', label: '  └ تسمیەکان (ناڤ، پۆل، جۆر، تێبینی...)' },
            { id: 'layout-optional-item-currency', label: '  └ دراڤێ نرخێ ڤێ کەرەستەی' },
            { id: 'layout-category-btns', label: '  └ دوگمەکانی پۆل (+ / چاککردن)' },
            { id: 'layout-step1-unit-levels', label: '  └ تاک + پاکێت + کارتۆن (+/−)' },
            { id: 'layout-step2-unit-note', label: 'قۆناغ ٢ - جۆرێ یەکێ و تێبینی' },
            { id: 'layout-step3-stock', label: 'قۆناغ ١ - یەکە، بارکۆد، کرین، فرۆتن، خشتە، کۆگە' },
            { id: 'layout-step3-desc', label: '  └ نەخشێ قۆناغ ٢ (پێناسە)' },
            { id: 'layout-conversion-row', label: '  └ دانە ل پاکێت / پاکێت ل کارتۆن' },
            { id: 'layout-table-header', label: '  └ سەرۆکی خشتە (یەکە، بارکۆد...)' },
            { id: 'layout-step3-options', label: 'پاراستن / بەشێ خوارێ' },
            { id: 'layout-optional-expiry', label: '  └ بەروارا ب سەرچوونێ (قۆناغ ١)' },
            { id: 'layout-optional-companies', label: '  └ کۆمپانیا دروستکەر' },
            { id: 'layout-optional-track', label: '  └ حیسابا مەخزەنی' },
            { id: 'layout-optional-forsale', label: '  └ پیشاندان لە فرۆتن' },
            { id: 'layout-optional-takeaway', label: '  └ بهایێ جوملە' },
            { id: 'layout-optional-wholesale', label: '  └ فرۆتنا بە کۆم' },
            { id: 'layout-btn-back', label: '  └ دوگمەی پاش (Back)' },
            { id: 'layout-btn-partner', label: '  └ دوگمەی هاوبەش' },
            { id: 'layout-btn-clear', label: '  └ دوگمەی پاککردنەوە' }
        ];
        var PRODUCT_LAYOUT_STEP3_ORDER_IDS = ['layout-step2-unit-note', 'layout-step3-options'];

        var PRODUCT_LAYOUT_ITEM_LABEL_AR = {
            'layout-step-indicator': 'مؤشر الخطوات (١٢ + فلتر + التخطيط + مسح)',
            'layout-step2': 'الخطوة ١ - معلومات أساسية',
            'layout-section-titles': '  └ عناوين الأقسام',
            'layout-labels': '  └ التسميات (الاسم، التصنيف، النوع، الملاحظة...)',
            'layout-optional-item-currency': '  └ عملة سعر هذا الصنف',
            'layout-category-btns': '  └ أزرار التصنيف (+ / تعديل)',
            'layout-step1-unit-levels': '  └ قطعة + عبوة + كرتون (+/−)',
            'layout-step2-unit-note': 'الخطوة ٢ - نوع الوحدة والملاحظة',
            'layout-step3-stock': 'الخطوة ١ - الوحدة، الباركود، التكلفة، البيع، الجدول، المخزون',
            'layout-step3-desc': '  └ وصف الجدول',
            'layout-conversion-row': '  └ قطع في العبوة / عبوات في الكرتون',
            'layout-table-header': '  └ رأس الجدول (الوحدة، الباركود...)',
            'layout-step3-options': 'الحفظ / القسم السفلي',
            'layout-optional-expiry': '  └ تاريخ الانتهاء (الخطوة ١)',
            'layout-optional-companies': '  └ الشركة المصنعة',
            'layout-optional-track': '  └ تتبع المخزون',
            'layout-optional-forsale': '  └ إظهار في نقطة البيع',
            'layout-optional-takeaway': '  └ سعر «للأخذ»',
            'layout-optional-wholesale': '  └ بيع بالجملة',
            'layout-btn-back': '  └ زر الرجوع',
            'layout-btn-partner': '  └ زر الشريك',
            'layout-btn-clear': '  └ زر المسح'
        };
        function productLayoutItemLabel(x) {
            if (x && x.id === 'layout-optional-item-currency' && typeof t === 'function') {
                var curLbl = t('product_form_currency_label');
                if (curLbl && curLbl !== 'product_form_currency_label') return '  └ ' + curLbl;
            }
            if (typeof getCurrentLanguage === 'function' && getCurrentLanguage() === 'ar' && PRODUCT_LAYOUT_ITEM_LABEL_AR[x.id]) {
                return PRODUCT_LAYOUT_ITEM_LABEL_AR[x.id];
            }
            return x.label;
        }

        /** USD shop, or catalog already has USD items — otherwise hide from Form Settings. */
        function canUseProductItemCurrencyPicker() {
            var mode = '';
            try {
                if (typeof getDefaultCurrency === 'function') mode = String(getDefaultCurrency() || '').toUpperCase();
                if (mode !== 'USD' && typeof getActiveCurrency === 'function') {
                    var active = String(getActiveCurrency() || '').toUpperCase();
                    if (active === 'USD') mode = 'USD';
                }
            } catch (eMode) {}
            if (mode === 'USD') return true;
            try {
                var list = (typeof db !== 'undefined' && db && Array.isArray(db.products)) ? db.products : [];
                for (var i = 0; i < list.length; i++) {
                    var c = String((list[i] && (list[i].base_currency || list[i].currency)) || '').toUpperCase();
                    if (c === 'USD') return true;
                }
            } catch (eProd) {}
            return false;
        }
        if (typeof window !== 'undefined') window.canUseProductItemCurrencyPicker = canUseProductItemCurrencyPicker;

        function getProductFormLayoutConfig() {
            try {
                var s = localStorage.getItem('product_form_layout');
                if (s) {
                    var data = JSON.parse(s);
                    var o = { visibility: {}, step3Order: (data.step3Order && data.step3Order.length) ? data.step3Order.filter(function(id) { return PRODUCT_LAYOUT_STEP3_ORDER_IDS.indexOf(id) !== -1; }) : PRODUCT_LAYOUT_STEP3_ORDER_IDS.slice() };
                    if (!o.step3Order.length) o.step3Order = PRODUCT_LAYOUT_STEP3_ORDER_IDS.slice();
                    PRODUCT_LAYOUT_STEP3_ORDER_IDS.forEach(function(id) {
                        if (o.step3Order.indexOf(id) === -1) o.step3Order.push(id);
                    });
                    o.step3Order.sort(function(a, b) {
                        return PRODUCT_LAYOUT_STEP3_ORDER_IDS.indexOf(a) - PRODUCT_LAYOUT_STEP3_ORDER_IDS.indexOf(b);
                    });
                    if (data.visibility) {
                        o.visibility = data.visibility;
                    } else {
                        PRODUCT_LAYOUT_ITEMS.forEach(function(x) { o.visibility[x.id] = data[x.id] !== false; });
                    }
                    return o;
                }
            } catch (e) {}
            var o = { visibility: {}, step3Order: PRODUCT_LAYOUT_STEP3_ORDER_IDS.slice() };
            PRODUCT_LAYOUT_ITEMS.forEach(function(x) { o.visibility[x.id] = true; });
            return o;
        }

        function applyProductFormLayout() {
            var config = getProductFormLayoutConfig();
            var vis = config.visibility || config;
            var card = document.getElementById('product-form-card');
            if (!card) return;
            PRODUCT_LAYOUT_ITEMS.forEach(function(x) {
                var els = card.querySelectorAll('[data-layout-id="' + x.id + '"]');
                if (els.length === 0) {
                    var one = document.getElementById(x.id);
                    if (one) els = [one];
                }
                var show = vis[x.id] !== false;
                if (x.id === 'layout-optional-item-currency' && typeof canUseProductItemCurrencyPicker === 'function' && !canUseProductItemCurrencyPicker()) {
                    show = false;
                }
                els.forEach(function(el) { el.style.display = show ? '' : 'none'; });
            });
            var step3Order = config.step3Order || PRODUCT_LAYOUT_STEP3_ORDER_IDS.slice();
            var step2stock = document.getElementById('product-form-step-2');
            if (step2stock && Array.isArray(step3Order)) {
                var sections = [];
                step3Order.forEach(function(id) {
                    var el = document.getElementById(id) || step2stock.querySelector('[data-layout-id="' + id + '"]');
                    if (el && el.parentNode === step2stock) sections.push(el);
                });
                sections.forEach(function(el) { step2stock.appendChild(el); });
            }
            if (typeof applyProductUnitLevelUI === 'function') applyProductUnitLevelUI();
            if (typeof applyProductFormPremiumFeatureFields === 'function') applyProductFormPremiumFeatureFields();
            if (typeof refreshCustomMeasureUnitsUI === 'function') refreshCustomMeasureUnitsUI();
            initProductFormAllStepsFromPref();
        }

        function openProductLayoutManager() {
            renderProductLayoutList();
            var modal = document.getElementById('product-layout-modal');
            modal.style.display = 'flex';
            setTimeout(function() { modal.focus(); }, 100);
        }

        function closeProductLayoutManager() {
            document.getElementById('product-layout-modal').style.display = 'none';
        }

        function renderProductLayoutList() {
            var config = getProductFormLayoutConfig();
            var vis = config.visibility || config;
            var step3Order = config.step3Order || PRODUCT_LAYOUT_STEP3_ORDER_IDS.slice();
            var list = document.getElementById('product-layout-list');
            if (!list) return;
            var step3Set = {};
            PRODUCT_LAYOUT_STEP3_ORDER_IDS.forEach(function(id) { step3Set[id] = true; });
            var orderForStep3 = [];
            step3Order.forEach(function(id) {
                var item = PRODUCT_LAYOUT_ITEMS.find(function(x) { return x.id === id; });
                if (item) orderForStep3.push(item);
            });
            PRODUCT_LAYOUT_ITEMS.forEach(function(x) {
                if (step3Set[x.id] && orderForStep3.indexOf(x) === -1) orderForStep3.push(x);
            });
            var general = [];
            PRODUCT_LAYOUT_ITEMS.forEach(function(x) {
                if (step3Set[x.id]) return;
                if (x.id === 'layout-optional-item-currency' && typeof canUseProductItemCurrencyPicker === 'function' && !canUseProductItemCurrencyPicker()) return;
                var checked = vis[x.id] !== false;
                general.push('<label class="product-layout-checkbox-row"><input type="checkbox" data-layout-id="' + x.id + '" ' + (checked ? 'checked' : '') + '> <span>' + escapeHtml(productLayoutItemLabel(x)) + '</span></label>');
            });
            var step3Html = [];
            orderForStep3.forEach(function(x, i) {
                var checked = vis[x.id] !== false;
                step3Html.push('<div class="product-layout-step3-row">' +
                    '<input type="checkbox" data-layout-id="' + x.id + '" data-step3="1" ' + (checked ? 'checked' : '') + '> <span style="flex:1;">' + escapeHtml(productLayoutItemLabel(x)) + '</span>' +
                    '<button type="button" class="btn btn-sm" style="padding:2px 8px;" onclick="moveProductLayoutStep3(\'' + x.id + '\', -1)" title="پێشەوە">↑</button>' +
                    '<button type="button" class="btn btn-sm" style="padding:2px 8px;" onclick="moveProductLayoutStep3(\'' + x.id + '\', 1)" title="دواتر">↓</button></div>');
            });
            var step2Title = (typeof getCurrentLanguage === 'function' && getCurrentLanguage() === 'ar')
                ? 'ترتيب الخطوة ٢ (السحب لإعادة الترتيب):'
                : 'ترتیبا قۆناغ ٢ (ئاراستە بە هەڵۆکە):';
            list.innerHTML = '<div class="product-layout-general-grid">' + general.join('') + '</div>' +
                '<div class="product-layout-step2-order"><div class="product-layout-step2-order-title">' + escapeHtml(step2Title) + '</div>' + step3Html.join('') + '</div>';
        }

        function moveProductLayoutStep3(id, dir) {
            var config = getProductFormLayoutConfig();
            var order = (config.step3Order || PRODUCT_LAYOUT_STEP3_ORDER_IDS.slice()).slice();
            var i = order.indexOf(id);
            if (i === -1) return;
            var j = i + dir;
            if (j < 0 || j >= order.length) return;
            order[i] = order[j];
            order[j] = id;
            config.step3Order = order;
            try { localStorage.setItem('product_form_layout', JSON.stringify(config)); } catch (e) {}
            renderProductLayoutList();
            applyProductFormLayout();
        }

        function saveProductFormLayout() {
            var config = getProductFormLayoutConfig();
            var prevVis = config.visibility || {};
            config.visibility = {};
            PRODUCT_LAYOUT_ITEMS.forEach(function(x) {
                var cb = document.querySelector('#product-layout-list input[data-layout-id="' + x.id + '"]');
                if (cb) config.visibility[x.id] = cb.checked;
                else if (prevVis[x.id] !== undefined) config.visibility[x.id] = prevVis[x.id];
            });
            var step3Order = (config.step3Order || PRODUCT_LAYOUT_STEP3_ORDER_IDS.slice()).slice();
            try { localStorage.setItem('product_form_layout', JSON.stringify(config)); } catch (e) {}
            applyProductFormLayout();
            if (typeof showToast === 'function') showToast('ڕێکخستن پاراسترا', 'success');
        }

        function resetProductFormLayout() {
            var o = { visibility: {}, step3Order: PRODUCT_LAYOUT_STEP3_ORDER_IDS.slice() };
            PRODUCT_LAYOUT_ITEMS.forEach(function(x) { o.visibility[x.id] = true; });
            try { localStorage.setItem('product_form_layout', JSON.stringify(o)); } catch (e) {}
            applyProductFormLayout();
        }

        var _syncCostFromLevelLock = false;
        /** Auto-calculate cost between piece / pack / carton based on conversion and the field being edited. */
        function syncCostFromLevel(sourceId) {
            if (_syncCostFromLevelLock) return;
            _syncCostFromLevelLock = true;
            try {
                var fmt = productFormFormatDerivedField;
                var f = productFormGetConversionFactors();
                if (!sourceId && document.activeElement && document.activeElement.id) sourceId = document.activeElement.id;
                var costPieceEl = document.getElementById('p-cost');
                var costPackEl = document.getElementById('p-cost-pack');
                var costCartonEl = document.getElementById('p-cost-carton');
                var costPiece = costPieceEl ? (productFormParseNumericField('p-cost') || 0) : 0;
                var costPack = costPackEl ? (productFormParseNumericField('p-cost-pack') || 0) : 0;
                var costCarton = costCartonEl ? (productFormParseNumericField('p-cost-carton') || 0) : 0;
                var convFieldIds = {
                    'p-pieces-per-pack': 1,
                    'p-packs-per-carton': 1,
                    'p-pieces-per-carton-only': 1,
                    'p-pieces-per-carton-single': 1
                };
                var fromConv = !!(sourceId && convFieldIds[sourceId]);
                if (!sourceId || fromConv) {
                    if (costPiece > 0) sourceId = 'p-cost';
                    else if (costCarton > 0) sourceId = 'p-cost-carton';
                    else if (costPack > 0) sourceId = 'p-cost-pack';
                    else if (fromConv) return;
                }

                if (sourceId === 'p-cost-carton' && f.vc && f.piecesPerCarton > 0 && costCarton > 0) {
                    if (costPieceEl) costPieceEl.value = fmt(costCarton / f.piecesPerCarton);
                    if (f.vp && f.ppc > 0 && f.unitStructure === 'carton_pack_piece' && costPackEl) {
                        costPackEl.value = fmt(costCarton / f.ppc);
                    }
                } else if (sourceId === 'p-cost-pack' && f.vp && f.ppp > 0 && costPack > 0 && f.unitStructure === 'carton_pack_piece') {
                    if (costPieceEl) costPieceEl.value = fmt(costPack / f.ppp);
                    if (f.vc && costCartonEl) costCartonEl.value = fmt(costPack * f.ppc);
                } else if (sourceId === 'p-cost' && costPiece > 0) {
                    if (f.vp && costPackEl) costPackEl.value = fmt(costPiece * f.ppp);
                    if (f.vc && costCartonEl) costCartonEl.value = fmt(costPiece * f.piecesPerCarton);
                }
            } finally {
                _syncCostFromLevelLock = false;
            }
        }

        function calcTotalStockFromTable() {
            var f = productFormGetConversionFactors();
            var unitStructure = f.unitStructure;
            var vp = f.vp;
            var vc = f.vc;
            var ppp = f.ppp;
            var piecesPerCarton = f.piecesPerCarton;
            var qtyMode = (typeof getProductFormQtyMode === 'function') ? getProductFormQtyMode() : 'piece';
            var scRaw = parseFloat(((document.getElementById('p-stock-carton') && document.getElementById('p-stock-carton').value) || '0').replace(/,/g, ''));
            if (!isFinite(scRaw) || scRaw < 0) scRaw = 0;
            var spRaw = parseFloat(((document.getElementById('p-stock-pack') && document.getElementById('p-stock-pack').value) || '0').replace(/,/g, ''));
            if (!isFinite(spRaw) || spRaw < 0) spRaw = 0;
            var sc = vc ? ((qtyMode === 'kilo') ? (Math.round(scRaw * 1000) / 1000) : Math.floor(scRaw)) : 0;
            var sp = (vp && unitStructure !== 'carton_piece') ? ((qtyMode === 'kilo') ? (Math.round(spRaw * 1000) / 1000) : Math.floor(spRaw)) : 0;
            var siRaw = parseFloat((document.getElementById('p-stock-piece').value || '0').replace(/,/g, ''));
            if (!isFinite(siRaw) || siRaw < 0) siRaw = 0;
            var si = (qtyMode === 'kilo') ? (Math.round(siRaw * 1000) / 1000) : Math.floor(siRaw);
            var total = (qtyMode === 'kilo') ? (sc + sp + si) : ((sc * piecesPerCarton) + (sp * ppp) + si);
            var el = document.getElementById('p-total-stock-preview');
            if (el) el.innerText = total > 0 ? ('کۆیا گشتی مەخزەن: ' + formatQtyForDisplay(total, { qty_mode: qtyMode }) + ' ' + (qtyMode === 'kilo' ? 'کیلۆ' : 'دانە')) : '';
        }

        function productFormParseNumericField(elId) {
            var el = document.getElementById(elId);
            if (!el) return NaN;
            var s = String(el.value != null ? el.value : '').replace(/,/g, '').trim();
            if (s === '') return NaN;
            var n = parseFloat(s);
            return isNaN(n) ? NaN : n;
        }

        function productFormExpiryEnabled() {
            var ch = document.getElementById('p-expiry-enabled');
            return !!(ch && ch.checked);
        }

        function syncProductFormExpiryUi() {
            var on = productFormExpiryEnabled();
            var wrap = document.getElementById('p-expiry-field-wrap');
            var alertWrap = document.getElementById('p-expiry-alert-wrap');
            var inp = document.getElementById('p-expiry');
            if (wrap) wrap.classList.toggle('is-hidden', !on);
            if (alertWrap) alertWrap.classList.toggle('is-hidden', !on);
            if (!on && inp) inp.value = '';
        }
        window.syncProductFormExpiryUi = syncProductFormExpiryUi;
        window.productFormExpiryEnabled = productFormExpiryEnabled;

        function getProductFormExpiryForSave() {
            if (!productFormExpiryEnabled()) return '';
            var inp = document.getElementById('p-expiry');
            var exp = (inp && inp.value) ? String(inp.value).trim() : '';
            var ymdRx = /^\d{4}-\d{2}-\d{2}$/;
            return ymdRx.test(exp) ? exp : '';
        }

        function isProductNameOptionalAllowed() {
            var el = document.getElementById('p-allow-no-name');
            return !!(el && el.checked);
        }

        function buildProductNameFromBarcodePrice(barcode, priceIqd) {
            var bc = String(barcode == null ? '' : barcode).trim();
            var priceNum = Number(priceIqd);
            if (!isFinite(priceNum) || priceNum < 0) priceNum = 0;
            var priceStr = (typeof formatCurrency === 'function')
                ? formatCurrency(priceNum)
                : String(Math.round(priceNum));
            var sym = (typeof getCurrencySymbol === 'function') ? String(getCurrencySymbol() || '').trim() : '';
            if (bc && priceStr) return bc + ' · ' + priceStr + (sym ? (' ' + sym) : '');
            if (bc) return bc;
            if (priceStr) return priceStr + (sym ? (' ' + sym) : '');
            return '';
        }

        function resolveProductNameForSave(nameRaw, barcode, priceIqd) {
            var name = String(nameRaw == null ? '' : nameRaw).trim();
            if (name) return name;
            if (typeof isJewelryMode === 'function' && isJewelryMode()) return name;
            if (!isProductNameOptionalAllowed()) return '';
            return buildProductNameFromBarcodePrice(barcode, priceIqd);
        }

        function syncProductNameOptionalUi() {
            var allow = isProductNameOptionalAllowed();
            var nameEl = document.getElementById('p-name');
            var mark = document.getElementById('p-name-required-mark');
            var hint = document.getElementById('p-name-optional-hint');
            if (mark) mark.style.display = allow ? 'none' : '';
            if (hint) hint.style.display = allow ? '' : 'none';
            if (nameEl) {
                nameEl.placeholder = allow
                    ? ((typeof t === 'function') ? t('product_form_name_optional_placeholder') : 'ئارەزوومەندانە — یان بارکۆد + نرخ')
                    : ((typeof t === 'function') ? t('product_form_name_placeholder') : 'ناڤ');
                nameEl.setAttribute('aria-required', allow ? 'false' : 'true');
            }
        }
        window.syncProductNameOptionalUi = syncProductNameOptionalUi;
        window.isProductNameOptionalAllowed = isProductNameOptionalAllowed;
        window.buildProductNameFromBarcodePrice = buildProductNameFromBarcodePrice;

        /** New product (insert): require category, piece price/cost, and pack/carton barcodes when those unit rows are enabled. */
        function validateNewProductFormCompleteness() {
            if (typeof isJewelryMode === 'function' && isJewelryMode()
                && typeof ensureJewelryCostBeforeSave === 'function') {
                try { ensureJewelryCostBeforeSave(); } catch (eJew) {}
            }
            var nameEl = document.getElementById('p-name');
            var name = (nameEl && nameEl.value) ? nameEl.value.trim() : '';
            var barcodeElV = document.getElementById('p-barcode');
            var barcodeV = (barcodeElV && barcodeElV.value) ? barcodeElV.value.trim() : '';
            var priceV = productFormParseNumericField('p-price');
            if (!name && !(typeof isJewelryMode === 'function' && isJewelryMode())) {
                if (isProductNameOptionalAllowed()) {
                    if (!barcodeV) {
                        alert(typeof t === 'function' ? t('product_barcode_required') : '⛔ بارکۆد ئیجبارییە ئەگەر ناو نەبێت.');
                        if (barcodeElV) { try { barcodeElV.focus(); } catch (eBc) {} }
                        return false;
                    }
                    if (!(priceV > 0)) {
                        alert(typeof t === 'function' ? t('product_new_requires_price') : '⛔ نرخ ئیجبارییە ئەگەر ناو نەبێت.');
                        var pe0 = document.getElementById('p-price');
                        if (pe0) pe0.focus();
                        return false;
                    }
                } else {
                    alert(typeof t === 'function' ? t('product_new_requires_name') : '⛔ ناڤێ ئایتمی ئیجبارییە بۆ ڤی جورێ دکانێ.');
                    if (nameEl) { try { nameEl.focus(); } catch (e1) {} }
                    return false;
                }
            }
            var catEl = document.getElementById('p-cat');
            var cat = (catEl && catEl.value) ? catEl.value.trim() : '';
            if (!cat) {
                alert(typeof t === 'function' ? t('product_new_requires_category') : '⛔ لإضافة صنف جديد يجب اختيار التصنيف.');
                if (catEl) { try { catEl.focus(); } catch (e1) {} }
                return false;
            }
            var price = productFormParseNumericField('p-price');
            if (!(price > 0)) {
                alert(typeof t === 'function' ? t('product_new_requires_price') : '⛔ سعر البيع (للتك) إلزامي ويجب أن يكون أكبر من صفر.');
                var pe = document.getElementById('p-jewelry-price') || document.getElementById('p-price');
                if (pe) pe.focus();
                return false;
            }
            var cost = productFormParseNumericField('p-cost');
            // Metal jewelry: cost field hidden — empty becomes 0 (or buy-rate×grams)
            // Piece jewelry (watches): cost is required from the unit table like market
            if (typeof isJewelryMode === 'function' && isJewelryMode()
                && !(typeof isJewelryPieceEntryMode === 'function' && isJewelryPieceEntryMode())) {
                if (isNaN(cost) || cost < 0) {
                    var cEl = document.getElementById('p-cost');
                    if (cEl) cEl.value = '0';
                    cost = 0;
                }
            } else if (isNaN(cost) || cost < 0) {
                alert(typeof t === 'function' ? t('product_new_requires_cost') : '⛔ أدخل تكلفة التك (رقم صالح ≥ 0).');
                var ce = document.getElementById('p-cost'); if (ce) ce.focus();
                return false;
            }
            var showPack = !!(document.getElementById('p-unit-show-pack') && document.getElementById('p-unit-show-pack').value === '1');
            var showCarton = !!(document.getElementById('p-unit-show-carton') && document.getElementById('p-unit-show-carton').value === '1');
            if (typeof isJewelryMode === 'function' && isJewelryMode()) {
                showPack = false;
                showCarton = false;
            }
            if (showPack) {
                var bp = (document.getElementById('p-barcode-pack') && document.getElementById('p-barcode-pack').value) ? document.getElementById('p-barcode-pack').value.trim() : '';
                if (!bp) {
                    alert(typeof t === 'function' ? t('product_new_requires_pack_barcode') : '⛔ الباكيت مفعّل — باركود الباكيت إلزامي.');
                    var bpe = document.getElementById('p-barcode-pack'); if (bpe) bpe.focus();
                    return false;
                }
            }
            if (showCarton) {
                var bct = (document.getElementById('p-barcode-carton') && document.getElementById('p-barcode-carton').value) ? document.getElementById('p-barcode-carton').value.trim() : '';
                if (!bct) {
                    alert(typeof t === 'function' ? t('product_new_requires_carton_barcode') : '⛔ الكرتون مفعّل — باركود الكرتون إلزامي.');
                    var bce = document.getElementById('p-barcode-carton'); if (bce) bce.focus();
                    return false;
                }
            }
            return true;
        }

        function getProductsListSearchQuery() {
            var el = document.getElementById('products-search-input');
            return el ? String(el.value || '').trim() : '';
        }

        function getProductListStockDisplay(p) {
            if (!p || !p.trackStock) {
                return { html: '∞', color: 'var(--text)' };
            }
            var qtyRaw = 0;
            try {
                qtyRaw = (typeof getDisplayQty === 'function') ? getDisplayQty(p) : (Number(p.qty) || 0);
            } catch (_qtyErr) {
                qtyRaw = Number(p.qty) || 0;
            }
            var qtyDisp = (typeof formatQtyForDisplay === 'function') ? formatQtyForDisplay(qtyRaw, p) : String(qtyRaw);
            var unitLbl = (typeof getProductUnitLabel === 'function') ? getProductUnitLabel(p, 'piece') : '';
            var base = escapeHtml(String(qtyDisp) + (unitLbl ? (' ' + unitLbl) : ''));
            var tFn = (typeof t === 'function') ? t : null;
            var lbl = function(key, fb) {
                var v = tFn ? tFn(key) : fb;
                return (v && v !== key) ? v : fb;
            };
            if (qtyRaw <= 0) {
                return {
                    html: base + ' <small style="opacity:0.9;">(' + escapeHtml(lbl('wh_status_stockout', 'نەما')) + ')</small>',
                    color: 'var(--danger)'
                };
            }
            if (qtyRaw > 0 && qtyRaw <= getMinStock(p)) {
                return { html: base, color: '#d97706' };
            }
            return { html: base, color: 'var(--text)' };
        }

        function safeProductListRowHtml(p, posY, posN) {
            if (!p || p.id == null) return '';
            try {
                var shopUsd = (typeof getDefaultCurrency === 'function') && getDefaultCurrency() === 'USD';
                var itemCur = (typeof inventoryItemNativeCurrency === 'function')
                    ? inventoryItemNativeCurrency(p)
                    : String((p && p.currency) || '').toUpperCase();
                var costIqd;
                var sellIqd;
                if (!shopUsd && itemCur !== 'USD' && typeof inventoryNativeUnitIqd === 'function') {
                    costIqd = inventoryNativeUnitIqd(p, 'cost');
                    sellIqd = inventoryNativeUnitIqd(p, 'sell');
                } else if (shopUsd && itemCur === 'USD' && typeof inventoryNativeUnitUsd === 'function') {
                    costIqd = inventoryNativeUnitUsd(p, 'cost');
                    sellIqd = inventoryNativeUnitUsd(p, 'sell');
                } else {
                    costIqd = (typeof getCatalogPieceCostIqd === 'function') ? getCatalogPieceCostIqd(p) : (Number(p.cost) || 0);
                    sellIqd = (typeof getCatalogPieceSellIqd === 'function') ? getCatalogPieceSellIqd(p) : (Number(p.price) || 0);
                }
                var sym = (typeof getCurrencySymbol === 'function') ? getCurrencySymbol() : '';
                var stockDisp = getProductListStockDisplay(p);
                var forSale = (typeof isProductForSale === 'function') ? isProductForSale(p) : (p.forSale !== false && p.forSale !== 0 && p.forSale !== '0');
                var catLabel = escapeHtml(String(p.cat != null ? p.cat : (p.category != null ? p.category : '')) || '-');
                var fmt = (typeof formatActiveCurrencyAmount === 'function')
                    ? formatActiveCurrencyAmount
                    : ((typeof formatCurrency === 'function') ? formatCurrency : function (v) { return String(v == null ? 0 : v); });
                var pinCls = p.isPinned ? 'btn-warning' : 'btn-dark';
                var pinVal = p.isPinned ? 0 : 1;
                return '<tr data-product-id="' + String(p.id) + '">' +
                    '<td><b>' + escapeHtml(p.name || '-') + '</b></td>' +
                    '<td>' + escapeHtml(p.barcode || '-') + '</td>' +
                    '<td>' + catLabel + '</td>' +
                    '<td>' + fmt(costIqd) + ' ' + sym + '</td>' +
                    '<td>' + fmt(sellIqd) + ' ' + sym + '</td>' +
                    '<td style="color:' + stockDisp.color + ';font-weight:' + (stockDisp.color === 'var(--danger)' ? 'bold' : 'normal') + '">' + stockDisp.html + '</td>' +
                    '<td>' + (forSale ? ('<span style="color:green">' + escapeHtml(posY) + '</span>') : ('<span style="color:red">' + escapeHtml(posN) + '</span>')) + '</td>' +
                    '<td>' +
                        '<button type="button" class="btn btn-sm ' + pinCls + '" onclick="toggleProductPin(' + p.id + ', ' + pinVal + ')" title="' + (p.isPinned ? 'Unpin' : 'Pin') + '"><i class="fas fa-thumbtack"></i></button> ' +
                        '<button type="button" class="btn btn-sm btn-info" onclick="if(typeof printProductLabel===\'function\')printProductLabel(' + p.id + ')" title="چاپا لزگە"><i class="fas fa-tag"></i></button> ' +
                        '<button type="button" class="btn btn-sm btn-brand" onclick="editProd(' + p.id + ')"><i class="fas fa-edit"></i></button> ' +
                        '<button type="button" class="btn btn-danger btn-sm" onclick="deleteProd(' + p.id + ')"><i class="fas fa-trash"></i></button>' +
                    '</td>' +
                '</tr>';
            } catch (rowErr) {
                console.warn('Product list row skipped for id=' + (p && p.id), rowErr);
                return '';
            }
        }

        function setProductSaveInFlight(on) {
            window.__productSaveInFlight = !!on;
            ['btn-save-prod-step1', 'btn-save-prod', 'layout-btn-partner'].forEach(function (id) {
                var btn = document.getElementById(id);
                if (!btn) return;
                btn.disabled = !!on;
                if (on) btn.setAttribute('aria-busy', 'true');
                else btn.removeAttribute('aria-busy');
            });
        }

        function snapshotProductFormForSave() {
            var ids = [
                'p-id', 'p-name', 'p-barcode', 'p-sku', 'p-price', 'p-cost', 'p-cat', 'p-supplier', 'p-manufacturer',
                'p-takeaway-price', 'p-takeaway-price-pack', 'p-takeaway-price-carton', 'p-wholesale-qty', 'p-wholesale-price',
                'p-min-stock', 'p-expiry-alert-days', 'p-expiry', 'p-note', 'p-stock-carton', 'p-stock-pack', 'p-stock-piece',
                'p-pieces-per-pack', 'p-packs-per-carton', 'p-pieces-per-carton-only', 'p-barcode-pack', 'p-barcode-carton',
                'p-price-pack', 'p-price-carton', 'p-cost-pack', 'p-cost-carton', 'p-unit-name-piece', 'p-unit-name-pack',
                'p-unit-name-carton', 'p-unit-show-pack', 'p-unit-show-carton', 'p-item-type', 'p-unit-structure'
            ];
            var snap = { values: {}, checks: {} };
            ids.forEach(function (id) {
                var el = document.getElementById(id);
                if (el) snap.values[id] = el.value;
            });
            ['p-track', 'p-for-sale', 'p-allow-no-name', 'p-expiry-enabled', 'p-multi-barcode'].forEach(function (id) {
                var el = document.getElementById(id);
                if (el) snap.checks[id] = !!el.checked;
            });
            return snap;
        }

        function restoreProductFormSnapshot(snap) {
            if (!snap || !snap.values) return;
            Object.keys(snap.values).forEach(function (id) {
                var el = document.getElementById(id);
                if (el) el.value = snap.values[id];
            });
            Object.keys(snap.checks || {}).forEach(function (id) {
                var el = document.getElementById(id);
                if (el) el.checked = !!snap.checks[id];
            });
            try {
                if (typeof syncBarcodeToPieceCell === 'function') syncBarcodeToPieceCell();
                if (typeof syncProductNameOptionalUi === 'function') syncProductNameOptionalUi();
                if (typeof syncProductFormExpiryUi === 'function') syncProductFormExpiryUi();
                if (typeof toggleStockInputs === 'function') toggleStockInputs();
                if (typeof toggleSupplierInput === 'function') toggleSupplierInput();
                if (typeof calcMultiLevelCarton === 'function') calcMultiLevelCarton();
            } catch (_eRest) {}
        }

        function focusProductBarcodeForBurstEntry() {
            var bc = document.getElementById('p-barcode');
            if (!bc) bc = document.getElementById('p-barcode-piece');
            if (!bc) return;
            try {
                bc.focus();
                if (bc.select) bc.select();
            } catch (_eF) {}
        }

        /** Single-row DOM update — never rebuild the whole products table. */
        function upsertProductAdminListRow(p, isInsert) {
            if (!p || p.id == null) return false;
            var container = document.getElementById('product-list-container');
            if (!container) return false;
            var tbody = container.querySelector('table.products-admin-table tbody');
            function T(k, kuFallback) {
                if (typeof t !== 'function') return kuFallback || '';
                var v = t(k);
                return (v && String(v).trim()) ? v : (kuFallback || '');
            }
            var posY = T('products_pos_yes', 'بەڵێ');
            var posN = T('products_pos_no', 'نەخێر');
            var rowHtml = safeProductListRowHtml(p, posY, posN);
            if (!rowHtml) return false;

            if (!tbody) {
                // Empty-state / first product: one light paint is cheaper than waiting forever.
                if (typeof renderProducts === 'function') renderProducts(getProductsListSearchQuery());
                return true;
            }

            var q = getProductsListSearchQuery();
            if (q) {
                var matches = (typeof window.productMatchesBarcodeOrNameSearch === 'function')
                    ? window.productMatchesBarcodeOrNameSearch(p, q)
                    : true;
                if (!matches) {
                    var stale = tbody.querySelector('tr[data-product-id="' + String(p.id) + '"]');
                    if (stale) stale.remove();
                    return true;
                }
            }

            var existing = tbody.querySelector('tr[data-product-id="' + String(p.id) + '"]');
            if (existing) {
                existing.outerHTML = rowHtml;
            } else if (isInsert) {
                tbody.insertAdjacentHTML('afterbegin', rowHtml);
                var countEl = document.getElementById('total-products-count');
                if (countEl && !q) {
                    var n = parseInt(countEl.innerText, 10);
                    if (Number.isFinite(n)) countEl.innerText = String(n + 1);
                }
            } else {
                tbody.insertAdjacentHTML('afterbegin', rowHtml);
            }
            return true;
        }

        /**
         * Turbo finish: clear form + focus barcode. Never await full catalog / full table rebuild.
         * Pass localProd to patch scan index + single table row when available.
         */
        function finishProductSaveAndStayOnStep1(localProd, saveAction) {
            clearProductInputs(false, true);
            if (typeof productFormGoToStep === 'function') productFormGoToStep(1);
            focusProductBarcodeForBurstEntry();
            if (localProd && localProd.id != null) {
                try {
                    if (typeof registerProductInScanIndex === 'function') registerProductInScanIndex(localProd);
                    else if (typeof window.registerProductInScanIndex === 'function') window.registerProductInScanIndex(localProd);
                    upsertProductAdminListRow(localProd, saveAction === 'insert');
                } catch (_eRow) {}
            }
        }

        function saveProduct(skipTransaction = false) {
            try {
            if (window.__productSaveInFlight) return;
            var idEl = document.getElementById('p-id');
            var nameEl = document.getElementById('p-name');
            var barcodeEl = document.getElementById('p-barcode');
            if (!nameEl) { alert("هەڵە: ناڤێن فۆرمێ نەهاتنە دیتن. هیڤییە پەڕەی نووی بکە."); return; }
            var id = (idEl && idEl.value) || '';
            var name = (nameEl && nameEl.value) || '';
            var barcode = (barcodeEl && barcodeEl.value) ? barcodeEl.value.trim() : '';
            var skuEl = document.getElementById('p-sku');
            var skuVal = (skuEl && skuEl.value) ? String(skuEl.value).trim().slice(0, 64) : '';

            if (!barcode) {
                var msg = typeof t === 'function' ? t('product_barcode_required') : '⛔ الباركود إلزامي. لا يمكن حفظ صنف بدون باركود. يرجى إدخال الباركود (أو مسحه) ثم المحاولة مرة أخرى.';
                alert(msg);
                if (barcodeEl) { barcodeEl.focus(); barcodeEl.select(); }
                return;
            }
            if (typeof isJewelryMode === 'function' && isJewelryMode()
                && typeof ensureJewelryCostBeforeSave === 'function') {
                try { ensureJewelryCostBeforeSave(); } catch (eJewSave) {}
            }
            if (!id && !validateNewProductFormCompleteness()) return;

            var formCurSave = (typeof getProductFormCurrency === 'function') ? getProductFormCurrency() : ((typeof getDefaultCurrency === 'function') ? getDefaultCurrency() : 'IQD');
            var priceEarly = productFormInputToIqd((document.getElementById('p-price') && document.getElementById('p-price').value) || 0, formCurSave);
            name = resolveProductNameForSave(name, barcode, priceEarly);
            var techPack = { name: name, json: '', specs: {} };
            var techSpecsOn = typeof canUseTechSpecs === 'function' && canUseTechSpecs();
            if (techSpecsOn && typeof collectTechSpecsForSave === 'function') {
                techPack = collectTechSpecsForSave(name);
                name = techPack.name || name;
            }
            if (!(typeof isJewelryMode === 'function' && isJewelryMode()) && !String(name || '').trim()) {
                if (isProductNameOptionalAllowed()) {
                    alert(typeof t === 'function' ? t('product_no_name_needs_barcode_price') : '⛔ بۆ بێ ناو: بارکۆد و نرخ پێویستن.');
                } else {
                    alert(typeof t === 'function' ? t('product_new_requires_name') : '⛔ ناڤێ ئایتمی ئیجبارییە بۆ ڤی جورێ دکانێ.');
                }
                if (nameEl) nameEl.focus();
                return;
            }
            if (nameEl && String(nameEl.value || '').trim() === '' && String(name || '').trim()) {
                nameEl.value = name;
            }
            
            var supplier = "Direct Store";
            var suppElSave = document.getElementById('p-supplier');
            if (suppElSave && suppElSave.value && String(suppElSave.value).trim()) supplier = String(suppElSave.value).trim();
            var manufacturer = '';
            var mfrElSave = document.getElementById('p-manufacturer');
            if (mfrElSave && mfrElSave.value && String(mfrElSave.value).trim()) manufacturer = String(mfrElSave.value).trim();
            var products = (db && db.products) ? db.products : [];

            var duplicate = products.find(function(p) {
                return name.trim() !== '' && (p.name || '').trim().toLowerCase() === name.trim().toLowerCase() && p.id != (id || 0);
            });
            if(duplicate) {
                alert("⛔ ئەڤ ئایتمە (" + name + ") بەری نوکە یێ هاتیە تۆمارکرن!");
                return;
            }
            if (skuVal) {
                var dupSku = products.find(function(p) {
                    return String(p.sku || '').trim().toLowerCase() === skuVal.toLowerCase() && String(p.id) !== String(id || 0);
                });
                if (dupSku) {
                    alert("⛔ ئەڤ SKU یێ (" + skuVal + ") بەری نوکە بۆ ئایتمەکێ دی هاتیە تۆمارکرن!");
                    if (skuEl) skuEl.focus();
                    return;
                }
            }

            var price = productFormInputToIqd((document.getElementById('p-price') && document.getElementById('p-price').value) || 0, formCurSave);
            var cost = productFormInputToIqd((document.getElementById('p-cost') && document.getElementById('p-cost').value) || 0, formCurSave);
            var cat = (document.getElementById('p-cat') && document.getElementById('p-cat').value) || '';
            var takeawayPrice = productFormInputToIqd((document.getElementById('p-takeaway-price') && document.getElementById('p-takeaway-price').value) || 0, formCurSave);
            var takeawayPricePack = productFormInputToIqd((document.getElementById('p-takeaway-price-pack') && document.getElementById('p-takeaway-price-pack').value) || 0, formCurSave);
            var takeawayPriceCarton = productFormInputToIqd((document.getElementById('p-takeaway-price-carton') && document.getElementById('p-takeaway-price-carton').value) || 0, formCurSave);
            var wholesaleQty = parseInt((document.getElementById('p-wholesale-qty') && document.getElementById('p-wholesale-qty').value) || 0, 10) || 0;
            var wholesalePrice = productFormInputToIqd((document.getElementById('p-wholesale-price') && document.getElementById('p-wholesale-price').value) || 0, formCurSave);
            var minStockRaw = (document.getElementById('p-min-stock') && document.getElementById('p-min-stock').value != null) ? String(document.getElementById('p-min-stock').value).trim() : '';
            var minStock = minStockRaw === '' ? 5 : (parseInt(minStockRaw, 10) || 5);
            if (minStock < 0) minStock = 5;
            var expiryAlertRaw = (document.getElementById('p-expiry-alert-days') && document.getElementById('p-expiry-alert-days').value != null) ? String(document.getElementById('p-expiry-alert-days').value).trim() : '';
            var expiryAlertDays = expiryAlertRaw === '' ? 30 : (parseInt(expiryAlertRaw, 10) || 30);
            if (expiryAlertDays <= 0) expiryAlertDays = 30;
            var trackEl = document.getElementById('p-track');
            var track = trackEl ? trackEl.checked : true;
            // Jewelry pieces: always track stock (never ∞)
            if (typeof isJewelryMode === 'function' && isJewelryMode()) {
                var jewSetChk = document.getElementById('p-jewelry-sell-set');
                var isJewSet = !!(jewSetChk && jewSetChk.checked);
                if (!isJewSet) {
                    if (typeof ensureJewelryTrackStockOn === 'function') ensureJewelryTrackStockOn();
                    if (typeof syncJewelryMoneyFromSimple === 'function') syncJewelryMoneyFromSimple('stock');
                    track = true;
                    if (trackEl) trackEl.checked = true;
                }
            }
            if (!id) setProductFormTrackStockPref(track);
            var expiry = (typeof getProductFormExpiryForSave === 'function') ? getProductFormExpiryForSave() : '';
            var qtyMode = getProductFormQtyMode();
            var ppp = typeof productFormEffectivePpp === 'function' ? productFormEffectivePpp() : (parseInt((document.getElementById('p-pieces-per-pack') && document.getElementById('p-pieces-per-pack').value) || 1, 10) || 1);
            var ppc = parseInt((document.getElementById('p-packs-per-carton') && document.getElementById('p-packs-per-carton').value) || 1, 10) || 1;
            var showPack = !!(document.getElementById('p-unit-show-pack') && document.getElementById('p-unit-show-pack').value === '1');
            var showCarton = !!(document.getElementById('p-unit-show-carton') && document.getElementById('p-unit-show-carton').value === '1');
            if (typeof isJewelryMode === 'function' && isJewelryMode()) {
                showPack = false;
                showCarton = false;
                var spHide = document.getElementById('p-unit-show-pack');
                var scHide = document.getElementById('p-unit-show-carton');
                if (spHide) spHide.value = '0';
                if (scHide) scHide.value = '0';
            }
            var pppSave = ppp;
            var ppcSave = ppc;
            if (!showPack && showCarton) ppcSave = 1;
            if (!showPack && !showCarton) {
                pppSave = 1;
                ppcSave = 1;
            }
            if (showPack && !showCarton) ppcSave = 1;
            var itemsPerCarton = pppSave * ppcSave;
            var scRaw = parseFloat((((document.getElementById('p-stock-carton') && document.getElementById('p-stock-carton').value) || '0')).replace(/,/g, ''));
            var spRaw = parseFloat((((document.getElementById('p-stock-pack') && document.getElementById('p-stock-pack').value) || '0')).replace(/,/g, ''));
            if (!isFinite(scRaw) || scRaw < 0) scRaw = 0;
            if (!isFinite(spRaw) || spRaw < 0) spRaw = 0;
            var sc = (qtyMode === 'kilo') ? (Math.round(scRaw * 1000) / 1000) : (showCarton ? Math.floor(scRaw) : 0);
            var sp = (qtyMode === 'kilo') ? (Math.round(spRaw * 1000) / 1000) : (showPack ? Math.floor(spRaw) : 0);
            var siRaw = parseFloat(((document.getElementById('p-stock-piece') && document.getElementById('p-stock-piece').value) || '0').replace(/,/g, ''));
            if (!isFinite(siRaw) || siRaw < 0) siRaw = 0;
            var si = (qtyMode === 'kilo') ? (Math.round(siRaw * 1000) / 1000) : Math.floor(siRaw);
            var unitType = (qtyMode === 'kilo') ? 'kilo' : 'carton';
            if (qtyMode === 'kilo') {
                showPack = false;
                showCarton = false;
                pppSave = 1;
                ppcSave = 1;
                itemsPerCarton = 1;
            }

            var totalQty = (qtyMode === 'kilo') ? (sc + sp + si) : ((sc * itemsPerCarton) + (sp * pppSave) + si);

            if (track && (cost * totalQty > 100000000)) {
                if(!confirm("⚠️ ئاگەهداربە! بهایێ گشتی یێ ڤی ئایتمی گەلەک مەزنە. ئەرێ دڵنیای ئەڤە بارکۆد نینە؟")) return;
            }

            if (!name || !name.trim()) {
                alert(typeof t === 'function' ? t('product_new_requires_name') : 'هیڤیە ناڤێ ئایتمی بنڤیسە!');
                return;
            }

            var barcode_pack = (document.getElementById('p-barcode-pack') && document.getElementById('p-barcode-pack').value) ? document.getElementById('p-barcode-pack').value.trim() : '';
            var barcode_carton = (document.getElementById('p-barcode-carton') && document.getElementById('p-barcode-carton').value) ? document.getElementById('p-barcode-carton').value.trim() : '';
            var price_pack_raw = (document.getElementById('p-price-pack') && document.getElementById('p-price-pack').value) ? String(document.getElementById('p-price-pack').value).trim() : '';
            var price_carton_raw = (document.getElementById('p-price-carton') && document.getElementById('p-price-carton').value) ? String(document.getElementById('p-price-carton').value).trim() : '';
            var cost_pack_raw = (document.getElementById('p-cost-pack') && document.getElementById('p-cost-pack').value) ? String(document.getElementById('p-cost-pack').value).trim() : '';
            var cost_carton_raw = (document.getElementById('p-cost-carton') && document.getElementById('p-cost-carton').value) ? String(document.getElementById('p-cost-carton').value).trim() : '';
            var price_pack = price_pack_raw !== '' ? productFormInputToIqd(price_pack_raw, formCurSave) : '';
            var price_carton = price_carton_raw !== '' ? productFormInputToIqd(price_carton_raw, formCurSave) : '';
            var cost_pack = cost_pack_raw !== '' ? productFormInputToIqd(cost_pack_raw, formCurSave) : '';
            var cost_carton = cost_carton_raw !== '' ? productFormInputToIqd(cost_carton_raw, formCurSave) : '';
            var unit_name_piece = (document.getElementById('p-unit-name-piece') && document.getElementById('p-unit-name-piece').value) ? document.getElementById('p-unit-name-piece').value.trim() : '';
            var unit_name_pack = (document.getElementById('p-unit-name-pack') && document.getElementById('p-unit-name-pack').value) ? document.getElementById('p-unit-name-pack').value.trim() : '';
            var unit_name_carton = (document.getElementById('p-unit-name-carton') && document.getElementById('p-unit-name-carton').value) ? document.getElementById('p-unit-name-carton').value.trim() : '';
            if (!showPack) {
                barcode_pack = '';
                price_pack = '';
                cost_pack = '';
            }
            if (!showCarton) {
                barcode_carton = '';
                price_carton = '';
                cost_carton = '';
            }

            // Validation: Ensure piece, pack, and carton barcodes are distinct from each other in THIS form
            var pieceBarcodes = barcode.split(',').map(function(c){ return c.trim(); }).filter(function(c){ return c !== ''; });
            var packBarcodes = showPack ? barcode_pack.split(',').map(function(c){ return c.trim(); }).filter(function(c){ return c !== ''; }) : [];
            var cartonBarcodes = showCarton ? barcode_carton.split(',').map(function(c){ return c.trim(); }).filter(function(c){ return c !== ''; }) : [];

            var allBarcodes = [].concat(pieceBarcodes, packBarcodes, cartonBarcodes);
            var uniqueBarcodes = new Set(allBarcodes);

            // Validation: Ensure NONE of these barcodes exist in ANY other product (piece, pack, or carton)
            if (allBarcodes.length > 0) {
                for (var ci = 0; ci < allBarcodes.length; ci++) {
                    var code = allBarcodes[ci];
                    var existsInOther = products.some(function(p) {
                        if (p.id == (id || 0)) return false; // skip current product
                        var pPieces = (p.barcode || '').split(',').map(function(c){ return c.trim(); });
                        var pPacks = (p.unit_show_pack != null && Number(p.unit_show_pack) === 0) ? [] : (p.barcode_pack || '').split(',').map(function(c){ return c.trim(); });
                        var pCartons = (p.unit_show_carton != null && Number(p.unit_show_carton) === 0) ? [] : (p.barcode_carton || '').split(',').map(function(c){ return c.trim(); });
                        var allProductCodes = [].concat(pPieces, pPacks, pCartons);
                        return allProductCodes.indexOf(code) !== -1;
                    });
                    if (existsInOther) {
                        alert("⛔ ئەڤ بارکۆدە (" + code + ") بەری نوکە بۆ ئایتمەکێ دی یان یەکەیەکا دی هاتیە تۆمارکرن!");
                        return;
                    }
                }
            }

            var formData = new FormData();
            if(id) formData.append('id', id); // Send ID for update
            formData.append('action', 'save_product');
            formData.append('name', name);
            formData.append('barcode', barcode);
            formData.append('sku', skuVal);
            formData.append('price', price);
            formData.append('cost', cost);
            formData.append('qty', track ? totalQty : 0);
            var pWhEl = document.getElementById('p-warehouse-select');
            var pWhId = pWhEl && pWhEl.value ? parseInt(pWhEl.value, 10) : 0;
            if (!pWhId && typeof getDefaultWarehouseId === 'function') pWhId = getDefaultWarehouseId();
            if (track && pWhId && typeof canUseMultiWarehouse === 'function' && canUseMultiWarehouse()) formData.append('warehouse_id', String(pWhId));
            formData.append('category', cat);
            formData.append('supplier', supplier);
            formData.append('manufacturer', manufacturer);
            formData.append('trackStock', track ? 1 : 0);
            formData.append('unitType', unitType);
            formData.append('qty_mode', qtyMode);
            formData.append('itemsPerCarton', itemsPerCarton);
            formData.append('takeawayPrice', takeawayPrice);
            formData.append('takeawayPrice_pack', takeawayPricePack);
            formData.append('takeawayPrice_carton', takeawayPriceCarton);
            formData.append('wholesaleQty', wholesaleQty);
            formData.append('wholesalePrice', wholesalePrice);
            formData.append('expiry', expiry);
            formData.append('minStock', minStock);
            formData.append('expiry_alert_days', expiryAlertDays);
            var noteEl = document.getElementById('p-note');
            var noteVal = (noteEl && noteEl.value) ? noteEl.value.trim() : '';
            formData.append('note', noteVal);
            if (techSpecsOn) {
                formData.append('tech_specs', (techPack && techPack.json) ? techPack.json : '');
            }
            var forSaleEl = document.getElementById('p-for-sale');
            var forSaleVal = forSaleEl ? forSaleEl.checked : true;
            formData.append('forSale', forSaleVal ? 1 : 0);
            var itemType = expiry ? 'perishable' : 'constant';
            formData.append('item_type', itemType);
            var itHidden = document.getElementById('p-item-type');
            if (itHidden) itHidden.value = itemType;
            formData.append('user', (typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : 'System');
            formData.append('pieces_per_pack', pppSave);
            formData.append('packs_per_carton', ppcSave);
            formData.append('barcode_pack', barcode_pack);
            formData.append('barcode_carton', barcode_carton);
            formData.append('price_pack', price_pack);
            formData.append('price_carton', price_carton);
            formData.append('cost_pack', cost_pack);
            formData.append('cost_carton', cost_carton);
            formData.append('unit_show_pack', showPack ? 1 : 0);
            formData.append('unit_show_carton', showCarton ? 1 : 0);
            formData.append('unit_name_piece', unit_name_piece);
            formData.append('unit_name_pack', unit_name_pack);
            formData.append('unit_name_carton', unit_name_carton);
            var jSaved = null;
            if (typeof appendJewelryToFormData === 'function') {
                jSaved = appendJewelryToFormData(formData);
            }

            if (formCurSave === 'USD' && typeof productFormParseUsdRaw === 'function') {
                var _usdP = productFormParseUsdRaw((document.getElementById('p-price') && document.getElementById('p-price').value) || '');
                if (!isNaN(_usdP)) formData.append('price_usd', String(parseFloat(_usdP.toFixed(6))));
                var _usdC = productFormParseUsdRaw((document.getElementById('p-cost') && document.getElementById('p-cost').value) || '');
                if (!isNaN(_usdC)) formData.append('cost_usd', String(parseFloat(_usdC.toFixed(6))));
                if (!isNaN(_usdP)) formData.append('base_price', String(parseFloat(_usdP.toFixed(6))));
                if (!isNaN(_usdC)) formData.append('base_cost', String(parseFloat(_usdC.toFixed(6))));
                formData.append('base_currency', 'USD');
                if (showPack) {
                    var _usdPP = productFormParseUsdRaw(price_pack_raw);
                    if (!isNaN(_usdPP)) formData.append('price_pack_usd', String(parseFloat(_usdPP.toFixed(6))));
                    var _usdCPk = productFormParseUsdRaw(cost_pack_raw);
                    if (!isNaN(_usdCPk)) formData.append('cost_pack_usd', String(parseFloat(_usdCPk.toFixed(6))));
                }
                if (showCarton) {
                    var _usdPC = productFormParseUsdRaw(price_carton_raw);
                    if (!isNaN(_usdPC)) formData.append('price_carton_usd', String(parseFloat(_usdPC.toFixed(6))));
                    var _usdCC = productFormParseUsdRaw(cost_carton_raw);
                    if (!isNaN(_usdCC)) formData.append('cost_carton_usd', String(parseFloat(_usdCC.toFixed(6))));
                }
            } else {
                formData.append('base_currency', 'IQD');
                formData.append('base_price', String(price));
                formData.append('base_cost', String(cost));
            }

            // Capture USD stamps before clearing the form (burst entry clears DOM immediately).
            var capturedUsd = {
                price_usd: null, cost_usd: null,
                price_pack_usd: null, cost_pack_usd: null,
                price_carton_usd: null, cost_carton_usd: null,
                base_currency: 'IQD', base_price: Number(price) || 0, base_cost: Number(cost) || 0
            };
            if (formCurSave === 'USD' && typeof productFormParseUsdRaw === 'function') {
                var _cP = productFormParseUsdRaw(String((document.getElementById('p-price') && document.getElementById('p-price').value) || ''));
                var _cC = productFormParseUsdRaw(String((document.getElementById('p-cost') && document.getElementById('p-cost').value) || ''));
                if (!isNaN(_cP)) { capturedUsd.price_usd = parseFloat(_cP.toFixed(6)); capturedUsd.base_price = capturedUsd.price_usd; }
                if (!isNaN(_cC)) { capturedUsd.cost_usd = parseFloat(_cC.toFixed(6)); capturedUsd.base_cost = capturedUsd.cost_usd; }
                capturedUsd.base_currency = 'USD';
                if (showPack) {
                    var _cPP = productFormParseUsdRaw(price_pack_raw);
                    var _cCPk = productFormParseUsdRaw(cost_pack_raw);
                    if (!isNaN(_cPP)) capturedUsd.price_pack_usd = parseFloat(_cPP.toFixed(6));
                    if (!isNaN(_cCPk)) capturedUsd.cost_pack_usd = parseFloat(_cCPk.toFixed(6));
                }
                if (showCarton) {
                    var _cPC = productFormParseUsdRaw(price_carton_raw);
                    var _cCC = productFormParseUsdRaw(cost_carton_raw);
                    if (!isNaN(_cPC)) capturedUsd.price_carton_usd = parseFloat(_cPC.toFixed(6));
                    if (!isNaN(_cCC)) capturedUsd.cost_carton_usd = parseFloat(_cCC.toFixed(6));
                }
            }
            var wasInsert = !id;
            var localTechSpecsPre = '';
            if (techSpecsOn) localTechSpecsPre = (techPack && techPack.json) ? techPack.json : '';
            else {
                var oldPTech0 = products.find(function(x) { return x.id == id; });
                localTechSpecsPre = (oldPTech0 && oldPTech0.tech_specs) ? oldPTech0.tech_specs : '';
            }

            setProductSaveInFlight(true);
            var formSnap = snapshotProductFormForSave();
            // Burst entry: reset form + barcode focus immediately (do not wait for server).
            clearProductInputs(false, true);
            if (typeof productFormGoToStep === 'function') productFormGoToStep(1);
            focusProductBarcodeForBurstEntry();

            fetch('?action=save_product', { method: 'POST', body: formData })
            .then(function(res) { return res.text().then(function(t) { try { return JSON.parse(t); } catch(e) { throw new Error(t.indexOf('<!DOCTYPE') !== -1 || t.indexOf('<') === 0 ? 'سێرڤەر بەرسڤا HTML زڤڕاند. پەڕەی نووی بکە.' : 'وەڵامێ سێرڤەر نادروستە (Not valid JSON).'); } }); })
            .then(function(data) {
                if(data && data.status === 'success') {
                    var localProd = {
                        id: parseInt(data.id, 10), name: name, barcode: barcode, sku: skuVal, price: price, cost: cost, qty: track ? totalQty : 0, cat: cat, category: cat, supplier: supplier, manufacturer: manufacturer, trackStock: track, unitType: unitType, qty_mode: qtyMode, itemsPerCarton: itemsPerCarton, forSale: forSaleVal, note: noteVal, tech_specs: localTechSpecsPre, takeawayPrice: takeawayPrice, takeawayPrice_pack: takeawayPricePack, takeawayPrice_carton: takeawayPriceCarton, expiry: expiry, minStock: minStock, expiry_alert_days: expiryAlertDays, wholesaleQty: wholesaleQty, wholesalePrice: wholesalePrice, item_type: itemType, pieces_per_pack: pppSave, packs_per_carton: ppcSave, barcode_pack: barcode_pack, barcode_carton: barcode_carton, price_pack: price_pack, price_carton: price_carton, cost_pack: cost_pack, cost_carton: cost_carton, unit_show_pack: showPack ? 1 : 0, unit_show_carton: showCarton ? 1 : 0, unit_name_piece: unit_name_piece, unit_name_pack: unit_name_pack, unit_name_carton: unit_name_carton, catalog_only: 0
                    };
                    if (jSaved && typeof isJewelryMode === 'function' && isJewelryMode()) {
                        localProd.metal_type = jSaved.metal_type;
                        localProd.karat = jSaved.karat;
                        localProd.weight_grams = jSaved.weight_grams;
                        localProd.making_charge = jSaved.making_charge;
                        localProd.jewelry_price_mode = jSaved.jewelry_price_mode;
                        if (jSaved.jewelry_price_mode === 'by_weight' && typeof computeProductJewelryPrice === 'function') {
                            var liveP = computeProductJewelryPrice(localProd);
                            if (liveP > 0) localProd.price = liveP;
                        }
                        if (jSaved.jewelry_price_mode === 'by_weight' && typeof computeProductJewelryBuyCost === 'function') {
                            var liveC = computeProductJewelryBuyCost(localProd);
                            if (liveC > 0) localProd.cost = liveC;
                        }
                    }
                    if (data.is_jewelry_set) {
                        localProd.is_jewelry_set = true;
                        localProd.jewelry_set_items = Array.isArray(data.jewelry_set_items) ? data.jewelry_set_items : [];
                        localProd.trackStock = 0;
                        if (data.price != null) localProd.price = Number(data.price) || localProd.price;
                        if (Array.isArray(localProd.jewelry_set_items)) {
                            localProd.jewelry_set_items.forEach(function (m) {
                                var mid = m.product_id || m.id;
                                if (!mid) return;
                                var memberProd = {
                                    id: parseInt(mid, 10),
                                    name: m.name || m.label || 'پارچە',
                                    barcode: m.barcode || '',
                                    price: Number(m.price) || 0,
                                    cost: 0,
                                    qty: 0,
                                    category: 'سێت',
                                    trackStock: 1,
                                    forSale: 1,
                                    weight_grams: Number(m.weight_grams) || 0,
                                    metal_type: localProd.metal_type || '',
                                    karat: localProd.karat,
                                    jewelry_price_mode: 'fixed',
                                    is_jewelry_set: false,
                                    unitType: 'carton',
                                    qty_mode: 'piece'
                                };
                                if (typeof posPatchLocalProduct === 'function') posPatchLocalProduct(memberProd, { prepend: true });
                            });
                        }
                    } else if (typeof isJewelryMode === 'function' && isJewelryMode()) {
                        localProd.is_jewelry_set = false;
                        localProd.jewelry_set_items = [];
                    }
                    localProd.price_usd = capturedUsd.price_usd;
                    localProd.cost_usd = capturedUsd.cost_usd;
                    localProd.price_pack_usd = capturedUsd.price_pack_usd;
                    localProd.cost_pack_usd = capturedUsd.cost_pack_usd;
                    localProd.price_carton_usd = capturedUsd.price_carton_usd;
                    localProd.cost_carton_usd = capturedUsd.cost_carton_usd;
                    localProd.base_currency = capturedUsd.base_currency;
                    localProd.base_price = capturedUsd.base_price;
                    localProd.base_cost = capturedUsd.base_cost;
                    if (data.base_price != null) localProd.base_price = Number(data.base_price);
                    if (data.base_cost != null) localProd.base_cost = Number(data.base_cost);
                    if (data.base_currency) localProd.base_currency = data.base_currency;
                    if (track && pWhId && db) {
                        if (!Array.isArray(db.warehouse_stock)) db.warehouse_stock = [];
                        var wsIdx = db.warehouse_stock.findIndex(function(r) {
                            return Number(r.product_id) === Number(data.id) && Number(r.warehouse_id) === Number(pWhId);
                        });
                        var wsRow = { warehouse_id: pWhId, product_id: parseInt(data.id, 10), qty: totalQty };
                        if (wsIdx > -1) db.warehouse_stock[wsIdx] = Object.assign({}, db.warehouse_stock[wsIdx], wsRow);
                        else db.warehouse_stock.push(wsRow);
                        if (data.action === 'update') {
                            var sumQty = 0;
                            db.warehouse_stock.forEach(function(r) {
                                if (Number(r.product_id) === Number(data.id)) sumQty += parseFloat(r.qty) || 0;
                            });
                            localProd.qty = sumQty;
                        }
                    }
                    if (data.action === 'insert') localProd.isPinned = false;

                    // Local cache patch only — never await full catalog / full table rebuild.
                    if (typeof posPatchLocalProduct === 'function') {
                        posPatchLocalProduct(localProd, { prepend: data.action === 'insert' || wasInsert });
                    } else if (db) {
                        if (!Array.isArray(db.products)) db.products = [];
                        if (data.action === 'insert' || wasInsert) db.products.unshift(localProd);
                        else {
                            var pIdx = db.products.findIndex(function(p) { return p.id == data.id; });
                            if (pIdx > -1) Object.keys(localProd).forEach(function(k) {
                                if (localProd[k] !== undefined) db.products[pIdx][k] = localProd[k];
                            });
                        }
                        if (typeof registerProductInScanIndex === 'function') registerProductInScanIndex(localProd);
                        else if (typeof window.registerProductInScanIndex === 'function') window.registerProductInScanIndex(localProd);
                    }

                    try {
                        if (typeof updateCurrencyLockUI === 'function') updateCurrencyLockUI();
                        upsertProductAdminListRow(localProd, data.action === 'insert' || wasInsert);
                    } catch (postSaveUiErr) {
                        console.warn('Post-save product UI refresh failed', postSaveUiErr);
                    }

                    var stockMsg = "";
                    if(track) stockMsg = "\n📊 مەخزەنێ نوکە: " + sc + " کارتۆن، " + sp + " پاکێت، " + si + " تاک (کۆ: " + totalQty + " دانە)";
                    if (typeof showToast === 'function') showToast("✅ ئایتم هاتە پاراستن!" + stockMsg.replace(/\n/g, "<br>"));
                    else alert("✅ ئایتم هاتە پاراستن!" + stockMsg);
                    if (typeof window.scheduleFirebaseMobilePush === 'function') {
                        window.scheduleFirebaseMobilePush('product', false);
                    }
                    setProductFormTrackStockPref(track);
                    if (typeof rememberUnitNamesFromProductForm === 'function') {
                        rememberUnitNamesFromProductForm(qtyMode === 'kilo');
                    }
                    focusProductBarcodeForBurstEntry();
                    if (window._productEditFromPurchase && typeof window.closePurchaseProductEditModal === 'function') {
                        window.closePurchaseProductEditModal({ saved: true });
                    }
                } else {
                    restoreProductFormSnapshot(formSnap);
                    var errMsg = (data && data.message) ? data.message : "هەڵەی نەناسراو";
                    if (typeof showToast === 'function') showToast("❌ " + errMsg, "error");
                    else alert("❌ " + errMsg);
                    focusProductBarcodeForBurstEntry();
                }
            })
            .catch(function(err) {
                restoreProductFormSnapshot(formSnap);
                var msg = err && err.message ? err.message : "پەیوەندی یان وەڵامێ سێرڤەر هەڵەیە.";
                if (/Failed to fetch|NetworkError|TypeError|abort/i.test(msg)) {
                    msg = (typeof t === 'function')
                        ? t('product_save_network_error')
                        : 'پەیوەندی سست بوو. فۆرم هاتە گەڕاندن — دوگمێ پاراستنێ دوبارە لێدە.';
                }
                if (typeof showToast === 'function') showToast("❌ " + msg, "error");
                else alert("❌ هەڵە د پاراستنێ دا: " + msg);
                focusProductBarcodeForBurstEntry();
            })
            .then(function () {
                setProductSaveInFlight(false);
            });
            } catch (e) {
                setProductSaveInFlight(false);
                var msg = e && e.message ? e.message : String(e);
                alert("هەڵە د پاراستنێ دا: " + msg);
            }
        }

        function clearProductInputs(keepData = false, preserveCategory = false) {
            var idEl = document.getElementById('p-id'); if(idEl) idEl.value = '';
            if(!keepData) {
                var nameEl = document.getElementById('p-name');
                if(nameEl) nameEl.value = '';
                var noNameEl = document.getElementById('p-allow-no-name');
                if (noNameEl) noNameEl.checked = false;
                if (typeof syncProductNameOptionalUi === 'function') syncProductNameOptionalUi();
            }
            var barcodeEl = document.getElementById('p-barcode'); if(barcodeEl) barcodeEl.value = '';
            var skuClear = document.getElementById('p-sku'); if (skuClear) skuClear.value = '';
            if (typeof syncBarcodeToPieceCell === 'function') syncBarcodeToPieceCell();
            var pNoteEl = document.getElementById('p-note');
            if (pNoteEl) pNoteEl.value = '';
            if (typeof clearTechSpecsForm === 'function') clearTechSpecsForm();
            if(document.getElementById('p-multi-barcode')) {
                document.getElementById('p-multi-barcode').checked = false;
                toggleMultiBarcodeUI();
            }
            var suppEl = document.getElementById('p-supplier'); if(suppEl) suppEl.value = '';
            var mfrEl = document.getElementById('p-manufacturer'); if(mfrEl) mfrEl.value = '';
            var priceEl = document.getElementById('p-price'); if(priceEl) priceEl.value = '';
            var tkPriceEl = document.getElementById('p-takeaway-price'); if(tkPriceEl) tkPriceEl.value = '';
            var tkPricePackEl = document.getElementById('p-takeaway-price-pack'); if(tkPricePackEl) tkPricePackEl.value = '';
            var tkPriceCartonEl = document.getElementById('p-takeaway-price-carton'); if(tkPriceCartonEl) tkPriceCartonEl.value = '';
            var costEl = document.getElementById('p-cost'); if(costEl) costEl.value = ''; 
            var wsQtyEl = document.getElementById('p-wholesale-qty'); if(wsQtyEl) wsQtyEl.value = '';
            var wsPriceEl = document.getElementById('p-wholesale-price'); if(wsPriceEl) wsPriceEl.value = '';
            var minStockEl = document.getElementById('p-min-stock'); if(minStockEl) minStockEl.value = '5';
            var expAlertEl = document.getElementById('p-expiry-alert-days'); if(expAlertEl) expAlertEl.value = '30';
            var totalBuyEl = document.getElementById('p-total-buy-cost'); if(totalBuyEl) totalBuyEl.value = ''; 
            if(!keepData && !preserveCategory) { var catEl = document.getElementById('p-cat'); if(catEl) catEl.value = ''; if (typeof updateProductCategoryPillsUI === 'function') updateProductCategoryPillsUI(); }
            var stockCarton = document.getElementById('p-stock-carton');
            var stockPack = document.getElementById('p-stock-pack');
            var stockPiece = document.getElementById('p-stock-piece');
            if(stockCarton) stockCarton.value = '0';
            if(stockPack) stockPack.value = '0';
            if(stockPiece) stockPiece.value = '0';
            var itEl = document.getElementById('p-item-type');
            if(itEl) itEl.value = 'constant';
            var newCartonsEl = document.getElementById('p-new-cartons');
            if(newCartonsEl) newCartonsEl.value = '';
            var newUnitsEl = document.getElementById('p-new-units');
            if(newUnitsEl) newUnitsEl.value = '';
            var pExp = document.getElementById('p-expiry'); if(pExp) pExp.value = '';
            var pExpEn = document.getElementById('p-expiry-enabled'); if (pExpEn) pExpEn.checked = false;
            if (typeof syncProductFormExpiryUi === 'function') syncProductFormExpiryUi();
            var pForSale = document.getElementById('p-for-sale'); if(pForSale) pForSale.checked = true;
            var pSource = document.querySelector('input[name="p-source"][value="direct"]'); if(pSource) pSource.checked = true;
            
            var btnRecipe = document.getElementById('btn-recipe'); if(btnRecipe) btnRecipe.style.display = 'none';
            if (typeof setProductFormQtyMode === 'function') setProductFormQtyMode('piece');
            if (typeof clearJewelryFieldsForm === 'function') clearJewelryFieldsForm();
            if (!keepData) applyProductFormTrackStockPrefForNewItem();
            else toggleStockInputs();
            toggleSupplierInput();
            var stockPreviewEl = document.getElementById('p-total-stock-preview'); if(stockPreviewEl) stockPreviewEl.innerText = "";
            // Multi-level units reset
            if(document.getElementById('p-pieces-per-pack')) document.getElementById('p-pieces-per-pack').value = '1';
            if(document.getElementById('p-pieces-per-carton-only')) document.getElementById('p-pieces-per-carton-only').value = '1';
            if(document.getElementById('p-packs-per-carton')) document.getElementById('p-packs-per-carton').value = '1';
            if (typeof resetLevelBarcodeField === 'function') {
                resetLevelBarcodeField(document.getElementById('p-barcode-pack'));
                resetLevelBarcodeField(document.getElementById('p-barcode-carton'));
            } else {
                if(document.getElementById('p-barcode-pack')) document.getElementById('p-barcode-pack').value = '';
                if(document.getElementById('p-barcode-carton')) document.getElementById('p-barcode-carton').value = '';
            }
            if(document.getElementById('p-cost-pack')) document.getElementById('p-cost-pack').value = '';
            if(document.getElementById('p-cost-carton')) document.getElementById('p-cost-carton').value = '';
            if(document.getElementById('p-price-pack')) document.getElementById('p-price-pack').value = '';
            if(document.getElementById('p-price-carton')) document.getElementById('p-price-carton').value = '';
            if(document.getElementById('p-unit-name-piece')) document.getElementById('p-unit-name-piece').value = '';
            if(document.getElementById('p-unit-name-pack')) document.getElementById('p-unit-name-pack').value = '';
            if(document.getElementById('p-unit-name-carton')) document.getElementById('p-unit-name-carton').value = '';
            if (typeof refreshCustomMeasureUnitsUI === 'function') refreshCustomMeasureUnitsUI();
            if(typeof calcMultiLevelCarton === 'function') calcMultiLevelCarton();
            var us = document.getElementById('p-unit-structure'); if(us) us.value = 'carton_pack_piece';
            var singleEl = document.getElementById('p-pieces-per-carton-single'); if(singleEl) singleEl.value = '';
            var uspClear = document.getElementById('p-unit-show-pack');
            var uscClear = document.getElementById('p-unit-show-carton');
            if (uspClear) uspClear.value = '0';
            if (uscClear) uscClear.value = '0';
            if(typeof setUnitStructure === 'function') setUnitStructure('carton_pack_piece');
            if(typeof productFormGoToStep === 'function') productFormGoToStep(1);
            if (typeof fillWarehouseSelects === 'function') fillWarehouseSelects();
            if (typeof syncJewelryUiVisibility === 'function') {
                try { syncJewelryUiVisibility(); } catch (eJewClear) {}
            }
            if (typeof syncProductStockQtyLockForForm === 'function') syncProductStockQtyLockForForm();
            if (typeof setProductFormCurrency === 'function') {
                if (typeof applyProductFormCurrencyDefaultForNewItem === 'function') applyProductFormCurrencyDefaultForNewItem();
                else {
                    var defCur = (typeof getDefaultCurrency === 'function') ? getDefaultCurrency() : 'IQD';
                    setProductFormCurrency(defCur, true);
                }
            }
        }

        function clearProductFormForNewItem() {
            if (typeof clearProductInputs === 'function') clearProductInputs(false, false);
            var barcode = document.getElementById('p-barcode');
            if (barcode) {
                try {
                    barcode.focus();
                    if (barcode.select) barcode.select();
                } catch (eFocus) {}
            }
            var msg = (typeof T === 'function') ? T('product_form_clear_toast', 'فۆرم هاتە پاککرن — ئایتمێ نوو بنڤیسە') : 'فۆرم هاتە پاککرن — ئایتمێ نوو بنڤیسە';
            if (typeof showToast === 'function') showToast(msg, 'success');
        }

        function editProd(id) {
            const p = db.products.find(x => x.id == id); if (!p) return;
            document.getElementById('p-id').value = p.id;
            document.getElementById('p-name').value = p.name;
            var noNameEdit = document.getElementById('p-allow-no-name');
            if (noNameEdit) {
                // Auto-detect prior "barcode · price" style names as optional-name mode
                var nm = String(p.name || '').trim();
                var bc = String(p.barcode || '').trim();
                noNameEdit.checked = !!(bc && nm && (nm === bc || nm.indexOf(bc + ' · ') === 0));
            }
            if (typeof syncProductNameOptionalUi === 'function') syncProductNameOptionalUi();
            document.getElementById('p-barcode').value = p.barcode || '';
            var skuEdit = document.getElementById('p-sku');
            if (skuEdit) skuEdit.value = (p.sku != null && p.sku !== undefined) ? String(p.sku) : '';
            if (typeof syncBarcodeToPieceCell === 'function') syncBarcodeToPieceCell();
            var pNoteEl = document.getElementById('p-note');
            if (pNoteEl) pNoteEl.value = (p.note != null && p.note !== undefined) ? String(p.note) : '';
            if (typeof fillTechSpecsForm === 'function' && typeof canUseTechSpecs === 'function' && canUseTechSpecs()) {
                var storedSpecs = p.tech_specs;
                var parsedSpecs = (typeof parseTechSpecsFromText === 'function') ? parseTechSpecsFromText(p.name) : null;
                if (storedSpecs && String(storedSpecs).trim() && String(storedSpecs).trim() !== '{}') {
                    fillTechSpecsForm(storedSpecs);
                } else if (parsedSpecs && typeof techSpecsHasContent === 'function' && techSpecsHasContent(parsedSpecs)) {
                    fillTechSpecsForm(parsedSpecs);
                } else if (typeof clearTechSpecsForm === 'function') {
                    clearTechSpecsForm();
                }
            } else if (typeof clearTechSpecsForm === 'function') {
                clearTechSpecsForm();
            }
            if (p.barcode && p.barcode.includes(',')) {
                document.getElementById('p-multi-barcode').checked = true;
            } else {
                document.getElementById('p-multi-barcode').checked = false;
            }
            toggleMultiBarcodeUI();
            
            var srcDir = document.querySelector('input[name="p-source"][value="direct"]');
            var srcCmp = document.querySelector('input[name="p-source"][value="company"]');
            var suppElEdit = document.getElementById('p-supplier');
            if (suppElEdit) {
                var supVal = (p.supplier === 'Direct Store' || !p.supplier) ? '' : String(p.supplier);
                suppElEdit.value = supVal;
            }
            if (srcDir && srcCmp) {
                if(p.supplier === "Direct Store" || !p.supplier) {
                    srcDir.checked = true;
                } else {
                    srcCmp.checked = true;
                }
                toggleSupplierInput();
            }
            var mfrElEdit = document.getElementById('p-manufacturer');
            if (mfrElEdit) mfrElEdit.value = (p.manufacturer != null && p.manufacturer !== undefined) ? String(p.manufacturer) : '';

            if (typeof setProductFormCurrency === 'function') {
                var editCur = (typeof getProductBaseCurrency === 'function') ? getProductBaseCurrency(p) : (p.base_currency || 'IQD');
                setProductFormCurrency(editCur, true);
            }

            document.getElementById('p-price').value = typeof productFormDisplayMoneyInput === 'function' ? productFormDisplayMoneyInput(p, 'price', 'price_usd') : productFormMoneyIqdToInput(p.price);
            var pTkEl = document.getElementById('p-takeaway-price');
            if (pTkEl) pTkEl.value = productFormMoneyOptionalIqdToInput(p.takeawayPrice);
            var pTkPkEl = document.getElementById('p-takeaway-price-pack');
            if (pTkPkEl) pTkPkEl.value = productFormMoneyOptionalIqdToInput(p.takeawayPrice_pack);
            var pTkCtEl = document.getElementById('p-takeaway-price-carton');
            if (pTkCtEl) pTkCtEl.value = productFormMoneyOptionalIqdToInput(p.takeawayPrice_carton);
            document.getElementById('p-wholesale-qty').value = p.wholesaleQty || '';
            document.getElementById('p-wholesale-price').value = productFormMoneyOptionalIqdToInput(p.wholesalePrice);
            document.getElementById('p-cost').value = typeof productFormDisplayMoneyInput === 'function' ? productFormDisplayMoneyInput(p, 'cost', 'cost_usd') : productFormMoneyIqdToInput(p.cost);
            var totalBuyEl = document.getElementById('p-total-buy-cost');
            if (totalBuyEl) {
                var effCost = typeof catalogIqdFromUsdField === 'function' ? catalogIqdFromUsdField(p, 'cost_usd', 'cost') : (parseFloat(p.cost) || 0);
                var totalIqd = effCost * (p.itemsPerCarton || 1);
                totalBuyEl.value = productFormMoneyIqdToInput(totalIqd);
            }
            
            var catVal = (p.cat != null && String(p.cat).trim() !== '') ? p.cat : (p.category || '');
            document.getElementById('p-cat').value = catVal;
            if (typeof updateProductCategoryPillsUI === 'function') updateProductCategoryPillsUI();
            document.getElementById('p-track').checked = p.trackStock;
            var expOn = (typeof isValidProductCatalogExpiry === 'function') && isValidProductCatalogExpiry(p.expiry);
            var expVal = expOn ? String(p.expiry).trim() : '';
            var pExpEn = document.getElementById('p-expiry-enabled');
            if (pExpEn) pExpEn.checked = expOn;
            var pExpInp = document.getElementById('p-expiry');
            if (pExpInp) pExpInp.value = expOn ? expVal : '';
            if (typeof syncProductFormExpiryUi === 'function') syncProductFormExpiryUi();
            var pMinS = document.getElementById('p-min-stock'); if (pMinS) pMinS.value = (p.minStock !== undefined && p.minStock !== null && p.minStock !== '') ? p.minStock : 5;
            var pExpDays = document.getElementById('p-expiry-alert-days'); if (pExpDays) pExpDays.value = (p.expiry_alert_days !== undefined && p.expiry_alert_days !== null && p.expiry_alert_days !== '') ? p.expiry_alert_days : 30;
            document.getElementById('p-for-sale').checked = isProductForSale(p);
            if (typeof setProductFormQtyMode === 'function') setProductFormQtyMode(getProductQtyMode(p));
            if (typeof fillJewelryFieldsToForm === 'function') fillJewelryFieldsToForm(p);
            var itEl = document.getElementById('p-item-type');
            if(itEl) itEl.value = (p.item_type === 'perishable' ? 'perishable' : 'constant');
            if((typeof isRecipeFeatureEnabled === 'function' ? isRecipeFeatureEnabled() : db.settings.enableRecipe === true) && document.getElementById('btn-recipe')) document.getElementById('btn-recipe').style.display = 'block';
            // Multi-level units
            var pppEl = document.getElementById('p-pieces-per-pack');
            var ppcEl = document.getElementById('p-packs-per-carton');
            if(pppEl) pppEl.value = (p.pieces_per_pack != null && p.pieces_per_pack >= 1) ? p.pieces_per_pack : 1;
            if(ppcEl) ppcEl.value = (p.packs_per_carton != null && p.packs_per_carton >= 1) ? p.packs_per_carton : 1;
            if(document.getElementById('p-barcode-pack')) document.getElementById('p-barcode-pack').value = p.barcode_pack || '';
            if(document.getElementById('p-barcode-carton')) document.getElementById('p-barcode-carton').value = p.barcode_carton || '';
            if (typeof hydrateInheritedLevelBarcodes === 'function') hydrateInheritedLevelBarcodes();
            if(document.getElementById('p-cost-pack')) document.getElementById('p-cost-pack').value = (p.cost_pack != null && p.cost_pack !== '') ? (typeof productFormDisplayMoneyInput === 'function' ? productFormDisplayMoneyInput(p, 'cost_pack', 'cost_pack_usd') : productFormMoneyIqdToInput(p.cost_pack)) : '';
            if(document.getElementById('p-cost-carton')) document.getElementById('p-cost-carton').value = (p.cost_carton != null && p.cost_carton !== '') ? (typeof productFormDisplayMoneyInput === 'function' ? productFormDisplayMoneyInput(p, 'cost_carton', 'cost_carton_usd') : productFormMoneyIqdToInput(p.cost_carton)) : '';
            if(document.getElementById('p-price-pack')) document.getElementById('p-price-pack').value = (p.price_pack != null && p.price_pack !== '') ? (typeof productFormDisplayMoneyInput === 'function' ? productFormDisplayMoneyInput(p, 'price_pack', 'price_pack_usd') : productFormMoneyIqdToInput(p.price_pack)) : '';
            if(document.getElementById('p-price-carton')) document.getElementById('p-price-carton').value = (p.price_carton != null && p.price_carton !== '') ? (typeof productFormDisplayMoneyInput === 'function' ? productFormDisplayMoneyInput(p, 'price_carton', 'price_carton_usd') : productFormMoneyIqdToInput(p.price_carton)) : '';
            if(document.getElementById('p-unit-name-piece')) document.getElementById('p-unit-name-piece').value = p.unit_name_piece || '';
            if(document.getElementById('p-unit-name-pack')) document.getElementById('p-unit-name-pack').value = p.unit_name_pack || '';
            if(document.getElementById('p-unit-name-carton')) document.getElementById('p-unit-name-carton').value = p.unit_name_carton || '';
            if (typeof refreshCustomMeasureUnitsUI === 'function') refreshCustomMeasureUnitsUI();
            if(typeof calcMultiLevelCarton === 'function') calcMultiLevelCarton();
            var uspEl = document.getElementById('p-unit-show-pack');
            var uscEl = document.getElementById('p-unit-show-carton');
            if (uspEl) {
                if (p.unit_show_pack !== undefined && p.unit_show_pack !== null) {
                    uspEl.value = parseInt(p.unit_show_pack, 10) === 1 ? '1' : '0';
                } else {
                    var inferPack = (p.barcode_pack && String(p.barcode_pack).trim()) || (p.price_pack != null && p.price_pack !== '' && Number(p.price_pack) > 0) || (p.cost_pack != null && p.cost_pack !== '' && Number(p.cost_pack) > 0);
                    uspEl.value = inferPack ? '1' : '0';
                }
            }
            if (uscEl) {
                if (p.unit_show_carton !== undefined && p.unit_show_carton !== null) {
                    uscEl.value = parseInt(p.unit_show_carton, 10) === 1 ? '1' : '0';
                } else {
                    var inferCarton = (p.barcode_carton && String(p.barcode_carton).trim()) || (p.price_carton != null && p.price_carton !== '' && Number(p.price_carton) > 0) || (p.cost_carton != null && p.cost_carton !== '' && Number(p.cost_carton) > 0);
                    uscEl.value = inferCarton ? '1' : '0';
                }
            }
            var showPackL = uspEl && uspEl.value === '1';
            var showCartonL = uscEl && uscEl.value === '1';
            var ppo = document.getElementById('p-pieces-per-carton-only');
            if (ppo) {
                if (!showPackL && showCartonL) {
                    var ipc = (p.pieces_per_pack != null && p.pieces_per_pack >= 1) ? p.pieces_per_pack : 1;
                    ppo.value = String(ipc);
                } else {
                    ppo.value = '1';
                }
            }
            if (typeof applyProductUnitLevelUI === 'function') applyProductUnitLevelUI();
            // Call toggleStockInputs to reflect the loaded product's trackStock status
            toggleStockInputs();

            if (typeof fillWarehouseSelects === 'function') fillWarehouseSelects();
            if(p.trackStock) {
                var whSel = document.getElementById('p-warehouse-select');
                var whId = whSel && whSel.value ? parseInt(whSel.value, 10) : (typeof getDefaultWarehouseId === 'function' ? getDefaultWarehouseId() : 0);
                var totalPieces = typeof getProductQtyForWarehouse === 'function' ? getProductQtyForWarehouse(p, whId) : (parseFloat(p.qty) || 0);
                applyProductFormStockFromQty(p, totalPieces);
            } else {
                var elC = document.getElementById('p-stock-carton');
                var elP = document.getElementById('p-stock-pack');
                var elI = document.getElementById('p-stock-piece');
                if(elC) elC.value = '0';
                if(elP) elP.value = '0';
                if(elI) elI.value = '0';
            }
            updateUnitLabels(); // Update labels based on loaded type
            if (typeof refreshCustomMeasureUnitsUI === 'function') refreshCustomMeasureUnitsUI();
            if(typeof calcTotalStockFromTable === 'function') calcTotalStockFromTable();
            if (typeof syncJewelryMoneyToSimple === 'function') syncJewelryMoneyToSimple();
            if(typeof setUnitStructure === 'function') setUnitStructure('carton_pack_piece');
            if (typeof updateProductFormFxHints === 'function') updateProductFormFxHints();
            if(typeof productFormGoToStep === 'function') productFormGoToStep(1);
            if (typeof syncJewelryUiVisibility === 'function') {
                try { syncJewelryUiVisibility(); } catch (eJewEdit) {}
            }
            if (typeof syncProductStockQtyLockForForm === 'function') syncProductStockQtyLockForForm();
            if (!window._productEditFromPurchase) {
                var _pfc = document.getElementById('product-form-card');
                if (_pfc) _pfc.scrollIntoView({ behavior: 'smooth' });
            }
        }
        window.editProd = editProd;

        function rememberProductFormHome() {
            var formCard = document.getElementById('product-form-card');
            if (!formCard || window._productFormHome) return;
            window._productFormHome = {
                parent: formCard.parentNode,
                next: formCard.nextElementSibling
            };
        }

        function restoreProductFormHome() {
            var formCard = document.getElementById('product-form-card');
            var home = window._productFormHome;
            if (!formCard || !home || !home.parent) return;
            home.parent.insertBefore(formCard, home.next);
        }

        window.editProdFromPurchase = function editProdFromPurchase(id) {
            try {
                if (window._editProdFromPurchaseLock && (Date.now() - window._editProdFromPurchaseLock) < 250) return;
                window._editProdFromPurchaseLock = Date.now();
                if (typeof hasPermission === 'function' && !hasPermission('products_manage')) {
                    if (typeof showToast === 'function') showToast('تۆ دەستوورا دەستکاریا ئایتمێ نینە', 'error');
                    return;
                }
                var formCard = document.getElementById('product-form-card');
                var mount = document.getElementById('purchase-product-edit-mount');
                var modal = document.getElementById('purchase-product-edit-modal');
                var fillFn = (typeof window.editProd === 'function') ? window.editProd : editProd;
                if (!formCard || !mount || !modal) {
                    if (typeof nav === 'function') nav('products');
                    setTimeout(function() { if (typeof fillFn === 'function') fillFn(id); }, 150);
                    return;
                }
                rememberProductFormHome();
                if (formCard.parentNode !== mount) mount.appendChild(formCard);
                window._productEditFromPurchase = true;
                modal.style.display = 'flex';
                modal.style.zIndex = '50000';
                document.body.classList.add('purchase-product-edit-open');
                if (typeof fillFn === 'function') fillFn(id);
                var body = modal.querySelector('.purchase-product-edit-body');
                if (body) body.scrollTop = 0;
            } catch (err) {
                if (typeof showToast === 'function') showToast('تەعدیلی ئایتم سەرنەکەوت', 'error');
                try { console.error(err); } catch (_e) {}
            }
        };

        window.closePurchaseProductEditModal = function closePurchaseProductEditModal(opts) {
            opts = opts || {};
            var modal = document.getElementById('purchase-product-edit-modal');
            if (!opts.saved && typeof clearProductInputs === 'function') {
                clearProductInputs(false, true);
            }
            restoreProductFormHome();
            window._productEditFromPurchase = false;
            if (modal) modal.style.display = 'none';
            document.body.classList.remove('purchase-product-edit-open');
            if (typeof renderPurchaseProductGrid === 'function') renderPurchaseProductGrid();
            if (typeof renderPurchaseCart === 'function') renderPurchaseCart();
        };

        // --- RECIPE MANAGEMENT ---
        window.toggleRecipeSettings = function toggleRecipeSettings() {
            const el = document.getElementById('set-enable-recipe');
            const enabled = !!(el && el.checked);
            if (db && db.settings) db.settings.enableRecipe = enabled;
            if (typeof persistSystemFeaturesToStorage === 'function') persistSystemFeaturesToStorage();
            if (enabled && typeof setMainNavItemVisible === 'function') setMainNavItemVisible('recipes', true);
            if (typeof applyFeatureVisibility === 'function') applyFeatureVisibility();
            const btn = document.getElementById('btn-recipe');
            const navItem = document.getElementById('nav-recipes');
            
            const allowed = hasPermission('recipes_manage');
            if(navItem) navItem.style.display = (enabled && allowed) ? 'flex' : 'none';

            if(btn) {
                if(!enabled) btn.style.display = 'none';
                else if(document.getElementById('p-id').value) btn.style.display = 'block';
            }
            if (typeof saveSettings === 'function') saveSettings().catch(function () {});
        }

        window.toggleWholesaleSettings = function toggleWholesaleSettings() {
            var el = document.getElementById('set-enable-wholesale');
            if (el && db && db.settings) db.settings.enableWholesale = el.checked;
            if (typeof applyProductFormPremiumFeatureFields === 'function') applyProductFormPremiumFeatureFields();
        }

        function openRecipeModal(id = null) {
            const pid = id || document.getElementById('p-id').value;
            if(!pid) return;
            document.getElementById('recipe-modal-pid').value = pid;
            const p = db.products.find(x => x.id == pid);
            document.getElementById('recipe-prod-name').innerText = p.name;
            document.getElementById('recipe-modal').style.display = 'flex';
            
            // Populate Datalist for Search
            const datalist = document.getElementById('recipe-datalist');
            datalist.innerHTML = '';
            db.products.filter(p => p.trackStock).sort((a,b) => a.name.localeCompare(b.name)).forEach(p => {
                const opt = document.createElement('option');
                opt.value = p.name;
                datalist.appendChild(opt);
            });

            const container = document.getElementById('recipe-ingredients-list');
            container.innerHTML = '';
            
            const recipes = db.recipes.filter(r => r.product_id == pid);
            if(recipes.length > 0) {
                recipes.forEach(r => addRecipeRow(r.ingredient_id, r.qty));
            } else {
                addRecipeRow(); // Add one empty row
            }
            calcRecipeTotal();
            syncRecipeSaleModePanel(p);
            updateRecipeProducePanel();
        }

        function syncRecipeSaleModePanel(prod) {
            var panel = document.getElementById('recipe-sale-mode-panel');
            if (!panel) return;
            var mode = (prod && prod.recipe_sale_mode) ? String(prod.recipe_sale_mode) : 'auto';
            if (typeof normalizeRecipeSaleMode === 'function') mode = normalizeRecipeSaleMode(mode);
            panel.querySelectorAll('input[name="recipe-sale-mode"]').forEach(function(el) {
                el.checked = (el.value === mode);
            });
        }

        function getRecipeSaleModeFromPanel() {
            var checked = document.querySelector('#recipe-sale-mode-panel input[name="recipe-sale-mode"]:checked');
            var mode = checked ? checked.value : 'auto';
            return typeof normalizeRecipeSaleMode === 'function' ? normalizeRecipeSaleMode(mode) : mode;
        }

        function updateRecipeProducePanel() {
            var panel = document.getElementById('recipe-produce-panel');
            var modePanel = document.getElementById('recipe-sale-mode-panel');
            if (!panel) return;
            var pid = document.getElementById('recipe-modal-pid') && document.getElementById('recipe-modal-pid').value;
            var p = pid && db && db.products ? db.products.find(function(x) { return String(x.id) === String(pid); }) : null;
            var hasSavedRecipe = pid && db && db.recipes && db.recipes.some(function(r) { return String(r.product_id) === String(pid); });
            var trackOn = p && (p.trackStock === true || p.trackStock === 1 || p.trackStock === '1');
            panel.style.display = (hasSavedRecipe && trackOn) ? 'block' : 'none';
            if (modePanel) modePanel.style.display = hasSavedRecipe ? 'block' : 'none';
        }

        window.produceRecipeBatch = function produceRecipeBatch() {
            var pid = document.getElementById('recipe-modal-pid') && document.getElementById('recipe-modal-pid').value;
            var qtyEl = document.getElementById('recipe-produce-qty');
            var qty = qtyEl ? parseFloat(qtyEl.value) : 1;
            if (!pid) return;
            if (!qty || qty <= 0) { alert('⚠️ ژمارەکا دروست بنووسە'); return; }
            var p = db.products.find(function(x) { return String(x.id) === String(pid); });
            if (!p) return;
            if (!(p.trackStock === true || p.trackStock === 1 || p.trackStock === '1')) {
                alert('⚠️ بۆ دروستکرنێ، ل ئایتمی بەرهەمێ «حیسابا کۆگەهی» چالاک بکە.');
                return;
            }
            var hasRecipe = db.recipes && db.recipes.some(function(r) { return String(r.product_id) === String(pid); });
            if (!hasRecipe) {
                alert('⚠️ پێش دروستکرنێ ڕەچەتە پاراستن بکە.');
                return;
            }
            if (!confirm('دروستکرنا «' + p.name + '» x' + qty + '؟\nکەرەستە دکەمێت، بەرهەما ئامادە د کۆگەهێ زیاد دبیت.')) return;

            var formData = new FormData();
            formData.append('action', 'produce_recipe');
            formData.append('product_id', pid);
            formData.append('qty', String(qty));
            if (currentUser && currentUser.name) formData.append('user', currentUser.name);

            apiJson('?action=produce_recipe', { method: 'POST', body: formData, credentials: 'same-origin' })
            .then(function(data) {
                if (!data || data.status !== 'success') {
                    var msg = (data && data.message) ? data.message : 'produce_failed';
                    if (msg.indexOf('stock_not_enough:') === 0) {
                        alert('❌ کەرەستە تێر نین: ' + msg.split(':').slice(1).join(':').trim());
                    } else if (msg === 'no_recipe_defined') {
                        alert('❌ ڕەچەتە نەهاتە دیارکرن.');
                    } else if (msg === 'product_must_track_stock') {
                        alert('❌ حیسابا کۆگەهی چالاک بکە.');
                    } else {
                        alert('❌ هەڵە: ' + msg);
                    }
                    return;
                }
                if (typeof showToast === 'function') {
                    showToast('✅ ' + (data.product_name || p.name) + ' x' + data.produced + ' هاتە دروستکرن');
                } else {
                    alert('✅ ' + (data.product_name || p.name) + ' x' + data.produced + ' هاتە دروستکرن');
                }
                if (typeof connectToDB === 'function') connectToDB(true);
            })
            .catch(function(e) {
                alert('❌ هەڵە: ' + (e && e.message ? e.message : 'Unknown error'));
            });
        };

        function addRecipeRow(ingId = '', qty = '') {
            const container = document.getElementById('recipe-ingredients-list');
            const div = document.createElement('div');
            div.className = 'ing-row';
            
            // Find product name if ID is provided
            let ingName = '';
            if(ingId) {
                const p = db.products.find(x => x.id == ingId);
                if(p) ingName = p.name;
            }

            div.innerHTML = `
                <input type="text" class="input-std recipe-ing-name" list="recipe-datalist" placeholder="کەرەستە (Search)..." value="${escapeHtml(ingName)}" style="margin:0; flex:2;" onchange="calcRecipeTotal()">
                <input type="number" class="input-std recipe-ing-qty" placeholder="بڕ (Qty)" value="${qty}" style="margin:0; flex:1;" oninput="calcRecipeTotal()">
                <button class="btn btn-danger btn-sm" onclick="this.parentElement.remove(); calcRecipeTotal();"><i class="fas fa-trash"></i></button>
            `;
            container.appendChild(div);
        }

        function calcRecipeTotal() {
            let total = 0;
            document.querySelectorAll('.ing-row').forEach(row => {
                const name = row.querySelector('.recipe-ing-name').value;
                const qty = parseFloat(row.querySelector('.recipe-ing-qty').value) || 0;
                const p = db.products.find(x => x.name === name);
                if(p) total += (p.cost * qty);
            });
            document.getElementById('recipe-total-cost').innerText = formatCurrency(total) + " " + getCurrencySymbol();
            updateRecipeProducePanel();
        }

        function saveRecipe() {
            const pid = document.getElementById('recipe-modal-pid').value;
            const rows = document.querySelectorAll('.ing-row');
            const ingredients = [];
            
            for(let row of rows) {
                const name = row.querySelector('.recipe-ing-name').value;
                const qty = row.querySelector('.recipe-ing-qty').value;
                const p = db.products.find(x => x.name === name);
                
                if(p && qty > 0) {
                    ingredients.push({ id: p.id, qty: qty });
                } else if (name && !p) {
                    alert(`⚠️ کەرەستە نەهاتە دیتن: ${name}`);
                    return;
                }
            }

            const formData = new FormData();
            formData.append('action', 'save_recipe');
            formData.append('product_id', pid);
            formData.append('ingredients', JSON.stringify(ingredients));
            formData.append('recipe_sale_mode', getRecipeSaleModeFromPanel());

            apiJson('?action=save_recipe', { method: 'POST', body: formData, credentials: 'same-origin' })
            .then(function (data) {
                if (!data || data.status !== 'success') {
                    throw new Error((data && data.message) ? data.message : 'Save recipe failed');
                }
                var savedMode = (data && data.recipe_sale_mode) ? data.recipe_sale_mode : getRecipeSaleModeFromPanel();
                // Keep local state in sync immediately so delete/add is visible without refresh.
                db.recipes = (db.recipes || []).filter(function (r) { return String(r.product_id) !== String(pid); });
                ingredients.forEach(function (ing) {
                    db.recipes.push({ product_id: Number(pid), ingredient_id: Number(ing.id), qty: parseFloat(ing.qty) || 0 });
                });
                var prodLocal = db.products.find(function(x) { return String(x.id) === String(pid); });
                if (prodLocal) prodLocal.recipe_sale_mode = savedMode;
                if (typeof renderRecipeManager === 'function') renderRecipeManager();
                updateRecipeProducePanel();
                alert("✅ ڕەسەپی هاتە پاراستن!");
                document.getElementById('recipe-modal').style.display = 'none';
                // Sync full state in background (for multi-user/live consistency)
                if (typeof connectToDB === 'function') connectToDB(true);
            })
            .catch(function (e) {
                alert("❌ هەڵە د پاراستنێ دا: " + (e && e.message ? e.message : 'Unknown error'));
            });
        }

        function renderRecipeManager(q = '') {
            const container = document.getElementById('recipe-manager-grid');
            const lowerQ = q.toLowerCase().trim();
            
            const list = db.products.filter(p => p.name.toLowerCase().includes(lowerQ));
            
            container.innerHTML = list.map(p => {
                const recipeCount = db.recipes.filter(r => r.product_id == p.id).length;
                const hasRecipe = recipeCount > 0;
                const trackOn = p.trackStock === true || p.trackStock === 1 || p.trackStock === '1';
                const stockQty = (p.qty != null) ? p.qty : 0;
                var modeLbl = '';
                if (hasRecipe && typeof getRecipeSaleModeLabel === 'function') {
                    modeLbl = ' · ' + getRecipeSaleModeLabel(p.recipe_sale_mode || 'auto');
                }
                    
                return `
                <div class="recipe-card ${hasRecipe ? 'has-recipe' : 'no-recipe'}">
                    <div onclick="openRecipeModal(${p.id})" style="cursor:pointer; flex:1;">
                        <i class="fas ${hasRecipe ? 'fa-check-circle' : 'fa-plus-circle'}"></i>
                        <h3>${escapeHtml(p.name || 'ئایتم')}</h3>
                        <p>${hasRecipe ? recipeCount + ' کەرەستە · کۆگە: ' + stockQty + modeLbl : 'چ ڕەسەپی نینن'}</p>
                    </div>
                    ${hasRecipe && trackOn ? `<button type="button" class="btn btn-success btn-sm" style="margin-top:8px; width:100%;" onclick="event.stopPropagation(); openRecipeModal(${p.id}); setTimeout(function(){ var q=document.getElementById('recipe-produce-qty'); if(q) q.focus(); }, 200);"><i class="fas fa-hammer"></i> دروستکرن</button>` : ''}
                </div>`;
            }).join('');
        }

        // --- DYNAMIC MULTI-BARCODE UI ---
        function toggleMultiBarcodeUI() {
            var mb = document.getElementById('p-multi-barcode');
            var isMulti = mb && mb.checked;
            var mainInput = document.getElementById('p-barcode');
            var list = document.getElementById('dynamic-barcode-list');
            var addBtn = document.getElementById('btn-add-barcode');
            if (!mainInput) return;
            if (isMulti && list) {
                mainInput.style.display = 'none';
                list.style.display = 'flex';
                if (addBtn) addBtn.style.display = 'block';
                list.innerHTML = '';
                var currentVal = mainInput.value.trim();
                var codes = currentVal ? currentVal.split(',').map(function(c){ return c.trim(); }) : [''];
                if (codes.length === 0) codes.push('');
                codes.forEach(function(code){ addDynamicBarcodeField(code); });
            } else {
                mainInput.style.display = '';
                if (list) list.style.display = 'none';
                if (addBtn) addBtn.style.display = 'none';
                mainInput.focus();
            }
        }

        function addDynamicBarcodeField(val) {
            val = val || '';
            var list = document.getElementById('dynamic-barcode-list');
            if (!list) return;
            var div = document.createElement('div');
            div.style.display = 'flex'; div.style.gap = '5px';
            div.innerHTML = `<input type="text" class="input-std dynamic-barcode-input" value="${val}" placeholder="Scan Barcode..." style="margin:0; flex:1;" oninput="syncToMainBarcode()" onkeydown="handleDynamicBarcodeEnter(event)">
                <button class="btn btn-danger btn-sm" onclick="this.parentElement.remove(); syncToMainBarcode();"><i class="fas fa-trash"></i></button>`;
            list.appendChild(div);
            setTimeout(() => { const inputs = list.querySelectorAll('input'); inputs[inputs.length - 1].focus(); }, 50);
        }

        function syncToMainBarcode() {
            const inputs = document.querySelectorAll('.dynamic-barcode-input');
            const values = Array.from(inputs).map(i => i.value.trim()).filter(v => v !== '');
            document.getElementById('p-barcode').value = values.join(', ');
        }

        function handleDynamicBarcodeEnter(e) {
            if(e.key === 'Enter') { e.preventDefault(); if(e.target.value.trim()) addDynamicBarcodeField(); else document.getElementById('p-name').focus(); }
        }

        function toggleProductPin(id, val) {
            const formData = new FormData();
            formData.append('action', 'toggle_product_pin');
            formData.append('id', id);
            formData.append('val', val);
            
            fetch('?action=toggle_product_pin', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                if(data.status === 'success') {
                    const p = db.products.find(x => x.id == id);
                    if(p) p.isPinned = (val === 1);
                    
                    const prodSearch = document.getElementById('products-search-input');
                    renderProducts(prodSearch ? prodSearch.value : '');
                    
                    const posSearch = document.getElementById('pos-barcode-input');
                    renderPOSMenu(posSearch ? posSearch.value : '');
                    
                    showToast(val ? "✅ ئایتم هاتە پینکرن (Pinned)" : "❌ پین هاتە لادان (Unpinned)");
                }
            });
        }

        function deleteProd(id) { 
            const isActive = (db.tables || []).some(t => t && Array.isArray(t.items) && t.items.some(i => i && i.id === id));
            if (isActive) return alert("⛔ نەشێی ڤی ئایتمی ژێ ببەی! نوکە ل سەر " + (typeof getTablesLabelShort === 'function' ? getTablesLabelShort() + 'ەکێ' : 'مێزەکێ') + " یێ هاتیە داواکرن.");
            if(confirm('ئەرێ دڵنیای ژ ژێبرنا ڤی ئایتمی؟')) { 
                const formData = new FormData();
                formData.append('action', 'delete_product');
                formData.append('id', id);
                formData.append('user', currentUser ? currentUser.name : 'System');
                fetch('?action=delete_product', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if(data.status === 'success') {
                        db.products = db.products.filter(p => p.id != id);
                        if (typeof invalidateWmsWarehouseCache === 'function') invalidateWmsWarehouseCache();
                        if (typeof updateCurrencyLockUI === 'function') updateCurrencyLockUI();
                        const searchVal = (document.getElementById('products-search-input') && document.getElementById('products-search-input').value) || '';
                        renderProducts(searchVal);
                        if (typeof renderPOSMenu === 'function') renderPOSMenu(document.getElementById('pos-barcode-input') ? document.getElementById('pos-barcode-input').value : '');
                        showToast('✅ ئایتم ژێبرا', 'success');
                    } else if(data.message && (data.reason === 'has_purchases' || data.reason === 'has_stock' || /کڕین|لڤین|مێژوو|کۆگە/.test(String(data.message || '')))) {
                        alert(data.message + '\n\nبۆ شاردنەوە لە فرۆشتن: ئایتم دەستکاری بکە و «پیشاندان لە فرۆتن» ناکارا بکە — ناچالاککردن (ژێبرن) مەکە چونکە لە کۆگە و فرۆشتن ون دەبێت.');
                    } else if(data.message && confirm(data.message + '\n\nئەرێ تە دڤێت ژ کار بێخی ل شوینا ژێبرنێ؟')) {
                        const fd = new FormData();
                        fd.append('action', 'void_product');
                        fd.append('id', id);
                        fd.append('user', currentUser ? currentUser.name : 'System');
                        fetch('?action=void_product', { method: 'POST', body: fd }).then(r => r.json()).then(d => {
                            if(d.status === 'success') connectToDB(true);
                            else if (d.message) {
                                if (typeof showToast === 'function') showToast(d.message, 'error');
                                else alert(d.message);
                            }
                        });
                    } else if(data.message) showToast(data.message, 'error');
                });
            }
        }


        function renderProducts(searchQ) {
            if (arguments.length === 0) {
                searchQ = getProductsListSearchQuery();
            }
            const container = document.getElementById('product-list-container');
            if (!container) return;

            var catalog = (db && Array.isArray(db.products))
                ? db.products.filter(function (p) { return p && p.id != null; })
                : [];
            if (!catalog.length && typeof posEnsureCatalogLoaded === 'function' && !window.__productsListCatalogRetry) {
                window.__productsListCatalogRetry = true;
                var loadMsg = (typeof t === 'function' && t('products_loading_catalog') !== 'products_loading_catalog')
                    ? t('products_loading_catalog')
                    : 'بارکرنا لیستا ئایتمان...';
                container.innerHTML = '<div style="padding:20px;margin-top:10px;text-align:center;color:var(--text-secondary);"><i class="fas fa-spinner fa-spin"></i> ' + escapeHtml(loadMsg) + '</div>';
                return posEnsureCatalogLoaded({ allowPartial: true }).then(function () {
                    window.__productsListCatalogRetry = false;
                    renderProducts(searchQ);
                }).catch(function () {
                    window.__productsListCatalogRetry = false;
                    renderProducts(searchQ);
                });
            }

            const mfrSelect = document.getElementById('p-manufacturer');
            if (typeof refreshProductManufacturerSelect === 'function') {
                var keepMfr = mfrSelect ? mfrSelect.value : '';
                refreshProductManufacturerSelect(keepMfr || undefined);
            } else if (mfrSelect) {
                function fillProductManufacturerSelect(el, phKey, kuFallback) {
                    if (!el) return;
                    var phOpt = (typeof t === 'function' && t(phKey) !== phKey) ? t(phKey) : (kuFallback || 'هەلبژێرە...');
                    el.innerHTML = '<option value="">' + escapeHtml(phOpt) + '</option>';
                    (db.manufacturers || []).forEach(function(m) {
                        if (!m || !m.name) return;
                        el.innerHTML += '<option value="' + escapeHtml(m.name) + '">' + escapeHtml(m.name) + '</option>';
                    });
                }
                fillProductManufacturerSelect(mfrSelect, 'product_form_manufacturer_placeholder', 'هەلبژێرە...');
            }
            
            const raw = String(searchQ == null ? '' : searchQ).trim();
            if (window._productsAdminListLastQuery !== raw) {
                window._productsAdminListLastQuery = raw;
                window._productsAdminListPage = 1;
            }

            const filteredProducts = catalog.filter(function(p) {
                var curSel = document.getElementById('products-filter-currency');
                var curVal = curSel ? String(curSel.value || '').toUpperCase() : '';
                if (curVal === 'USD' || curVal === 'IQD') {
                    var pc = (typeof getProductBaseCurrency === 'function')
                        ? getProductBaseCurrency(p)
                        : String((p && (p.base_currency || p.currency)) || '').toUpperCase();
                    if (pc !== curVal) return false;
                }
                if (!raw) return true;
                if (typeof window.productMatchesBarcodeOrNameSearch === 'function' && window.productMatchesBarcodeOrNameSearch(p, raw)) return true;
                var lq = raw.toLowerCase();
                if (p.cat && String(p.cat).toLowerCase().indexOf(lq) !== -1) return true;
                if (p.category && String(p.category).toLowerCase().indexOf(lq) !== -1) return true;
                if (p.supplier && String(p.supplier).toLowerCase().indexOf(lq) !== -1) return true;
                if (p.manufacturer && String(p.manufacturer).toLowerCase().indexOf(lq) !== -1) return true;
                return false;
            }).sort((a, b) => b.id - a.id); // FIX: Sort by ID DESC (Newest First)

            // Update Total Count
            const countEl = document.getElementById('total-products-count');
            if (countEl) {
                var catalogTotal = (typeof posCatalogTotal === 'function') ? posCatalogTotal() : catalog.length;
                if (catalogTotal < catalog.length) catalogTotal = catalog.length;
                var curSelCount = document.getElementById('products-filter-currency');
                var curFiltered = !!(curSelCount && String(curSelCount.value || '').trim());
                countEl.innerText = ((raw || curFiltered) && filteredProducts.length !== catalog.length)
                    ? (String(filteredProducts.length) + ' / ' + catalogTotal)
                    : String(catalogTotal);
            }

            var pageSize = 50;
            var totalFiltered = filteredProducts.length;
            var maxPage = totalFiltered === 0 ? 1 : Math.max(1, Math.ceil(totalFiltered / pageSize));
            var page = parseInt(window._productsAdminListPage, 10) || 1;
            if (page > maxPage) page = maxPage;
            if (page < 1) page = 1;
            window._productsAdminListPage = page;

            function T(k, kuFallback) {
                if (typeof t !== 'function') return kuFallback || '';
                var v = t(k);
                return (v && String(v).trim()) ? v : (kuFallback || '');
            }

            if (totalFiltered === 0) {
                var emptyMsg;
                if (raw) {
                    emptyMsg = T('products_empty_search', 'هیچ ئایتمێک نەهاتە دیتن بۆ «{q}».').replace(/\{q\}/g, raw);
                } else {
                    emptyMsg = T('products_empty_catalog', 'هیچ ئایتمان تۆمار نەکرین.');
                }
                container.innerHTML = `<div style="padding:20px;margin-top:10px;text-align:center;color:var(--text-secondary);border:1px solid var(--border);border-radius:12px;">${raw ? (escapeHtml(T('products_empty_search', 'هیچ ئایتمێک نەهاتە دیتن بۆ «{q}».').replace(/\{q\}/g, raw)) + ' <button type="button" class="btn btn-sm btn-dark" style="margin-top:10px;" onclick="var el=document.getElementById(\'products-search-input\');if(el){el.value=\'\';}if(typeof renderProducts===\'function\')renderProducts(\'\');">' + escapeHtml(T('products_clear_search', 'پاککردنا لێگەریان')) + '</button>') : escapeHtml(emptyMsg)}</div>`;
                return;
            }

            var startIdx = (page - 1) * pageSize;
            var renderList = filteredProducts.slice(startIdx, startIdx + pageSize);
            var showFrom = startIdx + 1;
            var showTo = startIdx + renderList.length;
            var prevDisabled = page <= 1 ? ' disabled' : '';
            var nextDisabled = page >= maxPage ? ' disabled' : '';
            var thItem = T('products_tbl_item', 'ئایتم');
            var thBc = T('products_tbl_barcode', 'بارکۆد');
            var thCat = T('products_tbl_category', 'پۆل');
            var thCost = T('products_tbl_cost', 'کرین (تاک)');
            var thPrice = T('products_tbl_price', 'نرخ');
            var thStock = T('products_tbl_stock', 'کۆگەه');
            var thPos = T('products_tbl_pos', 'فرۆتن');
            var thAct = T('products_tbl_actions', 'کردار');
            var posY = T('products_pos_yes', 'بەڵێ');
            var posN = T('products_pos_no', 'نەخێر');
            var pgLine = T('products_pager_results', 'ئەنجام') + ': ' + totalFiltered + ' — ' + T('products_pager_showing', 'نیشاندان') + ': ' + showFrom + '–' + showTo + ' — ' + T('products_pager_page', 'پەڕە') + ' ' + page + ' ' + T('products_pager_of', 'لە') + ' ' + maxPage;
            var btnPrev = T('products_pager_prev', 'پێشوو');
            var btnNext = T('products_pager_next', 'دواتر');
            var pagerBar = `
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin:10px 0;padding:10px 12px;background:var(--card);border:1px solid var(--border);border-radius:12px;">
                    <span style="font-size:0.9rem;color:var(--text);">${escapeHtml(pgLine)}</span>
                    <div style="display:flex;gap:8px;">
                        <button type="button" class="btn btn-sm btn-dark"${prevDisabled} onclick="if(!this.disabled){window._productsAdminListPage=${page - 1};renderProducts((document.getElementById('products-search-input')&&document.getElementById('products-search-input').value)||'');}">${escapeHtml(btnPrev)}</button>
                        <button type="button" class="btn btn-sm btn-dark"${nextDisabled} onclick="if(!this.disabled){window._productsAdminListPage=${page + 1};renderProducts((document.getElementById('products-search-input')&&document.getElementById('products-search-input').value)||'');}">${escapeHtml(btnNext)}</button>
                    </div>
                </div>`;

            var rowsHtml = '';
            try {
                rowsHtml = renderList.map(function (p) { return safeProductListRowHtml(p, posY, posN); }).join('');
            } catch (rowsErr) {
                console.error('renderProducts rows failed', rowsErr);
            }
            if (!rowsHtml && renderList.length) {
                rowsHtml = '<tr><td colspan="8" style="text-align:center;color:var(--danger);padding:16px;">هەڵە د نیشاندana لیستێ دا. F5 بکە.</td></tr>';
            }

            try {
                container.innerHTML =
                    '<div class="products-list-scroll">' +
                    '<table class="report-table products-admin-table" style="margin-top:10px;">' +
                    '<thead><tr><th>' + escapeHtml(thItem) + '</th><th>' + escapeHtml(thBc) + '</th><th>' + escapeHtml(thCat) + '</th><th>' + escapeHtml(thCost) + '</th><th>' + escapeHtml(thPrice) + '</th><th>' + escapeHtml(thStock) + '</th><th>' + escapeHtml(thPos) + '</th><th>' + escapeHtml(thAct) + '</th></tr></thead>' +
                    '<tbody>' + rowsHtml + '</tbody>' +
                    '</table></div>' + pagerBar;
            } catch (paintErr) {
                console.error('renderProducts paint failed', paintErr);
                container.innerHTML = '<div style="padding:20px;margin-top:10px;text-align:center;color:var(--danger);border:1px solid var(--border);border-radius:12px;">هەڵە د نیشاندana لیستێ دا: ' + escapeHtml(paintErr && paintErr.message ? paintErr.message : String(paintErr)) + '</div>';
            }
            const posView = document.getElementById('view-pos');
            const prodView = document.getElementById('view-products');
            if (posView && posView.classList.contains('active')
                && !(prodView && prodView.classList.contains('active'))
                && typeof renderPOSMenu === 'function') {
                renderPOSMenu(searchQ);
            }
        }
        window.renderProducts = renderProducts;
        var _productsSearchTimer = null;
        window.debouncedRenderProducts = function (q) {
            if (_productsSearchTimer) clearTimeout(_productsSearchTimer);
            if (typeof posPauseCatalogBackground === 'function') posPauseCatalogBackground();
            var delay = (typeof isPosCpuSaveMode === 'function' && isPosCpuSaveMode()) ? 380 : 180;
            _productsSearchTimer = setTimeout(function () {
                _productsSearchTimer = null;
                renderProducts(q);
                var raw = String(q == null ? '' : q).trim();
                if (!raw) {
                    if (typeof posResumeCatalogBackgroundLoad === 'function') posResumeCatalogBackgroundLoad();
                    return;
                }
                var afterSearch = function () {
                    if (typeof posResumeCatalogBackgroundLoad === 'function') {
                        setTimeout(function () { posResumeCatalogBackgroundLoad(); }, 800);
                    }
                };
                if (typeof posIsCatalogPartial === 'function' && !posIsCatalogPartial()) {
                    afterSearch();
                    return;
                }
                if (typeof posFetchProductSearchAll === 'function') {
                    posFetchProductSearchAll(raw, 200, 8000).then(function () {
                        renderProducts(q);
                    }).catch(function () {}).then(afterSearch);
                    return;
                }
                if (typeof posFetchProductSearch === 'function') {
                    posFetchProductSearch(raw, 80, 0).then(function (data) {
                        if (data && data.status === 'ok' && Array.isArray(data.rows) && data.rows.length
                            && typeof posUpsertProducts === 'function') {
                            posUpsertProducts(data.rows);
                        }
                        renderProducts(q);
                    }).catch(function () {}).then(afterSearch);
                    return;
                }
                afterSearch();
            }, delay);
        };


        // --- CUSTOM MEASURE UNITS ---
        var CUSTOM_MEASURE_UNITS_DEFAULTS = [
            { name: 'دانە', allowDecimal: false },
            { name: 'کیلۆ', allowDecimal: true },
            { name: 'لتر', allowDecimal: true },
            { name: 'مەتر', allowDecimal: true },
            { name: 'فەردە', allowDecimal: false },
            { name: 'گێنیک', allowDecimal: false },
            { name: 'پاکێت', allowDecimal: false },
            { name: 'کارتۆن', allowDecimal: false }
        ];

        function normalizeCustomMeasureUnitName(name) {
            return String(name == null ? '' : name).trim().replace(/\s+/g, ' ');
        }

        function getCustomMeasureUnits() {
            ensureCustomMeasureUnits();
            return (db && db.settings && Array.isArray(db.settings.customMeasureUnits)) ? db.settings.customMeasureUnits : [];
        }

        function ensureCustomMeasureUnits() {
            if (!db) return;
            if (!db.settings) db.settings = {};
            if (!Array.isArray(db.settings.customMeasureUnits) || !db.settings.customMeasureUnits.length) {
                var seeded = null;
                try {
                    var raw = localStorage.getItem('pos_custom_measure_units');
                    if (raw) seeded = JSON.parse(raw);
                } catch (eLs) { seeded = null; }
                if (Array.isArray(seeded) && seeded.length) {
                    db.settings.customMeasureUnits = seeded.map(function(u) {
                        return {
                            name: normalizeCustomMeasureUnitName(u && u.name),
                            allowDecimal: !!(u && (u.allowDecimal === true || u.allowDecimal === 1 || u.allowDecimal === '1'))
                        };
                    }).filter(function(u) { return !!u.name; });
                } else {
                    db.settings.customMeasureUnits = CUSTOM_MEASURE_UNITS_DEFAULTS.map(function(u) {
                        return { name: u.name, allowDecimal: !!u.allowDecimal };
                    });
                }
            }
            // Deduplicate by name (case-sensitive Kurdish)
            var seen = {};
            db.settings.customMeasureUnits = db.settings.customMeasureUnits.filter(function(u) {
                var n = normalizeCustomMeasureUnitName(u && u.name);
                if (!n || seen[n]) return false;
                seen[n] = true;
                u.name = n;
                u.allowDecimal = !!u.allowDecimal;
                return true;
            });
        }

        function persistCustomMeasureUnits() {
            ensureCustomMeasureUnits();
            try {
                localStorage.setItem('pos_custom_measure_units', JSON.stringify(db.settings.customMeasureUnits));
            } catch (e) {}
            if (typeof saveSettings === 'function') {
                saveSettings().catch(function() {});
            }
        }

        function findCustomMeasureUnit(name) {
            var n = normalizeCustomMeasureUnitName(name);
            if (!n) return null;
            var list = getCustomMeasureUnits();
            for (var i = 0; i < list.length; i++) {
                if (list[i].name === n) return list[i];
            }
            return null;
        }

        function upsertCustomMeasureUnit(name, allowDecimal) {
            var n = normalizeCustomMeasureUnitName(name);
            if (!n) return false;
            ensureCustomMeasureUnits();
            var existing = findCustomMeasureUnit(n);
            if (existing) {
                existing.allowDecimal = !!allowDecimal;
            } else {
                db.settings.customMeasureUnits.push({ name: n, allowDecimal: !!allowDecimal });
            }
            persistCustomMeasureUnits();
            updateUnitNamesSuggestions();
            renderCustomMeasureUnitChips();
            if (document.getElementById('custom-measure-units-modal') && document.getElementById('custom-measure-units-modal').style.display !== 'none') {
                renderCustomMeasureUnitsList();
            }
            return true;
        }

        function removeCustomMeasureUnit(name) {
            var n = normalizeCustomMeasureUnitName(name);
            if (!n || !db || !db.settings || !Array.isArray(db.settings.customMeasureUnits)) return;
            db.settings.customMeasureUnits = db.settings.customMeasureUnits.filter(function(u) {
                return normalizeCustomMeasureUnitName(u && u.name) !== n;
            });
            persistCustomMeasureUnits();
            updateUnitNamesSuggestions();
            renderCustomMeasureUnitChips();
            renderCustomMeasureUnitsList();
        }

        function rememberUnitNamesFromProductForm(allowDecimalHint) {
            var allowDec = (allowDecimalHint === true || allowDecimalHint === false)
                ? !!allowDecimalHint
                : ((typeof getProductFormQtyMode === 'function' ? getProductFormQtyMode() : 'piece') === 'kilo');
            ensureCustomMeasureUnits();
            var changed = false;
            ['p-unit-name-piece', 'p-unit-name-pack', 'p-unit-name-carton'].forEach(function(id) {
                var el = document.getElementById(id);
                var n = el ? normalizeCustomMeasureUnitName(el.value) : '';
                if (!n) return;
                if (findCustomMeasureUnit(n)) return; // keep user's explicit point setting
                db.settings.customMeasureUnits.push({ name: n, allowDecimal: !!allowDec });
                changed = true;
            });
            if (changed) {
                persistCustomMeasureUnits();
                updateUnitNamesSuggestions();
                renderCustomMeasureUnitChips();
            }
        }

        function getActiveCustomMeasureUnitName() {
            var el = document.getElementById('p-unit-name-piece');
            return el ? normalizeCustomMeasureUnitName(el.value) : '';
        }

        function syncQtyModeFromUnitNameInput(inputEl) {
            var n = normalizeCustomMeasureUnitName(inputEl && inputEl.value);
            renderCustomMeasureUnitChips();
            if (!n) return;
            var u = findCustomMeasureUnit(n);
            if (!u) return;
            var wantKilo = !!u.allowDecimal;
            var curKilo = (typeof getProductFormQtyMode === 'function' ? getProductFormQtyMode() : 'piece') === 'kilo';
            if (wantKilo === curKilo) return;
            var pieceEl = document.getElementById('p-mode-piece');
            var kiloEl = document.getElementById('p-mode-kilo');
            if (pieceEl) pieceEl.checked = !wantKilo;
            if (kiloEl) kiloEl.checked = !!wantKilo;
            if (wantKilo) {
                var usp = document.getElementById('p-unit-show-pack');
                var usc = document.getElementById('p-unit-show-carton');
                if (usp) usp.value = '0';
                if (usc) usc.value = '0';
            }
            if (typeof applyProductUnitLevelUI === 'function') applyProductUnitLevelUI();
            if (typeof updateUnitLabels === 'function') updateUnitLabels();
            renderCustomMeasureUnitChips();
        }

        function applyCustomMeasureUnit(name) {
            var n = normalizeCustomMeasureUnitName(name);
            if (!n) return;
            var u = findCustomMeasureUnit(n);
            var allowDec = u ? !!u.allowDecimal : false;
            var pieceEl = document.getElementById('p-mode-piece');
            var kiloEl = document.getElementById('p-mode-kilo');
            if (pieceEl) pieceEl.checked = !allowDec;
            if (kiloEl) kiloEl.checked = !!allowDec;
            if (allowDec) {
                var usp = document.getElementById('p-unit-show-pack');
                var usc = document.getElementById('p-unit-show-carton');
                if (usp) usp.value = '0';
                if (usc) usc.value = '0';
            }
            var pieceName = document.getElementById('p-unit-name-piece');
            if (pieceName) pieceName.value = n;
            if (typeof applyProductUnitLevelUI === 'function') applyProductUnitLevelUI();
            if (typeof updateUnitLabels === 'function') updateUnitLabels();
            renderCustomMeasureUnitChips();
            var statusEl = document.getElementById('custom-measure-units-active');
            if (statusEl) {
                statusEl.textContent = allowDec
                    ? ('هەڵبژارد: ' + n + ' — پوینت هەیە')
                    : ('هەڵبژارد: ' + n + ' — بێ پوینت');
            }
            if (typeof showToast === 'function') {
                showToast(allowDec
                    ? ('✅ ' + n + ' — پوینت هەیە')
                    : ('✅ ' + n + ' — بێ پوینت'), 'success');
            }
        }

        function bindCustomMeasureUnitsChipClicks() {
            var wrap = document.getElementById('custom-measure-units-chips');
            if (!wrap || wrap._cmuBound) return;
            wrap._cmuBound = true;
            wrap.addEventListener('click', function(ev) {
                var btn = ev.target && ev.target.closest ? ev.target.closest('[data-cmu-name]') : null;
                if (!btn || !wrap.contains(btn)) return;
                ev.preventDefault();
                ev.stopPropagation();
                var n = btn.getAttribute('data-cmu-name') || '';
                if (n && typeof applyCustomMeasureUnit === 'function') applyCustomMeasureUnit(n);
            });
        }

        function bindCustomMeasureUnitsListClicks() {
            var listEl = document.getElementById('custom-measure-units-list');
            if (!listEl || listEl._cmuBound) return;
            listEl._cmuBound = true;
            listEl.addEventListener('click', function(ev) {
                var t = ev.target && ev.target.closest ? ev.target.closest('[data-cmu-action]') : null;
                if (!t || !listEl.contains(t)) return;
                var action = t.getAttribute('data-cmu-action');
                var n = t.getAttribute('data-cmu-name') || '';
                if (!n) return;
                if (action === 'apply') {
                    applyCustomMeasureUnit(n);
                    closeCustomMeasureUnitsModal();
                } else if (action === 'remove') {
                    if (confirm('ژێبرنا ڤێ یەکێ؟')) removeCustomMeasureUnit(n);
                }
            });
            listEl.addEventListener('change', function(ev) {
                var t = ev.target;
                if (!t || t.getAttribute('data-cmu-action') !== 'toggle-point') return;
                var n = t.getAttribute('data-cmu-name') || '';
                if (n) upsertCustomMeasureUnit(n, !!t.checked);
            });
        }

        function renderCustomMeasureUnitChips() {
            var wrap = document.getElementById('custom-measure-units-chips');
            if (!wrap) return;
            bindCustomMeasureUnitsChipClicks();
            ensureCustomMeasureUnits();
            var active = getActiveCustomMeasureUnitName();
            var list = getCustomMeasureUnits();
            if (!list.length) {
                wrap.innerHTML = '';
                return;
            }
            wrap.innerHTML = list.map(function(u) {
                var isActive = u.name === active;
                var tip = u.allowDecimal ? 'پوینت هەیە' : 'بێ پوینت';
                var badge = u.allowDecimal ? ' <span style="opacity:0.75;font-size:0.7em;">(پوینت)</span>' : '';
                return '<button type="button" class="cmu-chip btn btn-sm' + (isActive ? ' btn-brand' : '') + '" data-cmu-name="' + escapeHtml(u.name) + '" style="padding:4px 10px; font-size:0.8rem; border-radius:999px; cursor:pointer; ' +
                    (isActive ? 'box-shadow:0 0 0 2px rgba(37,99,235,0.35);' : 'background:var(--input-bg); color:var(--text); border:1px solid var(--border);') +
                    '" title="' + escapeHtml(tip) + '">' +
                    escapeHtml(u.name) + badge + '</button>';
            }).join('');
            var statusEl = document.getElementById('custom-measure-units-active');
            if (statusEl) {
                if (active) {
                    var au = findCustomMeasureUnit(active);
                    statusEl.textContent = au && au.allowDecimal
                        ? ('هەڵبژارد: ' + active + ' — پوینت هەیە')
                        : ('هەڵبژارد: ' + active + (au ? ' — بێ پوینت' : ''));
                } else {
                    statusEl.textContent = 'یەکێک هەڵبژێرە یان دوگمەی «یەکە» بۆ زێدەکرن';
                }
            }
        }

        function renderCustomMeasureUnitsList() {
            var listEl = document.getElementById('custom-measure-units-list');
            if (!listEl) return;
            bindCustomMeasureUnitsListClicks();
            ensureCustomMeasureUnits();
            var list = getCustomMeasureUnits();
            if (!list.length) {
                listEl.innerHTML = '<div style="color:var(--text-muted); font-size:0.85rem; padding:8px 0;">هیچ یەکەیەک نەهاتیە خەزنکرن.</div>';
                return;
            }
            listEl.innerHTML = list.map(function(u) {
                var pointLbl = u.allowDecimal ? 'پوینت ✓' : 'بێ پوینت';
                var safe = escapeHtml(u.name);
                return '<div style="display:flex; align-items:center; gap:8px; padding:8px 10px; border:1px solid var(--border); border-radius:10px; background:var(--card);">' +
                    '<div style="flex:1; min-width:0;">' +
                    '<div style="font-weight:700;">' + safe + '</div>' +
                    '<div style="font-size:0.75rem; color:var(--text-muted);">' + escapeHtml(pointLbl) + '</div>' +
                    '</div>' +
                    '<label style="display:flex; align-items:center; gap:4px; font-size:0.75rem; white-space:nowrap; cursor:pointer;" title="پوینت">' +
                    '<input type="checkbox" data-cmu-action="toggle-point" data-cmu-name="' + safe + '" ' + (u.allowDecimal ? 'checked' : '') + '>' +
                    '<span>پوینت</span></label>' +
                    '<button type="button" class="btn btn-sm btn-brand" style="padding:4px 8px;" data-cmu-action="apply" data-cmu-name="' + safe + '">هەڵبژێرە</button>' +
                    '<button type="button" class="btn btn-sm btn-dark" style="padding:4px 8px;" title="ژێبرن" data-cmu-action="remove" data-cmu-name="' + safe + '"><i class="fas fa-trash"></i></button>' +
                    '</div>';
            }).join('');
        }

        function openCustomMeasureUnitsModal() {
            ensureCustomMeasureUnits();
            var modal = document.getElementById('custom-measure-units-modal');
            if (!modal) return;
            var nameInp = document.getElementById('cmu-name-input');
            var decInp = document.getElementById('cmu-allow-decimal');
            if (nameInp) nameInp.value = '';
            if (decInp) decInp.checked = true;
            renderCustomMeasureUnitsList();
            modal.style.display = 'flex';
            setTimeout(function() { if (nameInp) nameInp.focus(); }, 80);
        }

        function closeCustomMeasureUnitsModal() {
            var modal = document.getElementById('custom-measure-units-modal');
            if (modal) modal.style.display = 'none';
        }

        function addCustomMeasureUnitFromForm() {
            var nameInp = document.getElementById('cmu-name-input');
            var decInp = document.getElementById('cmu-allow-decimal');
            var n = nameInp ? normalizeCustomMeasureUnitName(nameInp.value) : '';
            if (!n) {
                if (typeof showToast === 'function') showToast('ناڤێ یەکێ بنڤیسە', 'warning');
                else alert('ناڤێ یەکێ بنڤیسە');
                if (nameInp) nameInp.focus();
                return;
            }
            upsertCustomMeasureUnit(n, !!(decInp && decInp.checked));
            if (nameInp) nameInp.value = '';
            if (typeof showToast === 'function') showToast('✅ یەکە هاتە خەزنکرن', 'success');
        }

        function updateUnitNamesSuggestions() {
            var dl = document.getElementById('unit-names-list');
            if (!dl) return;
            var names = new Set();
            ensureCustomMeasureUnits();
            getCustomMeasureUnits().forEach(function(u) {
                if (u && u.name) names.add(u.name);
            });
            CUSTOM_MEASURE_UNITS_DEFAULTS.forEach(function(u) { names.add(u.name); });
            ['درەزن', 'ملیگرام', 'گروم', 'سی سی', 'پاوند', 'ئۆنز', 'كيلۆ'].forEach(function(n) { names.add(n); });
            if (db && Array.isArray(db.products)) {
                db.products.forEach(function(p) {
                    if (p.unit_name_piece) names.add(p.unit_name_piece);
                    if (p.unit_name_pack) names.add(p.unit_name_pack);
                    if (p.unit_name_carton) names.add(p.unit_name_carton);
                });
            }
            var html = '';
            names.forEach(function(n) {
                if (n && String(n).trim()) {
                    html += '<option value="' + escapeHtml(n) + '">';
                }
            });
            dl.innerHTML = html;
        }

        function refreshCustomMeasureUnitsUI() {
            updateUnitNamesSuggestions();
            renderCustomMeasureUnitChips();
        }

        window.updateUnitNamesSuggestions = updateUnitNamesSuggestions;
        window.refreshCustomMeasureUnitsUI = refreshCustomMeasureUnitsUI;
        window.openCustomMeasureUnitsModal = openCustomMeasureUnitsModal;
        window.closeCustomMeasureUnitsModal = closeCustomMeasureUnitsModal;
        window.addCustomMeasureUnitFromForm = addCustomMeasureUnitFromForm;
        window.applyCustomMeasureUnit = applyCustomMeasureUnit;
        window.upsertCustomMeasureUnit = upsertCustomMeasureUnit;
        window.removeCustomMeasureUnit = removeCustomMeasureUnit;
        window.renderCustomMeasureUnitChips = renderCustomMeasureUnitChips;
        window.rememberUnitNamesFromProductForm = rememberUnitNamesFromProductForm;
        window.syncQtyModeFromUnitNameInput = syncQtyModeFromUnitNameInput;
        window.productFormGoToStep = productFormGoToStep;
        window.toggleProductFormAllSteps = toggleProductFormAllSteps;
        window.isProductFormAllSteps = isProductFormAllSteps;
        window.getCurrentProductFormStep = getCurrentProductFormStep;
        window.getProductFormFocusables = getProductFormFocusables;
        window.clearProductInputs = clearProductInputs;
        window.clearProductFormForNewItem = clearProductFormForNewItem;
        window.saveProduct = saveProduct;
        window.finishProductSaveAndStayOnStep1 = finishProductSaveAndStayOnStep1;
        window.upsertProductAdminListRow = upsertProductAdminListRow;
