/**
 * Business-specific UI profiles: icons, nav order, visible sections, accent.
 * Each business type has a distinct look and feature set.
 */
(function (global) {
    'use strict';

    var ALL_SECTIONS = ['calendar', 'tables', 'pos', 'debt', 'companies', 'warehouse', 'products', 'purchase', 'purchase-returns', 'delivery', 'expenses', 'waste', 'recipes', 'print-history', 'notifications', 'staff', 'settings', 'print-design'];

    var BUSINESS_PROFILES = {
        market: {
            accent: '#2563eb',
            tablesLabel: 'سەبەت (Carts)',
            navOrder: ['calendar', 'tables', 'pos', 'products', 'purchase', 'purchase-returns', 'warehouse', 'companies', 'delivery', 'expenses', 'waste', 'notifications', 'staff', 'settings', 'print-design', 'print-history'],
            visibleSections: ['tables', 'pos', 'debt', 'companies', 'warehouse', 'products', 'purchase', 'purchase-returns', 'delivery', 'expenses', 'waste', 'calendar', 'notifications', 'staff', 'settings', 'print-design', 'print-history'],
            icons: {
                menu: 'fa-bars', dash: 'fa-chart-pie', tables: 'fa-shopping-cart', pos: 'fa-cash-register', debt: 'fa-file-invoice-dollar',
                companies: 'fa-truck-loading', warehouse: 'fa-boxes-stacked', 'warehouse-categories': 'fa-layer-group', 'warehouse-printers': 'fa-print', 'warehouse-stocktake': 'fa-clipboard-check', 'warehouse-movements': 'fa-arrows-left-right', 'warehouse-suppliers': 'fa-truck', 'warehouse-reports': 'fa-chart-column', 'stock-card': 'fa-box-open', products: 'fa-tags', delivery: 'fa-truck-fast',
                expenses: 'fa-money-bill-wave', waste: 'fa-trash-can', recipes: 'fa-boxes-packing', 'print-history': 'fa-clock-rotate-left', calendar: 'fa-calendar-check', notifications: 'fa-bell', staff: 'fa-users', settings: 'fa-sliders', 'print-design': 'fa-print', purchase: 'fa-cart-shopping'
            }
        },
        pharmacy: {
            accent: '#0d9488',
            tablesLabel: 'وەسڵ / Rx',
            navOrder: ['calendar', 'tables', 'pos', 'products', 'recipes', 'warehouse', 'purchase', 'purchase-returns', 'debt', 'companies', 'expenses', 'notifications', 'staff', 'settings', 'print-design', 'print-history'],
            visibleSections: ['tables', 'pos', 'debt', 'companies', 'warehouse', 'products', 'purchase', 'purchase-returns', 'recipes', 'expenses', 'calendar', 'notifications', 'staff', 'settings', 'print-design', 'print-history'],
            icons: {
                menu: 'fa-bars', dash: 'fa-heart-pulse', tables: 'fa-file-prescription', pos: 'fa-capsules', debt: 'fa-hand-holding-medical',
                companies: 'fa-truck-medical', warehouse: 'fa-tablets', 'warehouse-locations': 'fa-hospital', 'warehouse-transfers': 'fa-right-left', 'warehouse-categories': 'fa-flask-vial', 'warehouse-printers': 'fa-print', 'warehouse-stocktake': 'fa-vial-circle-check', 'warehouse-movements': 'fa-arrow-right-arrow-left', 'warehouse-suppliers': 'fa-syringe', 'warehouse-reports': 'fa-clipboard-prescription', 'stock-card': 'fa-prescription-bottle-medical', products: 'fa-pills',
                'purchase-returns': 'fa-rotate-left', purchase: 'fa-truck-medical', delivery: 'fa-truck-medical',
                expenses: 'fa-sack-dollar', waste: 'fa-bottle-droplet', recipes: 'fa-mortar-pestle', 'print-history': 'fa-clock-rotate-left', calendar: 'fa-calendar-days', notifications: 'fa-bell', staff: 'fa-user-doctor', settings: 'fa-gear', 'print-design': 'fa-print',
                'mega-stats': 'fa-chart-pie', 'returns-new': 'fa-prescription-bottle'
            }
        },
        stationery: {
            accent: '#f97316',
            tablesLabel: 'سەبەت (Carts)',
            navOrder: ['calendar', 'tables', 'pos', 'products', 'purchase', 'purchase-returns', 'warehouse', 'companies', 'delivery', 'expenses', 'waste', 'notifications', 'staff', 'settings', 'print-design', 'print-history'],
            visibleSections: ['tables', 'pos', 'debt', 'companies', 'warehouse', 'products', 'purchase', 'purchase-returns', 'delivery', 'expenses', 'waste', 'calendar', 'notifications', 'staff', 'settings', 'print-design', 'print-history'],
            icons: {
                menu: 'fa-bars', dash: 'fa-pen-ruler', tables: 'fa-basket-shopping', pos: 'fa-pen-fancy', debt: 'fa-book-open', companies: 'fa-store', warehouse: 'fa-archive', 'warehouse-categories': 'fa-folder-tree', 'warehouse-printers': 'fa-print', 'warehouse-stocktake': 'fa-list-check', 'warehouse-movements': 'fa-arrows-up-down-left-right', 'warehouse-suppliers': 'fa-truck', 'warehouse-reports': 'fa-file-lines', 'stock-card': 'fa-bookmark', products: 'fa-pencil', delivery: 'fa-truck',
                expenses: 'fa-coins', waste: 'fa-scissors', recipes: 'fa-wand-magic-sparkles', 'print-history': 'fa-rotate-left', calendar: 'fa-calendar', notifications: 'fa-bell', staff: 'fa-user-pen', settings: 'fa-gears', 'print-design': 'fa-print', purchase: 'fa-cart-plus'
            }
        },
        mobile: {
            accent: '#5b7a9a',
            tablesLabel: 'سەبەت (Carts)',
            navOrder: ['calendar', 'tables', 'pos', 'products', 'purchase', 'purchase-returns', 'warehouse', 'companies', 'delivery', 'expenses', 'waste', 'notifications', 'staff', 'settings', 'print-design', 'print-history'],
            visibleSections: ['tables', 'pos', 'debt', 'companies', 'warehouse', 'products', 'purchase', 'purchase-returns', 'delivery', 'expenses', 'waste', 'calendar', 'notifications', 'staff', 'settings', 'print-design', 'print-history'],
            icons: {
                menu: 'fa-bars', dash: 'fa-chart-line', tables: 'fa-tablet-screen-button', pos: 'fa-mobile-screen-button', debt: 'fa-file-invoice-dollar',
                companies: 'fa-store', warehouse: 'fa-boxes-stacked', 'warehouse-categories': 'fa-layer-group', 'warehouse-printers': 'fa-print', 'warehouse-stocktake': 'fa-clipboard-check', 'warehouse-movements': 'fa-arrows-left-right', 'warehouse-suppliers': 'fa-truck', 'warehouse-reports': 'fa-chart-column', 'stock-card': 'fa-box-open', products: 'fa-headphones', delivery: 'fa-truck-fast',
                expenses: 'fa-money-bill-wave', waste: 'fa-trash-can', recipes: 'fa-layer-group', 'print-history': 'fa-clock-rotate-left', calendar: 'fa-calendar-check', notifications: 'fa-bell', staff: 'fa-users', settings: 'fa-sliders', 'print-design': 'fa-print', purchase: 'fa-cart-shopping'
            }
        },
        company: {
            accent: '#4b5563',
            tablesLabel: 'داواکاری (Orders)',
            navOrder: ['calendar', 'tables', 'companies', 'debt', 'products', 'purchase', 'purchase-returns', 'delivery', 'expenses', 'notifications', 'staff', 'settings', 'print-design', 'print-history'],
            visibleSections: ['companies', 'debt', 'warehouse', 'products', 'purchase', 'purchase-returns', 'delivery', 'expenses', 'calendar', 'notifications', 'staff', 'settings', 'print-design', 'print-history'],
            icons: {
                menu: 'fa-bars', dash: 'fa-building-columns', tables: 'fa-clipboard-list', pos: 'fa-file-invoice', debt: 'fa-scale-balanced', companies: 'fa-building', warehouse: 'fa-warehouse', 'warehouse-categories': 'fa-diagram-project', 'warehouse-printers': 'fa-print', 'warehouse-stocktake': 'fa-clipboard-list', 'warehouse-movements': 'fa-right-left', 'warehouse-suppliers': 'fa-handshake', 'warehouse-reports': 'fa-chart-mixed', 'stock-card': 'fa-folder-open', products: 'fa-box-archive', delivery: 'fa-truck-ramp-box',
                expenses: 'fa-wallet', waste: 'fa-file-circle-xmark', recipes: 'fa-book', 'print-history': 'fa-clock-rotate-left', calendar: 'fa-calendar-week', notifications: 'fa-envelope', staff: 'fa-user-tie', settings: 'fa-cog', 'print-design': 'fa-print', purchase: 'fa-cart-shopping'
            }
        },
        factory: {
            accent: '#0891b2',
            tablesLabel: 'Batch / Production',
            navOrder: ['calendar', 'tables', 'pos', 'debt', 'companies', 'warehouse', 'products', 'purchase', 'purchase-returns', 'delivery', 'recipes', 'expenses', 'waste', 'notifications', 'staff', 'settings', 'print-design', 'print-history'],
            visibleSections: ['tables', 'pos', 'debt', 'companies', 'warehouse', 'products', 'purchase', 'purchase-returns', 'delivery', 'recipes', 'expenses', 'waste', 'calendar', 'notifications', 'staff', 'settings', 'print-design', 'print-history'],
            icons: {
                menu: 'fa-bars', dash: 'fa-industry', tables: 'fa-gears', pos: 'fa-cash-register', debt: 'fa-file-invoice-dollar',
                companies: 'fa-handshake', warehouse: 'fa-warehouse', 'warehouse-categories': 'fa-layer-group', 'warehouse-printers': 'fa-print', 'warehouse-stocktake': 'fa-clipboard-check', 'warehouse-movements': 'fa-truck-ramp-box', 'warehouse-suppliers': 'fa-truck', 'warehouse-reports': 'fa-chart-column', 'stock-card': 'fa-boxes-stacked', products: 'fa-flask', delivery: 'fa-truck-fast',
                expenses: 'fa-sack-dollar', waste: 'fa-recycle', recipes: 'fa-pump-soap', 'print-history': 'fa-clock-rotate-left', calendar: 'fa-calendar-check', notifications: 'fa-bell', staff: 'fa-users-gear', settings: 'fa-screwdriver-wrench', 'print-design': 'fa-print', purchase: 'fa-cart-shopping'
            }
        },
        cafe: {
            accent: '#a855f7',
            tablesLabel: 'مێز (Tables)',
            navOrder: ['calendar', 'tables', 'pos', 'debt', 'recipes', 'expenses', 'waste', 'notifications', 'staff', 'settings', 'print-design', 'print-history'],
            visibleSections: ['tables', 'pos', 'debt', 'recipes', 'expenses', 'waste', 'calendar', 'notifications', 'staff', 'settings', 'print-design', 'print-history'],
            icons: {
                menu: 'fa-bars', dash: 'fa-mug-saucer', tables: 'fa-chair', pos: 'fa-mug-hot', debt: 'fa-receipt', companies: 'fa-store', warehouse: 'fa-warehouse', 'warehouse-categories': 'fa-layer-group', 'warehouse-printers': 'fa-print', 'warehouse-stocktake': 'fa-clipboard-list', 'warehouse-movements': 'fa-exchange-alt', 'warehouse-suppliers': 'fa-truck', 'warehouse-reports': 'fa-chart-bar', 'stock-card': 'fa-history', products: 'fa-martini-glass-citrus', delivery: 'fa-truck',
                expenses: 'fa-credit-card', waste: 'fa-bottle-water', recipes: 'fa-blender', 'print-history': 'fa-clock-rotate-left', calendar: 'fa-calendar-days', notifications: 'fa-bell', staff: 'fa-user', settings: 'fa-sliders-h', 'print-design': 'fa-print', purchase: 'fa-shopping-bag'
            }
        },
        restaurant: {
            accent: '#ef4444',
            tablesLabel: 'مێز (Tables)',
            navOrder: ['calendar', 'tables', 'pos', 'products', 'purchase', 'purchase-returns', 'recipes', 'delivery', 'expenses', 'waste', 'notifications', 'staff', 'settings', 'print-design', 'print-history'],
            visibleSections: ['tables', 'pos', 'products', 'purchase', 'purchase-returns', 'recipes', 'delivery', 'expenses', 'waste', 'calendar', 'notifications', 'staff', 'settings', 'print-design', 'print-history'],
            icons: {
                menu: 'fa-bars', dash: 'fa-utensils', tables: 'fa-chair', pos: 'fa-bowl-food', debt: 'fa-book', companies: 'fa-building', warehouse: 'fa-warehouse', 'warehouse-categories': 'fa-layer-group', 'warehouse-printers': 'fa-print', 'warehouse-stocktake': 'fa-clipboard-list', 'warehouse-movements': 'fa-exchange-alt', 'warehouse-suppliers': 'fa-truck', 'warehouse-reports': 'fa-chart-bar', 'stock-card': 'fa-history', products: 'fa-tags', delivery: 'fa-truck',
                expenses: 'fa-wallet', waste: 'fa-trash-alt', recipes: 'fa-kitchen-set', 'print-history': 'fa-history', calendar: 'fa-calendar-days', notifications: 'fa-bell', staff: 'fa-users', settings: 'fa-cog', 'print-design': 'fa-print', purchase: 'fa-cart-shopping', 'purchase-returns': 'fa-rotate-left'
            }
        },
        clinic: {
            accent: '#0ea5e9',
            tablesLabel: 'ڕێکخستنا مراجعین',
            navOrder: ['calendar', 'tables', 'pos', 'debt', 'products', 'purchase', 'purchase-returns', 'expenses', 'notifications', 'staff', 'settings', 'print-design', 'print-history'],
            visibleSections: ['tables', 'pos', 'debt', 'products', 'purchase', 'purchase-returns', 'expenses', 'calendar', 'notifications', 'staff', 'settings', 'print-design', 'print-history'],
            icons: {
                menu: 'fa-bars', dash: 'fa-stethoscope', tables: 'fa-user-injured', pos: 'fa-syringe', debt: 'fa-file-medical', companies: 'fa-hospital', warehouse: 'fa-pills', 'warehouse-categories': 'fa-flask', 'warehouse-printers': 'fa-print', 'warehouse-stocktake': 'fa-vial', 'warehouse-movements': 'fa-arrow-right-arrow-left', 'warehouse-suppliers': 'fa-truck-medical', 'warehouse-reports': 'fa-clipboard-pulse', 'stock-card': 'fa-notes-medical', products: 'fa-pills', delivery: 'fa-ambulance',
                expenses: 'fa-sack-dollar', waste: 'fa-bottle-droplet', recipes: 'fa-mortar-pestle', 'print-history': 'fa-history', calendar: 'fa-calendar-check', notifications: 'fa-bell', staff: 'fa-user-nurse', settings: 'fa-gear', 'print-design': 'fa-print', purchase: 'fa-cart-shopping'
            }
        },
        hotel: {
            accent: '#eab308',
            tablesLabel: 'ژوور (Rooms)',
            navOrder: ['calendar', 'tables', 'pos', 'debt', 'recipes', 'expenses', 'notifications', 'staff', 'settings', 'print-design', 'print-history'],
            visibleSections: ['tables', 'pos', 'debt', 'recipes', 'expenses', 'waste', 'calendar', 'notifications', 'staff', 'settings', 'print-design', 'print-history'],
            icons: {
                menu: 'fa-bars', dash: 'fa-hotel', tables: 'fa-bed', pos: 'fa-concierge-bell', debt: 'fa-key', companies: 'fa-building', warehouse: 'fa-warehouse', 'warehouse-categories': 'fa-layer-group', 'warehouse-printers': 'fa-print', 'warehouse-stocktake': 'fa-clipboard-list', 'warehouse-movements': 'fa-exchange-alt', 'warehouse-suppliers': 'fa-truck', 'warehouse-reports': 'fa-chart-bar', 'stock-card': 'fa-history', products: 'fa-spa', delivery: 'fa-truck',
                expenses: 'fa-money-check-dollar', waste: 'fa-trash-alt', recipes: 'fa-utensils', 'print-history': 'fa-history', calendar: 'fa-calendar-days', notifications: 'fa-bell', staff: 'fa-user-tie', settings: 'fa-cog', 'print-design': 'fa-print', purchase: 'fa-cart-shopping'
            }
        },
        school: {
            accent: '#4f46e5',
            tablesLabel: 'پۆل (Classes)',
            navOrder: ['calendar', 'tables', 'pos', 'debt', 'products', 'expenses', 'notifications', 'staff', 'settings', 'print-design', 'print-history'],
            visibleSections: ['tables', 'pos', 'debt', 'products', 'expenses', 'calendar', 'notifications', 'staff', 'settings', 'print-design', 'print-history'],
            icons: {
                menu: 'fa-bars', dash: 'fa-school', tables: 'fa-chalkboard-user', pos: 'fa-cash-register', debt: 'fa-file-invoice-dollar', companies: 'fa-building', warehouse: 'fa-warehouse', 'warehouse-categories': 'fa-layer-group', 'warehouse-printers': 'fa-print', 'warehouse-stocktake': 'fa-clipboard-list', 'warehouse-movements': 'fa-exchange-alt', 'warehouse-suppliers': 'fa-truck', 'warehouse-reports': 'fa-chart-bar', 'stock-card': 'fa-history', products: 'fa-book', delivery: 'fa-truck',
                expenses: 'fa-wallet', waste: 'fa-trash-alt', recipes: 'fa-utensils', 'print-history': 'fa-history', calendar: 'fa-calendar-days', notifications: 'fa-bell', staff: 'fa-chalkboard-teacher', settings: 'fa-cog', 'print-design': 'fa-print', purchase: 'fa-cart-shopping'
            }
        },
        jewelry: {
            accent: '#c9a227',
            tablesLabel: 'سەبەت (Carts)',
            navOrder: ['calendar', 'tables', 'pos', 'products', 'purchase', 'purchase-returns', 'warehouse', 'companies', 'debt', 'expenses', 'waste', 'notifications', 'staff', 'settings', 'print-design', 'print-history'],
            visibleSections: ['tables', 'pos', 'debt', 'companies', 'warehouse', 'products', 'purchase', 'purchase-returns', 'expenses', 'waste', 'calendar', 'notifications', 'staff', 'settings', 'print-design', 'print-history'],
            icons: {
                menu: 'fa-bars', dash: 'fa-gem', tables: 'fa-basket-shopping', pos: 'fa-ring', debt: 'fa-file-invoice-dollar',
                companies: 'fa-handshake', warehouse: 'fa-boxes-stacked', 'warehouse-categories': 'fa-layer-group', 'warehouse-printers': 'fa-print', 'warehouse-stocktake': 'fa-clipboard-check', 'warehouse-movements': 'fa-arrows-left-right', 'warehouse-suppliers': 'fa-truck', 'warehouse-reports': 'fa-chart-column', 'stock-card': 'fa-box-open', products: 'fa-gem', delivery: 'fa-truck',
                expenses: 'fa-coins', waste: 'fa-recycle', recipes: 'fa-layer-group', 'print-history': 'fa-clock-rotate-left', calendar: 'fa-calendar-check', notifications: 'fa-bell', staff: 'fa-users', settings: 'fa-sliders', 'print-design': 'fa-print', purchase: 'fa-cart-shopping', 'purchase-returns': 'fa-rotate-left'
            }
        },
        general: {
            accent: null,
            tablesLabel: 'بەش (Sections)',
            navOrder: ['calendar', 'tables', 'pos', 'debt', 'companies', 'warehouse', 'products', 'purchase', 'purchase-returns', 'delivery', 'expenses', 'waste', 'recipes', 'notifications', 'staff', 'settings', 'print-design', 'print-history'],
            visibleSections: ['tables', 'pos', 'debt', 'companies', 'warehouse', 'products', 'purchase', 'purchase-returns', 'delivery', 'expenses', 'waste', 'recipes', 'calendar', 'notifications', 'staff', 'settings', 'print-design', 'print-history'],
            icons: {
                menu: 'fa-bars', dash: 'fa-chart-line', tables: 'fa-cash-register', pos: 'fa-cart-plus', debt: 'fa-book', companies: 'fa-building', warehouse: 'fa-warehouse', 'warehouse-categories': 'fa-layer-group', 'warehouse-printers': 'fa-print', 'warehouse-stocktake': 'fa-clipboard-list', 'warehouse-movements': 'fa-exchange-alt', 'warehouse-suppliers': 'fa-truck', 'warehouse-reports': 'fa-chart-bar', 'stock-card': 'fa-history', products: 'fa-tags', delivery: 'fa-truck',
                expenses: 'fa-wallet', waste: 'fa-trash-alt', recipes: 'fa-utensils', 'print-history': 'fa-history', calendar: 'fa-calendar-days', notifications: 'fa-bell', staff: 'fa-user-tie', settings: 'fa-cog', 'print-design': 'fa-print', purchase: 'fa-shopping-cart'
            }
        }
    };

    /** Top accent colours per functional zone on the Home dashboard (distinct stripes per card group). */
    var HOME_ZONE_PALETTES = {
        market: { core: '#93c5fd', sales: '#3b82f6', catalog: '#2563eb', stock: '#1e40af', trade: '#172554', kitchen: '#60a5fa', finance: '#475569', insights: '#38bdf8', ops: '#64748b', system: '#334155' },
        pharmacy: { core: '#99f6e4', sales: '#14b8a6', catalog: '#0d9488', stock: '#115e59', trade: '#134e4a', kitchen: '#5eead4', finance: '#134e4a', insights: '#2dd4bf', ops: '#64748b', system: '#475569' },
        stationery: { core: '#fed7aa', sales: '#fb923c', catalog: '#f97316', stock: '#ea580c', trade: '#c2410c', kitchen: '#fdba74', finance: '#9a3412', insights: '#ea580c', ops: '#78716c', system: '#57534e' },
        mobile: { core: '#cbd5e1', sales: '#64748b', catalog: '#5b7a9a', stock: '#475569', trade: '#334155', kitchen: '#94a3b8', finance: '#1e293b', insights: '#3b82f6', ops: '#64748b', system: '#475569' },
        company: { core: '#e5e7eb', sales: '#6b7280', catalog: '#4b5563', stock: '#374151', trade: '#111827', kitchen: '#9ca3af', finance: '#1f2937', insights: '#52525b', ops: '#78716c', system: '#57534e' },
        factory: { core: '#67e8f9', sales: '#0891b2', catalog: '#0e7490', stock: '#155e75', trade: '#164e63', kitchen: '#22d3ee', finance: '#083344', insights: '#06b6d4', ops: '#64748b', system: '#475569' },
        cafe: { core: '#e9d5ff', sales: '#a855f7', catalog: '#9333ea', stock: '#7e22ce', trade: '#581c87', kitchen: '#f0abfc', finance: '#4c1d95', insights: '#c084fc', ops: '#78716c', system: '#57534e' },
        restaurant: { core: '#fecaca', sales: '#ef4444', catalog: '#dc2626', stock: '#b91c1c', trade: '#7f1d1d', kitchen: '#fca5a5', finance: '#991b1b', insights: '#f87171', ops: '#78716c', system: '#57534e' },
        clinic: { core: '#bae6fd', sales: '#0ea5e9', catalog: '#0284c7', stock: '#0369a1', trade: '#075985', kitchen: '#7dd3fc', finance: '#0c4a6e', insights: '#38bdf8', ops: '#64748b', system: '#475569' },
        hotel: { core: '#fef08a', sales: '#eab308', catalog: '#ca8a04', stock: '#a16207', trade: '#713f12', kitchen: '#fde047', finance: '#854d0e', insights: '#facc15', ops: '#78716c', system: '#57534e' },
        school: { core: '#c7d2fe', sales: '#6366f1', catalog: '#4f46e5', stock: '#4338ca', trade: '#312e81', kitchen: '#a5b4fc', finance: '#1e1b4b', insights: '#818cf8', ops: '#64748b', system: '#475569' },
        jewelry: { core: '#f5e6b8', sales: '#d4a017', catalog: '#c9a227', stock: '#a67c00', trade: '#7a5c00', kitchen: '#e8c547', finance: '#5c4500', insights: '#b8860b', ops: '#78716c', system: '#57534e' },
        general: { core: '#cbd5e1', sales: '#3b82f6', catalog: '#6366f1', stock: '#8b5cf6', trade: '#0ea5e9', kitchen: '#14b8a6', finance: '#64748b', insights: '#f59e0b', ops: '#78716c', system: '#57534e' }
    };

    /** Short subtitle under the Home dashboard title (Badini + Arabic). */
    var HOME_SUBTITLES = {
        market: { badini: 'مارکێت · سەبەت، فرۆتن، کۆگەه و گەیاندن', ar: 'السوق · السلة والبيع والمخزون والتوصيل' },
        pharmacy: { badini: 'سەیدەلی · وەسڵ، دەرمان، کۆگە و کڕین', ar: 'الصيدلية · الوصفات والأدوية والمخزون والشراء' },
        stationery: { badini: 'قرطاسیە · کەلوپەل، فرۆتن، کۆگەه — ڕێک و ڕوون', ar: 'القرطاسية · الأصناف والبيع والمخزون بترتيب واضح' },
        mobile: { badini: 'مۆبایل · فرۆتن، کەلوپەل، گەیاندن', ar: 'الهاتف المحمول · البيع والأصناف والتوصيل' },
        company: { badini: 'کۆمپانیا · داواکاری، کڕین، ڕاپۆرت', ar: 'الشركات · الطلبات والمشتريات والتقارير' },
        factory: { badini: 'کارگە · بەرهەمان، کۆگەه، ڕێسیپی و کڕین', ar: 'المصنع · الإنتاج والمخزون والوصفات والمشتريات' },
        cafe: { badini: 'کۆفی شۆپ · مێز، خواردنەوە، ڕێسیپی', ar: 'المقهى · الطاولات والمشروبات والوصفات' },
        restaurant: { badini: 'مەتعەم · مێز، چێشتخانە، گەیاندن', ar: 'المطعم · الطاولات والمطبخ والتوصيل' },
        clinic: { badini: 'عیادة · چاوپێکەوتن، فرۆتن، پسوولە', ar: 'العيادة · المواعيد والبيع والفواتير' },
        hotel: { badini: 'فندق · ژوور، خزمەت، حساب', ar: 'الفندق · الغرف والخدمات والحسابات' },
        school: { badini: 'قوتابخانە · پۆل، فرۆتن، ڕاپۆرت', ar: 'المدرسة · الصفوف والبيع والتقارير' },
        jewelry: { badini: 'زیڤ و زێر · حەلقە، رستە، فرۆتن و کۆگە', ar: 'الذهب والفضة · الخواتم والأساور والبيع والمخزون' },
        general: { badini: 'گشتی · هەمی بەشەکان ڕێکخراون بۆ کارکردنی خێرا', ar: 'عام · كل الأقسام مرتبة وسريعة الاستخدام' }
    };

    Object.keys(BUSINESS_PROFILES).forEach(function (key) {
        var p = BUSINESS_PROFILES[key];
        if (HOME_ZONE_PALETTES[key]) {
            p.homeZoneColors = HOME_ZONE_PALETTES[key];
        }
        if (HOME_SUBTITLES[key]) {
            p.homeSubtitle = HOME_SUBTITLES[key].badini || '';
            p.homeSubtitleAr = HOME_SUBTITLES[key].ar || '';
        }
    });

    function getBusinessProfile(mode) {
        if (!mode || !BUSINESS_PROFILES[mode]) return BUSINESS_PROFILES.general;
        return BUSINESS_PROFILES[mode];
    }

    global.BUSINESS_PROFILES = BUSINESS_PROFILES;
    global.getBusinessProfile = getBusinessProfile;
})(typeof window !== 'undefined' ? window : this);
