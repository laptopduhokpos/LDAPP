<?php
// --- HELPER: Flexible backup normalization (multi-source JSON compatibility) ---
function pickBackupValue($source, $keys, $default = null) {
    if (!is_array($source)) return $default;
    foreach ($keys as $k) {
        if (array_key_exists($k, $source)) return $source[$k];
    }
    return $default;
}

function normalizeBackupArray($v) {
    if (is_array($v)) return $v;
    if (is_object($v)) return json_decode(json_encode($v), true);
    return [];
}

function normalizeBackupPayload($raw) {
    $d = normalizeBackupArray($raw);
    if (isset($d['table_data']) && is_array($d['table_data'])) {
        $d = $d['table_data'];
    }

    // Accept nested structures from other systems, e.g. { data: {...} } or { payload: {...} }.
    $root = normalizeBackupArray(pickBackupValue($d, ['data', 'payload', 'backup', 'db'], $d));
    if (!$root) $root = $d;

    // Unified keys expected by performRestoreLogic.
    $map = [
        'products' => ['products', 'items', 'inventory_items'],
        'categories' => ['categories', 'product_categories', 'inventory_categories'],
        'companies' => ['companies', 'suppliers', 'vendors'],
        'sales' => ['sales', 'invoices', 'sales_invoices', 'orders'],
        'customers' => ['customers', 'clients'],
        'expenses' => ['expenses', 'expense', 'costs'],
        'users' => ['users', 'staff', 'employees', 'cashiers'],
        'tables' => ['tables', 'pos_tables'],
        'settings' => ['settings', 'config', 'preferences'],
        'supplies' => ['supplies', 'purchases', 'purchase_items'],
        'ledger' => ['ledger', 'company_ledger', 'transactions'],
        'customer_ledger' => ['customer_ledger', 'customerLedger', 'client_ledger'],
        'waste' => ['waste', 'damages', 'losses'],
        'recipes' => ['recipes', 'formula', 'recipe_items'],
        'shifts' => ['shifts', 'sessions', 'work_shifts'],
        'returns' => ['returns', 'sales_returns'],
        'purchase_returns' => ['purchase_returns', 'supplier_returns'],
        'deliveries' => ['deliveries', 'delivery_orders'],
        'drivers' => ['drivers', 'delivery_drivers'],
        'logs' => ['logs', 'audit_logs'],
        'print_log' => ['print_log', 'printing_logs'],
        'sales_archive' => ['sales_archive'],
        'expenses_archive' => ['expenses_archive'],
        'stock_movements' => ['stock_movements', 'warehouse_movements'],
        'stock_batches' => ['stock_batches'],
        'warehouses' => ['warehouses'],
        'warehouse_stock' => ['warehouse_stock'],
        'stock_transfers' => ['stock_transfers'],
        'stock_transfer_lines' => ['stock_transfer_lines'],
        'manufacturers' => ['manufacturers'],
        'customer_installment_plans' => ['customer_installment_plans', 'installment_plans'],
        'customer_installment_items' => ['customer_installment_items', 'installment_items'],
        'company_documents' => ['company_documents'],
        'exchange_rate_history' => ['exchange_rate_history'],
        'pos_notifications' => ['pos_notifications'],
        'pos_notification_reads' => ['pos_notification_reads'],
        'system_snapshots' => ['system_snapshots']
    ];

    $normalized = [];
    foreach ($map as $target => $aliases) {
        $val = pickBackupValue($root, $aliases, []);
        $normalized[$target] = normalizeBackupArray($val);
    }

    // Preserve simple scalar settings aliases if settings array is missing.
    if (empty($normalized['settings'])) {
        $settingsFallback = pickBackupValue($root, ['app_settings', 'system_settings'], []);
        $normalized['settings'] = normalizeBackupArray($settingsFallback);
    }

    // Merge top-level metadata if present.
    if (isset($root['today_stats'])) $normalized['today_stats'] = normalizeBackupArray($root['today_stats']);
    if (isset($root['session_user'])) $normalized['session_user'] = $root['session_user'];

    return $normalized;
}

/**
 * Detect modern export JSON: keys under table_data match real MySQL table names (same as ZIP inner DB).
 * Legacy JSON uses semantic keys only (products, sales, …) without a sql-shaped table_data map.
 */
function backupPayloadUsesSqlTableData($conn, $raw) {
    if (!is_array($raw) || !isset($raw['table_data']) || !is_array($raw['table_data'])) {
        return false;
    }
    foreach ($raw['table_data'] as $tableName => $rows) {
        if (!is_string($tableName) || $tableName === '') {
            continue;
        }
        $exists = $conn->query("SHOW TABLES LIKE '" . $conn->real_escape_string($tableName) . "'");
        if ($exists && $exists->num_rows > 0) {
            return true;
        }
    }
    return false;
}

function pos_backup_restore_merge_tables() {
    return ['products', 'categories', 'manufacturers'];
}

/**
 * Convert legacy / semantic settings blob into SQL settings rows.
 */
function pos_coerce_settings_table_rows($settings) {
    if (!is_array($settings) || empty($settings)) {
        return [];
    }
    if (isset($settings[0]) && is_array($settings[0]) && array_key_exists('setting_key', $settings[0])) {
        return array_values(array_filter($settings, 'is_array'));
    }
    if (array_key_exists('setting_key', $settings) && array_key_exists('setting_value', $settings)) {
        return [$settings];
    }
    $rows = [];
    $looksKeyed = true;
    foreach ($settings as $k => $v) {
        if (!is_string($k) || is_numeric($k)) {
            $looksKeyed = false;
            break;
        }
        if (is_array($v) && array_key_exists('setting_key', $v)) {
            $rows[] = $v;
            continue;
        }
        $rows[] = [
            'setting_key' => $k,
            'setting_value' => is_string($v) ? $v : json_encode($v, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE),
        ];
    }
    if ($looksKeyed && $rows) {
        return $rows;
    }
    return [[
        'setting_key' => 'app_settings',
        'setting_value' => json_encode($settings, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE),
    ]];
}

/**
 * Prefer generic SQL restore for legacy semantic backups too (covers warehouses, transfers, …).
 */
function pos_normalized_to_sql_table_data($conn, array $normalized) {
    $existing = [];
    if (function_exists('getBackupTableList')) {
        $existing = array_flip(getBackupTableList($conn));
    }
    $aliasToTable = [
        'logs' => 'audit_logs',
        'warehouse_movements' => 'stock_movements',
    ];
    $skipKeys = ['today_stats' => true, 'session_user' => true];
    $tableData = [];
    foreach ($normalized as $key => $rows) {
        if (isset($skipKeys[$key]) || !is_array($rows)) {
            continue;
        }
        $table = $aliasToTable[$key] ?? $key;
        if ($existing && !isset($existing[$table])) {
            continue;
        }
        if ($table === 'settings') {
            $coerced = pos_coerce_settings_table_rows($rows);
            if ($coerced) {
                $tableData['settings'] = $coerced;
            }
            continue;
        }
        if ($rows === []) {
            $tableData[$table] = [];
            continue;
        }
        // List of row arrays
        if (isset($rows[0]) && is_array($rows[0])) {
            $tableData[$table] = array_values(array_filter($rows, 'is_array'));
            continue;
        }
        // Single associative row
        $isAssocRow = false;
        foreach ($rows as $v) {
            if (!is_array($v)) {
                $isAssocRow = true;
                break;
            }
        }
        if ($isAssocRow) {
            $tableData[$table] = [$rows];
        }
    }
    return $tableData;
}

/**
 * Merge one or more loaded backup packages (Telegram part1 + part2).
 */
function pos_merge_restore_loads(array $loads) {
    if (count($loads) === 0) {
        throw new Exception('هیچ فایلی بک‌ئەپ نەدۆزرایەوە.');
    }
    if (count($loads) === 1) {
        return $loads[0];
    }

    // Items merge from many shops: concatenate in file order (batch1 first wins on barcode).
    if (function_exists('pos_backup_restore_is_merge') && pos_backup_restore_is_merge()
        && function_exists('pos_merge_items_catalog_loads')) {
        return pos_merge_items_catalog_loads($loads);
    }

    $mergedTableData = [];
    $partsSeen = [];
    $partsTotal = 0;
    $zipKeep = null;
    $mode = 'package';
    $meta = [
        '_backup_at' => date('Y-m-d H:i:s'),
        '_version' => 2,
        '_format' => 'full_zip_package_v2',
        '_restored_from_parts' => true,
    ];

    foreach ($loads as $idx => $loaded) {
        $data = $loaded['data'] ?? [];
        if (!is_array($data)) {
            throw new Exception('فایلی بک‌ئەپ #' . ($idx + 1) . ' نادروستە.');
        }
        $td = null;
        if (isset($data['table_data']) && is_array($data['table_data'])) {
            $td = $data['table_data'];
        } elseif (($loaded['mode'] ?? '') === 'legacy') {
            // Will be converted later if needed — store as-is under semantic keys only if table_data missing
            throw new Exception('بۆ یەکگرتنی part1+part2 پێویستە هەردوو فایل ZIP/JSON مۆدێرن بن (table_data).');
        }
        if (!is_array($td)) {
            throw new Exception('فایلی بک‌ئەپ #' . ($idx + 1) . ' table_data نییە.');
        }
        $part = (int)($data['_backup_part'] ?? 0);
        $total = (int)($data['_backup_parts_total'] ?? 0);
        if ($part > 0) {
            if (isset($partsSeen[$part])) {
                throw new Exception("هەمان part{$part} دووجار هەڵبژێردرا — part1 و part2 جیاواز هەڵبژێرە.");
            }
            $partsSeen[$part] = true;
            if ($total > $partsTotal) {
                $partsTotal = $total;
            }
        }
        foreach ($td as $table => $rows) {
            $table = trim((string)$table);
            if ($table === '' || !is_array($rows)) {
                continue;
            }
            if (!isset($mergedTableData[$table])) {
                $mergedTableData[$table] = $rows;
            } elseif (count($rows) > count($mergedTableData[$table])) {
                $mergedTableData[$table] = $rows;
            }
        }
        if (($loaded['mode'] ?? '') === 'package' && isset($loaded['zip']) && $loaded['zip'] instanceof ZipArchive) {
            if ($zipKeep instanceof ZipArchive) {
                @$loaded['zip']->close();
            } else {
                $zipKeep = $loaded['zip'];
                $mode = 'package';
            }
        } elseif (($loaded['mode'] ?? '') === 'legacy') {
            $mode = 'legacy';
        }
    }

    if ($partsTotal > 0) {
        for ($p = 1; $p <= $partsTotal; $p++) {
            if (empty($partsSeen[$p])) {
                throw new Exception("بک‌ئەپی پارچەکراو ناتەواوە — part{$p} لە {$partsTotal} کەمە. هەردوو فایل پێکەوە هەڵبژێرە.");
            }
        }
    } elseif (count($partsSeen) > 0 && count($partsSeen) < 2) {
        throw new Exception('بک‌ئەپی پارچەکراو ناتەواوە — part1 و part2 پێکەوە هەڵبژێرە.');
    }

    $meta['table_data'] = $mergedTableData;
    $meta['table_counts'] = [];
    foreach ($mergedTableData as $t => $rows) {
        $meta['table_counts'][$t] = is_array($rows) ? count($rows) : 0;
    }
    $meta['_backup_parts_merged'] = array_keys($partsSeen);
    $meta['_backup_parts_total'] = $partsTotal > 0 ? $partsTotal : count($partsSeen);

    return [
        'mode' => $mode,
        'data' => $meta,
        'manifest' => null,
        'zip' => $zipKeep,
        'files_restored' => 0,
    ];
}

/**
 * Multi-shop items merge: keep batch order (file1 then file2…); first barcode/name wins.
 */
function pos_merge_items_catalog_loads(array $loads) {
    $merged = [
        'products' => [],
        'categories' => [],
        'manufacturers' => [],
        'recipes' => [],
    ];
    $mode = 'package';

    foreach ($loads as $idx => $loaded) {
        $data = $loaded['data'] ?? [];
        if (!is_array($data)) {
            throw new Exception('فایلی ئایتم #' . ($idx + 1) . ' نادروستە.');
        }
        $td = [];
        if (function_exists('pos_normalize_decoded_backup')) {
            $norm = pos_normalize_decoded_backup($data);
            if (is_array($norm) && isset($norm['table_data']) && is_array($norm['table_data'])) {
                $td = $norm['table_data'];
            }
        }
        if (!$td && isset($data['table_data']) && is_array($data['table_data'])) {
            $td = $data['table_data'];
        } elseif (!$td) {
            foreach (['products', 'categories', 'manufacturers', 'recipes'] as $k) {
                if (!empty($data[$k]) && is_array($data[$k])) {
                    $td[$k] = $data[$k];
                }
            }
        }
        if (!$td) {
            throw new Exception('فایلی ئایتم #' . ($idx + 1) . ' table_data / products نییە.');
        }
        foreach (['products', 'categories', 'manufacturers', 'recipes'] as $table) {
            if (empty($td[$table]) || !is_array($td[$table])) continue;
            foreach ($td[$table] as $row) {
                if (is_array($row)) $merged[$table][] = $row;
            }
        }
        if (($loaded['mode'] ?? '') === 'legacy') $mode = 'legacy';
        if (function_exists('pos_backup_close_loaded_package')) {
            pos_backup_close_loaded_package($loaded);
        } elseif (isset($loaded['zip']) && $loaded['zip'] instanceof ZipArchive) {
            @$loaded['zip']->close();
        }
    }

    if (function_exists('pos_prepare_merge_items_table_data')) {
        $merged = pos_prepare_merge_items_table_data($merged);
    }

    $counts = [];
    foreach ($merged as $t => $rows) {
        $counts[$t] = is_array($rows) ? count($rows) : 0;
    }

    return [
        'mode' => $mode,
        'data' => [
            '_backup_at' => date('Y-m-d H:i:s'),
            '_version' => 2,
            '_format' => 'items_catalog_merge_v1',
            '_restored_from_parts' => true,
            '_note' => 'Multi-shop items merge: first file wins on barcode/name; qty=0; no expiry.',
            'table_data' => $merged,
            'table_counts' => $counts,
        ],
        'manifest' => null,
        'zip' => null,
        'files_restored' => 0,
    ];
}

/**
 * Prepare products for merge: qty=0, clear dates, first-wins dedupe, sort by category+name.
 */
function pos_prepare_merge_items_table_data(array $tableData) {
    $out = [];

    if (!empty($tableData['categories']) && is_array($tableData['categories'])) {
        $seenCat = [];
        $cats = [];
        foreach ($tableData['categories'] as $row) {
            if (!is_array($row)) continue;
            $name = trim((string)($row['name'] ?? ''));
            if ($name === '') continue;
            $key = mb_strtolower($name, 'UTF-8');
            if (isset($seenCat[$key])) continue;
            $seenCat[$key] = true;
            unset($row['id']);
            $cats[] = $row;
        }
        usort($cats, function ($a, $b) {
            return strcasecmp((string)($a['name'] ?? ''), (string)($b['name'] ?? ''));
        });
        $out['categories'] = $cats;
    }

    if (!empty($tableData['manufacturers']) && is_array($tableData['manufacturers'])) {
        $seenMfr = [];
        $mfrs = [];
        foreach ($tableData['manufacturers'] as $row) {
            if (!is_array($row)) continue;
            $name = trim((string)($row['name'] ?? ''));
            if ($name === '') continue;
            $key = mb_strtolower($name, 'UTF-8');
            if (isset($seenMfr[$key])) continue;
            $seenMfr[$key] = true;
            unset($row['id']);
            $mfrs[] = $row;
        }
        usort($mfrs, function ($a, $b) {
            return strcasecmp((string)($a['name'] ?? ''), (string)($b['name'] ?? ''));
        });
        $out['manufacturers'] = $mfrs;
    }

    if (!empty($tableData['products']) && is_array($tableData['products'])) {
        $seenBc = [];
        $seenName = [];
        $products = [];
        foreach ($tableData['products'] as $row) {
            if (!is_array($row)) continue;
            $name = trim((string)($row['name'] ?? ''));
            if ($name === '') continue;

            $barcodes = [];
            foreach (['barcode', 'barcode_pack', 'barcode_carton'] as $bk) {
                $bc = trim((string)($row[$bk] ?? ''));
                if ($bc !== '' && $bc !== '0') $barcodes[] = $bc;
            }
            $dup = false;
            foreach ($barcodes as $bc) {
                $bk = mb_strtolower($bc, 'UTF-8');
                if (isset($seenBc[$bk])) {
                    $dup = true;
                    break;
                }
            }
            $nk = mb_strtolower($name, 'UTF-8');
            if (!$dup && isset($seenName[$nk])) {
                $dup = true;
            }
            if ($dup) continue;

            foreach ($barcodes as $bc) {
                $seenBc[mb_strtolower($bc, 'UTF-8')] = true;
            }
            $seenName[$nk] = true;

            $row['qty'] = 0;
            $row['expiry'] = '';
            if (array_key_exists('expiry_date', $row)) $row['expiry_date'] = '';
            if (array_key_exists('created_at', $row)) $row['created_at'] = null;
            if (array_key_exists('updated_at', $row)) $row['updated_at'] = null;
            $row['catalog_only'] = 1;
            unset($row['id']);
            $products[] = $row;
        }
        usort($products, function ($a, $b) {
            $ca = (string)($a['category'] ?? $a['cat'] ?? '');
            $cb = (string)($b['category'] ?? $b['cat'] ?? '');
            $c = strcasecmp($ca, $cb);
            if ($c !== 0) return $c;
            return strcasecmp((string)($a['name'] ?? ''), (string)($b['name'] ?? ''));
        });
        $out['products'] = $products;
    }

    if (!empty($tableData['recipes']) && is_array($tableData['recipes'])) {
        $out['recipes'] = $tableData['recipes'];
    }

    return $out;
}

/**
 * Block restoring a single Telegram split part (would wipe the other half).
 * For full modern packages, require critical business tables when they exist in MySQL.
 */
function pos_assert_restore_payload_complete($conn, array $loaded) {
    if (pos_backup_restore_is_merge()) {
        return;
    }
    $data = $loaded['data'] ?? [];
    if (!is_array($data)) {
        throw new Exception('فایلی بک‌ئەپ نادروستە.');
    }
    $part = (int)($data['_backup_part'] ?? 0);
    $total = (int)($data['_backup_parts_total'] ?? 0);
    $merged = $data['_backup_parts_merged'] ?? null;
    if (is_array($merged) && $merged) {
        // Already merged — completeness checked in pos_merge_restore_loads.
        $part = 0;
    }
    if ($part > 0 && $total > 1) {
        throw new Exception(
            "ئەم فایلە تەنها part{$part} لە {$total} ـە. بۆ ڕیستۆری تەواو هەردوو فایل (part1 و part2) پێکەوە هەڵبژێرە."
        );
    }
    if ($part > 0 && $total <= 1) {
        throw new Exception(
            "ئەم فایلە پارچەیەکی ناتەواوە (part{$part}). فایلی تەواوی بک‌ئەپ یان part1+part2 پێکەوە بەکاربهێنە."
        );
    }

    $td = $data['table_data'] ?? null;
    if (!is_array($td)) {
        return;
    }
    $format = (string)($data['_format'] ?? '');
    $isModernFull = ($format === 'full_zip_package_v2' || $format === 'posbak_gzip_v1' || !empty($data['_version']) || is_array($merged));
    if (!$isModernFull) {
        return;
    }
    if (function_exists('pos_verify_backup_payload')) {
        $verify = pos_verify_backup_payload(['table_data' => $td, 'table_counts' => $data['table_counts'] ?? []], $conn);
        if (empty($verify['ok'])) {
            $missing = $verify['missing'] ?? [];
            throw new Exception(
                'بک‌ئەپ ناتەواوە بۆ ڕیستۆر — خشتە کەمن: ' . implode(', ', $missing)
                . '. ئەگەر لە تیلیگرام part1/part2ـە، هەردووکیان پێکەوە هەڵبژێرە.'
            );
        }
    }
}

/**
 * Collect uploaded / local backup file paths for restore (supports multi-file part1+part2).
 * @return array<int, array{0:string,1:string}> list of [tmpPath, fileName]
 */
function pos_collect_restore_upload_sources() {
    $sources = [];
    if (!empty($_POST['backup_name']) && function_exists('pos_resolve_local_backup_path')) {
        $names = $_POST['backup_name'];
        if (!is_array($names)) {
            $names = [$names];
        }
        if (!empty($_POST['backup_name2'])) {
            $names[] = $_POST['backup_name2'];
        }
        foreach ($names as $name) {
            $name = trim((string)$name);
            if ($name === '') {
                continue;
            }
            $tmp = pos_resolve_local_backup_path($name);
            $sources[] = [$tmp, basename($tmp)];
        }
        return $sources;
    }

    $appendFile = function ($fileArr) use (&$sources) {
        if (!is_array($fileArr) || empty($fileArr['tmp_name'])) {
            return;
        }
        if (is_array($fileArr['tmp_name'])) {
            $n = count($fileArr['tmp_name']);
            for ($i = 0; $i < $n; $i++) {
                $tmp = $fileArr['tmp_name'][$i] ?? '';
                $name = $fileArr['name'][$i] ?? ('backup_' . $i);
                $err = (int)($fileArr['error'][$i] ?? UPLOAD_ERR_NO_FILE);
                if ($tmp === '' || $err !== UPLOAD_ERR_OK) {
                    continue;
                }
                $sources[] = [$tmp, $name];
            }
            return;
        }
        $err = (int)($fileArr['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($err === UPLOAD_ERR_OK && $fileArr['tmp_name'] !== '') {
            $sources[] = [$fileArr['tmp_name'], $fileArr['name'] ?? 'backup.zip'];
        }
    };

    if (isset($_FILES['file'])) {
        $appendFile($_FILES['file']);
    }
    if (isset($_FILES['file2'])) {
        $appendFile($_FILES['file2']);
    }
    return $sources;
}

function pos_truncate_all_database_tables($conn) {
    $conn->query('SET FOREIGN_KEY_CHECKS = 0');
    foreach (getBackupTableList($conn) as $table) {
        $tableEsc = str_replace('`', '``', $table);
        $conn->query("TRUNCATE TABLE `{$tableEsc}`");
    }
    $conn->query('SET FOREIGN_KEY_CHECKS = 1');
}

function pos_backup_restore_is_merge() {
    return isset($_POST['merge_items']) && (string)$_POST['merge_items'] === '1';
}

/**
 * Merge items: lenient (qty may be forced 0, expiry optional).
 * Full restore: strict — name, price, qty for tracked stock, valid expiry when provided.
 */
function pos_validate_backup_product_row(array $row, int $index, bool $isMerge) {
    $name = trim((string)($row['name'] ?? ''));
    $label = $name !== '' ? $name : ('#' . $index);
    if ($name === '') {
        throw new Exception("ئایتم {$label}: ناو پێویستە.");
    }
    if ($isMerge) {
        return;
    }
    if (!isset($row['price']) || !is_numeric($row['price']) || (float)$row['price'] < 0) {
        throw new Exception("ئایتم «{$label}»: نرخ دروست نییە.");
    }
    if (!isset($row['cost']) || !is_numeric($row['cost']) || (float)$row['cost'] < 0) {
        $row['cost'] = 0;
    }
    if (!array_key_exists('qty', $row) || $row['qty'] === '' || !is_numeric($row['qty'])) {
        throw new Exception("ئایتم «{$label}»: عەدەد (qty) پێویستە و دەبێت ژمارە بێت.");
    }
    if ((float)$row['qty'] < 0) {
        $row['qty'] = 0;
    }
    $expiryRaw = trim((string)($row['expiry'] ?? ''));
    if ($expiryRaw !== '' && $expiryRaw !== '0' && !preg_match('/^0000-00-00/', $expiryRaw)) {
        $san = function_exists('pos_sanitize_expiry_for_restore')
            ? pos_sanitize_expiry_for_restore($expiryRaw)
            : (function_exists('normalizeProductCatalogExpiry') ? normalizeProductCatalogExpiry($expiryRaw) : '');
        // Invalid expiry in backup → treat as no expiry (restore continues).
        if ($san === '' && $expiryRaw !== '') {
            return;
        }
    }
}

function pos_validate_backup_stock_batch_row(array $row, int $index, bool $isMerge) {
    if ($isMerge) {
        return;
    }
    $qty = (float)($row['qty'] ?? 0);
    if ($qty <= 0) {
        return;
    }
    $expiry = trim((string)($row['expiry_date'] ?? ''));
    $san = function_exists('pos_sanitize_expiry_for_restore')
        ? pos_sanitize_expiry_for_restore($expiry)
        : (function_exists('isValidYmdDate') && isValidYmdDate($expiry) ? $expiry : '');
    if ($san === '') {
        return;
    }
    if (!isset($row['product_id']) || (int)$row['product_id'] <= 0) {
        throw new Exception("Batch #{$index}: product_id پێویستە.");
    }
}

function pos_sanitize_backup_product_row(array &$row) {
    if (!array_key_exists('qty', $row) || $row['qty'] === '' || !is_numeric($row['qty'])) {
        $row['qty'] = 0;
    } else {
        $row['qty'] = max(0, (float)$row['qty']);
    }
    foreach (['price', 'cost', 'takeawayPrice', 'takeawayPrice_pack', 'takeawayPrice_carton', 'wholesalePrice', 'price_pack', 'price_carton', 'cost_pack', 'cost_carton'] as $numKey) {
        if (!array_key_exists($numKey, $row)) continue;
        if ($row[$numKey] === '' || $row[$numKey] === null || !is_numeric($row[$numKey])) {
            $row[$numKey] = 0;
        } else {
            $row[$numKey] = max(0, (float)$row[$numKey]);
        }
    }
    if (array_key_exists('expiry', $row)) {
        $row['expiry'] = function_exists('pos_sanitize_expiry_for_restore')
            ? pos_sanitize_expiry_for_restore($row['expiry'] ?? '')
            : (function_exists('normalizeProductCatalogExpiry') ? normalizeProductCatalogExpiry($row['expiry'] ?? '') : '');
    }
}

function pos_sanitize_backup_table_data(array &$tableData) {
    if (isset($tableData['products']) && is_array($tableData['products'])) {
        foreach ($tableData['products'] as &$row) {
            if (!is_array($row)) continue;
            pos_sanitize_backup_product_row($row);
        }
        unset($row);
    }
    if (isset($tableData['stock_batches']) && is_array($tableData['stock_batches'])) {
        $clean = [];
        foreach ($tableData['stock_batches'] as $row) {
            if (!is_array($row)) continue;
            $qty = (float)($row['qty'] ?? 0);
            if ($qty < 0) $qty = 0;
            $row['qty'] = $qty;
            $exp = function_exists('pos_sanitize_expiry_for_restore')
                ? pos_sanitize_expiry_for_restore($row['expiry_date'] ?? '')
                : '';
            $row['expiry_date'] = $exp;
            if ($qty <= 0.000001) {
                continue;
            }
            $clean[] = $row;
        }
        $tableData['stock_batches'] = $clean;
    }
    if (isset($tableData['supplies']) && is_array($tableData['supplies'])) {
        foreach ($tableData['supplies'] as &$row) {
            if (!is_array($row)) continue;
            if (array_key_exists('expiry_date', $row)) {
                $row['expiry_date'] = function_exists('pos_sanitize_expiry_for_restore')
                    ? pos_sanitize_expiry_for_restore($row['expiry_date'] ?? '')
                    : '';
            }
        }
        unset($row);
    }
}

function pos_validate_full_restore_payload($conn, array $loaded) {
    if (pos_backup_restore_is_merge()) {
        return;
    }
    $isMerge = false;
    if (($loaded['mode'] ?? '') === 'package') {
        if (!is_array($loaded['data']['table_data'] ?? null)) {
            throw new Exception('داتای backup نادروستە (table_data).');
        }
        pos_sanitize_backup_table_data($loaded['data']['table_data']);
        $tableData = $loaded['data']['table_data'];
        if (isset($tableData['products']) && is_array($tableData['products'])) {
            $i = 0;
            foreach ($tableData['products'] as $row) {
                $i++;
                if (!is_array($row)) continue;
                pos_validate_backup_product_row($row, $i, $isMerge);
            }
        }
        if (isset($tableData['stock_batches']) && is_array($tableData['stock_batches'])) {
            $i = 0;
            foreach ($tableData['stock_batches'] as $row) {
                $i++;
                if (!is_array($row)) continue;
                pos_validate_backup_stock_batch_row($row, $i, $isMerge);
            }
        }
        return;
    }
    $raw = $loaded['data'] ?? [];
    if (!is_array($raw)) {
        throw new Exception('فایلی backup نادروستە.');
    }
    if (backupPayloadUsesSqlTableData($conn, $raw)) {
        if (!is_array($raw['table_data'] ?? null)) {
            throw new Exception('داتای backup نادروستە (table_data).');
        }
        pos_sanitize_backup_table_data($raw['table_data']);
        $tableData = $raw['table_data'];
        if (isset($tableData['products']) && is_array($tableData['products'])) {
            $i = 0;
            foreach ($tableData['products'] as $row) {
                $i++;
                if (!is_array($row)) continue;
                pos_validate_backup_product_row($row, $i, $isMerge);
            }
        }
        if (isset($tableData['stock_batches']) && is_array($tableData['stock_batches'])) {
            $i = 0;
            foreach ($tableData['stock_batches'] as $row) {
                $i++;
                if (!is_array($row)) continue;
                pos_validate_backup_stock_batch_row($row, $i, $isMerge);
            }
        }
        return;
    }
    $data = normalizeBackupPayload($raw);
    if (!empty($data['products']) && is_array($data['products'])) {
        $legacyWrap = ['products' => $data['products']];
        if (!empty($data['stock_batches']) && is_array($data['stock_batches'])) {
            $legacyWrap['stock_batches'] = $data['stock_batches'];
        }
        pos_sanitize_backup_table_data($legacyWrap);
        $data['products'] = $legacyWrap['products'];
        if (isset($legacyWrap['stock_batches'])) {
            $data['stock_batches'] = $legacyWrap['stock_batches'];
        }
        $i = 0;
        foreach ($data['products'] as $row) {
            $i++;
            if (!is_array($row)) continue;
            pos_validate_backup_product_row($row, $i, $isMerge);
        }
    }
    if (!empty($data['stock_batches']) && is_array($data['stock_batches'])) {
        $i = 0;
        foreach ($data['stock_batches'] as $row) {
            $i++;
            if (!is_array($row)) continue;
            pos_validate_backup_stock_batch_row($row, $i, $isMerge);
        }
    }
}

// --- HELPER: RESTORE LOGIC (Reusable) - backward compatible with old JSON backups ---
function performRestoreLogic($conn, $data) {
    $def = function($arr, $key, $default = null) { return array_key_exists($key, $arr) ? $arr[$key] : $default; };
    
    // Disable Foreign Key checks for a clean wipe and restore
    $conn->query("SET FOREIGN_KEY_CHECKS = 0");

    // 1. Products
    $isMerge = pos_backup_restore_is_merge();
    
    if (!$isMerge) {
        pos_truncate_all_database_tables($conn);
    }
    
    if(!empty($data['products'])) {
        if ($isMerge) {
            $stmt = $conn->prepare("INSERT INTO products (name, barcode, price, cost, qty, category, supplier, trackStock, unitType, qty_mode, itemsPerCarton, forSale, takeawayPrice, takeawayPrice_pack, takeawayPrice_carton, expiry, wholesaleQty, wholesalePrice, pieces_per_pack, packs_per_carton, barcode_pack, barcode_carton, price_pack, price_carton, cost_pack, cost_carton, unit_show_pack, unit_show_carton, isPinned, minStock, item_type, price_usd, cost_usd, price_pack_usd, price_carton_usd, cost_pack_usd, cost_carton_usd, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        } else {
            $stmt = $conn->prepare("INSERT INTO products (id, name, barcode, price, cost, qty, category, supplier, trackStock, unitType, qty_mode, itemsPerCarton, forSale, takeawayPrice, takeawayPrice_pack, takeawayPrice_carton, expiry, wholesaleQty, wholesalePrice, pieces_per_pack, packs_per_carton, barcode_pack, barcode_carton, price_pack, price_carton, cost_pack, cost_carton, unit_show_pack, unit_show_carton, isPinned, minStock, item_type, price_usd, cost_usd, price_pack_usd, price_carton_usd, cost_pack_usd, cost_carton_usd, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        }
        
        $prodIdx = 0;
        foreach($data['products'] as $r) {
            $prodIdx++;
            pos_validate_backup_product_row($r, $prodIdx, $isMerge);
            $id = (int)($def($r, 'id', 0));
            $name = (string)($def($r, 'name', ''));
            $barcode = trim((string)($def($r, 'barcode', '')));
            
            if ($isMerge) {
                $dupSql = "SELECT id FROM products WHERE name = ? OR (barcode != '' AND barcode = ?) LIMIT 1";
                $dupStmt = $conn->prepare($dupSql);
                $dupStmt->bind_param("ss", $name, $barcode);
                $dupStmt->execute();
                $dupRes = $dupStmt->get_result();
                if ($dupRes && $dupRes->num_rows > 0) {
                    continue; // Skip duplicate
                }
            }

            $price = (float)($def($r, 'price', 0));
            $cost = (float)($def($r, 'cost', 0));
            // Merge: catalog only — qty starts at 0. Full restore: preserve backup qty.
            $qty = $isMerge ? 0.0 : (float)($def($r, 'qty', 0));
            $cat = !empty($r['category']) ? $r['category'] : (!empty($r['cat']) ? $r['cat'] : 'General');
            $supplier = (string)($def($r, 'supplier', ''));
            $track = isset($r['trackStock']) ? ($r['trackStock'] ? 1 : 0) : 0;
            $unit = (string)($def($r, 'unitType', 'carton'));
            $itemsPerCarton = (int)($def($r, 'itemsPerCarton', 1));
            $sale = isset($r['forSale']) ? ($r['forSale'] ? 1 : 0) : 1;
            $tkPrice = (float)($def($r, 'takeawayPrice', 0));
            $tkPricePack = (float)($def($r, 'takeawayPrice_pack', 0));
            $tkPriceCarton = (float)($def($r, 'takeawayPrice_carton', 0));
            $expiry = (string)($def($r, 'expiry', ''));
            if (!$isMerge && $expiry !== '') {
                $expiry = function_exists('normalizeProductCatalogExpiry') ? normalizeProductCatalogExpiry($expiry) : $expiry;
            }
            $wsQty = (int)($def($r, 'wholesaleQty', 0));
            $wsPrice = (float)($def($r, 'wholesalePrice', 0));
            $ppp = max(1, (int)($def($r, 'pieces_per_pack', 1)));
            $ppc = max(1, (int)($def($r, 'packs_per_carton', 1)));
            $bpack = trim((string)($def($r, 'barcode_pack', '')));
            $bcart = trim((string)($def($r, 'barcode_carton', '')));
            $prpack = (float)($def($r, 'price_pack', 0));
            $prcart = (float)($def($r, 'price_carton', 0));
            $cpack = (float)($def($r, 'cost_pack', 0));
            $ccart = (float)($def($r, 'cost_carton', 0));
            $unitShowPack = isset($r['unit_show_pack']) ? ((int)$r['unit_show_pack'] ? 1 : 0) : 1;
            $unitShowCarton = isset($r['unit_show_carton']) ? ((int)$r['unit_show_carton'] ? 1 : 0) : 1;
            $qtyMode = strtolower(trim((string)($def($r, 'qty_mode', $def($r, 'measure_mode', '')))));
            if ($qtyMode !== 'piece' && $qtyMode !== 'kilo') $qtyMode = ($unit === 'kilo' || ($unitShowPack === 0 && $unitShowCarton === 0)) ? 'kilo' : 'piece';
            $isPinned = isset($r['isPinned']) ? ($r['isPinned'] ? 1 : 0) : 0;
            $minStock = (int)($def($r, 'minStock', 5));
            $itemType = (string)($def($r, 'item_type', 'constant'));
            $isActive = isset($r['is_active']) ? ($r['is_active'] ? 1 : 0) : 1;
            $ruPriceUsd = (isset($r['price_usd']) && $r['price_usd'] !== '' && $r['price_usd'] !== null) ? (float)$r['price_usd'] : null;
            $ruCostUsd = (isset($r['cost_usd']) && $r['cost_usd'] !== '' && $r['cost_usd'] !== null) ? (float)$r['cost_usd'] : null;
            $ruPackUsd = (isset($r['price_pack_usd']) && $r['price_pack_usd'] !== '' && $r['price_pack_usd'] !== null) ? (float)$r['price_pack_usd'] : null;
            $ruCartonUsd = (isset($r['price_carton_usd']) && $r['price_carton_usd'] !== '' && $r['price_carton_usd'] !== null) ? (float)$r['price_carton_usd'] : null;
            $ruCostPackUsd = (isset($r['cost_pack_usd']) && $r['cost_pack_usd'] !== '' && $r['cost_pack_usd'] !== null) ? (float)$r['cost_pack_usd'] : null;
            $ruCostCartonUsd = (isset($r['cost_carton_usd']) && $r['cost_carton_usd'] !== '' && $r['cost_carton_usd'] !== null) ? (float)$r['cost_carton_usd'] : null;

            if ($isMerge) {
                $stmt->bind_param("ssdddssissiidsddidiissddddiiiisddddddi", $name, $barcode, $price, $cost, $qty, $cat, $supplier, $track, $unit, $qtyMode, $itemsPerCarton, $sale, $tkPrice, $tkPricePack, $tkPriceCarton, $expiry, $wsQty, $wsPrice, $ppp, $ppc, $bpack, $bcart, $prpack, $prcart, $cpack, $ccart, $unitShowPack, $unitShowCarton, $isPinned, $minStock, $itemType, $ruPriceUsd, $ruCostUsd, $ruPackUsd, $ruCartonUsd, $ruCostPackUsd, $ruCostCartonUsd, $isActive);
            } else {
                $stmt->bind_param("issdddssissiidsddidiissddddiiiisddddddi", $id, $name, $barcode, $price, $cost, $qty, $cat, $supplier, $track, $unit, $qtyMode, $itemsPerCarton, $sale, $tkPrice, $tkPricePack, $tkPriceCarton, $expiry, $wsQty, $wsPrice, $ppp, $ppc, $bpack, $bcart, $prpack, $prcart, $cpack, $ccart, $unitShowPack, $unitShowCarton, $isPinned, $minStock, $itemType, $ruPriceUsd, $ruCostUsd, $ruPackUsd, $ruCartonUsd, $ruCostPackUsd, $ruCostCartonUsd, $isActive);
            }
            $stmt->execute();
        }
    }

    // 2. Categories
    if (!$isMerge) {
        $conn->query("TRUNCATE TABLE categories");
    }
    if(!empty($data['categories'])) {
        $stmt = $conn->prepare("INSERT IGNORE INTO categories (name) VALUES (?)");
        foreach($data['categories'] as $c) {
            $catName = is_array($c) ? ($c['name'] ?? ($c['cat'] ?? '')) : $c;
            if(!empty($catName)) { $stmt->bind_param("s", $catName); $stmt->execute(); }
        }
    }

    // 3. Companies
    if (!$isMerge) {
        $conn->query("TRUNCATE TABLE companies");
    }
    if(!empty($data['companies'])) {
        if ($isMerge) {
            $stmt = $conn->prepare("INSERT INTO companies (name, phone, address, balance, is_active) VALUES (?, ?, ?, ?, ?)");
        } else {
            $stmt = $conn->prepare("INSERT INTO companies (id, name, phone, address, balance, is_active) VALUES (?, ?, ?, ?, ?, ?)");
        }
        
        foreach($data['companies'] as $r) {
            $id = (int)($def($r, 'id', 0));
            $name = (string)($def($r, 'name', ''));
            
            if ($isMerge) {
                $dupSql = "SELECT id FROM companies WHERE name = ? LIMIT 1";
                $dupStmt = $conn->prepare($dupSql);
                $dupStmt->bind_param("s", $name);
                $dupStmt->execute();
                $dupRes = $dupStmt->get_result();
                if ($dupRes && $dupRes->num_rows > 0) {
                    continue; // Skip duplicate
                }
            }

            $phone = (string)($def($r, 'phone', ''));
            $address = (string)($def($r, 'address', ''));
            $balance = (float)($def($r, 'balance', 0));
            $isActive = isset($r['is_active']) ? ($r['is_active'] ? 1 : 0) : 1;
            
            if ($isMerge) {
                $stmt->bind_param("sssdi", $name, $phone, $address, $balance, $isActive);
            } else {
                $stmt->bind_param("isssdi", $id, $name, $phone, $address, $balance, $isActive);
            }
            $stmt->execute();
        }
    }

    // 4. Sales
    if (!$isMerge) {
        $conn->query("TRUNCATE TABLE sales");
    }
    if(!empty($data['sales'])) {
        $stmt = $conn->prepare("INSERT INTO sales (id, total, discount, items_json, created_at, cashier, payment_method, customer_id, customer_type, is_returned, transaction_id, fx_usd_rate, fx_currency_mode) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CAST(NULLIF(?, '') AS UNSIGNED), NULLIF(?, ''))");
        foreach($data['sales'] as $r) {
            $items = is_string($def($r, 'items_json', '')) ? $r['items_json'] : json_encode($def($r, 'items', []));
            $date = (string)($def($r, 'date', $def($r, 'created_at', date('Y-m-d H:i:s'))));
            $pm = (string)($def($r, 'payment_method', 'cash'));
            $cid = (int)($def($r, 'customer_id', 0));
            $ct = (string)($def($r, 'customer_type', 'customer'));
            $isRet = (int)($def($r, 'is_returned', 0));
            $tid = (string)($def($r, 'transaction_id', ''));
            $fxRaw = isset($r['fx_usd_rate']) ? (int)$r['fx_usd_rate'] : 0;
            if ($fxRaw < 1000 || $fxRaw > 50000000) {
                $fxRaw = 0;
            }
            $fxRateStr = $fxRaw > 0 ? (string)$fxRaw : '';
            $fxModeStr = '';
            if (isset($r['fx_currency_mode'])) {
                $m = strtoupper(trim((string)$r['fx_currency_mode']));
                if ($m === 'USD' || $m === 'IQD') {
                    $fxModeStr = $m;
                }
            }
            $stmt->bind_param("iddssssisisss", (int)($def($r, 'id', 0)), (float)($def($r, 'total', 0)), (float)($def($r, 'discount', 0)), $items, $date, (string)($def($r, 'cashier', '')), $pm, $cid, $ct, $isRet, $tid, $fxRateStr, $fxModeStr);
            $stmt->execute();
        }
    }

    // 5. Customers
    $conn->query("TRUNCATE TABLE customers");
    if(!empty($data['customers'])) {
        $stmt = $conn->prepare("INSERT INTO customers (id, name, phone, address, balance, debt_limit, opening_balance, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        foreach($data['customers'] as $r) {
            $isActive = isset($r['is_active']) ? ($r['is_active'] ? 1 : 0) : 1;
            $stmt->bind_param("isssdddi", (int)($def($r, 'id', 0)), (string)($def($r, 'name', '')), (string)($def($r, 'phone', '')), (string)($def($r, 'address', '')), (float)($def($r, 'balance', 0)), (float)($def($r, 'debt_limit', 0)), (float)($def($r, 'opening_balance', 0)), $isActive);
            $stmt->execute();
        }
    }

    // 6. Expenses
    $conn->query("TRUNCATE TABLE expenses");
    if(!empty($data['expenses'])) {
        $stmt = $conn->prepare("INSERT INTO expenses (id, note, amount, `date`, user, transaction_id, type) VALUES (?, ?, ?, ?, ?, ?, ?)");
        foreach($data['expenses'] as $r) {
            $stmt->bind_param("isdssss", (int)($def($r, 'id', 0)), (string)($def($r, 'note', '')), (float)($def($r, 'amount', 0)), (string)($def($r, 'date', date('Y-m-d H:i:s'))), (string)($def($r, 'user', '')), (string)($def($r, 'transaction_id', '')), (string)($def($r, 'type', 'operational')));
            $stmt->execute();
        }
    }

    // 7. Ledger
    $conn->query("TRUNCATE TABLE ledger");
    if(!empty($data['ledger'])) {
        $stmt = $conn->prepare("INSERT INTO ledger (id, transaction_id, type, amount, related_id, description, created_at, balance_after, companyId) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        foreach($data['ledger'] as $r) {
            $date = $def($r, 'created_at', $def($r, 'date', date('Y-m-d H:i:s')));
            $desc = $def($r, 'description', $def($r, 'note', ''));
            $stmt->bind_param("issdissdd", (int)($def($r, 'id', 0)), (string)($def($r, 'transaction_id', '')), (string)($def($r, 'type', '')), (float)($def($r, 'amount', 0)), (int)($def($r, 'related_id', 0)), (string)$desc, (string)$date, (float)($def($r, 'balance_after', 0)), (int)($def($r, 'companyId', 0)));
            $stmt->execute();
        }
    }

    // 8. Shifts
    $conn->query("TRUNCATE TABLE shifts");
    if(!empty($data['shifts'])) {
        $stmt = $conn->prepare("INSERT INTO shifts (id, userId, userName, startTime, endTime, hourlyRate, opening_balance, closing_balance_expected, closing_balance_actual, shortage, surplus, reconciled_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        foreach($data['shifts'] as $r) {
            $stmt->bind_param("iisssdddddds", (int)($def($r, 'id', 0)), (int)($def($r, 'userId', 0)), (string)($def($r, 'userName', '')), (string)($def($r, 'startTime', '')), (string)($def($r, 'endTime', '')), (float)($def($r, 'hourlyRate', 0)), (float)($def($r, 'opening_balance', 0)), (float)($def($r, 'closing_balance_expected', 0)), (float)($def($r, 'closing_balance_actual', 0)), (float)($def($r, 'shortage', 0)), (float)($def($r, 'surplus', 0)), (string)($def($r, 'reconciled_by', '')));
            $stmt->execute();
        }
    }

    // 9. Waste
    $conn->query("TRUNCATE TABLE waste");
    if(!empty($data['waste'])) {
        $stmt = $conn->prepare("INSERT INTO waste (id, prodId, prodName, qty, cost, reason, date, user) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        foreach($data['waste'] as $r) {
            $stmt->bind_param("iisddsss", (int)($def($r, 'id', 0)), (int)($def($r, 'prodId', 0)), (string)($def($r, 'prodName', '')), (float)($def($r, 'qty', 0)), (float)($def($r, 'cost', 0)), (string)($def($r, 'reason', '')), (string)($def($r, 'date', '')), (string)($def($r, 'user', '')));
            $stmt->execute();
        }
    }

    // 10. Returns
    $conn->query("TRUNCATE TABLE returns");
    if(!empty($data['returns'])) {
        $stmt = $conn->prepare("INSERT INTO returns (id, items_json, total, date, cashier, note, sale_id, payment_method, target_id, target_type, fx_usd_rate, fx_currency_mode) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CAST(NULLIF(?, '') AS UNSIGNED), NULLIF(?, ''))");
        foreach($data['returns'] as $r) {
            $items = is_string($def($r, 'items_json', '')) ? $r['items_json'] : json_encode($def($r, 'items', []));
            $fxRaw = isset($r['fx_usd_rate']) ? (int)$r['fx_usd_rate'] : 0;
            if ($fxRaw < 1000 || $fxRaw > 50000000) {
                $fxRaw = 0;
            }
            $fxRateStr = $fxRaw > 0 ? (string)$fxRaw : '';
            $fxModeStr = '';
            if (isset($r['fx_currency_mode'])) {
                $m = strtoupper(trim((string)$r['fx_currency_mode']));
                if ($m === 'USD' || $m === 'IQD') {
                    $fxModeStr = $m;
                }
            }
            $stmt->bind_param("isdssssisisss", (int)($def($r, 'id', 0)), $items, (float)($def($r, 'total', 0)), (string)($def($r, 'date', '')), (string)($def($r, 'cashier', '')), (string)($def($r, 'note', '')), (int)($def($r, 'sale_id', 0)), (string)($def($r, 'payment_method', 'cash')), (int)($def($r, 'target_id', 0)), (string)($def($r, 'target_type', '')), $fxRateStr, $fxModeStr);
            $stmt->execute();
        }
    }

    // 11. Deliveries
    $conn->query("TRUNCATE TABLE deliveries");
    if(!empty($data['deliveries'])) {
        $stmt = $conn->prepare("INSERT INTO deliveries (id, customer_name, phone, address, driver, driver_phone, delivery_cost, total, status, date, note, items_json, customer_id, driver_id, sale_id, settled_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        foreach($data['deliveries'] as $r) {
            $items = is_string($def($r, 'items_json', '')) ? $r['items_json'] : json_encode($def($r, 'items', []));
            $settled = (string)($def($r, 'settled_at', '') ?: '');
            if ($settled === '') $settled = null;
            $custId = (int)($def($r, 'customer_id', 0));
            $drvId = (int)($def($r, 'driver_id', 0));
            $saleId = (int)($def($r, 'sale_id', 0));
            $stmt->bind_param("isssssddssssiiis", (int)($def($r, 'id', 0)), (string)($def($r, 'customer_name', '')), (string)($def($r, 'phone', '')), (string)($def($r, 'address', '')), (string)($def($r, 'driver', '')), (string)($def($r, 'driver_phone', '')), (float)($def($r, 'delivery_cost', 0)), (float)($def($r, 'total', 0)), (string)($def($r, 'status', '')), (string)($def($r, 'date', '')), (string)($def($r, 'note', '')), $items, $custId, $drvId, $saleId, $settled);
            $stmt->execute();
        }
    }

    $conn->query("TRUNCATE TABLE drivers");
    if(!empty($data['drivers'])) {
        $stmt = $conn->prepare("INSERT INTO drivers (id, name, phone, note, is_active) VALUES (?, ?, ?, ?, ?)");
        foreach($data['drivers'] as $r) {
            if (!is_array($r)) continue;
            $isActive = isset($r['is_active']) ? ((int)$r['is_active'] ? 1 : 0) : 1;
            $stmt->bind_param("isssi", (int)($def($r, 'id', 0)), (string)($def($r, 'name', '')), (string)($def($r, 'phone', '')), (string)($def($r, 'note', '')), $isActive);
            $stmt->execute();
        }
    }

    // 12. Recipes
    $conn->query("TRUNCATE TABLE recipes");
    if(!empty($data['recipes'])) {
        $stmt = $conn->prepare("INSERT INTO recipes (id, product_id, ingredient_id, qty) VALUES (?, ?, ?, ?)");
        foreach($data['recipes'] as $r) {
            $stmt->bind_param("iiid", (int)($def($r, 'id', 0)), (int)($def($r, 'product_id', 0)), (int)($def($r, 'ingredient_id', 0)), (float)($def($r, 'qty', 0)));
            $stmt->execute();
        }
    }

    // 13. Settings
    if(!empty($data['settings'])) {
        $raw = $data['settings'];
        $jsonSettings = is_string($raw) ? $raw : json_encode($raw);
        $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('app_settings', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        $stmt->bind_param("ss", $jsonSettings, $jsonSettings);
        $stmt->execute();
    }

    // 14. Users
    $conn->query("TRUNCATE TABLE users");
    if(!empty($data['users'])) {
        $stmt = $conn->prepare("INSERT INTO users (id, name, pin, role, hourlyRate, permissions, balance, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        foreach($data['users'] as $r) {
            $uid = (int)($def($r, 'id', 0));
            $name = (string)($def($r, 'name', ''));
            $pin = (string)($def($r, 'pin', ''));
            if ($uid == 1 && $pin === '') $pin = '2026';
            $perms = is_string($def($r, 'permissions', '')) ? $r['permissions'] : json_encode($def($r, 'permissions', []));
            $isActive = isset($r['is_active']) ? ($r['is_active'] ? 1 : 0) : 1;
            $role = (string)($def($r, 'role', 'user'));
            if ($uid === 1 || strcasecmp(trim($name), 'Manager') === 0) {
                $role = 'admin';
            }
            $stmt->bind_param("isssdsdi", $uid, $name, $pin, $role, (float)($def($r, 'hourlyRate', 0)), $perms, (float)($def($r, 'balance', 0)), $isActive);
            $stmt->execute();
        }
    }
    if (function_exists('pos_ensure_primary_admin')) {
        pos_ensure_primary_admin($conn);
    }

    // 15. Supplies
    $conn->query("TRUNCATE TABLE supplies");
    if(!empty($data['supplies'])) {
        $stmt = $conn->prepare("INSERT INTO supplies (id, company, prodId, itemName, qtyAdded, totalCost, date, type, transaction_id, supplier_invoice_number, fx_usd_rate, fx_currency_mode) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CAST(NULLIF(?, '') AS UNSIGNED), NULLIF(?, ''))");
        foreach($data['supplies'] as $r) {
            $fxRaw = isset($r['fx_usd_rate']) ? (int)$r['fx_usd_rate'] : 0;
            if ($fxRaw < 1000 || $fxRaw > 50000000) {
                $fxRaw = 0;
            }
            $fxRateStr = $fxRaw > 0 ? (string)$fxRaw : '';
            $fxModeStr = '';
            if (isset($r['fx_currency_mode'])) {
                $m = strtoupper(trim((string)$r['fx_currency_mode']));
                if ($m === 'USD' || $m === 'IQD') {
                    $fxModeStr = $m;
                }
            }
            $stmt->bind_param("isisddssssss", (int)($def($r, 'id', 0)), (string)($def($r, 'company', '')), (int)($def($r, 'prodId', 0)), (string)($def($r, 'itemName', '')), (float)($def($r, 'qtyAdded', 0)), (float)($def($r, 'totalCost', 0)), (string)($def($r, 'date', '')), (string)($def($r, 'type', '')), (string)($def($r, 'transaction_id', '')), (string)($def($r, 'supplier_invoice_number', '')), $fxRateStr, $fxModeStr);
            $stmt->execute();
        }
    }

    // 16. Customer Ledger
    $conn->query("TRUNCATE TABLE customer_ledger");
    if(!empty($data['customer_ledger'])) {
        $stmt = $conn->prepare("INSERT INTO customer_ledger (id, target_id, target_type, type, amount, date, note, transaction_id, receipt_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        foreach($data['customer_ledger'] as $r) {
            $stmt->bind_param("iisidssss", (int)($def($r, 'id', 0)), (int)($def($r, 'target_id', 0)), (string)($def($r, 'target_type', 'customer')), (string)($def($r, 'type', '')), (float)($def($r, 'amount', 0)), (string)($def($r, 'date', '')), (string)($def($r, 'note', '')), (string)($def($r, 'transaction_id', '')), (string)($def($r, 'receipt_id', '')));
            $stmt->execute();
        }
    }

    // 17. Purchase Returns
    $conn->query("TRUNCATE TABLE purchase_returns");
    if(!empty($data['purchase_returns'])) {
        $stmt = $conn->prepare("INSERT INTO purchase_returns (id, company_id, company_name, items_json, total, `date`, `user`, note, transaction_id, supplier_invoice_number) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        foreach($data['purchase_returns'] as $r) {
            $items = is_string($def($r, 'items_json', '')) ? $r['items_json'] : json_encode($def($r, 'items', []));
            $stmt->bind_param("iissssssss", (int)($def($r, 'id', 0)), (int)($def($r, 'company_id', 0)), (string)($def($r, 'company_name', '')), $items, (float)($def($r, 'total', 0)), (string)($def($r, 'date', '')), (string)($def($r, 'user', '')), (string)($def($r, 'note', '')), (string)($def($r, 'transaction_id', '')), (string)($def($r, 'supplier_invoice_number', '')));
            $stmt->execute();
        }
    }

    // 18. Tables
    $conn->query("TRUNCATE TABLE tables");
    if(!empty($data['tables'])) {
        $stmt = $conn->prepare("INSERT INTO tables (id, name, items_json, isTakeaway, has_new_items) VALUES (?, ?, ?, ?, ?)");
        foreach($data['tables'] as $r) {
            $items = is_string($def($r, 'items_json', '')) ? $r['items_json'] : json_encode($def($r, 'items', []));
            $stmt->bind_param("issii", (int)($def($r, 'id', 0)), (string)($def($r, 'name', '')), $items, (int)($def($r, 'isTakeaway', 0)), (int)($def($r, 'has_new_items', 0)));
            $stmt->execute();
        }
    }

    // 19. Print Log
    $conn->query("TRUNCATE TABLE print_log");
    if(!empty($data['print_log'])) {
        $stmt = $conn->prepare("INSERT INTO print_log (id, doc_type, doc_id, action, user, user_id, note, details, ip_address, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        foreach($data['print_log'] as $r) {
            $stmt->bind_param("issssissss", (int)($def($r, 'id', 0)), (string)($def($r, 'doc_type', '')), (string)($def($r, 'doc_id', '')), (string)($def($r, 'action', '')), (string)($def($r, 'user', '')), (int)($def($r, 'user_id', 0)), (string)($def($r, 'note', '')), (string)($def($r, 'details', '')), (string)($def($r, 'ip_address', '')), (string)($def($r, 'created_at', '')));
            $stmt->execute();
        }
    }

    // 20. Stock Movements
    $conn->query("TRUNCATE TABLE stock_movements");
    $movements = !empty($data['warehouse_movements']) ? $data['warehouse_movements'] : (!empty($data['stock_movements']) ? $data['stock_movements'] : []);
    if(!empty($movements)) {
        $stmt = $conn->prepare("INSERT INTO stock_movements (id, product_id, barcode, movement_type, quantity, unit_cost, total_value, reference_type, reference_id, date, user, note) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        foreach($movements as $r) {
            $stmt->bind_param("iisidddsisss", (int)($def($r, 'id', 0)), (int)($def($r, 'product_id', 0)), (string)($def($r, 'barcode', '')), (string)($def($r, 'movement_type', '')), (int)($def($r, 'quantity', 0)), (float)($def($r, 'unit_cost', 0)), (float)($def($r, 'total_value', 0)), (string)($def($r, 'reference_type', '')), (int)($def($r, 'reference_id', 0)), (string)($def($r, 'date', '')), (string)($def($r, 'user', '')), (string)($def($r, 'note', '')));
            $stmt->execute();
        }
    }

    // 21. Audit Logs
    $conn->query("TRUNCATE TABLE audit_logs");
    $logs = !empty($data['logs']) ? $data['logs'] : [];
    if(!empty($logs)) {
        $stmt = $conn->prepare("INSERT INTO audit_logs (id, user, action_type, details, created_at, ip_address, user_id, entity_type, entity_id, old_value, new_value) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        foreach($logs as $r) {
            $stmt->bind_param("isssssissss", (int)($def($r, 'id', 0)), (string)($def($r, 'user', '')), (string)($def($r, 'action_type', '')), (string)($def($r, 'details', '')), (string)($def($r, 'created_at', '')), (string)($def($r, 'ip_address', '')), (int)($def($r, 'user_id', 0)), (string)($def($r, 'entity_type', '')), (int)($def($r, 'entity_id', 0)), (string)($def($r, 'old_value', '')), (string)($def($r, 'new_value', '')));
            $stmt->execute();
        }
    }

    // 22. Sales Archive
    $conn->query("TRUNCATE TABLE sales_archive");
    if(!empty($data['sales_archive'])) {
        $stmt = $conn->prepare("INSERT INTO sales_archive (id, total, discount, items_json, created_at, cashier, payment_method, customer_id, customer_type, is_returned, transaction_id, archived_at, fx_usd_rate, fx_currency_mode) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CAST(NULLIF(?, '') AS UNSIGNED), NULLIF(?, ''))");
        foreach($data['sales_archive'] as $r) {
            $items = is_string($def($r, 'items_json', '')) ? $r['items_json'] : json_encode($def($r, 'items', []));
            $fxRaw = isset($r['fx_usd_rate']) ? (int)$r['fx_usd_rate'] : 0;
            if ($fxRaw < 1000 || $fxRaw > 50000000) {
                $fxRaw = 0;
            }
            $fxRateStr = $fxRaw > 0 ? (string)$fxRaw : '';
            $fxModeStr = '';
            if (isset($r['fx_currency_mode'])) {
                $m = strtoupper(trim((string)$r['fx_currency_mode']));
                if ($m === 'USD' || $m === 'IQD') {
                    $fxModeStr = $m;
                }
            }
            $stmt->bind_param("iddssssisisssss", (int)($def($r, 'id', 0)), (float)($def($r, 'total', 0)), (float)($def($r, 'discount', 0)), $items, (string)($def($r, 'created_at', '')), (string)($def($r, 'cashier', '')), (string)($def($r, 'payment_method', 'cash')), (int)($def($r, 'customer_id', 0)), (string)($def($r, 'customer_type', 'customer')), (int)($def($r, 'is_returned', 0)), (string)($def($r, 'transaction_id', '')), (string)($def($r, 'archived_at', '')), $fxRateStr, $fxModeStr);
            $stmt->execute();
        }
    }

    // 23. Expenses Archive
    $conn->query("TRUNCATE TABLE expenses_archive");
    if(!empty($data['expenses_archive'])) {
        $stmt = $conn->prepare("INSERT INTO expenses_archive (id, note, amount, `date`, user, type, transaction_id, archived_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        foreach($data['expenses_archive'] as $r) {
            $stmt->bind_param("isdsssss", (int)($def($r, 'id', 0)), (string)($def($r, 'note', '')), (float)($def($r, 'amount', 0)), (string)($def($r, 'date', '')), (string)($def($r, 'user', '')), (string)($def($r, 'type', 'operational')), (string)($def($r, 'transaction_id', '')), (string)($def($r, 'archived_at', '')));
            $stmt->execute();
        }
    }

    $conn->query("SET FOREIGN_KEY_CHECKS = 1");
}

/**
 * mysqli DATE/DATETIME reject '' under STRICT mode — use NULL instead.
 */
function pos_restore_sql_bind_value($v, $colType) {
    $type = strtolower(trim((string)$colType));
    if (is_array($v) || is_object($v)) {
        $v = json_encode($v, JSON_UNESCAPED_UNICODE);
    }
    $isDateCol = (bool)preg_match('/^(date|datetime|timestamp|year)\b/', $type);
    if ($isDateCol) {
        if ($v === null) return null;
        $s = trim((string)$v);
        if ($s === '' || $s === '0' || preg_match('/^0000-00-00/', $s)) return null;
        return $s;
    }
    return $v;
}

function restoreTableDataGeneric($conn, $tableData, $opts = []) {
    $opts = is_array($opts) ? $opts : [];
    $truncate = !array_key_exists('truncate', $opts) || !empty($opts['truncate']);
    $conn->query("SET FOREIGN_KEY_CHECKS = 0");
    $isMerge = pos_backup_restore_is_merge();

    if ($isMerge) {
        $mergeMap = array_flip(pos_backup_restore_merge_tables());
        $filtered = [];
        foreach ($tableData as $table => $rows) {
            if (isset($mergeMap[$table])) {
                $filtered[$table] = $rows;
            }
        }
        $tableData = $filtered;
        if (function_exists('pos_prepare_merge_items_table_data')) {
            $tableData = pos_prepare_merge_items_table_data($tableData);
        }
    } else if ($truncate) {
        pos_truncate_all_database_tables($conn);
    }

    if (!$isMerge && $truncate) {
        if (isset($tableData['products']) && is_array($tableData['products'])) {
            $i = 0;
            foreach ($tableData['products'] as $row) {
                $i++;
                if (!is_array($row)) continue;
                pos_validate_backup_product_row($row, $i, false);
            }
        }
        if (isset($tableData['stock_batches']) && is_array($tableData['stock_batches'])) {
            $i = 0;
            foreach ($tableData['stock_batches'] as $row) {
                $i++;
                if (!is_array($row)) continue;
                pos_validate_backup_stock_batch_row($row, $i, false);
            }
        }
    }

    foreach ($tableData as $table => $rows) {
        $table = trim((string)$table);
        if ($table === '') continue;
        $tableEsc = str_replace('`', '``', $table);
        $exists = $conn->query("SHOW TABLES LIKE '" . $conn->real_escape_string($table) . "'");
        if (!$exists || $exists->num_rows === 0) continue;

        if (!is_array($rows)) $rows = [];

        if (count($rows) === 0) continue;

        // Deduplicate settings by primary key (setting_key) — backups may list the same key twice
        if ($table === 'settings') {
            $byKey = [];
            foreach ($rows as $r) {
                if (!is_array($r)) continue;
                $sk = isset($r['setting_key']) ? (string)$r['setting_key'] : '';
                if ($sk === '') continue;
                $byKey[$sk] = $r;
            }
            $rows = array_values($byKey);
            if (count($rows) === 0) continue;
        }

        $colRes = $conn->query("SHOW COLUMNS FROM `{$tableEsc}`");
        $validCols = [];
        $colTypes = [];
        if ($colRes) {
            while ($c = $colRes->fetch_assoc()) {
                $validCols[$c['Field']] = true;
                $colTypes[$c['Field']] = (string)($c['Type'] ?? '');
            }
        }
        if (empty($validCols)) continue;

        foreach ($rows as $row) {
            if (!is_array($row)) continue;
            
            // Merge only: import catalog with zero stock + no expiry (do not overwrite existing stock).
            if ($isMerge && $table === 'products') {
                $row['qty'] = 0;
                $row['expiry'] = '';
                if (array_key_exists('expiry_date', $row)) $row['expiry_date'] = '';
                $row['catalog_only'] = 1;
            }

            if ($isMerge && $table === 'products') {
                $checkName = trim((string)($row['name'] ?? ''));
                $checkBarcode = trim((string)($row['barcode'] ?? ''));
                $checkPack = trim((string)($row['barcode_pack'] ?? ''));
                $checkCarton = trim((string)($row['barcode_carton'] ?? ''));

                // First wins: skip if name or any barcode already exists in DB.
                $dupFound = false;
                $checks = [];
                if ($checkName !== '') {
                    $checks[] = ['sql' => 'SELECT id FROM products WHERE name = ? LIMIT 1', 'types' => 's', 'vals' => [$checkName]];
                }
                foreach ([$checkBarcode, $checkPack, $checkCarton] as $bc) {
                    if ($bc === '') continue;
                    $checks[] = [
                        'sql' => 'SELECT id FROM products WHERE barcode = ? OR barcode_pack = ? OR barcode_carton = ? LIMIT 1',
                        'types' => 'sss',
                        'vals' => [$bc, $bc, $bc],
                    ];
                }
                foreach ($checks as $chk) {
                    $st = $conn->prepare($chk['sql']);
                    if (!$st) continue;
                    $vals = $chk['vals'];
                    $bind = [$chk['types']];
                    for ($bi = 0; $bi < count($vals); $bi++) {
                        $bind[] = &$vals[$bi];
                    }
                    call_user_func_array([$st, 'bind_param'], $bind);
                    $st->execute();
                    $dr = $st->get_result();
                    if ($dr && $dr->num_rows > 0) {
                        $dupFound = true;
                        $st->close();
                        break;
                    }
                    $st->close();
                }
                if ($dupFound) {
                    continue; // Skip — batch1 / existing wins
                }
                unset($row['id']); // Let it auto-increment
            }

            if ($isMerge && $table === 'categories') {
                $checkName = $row['name'] ?? '';
                $dupSql = "SELECT id FROM categories WHERE name = ? LIMIT 1";
                $dupStmt = $conn->prepare($dupSql);
                $dupStmt->bind_param("s", $checkName);
                $dupStmt->execute();
                $dupRes = $dupStmt->get_result();
                if ($dupRes && $dupRes->num_rows > 0) {
                    continue; // Skip duplicate
                }
                unset($row['id']); // Let it auto-increment
            }

            if ($isMerge && $table === 'manufacturers') {
                $checkName = trim((string)($row['name'] ?? ''));
                if ($checkName === '') continue;
                $dupSql = "SELECT id FROM manufacturers WHERE name = ? LIMIT 1";
                $dupStmt = $conn->prepare($dupSql);
                $dupStmt->bind_param("s", $checkName);
                $dupStmt->execute();
                $dupRes = $dupStmt->get_result();
                if ($dupRes && $dupRes->num_rows > 0) {
                    continue;
                }
                unset($row['id']);
            }

            if ($table === 'products') {
                pos_sanitize_backup_product_row($row);
            }
            if ($table === 'stock_batches' && array_key_exists('expiry_date', $row)) {
                $row['expiry_date'] = function_exists('pos_sanitize_expiry_for_restore')
                    ? pos_sanitize_expiry_for_restore($row['expiry_date'] ?? '')
                    : '';
            }
            if ($table === 'supplies' && array_key_exists('expiry_date', $row)) {
                $row['expiry_date'] = function_exists('pos_sanitize_expiry_for_restore')
                    ? pos_sanitize_expiry_for_restore($row['expiry_date'] ?? '')
                    : '';
            }

            $cols = [];
            $vals = [];
            foreach ($row as $k => $v) {
                if (!isset($validCols[$k])) continue;
                $cols[] = '`' . str_replace('`', '``', $k) . '`';
                $vals[] = pos_restore_sql_bind_value($v, $colTypes[$k] ?? '');
            }
            if (empty($cols)) continue;
            $placeholders = implode(',', array_fill(0, count($cols), '?'));
            $types = str_repeat('s', count($cols));
            $updateParts = [];
            foreach ($cols as $colSql) {
                $updateParts[] = $colSql . ' = VALUES(' . $colSql . ')';
            }
            $sql = "INSERT INTO `{$tableEsc}` (" . implode(',', $cols) . ") VALUES ($placeholders)"
                . " ON DUPLICATE KEY UPDATE " . implode(', ', $updateParts);
            $stmt = $conn->prepare($sql);
            if (!$stmt) throw new Exception("Prepare failed for table {$table}");
            $bind = [$types];
            for ($i = 0; $i < count($vals); $i++) $bind[] = &$vals[$i];
            call_user_func_array([$stmt, 'bind_param'], $bind);
            if (!$stmt->execute()) throw new Exception("Insert failed in {$table}: " . $stmt->error);
        }
    }
    $conn->query("SET FOREIGN_KEY_CHECKS = 1");
}

function restoreFilesystemFromPackageZip($zip, $baseDir) {
    $restored = 0;
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $stat = $zip->statIndex($i);
        $name = str_replace('\\', '/', (string)($stat['name'] ?? ''));
        if (strpos($name, 'files/') !== 0) continue;
        $rel = ltrim(substr($name, strlen('files/')), '/');
        if ($rel === '' || strpos($rel, '..') !== false) continue;
        $dest = rtrim($baseDir, '/\\') . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $rel);
        $destDir = dirname($dest);
        if (!is_dir($destDir)) @mkdir($destDir, 0755, true);
        $content = $zip->getFromIndex($i);
        if ($content === false) continue;
        if (@file_put_contents($dest, $content) === false) {
            throw new Exception("Failed restoring file: {$rel}");
        }
        $restored++;
    }
    return $restored;
}

function pos_rrmdir_tree($dir) {
    if (!$dir || !is_dir($dir)) return;
    try {
        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($it as $f) {
            /** @var SplFileInfo $f */
            $p = $f->getPathname();
            if ($f->isDir()) @rmdir($p);
            else @unlink($p);
        }
        @rmdir($dir);
    } catch (\Throwable $e) {}
}

function restoreFilesystemFromExtractDir($extractDir, $baseDir) {
    $restored = 0;
    if (!$extractDir || !is_dir($extractDir)) return 0;
    $prefixLen = strlen(rtrim($extractDir, '/\\')) + 1;
    try {
        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($extractDir, FilesystemIterator::SKIP_DOTS)
        );
    } catch (\Throwable $e) {
        return 0;
    }
    foreach ($it as $f) {
        /** @var SplFileInfo $f */
        if (!$f->isFile()) continue;
        $rel = str_replace('\\', '/', substr($f->getPathname(), $prefixLen));
        $idx = strpos($rel, 'files/');
        if ($idx === false) continue;
        $rel = ltrim(substr($rel, $idx + strlen('files/')), '/');
        if ($rel === '' || strpos($rel, '..') !== false) continue;
        $dest = rtrim($baseDir, '/\\') . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $rel);
        $destParent = dirname($dest);
        if (!is_dir($destParent)) @mkdir($destParent, 0755, true);
        $content = @file_get_contents($f->getPathname());
        if ($content === false) continue;
        if (@file_put_contents($dest, $content) === false) {
            throw new Exception("Failed restoring file: {$rel}");
        }
        $restored++;
    }
    return $restored;
}

/**
 * Extract ZIP without requiring php_zip (some XAMPP laptops have ZipArchive disabled).
 * Upload temp files often have no .zip extension — copy first so tar/PowerShell work.
 */
function pos_backup_ensure_zip_ext($srcPath) {
    $ext = strtolower(pathinfo((string)$srcPath, PATHINFO_EXTENSION));
    if ($ext === 'zip' && is_file($srcPath)) {
        return [$srcPath, false];
    }
    $dest = rtrim(sys_get_temp_dir(), '/\\') . DIRECTORY_SEPARATOR . 'pos_upl_' . bin2hex(random_bytes(5)) . '.zip';
    if (!@copy($srcPath, $dest)) {
        $bin = @file_get_contents($srcPath);
        if ($bin === false || @file_put_contents($dest, $bin) === false) {
            return [$srcPath, false];
        }
    }
    return [$dest, true];
}

function pos_extract_zip_to_dir($zipPath, $destDir) {
    if (!is_dir($destDir) && !@mkdir($destDir, 0755, true) && !is_dir($destDir)) {
        return ['ok' => false, 'message' => 'نەتوانرا فۆڵدەری کاتی ZIP دروست بکرێت'];
    }
    list($zipFile, $copied) = pos_backup_ensure_zip_ext($zipPath);
    try {
        if (class_exists('ZipArchive')) {
            $zip = new ZipArchive();
            if ($zip->open($zipFile) === true) {
                $ok = $zip->extractTo($destDir);
                $zip->close();
                if ($ok) return ['ok' => true, 'via' => 'ZipArchive'];
            }
        }
        if (function_exists('pos_ota_extract_zip')) {
            $r = pos_ota_extract_zip($zipFile, $destDir);
            if (!empty($r['ok'])) return $r;
        }
        $isWin = strtoupper(substr(PHP_OS, 0, 3)) === 'WIN';
        if ($isWin) {
            $tar = 'C:\\Windows\\System32\\tar.exe';
            if (is_file($tar)) {
                $out = [];
                $code = 1;
                @exec(escapeshellarg($tar) . ' -xf ' . escapeshellarg($zipFile) . ' -C ' . escapeshellarg($destDir) . ' 2>&1', $out, $code);
                if ($code === 0) return ['ok' => true, 'via' => 'tar'];
            }
            $ps = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe';
            if (is_file($ps)) {
                $z = str_replace("'", "''", $zipFile);
                $d = str_replace("'", "''", $destDir);
                $script = "Expand-Archive -LiteralPath '" . $z . "' -DestinationPath '" . $d . "' -Force";
                $out = [];
                $code = 1;
                @exec(escapeshellarg($ps) . ' -NoProfile -NonInteractive -Command ' . escapeshellarg($script) . ' 2>&1', $out, $code);
                if ($code === 0) return ['ok' => true, 'via' => 'powershell'];
            }
        }
        return ['ok' => false, 'message' => 'نەتوانرا ZIP بکرێتەوە. ل ڤی لاپتۆپی پێوەکراوی ZIP نەچالاکە — tar/PowerShell ژی سەرکەوتوو نەبوو.'];
    } finally {
        if ($copied && $zipFile !== $srcPath && is_file($zipFile)) {
            @unlink($zipFile);
        }
    }
}

function pos_backup_find_in_extract($extractDir, $relativePath) {
    if (!$extractDir || !is_dir($extractDir)) return null;
    $wanted = str_replace('\\', '/', $relativePath);
    $direct = rtrim($extractDir, '/\\') . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $wanted);
    if (is_file($direct)) return $direct;
    $prefixLen = strlen(rtrim($extractDir, '/\\')) + 1;
    try {
        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($extractDir, FilesystemIterator::SKIP_DOTS)
        );
        foreach ($it as $f) {
            /** @var SplFileInfo $f */
            if (!$f->isFile()) continue;
            $rel = str_replace('\\', '/', substr($f->getPathname(), $prefixLen));
            if ($rel === $wanted || substr($rel, -strlen('/' . $wanted)) === '/' . $wanted) {
                return $f->getPathname();
            }
        }
    } catch (\Throwable $e) {}
    return null;
}

function pos_backup_read_zip_member($zip, $extractDir, $name) {
    $name = ltrim(str_replace('\\', '/', (string)$name), './');
    if ($zip instanceof ZipArchive) {
        foreach ([$name, str_replace('/', '\\', $name)] as $try) {
            $c = @$zip->getFromName($try);
            if ($c !== false && $c !== '') return $c;
        }
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $n = ltrim(str_replace('\\', '/', (string)$zip->getNameIndex($i)), './');
            if ($n === $name || substr($n, -strlen('/' . $name)) === '/' . $name) {
                $c = $zip->getFromIndex($i);
                if ($c !== false) return $c;
            }
        }
        return false;
    }
    $path = pos_backup_find_in_extract($extractDir, $name);
    if (!$path) return false;
    $c = @file_get_contents($path);
    return ($c === false) ? false : $c;
}

function pos_backup_collect_json_entries($zip, $extractDir) {
    $files = [];
    $skipBase = ['mysql_data_manifest.json' => true];
    if ($zip instanceof ZipArchive) {
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = ltrim(str_replace('\\', '/', (string)$zip->getNameIndex($i)), './');
            if ($name === '' || substr($name, -1) === '/') continue;
            if (strtolower(pathinfo($name, PATHINFO_EXTENSION)) !== 'json') continue;
            $base = strtolower(basename($name));
            if (isset($skipBase[$base])) continue;
            $body = $zip->getFromIndex($i);
            if ($body === false || $body === '') continue;
            if (strncmp($body, "\xEF\xBB\xBF", 3) === 0) $body = substr($body, 3);
            $files[] = ['name' => $name, 'body' => $body];
        }
    }
    if (!$files && $extractDir && is_dir($extractDir)) {
        $prefixLen = strlen(rtrim($extractDir, '/\\')) + 1;
        try {
            $it = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($extractDir, FilesystemIterator::SKIP_DOTS)
            );
            foreach ($it as $f) {
                /** @var SplFileInfo $f */
                if (!$f->isFile()) continue;
                if (strtolower($f->getExtension()) !== 'json') continue;
                $base = strtolower($f->getFilename());
                if (isset($skipBase[$base])) continue;
                $body = @file_get_contents($f->getPathname());
                if ($body === false || $body === '') continue;
                if (strncmp($body, "\xEF\xBB\xBF", 3) === 0) $body = substr($body, 3);
                $rel = str_replace('\\', '/', substr($f->getPathname(), $prefixLen));
                $files[] = ['name' => $rel, 'body' => $body];
            }
        } catch (\Throwable $e) {}
    }
    return $files;
}

function pos_backup_pick_json_entry(array $files, $preferDb) {
    $best = null;
    $bestScore = -999;
    foreach ($files as $f) {
        $decoded = json_decode($f['body'], true);
        if (!is_array($decoded)) continue;
        $n = strtolower(str_replace('\\', '/', $f['name']));
        $base = basename($n);
        $score = 0;
        if ($preferDb) {
            if (substr($n, -strlen('database/full_backup.json')) === 'database/full_backup.json') $score += 120;
            if ($base === 'full_backup.json') $score += 90;
            if (isset($decoded['table_data']) && is_array($decoded['table_data'])) $score += 60;
            if (!empty($decoded['products']) && is_array($decoded['products'])) $score += 25;
            if ($base === 'manifest.json') $score -= 80;
        } else {
            if ($base === 'manifest.json') $score += 100;
        }
        if ($score > $bestScore) {
            $bestScore = $score;
            $best = $f;
            $best['decoded'] = $decoded;
        }
    }
    return $best;
}

function pos_backup_close_loaded_package($loaded) {
    if (!is_array($loaded)) return;
    if (isset($loaded['zip']) && $loaded['zip'] instanceof ZipArchive) {
        @$loaded['zip']->close();
        $loaded['zip'] = null;
    }
    if (!empty($loaded['extract_dir']) && is_dir($loaded['extract_dir'])) {
        pos_rrmdir_tree($loaded['extract_dir']);
    }
}

/**
 * Read JSON-like members from a ZIP using only PHP (no ZipArchive).
 * Used when php_zip is missing or the upload has no .zip extension.
 */
function pos_native_zip_collect_json($zipPath) {
    $files = [];
    $fp = @fopen($zipPath, 'rb');
    if (!$fp) {
        return $files;
    }
    $size = @filesize($zipPath);
    if ($size === false || $size < 22) {
        fclose($fp);
        return $files;
    }
    $max = (int)min($size, 65557);
    if (@fseek($fp, $size - $max) !== 0) {
        fclose($fp);
        return $files;
    }
    $tail = @fread($fp, $max);
    if (!is_string($tail) || $tail === '') {
        fclose($fp);
        return $files;
    }
    $eocd = strrpos($tail, "PK\x05\x06");
    if ($eocd === false) {
        fclose($fp);
        return $files;
    }
    $cdOff = unpack('V', substr($tail, $eocd + 16, 4));
    $cdSize = unpack('V', substr($tail, $eocd + 12, 4));
    $nEntries = unpack('v', substr($tail, $eocd + 10, 2));
    $cdOff = isset($cdOff[1]) ? (int)$cdOff[1] : 0;
    $cdSize = isset($cdSize[1]) ? (int)$cdSize[1] : 0;
    $nEntries = isset($nEntries[1]) ? (int)$nEntries[1] : 0;
    if ($cdOff === 0xFFFFFFFF || $nEntries === 0xFFFF || $cdSize <= 0 || $nEntries <= 0) {
        fclose($fp);
        return $files;
    }
    if (@fseek($fp, $cdOff) !== 0) {
        fclose($fp);
        return $files;
    }
    $cd = @fread($fp, $cdSize);
    if (!is_string($cd) || strlen($cd) < 46) {
        fclose($fp);
        return $files;
    }
    $pos = 0;
    $cdLen = strlen($cd);
    for ($i = 0; $i < $nEntries && ($pos + 46) <= $cdLen; $i++) {
        if (substr($cd, $pos, 4) !== "PK\x01\x02") {
            break;
        }
        $method = unpack('v', substr($cd, $pos + 10, 2));
        $compSize = unpack('V', substr($cd, $pos + 20, 4));
        $uncomp = unpack('V', substr($cd, $pos + 24, 4));
        $nameLen = unpack('v', substr($cd, $pos + 28, 2));
        $extraLen = unpack('v', substr($cd, $pos + 30, 2));
        $commentLen = unpack('v', substr($cd, $pos + 32, 2));
        $localOff = unpack('V', substr($cd, $pos + 42, 4));
        $method = isset($method[1]) ? (int)$method[1] : 0;
        $compSize = isset($compSize[1]) ? (int)$compSize[1] : 0;
        $uncomp = isset($uncomp[1]) ? (int)$uncomp[1] : 0;
        $nameLen = isset($nameLen[1]) ? (int)$nameLen[1] : 0;
        $extraLen = isset($extraLen[1]) ? (int)$extraLen[1] : 0;
        $commentLen = isset($commentLen[1]) ? (int)$commentLen[1] : 0;
        $localOff = isset($localOff[1]) ? (int)$localOff[1] : 0;
        $name = substr($cd, $pos + 46, $nameLen);
        $pos += 46 + $nameLen + $extraLen + $commentLen;
        $rel = ltrim(str_replace('\\', '/', (string)$name), './');
        if ($rel === '' || substr($rel, -1) === '/') {
            continue;
        }
        $ext = strtolower(pathinfo($rel, PATHINFO_EXTENSION));
        $base = strtolower(basename($rel));
        $looksJson = ($ext === 'json' || $ext === 'jsonl' || $base === 'full_backup.json' || $base === 'manifest.json');
        $peekSmall = ($uncomp > 0 && $uncomp <= 12 * 1024 * 1024);
        if (!$looksJson && !$peekSmall) {
            continue;
        }
        if ($uncomp > 400 * 1024 * 1024) {
            continue;
        }
        if (@fseek($fp, $localOff) !== 0) {
            continue;
        }
        $lh = @fread($fp, 30);
        if (!is_string($lh) || substr($lh, 0, 4) !== "PK\x03\x04") {
            continue;
        }
        $ln = unpack('v', substr($lh, 26, 2));
        $le = unpack('v', substr($lh, 28, 2));
        $ln = isset($ln[1]) ? (int)$ln[1] : 0;
        $le = isset($le[1]) ? (int)$le[1] : 0;
        @fseek($fp, $localOff + 30 + $ln + $le);
        $comp = ($compSize > 0) ? @fread($fp, $compSize) : '';
        if (!is_string($comp)) {
            continue;
        }
        $raw = false;
        if ($method === 0) {
            $raw = $comp;
        } elseif ($method === 8) {
            $raw = @gzinflate($comp);
        }
        if (!is_string($raw) || $raw === '') {
            continue;
        }
        if (function_exists('pos_backup_bytes_to_utf8')) {
            $raw = pos_backup_bytes_to_utf8($raw);
        } elseif (strncmp($raw, "\xEF\xBB\xBF", 3) === 0) {
            $raw = substr($raw, 3);
        }
        $t = ltrim($raw);
        if ($t === '' || ($t[0] !== '{' && $t[0] !== '[')) {
            if (!$looksJson) {
                continue;
            }
        }
        $files[] = ['name' => $rel, 'body' => $raw];
    }
    fclose($fp);
    return $files;
}

function loadBackupPackageFromUpload($tmpName, $fileName) {
    $fh = @fopen($tmpName, 'rb');
    if (!$fh) {
        throw new Exception("Could not read uploaded file");
    }
    $head = (string)@fread($fh, 16);
    @fclose($fh);
    if ($head === '') {
        throw new Exception("Could not read uploaded file");
    }
    $isGzip = (strlen($head) >= 2 && $head[0] === "\x1f" && $head[1] === "\x8b");
    $isZipMagic = (strncmp($head, "PK\x03\x04", 4) === 0) || (strncmp($head, "PK\x05\x06", 4) === 0);

    if ($isGzip) {
        $raw = @file_get_contents($tmpName);
        if ($raw === false || $raw === '') {
            throw new Exception("Could not read uploaded file");
        }
        if (!function_exists('gzdecode')) {
            throw new Exception('gzip ل ڤی PHP نەچالاکە — zlib پێتڤیە.');
        }
        $json = @gzdecode($raw);
        unset($raw);
        if (!is_string($json) || $json === '') {
            throw new Exception('فایلێ .posbak (gzip) نەهاتە کرنەوە.');
        }
        $decoded = function_exists('pos_json_decode_lenient')
            ? pos_json_decode_lenient($json)
            : json_decode($json, true);
        unset($json);
        if (!is_array($decoded)) {
            throw new Exception('د ناڤ ڤی .posbak دا داتای POS نەهاتە دیتن.');
        }
        if (function_exists('pos_loaded_package_from_decoded')) {
            return pos_loaded_package_from_decoded($decoded);
        }
        return ['mode' => 'legacy', 'data' => $decoded, 'manifest' => null, 'files_restored' => 0];
    }

    if (!$isZipMagic) {
        $raw = @file_get_contents($tmpName);
        if ($raw === false || $raw === '') {
            throw new Exception("Could not read uploaded file");
        }
        $utf = function_exists('pos_backup_bytes_to_utf8') ? pos_backup_bytes_to_utf8($raw) : $raw;
        unset($raw);
        $trim = ltrim((string)$utf);
        if ($trim !== '' && ($trim[0] === '{' || $trim[0] === '[')) {
            $decoded = function_exists('pos_json_decode_lenient')
                ? pos_json_decode_lenient($utf)
                : json_decode($utf, true);
            unset($utf);
            if (is_array($decoded)) {
                if (function_exists('pos_loaded_package_from_decoded')) {
                    return pos_loaded_package_from_decoded($decoded);
                }
                return ['mode' => 'legacy', 'data' => $decoded, 'manifest' => null, 'files_restored' => 0];
            }
            throw new Exception("Invalid JSON file (decode failed — file too large for PHP limits or corrupted)");
        }
        throw new Exception("د ناڤ ڤی فایلێ دا داتای POS نەهاتە دیتن. فایلێ .posbak یان JSON یان ZIP یێ دروست بکاربینە.");
    }

    $zip = null;
    $extractDir = null;
    if (class_exists('ZipArchive')) {
        $zip = new ZipArchive();
        $res = $zip->open($tmpName);
        if ($res !== TRUE) {
            $zip = null;
        }
    }

    $jsonFiles = pos_backup_collect_json_entries($zip, null);
    if (!$jsonFiles) {
        $jsonFiles = pos_native_zip_collect_json($tmpName);
    }
    if (!$jsonFiles) {
        if ($zip instanceof ZipArchive) {
            @$zip->close();
            $zip = null;
        }
        $extractDir = rtrim(sys_get_temp_dir(), '/\\') . DIRECTORY_SEPARATOR . 'pos_bakzip_' . bin2hex(random_bytes(4));
        $ex = pos_extract_zip_to_dir($tmpName, $extractDir);
        if (empty($ex['ok'])) {
            pos_rrmdir_tree($extractDir);
            throw new Exception((string)($ex['message'] ?? 'نەتوانرا ZIP بکرێتەوە'));
        }
        $jsonFiles = pos_backup_collect_json_entries(null, $extractDir);
        if (!$jsonFiles) {
            $jsonFiles = pos_backup_collect_any_json_on_disk($extractDir);
        }
    }

    $dbPick = pos_backup_pick_json_entry($jsonFiles, true);
    $manPick = pos_backup_pick_json_entry($jsonFiles, false);

    $read = function ($name) use ($zip, $extractDir) {
        return pos_backup_read_zip_member($zip, $extractDir, $name);
    };

    $manifestRaw = $read('manifest.json');
    $dbRaw = $read('database/full_backup.json');
    if ($dbRaw === false && $dbPick) $dbRaw = $dbPick['body'];
    if ($manifestRaw === false && $manPick && strtolower(basename($manPick['name'])) === 'manifest.json') {
        $manifestRaw = $manPick['body'];
    }

    if ($manifestRaw !== false && $dbRaw !== false) {
        $manifest = json_decode($manifestRaw, true);
        $data = json_decode($dbRaw, true);
        if (!is_array($manifest) || !is_array($data)) {
            if ($zip instanceof ZipArchive) $zip->close();
            pos_rrmdir_tree($extractDir);
            throw new Exception("Invalid manifest/database in ZIP");
        }
        if (($manifest['format'] ?? '') !== 'full_zip_package_v2' && isset($data['table_data'])) {
            $manifest['format'] = 'full_zip_package_v2';
        }
        if (($manifest['format'] ?? '') !== 'full_zip_package_v2') {
            if (isset($data['table_data']) && is_array($data['table_data'])) {
                $manifest['format'] = 'full_zip_package_v2';
            } else {
                if ($zip instanceof ZipArchive) $zip->close();
                pos_rrmdir_tree($extractDir);
                throw new Exception("Unsupported backup package format");
            }
        }
        if (!isset($manifest['database']) || !is_array($manifest['database'])) {
            $manifest['database'] = [
                'path' => 'database/full_backup.json',
                'sha256' => hash('sha256', $dbRaw),
            ];
        }
        $expectedDbHash = (string)($manifest['database']['sha256'] ?? '');
        $actualDbHash = hash('sha256', $dbRaw);
        $skipHash = function_exists('pos_backup_restore_is_merge') && pos_backup_restore_is_merge();
        if (!$skipHash && $expectedDbHash !== '' && !hash_equals($expectedDbHash, $actualDbHash)) {
            if ($zip instanceof ZipArchive) $zip->close();
            pos_rrmdir_tree($extractDir);
            throw new Exception("Backup integrity failed (database checksum mismatch)");
        }
        if (!isset($data['table_data']) || !is_array($data['table_data'])) {
            if ($zip instanceof ZipArchive) $zip->close();
            pos_rrmdir_tree($extractDir);
            throw new Exception("Invalid package database payload");
        }
        if (!isset($manifest['table_counts']) || !is_array($manifest['table_counts'])) {
            $manifest['table_counts'] = [];
            foreach ($data['table_data'] as $tbl => $rows) {
                $manifest['table_counts'][$tbl] = is_array($rows) ? count($rows) : 0;
            }
        }
        if (!$skipHash) {
            foreach ($manifest['table_counts'] as $tbl => $cnt) {
                if (!array_key_exists($tbl, $data['table_data'])) {
                    if ($zip instanceof ZipArchive) $zip->close();
                    pos_rrmdir_tree($extractDir);
                    throw new Exception("Backup integrity failed (missing table payload: {$tbl})");
                }
                if ((int)$cnt !== count((array)$data['table_data'][$tbl])) {
                    if ($zip instanceof ZipArchive) $zip->close();
                    pos_rrmdir_tree($extractDir);
                    throw new Exception("Backup integrity failed (table row count mismatch: {$tbl})");
                }
            }
            if (isset($manifest['files']) && is_array($manifest['files'])) {
                foreach ($manifest['files'] as $f) {
                    if (!is_array($f)) continue;
                    $rel = str_replace('\\', '/', (string)($f['path'] ?? ''));
                    if ($rel === '' || strpos($rel, '..') !== false) {
                        if ($zip instanceof ZipArchive) $zip->close();
                        pos_rrmdir_tree($extractDir);
                        throw new Exception("Backup integrity failed (invalid file path in manifest)");
                    }
                    $content = $read('files/' . $rel);
                    if ($content === false) {
                        if ($zip instanceof ZipArchive) $zip->close();
                        pos_rrmdir_tree($extractDir);
                        throw new Exception("Backup integrity failed (missing file in ZIP: {$rel})");
                    }
                    $expected = (string)($f['sha256'] ?? '');
                    if ($expected !== '' && !hash_equals($expected, hash('sha256', $content))) {
                        if ($zip instanceof ZipArchive) $zip->close();
                        pos_rrmdir_tree($extractDir);
                        throw new Exception("Backup integrity failed (file checksum mismatch: {$rel})");
                    }
                }
            }
        }
        return ['mode' => 'package', 'data' => $data, 'manifest' => $manifest, 'zip' => $zip, 'extract_dir' => $extractDir];
    }

    if ($dbRaw !== false) {
        $data = json_decode($dbRaw, true);
        if (is_array($data) && isset($data['table_data']) && is_array($data['table_data'])) {
            $counts = [];
            foreach ($data['table_data'] as $tbl => $rows) {
                $counts[$tbl] = is_array($rows) ? count($rows) : 0;
            }
            $manifest = [
                'format' => 'full_zip_package_v2',
                'table_counts' => $counts,
                'database' => ['path' => 'database/full_backup.json', 'sha256' => hash('sha256', $dbRaw)],
                'files' => [],
            ];
            return ['mode' => 'package', 'data' => $data, 'manifest' => $manifest, 'zip' => $zip, 'extract_dir' => $extractDir];
        }
        if (is_array($data) && function_exists('pos_loaded_package_from_decoded')) {
            $loaded = pos_loaded_package_from_decoded($data);
            $loaded['zip'] = $zip;
            $loaded['extract_dir'] = $extractDir;
            return $loaded;
        }
    }

    foreach ($jsonFiles as $jf) {
        $decoded = function_exists('pos_json_decode_lenient')
            ? pos_json_decode_lenient($jf['body'])
            : json_decode($jf['body'], true);
        if (!is_array($decoded)) {
            continue;
        }
        if (function_exists('pos_normalize_decoded_backup')) {
            $decoded = pos_normalize_decoded_backup($decoded);
        }
        if (is_array($decoded) && isset($decoded['table_data']) && is_array($decoded['table_data'])) {
            if ($zip instanceof ZipArchive) {
                @$zip->close();
                $zip = null;
            }
            pos_rrmdir_tree($extractDir);
            if (function_exists('pos_loaded_package_from_decoded')) {
                return pos_loaded_package_from_decoded($decoded);
            }
            return ['mode' => 'legacy', 'data' => $decoded, 'manifest' => null, 'files_restored' => 0];
        }
    }

    $json = $dbPick ? $dbPick['body'] : false;
    if ($json === false && $jsonFiles) {
        $json = $jsonFiles[0]['body'];
    }
    if ($zip instanceof ZipArchive) {
        $zip->close();
        $zip = null;
    }
    pos_rrmdir_tree($extractDir);
    if ($json === false) {
        throw new Exception("د ناڤ ڤی فایلێ دا داتای POS نەهاتە دیتن. فایلێ .posbak یێ نوو ژ «داونلۆدی بک‌ئەپ» یان «داونلۆد تەنها ئایتم» وەربگرە.");
    }
    $decoded = function_exists('pos_json_decode_lenient')
        ? pos_json_decode_lenient($json)
        : json_decode($json, true);
    if (!is_array($decoded)) throw new Exception("Invalid JSON in ZIP");
    if (function_exists('pos_loaded_package_from_decoded')) {
        return pos_loaded_package_from_decoded($decoded);
    }
    return ['mode' => 'legacy', 'data' => $decoded, 'manifest' => null, 'files_restored' => 0];
}

function pos_backup_collect_any_json_on_disk($extractDir) {
    $files = [];
    if (!$extractDir || !is_dir($extractDir)) {
        return $files;
    }
    $prefixLen = strlen(rtrim($extractDir, '/\\')) + 1;
    try {
        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($extractDir, FilesystemIterator::SKIP_DOTS)
        );
        foreach ($it as $f) {
            if (!$f->isFile()) continue;
            $size = (int)$f->getSize();
            if ($size < 2 || $size > 400 * 1024 * 1024) continue;
            $body = @file_get_contents($f->getPathname(), false, null, 0, min($size, 12 * 1024 * 1024));
            if ($body === false || $body === '') continue;
            if (function_exists('pos_backup_bytes_to_utf8')) {
                $body = pos_backup_bytes_to_utf8($body);
            }
            $t = ltrim($body);
            if ($t === '' || ($t[0] !== '{' && $t[0] !== '[')) continue;
            if ($size > 12 * 1024 * 1024) {
                $body = @file_get_contents($f->getPathname());
                if ($body === false) continue;
                if (function_exists('pos_backup_bytes_to_utf8')) {
                    $body = pos_backup_bytes_to_utf8($body);
                }
            }
            $rel = str_replace('\\', '/', substr($f->getPathname(), $prefixLen));
            $files[] = ['name' => $rel, 'body' => $body];
        }
    } catch (\Throwable $e) {}
    return $files;
}

function fetchAllDataForSnapshot($conn) {
    // Simulate get_data logic internally
    // For simplicity, we can just call the same logic or rely on frontend to send data.
    // But better to do it server side to avoid huge POST payload.
    // Re-using the GET logic is tricky without refactoring.
    // Let's assume the frontend sends the current state for snapshot to keep it simple and consistent with current architecture.
    return null; 
}
