<?php
// touchLastUpdate, audit log, warehouse, print_log
// --- HELPER: TOUCH UPDATE TIMESTAMP ---
function touchLastUpdate($conn) {
    $t = (string)microtime(true);
    $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('last_update', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
    $stmt->bind_param("ss", $t, $t);
    $stmt->execute();
}

// --- HELPER: SECURITY LOGGING (Advanced) - with user_id and optional entity/old/new for audit ---
function logAction($conn, $user, $type, $details, $user_id = null, $entity_type = null, $entity_id = null, $old_value = null, $new_value = null) {
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    $uid = $user_id !== null ? (int)$user_id : (isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0);
    $stmt = $conn->prepare("INSERT INTO audit_logs (user, user_id, action_type, details, ip_address, created_at, entity_type, entity_id, old_value, new_value) VALUES (?, ?, ?, ?, ?, NOW(), ?, ?, ?, ?)");
    $eid = $entity_id !== null ? (int)$entity_id : null;
    $stmt->bind_param("sissssiss", $user, $uid, $type, $details, $ip, $entity_type, $eid, $old_value, $new_value);
    $stmt->execute();
}

/**
 * Voided purchase audit is still "active" (shows in ژێبراو) until restored.
 * Restored if new_value.restored OR supplies for txn_id exist again.
 */
function pos_void_purchase_audit_is_active(mysqli $conn, array $auditRow, $snap = null): bool {
    if (!empty($auditRow['new_value'])) {
        $nv = json_decode((string)$auditRow['new_value'], true);
        if (is_array($nv) && !empty($nv['restored'])) {
            return false;
        }
    }
    if ($snap === null && !empty($auditRow['old_value'])) {
        $decoded = json_decode((string)$auditRow['old_value'], true);
        $snap = is_array($decoded) ? $decoded : null;
    }
    $txnId = is_array($snap) ? trim((string)($snap['txn_id'] ?? '')) : '';
    if ($txnId === '') {
        return true;
    }
    $st = $conn->prepare('SELECT 1 FROM supplies WHERE transaction_id = ? LIMIT 1');
    if (!$st) {
        return true;
    }
    $st->bind_param('s', $txnId);
    $st->execute();
    $res = $st->get_result();
    if ($res && $res->fetch_row()) {
        return false;
    }
    return true;
}

/** Mark a void_purchase_invoice audit row as restored (so it leaves ژێبراو lists). */
function pos_mark_void_purchase_audit_restored(mysqli $conn, int $auditId, string $txnId, string $user): void {
    if ($auditId <= 0) {
        return;
    }
    $payload = json_encode([
        'restored' => true,
        'restored_at' => date('Y-m-d H:i:s'),
        'restored_by' => $user,
        'txn_id' => $txnId,
    ], JSON_UNESCAPED_UNICODE);
    if ($payload === false) {
        return;
    }
    $st = $conn->prepare("UPDATE audit_logs SET new_value = ? WHERE id = ? AND action_type = 'void_purchase_invoice'");
    if ($st) {
        $st->bind_param('si', $payload, $auditId);
        $st->execute();
    }
}

/** Unit label for sale-edit audit lines (Badini). */
function pos_sale_edit_unit_label(string $unit): string {
    $u = strtolower(trim($unit));
    if ($u === 'carton' || $u === 'box') {
        return 'کارتۆن';
    }
    if ($u === 'pack' || $u === 'packet') {
        return 'پاکێت';
    }
    return 'دانە';
}

function pos_sale_edit_fmt_qty($q): string {
    $q = (float)$q;
    if (abs($q - round($q)) < 0.0001) {
        return (string)(int)round($q);
    }
    return rtrim(rtrim(number_format($q, 3, '.', ''), '0'), '.');
}

function pos_sale_edit_fmt_money($n): string {
    $n = function_exists('roundMoney') ? roundMoney($n) : (float)$n;
    if (abs($n - round($n)) < 0.001) {
        return number_format((float)round($n), 0, '.', ',');
    }
    return number_format((float)$n, 2, '.', ',');
}

function pos_sale_edit_line_snap(array $it): array {
    $qty = (float)($it['qty'] ?? ($it['count'] ?? 0));
    $price = (float)($it['price'] ?? 0);
    $unit = strtolower(trim((string)($it['saleUnit'] ?? ($it['sale_unit'] ?? 'piece'))));
    if (!in_array($unit, ['piece', 'pack', 'carton'], true)) {
        $unit = 'piece';
    }
    $name = trim((string)($it['name'] ?? ''));
    if ($name === '') {
        $name = 'ئایتم';
    }
    return [
        'id' => (int)($it['id'] ?? 0),
        'name' => $name,
        'qty' => $qty,
        'price' => function_exists('roundMoney') ? roundMoney($price) : $price,
        'line_total' => function_exists('roundMoney') ? roundMoney($price * $qty) : ($price * $qty),
        'saleUnit' => $unit,
        'isGift' => !empty($it['isGift']),
    ];
}

function pos_sale_edit_line_key(array $snap): string {
    $unit = (string)($snap['saleUnit'] ?? 'piece');
    $gift = !empty($snap['isGift']) ? '1' : '0';
    $id = (int)($snap['id'] ?? 0);
    if ($id > 0) {
        return 'p:' . $id . '|' . $unit . '|' . $gift;
    }
    $name = function_exists('mb_strtolower')
        ? mb_strtolower((string)($snap['name'] ?? ''), 'UTF-8')
        : strtolower((string)($snap['name'] ?? ''));
    return 'n:' . $name . '|' . $unit . '|' . $gift;
}

/**
 * Build human-readable item-level diff for sale cart edits (manager audit).
 * @return array{lines: string[], old_items: array, new_items: array}
 */
function pos_build_sale_cart_edit_diff(array $oldItems, array $newItems, $oldTotal = null, $newTotal = null, $oldDiscount = null, $newDiscount = null): array {
    $oldSnaps = [];
    foreach ($oldItems as $it) {
        if (is_array($it)) {
            $oldSnaps[] = pos_sale_edit_line_snap($it);
        }
    }
    $newSnaps = [];
    foreach ($newItems as $it) {
        if (is_array($it)) {
            $newSnaps[] = pos_sale_edit_line_snap($it);
        }
    }

    $oldByKey = [];
    foreach ($oldSnaps as $s) {
        $oldByKey[pos_sale_edit_line_key($s)][] = $s;
    }
    $newByKey = [];
    foreach ($newSnaps as $s) {
        $newByKey[pos_sale_edit_line_key($s)][] = $s;
    }

    $lines = [];
    $allKeys = array_unique(array_merge(array_keys($oldByKey), array_keys($newByKey)));
    foreach ($allKeys as $k) {
        $oList = $oldByKey[$k] ?? [];
        $nList = $newByKey[$k] ?? [];
        $max = max(count($oList), count($nList));
        for ($i = 0; $i < $max; $i++) {
            $o = $oList[$i] ?? null;
            $nw = $nList[$i] ?? null;
            if ($o && !$nw) {
                $ul = pos_sale_edit_unit_label((string)$o['saleUnit']);
                $gift = !empty($o['isGift']) ? ' (هدیە)' : '';
                $lines[] = 'سڕا: ' . $o['name'] . $gift . ' — ' . pos_sale_edit_fmt_qty($o['qty']) . ' ' . $ul
                    . ' · ' . pos_sale_edit_fmt_money($o['line_total']);
            } elseif ($nw && !$o) {
                $ul = pos_sale_edit_unit_label((string)$nw['saleUnit']);
                $gift = !empty($nw['isGift']) ? ' (هدیە)' : '';
                $lines[] = 'زیادکرا: ' . $nw['name'] . $gift . ' — ' . pos_sale_edit_fmt_qty($nw['qty']) . ' ' . $ul
                    . ' · ' . pos_sale_edit_fmt_money($nw['line_total']);
            } elseif ($o && $nw) {
                $parts = [];
                $ulO = pos_sale_edit_unit_label((string)$o['saleUnit']);
                $ulN = pos_sale_edit_unit_label((string)$nw['saleUnit']);
                if (abs((float)$o['qty'] - (float)$nw['qty']) >= 0.0001 || (string)$o['saleUnit'] !== (string)$nw['saleUnit']) {
                    $parts[] = 'ژمارە ' . pos_sale_edit_fmt_qty($o['qty']) . ' ' . $ulO . '→' . pos_sale_edit_fmt_qty($nw['qty']) . ' ' . $ulN;
                }
                if (abs((float)$o['price'] - (float)$nw['price']) >= 0.01) {
                    $parts[] = 'نرخ ' . pos_sale_edit_fmt_money($o['price']) . '→' . pos_sale_edit_fmt_money($nw['price']);
                } elseif (abs((float)$o['line_total'] - (float)$nw['line_total']) >= 0.01) {
                    $parts[] = 'کۆی هێڵ ' . pos_sale_edit_fmt_money($o['line_total']) . '→' . pos_sale_edit_fmt_money($nw['line_total']);
                }
                if (!empty($parts)) {
                    $lines[] = 'گۆڕا: ' . $nw['name'] . ' — ' . implode(' · ', $parts);
                }
            }
        }
    }

    if ($oldDiscount !== null && $newDiscount !== null && abs((float)$oldDiscount - (float)$newDiscount) >= 0.01) {
        array_unshift($lines, 'داشکاندن ' . pos_sale_edit_fmt_money($oldDiscount) . '→' . pos_sale_edit_fmt_money($newDiscount));
    }

    if (empty($lines) && $oldTotal !== null && $newTotal !== null && abs((float)$oldTotal - (float)$newTotal) >= 0.01) {
        $lines[] = 'کۆی گشتی ' . pos_sale_edit_fmt_money($oldTotal) . '→' . pos_sale_edit_fmt_money($newTotal);
    }

    return [
        'lines' => $lines,
        'old_items' => $oldSnaps,
        'new_items' => $newSnaps,
    ];
}

// --- MULTI-WAREHOUSE HELPERS ---
function pos_default_warehouse_id(mysqli $conn): int {
    static $cached = null;
    if ($cached !== null && $cached > 0) return (int)$cached;
    $fromSetting = function_exists('pos_db_get_setting_value') ? pos_db_get_setting_value($conn, 'default_warehouse_id') : null;
    if ($fromSetting !== null && (int)$fromSetting > 0) {
        $cached = (int)$fromSetting;
        return (int)$cached;
    }
    $res = $conn->query("SELECT id FROM warehouses WHERE is_default = 1 AND is_active = 1 ORDER BY id ASC LIMIT 1");
    if ($res && ($row = $res->fetch_assoc())) {
        $cached = (int)$row['id'];
        return (int)$cached;
    }
    $res2 = $conn->query("SELECT id FROM warehouses WHERE is_active = 1 ORDER BY id ASC LIMIT 1");
    if ($res2 && ($row2 = $res2->fetch_assoc())) {
        $cached = (int)$row2['id'];
        return (int)$cached;
    }
    return 1;
}

function pos_resolve_warehouse_id(mysqli $conn, $requested): int {
    $id = (int)$requested;
    if ($id > 0) {
        $st = $conn->prepare("SELECT id FROM warehouses WHERE id = ? AND is_active = 1 LIMIT 1");
        if ($st) {
            $st->bind_param('i', $id);
            $st->execute();
            $row = $st->get_result()->fetch_assoc();
            if ($row) return (int)$row['id'];
        }
    }
    return pos_default_warehouse_id($conn);
}

function pos_sync_product_qty_total(mysqli $conn, int $productId): void {
    if ($productId <= 0) return;
    $st = $conn->prepare("UPDATE products p SET qty = COALESCE((SELECT SUM(ws.qty) FROM warehouse_stock ws WHERE ws.product_id = p.id), 0) WHERE p.id = ?");
    if ($st) {
        $st->bind_param('i', $productId);
        $st->execute();
    }
}

/**
 * Multi-warehouse OFF (or never enabled): leftover qty on extra locations
 * is added onto the default warehouse so the shop is one stock. Extra
 * warehouse rows stay (re-enable later) but qty is zeroed. Returns true
 * if any extra qty was moved.
 */
function pos_collapse_extra_warehouse_stock_into_default(mysqli $conn): bool {
    try {
        $defId = pos_default_warehouse_id($conn);
        if ($defId <= 0) {
            return false;
        }
        $defSql = (int)$defId;
        if (function_exists('pos_set_open_warehouse_id')) {
            pos_set_open_warehouse_id($defId);
        }
        $chk = $conn->query(
            "SELECT 1 FROM warehouse_stock
             WHERE warehouse_id <> {$defSql} AND ABS(qty) > 0.000001
             LIMIT 1"
        );
        if (!$chk || $chk->num_rows < 1) {
            return false;
        }
        $conn->query(
            "INSERT IGNORE INTO warehouse_stock (warehouse_id, product_id, qty, min_stock)
             SELECT {$defSql}, ws.product_id, 0, 5
             FROM warehouse_stock ws
             WHERE ws.warehouse_id <> {$defSql}
             GROUP BY ws.product_id"
        );
        $conn->query(
            "UPDATE warehouse_stock d
             INNER JOIN (
                SELECT product_id, SUM(qty) AS extra
                FROM warehouse_stock
                WHERE warehouse_id <> {$defSql}
                GROUP BY product_id
                HAVING ABS(SUM(qty)) > 0.000001
             ) x ON x.product_id = d.product_id
             SET d.qty = d.qty + x.extra
             WHERE d.warehouse_id = {$defSql}"
        );
        $conn->query(
            "UPDATE warehouse_stock
             SET qty = 0
             WHERE warehouse_id <> {$defSql} AND ABS(qty) > 0.000001"
        );
        $conn->query(
            "UPDATE products p
             INNER JOIN (
                SELECT product_id, SUM(qty) AS s
                FROM warehouse_stock
                GROUP BY product_id
             ) x ON x.product_id = p.id
             SET p.qty = x.s
             WHERE COALESCE(p.trackStock, 1) = 1"
        );
        return true;
    } catch (Throwable $e) {
        return false;
    }
}

/**
 * Pharmacies often "void" products after failed delete — purchase history remains but
 * POS/warehouse hide them (is_active=0). Reactivate inactive SKUs that still have stock
 * or any purchase (supplies) history so they become findable again.
 * Returns number of products restored.
 */
function pos_heal_reactivate_inactive_with_stock(mysqli $conn): int {
    try {
        if (function_exists('checkAndAddCol')) {
            checkAndAddCol($conn, 'products', 'is_active', 'TINYINT(1) NOT NULL DEFAULT 1');
        }
        $sql = "UPDATE products p
                SET p.is_active = 1
                WHERE (p.is_active = 0)
                  AND (
                    COALESCE(p.qty, 0) > 0.000001
                    OR EXISTS (
                        SELECT 1 FROM warehouse_stock ws
                        WHERE ws.product_id = p.id AND COALESCE(ws.qty, 0) > 0.000001
                    )
                    OR EXISTS (
                        SELECT 1 FROM supplies s WHERE s.prodId = p.id LIMIT 1
                    )
                  )";
        if (!$conn->query($sql)) return 0;
        return (int)$conn->affected_rows;
    } catch (Throwable $e) {
        return 0;
    }
}

/**
 * Heal legacy desync: products.qty had stock but warehouse_stock was 0/missing.
 * Bulk-heal when shop has a single warehouse (products.qty ahead of warehouse_stock).
 */
function pos_heal_single_warehouse_stock_bulk(mysqli $conn): void {
    $res = $conn->query("SELECT COUNT(*) AS c FROM warehouses");
    $count = ($res && ($row = $res->fetch_assoc())) ? (int)($row['c'] ?? 0) : 0;
    if ($count !== 1) return;
    $whId = pos_default_warehouse_id($conn);
    if ($whId <= 0) return;
    $whSql = (int)$whId;
    $conn->query(
        "INSERT IGNORE INTO warehouse_stock (warehouse_id, product_id, qty, min_stock)
         SELECT {$whSql}, p.id, p.qty, COALESCE(p.minStock, 5)
         FROM products p
         WHERE COALESCE(p.trackStock, 1) = 1
         AND NOT EXISTS (
            SELECT 1 FROM warehouse_stock ws
            WHERE ws.warehouse_id = {$whSql} AND ws.product_id = p.id
         )"
    );
}

/**
 * Multi-WH: leftover catalog qty (products.qty ahead of SUM warehouses) goes onto
 * the open/working warehouse. Never lower warehouse or catalog. Batches are not truth.
 */
function pos_heal_warehouse_qty_gap_from_products(mysqli $conn): void {
    try {
        $targetId = 0;
        if (function_exists('pos_session_open_warehouse_id')) {
            $targetId = (int)pos_session_open_warehouse_id();
        }
        if ($targetId > 0 && function_exists('pos_resolve_warehouse_id')) {
            $targetId = (int)pos_resolve_warehouse_id($conn, $targetId);
        }
        if ($targetId <= 0) {
            $targetId = pos_default_warehouse_id($conn);
        }
        if ($targetId <= 0) return;
        $defSql = (int)$targetId;
        @$conn->query(
            "INSERT IGNORE INTO warehouse_stock (warehouse_id, product_id, qty, min_stock)
             SELECT {$defSql}, p.id, 0, COALESCE(p.minStock, 5)
             FROM products p
             WHERE COALESCE(p.trackStock, 1) = 1
             AND NOT EXISTS (
                SELECT 1 FROM warehouse_stock ws
                WHERE ws.warehouse_id = {$defSql} AND ws.product_id = p.id
             )"
        );
        @$conn->query("DROP TEMPORARY TABLE IF EXISTS tmp_pos_wh_gap");
        @$conn->query(
            "CREATE TEMPORARY TABLE tmp_pos_wh_gap AS
             SELECT p.id AS product_id, (p.qty - COALESCE(tot.s, 0)) AS gap
             FROM products p
             LEFT JOIN (
                SELECT product_id, SUM(qty) AS s FROM warehouse_stock GROUP BY product_id
             ) tot ON tot.product_id = p.id
             WHERE COALESCE(p.trackStock, 1) = 1
               AND p.qty > COALESCE(tot.s, 0) + 0.000001"
        );
        @$conn->query(
            "UPDATE warehouse_stock ws
             INNER JOIN tmp_pos_wh_gap g ON g.product_id = ws.product_id
             SET ws.qty = ws.qty + g.gap
             WHERE ws.warehouse_id = {$defSql}"
        );
    } catch (Throwable $e) {
        return;
    }
}

/** Raise catalog when warehouses are ahead. Never lower warehouse qty to match a stale catalog. */
function pos_repair_warehouse_qty_desync(mysqli $conn): void {
    if (function_exists('pos_heal_voided_sales_warehouse_stock')) {
        pos_heal_voided_sales_warehouse_stock($conn);
    }
    $conn->query(
        "UPDATE products p
         INNER JOIN (
            SELECT product_id, SUM(qty) AS s
            FROM warehouse_stock
            GROUP BY product_id
         ) x ON x.product_id = p.id
         SET p.qty = x.s
         WHERE COALESCE(p.trackStock, 1) = 1
           AND x.s > COALESCE(p.qty, 0) + 0.000001"
    );
    // Stale catalog (ahead of warehouses) must not resurrect sold stock — pull catalog down.
    $conn->query(
        "UPDATE products p
         INNER JOIN (
            SELECT product_id, SUM(qty) AS s
            FROM warehouse_stock
            GROUP BY product_id
         ) x ON x.product_id = p.id
         SET p.qty = x.s
         WHERE COALESCE(p.trackStock, 1) = 1
           AND COALESCE(p.qty, 0) > x.s + 0.000001"
    );
}

function pos_heal_warehouse_stock_from_product(mysqli $conn, int $warehouseId, int $productId): float {
    return pos_warehouse_product_qty($conn, $warehouseId, $productId);
}

/** Current qty on one warehouse. Never copy catalog onto warehouse (that brought sold stock back). */
function pos_warehouse_product_qty(mysqli $conn, int $warehouseId, int $productId): float {
    if ($productId <= 0) return 0.0;
    $warehouseId = pos_resolve_warehouse_id($conn, $warehouseId);
    pos_ensure_warehouse_stock_row($conn, $warehouseId, $productId);
    $whQty = 0.0;
    $stWh = $conn->prepare('SELECT qty FROM warehouse_stock WHERE warehouse_id = ? AND product_id = ? LIMIT 1');
    if ($stWh) {
        $stWh->bind_param('ii', $warehouseId, $productId);
        $stWh->execute();
        $rowWh = $stWh->get_result()->fetch_assoc();
        if ($rowWh) {
            $whQty = (float)($rowWh['qty'] ?? 0);
        }
    }
    return $whQty;
}

function pos_ensure_warehouse_pin_column(mysqli $conn): void {
    if (function_exists('checkAndAddCol')) {
        checkAndAddCol($conn, 'warehouses', 'pin_hash', "VARCHAR(255) NOT NULL DEFAULT ''");
    }
}

function pos_format_warehouse_public_row(array $r): array {
    $hash = trim((string)($r['pin_hash'] ?? ''));
    unset($r['pin_hash']);
    $r['id'] = (int)($r['id'] ?? 0);
    $r['is_default'] = (int)($r['is_default'] ?? 0);
    $r['is_active'] = (int)($r['is_active'] ?? 1);
    $r['sort_order'] = (int)($r['sort_order'] ?? 0);
    $r['has_pin'] = $hash !== '' ? 1 : 0;
    return $r;
}

function pos_fetch_warehouses_public(mysqli $conn): array {
    pos_ensure_warehouse_pin_column($conn);
    $out = [];
    $res = $conn->query("SELECT id, code, name, address, is_default, is_active, sort_order, pin_hash FROM warehouses WHERE is_active = 1 ORDER BY is_default DESC, sort_order ASC, id ASC");
    if ($res) {
        while ($r = $res->fetch_assoc()) {
            $out[] = pos_format_warehouse_public_row($r);
        }
    }
    return $out;
}

function pos_session_open_warehouse_id(): int {
    return isset($_SESSION['pos_open_warehouse_id']) ? (int)$_SESSION['pos_open_warehouse_id'] : 0;
}

function pos_set_open_warehouse_id(int $id): void {
    $_SESSION['pos_open_warehouse_id'] = $id > 0 ? $id : 0;
}

function pos_warehouse_pin_hash(mysqli $conn, int $id): string {
    pos_ensure_warehouse_pin_column($conn);
    if ($id <= 0) return '';
    $st = $conn->prepare("SELECT pin_hash FROM warehouses WHERE id = ? AND is_active = 1 LIMIT 1");
    if (!$st) return '';
    $st->bind_param('i', $id);
    $st->execute();
    $row = $st->get_result()->fetch_assoc();
    return $row ? trim((string)($row['pin_hash'] ?? '')) : '';
}

function pos_any_active_warehouse_has_pin(mysqli $conn): bool {
    pos_ensure_warehouse_pin_column($conn);
    $res = $conn->query("SELECT 1 FROM warehouses WHERE is_active = 1 AND pin_hash <> '' LIMIT 1");
    return $res && $res->num_rows > 0;
}

/** Which warehouse a sale/cart must deduct from — POS chip (posted) wins when valid. */
function pos_sale_warehouse_id_or_error(mysqli $conn, int $postedWhId): array {
    if (function_exists('pos_multi_warehouse_pro_enabled') && !pos_multi_warehouse_pro_enabled($conn)) {
        $def = pos_default_warehouse_id($conn);
        if ($def > 0 && function_exists('pos_set_open_warehouse_id')) {
            pos_set_open_warehouse_id($def);
        }
        return ['ok' => true, 'id' => $def];
    }
    $posted = $postedWhId > 0 ? pos_resolve_warehouse_id($conn, $postedWhId) : 0;
    if ($posted > 0) {
        $hash = pos_warehouse_pin_hash($conn, $posted);
        if ($hash !== '') {
            $open = pos_session_open_warehouse_id();
            if ($open !== $posted) {
                return ['ok' => false, 'message' => 'پێش فرۆتنێ کۆگەهەکێ ڤەکە ب پاسۆرد'];
            }
        } elseif (pos_session_open_warehouse_id() !== $posted) {
            pos_set_open_warehouse_id($posted);
        }
        return ['ok' => true, 'id' => $posted];
    }
    $open = pos_session_open_warehouse_id();
    if ($open > 0) {
        return ['ok' => true, 'id' => pos_resolve_warehouse_id($conn, $open)];
    }
    if (pos_any_active_warehouse_has_pin($conn)) {
        return ['ok' => false, 'message' => 'پێش فرۆتنێ کۆگەهەکێ ڤەکە ب پاسۆرد'];
    }
    return ['ok' => true, 'id' => pos_default_warehouse_id($conn)];
}

/** id => name, one query per request. */
function pos_warehouse_names_map(mysqli $conn): array {
    static $map = null;
    if ($map !== null) return $map;
    $map = [];
    $res = @$conn->query("SELECT id, name FROM warehouses");
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $map[(int)$row['id']] = trim((string)($row['name'] ?? ''));
        }
    }
    return $map;
}

function pos_ensure_sales_warehouse_column(mysqli $conn): void {
    static $done = false;
    if ($done) return;
    $done = true;
    if (function_exists('pos_ensure_sales_checkout_columns')) {
        pos_ensure_sales_checkout_columns($conn);
        return;
    }
    if (function_exists('checkAndAddCol')) {
        checkAndAddCol($conn, 'sales', 'warehouse_id', 'INT NOT NULL DEFAULT 0');
    }
}

function pos_stamp_sale_items_warehouse(mysqli $conn, string $itemsJson, int $warehouseId): string {
    if ($warehouseId <= 0) return $itemsJson;
    $items = json_decode($itemsJson, true);
    if (!is_array($items)) return $itemsJson;
    $names = pos_warehouse_names_map($conn);
    $whName = $names[$warehouseId] ?? '';
    foreach ($items as &$it) {
        if (!is_array($it)) continue;
        $it['warehouse_id'] = $warehouseId;
        if ($whName !== '') $it['warehouse_name'] = $whName;
    }
    unset($it);
    $enc = json_encode($items, JSON_UNESCAPED_UNICODE);
    return ($enc !== false) ? $enc : $itemsJson;
}

function pos_hydrate_sale_item_warehouse($item, int $saleWid, array $names) {
    $isObj = is_object($item);
    if (!$isObj && !is_array($item)) return $item;
    $wid = $isObj ? (int)($item->warehouse_id ?? 0) : (int)($item['warehouse_id'] ?? 0);
    if ($wid <= 0) $wid = $saleWid;
    $wname = $isObj ? trim((string)($item->warehouse_name ?? '')) : trim((string)($item['warehouse_name'] ?? ''));
    if ($wname === '' && $wid > 0 && isset($names[$wid])) $wname = $names[$wid];
    if ($isObj) {
        if ($wid > 0) $item->warehouse_id = $wid;
        if ($wname !== '') $item->warehouse_name = $wname;
        return $item;
    }
    if ($wid > 0) $item['warehouse_id'] = $wid;
    if ($wname !== '') $item['warehouse_name'] = $wname;
    return $item;
}

/** Fill warehouse_id / warehouse_name on sale rows + line items (old receipts from stock_movements). */
function pos_attach_sales_warehouse(mysqli $conn, array &$salesRows): void {
    if (!$salesRows) return;
    pos_ensure_sales_warehouse_column($conn);
    $names = pos_warehouse_names_map($conn);
    $missing = [];
    foreach ($salesRows as $i => $r) {
        if (!is_array($r)) continue;
        if ((int)($r['warehouse_id'] ?? 0) <= 0) {
            $id = (int)($r['id'] ?? 0);
            if ($id > 0) $missing[$id] = $i;
        }
    }
    if ($missing) {
        $in = implode(',', array_map('intval', array_keys($missing)));
        $res = @$conn->query("SELECT reference_id, warehouse_id FROM stock_movements WHERE reference_type = 'sale' AND warehouse_id > 0 AND reference_id IN ($in)");
        if ($res) {
            while ($row = $res->fetch_assoc()) {
                $rid = (int)$row['reference_id'];
                $wid = (int)($row['warehouse_id'] ?? 0);
                if ($wid <= 0 || !isset($missing[$rid])) continue;
                $idx = $missing[$rid];
                if ((int)($salesRows[$idx]['warehouse_id'] ?? 0) <= 0) {
                    $salesRows[$idx]['warehouse_id'] = $wid;
                }
            }
        }
    }
    foreach ($salesRows as &$r) {
        if (!is_array($r)) continue;
        $wid = (int)($r['warehouse_id'] ?? 0);
        if ($wid > 0) {
            $r['warehouse_id'] = $wid;
            if (!empty($names[$wid])) $r['warehouse_name'] = $names[$wid];
        }
        $items = $r['items'] ?? null;
        if (is_array($items)) {
            foreach ($items as $k => $it) {
                $items[$k] = pos_hydrate_sale_item_warehouse($it, $wid, $names);
            }
            $r['items'] = $items;
        }
    }
    unset($r);
}

function pos_attach_sales_history_adjustment_meta(mysqli $conn, array &$sales): void {
    if (!$sales) return;
    if (function_exists('pos_attach_sales_warehouse')) {
        pos_attach_sales_warehouse($conn, $sales);
    }
    $ids = [];
    foreach ($sales as $r) {
        $id = (int)($r['id'] ?? 0);
        if ($id > 0) $ids[$id] = true;
    }
    if (!$ids) return;
    $in = implode(',', array_map('intval', array_keys($ids)));
    $editCounts = [];
    $resE = @$conn->query("SELECT entity_id, COUNT(*) AS c FROM audit_logs
        WHERE action_type IN ('sale_cart_replace','sale_line_edit','sale_line_add','sale_line_delete')
          AND entity_id IN ($in)
        GROUP BY entity_id");
    if ($resE) {
        while ($row = $resE->fetch_assoc()) {
            $editCounts[(int)$row['entity_id']] = (int)($row['c'] ?? 0);
        }
    }
    $returnCounts = [];
    $resR = @$conn->query("SELECT sale_id, COUNT(*) AS c FROM `returns` WHERE sale_id IN ($in) GROUP BY sale_id");
    if ($resR) {
        while ($row = $resR->fetch_assoc()) {
            $returnCounts[(int)$row['sale_id']] = (int)($row['c'] ?? 0);
        }
    }
    foreach ($sales as &$r) {
        $id = (int)($r['id'] ?? 0);
        $r['edit_count'] = (int)($editCounts[$id] ?? 0);
        $r['has_edits'] = $r['edit_count'] > 0 ? 1 : 0;
        $r['return_count'] = (int)($returnCounts[$id] ?? 0);
        $r['has_return'] = $r['return_count'] > 0 ? 1 : 0;
        $r['warehouse_id'] = (int)($r['warehouse_id'] ?? 0);
        if (empty($r['warehouse_name'])) $r['warehouse_name'] = '';
    }
    unset($r);
}

/**
 * Edit / return / void flags for purchase invoices (keyed by transaction_id).
 * Also returns active voided invoices so they can appear in the same list as sales history.
 *
 * @return array{by_txn: array<string, array>, voided: list<array>}
 */
function pos_purchase_history_adjustments(mysqli $conn, array $supplies, string $dtStart, string $dtEnd): array {
    $byTxn = [];
    $txnIds = [];
    $invToTxns = [];
    foreach ($supplies as $r) {
        if (!is_array($r)) continue;
        $txn = trim((string)($r['transaction_id'] ?? ''));
        if ($txn === '') continue;
        $txnIds[$txn] = true;
        if (!isset($byTxn[$txn])) {
            $byTxn[$txn] = [
                'edit_count' => 0,
                'has_edits' => 0,
                'return_count' => 0,
                'has_return' => 0,
                'is_voided' => 0,
            ];
        }
        $inv = trim((string)($r['supplier_invoice_number'] ?? ''));
        $comp = trim((string)($r['company'] ?? ''));
        if ($inv !== '' && $comp !== '') {
            $invToTxns[$comp . "\0" . $inv][$txn] = true;
        }
    }

    $resE = @$conn->query("SELECT details FROM audit_logs
        WHERE action_type IN ('purchase_cart_replace','purchase_line_edit','purchase_line_add','purchase_line_delete')
        ORDER BY id DESC LIMIT 8000");
    if ($resE) {
        while ($row = $resE->fetch_assoc()) {
            $details = (string)($row['details'] ?? '');
            $txnId = '';
            if (preg_match('/#([A-Za-z0-9_-]+)/u', $details, $m)) {
                $txnId = (string)$m[1];
            }
            if ($txnId === '' || !isset($txnIds[$txnId])) continue;
            $byTxn[$txnId]['edit_count']++;
            $byTxn[$txnId]['has_edits'] = 1;
        }
    }

    $resRet = @$conn->query("SELECT company_name, supplier_invoice_number, COUNT(*) AS c
        FROM purchase_returns
        GROUP BY company_name, supplier_invoice_number");
    if ($resRet) {
        while ($row = $resRet->fetch_assoc()) {
            $key = trim((string)($row['company_name'] ?? '')) . "\0" . trim((string)($row['supplier_invoice_number'] ?? ''));
            if ($key === "\0" || !isset($invToTxns[$key])) continue;
            $c = (int)($row['c'] ?? 0);
            if ($c <= 0) continue;
            foreach ($invToTxns[$key] as $txn => $_x) {
                if (strpos($txn, 'TXPR') === 0) continue;
                $byTxn[$txn]['return_count'] += $c;
                $byTxn[$txn]['has_return'] = 1;
            }
        }
    }

    foreach ($supplies as $r) {
        if (!is_array($r)) continue;
        if (strtolower(trim((string)($r['type'] ?? ''))) !== 'return') continue;
        $inv = trim((string)($r['supplier_invoice_number'] ?? ''));
        $comp = trim((string)($r['company'] ?? ''));
        $key = $comp . "\0" . $inv;
        if ($inv === '' || !isset($invToTxns[$key])) continue;
        foreach ($invToTxns[$key] as $txn => $_x) {
            if (strpos($txn, 'TXPR') === 0) continue;
            $byTxn[$txn]['return_count']++;
            $byTxn[$txn]['has_return'] = 1;
        }
    }

    $voided = [];
    $stV = $conn->prepare(
        "SELECT id, user, details, created_at, old_value, new_value
         FROM audit_logs
         WHERE action_type = 'void_purchase_invoice'
           AND created_at >= ? AND created_at <= ?
         ORDER BY id DESC
         LIMIT 800"
    );
    if ($stV) {
        $stV->bind_param('ss', $dtStart, $dtEnd);
        $stV->execute();
        $resV = $stV->get_result();
        while ($resV && ($row = $resV->fetch_assoc())) {
            $snap = null;
            if (!empty($row['old_value'])) {
                $decoded = json_decode((string)$row['old_value'], true);
                if (is_array($decoded)) $snap = $decoded;
            }
            if (function_exists('pos_void_purchase_audit_is_active') && !pos_void_purchase_audit_is_active($conn, $row, $snap)) {
                continue;
            }
            $kind = '';
            if (is_array($snap) && !empty($snap['kind'])) {
                $kind = strtolower(trim((string)$snap['kind']));
            } elseif (is_array($snap) && !empty($snap['type'])) {
                $kind = (strtolower(trim((string)$snap['type'])) === 'return') ? 'return' : 'purchase';
            }
            if ($kind === 'return') continue;
            $txnId = is_array($snap) ? trim((string)($snap['txn_id'] ?? '')) : '';
            if ($txnId === '') continue;
            $items = [];
            if (is_array($snap) && !empty($snap['items']) && is_array($snap['items'])) {
                foreach ($snap['items'] as $it) {
                    if (!is_array($it)) continue;
                    $items[] = [
                        'prodId' => (int)($it['prodId'] ?? 0),
                        'itemName' => (string)($it['name'] ?? ''),
                        'qtyAdded' => (float)($it['qty'] ?? 0),
                        'totalCost' => function_exists('roundMoney') ? roundMoney($it['totalCost'] ?? 0) : (float)($it['totalCost'] ?? 0),
                        'batch_number' => (string)($it['batch'] ?? ''),
                    ];
                }
            }
            $voided[] = [
                'txn_id' => $txnId,
                'audit_id' => (int)($row['id'] ?? 0),
                'company' => is_array($snap) ? (string)($snap['company'] ?? '') : '',
                'type' => is_array($snap) ? (string)($snap['type'] ?? 'cash') : 'cash',
                'total' => is_array($snap) ? (function_exists('roundMoney') ? roundMoney($snap['total'] ?? 0) : (float)($snap['total'] ?? 0)) : 0,
                'date' => is_array($snap) ? (string)($snap['date'] ?? ($row['created_at'] ?? '')) : (string)($row['created_at'] ?? ''),
                'supplier_invoice_number' => is_array($snap) ? (string)($snap['supplier_invoice_number'] ?? '') : '',
                'items_count' => is_array($snap) ? (int)($snap['items_count'] ?? count($items)) : count($items),
                'items' => $items,
                'void_user' => (string)($row['user'] ?? ''),
                'void_at' => (string)($row['created_at'] ?? ''),
            ];
        }
    }

    return ['by_txn' => $byTxn, 'voided' => $voided];
}

function pos_sale_row_warehouse_id(mysqli $conn, array $row): int {
    $wid = (int)($row['warehouse_id'] ?? 0);
    if ($wid > 0) return pos_resolve_warehouse_id($conn, $wid);
    $items = $row['items_json'] ?? ($row['items'] ?? null);
    if (is_string($items)) $items = json_decode($items, true);
    if (is_array($items)) {
        foreach ($items as $it) {
            if (is_object($it)) $it = (array)$it;
            if (!is_array($it)) continue;
            $iw = (int)($it['warehouse_id'] ?? 0);
            if ($iw > 0) return pos_resolve_warehouse_id($conn, $iw);
        }
    }
    $sid = (int)($row['id'] ?? 0);
    if ($sid > 0) {
        $st = $conn->prepare("SELECT warehouse_id FROM stock_movements WHERE reference_type = 'sale' AND reference_id = ? AND warehouse_id > 0 ORDER BY id ASC LIMIT 1");
        if ($st) {
            $st->bind_param('i', $sid);
            $st->execute();
            $mv = $st->get_result()->fetch_assoc();
            if ($mv && (int)($mv['warehouse_id'] ?? 0) > 0) {
                return pos_resolve_warehouse_id($conn, (int)$mv['warehouse_id']);
            }
        }
    }
    return pos_default_warehouse_id($conn);
}

/** @return list<array{pid:int,wid:int,qty:float}> */
function pos_sale_tracked_piece_counts(mysqli $conn, array $items): array {
    $pids = [];
    foreach ($items as $prod) {
        if (is_object($prod)) $prod = (array)$prod;
        if (!is_array($prod)) continue;
        $pid = (int)($prod['id'] ?? 0);
        if ($pid > 0) $pids[$pid] = true;
    }
    $trackMap = [];
    if ($pids) {
        $in = implode(',', array_map('intval', array_keys($pids)));
        $res = @$conn->query("SELECT id, trackStock FROM products WHERE id IN ($in)");
        if ($res) {
            while ($r = $res->fetch_assoc()) {
                $trackMap[(int)$r['id']] = ((int)($r['trackStock'] ?? 1) === 1);
            }
        }
    }
    $counts = [];
    foreach ($items as $prod) {
        if (is_object($prod)) $prod = (array)$prod;
        if (!is_array($prod)) continue;
        $pid = (int)($prod['id'] ?? 0);
        if ($pid <= 0) continue;
        $tracked = !empty($trackMap[$pid]);
        if (array_key_exists('trackStock', $prod)) {
            $ts = $prod['trackStock'];
            $tracked = ($ts === true || $ts === 1 || $ts === '1');
        }
        if (!$tracked) continue;
        $pcs = function_exists('pos_sale_item_pieces') ? pos_sale_item_pieces($prod) : (float)($prod['qty'] ?? $prod['count'] ?? 1);
        if ($pcs <= 0.0000001) continue;
        $wid = (int)($prod['warehouse_id'] ?? 0);
        $key = $pid . ':' . $wid;
        if (!isset($counts[$key])) {
            $counts[$key] = ['pid' => $pid, 'wid' => $wid, 'qty' => 0.0];
        }
        $counts[$key]['qty'] += $pcs;
    }
    return array_values($counts);
}

function pos_restore_stock_batch_qty(mysqli $conn, int $pid, float $qty, int $warehouseId): void {
    if ($pid <= 0 || $qty <= 0.0000001) return;
    $stmtB = null;
    if ($warehouseId > 0) {
        $stmtB = $conn->prepare("SELECT id FROM stock_batches WHERE product_id = ? AND warehouse_id = ? ORDER BY expiry_date ASC, id ASC LIMIT 1 FOR UPDATE");
        if ($stmtB) $stmtB->bind_param('ii', $pid, $warehouseId);
    }
    if (!$stmtB) {
        $stmtB = $conn->prepare("SELECT id FROM stock_batches WHERE product_id = ? ORDER BY expiry_date ASC, id ASC LIMIT 1 FOR UPDATE");
        if ($stmtB) $stmtB->bind_param('i', $pid);
    }
    if (!$stmtB) return;
    $stmtB->execute();
    $resB = $stmtB->get_result();
    if ($resB && ($b = $resB->fetch_assoc())) {
        $bid = (int)$b['id'];
        $stmtBU = $conn->prepare("UPDATE stock_batches SET qty = qty + ? WHERE id = ?");
        if ($stmtBU) {
            $stmtBU->bind_param('di', $qty, $bid);
            $stmtBU->execute();
        }
        return;
    }
    $fallbackDate = date('Y-m-d', strtotime('+10 years'));
    $stmtBI = $conn->prepare("INSERT INTO stock_batches (product_id, expiry_date, qty, unit_cost, source_type, source_id, transaction_id, warehouse_id) VALUES (?, ?, ?, 0, 'void_restore', 0, ?, ?)");
    if ($stmtBI) {
        $txnRestore = 'TXV' . str_replace('.', '', uniqid('', true));
        $wh = $warehouseId > 0 ? $warehouseId : pos_default_warehouse_id($conn);
        $stmtBI->bind_param('isdsi', $pid, $fallbackDate, $qty, $txnRestore, $wh);
        if (!$stmtBI->execute()) {
            $stmtBI2 = $conn->prepare("INSERT INTO stock_batches (product_id, expiry_date, qty, unit_cost, source_type, source_id, transaction_id) VALUES (?, ?, ?, 0, 'void_restore', 0, ?)");
            if ($stmtBI2) {
                $stmtBI2->bind_param('isds', $pid, $fallbackDate, $qty, $txnRestore);
                $stmtBI2->execute();
            }
        }
    }
}

/**
 * $sign +1 = void restore into warehouse; -1 = undelete / re-consume.
 */
function pos_apply_sale_warehouse_stock_delta(mysqli $conn, array $counts, int $fallbackWh, string $user, int $saleId, string $moveType, float $sign, string $note): void {
    $fallbackWh = $fallbackWh > 0 ? pos_resolve_warehouse_id($conn, $fallbackWh) : pos_default_warehouse_id($conn);
    foreach ($counts as $c) {
        $pid = (int)($c['pid'] ?? 0);
        $lineQty = (float)($c['qty'] ?? 0);
        $qty = $lineQty * $sign;
        if ($pid <= 0 || abs($qty) < 0.0000001) continue;
        $wh = ((int)($c['wid'] ?? 0) > 0) ? pos_resolve_warehouse_id($conn, (int)$c['wid']) : $fallbackWh;
        pos_adjust_tracked_stock($conn, $pid, $qty, $wh);
        if (function_exists('insertStockMovement')) {
            insertStockMovement($conn, $pid, '', $moveType, $qty, 0, 0, $sign > 0 ? 'void' : 'restore', $saleId, date('Y-m-d H:i:s'), $user, $note, $wh);
        }
        if ($qty > 0) {
            pos_restore_stock_batch_qty($conn, $pid, $qty, $wh);
        } elseif ($qty < 0 && function_exists('consumeStockBatchesFefo')) {
            consumeStockBatchesFefo($conn, $pid, abs($qty), '', $saleId, '');
        }
    }
}

function pos_void_restore_sale_warehouse_stock(mysqli $conn, int $saleId, array $row, string $user): void {
    $items = $row['items_json'] ?? ($row['items'] ?? []);
    if (is_string($items)) $items = json_decode($items, true);
    if (!is_array($items)) $items = [];
    $counts = pos_sale_tracked_piece_counts($conn, $items);
    $fallback = pos_sale_row_warehouse_id($conn, $row);
    pos_apply_sale_warehouse_stock_delta($conn, $counts, $fallback, $user, $saleId, 'sale_void_wh', 1.0, "Voided Sale #$saleId");
}

function pos_restore_sale_reconsume_warehouse_stock(mysqli $conn, int $saleId, array $row, string $user): void {
    $items = $row['items_json'] ?? ($row['items'] ?? []);
    if (is_string($items)) $items = json_decode($items, true);
    if (!is_array($items)) $items = [];
    $counts = pos_sale_tracked_piece_counts($conn, $items);
    $fallback = pos_sale_row_warehouse_id($conn, $row);
    pos_apply_sale_warehouse_stock_delta($conn, $counts, $fallback, $user, $saleId, 'sale_restore_void', -1.0, "Restored Sale #$saleId");
}

/** One-time: voided invoices that only bumped products.qty, not warehouse_stock. */
function pos_heal_voided_sales_warehouse_stock(mysqli $conn): void {
    static $ran = false;
    if ($ran) return;
    $ran = true;
    if (!function_exists('pos_db_get_setting_value') || !function_exists('pos_db_set_setting_value')) return;
    if (pos_db_get_setting_value($conn, 'void_wh_restore_heal_v1') === '1') return;
    pos_ensure_sales_warehouse_column($conn);
    $res = @$conn->query("SELECT id, items_json, warehouse_id FROM sales WHERE is_returned = 1 AND created_at >= DATE_SUB(NOW(), INTERVAL 14 DAY)");
    if (!$res) {
        pos_db_set_setting_value($conn, 'void_wh_restore_heal_v1', '1');
        return;
    }
    while ($sale = $res->fetch_assoc()) {
        $sid = (int)($sale['id'] ?? 0);
        if ($sid <= 0) continue;
        $chk = @$conn->query("SELECT 1 FROM stock_movements WHERE reference_id = {$sid} AND movement_type = 'sale_void_wh' LIMIT 1");
        if ($chk && $chk->num_rows > 0) continue;
        $got = false;
        $mv = @$conn->query("SELECT product_id, warehouse_id, SUM(quantity) AS q
            FROM stock_movements
            WHERE reference_id = {$sid}
              AND reference_type = 'sale'
              AND movement_type IN ('sale', 'sale_edit')
              AND warehouse_id > 0
            GROUP BY product_id, warehouse_id
            HAVING SUM(quantity) < -0.0000001");
        if ($mv) {
            while ($row = $mv->fetch_assoc()) {
                $restore = abs((float)($row['q'] ?? 0));
                $pid = (int)($row['product_id'] ?? 0);
                $wh = (int)($row['warehouse_id'] ?? 0);
                if ($pid <= 0 || $wh <= 0 || $restore < 0.0000001) continue;
                pos_adjust_tracked_stock($conn, $pid, $restore, $wh);
                if (function_exists('insertStockMovement')) {
                    insertStockMovement($conn, $pid, '', 'sale_void_wh', $restore, 0, 0, 'void', $sid, date('Y-m-d H:i:s'), 'System', "Heal void warehouse sale #$sid", $wh);
                }
                pos_restore_stock_batch_qty($conn, $pid, $restore, $wh);
                $got = true;
            }
        }
        if (!$got && (int)($sale['warehouse_id'] ?? 0) > 0) {
            pos_void_restore_sale_warehouse_stock($conn, $sid, $sale, 'System');
        }
    }
    pos_db_set_setting_value($conn, 'void_wh_restore_heal_v1', '1');
}

function pos_ensure_warehouse_stock_row(mysqli $conn, int $warehouseId, int $productId): void {
    if ($warehouseId <= 0 || $productId <= 0) return;
    $st = $conn->prepare("INSERT IGNORE INTO warehouse_stock (warehouse_id, product_id, qty, min_stock) SELECT ?, ?, 0, COALESCE(p.minStock, 5) FROM products p WHERE p.id = ?");
    if ($st) {
        $st->bind_param('iii', $warehouseId, $productId, $productId);
        $st->execute();
    }
}

function pos_delta_warehouse_stock(mysqli $conn, int $warehouseId, int $productId, float $delta): bool {
    if ($productId <= 0 || abs($delta) < 0.0000001) return true;
    $warehouseId = pos_resolve_warehouse_id($conn, $warehouseId);
    pos_ensure_warehouse_stock_row($conn, $warehouseId, $productId);
    $st = $conn->prepare("UPDATE warehouse_stock SET qty = qty + ? WHERE warehouse_id = ? AND product_id = ?");
    if (!$st) return false;
    $st->bind_param('dii', $delta, $warehouseId, $productId);
    $ok = $st->execute();
    pos_sync_product_qty_total($conn, $productId);
    return $ok;
}

function pos_set_warehouse_stock(mysqli $conn, int $warehouseId, int $productId, float $newQty): bool {
    if ($productId <= 0) return false;
    $warehouseId = pos_resolve_warehouse_id($conn, $warehouseId);
    $newQty = roundMoney($newQty);
    pos_ensure_warehouse_stock_row($conn, $warehouseId, $productId);
    $st = $conn->prepare("UPDATE warehouse_stock SET qty = ? WHERE warehouse_id = ? AND product_id = ?");
    if (!$st) return false;
    $st->bind_param('dii', $newQty, $warehouseId, $productId);
    $ok = $st->execute();
    pos_sync_product_qty_total($conn, $productId);
    return $ok;
}

/** Recipe ingredients per 1 finished unit (product_id => [ingredient_id => qty]). */
function pos_get_recipe_map(mysqli $conn, int $productId): array {
    $map = [];
    if ($productId <= 0) return $map;
    $st = $conn->prepare("SELECT ingredient_id, qty FROM recipes WHERE product_id = ?");
    if (!$st) return $map;
    $st->bind_param('i', $productId);
    $st->execute();
    $res = $st->get_result();
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $ingId = (int)($row['ingredient_id'] ?? 0);
            $q = (float)($row['qty'] ?? 0);
            if ($ingId > 0 && $q > 0) {
                $map[$ingId] = ($map[$ingId] ?? 0) + $q;
            }
        }
    }
    return $map;
}

/**
 * Sale/stock plan: use pre-produced finished stock when available; otherwise consume recipe ingredients.
 * $saleMode: auto | direct (finished stock only) | manufacture (ingredients only)
 * @return array{finished: float, ingredients: array<int, float>}
 */
function pos_normalize_recipe_sale_mode($mode): string {
    $m = strtolower(trim((string)$mode));
    return in_array($m, ['auto', 'direct', 'manufacture'], true) ? $m : 'auto';
}

function pos_recipe_deduction_plan(mysqli $conn, int $productId, float $salePieces, int $warehouseId, string $saleMode = 'auto'): array {
    $plan = ['finished' => 0.0, 'ingredients' => []];
    if ($productId <= 0 || $salePieces <= 0.0000001) return $plan;
    $saleMode = pos_normalize_recipe_sale_mode($saleMode);

    $tracksStock = false;
    $stP = $conn->prepare("SELECT trackStock FROM products WHERE id = ? LIMIT 1");
    if ($stP) {
        $stP->bind_param('i', $productId);
        $stP->execute();
        $rowP = $stP->get_result()->fetch_assoc();
        $tracksStock = $rowP && ((int)($rowP['trackStock'] ?? 0) === 1);
    }

    $recipe = pos_get_recipe_map($conn, $productId);
    if (empty($recipe)) {
        if ($tracksStock) $plan['finished'] = $salePieces;
        return $plan;
    }

    if ($saleMode === 'direct') {
        if ($tracksStock) $plan['finished'] = $salePieces;
        return $plan;
    }

    if ($saleMode === 'manufacture') {
        foreach ($recipe as $ingId => $perUnit) {
            $iid = (int)$ingId;
            $plan['ingredients'][$iid] = ($plan['ingredients'][$iid] ?? 0) + ((float)$perUnit * $salePieces);
        }
        return $plan;
    }

    if ($tracksStock) {
        $available = pos_heal_warehouse_stock_from_product($conn, $warehouseId, $productId);
        if ($available + 0.000001 >= $salePieces) {
            $plan['finished'] = $salePieces;
            return $plan;
        }
    }

    foreach ($recipe as $ingId => $perUnit) {
        $iid = (int)$ingId;
        $plan['ingredients'][$iid] = ($plan['ingredients'][$iid] ?? 0) + ((float)$perUnit * $salePieces);
    }
    return $plan;
}

function pos_adjust_tracked_stock(mysqli $conn, int $productId, float $delta, int $warehouseId = 0): bool {
    if ($productId <= 0 || abs($delta) < 0.0000001) return true;
    $st = $conn->prepare("SELECT trackStock FROM products WHERE id = ? LIMIT 1");
    if ($st) {
        $st->bind_param('i', $productId);
        $st->execute();
        $row = $st->get_result()->fetch_assoc();
        if ($row && isset($row['trackStock']) && (int)$row['trackStock'] === 0) return true;
    }
    return pos_delta_warehouse_stock($conn, $warehouseId, $productId, $delta);
}

function pos_warehouse_stock_map(mysqli $conn): array {
    $map = [];
    $res = $conn->query("SELECT warehouse_id, product_id, qty, min_stock FROM warehouse_stock");
    if (!$res) return $map;
    while ($row = $res->fetch_assoc()) {
        $wh = (int)$row['warehouse_id'];
        $pid = (int)$row['product_id'];
        if (!isset($map[$wh])) $map[$wh] = [];
        $map[$wh][$pid] = [
            'qty' => roundMoney((float)($row['qty'] ?? 0)),
            'min_stock' => (int)($row['min_stock'] ?? 5),
        ];
    }
    return $map;
}

// --- HELPER: Stock movement audit trail (for Stock Card) ---
function insertStockMovement($conn, $product_id, $barcode, $movement_type, $quantity, $unit_cost, $total_value, $reference_type, $reference_id, $date, $user, $note = '', $warehouse_id = 0, $to_warehouse_id = null) {
    $unit_cost = roundMoney($unit_cost);
    $total_value = roundMoney($total_value);
    $warehouse_id = pos_resolve_warehouse_id($conn, $warehouse_id);
    $toWh = ($to_warehouse_id !== null && (int)$to_warehouse_id > 0) ? (int)$to_warehouse_id : null;
    $stmt = $conn->prepare("INSERT INTO stock_movements (product_id, barcode, movement_type, quantity, unit_cost, total_value, reference_type, reference_id, date, user, note, warehouse_id, to_warehouse_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    if (!$stmt) return false;
    $stmt->bind_param("issdddsisssii", $product_id, $barcode, $movement_type, $quantity, $unit_cost, $total_value, $reference_type, $reference_id, $date, $user, $note, $warehouse_id, $toWh);
    return $stmt->execute();
}

// --- HELPER: General History (print_log) for print/delete actions (non-sales) ---
function logGeneralHistory($conn, $doc_type, $doc_id, $action, $note = '', $details = '') {
    try {
        $user = function_exists('pos_session_user_name') ? pos_session_user_name() : 'System';
        $uid = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $stmt = $conn->prepare("INSERT INTO print_log (doc_type, doc_id, action, user, user_id, note, details, ip_address, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
        if(!$stmt) return false;
        $docTypeSafe = (string)$doc_type;
        $docIdSafe = (string)$doc_id;
        $actionSafe = (string)$action;
        $noteSafe = is_array($note) || is_object($note) ? json_encode($note, JSON_UNESCAPED_UNICODE) : (string)$note;
        $detailsSafe = is_array($details) || is_object($details) ? json_encode($details, JSON_UNESCAPED_UNICODE) : (string)$details;
        $ipSafe = (string)$ip;
        $stmt->bind_param("ssssisss", $docTypeSafe, $docIdSafe, $actionSafe, $user, $uid, $noteSafe, $detailsSafe, $ipSafe);
        return $stmt->execute();
    } catch(Throwable $e) {
        return false;
    }
}
