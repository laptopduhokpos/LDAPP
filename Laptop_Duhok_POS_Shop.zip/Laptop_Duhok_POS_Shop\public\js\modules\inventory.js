/**
 * Inventory: products, categories, warehouse, companies.
 * Logic currently lives in app.js; can be moved here gradually.
 */
import { state } from './state.js';

// Placeholder: saveProduct, renderProducts, etc. remain in app.js.
