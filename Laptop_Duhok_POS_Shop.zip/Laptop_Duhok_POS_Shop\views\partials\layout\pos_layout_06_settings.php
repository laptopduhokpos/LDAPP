        <!-- SETTINGS (ADDED LOGO UPLOAD & BACKUP FOR CASHIER) -->
        <div id="view-settings" class="workspace">
            <h2><i class="fas fa-cog"></i> <span data-i18n="settings_title">ڕێکخستن</span></h2>

            <!-- Language / اللغة -->
            <div class="card" style="border-top: 5px solid var(--primary, #6366f1);">
                <h3><i class="fas fa-language"></i> <span data-i18n="settings_language">زمان</span></h3>
                <p style="margin:0 0 12px 0; color:var(--text-muted); font-size:0.95rem;"><span data-i18n="language_desc">زمانێ سیستەمی دیار بکە د ناڤبەرا بادینی و عەرەبی فۆسحا دا.</span></p>
                <div style="display:flex; gap:12px; flex-wrap:wrap;">
                    <button type="button" id="btn-lang-badini" class="btn btn-primary" onclick="if(typeof setUILanguage==='function') setUILanguage('badini');"><i class="fas fa-check-circle"></i> <span data-i18n="settings_lang_badini">بادینی</span></button>
                    <button type="button" id="btn-lang-ar" class="btn btn-outline" style="border:2px solid var(--border); background:transparent;" onclick="if(typeof setUILanguage==='function') setUILanguage('ar');"><i class="fas fa-check-circle" style="display:none;"></i> <span data-i18n="settings_lang_ar">عەرەبی</span></button>
                </div>
            </div>

            <div class="card" style="border-top: 5px solid var(--info);">
                <h3><i class="fas fa-adjust"></i> <span data-i18n="settings_theme">دیزاین</span></h3>
                <button id="theme-toggle-btn" class="btn btn-info" style="width:100%" onclick="toggleTheme()"><i class="fas fa-eye"></i> <span data-i18n="settings_theme_medical">دێمێ پزیشکی</span></button>
            </div>

            <div class="card settings-display-card" style="border-top: 5px solid var(--success);">
                <h3><i class="fas fa-text-height"></i> <span data-i18n="settings_display_title">قەبارە</span></h3>
                <div class="settings-size-rows">
                    <div class="settings-size-row">
                        <span class="settings-size-row__label"><i class="fas fa-search"></i> <span data-i18n="settings_display_zoom">زۆم</span></span>
                        <div class="settings-size-row__ctl">
                            <button type="button" class="settings-icon-btn" onclick="if(typeof adjustZoomLevel==='function')adjustZoomLevel(-5);" title="بچووکتر" aria-label="زۆم بچووکتر"><i class="fas fa-minus"></i></button>
                            <span id="zoom-value" class="settings-icon-val">100%</span>
                            <button type="button" class="settings-icon-btn" onclick="if(typeof adjustZoomLevel==='function')adjustZoomLevel(5);" title="گەورەتر" aria-label="زۆم گەورەتر"><i class="fas fa-plus"></i></button>
                            <button type="button" class="settings-icon-btn settings-icon-btn--reset" onclick="if(typeof applyZoomLevel==='function'){applyZoomLevel(100); if(typeof saveSettings==='function')saveSettings().catch(function(){});}" title="100%" aria-label="زۆم 100%"><i class="fas fa-undo"></i></button>
                        </div>
                    </div>
                    <div class="settings-size-row">
                        <span class="settings-size-row__label"><i class="fas fa-shopping-basket"></i> <span data-i18n="settings_display_cart_width">پانی سەبەتە</span></span>
                        <div class="settings-size-row__ctl">
                            <button type="button" class="settings-icon-btn" onclick="if(typeof adjustCartPanelWidth==='function')adjustCartPanelWidth(-40);" title="سەبەتە تەنگتر" aria-label="سەبەتە تەنگتر"><i class="fas fa-minus"></i></button>
                            <span id="cart-width-value" class="settings-icon-val">380px</span>
                            <button type="button" class="settings-icon-btn" onclick="if(typeof adjustCartPanelWidth==='function')adjustCartPanelWidth(40);" title="سەبەتە پانتر" aria-label="سەبەتە پانتر"><i class="fas fa-plus"></i></button>
                            <button type="button" class="settings-icon-btn settings-icon-btn--reset" onclick="if(typeof applyCartPanelWidthPos==='function')applyCartPanelWidthPos(380);" title="380px" aria-label="سەبەتە 380px"><i class="fas fa-undo"></i></button>
                        </div>
                    </div>
                    <div class="settings-size-row">
                        <span class="settings-size-row__label"><i class="fas fa-th-large"></i> <span data-i18n="settings_display_item_size">قەبارەی ئایتم</span></span>
                        <div class="settings-size-row__ctl">
                            <button type="button" class="settings-icon-btn" onclick="if(typeof adjustCartDensity==='function')adjustCartDensity(-5);" title="ئایتم بچووکتر" aria-label="ئایتم بچووکتر"><i class="fas fa-minus"></i></button>
                            <span id="cart-density-value" class="settings-icon-val">100%</span>
                            <button type="button" class="settings-icon-btn" onclick="if(typeof adjustCartDensity==='function')adjustCartDensity(5);" title="ئایتم گەورەتر" aria-label="ئایتم گەورەتر"><i class="fas fa-plus"></i></button>
                            <button type="button" class="settings-icon-btn settings-icon-btn--reset" onclick="if(typeof applyCartDensity==='function')applyCartDensity(100);" title="100%" aria-label="ئایتم 100%"><i class="fas fa-undo"></i></button>
                        </div>
                    </div>
                </div>
                <input type="range" id="set-zoom" min="70" max="150" value="100" step="5" hidden aria-hidden="true">
                <input type="range" id="set-cart-width" min="280" max="960" value="380" step="10" hidden aria-hidden="true">
                <input type="range" id="set-cart-density" min="85" max="130" value="100" step="5" hidden aria-hidden="true">
            </div>

            <div class="card settings-display-card" id="settings-sub-device-mgmt-card">
                <div class="settings-icon-bar" role="group" aria-label="ژێرسیستەم و تۆڕ">
                    <button type="button" class="settings-icon-ctl settings-icon-ctl--btn" onclick="typeof openSubDeviceNetworkModal==='function'&&openSubDeviceNetworkModal()" title="ژێرسیستەم و تۆڕ">
                        <span class="settings-icon-ctl__mark"><i class="fas fa-network-wired"></i></span>
                    </button>
                    <button type="button" class="settings-icon-ctl settings-icon-ctl--btn" onclick="typeof openSubDeviceNetworkModal==='function'&&openSubDeviceNetworkModal()" title="پەیوەست">
                        <span class="settings-icon-ctl__mark"><i class="fas fa-plug"></i></span>
                        <span id="subdev-stat-connected" class="settings-icon-val">0</span>
                    </button>
                    <button type="button" class="settings-icon-ctl settings-icon-ctl--btn" onclick="typeof openSubDeviceNetworkModal==='function'&&openSubDeviceNetworkModal()" title="پەسندکراو">
                        <span class="settings-icon-ctl__mark"><i class="fas fa-circle-check"></i></span>
                        <span id="subdev-stat-approved" class="settings-icon-val">0</span>
                    </button>
                    <button type="button" class="settings-icon-ctl settings-icon-ctl--btn" onclick="typeof openSubDeviceNetworkModal==='function'&&openSubDeviceNetworkModal()" title="چاوەڕوان">
                        <span class="settings-icon-ctl__mark"><i class="fas fa-hourglass-half"></i></span>
                        <span id="subdev-stat-pending" class="settings-icon-val">0</span>
                    </button>
                    <button type="button" class="settings-icon-ctl settings-icon-ctl--btn" onclick="typeof openSubDeviceNetworkModal==='function'&&openSubDeviceNetworkModal()" title="خانە">
                        <span class="settings-icon-ctl__mark"><i class="fas fa-shield-halved"></i></span>
                        <span id="subdev-stat-purchased" class="settings-icon-val">0</span>
                    </button>
                    <button type="button" class="settings-icon-btn" id="subdev-refresh-btn" onclick="if(typeof loadSubDeviceNetworkPanel==='function')loadSubDeviceNetworkPanel(true);" title="نوێکردنەوە" aria-label="نوێکردنەوە"><i class="fas fa-sync"></i></button>
                </div>
            </div>

            <div class="card settings-display-card" id="settings-changelog-card">
                <div class="settings-icon-bar" role="group">
                    <button type="button" class="settings-icon-ctl settings-icon-ctl--btn" onclick="typeof openSettingsChangelogModal==='function'&&openSettingsChangelogModal()" title="تۆمارا نوێکرن">
                        <span class="settings-icon-ctl__mark"><i class="fas fa-list-ul"></i></span>
                        <span id="settings-changelog-count" class="settings-icon-val settings-changelog-count"></span>
                    </button>
                    <button type="button" class="settings-icon-ctl settings-icon-ctl--btn" onclick="typeof openSettingsInstallCodesModal==='function'&&openSettingsInstallCodesModal()" title="کۆدێن ناسنامەیێ">
                        <span class="settings-icon-ctl__mark"><i class="fas fa-shield-alt"></i></span>
                    </button>
                </div>
            </div>

            <div class="card" id="settings-terminal-security-card" style="display:none; border-top: 5px solid #0ea5e9;">
                <h3><i class="fas fa-shield-halved"></i> <span data-i18n="settings_terminal_security_title">سیکوریتی لاپتۆپ/موبایلی فرعی</span></h3>
                <p style="margin:0 0 12px 0; color:var(--text-muted); font-size:0.92rem;" data-i18n="settings_terminal_security_desc">کۆدی خانەکەت لە لاپتۆپی سەرەکی وەربگرە و لێرە بنووسە — دوای چالاککردن POS لەسەر ئەم ئامێرە کار دەکات.</p>
                <p id="settings-terminal-security-mac" dir="ltr" style="font-family:'Rudaw',sans-serif; font-size:0.85rem; color:#64748b; margin:0 0 10px 0;">—</p>
                <div style="display:flex; flex-wrap:wrap; gap:8px; align-items:center; margin-bottom:8px;">
                    <input type="text" id="settings-terminal-security-code-input" dir="ltr" placeholder="TERM-XXXX-XXXX" autocomplete="off" class="input-std" style="flex:1; min-width:220px; font-family:'Rudaw',sans-serif; letter-spacing:0.06em;" />
                    <button type="button" class="btn btn-brand btn-sm" id="settings-terminal-security-submit-btn" onclick="if(typeof posRedeemTerminalActivationCodeFromSettings==='function')posRedeemTerminalActivationCodeFromSettings();">
                        <i class="fas fa-key"></i> <span data-i18n="settings_terminal_security_activate">چالاککردن</span>
                    </button>
                </div>
                <p id="settings-terminal-security-msg" style="display:none; margin:0; font-size:0.88rem;"></p>
            </div>

            <div class="card" id="settings-multi-device-card" style="display:none !important;" aria-hidden="true"></div>

            <div class="card settings-display-card firebase-sync-card" id="settings-firebase-sync-card">
                <div class="settings-icon-bar" role="group" aria-label="تەزامونا موبایلێ">
                    <button type="button" class="settings-icon-ctl settings-icon-ctl--btn" onclick="typeof openFirebaseSyncModal==='function'&&openFirebaseSyncModal()" title="تەزامونا موبایلێ">
                        <span class="settings-icon-ctl__mark"><i class="fas fa-mobile-screen-button"></i></span>
                        <span id="firebase-sync-status-pill" class="firebase-sync-status-pill firebase-sync-status-pill--disconnected">
                            <span id="firebase-sync-dot" class="firebase-sync-status-pill__dot" aria-hidden="true"></span>
                            <span id="firebase-sync-status-text">—</span>
                        </span>
                    </button>
                </div>
            </div>
            
            <div class="card protected" style="border-top: 5px solid var(--brand);">
                <p style="margin:0; color:var(--text-muted); font-size:1rem;"><i class="fas fa-print"></i> زانیاریێن دکانێ، لۆگۆ، ناڤ، تەلەفۆن، نڤیسینا خوارێ و هەموو ڕێکخستنێن چاپ و دیزاین ل <strong onclick="nav('print-design')" style="cursor:pointer; color:var(--info); text-decoration:underline;">ڕێکخستنێن چاپی و دیزاینێ</strong>.</p>
                <select id="set-paper-size" class="input-std" style="margin:0; display:none;" aria-hidden="true"><option value="80mm">80mm</option><option value="210mm">210mm</option></select>
            </div>

            <div class="card protected" style="border-top: 5px solid #f59e0b;">
                <h3><i class="fas fa-coins"></i> <span data-i18n="currency">دراڤ</span></h3>
                <p id="currency-settings-blurb" style="margin:0 0 12px 0; color:var(--text-muted); font-size:0.95rem;"></p>
                <div style="display:flex; flex-wrap:wrap; gap:20px; align-items:flex-start;">
                    <div id="settings-base-currency-row" class="currency-mode-panel" data-allow-iqd="1">
                        <label style="display:block; margin-bottom:8px; font-weight:bold;"><span data-i18n="shop_default_currency">دراڤێ بنەڕەتی دکانێ</span></label>
                        <div class="currency-mode-choices currency-mode-choices--compact" role="radiogroup">
                            <label class="currency-mode-choice">
                                <input type="radio" name="set-currency-mode" id="set-currency-iqd" value="IQD" checked onchange="applyCurrencySettings()">
                                <span class="currency-mode-choice-body">
                                    <span class="currency-mode-choice-title" data-i18n="currency_iqd">دیناری عێراقی (IQD)</span>
                                </span>
                            </label>
                            <label class="currency-mode-choice">
                                <input type="radio" name="set-currency-mode" id="set-currency-usd" value="USD" onchange="applyCurrencySettings()">
                                <span class="currency-mode-choice-body">
                                    <span class="currency-mode-choice-title" data-i18n="currency_usd_label">دۆلاری ئەمریکی (USD)</span>
                                </span>
                            </label>
                        </div>
                        <small id="settings-currency-catalog-hint" style="display:block; margin-top:8px; color:var(--text-muted); font-size:0.85rem; max-width:420px;" data-i18n="shop_default_currency_hint"></small>
                        <label style="display:flex; align-items:flex-start; gap:10px; cursor:pointer; margin-top:14px; max-width:420px;">
                            <input type="checkbox" id="set-show-both-currencies" checked style="margin-top:4px;" onchange="if(window.db&&window.db.settings){window.db.settings.showBothCurrencies=this.checked;} if(typeof saveSettings==='function')saveSettings().then(function(){ if(typeof refreshAfterCurrencySettingsSave==='function')refreshAfterCurrencySettingsSave(); }).catch(function(){});">
                            <span>
                                <strong style="display:block;" data-i18n="show_both_currencies">نیشاندانا هەردوو دراڤان (دینار + دۆلار)</strong>
                                <small style="display:block; margin-top:4px; color:var(--text-muted); font-size:0.85rem;" data-i18n="show_both_currencies_hint">ئەگەر ناکارا بیت، تەنێ دراڤێ بنەڕەتی دکانێ دیار دبیت.</small>
                            </span>
                        </label>
                    </div>
                    <div id="settings-exchange-rate-row">
                        <label for="set-exchange-rate" style="display:block; margin-bottom:6px; font-weight:bold;"><span data-i18n="exchange_rate_input">بهایێ 100$ (دینار بۆ فەقەی 100 دۆلار)</span></label>
                        <input type="number" id="set-exchange-rate" class="input-std" placeholder="150000" min="50" step="1" value="150000" style="width:140px; margin:0;" onchange="applyCurrencySettings()" oninput="if(typeof updateExchangeRateLivePreview==='function')updateExchangeRateLivePreview()" onblur="if(typeof onExchangeRateInputBlur==='function')onExchangeRateInputBlur()">
                        <div id="set-exchange-rate-live-preview" style="margin-top:6px; font-size:0.9rem; color:var(--brand);"></div>
                        <small style="display:block; margin-top:6px; color:var(--text-muted); font-size:0.85rem; max-width:320px;" data-i18n="exchange_rate_hint">کۆی دینار بۆ 100 دۆلار (هەمان ژمارە کۆن د خەزنێ دا). نموونە: 1$ = 1500 ⟺ 100$ = 150000.</small>
                        <small id="set-exchange-rate-iqd-lock" style="display:none; margin-top:8px; color:#b45309; font-size:0.85rem; max-width:360px; font-weight:600;" data-i18n="exchange_rate_iqd_locked"></small>
                    </div>
                </div>
            </div>

            <div class="card jewelry-only" id="settings-jewelry-rates-card" style="display:none; border-top: 5px solid #c9a227;">
                <h3><i class="fas fa-gem"></i> نرخێن زێر و زیڤ (بۆ هەر گرامێک · دینار)</h3>
                <p style="margin:0 0 12px 0; color:var(--text-muted); font-size:0.92rem;">کڕین و فرۆشتن جیا دابنێ — لە شاشەی فرۆشتن دەردەکەوێت.</p>
                <div style="overflow-x:auto;">
                    <table style="width:100%; border-collapse:collapse; min-width:420px;">
                        <thead>
                            <tr style="text-align:right; color:var(--text-muted); font-size:0.85rem;">
                                <th style="padding:8px 6px; font-weight:600;">جۆر</th>
                                <th style="padding:8px 6px; font-weight:600; color:#b45309;">کڕین</th>
                                <th style="padding:8px 6px; font-weight:600; color:#047857;">فرۆشتن</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td colspan="3" style="padding:8px 6px;">
                                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
                                        <strong>زیڤ — دەرجەکان</strong>
                                        <button type="button" class="btn btn-sm btn-brand" onclick="if(typeof promptAddSilverGrade==='function')promptAddSilverGrade(true)"><i class="fas fa-plus"></i> دەرجە</button>
                                    </div>
                                    <div id="set-silver-grades-list"></div>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding:8px 6px; font-weight:700;">زێر 18K</td>
                                <td style="padding:6px;"><input type="number" id="set-gold-buy-rate-18" class="input-std" min="0" step="1" placeholder="0" dir="ltr" style="margin:0;" onchange="if(typeof applyJewelryRateSettings==='function')applyJewelryRateSettings(false)"></td>
                                <td style="padding:6px;"><input type="number" id="set-gold-rate-18" class="input-std" min="0" step="1" placeholder="0" dir="ltr" style="margin:0;" onchange="if(typeof applyJewelryRateSettings==='function')applyJewelryRateSettings(false)"></td>
                            </tr>
                            <tr>
                                <td style="padding:8px 6px; font-weight:700;">زێر 21K</td>
                                <td style="padding:6px;"><input type="number" id="set-gold-buy-rate-21" class="input-std" min="0" step="1" placeholder="0" dir="ltr" style="margin:0;" onchange="if(typeof applyJewelryRateSettings==='function')applyJewelryRateSettings(false)"></td>
                                <td style="padding:6px;"><input type="number" id="set-gold-rate-21" class="input-std" min="0" step="1" placeholder="0" dir="ltr" style="margin:0;" onchange="if(typeof applyJewelryRateSettings==='function')applyJewelryRateSettings(false)"></td>
                            </tr>
                            <tr>
                                <td style="padding:8px 6px; font-weight:700;">زێر 22K</td>
                                <td style="padding:6px;"><input type="number" id="set-gold-buy-rate-22" class="input-std" min="0" step="1" placeholder="0" dir="ltr" style="margin:0;" onchange="if(typeof applyJewelryRateSettings==='function')applyJewelryRateSettings(false)"></td>
                                <td style="padding:6px;"><input type="number" id="set-gold-rate-22" class="input-std" min="0" step="1" placeholder="0" dir="ltr" style="margin:0;" onchange="if(typeof applyJewelryRateSettings==='function')applyJewelryRateSettings(false)"></td>
                            </tr>
                            <tr>
                                <td style="padding:8px 6px; font-weight:700;">زێر 24K</td>
                                <td style="padding:6px;"><input type="number" id="set-gold-buy-rate-24" class="input-std" min="0" step="1" placeholder="0" dir="ltr" style="margin:0;" onchange="if(typeof applyJewelryRateSettings==='function')applyJewelryRateSettings(false)"></td>
                                <td style="padding:6px;"><input type="number" id="set-gold-rate-24" class="input-std" min="0" step="1" placeholder="0" dir="ltr" style="margin:0;" onchange="if(typeof applyJewelryRateSettings==='function')applyJewelryRateSettings(false)"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div style="margin-top:12px;">
                    <button type="button" class="btn btn-brand" onclick="if(typeof applyJewelryRateSettings==='function')applyJewelryRateSettings(true)"><i class="fas fa-save"></i> پاراستنا نرخان</button>
                </div>
            </div>

            <div class="card protected" style="border-top: 5px solid var(--success);">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 20px;">
        <h3 style="margin:0;"><i class="fas fa-cogs"></i> <span data-i18n="settings_layout_main_title">ڕێکخستنێن گشتی یێن سیستەمی</span></h3>
    </div>
    
    <div style="background:var(--bg); border:1px solid var(--border); border-radius:12px; padding:15px; margin-bottom:20px;">
        <h4 style="margin-top:0; color:var(--brand); border-bottom:1px solid var(--border); padding-bottom:8px; margin-bottom:15px;"><i class="fas fa-th-large"></i> <span data-i18n="settings_sec_modules">بەشێن سەرەکی (لیست و داشبۆرد)</span></h4>
        <div class="settings-grid">
            <label class="setting-toggle-card" for="set-enable-warehouse">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-warehouse"></i></div><div class="stc-info"><h4 data-i18n="settings_t_warehouse">کۆگەه</h4></div></div>
                <div class="toggle-switch"><input type="checkbox" id="set-enable-warehouse" onchange="applyFeatureVisibility(); updateToggleCards()"><span class="slider"></span></div>
            </label>
            <label class="setting-toggle-card" for="set-enable-purchase">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-cart-shopping"></i></div><div class="stc-info"><h4 data-i18n="settings_t_purchase">کڕین</h4></div></div>
                <div class="toggle-switch"><input type="checkbox" id="set-enable-purchase" onchange="applyFeatureVisibility(); updateToggleCards()"><span class="slider"></span></div>
            </label>
            <label class="setting-toggle-card" for="set-enable-companies">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-building"></i></div><div class="stc-info"><h4 data-i18n="settings_t_companies">کۆمپانیا و دابینکەر</h4></div></div>
                <div class="toggle-switch"><input type="checkbox" id="set-enable-companies" onchange="applyFeatureVisibility(); updateToggleCards()"><span class="slider"></span></div>
            </label>
            <label class="setting-toggle-card" for="set-enable-debt">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-users"></i></div><div class="stc-info"><h4 data-i18n="settings_t_debt">کریار</h4></div></div>
                <div class="toggle-switch"><input type="checkbox" id="set-enable-debt" onchange="toggleDebtSettings(); updateToggleCards()"><span class="slider"></span></div>
            </label>
            <label class="setting-toggle-card" for="set-enable-expenses">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-money-bill-wave"></i></div><div class="stc-info"><h4 data-i18n="settings_t_expenses">مەزاختن</h4></div></div>
                <div class="toggle-switch"><input type="checkbox" id="set-enable-expenses" onchange="applyFeatureVisibility(); updateToggleCards()"><span class="slider"></span></div>
            </label>
            <label class="setting-toggle-card" for="set-enable-reports">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-chart-line"></i></div><div class="stc-info"><h4 data-i18n="settings_t_reports">ڕاپۆرت</h4></div></div>
                <div class="toggle-switch"><input type="checkbox" id="set-enable-reports" onchange="applyFeatureVisibility(); updateToggleCards()"><span class="slider"></span></div>
            </label>
            <label class="setting-toggle-card" for="set-enable-calendar">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-calendar"></i></div><div class="stc-info"><h4 data-i18n="settings_t_calendar">ڕۆژمێر</h4></div></div>
                <div class="toggle-switch"><input type="checkbox" id="set-enable-calendar" onchange="applyFeatureVisibility(); updateToggleCards()"><span class="slider"></span></div>
            </label>
            <label class="setting-toggle-card" for="set-enable-staff">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-users"></i></div><div class="stc-info"><h4 data-i18n="settings_t_staff">کارمەند</h4></div></div>
                <div class="toggle-switch"><input type="checkbox" id="set-enable-staff" onchange="applyFeatureVisibility(); updateToggleCards()"><span class="slider"></span></div>
            </label>
        </div>
    </div>

    <div style="background:var(--bg); border:1px solid var(--border); border-radius:12px; padding:15px; margin-bottom:20px;">
        <h4 style="margin-top:0; color:var(--brand); border-bottom:1px solid var(--border); padding-bottom:8px; margin-bottom:15px;"><i class="fas fa-cash-register"></i> <span data-i18n="settings_sec_pos">شێوازێ فرۆتنێ (POS)</span></h4>
        <div class="settings-grid">
            <label class="setting-toggle-card" for="set-auto-print">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-print"></i></div><div class="stc-info"><h4 data-i18n="settings_t_autoprint_sale">چاپکرنا ئوتۆماتیکی (وەسڵا فرۆتنێ)</h4></div></div>
                <div class="toggle-switch"><input type="checkbox" id="set-auto-print" onchange="updateToggleCards()"><span class="slider"></span></div>
            </label>
            <label class="setting-toggle-card" for="set-auto-print-purchase-invoice">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-file-invoice"></i></div><div class="stc-info"><h4 data-i18n="settings_t_autoprint_purchase">چاپکرنا ئوتۆماتیکی (وەسڵا کڕینێ)</h4></div></div>
                <div class="toggle-switch"><input type="checkbox" id="set-auto-print-purchase-invoice" onchange="updateToggleCards()"><span class="slider"></span></div>
            </label>
            <label class="setting-toggle-card" for="set-use-barcode">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-barcode"></i></div><div class="stc-info"><h4 data-i18n="settings_t_barcode">لێگەڕیان ب بارکۆدی</h4></div></div>
                <div class="toggle-switch"><input type="checkbox" id="set-use-barcode" onchange="toggleBarcodeUI(); updateToggleCards()"><span class="slider"></span></div>
            </label>
            <label class="setting-toggle-card" for="set-show-return-button">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-undo"></i></div><div class="stc-info"><h4 data-i18n="settings_t_return_btn">دوگما زڤڕاندنێ</h4></div></div>
                <div class="toggle-switch"><input type="checkbox" id="set-show-return-button" onchange="updateToggleCards()"><span class="slider"></span></div>
            </label>
            <label class="setting-toggle-card" for="set-enable-manual-price">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-tag"></i></div><div class="stc-info"><h4 data-i18n="settings_t_manual_price">دەستکاریا بهای</h4><p data-i18n="settings_t_manual_price_hint">ڕێگە بدە دەستکاریا نرخێ فرۆتنێ بکەی</p></div></div>
                <div class="toggle-switch"><input type="checkbox" id="set-enable-manual-price" onchange="renderBill(); updateToggleCards()"><span class="slider"></span></div>
            </label>
            <label class="setting-toggle-card" for="set-show-customer-name">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-user-tag"></i></div><div class="stc-info"><h4 data-i18n="settings_t_customer_pos">ناڤێ کریاری ل POS</h4></div></div>
                <div class="toggle-switch"><input type="checkbox" id="set-show-customer-name" onchange="toggleCustomerNameUI(); updateToggleCards()"><span class="slider"></span></div>
            </label>
            <label class="setting-toggle-card" for="set-enable-multi-cart">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-layer-group"></i></div><div class="stc-info"><h4 data-i18n="settings_t_multi_cart">سەبەتێن زێدە</h4></div></div>
                <div class="toggle-switch"><input type="checkbox" id="set-enable-multi-cart" onchange="toggleMultiCartTabsUI(); updateToggleCards()"><span class="slider"></span></div>
            </label>
            <label class="setting-toggle-card" for="set-sort-out-of-stock-bottom">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-sort-amount-down"></i></div><div class="stc-info"><h4>ئایتمێن بێ ڕەسید بچنە خوارێ</h4><p>ئەو ئایتمێن سفر قەتعەن دێ چنە دوماهییا لیستێ ل شاشا فرۆتنێ</p></div></div>
                <div class="toggle-switch"><input type="checkbox" id="set-sort-out-of-stock-bottom" onchange="if(db&&db.settings){db.settings.sortOutOfStockToBottom=this.checked;} if(typeof renderPOSMenu==='function')renderPOSMenu(document.getElementById('pos-search-input')?document.getElementById('pos-search-input').value:''); updateToggleCards(); if(typeof saveSettings==='function')saveSettings().catch(function(){});"><span class="slider"></span></div>
            </label>
        </div>
    </div>

    <div style="background:var(--bg); border:1px solid var(--border); border-radius:12px; padding:15px; margin-bottom:20px;">
        <h4 style="margin-top:0; color:var(--brand); border-bottom:1px solid var(--border); padding-bottom:8px; margin-bottom:15px;"><i class="fas fa-star"></i> <span data-i18n="settings_sec_extra">تایبەتمەندیێن زێدە</span></h4>
        <div class="settings-grid">
            <label class="setting-toggle-card" for="set-enable-kitchen">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-utensils"></i></div><div class="stc-info"><h4 data-i18n="settings_t_kitchen">بەشێ مەتبەخ / چایخانە</h4></div></div>
                <div class="toggle-switch"><input type="checkbox" id="set-enable-kitchen" onchange="applyKitchenVisibility(); updateToggleCards()"><span class="slider"></span></div>
            </label>
            <label class="setting-toggle-card" for="set-enable-waste">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-trash-alt"></i></div><div class="stc-info"><h4 data-i18n="settings_t_waste">ڕێڤەبرنا تەلەفێ</h4></div></div>
                <div class="toggle-switch"><input type="checkbox" id="set-enable-waste" onchange="toggleWasteSettings(); updateToggleCards()"><span class="slider"></span></div>
            </label>
            <label class="setting-toggle-card" for="set-enable-recipe">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-boxes-packing recipe-ui-icon"></i></div><div class="stc-info"><h4 data-i18n="settings_t_recipe">ڕێڤەبرنا ڕەچەتە (پێکهاتە)</h4><p data-i18n="settings_t_recipe_hint">بنەڕەت کوژاوە — تەنها کاتێک پێویستتە لە Settings چالاک بکە</p></div></div>
                <div class="toggle-switch"><input type="checkbox" id="set-enable-recipe" onchange="toggleRecipeSettings(); applyFeatureVisibility(); updateToggleCards()"><span class="slider"></span></div>
            </label>
        </div>
    </div>

    <div class="settings-premium-locked-wrap" style="background:linear-gradient(185deg, rgba(234,179,8,0.07) 0%, var(--card) 42%); border:1px solid rgba(212,175,55,0.38); border-radius:14px; padding:16px 18px; margin-bottom:20px; box-shadow:inset 0 1px 0 rgba(255,255,255,0.06);">
        <h4 style="margin-top:0; color:#b45309; border-bottom:1px solid var(--border); padding-bottom:10px; margin-bottom:10px; display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
            <span style="display:inline-flex; align-items:center; justify-content:center; width:36px; height:36px; border-radius:10px; background:rgba(251,191,36,0.2); color:#92400e;"><i class="fas fa-lock"></i></span>
            <span data-i18n="settings_locked_section_title">تایبەتمەندیە قفڵکراوەکان (تایبەت)</span>
        </h4>
        <p style="margin:0 0 16px; font-size:0.86rem; color:var(--text-muted); line-height:1.6; max-width:720px;" data-i18n="settings_locked_section_hint">قفڵ لێرە تەنها پیشان دەدرێت. کردنەوەی قفڵ تەنها لە مێنوی نهێنییە؛ دوای کردنەوە دەتوانیت لێرە چالاک/ناچالاک بکەیت.</p>
        <div class="settings-grid">
            <div class="setting-toggle-card setting-locked-card" data-locked-sync="set-show-note-icon">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-comment-dots"></i></div><div class="stc-info"><h4 data-i18n="settings_t_item_note">تێبینی بۆ ئایتمان</h4></div></div>
                <div class="setting-locked-card-badge"><i class="fas fa-lock" aria-hidden="true"></i><span class="setting-locked-card-label">—</span></div>
            </div>
            <div class="setting-toggle-card setting-locked-card" data-locked-sync="set-enable-takeaway">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-box"></i></div><div class="stc-info"><h4 data-i18n="settings_t_takeaway">سیستەمێ جوملە</h4><p data-i18n="settings_t_takeaway_hint">فرۆشتن ب نرخێ جوملە — دوگمەی جوملە ل POS</p></div></div>
                <div class="setting-locked-card-badge"><i class="fas fa-lock"></i><span class="setting-locked-card-label">—</span></div>
            </div>
            <div class="setting-toggle-card setting-locked-card" data-locked-sync="set-enable-wholesale">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-boxes"></i></div><div class="stc-info"><h4 data-i18n="settings_t_wholesale">فرۆتنا ب کۆم</h4></div></div>
                <div class="setting-locked-card-badge"><i class="fas fa-lock"></i><span class="setting-locked-card-label">—</span></div>
            </div>
            <div class="setting-toggle-card setting-locked-card" data-locked-sync="set-show-tables">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-th"></i></div><div class="stc-info"><h4 data-i18n="settings_t_tables">نیشاندانا مێزان</h4></div></div>
                <div class="setting-locked-card-badge"><i class="fas fa-lock"></i><span class="setting-locked-card-label">—</span></div>
            </div>
            <div class="setting-toggle-card setting-locked-card" data-locked-sync="set-enable-gift">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-gift"></i></div><div class="stc-info"><h4 data-i18n="settings_t_gift">دیاریکرنا دیاریێ</h4></div></div>
                <div class="setting-locked-card-badge"><i class="fas fa-lock"></i><span class="setting-locked-card-label">—</span></div>
            </div>
            <div class="setting-toggle-card setting-locked-card" data-locked-sync="set-enable-manual-sale">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-keyboard"></i></div><div class="stc-info"><h4 data-i18n="settings_enable_manual_sale">فرۆتنا دەستی</h4><p data-i18n="settings_enable_manual_sale_hint">ئەگەر کوژێیت، دوگمە و فرۆتنا بێ بارکۆد دەشارێتەوە.</p></div></div>
                <div class="setting-locked-card-badge"><i class="fas fa-lock"></i><span class="setting-locked-card-label">—</span></div>
            </div>
            <div class="setting-toggle-card setting-locked-card" data-locked-sync="set-unlock-staff-beyond-five">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-users-cog"></i></div><div class="stc-info"><h4 data-i18n="settings_locked_staff_cap_title">زیاتر لە ٥ کارمەند</h4><p data-i18n="settings_locked_staff_cap_hint">کردنەوە زیاتر لە ٥ هەژماری کارمەند</p></div></div>
                <div class="setting-locked-card-badge"><i class="fas fa-lock"></i><span class="setting-locked-card-label">—</span></div>
            </div>
            <div class="setting-toggle-card setting-locked-card" data-locked-sync="set-show-fab">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-bars"></i></div><div class="stc-info"><h4 data-i18n="settings_t_fab_menu">بشکوکێ لیستا سەرەکی</h4><p data-i18n="settings_locked_fab_hint">مینیوی پشکوک (FAB)</p></div></div>
                <div class="setting-locked-card-badge"><i class="fas fa-lock"></i><span class="setting-locked-card-label">—</span></div>
            </div>
            <div class="setting-toggle-card setting-locked-card" data-locked-sync="set-enable-delivery">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-truck"></i></div><div class="stc-info"><h4 data-i18n="settings_t_delivery">گەهاندن</h4></div></div>
                <div class="setting-locked-card-badge"><i class="fas fa-lock"></i><span class="setting-locked-card-label">—</span></div>
            </div>
            <div class="setting-toggle-card setting-locked-card" data-locked-sync="set-require-opening-balance-prompt">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-cash-register"></i></div><div class="stc-info"><h4 data-i18n="settings_t_opening_balance">داخوازکرنا پارەیێ دەستپێکێ</h4><p data-i18n="settings_t_opening_balance_hint">ل دەمێ ڤەکرنا سیستەمی</p></div></div>
                <div class="setting-locked-card-badge"><i class="fas fa-lock"></i><span class="setting-locked-card-label">—</span></div>
            </div>
            <div class="setting-toggle-card setting-locked-card" data-locked-sync="set-require-end-shift-reconcile-prompt">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-clipboard-check"></i></div><div class="stc-info"><h4 data-i18n="settings_t_end_shift">داخوازکرنا قاسەی ل داویێ</h4><p data-i18n="settings_t_end_shift_hint">ل دەمێ گرتنا شیفتی</p></div></div>
                <div class="setting-locked-card-badge"><i class="fas fa-lock"></i><span class="setting-locked-card-label">—</span></div>
            </div>
            <div class="setting-toggle-card setting-locked-card" data-locked-sync="set-allow-negative-stock">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-box-open"></i></div><div class="stc-info"><h4 data-i18n="settings_t_neg_stock">فرۆتنا بێ کۆگەه (سالب)</h4><p data-i18n="settings_t_neg_stock_hint">فرۆتن ئەگەر ئایتم ژی نەمابیت</p></div></div>
                <div class="setting-locked-card-badge"><i class="fas fa-lock"></i><span class="setting-locked-card-label">—</span></div>
            </div>
            <div class="setting-toggle-card setting-locked-card" data-locked-sync="set-enable-money-rounding">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-coins"></i></div><div class="stc-info"><h4 data-i18n="settings_t_money_round">خڕکرنا پارەیێ دیناری</h4><p data-i18n="settings_t_money_round_hint">کۆژم بێ باقی دەرکەڤیت</p></div></div>
                <div class="setting-locked-card-badge"><i class="fas fa-lock"></i><span class="setting-locked-card-label">—</span></div>
            </div>
            <div class="setting-toggle-card setting-locked-card" data-locked-sync="set-show-payment-modal">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-window-maximize"></i></div><div class="stc-info"><h4 data-i18n="settings_t_payment_modal">شاشا پارەدانێ</h4><p data-i18n="settings_t_payment_modal_hint">ئەگەر نەبیت، ڕاستەوخۆ وەسلێ دەردێخیت</p></div></div>
                <div class="setting-locked-card-badge"><i class="fas fa-lock"></i><span class="setting-locked-card-label">—</span></div>
            </div>
            <div class="setting-toggle-card setting-locked-card" data-locked-sync="set-enable-multi-warehouse">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-store-alt"></i></div><div class="stc-info"><h4 data-i18n="settings_t_multi_warehouse">کۆگای فرە (Pro)</h4><p data-i18n="settings_t_multi_warehouse_hint">زیاتر لە یەک کۆگە، گواستنەوە، هەڵبژاردن ل کڕین و ئایتم</p></div></div>
                <div class="setting-locked-card-badge"><i class="fas fa-lock"></i><span class="setting-locked-card-label">—</span></div>
            </div>
            <div class="setting-toggle-card setting-locked-card" data-locked-sync="premium-purchase-batch">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-layer-group"></i></div><div class="stc-info"><h4 data-i18n="settings_t_purchase_batch">ژمارا وەجبێ (کڕین)</h4><p data-i18n="settings_t_purchase_batch_hint">گەڕاندن و مێژووی کڕین بە ژمارەی وەجبە · <span data-pos-price="purchase_batch">$25</span></p></div></div>
                <div class="setting-locked-card-badge"><i class="fas fa-lock"></i><span class="setting-locked-card-label">—</span></div>
            </div>
            <div class="setting-toggle-card setting-locked-card" data-locked-sync="premium-mfr-slot">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-industry"></i></div><div class="stc-info"><h4 data-i18n="settings_t_manufacturer">کۆمپانیا دروستکەر</h4><p data-i18n="settings_t_manufacturer_hint">فلتەر و هەڵبژاردن ل ئایتم و کۆگە · <span data-pos-price="feature">$50</span></p></div></div>
                <div class="setting-locked-card-badge"><i class="fas fa-lock"></i><span class="setting-locked-card-label">—</span></div>
            </div>
            <div class="setting-toggle-card setting-locked-card" data-locked-sync="premium-tech-specs">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-microchip"></i></div><div class="stc-info"><h4 data-i18n="settings_t_tech_specs">مواسفات لاپتۆب / مۆبایل</h4><p data-i18n="settings_t_tech_specs_hint">CPU، RAM، GPU ل فۆرمێ ئایتم و لزگە · <span data-pos-price="feature">$50</span></p></div></div>
                <div class="setting-locked-card-badge"><i class="fas fa-lock"></i><span class="setting-locked-card-label">—</span></div>
            </div>
            <div class="setting-toggle-card setting-locked-card" data-locked-sync="premium-sale-followup">
                <div class="stc-content"><div class="stc-icon" style="background: rgba(37, 211, 102, 0.15); color: #128c7e;"><i class="fab fa-whatsapp"></i></div><div class="stc-info"><h4 data-i18n="settings_t_sale_followup">پەیوەندیا پشتی فرۆتنێ</h4><p data-i18n="settings_t_sale_followup_hint">وەختێ وەخت گەهشت، ل ئاگەهداریان ناڤێ کریاری دێت · Pro یان <span data-pos-price="feature">$50</span></p></div></div>
                <div class="setting-locked-card-badge"><i class="fas fa-lock"></i><span class="setting-locked-card-label">—</span></div>
            </div>
        </div>
    </div>

