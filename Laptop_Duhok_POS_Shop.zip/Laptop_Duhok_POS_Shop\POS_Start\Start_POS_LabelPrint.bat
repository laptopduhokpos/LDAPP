@echo off
chcp 65001 >nul
title POS Label Print Agent
echo.
echo  Laptop Duhok POS — Label Print Agent
echo.
cd /d "%~dp0.."
start "POS Label Print Agent" powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%cd%\api\tools\pos_label_print_agent.ps1"
timeout /t 2 /nobreak >nul
start "" "%~dp0LaptopDuhokPOS.exe"
exit
