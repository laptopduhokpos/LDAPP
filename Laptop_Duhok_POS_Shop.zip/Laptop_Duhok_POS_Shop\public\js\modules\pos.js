/**
 * POS: cashier screen, bills, barcode, tables.
 * Logic currently lives in app.js; can be moved here gradually.
 */
import { state } from './state.js';

// Placeholder: renderBill, addToBill, removeFromBill, etc. remain in app.js
// and are attached to window by app.js. This module can later export them.
