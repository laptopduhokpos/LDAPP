<?php
/**
 * Supabase — Mobile Manager sync (dashboard / inventory / debt / daily detail).
 * Separate project from license Supabase (config/supabase_license.php).
 *
 * Run sql/supabase_mobile_sync.sql in this project's SQL Editor first.
 */
if (!defined('POS_SUPABASE_MOBILE_URL')) {
    define('POS_SUPABASE_MOBILE_URL', 'https://zjcdivzodvgrxlzhhbpk.supabase.co');
}
if (!defined('POS_SUPABASE_MOBILE_ANON_KEY')) {
    define('POS_SUPABASE_MOBILE_ANON_KEY', 'sb_publishable_-L7lJw3wwFGr7iPVUx_tCw_P8cArqGT');
}
/** When true, POS pushes to Supabase alongside Firebase (dual-write during migration). */
if (!defined('POS_SUPABASE_MOBILE_ENABLED')) {
    define('POS_SUPABASE_MOBILE_ENABLED', true);
}
