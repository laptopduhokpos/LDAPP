<?php
// POST: print log, delivery, debt, company docs, snapshots

if (!function_exists('pos_delivery_adjust_stock')) {
    /**
     * $sign -1 = leave warehouse with driver; +1 = return items to stock (رەفس / هەلوەشاندن).
     */
    function pos_delivery_adjust_stock($conn, $cartItems, $sign) {
        if (!is_array($cartItems) || !$conn) {
            return;
        }
        $sign = ((float)$sign >= 0) ? 1.0 : -1.0;
        $counts = [];
        foreach ($cartItems as $prod) {
            if (!is_array($prod)) continue;
            $pid = (int)($prod['id'] ?? 0);
            if ($pid <= 0) continue;
            $tracked = isset($prod['trackStock']) && ($prod['trackStock'] === true || $prod['trackStock'] == 1 || $prod['trackStock'] === '1');
            if (!$tracked) continue;
            $qNorm = function_exists('normalizeQtyForProductData')
                ? normalizeQtyForProductData($prod, isset($prod['qty']) ? $prod['qty'] : 1)
                : (float)($prod['qty'] ?? 1);
            if ($qNorm <= 0) continue;
            if (!isset($counts[$pid])) $counts[$pid] = 0.0;
            $counts[$pid] += $qNorm;
        }
        foreach ($counts as $pid => $qty) {
            $delta = $sign * (float)$qty;
            $stmt = $conn->prepare('UPDATE products SET qty = qty + ? WHERE id = ?');
            if ($stmt) {
                $stmt->bind_param('di', $delta, $pid);
                $stmt->execute();
            }
            if ($sign > 0 && function_exists('pos_restore_stock_batch_qty')) {
                pos_restore_stock_batch_qty($conn, (int)$pid, (float)$qty, 0);
            }
        }
    }
}

    // --- LIST WINDOWS PRINTERS (for label printer dropdown) ---
    if ($act == 'list_windows_printers') {
        header('Content-Type: application/json; charset=utf-8');
        if (strtoupper(substr(PHP_OS, 0, 3)) !== 'WIN') {
            echo json_encode(['status' => 'ok', 'printers' => []]);
            exit();
        }
        $ps1 = __DIR__ . DIRECTORY_SEPARATOR . 'tools' . DIRECTORY_SEPARATOR . 'list_windows_printers.ps1';
        if (!is_file($ps1)) {
            echo json_encode(['status' => 'error', 'message' => 'list_windows_printers.ps1 missing', 'printers' => []]);
            exit();
        }
        $cmd = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File ' . escapeshellarg($ps1);
        $lines = [];
        $code = 1;
        @exec($cmd . ' 2>&1', $lines, $code);
        $raw = trim(implode("\n", $lines));
        $decoded = json_decode($raw, true);
        $list = [];
        if (is_array($decoded)) {
            // single object vs array
            if (isset($decoded['name'])) {
                $decoded = [$decoded];
            }
            foreach ($decoded as $row) {
                if (!is_array($row)) continue;
                $name = isset($row['name']) ? trim((string)$row['name']) : '';
                if ($name === '' || strlen($name) > 120) continue;
                if (preg_match('/[<>"|?*\x00-\x1F]/', $name)) continue;
                $list[] = [
                    'name' => $name,
                    'offline' => !empty($row['offline']),
                    'default' => !empty($row['default']),
                ];
            }
        }
        // Prefer physical/label printers first in UI (client also sorts)
        echo json_encode(['status' => 'ok', 'printers' => $list]);
        exit();
    }

    // --- SILENT LABEL PRINT (Windows named printer, no Chrome dialog) ---
    if ($act == 'silent_print_label') {
        header('Content-Type: application/json; charset=utf-8');
        if (strtoupper(substr(PHP_OS, 0, 3)) !== 'WIN') {
            echo json_encode(['status' => 'error', 'message' => 'Silent label print is Windows-only']);
            exit();
        }
        $printer = isset($_POST['printer']) ? trim((string)$_POST['printer']) : '';
        $printer = preg_replace('/[\r\n\x00]/', '', $printer);
        if ($printer === '' || strlen($printer) > 120) {
            echo json_encode(['status' => 'error', 'message' => 'ناڤێ پرینتەری دروست هەڵبژێرە']);
            exit();
        }
        // Disallow shell metacharacters in printer name
        if (preg_match('/[<>"|?*]/', $printer)) {
            echo json_encode(['status' => 'error', 'message' => 'ناڤێ پرینتەری نادروستە']);
            exit();
        }
        $widthMm = isset($_POST['width_mm']) ? (float)$_POST['width_mm'] : 50;
        $heightMm = isset($_POST['height_mm']) ? (float)$_POST['height_mm'] : 30;
        if ($widthMm < 15) $widthMm = 15;
        if ($widthMm > 120) $widthMm = 120;
        if ($heightMm < 10) $heightMm = 10;
        if ($heightMm > 100) $heightMm = 100;
        $copies = isset($_POST['copies']) ? (int)$_POST['copies'] : 1;
        if ($copies < 1) $copies = 1;
        if ($copies > 50) $copies = 50;

        $imageB64 = isset($_POST['image']) ? (string)$_POST['image'] : '';
        if (strpos($imageB64, 'base64,') !== false) {
            $imageB64 = substr($imageB64, strpos($imageB64, 'base64,') + 7);
        }
        $imageB64 = preg_replace('/\s+/', '', $imageB64);
        $bin = base64_decode($imageB64, true);
        if ($bin === false || strlen($bin) < 64 || strlen($bin) > 8 * 1024 * 1024) {
            echo json_encode(['status' => 'error', 'message' => 'وێنەی لزگە نادروستە']);
            exit();
        }
        // PNG or JPEG magic
        $isPng = (substr($bin, 0, 8) === "\x89PNG\r\n\x1a\n");
        $isJpg = (substr($bin, 0, 2) === "\xFF\xD8");
        if (!$isPng && !$isJpg) {
            echo json_encode(['status' => 'error', 'message' => 'تەنها PNG/JPG']);
            exit();
        }
        $ext = $isPng ? 'png' : 'jpg';
        $tmpDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'pos_label_print';
        if (!is_dir($tmpDir)) {
            @mkdir($tmpDir, 0777, true);
        }
        $imgPath = $tmpDir . DIRECTORY_SEPARATOR . 'label_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        if (@file_put_contents($imgPath, $bin) === false) {
            echo json_encode(['status' => 'error', 'message' => 'نەشێت فایلی لزگە بنڤیسێت']);
            exit();
        }

        $ps1 = __DIR__ . DIRECTORY_SEPARATOR . 'tools' . DIRECTORY_SEPARATOR . 'print_label_image.ps1';
        if (!is_file($ps1)) {
            @unlink($imgPath);
            echo json_encode(['status' => 'error', 'message' => 'print_label_image.ps1 missing']);
            exit();
        }

        $psExe = 'powershell.exe';
        $cmd = $psExe
            . ' -NoProfile -ExecutionPolicy Bypass -File '
            . escapeshellarg($ps1)
            . ' -ImagePath ' . escapeshellarg($imgPath)
            . ' -PrinterName ' . escapeshellarg($printer)
            . ' -WidthMm ' . escapeshellarg((string)$widthMm)
            . ' -HeightMm ' . escapeshellarg((string)$heightMm)
            . ' -Copies ' . escapeshellarg((string)$copies);

        $stdoutLines = [];
        $exitCode = 1;
        $stderr = '';
        @exec($cmd . ' 2>&1', $stdoutLines, $exitCode);
        $stdout = implode("\n", $stdoutLines);
        if ($exitCode !== 0) {
            $stderr = $stdout;
        }

        if ($exitCode === 0) {
            @unlink($imgPath);
            echo json_encode([
                'status' => 'success',
                'printer' => $printer,
                'message' => 'هاتە چاپکرن',
            ]);
            exit();
        }

        // Fallback: mspaint /pt (uses printer name, may ignore custom size)
        $mspaint = getenv('WINDIR') ? (rtrim(getenv('WINDIR'), '\\/') . '\\System32\\mspaint.exe') : 'mspaint.exe';
        if (is_file($mspaint)) {
            $msCmd = escapeshellarg($mspaint) . ' /pt ' . escapeshellarg($imgPath) . ' ' . escapeshellarg($printer);
            $msOut = [];
            $msCode = 1;
            @exec($msCmd . ' 2>&1', $msOut, $msCode);
            usleep(900000);
            @unlink($imgPath);
            if ($msCode === 0) {
                echo json_encode([
                    'status' => 'success',
                    'printer' => $printer,
                    'message' => 'هاتە چاپکرن (mspaint)',
                    'fallback' => 'mspaint',
                ]);
                exit();
            }
        } else {
            @unlink($imgPath);
        }

        $errMsg = trim($stderr !== '' ? $stderr : $stdout);
        if ($errMsg === '') $errMsg = 'چاپا بێدەنگ سەرنەکەوت — Start_POS.bat بکەرەوە (Agent).';
        if (stripos($errMsg, 'Printer not found') !== false || stripos($errMsg, 'invalid:') !== false) {
            $errMsg = 'پرینتەر نەهاتە دیتن ل ویندۆزێ. Start_POS.bat بکەرەوە، پاشێ پرینتەرێ ژ لیستێ هەڵبژێرە (ئەگەر #2 هەیە ئەو هەڵبژێرە).';
        }
        if (preg_match('/Exception calling|MethodInvocationException|FullyQualifiedErrorId/i', $errMsg)) {
            $errMsg = 'چاپ سەرنەکەوت. Start_POS.bat بکەرەوە و پەنجەرەی Agent بکەرەوە بمێنێت.';
        }
        echo json_encode([
            'status' => 'error',
            'message' => $errMsg,
            'exit' => $exitCode,
        ]);
        exit();
    }

    // --- PRINT LOG (سجل الطباعة) ---
    if($act == 'log_print_action') {

        header('Content-Type: application/json; charset=utf-8');
        $doc_type = $conn->real_escape_string($_POST['doc_type'] ?? '');
        $doc_id = $conn->real_escape_string($_POST['doc_id'] ?? '');
        $action = $conn->real_escape_string($_POST['log_action'] ?? 'print');
        $note = $_POST['note'] ?? '';
        $details = $_POST['details'] ?? '';
        $user = $_POST['user'] ?? (isset($_SESSION['user']) ? $_SESSION['user'] : 'System');
        $uid = isset($_POST['user_id']) ? (int)$_POST['user_id'] : (isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0);
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $stmt = $conn->prepare("INSERT INTO print_log (doc_type, doc_id, action, user, user_id, note, details, ip_address, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
        $stmt->bind_param("ssssisss", $doc_type, $doc_id, $action, $user, $uid, $note, $details, $ip);
        if($stmt->execute()) {
            echo json_encode(["status"=>"success", "id"=>$conn->insert_id]); exit();
        }
        echo json_encode(["status"=>"error", "message"=>"Failed to log"]); exit();
    }

    // --- DELIVERY HANDLERS ---
    if($act == 'save_driver') {
        if (function_exists('pos_ensure_drivers_schema')) pos_ensure_drivers_schema($conn);
        $name = trim((string)($_POST['name'] ?? ''));
        $phone = trim((string)($_POST['phone'] ?? ''));
        $note = trim((string)($_POST['note'] ?? ''));
        if ($name === '') {
            echo json_encode(['status' => 'error', 'message' => 'ناڤێ سایێقی پێدڤیە.']);
            exit();
        }
        if (strlen($name) > 100) $name = substr($name, 0, 100);
        if (strlen($phone) > 50) $phone = substr($phone, 0, 50);
        if (strlen($note) > 255) $note = substr($note, 0, 255);
        $stmt = $conn->prepare('INSERT INTO drivers (name, phone, note) VALUES (?, ?, ?)');
        if (!$stmt) {
            echo json_encode(['status' => 'error', 'message' => $conn->error ?: 'prepare failed']);
            exit();
        }
        $stmt->bind_param('sss', $name, $phone, $note);
        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'id' => (int)$stmt->insert_id, 'name' => $name, 'phone' => $phone, 'note' => $note]);
            exit();
        }
        echo json_encode(['status' => 'error', 'message' => $stmt->error ?: 'نەشیا تۆمار کەت.']);
        exit();
    }

    if($act == 'update_driver') {
        if (function_exists('pos_ensure_drivers_schema')) pos_ensure_drivers_schema($conn);
        $id = (int)($_POST['id'] ?? 0);
        $name = trim((string)($_POST['name'] ?? ''));
        $phone = trim((string)($_POST['phone'] ?? ''));
        $note = trim((string)($_POST['note'] ?? ''));
        if ($id <= 0 || $name === '') {
            echo json_encode(['status' => 'error', 'message' => 'ناڤ پێدڤیە.']);
            exit();
        }
        if (strlen($name) > 100) $name = substr($name, 0, 100);
        if (strlen($phone) > 50) $phone = substr($phone, 0, 50);
        if (strlen($note) > 255) $note = substr($note, 0, 255);
        $up = $conn->prepare('UPDATE drivers SET name = ?, phone = ?, note = ? WHERE id = ?');
        if (!$up) {
            echo json_encode(['status' => 'error', 'message' => $conn->error ?: 'prepare failed']);
            exit();
        }
        $up->bind_param('sssi', $name, $phone, $note, $id);
        $up->execute();
        $stD = $conn->prepare('UPDATE deliveries SET driver = ?, driver_phone = ? WHERE driver_id = ? AND status = ?');
        if ($stD) {
            $pending = 'pending';
            $stD->bind_param('ssis', $name, $phone, $id, $pending);
            $stD->execute();
        }
        echo json_encode(['status' => 'success', 'id' => $id, 'name' => $name, 'phone' => $phone, 'note' => $note]);
        exit();
    }

    if($act == 'delete_driver') {
        if (function_exists('pos_ensure_drivers_schema')) pos_ensure_drivers_schema($conn);
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'نادروستە.']);
            exit();
        }
        $pending = 'pending';
        $chk = $conn->prepare('SELECT COUNT(*) AS c FROM deliveries WHERE driver_id = ? AND status = ?');
        if ($chk) {
            $chk->bind_param('is', $id, $pending);
            $chk->execute();
            $resChk = $chk->get_result();
            $rowChk = $resChk ? $resChk->fetch_assoc() : null;
            if ($rowChk && (int)($rowChk['c'] ?? 0) > 0) {
                echo json_encode(['status' => 'error', 'message' => 'ئەڤ سایێقە گەهاندنێن چالاک هەنە.']);
                exit();
            }
        }
        $del = $conn->prepare('UPDATE drivers SET is_active = 0 WHERE id = ?');
        if (!$del) {
            echo json_encode(['status' => 'error', 'message' => $conn->error ?: 'prepare failed']);
            exit();
        }
        $del->bind_param('i', $id);
        $del->execute();
        echo json_encode(['status' => 'success', 'id' => $id]);
        exit();
    }

    if($act == 'save_delivery') {
        if (function_exists('pos_ensure_drivers_schema')) pos_ensure_drivers_schema($conn);
        $cust = trim((string)($_POST['customer'] ?? ''));
        $phone = trim((string)($_POST['phone'] ?? ''));
        $addr = trim((string)($_POST['address'] ?? ''));
        $driverId = (int)($_POST['driver_id'] ?? 0);
        $customerId = (int)($_POST['customer_id'] ?? 0);
        $driver = trim((string)($_POST['driver'] ?? ''));
        $driverPhone = trim((string)($_POST['driver_phone'] ?? ''));
        $deliveryCost = roundMoney((float)($_POST['delivery_cost'] ?? 0));
        $total = roundMoney((float)($_POST['total'] ?? 0));
        $note = (string)($_POST['note'] ?? '');
        $itemsJson = isset($_POST['items']) ? (string)$_POST['items'] : '[]';
        $date = date('Y-m-d H:i:s');
        $status = 'pending';

        if ($driverId > 0) {
            $stDrv = $conn->prepare('SELECT name, phone FROM drivers WHERE id = ? AND (is_active IS NULL OR is_active = 1) LIMIT 1');
            if ($stDrv) {
                $stDrv->bind_param('i', $driverId);
                $stDrv->execute();
                $resDrv = $stDrv->get_result();
                if ($resDrv && ($rowDrv = $resDrv->fetch_assoc())) {
                    $driver = trim((string)($rowDrv['name'] ?? $driver));
                    if ($driverPhone === '') $driverPhone = trim((string)($rowDrv['phone'] ?? ''));
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'سایێق نەهاتە دیتن.']);
                    exit();
                }
            }
        }
        if ($customerId > 0) {
            $stC = $conn->prepare('SELECT name, phone, address FROM customers WHERE id = ? LIMIT 1');
            if ($stC) {
                $stC->bind_param('i', $customerId);
                $stC->execute();
                $resC = $stC->get_result();
                if ($resC && ($rowC = $resC->fetch_assoc())) {
                    if ($cust === '') $cust = trim((string)($rowC['name'] ?? ''));
                    if ($phone === '') $phone = trim((string)($rowC['phone'] ?? ''));
                    if ($addr === '') $addr = trim((string)($rowC['address'] ?? ''));
                }
            }
        }
        if ($driver === '') {
            echo json_encode(['status' => 'error', 'message' => 'سایێق پێدڤیە.']);
            exit();
        }

        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare('INSERT INTO deliveries (customer_name, phone, address, driver, driver_phone, delivery_cost, total, status, date, note, items_json, customer_id, driver_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
            $stmt->bind_param('sssssddssssii', $cust, $phone, $addr, $driver, $driverPhone, $deliveryCost, $total, $status, $date, $note, $itemsJson, $customerId, $driverId);
            $stmt->execute();
            $insertId = $stmt->insert_id;

            $cartItems = json_decode($itemsJson, true);
            pos_delivery_adjust_stock($conn, is_array($cartItems) ? $cartItems : [], -1);

            $conn->commit();
            touchLastUpdate($conn);
            echo json_encode([
                'status' => 'success',
                'id' => $insertId,
                'date' => $date,
                'driver' => $driver,
                'driver_phone' => $driverPhone,
                'customer_id' => $customerId,
                'driver_id' => $driverId
            ]);
            exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
            exit();
        }
    }

    if($act == 'update_delivery') {
        if (function_exists('pos_ensure_drivers_schema')) pos_ensure_drivers_schema($conn);
        $id = (int)$_POST['id'];
        $status = strtolower(trim((string)($_POST['status'] ?? '')));
        $allowed = ['delivered', 'refused', 'cancelled'];
        if ($id <= 0 || !in_array($status, $allowed, true)) {
            echo json_encode(['status' => 'error', 'message' => 'نادروستە.']);
            exit();
        }

        $conn->begin_transaction();
        try {
            $check = $conn->prepare('SELECT * FROM deliveries WHERE id = ? FOR UPDATE');
            $check->bind_param('i', $id);
            $check->execute();
            $resCheck = $check->get_result();
            $d = ($resCheck && ($row = $resCheck->fetch_assoc())) ? $row : null;
            if (!$d) {
                throw new Exception('گەهاندن نەهاتە دیتن.');
            }
            $cur = strtolower(trim((string)($d['status'] ?? '')));
            if ($cur === $status) {
                $conn->commit();
                echo json_encode(['status' => 'success', 'message' => 'Already updated', 'sale_id' => (int)($d['sale_id'] ?? 0)]);
                exit();
            }
            if ($cur !== 'pending') {
                throw new Exception('ئەڤ گەهاندنە هاتیە تەواوکرن.');
            }

            $settledAt = date('Y-m-d H:i:s');
            $itemsJson = $d['items_json'] ?? '[]';
            $cartItems = json_decode($itemsJson, true);
            $newSaleId = 0;
            $date = $settledAt;
            $payMethodOut = '';

            if ($status === 'delivered') {
                $cashier = !empty($d['driver']) ? ('Driver: ' . $d['driver']) : 'Delivery';
                $totalVal = roundMoney($d['total'] ?? 0);
                $disc = 0.0;
                $payRaw = strtolower(trim((string)($_POST['payment_method'] ?? 'cash')));
                $payMethod = in_array($payRaw, ['fib', 'bank', 'card'], true) ? 'fib' : 'cash';
                $payMethodOut = $payMethod;
                $isFib = ($payMethod === 'fib');
                $paidCashCol = $isFib ? 0.0 : $totalVal;
                $paidBankCol = $isFib ? $totalVal : 0.0;
                $bankAmountCol = $paidBankCol;
                $targetId = (int)($d['customer_id'] ?? 0);
                $targetType = $targetId > 0 ? 'customer' : '';
                $txnId = 'TX' . str_replace('.', '', uniqid('', true)) . bin2hex(random_bytes(4));
                $saleRequestKey = 'DEL' . $id . '-' . str_replace(['.', ' '], '', uniqid('', true));
                $zero = 0.0;
                $whId = function_exists('pos_session_open_warehouse_id') ? (int)pos_session_open_warehouse_id() : 0;
                $fxDelSnap = function_exists('fxSnapshotBindStringsFromConnection')
                    ? fxSnapshotBindStringsFromConnection($conn)
                    : ['rate' => '', 'mode' => ''];
                $fxRate = (string)($fxDelSnap['rate'] ?? '');
                $fxMode = (string)($fxDelSnap['mode'] ?? '');
                if (function_exists('pos_lock_sale_items_fx')) {
                    $itemsJson = pos_lock_sale_items_fx($itemsJson, $fxRate, $fxMode);
                }
                if (function_exists('pos_ensure_sales_checkout_columns')) {
                    pos_ensure_sales_checkout_columns($conn);
                }
                $saleInsertSql = 'INSERT INTO sales (total, discount, items_json, created_at, cashier, payment_method, customer_id, customer_type, transaction_id, sale_request_key, paid_amount, debt_amount, bank_amount, received_amount, total_bill, tax_discount, paid_cash, paid_bank, remaining_debt, warehouse_id, fx_usd_rate, fx_currency_mode) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CAST(NULLIF(?, \'\') AS UNSIGNED), NULLIF(?, \'\'))';
                $stmtS = $conn->prepare($saleInsertSql);
                if (!$stmtS) throw new Exception('Prepare sale failed: ' . $conn->error);
                $stmtS->bind_param(
                    'ddssssisssdddddddddiss',
                    $totalVal,
                    $disc,
                    $itemsJson,
                    $date,
                    $cashier,
                    $payMethod,
                    $targetId,
                    $targetType,
                    $txnId,
                    $saleRequestKey,
                    $totalVal,
                    $zero,
                    $bankAmountCol,
                    $totalVal,
                    $totalVal,
                    $disc,
                    $paidCashCol,
                    $paidBankCol,
                    $zero,
                    $whId,
                    $fxRate,
                    $fxMode
                );
                if (!$stmtS->execute()) throw new Exception('Insert sale failed: ' . $stmtS->error);
                $newSaleId = (int)$stmtS->insert_id;
                if ($newSaleId > 0 && function_exists('pos_sale_stamp_dual_totals')) {
                    pos_sale_stamp_dual_totals($conn, $newSaleId, $totalVal, $totalVal, $fxRate);
                }

                if ($totalVal > 0) {
                    $ledgerType = $isFib ? 'sale_fib' : 'sale';
                    $ledgerNote = 'Sale #' . $newSaleId . ($isFib ? ' (delivery FIB)' : ' (delivery cash)');
                    $stmtL = $conn->prepare('INSERT INTO ledger (transaction_id, type, amount, related_id, note, date) VALUES (?, ?, ?, ?, ?, ?)');
                    if ($stmtL) {
                        $stmtL->bind_param('ssdiss', $txnId, $ledgerType, $totalVal, $newSaleId, $ledgerNote, $date);
                        if (!$stmtL->execute()) throw new Exception('Insert ledger failed: ' . $stmtL->error);
                    }
                    if ($targetId > 0 && !$isFib) {
                        $cNote = 'فرۆتن (گەهاندن کاش) ' . date('Y-m-d H:i');
                        $receiptIdStr = (string)$newSaleId;
                        $cType = 'customer';
                        $clType = 'sale_cash';
                        $stmtCL = $conn->prepare('INSERT INTO customer_ledger (target_id, target_type, type, amount, date, note, transaction_id, receipt_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
                        if ($stmtCL) {
                            $stmtCL->bind_param('issdssss', $targetId, $cType, $clType, $totalVal, $date, $cNote, $txnId, $receiptIdStr);
                            $stmtCL->execute();
                            $clId = (int)$conn->insert_id;
                            if ($clId > 0 && function_exists('pos_stamp_table_fx')) {
                                pos_stamp_table_fx($conn, 'customer_ledger', $clId, 'IQD');
                            }
                        }
                    }
                }
            } else if ($status === 'refused' || $status === 'cancelled') {
                pos_delivery_adjust_stock($conn, is_array($cartItems) ? $cartItems : [], 1);
            }

            $stmt = $conn->prepare('UPDATE deliveries SET status = ?, sale_id = ?, settled_at = ? WHERE id = ?');
            $stmt->bind_param('sisi', $status, $newSaleId, $settledAt, $id);
            $stmt->execute();

            $conn->commit();
            touchLastUpdate($conn);
            echo json_encode(['status' => 'success', 'sale_id' => $newSaleId, 'date' => $date, 'settled_at' => $settledAt, 'payment_method' => $payMethodOut]);
            exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
            exit();
        }
    }

    // --- CUSTOMER & DEBT HANDLERS ---
    if ($act === 'patch_customer_phone') {
        $id = (int)($_POST['id'] ?? 0);
        $phone = trim((string)($_POST['phone'] ?? ''));
        if ($id <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'id required'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $st = $conn->prepare('UPDATE customers SET phone = ? WHERE id = ?');
        if (!$st) {
            echo json_encode(['status' => 'error'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $st->bind_param('si', $phone, $id);
        if ($st->execute()) {
            echo json_encode(['status' => 'success', 'id' => $id, 'phone' => $phone], JSON_UNESCAPED_UNICODE);
        } else {
            echo json_encode(['status' => 'error'], JSON_UNESCAPED_UNICODE);
        }
        exit();
    }

    if($act == 'save_customer') {
        pos_ensure_wide_debt_money_columns($conn);
        if (function_exists('pos_ensure_payment_due_schema')) pos_ensure_payment_due_schema($conn);
        $name = trim($_POST['name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $address = trim($_POST['address'] ?? '');
        if ($name !== '') {
            if ($phone !== '') {
                $stDup = $conn->prepare('SELECT id FROM customers WHERE TRIM(name) = ? AND TRIM(phone) = ? LIMIT 1');
                if ($stDup) {
                    $stDup->bind_param('ss', $name, $phone);
                    $stDup->execute();
                    $dupRow = $stDup->get_result()->fetch_assoc();
                    if ($dupRow && (int)$dupRow['id'] > 0) {
                        echo json_encode(['status' => 'error', 'message' => 'ئەڤ کریارە بەری نوکە یێ هەی!'], JSON_UNESCAPED_UNICODE);
                        exit();
                    }
                }
            } else {
                $stDup = $conn->prepare("SELECT id FROM customers WHERE TRIM(name) = ? AND TRIM(IFNULL(phone,'')) = '' LIMIT 1");
                if ($stDup) {
                    $stDup->bind_param('s', $name);
                    $stDup->execute();
                    $dupRow = $stDup->get_result()->fetch_assoc();
                    if ($dupRow && (int)$dupRow['id'] > 0) {
                        echo json_encode(['status' => 'error', 'message' => 'ئەڤ کریارە بەری نوکە یێ هەی!'], JSON_UNESCAPED_UNICODE);
                        exit();
                    }
                }
            }
        }
        list($opening, $limit) = pos_debt_form_amounts_to_stored_iqd($conn, $_POST['opening_balance'] ?? 0, $_POST['debt_limit'] ?? 0);
        $paymentTermValue = max(0, (int)($_POST['payment_term_value'] ?? 0));
        $paymentTermUnit = pos_normalize_payment_term_unit($_POST['payment_term_unit'] ?? 'day');
        $stmt = $conn->prepare("INSERT INTO customers (name, phone, address, balance, debt_limit, opening_balance, payment_term_value, payment_term_unit) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssdddis", $name, $phone, $address, $opening, $limit, $opening, $paymentTermValue, $paymentTermUnit);
        if($stmt->execute()) {
            logAction($conn, 'Admin', 'add_customer', "Added new customer: $name");
            echo json_encode(["status"=>"success", "id"=>$stmt->insert_id]); exit();
        }
        else echo json_encode(["status"=>"error"]); exit();
    }

    if($act == 'update_customer') {
        pos_ensure_wide_debt_money_columns($conn);
        if (function_exists('pos_ensure_payment_due_schema')) pos_ensure_payment_due_schema($conn);
        $id = (int)($_POST['id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $address = trim($_POST['address'] ?? '');
        list($openingNew, $limit) = pos_debt_form_amounts_to_stored_iqd($conn, $_POST['opening_balance'] ?? 0, $_POST['debt_limit'] ?? 0);
        $paymentTermValue = max(0, (int)($_POST['payment_term_value'] ?? 0));
        $paymentTermUnit = pos_normalize_payment_term_unit($_POST['payment_term_unit'] ?? 'day');
        if($id <= 0 || $name === '') { echo json_encode(["status"=>"error", "message"=>"ناڤێ کریاری پێدڤیە."]); exit(); }

        $conn->begin_transaction();
        try {
            $sel = $conn->prepare("SELECT name, opening_balance FROM customers WHERE id = ? FOR UPDATE");
            $sel->bind_param("i", $id);
            $sel->execute();
            $res = $sel->get_result();
            if(!$res || !($row = $res->fetch_assoc())) throw new Exception("کریار نەهاتە دیتن");
            $oldName = trim((string)($row['name'] ?? ''));
            $openingOld = roundMoney((float)($row['opening_balance'] ?? 0));
            $delta = roundMoney($openingNew - $openingOld);

            $up = $conn->prepare("UPDATE customers SET name = ?, phone = ?, address = ?, debt_limit = ?, opening_balance = ?, payment_term_value = ?, payment_term_unit = ?, balance = balance + ? WHERE id = ?");
            $up->bind_param("sssddisdi", $name, $phone, $address, $limit, $openingNew, $paymentTermValue, $paymentTermUnit, $delta, $id);
            $up->execute();

            if ($oldName !== '' && $oldName !== $name) {
                $stD = $conn->prepare("UPDATE deliveries SET customer_name = ? WHERE customer_name = ?");
                if ($stD) {
                    $stD->bind_param("ss", $name, $oldName);
                    $stD->execute();
                }
            }

            $balStmt = $conn->prepare("SELECT balance FROM customers WHERE id = ?");
            $balStmt->bind_param("i", $id);
            $balStmt->execute();
            $balRes = $balStmt->get_result();
            $newBalance = ($balRes && ($brow = $balRes->fetch_assoc())) ? roundMoney((float)$brow['balance']) : 0;

            // Backfill payment_due_at on open credit sales when a term is set
            if ($paymentTermValue > 0) {
                $stOpen = $conn->prepare(
                    "SELECT id, created_at FROM sales WHERE customer_id = ? AND customer_type IN ('customer','customers') "
                    . "AND remaining_debt > 0 AND (payment_due_at IS NULL OR payment_due_at = '')"
                );
                if ($stOpen) {
                    $stOpen->bind_param('i', $id);
                    $stOpen->execute();
                    $openRes = $stOpen->get_result();
                    if ($openRes) {
                        $stSetDue = $conn->prepare("UPDATE sales SET payment_due_at = ? WHERE id = ?");
                        while ($openRow = $openRes->fetch_assoc()) {
                            $dueAt = pos_compute_payment_due_at($paymentTermValue, $paymentTermUnit, $openRow['created_at'] ?? null);
                            if ($dueAt && $stSetDue) {
                                $saleOpenId = (int)$openRow['id'];
                                $stSetDue->bind_param('si', $dueAt, $saleOpenId);
                                $stSetDue->execute();
                            }
                        }
                    }
                }
            }

            $conn->commit();
            logAction($conn, 'Admin', 'edit_customer', "Updated customer: #$id $name");
            echo json_encode([
                "status"=>"success",
                "balance"=>$newBalance,
                "opening_balance"=>$openingNew,
                "debt_limit"=>$limit,
                "payment_term_value"=>$paymentTermValue,
                "payment_term_unit"=>$paymentTermUnit,
                "name"=>$name,
                "old_name"=>$oldName
            ]); exit();
        } catch(Exception $e) {
            $conn->rollback();
            echo json_encode(["status"=>"error", "message"=>$e->getMessage()]); exit();
        }
    }

    if($act == 'delete_customer') {
        $id = (int)$_POST['id'];
        $chkStmt = $conn->prepare("SELECT 1 FROM customer_ledger WHERE target_id = ? AND target_type = 'customer' LIMIT 1");
        $chkStmt->bind_param("i", $id);
        $chkStmt->execute();
        $chk = $chkStmt->get_result();
        if($chk && $chk->num_rows > 0) { echo json_encode(["status"=>"error", "message"=>"نەشێی ژێببەی چونکە قەرز هەنە."]); exit(); }
        logAction($conn, 'Admin', 'delete_customer', "Deleted customer ID: $id");
        $delStmt = $conn->prepare("DELETE FROM customers WHERE id = ?");
        $delStmt->bind_param("i", $id);
        $delStmt->execute();
        logGeneralHistory($conn, 'customer', $id, 'delete', "Deleted customer ID: $id");
        echo json_encode(["status"=>"success"]); exit();
    }

    if($act == 'void_customer') {
        $id = (int)$_POST['id'];
        $stmt = $conn->prepare("UPDATE customers SET is_active = 0 WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        logAction($conn, $_POST['user'] ?? 'System', 'void_customer', "Voided customer ID: $id");
        echo json_encode(["status"=>"success"]); exit();
    }

    if($act == 'pay_debt') {
        $id = (int)$_POST['id'];
        $type = $_POST['type']; // 'customer' or 'user'
        $amount = roundMoney((float)($_POST['amount'] ?? 0));
        $note = isset($_POST['note']) ? $_POST['note'] : '';
        $receipt_id = isset($_POST['receipt_id']) ? trim($_POST['receipt_id']) : '';
        $saleIdPay = (int)($_POST['sale_id'] ?? 0);
        $user = isset($_POST['user']) ? trim((string)$_POST['user']) : 'System';
        if ($user === '') $user = 'System';
        $payChannel = function_exists('pos_normalize_debt_pay_channel')
            ? pos_normalize_debt_pay_channel($_POST['payment_method'] ?? 'cash')
            : (strtolower(trim((string)($_POST['payment_method'] ?? 'cash'))) === 'fib' ? 'fib' : 'cash');
        $date = date('Y-m-d H:i:s');
        if ($amount <= 0) { echo json_encode(["status"=>"error", "message"=>"بڕێ پارێ نادروستە!"]); exit(); }

        $table = ($type == 'user') ? 'users' : 'customers';
        
        // SECURITY: Check Balance Before Payment (prepared statement - table name is whitelisted)
        $balanceStmt = ($table === 'users') ? $conn->prepare("SELECT balance, name FROM users WHERE id = ?") : $conn->prepare("SELECT balance, name FROM customers WHERE id = ?");
        $balanceStmt->bind_param("i", $id);
        $balanceStmt->execute();
        $check = $balanceStmt->get_result();
        $targetName = '';
        if($check && $row = $check->fetch_assoc()) {
            $targetName = trim((string)($row['name'] ?? ''));
            if($row['balance'] <= 0) { echo json_encode(["status"=>"error", "message"=>"چ قەرز ل سەر ڤی کەسی نینن!"]); exit(); }
            if($amount > roundMoney($row['balance']) + 0) { echo json_encode(["status"=>"error", "message"=>"بڕێ پارەی ژ قەرزی مەزنترە!"]); exit(); }
        } else { echo json_encode(["status"=>"error", "message"=>"کەس نەهاتە دیتن"]); exit(); }

        // Cap payment to specific invoice remaining debt when sale_id is provided
        if ($type === 'customer' && $saleIdPay > 0) {
            if (function_exists('pos_ensure_payment_due_schema')) pos_ensure_payment_due_schema($conn);
            $stSale = $conn->prepare(
                "SELECT remaining_debt FROM sales WHERE id = ? AND customer_id = ? AND customer_type IN ('customer','customers') LIMIT 1"
            );
            if ($stSale) {
                $stSale->bind_param('ii', $saleIdPay, $id);
                $stSale->execute();
                $saleRow = $stSale->get_result()->fetch_assoc();
                if (!$saleRow) {
                    echo json_encode(["status"=>"error", "message"=>"فاتوورە نەهاتە دیتن!"]); exit();
                }
                $saleRem = roundMoney((float)($saleRow['remaining_debt'] ?? 0));
                if ($saleRem <= 0) {
                    echo json_encode(["status"=>"error", "message"=>"ئەڤ فاتورە چ قەرزێ مایی نینە!"]); exit();
                }
                if ($amount > $saleRem) {
                    $amount = $saleRem;
                }
            }
            if ($receipt_id === '') {
                $receipt_id = (string)$saleIdPay;
            }
        }

        
        $conn->begin_transaction();
        try {
            $id = (int)$id;
            $tblSafe = ($table === 'users') ? 'users' : 'customers';
            $stmtPay = $conn->prepare("UPDATE $tblSafe SET balance = balance - ? WHERE id = ?");
            $stmtPay->bind_param("di", $amount, $id);
            $stmtPay->execute();
            
            $ledgerNote = trim((string)$note);
            if ($ledgerNote === '') {
                $ledgerNote = ($saleIdPay > 0) ? ("وەرگرتنا پارەی - فاتورە #" . $saleIdPay) : "دانەڤا قەرزی کریار";
            }
            if ($targetName !== '') $ledgerNote .= " | ناڤ: " . $targetName;
            if ($saleIdPay > 0) $ledgerNote .= " | sale#" . $saleIdPay;
            if ($receipt_id !== '') $ledgerNote .= " | receipt#" . $receipt_id;
            if ($user !== '') $ledgerNote .= " | by: " . $user;
            $ledgerNote .= ' | کانال: ' . ($payChannel === 'fib' ? 'FIB' : 'نقد');

            if (function_exists('checkAndAddCol')) {
                checkAndAddCol($conn, 'customer_ledger', 'payment_method', "VARCHAR(20) DEFAULT 'cash'");
            }
            $stmt = $conn->prepare("INSERT INTO customer_ledger (target_id, target_type, type, amount, date, note, receipt_id, payment_method) VALUES (?, ?, 'payment', ?, ?, ?, ?, ?)");
            if (!$stmt) {
                $stmt = $conn->prepare("INSERT INTO customer_ledger (target_id, target_type, type, amount, date, note, receipt_id) VALUES (?, ?, 'payment', ?, ?, ?, ?)");
                if (!$stmt) throw new Exception($conn->error);
                $stmt->bind_param("isdsss", $id, $type, $amount, $date, $ledgerNote, $receipt_id);
            } else {
                $stmt->bind_param("isdssss", $id, $type, $amount, $date, $ledgerNote, $receipt_id, $payChannel);
            }
            $stmt->execute();
            $paymentId = (int)$stmt->insert_id;
            if ($paymentId > 0 && function_exists('pos_stamp_table_fx')) {
                pos_stamp_table_fx($conn, 'customer_ledger', $paymentId, 'IQD');
            }
            
            // UNIFIED LEDGER ENTRY — cash into drawer vs FIB/bank (excluded from drawer)
            $txnId = uniqid('TXP');
            $ledgerInType = ($payChannel === 'fib') ? 'debt_payment_in_fib' : 'debt_payment_in';
            $stmtL = $conn->prepare("INSERT INTO ledger (transaction_id, type, amount, note, date) VALUES (?, ?, ?, ?, ?)");
            $stmtL->bind_param("ssdss", $txnId, $ledgerInType, $amount, $ledgerNote, $date);
            $stmtL->execute();

            if ($type === 'customer') {
                pos_apply_installment_payment($conn, $id, $amount, $paymentId);
                if (function_exists('pos_apply_customer_sale_debt_payment')) {
                    pos_apply_customer_sale_debt_payment($conn, $id, $amount, $saleIdPay);
                }
            }
            
            $conn->commit();
            logAction($conn, $user, 'pay_debt', "Debt Payment: $amount for ID $id ($type) channel=$payChannel | name=$targetName" . ($saleIdPay > 0 ? " | sale#$saleIdPay" : ""));
            echo json_encode([
                "status"=>"success",
                "id"=>$paymentId,
                "new_balance"=>roundMoney(((float)$row['balance']) - $amount),
                "target_name"=>$targetName,
                "ledger_note"=>$ledgerNote,
                "sale_id"=>$saleIdPay,
                "amount"=>$amount,
                "payment_method"=>$payChannel,
                "ledger_type"=>$ledgerInType,
            ], JSON_UNESCAPED_UNICODE); exit();
        } catch(Exception $e) { $conn->rollback(); echo json_encode(["status"=>"error"]); exit(); }
    }

    if($act == 'save_waste') {
        $pid = (int)$_POST['prodId']; $qty = (float)$_POST['qty']; 
        $reason = $_POST['reason']; $user = $_POST['user'];
        $date = date('Y-m-d H:i:s');
        $txnId = uniqid('TXW');
        
        $conn->begin_transaction();
        try {
            $stmtP = $conn->prepare("SELECT name, cost, trackStock FROM products WHERE id = ?");
            $stmtP->bind_param("i", $pid);
            $stmtP->execute();
            $res = $stmtP->get_result();
            if($res && $p=$res->fetch_assoc()) {
                $cost = roundMoney((float)$p['cost'] * $qty);
                $stmt = $conn->prepare("INSERT INTO waste (prodId, prodName, qty, cost, reason, date, user) VALUES (?, ?, ?, ?, ?, ?, ?)");
                if(!$stmt) throw new Exception($conn->error);
                $stmt->bind_param("isddsss", $pid, $p['name'], $qty, $cost, $reason, $date, $user);
                if(!$stmt->execute()) throw new Exception($stmt->error);
                $wasteId = $stmt->insert_id;
                
                if($p['trackStock']) {
                    $stmtW = $conn->prepare("UPDATE products SET qty = qty - ? WHERE id = ?");
                    $stmtW->bind_param("di", $qty, $pid);
                    if(!$stmtW->execute()) throw new Exception($stmtW->error);
                }
                $ledgerNote = "تەلەف (Waste): {$p['name']} x$qty - $reason";
                $stmtL = $conn->prepare("INSERT INTO ledger (transaction_id, type, amount, related_id, note, date) VALUES (?, 'waste', ?, ?, ?, ?)");
                if(!$stmtL) throw new Exception($conn->error);
                $stmtL->bind_param("sdiss", $txnId, $cost, $wasteId, $ledgerNote, $date);
                if(!$stmtL->execute()) throw new Exception($stmtL->error);
                $unitCost = $qty != 0 ? $cost / $qty : 0;
                insertStockMovement($conn, $pid, '', 'waste', -$qty, $unitCost, $cost, 'waste', $wasteId, $date, $user, $reason);
                logAction($conn, $user, 'waste_report', "Reported Waste: {$p['name']} (Qty: $qty, Reason: $reason)");
                $conn->commit();
                echo json_encode(["status"=>"success", "id"=>$wasteId]); exit();
            } else throw new Exception("Product not found");
        } catch(Exception $e) { $conn->rollback(); echo json_encode(["status"=>"error", "message"=>$e->getMessage()]); exit(); }
    }

    if ($act === 'undo_waste' || $act === 'delete_waste') {
        if (function_exists('pos_session_can_manage_waste') && !pos_session_can_manage_waste()) {
            pos_json_perm_denied();
        }
        $wid = (int)($_POST['id'] ?? 0);
        $user = $_SESSION['user_name'] ?? ($_POST['user'] ?? 'System');
        if ($wid <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'ناسنامەی تەلەف نادروستە.']);
            exit();
        }
        $stW = $conn->prepare('SELECT * FROM waste WHERE id = ? LIMIT 1');
        $stW->bind_param('i', $wid);
        $stW->execute();
        $wRow = $stW->get_result()->fetch_assoc();
        if (!$wRow) {
            echo json_encode(['status' => 'error', 'message' => 'تەلەف #' . $wid . ' نەدۆزرایەوە.']);
            exit();
        }
        $pid = (int)$wRow['prodId'];
        $qty = (float)$wRow['qty'];
        $conn->begin_transaction();
        try {
            $stmtP = $conn->prepare('SELECT name, trackStock FROM products WHERE id = ?');
            $stmtP->bind_param('i', $pid);
            $stmtP->execute();
            $p = $stmtP->get_result()->fetch_assoc();
            if ($p && !empty($p['trackStock'])) {
                $stmtRestore = $conn->prepare('UPDATE products SET qty = qty + ? WHERE id = ?');
                $stmtRestore->bind_param('di', $qty, $pid);
                if (!$stmtRestore->execute()) throw new Exception($stmtRestore->error);
            }
            $stDL = $conn->prepare("DELETE FROM ledger WHERE type = 'waste' AND related_id = ?");
            $stDL->bind_param('i', $wid);
            $stDL->execute();
            $stDM = $conn->prepare("DELETE FROM stock_movements WHERE reference_type = 'waste' AND reference_id = ?");
            $stDM->bind_param('i', $wid);
            $stDM->execute();
            $stDW = $conn->prepare('DELETE FROM waste WHERE id = ?');
            $stDW->bind_param('i', $wid);
            if (!$stDW->execute()) throw new Exception($stDW->error);
            $oldJson = json_encode($wRow, JSON_UNESCAPED_UNICODE);
            logAction($conn, $user, 'undo_waste', "Undid waste #$wid: {$wRow['prodName']} x$qty", null, 'waste', $wid, $oldJson, null);
            if (function_exists('logGeneralHistory')) {
                logGeneralHistory($conn, 'waste', (string)$wid, 'undo', (string)($wRow['prodName'] ?? ''), $oldJson);
            }
            $conn->commit();
            if (function_exists('touchLastUpdate')) touchLastUpdate($conn);
            echo json_encode([
                'status' => 'success',
                'id' => $wid,
                'prodId' => $pid,
                'qty' => $qty,
                'message' => 'تەلەف #' . $wid . ' گەڕایەوە — کۆگە نوێکرایەوە.',
            ], JSON_UNESCAPED_UNICODE);
            exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(['status' => 'error', 'message' => $e->getMessage(), 'id' => $wid], JSON_UNESCAPED_UNICODE);
            exit();
        }
    }

    if($act == 'save_recipe') {
        $pid = (int)$_POST['product_id'];
        $ingredients = json_decode($_POST['ingredients'], true);
        if(!is_array($ingredients)) $ingredients = [];
        $saleMode = function_exists('pos_normalize_recipe_sale_mode')
            ? pos_normalize_recipe_sale_mode($_POST['recipe_sale_mode'] ?? 'auto')
            : 'auto';
        
        $conn->begin_transaction();
        try {
            $stmtDel = $conn->prepare("DELETE FROM recipes WHERE product_id = ?");
            if(!$stmtDel) throw new Exception($conn->error);
            $stmtDel->bind_param("i", $pid);
            if(!$stmtDel->execute()) throw new Exception($stmtDel->error);
            $stmt = $conn->prepare("INSERT INTO recipes (product_id, ingredient_id, qty) VALUES (?, ?, ?)");
            if(!$stmt) throw new Exception($conn->error);
            foreach($ingredients as $ing) {
                $ingId = isset($ing['id']) ? (int)$ing['id'] : 0;
                $ingQty = isset($ing['qty']) ? (float)$ing['qty'] : 0;
                if($ingId <= 0 || $ingQty <= 0) continue;
                $stmt->bind_param("iid", $pid, $ingId, $ingQty);
                if(!$stmt->execute()) throw new Exception($stmt->error);
            }
            $stmtMode = $conn->prepare("UPDATE products SET recipe_sale_mode = ? WHERE id = ?");
            if ($stmtMode) {
                $stmtMode->bind_param("si", $saleMode, $pid);
                $stmtMode->execute();
            }
            $conn->commit(); echo json_encode(["status"=>"success", "recipe_sale_mode" => $saleMode]); exit();
        } catch(Exception $e) { $conn->rollback(); echo json_encode(["status"=>"error", "message"=>$e->getMessage()]); exit(); }
    }

    if ($act == 'produce_recipe') {
        $pid = (int)($_POST['product_id'] ?? 0);
        $batchQty = (float)($_POST['qty'] ?? 1);
        $warehouseId = pos_resolve_warehouse_id($conn, (int)($_POST['warehouse_id'] ?? 0));
        $user = $_POST['user'] ?? (function_exists('pos_session_user_name') ? pos_session_user_name() : 'System');
        $date = date('Y-m-d H:i:s');
        $refKey = uniqid('PRD');

        if ($pid <= 0 || $batchQty <= 0) {
            echo json_encode(["status" => "error", "message" => "product_or_qty_invalid"]); exit();
        }

        $conn->begin_transaction();
        try {
            $settings = pos_load_app_settings_array($conn);
            $allowNegativeStock = !empty($settings['allowNegativeStock'])
                && ($settings['allowNegativeStock'] === true || $settings['allowNegativeStock'] === 'true' || $settings['allowNegativeStock'] == 1);

            $stmtP = $conn->prepare("SELECT id, name, trackStock, cost, barcode FROM products WHERE id = ? LIMIT 1");
            if (!$stmtP) throw new Exception($conn->error);
            $stmtP->bind_param("i", $pid);
            $stmtP->execute();
            $resP = $stmtP->get_result();
            if (!$resP || !($product = $resP->fetch_assoc())) throw new Exception("product_not_found");
            if ((int)($product['trackStock'] ?? 0) !== 1) throw new Exception("product_must_track_stock");

            $recipe = pos_get_recipe_map($conn, $pid);
            if (empty($recipe)) throw new Exception("no_recipe_defined");

            $ingredientNeeds = [];
            $totalIngredientCost = 0.0;
            foreach ($recipe as $ingId => $perUnit) {
                $need = (float)$perUnit * $batchQty;
                if ($need <= 0) continue;
                $ingredientNeeds[(int)$ingId] = ($ingredientNeeds[(int)$ingId] ?? 0) + $need;

                $stmtIng = $conn->prepare("SELECT name, cost FROM products WHERE id = ? LIMIT 1");
                if ($stmtIng) {
                    $ingIdInt = (int)$ingId;
                    $stmtIng->bind_param("i", $ingIdInt);
                    $stmtIng->execute();
                    $resIng = $stmtIng->get_result();
                    if ($resIng && ($ingRow = $resIng->fetch_assoc())) {
                        $totalIngredientCost += roundMoney((float)($ingRow['cost'] ?? 0) * $need);
                    }
                }
            }

            foreach ($ingredientNeeds as $ingId => $need) {
                $available = pos_heal_warehouse_stock_from_product($conn, $warehouseId, (int)$ingId);
                if (!$allowNegativeStock && ($available + 0.000001) < $need) {
                    $stmtNm = $conn->prepare("SELECT name FROM products WHERE id = ? LIMIT 1");
                    $nm = '#' . $ingId;
                    if ($stmtNm) {
                        $stmtNm->bind_param("i", $ingId);
                        $stmtNm->execute();
                        $rNm = $stmtNm->get_result()->fetch_assoc();
                        if ($rNm && !empty($rNm['name'])) $nm = (string)$rNm['name'];
                    }
                    throw new Exception("stock_not_enough:" . $nm . " (available: $available, required: $need)");
                }
            }

            foreach ($ingredientNeeds as $ingId => $need) {
                pos_adjust_tracked_stock($conn, (int)$ingId, -(float)$need, $warehouseId);
                $stmtIngC = $conn->prepare("SELECT name, cost FROM products WHERE id = ? LIMIT 1");
                $ingName = '';
                $ingUnitCost = 0.0;
                if ($stmtIngC) {
                    $ingIdInt = (int)$ingId;
                    $stmtIngC->bind_param("i", $ingIdInt);
                    $stmtIngC->execute();
                    $resIngC = $stmtIngC->get_result();
                    if ($resIngC && ($ingRow = $resIngC->fetch_assoc())) {
                        $ingName = (string)($ingRow['name'] ?? '');
                        $ingUnitCost = (float)($ingRow['cost'] ?? 0);
                    }
                }
                $lineCost = roundMoney($ingUnitCost * $need);
                insertStockMovement($conn, (int)$ingId, '', 'recipe_consume', -(float)$need, $ingUnitCost, $lineCost, 'recipe_produce', 0, $date, $user, 'ڕەچەتە → ' . ($product['name'] ?? ''), $warehouseId);
                if (function_exists('consumeStockBatchesFefo')) {
                    consumeStockBatchesFefo($conn, (int)$ingId, (float)$need, $refKey, 0, $ingName);
                }
            }

            $unitCost = $batchQty > 0 ? roundMoney($totalIngredientCost / $batchQty) : 0.0;
            pos_adjust_tracked_stock($conn, $pid, $batchQty, $warehouseId);
            insertStockMovement($conn, $pid, (string)($product['barcode'] ?? ''), 'recipe_produce', $batchQty, $unitCost, $totalIngredientCost, 'recipe_produce', 0, $date, $user, 'دروستکرن لە ڕەچەتە', $warehouseId);

            $stmtCost = $conn->prepare("UPDATE products SET cost = ? WHERE id = ?");
            if ($stmtCost && $unitCost > 0) {
                $stmtCost->bind_param("di", $unitCost, $pid);
                $stmtCost->execute();
            }

            logAction($conn, $user, 'recipe_produce', "Produced {$product['name']} x{$batchQty} (recipe)");
            $conn->commit();
            echo json_encode([
                "status" => "success",
                "produced" => $batchQty,
                "unit_cost" => $unitCost,
                "product_id" => $pid,
                "product_name" => $product['name'] ?? ''
            ]);
            exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(["status" => "error", "message" => $e->getMessage()]);
            exit();
        }
    }

    // --- COMPANY DOCUMENTS HANDLERS ---
    if($act == 'get_company_docs') {
        $cid = (int)$_POST['company_id'];
        $res = $conn->query("SELECT id, created_at, note, image_data FROM company_documents WHERE company_id = $cid ORDER BY id DESC");
        $docs = [];
        if($res) while($r=$res->fetch_assoc()) { $docs[] = $r; }
        echo json_encode(["status"=>"success", "docs"=>$docs]);
        exit();
    }

    if($act == 'save_company_doc') {
        $cid = (int)$_POST['company_id'];
        $img = $_POST['image'];
        $note = $_POST['note'];
        $date = date('Y-m-d H:i:s');
        
        if(empty($img)) { echo json_encode(["status"=>"error", "message"=>"No image data"]); exit(); }

        $stmt = $conn->prepare("INSERT INTO company_documents (company_id, image_data, created_at, note) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isss", $cid, $img, $date, $note);
        if($stmt->execute()) { echo json_encode(["status"=>"success"]); exit(); }
        else { echo json_encode(["status"=>"error", "message"=>$stmt->error]); }
        exit();
    }

    if($act == 'delete_company_doc') {
        $id = (int)$_POST['id'];
        $conn->query("DELETE FROM company_documents WHERE id=$id");
        echo json_encode(["status"=>"success"]);
        exit();
    }

    if ($act == 'delete_customer_payment') {
        pos_session_require_login_json();
        $id = (int)$_POST['id'];
        $user = isset($_POST['user']) ? trim((string)$_POST['user']) : 'System';

        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("SELECT target_id, target_type, amount, date, note FROM customer_ledger WHERE id = ? AND (type = 'payment' OR type = 'pay') FOR UPDATE");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $res = $stmt->get_result();
            if (!$res || $res->num_rows === 0) {
                throw new Exception("دانەڤا پارەی نەهاتە دیتن یان جۆرێ وێ نەدرستە.");
            }
            $row = $res->fetch_assoc();
            
            $target_id = (int)$row['target_id'];
            $target_type = $row['target_type'];
            $amount = (float)$row['amount'];
            $note = $row['note'];
            $date = $row['date'];
            
            $table = ($target_type === 'user') ? 'users' : 'customers';
            $stmtRefund = $conn->prepare("UPDATE $table SET balance = balance + ? WHERE id = ?");
            $stmtRefund->bind_param("di", $amount, $target_id);
            $stmtRefund->execute();

            $stmtDelLedger = $conn->prepare("DELETE FROM ledger WHERE type = 'debt_payment_in' AND amount = ? AND note = ? AND date = ? LIMIT 1");
            $stmtDelLedger->bind_param("dss", $amount, $note, $date);
            $stmtDelLedger->execute();

            $stmtDel = $conn->prepare("DELETE FROM customer_ledger WHERE id = ?");
            $stmtDel->bind_param("i", $id);
            $stmtDel->execute();
            
            if ($target_type === 'customer') {
                $stmtDelInst = $conn->prepare("DELETE FROM installment_payments WHERE payment_ledger_id = ?");
                if ($stmtDelInst) {
                    $stmtDelInst->bind_param("i", $id);
                    $stmtDelInst->execute();
                }
            }

            logAction($conn, $user, 'delete_customer_payment', "Deleted Payment ID: $id | Target: $target_id");
            $conn->commit();
            touchLastUpdate($conn);
            echo json_encode(["status"=>"success"]); exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(["status"=>"error", "message"=>$e->getMessage()], JSON_UNESCAPED_UNICODE); exit();
        }
    }

    if ($act == 'edit_customer_payment') {
        pos_session_require_login_json();
        $id = (int)$_POST['id'];
        $new_amount = roundMoney((float)($_POST['amount'] ?? 0));
        $user = isset($_POST['user']) ? trim((string)$_POST['user']) : 'System';

        if ($new_amount <= 0) {
            echo json_encode(["status"=>"error", "message"=>"بڕێ پارێ نادروستە!"], JSON_UNESCAPED_UNICODE); exit();
        }

        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("SELECT target_id, target_type, amount, date, note FROM customer_ledger WHERE id = ? AND (type = 'payment' OR type = 'pay') FOR UPDATE");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $res = $stmt->get_result();
            if (!$res || $res->num_rows === 0) {
                throw new Exception("دانەڤا پارەی نەهاتە دیتن یان جۆرێ وێ نەدرستە.");
            }
            $row = $res->fetch_assoc();
            
            $target_id = (int)$row['target_id'];
            $target_type = $row['target_type'];
            $old_amount = (float)$row['amount'];
            $note = $row['note'];
            $date = $row['date'];
            
            $diff = $new_amount - $old_amount;
            
            if ($diff !== 0.0) {
                $table = ($target_type === 'user') ? 'users' : 'customers';
                
                $stmtBal = $conn->prepare("SELECT balance FROM $table WHERE id = ? FOR UPDATE");
                $stmtBal->bind_param("i", $target_id);
                $stmtBal->execute();
                $resBal = $stmtBal->get_result()->fetch_assoc();
                if ($resBal) {
                    $current_balance = (float)$resBal['balance'];
                    if ($current_balance - $diff < 0) {
                        throw new Exception("بڕێ نوی ژ قەرزی مای مەزنترە!");
                    }
                }
                
                $stmtUpdateBal = $conn->prepare("UPDATE $table SET balance = balance - ? WHERE id = ?");
                $stmtUpdateBal->bind_param("di", $diff, $target_id);
                $stmtUpdateBal->execute();

                $stmtUpdateLedger = $conn->prepare("UPDATE customer_ledger SET amount = ? WHERE id = ?");
                $stmtUpdateLedger->bind_param("di", $new_amount, $id);
                $stmtUpdateLedger->execute();
                
                $stmtUpdateMainLedger = $conn->prepare("UPDATE ledger SET amount = ? WHERE type = 'debt_payment_in' AND amount = ? AND note = ? AND date = ? LIMIT 1");
                $stmtUpdateMainLedger->bind_param("ddss", $new_amount, $old_amount, $note, $date);
                $stmtUpdateMainLedger->execute();
                
                if ($target_type === 'customer') {
                    $stmtInst = $conn->prepare("SELECT id FROM installment_payments WHERE payment_ledger_id = ?");
                    if ($stmtInst) {
                        $stmtInst->bind_param("i", $id);
                        $stmtInst->execute();
                        $resInst = $stmtInst->get_result();
                        if ($resInst && $resInst->num_rows === 1) {
                            $instRow = $resInst->fetch_assoc();
                            $stmtUpdateInst = $conn->prepare("UPDATE installment_payments SET amount_paid = ? WHERE id = ?");
                            $stmtUpdateInst->bind_param("di", $new_amount, $instRow['id']);
                            $stmtUpdateInst->execute();
                        }
                    }
                }

                logAction($conn, $user, 'edit_customer_payment', "Edited Payment ID: $id | Target: $target_id");
            }

            $conn->commit();
            touchLastUpdate($conn);
            echo json_encode(["status"=>"success"]); exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(["status"=>"error", "message"=>$e->getMessage()], JSON_UNESCAPED_UNICODE); exit();
        }
    }
