<?php
/** POS workspace views - split loader; edit views/partials/layout/*.php */
$__pos_layout_dir = __DIR__ . '/layout';require $__pos_layout_dir . '/pos_layout_01_shell.php';
require $__pos_layout_dir . '/pos_layout_02_home.php';
require $__pos_layout_dir . '/pos_layout_03_warehouse.php';
require $__pos_layout_dir . '/pos_layout_04_products_txn.php';
require $__pos_layout_dir . '/pos_layout_05_reports.php';
require $__pos_layout_dir . '/pos_layout_06_settings.php';
