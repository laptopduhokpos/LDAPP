// POS reports - expenses & print/settings UI
        // --- EXPENSES & SETTINGS ---
        function renderExpenses() { 
            if (typeof ensureDateFilterToday === 'function') ensureDateFilterToday('expenses');
            // Populate Dropdown
            const select = document.getElementById('e-comp-select');
            if (!select) return;
            var expAll = (typeof t === 'function') ? t('exp_comp_all') : 'مەزاختنێن گشتی';
            var staffGrp = (typeof t === 'function') ? t('exp_staff_optgroup') : 'کارمەند';
            var advGrp = (typeof t === 'function') ? t('exp_advance_optgroup') : 'نزبا یا کاری';
            var salPref = (typeof t === 'function') ? t('exp_salary_colon') : 'مووچە:';
            var advPref = (typeof t === 'function') ? t('exp_advance_colon') : 'نزبا:';
            select.innerHTML = '<option value="">' + escapeHtml(expAll) + '</option>';
            if(db.companies) {
                db.companies.forEach(c => {
                    select.innerHTML += `<option value="${escapeHtml(c.name)}">${escapeHtml(c.name)}</option>`;
                });
            }
            if(db.users) {
                select.innerHTML += '<optgroup label="' + escapeHtml(advGrp) + '">';
                db.users.forEach(u => {
                    select.innerHTML += `<option value="Advance: ${escapeHtml(u.name)}">${escapeHtml(advPref + u.name)}</option>`;
                });
                select.innerHTML += '</optgroup>';
                select.innerHTML += '<optgroup label="' + escapeHtml(staffGrp) + '">';
                db.users.forEach(u => {
                    select.innerHTML += `<option value="Salary: ${escapeHtml(u.name)}">${escapeHtml(salPref + u.name)}</option>`;
                });
                select.innerHTML += '</optgroup>';
            }

            // Render List
            if (!Array.isArray(db.expenses)) db.expenses = [];
            let list = (typeof filterOperationalExpenses === 'function' ? filterOperationalExpenses(db.expenses) : db.expenses.slice());
            // Security: Cashiers only see their own expenses
            if(currentUser && currentUser.role !== 'admin') {
                list = list.filter(e => e.user === currentUser.name);
            }

            const filteredList = list.filter(e => isDateInScope(e.date, 'expenses'));

            // Check if financial data is fully loaded, trigger fetch if pending
            var isFinReady = (typeof posIsFinancialDataReady === 'function') ? posIsFinancialDataReady() : true;
            if (!isFinReady && typeof posFetchSecondaryDataNow === 'function') {
                posFetchSecondaryDataNow(1);
            }

            // --- NEW: Calculate Stats for Expense Dashboard ---
            const todayStr = getBusinessDate(new Date());
            const thisMonthStr = getBusinessMonth(new Date());
            
            const todayRows = list.filter(e => getBusinessDate(parseSQLDate(e.date)) === todayStr);
            const monthRows = list.filter(e => getBusinessMonth(parseSQLDate(e.date)) === thisMonthStr);
            const fmtExpSum = (typeof formatFrozenIqdRowsSum === 'function') ? formatFrozenIqdRowsSum : function(rows) {
                return formatCurrency(rows.reduce(function(s, e) { return s + ((typeof expenseAmountIqd === 'function') ? expenseAmountIqd(e) : (parseFloat(e.amount) || 0)); }, 0));
            };
            const fmtExpRow = (typeof formatExpenseAmountDisplay === 'function')
                ? formatExpenseAmountDisplay
                : function(e) { return formatCurrency((typeof expenseAmountIqd === 'function') ? expenseAmountIqd(e) : e.amount); };

            if(document.getElementById('exp-stat-today')) document.getElementById('exp-stat-today').innerText = fmtExpSum(todayRows);
            if(document.getElementById('exp-stat-month')) document.getElementById('exp-stat-month').innerText = fmtExpSum(monthRows);
            if(document.getElementById('exp-stat-total')) document.getElementById('exp-stat-total').innerText = fmtExpSum(filteredList);
            var kindOf = (typeof staffPayExpenseKind === 'function') ? staffPayExpenseKind : function() { return ''; };
            var monthSalaryRows = monthRows.filter(function(e) { return kindOf(e.note) === 'salary'; });
            var monthAdvanceRows = monthRows.filter(function(e) { return kindOf(e.note) === 'advance'; });
            if (document.getElementById('exp-stat-salary-month')) document.getElementById('exp-stat-salary-month').innerText = fmtExpSum(monthSalaryRows);
            if (document.getElementById('exp-stat-advance-month')) document.getElementById('exp-stat-advance-month').innerText = fmtExpSum(monthAdvanceRows);

            const retImpactEl = document.getElementById('exp-stat-returns-impact');
            if (retImpactEl && typeof getFinancialMetrics === 'function') {
                const _showReturnImpact = (typeof canViewProfit === 'function') ? canViewProfit() : true;
                const _retCard = retImpactEl.closest('.stat-card, .card');
                if (_retCard) _retCard.style.display = _showReturnImpact ? '' : 'none';
                if (_showReturnImpact) {
                    const m = getFinancialMetrics(todayStr);
                    const imp = m && m.returnProfitImpact != null ? m.returnProfitImpact : 0;
                    const impUsd = m && m.returnProfitImpactUsd != null ? m.returnProfitImpactUsd : undefined;
                    retImpactEl.innerText = (typeof formatCanonicalMoney === 'function')
                        ? formatCanonicalMoney(imp, impUsd)
                        : formatCurrency(imp);
                } else {
                    retImpactEl.innerText = '---';
                }
            }

            var expListEl = document.getElementById('expense-list');
            if (expListEl) {
                var dl = typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ';
                if (!filteredList.length) {
                    var emptyMsg = !isFinReady
                        ? ((typeof t === 'function') ? t('exp_list_loading') : 'مەزاختن بار دەکرێن… ئەگەر درێژ بوو Ctrl+F5 بکە.')
                        : ((typeof t === 'function') ? t('exp_list_empty') : 'هیچ مەزاختنێک نییە بۆ ئەم فلتەرە.');
                    var emptyIco = !isFinReady ? 'fa-spinner fa-spin' : 'fa-wallet';
                    expListEl.innerHTML = '<div class="expense-empty-state"><i class="fas ' + emptyIco + '"></i><p>' + escapeHtml(emptyMsg) + '</p></div>';
                } else expListEl.innerHTML = filteredList.slice().reverse().slice(0, 50).map(e => {
                    var noteDisp = (typeof translateExpenseNoteForUi === 'function') ? translateExpenseNoteForUi(e.note) : (e.note || '');
                    var canManage = canDeleteExpense();
                    var editBtn = (canManage && !isPurchaseLinkedExpense(e))
                        ? `<button type="button" class="btn btn-sm btn-warning expense-row-btn" onclick="editExpense(${e.id})" title="${escapeHtml((typeof t === 'function') ? t('exp_btn_edit') : 'دەستکاری')}"><i class="fas fa-pen"></i></button>`
                        : '';
                    var delBtn = (canManage && !isPurchaseLinkedExpense(e))
                        ? `<button type="button" class="btn btn-sm btn-dark expense-row-btn" onclick="deleteExpense(${e.id})" title="${escapeHtml((typeof t === 'function') ? t('exp_btn_delete') : 'سڕینەوە')}"><i class="fas fa-trash"></i></button>`
                        : '';
                    var payKind = (typeof staffPayExpenseKind === 'function') ? staffPayExpenseKind(e.note) : '';
                    var rowIco = isPurchaseLinkedExpense(e) ? 'fa-truck' : (payKind === 'salary' ? 'fa-user-tie' : (payKind === 'advance' ? 'fa-hand-holding-usd' : 'fa-wallet'));
                    return `
                <div class="expense-row-card">
                    <div class="expense-row-avatar" aria-hidden="true"><i class="fas ${rowIco}"></i></div>
                    <div class="expense-row-body">
                        <b class="expense-row-note">${escapeHtml(noteDisp)}</b>
                        <small class="expense-row-meta"><i class="fas fa-clock"></i> ${parseSQLDate(e.date).toLocaleDateString(dl)} &nbsp; <i class="fas fa-user"></i> ${escapeHtml(e.user || '-')}</small>
                    </div>
                    <div class="expense-row-amt"><i class="fas fa-coins"></i> ${fmtExpRow(e)}</div>
                    <div class="expense-row-actions">${editBtn}${delBtn}</div>
                </div>`;
                }).join('');
            }
            renderDeletedExpenses();
            var editEl = document.getElementById('e-edit-id');
            if (!window._expFormCurrencyInited) {
                window._expFormCurrencyInited = true;
                if (!editEl || !String(editEl.value || '').trim()) setExpenseFormCurrencyDefault();
            } else if (!editEl || !String(editEl.value || '').trim()) {
                if (typeof syncExpenseAmountInputKind === 'function') syncExpenseAmountInputKind();
            }
        }

        function canDeleteExpense() {
            if (!currentUser) return false;
            if (currentUser.role === 'admin') return true;
            return (typeof hasPermission === 'function') && hasPermission('expenses_manage');
        }

        function canEditExpense() {
            return canDeleteExpense();
        }

        function setExpenseFormMode(editing) {
            var saveBtn = document.getElementById('e-save-btn');
            var cancelBtn = document.getElementById('e-cancel-edit-btn');
            if (saveBtn) {
                var label = editing
                    ? ((typeof t === 'function') ? t('exp_btn_update') : 'نوێکردنەوە')
                    : ((typeof t === 'function') ? t('exp_btn_save') : 'تۆمارکرن');
                var icon = editing ? 'fa-check' : 'fa-floppy-disk';
                saveBtn.innerHTML = '<i class="fas ' + icon + '"></i> <span>' + escapeHtml(label) + '</span>';
            }
            if (cancelBtn) cancelBtn.style.display = editing ? '' : 'none';
        }

        function cancelExpenseEdit() {
            var editEl = document.getElementById('e-edit-id');
            if (editEl) editEl.value = '';
            var noteEl = document.getElementById('e-note');
            var amtEl = document.getElementById('e-amount');
            var compEl = document.getElementById('e-comp-select');
            if (noteEl) noteEl.value = '';
            if (amtEl) amtEl.value = '';
            if (compEl) compEl.value = '';
            setExpenseFormCurrencyDefault();
            setExpenseFormMode(false);
        }

        function parseExpenseNoteForEdit(note) {
            var raw = String(note || '').trim();
            if (!raw) return { note: '', company: '' };
            var m = raw.match(/^(.+?)\s+\(([^)]+)\)\s*$/);
            if (m) return { note: m[1].trim(), company: m[2].trim() };
            var payRaw = raw.replace(/^Expense:\s*/i, '');
            if (payRaw.indexOf('Salary: ') === 0 || payRaw.indexOf('Advance: ') === 0) {
                var dashAt = payRaw.indexOf(' — ');
                if (dashAt > 0) return { note: payRaw.slice(dashAt + 3).trim(), company: payRaw.slice(0, dashAt).trim() };
                return { note: '', company: payRaw };
            }
            if (raw.indexOf('Expense: ') === 0) return { note: '', company: raw.replace(/^Expense:\s*/, '') };
            return { note: raw, company: '' };
        }

        function formatExpenseAmount(e) {
            if (!e) return (typeof formatCurrency === 'function') ? formatCurrency(0) : '0';
            if (typeof formatExpenseAmountDisplay === 'function') return formatExpenseAmountDisplay(e);
            if (typeof formatFrozenIqdAmount === 'function') return formatFrozenIqdAmount(e, (typeof expenseAmountIqd === 'function') ? expenseAmountIqd(e) : e.amount);
            return formatCurrency((typeof expenseAmountIqd === 'function') ? expenseAmountIqd(e) : e.amount);
        }

        function getExpenseFormCurrency() {
            var el = document.getElementById('e-currency');
            var v = el ? String(el.value || '').toUpperCase() : '';
            if (v === 'USD' || v === 'IQD') return v;
            return (typeof getDefaultCurrency === 'function') ? getDefaultCurrency() : 'IQD';
        }

        function setExpenseFormCurrency(cur) {
            var el = document.getElementById('e-currency');
            if (!el) return;
            var v = String(cur || '').toUpperCase();
            if (v !== 'USD' && v !== 'IQD') v = (typeof getDefaultCurrency === 'function') ? getDefaultCurrency() : 'IQD';
            el.value = v;
            syncExpenseAmountInputKind();
        }

        function setExpenseFormCurrencyDefault() {
            setExpenseFormCurrency((typeof getDefaultCurrency === 'function') ? getDefaultCurrency() : 'IQD');
        }

        function syncExpenseAmountInputKind() {
            var amtEl = document.getElementById('e-amount');
            if (!amtEl) return;
            var usd = getExpenseFormCurrency() === 'USD';
            amtEl.classList.add('pos-money-input');
            amtEl.dataset.moneyInputKind = usd ? 'usd' : 'int';
            amtEl.setAttribute('inputmode', 'decimal');
            amtEl.setAttribute('dir', 'ltr');
            amtEl.placeholder = usd
                ? ((typeof t === 'function') ? t('exp_amount_ph_usd') : '0.00')
                : ((typeof t === 'function') ? t('exp_amount_ph') : 'بڕ');
            amtEl.title = usd ? '$ (USD)' : 'IQD';
        }

        function onExpenseCurrencyChange() {
            syncExpenseAmountInputKind();
        }
        try { window.onExpenseCurrencyChange = onExpenseCurrencyChange; window.syncExpenseAmountInputKind = syncExpenseAmountInputKind; } catch (_eCur) {}

        function expenseFrozenRatePerOne(exp) {
            if (typeof expenseRecordRatePerOne === 'function') return expenseRecordRatePerOne(exp);
            return (typeof getUsdRatePerOne === 'function') ? getUsdRatePerOne() : 0;
        }

        function expenseAmountForForm(expRow) {
            if (!expRow) return '';
            var cur = (typeof expenseRecordCurrency === 'function') ? expenseRecordCurrency(expRow) : 'IQD';
            var n = Number(expRow.amount) || 0;
            if (cur === 'USD') {
                return (typeof formatPaymentAmountNumber === 'function')
                    ? formatPaymentAmountNumber(n, 'usd')
                    : String(Number(n).toFixed(2));
            }
            if (typeof formatPaymentAmountNumber === 'function') {
                return formatPaymentAmountNumber(Math.round(n), 'int');
            }
            return String(Math.round(n));
        }

        function editExpense(id) {
            if (!canEditExpense()) return;
            var numId = parseInt(id, 10);
            if (!numId) return;
            var exp = (db.expenses || []).find(function(e) { return Number(e.id) === numId; });
            if (!exp || isPurchaseLinkedExpense(exp)) return;

            var parsed = parseExpenseNoteForEdit(exp.note);
            var noteEl = document.getElementById('e-note');
            var amtEl = document.getElementById('e-amount');
            var compEl = document.getElementById('e-comp-select');
            var editEl = document.getElementById('e-edit-id');
            if (noteEl) noteEl.value = parsed.note;
            if (amtEl) amtEl.value = expenseAmountForForm(exp);
            if (compEl) compEl.value = parsed.company || '';
            setExpenseFormCurrency((typeof expenseRecordCurrency === 'function') ? expenseRecordCurrency(exp) : 'IQD');
            if (editEl) editEl.value = String(numId);
            setExpenseFormMode(true);
            if (noteEl) {
                try { noteEl.focus(); noteEl.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch (e) {}
            }
        }

        function isPurchaseLinkedExpense(e) {
            if (!e) return false;
            if ((e.type || '') === 'purchase') return true;
            var note = String(e.note || '');
            if (e.transaction_id && (note.indexOf('کڕین') >= 0 || note.indexOf('شراء') >= 0)) return true;
            return false;
        }

        function renderDeletedExpenses(scrollToSection) {
            var wrap = document.getElementById('expense-deleted-list');
            var section = document.getElementById('expense-deleted-section');
            var countEl = document.getElementById('expense-deleted-count');
            if (!wrap || !section) return;
            if (!canDeleteExpense()) {
                section.style.display = 'none';
                section.setAttribute('aria-hidden', 'true');
                return;
            }
            section.style.display = '';
            section.setAttribute('aria-hidden', 'false');
            var list = (db.expenses_deleted || []).slice().sort(function(a, b) {
                return String(b.archived_at || '').localeCompare(String(a.archived_at || ''));
            });
            if (countEl) countEl.textContent = list.length ? String(list.length) : '';
            if (!list.length) {
                wrap.innerHTML = '<div class="expense-deleted-row expense-deleted-row--empty"><small>' + escapeHtml((typeof t === 'function') ? t('exp_deleted_empty') : 'هیچ مەزاختنێکی سڕدراو نییە.') + '</small></div>';
                if (scrollToSection) {
                    try { section.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); } catch (e) {}
                }
                return;
            }
            var dl = typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ';
            var badgeLbl = (typeof t === 'function') ? t('exp_deleted_badge') : 'سڕدراو';
            var byLbl = (typeof t === 'function') ? t('exp_deleted_by') : 'سڕدراو لەلایەن';
            wrap.innerHTML = list.slice(0, 50).map(function(e) {
                var noteDisp = (typeof translateExpenseNoteForUi === 'function') ? translateExpenseNoteForUi(e.note) : (e.note || '');
                var delAt = e.archived_at ? parseSQLDate(e.archived_at).toLocaleString(dl) : '-';
                var origDate = e.date ? parseSQLDate(e.date).toLocaleDateString(dl) : '-';
                return `
                <div class="expense-deleted-row">
                    <span class="expense-deleted-badge"><i class="fas fa-trash"></i> ${escapeHtml(badgeLbl)}</span>
                    <b class="expense-deleted-note">${escapeHtml(noteDisp)}</b>
                    <span class="expense-deleted-amount"><i class="fas fa-coins"></i> ${formatExpenseAmount(e)}</span>
                    <small class="expense-deleted-meta"><i class="fas fa-clock"></i> ${escapeHtml(origDate)} | <i class="fas fa-user"></i> ${escapeHtml(e.user || '-')}<br>
                    <i class="fas fa-user-slash"></i> ${escapeHtml(byLbl)}: <strong>${escapeHtml(e.deleted_by || '-')}</strong> | ${escapeHtml(delAt)}</small>
                </div>`;
            }).join('');
            if (scrollToSection) {
                try { section.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); } catch (e) {}
            }
        }

        function deleteExpense(id) {
            if (!canDeleteExpense()) return;
            var numId = parseInt(id, 10);
            if (!numId) return;
            var exp = (db.expenses || []).find(function(e) { return Number(e.id) === numId; });
            if (!exp) return;
            var noteDisp = (typeof translateExpenseNoteForUi === 'function') ? translateExpenseNoteForUi(exp.note) : (exp.note || '');
            var msgTpl = (typeof t === 'function') ? t('exp_delete_confirm') : 'دڵنیایت لە سڕینەوەی ئەم مەزاختنە؟\n{note}\n{amount}';
            var msg = msgTpl.replace('{note}', noteDisp).replace('{amount}', formatExpenseAmount(exp));
            if (!confirm(msg)) return;

            var user = currentUser ? currentUser.name : 'System';
            var formData = new FormData();
            formData.append('action', 'delete_expense');
            formData.append('id', String(numId));
            formData.append('user', user);

            fetch('?action=delete_expense', { method: 'POST', body: formData, credentials: 'same-origin' })
                .then(function(res) {
                    return res.text().then(function(text) {
                        try { return JSON.parse(text); } catch (e) {
                            return { status: 'error', message: text ? String(text).slice(0, 200) : 'Invalid server response' };
                        }
                    });
                })
                .then(function(data) {
                    if (!data || typeof data !== 'object') {
                        alert((typeof t === 'function') ? t('exp_delete_failed') : 'سڕینەوەی مەزاختن سەرکەوتوو نەبوو.');
                        return;
                    }
                    if (data.status === 'success') {
                        db.expenses = (db.expenses || []).filter(function(e) { return Number(e.id) !== numId; });
                        if (!db.expenses_deleted) db.expenses_deleted = [];
                        if (data.deleted) {
                            var delId = Number(data.deleted.id);
                            var exists = db.expenses_deleted.some(function(x) { return Number(x.id) === delId; });
                            if (!exists) db.expenses_deleted.unshift(data.deleted);
                        }
                        if (db.today_stats && exp.date) {
                            var todayStr = (typeof getBusinessDate === 'function') ? getBusinessDate(new Date()) : '';
                            var expDay = (typeof getBusinessDate === 'function') ? getBusinessDate(parseSQLDate(exp.date)) : '';
                            if (todayStr && expDay === todayStr) {
                                var delIqd = (typeof expenseAmountIqd === 'function') ? expenseAmountIqd(exp) : (parseFloat(exp.amount) || 0);
                                db.today_stats.expenses = Math.max(0, (parseFloat(db.today_stats.expenses) || 0) - delIqd);
                            }
                        }
                        if (typeof posInvalidateDailyDetailCache === 'function' && typeof getBusinessDate === 'function') {
                            posInvalidateDailyDetailCache(getBusinessDate(new Date()));
                        }
                        renderExpenses();
                        renderDeletedExpenses(true);
                        if (typeof updateStats === 'function') updateStats();
                        if (typeof posRefreshOpenFinancialScreens === 'function') posRefreshOpenFinancialScreens();
                        window._printLogLoaded = false;
                        var ghView = document.getElementById('view-print-history');
                        if (ghView && ghView.classList.contains('active') && typeof renderGeneralHistory === 'function') renderGeneralHistory();
                        alert((typeof t === 'function') ? t('exp_deleted_ok') : 'مەزاختن سڕایەوە — لە تۆمار/ئەرشیفدا مایەوە.');
                    } else {
                        alert(data.message || ((typeof t === 'function') ? t('exp_delete_failed') : 'سڕینەوە سەرکەوتوو نەبوو.'));
                    }
                })
                .catch(function(err) {
                    var msg = (err && err.message) ? err.message : '';
                    alert(msg || ((typeof t === 'function') ? t('exp_delete_failed') : 'سڕینەوەی مەزاختن سەرکەوتوو نەبوو.'));
                });
        }

        function saveExpense() { 
            const noteInput = document.getElementById('e-note').value;
            const rawAmountInput = (document.getElementById('e-amount').value || '').trim();
            const editIdEl = document.getElementById('e-edit-id');
            const editId = editIdEl ? parseInt(editIdEl.value, 10) : 0;
            const parsedDisplayAmount = (typeof parseAmountInput === 'function')
                ? parseAmountInput(rawAmountInput)
                : (function(v) {
                    var s = String(v || '').replace(/[\u066B]/g, '.').replace(/\s+/g, '');
                    if (s.indexOf('.') === -1 && s.indexOf(',') !== -1) s = s.replace(',', '.');
                    else s = s.replace(/,/g, '');
                    return parseFloat(s);
                })(rawAmountInput);
            const amountDisplay = Number.isFinite(parsedDisplayAmount) ? parsedDisplayAmount : NaN;
            const expCurrency = getExpenseFormCurrency();
            const liveRate = (typeof getUsdRatePerOne === 'function') ? getUsdRatePerOne() : 0;
            const amount = amountDisplay;
            const normalizedAmount = (expCurrency === 'USD')
                ? ((typeof roundUsd === 'function') ? roundUsd(amount) : Math.round(amount * 100) / 100)
                : ((typeof roundMoney === 'function') ? roundMoney(amount) : Math.round(amount));
            var existingExp = (editId > 0 && db.expenses) ? db.expenses.find(function(e) { return Number(e.id) === editId; }) : null;
            var postedRate = liveRate;
            if (existingExp) {
                var oldCur = (typeof expenseRecordCurrency === 'function') ? expenseRecordCurrency(existingExp) : 'IQD';
                var oldAmt = Number(existingExp.amount) || 0;
                var oldRate = expenseFrozenRatePerOne(existingExp);
                var amtUnchanged = Math.abs(oldAmt - normalizedAmount) < 0.005;
                if (oldCur === expCurrency && amtUnchanged && oldRate > 0) postedRate = oldRate;
            }
            if (!(postedRate > 0)) postedRate = 1500;
            var pendingRow = { amount: normalizedAmount, currency: expCurrency, exchange_rate: postedRate };
            var pendingIqd = (typeof expenseAmountIqd === 'function') ? expenseAmountIqd(pendingRow) : normalizedAmount;
            const compSelect = document.getElementById('e-comp-select').value;
            
            let finalNote = noteInput;
            if(compSelect) {
                if (compSelect.indexOf('Salary:') === 0 || compSelect.indexOf('Advance:') === 0) {
                    finalNote = noteInput ? (compSelect + ' — ' + noteInput) : compSelect;
                } else {
                    finalNote = noteInput ? `${noteInput} (${compSelect})` : `Expense: ${compSelect}`;
                }
            }

            if (!(finalNote && Number.isFinite(normalizedAmount) && normalizedAmount > 0)) {
                if (rawAmountInput) {
                    alert((typeof t === 'function') ? t('exp_invalid_amount') : '⚠️ بڕا مەزاختنێ دروست بنڤیسە (دەتوانی کەسر/دەسەنیشانیش بنڤیسی).');
                }
                return;
            }

            const user = currentUser ? currentUser.name : 'System';

            if (editId > 0) {
                if (!canEditExpense()) return;
                const formData = new FormData();
                formData.append('action', 'update_expense');
                formData.append('id', String(editId));
                formData.append('note', finalNote);
                formData.append('amount', normalizedAmount);
                formData.append('currency', expCurrency);
                formData.append('exchange_rate', String(postedRate || 0));
                formData.append('user', user);

                fetch('?action=update_expense', { method: 'POST', body: formData, credentials: 'same-origin' })
                .then(function(res) {
                    return res.text().then(function(text) {
                        try { return JSON.parse(text); } catch (e) {
                            return { status: 'error', message: text ? String(text).slice(0, 200) : 'Invalid server response' };
                        }
                    });
                })
                .then(function(data) {
                    if (data && data.status === 'success' && data.expense) {
                        var oldExp = (db.expenses || []).find(function(e) { return Number(e.id) === editId; });
                        var oldIqd = oldExp
                            ? ((typeof expenseAmountIqd === 'function') ? expenseAmountIqd(oldExp) : (parseFloat(oldExp.amount) || 0))
                            : (parseFloat(data.old_iqd != null ? data.old_iqd : data.old_amount) || 0);
                        var newIqd = (data.ledger_iqd != null)
                            ? (parseFloat(data.ledger_iqd) || 0)
                            : pendingIqd;
                        db.expenses = (db.expenses || []).map(function(e) {
                            return Number(e.id) === editId ? Object.assign({}, e, data.expense) : e;
                        });
                        if (db.today_stats && oldExp && oldExp.date) {
                            var todayStr = (typeof getBusinessDate === 'function') ? getBusinessDate(new Date()) : '';
                            var expDay = (typeof getBusinessDate === 'function') ? getBusinessDate(parseSQLDate(oldExp.date)) : '';
                            if (todayStr && expDay === todayStr) {
                                db.today_stats.expenses = Math.max(0, (parseFloat(db.today_stats.expenses) || 0) - oldIqd + newIqd);
                            }
                        }
                        cancelExpenseEdit();
                        renderExpenses();
                        if (typeof posInvalidateDailyDetailCache === 'function' && typeof getBusinessDate === 'function') {
                            posInvalidateDailyDetailCache(getBusinessDate(new Date()));
                        }
                        if (typeof updateStats === 'function') updateStats();
                        if (typeof posRefreshOpenFinancialScreens === 'function') posRefreshOpenFinancialScreens();
                    } else {
                        alert((data && data.message) || ((typeof t === 'function') ? t('exp_update_failed') : 'نوێکردنەوە سەرکەوتوو نەبوو.'));
                    }
                })
                .catch(function(err) {
                    alert((err && err.message) || ((typeof t === 'function') ? t('exp_update_failed') : 'نوێکردنەوە سەرکەوتوو نەبوو.'));
                });
                return;
            }

            const formData = new FormData();
            formData.append('action', 'save_expense');
            formData.append('note', finalNote);
            formData.append('amount', normalizedAmount);
            formData.append('currency', expCurrency);
            formData.append('exchange_rate', String(postedRate || 0));
            formData.append('user', user);
            if (typeof db !== 'undefined' && db && db.settings && db.settings.usdRate) {
                var fxSave = (typeof normalizeUsdBundleRate === 'function')
                    ? normalizeUsdBundleRate(db.settings.usdRate)
                    : Math.round(Number(db.settings.usdRate) || 0);
                if (fxSave >= 1000) formData.append('fx_usd_rate', String(fxSave));
                if (db.settings.currencyMode === 'USD' || db.settings.currencyMode === 'IQD') {
                    formData.append('fx_currency_mode', db.settings.currencyMode);
                }
            }

            fetch('?action=save_expense', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                if(data.status === 'success') {
                    var savedRow = {
                        id: data.id,
                        note: finalNote,
                        amount: data.amount != null ? data.amount : normalizedAmount,
                        currency: data.currency || expCurrency,
                        exchange_rate: data.exchange_rate != null ? data.exchange_rate : postedRate,
                        date: data.date || new Date(),
                        user: user,
                        type: 'operational',
                        transaction_id: data.transaction_id || null,
                        fx_usd_rate: data.fx_usd_rate != null ? data.fx_usd_rate : (db.settings && db.settings.usdRate),
                        fx_currency_mode: data.fx_currency_mode || (db.settings && db.settings.currencyMode) || null
                    };
                    db.expenses.push(savedRow);
                    
                    if(db.today_stats) {
                        var addIqd = (typeof expenseAmountIqd === 'function') ? expenseAmountIqd(savedRow) : pendingIqd;
                        db.today_stats.expenses = (parseFloat(db.today_stats.expenses) || 0) + addIqd;
                    }

                    if (typeof window.scheduleFirebaseMobilePush === 'function') {
                        window.scheduleFirebaseMobilePush('expense', false);
                    }
                    if (typeof posInvalidateDailyDetailCache === 'function' && typeof getBusinessDate === 'function') {
                        posInvalidateDailyDetailCache(getBusinessDate(new Date()));
                    }
                    cancelExpenseEdit();
                    renderExpenses(); 
                    updateStats();
                    if (typeof posRefreshOpenFinancialScreens === 'function') posRefreshOpenFinancialScreens();
                }
            });
        }
        
        // Promisified Save Settings for Chaining
        function saveSettingsPromise() {
            return new Promise((resolve) => {
                const formData = new FormData();
                formData.append('action', 'save_settings');
                formData.append('settings', JSON.stringify(db.settings));
                fetch('?action=save_settings', { method: 'POST', body: formData })
                .then(() => resolve()).catch(() => resolve()); // Always resolve to prevent blocking sale
            });
        }

        function savePrintSettings() {
            if (typeof ensurePremiumFeatureUnlocks === 'function') ensurePremiumFeatureUnlocks();
            // Identity (اسم المتجر، لۆگۆ، تەلەفۆن، footer، ملاحظات) تُحفظ فقط من إعدادات الطباعة والتصميم
            db.settings.paperWidth = (getPrintConfig && getPrintConfig('pos_sale') ? getPrintConfig('pos_sale').paper : null) || (document.getElementById('set-paper-size') && document.getElementById('set-paper-size').value) || '80mm';
            db.settings.autoPrint = document.getElementById('set-auto-print').checked;
            db.settings.autoPrintPurchaseInvoice = document.getElementById('set-auto-print-purchase-invoice') ? document.getElementById('set-auto-print-purchase-invoice').checked : false;
            var jumlaEl = document.getElementById('set-enable-takeaway');
            if (typeof syncJumlaSystemSettings === 'function') syncJumlaSystemSettings(!!(jumlaEl && jumlaEl.checked));
            else {
                db.settings.enableTakeaway = jumlaEl ? jumlaEl.checked : false;
                if (!db.settings.enableTakeaway) db.settings.takeawayAsWholesale = false;
            }
            db.settings.useBarcode = document.getElementById('set-use-barcode').checked;
            db.settings.enableDebt = document.getElementById('set-enable-debt').checked;
            db.settings.showTables = document.getElementById('set-show-tables').checked;
            db.settings.showCustomerName = document.getElementById('set-show-customer-name').checked;
            db.settings.enableKitchen = document.getElementById('set-enable-kitchen') ? document.getElementById('set-enable-kitchen').checked : true;
            db.settings.showItemNoteIcon = document.getElementById('set-show-note-icon').checked;
            db.settings.enableWaste = document.getElementById('set-enable-waste').checked;
            db.settings.enableRecipe = document.getElementById('set-enable-recipe').checked;
            db.settings.enableGift = document.getElementById('set-enable-gift').checked;
            db.settings.enableWholesale = document.getElementById('set-enable-wholesale').checked;
            db.settings.enableMoneyRounding = document.getElementById('set-enable-money-rounding').checked;
            db.settings.enableManualPrice = document.getElementById('set-enable-manual-price').checked;
            var elManualSale = document.getElementById('set-enable-manual-sale');
            if (elManualSale) db.settings.enableManualSale = elManualSale.checked;
            var elSortOutOfStockBottom = document.getElementById('set-sort-out-of-stock-bottom');
            if (elSortOutOfStockBottom) db.settings.sortOutOfStockToBottom = elSortOutOfStockBottom.checked;
            var elUnlockStaffBeyond = document.getElementById('set-unlock-staff-beyond-five');
            if (elUnlockStaffBeyond) db.settings.unlockStaffBeyondFive = elUnlockStaffBeyond.checked;
            db.settings.showReturnButton = document.getElementById('set-show-return-button').checked;
            var showStockPosEl = document.getElementById('set-show-stock-on-pos');
            if (showStockPosEl) db.settings.showStockOnPos = showStockPosEl.checked;
            db.settings.showPaymentModal = document.getElementById('set-show-payment-modal').checked;
            var openingPromptEl = document.getElementById('set-require-opening-balance-prompt');
            if (openingPromptEl) db.settings.requireOpeningBalancePrompt = openingPromptEl.checked;
            var endShiftPromptEl = document.getElementById('set-require-end-shift-reconcile-prompt');
            if (endShiftPromptEl) db.settings.requireEndShiftReconcilePrompt = endShiftPromptEl.checked;
            var elWarehouse = document.getElementById('set-enable-warehouse');
            if (elWarehouse) db.settings.enableWarehouse = elWarehouse.checked;
            var elCompanies = document.getElementById('set-enable-companies');
            if (elCompanies) db.settings.enableCompanies = elCompanies.checked;
            var elPurchase = document.getElementById('set-enable-purchase');
            if (elPurchase) db.settings.enablePurchase = elPurchase.checked;
            var elReports = document.getElementById('set-enable-reports');
            if (elReports) db.settings.enableReports = elReports.checked;
            var elDelivery = document.getElementById('set-enable-delivery');
            if (elDelivery) db.settings.enableDelivery = elDelivery.checked;
            var elMultiWh = document.getElementById('set-enable-multi-warehouse');
            if (elMultiWh) db.settings.enableMultiWarehouse = elMultiWh.checked;
            var elPurchaseBatch = document.getElementById('premium-purchase-batch');
            if (elPurchaseBatch) db.settings.enablePurchaseBatch = elPurchaseBatch.checked;
            var elMfrSlot = document.getElementById('premium-mfr-slot');
            if (elMfrSlot) db.settings.manufacturerSlot = elMfrSlot.checked;
            var elTechSpecs = document.getElementById('premium-tech-specs');
            if (elTechSpecs) db.settings.enableTechSpecs = elTechSpecs.checked;
            var elSaleFollowup = document.getElementById('premium-sale-followup');
            if (elSaleFollowup) db.settings.enableSaleFollowup = elSaleFollowup.checked;
            var elExpenses = document.getElementById('set-enable-expenses');
            if (elExpenses) db.settings.enableExpenses = elExpenses.checked;
            var elCalendar = document.getElementById('set-enable-calendar');
            if (elCalendar) db.settings.enableCalendar = elCalendar.checked;
            var elNotifications = document.getElementById('set-enable-notifications');
            if (elNotifications) db.settings.enableNotifications = elNotifications.checked;
            var elHideWhStockWarn = document.getElementById('set-hide-warehouse-stock-warn');
            if (elHideWhStockWarn) db.settings.hideWarehouseStockWarn = elHideWhStockWarn.checked;
            var elStaff = document.getElementById('set-enable-staff');
            if (elStaff) db.settings.enableStaff = elStaff.checked;
            var elMultiCart = document.getElementById('set-enable-multi-cart');
            if (elMultiCart) db.settings.enableMultiCartTabs = elMultiCart.checked;
            var elAllowNegativeStock = document.getElementById('set-allow-negative-stock');
            if (elAllowNegativeStock) db.settings.allowNegativeStock = elAllowNegativeStock.checked;
            var elBusinessDayStart = document.getElementById('set-business-day-start-hour');
            if (elBusinessDayStart && !elBusinessDayStart.disabled) {
                db.settings.businessDayStartHour = parseInt(elBusinessDayStart.value, 10) || 0;
            }
            var rateInputSave = document.getElementById('set-exchange-rate');
            var usdRS = document.getElementById('set-currency-usd');
            var iqdRS = document.getElementById('set-currency-iqd');
            if (usdRS && iqdRS && typeof isCurrencyModeLocked === 'function' && !isCurrencyModeLocked()) {
                if (typeof applyShopDefaultCurrency === 'function') {
                    applyShopDefaultCurrency(iqdRS.checked ? 'IQD' : 'USD');
                } else {
                    db.settings.currencyMode = iqdRS.checked ? 'IQD' : 'USD';
                }
            }
            ensureValidCurrencyMode();
            var canRateExp = (typeof canEditExchangeRate === 'function') ? canEditExchangeRate() : false;
            if (rateInputSave && canRateExp && !(typeof isIqdExchangeRateLocked === 'function' && isIqdExchangeRateLocked())) {
                db.settings.usdRate = normalizeUsdBundleRateFromInput(rateInputSave.value);
            } else if (!db.settings.usdRate) {
                db.settings.usdRate = 150000;
            }
            if(document.getElementById('tg-bot-token')) db.settings.tgToken = document.getElementById('tg-bot-token').value;
            if(document.getElementById('tg-chat-id')) db.settings.tgChatId = document.getElementById('tg-chat-id').value;
            
            // New Telegram Shift Settings
            var tgShiftStart = document.getElementById('set-tg-shift-start-report');
            if (tgShiftStart) db.settings.tg_shift_start_report = tgShiftStart.checked;
            var tgShiftEnd = document.getElementById('set-tg-shift-end-report');
            if (tgShiftEnd) db.settings.tg_shift_end_report = tgShiftEnd.checked;
            var tgIncludeCash = document.getElementById('set-tg-include-cash-in-drawer');
            if (tgIncludeCash) db.settings.tg_include_cash_in_drawer = tgIncludeCash.checked;
            var tgReportType = document.getElementById('set-tg-report-type');
            if (tgReportType) db.settings.tg_report_type = tgReportType.value;

            var showFinA4 = document.getElementById('set-show-financial-summary-on-a4');
            if (showFinA4) db.settings.showFinancialSummaryOnA4 = showFinA4.checked;
            var showBothCurA4 = document.getElementById('set-show-both-currencies-on-a4');
            if (showBothCurA4) db.settings.showBothCurrenciesOnA4 = showBothCurA4.checked;
            var showBothCurUi = document.getElementById('set-show-both-currencies');
            if (showBothCurUi) db.settings.showBothCurrencies = showBothCurUi.checked;
            var showBothCurA4 = document.getElementById('set-show-both-currencies-on-a4');
            if (showBothCurA4) db.settings.showBothCurrenciesOnA4 = showBothCurA4.checked;

            var setLabMin = document.getElementById('set-label-min-stock-alert');
            var setLabEx = document.getElementById('set-label-expiry-alert-days');
            if (setLabMin) db.settings.labelProductMinStockAlert = setLabMin.value.trim();
            if (setLabEx) db.settings.labelProductExpiryAlertDays = setLabEx.value.trim();

            var useGlobalMinStockEl = document.getElementById('set-use-global-min-stock');
            if (useGlobalMinStockEl) db.settings.useGlobalMinStock = useGlobalMinStockEl.checked;
            var globalMinStockThresholdEl = document.getElementById('set-global-min-stock-threshold');
            if (globalMinStockThresholdEl) db.settings.globalMinStockThreshold = parseInt(globalMinStockThresholdEl.value, 10) || 0;

            saveSettings().then(function() {
                if (typeof persistSystemFeaturesToStorage === 'function') persistSystemFeaturesToStorage();
                if (typeof applyUserPermissions === 'function') applyUserPermissions();
                if (typeof applyMultiWarehouseVisibility === 'function') applyMultiWarehouseVisibility();
                if (typeof renderRightSidebar === 'function') renderRightSidebar();
                if (typeof applyPurchaseBatchPremiumUi === 'function') applyPurchaseBatchPremiumUi();
                if (typeof applyProductFormPremiumFeatureFields === 'function') applyProductFormPremiumFeatureFields();
                var homeEl = document.getElementById('home-grid-container');
                if (homeEl && typeof renderHomeView === 'function') renderHomeView();
                try {
                    localStorage.setItem('pos_usd_rate', String(db.settings.usdRate));
                    localStorage.setItem('pos_currency_mode', db.settings.currencyMode || 'IQD');
                } catch (eLs2) {}
                applyPrintSettings(); applySystemMode();
                if (typeof renderAll === 'function') renderAll();
                if (typeof updateUSDBadge === 'function') updateUSDBadge();
                if (typeof updateCurrencyLockUI === 'function') updateCurrencyLockUI();
                if (typeof showToast === 'function') showToast("✅ ڕێکخستن هاتنە پاراستن!");
            }).catch(function(e) { if (typeof showToast === 'function') showToast("❌ هەڵە د پاراستنێ دا: " + (e && e.message ? e.message : ""), 'error'); else alert("Save failed"); });
        }
        function applyPrintSettings() { 
            if(db && db.settings) { 
                var billName = document.getElementById('bill-cafe-name');
                if (billName) billName.innerText = db.settings.cafeName || '';
                var billInfo = document.getElementById('bill-cafe-info');
                if (billInfo) billInfo.innerText = db.settings.cafeInfo || '';
                var billFooter = document.getElementById('bill-footer-msg');
                if (billFooter) billFooter.innerText = db.settings.footer || '';
                var nameEl = document.getElementById('set-cafe-name');
                if (nameEl) nameEl.value = db.settings.cafeName || "";
                var infoEl = document.getElementById('set-cafe-info');
                if (infoEl) infoEl.value = db.settings.cafeInfo || "";
                var phoneEl = document.getElementById('set-cafe-phone');
                if (phoneEl) phoneEl.value = db.settings.cafePhone || "";
                var addrEl = document.getElementById('set-cafe-address');
                if (addrEl) addrEl.value = db.settings.cafeAddress || "";
                var footerEl = document.getElementById('set-cafe-footer');
                if (footerEl) footerEl.value = db.settings.footer || "";
                var noteEl = document.getElementById('set-invoice-note');
                if (noteEl) noteEl.value = db.settings.invoiceNote || "";
                var customNoteEl = document.getElementById('set-custom-note');
                if (customNoteEl) customNoteEl.value = db.settings.customNote || "";
                var sn1 = document.getElementById('set-static-note1'); if (sn1) sn1.value = db.settings.staticNote1 || "";
                var sn2 = document.getElementById('set-static-note2'); if (sn2) sn2.value = db.settings.staticNote2 || "";
                var sn3 = document.getElementById('set-static-note3'); if (sn3) sn3.value = db.settings.staticNote3 || "";
                var taxEl = document.getElementById('set-tax-number');
                if (taxEl) taxEl.value = db.settings.taxNumber || "";
                var webEl = document.getElementById('set-website');
                if (webEl) webEl.value = db.settings.website || "";
                var socialEl = document.getElementById('set-social-links');
                if (socialEl) socialEl.value = db.settings.socialLinks || "";
                var paperEl = document.getElementById('set-paper-size');
                if (paperEl) paperEl.value = (getPrintConfig && getPrintConfig('pos_sale') ? getPrintConfig('pos_sale').paper : null) || db.settings.paperWidth || "80mm";
                var logoPrev = document.getElementById('pds-logo-preview');
                var logoWrap = document.getElementById('pds-logo-preview-wrap');
                var shopLogoUrl = (typeof getPosShopLogoUrl === 'function') ? getPosShopLogoUrl() : (db.settings.logo || '');
                if (shopLogoUrl) {
                    if (logoPrev) { logoPrev.src = shopLogoUrl; logoPrev.style.display = ''; }
                    if (logoWrap) logoWrap.style.display = 'inline-block';
                } else {
                    if (logoPrev) logoPrev.src = ''; if (logoWrap) logoWrap.style.display = 'none';
                }
                if (typeof syncHomeShopLogo === 'function') syncHomeShopLogo();
                var d3LayoutEl = document.getElementById('set-a4-design3-logo-layout');
                if (d3LayoutEl) d3LayoutEl.value = db.settings.a4Design3LogoLayout || 'center';
                var accentEl = document.getElementById('set-a4-accent-theme');
                if (accentEl) accentEl.value = (db.settings.a4AccentTheme === 'navy' || db.settings.a4AccentTheme === 'blue') ? 'navy' : 'amber';
                if (typeof applyA4Design3LogoPreview === 'function') {
                    applyA4Design3LogoPreview('left', db.settings.a4Design3LogoLeft || '');
                    applyA4Design3LogoPreview('center', db.settings.a4Design3LogoCenter || '');
                    applyA4Design3LogoPreview('right', db.settings.a4Design3LogoRight || '');
                }
                if (typeof applyPrintDesignSettings === 'function') applyPrintDesignSettings();
                if (typeof updateReceiptPreview === 'function') updateReceiptPreview();
                document.getElementById('set-auto-print').checked = (db.settings.autoPrint !== false);
                var autoPurchasePrintEl = document.getElementById('set-auto-print-purchase-invoice');
                if (autoPurchasePrintEl) autoPurchasePrintEl.checked = (db.settings.autoPrintPurchaseInvoice === true);
                if (typeof normalizeJumlaSystemSettings === 'function') normalizeJumlaSystemSettings();
                var jumlaOn = !!(db.settings && (db.settings.enableTakeaway === true || db.settings.takeawayAsWholesale === true));
                if (typeof syncJumlaSystemSettings === 'function') syncJumlaSystemSettings(jumlaOn);
                else {
                    document.getElementById('set-enable-takeaway').checked = jumlaOn;
                    if (document.getElementById('set-takeaway-as-wholesale')) {
                        document.getElementById('set-takeaway-as-wholesale').checked = !!(db.settings && db.settings.takeawayAsWholesale);
                    }
                }
                if (typeof updateJumlaModeSelectorUI === 'function') updateJumlaModeSelectorUI();
                document.getElementById('set-use-barcode').checked = (db.settings.useBarcode !== false);
                var pibEl = document.getElementById('set-print-invoice-barcode');
                if (pibEl) pibEl.checked = (db.settings.printInvoiceBarcode !== false);
                document.getElementById('set-enable-debt').checked = (db.settings.enableDebt === true);
                document.getElementById('set-show-tables').checked = (db.settings.showTables === true);
                document.getElementById('set-show-customer-name').checked = (db.settings.showCustomerName !== false);
                var kitchenChk = document.getElementById('set-enable-kitchen');
                if (kitchenChk) kitchenChk.checked = (db.settings.enableKitchen !== false);
                document.getElementById('set-show-note-icon').checked = (db.settings.showItemNoteIcon === true);
                if (typeof applyKitchenVisibility === 'function') applyKitchenVisibility();
                document.getElementById('set-enable-waste').checked = (db.settings.enableWaste !== false);
                var recipeChk = document.getElementById('set-enable-recipe');
                if (recipeChk) recipeChk.checked = (typeof isSettingTruthy === 'function') ? isSettingTruthy(db.settings.enableRecipe) : (db.settings.enableRecipe === true);
                document.getElementById('set-enable-gift').checked = (db.settings.enableGift === true);
                document.getElementById('set-enable-wholesale').checked = (db.settings.enableWholesale === true);
                var roundingChk = document.getElementById('set-enable-money-rounding');
                if (roundingChk) {
                    roundingChk.checked = (typeof isPremiumSettingsFeatureEnabled === 'function')
                        && isPremiumSettingsFeatureEnabled('set-enable-money-rounding');
                }
                document.getElementById('set-enable-manual-price').checked = (db.settings.enableManualPrice === true);
                var elManualSale = document.getElementById('set-enable-manual-sale');
                if (elManualSale) elManualSale.checked = (db.settings.enableManualSale === true);
                var elSortOutOfStockBottom = document.getElementById('set-sort-out-of-stock-bottom');
                if (elSortOutOfStockBottom) elSortOutOfStockBottom.checked = (db.settings.sortOutOfStockToBottom === true);
                var elUnlockStaffBeyond = document.getElementById('set-unlock-staff-beyond-five');
                if (elUnlockStaffBeyond) elUnlockStaffBeyond.checked = (db.settings.unlockStaffBeyondFive === true);
                document.getElementById('set-show-return-button').checked = (db.settings.showReturnButton !== false);
                var showStockPosEl = document.getElementById('set-show-stock-on-pos');
                if (showStockPosEl) {
                    showStockPosEl.checked = (db.settings.showStockOnPos !== false && db.settings.showStockOnPos !== 'false' && db.settings.showStockOnPos !== 0);
                }

                document.getElementById('set-show-payment-modal').checked = (db.settings.showPaymentModal === true);
                var openingPromptChk = document.getElementById('set-require-opening-balance-prompt');
                if (openingPromptChk) {
                    var openingUnlocked = (typeof isPremiumFeatureUnlocked === 'function')
                        && isPremiumFeatureUnlocked('set-require-opening-balance-prompt');
                    openingPromptChk.checked = openingUnlocked
                        && !(db.settings.requireOpeningBalancePrompt === false || db.settings.requireOpeningBalancePrompt === 0);
                }
                var endShiftPromptChk = document.getElementById('set-require-end-shift-reconcile-prompt');
                if (endShiftPromptChk) {
                    var endShiftUnlocked = (typeof isPremiumFeatureUnlocked === 'function')
                        && isPremiumFeatureUnlocked('set-require-end-shift-reconcile-prompt');
                    endShiftPromptChk.checked = endShiftUnlocked
                        && !(db.settings.requireEndShiftReconcilePrompt === false || db.settings.requireEndShiftReconcilePrompt === 0);
                }
                var elW = document.getElementById('set-enable-warehouse'); if (elW) elW.checked = (db.settings.enableWarehouse !== false);
                var elC = document.getElementById('set-enable-companies'); if (elC) elC.checked = (db.settings.enableCompanies !== false);
                var elP = document.getElementById('set-enable-purchase'); if (elP) elP.checked = (db.settings.enablePurchase !== false);
                var elR = document.getElementById('set-enable-reports'); if (elR) elR.checked = (db.settings.enableReports !== false);
                var elD = document.getElementById('set-enable-delivery');
                if (elD) {
                    elD.checked = (typeof isPremiumSettingsFeatureEnabled === 'function')
                        && isPremiumSettingsFeatureEnabled('set-enable-delivery');
                }
                var elMultiWh = document.getElementById('set-enable-multi-warehouse');
                if (elMultiWh) {
                    elMultiWh.checked = (typeof isPremiumSettingsFeatureEnabled === 'function')
                        && isPremiumSettingsFeatureEnabled('set-enable-multi-warehouse');
                }
                var elPurchaseBatch = document.getElementById('premium-purchase-batch');
                if (elPurchaseBatch) {
                    elPurchaseBatch.checked = (typeof isPremiumSettingsFeatureEnabled === 'function')
                        && isPremiumSettingsFeatureEnabled('premium-purchase-batch');
                }
                var elMfrSlot = document.getElementById('premium-mfr-slot');
                if (elMfrSlot) {
                    if (typeof hasPremiumEntitlement === 'function' && hasPremiumEntitlement()
                        && (db.settings.manufacturerSlot === undefined || db.settings.manufacturerSlot === null)) {
                        db.settings.manufacturerSlot = true;
                    }
                    elMfrSlot.checked = (typeof isPremiumSettingsFeatureEnabled === 'function')
                        && isPremiumSettingsFeatureEnabled('premium-mfr-slot');
                }
                var elTechSpecs = document.getElementById('premium-tech-specs');
                if (elTechSpecs) {
                    elTechSpecs.checked = (typeof isPremiumSettingsFeatureEnabled === 'function')
                        && isPremiumSettingsFeatureEnabled('premium-tech-specs');
                }
                var elSaleFollowup = document.getElementById('premium-sale-followup');
                if (elSaleFollowup) {
                    elSaleFollowup.checked = (typeof isPremiumSettingsFeatureEnabled === 'function')
                        && isPremiumSettingsFeatureEnabled('premium-sale-followup');
                }
                var elE = document.getElementById('set-enable-expenses'); if (elE) elE.checked = (db.settings.enableExpenses !== false);
                var elCal = document.getElementById('set-enable-calendar'); if (elCal) elCal.checked = (db.settings.enableCalendar !== false);
                var elN = document.getElementById('set-enable-notifications'); if (elN) elN.checked = (db.settings.enableNotifications !== false);
                if (typeof loadSaleFollowupSettingsUi === 'function') loadSaleFollowupSettingsUi();
                var elHideWhWarn = document.getElementById('set-hide-warehouse-stock-warn'); if (elHideWhWarn) elHideWhWarn.checked = (db.settings.hideWarehouseStockWarn === true || db.settings.hideWarehouseStockWarn === 'true' || db.settings.hideWarehouseStockWarn === 1);
                if (typeof syncProductStockQtyLockForForm === 'function') syncProductStockQtyLockForForm();
                var elSt = document.getElementById('set-enable-staff'); if (elSt) elSt.checked = (db.settings.enableStaff !== false);
                var elMC = document.getElementById('set-enable-multi-cart'); if (elMC) elMC.checked = (db.settings.enableMultiCartTabs !== false);
                var elNegStock = document.getElementById('set-allow-negative-stock'); if (elNegStock) elNegStock.checked = (db.settings.allowNegativeStock === true);
                ensureValidCurrencyMode();
                const mode = (String(db.settings.currencyMode || 'IQD').toUpperCase() === 'USD') ? 'USD' : 'IQD';
                const iqdRadio = document.getElementById('set-currency-iqd');
                const usdRadio = document.getElementById('set-currency-usd');
                if (iqdRadio) iqdRadio.checked = (mode === 'IQD');
                if (usdRadio) usdRadio.checked = (mode === 'USD');
                const rateInput = document.getElementById('set-exchange-rate');
                if (rateInput) rateInput.value = Math.round(db.settings.usdRate || 150000);
                if (typeof updateCurrencyLockUI === 'function') updateCurrencyLockUI();

                if (typeof applyGraphicsQuality === 'function') {
                    applyGraphicsQuality(db.settings.graphicsQuality || 'low');
                } else if (typeof initGraphicsQualityFromStorage === 'function') {
                    initGraphicsQualityFromStorage();
                }
                
                toggleTakeawaySettings();
                toggleBarcodeUI();
                toggleDebtSettings();
                toggleTablesUI();
                toggleCustomerNameUI();
                toggleWasteSettings();
                toggleRecipeSettings();
                toggleWholesaleSettings();
                
                updateToggleCards(); // Update visual state of toggles
                if (typeof applyFeatureVisibility === 'function') applyFeatureVisibility();
                if (typeof window.syncPaymentToggles === 'function') window.syncPaymentToggles();
                // Apply Return Button Visibility
                const retBtn = document.getElementById('pos-return-btn-wrapper');
                if(retBtn) retBtn.style.display = (db.settings.showReturnButton !== false) ? 'flex' : 'none';
                if (typeof applyManualSaleVisibility === 'function') applyManualSaleVisibility();

                // Apply Telegram Settings
                if(document.getElementById('tg-bot-token')) document.getElementById('tg-bot-token').value = db.settings.tgToken || "";
                if(document.getElementById('tg-chat-id')) document.getElementById('tg-chat-id').value = db.settings.tgChatId || "";
                
                // New Telegram Shift Settings
                var tgShiftStart = document.getElementById('set-tg-shift-start-report');
                if (tgShiftStart) tgShiftStart.checked = (db.settings.tg_shift_start_report !== false);
                var tgShiftEnd = document.getElementById('set-tg-shift-end-report');
                if (tgShiftEnd) tgShiftEnd.checked = (db.settings.tg_shift_end_report !== false);
                var tgIncludeCash = document.getElementById('set-tg-include-cash-in-drawer');
                if (tgIncludeCash) tgIncludeCash.checked = (db.settings.tg_include_cash_in_drawer !== false);
                var tgReportType = document.getElementById('set-tg-report-type');
                if (tgReportType) tgReportType.value = db.settings.tg_report_type || 'full';

                var showFinA4 = document.getElementById('set-show-financial-summary-on-a4');
                if (showFinA4) showFinA4.checked = (db.settings.showFinancialSummaryOnA4 !== false);
                var showBothCurA4 = document.getElementById('set-show-both-currencies-on-a4');
                if (showBothCurA4) showBothCurA4.checked = (db.settings.showBothCurrenciesOnA4 === true);
                var showBothCurUi = document.getElementById('set-show-both-currencies');
                if (showBothCurUi) showBothCurUi.checked = (db.settings.showBothCurrencies !== false);

                if (typeof applyProductFormFieldLabels === 'function') applyProductFormFieldLabels();

                var bdHr = document.getElementById('set-business-day-start-hour');
                if (bdHr && db.settings) {
                    bdHr.value = db.settings.businessDayStartHour !== undefined ? db.settings.businessDayStartHour : 0;
                }
                if (typeof refreshBusinessDayStartHourControlState === 'function') refreshBusinessDayStartHourControlState();
                if (typeof applyPremiumSettingsUI === 'function') applyPremiumSettingsUI();
            } 
        }

        /** ناونیشانەکانی فۆرمی کاڵا (تنبيه كمية / تاريخ) لە db.settings — هاتنە حفظ لە MySQL */
        function applyProductFormFieldLabels() {
            if (!db || !db.settings) return;
            var defMin = (typeof t === 'function') ? t('product_form_label_min_stock_default') : 'حد تنبيه الكمية';
            var defEx = (typeof t === 'function') ? t('product_form_label_expiry_alert_default') : 'تنبيه قبل انتهاء الصلاحية (يوم)';
            var sMin = db.settings.labelProductMinStockAlert;
            var sEx = db.settings.labelProductExpiryAlertDays;
            var textMin = (sMin != null && String(sMin).trim() !== '') ? String(sMin).trim() : defMin;
            var textEx = (sEx != null && String(sEx).trim() !== '') ? String(sEx).trim() : defEx;
            var spanMin = document.getElementById('span-p-min-stock-label');
            var spanEx = document.getElementById('span-p-expiry-alert-label');
            if (spanMin) spanMin.textContent = textMin;
            if (spanEx) spanEx.textContent = textEx;
            var inpSetMin = document.getElementById('set-label-min-stock-alert');
            var inpSetEx = document.getElementById('set-label-expiry-alert-days');
            if (inpSetMin) inpSetMin.value = textMin;
            if (inpSetEx) inpSetEx.value = textEx;
        }
        if (typeof window !== 'undefined') { window.applyProductFormFieldLabels = applyProductFormFieldLabels; }

        function toggleTablesUI() {
            const show = (db.settings.showTables === true);
            const navTables = document.querySelector('.nav-item[onclick="nav(\'tables\')"]');
            const navPos = document.getElementById('nav-pos');
            
            // Show/hide tables navigation
            if (navTables) {
                navTables.style.display = show ? 'flex' : 'none';
            }
            
            // POS button logic: always visible when tables are hidden, require table selection when tables are shown
            if (!show) {
                if (navPos) {
                    navPos.style.display = 'flex';
                    navPos.onclick = function(e) { openPosOptionsModal(e); };
                }
            } else {
                if (navPos) {
                    navPos.onclick = function(e) { openPosOptionsModal(e); };
                    // Only hide POS button if no active table when tables are enabled
                    if (!activeTableId) navPos.style.display = 'none';
                    else navPos.style.display = 'flex';
                }
            }
        }

        /** Ensure there is always an active cart/table for POS so add-to-cart never breaks (even when tables UI is hidden). */
        function ensureDefaultCart() {
            if (!db || !db.tables) return;
            if (activeTableId != null && db.tables.some(function(t) { return String(t.id) === String(activeTableId); })) {
                var activeTbl = db.tables.find(function(t) { return String(t.id) === String(activeTableId); });
                if (activeTbl && !Array.isArray(activeTbl.items)) activeTbl.items = [];
                return;
            }
            
            var t = db.tables[0];
            if (!t) {
                // Default Cart System: Create appropriate cart name based on business mode
                var mode = (db.settings && db.settings.systemMode) ? db.settings.systemMode : 'general';
                var cartName = 'General Cart';
                
                if (mode === 'market') cartName = 'سەبەتا سەرەکی (Main Cart)';
                else if (mode === 'pharmacy') cartName = 'وەسڵا سەرەکی (Main Bill)';
                else if (mode === 'restaurant') cartName = 'مێزێ سەرەکی (Main Table)';
                else if (mode === 'cafe') cartName = 'مێزێ سەرەکی (Main Table)';
                else if (mode === 'company') cartName = 'داواکاریا سەرەکی (Main Order)';
                else if (mode === 'clinic') cartName = 'مراجعێ سەرەکی (Main Patient)';
                else if (mode === 'hotel') cartName = 'ژورێ سەرەکی (Main Room)';
                else if (mode === 'stationery') cartName = 'سەبەتا سەرەکی (Main Cart)';
                else if (mode === 'mobile') cartName = 'سەبەتا سەرەکی (Main Cart)';
                else if (mode === 'factory') cartName = 'بەچا سەرەکی (Main Batch)';
                else if (mode === 'jewelry') cartName = 'سەبەتا سەرەکی (Main Cart)';
                
                db.tables.push({ id: 1, name: cartName, items: [] });
                t = db.tables[0];
            }
            if (t && !Array.isArray(t.items)) t.items = [];
            activeTableId = (t.id != null && !isNaN(Number(t.id))) ? Number(t.id) : t.id;
        }
        window.ensureDefaultCart = ensureDefaultCart;
        function openDirectPOS(opts) {
            opts = opts || {};
            ensureDefaultCart();
            if (activeTableId) { 
                nav('pos'); 
                // Show Default Cart indicator if tables are hidden
                if (db.settings && db.settings.showTables !== true) {
                    showDefaultCartIndicator();
                }
                if (typeof window.updateTakeawayToggleUI === 'function') window.updateTakeawayToggleUI();
                applyPrintSettings();
                if (typeof updatePOSUnitButtons === 'function') updatePOSUnitButtons();
                renderBill();
                if (opts.markReady) finalizePosInit();
                return; 
            }
            // If still no active table, create and open default cart
            var t = db.tables[0];
            if (!t) {
                var mode = (db.settings && db.settings.systemMode) ? db.settings.systemMode : 'general';
                var cartName = 'Direct POS Cart';
                
                if (mode === 'market') cartName = 'سەبەتا فرۆتنێ (Sales Cart)';
                else if (mode === 'pharmacy') cartName = 'وەسڵا فرۆتنێ (Sales Bill)';
                else if (mode === 'restaurant') cartName = 'مێزێ فرۆتنێ (Sales Table)';
                else if (mode === 'cafe') cartName = 'مێزێ فرۆتنێ (Sales Table)';
                else if (mode === 'company') cartName = 'داواکاریا فرۆتنێ (Sales Order)';
                else if (mode === 'clinic') cartName = 'مراجعێ فرۆتنێ (Sales Patient)';
                else if (mode === 'hotel') cartName = 'ژورێ فرۆتنێ (Sales Room)';
                else if (mode === 'stationery') cartName = 'سەبەتا فرۆتنێ (Sales Cart)';
                else if (mode === 'mobile') cartName = 'سەبەتا فرۆتنێ (Sales Cart)';
                else if (mode === 'factory') cartName = 'بەچا فرۆتنێ (Sales Batch)';
                else if (mode === 'jewelry') cartName = 'سەبەتا فرۆتنێ (Sales Cart)';
                
                db.tables.push({id: 1, name: cartName, items: []});
                t = db.tables[0];
            }
            openTable(t.id);
            // Show Default Cart indicator if tables are hidden
            if (db.settings && db.settings.showTables !== true) {
                showDefaultCartIndicator();
            }
        }

        // Show visual indicator for Default Cart mode
        function showDefaultCartIndicator() {
            const activeTableEl = document.getElementById('pos-active-table');
            if (activeTableEl) {
                const table = db.tables.find(t => t.id === activeTableId);
                if (table) {
                    activeTableEl.innerHTML = `🛒 ${table.name} <span style="font-size:0.8em; opacity:0.7;">(Default Cart)</span>`;
                }
            }
        }

        function toggleTakeawaySettings() {
            var el = document.getElementById('set-enable-takeaway');
            var checked = !!(el && el.checked);
            if (typeof syncJumlaSystemSettings === 'function') syncJumlaSystemSettings(checked);
            else if (db && db.settings) {
                db.settings.enableTakeaway = checked;
                if (!checked) db.settings.takeawayAsWholesale = false;
            }
            if (typeof updateJumlaModeSelectorUI === 'function') updateJumlaModeSelectorUI();
            if (typeof applyJumlaSystemGlobally === 'function') applyJumlaSystemGlobally();
            else {
                if (typeof applyProductFormPremiumFeatureFields === 'function') applyProductFormPremiumFeatureFields();
                if (typeof window.updateTakeawayToggleUI === 'function') window.updateTakeawayToggleUI();
                lastTableState = '';
                if (typeof renderTables === 'function') renderTables();
            }
        }

        function toggleTakeawayAsWholesale() {
            if (typeof syncJumlaSystemSettings === 'function') {
                syncJumlaSystemSettings(!!(db && db.settings && db.settings.enableTakeaway));
            }
            if (typeof applyProductFormPremiumFeatureFields === 'function') applyProductFormPremiumFeatureFields();
            if (typeof window.updateTakeawayToggleUI === 'function') window.updateTakeawayToggleUI();
        }

        function toggleBarcodeUI() {
            const enabled = document.getElementById('set-use-barcode').checked;
            
            // Product Form
            const pBar = document.getElementById('p-barcode');
            if(pBar) {
                pBar.style.display = enabled ? 'block' : 'none';
                if(pBar.previousElementSibling && pBar.previousElementSibling.tagName === 'LABEL') {
                    pBar.previousElementSibling.style.display = enabled ? 'block' : 'none';
                }
            }

            // POS
            const posBar = document.getElementById('pos-barcode-input');
            if(posBar) posBar.style.display = enabled ? 'block' : 'none';
            const posExpandBar = document.getElementById('pos-expand-search-input');
            if(posExpandBar) posExpandBar.style.display = enabled ? 'block' : 'none';

            // Supply
            const supBar = document.getElementById('supply-barcode');
            if(supBar && supBar.parentElement) supBar.parentElement.style.display = enabled ? 'block' : 'none';
        }

        function applyManualSaleVisibility() {
            var elChk = document.getElementById('set-enable-manual-sale');
            var enabled = (typeof isPremiumSettingsFeatureEnabled === 'function')
                ? isPremiumSettingsFeatureEnabled('set-enable-manual-sale')
                : (elChk ? elChk.checked : (db && db.settings && db.settings.enableManualSale === true));
            var btn = document.getElementById('btn-pos-manual-sale');
            if (btn) btn.style.display = enabled ? '' : 'none';
            if (!enabled && typeof closeManualItemModal === 'function') closeManualItemModal();
        }
        if (typeof window !== 'undefined') window.applyManualSaleVisibility = applyManualSaleVisibility;

