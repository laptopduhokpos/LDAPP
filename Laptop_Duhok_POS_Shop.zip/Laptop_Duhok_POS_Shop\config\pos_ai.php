<?php
/**
 * Shop AI assistant — Gemini API (production / paid-tier ready).
 * API key: config/pos_ai_local.php (POS_GEMINI_API_KEY) or env — NEVER sent to browser.
 * Model: pos_ai_local.php or env POS_GEMINI_MODEL (default gemini-2.5-flash).
 */

$__pos_ai_local = __DIR__ . '/pos_ai_local.php';
if (is_file($__pos_ai_local)) {
    require_once $__pos_ai_local;
}
require_once __DIR__ . '/pos_ai_limits.php';
if (is_file(__DIR__ . '/pos_ai_supabase.php')) {
    require_once __DIR__ . '/pos_ai_supabase.php';
}

if (!function_exists('pos_ai_purge_secrets_from_db')) {
    /** Remove legacy API keys that were saved in app_settings before server-only config. */
    function pos_ai_purge_secrets_from_db(mysqli $conn): void {
        $s = pos_ai_load_settings_row($conn);
        if (empty($s['geminiApiKey']) && empty($s['geminiModel'])) return;
        unset($s['geminiApiKey'], $s['geminiModel']);
        $json = json_encode($s, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
        if ($json === false) return;
        $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('app_settings', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        if ($stmt) {
            $stmt->bind_param('ss', $json, $json);
            $stmt->execute();
        }
    }
}

if (!function_exists('pos_ai_sanitize_settings_for_client')) {
    /** Strip server-only secrets before settings JSON goes to the SPA. */
    function pos_ai_sanitize_settings_for_client(array $settings): array {
        unset($settings['geminiApiKey'], $settings['geminiModel']);
        return $settings;
    }
}

if (!function_exists('pos_ai_allowed_models')) {
    /** @return array<string,string> id => label */
    function pos_ai_allowed_models(): array {
        return [
            'gemini-2.5-flash' => 'Gemini 2.5 Flash (پێشنیار — باش + جێگیر)',
            'gemini-2.5-flash-lite' => 'Gemini 2.5 Flash-Lite (زۆر پرسیار — هەرزانتر)',
            'gemini-2.5-pro' => 'Gemini 2.5 Pro (باشترین وەڵام — گرانتر)',
        ];
    }
}

if (!function_exists('pos_ai_normalize_model')) {
    function pos_ai_normalize_model(string $model): string {
        $m = trim($model);
        $allowed = array_keys(pos_ai_allowed_models());
        // Deprecated models → current GA equivalents
        $legacy = [
            'gemini-2.0-flash' => 'gemini-2.5-flash',
            'gemini-2.0-flash-lite' => 'gemini-2.5-flash-lite',
            'gemini-1.5-flash' => 'gemini-2.5-flash',
            'gemini-1.5-pro' => 'gemini-2.5-pro',
        ];
        if (isset($legacy[$m])) $m = $legacy[$m];
        return in_array($m, $allowed, true) ? $m : 'gemini-2.5-flash';
    }
}

if (!function_exists('pos_ai_load_settings_row')) {
    function pos_ai_load_settings_row(mysqli $conn): array {
        $res = $conn->query("SELECT setting_value FROM settings WHERE setting_key = 'app_settings' LIMIT 1");
        if ($res && ($row = $res->fetch_assoc())) {
            $s = json_decode($row['setting_value'] ?? '', true);
            if (is_array($s)) return $s;
        }
        return [];
    }
}

if (!function_exists('pos_ai_vendor_gemini_allowed')) {
    /** Vendor Gemini when AI enabled — monthly cap enforced by quota (Basic 150 / Pro 300 per 30 days). */
    function pos_ai_vendor_gemini_allowed(mysqli $conn): bool {
        $q = function_exists('pos_ai_supabase_quota_raw') ? pos_ai_supabase_quota_raw($conn) : null;
        if (is_array($q)) {
            if (isset($q['ai_enabled']) && empty($q['ai_enabled'])) {
                return false;
            }
            return !empty($q['vendor_gemini']);
        }
        return true;
    }
}

if (!function_exists('pos_ai_resolve_api_key')) {
    function pos_ai_resolve_api_key(mysqli $conn): string {
        if (!pos_ai_vendor_gemini_allowed($conn)) {
            return '';
        }
        if (defined('POS_GEMINI_API_KEY')) {
            $key = trim((string)POS_GEMINI_API_KEY);
            if ($key !== '') return $key;
        }
        if (!empty($_ENV['POS_GEMINI_API_KEY'])) {
            $key = trim((string)$_ENV['POS_GEMINI_API_KEY']);
            if ($key !== '') return $key;
        }
        if (getenv('POS_GEMINI_API_KEY')) {
            $key = trim((string)getenv('POS_GEMINI_API_KEY'));
            if ($key !== '') return $key;
        }
        return '';
    }
}

if (!function_exists('pos_ai_resolve_model')) {
    function pos_ai_resolve_model(mysqli $conn): string {
        if (defined('POS_GEMINI_MODEL')) {
            $m = trim((string)POS_GEMINI_MODEL);
            if ($m !== '') return pos_ai_normalize_model($m);
        }
        if (!empty($_ENV['POS_GEMINI_MODEL'])) {
            $m = trim((string)$_ENV['POS_GEMINI_MODEL']);
            if ($m !== '') return pos_ai_normalize_model($m);
        }
        if (getenv('POS_GEMINI_MODEL')) {
            $m = trim((string)getenv('POS_GEMINI_MODEL'));
            if ($m !== '') return pos_ai_normalize_model($m);
        }
        return 'gemini-2.5-flash';
    }
}

if (!function_exists('pos_ai_model_fallback_chain')) {
    /** @return string[] */
    function pos_ai_model_fallback_chain(string $primary): array {
        $primary = pos_ai_normalize_model($primary);
        $chain = [$primary];
        $extras = ['gemini-2.5-flash', 'gemini-2.5-flash-lite', 'gemini-2.5-pro'];
        foreach ($extras as $m) {
            if (!in_array($m, $chain, true)) $chain[] = $m;
        }
        return $chain;
    }
}

if (!function_exists('pos_ai_call_gemini_once')) {
    /**
     * @param array<int,array{role:string,text:string}> $turns
     * @return array{ok:bool, text?:string, error?:string, http?:int, model?:string}
     */
    function pos_ai_call_gemini_once(string $apiKey, string $model, string $systemPrompt, array $turns, string $userQuestion): array {
        if ($apiKey === '') {
            return ['ok' => false, 'error' => 'no_api_key', 'http' => 0];
        }
        $model = pos_ai_normalize_model($model);
        $contents = [];
        foreach ($turns as $t) {
            $role = ($t['role'] ?? '') === 'assistant' ? 'model' : 'user';
            $text = trim((string)($t['text'] ?? ''));
            if ($text === '') continue;
            $contents[] = ['role' => $role, 'parts' => [['text' => $text]]];
        }
        $contents[] = ['role' => 'user', 'parts' => [['text' => $userQuestion]]];

        $payload = [
            'system_instruction' => ['parts' => [['text' => $systemPrompt]]],
            'contents' => $contents,
            'generationConfig' => [
                'temperature' => 0.3,
                'maxOutputTokens' => 3072,
            ],
        ];

        $url = 'https://generativelanguage.googleapis.com/v1beta/models/'
            . rawurlencode($model) . ':generateContent?key=' . rawurlencode($apiKey);

        $ch = curl_init($url);
        if ($ch === false) {
            return ['ok' => false, 'error' => 'curl_init_failed', 'http' => 0, 'model' => $model];
        }
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 120,
            CURLOPT_CONNECTTIMEOUT => 20,
        ]);
        $raw = curl_exec($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $cerr = curl_error($ch);
        curl_close($ch);

        if ($raw === false || $cerr !== '') {
            return ['ok' => false, 'error' => 'network: ' . ($cerr ?: 'empty response'), 'http' => $http, 'model' => $model];
        }
        $data = json_decode($raw, true);
        if ($http >= 400 || !is_array($data)) {
            $msg = is_array($data) && isset($data['error']['message']) ? (string)$data['error']['message'] : ('HTTP ' . $http);
            return ['ok' => false, 'error' => $msg, 'http' => $http, 'model' => $model];
        }
        $text = '';
        if (!empty($data['candidates'][0]['content']['parts'])) {
            foreach ($data['candidates'][0]['content']['parts'] as $part) {
                if (!empty($part['text'])) $text .= (string)$part['text'];
            }
        }
        $text = trim($text);
        if ($text === '') {
            $block = $data['candidates'][0]['finishReason'] ?? '';
            return ['ok' => false, 'error' => 'empty_model_response' . ($block ? " ($block)" : ''), 'http' => $http, 'model' => $model];
        }
        return ['ok' => true, 'text' => $text, 'http' => $http, 'model' => $model];
    }
}

if (!function_exists('pos_ai_call_gemini')) {
    /**
     * Retry on rate-limit (429), fallback on model-not-found (404).
     *
     * @param array<int,array{role:string,text:string}> $turns
     * @return array{ok:bool, text?:string, error?:string, model?:string}
     */
    function pos_ai_call_gemini(string $apiKey, string $systemPrompt, array $turns, string $userQuestion, ?string $preferredModel = null): array {
        $primary = $preferredModel ? pos_ai_normalize_model($preferredModel) : 'gemini-2.5-flash';
        $chain = pos_ai_model_fallback_chain($primary);
        $lastErr = 'unknown';
        $lastHttp = 0;

        foreach ($chain as $model) {
            $attempts = ($model === $primary) ? 3 : 1;
            for ($try = 0; $try < $attempts; $try++) {
                $res = pos_ai_call_gemini_once($apiKey, $model, $systemPrompt, $turns, $userQuestion);
                if (!empty($res['ok'])) {
                    return ['ok' => true, 'text' => $res['text'], 'model' => $res['model'] ?? $model];
                }
                $lastErr = (string)($res['error'] ?? 'unknown');
                $lastHttp = (int)($res['http'] ?? 0);

                // Rate limit — wait and retry same model
                if ($lastHttp === 429 && $try < $attempts - 1) {
                    usleep(1500000 * ($try + 1)); // 1.5s, 3s
                    continue;
                }
                // Model missing / deprecated — try next in chain
                if ($lastHttp === 404 || stripos($lastErr, 'not found') !== false || stripos($lastErr, 'not supported') !== false) {
                    break;
                }
                // Quota / billing — don't spam fallbacks
                if ($lastHttp === 403 || stripos($lastErr, 'quota') !== false || stripos($lastErr, 'billing') !== false) {
                    return [
                        'ok' => false,
                        'error' => pos_ai_friendly_error($lastErr, $lastHttp),
                        'model' => $model,
                    ];
                }
                // Other errors on primary — one retry then fallback
                if ($try < $attempts - 1) {
                    usleep(800000);
                    continue;
                }
                break;
            }
        }

        return [
            'ok' => false,
            'error' => pos_ai_friendly_error($lastErr, $lastHttp),
            'model' => $primary,
        ];
    }
}

if (!function_exists('pos_ai_friendly_error')) {
    function pos_ai_friendly_error(string $raw, int $http): string {
        $raw = trim($raw);
        if ($http === 429 || stripos($raw, 'quota') !== false || stripos($raw, 'rate') !== false) {
            return 'سنوورێ داواکاریێ گەهشت — چەند چرکە چاوەڕێ بکە یان لە Google AI Studio billing چالاک بکە بۆ پرسیارێن زۆرتر.';
        }
        if ($http === 403 || stripos($raw, 'billing') !== false || stripos($raw, 'API key') !== false) {
            return 'کلیلێ API یان billing نادروستە. لە aistudio.google.com کلیلێ نوێ دروست بکە و «Set up billing» چالاک بکە.';
        }
        if ($http === 404 || stripos($raw, 'not found') !== false) {
            return 'مۆدێلێ AI بەردەست نینە. لە ڕێکخستنی AI مۆدێلێ بگۆڕە بۆ Gemini 2.5 Flash.';
        }
        return 'AI: ' . ($raw !== '' ? $raw : ('HTTP ' . $http));
    }
}

if (!function_exists('pos_ai_model_name')) {
    /** @deprecated use pos_ai_resolve_model */
    function pos_ai_model_name(): string {
        return 'gemini-2.5-flash';
    }
}

if (!function_exists('pos_ai_language_rules_block')) {
    function pos_ai_language_rules_block(array $ctx): string {
        $uiLang = (string)($ctx['language'] ?? 'badini');
        $question = trim((string)($ctx['user_question'] ?? ''));

        $badiniExamples = <<<'BD'
وشەی بادینی سادە بۆ وەڵام (نموونە): ئەڤرۆ، دوێنێ، کۆگە، قازانج، فرۆتن، مەزاختن، دابینکەر، کارمەند، مانگ، کاڵا، دکان، چەندە، بۆچی، کام.
BD;

        $inputUnderstanding = <<<'IN'
تێگەهشتن لە پرسیار (گرنگ — پێش وەڵامدان):
• کارمەند دەتوانێت بە **بادینی ڕۆژانە/سادە** بنووسێت — نەپێویستە بادینی فەرمی یان «پەتی» بێت.
• وشەی سۆرانی، هەورامی، کورمانجی، عەرەبی تێکەڵ، یان هەڵەی نووسین → **تێبگەهە و وەڵام بدە**؛ هەرگیز نەڵێ «بە بادینی ڕاست بنووسە».
• نموونەی وشەی جێگر کە هەمان مانایان هەیە (هەموویان قبووڵە لە پرسیاردا):
  ئەمڕۆ=ئەڤرۆ | کۆگا=کۆگە=مەخزەن | فرۆشتن=فرۆتن | قازانج=ڕبح=قازانج کردن
  چۆن=چاوا=چی جۆرە | زیاد=زێدە | کاڵا=ئایتم=مادە | کڕیار=کریار | پارە=دراو
  هەیە=هەنە=هەن | ناکەم=ناکەم | دەمێنێت=دەمێنێت | بۆچی=بۆ | چەند=چەندە
• ئەگەر پرسیار ناڕوون بێت → بەزانیاری داتا یان پرسیارێکی کورت ڕوون بکەرەوە، نەک ڕەتکردنەوە.
IN;

        return <<<LANG
═══ ڕێساکانی زمان (گرنگترین) ═══

{$inputUnderstanding}

A) زمانێ وەڵامێ = زمانێ پرسیارێ کارمەند:
   • پرسیار بە عەرەبی → وەڵام ١٠٠٪ بە عەرەبی سادە و ڕوون.
   • پرسیار بە ئینگلیزی → وەڵام بە ئینگلیزی سادە.
   • پرسیار بە تورکی → وەڵام بە تورکی سادە.
   • پرسیار بە کوردی (هەر شێوازێک) → وەڵام بە **بادینی سادە** (خوارەوە B).
   • هەر زمانێکی تر → هەمان زمان بەکاربهێنە.

B) وەڵام بە کوردی — **بادینی سادە و ڕوون** (نه بادینی پەتی/کتێبی):
   • وەک قسەکردن لەگەڵ خاوەن دکانێ لە دهۆک — ڕستە کورت، وشەی ئاسان، بێ ئاڵۆزی.
   • قەدەغە لە وەڵامدا: فەرهەنگی قورس، وشەی کۆنە نەزانراو، یان ڕستەی درێژی فەلسەفی.
   • لە وەڵامدا بادینی دهۆک/ماردین بەکاربهێنە — نە سۆرانی تەواو (نەبێ «ئەمڕۆ فرۆشرا» بە شێوەی سۆرانی).
   • {$badiniExamples}
   • ئەگەر دەتوانیت بە یەک وشەی سادەتر بڵێیت — بەکاریبهێنە (نموونە: «کەمە» نەک «کەمبوونەوەیەک هەیە»).

C) زمانێ ڕێکخستنا سیستەم (UI): «{$uiLang}»
   • پرسیار کوردی/نادیار + UI=badini → بادینی سادە.
   • پرسیار کوردی/نادیار + UI=ar → عەرەبی سادە.

D) هەرگیز وەڵام بە دوو زمان تێکەڵ مەکە (مەگەر ناوی کاڵا/ژمارە).

E) هەرگیز ڕەخنە لە شێوازی قسەکردنی کارمەند مەگرە — تەنها یارمەتی بدە.

پرسیارێ ئێستا کارمەند (بۆ تێگەهشتن و دیاریکردنی زمان):
«{$question}»
LANG;
    }
}

if (!function_exists('pos_ai_detect_question_intent')) {
    /**
     * Heuristic hint for training vs shop-data questions (model still decides).
     * @return 'training'|'shop_data'|'mixed'|'unknown'
     */
    function pos_ai_detect_question_intent(string $question): string {
        $q = mb_strtolower(trim($question));
        if ($q === '') {
            return 'unknown';
        }
        $training = 0;
        $data = 0;
        $trainingNeedles = [
            'چۆن', 'چاوا', 'دێ چەوا', 'چەوان', 'فێر', 'ل کوێ', 'لە کوێ', 'زیاد کە', 'زێدە کە',
            'ڕێک بخ', 'تۆمار کە', 'دانم', 'بکەم', 'بکە', 'کردن', 'کلیک', 'کردم', 'چی بکەم',
            'how to', 'where', 'setup', 'لۆگۆ', 'png', 'پرینتەر', 'ڕێکخستن', 'مۆڵەت', 'فێرکردن',
        ];
        $dataNeedles = [
            'چەند', 'چەندە', 'قازانج', 'مفا', 'ڕبح', 'فرۆشتن', 'فرۆتن', 'کۆگە', 'کۆگا', 'کەم',
            'زۆرترین', 'کەمترین', 'بەراورد', 'کارمەند', 'مەزاختن', 'قەرز', 'ئەڤرۆ', 'ئەمڕۆ',
            'دوێنێ', 'مانگ', 'کام', 'بۆچی', 'چر', 'دابینکەر', 'کڕیار', 'تەلەف', 'ڕاپۆرت', 'ئامار',
            'قاسە', 'قاست', 'پارە ل', 'پارێ قاس', 'پارە د قاس', 'cash drawer', 'till',
            'کۆمپانیا', 'دابینکەر', 'جەردە', 'تۆمار', 'کڕیار', 'ئایتم', 'کاڵا',
            'profit', 'sales', 'stock', 'july', 'یولای', 'تەمموز',
        ];
        foreach ($trainingNeedles as $needle) {
            if (mb_strpos($q, mb_strtolower($needle)) !== false) {
                $training++;
            }
        }
        foreach ($dataNeedles as $needle) {
            if (mb_strpos($q, mb_strtolower($needle)) !== false) {
                $data++;
            }
        }
        if ($training > 0 && $data > 0) {
            return 'mixed';
        }
        if ($training > 0) {
            return 'training';
        }
        if ($data > 0) {
            return 'shop_data';
        }
        return 'unknown';
    }
}

if (!function_exists('pos_ai_intent_rules_block')) {
    function pos_ai_intent_rules_block(array $ctx): string {
        $intent = (string)($ctx['question_intent'] ?? 'unknown');
        $hintLine = match ($intent) {
            'training' => 'ئاماژەی سێرڤەر: ئەڤ پرسیارە زۆرتر **فێرکردنا سیستەم** وایە (چۆنێتی).',
            'shop_data' => 'ئاماژەی سێرڤەر: ئەڤ پرسیارە زۆرتر **داتای دکان/کاشێر** وایە (ژمارە/ئامار).',
            'mixed' => 'ئاماژەی سێرڤەر: ئەڤ پرسیارە **تێکەڵ** وایە — فێرکردن + داتا؛ دوو بەش جیا بکە.',
            default => 'ئاماژەی سێرڤەر: جۆرەکە لە دەقێ پرسیارێ خۆت دەستنیشان بکە.',
        };

        return <<<INTENT
═══ جیاکردنەوەی جۆری پرسیار (زۆر گرنگ — هەر وەڵامێک) ═══

{$hintLine}

**پێش وەڵامدان** لە مێشکتدا جۆرەکە دیاری بکە و لە دەستپێکی وەڵام **نیشانەی جۆر** بنووسە:

📚 **فێرکردنا سیستەم** — پرسیار دەربارەی «چۆن / چاوا / دێ چەوا / لە کوێ بچم / چی بکەم»:
   • نموونە: چۆن ئایتم زیاد بکەم؟ چۆن لۆگۆ دابنێم؟ چۆن پرینتەر ڕێک بخەم؟
   • تەنها **ڕێنمای سیستەم** (help guide) — **مەگەڕێوە** بۆ JSON داتا بۆ ژمارە.
   • دەستپێکی وەڵام دەبێت بێت: «📚 **فێرکردنا سیستەم:**»

📊 **داتای دکان / کاشێر** — پرسیار دەربارەی ژمارە، ئامار، قازانج، فرۆشتن، کۆگە، کارمەند، قەرز...:
   • نموونە: ئەڤرۆ مفا چەندە؟ چ ئایتەمەک کەمن؟ کام کارمەند باشترە؟
   • تەنها **JSON داتای دکان** — **مەفێرکە** چۆنێتی سیستەم مەگەر پرسیارەکە ڕاستەوخۆ بپرسێت.
   • دەستپێکی وەڵام دەبێت بێت: «📊 **داتای دکان:**»

**تێکەڵ** (هەردوو لە یەک پرسیاردا):
   • وەڵام بە **دوو بەشی جیا**:
     📚 فێرکردنا سیستەم: ...
     📊 داتای دکان: ...

**ناڕوون**:
   • یەک پرسیاری کورت بکەوە: «ئایا دەتەوێت فێرکردنا سیستەم (چۆن) یان داتای دکان (چەند/کام)?»

**قەدەغە:**
   • فێرکردن وەڵام مەدە بە ژمارەی داتا کە لە JSON نییە.
   • داتای دکان وەڵام مەدە بە هەنگاوی فێرکردن مەگەر تەنها بۆ ڕوونکردنەوەی ژمارەیەک بێت.
INTENT;
    }
}

if (!function_exists('pos_ai_normalize_question_digits')) {
    function pos_ai_normalize_question_digits(string $q): string {
        static $eastern = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
        static $western = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
        return str_replace($eastern, $western, $q);
    }
}

if (!function_exists('pos_ai_resolve_question_timeframe')) {
    /**
     * Parse colloquial Kurdish/Arabic/English relative dates from a shop question.
     * @return array{kind:string,date?:string,from?:string,to?:string,days?:int}|null
     */
    function pos_ai_resolve_question_timeframe(string $question): ?array {
        $q = mb_strtolower(pos_ai_normalize_question_digits(trim($question)));
        if ($q === '') {
            return null;
        }

        // Single calendar day: N days ago
        $agoPatterns = [
            '/(?:بەری|پێش|beri|peş|pêş|قبل|before)\s*(\d{1,3})\s*(?:ڕۆژان?|roj(?:an)?|day?s?|أ?يام?)/u',
            '/(\d{1,3})\s*(?:ڕۆژان?|roj(?:an)?|day?s?|أ?يام?)\s*(?:پێش|pêş|peş|ago|قبل|before)/u',
        ];
        foreach ($agoPatterns as $pat) {
            if (preg_match($pat, $q, $m)) {
                $n = (int)$m[1];
                if ($n >= 0 && $n <= 730) {
                    return [
                        'kind' => 'day',
                        'date' => date('Y-m-d', strtotime('-' . $n . ' days')),
                        'days_ago' => $n,
                    ];
                }
            }
        }

        // Range: last N days (including today)
        $rangePatterns = [
            '/(?:دوایین|دوماهی|last|آخر|اخر)\s*(\d{1,3})\s*(?:ڕۆژان?|roj(?:an)?|day?s?|أ?يام?)/u',
            '/(\d{1,3})\s*(?:ڕۆژان?|roj(?:an)?|day?s?|أ?يام?)\s*(?:دوایین|دوماهی|last|اخر|آخر)/u',
        ];
        foreach ($rangePatterns as $pat) {
            if (preg_match($pat, $q, $m)) {
                $n = (int)$m[1];
                if ($n >= 1 && $n <= 90) {
                    return [
                        'kind' => 'range',
                        'days' => $n,
                        'from' => date('Y-m-d', strtotime('-' . ($n - 1) . ' days')),
                        'to' => date('Y-m-d'),
                    ];
                }
            }
        }

        return null;
    }
}

if (!function_exists('pos_ai_attach_question_timeframe')) {
    /** @param array<string,mixed> $data */
    function pos_ai_attach_question_timeframe(mysqli $conn, array &$data, string $question, bool $canProfit, bool $canExpenses): void {
        $frame = pos_ai_resolve_question_timeframe($question);
        if (!$frame) {
            return;
        }

        if ($frame['kind'] === 'day' && !empty($frame['date'])) {
            $dateYmd = (string)$frame['date'];
            [$qFrom, $qTo] = pos_ai_business_day_bounds($conn, $dateYmd);
            $data['question_day'] = array_merge(
                [
                    'date' => $dateYmd,
                    'days_ago' => (int)($frame['days_ago'] ?? 0),
                    'source' => 'mysql_full_history',
                ],
                pos_ai_period_financial_summary($conn, $qFrom, $qTo, $canProfit, $canExpenses)
            );
            $data['question_day']['sales_invoices'] = pos_ai_fetch_sale_invoices($conn, $qFrom, $qTo, 120);
            $data['question_day']['payment_breakdown'] = pos_ai_fetch_payment_breakdown($conn, $qFrom, $qTo);
            $data['question_day']['trade'] = pos_ai_fetch_period_trade_summary($conn, $qFrom, $qTo);
            return;
        }

        if ($frame['kind'] === 'range' && !empty($frame['from']) && !empty($frame['to'])) {
            $days = (int)($frame['days'] ?? 1);
            $fromYmd = (string)$frame['from'];
            $toYmd = (string)$frame['to'];
            [$rFrom, ] = pos_ai_business_day_bounds($conn, $fromYmd);
            [, $rTo] = pos_ai_business_day_bounds($conn, $toYmd);

            $period = [
                'kind' => 'range',
                'days' => $days,
                'from' => $fromYmd,
                'to' => $toYmd,
                'source' => 'mysql_full_history',
                'financial' => pos_ai_period_financial_summary($conn, $rFrom, $rTo, $canProfit, $canExpenses),
                'sales' => pos_ai_period_sales($conn, $rFrom, $rTo, $canProfit),
                'trade' => pos_ai_fetch_period_trade_summary($conn, $rFrom, $rTo),
                'payment_breakdown' => pos_ai_fetch_payment_breakdown($conn, $rFrom, $rTo),
                'sales_invoices' => pos_ai_fetch_sale_invoices($conn, $rFrom, $rTo, min(150, 40 + $days * 3)),
            ];

            $daily = [];
            if ($days <= 31) {
                for ($d = $days - 1; $d >= 0; $d--) {
                    $dayYmd = date('Y-m-d', strtotime('-' . $d . ' days'));
                    [$dFrom, $dTo] = pos_ai_business_day_bounds($conn, $dayYmd);
                    $dFin = pos_ai_period_financial_summary($conn, $dFrom, $dTo, $canProfit, $canExpenses);
                    $daily[] = [
                        'date' => $dayYmd,
                        'cash_drawer' => $dFin['cash_drawer'],
                        'sales_total' => $dFin['sales_total'],
                        'sales_invoices' => $dFin['sales_invoices'],
                        'net_profit' => $dFin['net_profit'],
                    ];
                }
            }
            $period['daily_breakdown'] = $daily;
            $data['question_period'] = $period;
        }
    }
}

if (!function_exists('pos_ai_parse_question_date')) {
    /** Try to extract Y-m-d from colloquial Kurdish/English date in the question. */
    function pos_ai_parse_question_date(string $question): ?string {
        $frame = pos_ai_resolve_question_timeframe($question);
        if ($frame && ($frame['kind'] ?? '') === 'day' && !empty($frame['date'])) {
            return (string)$frame['date'];
        }

        $q = mb_strtolower(pos_ai_normalize_question_digits(trim($question)));
        if ($q === '') {
            return null;
        }
        if (preg_match('/\b(20\d{2})-(\d{1,2})-(\d{1,2})\b/', $q, $m)) {
            return sprintf('%04d-%02d-%02d', (int)$m[1], (int)$m[2], (int)$m[3]);
        }
        if (preg_match('/\b(\d{1,2})[\/\.\-](\d{1,2})(?:[\/\.\-](20\d{2}))?\b/', $q, $m)) {
            $y = !empty($m[3]) ? (int)$m[3] : (int)date('Y');
            return sprintf('%04d-%02d-%02d', $y, (int)$m[2], (int)$m[1]);
        }
        $months = [
            'january' => 1, 'february' => 2, 'march' => 3, 'april' => 4, 'may' => 5, 'june' => 6,
            'july' => 7, 'august' => 8, 'september' => 9, 'october' => 10, 'november' => 11, 'december' => 12,
            'یولای' => 7, 'تەمموز' => 7, 'ئاب' => 8, 'ئەیلول' => 9, 'تشرینی یەکەم' => 10,
        ];
        foreach ($months as $name => $mon) {
            if (mb_strpos($q, $name) !== false && preg_match('/(\d{1,2})/', $q, $dm)) {
                $y = (int)date('Y');
                if (preg_match('/(20\d{2})/', $q, $ym)) {
                    $y = (int)$ym[1];
                }
                return sprintf('%04d-%02d-%02d', $y, $mon, (int)$dm[1]);
            }
        }
        if (mb_strpos($q, 'ئەڤرۆ') !== false || mb_strpos($q, 'ئەمڕۆ') !== false || mb_strpos($q, 'today') !== false) {
            return date('Y-m-d');
        }
        if (mb_strpos($q, 'دوێنێ') !== false || mb_strpos($q, 'yesterday') !== false) {
            return date('Y-m-d', strtotime('-1 day'));
        }
        return null;
    }
}

if (!function_exists('pos_ai_financial_terms_block')) {
    function pos_ai_financial_terms_block(): string {
        return <<<'TERMS'
═══ وشەنامەی دارایی (زۆر گرنگ — بۆ وەڵامی ڕاست) ═══

**قاسە / پارە ل قاسە / cash_drawer** = پارەی نەقد ل قاسێ دا (ل JSON: financial.cash_drawer یان recent_7_days).
   • فۆرمولا: opening_balance + cash_sales + وەرگرتنا قەرزی کریار + زڤڕاندنا کڕینێ − مەزاختن − کڕینا نەقد − دانەڤا قەرزی کۆمپانیا − زڤڕاندنا فرۆشتن
   • **ئەگەر پرسیار دەربارەی قاسە/پارە ل قاسەیە → تەنها cash_drawer بڵێ — مەگەڕێوە بۆ sales_total.**

**فرۆتنا گشتی / sales_total** = کۆی هەموو وەسڵ (نەقد + قەرز). بۆ «چەند فرۆشت» — **نە** بۆ قاسە.

**قازانجێ سافی / net_profit** = قازانجی کاڵا − مەزاختن. **جیا لە قاسە** — مەگەڕێوە بۆ cash_drawer کاتێ پرسیار قازانجە.

**بەروار:**
   • ئەڤرۆ = today · دوێنێ = yesterday
   • ئەگەر question_day لە JSON هەیە → ئەو بەروارە لە **MySQL** هاتووە — بەکاربهێنە (تەنها ٧ ڕۆژ سنوور نییە)
   • ئەگەر question_period لە JSON هەیە → کۆی ئەو ماوەیە لە **MySQL** — بەکاربهێنە
   • recent_7_days تەنها پوختەی خێرا بۆ ٧ ڕۆژە — بۆ بەروارێ تر question_day / question_period بەکاربهێنە
   • **مەبڵێ** «تەنها ٧ ڕۆژ داتا هەیە» ئەگەر question_day یان question_period بۆ ئەو بەروار/ماوەیە پڕکراوە

**وەڵام:**
   • کورت و ڕوون · ژمارە لە JSON · ئەگەر قاسە و فرۆشتن جیا بن → هەردووکیان بڵێ بە ناونیشانی جیا

**سەرچاوەکانی JSON (بابەتەکان):**
   • ئایتم/کۆگە → inventory, products_index, low_stock, top_sellers_month
   • کریار + قەرز → customers_index (تەواو), customers_registry, customer_ledger_recent, question_focus.matched_customers
   • کۆمپانیا/دابینکەر → companies_index, companies_registry, question_focus.matched_companies
   • وەسڵ/فرۆشتن → today.sales_invoices, yesterday.sales_invoices, recent_sales, question_focus.matched_receipts
   • تۆمارا پارە/قاسە → cash_ledger_recent, shifts, today/yesterday/recent_7_days.financial
   • کڕین/زڤڕاندن → today_trade, this_month.trade, recent_purchases, recent_returns
   • پرسیارێ تایبەت → **پێشەنگی question_focus** (ناو/وەسڵ لە پرسیار)
TERMS;
    }
}

if (!function_exists('pos_ai_accuracy_rules_block')) {
    function pos_ai_accuracy_rules_block(): string {
        return <<<'ACC'
═══ وردبینی و ڕاستی ژمارە (زۆر گرنگ) ═══

1. **تەنها JSON** — هەر ژمارەیەک دەبێت لە «داتای دکان (JSON)» بێت. **مەخەیتە، مەخەمڵێنە، مەگەڕێوە.**
2. **کۆکردنەوە** — دەتوانیت کۆی لیستەکان بکەیت (وەک کۆی customers_registry.totals) — بەڵام تەنها لە ژمارەکانی JSON.
3. **ئەگەر داتا نییە** — ڕاستەوخۆ بڵێ: «ل داتای ئێستادا نییە» — نە خەمڵاندن.
4. **جیاکردنەوە:**
   • کریار (customers) ≠ کۆمپانیا (companies)
   • قاسە (cash_drawer) ≠ فرۆشتن (sales_total) ≠ قازانج (net_profit)
   • کۆگە (inventory.qty) ≠ فرۆشتن
5. **بەروار** — today / yesterday / recent_7_days / **question_day** / **question_period** — بەرواری دروست هەڵبژێرە پێش وەڵام. بۆ «پێش N ڕۆژ» یان «دوایین N ڕۆژ» → question_day یان question_period.
6. **لیستە سنووردارەکان** — customers_index و products_index زۆربەی ناوەکان هەن؛ ئەگەر ناوی تایبەت لە پرسیارە → سەرەتا question_focus بپشکنە.
7. **question_focus** — ئەگەر matched_customers / matched_products / matched_receipts هەیە → ئەو داتایە بەکاربهێنە (وردترینە).
8. **وەڵامێ کورت و ژمارەیی** — سەرەتا ژمارەی سەرەکی، پاشان ١–٢ ڕستەی ڕوونکردنەوە.
ACC;
    }
}

if (!function_exists('pos_ai_system_prompt')) {
    function pos_ai_system_prompt(array $ctx): string {
        $shop = (string)($ctx['shop_name'] ?? 'دکان');
        $mode = (string)($ctx['business_mode'] ?? 'general');
        $canProfit = !empty($ctx['can_view_profit']);
        $langRules = pos_ai_language_rules_block($ctx);
        $intentRules = pos_ai_intent_rules_block($ctx);
        $financialTerms = pos_ai_financial_terms_block();
        $accuracyRules = pos_ai_accuracy_rules_block();
        $systemHelp = (string)($ctx['system_help'] ?? '');
        if ($systemHelp === '' && function_exists('pos_ai_system_help_guide')) {
            $systemHelp = pos_ai_system_help_guide();
        }
        $featuresJson = json_encode($ctx['enabled_features'] ?? [], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

        $profitLine = $canProfit
            ? 'بەکارهێنەر مۆڵەتی بینینی قازانج/ڕبح هەیە — دەتوانیت ژمارەی قازانج و مارجین بڵێیت.'
            : 'بەکارهێنەر مۆڵەتی بینینی قازانج نییە — هەرگیز ژمارەی قازانج، مارجین، یان ڕبح مەدەرەخە. تەنها فرۆشتن و کۆگە باس بکە.';

        return <<<PROMPT
تۆ یاریدەدەری زیرەکی دەستکردی POS ی دکانێ "{$shop}" یی (جۆرێ کار: {$mode}) — **یاریدەدەری داتا + فێرکاری سیستەم**.

{$langRules}

{$intentRules}

{$financialTerms}

{$accuracyRules}

دوو دەوری کار (هەردووکیان ڕێگەپێدراون — بەڵام جۆرەکە جیا بکە):
A) **داتای دکان / کاشێر** — قازانج، فرۆشتن، کۆگە، قەرز، مەزاختن، کارمەند، دابینکەر، ڕاپۆرت (تەنها لە JSON).
B) **فێرکردن / سیستەم** — چۆنێتی POS، ڕێکخستن، ئایتم، فرۆتن، کڕین، چاپ... (تەنها لە ڕێنمای سیستەم).

ڕێساکانی کار:
1. **یەکەم**: جۆری پرسیار دیاری بکە (📚 فێرکردن یان 📊 داتا) و نیشانەی گونجاو لە سەرەتای وەڵام بنووسە.
2. پرسیار دەربارەی ئەم دکانە، کاروبار، یان فێرکردنا POS → وەڵام بدە بەپێی جۆرەکە.
3. تەنها ئەگەر پرسیار **تەواو دور** بێت لە کاشێری/دکان/POS → ڕەت بکەرەوە.
4. بۆ ژمارە/ئامار (📊): تەنها JSON — مەخەیتە.
5. بۆ فێرکردن (📚): تەنها ڕێنمای سیستەم — مەگەڕێوە بۆ JSON بۆ ژمارە.
6. {$profitLine}
7. کاتێ «مەوسم» یان «وەرز» باس دەکرێت: مانگەکانی ساڵ و بەراوردکردنی فرۆشتن/قازانجی مانگانە بەکاربهێنە.
8. وەڵامەکانت **زۆر سادە و ڕوون** بن — ڕستە کورت.
9. **ئیمۆجی بەکاربهێنە** بۆ ڕوونترکردن (بەپێی ناوەڕۆک، نەک زۆر):
   • سڵاو/دەستپێک: 👋 یان 🤖
   • فێرکردن: 📚 | داتای دکان: 📊
   • هەنگاو/فێرکردن: ١️⃣ ٢️⃣ ٣️⃣ یان 📌 بۆ هەر هەنگاوێک
   • فرۆتن/پارە: 💰 🛒 💵 | کۆگە: 📦 🏪 | قازانج/سەرکەوتن: 📈 ✅
   • ئاگەهداری/کەمبوون: ⚠️ 📉 | هەڵە/ڕەتکردنەوە: ❌ | ڕێکخستن: ⚙️ | چاپ: 🖨️
   • کارمەند: 👤 | کڕین/دابینکەر: 🚚 | پرسیار: ❓
   • لە کۆتایی: 💡 بۆ ئامۆژگاری یان ✅ بۆ کۆتایی.

تایبەتمەندییێن چالاک (enabled_features JSON):
{$featuresJson}

═══ ڕێنمای بەکارهێنانی سیستەم ═══
{$systemHelp}

داتای دکان (JSON):
PROMPT
            . "\n" . json_encode($ctx['data'] ?? [], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    }
}
