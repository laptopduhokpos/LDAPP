/**
 * Shop AI assistant — floating mini panel (not in main nav).
 * API key lives server-side only (config/pos_ai_local.php).
 */
(function () {
    'use strict';

    var _history = [];
    var _busy = false;
    var _panelOpen = false;
    var _inited = false;
    var _usageExhausted = false;

    var SHOP_AI_HIDDEN_VIEWS = ['pos', 'purchase', 'purchase-returns', 'returns-new'];

    var QUICK_QUESTIONS = [
        '📦 دێ چەوا ئایتەمەکێ نوی زێدە کەم؟',
        '🖼️ دێ چەوا لۆگۆیێ PNG بۆ دوکانێ دانم؟',
        '🛒 دێ چەوا فرۆتنێ تۆمار کەم؟',
        '📈 ئەڤرۆ مفا چەندە و بەراورد بکە ب دوێنێ؟',
        '⚠️ چ ئایتەمەک لە کۆگەهێ کەمن؟',
        '💳 دێ چەوا قەرزا کریارێ تۆمار کەم؟',
        '👤 کام کارمەند ئەڤ مانگێ زۆرترین فرۆتن کرد؟',
        '🚚 دێ چەوا کڕینێ ل دابینکەرێ تۆمار کەم؟',
        '↩️ دێ چەوا زڤڕاندنێ کەم؟',
        '🖨️ دێ چەوا پرینتەر ڕێک بخەم؟',
        '💸 مەزاختنێن ئەڤ مانگێ چین؟',
        '⚙️ دێ چەوا کارمەندەکێ نوی زێدە کەم و مۆڵەت بدەم؟'
    ];

    function tf(key, fallback) {
        return (typeof t === 'function') ? t(key) : fallback;
    }

    function esc(s) {
        return (typeof escapeHtml === 'function') ? escapeHtml(s) : String(s || '');
    }

    function getShopName() {
        return (db && db.settings && db.settings.cafeName) ? db.settings.cafeName : 'دوکان';
    }

    function getActiveViewId() {
        var active = document.querySelector('.workspace.active');
        return active && active.id ? active.id.replace('view-', '') : '';
    }

    function shopAiCanUse() {
        if (!currentUser) return false;
        if (document.documentElement.classList.contains('pos-pre-auth')) return false;
        if (document.documentElement.classList.contains('app-booting') && window.__posAppShellReady === false) return false;
        if (currentUser.role === 'admin') return true;
        return (typeof hasPermission === 'function') ? hasPermission('reports_view') : false;
    }

    function shopAiUpdateFabVisibility() {
        var fab = document.getElementById('pos-shop-ai-fab');
        if (!fab) return;
        var show = shopAiCanUse();
        if (show) {
            var viewId = getActiveViewId();
            if (SHOP_AI_HIDDEN_VIEWS.indexOf(viewId) >= 0) show = false;
        }
        fab.style.display = show ? 'flex' : 'none';
        if (!show && _panelOpen) shopAiClosePanel();
    }

    function shopAiOpenPanel() {
        var panel = document.getElementById('pos-shop-ai-panel');
        var backdrop = document.getElementById('pos-shop-ai-backdrop');
        var fab = document.getElementById('pos-shop-ai-fab');
        if (!panel || !shopAiCanUse()) return;
        if (!_inited) {
            shopAiInit();
            _inited = true;
        }
        panel.style.display = 'flex';
        if (backdrop) backdrop.style.display = 'block';
        if (fab) fab.classList.add('panel-open');
        _panelOpen = true;
        document.body.classList.add('pos-shop-ai-open');
        var inp = document.getElementById('shop-ai-input');
        if (inp) setTimeout(function () { inp.focus(); }, 120);
    }

    function shopAiClosePanel() {
        var panel = document.getElementById('pos-shop-ai-panel');
        var backdrop = document.getElementById('pos-shop-ai-backdrop');
        var fab = document.getElementById('pos-shop-ai-fab');
        if (panel) panel.style.display = 'none';
        if (backdrop) backdrop.style.display = 'none';
        if (fab) fab.classList.remove('panel-open');
        _panelOpen = false;
        document.body.classList.remove('pos-shop-ai-open');
    }

    function shopAiTogglePanel(forceOpen) {
        if (forceOpen === true) {
            shopAiOpenPanel();
            return;
        }
        if (forceOpen === false) {
            shopAiClosePanel();
            return;
        }
        if (_panelOpen) shopAiClosePanel();
        else shopAiOpenPanel();
    }

    function renderShopAiChips() {
        var wrap = document.getElementById('shop-ai-chips');
        if (!wrap) return;
        wrap.innerHTML = QUICK_QUESTIONS.map(function (q) {
            return '<button type="button" class="shop-ai-chip" onclick="shopAiAskChip(this)">' + esc(q) + '</button>';
        }).join('');
    }

    function appendMessage(role, text, opts) {
        opts = opts || {};
        var box = document.getElementById('shop-ai-messages');
        if (!box) return;
        var div = document.createElement('div');
        div.className = 'shop-ai-msg shop-ai-msg--' + (role === 'user' ? 'user' : 'assistant');
        if (opts.loading) div.classList.add('shop-ai-msg--loading');
        var who = role === 'user'
            ? (currentUser && currentUser.name ? currentUser.name : 'تۆ')
            : tf('shop_ai_bot_name', '🤖 هاریکارێ دوکانێ');
        var icon = role === 'user' ? 'fa-user' : 'fa-robot';
        div.innerHTML =
            '<div class="shop-ai-msg__head"><i class="fas ' + icon + '"></i> <strong>' + esc(who) + '</strong></div>' +
            '<div class="shop-ai-msg__body">' + (opts.loading ? '<span class="shop-ai-typing">' + esc(tf('shop_ai_thinking', 'دەفکرم...')) + '</span>' : formatAnswer(text)) + '</div>';
        box.appendChild(div);
        box.scrollTop = box.scrollHeight;
        return div;
    }

    function formatAnswer(text) {
        if (!text) return '';
        var safe = esc(text);
        safe = safe.replace(/\n/g, '<br>');
        safe = safe.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
        return safe;
    }

    function welcomeIfEmpty() {
        var box = document.getElementById('shop-ai-messages');
        if (!box || box.children.length) return;
        var name = getShopName();
        var isAr = db && db.settings && db.settings.language === 'ar';
        if (isAr) {
            appendMessage('assistant',
                tf('shop_ai_welcome_ar', 'مرحباً! أنا المساعد الذكي لـ «') + name + tf('shop_ai_welcome2_ar', '». اسأل عن الأرباح والمخزون... أو **كيفية استخدام النظام** (إضافة أصناف، شعار PNG، البيع، الطباعة).')
            );
        } else {
            appendMessage('assistant',
                tf('shop_ai_welcome', 'سلاڤ! ئەز هاریکارێ زیرەکم بۆ «') + name + tf('shop_ai_welcome2', '». 📊 داتای دکان (مفا، کۆگە، کارمەند) یان 📚 فێرکردنا سیستەم (چۆن ئایتم زێدە کەم، لۆگۆ، فرۆتن) — ئەز فەرق دکەم و وەڵامێ گونجاو دەم.')
            );
        }
    }

    function shopAiSetInputEnabled(on) {
        var inp = document.getElementById('shop-ai-input');
        var btn = document.getElementById('shop-ai-send-btn');
        if (inp) {
            inp.disabled = !on;
            if (!on) {
                inp.placeholder = tf('shop_ai_limit_placeholder', '⚠️ سنوورا ٣٠ ڕۆژانە تەواو بوو — کۆد یان Pro');
            } else {
                inp.placeholder = tf('shop_ai_input_placeholder', 'ب سادەیی بنڤیسە...');
            }
        }
        if (btn) btn.disabled = !on;
        document.querySelectorAll('#shop-ai-chips .shop-ai-chip').forEach(function (c) {
            c.disabled = !on;
            if (!on) c.classList.add('is-disabled');
            else c.classList.remove('is-disabled');
        });
    }

    function shopAiFormatResetDate(iso) {
        if (!iso) return '';
        var parts = String(iso).split('-');
        if (parts.length !== 3) return iso;
        return parts[2] + '/' + parts[1];
    }

    function shopAiToggleCommerce(open) {
        var el = document.getElementById('shop-ai-commerce');
        if (!el) return;
        if (open === true) el.setAttribute('open', '');
        else if (open === false) el.removeAttribute('open');
    }

    function formatUsd(n) {
        var v = parseFloat(n);
        if (!isFinite(v) || v <= 0) return '$0';
        return '$' + (Math.round(v * 100) % 100 === 0 ? v.toFixed(0) : v.toFixed(2));
    }

    function renderShopAiPacks(packs) {
        var wrap = document.getElementById('shop-ai-packs');
        if (!wrap) return;
        var list = Array.isArray(packs) ? packs : [];
        if (!list.length) {
            wrap.innerHTML = '';
            return;
        }
        var giftLbl = tf('shop_ai_gift_short', 'دیاری');
        var ptsLbl = tf('shop_ai_points_short', 'خاڵ');
        var totalLbl = tf('shop_ai_pack_total', 'کۆی');
        wrap.innerHTML = list.map(function (p) {
            var packPts = parseInt(p.pack_points, 10) || 0;
            var giftPts = parseInt(p.gift_points, 10) || 0;
            var totalPts = parseInt(p.bonus_points, 10) || (packPts + giftPts);
            if (!packPts && totalPts && giftPts) packPts = Math.max(0, totalPts - giftPts);
            var priceUsd = p.price_usd != null && p.price_usd !== '' ? parseFloat(p.price_usd) : NaN;
            var priceText = isFinite(priceUsd) && priceUsd > 0
                ? formatUsd(priceUsd)
                : formatIqd(parseInt(p.price_iqd, 10) || 0);
            return '<div class="shop-ai-pack-card">' +
                '<div class="shop-ai-pack-card__head">' +
                    '<span class="shop-ai-pack-card__pts">+' + packPts + '</span>' +
                    '<span class="shop-ai-pack-card__pts-label">' + esc(ptsLbl) + '</span>' +
                '</div>' +
                (giftPts > 0
                    ? '<span class="shop-ai-pack-card__gift"><i class="fas fa-gift" aria-hidden="true"></i> +' + giftPts + ' ' + esc(giftLbl) + '</span>'
                    : '') +
                '<span class="shop-ai-pack-card__price">' + esc(priceText) + '</span>' +
                '<span class="shop-ai-pack-card__total">= ' + esc(String(totalPts)) + ' ' + esc(totalLbl) + '</span>' +
                '</div>';
        }).join('');
    }

    function formatIqd(n) {
        var v = parseInt(n, 10) || 0;
        return v.toLocaleString('en-US') + ' IQD';
    }

    function shopAiUpdatePlanBadge(tier, usage) {
        var el = document.getElementById('shop-ai-plan-badge');
        if (!el) return;
        var t = String(tier || 'free');
        var isPro = t === 'pro' || t === 'pro_plus';
        var baseLimit = usage && usage.base_limit != null
            ? parseInt(usage.base_limit, 10)
            : (isPro ? 300 : 150);
        var periodDays = usage && usage.period_days != null ? parseInt(usage.period_days, 10) : 30;
        if (!periodDays || isNaN(periodDays)) periodDays = 30;
        el.textContent = (isPro ? 'Pro' : 'Basic') + ' · ' + baseLimit + '/' + periodDays + ' ' + tf('shop_ai_days_short', 'ڕۆژ');
        el.classList.toggle('is-pro', isPro);
    }

    function shopAiRedeemLimitCode() {
        var inp = document.getElementById('shop-ai-limit-code');
        if (!inp) return;
        var code = inp.value.trim();
        if (!code) return;
        var body = new FormData();
        body.append('action', 'redeem_ai_limit_code');
        body.append('code', code);
        var req = (typeof apiJson === 'function')
            ? apiJson('?action=redeem_ai_limit_code', { method: 'POST', body: body })
            : fetch('?action=redeem_ai_limit_code', { method: 'POST', body: body, credentials: 'same-origin' }).then(function (r) { return r.json(); });
        req.then(function (res) {
            if (res && res.usage) shopAiUpdateUsageBar(res.usage);
            if (res && res.status === 'success') {
                inp.value = '';
                appendMessage('assistant', res.message || tf('shop_ai_code_ok', 'کۆد سەرکەوتوو بوو!'));
                _usageExhausted = false;
                shopAiSetInputEnabled(true);
            } else {
                appendMessage('assistant', (res && res.message) ? res.message : tf('shop_ai_code_fail', 'کۆد کار نەکرد.'));
            }
        }).catch(function () {
            appendMessage('assistant', tf('shop_ai_network_error', 'پەیوەندی سەرکەوتوو نەبوو.'));
        });
    }

    function shopAiUpdateUsageBar(usage, turnCost) {
        var wrap = document.getElementById('shop-ai-usage');
        var textEl = document.getElementById('shop-ai-usage-text');
        var fill = document.getElementById('shop-ai-usage-fill');
        var track = wrap ? wrap.querySelector('.pos-shop-ai-usage__track') : null;
        var bonusEl = document.getElementById('shop-ai-bonus-tag');
        var resetEl = document.getElementById('shop-ai-reset-hint');
        var remainEl = document.getElementById('shop-ai-remaining-hint');
        if (!wrap || !usage) return;
        if (usage.tier) shopAiUpdatePlanBadge(usage.tier, usage);
        var used = parseInt(usage.used, 10) || 0;
        var limit = parseInt(usage.limit, 10) || 100;
        var bonus = parseInt(usage.bonus_limit, 10) || 0;
        var remaining = usage.remaining != null ? parseInt(usage.remaining, 10) : Math.max(0, limit - used);
        var minCost = parseInt(usage.min_cost, 10) || 8;
        var pct = usage.pct != null ? parseFloat(usage.pct) : (limit > 0 ? (used / limit) * 100 : 0);
        pct = Math.min(100, Math.max(0, pct));
        if (textEl) {
            var line = used + ' / ' + limit;
            if (turnCost && turnCost.cost) {
                line += '  (−' + turnCost.cost + ')';
            }
            textEl.textContent = line;
        }
        if (bonusEl) {
            if (bonus > 0) {
                bonusEl.hidden = false;
                bonusEl.textContent = '+' + bonus + ' ' + tf('shop_ai_points_short', 'خاڵ');
            } else {
                bonusEl.hidden = true;
                bonusEl.textContent = '';
            }
        }
        if (remainEl) {
            remainEl.textContent = remaining + ' ' + tf('shop_ai_remaining', 'ماوە');
        }
        if (resetEl) {
            var resetDate = shopAiFormatResetDate(usage.resets_on || '');
            var periodDays = parseInt(usage.period_days, 10) || 30;
            resetEl.textContent = resetDate
                ? (tf('shop_ai_reset_hint', 'نوێدەبێتەوە') + ' ' + resetDate + ' · ' + periodDays + ' ' + tf('shop_ai_days_short', 'ڕۆژ'))
                : (tf('shop_ai_period_days', 'هەر ٣٠ ڕۆژان') + ' · ' + periodDays + ' ' + tf('shop_ai_days_short', 'ڕۆژ'));
        }
        if (fill) fill.style.width = pct + '%';
        if (track) track.setAttribute('aria-valuenow', String(Math.round(pct)));
        _usageExhausted = !!usage.exhausted || used >= limit || remaining < minCost;
        wrap.classList.toggle('is-full', _usageExhausted);
        wrap.classList.toggle('is-warning', !_usageExhausted && pct >= 85);
        shopAiSetInputEnabled(!_usageExhausted);
        var commerce = document.getElementById('shop-ai-commerce');
        if (commerce) commerce.classList.toggle('is-exhausted', _usageExhausted);
        if (_usageExhausted) {
            shopAiToggleCommerce(true);
            var bar = document.getElementById('shop-ai-status');
            var textSt = document.getElementById('shop-ai-status-text');
            var iconEl = document.getElementById('shop-ai-status-icon');
            if (bar && textSt) {
                bar.style.display = 'flex';
                bar.className = 'shop-ai-status pos-shop-ai-panel__status shop-ai-status--off';
                var tier = String(usage.tier || 'free');
                textSt.textContent = (tier === 'pro' || tier === 'pro_plus')
                    ? tf('shop_ai_limit_pro', '⚠️ سنوورا ٣٠ ڕۆژانە تەواو بوو (٣٠٠ خاڵ)')
                    : tf('shop_ai_limit_free', '⚠️ سنوورا ٣٠ ڕۆژانە تەواو بوو (١٥٠ خاڵ)');
                if (iconEl) iconEl.innerHTML = '<i class="fas fa-hourglass-end"></i>';
            }
        }
    }

    function updateAiStatusBanner(res) {
        var bar = document.getElementById('shop-ai-status');
        var textEl = document.getElementById('shop-ai-status-text');
        var iconEl = document.getElementById('shop-ai-status-icon');
        if (!bar || !textEl) return;
        if (!res || res.status !== 'success') {
            bar.style.display = 'none';
            return;
        }
        if (res.configured && !_usageExhausted) {
            bar.style.display = 'none';
            return;
        }
        bar.style.display = 'flex';
        if (res.configured) {
            bar.className = 'shop-ai-status pos-shop-ai-panel__status shop-ai-status--off';
            if (iconEl) iconEl.innerHTML = '<i class="fas fa-hourglass-end"></i>';
        } else {
            bar.className = 'shop-ai-status pos-shop-ai-panel__status shop-ai-status--off';
            textEl.textContent = tf('shop_ai_status_off', 'یاریدەدەر لەم دەمەدا بەردەست نییە.');
            if (iconEl) iconEl.innerHTML = '<i class="fas fa-exclamation-circle"></i>';
        }
    }

    function checkAiStatus() {
        return (typeof apiJson === 'function' ? apiJson('?action=ai_shop_status') : fetch('?action=ai_shop_status', { credentials: 'same-origin' }).then(function (r) { return r.json(); }))
            .then(function (res) {
                updateAiStatusBanner(res);
                if (res && res.tier) shopAiUpdatePlanBadge(res.tier, res.usage);
                if (res && res.usage) {
                    shopAiUpdateUsageBar(res.usage);
                    if (res.usage.tier) shopAiUpdatePlanBadge(res.usage.tier, res.usage);
                }
                if (res && res.packs) renderShopAiPacks(res.packs);
                if (!res || res.status !== 'success') return;
                if (!res.configured) {
                    appendMessage('assistant', tf('shop_ai_no_key_staff', 'یاریدەدەرێ AI هێشتا چالاک نەکراوە. پەیوەندی بکە لەگەڵ پشتیوانی سیستەم.'));
                }
            })
            .catch(function () {});
    }

    function shopAiInit() {
        renderShopAiChips();
        welcomeIfEmpty();
        checkAiStatus();
        var inp = document.getElementById('shop-ai-input');
        if (inp && !inp._shopAiBound) {
            inp._shopAiBound = true;
            inp.addEventListener('keydown', function (e) {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    shopAiSend();
                }
            });
        }
        if (typeof applyI18nSubtree === 'function') {
            var panel = document.getElementById('pos-shop-ai-panel');
            if (panel) applyI18nSubtree(panel);
        }
    }

    function shopAiClearChat() {
        _history = [];
        var box = document.getElementById('shop-ai-messages');
        if (box) box.innerHTML = '';
        welcomeIfEmpty();
    }

    function shopAiAskChip(btn) {
        var q = btn && btn.textContent ? btn.textContent.trim() : '';
        if (!q) return;
        var inp = document.getElementById('shop-ai-input');
        if (inp) inp.value = q;
        shopAiSend();
    }

    function shopAiSend() {
        if (_busy || _usageExhausted) return;
        var inp = document.getElementById('shop-ai-input');
        var btn = document.getElementById('shop-ai-send-btn');
        if (!inp) return;
        var question = inp.value.trim();
        if (!question) return;

        _busy = true;
        if (btn) btn.disabled = true;
        inp.value = '';

        appendMessage('user', question);
        _history.push({ role: 'user', text: question });
        var loadingEl = appendMessage('assistant', '', { loading: true });

        var body = new FormData();
        body.append('action', 'ai_shop_chat');
        body.append('question', question);
        body.append('history', JSON.stringify(_history.slice(0, -1)));

        var req = (typeof apiJson === 'function')
            ? apiJson('?action=ai_shop_chat', { method: 'POST', body: body })
            : fetch('?action=ai_shop_chat', { method: 'POST', body: body, credentials: 'same-origin' }).then(function (r) { return r.json(); });

        req.then(function (res) {
            if (loadingEl && loadingEl.parentNode) loadingEl.parentNode.removeChild(loadingEl);
            if (res && res.usage) shopAiUpdateUsageBar(res.usage, res.turn_cost || null);
            if (!res || res.status !== 'success') {
                var err = (res && res.message) ? res.message : tf('shop_ai_error', 'هەڵەیەک ڕوویدا');
                if (res && res.code === 'no_api_key') checkAiStatus();
                if (res && res.code === 'ai_limit_exceeded') {
                    if (res.usage) shopAiUpdateUsageBar(res.usage);
                }
                appendMessage('assistant', err);
                return;
            }
            var answer = res.answer || '';
            appendMessage('assistant', answer);
            _history.push({ role: 'assistant', text: answer });
            if (_history.length > 20) _history = _history.slice(-20);
        }).catch(function () {
            if (loadingEl && loadingEl.parentNode) loadingEl.parentNode.removeChild(loadingEl);
            appendMessage('assistant', tf('shop_ai_network_error', 'پەیوەندی سەرکەوتوو نەبوو. دووبارە هەوڵ بدە.'));
        }).finally(function () {
            _busy = false;
            if (btn) btn.disabled = false;
            if (inp) inp.focus();
        });
    }

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && _panelOpen) shopAiClosePanel();
    });

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', shopAiUpdateFabVisibility);
    } else {
        shopAiUpdateFabVisibility();
    }

    window.shopAiInit = shopAiInit;
    window.shopAiSend = shopAiSend;
    window.shopAiClearChat = shopAiClearChat;
    window.shopAiAskChip = shopAiAskChip;
    window.shopAiTogglePanel = shopAiTogglePanel;
    window.shopAiOpenPanel = shopAiOpenPanel;
    window.shopAiClosePanel = shopAiClosePanel;
    window.shopAiRedeemLimitCode = shopAiRedeemLimitCode;
    window.shopAiUpdateFabVisibility = shopAiUpdateFabVisibility;
    window.shopAiUpdateUsageBar = shopAiUpdateUsageBar;
})();
