/**
 * Virtual scroll for POS product grid — large shops only (few DOM nodes, smooth scroll).
 */
(function () {
    'use strict';

    var ROW_H = 148;
    var COL_MIN = 126;
    var BUFFER_ROWS = 2;

    function shouldUse(listLen) {
        if (!listLen || listLen < 48) return false;
        if (typeof window.isPosLargeShopMode === 'function' && window.isPosLargeShopMode()) return true;
        if (typeof window.isPosLargeCatalogMode === 'function' && window.isPosLargeCatalogMode()) return true;
        if (typeof window.isPosCpuSaveMode === 'function' && window.isPosCpuSaveMode()) return listLen >= 44;
        return listLen >= 72;
    }

    function getCols(container) {
        var w = container.clientWidth || 400;
        return Math.max(2, Math.floor((w - 20) / COL_MIN));
    }

    function throttle(fn, ms) {
        var t = 0;
        var pend = null;
        return function () {
            var now = Date.now();
            var args = arguments;
            var ctx = this;
            if (now - t >= ms) {
                t = now;
                fn.apply(ctx, args);
            } else {
                clearTimeout(pend);
                pend = setTimeout(function () {
                    t = Date.now();
                    fn.apply(ctx, args);
                }, ms);
            }
        };
    }

    function unmount(container) {
        if (!container) return;
        container.classList.remove('pos-virtual-active');
        container.onscroll = null;
        if (window._posVirtualMenuState && window._posVirtualMenuState.container === container) {
            window._posVirtualMenuState = null;
        }
    }

    function render(container, list, opts) {
        opts = opts || {};
        if (!container || !Array.isArray(list) || !list.length) {
            unmount(container);
            return;
        }

        var buildCard = opts.buildCard;
        if (typeof buildCard !== 'function') return;

        unmount(container);
        container.classList.add('pos-virtual-active');
        container.scrollTop = 0;

        var cols = getCols(container);
        var footerH = opts.loadMoreHtml ? 52 : 12;
        var spacerH = Math.ceil(list.length / cols) * ROW_H + footerH;

        container.innerHTML =
            '<div class="pos-virtual-spacer" aria-hidden="true" style="height:' + spacerH + 'px;"></div>' +
            '<div class="pos-virtual-window"></div>' +
            (opts.loadMoreHtml || '');

        var windowEl = container.querySelector('.pos-virtual-window');
        var state = {
            container: container,
            windowEl: windowEl,
            list: list,
            cols: cols,
            buildCard: buildCard,
            opts: opts
        };
        window._posVirtualMenuState = state;

        function paint() {
            if (!state.windowEl || !state.windowEl.parentNode) return;
            var curList = state.list || [];
            var curCols = state.cols || getCols(container);
            var totalRows = Math.max(1, Math.ceil(curList.length / curCols));
            var curFooterH = (state.opts && state.opts.loadMoreHtml) ? 52 : 12;
            var curSpacerH = totalRows * ROW_H + curFooterH;
            var scrollTop = container.scrollTop;
            var viewH = container.clientHeight || 400;
            var startRow = Math.max(0, Math.floor(scrollTop / ROW_H) - BUFFER_ROWS);
            var endRow = Math.min(totalRows, Math.ceil((scrollTop + viewH) / ROW_H) + BUFFER_ROWS);
            var startIdx = startRow * curCols;
            var endIdx = Math.min(curList.length, endRow * curCols);
            var slice = curList.slice(startIdx, endIdx);
            var offsetY = startRow * ROW_H;
            var build = state.buildCard;
            windowEl.style.transform = 'translate3d(0,' + offsetY + 'px,0)';
            windowEl.style.gridTemplateColumns = 'repeat(' + curCols + ', minmax(0, 1fr))';
            windowEl.innerHTML = slice.map(function (p) { return build(p); }).join('');
            if (state.opts && state.opts.onNearEnd && scrollTop + viewH >= curSpacerH - ROW_H * 2) {
                state.opts.onNearEnd();
            }
        }

        state.repaint = paint;
        paint();
        container.onscroll = throttle(paint, 40);

        if (!window._posVirtualResizeBound) {
            window._posVirtualResizeBound = true;
            window.addEventListener('resize', throttle(function () {
                var st = window._posVirtualMenuState;
                if (!st || !st.container) return;
                st.cols = getCols(st.container);
                st.repaint();
            }, 120));
        }
    }

    function setList(list, extra) {
        extra = extra || {};
        var st = window._posVirtualMenuState;
        if (!st || !st.container || !st.container.classList.contains('pos-virtual-active')) return false;
        if (!Array.isArray(list) || !list.length) return false;
        st.list = list;
        if (typeof extra.buildCard === 'function') st.buildCard = extra.buildCard;
        st.opts = st.opts || {};
        if (extra.loadMoreHtml !== undefined) st.opts.loadMoreHtml = extra.loadMoreHtml || '';
        if (typeof extra.onNearEnd === 'function' || extra.onNearEnd === null) st.opts.onNearEnd = extra.onNearEnd;
        var container = st.container;
        st.cols = getCols(container);
        var totalRows = Math.max(1, Math.ceil(st.list.length / st.cols));
        var footerH = st.opts.loadMoreHtml ? 52 : 12;
        var spacer = container.querySelector('.pos-virtual-spacer');
        if (spacer) spacer.style.height = (totalRows * ROW_H + footerH) + 'px';
        var wrap = container.querySelector('#pos-products-load-more-wrap');
        if (st.opts.loadMoreHtml) {
            if (wrap) wrap.outerHTML = st.opts.loadMoreHtml;
            else container.insertAdjacentHTML('beforeend', st.opts.loadMoreHtml);
        } else if (wrap) {
            wrap.remove();
        }
        container.scrollTop = 0;
        if (typeof st.repaint === 'function') st.repaint();
        return true;
    }

    window.posVirtualMenuShouldUse = shouldUse;
    window.posVirtualMenuRender = render;
    window.posVirtualMenuUnmount = unmount;
    window.posVirtualMenuSetList = setList;
    window.posVirtualMenuRepaint = function () {
        var st = window._posVirtualMenuState;
        if (st && typeof st.repaint === 'function') st.repaint();
    };
})();
