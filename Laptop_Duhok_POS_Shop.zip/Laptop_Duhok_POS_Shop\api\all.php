<?php
if (file_exists(__DIR__ . '/../config/cors.php')) {
    require_once __DIR__ . '/../config/cors.php';
}

if (!function_exists('pos_api_cors_apply_headers')) {
    function pos_api_cors_apply_headers() {
        if (headers_sent()) return;
        $origin = isset($_SERVER['HTTP_ORIGIN']) ? trim((string)$_SERVER['HTTP_ORIGIN']) : '';
        if ($origin !== '') {
            header('Access-Control-Allow-Origin: ' . $origin);
            header('Vary: Origin');
            header('Access-Control-Allow-Credentials: true');
        } else {
            header('Access-Control-Allow-Origin: *');
        }
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
        $reqHdr = isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']) ? trim((string)$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']) : '';
        if ($reqHdr !== '') {
            header('Access-Control-Allow-Headers: ' . $reqHdr);
        } else {
            header('Access-Control-Allow-Headers: Content-Type, X-Requested-With, X-Debug-Session-Id, X-POS-Language, X-POS-Mobile-Pin, Authorization, Accept, Accept-Language');
        }
        header('Access-Control-Max-Age: 86400');
    }
}

if (!function_exists('pos_api_cors_handle_options_and_exit')) {
    function pos_api_cors_handle_options_and_exit() {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'OPTIONS') {
            return false;
        }
        pos_api_cors_apply_headers();
        header('Content-Length: 0');
        http_response_code(204);
        return true;
    }
}

if (function_exists('pos_api_cors_handle_options_and_exit') && pos_api_cors_handle_options_and_exit()) {
    exit();
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/version.php';
// Migrations already ran in database.php (schema_version gated).
require_once __DIR__ . '/../config/core.php';
require_once __DIR__ . '/../config/supabase_license.php';
pos_api_require_license_or_exit($conn);

$action = isset($_GET['action']) ? $_GET['action'] : (isset($_POST['action']) ? $_POST['action'] : '');

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'GET' && $action === 'get_sync_tick') {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    if (empty($_SESSION['user_id'])) {
        echo json_encode(['status' => 'auth_required'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }
    $serverTime = 0.0;
    $resTick = $conn->query("SELECT setting_value FROM settings WHERE setting_key = 'last_update' LIMIT 1");
    if ($resTick && ($rowTick = $resTick->fetch_assoc())) {
        $serverTime = (float)$rowTick['setting_value'];
    }
    echo json_encode(['status' => 'ok', 'server_time' => $serverTime], JSON_UNESCAPED_UNICODE);
    exit();
}

if (!in_array($action, pos_api_actions_exempt_terminal_device_gate(), true)) {
    pos_api_enforce_subdevice_access_gate_if_needed($conn);
}

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && $action === 'register_pos_client_device') {
    pos_api_register_pos_client_device_and_exit($conn);
}

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && $action === 'redeem_device_activation_code') {
    pos_api_redeem_device_activation_code_and_exit($conn);
}

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && $action === 'redeem_terminal_activation_code') {
    pos_api_redeem_terminal_activation_code_and_exit($conn);
}

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && $action === 'redeem_terminal_slot_purchase_code') {
    pos_api_redeem_terminal_slot_purchase_code_and_exit($conn);
}

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && $action === 'release_terminal_license_slot') {
    pos_api_release_terminal_license_slot_and_exit($conn);
}

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && $action === 'generate_slot_terminal_security_code') {
    pos_api_generate_slot_terminal_security_code_and_exit($conn);
}

if ($action === 'get_terminal_network_identity') {
    pos_api_get_terminal_network_identity_and_exit($conn);
}

if ($action === 'get_fragi_client_device_key') {
    pos_api_get_fragi_client_device_key_and_exit($conn);
}

if ($action === 'check_pos_client_device_status') {
    pos_api_check_pos_client_device_status_and_exit($conn);
}

// فرعی (multi-device): gated via pos_api_enforce_fragi_device_gate_if_needed on get_data and other API calls.
// Exempt actions: register, TERM redeem, MAC probe — see pos_api_actions_exempt_terminal_device_gate().

if ($action === 'get_sub_device_network_status') {
    pos_api_get_sub_device_network_status_and_exit($conn);
}

if ($action === 'check_secret_menu_access') {
    pos_api_check_secret_menu_access_and_exit($conn);
}
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && $action === 'request_secret_menu_access') {
    pos_api_request_secret_menu_access_and_exit($conn);
}

// When post_max_size is exceeded, PHP empties $_POST/$_FILES before user code runs — request may still be POST with Content-Length (multipart restore).
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cl = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
    if ($cl > 0 && empty($_POST) && empty($_FILES)) {
        $ctype = strtolower((string)($_SERVER['CONTENT_TYPE'] ?? ''));
        $multipart = (strpos($ctype, 'multipart/form-data') !== false);
        $getAct = isset($_GET['action']) ? trim((string)$_GET['action']) : '';
        if ($multipart || $getAct === 'restore_backup') {

            header('Content-Type: application/json; charset=utf-8');
            http_response_code(413);
            echo json_encode([
                'status' => 'error',
                'message' => 'قەبارەی فایل یان گۆشەی POST زۆر گەورەیە بۆ ڕێکخستنی php.ini ئێستا. لە C:\\xampp\\php\\php.ini زیاد بکە: post_max_size و upload_max_filesize (بۆ نموونە 512M بۆ هەر دووک)، دوای ئەوە Apache ڕێستارت بکە. / Increase post_max_size and upload_max_filesize in php.ini then restart Apache.',
            ], JSON_UNESCAPED_UNICODE);
            exit();
        }
    }
}

// Slow-request file log (opt-in — off by default to avoid disk churn on weak laptops)
$__pos_req_start = microtime(true);
if (!empty($_ENV['POS_SLOW_REQUEST_LOG']) || (defined('POS_SLOW_REQUEST_LOG') && POS_SLOW_REQUEST_LOG)) {
    register_shutdown_function(function() use ($action, $__pos_req_start) {
        $ms = (int)round((microtime(true) - $__pos_req_start) * 1000);
        if ($ms < 2500) return;
        $logDir = __DIR__ . '/../logs';
        if (!is_dir($logDir)) @mkdir($logDir, 0777, true);
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $method = $_SERVER['REQUEST_METHOD'] ?? '';
        $line = date('Y-m-d H:i:s') . " | slow_request ms=$ms method=$method action=$action ip=$ip\n";
        @file_put_contents($logDir . '/slow_requests_' . date('Ymd') . '.log', $line, FILE_APPEND);
    });
}

require_once __DIR__ . '/all-helpers-core.php';
require_once __DIR__ . '/../config/pos_ai.php';
require_once __DIR__ . '/all-helpers-money.php';
if (isset($conn) && $conn instanceof mysqli && function_exists('pos_ensure_old_debt_repair_v2')) {
    pos_ensure_old_debt_repair_v2($conn);
}
require_once __DIR__ . '/all-helpers-audit.php';
require_once __DIR__ . '/all-backup-build.php';
require_once __DIR__ . '/all-get-handlers.php';
require_once __DIR__ . '/all-get-backup-reports.php';
require_once __DIR__ . '/all-get-sync.php';
require_once __DIR__ . '/all-get-misc.php';
require_once __DIR__ . '/all-ai.php';
require_once __DIR__ . '/all-backup-helpers.php';
require_once __DIR__ . '/all-actions.php';
