        <!-- لیستا سەرەکی: تۆڕا ئایکۆنان — جودا ژ شاشا سەرەکی (ڕۆژمێر) -->
        <div id="view-home" class="workspace view-home-premium">
            <div class="view-home-bg" aria-hidden="true">
                <span class="view-home-orb view-home-orb--1"></span>
                <span class="view-home-orb view-home-orb--2"></span>
                <span class="view-home-orb view-home-orb--3"></span>
                <span class="view-home-sparkles"></span>
            </div>
            <div class="view-home-content">
                <header class="view-home-hero view-home-hero--compact">
                    <span class="view-home-hero-icon view-home-hero-icon--logo">
                        <img id="home-shop-logo-img" class="home-shop-logo-img" alt="" src="public/assets/brand/laptop-duhok-logo.png" decoding="async">
                    </span>
                    <h2 class="view-home-title"><span data-i18n="bc_menu">لیستا سەرەکی</span></h2>
                </header>
                <div id="home-tier-banner" class="home-tier-banner" style="display:none;" aria-hidden="true">
                    <div class="home-tier-banner__glow" aria-hidden="true"></div>
                    <span class="home-tier-banner__icon" aria-hidden="true"><i class="fas fa-crown"></i></span>
                    <div class="home-tier-banner__body">
                        <strong id="home-tier-banner-title" class="home-tier-banner__title"></strong>
                        <span id="home-tier-banner-desc" class="home-tier-banner__desc"></span>
                    </div>
                    <span id="home-tier-banner-badge" class="home-tier-banner__badge"></span>
                </div>
                <p id="view-home-subtitle" class="view-home-subtitle" style="display:none;" aria-live="polite"></p>
                <div class="view-home-stage">
                    <div id="home-grid-container" class="home-grid home-grid--premium"></div>
                </div>
            </div>
        </div>
        <div id="view-dash" class="workspace"></div>

        <!-- GENERAL HISTORY: Print & Delete (Non-Sales) -->
        <div id="view-print-history" class="workspace gh-workspace">
            <div class="gh-header card">
                <div class="gh-header-top">
                    <div>
                        <h2 class="gh-title"><i class="fas fa-history"></i> <span data-i18n="view_print_history_title">تۆمارا گشتی یا چاپێ و ژێبرنێ</span></h2>
                        <p class="gh-desc"><span data-i18n="view_print_history_desc">چاڤدێرییا هەمی کارێن چاپکرنێ و ژێبرنێ بکە. کلیکێ ل سەر ڕێزێ بکە بۆ دیتن و دووبارە چاپکرنێ.</span></p>
                    </div>
                    <button type="button" class="btn btn-sm btn-brand gh-refresh-btn" onclick="if(typeof refreshGeneralHistory==='function')refreshGeneralHistory();" title="نویکرن"><i class="fas fa-sync-alt"></i> <span data-i18n="gh_refresh">نویکرن</span></button>
                </div>
                <p id="gh-count" class="gh-count" aria-live="polite"></p>
            </div>
            <div class="gh-filters card no-print">
                <div class="gh-filters-inner">
                    <input type="text" id="gh-search" class="input-std gh-search" data-i18n-placeholder="search_placeholder" placeholder="لێگەریان..." oninput="renderGeneralHistory()">
                    <select id="gh-action-filter" class="input-std gh-select" onchange="renderGeneralHistory()">
                        <option value="" data-i18n-opt="gh_all_actions">هەموو کاران</option>
                        <option value="print" data-i18n-opt="gh_filter_print">چاپ</option>
                        <option value="delete" data-i18n-opt="gh_filter_delete">سڕینەوە</option>
                        <option value="update" data-i18n-opt="gh_filter_update">نویکرن</option>
                    </select>
                    <select id="gh-doc-filter" class="input-std gh-select" onchange="renderGeneralHistory()">
                        <option value="" data-i18n-opt="gh_all_doc_types">هەموو جۆرێ دۆکومێنت</option>
                        <option value="stocktake_report" data-i18n-opt="gh_doc_stocktake_report">ڕاپۆرتی پێداچوون/جەرد</option>
                        <option value="stock_movement_log" data-i18n-opt="gh_doc_stock_movement_log">تۆمارا لڤینێن کۆگەهێ</option>
                        <option value="stock_transfer_report" data-i18n-opt="gh_doc_stock_transfer_report">گواستنەوەی کۆگە</option>
                        <option value="inventory_report" data-i18n-opt="gh_doc_inventory_report">لیستا کۆگەه</option>
                        <option value="company_ledger" data-i18n-opt="gh_doc_company_ledger">کۆمپانیا / دابینکەران</option>
                        <option value="delivery_slip" data-i18n-opt="gh_doc_delivery_slip">گەهاندن</option>
                        <option value="expenses_report" data-i18n-opt="gh_doc_expenses_report">ڕاپۆرتا مەزاختنان</option>
                        <option value="expense" data-i18n-opt="gh_doc_expense">مەزاختن (تاک)</option>
                        <option value="debt_list" data-i18n-opt="gh_doc_debt_report">قەرزان</option>
                        <option value="daily_report" data-i18n-opt="gh_doc_daily_report">ڕاپۆرتێ رۆژانە</option>
                        <option value="monthly_report" data-i18n-opt="gh_doc_monthly_report">ڕاپۆرتێ مانگانە</option>
                    </select>
                </div>
            </div>
            <div class="gh-table-card card">
                <div class="gh-table-wrap">
                    <table class="gh-table" id="gh-table">
                        <thead>
                            <tr>
                                <th class="gh-th-id" data-i18n="gh_th_id">ناسنامە</th>
                                <th class="gh-th-doc"><span data-i18n="gh_th_doc_type">جۆرێ دۆکومێنت</span></th>
                                <th class="gh-th-ref"><span data-i18n="gh_th_ref">ناسناما</span></th>
                                <th class="gh-th-action"><span data-i18n="gh_th_action">کار</span></th>
                                <th class="gh-th-user"><span data-i18n="gh_th_user">بەکارهێنەر</span></th>
                                <th class="gh-th-date"><span data-i18n="gh_th_date">بەروار</span></th>
                                <th class="gh-th-note"><span data-i18n="gh_th_note">ملاحظة</span></th>
                                <th class="gh-th-btn"></th>
                            </tr>
                        </thead>
                        <tbody id="general-history-body">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- TABLES / سەبەتە و مێز -->
        <div id="view-tables" class="workspace tables-workspace">
            <header class="tables-page-header">
                <div class="tables-page-header-main">
                    <div class="tables-page-icon" aria-hidden="true"><i class="fas fa-th-large"></i></div>
                    <div>
                        <h2 class="tables-page-title"><span data-i18n="view_tables_title">نەخشێ مێزان</span></h2>
                        <p class="tables-page-subtitle">سەبەتە، سەفەری، و دۆخی چالاک — کلیک بکە بۆ کردنەوە</p>
                    </div>
                </div>
                <div class="tables-summary-chips" aria-live="polite">
                    <span class="tables-chip tables-chip--total"><i class="fas fa-layer-group" aria-hidden="true"></i> <span id="tables-stat-total">0</span> کۆ</span>
                    <span class="tables-chip tables-chip--free"><i class="fas fa-check-circle" aria-hidden="true"></i> <span id="tables-stat-free">0</span> بەردەست</span>
                    <span class="tables-chip tables-chip--busy"><i class="fas fa-circle" aria-hidden="true"></i> <span id="tables-stat-busy">0</span> مژوول</span>
                </div>
            </header>
            <div class="tables-toolbar">
                <button type="button" class="tables-tool-btn tables-tool-btn--transfer protected" data-perm="pos_access" onclick="transferTableUI()">
                    <i class="fas fa-exchange-alt" aria-hidden="true"></i>
                    <span data-i18n="btn_transfer">ڤەگوهاستن</span>
                </button>
                <button type="button" class="tables-tool-btn tables-tool-btn--edit protected" data-perm="pos_access" onclick="toggleTableEditMode()" title="دەستکاری">
                    <i class="fas fa-pen" aria-hidden="true"></i>
                    <span>دەستکاری</span>
                </button>
                <button type="button" class="tables-tool-btn tables-tool-btn--z protected" data-perm="pos_access" onclick="printZReport()">
                    <i class="fas fa-file-invoice" aria-hidden="true"></i>
                    <span data-i18n="btn_close_day">داخستنا ڕۆژێ</span>
                </button>
                <button type="button" class="tables-tool-btn tables-tool-btn--add protected" data-perm="pos_access" onclick="addTable()">
                    <i class="fas fa-plus-circle" aria-hidden="true"></i>
                    <span data-i18n="btn_add_table">+ سەبەتە</span>
                </button>
                <button type="button" class="tables-tool-btn tables-tool-btn--refresh" onclick="if(typeof refreshTablesView==='function')refreshTablesView();" title="نویکرن" aria-label="نویکرن">
                    <i class="fas fa-sync-alt" aria-hidden="true"></i>
                </button>
            </div>
            <div id="tables-grid" class="tables-layout-root"></div>
        </div>

        <!-- COMPANIES VIEW — کڕین کۆمپانیا + کۆمپانیا دروستکەر (جیا) -->
        <div id="view-companies" class="workspace txn-entity-list-view">
            <a href="javascript:void(0)" class="companies-purchase-shortcut no-print" id="companies-purchase-shortcut" onclick="nav('purchase')">
                <i class="fas fa-shopping-cart"></i>
                <span data-i18n="quick_purchase">کڕینا بلەز</span>
            </a>
            <div class="page-action-row txn-entity-page-header">
                <h2 style="margin:0;"><i class="fas fa-building"></i> <span data-i18n="view_companies_title">کۆمپانیا</span></h2>
                <div class="page-actions-standard" id="companies-page-actions">
                    <button type="button" class="btn btn-brand btn-sm" data-perm="companies_manage" id="companies-print-btn" onclick="printCompaniesReport()"><i class="fas fa-print"></i> <span data-i18n="debt_print_report">چاپکرنا ڕاپۆرتێ</span></button>
                </div>
            </div>
            <div class="card txn-entity-list-card companies-hub-card">
                <div class="txn-entity-tabs companies-hub-tabs">
                    <button type="button" class="btn btn-brand" id="companies-tab-purchase" onclick="setCompaniesTab('purchase')"><i class="fas fa-truck-loading"></i> <span data-i18n="companies_tab_purchase">کڕین کۆمپانیا</span></button>
                    <button type="button" class="btn btn-info" id="companies-tab-manufacturers" onclick="setCompaniesTab('manufacturers')"><i class="fas fa-industry"></i> <span data-i18n="companies_tab_manufacturers">کۆمپانیا دروستکەر</span></button>
                </div>

                <div id="companies-purchase-panel" class="companies-tab-panel">
                    <p class="companies-tab-hint" data-i18n="companies_purchase_hint">دابینکەر و قەرزی کڕین — پەیوەست بە کڕین و دەفتەری قەرز.</p>
                    <div id="companies-add-box" class="txn-entity-add-row" data-perm="companies_manage">
                        <label class="txn-field-ico" title="ناڤ"><i class="fas fa-building"></i><input type="text" id="c-name" class="input-std" data-i18n-placeholder="comp_name_ph" placeholder="ناڤێ کۆمپانیێ"></label>
                        <label class="txn-field-ico" title="تەلەفۆن"><i class="fas fa-phone"></i><input type="text" id="c-phone" class="input-std" data-i18n-placeholder="comp_phone_ph" placeholder="ژمارا تەلەفۆنێ"></label>
                        <label class="txn-field-ico" title="ناڤنیشان"><i class="fas fa-location-dot"></i><input type="text" id="c-addr" class="input-std" data-i18n-placeholder="comp_address_ph" placeholder="ناڤنیشان"></label>
                        <label class="txn-field-ico" title="دەین"><i class="fas fa-coins"></i><span class="txn-field-ico-stack"><input type="text" id="c-opening-balance" class="input-std" data-i18n-placeholder="comp_opening_ph" placeholder="دەینی کەڤن" inputmode="decimal" dir="ltr"><small id="c-opening-paper-hint" class="duhok-paper-hint"></small></span></label>
                        <label class="txn-field-ico" title="سنوور"><i class="fas fa-gauge-high"></i><input type="text" id="c-debt-limit" class="input-std" data-i18n-placeholder="comp_limit_ph" placeholder="سنووری قەرز" inputmode="decimal" dir="ltr"></label>
                        <label class="txn-field-ico" title="مەوعد"><i class="fas fa-clock"></i><input type="number" id="c-payment-term-value" class="input-std" min="0" step="1" data-i18n-placeholder="payment_term_value_ph" placeholder="مەوعد (ژمارە)" inputmode="numeric" dir="ltr" value="0"></label>
                        <label class="txn-field-ico" title="یەکە"><i class="fas fa-calendar-days"></i><select id="c-payment-term-unit" class="input-std" aria-label="مەوعدێ پارەدانێ">
                            <option value="minute" data-i18n-opt="payment_term_unit_minute">خولەک</option>
                            <option value="hour" data-i18n-opt="payment_term_unit_hour">دەمژمێر</option>
                            <option value="day" data-i18n-opt="payment_term_unit_day" selected>ڕۆژ</option>
                            <option value="month" data-i18n-opt="payment_term_unit_month">مانگ</option>
                            <option value="year" data-i18n-opt="payment_term_unit_year">ساڵ</option>
                        </select></label>
                        <button type="button" class="btn btn-success txn-entity-add-btn" onclick="saveCompany()"><i class="fas fa-plus"></i> <span data-i18n="debt_add_btn">زێدەکرن</span></button>
                    </div>
                    <div id="companies-grid" class="stat-grid txn-entity-list-grid"></div>
                </div>

                <div id="companies-manufacturers-panel" class="companies-tab-panel companies-mfr-panel" style="display:none;">
                    <div class="mfr-hero-banner">
                        <div class="mfr-hero-icon" aria-hidden="true"><i class="fas fa-industry"></i></div>
                        <div class="mfr-hero-text">
                            <h3 data-i18n="companies_tab_manufacturers">کۆمپانیا دروستکەر</h3>
                            <p data-i18n="mfr_section_intro">براند / کارگەی دروستکەری کاڵا — جیا لە کڕین کۆمپانیا؛ قەرز و کڕین لێرە نییە.</p>
                        </div>
                    </div>
                    <input type="hidden" id="mfr-edit-id" value="">
                    <div id="manufacturers-add-box" class="txn-entity-add-row mfr-add-row" data-perm="companies_manage">
                        <label class="txn-field-ico" title="ناڤ"><i class="fas fa-industry"></i><input type="text" id="mfr-name" class="input-std" data-i18n-placeholder="mfr_name_ph" placeholder="ناوی کۆمپانیا دروستکەر"></label>
                        <label class="txn-field-ico" title="تەلەفۆن"><i class="fas fa-phone"></i><input type="text" id="mfr-phone" class="input-std" data-i18n-placeholder="mfr_phone_ph" placeholder="ژمارەی تەلەفۆن"></label>
                        <label class="txn-field-ico" title="تێبینی"><i class="fas fa-sticky-note"></i><input type="text" id="mfr-note" class="input-std" data-i18n-placeholder="mfr_note_ph" placeholder="تێبینی (ئارەزوومەندانە)"></label>
                        <button type="button" class="btn btn-success txn-entity-add-btn" id="mfr-save-btn" onclick="saveManufacturer()"><i class="fas fa-plus"></i> <span data-i18n="debt_add_btn">زێدەکرن</span></button>
                        <button type="button" class="btn btn-dark txn-entity-add-btn hidden" id="mfr-cancel-edit-btn" onclick="cancelManufacturerEdit()"><i class="fas fa-times"></i> <span data-i18n="btn_cancel">پاشگەزبوون</span></button>
                    </div>
                    <div id="manufacturers-grid" class="stat-grid txn-entity-list-grid mfr-grid"></div>
                </div>
            </div>
        </div>

        <!-- CUSTOMERS / DEBT VIEW -->
        <div id="view-debt" class="workspace txn-entity-list-view">
            <div class="page-action-row txn-entity-page-header">
                <h2 style="margin:0;"><i class="fas fa-users"></i> <span data-i18n="debt_page_heading">کریار</span></h2>
                <div class="page-actions-standard">
                    <button type="button" class="btn btn-brand btn-sm" data-perm="debt_view" onclick="printCustomersReport()"><i class="fas fa-print"></i> <span data-i18n="debt_print_report">چاپکرنا ڕاپۆرتێ</span></button>
                </div>
            </div>
            <div class="card txn-entity-list-card">
                <div class="txn-entity-tabs">
                    <button type="button" class="btn btn-brand" id="debt-tab-btn-customers" data-perm="debt_view" onclick="renderDebtView('customers')"><i class="fas fa-user"></i> <span data-i18n="debt_tab_customers">کریار</span></button>
                    <button type="button" class="btn btn-info" id="debt-tab-btn-users" data-perm="debt_view" onclick="renderDebtView('users')"><i class="fas fa-user-tie"></i> <span data-i18n="debt_tab_staff">کارمەند</span></button>
                </div>
                <div id="debt-add-customer-box" class="txn-entity-add-row" data-perm="debt_manage">
                    <label class="txn-field-ico" title="ناڤ"><i class="fas fa-user"></i><input type="text" id="new-cust-name" class="input-std" data-i18n-placeholder="debt_new_name_ph" placeholder="ناڤێ کریاری"></label>
                    <label class="txn-field-ico" title="تەلەفۆن"><i class="fas fa-phone"></i><input type="text" id="new-cust-phone" class="input-std" data-i18n-placeholder="debt_new_phone_ph" placeholder="ژمارا تەلەفۆنێ"></label>
                    <label class="txn-field-ico" title="ناڤنیشان"><i class="fas fa-location-dot"></i><input type="text" id="new-cust-address" class="input-std" data-i18n-placeholder="debt_new_address_ph" placeholder="ناڤنیشان"></label>
                    <label class="txn-field-ico" title="دەین"><i class="fas fa-coins"></i><span class="txn-field-ico-stack"><input type="text" id="new-cust-opening-balance" class="input-std" data-i18n-placeholder="debt_new_opening_ph" placeholder="دەینی کەڤن" inputmode="decimal" dir="ltr"><small id="new-cust-opening-paper-hint" class="duhok-paper-hint"></small></span></label>
                    <label class="txn-field-ico" title="سنوور"><i class="fas fa-gauge-high"></i><input type="text" id="new-cust-debt-limit" class="input-std" data-i18n-placeholder="debt_new_limit_ph" placeholder="سنووری قەرز" inputmode="decimal" dir="ltr"></label>
                    <label class="txn-field-ico" title="مەوعد"><i class="fas fa-clock"></i><input type="number" id="new-cust-payment-term-value" class="input-std" min="0" step="1" data-i18n-placeholder="payment_term_value_ph" placeholder="مەوعد (ژمارە)" inputmode="numeric" dir="ltr" value="0"></label>
                    <label class="txn-field-ico" title="یەکە"><i class="fas fa-calendar-days"></i><select id="new-cust-payment-term-unit" class="input-std" aria-label="مەوعدێ پارەدانێ">
                        <option value="minute" data-i18n-opt="payment_term_unit_minute">خولەک</option>
                            <option value="hour" data-i18n-opt="payment_term_unit_hour">دەمژمێر</option>
                        <option value="day" data-i18n-opt="payment_term_unit_day" selected>ڕۆژ</option>
                        <option value="month" data-i18n-opt="payment_term_unit_month">مانگ</option>
                        <option value="year" data-i18n-opt="payment_term_unit_year">ساڵ</option>
                    </select></label>
                    <button type="button" class="btn btn-success txn-entity-add-btn" onclick="saveCustomer()"><i class="fas fa-user-plus"></i> <span data-i18n="debt_add_btn">زێدەکرن</span></button>
                </div>
                <div id="debt-list-container" class="stat-grid txn-entity-list-grid"></div>
            </div>

            <div class="card" id="debt-ledger-view" style="display:none; border-top: 5px solid var(--danger);">
                <h3 id="debt-ledger-title"><span data-i18n="debt_ledger_history_title">مێژوویا قەرزان</span></h3>
                <div style="display:flex; gap:5px; margin-bottom:10px; align-items:center;">
                    <input type="date" id="date-start-debt" class="input-std" style="margin:0; font-size:0.9rem;" onchange="renderCurrentDebtLedger()">
                    <span data-i18n="debt_date_range_to">تا</span>
                    <input type="date" id="date-end-debt" class="input-std" style="margin:0; font-size:0.9rem;" onchange="renderCurrentDebtLedger()">
                    <button class="btn btn-sm btn-dark" onclick="resetDateFilter('debt', renderCurrentDebtLedger)"><i class="fas fa-times"></i></button>
                </div>
                <div id="debt-ledger-list" style="max-height:300px; overflow-y:auto;"></div>
            </div>
        </div>

        <!-- WMS: کۆگەه — premium -->
