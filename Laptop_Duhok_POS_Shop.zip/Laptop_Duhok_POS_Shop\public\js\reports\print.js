// POS reports - reprint, A4 invoice, labels
        // --- REPRINT ---
        function resolveReprintPosCfg(opts) {
            opts = opts || {};
            var base = (typeof getPrintConfig === 'function') ? getPrintConfig('pos_sale') : { paper: '80mm', design: '7' };
            var paperRaw = opts.paper != null ? String(opts.paper) : '';
            var want80 = /^(80mm|80)$/i.test(paperRaw);
            var wantA4 = /^(210mm|A4)$/i.test(paperRaw);
            if (want80) {
                return (typeof normalizePosSalePrintConfig === 'function')
                    ? normalizePosSalePrintConfig('80mm', '7')
                    : { paper: '80mm', design: '7' };
            }
            if (wantA4) {
                var a4Design = '1';
                if (base && isA4PrintPaper(base.paper) && base.design) a4Design = String(base.design);
                else if (base && ['1', '2', '8'].indexOf(String(base.design || '')) >= 0) a4Design = String(base.design);
                return (typeof normalizePosSalePrintConfig === 'function')
                    ? normalizePosSalePrintConfig('210mm', a4Design)
                    : { paper: '210mm', design: a4Design };
            }
            return base || { paper: '80mm', design: '7' };
        }
        function closeSalesHistPrintChooser() {
            var modal = document.getElementById('sales-hist-print-chooser');
            if (modal) modal.style.display = 'none';
        }
        /** Shared 80mm / A4 picker (sales reprint + ledger reports). */
        function openPrintPaperChooser(opts) {
            opts = opts || {};
            var tf = typeof t === 'function';
            var title = opts.title || (tf ? (t('sales_hist_print_choose') || 'قەبارەی چاپێ هەلبژێرە') : 'قەبارەی چاپێ هەلبژێرە');
            var subtitle = opts.subtitle != null ? String(opts.subtitle) : '';
            var lbl80 = tf ? (t('sales_hist_print_80') || '٨٠ مم (ترمەڵ)') : '٨٠ مم (ترمەڵ)';
            var lblA4 = tf ? (t('sales_hist_print_a4') || 'A4') : 'A4';
            var lblCancel = tf ? (t('btn_cancel') || 'پاشگەزبوون') : 'پاشگەزبوون';
            var storageKey = opts.storageKey || 'pos_print_paper_choice';
            var last = '';
            try { last = String(localStorage.getItem(storageKey) || ''); } catch (_eLs) {}
            var prefer80 = !/^(210mm|A4)$/i.test(last);

            var modal = document.getElementById('sales-hist-print-chooser');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'sales-hist-print-chooser';
                modal.className = 'modal-overlay';
                modal.style.cssText = 'display:none;position:fixed;inset:0;background:rgba(15,23,42,0.55);align-items:center;justify-content:center;padding:16px;z-index:12000;';
                modal.innerHTML =
                    '<div role="dialog" aria-modal="true" style="background:var(--card,#fff);border-radius:14px;max-width:360px;width:100%;padding:18px 16px;box-shadow:0 16px 40px rgba(0,0,0,0.28);direction:rtl;text-align:center;">' +
                    '<div id="sales-hist-print-chooser-title" style="font-weight:800;font-size:1.05rem;margin-bottom:6px;"></div>' +
                    '<div style="font-size:0.85rem;color:var(--text-muted,#64748b);margin-bottom:14px;">' +
                    '<span id="sales-hist-print-chooser-id"></span></div>' +
                    '<div style="display:flex;flex-direction:column;gap:8px;">' +
                    '<button type="button" id="sales-hist-print-btn-80" class="btn btn-dark" style="width:100%;padding:12px;font-weight:800;"><i class="fas fa-receipt"></i> <span></span></button>' +
                    '<button type="button" id="sales-hist-print-btn-a4" class="btn" style="width:100%;padding:12px;font-weight:700;border:1px solid var(--border,#e2e8f0);background:var(--input-bg,#f8fafc);"><i class="fas fa-file-alt"></i> <span></span></button>' +
                    '<button type="button" id="sales-hist-print-btn-cancel" class="btn btn-sm" style="margin-top:4px;opacity:0.85;"></button>' +
                    '</div></div>';
                modal.addEventListener('click', function(e) {
                    if (e.target === modal) closeSalesHistPrintChooser();
                });
                document.body.appendChild(modal);
                if (typeof window._posWatchOverlay === 'function') window._posWatchOverlay(modal);
            }

            var titleEl = document.getElementById('sales-hist-print-chooser-title');
            var idEl = document.getElementById('sales-hist-print-chooser-id');
            var btn80 = document.getElementById('sales-hist-print-btn-80');
            var btnA4 = document.getElementById('sales-hist-print-btn-a4');
            var btnCancel = document.getElementById('sales-hist-print-btn-cancel');
            if (titleEl) titleEl.textContent = title;
            if (idEl) idEl.textContent = subtitle;
            if (btn80) {
                var s80 = btn80.querySelector('span');
                if (s80) s80.textContent = lbl80;
                btn80.style.outline = prefer80 ? '2px solid var(--brand,#0f172a)' : '';
                btn80.onclick = function() {
                    try { localStorage.setItem(storageKey, '80mm'); } catch (_e1) {}
                    closeSalesHistPrintChooser();
                    if (typeof opts.onPick === 'function') opts.onPick('80mm');
                };
            }
            if (btnA4) {
                var sA4 = btnA4.querySelector('span');
                if (sA4) sA4.textContent = lblA4;
                btnA4.style.outline = prefer80 ? '' : '2px solid var(--brand,#0f172a)';
                btnA4.onclick = function() {
                    try { localStorage.setItem(storageKey, '210mm'); } catch (_e2) {}
                    closeSalesHistPrintChooser();
                    if (typeof opts.onPick === 'function') opts.onPick('210mm');
                };
            }
            if (btnCancel) {
                btnCancel.textContent = lblCancel;
                btnCancel.onclick = closeSalesHistPrintChooser;
            }
            modal.style.display = 'flex';
            if (typeof window.bringOverlayToFront === 'function') window.bringOverlayToFront(modal);
        }
        window.openPrintPaperChooser = openPrintPaperChooser;
        /** From sales history: choose 80mm (compact thermal) or A4 before reprint. */
        function reprintBillFromHistory(id) {
            if (id == null || id === '') {
                if (typeof showToast === 'function') showToast('⚠️ وەسڵ نەدۆزرایەوە بۆ چاپکرن', 'warning');
                return;
            }
            var tf = typeof t === 'function';
            openPrintPaperChooser({
                title: tf ? (t('sales_hist_print_choose') || 'قەبارەی چاپێ هەلبژێرە') : 'قەبارەی چاپێ هەلبژێرە',
                subtitle: '#' + String(id),
                storageKey: 'pos_sales_hist_print_paper',
                onPick: function(paper) { reprintBill(id, { paper: paper }); }
            });
        }
        function posAdjSlipEsc(s) {
            return (typeof escapeHtml === 'function') ? escapeHtml(String(s == null ? '' : s)) : String(s == null ? '' : s);
        }
        function posAdjSlipWarehouse(sale) {
            if (typeof posHistWarehouseName === 'function') return posHistWarehouseName(sale);
            var n = String((sale && sale.warehouse_name) || '').trim();
            if (n) return n;
            var id = parseInt(sale && sale.warehouse_id, 10) || 0;
            if (id && typeof db !== 'undefined' && db && Array.isArray(db.warehouses)) {
                var w = db.warehouses.find(function(x) { return x && Number(x.id) === id; });
                if (w) return String(w.name || '');
            }
            return '';
        }
        function buildSaleAdjustmentSlipHtml(sale, edits) {
            sale = sale || {};
            edits = Array.isArray(edits) ? edits : [];
            var tf = typeof t === 'function';
            var shop = '';
            try {
                shop = String((db && db.settings && (db.settings.shopName || db.settings.store_name || db.settings.name)) || '');
            } catch (_e) { shop = ''; }
            var wh = posAdjSlipWarehouse(sale);
            var voided = !!(sale.is_returned == 1 || sale.is_returned === true || sale.is_returned === '1');
            var hasRet = (typeof posHistSaleHasReturn === 'function') ? posHistSaleHasReturn(sale) : !!(Number(sale.has_return) === 1);
            var kind = tf ? t('sale_hist_slip_title') : 'وەسڵا گۆڕانێ';
            if (voided) kind = tf ? (t('sale_hist_slip_void') || 'ژێبرنا وەسڵێ') : 'ژێبرنا وەسڵێ';
            else if (hasRet) kind = tf ? (t('sale_hist_slip_return') || 'زڤڕاندن') : 'زڤڕاندن';
            else if (edits.length) kind = tf ? (t('sale_hist_slip_edit') || 'تەعدیلا وەسڵێ') : 'تەعدیلا وەسڵێ';
            var when = '';
            try {
                when = (typeof formatPosDateTime === 'function')
                    ? formatPosDateTime(sale.date || sale.created_at)
                    : String(sale.date || sale.created_at || '');
            } catch (_e2) { when = String(sale.date || ''); }
            var lines = [];
            var getQty = (typeof getItemQty === 'function') ? getItemQty : function(i) {
                var q = parseFloat(i && (i.qty != null ? i.qty : i.count));
                return (!isNaN(q) && q > 0) ? q : 1;
            };
            if (voided || (!edits.length && !hasRet)) {
                (sale.items || []).forEach(function(it) {
                    if (!it) return;
                    var q = getQty(it);
                    var lineWh = String(it.warehouse_name || wh || '').trim();
                    lines.push(posAdjSlipEsc(it.name || 'ئایتم') + ' ×' + q + (lineWh ? (' — ' + posAdjSlipEsc(lineWh)) : ''));
                });
            }
            if (hasRet && typeof db !== 'undefined' && db && Array.isArray(db.returns)) {
                db.returns.forEach(function(r) {
                    if (!r || Number(r.sale_id) !== Number(sale.id)) return;
                    (r.items || []).forEach(function(it) {
                        if (!it) return;
                        var q = getQty(it);
                        lines.push(posAdjSlipEsc(it.name || 'ئایتم') + ' ×' + q);
                    });
                });
            }
            edits.forEach(function(ed) {
                (ed.changes || []).forEach(function(ch) {
                    if (ch) lines.push(posAdjSlipEsc(ch));
                });
            });
            if (!lines.length) {
                lines.push(posAdjSlipEsc(tf ? (t('sale_hist_slip_no_lines') || 'وردەکاری نینە') : 'وردەکاری نینە'));
            }
            var stockNote = '';
            if (voided) {
                stockNote = tf ? (t('sale_hist_slip_stock_back') || 'مەواد زڤڕیە کوگەهێ') : 'مەواد زڤڕیە کوگەهێ';
            } else if (hasRet) {
                stockNote = tf ? (t('sale_hist_slip_stock_return') || 'مەواد زڤڕیە کوگەهێ (زڤڕاندن)') : 'مەواد زڤڕیە کوگەهێ (زڤڕاندن)';
            } else if (edits.length) {
                stockNote = tf ? (t('sale_hist_slip_stock_edit') || 'عەدەدێ کوگەهێ هاتە نوێکرن') : 'عەدەدێ کوگەهێ هاتە نوێکرن';
            }
            var itemsHtml = lines.map(function(l) {
                return '<div style="text-align:right;padding:3px 0;border-bottom:1px dashed #ccc;">' + l + '</div>';
            }).join('');
            return '<!DOCTYPE html><html><head><meta charset="utf-8"><title>#' + posAdjSlipEsc(sale.id) + '</title>' +
                '<style>@page{size:80mm auto;margin:3mm;}body{font-family:Tahoma,Arial,sans-serif;direction:rtl;width:72mm;margin:0 auto;font-size:13px;color:#111;}h2{margin:0 0 6px;font-size:16px;} .muted{color:#555;font-size:12px;}</style></head><body>' +
                (shop ? ('<div style="text-align:center;font-weight:800;">' + posAdjSlipEsc(shop) + '</div>') : '') +
                '<h2 style="text-align:center;">' + posAdjSlipEsc(kind) + '</h2>' +
                '<div style="text-align:center;font-weight:800;margin-bottom:8px;">#' + posAdjSlipEsc(sale.id) + '</div>' +
                (when ? ('<div class="muted" style="text-align:center;">' + posAdjSlipEsc(when) + '</div>') : '') +
                (wh ? ('<div style="text-align:center;font-weight:800;color:#0f766e;margin:8px 0;"><i></i> ' + posAdjSlipEsc(tf ? (t('sale_hist_warehouse') || 'کوگەه') : 'کوگەه') + ': ' + posAdjSlipEsc(wh) + '</div>') : '') +
                (stockNote ? ('<div style="text-align:center;font-weight:700;margin:6px 0 10px;">' + posAdjSlipEsc(stockNote) + '</div>') : '') +
                itemsHtml +
                '<div class="muted" style="text-align:center;margin-top:10px;">' + posAdjSlipEsc(tf ? (t('sale_hist_slip_footer') || 'چاپا گۆڕانێ — نە وەسڵا فرۆتنێ') : 'چاپا گۆڕانێ — نە وەسڵا فرۆتنێ') + '</div>' +
                '</body></html>';
        }
        function printSaleAdjustmentSlip(id, editsOverride) {
            if (id == null || id === '') return;
            var go = function(sale, edits) {
                if (!sale) {
                    if (typeof showToast === 'function') showToast('⚠️ وەسڵ نەدۆزرایەوە', 'warning');
                    return;
                }
                var html = buildSaleAdjustmentSlipHtml(sale, edits);
                if (typeof printWithOptionalNote === 'function') {
                    printWithOptionalNote({
                        docType: 'pos_sale',
                        docId: sale.id,
                        details: 'adjustment-slip',
                        skipNotePopup: true,
                        docLabel: (typeof t === 'function' ? t('sale_hist_print_adjust') : 'چاپا تەعدیل / ژێبرن') + ' #' + sale.id,
                        buildHtml: function() { return html; }
                    });
                } else if (typeof printContent === 'function') {
                    printContent(html);
                }
            };
            var afterSale = function(sale) {
                if (editsOverride) {
                    go(sale, editsOverride);
                    return;
                }
                var needEdits = sale && (Number(sale.has_edits) === 1 || Number(sale.edit_count) > 0);
                if (!needEdits) {
                    go(sale, []);
                    return;
                }
                var q = 'action=get_sale_edits_history&sale_id=' + encodeURIComponent(id) + '&limit=80';
                var url = (typeof window.posRouterUrl === 'function') ? window.posRouterUrl(q) : ('?' + q);
                fetch(url, { credentials: 'same-origin', cache: 'no-store' })
                    .then(function(r) { return r.json().catch(function() { return {}; }); })
                    .then(function(data) { go(sale, (data && data.edits) || []); })
                    .catch(function() { go(sale, []); });
            };
            if (typeof withSaleRecord === 'function') {
                withSaleRecord(id, afterSale);
            } else {
                var sale = (typeof db !== 'undefined' && db && db.sales || []).find(function(s) { return String(s.id) === String(id); });
                afterSale(sale || null);
            }
        }
        function printPurchaseAdjustmentSlip(txnId, editsOverride) {
            txnId = String(txnId || '').trim();
            if (!txnId) return;
            var pickInv = function () {
                var list = window._gphInvoices || [];
                for (var i = 0; i < list.length; i++) {
                    if (String(list[i].txnId || '') === txnId) return list[i];
                }
                return null;
            };
            var invToSale = function (inv) {
                if (!inv) return null;
                var adj = (typeof posPurchaseInvAdj === 'function') ? posPurchaseInvAdj(inv) : {};
                var items = (inv.items || []).map(function (it) {
                    return {
                        name: it.itemName || it.name || 'ئایتم',
                        qty: it.qtyAdded != null ? it.qtyAdded : it.qty,
                        count: it.qtyAdded != null ? it.qtyAdded : it.qty,
                        warehouse_name: it.warehouse_name || ''
                    };
                });
                return {
                    id: inv.invNum || txnId,
                    date: inv.date,
                    items: items,
                    is_returned: inv.is_voided ? 1 : 0,
                    has_return: adj.has_return ? 1 : 0,
                    has_edits: adj.has_edits ? 1 : 0,
                    warehouse_name: ''
                };
            };
            var go = function (sale, edits) {
                if (!sale) {
                    if (typeof showToast === 'function') showToast('⚠️ وەسڵ نەدۆزرایەوە', 'warning');
                    return;
                }
                var html = buildSaleAdjustmentSlipHtml(sale, edits);
                if (typeof printWithOptionalNote === 'function') {
                    printWithOptionalNote({
                        docType: 'purchase_invoice',
                        docId: txnId,
                        details: 'adjustment-slip',
                        skipNotePopup: true,
                        docLabel: (typeof t === 'function' ? t('sale_hist_print_adjust') : 'چاپا تەعدیل / ژێبرن') + ' ' + (sale.id || txnId),
                        buildHtml: function () { return html; }
                    });
                } else if (typeof printContent === 'function') {
                    printContent(html);
                }
            };
            var inv = pickInv();
            var sale = invToSale(inv);
            if (editsOverride) {
                go(sale, editsOverride);
                return;
            }
            var adj = (typeof posPurchaseInvAdj === 'function') ? posPurchaseInvAdj(inv || {}) : {};
            var needEdits = !!(adj.has_edits || Number(adj.edit_count) > 0);
            if (!needEdits) {
                go(sale, []);
                return;
            }
            var q = 'action=get_purchase_edits_history&txn_id=' + encodeURIComponent(txnId) + '&limit=80';
            var url = (typeof window.posRouterUrl === 'function') ? window.posRouterUrl(q) : ('?' + q);
            fetch(url, { credentials: 'same-origin', cache: 'no-store' })
                .then(function (r) { return r.json().catch(function () { return {}; }); })
                .then(function (data) { go(sale, (data && data.edits) || []); })
                .catch(function () { go(sale, []); });
        }
        if (typeof window !== 'undefined') window.printPurchaseAdjustmentSlip = printPurchaseAdjustmentSlip;
        function reprintBill(id, opts) {
            if (id == null || id === '') {
                if (typeof showToast === 'function') showToast('⚠️ وەسڵ نەدۆزرایەوە بۆ چاپکرن', 'warning');
                return;
            }
            withSaleRecord(id, function(sale) {
                if (!sale) {
                    if (typeof showToast === 'function') showToast('⚠️ وەسڵ نەدۆزرایەوە بۆ چاپکرن', 'warning');
                    return;
                }
                reprintBillWithSale(sale, opts);
            });
        }
        function reprintBillWithSale(sale, opts) {
            if (!sale) return;
            if (typeof enrichSaleForPrint === 'function') enrichSaleForPrint(sale);
            const id = sale.id;
            if (!Array.isArray(sale.items)) sale.items = [];
            if (!sale.items.length) {
                if (typeof showToast === 'function') showToast('⚠️ ئایتمێن وەسڵێ نەهاتنە دیتن — چاپ نابیت', 'warning');
                return;
            }
            const saleFxOpts = (typeof fxUsdRateFormatOpts === 'function') ? fxUsdRateFormatOpts(sale) : undefined;
            const reprintCfg = resolveReprintPosCfg(opts);

            if (isA4PrintPaper(reprintCfg.paper)) {
                var a4ReprintBase = typeof buildPosSaleA4Html === 'function' ? buildPosSaleA4Html(sale) : '';
                if (a4ReprintBase && typeof printWithOptionalNote === 'function') {
                    printWithOptionalNote({
                        docType: 'pos_sale',
                        docId: sale.id,
                        details: 'reprint-a4',
                        skipNotePopup: true,
                        docLabel: (typeof t === 'function' ? t('print_copy_reprint') : 'دووبارە چاپ') + ' · ' + (typeof t === 'function' ? t('pds_card_pos_sale_title') : ''),
                        buildHtml: function(note) {
                            return typeof finalizePrintHtmlWithNote === 'function' ? finalizePrintHtmlWithNote(a4ReprintBase, note || '') : a4ReprintBase;
                        }
                    });
                } else if (a4ReprintBase) {
                    printContent(a4ReprintBase);
                } else if (typeof showToast === 'function') {
                    showToast('⚠️ دروستکرنا وەسڵێ A4 شکەست', 'error');
                }
                return;
            }

            const grouped = {};
            var getQty = (typeof getItemQty === 'function')
                ? getItemQty
                : (typeof getSaleLineQty === 'function' ? getSaleLineQty : function(i) {
                    var q = parseFloat(i && (i.qty != null ? i.qty : i.count));
                    return (!isNaN(q) && q > 0) ? q : 1;
                });
            sale.items.forEach(function(i) {
                const key = i.id + '_' + (i.note || '') + '_' + i.price + '_' + (i.saleUnit || 'piece') + '_' + (i.isGift ? 'gift' : 'normal');
                if (!grouped[key]) grouped[key] = { id: i.id, name: i.name, price: i.price, count: 0, sub: 0, note: i.note, saleUnit: i.saleUnit || 'piece', isGift: !!i.isGift, productRef: i.productRef || null };
                var rq = getQty(i);
                grouped[key].count += rq;
                grouped[key].sub += (i.isGift ? 0 : (Number(i.price) || 0)) * rq;
            });

            if (sale && sale.id != null) {
                var debtSnap80 = (typeof resolveSaleDebtBreakdown === 'function') ? resolveSaleDebtBreakdown(sale) : null;
                if (debtSnap80) {
                    sale.debt_added = debtSnap80.debtAdded;
                    sale.cash_paid = debtSnap80.cashPaid;
                    sale.previous_debt = debtSnap80.previousDebt;
                    sale.total_outstanding_debt = debtSnap80.totalOutstandingDebt;
                }
            }

            var billHtml = buildPosSaleReceiptHtml(sale, grouped, {
                printSaleFx: saleFxOpts,
                subTotal: (sale.total || 0) + (sale.discount || 0),
                discount: sale.discount || 0,
                discountPercent: sale.discountPercent || 0,
                isReprint: true,
                posCfg: reprintCfg
            });
            if (!billHtml) {
                if (typeof showToast === 'function') showToast('⚠️ دروستکرنا وەسڵێ شکەست', 'error');
                return;
            }
            if (typeof printWithOptionalNote === 'function') {
                printWithOptionalNote({
                    docType: 'pos_sale',
                    docId: sale.id,
                    details: 'reprint-thermal',
                    skipNotePopup: true,
                    docLabel: (typeof t === 'function' ? t('print_copy_reprint') : 'دووبارە چاپ') + ' · ' + (typeof t === 'function' ? t('pds_card_pos_sale_title') : ''),
                    buildHtml: function(note) {
                        return typeof finalizeThermalSaleBill === 'function' ? finalizeThermalSaleBill(billHtml, note || '') : billHtml;
                    }
                });
            } else {
                printContent(typeof finalizeThermalSaleBill === 'function' ? finalizeThermalSaleBill(billHtml, '') : billHtml);
            }
        }

        // --- A4 Invoice: shared data and 3 templates (Classic, Minimal, Premium) ---
        function formatA4SaleIqdPlain(iqd) {
            return '<span dir="ltr" data-allow-iqd="1">' + Number(Math.round(Number(iqd) || 0)).toLocaleString('en-US') + ' د.ع</span>';
        }
        function posA4ShowBothCurrencies() {
            try {
                return !!(typeof db !== 'undefined' && db && db.settings && db.settings.showBothCurrenciesOnA4 === true);
            } catch (eBoth) {
                return false;
            }
        }
        function formatA4SaleUsdPlain(usd) {
            if (typeof formatUsdNumberPlain === 'function') return formatUsdNumberPlain(usd);
            var n = Math.round((Number(usd) || 0) * 100) / 100;
            var cents = Math.round(Math.abs(n) * 100) % 100;
            return cents === 0
                ? Math.round(n).toLocaleString('en-US')
                : n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        }
        /** USD with $ prefix — use only for primary basket USD amounts on A4. */
        function formatA4SaleUsdTagged(usd) {
            return '$ ' + formatA4SaleUsdPlain(usd);
        }
        /** Secondary IQD hint line under USD grand total (never prefix with $). */
        function formatA4SaleIqdHintHtml(d) {
            if (!d || !d.showUsd || !d.showAltCurrency) return '';
            if (d.isUsdMode) {
                return '<div class="a4-iqd-hint" data-allow-iqd="1">' + formatA4SaleIqdPlain(d.invoiceIqd) + '</div>';
            }
            return '<div class="a4-usd-hint">≈ $' + formatA4SaleUsdPlain(d.usdAmount) + ' USD</div>';
        }
        /** Grand / subtotal row: USD tagged in USD mode; IQD + IQD label in IQD mode. */
        function formatA4SaleGrandPrimaryHtml(d, iqdAmount) {
            iqdAmount = iqdAmount != null ? iqdAmount : (d ? d.total : 0);
            if (d && d.isUsdMode && d.showUsd) {
                var usdVal = d.usdAmount;
                if (iqdAmount !== d.total && d.subTotal > 0 && d.subtotalUsd > 0) {
                    usdVal = (Number(iqdAmount) || 0) * d.subtotalUsd / d.subTotal;
                }
                return formatA4SaleUsdTagged(usdVal);
            }
            return formatCurrency(iqdAmount, d && d.formatFxOpts) + ' ' + (typeof getCurrencySymbol === 'function' ? getCurrencySymbol() : '');
        }
        /** Line money: in USD mode use frozen basket bill_unit_usd (not warehouse FX conversion). */
        function formatA4SaleLineMoney(line, d, kind) {
            if (line && line.isGift) {
                return (typeof t === 'function') ? t('pos_gift_label') : 'دیاری';
            }
            var qty = parseFloat(line && line.qty) || 0;
            if (d && d.isUsdMode && line && line.bill_unit_usd != null && line.bill_unit_usd !== '' && !isNaN(parseFloat(line.bill_unit_usd))) {
                var u = parseFloat(line.bill_unit_usd);
                var amt = (kind === 'total') ? (u * qty) : u;
                return formatA4SaleUsdTagged(amt);
            }
            if (d && d.isUsdMode && d.usdRateDisplay > 0) {
                var iqdLine = kind === 'total' ? (Number(line.total) || 0) : (Number(line.price) || 0);
                return formatA4SaleUsdTagged(iqdLine / d.usdRateDisplay);
            }
            return formatCurrency(kind === 'total' ? (line.total || 0) : (line.price || 0), d && d.formatFxOpts);
        }
        function formatA4SaleTotalPrimary(d) {
            if (d && d.isUsdMode && d.showUsd) {
                var usdHtml = formatA4SaleUsdTagged(d.usdAmount);
                if (d.showAltCurrency) {
                    usdHtml += ' <span class="a4-pay-iqd-hint" data-allow-iqd="1">(' + formatA4SaleIqdPlain(d.invoiceIqd) + ')</span>';
                }
                return usdHtml;
            }
            return formatCurrency(d.total, d.formatFxOpts) + ' ' + (typeof getCurrencySymbol === 'function' ? getCurrencySymbol() : '');
        }
        /** Invoice dates: day/month/year + 24h Baghdad (never US M/D/Y or AM/PM). */
        function formatA4InvoiceDateParts(dateInput) {
            var d = null;
            if (dateInput == null || dateInput === '') d = new Date();
            else if (typeof parseSQLDate === 'function') d = parseSQLDate(dateInput);
            else d = (dateInput instanceof Date) ? dateInput : new Date(dateInput);
            if (!d || isNaN(d.getTime())) d = new Date();
            var pad = function(n) { n = parseInt(n, 10) || 0; return (n < 10 ? '0' : '') + n; };
            if (typeof getPosTimezoneParts === 'function') {
                var p = getPosTimezoneParts(d);
                return {
                    dateStr: pad(p.day) + '/' + pad(p.month) + '/' + p.year,
                    timeStr: pad(p.hour) + ':' + pad(p.minute)
                };
            }
            return {
                dateStr: pad(d.getDate()) + '/' + pad(d.getMonth() + 1) + '/' + d.getFullYear(),
                timeStr: pad(d.getHours()) + ':' + pad(d.getMinutes())
            };
        }
        function lookupSaleCustomerBalance(sale) {
            var targetId = (sale && sale.customer_id && parseInt(sale.customer_id, 10) > 0) ? parseInt(sale.customer_id, 10) : 0;
            if (targetId <= 0 || typeof db === 'undefined' || !db) return 0;
            var targetType = String((sale && sale.customer_type) || '');
            try {
                if (targetType === 'user') {
                    var u = (db.users || []).find(function(x) { return Number(x.id) === targetId; });
                    return parseFloat(u && u.balance) || 0;
                }
                var c = (db.customers || []).find(function(x) { return Number(x.id) === targetId; });
                return parseFloat(c && c.balance) || 0;
            } catch (_eBal) {
                return 0;
            }
        }
        /** کۆیا قەرز = قەرزی پێشوو + قەرزی نوی. Stored 0 after instant print is treated as missing. */
        function resolveSaleDebtBreakdown(sale) {
            sale = sale || {};
            var targetId = (sale.customer_id && parseInt(sale.customer_id, 10) > 0) ? parseInt(sale.customer_id, 10) : 0;
            var targetType = (sale.customer_type || '').toString();
            var debtAdded = (sale.debt_amount != null) ? parseFloat(sale.debt_amount) : ((sale.debt_added != null) ? parseFloat(sale.debt_added) : NaN);
            var cashPaid = (sale.paid_amount != null) ? parseFloat(sale.paid_amount) : ((sale.cash_paid != null) ? parseFloat(sale.cash_paid) : NaN);
            var previousDebt = (sale.previous_debt != null && sale.previous_debt !== '') ? parseFloat(sale.previous_debt) : NaN;
            var storedTotal = (sale.total_outstanding_debt != null && sale.total_outstanding_debt !== '') ? parseFloat(sale.total_outstanding_debt) : NaN;

            if ((isNaN(debtAdded) || debtAdded == null) && targetId > 0 && db && db.customer_ledger) {
                debtAdded = db.customer_ledger
                    .filter(function(l) {
                        return String(l.receipt_id) === String(sale.id) && l.type === 'sale' && Number(l.target_id) === targetId && String(l.target_type) === targetType;
                    })
                    .reduce(function(s, l) { return s + (parseFloat(l.amount) || 0); }, 0);
            }
            if (isNaN(cashPaid) && db && db.ledger) {
                cashPaid = db.ledger
                    .filter(function(l) { return l.type === 'sale' && Number(l.related_id) === Number(sale.id); })
                    .reduce(function(s, l) { return s + (parseFloat(l.amount) || 0); }, 0);
            }
            debtAdded = isNaN(debtAdded) ? 0 : debtAdded;
            if (isNaN(cashPaid)) cashPaid = Math.max(0, (parseFloat(sale.total) || 0) - debtAdded);

            if (!isNaN(previousDebt) && previousDebt < 0) previousDebt = 0;
            var storedTotalValid = !isNaN(storedTotal) && (debtAdded <= 0 || storedTotal + 0.5 >= debtAdded);
            var storedPrevValid = !isNaN(previousDebt) && previousDebt >= -0.01;

            if (!storedTotalValid || !storedPrevValid) {
                var currentDebt = lookupSaleCustomerBalance(sale);
                if (!storedPrevValid) {
                    previousDebt = (currentDebt + 0.5 >= debtAdded) ? (currentDebt - debtAdded) : currentDebt;
                    if (previousDebt < 0) previousDebt = 0;
                }
                storedTotal = previousDebt + debtAdded;
            }
            if (isNaN(previousDebt) || previousDebt < 0) previousDebt = 0;
            if (isNaN(storedTotal) || storedTotal < previousDebt + debtAdded) storedTotal = previousDebt + debtAdded;
            if (debtAdded > 0 && storedTotal < debtAdded) storedTotal = previousDebt + debtAdded;

            return {
                cashPaid: cashPaid || 0,
                debtAdded: debtAdded || 0,
                previousDebt: previousDebt || 0,
                totalOutstandingDebt: storedTotal || 0
            };
        }
        if (typeof window !== 'undefined') {
            window.formatA4InvoiceDateParts = formatA4InvoiceDateParts;
            window.resolveSaleDebtBreakdown = resolveSaleDebtBreakdown;
        }
        function buildA4InvoiceData(sale) {
            const groupedItems = {};
            if (sale.items) {
                sale.items.forEach(i => {
                    const isGiftFlag = !!i.isGift;
                    const key = i.id + '_' + (i.price) + '_' + (i.note || '') + '_' + (i.saleUnit || 'piece') + '_' + (isGiftFlag ? 'gift' : 'normal');
                    if(!groupedItems[key]) groupedItems[key] = { ...i, qty: 0, total: 0, isGift: isGiftFlag };
                    groupedItems[key].qty += getItemQty(i);
                    groupedItems[key].total += (Number(i.price) || 0) * getItemQty(i);
                    if (i.bill_unit_usd != null && groupedItems[key].bill_unit_usd == null) {
                        groupedItems[key].bill_unit_usd = i.bill_unit_usd;
                    }
                });
            }
            const items = Object.values(groupedItems).map(it => {
                return {
                    ...it,
                    name: (typeof getSaleItemPlainName === 'function') ? getSaleItemPlainName(it) : String(it.name || '').replace(/<[^>]*>/g, '').trim(),
                    total: it.isGift ? 0 : it.total,
                    price: it.price,
                    giftValue: it.isGift ? it.total : 0
                };
            });
            const subTotal = sale.total + (sale.discount || 0);
            const rawFx = (sale.fx_usd_rate != null && Number(sale.fx_usd_rate) >= 1000)
                ? Math.round(Number(sale.fx_usd_rate))
                : ((db.settings && db.settings.usdRate) ? Math.round(Number(db.settings.usdRate)) : 0);
            const usdRate = rawFx > 0 ? rawFx / 100 : 0;
            const formatFxOpts = rawFx >= 1000 ? { fxUsdRate: rawFx } : undefined;
            const isUsdMode = (typeof isUsdMoneySystem === 'function')
                ? isUsdMoneySystem()
                : (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
            const basketMoney = (typeof resolveSaleBasketPrintMoney === 'function')
                ? resolveSaleBasketPrintMoney(sale, items)
                : { hasBasketUsd: false, usdNet: 0, basketIqd: sale.total, visualPerOne: 0, visualRate100: 0 };
            let showUsd = false;
            let usdAmount = '';
            let invoiceIqd = Math.round(parseFloat(sale.total) || 0);
            let usdRateDisplay = 0;
            var subtotalUsd = 0;
            var discountUsd = 0;
            items.forEach(function(it) {
                if (!it || it.isGift) return;
                var q = typeof getItemQty === 'function' ? getItemQty(it) : (parseFloat(it.qty || it.count) || 0);
                if (it.bill_unit_usd != null && it.bill_unit_usd !== '' && !isNaN(parseFloat(it.bill_unit_usd))) {
                    subtotalUsd += parseFloat(it.bill_unit_usd) * q;
                }
            });
            if (isUsdMode) {
                // Basket USD + visual IQD only — do not re-convert with warehouse FX (skews stock).
                showUsd = true;
                if (basketMoney.hasBasketUsd) {
                    usdAmount = basketMoney.usdNet;
                    invoiceIqd = basketMoney.basketIqd;
                } else if (usdRate > 0) {
                    usdAmount = sale.total / usdRate;
                } else {
                    usdAmount = 0;
                }
                if (subtotalUsd <= 0 && usdAmount > 0 && (sale.discount || 0) > 0) {
                    subtotalUsd = usdAmount + (usdAmount * ((sale.discount || 0) / Math.max(1, sale.total)));
                } else if (subtotalUsd <= 0) {
                    subtotalUsd = usdAmount + discountUsd;
                }
                discountUsd = Math.max(0, subtotalUsd - (Number(usdAmount) || 0));
                usdRateDisplay = basketMoney.visualPerOne > 0
                    ? Math.round(basketMoney.visualPerOne)
                    : (usdRate > 0 ? Math.round(usdRate) : 0);
            } else {
                showUsd = usdRate > 0;
                usdAmount = showUsd ? (sale.total / usdRate) : '';
                usdRateDisplay = usdRate > 0 ? Math.round(usdRate) : 0;
            }
            const displaySaleId = (typeof formatSaleIdForDisplay === 'function')
                ? formatSaleIdForDisplay(sale.id)
                : String(sale.id || '---');
            let barcodeImg = '';
            if (typeof getPrintInvoiceBarcodeEnabled === 'function' ? getPrintInvoiceBarcodeEnabled() : true) {
                try {
                    const canvas = document.createElement('canvas');
                    if(typeof JsBarcode !== 'undefined') {
                        var barcodeVal = String(displaySaleId).replace(/\D/g, '') || String(sale.id || '');
                        JsBarcode(canvas, barcodeVal, { format: "CODE128", displayValue: false, height: 25, margin: 0, width: 1.5, lineColor: "#334155" });
                        barcodeImg = canvas.toDataURL("image/png");
                    }
                } catch(e) {}
            }
            const brand = '#0E4AFF';
            const contact = (typeof getReceiptContactInfo === 'function') ? getReceiptContactInfo() : { phone: '', address: '', social: '' };
            const a4DateParts = formatA4InvoiceDateParts(sale.date);
            const debtSnap = resolveSaleDebtBreakdown(sale);
            const debtAdded = debtSnap.debtAdded;
            const cashPaid = debtSnap.cashPaid;
            const previousDebt = debtSnap.previousDebt;
            const totalOutstandingDebt = debtSnap.totalOutstandingDebt;

            return {
                sale, displaySaleId, items, subTotal, discount: sale.discount || 0, discountPercent: sale.discountPercent || 0, total: sale.total, formatFxOpts,
                isUsdMode: !!isUsdMode,
                invoiceIqd: invoiceIqd,
                subtotalUsd: subtotalUsd,
                discountUsd: discountUsd,
                logoHtml: (typeof getPosShopLogoUrl === 'function' && getPosShopLogoUrl()) ? `<img src="${getPosShopLogoUrl()}" style="max-height: 80px; max-width: 150px; object-fit: contain;">` : '',
                cafeName: (db.settings && db.settings.cafeName) || 'Store',
                cafeInfo: (db.settings && db.settings.cafeInfo) || '',
                footer: (db.settings && db.settings.footer) || (typeof t === 'function' ? t('print_thank_you') : 'سوپاس بۆ مامەڵەکرن دگەل مە.'),
                invoiceNote: (db.settings && db.settings.invoiceNote) ? escapeHtml(db.settings.invoiceNote) : '',
                customNote: (db.settings && db.settings.customNote) ? escapeHtml(db.settings.customNote) : '',
                staticNote1: (db.settings && db.settings.staticNote1) ? escapeHtml(db.settings.staticNote1) : '',
                staticNote2: (db.settings && db.settings.staticNote2) ? escapeHtml(db.settings.staticNote2) : '',
                staticNote3: (db.settings && db.settings.staticNote3) ? escapeHtml(db.settings.staticNote3) : '',
                barcodeImg, showUsd, usdAmount,
                showAltCurrency: posA4ShowBothCurrencies(),
                primaryColor: brand, accentColor: '#0d9488', borderColor: '#e2e8f0', lightBg: '#f1f5f9',
                statusPaid: (debtAdded > 0 && cashPaid > 0)
                    ? (typeof t === 'function' && t('print_status_split') && t('print_status_split') !== 'print_status_split' ? t('print_status_split') : 'نەقد و قەرز (تێکەڵ)')
                    : ((debtAdded > 0 || sale.payment_method === 'debt')
                        ? (typeof t === 'function' ? t('print_status_unpaid') : 'UNPAID (قەرز)')
                        : (typeof t === 'function' ? (t('payment_method_cash') || 'کاش') : 'کاش')),
                statusColor: (debtAdded > 0 && cashPaid > 0) ? '#f59e0b' : ((debtAdded > 0 || sale.payment_method === 'debt') ? '#ef4444' : '#10b981'),
                dateStr: a4DateParts.dateStr,
                timeStr: a4DateParts.timeStr,
                contactPhone: contact.phone ? escapeHtml(contact.phone) : '',
                contactAddress: contact.address ? escapeHtml(contact.address) : '',
                contactSocial: contact.social ? escapeHtml(contact.social) : '',
                posBlue: '#0E4AFF',
                posBlueDark: '#0A3BCC',
                posTeal: '#14b8a6',
                posInk: '#0f172a',
                posMuted: '#64748b',
                customerName: escapeHtml((typeof resolveSaleCustomerName === 'function' ? resolveSaleCustomerName(sale) : (sale.customer || '')) || (typeof t === 'function' ? t('print_customer_general') : 'گشتی')),
                termsLabel: typeof t === 'function' ? t('print_terms') : 'مەرج و ڕێکەوتن',
                thankYou: typeof t === 'function' ? t('print_thank_you') : 'سوپاس بۆ مامەڵەکرن',
                signatureLabel: typeof t === 'function' ? t('print_signature') : 'واژووی بەرپرسیار',
                signatureLabelShort: typeof t === 'function' ? t('print_signature_short') : 'ئیمزا',
                thItem: typeof t === 'function' ? t('th_item') : 'ئایتم',
                thPackaging: typeof t === 'function' ? t('th_packaging') : 'پێکهاتە',
                thUnit: typeof t === 'function' ? t('th_unit') : 'یەکە',
                thQty: typeof t === 'function' ? t('th_qty') : 'ژمارە',
                thPrice: typeof t === 'function' ? (t('th_unit_price') || t('th_price')) : 'نرخی یەکە',
                thTotal: typeof t === 'function' ? t('th_total') : 'کۆم',
                printInvoiceLabel: typeof t === 'function' ? t('print_invoice') : 'وەسڵ',
                printCustomerLabel: typeof t === 'function' ? t('print_customer') : 'کریار',
                printStatusLabel: typeof t === 'function' ? t('print_status') : 'دۆخ',
                printSubtotalLabel: typeof t === 'function' ? t('print_subtotal') : 'کۆیا گشتی',
                printDiscountLabel: typeof t === 'function' ? t('print_discount') : 'داشکاندن',
                printNetTotalLabel: typeof t === 'function' ? t('print_net_total') : 'کۆی سافی',
                printStampLabel: typeof t === 'function' ? t('print_stamp') : 'مورا لسەر کاخەزێ'
                ,
                design3LogoLayout: (db.settings && db.settings.a4Design3LogoLayout) ? String(db.settings.a4Design3LogoLayout) : 'center',
                design3LogoLeft: (db.settings && db.settings.a4Design3LogoLeft) ? String(db.settings.a4Design3LogoLeft) : '',
                design3LogoCenter: (db.settings && db.settings.a4Design3LogoCenter) ? String(db.settings.a4Design3LogoCenter) : '',
                design3LogoRight: (db.settings && db.settings.a4Design3LogoRight) ? String(db.settings.a4Design3LogoRight) : '',
                mainLogo: (typeof getPosShopLogoUrl === 'function') ? getPosShopLogoUrl() : ((db.settings && db.settings.logo) ? String(db.settings.logo) : ''),
                debtBreakdown: {
                    grandTotal: sale.total,
                    cashPaid: cashPaid || 0,
                    debtAdded: debtAdded || 0,
                    previousDebt: previousDebt || 0,
                    totalOutstandingDebt: totalOutstandingDebt || 0
                },
                cashierName: escapeHtml(String(sale.cashier || sale.user || ((typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : '') || '')),
                customerPhone: (function() {
                    var ph = '';
                    try {
                        var cid = sale.customer_id && parseInt(sale.customer_id, 10) > 0 ? parseInt(sale.customer_id, 10) : 0;
                        if (cid > 0 && db && Array.isArray(db.customers)) {
                            var c = db.customers.find(function(x) { return Number(x.id) === cid; });
                            if (c) ph = String(c.phone || c.mobile || c.tel || '').trim();
                        }
                        if (!ph && sale.customer_phone) ph = String(sale.customer_phone).trim();
                    } catch (_ePh) {}
                    return ph ? escapeHtml(ph) : '';
                })(),
                customerIdDisplay: (sale.customer_id && parseInt(sale.customer_id, 10) > 0) ? String(parseInt(sale.customer_id, 10)) : '',
                usdRateDisplay: usdRateDisplay,
                paymentMethodLabel: (function() {
                    var pm = String(sale.payment_method || 'cash');
                    if (debtAdded > 0 && cashPaid > 0) return (typeof t === 'function' && t('print_status_split') && t('print_status_split') !== 'print_status_split' ? t('print_status_split') : 'نەقد و قەرز (تێکەڵ)');
                    if (pm === 'debt' || debtAdded > 0) return (typeof t === 'function' ? (t('payment_method_debt') || 'قەرز') : 'قەرز');
                    return (typeof t === 'function' ? (t('payment_method_cash') || 'پارەدانی کاش') : 'پارەدانی کاش');
                })()
            };
        }
        function a4InvoiceFont() {
            return "'Rudaw', sans-serif";
        }
        function buildA4LogoStripHtml(d, boxPx) {
            boxPx = boxPx || 76;
            const renderLogoBox = function(url) {
                if (!url) return '<span class="a4-logo-slot a4-logo-slot--empty"></span>';
                return '<span class="a4-logo-slot a4-logo-slot--png"><img src="' + url + '" alt="" class="a4-png-logo" decoding="async"></span>';
            };
            const layout = (d.design3LogoLayout || 'center');
            const mainLogo = d.mainLogo || '';
            const leftLogo = d.design3LogoLeft || mainLogo;
            const centerLogo = d.design3LogoCenter || mainLogo;
            const rightLogo = d.design3LogoRight || mainLogo;
            const wrap = function(inner) { return '<div class="a4-logo-strip a4-logo-strip--png" data-size="' + boxPx + '">' + inner + '</div>'; };
            if (layout === 'left-right') return wrap(renderLogoBox(leftLogo) + renderLogoBox(rightLogo));
            if (layout === 'left-center-right') return wrap(renderLogoBox(leftLogo) + renderLogoBox(centerLogo) + renderLogoBox(rightLogo));
            if (layout === 'left-center') return wrap(renderLogoBox(leftLogo) + renderLogoBox(centerLogo));
            if (layout === 'center-right') return wrap(renderLogoBox(centerLogo) + renderLogoBox(rightLogo));
            if (layout === 'left') return wrap(renderLogoBox(leftLogo));
            if (layout === 'right') return wrap('<span class="a4-logo-strip-spacer"></span>' + renderLogoBox(rightLogo));
            if (layout === 'none') return '';
            return wrap(renderLogoBox(centerLogo || mainLogo));
        }
        /** Centered hero PNG logo for A4 designs (crisp, transparent-friendly). */
        function buildA4PngHeroLogoHtml(d, opts) {
            opts = opts || {};
            var url = (d && (opts.url || d.mainLogo || d.design3LogoCenter)) || '';
            if (!url && typeof getPosShopLogoUrl === 'function') url = getPosShopLogoUrl();
            if (url && typeof absAssetUrl === 'function' && !/^(data:|blob:|https?:|\/\/)/i.test(String(url))) {
                url = absAssetUrl(url);
            }
            var cls = opts.className || 'a4-png-hero';
            if (!url) {
                return '<div class="' + cls + ' a4-png-hero--empty"><i class="fas fa-store"></i><span>' +
                    escapeHtml((d && d.cafeName) || 'Store') + '</span></div>';
            }
            return '<div class="' + cls + '"><img src="' + url + '" alt="" class="a4-png-logo a4-png-hero-img" decoding="async"></div>';
        }
        if (typeof window !== 'undefined') window.buildA4PngHeroLogoHtml = buildA4PngHeroLogoHtml;
        function buildA4ContactLinesHtml(d) {
            const parts = [];
            if (d.contactPhone) parts.push('<span class="a4-contact-item">☎ ' + d.contactPhone + '</span>');
            if (d.contactAddress) parts.push('<span class="a4-contact-item">📍 ' + d.contactAddress + '</span>');
            if (d.contactSocial) parts.push('<span class="a4-contact-item">' + d.contactSocial + '</span>');
            if (!parts.length && d.cafeInfo) parts.push('<span class="a4-contact-item">' + d.cafeInfo + '</span>');
            return parts.length ? '<div class="a4-contact-lines">' + parts.join('') + '</div>' : '';
        }
        function buildA4StatusBadgeHtml(d) {
            return '<span class="a4-status-badge" style="--a4-status:' + d.statusColor + ';">' + d.statusPaid + '</span>';
        }
        function buildA4ItemRowsHtml(d, variant) {
            return d.items.map(function(i, idx) {
                const note = i.note ? '<div class="a4-item-note">' + escapeHtml(i.note) + '</div>' : '';
                const nameCell = (typeof formatSaleItemNameHtml === 'function')
                    ? formatSaleItemNameHtml(i, { skipPriceTypeLabel: true, skipUnitSuffix: true })
                    : escapeHtml(i.name);
                const prod = (typeof resolveSaleLineProduct === 'function') ? resolveSaleLineProduct(i) : null;
                const packLabel = escapeHtml((typeof formatProductPackagingLabel === 'function')
                    ? formatProductPackagingLabel(prod || i)
                    : '—');
                const unitLabel = escapeHtml((typeof getProductUnitLabel === 'function')
                    ? getProductUnitLabel(prod || i, i.saleUnit || 'piece')
                    : (i.saleUnit || '—'));
                const zebra = idx % 2 === 1 ? ' a4-row-alt' : '';
                return '<tr class="a4-item-row' + zebra + '">' +
                    '<td class="a4-td-num">' + (idx + 1) + '</td>' +
                    '<td class="a4-td-item"><div class="a4-item-name">' + nameCell + '</div>' + note + '</td>' +
                    '<td class="a4-td-pack">' + packLabel + '</td>' +
                    '<td class="a4-td-unit">' + unitLabel + '</td>' +
                    '<td class="a4-td-qty">' + i.qty + '</td>' +
                    '<td class="a4-td-money">' + formatA4SaleLineMoney(i, d, 'price') + '</td>' +
                    '<td class="a4-td-money a4-td-total">' + formatA4SaleLineMoney(i, d, 'total') + '</td></tr>';
            }).join('');
        }
        function buildA4TotalsPanelHtml(d, showFinancials) {
            const usdLine = formatA4SaleIqdHintHtml(d);
            let debtHtml = '';
            if (showFinancials && (d.debtBreakdown.debtAdded > 0 || d.debtBreakdown.totalOutstandingDebt > 0)) {
                debtHtml = '<div class="a4-debt-panel">' +
                    '<div class="a4-debt-title">کورتەی قەرز / Debt</div>' +
                    '<div class="a4-debt-row"><span>نەقد</span><b class="a4-debt-cash">' + formatA4SaleGrandPrimaryHtml(d, d.debtBreakdown.cashPaid) + '</b></div>' +
                    '<div class="a4-debt-row"><span>قەرزی نوی</span><b class="a4-debt-new">' + formatA4SaleGrandPrimaryHtml(d, d.debtBreakdown.debtAdded) + '</b></div>' +
                    '<div class="a4-debt-row"><span>قەرزی پێشوو</span><b>' + formatA4SaleGrandPrimaryHtml(d, d.debtBreakdown.previousDebt) + '</b></div>' +
                    '<div class="a4-debt-row a4-debt-row-total"><span>کۆیا قەرزی</span><b>' + formatA4SaleGrandPrimaryHtml(d, d.debtBreakdown.totalOutstandingDebt) + '</b></div>' +
                    '</div>';
            }
            var grandLabel = formatA4SaleGrandPrimaryHtml(d, d.total);
            return '<div class="a4-totals-panel">' +
                '<div class="a4-total-line"><span>' + d.printSubtotalLabel + '</span><b>' + formatA4SaleGrandPrimaryHtml(d, d.subTotal) + '</b></div>' +
                (d.discount > 0 ? '<div class="a4-total-line a4-total-discount"><span>' + d.printDiscountLabel + '</span><b>-' + (d.isUsdMode && d.showUsd && d.discountUsd > 0 ? formatA4SaleUsdTagged(d.discountUsd) : formatA4SaleGrandPrimaryHtml(d, d.discount)) + '</b></div>' : '') +
                '<div class="a4-grand-total"><span>' + d.printNetTotalLabel + '</span><strong>' + grandLabel + '</strong></div>' +
                usdLine + debtHtml +
                (d.barcodeImg ? '<div class="a4-barcode-wrap"><img src="' + d.barcodeImg + '" alt=""></div>' : '') +
                '</div>';
        }
        function buildA4NotesSignaturesHtml(d, sigVariant) {
            const sigClass = sigVariant === 'classic' ? 'a4-sigs a4-sigs-classic' : 'a4-sigs';
            return '<div class="a4-notes-block">' +
                '<h4 class="a4-notes-title">' + d.termsLabel + '</h4>' +
                (d.invoiceNote ? '<p class="a4-note-line">• ' + d.invoiceNote + '</p>' : '') +
                (d.customNote ? '<p class="a4-note-line a4-note-strong">• ' + d.customNote + '</p>' : '') +
                (d.staticNote1 ? '<p class="a4-note-line">• ' + d.staticNote1 + '</p>' : '') +
                (d.staticNote2 ? '<p class="a4-note-line">• ' + d.staticNote2 + '</p>' : '') +
                (d.staticNote3 ? '<p class="a4-note-line">• ' + d.staticNote3 + '</p>' : '') +
                '__NOTE_SLOT__' +
                '<p class="a4-footer-text">' + d.footer + '</p>' +
                '<p class="a4-thank-line">' + d.thankYou + '</p>' +
                '<div class="' + sigClass + '">' +
                '<div class="a4-sig"><div class="a4-sig-line"></div><span>' + d.signatureLabelShort + ' (کریار)</span></div>' +
                '<div class="a4-sig"><div class="a4-sig-line"></div><span>' + d.signatureLabelShort + ' (کۆمپانیا)</span></div>' +
                '</div></div>';
        }
        /** Compact POS sale header — one row, minimal vertical space. */
        function buildPosSaleA4CompactHeader(d, logoPx) {
            var storeLine = d.contactPhone ? '<em>☎ ' + d.contactPhone + '</em>' : (d.cafeInfo ? '<em>' + d.cafeInfo + '</em>' : '');
            var logoPart = '';
            if (logoPx !== 0 && logoPx !== false) {
                logoPx = logoPx || 68;
                logoPart = '<div class="a4-sale-head-logo">' + buildA4LogoStripHtml(d, logoPx) + '</div>';
            }
            return '<div class="a4-sale-head-bar' + (logoPart ? '' : ' a4-sale-head-bar--no-logo') + '">' +
                logoPart +
                '<div class="a4-sale-head-col a4-sale-head-store"><strong>' + escapeHtml(d.cafeName) + '</strong>' + storeLine + '</div>' +
                '<div class="a4-sale-head-col a4-sale-head-doc"><span>' + d.printInvoiceLabel + '</span>' +
                '<b class="a4-sale-inv-num">#' + d.displaySaleId + '</b><em>' + d.dateStr + ' · ' + (d.timeStr || '') +
                ' · <span class="a4-sale-status-pill" style="--a4-status:' + d.statusColor + '">' + d.statusPaid + '</span></em></div>' +
                '<div class="a4-sale-head-col a4-sale-head-customer"><span>' + d.printCustomerLabel + '</span>' +
                '<b>' + d.customerName + '</b><em>' + d.items.length + ' ' + d.thItem + '</em></div></div>';
        }
        function buildPosSaleA4CompactNotesHtml(d) {
            var html = '';
            if (d.invoiceNote) html += '<p class="a4-note-line">' + d.invoiceNote + '</p>';
            if (d.customNote) html += '<p class="a4-note-line">' + d.customNote + '</p>';
            if (d.staticNote1) html += '<p class="a4-note-line">' + d.staticNote1 + '</p>';
            if (d.staticNote2) html += '<p class="a4-note-line">' + d.staticNote2 + '</p>';
            if (d.staticNote3) html += '<p class="a4-note-line">' + d.staticNote3 + '</p>';
            if (d.footer) html += '<p class="a4-note-line a4-note-muted">' + d.footer + '</p>';
            return '<div class="a4-notes-block a4-notes-block--sale-compact">' + html +
                '<div class="a4-sigs-sale-inline"><span>ئیمزا کڕیار: ____</span><span>ئیمزا فرۆشیار: ____</span></div></div>';
        }
        function buildPosSaleA4CompactTotalsHtml(d, showFinancials) {
            var lines = '';
            if (d.discount > 0) {
                lines += '<div class="a4-total-line a4-total-line--compact"><span>' + d.printSubtotalLabel + '</span><b>' + formatA4SaleGrandPrimaryHtml(d, d.subTotal) + '</b></div>';
                lines += '<div class="a4-total-line a4-total-line--compact a4-total-discount"><span>' + d.printDiscountLabel + '</span><b>-' + (d.isUsdMode && d.showUsd && d.discountUsd > 0 ? formatA4SaleUsdTagged(d.discountUsd) : formatA4SaleGrandPrimaryHtml(d, d.discount)) + '</b></div>';
            }
            var debtHtml = '';
            if (showFinancials && (d.debtBreakdown.debtAdded > 0 || d.debtBreakdown.totalOutstandingDebt > 0)) {
                debtHtml = '<div class="a4-debt-panel a4-debt-panel--sale-compact">' +
                    '<div class="a4-debt-row"><span>نەقد</span><b>' + formatA4SaleGrandPrimaryHtml(d, d.debtBreakdown.cashPaid) + '</b></div>' +
                    '<div class="a4-debt-row"><span>قەرزی نوی</span><b>' + formatA4SaleGrandPrimaryHtml(d, d.debtBreakdown.debtAdded) + '</b></div>' +
                    '<div class="a4-debt-row"><span>قەرزی پێشوو</span><b>' + formatA4SaleGrandPrimaryHtml(d, d.debtBreakdown.previousDebt) + '</b></div>' +
                    '<div class="a4-debt-row a4-debt-row-total"><span>کۆیا قەرز</span><b>' + formatA4SaleGrandPrimaryHtml(d, d.debtBreakdown.totalOutstandingDebt) + '</b></div></div>';
            }
            var usdLine = formatA4SaleIqdHintHtml(d);
            return '<div class="a4-totals-panel a4-totals-panel--sale-compact">' + lines +
                '<div class="a4-grand-total a4-grand-total--sale-compact"><span>' + d.printNetTotalLabel + '</span><strong>' +
                formatA4SaleGrandPrimaryHtml(d, d.total) +
                '</strong></div>' +
                usdLine + debtHtml +
                (d.barcodeImg ? '<div class="a4-barcode-wrap a4-barcode-wrap--compact"><img src="' + d.barcodeImg + '" alt=""></div>' : '') +
                '</div>';
        }
        function buildPosSaleA4TableHtml(d, rows, theadClass) {
            return '<div class="a4-table-wrap a4-table-wrap--sale"><table class="inv-table a4-items-table a4-items-sale a4-items-sale--detail ' + theadClass + '"><thead><tr>' +
                '<th class="a4-th-num">#</th>' +
                '<th>' + d.thItem + '</th>' +
                '<th class="a4-th-pack">' + (d.thPackaging || 'پێکهاتە') + '</th>' +
                '<th class="a4-th-unit">' + (d.thUnit || 'یەکە') + '</th>' +
                '<th class="a4-th-qty">' + d.thQty + '</th>' +
                '<th class="a4-th-money">' + d.thPrice + '</th>' +
                '<th class="a4-th-money">' + d.thTotal + '</th></tr></thead><tbody>' + rows + '</tbody></table></div>';
        }
        function buildA4ProLogoHtml(d) {
            if (!d || !d.mainLogo) {
                return '<span class="a4-pro-logo-empty"><i class="fas fa-store"></i></span>';
            }
            return '<img src="' + d.mainLogo + '" alt="" class="a4-pro-logo-img a4-png-logo" decoding="async">';
        }
        function buildA4ProDebtPanelHtml(d, opts) {
            opts = opts || {};
            var show = opts.variant === 'company' ? d.showDebt : (opts.showFinancials && (d.debtBreakdown.debtAdded > 0 || d.debtBreakdown.totalOutstandingDebt > 0));
            if (!show) return '';
            var fx = d.formatFxOpts;
            var dbk = d.debtBreakdown || {};
            var cash = opts.variant === 'company' ? d.cashPaid : dbk.cashPaid;
            var debtAdded = opts.variant === 'company' ? d.debtAdded : dbk.debtAdded;
            var prev = opts.variant === 'company' ? d.previousDebt : dbk.previousDebt;
            var total = opts.variant === 'company' ? d.totalOutstandingDebt : dbk.totalOutstandingDebt;
            var bank = opts.variant === 'company' ? (d.bankPaid || 0) : 0;
            var tf = typeof t === 'function';
            return '<div class="a4-pro-debt">' +
                '<div class="a4-pro-debt-title">' + (tf ? (t('print_debt_summary') || 'کورتەی قەرز') : 'کورتەی قەرز') + '</div>' +
                '<div class="a4-pro-debt-row"><span>' + (tf ? (t('payment_method_cash') || 'نەقد') : 'نەقد') + '</span><b>' + (opts.variant === 'sale' ? formatA4SaleGrandPrimaryHtml(d, cash) : formatCurrency(cash, fx)) + '</b></div>' +
                (bank > 0 ? '<div class="a4-pro-debt-row"><span>Bank</span><b>' + (opts.variant === 'sale' ? formatA4SaleGrandPrimaryHtml(d, bank) : formatCurrency(bank, fx)) + '</b></div>' : '') +
                (debtAdded !== 0 ? '<div class="a4-pro-debt-row"><span>' + (d.isReturn ? 'کەمبوونەوە' : 'قەرزی نوی') + '</span><b>' + (opts.variant === 'sale' ? formatA4SaleGrandPrimaryHtml(d, debtAdded) : formatCurrency(debtAdded, fx)) + '</b></div>' : '') +
                (prev != 0 ? '<div class="a4-pro-debt-row"><span>قەرزی پێشوو</span><b>' + (opts.variant === 'sale' ? formatA4SaleGrandPrimaryHtml(d, prev) : formatCurrency(prev, fx)) + '</b></div>' : '') +
                '<div class="a4-pro-debt-row a4-pro-debt-row-total"><span>کۆیا قەرز</span><b>' + (opts.variant === 'sale' ? formatA4SaleGrandPrimaryHtml(d, total) : formatCurrency(total, fx)) + '</b></div>' +
                '</div>';
        }
        function buildA4InvoiceProHtml(d, opts) {
            opts = opts || {};
            var variant = opts.variant || 'sale';
            var showFinancials = opts.showFinancials !== false;
            var accent = (typeof getA4AccentTheme === 'function') ? getA4AccentTheme() : 'amber';
            var tf = typeof t === 'function';
            var L = function(k, fb) { return tf ? (t(k) || fb) : fb; };
            var retMod = d.isReturn ? ' invoice-a4-company--return' : '';
            var typeMod = variant === 'sale' ? ' invoice-a4-sale' : ' invoice-a4-company';
            var fontFn = variant === 'company' && typeof companyA4Font === 'function' ? companyA4Font() : a4InvoiceFont();
            var docTitle = variant === 'sale'
                ? d.printInvoiceLabel
                : (d.isReturn ? L('print_purchase_return', 'پسوولەی زڤڕاندن') : L('print_purchase_invoice', 'پسوولەی کڕین'));
            var storeExtra = '';
            if (variant === 'sale') {
                if (d.contactPhone) storeExtra = '<div class="a4-contact-lines"><span class="a4-contact-item" dir="ltr">☎ ' + d.contactPhone + '</span></div>';
                if (d.contactAddress) storeExtra += '<div class="a4-contact-lines"><span class="a4-contact-item">📍 ' + d.contactAddress + '</span></div>';
            } else if (typeof buildCompanyA4StoreContactHtml === 'function') {
                storeExtra = buildCompanyA4StoreContactHtml(d);
            }
            var toLabel = variant === 'sale' ? L('print_customer', 'کڕیار') : (d.lblSupplier || L('print_supplier', 'دابینکەر'));
            var toName = variant === 'sale' ? d.customerName : d.companyName;
            var toContact = variant === 'company' && d.companyContact ? '<em dir="ltr">☎ ' + d.companyContact + '</em>' : '';
            var detailsHtml = '';
            if (variant === 'sale') {
                detailsHtml =
                    '<div class="a4-pro-meta-row"><span>' + L('print_invoice_no', 'ژمارەی پسوولە') + '</span><b dir="ltr">#' + d.displaySaleId + '</b></div>' +
                    '<div class="a4-pro-meta-row"><span>' + L('print_date', 'بەروار') + '</span><b>' + d.dateStr + ' · ' + d.timeStr + '</b></div>' +
                    '<div class="a4-pro-meta-row"><span>' + d.printStatusLabel + '</span><b style="color:' + d.statusColor + '">' + d.statusPaid + '</b></div>' +
                    '<div class="a4-pro-meta-row"><span>' + L('print_items_count', 'ژمارەی کاڵا') + '</span><b>' + d.items.length + '</b></div>';
            } else {
                detailsHtml =
                    '<div class="a4-pro-meta-row"><span>' + L('print_invoice_no', 'ژمارەی پسوولە') + '</span><b dir="ltr">#' + d.displayInvoiceNumber + '</b></div>' +
                    (d.hasSupplierInvoice ? '' : ('<div class="a4-pro-meta-row"><span>' + d.lblInternal + '</span><b dir="ltr">#' + d.internalId + '</b></div>')) +
                    '<div class="a4-pro-meta-row"><span>' + L('print_date', 'بەروار') + '</span><b>' + d.dateStr + ' · ' + d.timeStr + '</b></div>' +
                    '<div class="a4-pro-meta-row"><span>' + d.lblPayment + '</span><b style="color:' + d.payColor + '">' + d.payLabel + '</b></div>' +
                    '<div class="a4-pro-meta-row"><span>' + L('print_items_count', 'ژمارەی کاڵا') + '</span><b>' + d.itemCount + '</b></div>';
            }
            var rows = '';
            var headCols = '';
            if (variant === 'sale') {
                headCols = '<th class="a4-th-num">#</th><th>' + d.thItem + '</th>' +
                    '<th class="a4-th-pack">' + (d.thPackaging || 'پێکهاتە') + '</th>' +
                    '<th class="a4-th-unit">' + (d.thUnit || 'یەکە') + '</th>' +
                    '<th class="a4-th-qty">' + d.thQty + '</th><th class="a4-th-money">' + d.thPrice + '</th><th class="a4-th-money">' + d.thTotal + '</th>';
                rows = d.items.map(function(i, idx) {
                    var nameCell = (typeof formatSaleItemNameHtml === 'function')
                        ? formatSaleItemNameHtml(i, { skipPriceTypeLabel: true, skipUnitSuffix: true })
                        : escapeHtml(i.name);
                    var prod = (typeof resolveSaleLineProduct === 'function') ? resolveSaleLineProduct(i) : null;
                    var packLabel = escapeHtml((typeof formatProductPackagingLabel === 'function')
                        ? formatProductPackagingLabel(prod || i)
                        : '—');
                    var unitLabel = escapeHtml((typeof getProductUnitLabel === 'function')
                        ? getProductUnitLabel(prod || i, i.saleUnit || 'piece')
                        : (i.saleUnit || '—'));
                    var zebra = idx % 2 === 1 ? ' a4-row-alt' : '';
                    return '<tr class="a4-item-row' + zebra + '"><td class="a4-td-num">' + (idx + 1) + '</td>' +
                        '<td class="a4-td-item"><div class="a4-item-name">' + nameCell + '</div></td>' +
                        '<td class="a4-td-pack">' + packLabel + '</td>' +
                        '<td class="a4-td-unit">' + unitLabel + '</td>' +
                        '<td class="a4-td-qty">' + i.qty + '</td>' +
                        '<td class="a4-td-money">' + formatA4SaleLineMoney(i, d, 'price') + '</td>' +
                        '<td class="a4-td-money a4-td-total">' + formatA4SaleLineMoney(i, d, 'total') + '</td></tr>';
                }).join('');
            } else {
                headCols = (typeof buildCompanyA4TableHead === 'function') ? buildCompanyA4TableHead(d) : '';
                rows = (typeof buildCompanyA4ItemRows === 'function') ? buildCompanyA4ItemRows(d) : '';
            }
            var termsBlock = '';
            if (d.invoiceNote) termsBlock += '<p class="a4-pro-note">' + d.invoiceNote + '</p>';
            if (d.customNote) termsBlock += '<p class="a4-pro-note">' + d.customNote + '</p>';
            if (d.staticNote1) termsBlock += '<p class="a4-pro-note">' + d.staticNote1 + '</p>';
            if (d.staticNote2) termsBlock += '<p class="a4-pro-note">' + d.staticNote2 + '</p>';
            if (d.staticNote3) termsBlock += '<p class="a4-pro-note">' + d.staticNote3 + '</p>';
            if (d.footer) termsBlock += '<p class="a4-pro-note a4-pro-note-muted">' + d.footer + '</p>';
            var fx = d.formatFxOpts;
            var currency = variant === 'sale' ? getCurrencySymbol() : (d.currency || getCurrencySymbol());
            var subTotal = variant === 'sale' ? d.subTotal : d.grandTotal;
            var grandTotal = variant === 'sale' ? d.total : d.grandTotal;
            var totalsHtml = '';
            if (variant === 'sale' && d.discount > 0) {
                totalsHtml += '<div class="a4-pro-total-row"><span>' + d.printSubtotalLabel + '</span><b>' + formatA4SaleGrandPrimaryHtml(d, subTotal) + '</b></div>';
                totalsHtml += '<div class="a4-pro-total-row a4-pro-discount"><span>' + d.printDiscountLabel + '</span><b>-' + (d.isUsdMode && d.showUsd && d.discountUsd > 0 ? formatA4SaleUsdTagged(d.discountUsd) : formatA4SaleGrandPrimaryHtml(d, d.discount)) + '</b></div>';
            } else if (variant === 'company') {
                totalsHtml += '<div class="a4-pro-total-row"><span>' + L('print_subtotal', 'کۆی') + '</span><b>' + formatCurrency(grandTotal) + ' ' + currency + '</b></div>';
            }
            totalsHtml += '<div class="a4-pro-total-row a4-pro-grand"><span>' + (variant === 'sale' ? d.printNetTotalLabel : L('print_grand_total', 'کۆی گشتی')) + '</span><strong>' +
                (variant === 'sale' ? formatA4SaleGrandPrimaryHtml(d, grandTotal) : (formatCurrency(grandTotal, fx) + ' ' + currency)) +
                '</strong></div>';
            if (variant === 'sale') {
                totalsHtml += formatA4SaleIqdHintHtml(d);
            }
            var sigLeft = variant === 'sale' ? L('print_customer', 'کڕیار') : L('print_supplier', 'دابینکەر');
            var sigRight = variant === 'sale' ? L('print_receiver', 'وەرگر') : L('print_receiver', 'وەرگر');
            var footContact = [];
            var storePhone = variant === 'sale' ? d.contactPhone : d.storePhone;
            var storeAddress = variant === 'sale' ? d.contactAddress : d.storeAddress;
            if (storePhone) footContact.push('<span dir="ltr">☎ ' + storePhone + '</span>');
            if (storeAddress) footContact.push('<span>📍 ' + storeAddress + '</span>');
            var brandFooter = (typeof buildPosReceiptBrandFooterHtml === 'function')
                ? buildPosReceiptBrandFooterHtml({ variant: 'a4', proBar: true })
                : '';
            var storeFootHtml = footContact.length
                ? ('<div class="a4-pro-store-foot">' + footContact.join('') + '</div>')
                : '';
            return '<div class="print-a4-container invoice-a4-company-pro' + typeMod + retMod + '" dir="rtl" data-a4-accent="' + accent + '" style="font-family:' + fontFn + ';">' +
                buildA4PngHeroLogoHtml(d, { className: 'a4-png-hero a4-png-hero--pro' }) +
                '<div class="a4-pro-head">' +
                    '<div class="a4-pro-head-brand">' +
                        '<div class="a4-pro-head-store">' +
                            '<strong>' + escapeHtml(d.cafeName || 'Store') + '</strong>' +
                            (d.cafeInfo ? '<em>' + d.cafeInfo + '</em>' : '') +
                            storeExtra +
                        '</div>' +
                    '</div>' +
                    '<div class="a4-pro-head-title"><span>' + docTitle + '</span></div>' +
                '</div>' +
                '<div class="a4-pro-meta">' +
                    '<div class="a4-pro-meta-to">' +
                        '<span class="a4-pro-meta-label">' + L('print_invoice_to', 'بۆ') + '</span>' +
                        '<strong>' + toName + '</strong>' + toContact +
                    '</div>' +
                    '<div class="a4-pro-meta-details">' + detailsHtml + '</div>' +
                '</div>' +
                '<div class="a4-pro-table-wrap"><table class="a4-pro-table inv-table"><thead><tr>' + headCols + '</tr></thead><tbody>' + rows + '</tbody></table></div>' +
                '<div class="a4-pro-bottom">' +
                    '<div class="a4-pro-bottom-left">' +
                        '<div class="a4-pro-section-title">' + L('print_payment_info', 'زانیاری پارەدان') + '</div>' +
                        buildA4ProDebtPanelHtml(d, { variant: variant, showFinancials: showFinancials }) +
                        '<div class="a4-pro-section-title">' + L('print_terms', 'مەرج و ڕێکەوتن') + '</div>' +
                        termsBlock +
                    '</div>' +
                    '<div class="a4-pro-bottom-right">' +
                        '<div class="a4-pro-totals">' + totalsHtml + '</div>' +
                        '<div class="a4-pro-sigs">' +
                            '<div class="a4-pro-sig"><div class="a4-pro-sig-line"></div><span>' + L('print_signature_short', 'واژوو') + ' · ' + sigLeft + '</span></div>' +
                            '<div class="a4-pro-sig"><div class="a4-pro-sig-line"></div><span>' + L('print_signature_short', 'واژوو') + ' · ' + sigRight + '</span></div>' +
                        '</div>' +
                        '<p class="a4-pro-thanks">' + L('print_thank_you', 'سوپاس بۆ مامەڵەکردن') + '</p>' +
                    '</div>' +
                '</div>' +
                storeFootHtml +
                '<div class="a4-pro-dev-footbar">' + brandFooter + '</div>' +
                '<div class="a4-pro-foot-accent"></div>' +
                '</div>';
        }
        if (typeof window !== 'undefined') {
            window.buildA4InvoiceProHtml = buildA4InvoiceProHtml;
        }
        function buildA4InvoiceClassic(d) {
            const showFinancials = (db.settings && db.settings.showFinancialSummaryOnA4 !== false);
            const rows = buildA4ItemRowsHtml(d, 'classic');
            const tf = typeof t === 'function';
            const L = function(k, fb) { return tf ? (t(k) || fb) : fb; };
            const sectionTitle = L('print_invoice_review', 'پێداچوونەوەی پسوولە');
            const logoHtml = buildA4PngHeroLogoHtml(d, { className: 'a4-d1-logo-wrap a4-png-hero' });
            const custId = d.customerIdDisplay ? ('#' + d.customerIdDisplay + ' ') : '';
            const custPhone = d.customerPhone ? ('<div class="a4-d1-meta-line" dir="ltr">☎ ' + d.customerPhone + '</div>') : '';
            const fxLine = (d.showAltCurrency && d.usdRateDisplay > 0)
                ? ('<div class="a4-d1-meta-line" dir="ltr" data-allow-iqd="1">$1 = ' + Number(d.usdRateDisplay).toLocaleString('en-US') + ' د.ع</div>')
                : '';
            const cashierLine = d.cashierName
                ? ('<div class="a4-d1-meta-line">' + L('print_cashier', 'فرۆشیار') + ': <b>' + d.cashierName + '</b>' +
                    (d.contactPhone ? (' <span dir="ltr">· ☎ ' + d.contactPhone + '</span>') : '') + '</div>')
                : (d.contactPhone ? ('<div class="a4-d1-meta-line" dir="ltr">☎ ' + d.contactPhone + '</div>') : '');
            const qtySum = (d.items || []).reduce(function(s, it) { return s + (parseFloat(it.qty) || 0); }, 0);
            const itemCount = (d.items || []).length;
            const giftCount = (d.items || []).filter(function(it) { return !!it.isGift; }).length;
            const payAmt = formatA4SaleTotalPrimary(d);
            var usdBig = '';
            var iqdBig = '';
            if (d.isUsdMode && d.showUsd) {
                usdBig = '<div class="a4-d1-total-usd">' + formatA4SaleUsdTagged(d.usdAmount) + '</div>';
                if (d.showAltCurrency) {
                    iqdBig = '<div class="a4-d1-total-iqd" data-allow-iqd="1">' + formatA4SaleIqdPlain(d.invoiceIqd != null ? d.invoiceIqd : d.total) + '</div>';
                }
            } else {
                iqdBig = '<div class="a4-d1-total-iqd" data-allow-iqd="1">' + formatA4SaleIqdPlain(d.invoiceIqd != null ? d.invoiceIqd : d.total) + '</div>';
                if (d.showAltCurrency && d.showUsd) {
                    usdBig = '<div class="a4-d1-total-usd">' + formatA4SaleUsdTagged(d.usdAmount) + '</div>';
                }
            }
            let debtBlock = '';
            if (showFinancials && d.debtBreakdown && (d.debtBreakdown.debtAdded > 0 || d.debtBreakdown.totalOutstandingDebt > 0)) {
                debtBlock = '<div class="a4-d1-debt">' +
                    '<div><span>نەقد</span><b>' + formatA4SaleGrandPrimaryHtml(d, d.debtBreakdown.cashPaid) + '</b></div>' +
                    '<div><span>قەرزی نوی</span><b>' + formatA4SaleGrandPrimaryHtml(d, d.debtBreakdown.debtAdded) + '</b></div>' +
                    (d.debtBreakdown.previousDebt > 0 ? '<div><span>قەرزی پێشوو</span><b>' + formatA4SaleGrandPrimaryHtml(d, d.debtBreakdown.previousDebt) + '</b></div>' : '') +
                    '<div><span>کۆیا قەرز</span><b>' + formatA4SaleGrandPrimaryHtml(d, d.debtBreakdown.totalOutstandingDebt) + '</b></div></div>';
            }
            const notes = [];
            if (d.invoiceNote) notes.push(d.invoiceNote);
            if (d.customNote) notes.push(d.customNote);
            if (d.staticNote1) notes.push(d.staticNote1);
            if (d.staticNote2) notes.push(d.staticNote2);
            if (d.staticNote3) notes.push(d.staticNote3);
            const notesHtml = notes.length
                ? ('<div class="a4-d1-guarantee"><div class="a4-d1-guarantee-title">' + L('print_terms', 'مەرج و گەرەنتی') + '</div>' +
                    notes.map(function(n) { return '<p>' + n + '</p>'; }).join('') + '</div>')
                : '';
            const contactBits = [];
            if (d.contactPhone) contactBits.push('<span dir="ltr">☎ ' + d.contactPhone + '</span>');
            if (d.contactAddress) contactBits.push('<span>📍 ' + d.contactAddress + '</span>');
            if (d.contactSocial) contactBits.push('<span>' + d.contactSocial + '</span>');
            if (d.cafeInfo && !contactBits.length) contactBits.push('<span>' + d.cafeInfo + '</span>');
            const contactBar = contactBits.length
                ? ('<div class="a4-d1-contact-bar">' + contactBits.join('<span class="a4-d1-dot">·</span>') + '</div>')
                : '';

            return '<div class="print-a4-container invoice-a4-classic invoice-a4-sale invoice-a4-d1" style="font-family:' + a4InvoiceFont() + ';">' +
                logoHtml +
                '<div class="a4-d1-meta">' +
                    '<div class="a4-d1-meta-doc">' +
                        '<div class="a4-d1-meta-line"><b>' + escapeHtml(d.cafeName || '') + '</b> | ' + d.printInvoiceLabel + ' <b dir="ltr">#' + d.displaySaleId + '</b></div>' +
                        '<div class="a4-d1-meta-line" dir="ltr">' + d.dateStr + ' ' + (d.timeStr || '') + '</div>' +
                        fxLine +
                        cashierLine +
                        '<div class="a4-d1-meta-line"><span class="a4-d1-status" style="--a4-status:' + d.statusColor + '">' + d.statusPaid + '</span></div>' +
                    '</div>' +
                    '<div class="a4-d1-meta-cust">' +
                        '<div class="a4-d1-meta-name">' + custId + d.customerName + '</div>' +
                        custPhone +
                    '</div>' +
                '</div>' +
                '<div class="a4-d1-section-bar">' + sectionTitle + '</div>' +
                '<div class="a4-table-wrap a4-table-wrap--sale a4-d1-table-wrap"><table class="inv-table a4-items-table a4-items-sale a4-items-sale--detail a4-items-sale-classic a4-d1-table"><thead><tr>' +
                '<th class="a4-th-num">#</th>' +
                '<th>' + d.thItem + '</th>' +
                '<th class="a4-th-pack">' + (d.thPackaging || 'پێکهاتە') + '</th>' +
                '<th class="a4-th-unit">' + (d.thUnit || 'یەکە') + '</th>' +
                '<th class="a4-th-qty">' + d.thQty + '</th>' +
                '<th class="a4-th-money">' + d.thPrice + '</th>' +
                '<th class="a4-th-money">' + d.thTotal + '</th></tr></thead><tbody>' + rows + '</tbody></table></div>' +
                '<div class="a4-d1-summary">' +
                    '<div class="a4-d1-counts">' +
                        '<span>' + L('print_items_count', 'ژمارەی کاڵا') + ': <b>' + itemCount + '</b></span>' +
                        '<span>' + L('th_qty', 'ژمارە') + ': <b>' + qtySum + '</b></span>' +
                        (giftCount ? ('<span>' + L('print_gift_count', 'دیاری') + ': <b>' + giftCount + '</b></span>') : '') +
                    '</div>' +
                    '<div class="a4-d1-totals">' +
                        (d.discount > 0 ? ('<div class="a4-d1-disc">' + d.printDiscountLabel + ': -' + (d.isUsdMode && d.discountUsd > 0 ? formatA4SaleUsdTagged(d.discountUsd) : formatA4SaleGrandPrimaryHtml(d, d.discount)) + '</div>') : '') +
                        '<div class="a4-d1-total-label">' + d.printNetTotalLabel + ' / گشتی</div>' +
                        usdBig + iqdBig +
                        '<div class="a4-d1-pay">' + ((d.isUsdMode && d.showUsd) ? '' : (payAmt + ' · ')) + escapeHtml(d.paymentMethodLabel || '') + '</div>' +
                        debtBlock +
                        (d.barcodeImg ? '<div class="a4-barcode-wrap a4-d1-barcode"><img src="' + d.barcodeImg + '" alt=""></div>' : '') +
                    '</div>' +
                '</div>' +
                '<div class="a4-d1-sigs">' +
                    '<div class="a4-d1-sig"><div class="a4-d1-sig-name">' + d.customerName + '</div><div class="a4-d1-sig-line"></div><span>' + L('print_customer', 'کڕیار') + '</span></div>' +
                    '<div class="a4-d1-sig"><div class="a4-d1-sig-name">' + (d.cashierName || '—') + '</div><div class="a4-d1-sig-line"></div><span>' + L('print_cashier', 'فرۆشیار') + '</span></div>' +
                '</div>' +
                notesHtml +
                (d.footer ? ('<p class="a4-d1-footer-msg">' + d.footer + '</p>') : '') +
                contactBar +
                '</div>';
        }
        function buildA4InvoiceMinimal(d) {
            const showFinancials = (db.settings && db.settings.showFinancialSummaryOnA4 !== false);
            const rows = buildA4ItemRowsHtml(d, 'minimal');
            const heroLogo = buildA4PngHeroLogoHtml(d, { className: 'a4-png-hero a4-png-hero--minimal' });
            return '<div class="print-a4-container invoice-a4-minimal invoice-a4-sale invoice-a4-sale--minimal a4-invoice-compact" style="font-family:' + a4InvoiceFont() + ';">' +
                heroLogo +
                buildPosSaleA4CompactHeader(d, 0) +
                buildPosSaleA4TableHtml(d, rows, 'a4-items-sale-minimal') +
                '<div class="a4-bottom-split a4-bottom-split--sale">' + buildPosSaleA4CompactNotesHtml(d) + buildPosSaleA4CompactTotalsHtml(d, showFinancials) + '</div></div>';
        }
        function buildA4InvoiceDesign3(d) {
            const showFinancials = (db.settings && db.settings.showFinancialSummaryOnA4 !== false);
            return buildA4InvoiceProHtml(d, { variant: 'sale', showFinancials: showFinancials });
        }

        function printInvoiceA4(id, saleOptional) {
            const sale = saleOptional || getAllSales().find(s => s.id === id);
            if (!sale) return;
            const html = buildPosSaleA4Html(sale);
            if (html) printContent(html, { docType: 'pos_sale' });
        }
        /** Open modal with invoice preview (معاينة الفاتورة) for a sale. */
        function previewSaleInvoice(id) {
            withSaleRecord(id, function(sale) {
            if(!sale) {
                if (typeof showToast === 'function') showToast('وەسڵ نەدۆزرایەوە.', 'error');
                return;
            }
            previewSaleInvoiceRender(sale);
            });
        }
        function previewSaleInvoiceRender(sale) {
            if(!sale) return;
            const d = buildA4InvoiceData(sale);
            const design = String((getPrintConfig('pos_sale') || {}).design || '1');
            const html = (design === '2') ? buildA4InvoiceMinimal(d) : (design === '8' ? buildA4InvoiceDesign3(d) : buildA4InvoiceClassic(d));
            let modal = document.getElementById('sales-invoice-preview-modal');
            if(!modal) {
                modal = document.createElement('div');
                modal.id = 'sales-invoice-preview-modal';
                modal.className = 'modal-overlay';
                modal.style.cssText = 'display:none; position:fixed; inset:0; background:rgba(0,0,0,0.6); align-items:center; justify-content:center; padding:20px;';
                modal.innerHTML = '<div style="background:var(--card); border-radius:12px; max-width:95vw; max-height:90vh; overflow:auto; box-shadow:0 10px 40px rgba(0,0,0,0.3); position:relative;"><button type="button" onclick="closeSaleInvoicePreview()" style="position:absolute; top:10px; left:10px; z-index:10; padding:8px 12px; background:var(--danger); color:white; border:none; border-radius:8px; cursor:pointer;"><i class="fas fa-times"></i> داخستن</button><div id="sales-invoice-preview-body" style="padding:24px;"></div></div>';
                modal.onclick = function(e) { if(e.target === modal) closeSaleInvoicePreview(); };
                document.body.appendChild(modal);
                if (typeof window._posWatchOverlay === 'function') window._posWatchOverlay(modal);
            }
            const body = document.getElementById('sales-invoice-preview-body');
            if(body) body.innerHTML = html;
            modal.style.display = 'flex';
            if (typeof window.bringOverlayToFront === 'function') window.bringOverlayToFront(modal);
        }
        function closeSaleInvoicePreview() {
            const modal = document.getElementById('sales-invoice-preview-modal');
            if(modal) modal.style.display = 'none';
        }
        if (typeof window !== 'undefined') { window.previewSaleInvoice = previewSaleInvoice; window.closeSaleInvoicePreview = closeSaleInvoicePreview; }

        // Product barcode/scale labels: implemented in app-settings.js (printProductLabel)

        function refundSale(id) {
            var salePreview = null;
            if (typeof getAllSales === 'function') {
                salePreview = getAllSales(true).find(function(s) { return s && String(s.id) === String(id); });
            }
            if (!salePreview && db && Array.isArray(db.sales)) {
                salePreview = db.sales.find(function(s) { return s && String(s.id) === String(id); });
            }
            var itemsLine = '';
            if (salePreview && salePreview.items && Array.isArray(salePreview.items) && salePreview.items.length) {
                itemsLine = '\n\nئایتم:\n' + salePreview.items.map(function(i) {
                    var q = (typeof getItemQty === 'function') ? getItemQty(i) : (parseFloat(i && i.qty) || 1);
                    return '• ' + ((i && i.name) ? String(i.name) : 'ئایتم') + ' ×' + q;
                }).slice(0, 8).join('\n') + (salePreview.items.length > 8 ? '\n…' : '');
            }
            var totalLine = salePreview && salePreview.total != null
                ? ('\nکۆم: ' + (typeof formatCurrency === 'function' ? formatCurrency(salePreview.total) : String(salePreview.total)))
                : '';
            var confirmMsg = 'ژێبرنا وەسڵێ #' + id + '؟\nئەڤە ژێبرنە — نە زڤڕاندنا فرۆتنێ.\nمەواد دێ زڤڕنە مەخزەنی.' + totalLine + itemsLine;

            var runVoid = function() {
            const formData = new FormData();
            formData.append('action', 'delete_sale');
            formData.append('id', id);
            formData.append('user', currentUser ? currentUser.name : 'System'); // SECURITY TRACKING
            
            fetch('?action=delete_sale', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                if(data.status === 'success') {
                    const saleIdx = db.sales.findIndex(s => s.id === id);
                    if(saleIdx > -1) {
                        const sale = db.sales[saleIdx];
                        // Update local stock (product + warehouse)
                        sale.items.forEach(function(item) {
                            const prod = db.products.find(function(p) { return String(p.id) === String(item.id); });
                            var q = (typeof getItemQty === 'function') ? getItemQty(item) : (parseFloat(item && (item.qty != null ? item.qty : item.count)) || 1);
                            var f = typeof getProductUnitFactors === 'function' ? getProductUnitFactors(item) : { piecesPerPack: 1, piecesPerCarton: 1 };
                            var pToAdd = q;
                            if (item.saleUnit === 'carton') pToAdd = q * (f.piecesPerCarton || 1);
                            else if (item.saleUnit === 'pack') pToAdd = q * (f.piecesPerPack || 1);
                            if(prod && prod.trackStock) {
                                prod.qty = (parseFloat(prod.qty) || 0) + pToAdd;
                            }
                            var lineWh = parseInt(item.warehouse_id, 10) || parseInt(sale.warehouse_id, 10) || 0;
                            if (lineWh > 0 && db.warehouse_stock && Array.isArray(db.warehouse_stock)) {
                                var wsRow = db.warehouse_stock.find(function(r) {
                                    return Number(r.product_id) === Number(item.id) && Number(r.warehouse_id) === Number(lineWh);
                                });
                                if (wsRow) wsRow.qty = (parseFloat(wsRow.qty) || 0) + pToAdd;
                                else db.warehouse_stock.push({ warehouse_id: lineWh, product_id: Number(item.id), qty: pToAdd });
                            }
                        });
                        
                        // FIX: Do not add to local returns list to avoid double negative in stats
                        // Just remove from sales list
                        
                        // db.sales.splice(saleIdx, 1);
                        // FIX: Mark as returned instead of removing, so it shows in history
                        db.sales[saleIdx].is_returned = 1;

                        // FIX: Update Admin Stats Immediately (Local Update)
                        if(db.today_stats) {
                            const todayStr = getBusinessDate(new Date());
                            const sDate = sale.date instanceof Date ? sale.date : parseSQLDate(sale.date);
                            if(getBusinessDate(sDate) === todayStr) {
                                db.today_stats.sales = (parseFloat(db.today_stats.sales) || 0) - sale.total;
                                db.today_stats.count = Math.max(0, (parseInt(db.today_stats.count) || 0) - 1);
                            }
                        }
                    }
                    
                    syncLiveData(); // FIX: Sync to update customer balance if it was a debt sale
                    renderSalesHistory();
                    updateStats();
                    var dailyModal = document.getElementById('daily-history-modal');
                    if (dailyModal && dailyModal.style.display === 'flex' && typeof openDailyHistoryModal === 'function') {
                        var voidedSale = (db.sales || []).find(function(s) { return s.id === id; }) || (typeof getAllSales === 'function' ? getAllSales(true).find(function(s) { return s.id === id; }) : null);
                        var voidDateIso = getBusinessDate(parseSQLDate(voidedSale && (voidedSale.date || voidedSale.created_at) || new Date()));
                        if (window._dailyDetailCache) {
                            delete window._dailyDetailCache[voidDateIso];
                        }
                        openDailyHistoryModal(voidDateIso);
                        setTimeout(function() {
                            if (typeof scrollToDailySummarySection === 'function') {
                                scrollToDailySummarySection('daily-sec-voided');
                            }
                        }, 350);
                    }
                    if (typeof showToast === 'function') {
                        showToast('وەسڵ #' + id + ' هاتە ژێبرن.', 'success', {
                            actionLabel: (typeof t === 'function') ? t('btn_undo_void') : 'پەشێمان بم',
                            durationMs: 12000,
                            onAction: function() {
                                if (typeof restoreVoidedSale === 'function') restoreVoidedSale(id);
                            }
                        });
                    } else {
                        alert('وەسڵ #' + id + ' هاتە ژێبرن (نە زڤڕاندن). مەواد زڤڕینە مەخزەنی.');
                    }
                } else {
                    alert((data && data.message) ? data.message : 'هەڵە ل ژێبرنا وەسڵێ');
                }
            });
            };

            if (typeof posConfirmDangerous === 'function') {
                posConfirmDangerous({
                    title: (typeof t === 'function') ? t('confirm_void_sale_title') : 'ژێبرنا وەسڵێ فرۆتنێ',
                    message: confirmMsg,
                    confirmText: (typeof t === 'function') ? t('confirm_void_btn') : 'بەڵێ، ژێ ببە'
                }).then(function(ok) { if (ok) runVoid(); });
            } else if (typeof posConfirm === 'function') {
                var code = String(1000 + Math.floor(Math.random() * 9000));
                posConfirm({
                    title: 'ژێبرنا وەسڵێ فرۆتنێ',
                    message: confirmMsg,
                    tone: 'danger',
                    confirmText: 'بەڵێ، ژێ ببە',
                    requirePhrase: code,
                    phraseNumeric: true,
                    phraseHint: 'بۆ پشتڕاستکرن، بنڤیسە کودێ: ' + code,
                    confirmDelayMs: 1500
                }).then(function(ok) { if (ok) runVoid(); });
            } else {
                if (!confirm(confirmMsg + '\n\nبنڤیسە ژێبرن بۆ پشتڕاستکرنێ…')) return;
                runVoid();
            }
        }

        function restoreVoidedSale(id) {
            id = parseInt(id, 10);
            if (!id) return;
            var user = (typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : 'System';
            var formData = new FormData();
            formData.append('action', 'restore_sale');
            formData.append('id', String(id));
            formData.append('user', user);
            fetch('?action=restore_sale', { method: 'POST', body: formData, credentials: 'same-origin' })
                .then(function(res) { return res.json().catch(function() { return {}; }); })
                .then(function(data) {
                    if (!data || data.status !== 'success') {
                        if (typeof showToast === 'function') showToast((data && data.message) || 'گەڕاندن سەرنەکەوت', 'error');
                        else alert((data && data.message) || 'گەڕاندن سەرنەکەوت');
                        return;
                    }
                    if (db && Array.isArray(db.sales)) {
                        var idx = db.sales.findIndex(function(s) { return String(s.id) === String(id); });
                        if (idx > -1) db.sales[idx].is_returned = 0;
                    }
                    if (typeof syncLiveData === 'function') syncLiveData();
                    if (typeof renderSalesHistory === 'function') renderSalesHistory();
                    if (typeof updateStats === 'function') updateStats();
                    if (typeof loadVoidedSalesHistoryForUi === 'function') loadVoidedSalesHistoryForUi();
                    else if (typeof renderReturnsHistoryModalContent === 'function') renderReturnsHistoryModalContent();
                    var dailyModal = document.getElementById('daily-history-modal');
                    if (dailyModal && dailyModal.style.display === 'flex' && typeof openDailyHistoryModal === 'function') {
                        try {
                            if (window._dailyDetailCache) {
                                Object.keys(window._dailyDetailCache).forEach(function(k) {
                                    try { delete window._dailyDetailCache[k]; } catch (_e) {}
                                });
                            }
                        } catch (_eC) {}
                        var sale = (db.sales || []).find(function(s) { return String(s.id) === String(id); });
                        var dayIso = (sale && (sale.date || sale.created_at) && typeof getBusinessDate === 'function')
                            ? getBusinessDate(parseSQLDate(sale.date || sale.created_at))
                            : undefined;
                        openDailyHistoryModal(dayIso);
                    }
                    if (typeof showToast === 'function') {
                        showToast(((typeof t === 'function') ? t('restore_sale_ok') : 'وەسڵ هاتە گەڕاندن') + ' #' + id, 'success');
                    }
                })
                .catch(function(err) {
                    if (typeof showToast === 'function') showToast(String(err && err.message || err), 'error');
                });
        }
        if (typeof window !== 'undefined') {
            window.restoreVoidedSale = restoreVoidedSale;
            window.refundSale = refundSale;
        }

        function restoreVoidedPurchase(txnId, auditId) {
            txnId = String(txnId || '').trim();
            auditId = parseInt(auditId, 10) || 0;
            if (!txnId && !auditId) return;
            var user = (typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : 'System';
            var formData = new FormData();
            formData.append('action', 'restore_purchase_invoice');
            if (txnId) formData.append('transaction_id', txnId);
            if (auditId) formData.append('audit_id', String(auditId));
            formData.append('user', user);
            fetch('?action=restore_purchase_invoice', { method: 'POST', body: formData, credentials: 'same-origin' })
                .then(function(res) { return res.json().catch(function() { return {}; }); })
                .then(function(data) {
                    if (!data || data.status !== 'success') {
                        if (typeof showToast === 'function') showToast((data && data.message) || 'گەڕاندنا کڕینێ سەرنەکەوت', 'error');
                        else alert((data && data.message) || 'گەڕاندنا کڕینێ سەرنەکەوت');
                        return;
                    }
                    if (typeof syncLiveData === 'function') setTimeout(function() { syncLiveData(false); }, 150);
                    if (typeof loadGlobalPurchaseHistory === 'function') {
                        loadGlobalPurchaseHistory(function () {
                            if (typeof renderGlobalPurchaseHistory === 'function') renderGlobalPurchaseHistory();
                        }, 'gph');
                    } else if (typeof renderGlobalPurchaseHistory === 'function') {
                        renderGlobalPurchaseHistory();
                    }
                    try {
                        if (typeof invalidateCalendarMonthCache === 'function') invalidateCalendarMonthCache();
                        else if (typeof window.invalidateCalendarMonthCache === 'function') window.invalidateCalendarMonthCache();
                        if (typeof renderWorkCalendar === 'function') renderWorkCalendar();
                        else if (typeof window.renderWorkCalendar === 'function') window.renderWorkCalendar();
                    } catch (_eRw) {}
                    var vm = document.getElementById('voided-purchases-history-modal');
                    if (vm && vm.style.display === 'flex' && typeof loadVoidedPurchasesHistory === 'function') {
                        try { loadVoidedPurchasesHistory(); } catch (_eL) {}
                    }
                    var dailyModal = document.getElementById('daily-history-modal');
                    if (dailyModal && dailyModal.style.display === 'flex' && typeof openDailyHistoryModal === 'function') {
                        openDailyHistoryModal(undefined, { force: true, refresh: true });
                    }
                    if (typeof showToast === 'function') {
                        showToast(((typeof t === 'function') ? t('restore_purchase_ok') : 'پسوولا کڕینێ هاتە گەڕاندن') + (txnId ? (' #' + txnId.slice(-8)) : ''), 'success');
                    }
                })
                .catch(function(err) {
                    if (typeof showToast === 'function') showToast(String(err && err.message || err), 'error');
                });
        }
        if (typeof window !== 'undefined') window.restoreVoidedPurchase = restoreVoidedPurchase;

        function printExpenses() {
            const opExpenses = typeof filterOperationalExpenses === 'function' ? filterOperationalExpenses(db.expenses) : (db.expenses || []);
            const totalExpIqd = opExpenses.reduce(function(a, e) {
                return a + ((typeof expenseAmountIqd === 'function') ? expenseAmountIqd(e) : (parseFloat(e.amount) || 0));
            }, 0);
            var locale = typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ';
            var reportTitle = (typeof t === 'function') ? t('print_expenses_report') : 'ڕاپۆرتا مەزاختنان';
            var totalExpTxt = (typeof formatFrozenIqdRowsSum === 'function')
                ? formatFrozenIqdRowsSum(opExpenses)
                : (formatCurrency(totalExpIqd) + ' ' + getCurrencySymbol());
            var summaryHtml = '<div class="p-box" style="border-color:#ef4444;flex:1 1 100%;"><h3>' + ((typeof t === 'function') ? t('print_total_expenses') : 'کۆیێ گشتی یێ مەزاختنێ') + '</h3><h2 style="color:#ef4444;">' + totalExpTxt + '</h2></div>';
            var amtHead = (typeof t === 'function') ? t('exp_amount_ph') : 'بڕ';
            var tableHtml = '<div class="section-title">' + ((typeof t === 'function') ? t('print_expenses_list') : 'لیستا مەزاختنان') + '</div><table class="print-table"><thead><tr><th>' + ((typeof t === 'function') ? t('print_date') : 'بەروار') + '</th><th>' + ((typeof t === 'function') ? t('gh_th_note') : 'تێبینی') + '</th><th>' + ((typeof t === 'function') ? t('gh_th_user') : 'بەکارهێنەر') + '</th><th>' + amtHead + '</th></tr></thead><tbody>' +
                opExpenses.slice().reverse().map(function(e) {
                    var amtTxt = (typeof formatExpenseAmountDisplay === 'function')
                        ? formatExpenseAmountDisplay(e)
                        : ((typeof formatFrozenIqdAmount === 'function')
                            ? formatFrozenIqdAmount(e, (typeof expenseAmountIqd === 'function') ? expenseAmountIqd(e) : e.amount)
                            : formatCurrency((typeof expenseAmountIqd === 'function') ? expenseAmountIqd(e) : e.amount));
                    return '<tr><td>' + parseSQLDate(e.date).toLocaleDateString(locale) + '</td><td>' + escapeHtml((typeof translateExpenseNoteForUi === 'function') ? translateExpenseNoteForUi(e.note) : (e.note || '')) + '</td><td>' + escapeHtml(e.user || '-') + '</td><td style="text-align:right;color:#ef4444;font-weight:bold;">' + amtTxt + '</td></tr>';
                }).join('') + '</tbody></table>';
            var html = (typeof buildFlexibleReportPrintHtml === 'function')
                ? buildFlexibleReportPrintHtml('expenses_report', reportTitle, ((typeof t === 'function') ? t('print_date') : 'بەروار') + ': ' + new Date().toLocaleDateString(locale), summaryHtml, tableHtml)
                : tableHtml;
            if (typeof routePrint === 'function') routePrint('expenses_report', html, { details: 'expenses=' + opExpenses.length });
            else if (typeof printContent === 'function') printContent(html);
        }
        
        function printLedger(opts) {
            opts = opts || {};
            const comp = db.companies.find(c => c.id === currentViewingCompanyId);
            if(!comp) { if (typeof showToast === 'function') showToast('وێ کۆمپانیێ هەلبژێرە یا تە دڤێت جەردێ پارەدان و قەرزێ وێ چاپ بکەی', 'warning'); return; }
            if (!opts.paper) {
                var tfLed = typeof t === 'function';
                openPrintPaperChooser({
                    title: tfLed ? (t('sales_hist_print_choose') || 'قەبارەی چاپێ هەلبژێرە') : 'قەبارەی چاپێ هەلبژێرە',
                    subtitle: comp.name || '',
                    storageKey: 'pos_company_ledger_print_paper',
                    onPick: function(paper) { printLedger({ paper: paper }); }
                });
                return;
            }
            
            const allEntries = db.ledger.filter(l => l.companyId === currentViewingCompanyId).sort((a, b) => b.id - a.id);
            let currentBal = parseFloat(comp.balance) || 0;
            allEntries.forEach(l => {
                l._running_balance = currentBal;
                let amt = Math.abs(parseFloat(l.amount) || 0);
                let effect = 0;
                if (l.type === 'credit_purchase' || l.type === 'receive') effect = amt;
                else if (l.type === 'payment' || l.type === 'pay' || l.type === 'return_to_supplier') effect = -amt;
                currentBal = currentBal - effect;
            });
            const l = allEntries.filter(e => isDateInScope(e.date, 'cp-ledger'));
            var want80Co = /^(80mm|80)$/i.test(String(opts.paper));
            var cfgCo = (typeof getPrintConfig === 'function') ? Object.assign({}, getPrintConfig('company_ledger')) : { paper: '80mm', design: '1' };
            cfgCo.paper = want80Co ? '80mm' : '210mm';
            var titleCo = typeof t === 'function' ? t('print_ledger') : 'کەشف حیساب';
            var subtitleCo = (typeof t === 'function' ? t('nav_companies') : 'کۆمپانیا') + ': ' + (comp.name || '');
            var summaryHtmlCo = '<div class="print-summary-box"><div class="p-box" style="border-color:#3b82f6;"><h3>' +
                (typeof t === 'function' ? t('dash_liabilities') : 'قەرزێ مە') + '</h3>' +
                '<h2 style="color:#dc2626;" dir="ltr">' + formatCurrency(comp.balance) + ' ' + getCurrencySymbol() + '</h2></div></div>';
            var tableHtmlCo = '<div class="section-title">وردەکاریێن لڤینان</div><table class="print-table" dir="rtl"><thead><tr>' +
                (want80Co ? '<th>بەروار</th><th>جۆر</th><th>بڕ</th><th>ماوە</th>' : '<th>بەروار (Date)</th><th>جۆرێ کارێ (Type)</th><th>تێبینی (Note)</th><th>بڕ (Amount)</th><th>ماوەیێ قەرزی (Balance)</th>') +
                '</tr></thead><tbody>' +
                l.map(function(x) {
                    var isDebt = (x.type === 'credit_purchase' || x.type === 'receive');
                    var isCash = (x.type === 'purchase');
                    var typeLabel = x.type;
                    if (x.type === 'credit_purchase') typeLabel = 'کڕین (قەرز)';
                    else if (x.type === 'return_to_supplier') typeLabel = 'زڤڕاندن بۆ کۆمپانیێ';
                    else if (x.type === 'payment' || x.type === 'pay') typeLabel = 'پارە هاتە دان';
                    else if (x.type === 'purchase') typeLabel = 'کڕین ب کاش';
                    else if (x.type === 'receive') typeLabel = 'پارە هاتە وەرگرتن';
                    var color = '#059669';
                    var prefix = '- ';
                    if (isDebt) { color = '#dc2626'; prefix = '+ '; }
                    else if (isCash) { color = '#2563eb'; prefix = ''; }
                    return '<tr><td>' + new Date(x.date).toLocaleDateString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ') + '</td>' +
                        '<td style="color:' + color + ';font-weight:bold;">' + escapeHtml(typeLabel) + '</td>' +
                        (want80Co ? '' : '<td>' + escapeHtml(x.note || '') + '</td>') +
                        '<td style="text-align:right;font-weight:bold;color:' + color + ';" dir="ltr">' + prefix + formatCurrency(Math.abs(x.amount)) + '</td>' +
                        '<td style="text-align:right;font-weight:bold;" dir="ltr">' + formatCurrency(x._running_balance) + '</td></tr>';
                }).join('') + '</tbody></table>';
            var html = (typeof buildFlexibleReportPrintHtml === 'function')
                ? buildFlexibleReportPrintHtml('company_ledger', titleCo, subtitleCo, summaryHtmlCo, tableHtmlCo, cfgCo)
                : (summaryHtmlCo + tableHtmlCo);
            if (typeof routePrint === 'function') {
                routePrint('company_ledger', html, { docId: String(comp.id || ''), details: 'company-ledger', paper: cfgCo.paper, cfg: cfgCo });
            } else if (typeof printContent === 'function') {
                printContent(html);
            }
        }

        function printCustomerLedger(opts) {
            opts = opts || {};
            const cust = db.customers.find(c => c.id === currentViewingCustomerId);
            if(!cust) { if (typeof showToast === 'function') showToast('کڕیار نەهاتە دیتن بۆ چاپکرنێ', 'warning'); return; }
            var tf = typeof t === 'function';
            if (!opts.paper) {
                openPrintPaperChooser({
                    title: (tf && t('cust_ledger_print_choose') !== 'cust_ledger_print_choose') ? t('cust_ledger_print_choose') : (tf ? (t('sales_hist_print_choose') || 'قەبارەی چاپێ هەلبژێرە') : 'قەبارەی چاپێ هەلبژێرە'),
                    subtitle: cust.name || '',
                    storageKey: 'pos_cust_ledger_print_paper',
                    onPick: function(paper) { printCustomerLedger({ paper: paper }); }
                });
                return;
            }

            let allEntries = [];
            if (window.currentCustomerLedgerAllEntries && window.currentCustomerLedgerAllEntries.length > 0) {
                allEntries = window.currentCustomerLedgerAllEntries;
            } else {
                allEntries = db.customer_ledger.filter(l => l.target_id === currentViewingCustomerId && l.target_type === 'customer').sort((a, b) => b.id - a.id);
                let currentBal = parseFloat(cust.balance) || 0;
                allEntries.forEach(l => {
                    l._running_balance = currentBal;
                    let amt = Math.abs(parseFloat(l.amount) || 0);
                    let effect = 0;
                    if (l.type === 'sale') effect = amt;
                    else if (l.type === 'payment' || l.type === 'pay' || l.type === 'return') effect = -amt;
                    currentBal = currentBal - effect;
                });
            }
            const l = allEntries.filter(e => isDateInScope(e.date, 'cust-ledger'));
            var want80 = /^(80mm|80)$/i.test(String(opts.paper));
            var cfg = (typeof getPrintConfig === 'function') ? Object.assign({}, getPrintConfig('customer_ledger')) : { paper: '80mm', design: '1' };
            cfg.paper = want80 ? '80mm' : '210mm';

            var title = tf ? t('print_ledger') : 'کەشف حیساب';
            var subtitle = (tf ? (t('cdm_entity_label') !== 'cdm_entity_label' ? t('cdm_entity_label') : 'کڕیار') : 'کڕیار') + ': ' + (cust.name || '');
            var summaryHtml = '<div class="print-summary-box"><div class="p-box" style="border-color:#3b82f6;"><h3>قەرزێ لای کڕیاری</h3>' +
                '<h2 style="color:#dc2626;" dir="ltr">' + formatCurrency(cust.balance) + ' ' + getCurrencySymbol() + '</h2></div></div>';
            var tableHtml = '<div class="section-title">وردەکاریێن لڤینان</div>' +
                '<table class="print-table" dir="rtl"><thead><tr>' +
                (want80
                    ? '<th>بەروار</th><th>جۆر</th><th>بڕ</th><th>ماوە</th>'
                    : '<th>بەروار (Date)</th><th>جۆرێ کارێ (Type)</th><th>تێبینی (Note)</th><th>بڕ (Amount)</th><th>ماوەیێ قەرزی (Balance)</th>') +
                '</tr></thead><tbody>' +
                l.map(function(x) {
                    var isDebt = (x.type === 'sale');
                    var isCashSale = (x.type === 'sale_cash');
                    var isCashReturn = (x.type === 'return_cash');
                    var typeLabel = x.type;
                    if (x.type === 'sale') typeLabel = 'فرۆتن ب قەرز';
                    else if (x.type === 'sale_cash') typeLabel = 'فرۆتن ب کاش (نەقد)';
                    else if (x.type === 'return') typeLabel = 'زڤڕاندن (مرتجع قەرز)';
                    else if (x.type === 'return_cash') typeLabel = 'زڤڕاندن (مرتجع کاش)';
                    else if (x.type === 'payment' || x.type === 'pay') {
                        var ch = (typeof customerDebtPaymentChannel === 'function') ? customerDebtPaymentChannel(x) : 'cash';
                        typeLabel = ch === 'fib' ? 'وەرگرتن (FIB)' : 'وەرگرتن (نقد)';
                    }
                    var color = '#059669';
                    var prefix = '- ';
                    if (isDebt) { color = '#dc2626'; prefix = '+ '; }
                    else if (isCashSale || isCashReturn) { color = '#2563eb'; prefix = ''; }
                    return '<tr>' +
                        '<td>' + new Date(x.date).toLocaleDateString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ') + '</td>' +
                        '<td style="color:' + color + ';font-weight:bold;">' + escapeHtml(typeLabel) + '</td>' +
                        (want80 ? '' : '<td>' + escapeHtml(x.note || '') + '</td>') +
                        '<td style="text-align:right;font-weight:bold;color:' + color + ';" dir="ltr">' + prefix + formatCurrency(Math.abs(x.amount)) + '</td>' +
                        '<td style="text-align:right;font-weight:bold;" dir="ltr">' + formatCurrency(x._running_balance) + '</td>' +
                        '</tr>';
                }).join('') +
                '</tbody></table>';

            var html;
            if (typeof buildFlexibleReportPrintHtml === 'function') {
                html = buildFlexibleReportPrintHtml('customer_ledger', title, subtitle, summaryHtml, tableHtml, cfg);
            } else {
                var logoHtml = (typeof getPosShopLogoUrl === 'function' && getPosShopLogoUrl()) ? '<img src="' + getPosShopLogoUrl() + '" style="max-height:80px;max-width:150px;">' : '';
                html = '<div class="' + (want80 ? 'print-thermal-container' : 'print-a4-container') + '" dir="rtl" style="' + (want80 ? 'max-width:80mm;width:100%;' : '') + '">' +
                    '<div class="print-header"><h1>' + escapeHtml((db.settings && db.settings.cafeName) || '') + '</h1>' + logoHtml +
                    '<h2>' + escapeHtml(title) + '</h2><p>' + escapeHtml(subtitle) + '</p></div>' +
                    summaryHtml + tableHtml +
                    '<div class="report-footer">' + (typeof window.posBrandWithVersion === 'function' ? window.posBrandWithVersion() : '') + ' | Ledger Report</div></div>';
            }
            if (typeof routePrint === 'function') {
                routePrint('customer_ledger', html, { docId: String(cust.id || ''), details: 'customer-ledger', paper: cfg.paper, cfg: cfg });
            } else if (typeof printContent === 'function') {
                printContent(html);
            } else if (typeof showToast === 'function') {
                showToast('چاپکرن بەردەست نییە — پەڕە نوێ بکە (F5)', 'error');
            }
        }
        window.printLedger = printLedger;
        window.printCustomerLedger = printCustomerLedger;
        window.reprintBill = reprintBill;
        window.reprintBillWithSale = reprintBillWithSale;
        window.reprintBillFromHistory = reprintBillFromHistory;
        window.printSaleAdjustmentSlip = printSaleAdjustmentSlip;
        window.closeSalesHistPrintChooser = closeSalesHistPrintChooser;

