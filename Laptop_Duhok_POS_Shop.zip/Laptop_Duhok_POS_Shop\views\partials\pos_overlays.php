    <!-- STARTUP SCREEN (Premium Glassmorphism) -->
    <div id="startup-screen" class="startup-overlay modal-overlay pos-auth-screen" style="display: <?php echo empty($pos_show_startup_license_codes) ? 'none' : 'flex'; ?>;">
        <div class="startup-bg" aria-hidden="true"></div>
        <div class="startup-glass-card glass-card startup-card-inner startup-card--clean">
            <!-- Mobile Connect (Top Right, RTL: top-left) -->
            <button type="button" class="startup-mobile-connect-btn" onclick="toggleMobileConnectInfo()" data-i18n-title="startup_mobile_btn_title" title="گرێدانا مۆبایل / تابلێت (Connect Mobile/Tablet)">
                <i class="fas fa-qrcode"></i>
            </button>

            <div class="startup-logo-wrap">
                <div class="startup-logo-glow"></div>
                <img id="startup-logo-img" class="startup-logo-img" src="<?php echo htmlspecialchars($pos_default_logo_url, ENT_QUOTES, 'UTF-8'); ?>" alt="Laptop Duhok POS" width="148" height="148" decoding="async" fetchpriority="high" loading="eager" onerror="this.style.display='none'; this.nextElementSibling.classList.add('show');">
                <div class="startup-logo-placeholder"><i class="fas fa-cash-register"></i></div>
            </div>

            <h1 class="startup-title">Laptop Duhok POS</h1>
            <p class="startup-version">
                <span class="startup-edition-badge" data-i18n="startup_edition_sql">SQL Database Edition</span>
                <span class="startup-version-sep" aria-hidden="true">·</span>
                <span class="startup-version-num">v<?php echo htmlspecialchars(POS_APP_VERSION, ENT_QUOTES, 'UTF-8'); ?></span>
            </p>

            <?php if (!empty($pos_show_startup_license_codes)): ?>
            <div class="startup-install-codes" aria-label="Installation serial and security code">
                <p class="startup-code-label"><i class="fas fa-laptop"></i> سێریاڵی لاپتۆپ / دامەزراندن · PC license serial</p>
                <code class="startup-code-value" dir="ltr"><?php echo htmlspecialchars($pos_startup_serial ?: '—', ENT_QUOTES, 'UTF-8'); ?></code>
                <?php if ($pos_bios_raw !== '' && $pos_bios_raw !== $pos_startup_serial): ?>
                <p class="startup-code-bios" dir="ltr"><span class="startup-code-bios-key">BIOS:</span> <?php echo htmlspecialchars($pos_bios_raw, ENT_QUOTES, 'UTF-8'); ?></p>
                <?php endif; ?>
                <p class="startup-code-label"><i class="fas fa-shield-alt"></i> کۆدی ئاسایش · Security code</p>
                <code class="startup-code-value startup-code-short" dir="ltr"><?php echo htmlspecialchars($pos_startup_security ?: '—', ENT_QUOTES, 'UTF-8'); ?></code>
                <p class="startup-code-hint">هەردوو ژمارە بۆ چالاککردن لە ئەدمین بنێرە · Send both numbers to activate in admin.</p>
            </div>
            <?php endif; ?>

            <button type="button" id="auto-start-system-btn" class="btn btn-start-system" onclick="if(typeof showAppBootLoader===&quot;function&quot;)showAppBootLoader(); var fn=window.connectToDB||(typeof connectToDB===&quot;function&quot;&amp;&amp;connectToDB); if(fn) fn(); else alert(typeof t===&quot;function&quot;?t(&quot;startup_connect_unavailable&quot;):&quot;پەڕەکە نوێ بکەرەوە (Refresh the page).&quot;);">
                <i class="fas fa-power-off"></i>
                <span data-i18n="startup_start_system">دەستپێکردن (Start System)</span>
            </button>
        </div>

        <?php if (empty($pos_show_startup_license_codes)): ?>
        <script>
        document.addEventListener('DOMContentLoaded', function() {
            var btn = document.getElementById('auto-start-system-btn');
            // Hide the startup screen wrapper immediately
            var wrap = document.getElementById('startup-screen');
            if (wrap) { wrap.style.display = 'none'; wrap.style.opacity = '0'; }
            
            // Wait for JS to be ready, then click
            function tryAutoStart() {
                if (typeof window.connectToDB === 'function') {
                    if (btn) btn.click();
                } else {
                    setTimeout(tryAutoStart, 50);
                }
            }
            tryAutoStart();
        });
        </script>
        <?php endif; ?>

        <!-- Mobile Connect — full startup overlay (not clipped inside small card) -->
        <?php
            $pos_mobile_host = php_uname('n');
            $pos_mobile_ip = getHostByName($pos_mobile_host);
            if ($pos_mobile_ip === '127.0.0.1') { $pos_mobile_ip = getHostByName(getHostName()); }
            $pos_mobile_path = isset($_SERVER['SCRIPT_NAME']) ? rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/') : '';
            if ($pos_mobile_path === '' || $pos_mobile_path === '.') { $pos_mobile_path = ''; }
            $pos_mobile_connect_url = 'http://' . $pos_mobile_ip . $pos_mobile_path . '/';
            $pos_mobile_entry_url = 'http://' . $pos_mobile_ip . $pos_mobile_path . '/_PRIVATE/mobile_manager/index.html#entry';
        ?>
        <div id="mobile-connect-info" class="startup-mobile-overlay startup-mobile-overlay--screen" style="display:none;" hidden>
            <button type="button" class="startup-mobile-overlay-close" onclick="toggleMobileConnectInfo()" data-i18n-aria-label="btn_close" aria-label="داخستن">&times;</button>
            <div class="startup-mobile-overlay-inner">
                <h3 class="startup-mobile-title"><span data-i18n="startup_mobile_title">گرێدانا مۆبایل (Connect)</span></h3>
                <div style="display:flex;gap:8px;margin-bottom:12px;justify-content:center;">
                    <button type="button" id="btn-qr-tab-pos" onclick="if(typeof switchMobileConnectQr==='function') switchMobileConnectQr('pos')" style="border-radius:8px;padding:6px 14px;background:#2563eb;color:#fff;border:none;cursor:pointer;font-weight:700;font-size:0.82rem;">فرۆشتن (POS)</button>
                    <button type="button" id="btn-qr-tab-entry" onclick="if(typeof switchMobileConnectQr==='function') switchMobileConnectQr('entry')" style="border-radius:8px;padding:6px 14px;background:#1e293b;color:#94a3b8;border:1px solid #334155;cursor:pointer;font-weight:700;font-size:0.82rem;">ئیدخال (LD Manager)</button>
                </div>
                <div class="startup-mobile-qr-wrap">
                    <div id="mobile-connect-qr" class="startup-mobile-qr" role="img" aria-label="QR code"></div>
                </div>
                <p class="startup-mobile-qr-instruction" id="mobile-qr-instruction-lbl"><span data-i18n="startup_mobile_qr_instruction">ب کەمێرێ مۆبایلەکە ئەڤ QR سکان بکە بۆ گرێدانێ ئێستا.</span></p>
                <p class="startup-mobile-url-label"><span data-i18n="startup_mobile_url_label">لینک (URL):</span></p>
                <div class="startup-mobile-url-wrap">
                    <span class="startup-mobile-url" dir="ltr" data-connect-url="<?php echo htmlspecialchars($pos_mobile_connect_url, ENT_QUOTES, 'UTF-8'); ?>" data-entry-url="<?php echo htmlspecialchars($pos_mobile_entry_url, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($pos_mobile_connect_url, ENT_QUOTES, 'UTF-8'); ?></span>
                </div>
                <p class="startup-mobile-tips-compact"><i class="fas fa-wifi"></i> <span data-i18n="startup_mobile_tip_wifi">هەمان Wi‑Fi · Firewall Off · ئەگەر QR نەبوو لینکێ بەرەوە بنووسە</span></p>
            </div>
        </div>
    </div>

    <!-- DEVICE NOT APPROVED (Supabase pos_devices) -->
    <div id="device-block-screen" class="startup-overlay modal-overlay" style="display:none; z-index: 2147483001;">
        <div class="startup-bg" aria-hidden="true"></div>
        <div class="startup-glass-card glass-card startup-card-inner" style="max-width: 540px; position: relative;">
            <div style="position: absolute; top: 12px; left: 16px; right: 16px; display: flex; justify-content: space-between; align-items: center;">
                <select id="dev-block-lang-toggle" onchange="toggleDevBlockLang(this.value)" style="background: rgba(0,0,0,0.4); color: white; border: 1px solid #475569; border-radius: 6px; padding: 4px 8px; font-size: 0.85rem; cursor: pointer; outline: none;">
                    <option value="badini">کوردی (بادینی)</option>
                    <option value="ar">العربية</option>
                </select>
            </div>

            <h2 id="dev-block-title" class="startup-title" style="font-size: 1.35rem; color: #fbbf24; margin-top: 24px;">قوفلکرنا لاپتۆپی — چاڤەڕێی پەسەندکرنێ یە</h2>
            <p id="device-block-msg" style="line-height: 1.75; color: #e2e8f0; margin: 12px 0;"></p>
            
            <p id="dev-block-lbl-serial" style="font-size: 0.9rem; color: #94a3b8; margin-bottom: 6px;">سێریاڵی لاپتۆپی (دگەل داخوازیا پەسەندکرنێ بنێرە):</p>
            <p id="device-block-install-serial" dir="ltr" style="font-family: 'Rudaw', sans-serif; text-align: center; background: #1e293b; color: #f8fafc; border: 1px solid #475569; padding: 14px; border-radius: 8px; word-break: break-all; font-size: 0.92rem; margin: 0 0 14px 0;"></p>
            
            <p id="dev-block-lbl-key" style="font-size: 0.9rem; color: #94a3b8; margin-bottom: 6px;">کورتکراوەیا کلیلا ڤی لاپتۆپی:</p>
            <p id="device-block-key-hint" dir="ltr" style="font-family: 'Rudaw', sans-serif; text-align: center; background: #451a03; color: #fed7aa; border: 1px solid #9a3412; padding: 14px; border-radius: 8px; word-break: break-all; font-size: 1rem; margin: 0 0 10px 0;"></p>
            
            <p id="dev-block-lbl-methods" style="font-size: 0.85rem; color: #94a3b8; line-height: 1.65; margin-bottom: 14px;">ڕێکا ١: ژ لایێ بەڕێوەبەری ڤە ب شێوەیەکێ دەستی بهێتە پەسەندکرن.<br>ڕێکا ٢: کۆدی چالاککرنێ یێ کو بەڕێوەبەری دایە تە لێرە بنڤێسە.</p>
            
            <div id="device-activation-form" style="margin-bottom: 16px; padding: 14px; border-radius: 10px; border: 1px solid rgba(34, 197, 94, 0.35); background: rgba(34, 197, 94, 0.08);">
                <p id="dev-block-lbl-code-desc" style="font-size: 0.88rem; color: #86efac; margin: 0 0 6px 0;"><i class="fas fa-key"></i> کۆدی چالاککرنێ ژ بەڕێوەبەری (٦ هژمارن — نە کۆدی ئاسایشێ یە)</p>
                <p id="dev-block-lbl-code-hint" style="font-size: 0.78rem; color: #94a3b8; margin: 0 0 10px 0;">ل دەف بەڕێوەبەری دهێتە دروستکرن → پێنگاڤا ٢ → «کۆدی چالاککرنێ».</p>
                <div style="display:flex; flex-wrap:wrap; gap:10px; align-items:center;">
                    <input type="text" id="device-activation-code-input" dir="ltr" placeholder="123456" autocomplete="off" inputmode="numeric" style="flex:1; min-width:180px; padding:12px 14px; border-radius:8px; border:1px solid #475569; background:#0f172a; color:#f8fafc; font-family:'Rudaw',sans-serif; letter-spacing:0.12em;" />
                    <button type="button" class="btn btn-start-system" id="device-activation-submit-btn" style="margin:0; white-space:nowrap;">
                        <i class="fas fa-unlock"></i>
                        <span id="dev-block-btn-activate">چالاک بکە</span>
                    </button>
                </div>
                <p id="device-activation-msg" style="display:none; margin:10px 0 0; font-size:0.85rem; line-height:1.5;"></p>
            </div>
            <p id="device-block-tech" style="display:none; font-size: 0.78rem; color: #64748b; margin: 12px 0 16px 0; line-height: 1.4;"></p>
            <button type="button" class="btn btn-start-system" onclick="if(typeof connectToDB==='function'){connectToDB(false);}else{location.reload();}">
                <i class="fas fa-sync"></i>
                <span id="dev-block-btn-retry">دووبارە پشکنین بکەوە</span>
            </button>
        </div>
    </div>
    
    <script>
    function toggleDevBlockLang(lang) {
        var isAr = (lang === 'ar');
        document.getElementById('dev-block-title').innerHTML = isAr ? 'قفل الجهاز — بانتظار الموافقة' : 'قوفلکرنا لاپتۆپی — چاڤەڕێی پەسەندکرنێ یە';
        document.getElementById('dev-block-lbl-serial').innerText = isAr ? 'رقم التثبيت للمتجر (يرسل مع طلب الموافقة):' : 'سێریاڵی لاپتۆپی (دگەل داخوازیا پەسەندکرنێ بنێرە):';
        document.getElementById('dev-block-lbl-key').innerText = isAr ? 'اختصار مفتاح الجهاز الحالي:' : 'کورتکراوەیا کلیلا ڤی لاپتۆپی:';
        document.getElementById('dev-block-lbl-methods').innerHTML = isAr ? 'طريقة ①: فعِّل الموافقة من لوحة الأدمن (قبول يدوي).<br>طريقة ②: أدخل كود التفعيل الذي أرسله المشرف.' : 'ڕێکا ١: ژ لایێ بەڕێوەبەری ڤە ب شێوەیەکێ دەستی بهێتە پەسەندکرن.<br>ڕێکا ٢: کۆدی چالاککرنێ یێ کو بەڕێوەبەری دایە تە لێرە بنڤێسە.';
        document.getElementById('dev-block-lbl-code-desc').innerHTML = isAr ? '<i class="fas fa-key"></i> كود التفعيل من الأدمن (6 أرقام — ليس «كود الأمان» على شاشة الترخيص)' : '<i class="fas fa-key"></i> کۆدی چالاککرنێ ژ بەڕێوەبەری (٦ هژمارن — نە کۆدی ئاسایشێ یە)';
        document.getElementById('dev-block-lbl-code-hint').innerText = isAr ? 'يُنشأ من لوحة الأدmin → الخطوة ② → «كود تفعيل الجهاز».' : 'ل دەف بەڕێوەبەری دهێتە دروستکرن → پێنگاڤا ٢ → «کۆدی چالاککرنێ».';
        document.getElementById('dev-block-btn-activate').innerText = isAr ? 'تفعيل' : 'چالاک بکە';
        document.getElementById('dev-block-btn-retry').innerText = isAr ? 'تحقق مرة أخرى' : 'دووبارە پشکنین بکەوە';
    }
    </script>

    <!-- SUB-DEVICE REQUIRES PRO PLUS (mandatory — second laptop / terminal) -->
    <div id="terminal-pro-plus-screen" class="startup-overlay modal-overlay" style="display:none; z-index: 2147483002;">
        <div class="startup-bg" aria-hidden="true"></div>
        <div class="startup-glass-card glass-card startup-card-inner terminal-pro-plus-card" style="max-width: 560px;">
            <div class="terminal-pro-plus-icon" aria-hidden="true"><i class="fas fa-crown"></i></div>
            <h2 class="startup-title terminal-pro-plus-title" data-i18n="terminal_pro_required_title">Pro پێویستە</h2>
            <p id="terminal-pro-plus-msg" class="terminal-pro-plus-msg" data-i18n="terminal_pro_required_msg">بۆ کردنەوەی خانەی لاوەکی (LAN/Wi-Fi) پلانی Pro پێویستە. سەرەتا بەرز بکەرەوە ($224)، دواتر هەر خانەیەک $99.</p>
            <p style="font-size: 0.85rem; color: #94a3b8; margin: 0 0 8px 0;">رقم التثبيت · Installation serial:</p>
            <p id="terminal-pro-plus-serial" dir="ltr" style="font-family: 'Rudaw', sans-serif; text-align: center; background: #1e293b; color: #f8fafc; border: 1px solid #475569; padding: 12px; border-radius: 8px; word-break: break-all; font-size: 0.9rem; margin: 0 0 14px 0;"></p>
            <div id="terminal-pro-plus-term-form" style="margin: 0 0 14px; padding: 12px; border-radius: 10px; border: 1px solid rgba(56, 189, 248, 0.4); background: rgba(56, 189, 248, 0.1); text-align: right;">
                <p style="margin:0 0 8px; color:#7dd3fc; font-weight:700; font-size:0.9rem;"><i class="fas fa-key"></i> <span data-i18n="terminal_mobile_enter_term">کۆدێ TERM ژ لاپتۆپێ سەرەکی ل ڤێرێ بنڤیسە</span></p>
                <input type="text" id="terminal-pro-plus-code-input" dir="ltr" placeholder="TERM-XXXX-XXXX" autocomplete="off" autocorrect="off" autocapitalize="characters" spellcheck="false" inputmode="text" enterkeyhint="done" style="width:100%; min-height:48px; box-sizing:border-box; padding:12px 14px; border-radius:8px; border:1px solid #475569; background:#fff; color:#0f172a; font-family:'Rudaw',sans-serif; letter-spacing:0.08em; font-size:16px; -webkit-user-select:text; user-select:text;" onkeydown="if(event.key==='Enter'){event.preventDefault(); if(typeof posRedeemTerminalActivationCode==='function')posRedeemTerminalActivationCode({inputEl:document.getElementById('terminal-pro-plus-code-input'),msgEl:document.getElementById('terminal-pro-plus-code-msg'),btnEl:document.getElementById('terminal-pro-plus-code-btn')});}">
                <button type="button" class="btn btn-start-system" id="terminal-pro-plus-code-btn" style="width:100%; margin-top:10px; min-height:48px;" onclick="if(typeof posRedeemTerminalActivationCode==='function'){posRedeemTerminalActivationCode({inputEl:document.getElementById('terminal-pro-plus-code-input'),msgEl:document.getElementById('terminal-pro-plus-code-msg'),btnEl:this});}return false;">
                    <i class="fas fa-unlock"></i> <span data-i18n="terminal_activation_submit">چالاککردن</span>
                </button>
                <p id="terminal-pro-plus-code-msg" style="display:none; margin:8px 0 0; font-size:0.85rem;"></p>
            </div>
            <button type="button" class="btn btn-start-system terminal-pro-plus-upgrade-btn" onclick="if(typeof posGoProPlusUpgradeFromTerminalScreen==='function')posGoProPlusUpgradeFromTerminalScreen();">
                <i class="fas fa-arrow-up"></i>
                <span data-i18n="terminal_pro_required_upgrade_btn">بەرزکردنەوە بۆ Pro</span>
            </button>
            <button type="button" class="btn btn-start-system" style="margin-top: 10px; background: transparent; border: 1px solid #475569;" onclick="if(typeof connectToDB==='function'){connectToDB(false);}else{location.reload();}">
                <i class="fas fa-sync"></i>
                <span data-i18n="terminal_pro_plus_recheck">Check again after upgrade</span>
            </button>
        </div>
    </div>

    <!-- TERMINAL ACTIVATION (sub-device LAN/Wi-Fi — TERM code only) -->
    <div id="terminal-activation-screen" class="startup-overlay modal-overlay" style="display:none; z-index: 2147483003;">
        <div class="startup-bg" aria-hidden="true"></div>
        <div class="startup-glass-card glass-card startup-card-inner terminal-activation-card" style="max-width: 580px;">
            <h2 class="startup-title" style="font-size: 1.35rem; color: #38bdf8;"><i class="fas fa-tablet-alt"></i> <span data-i18n="terminal_activation_title">Terminal Activation</span></h2>
            <p id="terminal-activation-msg" class="terminal-activation-msg" data-i18n="terminal_activation_desc">کۆدا سیکوریتیێ لاپتۆپێ فرعی — دوای چالاککردن هەموو براوزەر/Chrome لەسەر هەمان لاپتۆپ ئازادن.</p>
            <p style="font-size: 0.85rem; color: #94a3b8; margin: 0 0 6px 0;" data-i18n="terminal_activation_mac_label">Network adapter MAC (Wi-Fi / LAN):</p>
            <p id="terminal-activation-mac" dir="ltr" style="font-family: 'Rudaw', sans-serif; text-align: center; background: #0c4a6e; color: #bae6fd; border: 1px solid #0369a1; padding: 12px; border-radius: 8px; word-break: break-all; font-size: 0.92rem; margin: 0 0 14px 0;">—</p>
            <p style="font-size: 0.85rem; color: #94a3b8; margin: 0 0 6px 0;">رقم التثبيت · Store serial:</p>
            <p id="terminal-activation-serial" dir="ltr" style="font-family: 'Rudaw', sans-serif; text-align: center; background: #1e293b; color: #f8fafc; border: 1px solid #475569; padding: 10px; border-radius: 8px; font-size: 0.88rem; margin: 0 0 16px 0;"></p>
            <div id="terminal-activation-form" style="margin-bottom: 14px; padding: 14px; border-radius: 10px; border: 1px solid rgba(56, 189, 248, 0.35); background: rgba(56, 189, 248, 0.08);">
                <p style="font-size: 0.88rem; color: #7dd3fc; margin: 0 0 10px 0;"><i class="fas fa-key"></i> <span data-i18n="terminal_activation_code_label">Terminal code (TERM-XXXX-XXXX)</span></p>
                <div class="terminal-activation-actions">
                    <input type="text" id="terminal-activation-code-input" dir="ltr" placeholder="TERM-XXXX-XXXX" autocomplete="off" autocorrect="off" autocapitalize="characters" spellcheck="false" inputmode="text" enterkeyhint="done" style="flex:1; min-width:0; width:100%; min-height:48px; padding:12px 14px; border-radius:8px; border:1px solid #475569; background:#fff; color:#0f172a; font-family:'Rudaw',sans-serif; letter-spacing:0.08em; font-size:16px; -webkit-user-select:text; user-select:text;" />
                    <button type="button" class="btn btn-start-system" id="terminal-activation-submit-btn" style="margin:0; white-space:nowrap;" onclick="if(typeof posRedeemTerminalActivationCode==='function'){posRedeemTerminalActivationCode();}return false;">
                        <i class="fas fa-unlock"></i>
                        <span data-i18n="terminal_activation_submit">Activate terminal</span>
                    </button>
                </div>
                <p id="terminal-activation-status-msg" style="display:none; margin:10px 0 0; font-size:0.85rem; line-height:1.5;"></p>
            </div>
            <p style="text-align:center; margin:0 0 12px 0; font-size:0.88rem;">
                <button type="button" class="btn btn-dark btn-sm" onclick="if(typeof posPasteTerminalCodeFromClipboard==='function'){posPasteTerminalCodeFromClipboard();}else if(typeof posFocusTerminalCodeInput==='function'){posFocusTerminalCodeInput();}">
                    <i class="fas fa-paste"></i> <span data-i18n="terminal_activation_paste_code">کۆد لێرە بنووسە / Paste</span>
                </button>
            </p>
            <p class="terminal-activation-security-note" data-i18n="terminal_activation_security_note">ئاسایش: هەر خانەیەک = یەک لاپتۆپ/موبایلی فرعی. کۆدەکە لە لاپتۆپی سەرەکی ڕێکخستنەکان → خانەکانی سیکوریتی وەردەگیرێت.</p>
            <p style="font-size:0.82rem;color:#fbbf24;margin:0 0 10px 0;line-height:1.5;" data-i18n="terminal_activation_lan_hint">⚠️ لاپتۆپێ فرعی: لە Chrome بنووسە <strong dir="ltr">http://IP-سەرەکی/pos/</strong> — نەک localhost.</p>
            <button type="button" class="btn btn-start-system" style="margin-top: 10px; background: transparent; border: 1px solid #475569;" onclick="if(typeof connectToDB==='function'){connectToDB(false);}else{location.reload();}">
                <i class="fas fa-sync"></i>
                <span data-i18n="terminal_activation_recheck">Check again</span>
            </button>
        </div>
    </div>

    <!-- LICENSE BLOCKED (Server not activated for this installation) -->
    <div id="license-block-screen" class="startup-overlay modal-overlay" style="display:none; z-index: 2147483000;">
        <div class="startup-bg" aria-hidden="true"></div>
        <div class="startup-glass-card glass-card startup-card-inner" style="max-width: 520px; position: relative;">
            <div style="position: absolute; top: 12px; left: 16px; right: 16px; display: flex; justify-content: space-between; align-items: center;">
                <select id="license-lang-toggle" onchange="toggleLicenseLang(this.value)" style="background: rgba(0,0,0,0.4); color: white; border: 1px solid #475569; border-radius: 6px; padding: 4px 8px; font-size: 0.85rem; cursor: pointer; outline: none;">
                    <option value="badini">کوردی (بادینی)</option>
                    <option value="ar">العربية</option>
                </select>
                <button onclick="if(typeof promptLicenseActivationCode==='function')promptLicenseActivationCode()" style="background: transparent; border: none; color: #94a3b8; font-size: 0.85rem; cursor: pointer; text-decoration: underline;" id="btn-lic-offline">کۆدی ئۆفلایین</button>
            </div>
            
            <h2 id="lic-title" class="startup-title" style="font-size: 1.35rem; color: #fca5a5; margin-top: 24px;">🔒 سێرڤەر چالاک نەکراوە</h2>
            <p id="license-block-msg" style="line-height: 1.75; color: #e2e8f0; margin: 12px 0;"></p>
            
            <p id="lic-lbl-serial" style="font-size: 0.9rem; color: #94a3b8; margin-bottom: 6px;">سێریاڵی کۆمپیوتەرەکەت (بۆ بەڕێوەبەری بنێرە):</p>
            <p id="license-block-serial" dir="ltr" style="font-family: 'Rudaw', sans-serif; text-align: center; background: #1e293b; color: #f8fafc; border: 1px solid #475569; padding: 14px; border-radius: 8px; word-break: break-all; font-size: 0.95rem; letter-spacing: 0.5px; margin: 0 0 8px 0; min-height: 1.5em;"></p>
            
            <p id="lic-lbl-sec" style="font-size: 0.9rem; color: #94a3b8; margin-bottom: 6px;">کۆدی ئاسایش (Security Code):</p>
            <p id="license-block-security" dir="ltr" style="font-family: 'Rudaw', sans-serif; text-align: center; background: #1e293b; color: #fde68a; border: 1px solid #ca8a04; padding: 14px; border-radius: 8px; word-break: break-all; font-size: 1.05rem; letter-spacing: 0.15em; margin: 0 0 8px 0; min-height: 1.5em;"></p>
            <p id="license-block-tech" style="display:none; font-size: 0.78rem; color: #64748b; margin: 0 0 16px 0; line-height: 1.4;"></p>
            <button type="button" class="btn btn-start-system" onclick="location.reload()">
                <i class="fas fa-sync"></i>
                <span id="lic-btn-retry">دووبارە پشکنین بکەوە</span>
            </button>
        </div>
    </div>

    <script>
    function toggleLicenseLang(lang) {
        var isAr = (lang === 'ar');
        document.getElementById('lic-title').innerHTML = isAr ? '🔒 السيرفر غير مفعل' : '🔒 سێرڤەر چالاک نەکراوە';
        document.getElementById('lic-lbl-serial').innerText = isAr ? 'سيريال الكمبيوتر (أرسله للمدير):' : 'سێریاڵی کۆمپیوتەرەکەت (بۆ بەڕێوەبەری بنێرە):';
        document.getElementById('lic-lbl-sec').innerText = isAr ? 'كود الأمان (Security Code):' : 'کۆدی ئاسایش (Security Code):';
        document.getElementById('lic-btn-retry').innerText = isAr ? 'إعادة المحاولة' : 'دووبارە پشکنین بکەوە';
        document.getElementById('btn-lic-offline').innerText = isAr ? 'كود أوفلاين' : 'کۆدی ئۆفلایین';
        
        var msgEl = document.getElementById('license-block-msg');
        var msgText = msgEl.innerText || '';
        
        // Dynamic Translation of common API responses
        if (msgText.includes('چالاک نەکراوە') || msgText.includes('مفعّل بعد')) {
            msgEl.innerText = isAr ? 'النظام غير مفعّل بعد. أرسل السيريال أدناه للمشرف ليفعّله.' : 'سیستەمەکە هێشتا چالاک نەکراوە. سێریاڵەکەی خوارەوە بنێرە بۆ بەڕێوەبەر بۆ ئەوەی بۆتی چالاک بکات.';
        } else if (msgText.includes('ڕاگیراوە') || msgText.includes('موقوف')) {
            msgEl.innerText = isAr ? 'هذا النظام موقوف (محظور). يرجى التواصل مع المشرف.' : 'ئەم سیستەمە ڕاگیراوە (بلۆک کراوە). تکایە پەیوەندی بە بەڕێوەبەرەوە بکە.';
        } else if (msgText.includes('سێریاڵی') || msgText.includes('السيريال غير')) {
            msgEl.innerText = isAr ? 'سيريال النظام غير صالح.' : 'سێریاڵی سیستەمەکە دروست نییە.';
        } else if (msgText.includes('تەواو نییە') || msgText.includes('إعداد السيرفر')) {
            msgEl.innerText = isAr ? 'إعداد السيرفر غير مكتمل.' : 'ڕێکخستنی سێرڤەر تەواو نییە.';
        } else if (msgText.includes('بەردەست نییە') || msgText.includes('السيرفر غير متاح')) {
            msgEl.innerText = isAr ? 'السيرفر غير متاح مؤقتاً (حدود أو شبكة). المحلات المفعلة مسبقاً تستمر بالعمل المحلي.' : 'سێرڤەر بە کاتی بەردەست نییە (سنوور/تۆڕ). ئەو لاپتۆپەی پێشتر چالاک کراوە بەردەوام دەبێت لە کار.';
        }
    }
    </script>

    <script>
    (function(){ try {
        var DEFAULT_APP_LOGO = (typeof window.POS_DEFAULT_LOGO === 'string' && window.POS_DEFAULT_LOGO) ? window.POS_DEFAULT_LOGO : 'public/assets/brand/laptop-duhok-logo.png';
        var storedLogo = typeof localStorage !== 'undefined' && localStorage.getItem('pos_startup_logo');
        if (storedLogo && /blogger\.googleusercontent\.com/i.test(String(storedLogo))) {
            try { localStorage.removeItem('pos_startup_logo'); } catch(eRm) {}
            storedLogo = '';
        }
        var logo = storedLogo || DEFAULT_APP_LOGO;
        var startupLogo = document.getElementById('startup-logo-img');
        if (startupLogo) startupLogo.src = logo;
        var loginLogo = document.getElementById('login-logo-img');
        if (loginLogo) loginLogo.src = logo;
        var headerLogo = document.getElementById('top-header-logo');
        if (headerLogo) headerLogo.src = logo;
        var bootLogo = document.querySelector('.app-boot-loader__logo');
        if (bootLogo) bootLogo.src = logo;
    } catch(e) {} })();
    </script>
    <script>
    (function() {
        function paintMobileConnectQrEarly(qrEl, url) {
            if (!qrEl || !url) return;
            var size = 156;
            qrEl.innerHTML = '';
            if (typeof window.posOfflineQrDataUrl === 'function') {
                var du = window.posOfflineQrDataUrl(url, size);
                if (du) {
                    var im = document.createElement('img');
                    im.alt = 'QR';
                    im.width = size;
                    im.height = size;
                    im.src = du;
                    im.className = 'startup-mobile-qr-img';
                    qrEl.appendChild(im);
                    return;
                }
            }
            if (typeof window.QRCode !== 'undefined') {
                try {
                    var lvl = (window.QRCode.CorrectLevel && window.QRCode.CorrectLevel.M) ? window.QRCode.CorrectLevel.M : 1;
                    new window.QRCode(qrEl, { text: url, width: size, height: size, colorDark: '#000', colorLight: '#fff', correctLevel: lvl });
                    var c = qrEl.querySelector('canvas');
                    if (c) c.style.display = 'block';
                    return;
                } catch (e) {}
            }
            qrEl.innerHTML = '<p class="startup-mobile-qr-fallback">QR — لینکێ ل خوارەوە بەکاربینە</p>';
        }
        window.toggleMobileConnectInfo = function() {
            var info = document.getElementById('mobile-connect-info');
            if (!info) return;
            var open = info.style.display === 'none' || info.style.display === '' || info.hidden;
            if (open) {
                // Ensure z-index is high enough when opened from login screen
                info.style.zIndex = '2147483010';
                info.style.display = 'flex';
                info.hidden = false;
                var urlEl = info.querySelector('.startup-mobile-url');
                var url = ((urlEl && urlEl.getAttribute('data-connect-url')) || (urlEl && urlEl.textContent) || '').trim().replace(/\s+/g, '');
                paintMobileConnectQrEarly(document.getElementById('mobile-connect-qr'), url);
            } else {
                info.style.display = 'none';
                info.hidden = true;
            }
        };
    })();
    </script>

    <!-- LOGIN SCREEN -->
    <div id="login-screen" class="modal-overlay pos-auth-screen" style="display:none;">
        <div class="login-box login-box--lite" style="position: relative;">
            <button type="button" class="startup-mobile-connect-btn" onclick="toggleMobileConnectInfo()" data-i18n-title="startup_mobile_btn_title" title="گرێدانا مۆبایل / تابلێت (Connect Mobile/Tablet)" style="position: absolute; top: 16px; right: 16px;">
                <i class="fas fa-qrcode"></i>
            </button>
            <div class="login-icon-area">
                <img id="login-logo-img" src="<?php echo htmlspecialchars($pos_default_logo_url, ENT_QUOTES, 'UTF-8'); ?>" alt="POS Logo" width="64" height="64" decoding="async" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                <span class="login-icon-fallback" aria-hidden="true"><i class="fas fa-user-shield"></i></span>
            </div>
            <div class="login-header">
                <h2 data-i18n="login_heading">چوونە ژوور</h2>
                <p data-i18n="login_welcome_back">ب خێر هاتییە ڤە</p>
            </div>

            <div class="login-field login-field--staff">
                <label class="login-field__label"><i class="fas fa-users pos-ic" aria-hidden="true"></i> <span data-i18n="login_label_staff">کیش کارمەندی تو؟</span></label>
                <input type="hidden" id="login-user-select" value="">
                <div id="login-staff-list" class="login-staff-list" role="listbox" aria-label="Staff" tabindex="0"></div>
            </div>

            <div class="login-field login-field--pin">
                <label class="login-field__label" for="pin-code"><i class="fas fa-lock pos-ic" aria-hidden="true"></i> <span data-i18n="login_label_pin">PIN</span></label>
                <div style="position: relative;">
                    <input type="password" id="pin-code" class="login-pin-input" placeholder="••••" maxlength="4" value="" inputmode="numeric" autocomplete="off" onkeydown="if(event.key === 'Enter') attemptLogin()" style="padding-left: 40px;">
                    <button type="button" tabindex="-1" onclick="var p = document.getElementById('pin-code'); if(p.type==='password'){ p.type='text'; this.innerHTML='<i class=\'fas fa-eye-slash\'></i>'; } else { p.type='password'; this.innerHTML='<i class=\'fas fa-eye\'></i>'; } p.focus();" style="position: absolute; left: 10px; top: 50%; transform: translateY(-50%); background: none; border: none; color: #94a3b8; cursor: pointer; padding: 5px; font-size: 1.1rem; outline: none; touch-action: manipulation; -webkit-tap-highlight-color: transparent;">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>

            <button class="login-btn-main" onclick="attemptLogin()">
                <i class="fas fa-sign-in-alt"></i> <span data-i18n="login_btn_sign_in">چوونە ژوور</span>
            </button>

            <div id="login-ota-panel" style="display:none; margin:10px 0 4px; padding:12px; border-radius:14px; background:#ecfdf5; border:1px solid #6ee7b7; text-align:right;">
                <p id="login-ota-panel-title" style="margin:0 0 6px; font-weight:800; color:#047857; font-size:0.95rem;"></p>
                <p id="login-ota-panel-body" style="margin:0; color:#334155; font-size:0.85rem; line-height:1.55; white-space:pre-wrap;"></p>
                <div id="login-ota-panel-progress" style="display:none; margin-top:10px;">
                    <div style="height:8px; background:#d1fae5; border-radius:999px; overflow:hidden;">
                        <div id="login-ota-panel-bar" style="height:100%; width:0%; background:#10b981; transition:width .25s;"></div>
                    </div>
                    <p id="login-ota-panel-prog-text" style="margin:6px 0 0; font-size:0.8rem; color:#b45309; font-weight:700;"></p>
                </div>
                <div style="display:flex; gap:6px; margin-top:10px; flex-wrap:wrap; justify-content:stretch;">
                    <button type="button" id="login-ota-panel-later" class="login-btn-sub" style="flex:1; min-width:90px; font-size:0.82rem;" onclick="if(typeof posOtaDismissModal==='function')posOtaDismissModal(); else { var p=document.getElementById('login-ota-panel'); if(p)p.style.display='none'; }">
                        <i class="fas fa-clock"></i> دواتر
                    </button>
                    <button type="button" id="login-ota-panel-check" class="login-btn-sub" style="flex:1; min-width:90px; font-size:0.82rem;" onclick="if(typeof posOtaCheckUpdate==='function')posOtaCheckUpdate(true);">
                        <i class="fas fa-sync-alt"></i> پشکنین
                    </button>
                    <button type="button" id="login-ota-panel-apply" class="login-btn-main" style="flex:1.3; min-width:120px; display:none; font-size:0.85rem; padding:10px;" onclick="if(typeof posOtaDownloadAndApply==='function')posOtaDownloadAndApply();">
                        <i class="fas fa-bolt"></i> ئێستا نوێ بکە
                    </button>
                </div>
            </div>
            <div class="login-footer-actions" style="display: flex; gap: 8px;">
                <button class="login-btn-sub" onclick="openCustomerDisplay()" style="flex: 1;">
                    <i class="fas fa-desktop"></i> <span data-i18n="login_customer_display">شاشا کریاری</span>
                </button>
                <button type="button" id="login-ota-btn" class="login-btn-sub" onclick="window.__posLoginOtaClick && window.__posLoginOtaClick();" style="flex: 1; position:relative;">
                    <i class="fas fa-cloud-download-alt" id="login-ota-btn-icon"></i>
                    <span id="login-ota-btn-label" data-i18n="login_btn_ota">نوێکردنەوە</span>
                    <span id="login-ota-badge" style="display:none; position:absolute; top:-6px; left:-6px; min-width:18px; height:18px; padding:0 5px; border-radius:999px; background:#ef4444; color:#fff; font-size:0.7rem; font-weight:800; line-height:18px; box-shadow:0 2px 8px rgba(239,68,68,.45);">!</span>
                </button>
            </div>
            <p id="login-ota-hint" style="display:none; margin:8px 0 0; text-align:center; font-size:0.82rem; font-weight:700; color:#059669;"></p>
            <script>
            (function () {
                function showLoginOtaPanel(title, body, opts) {
                    opts = opts || {};
                    var panel = document.getElementById('login-ota-panel');
                    var tEl = document.getElementById('login-ota-panel-title');
                    var bEl = document.getElementById('login-ota-panel-body');
                    var applyBtn = document.getElementById('login-ota-panel-apply');
                    var laterBtn = document.getElementById('login-ota-panel-later');
                    var checkBtn = document.getElementById('login-ota-panel-check');
                    var prog = document.getElementById('login-ota-panel-progress');
                    if (!panel) return;
                    panel.style.display = 'block';
                    if (tEl) tEl.textContent = title || '';
                    if (bEl) bEl.textContent = body || '';
                    if (applyBtn) applyBtn.style.display = opts.showApply ? 'inline-flex' : 'none';
                    if (laterBtn) laterBtn.style.display = opts.hideLater ? 'none' : 'inline-flex';
                    if (checkBtn) checkBtn.style.display = opts.hideCheck ? 'none' : 'inline-flex';
                    if (prog && !opts.keepProgress) prog.style.display = 'none';
                    try { panel.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } catch (e) {}
                }
                window.__posShowLoginOtaPanel = showLoginOtaPanel;
                window.__posLoginOtaClick = function () {
                    showLoginOtaPanel('پشکنین…', 'چاوەڕێ بکە — پشکنینی ئابدەیت…', {});
                    var btn = document.getElementById('login-ota-btn');
                    var label = document.getElementById('login-ota-btn-label');
                    if (btn) btn.disabled = true;
                    if (label) label.textContent = 'پشکنین…';
                    function doneLabel() {
                        if (btn) btn.disabled = false;
                        if (label && label.textContent === 'پشکنین…') label.textContent = 'نوێکردنەوە';
                    }
                    function run() {
                        if (typeof window.posOtaFromLoginScreen === 'function') {
                            try { window.posOtaFromLoginScreen(); } catch (e1) {
                                showLoginOtaPanel('هەڵە', String(e1 && e1.message ? e1.message : e1));
                            }
                            setTimeout(doneLabel, 800);
                            return;
                        }
                        // Scripts still loading — retry briefly
                        var n = 0;
                        var iv = setInterval(function () {
                            n++;
                            if (typeof window.posOtaFromLoginScreen === 'function') {
                                clearInterval(iv);
                                window.posOtaFromLoginScreen();
                                doneLabel();
                            } else if (n > 40) {
                                clearInterval(iv);
                                doneLabel();
                                showLoginOtaPanel('چاوەڕێ', 'سیستەم هێشتا بار نەبووە — ٥ چرکە چاوەڕێ بکە و دووبارە کلیک بکە.');
                            }
                        }, 250);
                    }
                    run();
                };
            })();
            </script>
            
            <p id="login-error" style="color:var(--danger); margin-top:8px; font-size:0.9rem; min-height:20px;"></p>
            <p style="text-align:center; margin-top:4px; font-size:0.95rem; font-weight:700; color:var(--text-dark); letter-spacing:0.02em;">
                <span data-pos-app-version style="color:#2563eb; background:#eff6ff; padding:2px 8px; border-radius:6px;">v<?php echo htmlspecialchars(POS_APP_VERSION, ENT_QUOTES, 'UTF-8'); ?></span> 
                <span style="color:var(--text-muted); font-size:0.85rem; font-weight:normal; margin:0 4px;">·</span> 
                <span data-i18n="login_edition_short" style="color:var(--text-muted); font-weight:normal; font-size:0.85rem;">SQL Edition</span>
            </p>
        </div>
    </div>

    <!-- ZAKAT MODAL -->
    <div id="zakat-modal" class="modal-overlay" style="display:none;">
        <div class="glass-card" style="max-width: 480px; width: 95%; background: linear-gradient(to right, #14532d, #052e16); border: 1px solid #166534; color: white;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                <h3 style="margin: 0; color: #86efac;"><i class="fas fa-hand-holding-usd"></i> <span data-i18n="zakat">زەکات</span></h3>
                <button class="btn btn-dark btn-sm" onclick="document.getElementById('zakat-modal').style.display='none'; if(document.querySelector('.sidebar.open')) document.querySelector('.sidebar').classList.remove('open');" style="background: rgba(0,0,0,0.3); border-color: #166534;">✖</button>
            </div>
            <p style="font-size: 0.85rem; color: #86efac; margin-bottom: 15px;"><span data-i18n="zakat_desc">هەژمارکرنا زەکاتێ ل سەر بنەمایێ داتایا دارایی ب ڕێژەیا ٢.٥٪</span></p>
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 15px;">
                <div style="background: rgba(0,0,0,0.2); padding: 10px; border-radius: 12px; text-align: center;">
                    <small style="color: #86efac; display: block; margin-bottom: 4px;"><i class="fas fa-boxes"></i> <span data-i18n="inventory">کۆگەه</span></small>
                    <span id="zakat-modal-inventory" style="font-weight: bold; font-size: 0.95rem;">0</span>
                </div>
                <div style="background: rgba(0,0,0,0.2); padding: 10px; border-radius: 12px; text-align: center;">
                    <small style="color: #86efac; display: block; margin-bottom: 4px;"><i class="fas fa-hand-holding-usd"></i> المرجوة</small>
                    <span id="zakat-modal-receivables" style="font-weight: bold; font-size: 0.95rem;">0</span>
                </div>
                <div style="background: rgba(0,0,0,0.2); padding: 10px; border-radius: 12px; text-align: center;">
                    <small style="color: #86efac; display: block; margin-bottom: 4px;"><i class="fas fa-file-invoice-dollar"></i> <span data-i18n="due">ل سەر تە</span></small>
                    <span id="zakat-modal-liabilities" style="font-weight: bold; font-size: 0.95rem;">0</span>
                </div>
            </div>
            <div style="display: flex; flex-wrap: wrap; align-items: center; gap: 12px; padding: 12px; background: rgba(0,0,0,0.25); border-radius: 16px; border: 1px solid #166534;">
                <div style="flex: 1; min-width: 100px;">
                    <small style="color: #a7f3d0;"><span data-i18n="zakat_wealth">دەرامەتێ زەکاتێ</span></small>
                    <h2 id="zakat-modal-net" style="color: #86efac; margin: 6px 0 0 0; font-size: 1.25rem;">0</h2>
                </div>
                <div style="flex: 1; min-width: 100px; text-align: center;">
                    <small style="color: #a7f3d0;"><span data-i18n="zakat_amount">کوژمێ زەکاتێ (٢.٥٪)</span></small>
                    <h2 id="zakat-modal-amount" style="color: #fef08a; margin: 6px 0 0 0; font-size: 1.35rem;">0</h2>
                </div>
            </div>
            <p style="font-size: 0.75rem; color: #6ee7b7; margin-top: 12px; margin-bottom: 0;"><span data-i18n="zakat_rule">زەکات دهێتە دان دەمێ دەرامەت دگەهیتە نیسابێ. بۆ پتر پێزانینان پرسیارا مامۆستایێ ئایینی بکە.</span></p>
        </div>
    </div>

    <!-- END SHIFT RECONCILE MODAL (Daily Reconcile - النقد الفعلي) -->
    <div id="end-shift-reconcile-modal" class="modal-overlay" style="display:none;">
        <div class="glass-card" style="max-width:420px; width:95%;">
            <h3 style="margin:0 0 12px 0;"><i class="fas fa-cash-register"></i> <span data-i18n="daily_reconcile">هەڤسەنگییا ئەڤرۆ</span></h3>
            <p style="color:var(--text-muted); font-size:0.9rem; margin-bottom:14px;"><span data-i18n="enter_actual_cash">پارێ د قاسێ دا بنڤیسە بۆ هەڤبەرکرنێ دگەل پارێ چاڤەڕێکری.</span></p>
            <div style="margin-bottom:12px;">
                <label style="display:block; font-size:0.85rem; color:var(--text-muted);"><span data-i18n="reconcile_opening_balance">رصيد الافتتاح</span></label>
                <strong id="reconcile-opening" style="font-size:1.1rem;">0</strong>
            </div>
            <div style="margin-bottom:12px;">
                <label style="display:block; font-size:0.85rem; color:var(--text-muted);"><span data-i18n="expected_balance">پارێ چاڤەڕێکری</span></label>
                <strong id="reconcile-expected" style="font-size:1.2rem; color:var(--brand);">0</strong>
                <p id="reconcile-expected-note" style="display:none; font-size:0.8rem; color:#ef4444; margin:4px 0 0 0; line-height:1.4;"></p>
            </div>
            <div style="margin-bottom:14px;">
                <label style="display:block; font-size:0.85rem; margin-bottom:4px;"><span data-i18n="actual_cash">پارێ ل بەر دەست</span></label>
                <input type="text" inputmode="decimal" id="reconcile-actual" class="input-std pos-money-input" placeholder="0" style="margin:0; font-size:1.1rem;" dir="ltr">
            </div>
            <div id="reconcile-result" style="display:none; padding:10px; border-radius:10px; margin-bottom:12px;"></div>
            <div class="page-action-row" style="display:flex; gap:10px;">
                <div class="page-actions-standard" style="display:flex; gap:10px; width:100%;">
                    <button type="button" class="btn btn-brand" style="flex:1;" onclick="submitEndShiftReconcile()"><i class="fas fa-check"></i> <span data-i18n="save_close_session">پاراستن و گرتنا شیفتی</span></button>
                    <button type="button" class="btn btn-dark" style="flex:1;" onclick="document.getElementById('end-shift-reconcile-modal').style.display='none';"><span data-i18n="btn_cancel">پاشگەزبوون</span></button>
                </div>
            </div>
        </div>
    </div>

    <!-- QTY / MONEY PROMPT MODAL (POS / Purchase / Returns / Entity debt) -->
    <div id="pos-qty-prompt-modal" class="modal-overlay pos-qty-prompt-modal" style="display:none;" onclick="if(event.target===this&&typeof cancelPosQtyPrompt==='function')cancelPosQtyPrompt();">
        <div class="glass-card pos-qty-prompt-card" role="dialog" aria-modal="true" aria-labelledby="pos-qty-prompt-title">
            <div class="pos-qty-prompt-head">
                <span class="pos-qty-prompt-icon" id="pos-qty-prompt-icon-wrap" aria-hidden="true"><i id="pos-qty-prompt-icon-i" class="fas fa-balance-scale"></i></span>
                <div>
                    <h2 id="pos-qty-prompt-title" class="pos-qty-prompt-title" data-i18n="pos_qty_prompt_title">ژمارە بنووسە</h2>
                    <p id="pos-qty-prompt-hint" class="pos-qty-prompt-hint" data-i18n="pos_qty_prompt_hint">تا ٣ ژمارە دوای فاریزە (نموونە: ١.٢٥٠)</p>
                </div>
            </div>
            <div class="pos-qty-prompt-input-row">
                <button type="button" class="btn btn-dark pos-qty-step-btn" id="pos-qty-step-minus" onclick="posQtyPromptStepDown()" aria-label="-1">−1</button>
                <input type="text" id="pos-qty-prompt-input" class="input-std pos-qty-prompt-input" inputmode="decimal" autocomplete="off" dir="ltr">
                <button type="button" class="btn btn-dark pos-qty-step-btn" id="pos-qty-step-plus" onclick="posQtyPromptStepUp()" aria-label="+1">+1</button>
            </div>
            <div id="pos-qty-prompt-quick" class="pos-qty-prompt-quick"></div>
            <div class="page-action-row pos-qty-prompt-actions">
                <div class="page-actions-standard">
                    <button type="button" class="btn btn-dark" onclick="cancelPosQtyPrompt()"><i class="fas fa-times"></i> <span data-i18n="btn_cancel">پاشگەزبوون</span></button>
                    <button type="button" class="btn btn-brand" onclick="confirmPosQtyPrompt()"><i class="fas fa-check"></i> <span data-i18n="pos_qty_prompt_apply">جێبەجێکرن</span></button>
                </div>
            </div>
        </div>
    </div>

    <!-- ENTITY QUICK-ADD MODAL (Customer / Supplier) -->
    <div id="pos-entity-name-modal" class="modal-overlay pos-entity-name-modal" style="display:none;" onclick="if(event.target===this&&typeof cancelPosEntityNamePrompt==='function')cancelPosEntityNamePrompt();">
        <div class="glass-card pos-entity-name-card" role="dialog" aria-modal="true" aria-labelledby="pos-entity-name-title">
            <div class="pos-entity-name-head">
                <span id="pos-entity-name-icon" class="pos-entity-name-icon" aria-hidden="true"><i class="fas fa-user-plus"></i></span>
                <div>
                    <h2 id="pos-entity-name-title" class="pos-entity-name-title"></h2>
                    <p id="pos-entity-name-hint" class="pos-entity-name-hint"></p>
                </div>
            </div>
            <div class="pos-entity-name-form">
                <div class="pos-entity-section pos-entity-section--main">
                    <div class="pos-entity-name-field pos-entity-name-field--full">
                        <label for="pos-entity-name-input" id="pos-entity-name-label" data-i18n="debt_new_name_ph">ناڤ</label>
                        <input type="text" id="pos-entity-name-input" class="input-std pos-entity-name-input" autocomplete="off" spellcheck="false">
                    </div>
                </div>
                <div class="pos-entity-section pos-entity-section--contact" id="pos-entity-contact-section">
                    <div class="pos-entity-section-title"><i class="fas fa-address-card"></i> <span data-i18n="pos_entity_section_contact">پەیوەندی</span></div>
                    <div class="pos-entity-name-row" id="pos-entity-contact-row">
                        <div class="pos-entity-name-field">
                            <label for="pos-entity-phone-input" id="pos-entity-phone-label" data-i18n="debt_new_phone_ph">ژمارا تەلەفۆنێ</label>
                            <input type="text" id="pos-entity-phone-input" class="input-std pos-entity-contact-input" autocomplete="off" inputmode="tel" dir="ltr">
                        </div>
                        <div class="pos-entity-name-field">
                            <label for="pos-entity-address-input" id="pos-entity-address-label" data-i18n="debt_new_address_ph">ناڤنیشان</label>
                            <input type="text" id="pos-entity-address-input" class="input-std pos-entity-contact-input" autocomplete="off">
                        </div>
                    </div>
                </div>
                <div class="pos-entity-section pos-entity-section--debt" id="pos-entity-debt-row">
                    <div class="pos-entity-section-title"><i class="fas fa-coins"></i> <span data-i18n="pos_entity_section_debt">زانیاریێن قەرز</span></div>
                    <div class="pos-entity-name-row">
                        <div class="pos-entity-name-field pos-entity-money-field">
                            <label for="pos-entity-opening-input" id="pos-entity-opening-label" data-i18n="debt_new_opening_ph">دەینی کەڤن</label>
                            <div class="pos-entity-money-control">
                                <button type="button" class="btn btn-dark pos-entity-money-step" id="pos-entity-opening-minus" onclick="adjustPosEntityMoneyField('opening', -1)" aria-label="-">−</button>
                                <input type="text" id="pos-entity-opening-input" class="input-std pos-money-input pos-entity-money-input" value="0" inputmode="decimal" dir="ltr" autocomplete="off">
                                <button type="button" class="btn btn-dark pos-entity-money-step" id="pos-entity-opening-plus" onclick="adjustPosEntityMoneyField('opening', 1)" aria-label="+">+</button>
                            </div>
                            <div id="pos-entity-opening-quick" class="pos-entity-money-quick"></div>
                        </div>
                        <div class="pos-entity-name-field pos-entity-money-field">
                            <label for="pos-entity-limit-input" id="pos-entity-limit-label" data-i18n="debt_new_limit_ph">سنووری قەرز</label>
                            <div class="pos-entity-money-control">
                                <button type="button" class="btn btn-dark pos-entity-money-step" id="pos-entity-limit-minus" onclick="adjustPosEntityMoneyField('limit', -1)" aria-label="-">−</button>
                                <input type="text" id="pos-entity-limit-input" class="input-std pos-money-input pos-entity-money-input" value="0" inputmode="decimal" dir="ltr" autocomplete="off">
                                <button type="button" class="btn btn-dark pos-entity-money-step" id="pos-entity-limit-plus" onclick="adjustPosEntityMoneyField('limit', 1)" aria-label="+">+</button>
                            </div>
                            <div id="pos-entity-limit-quick" class="pos-entity-money-quick"></div>
                        </div>
                        <div class="pos-entity-name-field">
                            <label for="pos-entity-payment-term-value" id="pos-entity-payment-term-label" data-i18n="payment_due_label">مەوعدێ پارەدانێ</label>
                            <div class="pos-entity-name-row" style="gap:8px;">
                                <input type="number" id="pos-entity-payment-term-value" class="input-std pos-entity-contact-input" min="0" step="1" value="0" inputmode="numeric" dir="ltr" autocomplete="off" style="flex:1;">
                                <select id="pos-entity-payment-term-unit" class="input-std" style="width:auto; min-width:7rem;">
                                    <option value="minute" data-i18n-opt="payment_term_unit_minute">خولەک</option>
                            <option value="hour" data-i18n-opt="payment_term_unit_hour">دەمژمێر</option>
                                    <option value="day" data-i18n-opt="payment_term_unit_day" selected>ڕۆژ</option>
                                    <option value="month" data-i18n-opt="payment_term_unit_month">مانگ</option>
                                    <option value="year" data-i18n-opt="payment_term_unit_year">ساڵ</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="page-action-row pos-entity-name-actions">
                <div class="page-actions-standard">
                    <button type="button" class="btn btn-dark" onclick="cancelPosEntityNamePrompt()"><i class="fas fa-times"></i> <span data-i18n="btn_cancel">پاشگەزبوون</span></button>
                    <button type="button" class="btn btn-brand" onclick="confirmPosEntityNamePrompt()"><i class="fas fa-check"></i> <span data-i18n="pos_entity_name_apply">پاراستن</span></button>
                </div>
            </div>
        </div>
    </div>

    <!-- CATEGORY MANAGE MODAL (Rename / Delete) -->
    <div id="pos-category-manage-modal" class="modal-overlay pos-category-manage-modal" style="display:none;" onclick="if(event.target===this&&typeof closePosCategoryManageModal==='function')closePosCategoryManageModal();">
        <div class="glass-card pos-category-manage-card" role="dialog" aria-modal="true" aria-labelledby="pos-category-manage-title">
            <div class="pos-category-manage-head">
                <span class="pos-entity-name-icon pos-entity-name-icon--category" aria-hidden="true"><i class="fas fa-tags"></i></span>
                <div>
                    <h2 id="pos-category-manage-title" class="pos-entity-name-title" data-i18n="pos_category_manage_title">ڕێکخستنی پۆل</h2>
                    <p id="pos-category-manage-hint" class="pos-entity-name-hint" data-i18n="pos_category_manage_hint">گوهۆڕینا ناڤی یان ژێبرنی پۆلێ هەڵبژێردراو</p>
                </div>
            </div>
            <div class="pos-category-manage-pill" id="pos-category-manage-name">—</div>
            <div id="pos-category-manage-actions" class="pos-category-manage-actions">
                <button type="button" class="btn btn-brand pos-category-manage-btn" onclick="posCategoryManageChooseRename()">
                    <i class="fas fa-pen"></i> <span data-i18n="pos_category_manage_rename">گوهۆڕینا ناڤی</span>
                </button>
                <button type="button" class="btn btn-danger pos-category-manage-btn" onclick="posCategoryManageShowDeleteConfirm()">
                    <i class="fas fa-trash-alt"></i> <span data-i18n="pos_category_manage_delete">ژێبرن</span>
                </button>
            </div>
            <div id="pos-category-delete-panel" class="pos-category-delete-panel is-hidden" hidden>
                <p id="pos-category-delete-warning" class="pos-category-delete-warning"></p>
                <div class="page-action-row pos-category-delete-actions">
                    <button type="button" class="btn btn-dark" onclick="posCategoryManageHideDeleteConfirm()"><i class="fas fa-arrow-right"></i> <span data-i18n="product_form_btn_back">پاش</span></button>
                    <button type="button" class="btn btn-danger" onclick="posCategoryManageConfirmDelete()"><i class="fas fa-trash-alt"></i> <span data-i18n="pos_category_manage_delete_confirm">بەڵێ، بسڕەوە</span></button>
                </div>
            </div>
            <div class="page-action-row pos-category-manage-footer">
                <button type="button" class="btn btn-dark" onclick="closePosCategoryManageModal()"><i class="fas fa-times"></i> <span data-i18n="btn_cancel">پاشگەزبوون</span></button>
            </div>
        </div>
    </div>

    <!-- OPENING BALANCE MODAL -->
    <div id="opening-balance-modal" class="modal-overlay" style="display:none;">
        <div class="glass-card" style="width: 420px; text-align: right;">
            <h2 style="margin-top:0;"><i class="fas fa-cash-register"></i> <span data-i18n="shift_opening_title">پارێ دەستپێکێ د قاسێ دا</span></h2>
            <p style="color:var(--text-muted); font-size:0.9rem; margin-bottom:10px;">
                <span data-i18n="shift_opening_hint">دڵنیابە کا چەند پارە د قاسێ دا هەنە؟ ئەڤ ژمارە دێ هێتە تومارکرن بۆ ڤی شیفتی و تەنێ بۆ هەڤبەرهەڤکرنا قاسێ دێ هێتە بکارئینان.</span>
            </p>
            <input type="text" inputmode="decimal" id="opening-balance-input" class="input-std pos-money-input" data-i18n-placeholder="shift_opening_placeholder" placeholder="نموونە: 100000" style="margin-bottom:10px; direction:ltr; text-align:left;">
            <div class="page-action-row" style="display:flex; justify-content:flex-end; margin-top:5px;">
                <div class="page-actions-standard" style="display:flex; gap:10px;">
                    <button type="button" class="btn btn-dark" onclick="cancelOpeningBalance()"><i class="fas fa-times"></i> <span data-i18n="shift_opening_later">پاشێ</span></button>
                    <button type="button" class="btn btn-brand" onclick="confirmOpeningBalance()"><i class="fas fa-check"></i> <span data-i18n="shift_opening_confirm">دڵنیاکرن</span></button>
                </div>
            </div>
        </div>
    </div>

    <!-- FIRST-RUN BUSINESS TYPE (Market / Pharmacy / …) -->
    <div id="first-run-business-modal" class="modal-overlay first-run-business-modal" style="display:none;" role="dialog" aria-labelledby="first-run-business-title" aria-modal="true">
        <div class="glass-card first-run-business-card" style="max-width: 780px; width: 96%; text-align: right;">
            <h2 id="first-run-business-title" style="margin-top:0; color:var(--brand);"><i class="fas fa-store"></i> <span data-i18n="first_run_business_title">جۆرێ کاروبارێ هەلبژێرە</span></h2>
            <p style="color:var(--text-muted); font-size:0.92rem; margin:0 0 14px 0;" data-i18n="first_run_business_subtitle">ئەڤ سیستەمە بۆ چ جۆرێ کارێیە؟ مارکێت، سەیدەلی، مەتعەم… — بەش و ئایکۆن بەپێی هەلبژاردنێ دەگونجێن.</p>
            <div id="first-run-business-grid" class="first-run-business-grid" role="listbox" aria-label="Business type"></div>
            <div id="first-run-business-preview" class="first-run-business-preview" style="display:none;">
                <div class="first-run-business-preview__title"><i class="fas fa-list-check"></i> <span data-i18n="first_run_business_features_title">بەشێن چالاک بۆ ئەڤ جۆرێ:</span></div>
                <div id="first-run-business-features" class="first-run-business-features"></div>
            </div>
            <p id="first-run-business-error" class="first-run-business-error" style="display:none;"></p>
            <div class="page-action-row" style="display:flex; justify-content:flex-end; margin-top:16px;">
                <button type="button" class="btn btn-brand" id="first-run-business-confirm" onclick="confirmFirstRunBusinessSetup()" disabled>
                    <i class="fas fa-check"></i> <span data-i18n="first_run_business_confirm">دەستپێکرن</span>
                </button>
            </div>
        </div>
    </div>

    <!-- SIDEBAR -->
    <div class="sidebar">
        <div class="menu-screen-header">
            <div class="menu-user-info">
                <i class="fas fa-user-circle" style="font-size:3.5rem;"></i>
                <div>
                    <h2 id="user-display" style="margin:0;">User</h2>
                    <small style="opacity:0.7; cursor:pointer;" onclick="if(typeof openCurrentUserProfile==='function'){openCurrentUserProfile();}"><span data-i18n="profile_view_link">View Profile</span></small>
                </div>
            </div>
            <div style="display:flex; gap:10px;">
                <button class="btn btn-dark" onclick="toggleSidebar()"><i class="fas fa-times"></i> Close</button>
            </div>
        </div>
        
        <div style="margin-bottom:20px; display:flex; gap:20px; color:rgba(255,255,255,0.7); font-size:0.9rem; align-items:center;">
             <span><i id="save-status-dot" class="fas fa-circle" style="color:gray;"></i> <span id="save-status-text">Local</span></span>
             <span id="btn-toggle-menu-sections" onclick="toggleMenuSections()" style="cursor:pointer" title="وضع تعديل: انقر للدخول واختيار الأقسام المخفية (Edit mode)"><i id="icon-toggle-menu-sections" class="fas fa-pen"></i> <span id="label-toggle-menu-sections"><span data-i18n="menu_sections">بەشێن مێنیۆیێ</span></span></span>
             <span onclick="openCustomerDisplay()" style="cursor:pointer"><i class="fas fa-desktop"></i> <span data-i18n="login_customer_display">شاشا کریاری</span></span>
             <span class="sidebar-premium-link" onclick="if(typeof showPremiumLockedPurchasePopup==='function')showPremiumLockedPurchasePopup('');" style="cursor:pointer" title="Pro / Pro Plus"><i class="fas fa-crown" style="color:#fbbf24;"></i> <span data-i18n="sidebar_premium_title">وەشانا پارەدار</span></span>
        </div>

        <nav id="main-nav"></nav>
    </div>

