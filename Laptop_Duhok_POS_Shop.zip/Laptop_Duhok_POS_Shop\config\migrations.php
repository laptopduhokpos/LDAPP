<?php
/**
 * Schema migrations (idempotent).
 *
 * Trigger: included from `config/database.php` after a successful mysqli connection.
 * `pos_run_migrations_if_needed()` runs the body only while `settings.schema_version`
 * is behind `POS_SCHEMA_VERSION` (MySQL advisory lock avoids concurrent ALTER churn).
 */

// Bump this when you change migration logic.
    if (!defined('POS_SCHEMA_VERSION')) {
        define('POS_SCHEMA_VERSION', 36);
    }

require_once __DIR__ . '/supabase_license.php';

function pos_migrations_log($message) {
    @file_put_contents(__DIR__ . '/../pos_debug.log', date('Y-m-d H:i:s') . " - MIGRATE - " . $message . "\n", FILE_APPEND);
}

function pos_db_get_setting_value($conn, $key) {
    try {
        $stmt = $conn->prepare("SELECT setting_value FROM settings WHERE setting_key = ? LIMIT 1");
        if (!$stmt) return null;
        $stmt->bind_param("s", $key);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res && ($row = $res->fetch_assoc())) {
            return $row['setting_value'];
        }
    } catch (Throwable $e) {
        // settings table might not exist yet
    }
    return null;
}

function pos_db_set_setting_value($conn, $key, $val) {
    try {
        $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
        if (!$stmt) return false;
        $stmt->bind_param("ss", $key, $val);
        return (bool)$stmt->execute();
    } catch (Throwable $e) {
        return false;
    }
}

function pos_db_try_get_lock($conn, $lockName, $timeoutSeconds = 10) {
    try {
        $stmt = $conn->prepare("SELECT GET_LOCK(?, ?) AS l");
        if (!$stmt) return false;
        $stmt->bind_param("si", $lockName, $timeoutSeconds);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res && ($row = $res->fetch_assoc())) {
            return (int)($row['l'] ?? 0) === 1;
        }
    } catch (Throwable $e) {}
    return false;
}

function pos_db_release_lock($conn, $lockName) {
    try {
        $stmt = $conn->prepare("SELECT RELEASE_LOCK(?) AS r");
        if (!$stmt) return;
        $stmt->bind_param("s", $lockName);
        $stmt->execute();
    } catch (Throwable $e) {}
}

/**
 * Payment-due deadline columns (customer/company terms + sale/supply due_at).
 * Runs on connect so shops already at an older schema_version still get the columns.
 */
function pos_ensure_payment_due_schema($conn) {
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    if (!$conn || !($conn instanceof mysqli) || !function_exists('checkAndAddCol')) {
        return;
    }
    checkAndAddCol($conn, 'customers', 'payment_term_value', "INT NOT NULL DEFAULT 0");
    checkAndAddCol($conn, 'customers', 'payment_term_unit', "VARCHAR(10) NOT NULL DEFAULT 'day'");
    checkAndAddCol($conn, 'companies', 'payment_term_value', "INT NOT NULL DEFAULT 0");
    checkAndAddCol($conn, 'companies', 'payment_term_unit', "VARCHAR(10) NOT NULL DEFAULT 'day'");
    checkAndAddCol($conn, 'sales', 'payment_due_at', "DATETIME NULL DEFAULT NULL");
    checkAndAddCol($conn, 'supplies', 'payment_due_at', "DATETIME NULL DEFAULT NULL");
    checkAndAddCol($conn, 'supplies', 'remaining_debt', "DECIMAL(18,3) NULL DEFAULT NULL");
    @$conn->query(
        "UPDATE supplies SET remaining_debt = totalCost "
        . "WHERE remaining_debt IS NULL AND type IN ('credit','split')"
    );
}

/**
 * After-sale WhatsApp care: mark when the shop has messaged the customer.
 * Idempotent so shops already at current schema_version still get the column.
 */
function pos_ensure_sale_followup_schema($conn) {
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    if (!$conn || !($conn instanceof mysqli) || !function_exists('checkAndAddCol')) {
        return;
    }
    checkAndAddCol($conn, 'sales', 'followup_sent_at', "DATETIME NULL DEFAULT NULL");
    try {
        $conn->query("CREATE INDEX idx_sales_followup ON sales (followup_sent_at, created_at, customer_id)");
    } catch (Throwable $e) {}
    try {
        $conn->query(
            "CREATE TABLE IF NOT EXISTS sale_followup_sends (
                sale_id BIGINT NOT NULL,
                step_key VARCHAR(16) NOT NULL,
                sent_at DATETIME NOT NULL,
                PRIMARY KEY (sale_id, step_key)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );
    } catch (Throwable $e) {}
}

/**
 * Checkout INSERT columns. Format/restore can leave schema_version current
 * while sales.tax_discount (and siblings) are missing.
 */
function pos_ensure_sales_checkout_columns($conn) {
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    if (!$conn || !($conn instanceof mysqli) || !function_exists('checkAndAddCol')) {
        return;
    }
    checkAndAddCol($conn, 'sales', 'payment_method', "VARCHAR(20) DEFAULT 'cash'");
    checkAndAddCol($conn, 'sales', 'customer_id', "INT DEFAULT 0");
    checkAndAddCol($conn, 'sales', 'customer_type', "VARCHAR(20) DEFAULT 'customer'");
    checkAndAddCol($conn, 'sales', 'is_returned', "TINYINT(1) DEFAULT 0");
    checkAndAddCol($conn, 'sales', 'transaction_id', "VARCHAR(40)");
    checkAndAddCol($conn, 'sales', 'sale_request_key', "VARCHAR(80) DEFAULT NULL");
    checkAndAddCol($conn, 'sales', 'paid_amount', "DECIMAL(12,2) DEFAULT 0");
    checkAndAddCol($conn, 'sales', 'debt_amount', "DECIMAL(12,2) DEFAULT 0");
    checkAndAddCol($conn, 'sales', 'bank_amount', "DECIMAL(12,2) DEFAULT 0");
    checkAndAddCol($conn, 'sales', 'received_amount', "DECIMAL(12,2) DEFAULT 0");
    checkAndAddCol($conn, 'sales', 'total_bill', "DECIMAL(12,2) DEFAULT 0");
    checkAndAddCol($conn, 'sales', 'tax_discount', "DECIMAL(12,2) DEFAULT 0");
    checkAndAddCol($conn, 'sales', 'paid_cash', "DECIMAL(12,2) DEFAULT 0");
    checkAndAddCol($conn, 'sales', 'paid_bank', "DECIMAL(12,2) DEFAULT 0");
    checkAndAddCol($conn, 'sales', 'remaining_debt', "DECIMAL(12,2) DEFAULT 0");
    checkAndAddCol($conn, 'sales', 'warehouse_id', "INT NOT NULL DEFAULT 0");
    checkAndAddCol($conn, 'sales', 'fx_usd_rate', "INT UNSIGNED NULL DEFAULT NULL");
    checkAndAddCol($conn, 'sales', 'fx_currency_mode', "VARCHAR(3) NULL DEFAULT NULL");
}

function pos_parse_followup_schedule($settings) {
    $out = [];
    $raw = is_array($settings) ? ($settings['saleFollowupSchedule'] ?? null) : null;
    if (is_array($raw)) {
        foreach ($raw as $row) {
            if (!is_array($row)) {
                continue;
            }
            $unit = strtolower(trim((string)($row['unit'] ?? 'day')));
            if ($unit === 'min' || $unit === 'mins' || $unit === 'minutes') {
                $unit = 'minute';
            }
            if ($unit === 'hr' || $unit === 'hrs' || $unit === 'hours') {
                $unit = 'hour';
            }
            if ($unit === 'days') {
                $unit = 'day';
            }
            if (!in_array($unit, ['minute', 'hour', 'day'], true)) {
                $unit = 'day';
            }
            $value = (int)($row['value'] ?? 0);
            if ($value < 1) {
                continue;
            }
            if ($unit === 'day' && $value > 365) {
                $value = 365;
            }
            if ($unit !== 'day' && $value > 999) {
                $value = 999;
            }
            $short = ($unit === 'minute') ? 'm' : (($unit === 'hour') ? 'h' : 'd');
            $key = $value . $short;
            $seen = false;
            foreach ($out as $ex) {
                if ($ex['key'] === $key) {
                    $seen = true;
                    break;
                }
            }
            if ($seen) {
                continue;
            }
            $out[] = ['value' => $value, 'unit' => $unit, 'key' => $key];
            if (count($out) >= 6) {
                break;
            }
        }
    }
    if (!$out) {
        $days = is_array($settings) ? (int)($settings['saleFollowupDays'] ?? 10) : 10;
        if ($days !== 30) {
            $days = 10;
        }
        $out[] = ['value' => $days, 'unit' => 'day', 'key' => $days . 'd'];
    }
    return $out;
}

function pos_followup_step_seconds($value, $unit) {
    $value = max(1, (int)$value);
    if ($unit === 'minute') {
        return $value * 60;
    }
    if ($unit === 'hour') {
        return $value * 3600;
    }
    return $value * 86400;
}

function pos_followup_grace_seconds($value, $unit) {
    $value = max(1, (int)$value);
    if ($unit === 'minute') {
        return max($value * 3, 30) * 60;
    }
    if ($unit === 'hour') {
        return max($value * 2, 6) * 3600;
    }
    return max($value, 21) * 86400;
}

function pos_followup_load_app_settings($conn) {
    if (!$conn) {
        return [];
    }
    $res = $conn->query("SELECT setting_value FROM settings WHERE setting_key = 'app_settings' LIMIT 1");
    if ($res && ($row = $res->fetch_assoc())) {
        $dec = json_decode((string)($row['setting_value'] ?? '{}'), true);
        if (is_array($dec)) {
            return $dec;
        }
    }
    return [];
}

function pos_followup_fmt_qty($qty) {
    $qty = (float)$qty;
    if ($qty <= 0) {
        $qty = 1;
    }
    if (abs($qty - round($qty)) < 0.0001) {
        return (string)(int)round($qty);
    }
    return rtrim(rtrim(number_format($qty, 3, '.', ''), '0'), '.');
}

/** Invoice lines for WhatsApp: bullets with qty + a short comma list for the notification UI. */
function pos_followup_extract_sale_items($itemsJson, $maxLines = 12) {
    $lines = [];
    $short = [];
    $decoded = is_array($itemsJson) ? $itemsJson : json_decode((string)$itemsJson, true);
    if (!is_array($decoded)) {
        return ['list' => '', 'short' => ''];
    }
    foreach ($decoded as $it) {
        if (!is_array($it)) {
            continue;
        }
        $n = trim(strip_tags((string)($it['name'] ?? $it['itemName'] ?? $it['n'] ?? '')));
        if ($n === '') {
            continue;
        }
        $qty = pos_followup_fmt_qty($it['qty'] ?? $it['count'] ?? 1);
        $lines[] = '• ' . $n . ' × ' . $qty;
        $short[] = $n;
        if (count($lines) >= $maxLines) {
            break;
        }
    }
    return [
        'list' => implode("\n", $lines),
        'short' => implode('، ', array_slice($short, 0, 6)),
    ];
}

function pos_followup_merge_item_lists($prev, $next, $maxLines = 12) {
    $a = array_values(array_filter(array_map('trim', preg_split("/\r\n|\n|\r/", (string)$prev))));
    $b = array_values(array_filter(array_map('trim', preg_split("/\r\n|\n|\r/", (string)$next))));
    $seen = [];
    $out = [];
    foreach (array_merge($a, $b) as $line) {
        if ($line === '' || isset($seen[$line])) {
            continue;
        }
        $seen[$line] = 1;
        $out[] = $line;
        if (count($out) >= $maxLines) {
            break;
        }
    }
    return implode("\n", $out);
}

/**
 * Idempotent widen for debt/balance money columns. Run on each app DB connect so shops
 * that already had schema_version 12 (or a failed migration) still get the fix.
 * Large USD inputs × FX must fit (e.g. 1,000,000 USD × 1500 → 1.5e9 IQD; DECIMAL(10,2) overflows).
 */
function pos_ensure_debt_columns_wide($conn) {
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    if (!$conn || !($conn instanceof mysqli)) {
        return;
    }
    $alters = [
        "ALTER TABLE companies MODIFY COLUMN balance DECIMAL(18,3) DEFAULT 0",
        "ALTER TABLE companies MODIFY COLUMN debt_limit DECIMAL(18,3) DEFAULT 0",
        "ALTER TABLE companies MODIFY COLUMN opening_balance DECIMAL(18,3) DEFAULT 0",
        "ALTER TABLE customers MODIFY COLUMN balance DECIMAL(18,3) DEFAULT 0",
        "ALTER TABLE customers MODIFY COLUMN debt_limit DECIMAL(18,3) DEFAULT 0",
        "ALTER TABLE customers MODIFY COLUMN opening_balance DECIMAL(18,3) DEFAULT 0",
        "ALTER TABLE users MODIFY COLUMN balance DECIMAL(18,3) DEFAULT 0",
    ];
    foreach ($alters as $sql) {
        try {
            $conn->query($sql);
        } catch (Throwable $e) {
            // Table/column may not exist on empty edge DBs; ignore
        }
    }
}

/**
 * Idempotent product columns used by save_product / catalog UI.
 * Runs on every DB connect (not gated on schema_version) so shops already at v14
 * still get columns like `note` that were added to migration body after they upgraded.
 */
function pos_ensure_product_catalog_columns($conn) {
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    if (!$conn || !($conn instanceof mysqli) || !function_exists('checkAndAddCol')) {
        return;
    }
    $cols = [
        ['sku', "VARCHAR(64) NOT NULL DEFAULT ''"],
        ['unitType', "VARCHAR(20) DEFAULT 'carton'"],
        ['qty_mode', "VARCHAR(10) NOT NULL DEFAULT 'piece'"],
        ['itemsPerCarton', 'INT DEFAULT 1'],
        ['forSale', 'TINYINT(1) DEFAULT 1'],
        ['takeawayPrice', 'DECIMAL(10,2) DEFAULT 0'],
        ['takeawayPrice_pack', 'DECIMAL(10,2) DEFAULT 0'],
        ['takeawayPrice_carton', 'DECIMAL(10,2) DEFAULT 0'],
        ['wholesaleQty', 'INT DEFAULT 0'],
        ['wholesalePrice', 'DECIMAL(10,2) DEFAULT 0'],
        ['isPinned', 'TINYINT(1) DEFAULT 0'],
        ['minStock', 'INT DEFAULT 5'],
        ['expiry_alert_days', 'INT NOT NULL DEFAULT 30'],
        ['pieces_per_pack', 'INT DEFAULT 1'],
        ['packs_per_carton', 'INT DEFAULT 1'],
        ['barcode_pack', 'VARCHAR(100)'],
        ['barcode_carton', 'VARCHAR(100)'],
        ['price_pack', 'DECIMAL(10,2)'],
        ['price_carton', 'DECIMAL(10,2)'],
        ['cost_pack', 'DECIMAL(10,2)'],
        ['cost_carton', 'DECIMAL(10,2)'],
        ['unit_show_pack', 'TINYINT(1) NOT NULL DEFAULT 0'],
        ['unit_show_carton', 'TINYINT(1) NOT NULL DEFAULT 0'],
        ['note', "VARCHAR(255) NOT NULL DEFAULT ''"],
        ['unit_name_piece', "VARCHAR(100) DEFAULT ''"],
        ['unit_name_pack', "VARCHAR(100) DEFAULT ''"],
        ['unit_name_carton', "VARCHAR(100) DEFAULT ''"],
        ['price_usd', 'DECIMAL(14,6) NULL'],
        ['cost_usd', 'DECIMAL(14,6) NULL'],
        ['base_currency', "VARCHAR(3) NOT NULL DEFAULT 'IQD'"],
        ['base_price', 'DECIMAL(18,6) NOT NULL DEFAULT 0'],
        ['base_cost', 'DECIMAL(18,6) NOT NULL DEFAULT 0'],
        ['currency', "VARCHAR(3) NOT NULL DEFAULT 'IQD'"],
        ['cost_price', 'DECIMAL(18,6) NOT NULL DEFAULT 0'],
        ['price_pack_usd', 'DECIMAL(14,6) NULL'],
        ['price_carton_usd', 'DECIMAL(14,6) NULL'],
        ['cost_pack_usd', 'DECIMAL(14,6) NULL'],
        ['cost_carton_usd', 'DECIMAL(14,6) NULL'],
        ['expiry', 'VARCHAR(50)'],
        ['item_type', "VARCHAR(20) DEFAULT 'constant'"],
        ['is_active', 'TINYINT(1) DEFAULT 1'],
        ['manufacturer', "VARCHAR(100) NOT NULL DEFAULT ''"],
        ['recipe_sale_mode', "VARCHAR(20) NOT NULL DEFAULT 'auto'"],
        ['metal_type', "VARCHAR(20) NOT NULL DEFAULT ''"],
        ['karat', 'DECIMAL(5,2) NULL'],
        ['weight_grams', 'DECIMAL(14,3) NULL'],
        ['making_charge', 'DECIMAL(14,2) NOT NULL DEFAULT 0'],
        ['jewelry_price_mode', "VARCHAR(20) NOT NULL DEFAULT 'fixed'"],
        ['is_jewelry_set', 'TINYINT(1) NOT NULL DEFAULT 0'],
        ['catalog_only', 'TINYINT(1) NOT NULL DEFAULT 0'],
        ['tech_specs', 'TEXT NULL'],
    ];
    foreach ($cols as $spec) {
        checkAndAddCol($conn, 'products', $spec[0], $spec[1]);
    }
    // Jewelry set members: set (parent) ↔ pieces (earrings, bracelet…) each with own barcode/product
    try {
        $conn->query("CREATE TABLE IF NOT EXISTS jewelry_set_items (
            id INT AUTO_INCREMENT PRIMARY KEY,
            set_product_id INT NOT NULL,
            member_product_id INT NOT NULL,
            qty DECIMAL(14,3) NOT NULL DEFAULT 1,
            label VARCHAR(100) NOT NULL DEFAULT '',
            sort_order INT NOT NULL DEFAULT 0,
            INDEX idx_jew_set (set_product_id),
            INDEX idx_jew_member (member_product_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) {
        // ignore
    }
}

/**
 * Expense soft-delete archive columns (added after schema v14 for some installs).
 * Runs on every DB connect so delete_expense does not fail on missing columns.
 */
function pos_ensure_expenses_archive_columns($conn) {
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    if (!$conn || !($conn instanceof mysqli) || !function_exists('checkAndAddCol')) {
        return;
    }
    checkAndAddCol($conn, 'expenses_archive', 'archive_reason', "VARCHAR(50) DEFAULT NULL");
    checkAndAddCol($conn, 'expenses_archive', 'deleted_by', "VARCHAR(100) DEFAULT NULL");
    if (function_exists('pos_ensure_expense_currency_columns')) {
        pos_ensure_expense_currency_columns($conn);
    }
}

/** Frozen per-expense currency + rate. Changing shop FX must never rewrite these. */
function pos_ensure_expense_currency_columns($conn) {
    if (!$conn || !($conn instanceof mysqli) || !function_exists('checkAndAddCol')) {
        return;
    }
    checkAndAddCol($conn, 'expenses', 'currency', "VARCHAR(3) NOT NULL DEFAULT 'IQD'");
    checkAndAddCol($conn, 'expenses', 'exchange_rate', "DECIMAL(18,6) NOT NULL DEFAULT 0");
    checkAndAddCol($conn, 'expenses_archive', 'currency', "VARCHAR(3) NOT NULL DEFAULT 'IQD'");
    checkAndAddCol($conn, 'expenses_archive', 'exchange_rate', "DECIMAL(18,6) NOT NULL DEFAULT 0");
}

/** Frozen FX on purchases / customer debts. Shop FX changes must never rewrite these. */
function pos_ensure_txn_fx_columns($conn) {
    if (!$conn || !($conn instanceof mysqli) || !function_exists('checkAndAddCol')) {
        return;
    }
    checkAndAddCol($conn, 'supplies', 'currency', "VARCHAR(3) NOT NULL DEFAULT 'IQD'");
    checkAndAddCol($conn, 'supplies', 'exchange_rate', "DECIMAL(18,6) NOT NULL DEFAULT 0");
    checkAndAddCol($conn, 'customer_ledger', 'currency', "VARCHAR(3) NOT NULL DEFAULT 'IQD'");
    checkAndAddCol($conn, 'customer_ledger', 'exchange_rate', "DECIMAL(18,6) NOT NULL DEFAULT 0");
    checkAndAddCol($conn, 'customers', 'currency', "VARCHAR(3) NOT NULL DEFAULT 'IQD'");
    checkAndAddCol($conn, 'customers', 'exchange_rate', "DECIMAL(18,6) NOT NULL DEFAULT 0");
    checkAndAddCol($conn, 'companies', 'currency', "VARCHAR(3) NOT NULL DEFAULT 'IQD'");
    checkAndAddCol($conn, 'companies', 'exchange_rate', "DECIMAL(18,6) NOT NULL DEFAULT 0");
}

/**
 * Additive FX engine columns. Copies existing amounts 1:1 — never multiplies catalog or history.
 * settings.default_currency / settings.exchange_rate are KV rows (settings is key/value, not wide columns).
 * customer_debts maps to customer_ledger.amount + currency (no separate debts table).
 */
function pos_ensure_fx_engine_schema($conn) {
    if (!$conn || !($conn instanceof mysqli) || !function_exists('checkAndAddCol')) {
        return;
    }
    checkAndAddCol($conn, 'products', 'currency', "VARCHAR(3) NOT NULL DEFAULT 'IQD'");
    checkAndAddCol($conn, 'products', 'cost_price', "DECIMAL(18,6) NOT NULL DEFAULT 0");
    checkAndAddCol($conn, 'sales', 'total_iqd', "DECIMAL(18,6) NOT NULL DEFAULT 0");
    checkAndAddCol($conn, 'sales', 'total_usd', "DECIMAL(18,6) NULL DEFAULT NULL");
    checkAndAddCol($conn, 'sales', 'paid_iqd', "DECIMAL(18,6) NOT NULL DEFAULT 0");
    checkAndAddCol($conn, 'sales', 'paid_usd', "DECIMAL(18,6) NULL DEFAULT NULL");
    checkAndAddCol($conn, 'sales', 'exchange_rate', "DECIMAL(18,6) NOT NULL DEFAULT 0");
    checkAndAddCol($conn, 'supplies', 'total_amount', "DECIMAL(18,6) NOT NULL DEFAULT 0");
    if (function_exists('pos_ensure_txn_fx_columns')) {
        pos_ensure_txn_fx_columns($conn);
    }
    if (function_exists('pos_ensure_expense_currency_columns')) {
        pos_ensure_expense_currency_columns($conn);
    }
}

/**
 * Hot-path search indexes (idempotent). products.category is the shop category column
 * (there is no category_id). sales invoice number is sales.id / transaction_id.
 * expenses uses `date` (created_at when present).
 */
function pos_ensure_hot_search_indexes($conn) {
    static $done = false;
    if ($done || !$conn || !($conn instanceof mysqli)) {
        return;
    }
    $done = true;
    $flag = null;
    try {
        $flag = pos_db_get_setting_value($conn, 'hot_search_indexes_v34b');
    } catch (Throwable $e) {}
    if ($flag === '1') {
        return;
    }
    $hasCol = function ($table, $col) use ($conn) {
        if (!function_exists('pos_table_has_column')) {
            return true;
        }
        return pos_table_has_column($conn, $table, $col);
    };
    $stmts = [];
    if ($hasCol('products', 'barcode')) {
        $stmts[] = 'CREATE INDEX idx_products_barcode ON products (barcode)';
    }
    if ($hasCol('products', 'name')) {
        // utf8mb4 VARCHAR(255) can exceed older InnoDB key limits — prefix is safe.
        $stmts[] = 'CREATE INDEX idx_products_name ON products (name(191))';
    }
    if ($hasCol('products', 'sku')) {
        $stmts[] = 'CREATE INDEX idx_products_sku ON products (sku)';
    }
    if ($hasCol('products', 'category')) {
        $stmts[] = 'CREATE INDEX idx_products_category ON products (category)';
    }
    if ($hasCol('products', 'barcode_pack')) {
        $stmts[] = 'CREATE INDEX idx_products_barcode_pack ON products (barcode_pack)';
    }
    if ($hasCol('products', 'barcode_carton')) {
        $stmts[] = 'CREATE INDEX idx_products_barcode_carton ON products (barcode_carton)';
    }
    if ($hasCol('sales', 'created_at')) {
        $stmts[] = 'CREATE INDEX idx_sales_created_at ON sales (created_at)';
    }
    if ($hasCol('sales', 'transaction_id')) {
        $stmts[] = 'CREATE INDEX idx_sales_transaction_id ON sales (transaction_id)';
    }
    if ($hasCol('expenses', 'date')) {
        $stmts[] = 'CREATE INDEX idx_expenses_date ON expenses (`date`)';
    }
    if ($hasCol('products', 'is_active') && $hasCol('products', 'barcode')) {
        $stmts[] = 'CREATE INDEX idx_products_active_barcode ON products (is_active, barcode)';
    }
    if ($hasCol('products', 'category_id')) {
        $stmts[] = 'CREATE INDEX idx_products_category_id ON products (category_id)';
    }
    if ($hasCol('sales', 'invoice_number')) {
        $stmts[] = 'CREATE INDEX idx_sales_invoice_number ON sales (invoice_number)';
    }
    if ($hasCol('expenses', 'created_at')) {
        $stmts[] = 'CREATE INDEX idx_expenses_created_at ON expenses (created_at)';
    }
    foreach ($stmts as $sqlIdx) {
        try {
            @$conn->query($sqlIdx);
        } catch (Throwable $eIdx) {}
    }
    try {
        pos_db_set_setting_value($conn, 'hot_search_indexes_v34b', '1');
    } catch (Throwable $eFlag) {}
}

function pos_table_has_column($conn, $table, $col) {
    if (!$conn || !($conn instanceof mysqli)) {
        return false;
    }
    $table = preg_replace('/[^a-zA-Z0-9_]/', '', (string)$table);
    $col = preg_replace('/[^a-zA-Z0-9_]/', '', (string)$col);
    if ($table === '' || $col === '') {
        return false;
    }
    try {
        $escCol = $conn->real_escape_string($col);
        $check = @$conn->query("SHOW COLUMNS FROM `{$table}` LIKE '{$escCol}'");
        return $check && $check->num_rows > 0;
    } catch (Throwable $e) {
        return false;
    }
}

/**
 * True when an old backup (or mysql/data restore) left FX columns or settings keys missing.
 */
function pos_fx_schema_needs_heal($conn) {
    if (!$conn || !($conn instanceof mysqli)) {
        return false;
    }
    if (!pos_table_has_column($conn, 'products', 'currency')) return true;
    if (!pos_table_has_column($conn, 'products', 'cost_price')) return true;
    if (!pos_table_has_column($conn, 'expenses', 'currency')) return true;
    if (!pos_table_has_column($conn, 'expenses', 'exchange_rate')) return true;
    if (!pos_table_has_column($conn, 'sales', 'exchange_rate')) return true;
    if (!pos_table_has_column($conn, 'sales', 'total_iqd')) return true;
    if (!pos_table_has_column($conn, 'supplies', 'currency')) return true;
    $dc = pos_db_get_setting_value($conn, 'default_currency');
    $dc = is_string($dc) ? strtoupper(trim($dc)) : '';
    if ($dc !== 'USD' && $dc !== 'IQD') {
        return true;
    }
    $er = pos_db_get_setting_value($conn, 'exchange_rate');
    if ($er === null || $er === '' || !is_numeric($er) || (float)$er <= 0) {
        return true;
    }
    $v33 = pos_db_get_setting_value($conn, 'restored_catalog_price_repair_v33');
    if ($v33 !== '1') {
        return true;
    }
    return false;
}

function pos_shop_fx_rate_per_one_from_settings_row($conn) {
    $rate = 1500.0;
    try {
        $raw = pos_db_get_setting_value($conn, 'app_settings');
        $dec = ($raw !== null && $raw !== '') ? json_decode($raw, true) : [];
        if (is_array($dec)) {
            if (isset($dec['exchange_rate']) && (float)$dec['exchange_rate'] > 0 && (float)$dec['exchange_rate'] < 10000) {
                $rate = (float)$dec['exchange_rate'];
            } elseif (isset($dec['usdRate'])) {
                $rawR = (float)$dec['usdRate'];
                $rate = $rawR >= 100 ? ($rawR / 100.0) : $rawR;
            }
        }
    } catch (Throwable $e) {}
    if ($rate <= 0) {
        $rate = 1500.0;
    }
    return $rate;
}

function pos_shop_default_currency_from_settings_row($conn) {
    $mode = 'IQD';
    try {
        $dc = pos_db_get_setting_value($conn, 'default_currency');
        $dc = is_string($dc) ? strtoupper(trim($dc)) : '';
        if ($dc === 'USD' || $dc === 'IQD') {
            return $dc;
        }
        $raw = pos_db_get_setting_value($conn, 'app_settings');
        $dec = ($raw !== null && $raw !== '') ? json_decode($raw, true) : [];
        if (is_array($dec)) {
            $d = strtoupper(trim((string)($dec['defaultCurrency'] ?? $dec['default_currency'] ?? '')));
            if ($d === 'USD' || $d === 'IQD') {
                return $d;
            }
            $m = strtoupper(trim((string)($dec['currencyMode'] ?? 'IQD')));
            $mode = ($m === 'USD') ? 'USD' : 'IQD';
        }
    } catch (Throwable $e) {}
    return $mode;
}

/**
 * Copy existing amounts 1:1 into new FX columns. Never multiply/divide catalog prices.
 */
function pos_backfill_fx_engine_copy_1to1($conn) {
    if (!$conn || !($conn instanceof mysqli)) {
        return;
    }
    $rateFx = pos_shop_fx_rate_per_one_from_settings_row($conn);
    $rateFxSql = (float)$rateFx;
    @$conn->query("UPDATE products SET currency = CASE WHEN UPPER(TRIM(IFNULL(base_currency,''))) IN ('USD','IQD') THEN UPPER(TRIM(base_currency)) ELSE 'IQD' END WHERE currency IS NULL OR TRIM(IFNULL(currency,'')) = '' OR currency = '0' OR UPPER(TRIM(IFNULL(currency,''))) NOT IN ('IQD','USD')");
    @$conn->query("UPDATE products SET base_currency = CASE WHEN UPPER(TRIM(IFNULL(currency,''))) IN ('USD','IQD') THEN UPPER(TRIM(currency)) ELSE 'IQD' END WHERE base_currency IS NULL OR TRIM(IFNULL(base_currency,'')) = '' OR base_currency = '0' OR UPPER(TRIM(IFNULL(base_currency,''))) NOT IN ('IQD','USD')");
    @$conn->query("UPDATE products SET base_price = COALESCE(price, 0) WHERE (base_price IS NULL OR base_price = 0) AND UPPER(TRIM(IFNULL(currency, IFNULL(base_currency,'IQD')))) <> 'USD'");
    @$conn->query("UPDATE products SET base_price = COALESCE(NULLIF(price_usd, 0), price, 0) WHERE (base_price IS NULL OR base_price = 0) AND UPPER(TRIM(IFNULL(currency, IFNULL(base_currency,'')))) = 'USD'");
    @$conn->query("UPDATE products SET base_cost = COALESCE(cost, 0) WHERE (base_cost IS NULL OR base_cost = 0) AND UPPER(TRIM(IFNULL(currency, IFNULL(base_currency,'IQD')))) <> 'USD'");
    @$conn->query("UPDATE products SET base_cost = COALESCE(cost_usd, cost, 0) WHERE (base_cost IS NULL OR base_cost = 0) AND UPPER(TRIM(IFNULL(currency, IFNULL(base_currency,'')))) = 'USD'");
    @$conn->query("UPDATE products SET cost_price = COALESCE(cost, 0) WHERE cost_price IS NULL OR cost_price = 0");
    @$conn->query("UPDATE sales SET total_iqd = COALESCE(total, 0) WHERE total_iqd IS NULL OR total_iqd = 0");
    @$conn->query("UPDATE sales SET paid_iqd = COALESCE(paid_amount, 0) WHERE paid_iqd IS NULL OR paid_iqd = 0");
    @$conn->query("UPDATE sales SET exchange_rate = CASE WHEN fx_usd_rate >= 100 THEN ROUND(fx_usd_rate / 100, 6) WHEN fx_usd_rate > 0 THEN fx_usd_rate ELSE {$rateFxSql} END WHERE exchange_rate IS NULL OR exchange_rate <= 0");
    @$conn->query("UPDATE sales SET total_usd = CASE WHEN exchange_rate > 0.000001 THEN ROUND(total_iqd / exchange_rate, 2) ELSE NULL END WHERE total_usd IS NULL");
    @$conn->query("UPDATE sales SET paid_usd = CASE WHEN exchange_rate > 0.000001 THEN ROUND(paid_iqd / exchange_rate, 2) ELSE NULL END WHERE paid_usd IS NULL");
    @$conn->query("UPDATE supplies SET total_amount = COALESCE(totalCost, 0) WHERE total_amount IS NULL OR total_amount = 0");
    @$conn->query("UPDATE expenses SET currency = 'IQD' WHERE currency IS NULL OR currency = '' OR UPPER(TRIM(currency)) NOT IN ('IQD','USD')");
    @$conn->query("UPDATE expenses SET exchange_rate = {$rateFxSql} WHERE exchange_rate IS NULL OR exchange_rate <= 0");
    foreach (['supplies', 'customer_ledger', 'customers', 'companies'] as $tblFx) {
        @$conn->query("UPDATE `{$tblFx}` SET currency = 'IQD' WHERE currency IS NULL OR currency = '' OR UPPER(TRIM(currency)) NOT IN ('IQD','USD')");
        @$conn->query("UPDATE `{$tblFx}` SET exchange_rate = {$rateFxSql} WHERE exchange_rate IS NULL OR exchange_rate <= 0");
    }
}

/**
 * Old supermarket backups: columns exist but base_price/currency are empty → cart shows $0.00 / IQD 0.
 */
function pos_repair_restored_catalog_prices($conn) {
    if (!$conn || !($conn instanceof mysqli)) {
        return false;
    }
    if (function_exists('pos_ensure_fx_engine_schema')) {
        pos_ensure_fx_engine_schema($conn);
    }
    if (function_exists('pos_ensure_product_catalog_columns')) {
        pos_ensure_product_catalog_columns($conn);
    }
    pos_backfill_fx_engine_copy_1to1($conn);

    $dc = pos_db_get_setting_value($conn, 'default_currency');
    $dc = is_string($dc) ? strtoupper(trim($dc)) : '';
    if ($dc !== 'USD' && $dc !== 'IQD') {
        pos_db_set_setting_value($conn, 'default_currency', 'IQD');
        $dc = 'IQD';
    }
    $rate = pos_shop_fx_rate_per_one_from_settings_row($conn);
    if ($rate <= 0) {
        $rate = 1500.0;
    }
    $er = pos_db_get_setting_value($conn, 'exchange_rate');
    if ($er === null || $er === '' || !is_numeric($er) || (float)$er <= 0) {
        pos_db_set_setting_value($conn, 'exchange_rate', number_format($rate, 2, '.', ''));
    }
    try {
        $raw = pos_db_get_setting_value($conn, 'app_settings');
        $dec = ($raw !== null && $raw !== '') ? json_decode($raw, true) : [];
        if (!is_array($dec)) {
            $dec = [];
        }
        $mode = strtoupper(trim((string)($dec['defaultCurrency'] ?? $dec['default_currency'] ?? $dec['currencyMode'] ?? $dc)));
        if ($mode !== 'USD' && $mode !== 'IQD') {
            $mode = 'IQD';
        }
        $dec['defaultCurrency'] = $mode;
        $dec['default_currency'] = $mode;
        if (empty($dec['currencyMode'])) {
            $dec['currencyMode'] = $mode;
        }
        $dec['exchange_rate'] = round($rate, 2);
        if (!isset($dec['usdRate']) || (float)$dec['usdRate'] < 10000) {
            $dec['usdRate'] = (int)round($rate * 100);
        }
        $out = json_encode($dec, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
        if ($out !== false) {
            pos_db_set_setting_value($conn, 'app_settings', $out);
        }
        pos_db_set_setting_value($conn, 'default_currency', $mode);
    } catch (Throwable $e) {}
    pos_db_set_setting_value($conn, 'restored_catalog_price_repair_v33', '1');
    return true;
}

/**
 * Fallback after restoring an older backup: add missing FX columns/settings without rewriting live prices.
 * $forceCurrency: optional 'IQD'|'USD' from restore UI.
 */
function pos_heal_currency_schema($conn, $forceCurrency = null) {
    if (!$conn || !($conn instanceof mysqli)) {
        return false;
    }
    try {
        if (function_exists('pos_ensure_expense_currency_columns')) {
            pos_ensure_expense_currency_columns($conn);
        }
        if (function_exists('pos_ensure_txn_fx_columns')) {
            pos_ensure_txn_fx_columns($conn);
        }
        if (function_exists('pos_ensure_fx_engine_schema')) {
            pos_ensure_fx_engine_schema($conn);
        }
        if (function_exists('pos_ensure_product_catalog_columns')) {
            pos_ensure_product_catalog_columns($conn);
        }
        pos_backfill_fx_engine_copy_1to1($conn);
        if (function_exists('pos_repair_restored_catalog_prices')) {
            pos_repair_restored_catalog_prices($conn);
        }

        $mode = pos_shop_default_currency_from_settings_row($conn);
        $force = is_string($forceCurrency) ? strtoupper(trim($forceCurrency)) : '';
        if ($force === 'USD' || $force === 'IQD') {
            $mode = $force;
        }
        $rate = pos_shop_fx_rate_per_one_from_settings_row($conn);
        pos_db_set_setting_value($conn, 'default_currency', $mode);
        pos_db_set_setting_value($conn, 'exchange_rate', number_format($rate, 2, '.', ''));

        $raw = pos_db_get_setting_value($conn, 'app_settings');
        $dec = ($raw !== null && $raw !== '') ? json_decode($raw, true) : [];
        if (!is_array($dec)) {
            $dec = [];
        }
        $dec['defaultCurrency'] = $mode;
        $dec['default_currency'] = $mode;
        $dec['currencyMode'] = $mode;
        $dec['exchange_rate'] = round($rate, 2);
        if (!isset($dec['usdRate']) || (float)$dec['usdRate'] < 10000) {
            $dec['usdRate'] = (int)round($rate * 100);
        }
        $out = json_encode($dec, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
        if ($out !== false) {
            pos_db_set_setting_value($conn, 'app_settings', $out);
        }
        pos_db_set_setting_value($conn, 'pos_schema_ensure_ts', '0');
        pos_db_set_setting_value($conn, 'fx_engine_backfill_v32', '1');
        return true;
    } catch (Throwable $e) {
        pos_migrations_log('heal_currency_schema: ' . $e->getMessage());
        return false;
    }
}

/**
 * Manufacturers table/columns for save_manufacturer (phone, note on legacy installs).
 * Runs on every DB connect so shops already at current schema_version still get fixes.
 */
function pos_ensure_manufacturers_schema($conn) {
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    if (!$conn || !($conn instanceof mysqli) || !function_exists('checkAndAddCol')) {
        return;
    }
    try {
        $conn->query("CREATE TABLE IF NOT EXISTS manufacturers (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, phone VARCHAR(50) DEFAULT '', note VARCHAR(255) DEFAULT '', is_active TINYINT(1) DEFAULT 1)");
        $conn->query("SELECT 1 FROM manufacturers LIMIT 1");
        try {
            $conn->query("ALTER TABLE manufacturers ADD UNIQUE INDEX idx_mfr_name (name)");
        } catch (Throwable $eMfrIdx) {
        }
    } catch (Throwable $e) {
        pos_migrations_log('manufacturers ensure: ' . $e->getMessage());
    }
    checkAndAddCol($conn, 'manufacturers', 'phone', "VARCHAR(50) DEFAULT ''");
    checkAndAddCol($conn, 'manufacturers', 'note', "VARCHAR(255) DEFAULT ''");
    checkAndAddCol($conn, 'manufacturers', 'is_active', "TINYINT(1) DEFAULT 1");
}

/**
 * Delivery drivers registry + delivery link columns (customer_id, driver_id, sale_id, settled_at).
 */
function pos_ensure_drivers_schema($conn) {
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    if (!$conn || !($conn instanceof mysqli) || !function_exists('checkAndAddCol')) {
        return;
    }
    try {
        $conn->query("CREATE TABLE IF NOT EXISTS drivers (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, phone VARCHAR(50) DEFAULT '', note VARCHAR(255) DEFAULT '', created_at DATETIME DEFAULT CURRENT_TIMESTAMP, is_active TINYINT(1) DEFAULT 1)");
        $conn->query("SELECT 1 FROM drivers LIMIT 1");
    } catch (Throwable $e) {
        pos_migrations_log('drivers ensure: ' . $e->getMessage());
    }
    checkAndAddCol($conn, 'drivers', 'phone', "VARCHAR(50) DEFAULT ''");
    checkAndAddCol($conn, 'drivers', 'note', "VARCHAR(255) DEFAULT ''");
    checkAndAddCol($conn, 'drivers', 'created_at', "DATETIME DEFAULT CURRENT_TIMESTAMP");
    checkAndAddCol($conn, 'drivers', 'is_active', "TINYINT(1) DEFAULT 1");
    checkAndAddCol($conn, 'deliveries', 'customer_id', "INT DEFAULT 0");
    checkAndAddCol($conn, 'deliveries', 'driver_id', "INT DEFAULT 0");
    checkAndAddCol($conn, 'deliveries', 'sale_id', "INT DEFAULT 0");
    checkAndAddCol($conn, 'deliveries', 'settled_at', "DATETIME NULL DEFAULT NULL");
}

// Helper function to safely add columns (Fix for older MySQL versions)
function checkAndAddCol($conn, $table, $col, $spec) {
    try {
        $check = $conn->query("SHOW COLUMNS FROM $table LIKE '$col'");
        if ($check && $check->num_rows == 0) {
            $conn->query("ALTER TABLE $table ADD COLUMN $col $spec");
        }
    } catch (Throwable $e) {
        if (strpos($e->getMessage(), "doesn't exist in engine") !== false || strpos($e->getMessage(), 'Tablespace') !== false) {
            $conn->query("DROP TABLE IF EXISTS $table");
            // Don't send HTML redirect from API context (would break JSON); rethrow so caller returns JSON error
            if (!isset($_POST['action']) && (!isset($_GET['action']) || !in_array($_GET['action'] ?? '', ['get_data', 'get_sync_data', 'get_login_data'], true))) {
                header("Refresh:0"); exit();
            }
            throw $e;
        }
    }
}

function pos_run_migrations_body($conn) {
// --- AUTO-SETUP TABLES & DEFAULTS ---
try {
    $conn->query("CREATE TABLE IF NOT EXISTS categories (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) UNIQUE)");
    $conn->query("SELECT 1 FROM categories LIMIT 1");
} catch (Throwable $e) {
    file_put_contents('pos_debug.log', date('Y-m-d H:i:s') . " - DB INIT ERROR (categories): " . $e->getMessage() . "\n", FILE_APPEND);
}

// --- FIX: ENSURE ALL TABLES EXIST (Bo çareserkirina kêşa wenda buna datayan) ---
try {
    $conn->query("CREATE TABLE IF NOT EXISTS products (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255), barcode VARCHAR(100), price DECIMAL(10,2), cost DECIMAL(10,2), qty DECIMAL(14,3), category VARCHAR(100), supplier VARCHAR(100), trackStock TINYINT(1), unitType VARCHAR(20) DEFAULT 'carton', qty_mode VARCHAR(10) NOT NULL DEFAULT 'piece', itemsPerCarton INT DEFAULT 1, forSale TINYINT(1) DEFAULT 1)");
    $conn->query("SELECT 1 FROM products LIMIT 1");
} catch (Throwable $e) {
    // Log error instead of dropping table
    file_put_contents('pos_debug.log', date('Y-m-d H:i:s') . " - DB INIT ERROR (products): " . $e->getMessage() . "\n", FILE_APPEND);
    // If it's a tablespace error, manual intervention might be needed, but automatic drop is too dangerous.
}

checkAndAddCol($conn, 'products', 'unitType', "VARCHAR(20) DEFAULT 'carton'");
checkAndAddCol($conn, 'products', 'qty_mode', "VARCHAR(10) NOT NULL DEFAULT 'piece'");
checkAndAddCol($conn, 'products', 'itemsPerCarton', "INT DEFAULT 1");
checkAndAddCol($conn, 'products', 'forSale', "TINYINT(1) DEFAULT 1");
checkAndAddCol($conn, 'products', 'takeawayPrice', "DECIMAL(10,2) DEFAULT 0");
checkAndAddCol($conn, 'products', 'takeawayPrice_pack', "DECIMAL(10,2) DEFAULT 0");
checkAndAddCol($conn, 'products', 'takeawayPrice_carton', "DECIMAL(10,2) DEFAULT 0");
checkAndAddCol($conn, 'products', 'wholesaleQty', "INT DEFAULT 0");
checkAndAddCol($conn, 'products', 'wholesalePrice', "DECIMAL(10,2) DEFAULT 0");
checkAndAddCol($conn, 'products', 'isPinned', "TINYINT(1) DEFAULT 0");
checkAndAddCol($conn, 'products', 'minStock', "INT DEFAULT 5");
checkAndAddCol($conn, 'products', 'expiry_alert_days', "INT NOT NULL DEFAULT 30");

// --- MULTI-LEVEL UNITS: Piece / Pack (Small Box) / Carton (Large Box) ---
checkAndAddCol($conn, 'products', 'pieces_per_pack', "INT DEFAULT 1");
checkAndAddCol($conn, 'products', 'packs_per_carton', "INT DEFAULT 1");
checkAndAddCol($conn, 'products', 'barcode_pack', "VARCHAR(100)");
checkAndAddCol($conn, 'products', 'barcode_carton', "VARCHAR(100)");
checkAndAddCol($conn, 'products', 'price_pack', "DECIMAL(10,2)");
checkAndAddCol($conn, 'products', 'price_carton', "DECIMAL(10,2)");
checkAndAddCol($conn, 'products', 'cost_pack', "DECIMAL(10,2)");
checkAndAddCol($conn, 'products', 'cost_carton', "DECIMAL(10,2)");
checkAndAddCol($conn, 'products', 'unit_show_pack', "TINYINT(1) NOT NULL DEFAULT 0");
checkAndAddCol($conn, 'products', 'unit_show_carton', "TINYINT(1) NOT NULL DEFAULT 0");
checkAndAddCol($conn, 'products', 'note', "VARCHAR(255) NOT NULL DEFAULT ''");
checkAndAddCol($conn, 'products', 'manufacturer', "VARCHAR(100) NOT NULL DEFAULT ''");
checkAndAddCol($conn, 'products', 'unit_name_piece', "VARCHAR(100) DEFAULT ''");
checkAndAddCol($conn, 'products', 'unit_name_pack', "VARCHAR(100) DEFAULT ''");
checkAndAddCol($conn, 'products', 'unit_name_carton', "VARCHAR(100) DEFAULT ''");

// USD-stable catalog (nullable; when set + currencyMode USD, IQD fields are derived from rate)
checkAndAddCol($conn, 'products', 'price_usd', "DECIMAL(14,6) NULL");
checkAndAddCol($conn, 'products', 'cost_usd', "DECIMAL(14,6) NULL");
checkAndAddCol($conn, 'products', 'price_pack_usd', "DECIMAL(14,6) NULL");
checkAndAddCol($conn, 'products', 'price_carton_usd', "DECIMAL(14,6) NULL");
checkAndAddCol($conn, 'products', 'cost_pack_usd', "DECIMAL(14,6) NULL");
checkAndAddCol($conn, 'products', 'cost_carton_usd', "DECIMAL(14,6) NULL");
checkAndAddCol($conn, 'products', 'base_currency', "VARCHAR(3) NOT NULL DEFAULT 'IQD'");
checkAndAddCol($conn, 'products', 'base_price', "DECIMAL(18,6) NOT NULL DEFAULT 0");
checkAndAddCol($conn, 'products', 'base_cost', "DECIMAL(18,6) NOT NULL DEFAULT 0");

try {
    $conn->query("CREATE TABLE IF NOT EXISTS sales (id INT AUTO_INCREMENT PRIMARY KEY, total DECIMAL(10,2), discount DECIMAL(10,2), items_json LONGTEXT, created_at DATETIME, cashier VARCHAR(100))");
    $conn->query("SELECT 1 FROM sales LIMIT 1");
} catch (Throwable $e) {
    file_put_contents('pos_debug.log', date('Y-m-d H:i:s') . " - DB INIT ERROR (sales): " . $e->getMessage() . "\n", FILE_APPEND);
}
try {
    $conn->query("CREATE TABLE IF NOT EXISTS expenses (id INT AUTO_INCREMENT PRIMARY KEY, note VARCHAR(255), amount DECIMAL(10,2), `date` DATETIME, user VARCHAR(100))");
    $conn->query("SELECT 1 FROM expenses LIMIT 1");
} catch (Throwable $e) {
    file_put_contents('pos_debug.log', date('Y-m-d H:i:s') . " - DB INIT ERROR (expenses): " . $e->getMessage() . "\n", FILE_APPEND);
}

// --- NEW: ARCHIVE TABLES (ئەرشیف) ---
try {
    $conn->query("CREATE TABLE IF NOT EXISTS sales_archive (id BIGINT PRIMARY KEY, total DECIMAL(10,2), discount DECIMAL(10,2), items_json LONGTEXT, created_at DATETIME, cashier VARCHAR(100), payment_method VARCHAR(20) DEFAULT 'cash', customer_id INT DEFAULT 0, customer_type VARCHAR(20) DEFAULT 'customer', is_returned TINYINT(1) DEFAULT 0, transaction_id VARCHAR(40), archived_at DATETIME)");
    $conn->query("SELECT 1 FROM sales_archive LIMIT 1");
} catch (Throwable $e) {
    file_put_contents('pos_debug.log', date('Y-m-d H:i:s') . " - DB INIT ERROR (sales_archive): " . $e->getMessage() . "\n", FILE_APPEND);
}

try {
    $conn->query("CREATE TABLE IF NOT EXISTS expenses_archive (id BIGINT PRIMARY KEY, note VARCHAR(255), amount DECIMAL(10,2), `date` DATETIME, user VARCHAR(100), type VARCHAR(50) DEFAULT 'operational', transaction_id VARCHAR(40), archived_at DATETIME)");
    $conn->query("SELECT 1 FROM expenses_archive LIMIT 1");
} catch (Throwable $e) {
    file_put_contents('pos_debug.log', date('Y-m-d H:i:s') . " - DB INIT ERROR (expenses_archive): " . $e->getMessage() . "\n", FILE_APPEND);
}
try {
    $conn->query("CREATE TABLE IF NOT EXISTS companies (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100), phone VARCHAR(50), address VARCHAR(255), balance DECIMAL(10,2))");
    $conn->query("SELECT 1 FROM companies LIMIT 1");
    $conn->query("ALTER TABLE companies ADD UNIQUE INDEX idx_comp_name (name)"); // FIX: Prevent duplicate companies
} catch (Throwable $e) {
    file_put_contents('pos_debug.log', date('Y-m-d H:i:s') . " - DB INIT ERROR (companies): " . $e->getMessage() . "\n", FILE_APPEND);
}
checkAndAddCol($conn, 'companies', 'debt_limit', "DECIMAL(18,3) DEFAULT 0");
checkAndAddCol($conn, 'companies', 'opening_balance', "DECIMAL(18,3) DEFAULT 0");
checkAndAddCol($conn, 'companies', 'payment_term_value', "INT NOT NULL DEFAULT 0");
checkAndAddCol($conn, 'companies', 'payment_term_unit', "VARCHAR(10) NOT NULL DEFAULT 'day'");
try {
    $conn->query("CREATE TABLE IF NOT EXISTS manufacturers (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, phone VARCHAR(50) DEFAULT '', note VARCHAR(255) DEFAULT '', is_active TINYINT(1) DEFAULT 1)");
    $conn->query("SELECT 1 FROM manufacturers LIMIT 1");
    try { $conn->query("ALTER TABLE manufacturers ADD UNIQUE INDEX idx_mfr_name (name)"); } catch (Throwable $eMfrIdx) {}
    $mfrSeed = $conn->query("SELECT COUNT(*) AS c FROM manufacturers");
    $mfrCount = ($mfrSeed && ($mr = $mfrSeed->fetch_assoc())) ? (int)$mr['c'] : 0;
    if ($mfrCount === 0) {
        $prodMfr = $conn->query("SELECT DISTINCT TRIM(manufacturer) AS n FROM products WHERE manufacturer IS NOT NULL AND TRIM(manufacturer) <> ''");
        if ($prodMfr) {
            $insMfr = $conn->prepare("INSERT IGNORE INTO manufacturers (name) VALUES (?)");
            if ($insMfr) {
                while ($row = $prodMfr->fetch_assoc()) {
                    $n = trim((string)($row['n'] ?? ''));
                    if ($n === '') continue;
                    $insMfr->bind_param("s", $n);
                    $insMfr->execute();
                }
            }
        }
    }
} catch (Throwable $e) {
    file_put_contents('pos_debug.log', date('Y-m-d H:i:s') . " - DB INIT ERROR (manufacturers): " . $e->getMessage() . "\n", FILE_APPEND);
}
checkAndAddCol($conn, 'manufacturers', 'phone', "VARCHAR(50) DEFAULT ''");
checkAndAddCol($conn, 'manufacturers', 'note', "VARCHAR(255) DEFAULT ''");
checkAndAddCol($conn, 'manufacturers', 'is_active', "TINYINT(1) DEFAULT 1");
try {
    $conn->query("CREATE TABLE IF NOT EXISTS supplies (id INT AUTO_INCREMENT PRIMARY KEY, company VARCHAR(100), prodId INT, itemName VARCHAR(255), qtyAdded DECIMAL(14,3), totalCost DECIMAL(10,2), date DATETIME, type VARCHAR(20))");
    $conn->query("SELECT 1 FROM supplies LIMIT 1");
} catch (Throwable $e) {
    file_put_contents('pos_debug.log', date('Y-m-d H:i:s') . " - DB INIT ERROR (supplies): " . $e->getMessage() . "\n", FILE_APPEND);
}
try {
    $conn->query("CREATE TABLE IF NOT EXISTS ledger (id INT AUTO_INCREMENT PRIMARY KEY, companyId INT, type VARCHAR(50), amount DECIMAL(10,2), date DATETIME, note VARCHAR(255))");
    $conn->query("SELECT 1 FROM ledger LIMIT 1");
} catch (Throwable $e) {
    file_put_contents('pos_debug.log', date('Y-m-d H:i:s') . " - DB INIT ERROR (ledger): " . $e->getMessage() . "\n", FILE_APPEND);
}
try {
    $conn->query("CREATE TABLE IF NOT EXISTS users (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100), pin VARCHAR(50), role VARCHAR(20), hourlyRate DECIMAL(10,2))");
    $conn->query("SELECT 1 FROM users LIMIT 1");
} catch (Throwable $e) {
    file_put_contents('pos_debug.log', date('Y-m-d H:i:s') . " - DB INIT ERROR (users): " . $e->getMessage() . "\n", FILE_APPEND);
}
try {
    $conn->query("CREATE TABLE IF NOT EXISTS settings (setting_key VARCHAR(50) PRIMARY KEY, setting_value LONGTEXT)");
    $conn->query("SELECT 1 FROM settings LIMIT 1");
} catch (Throwable $e) {
    file_put_contents('pos_debug.log', date('Y-m-d H:i:s') . " - DB INIT ERROR (settings): " . $e->getMessage() . "\n", FILE_APPEND);
}

// --- NEW: CUSTOMERS & DEBT LEDGER TABLES ---
try {
    $conn->query("CREATE TABLE IF NOT EXISTS customers (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100), phone VARCHAR(50), balance DECIMAL(10,2) DEFAULT 0)");
    $conn->query("SELECT 1 FROM customers LIMIT 1");
} catch (Throwable $e) {
    if (strpos($e->getMessage(), 'Tablespace') !== false || strpos($e->getMessage(), "doesn't exist in engine") !== false) {
        $conn->query("DROP TABLE IF EXISTS customers");
        $conn->query("CREATE TABLE IF NOT EXISTS customers (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100), phone VARCHAR(50), balance DECIMAL(10,2) DEFAULT 0)");
    }
}
checkAndAddCol($conn, 'customers', 'address', "VARCHAR(255) DEFAULT ''");
checkAndAddCol($conn, 'customers', 'debt_limit', "DECIMAL(18,3) DEFAULT 0");
checkAndAddCol($conn, 'customers', 'opening_balance', "DECIMAL(18,3) DEFAULT 0");
checkAndAddCol($conn, 'customers', 'payment_term_value', "INT NOT NULL DEFAULT 0");
checkAndAddCol($conn, 'customers', 'payment_term_unit', "VARCHAR(10) NOT NULL DEFAULT 'day'");
try {
    $conn->query("CREATE TABLE IF NOT EXISTS customer_ledger (id BIGINT AUTO_INCREMENT PRIMARY KEY, target_id INT, target_type VARCHAR(20), type VARCHAR(50), amount DECIMAL(10,2), date DATETIME, note VARCHAR(255))");
    $conn->query("SELECT 1 FROM customer_ledger LIMIT 1");
} catch (Throwable $e) {
    if (strpos($e->getMessage(), 'Tablespace') !== false || strpos($e->getMessage(), "doesn't exist in engine") !== false) {
        $conn->query("DROP TABLE IF EXISTS customer_ledger");
        $conn->query("CREATE TABLE IF NOT EXISTS customer_ledger (id BIGINT AUTO_INCREMENT PRIMARY KEY, target_id INT, target_type VARCHAR(20), type VARCHAR(50), amount DECIMAL(10,2), date DATETIME, note VARCHAR(255))");
    }
}
// --- CUSTOMER INSTALLMENT PLANS (قست) ---
try {
    $conn->query("CREATE TABLE IF NOT EXISTS customer_installment_plans (
        id INT AUTO_INCREMENT PRIMARY KEY,
        customer_id INT NOT NULL,
        total_amount DECIMAL(18,3) NOT NULL DEFAULT 0,
        months INT NOT NULL DEFAULT 2,
        monthly_amount DECIMAL(18,3) NOT NULL DEFAULT 0,
        start_date DATE NOT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'active',
        note VARCHAR(255) DEFAULT '',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        created_by VARCHAR(100) DEFAULT '',
        INDEX idx_cip_customer (customer_id, status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $conn->query("SELECT 1 FROM customer_installment_plans LIMIT 1");
} catch (Throwable $e) {
    file_put_contents('pos_debug.log', date('Y-m-d H:i:s') . " - DB INIT ERROR (customer_installment_plans): " . $e->getMessage() . "\n", FILE_APPEND);
}
try {
    $conn->query("CREATE TABLE IF NOT EXISTS customer_installment_items (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        plan_id INT NOT NULL,
        installment_no INT NOT NULL,
        due_date DATE NOT NULL,
        amount DECIMAL(18,3) NOT NULL DEFAULT 0,
        paid_amount DECIMAL(18,3) NOT NULL DEFAULT 0,
        status VARCHAR(20) NOT NULL DEFAULT 'pending',
        paid_at DATETIME NULL,
        ledger_id BIGINT NULL,
        INDEX idx_cii_plan (plan_id),
        INDEX idx_cii_due (due_date, status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $conn->query("SELECT 1 FROM customer_installment_items LIMIT 1");
} catch (Throwable $e) {
    file_put_contents('pos_debug.log', date('Y-m-d H:i:s') . " - DB INIT ERROR (customer_installment_items): " . $e->getMessage() . "\n", FILE_APPEND);
}
try {
    $conn->query("CREATE TABLE IF NOT EXISTS waste (id BIGINT AUTO_INCREMENT PRIMARY KEY, prodId INT, prodName VARCHAR(255), qty INT, cost DECIMAL(10,2), reason VARCHAR(255), date DATETIME, user VARCHAR(100))");
    $conn->query("SELECT 1 FROM waste LIMIT 1");
} catch (Throwable $e) {
    if (strpos($e->getMessage(), 'Tablespace') !== false || strpos($e->getMessage(), "doesn't exist in engine") !== false) {
        $conn->query("DROP TABLE IF EXISTS waste");
        $conn->query("CREATE TABLE IF NOT EXISTS waste (id BIGINT AUTO_INCREMENT PRIMARY KEY, prodId INT, prodName VARCHAR(255), qty INT, cost DECIMAL(10,2), reason VARCHAR(255), date DATETIME, user VARCHAR(100))");
    }
}
try {
    $conn->query("CREATE TABLE IF NOT EXISTS recipes (id INT AUTO_INCREMENT PRIMARY KEY, product_id INT, ingredient_id INT, qty DECIMAL(10,3))");
    $conn->query("SELECT 1 FROM recipes LIMIT 1");
} catch (Throwable $e) {
    if (strpos($e->getMessage(), 'Tablespace') !== false || strpos($e->getMessage(), "doesn't exist in engine") !== false) {
        $conn->query("DROP TABLE IF EXISTS recipes");
        $conn->query("CREATE TABLE IF NOT EXISTS recipes (id INT AUTO_INCREMENT PRIMARY KEY, product_id INT, ingredient_id INT, qty DECIMAL(10,3))");
    }
}
// --- NEW: COMPANY DOCUMENTS (RECEIPTS) ---
try {
    $conn->query("CREATE TABLE IF NOT EXISTS company_documents (id INT AUTO_INCREMENT PRIMARY KEY, company_id INT, image_data LONGTEXT, created_at DATETIME, note VARCHAR(255))");
    $conn->query("SELECT 1 FROM company_documents LIMIT 1");
} catch (Throwable $e) {
    file_put_contents('pos_debug.log', date('Y-m-d H:i:s') . " - DB INIT ERROR (company_documents): " . $e->getMessage() . "\n", FILE_APPEND);
}
// --- NEW: SYSTEM SNAPSHOTS (AUTO-BACKUP) ---
try {
    $conn->query("CREATE TABLE IF NOT EXISTS system_snapshots (id INT AUTO_INCREMENT PRIMARY KEY, created_at DATETIME, data LONGTEXT)");
    $conn->query("SELECT 1 FROM system_snapshots LIMIT 1");
} catch (Throwable $e) {
    file_put_contents('pos_debug.log', date('Y-m-d H:i:s') . " - DB INIT ERROR (system_snapshots): " . $e->getMessage() . "\n", FILE_APPEND);
}
// --- PURCHASE RETURNS (زڤراندنا کەرەستان بۆ کۆمپانیێ) ---
try {
    $conn->query("CREATE TABLE IF NOT EXISTS purchase_returns (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        company_id BIGINT NOT NULL,
        company_name VARCHAR(100) NOT NULL,
        items_json LONGTEXT NOT NULL,
        total DECIMAL(12,2) NOT NULL DEFAULT 0,
        `date` DATETIME NOT NULL,
        `user` VARCHAR(100) DEFAULT '',
        note VARCHAR(255) DEFAULT '',
        transaction_id VARCHAR(50) DEFAULT NULL
    )");
    $conn->query("SELECT 1 FROM purchase_returns LIMIT 1");
} catch (Throwable $e) {
    file_put_contents('pos_debug.log', date('Y-m-d H:i:s') . " - DB INIT ERROR (purchase_returns): " . $e->getMessage() . "\n", FILE_APPEND);
}
checkAndAddCol($conn, 'purchase_returns', 'supplier_invoice_number', "VARCHAR(100) DEFAULT ''");
checkAndAddCol($conn, 'purchase_returns', 'cash_refunded', "DECIMAL(12,2) DEFAULT 0");
checkAndAddCol($conn, 'purchase_returns', 'debt_adjusted', "DECIMAL(12,2) DEFAULT 0");

// --- NEW: RETURNS TABLE (Bo vegerandina tistan be wesl) ---
try {
    $conn->query("CREATE TABLE IF NOT EXISTS returns (id INT AUTO_INCREMENT PRIMARY KEY, items_json LONGTEXT, total DECIMAL(10,2), date DATETIME, cashier VARCHAR(100), note VARCHAR(255))");
    $conn->query("SELECT 1 FROM returns LIMIT 1");
} catch (Throwable $e) {
    if (strpos($e->getMessage(), 'Tablespace') !== false || strpos($e->getMessage(), "doesn't exist in engine") !== false) {
        $conn->query("DROP TABLE IF EXISTS returns");
        $conn->query("CREATE TABLE IF NOT EXISTS returns (id INT AUTO_INCREMENT PRIMARY KEY, items_json LONGTEXT, total DECIMAL(10,2), date DATETIME, cashier VARCHAR(100), note VARCHAR(255))");
    }
}
checkAndAddCol($conn, 'returns', 'sale_id', "BIGINT DEFAULT NULL");
checkAndAddCol($conn, 'returns', 'payment_method', "VARCHAR(20) DEFAULT 'cash'");
checkAndAddCol($conn, 'returns', 'target_id', "INT DEFAULT 0");
checkAndAddCol($conn, 'returns', 'target_type', "VARCHAR(20) DEFAULT ''");
// --- NEW: DELIVERY TABLE (Bo Beridan) ---
try {
    $conn->query("CREATE TABLE IF NOT EXISTS deliveries (id INT AUTO_INCREMENT PRIMARY KEY, customer_name VARCHAR(100), phone VARCHAR(50), address VARCHAR(255), driver VARCHAR(100), total DECIMAL(10,2), status VARCHAR(20), date DATETIME, note VARCHAR(255))");
    $conn->query("SELECT 1 FROM deliveries LIMIT 1");
} catch (Throwable $e) {
    if (strpos($e->getMessage(), 'Tablespace') !== false || strpos($e->getMessage(), "doesn't exist in engine") !== false) {
        $conn->query("DROP TABLE IF EXISTS deliveries");
        $conn->query("CREATE TABLE IF NOT EXISTS deliveries (id INT AUTO_INCREMENT PRIMARY KEY, customer_name VARCHAR(100), phone VARCHAR(50), address VARCHAR(255), driver VARCHAR(100), total DECIMAL(10,2), status VARCHAR(20), date DATETIME, note VARCHAR(255))");
    }
}
checkAndAddCol($conn, 'deliveries', 'items_json', "LONGTEXT");
checkAndAddCol($conn, 'deliveries', 'driver_phone', "VARCHAR(50)");
checkAndAddCol($conn, 'deliveries', 'delivery_cost', "DECIMAL(10,2) DEFAULT 0");
if (function_exists('pos_ensure_drivers_schema')) {
    pos_ensure_drivers_schema($conn);
}

// Add balance column to users (employees)
checkAndAddCol($conn, 'users', 'balance', "DECIMAL(10,2) DEFAULT 0");
checkAndAddCol($conn, 'sales', 'payment_method', "VARCHAR(20) DEFAULT 'cash'");
checkAndAddCol($conn, 'users', 'permissions', "TEXT");
checkAndAddCol($conn, 'sales', 'customer_id', "INT DEFAULT 0");
checkAndAddCol($conn, 'sales', 'customer_type', "VARCHAR(20) DEFAULT 'customer'");
checkAndAddCol($conn, 'sales', 'is_returned', "TINYINT(1) DEFAULT 0");
checkAndAddCol($conn, 'sales', 'transaction_id', "VARCHAR(40)");
checkAndAddCol($conn, 'sales', 'sale_request_key', "VARCHAR(80) DEFAULT NULL");
checkAndAddCol($conn, 'sales', 'paid_amount', "DECIMAL(12,2) DEFAULT 0");
checkAndAddCol($conn, 'sales', 'debt_amount', "DECIMAL(12,2) DEFAULT 0");
checkAndAddCol($conn, 'sales', 'bank_amount', "DECIMAL(12,2) DEFAULT 0");
checkAndAddCol($conn, 'sales', 'received_amount', "DECIMAL(12,2) DEFAULT 0");
checkAndAddCol($conn, 'sales', 'total_bill', "DECIMAL(12,2) DEFAULT 0");
checkAndAddCol($conn, 'sales', 'tax_discount', "DECIMAL(12,2) DEFAULT 0");
checkAndAddCol($conn, 'sales', 'paid_cash', "DECIMAL(12,2) DEFAULT 0");
checkAndAddCol($conn, 'sales', 'paid_bank', "DECIMAL(12,2) DEFAULT 0");
checkAndAddCol($conn, 'sales', 'remaining_debt', "DECIMAL(12,2) DEFAULT 0");
checkAndAddCol($conn, 'sales', 'warehouse_id', "INT NOT NULL DEFAULT 0");
checkAndAddCol($conn, 'sales', 'payment_due_at', "DATETIME NULL DEFAULT NULL");
checkAndAddCol($conn, 'sales', 'followup_sent_at', "DATETIME NULL DEFAULT NULL");
// Per-transaction FX snapshot (same encoding as settings usdRate: per-one * 100)
checkAndAddCol($conn, 'sales', 'fx_usd_rate', "INT UNSIGNED NULL DEFAULT NULL");
checkAndAddCol($conn, 'sales', 'fx_currency_mode', "VARCHAR(3) NULL DEFAULT NULL");
checkAndAddCol($conn, 'sales_archive', 'fx_usd_rate', "INT UNSIGNED NULL DEFAULT NULL");
checkAndAddCol($conn, 'sales_archive', 'fx_currency_mode', "VARCHAR(3) NULL DEFAULT NULL");
checkAndAddCol($conn, 'returns', 'fx_usd_rate', "INT UNSIGNED NULL DEFAULT NULL");
checkAndAddCol($conn, 'returns', 'fx_currency_mode', "VARCHAR(3) NULL DEFAULT NULL");
checkAndAddCol($conn, 'supplies', 'fx_usd_rate', "INT UNSIGNED NULL DEFAULT NULL");
checkAndAddCol($conn, 'supplies', 'fx_currency_mode', "VARCHAR(3) NULL DEFAULT NULL");
checkAndAddCol($conn, 'expenses', 'transaction_id', "VARCHAR(40)");
checkAndAddCol($conn, 'supplies', 'transaction_id', "VARCHAR(40)");
checkAndAddCol($conn, 'supplies', 'supplier_invoice_number', "VARCHAR(100) DEFAULT ''");
checkAndAddCol($conn, 'supplies', 'batch_number', "VARCHAR(100) DEFAULT ''");
checkAndAddCol($conn, 'supplies', 'is_gift', "TINYINT(1) NOT NULL DEFAULT 0");
checkAndAddCol($conn, 'supplies', 'payment_due_at', "DATETIME NULL DEFAULT NULL");
checkAndAddCol($conn, 'supplies', 'expiry_date', "DATE DEFAULT NULL");
checkAndAddCol($conn, 'ledger', 'transaction_id', "VARCHAR(40)");
checkAndAddCol($conn, 'customer_ledger', 'transaction_id', "VARCHAR(40)");
checkAndAddCol($conn, 'customer_ledger', 'receipt_id', "VARCHAR(50)");
checkAndAddCol($conn, 'customer_ledger', 'payment_method', "VARCHAR(20) DEFAULT 'cash'");
// --- FIX: Create Shifts table (moved from restore)
try {
    $conn->query("CREATE TABLE IF NOT EXISTS shifts (id BIGINT PRIMARY KEY, userId INT, userName VARCHAR(100), startTime DATETIME, endTime DATETIME, hourlyRate DECIMAL(10,2), opening_balance DECIMAL(10,2) DEFAULT 0)");
    $conn->query("SELECT 1 FROM shifts LIMIT 1");
} catch (Throwable $e) {
    file_put_contents('pos_debug.log', date('Y-m-d H:i:s') . " - DB INIT ERROR (shifts): " . $e->getMessage() . "\n", FILE_APPEND);
}

checkAndAddCol($conn, 'shifts', 'opening_balance', "DECIMAL(10,2) DEFAULT 0");
checkAndAddCol($conn, 'shifts', 'closing_balance_expected', "DECIMAL(12,2)");
checkAndAddCol($conn, 'shifts', 'closing_balance_actual', "DECIMAL(12,2)");
checkAndAddCol($conn, 'shifts', 'shortage', "DECIMAL(12,2)");
checkAndAddCol($conn, 'shifts', 'surplus', "DECIMAL(12,2)");
checkAndAddCol($conn, 'shifts', 'reconciled_by', "VARCHAR(100)");

// --- FIX: Ensure Expenses Table Columns Exist (چاککردنی خشتەی مەسرەفات) ---
checkAndAddCol($conn, 'expenses', 'date', "DATETIME");
checkAndAddCol($conn, 'expenses', 'user', "VARCHAR(100)");
checkAndAddCol($conn, 'expenses', 'type', "VARCHAR(50) DEFAULT 'operational'"); // FIX: Add Type for Accounting
checkAndAddCol($conn, 'expenses', 'company_id', 'INT NULL DEFAULT NULL');
checkAndAddCol($conn, 'expenses_archive', 'archive_reason', "VARCHAR(50) DEFAULT NULL");
checkAndAddCol($conn, 'expenses_archive', 'deleted_by', "VARCHAR(100) DEFAULT NULL");

// Ensure Tables table exists and has correct structure (Fix for disappearing tables)
try {
    $conn->query("CREATE TABLE IF NOT EXISTS tables (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100), items_json LONGTEXT)");
    $conn->query("SELECT 1 FROM tables LIMIT 1");
} catch (Throwable $e) {
    file_put_contents('pos_debug.log', date('Y-m-d H:i:s') . " - DB INIT ERROR (tables): " . $e->getMessage() . "\n", FILE_APPEND);
}
// Must run after CREATE TABLE: early checkAndAddCol ran before `tables` existed and silently skipped (Takeaway / JSON parse errors).
checkAndAddCol($conn, 'tables', 'isTakeaway', "TINYINT(1) DEFAULT 0");
checkAndAddCol($conn, 'tables', 'has_new_items', "TINYINT(1) DEFAULT 0");

// --- NEW: UNIFIED LEDGER (Treasury & Accounting) ---
try {
    $conn->query("CREATE TABLE IF NOT EXISTS ledger (id BIGINT AUTO_INCREMENT PRIMARY KEY, transaction_id VARCHAR(50), type VARCHAR(20), amount DECIMAL(15,2), related_id BIGINT, description VARCHAR(255), created_at DATETIME, balance_after DECIMAL(15,2) DEFAULT 0)");
    $conn->query("SELECT 1 FROM ledger LIMIT 1");
} catch (Throwable $e) {
    file_put_contents('pos_debug.log', date('Y-m-d H:i:s') . " - DB INIT ERROR (ledger_bigint): " . $e->getMessage() . "\n", FILE_APPEND);
}
checkAndAddCol($conn, 'ledger', 'balance_after', "DECIMAL(15,2) DEFAULT 0");
checkAndAddCol($conn, 'ledger', 'related_id', "BIGINT DEFAULT 0");
checkAndAddCol($conn, 'ledger', 'companyId', "INT DEFAULT 0");

// --- NEW: AUDIT LOGS TABLE (Bo Security & Anti-Fraud) ---
try {
    $conn->query("CREATE TABLE IF NOT EXISTS audit_logs (id BIGINT AUTO_INCREMENT PRIMARY KEY, user VARCHAR(100), action_type VARCHAR(50), details TEXT, created_at DATETIME)");
    $conn->query("SELECT 1 FROM audit_logs LIMIT 1");
} catch (Throwable $e) {
    file_put_contents('pos_debug.log', date('Y-m-d H:i:s') . " - DB INIT ERROR (audit_logs): " . $e->getMessage() . "\n", FILE_APPEND);
}
checkAndAddCol($conn, 'audit_logs', 'ip_address', "VARCHAR(50)");
checkAndAddCol($conn, 'audit_logs', 'user_id', "INT DEFAULT 0");
checkAndAddCol($conn, 'audit_logs', 'entity_type', "VARCHAR(50) DEFAULT NULL");
checkAndAddCol($conn, 'audit_logs', 'entity_id', "BIGINT DEFAULT NULL");
checkAndAddCol($conn, 'audit_logs', 'old_value', "TEXT DEFAULT NULL");
checkAndAddCol($conn, 'audit_logs', 'new_value', "TEXT DEFAULT NULL");

// --- PRINT LOG (سجل عمليات الطباعة - Audit Trail for all printed receipts) ---
try {
    $conn->query("CREATE TABLE IF NOT EXISTS print_log (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        doc_type VARCHAR(50) NOT NULL,
        doc_id VARCHAR(50) DEFAULT '',
        action VARCHAR(20) NOT NULL,
        user VARCHAR(100) DEFAULT '',
        user_id BIGINT DEFAULT 0,
        note TEXT,
        details TEXT,
        ip_address VARCHAR(50) DEFAULT '',
        created_at DATETIME NOT NULL
    )");
    $conn->query("SELECT 1 FROM print_log LIMIT 1");
} catch (Throwable $e) {
    file_put_contents('pos_debug.log', date('Y-m-d H:i:s') . " - DB INIT ERROR (print_log): " . $e->getMessage() . "\n", FILE_APPEND);
}

// --- STOCK MOVEMENTS (Item lifecycle / Stock Card audit trail) ---
try {
    $conn->query("CREATE TABLE IF NOT EXISTS stock_movements (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        product_id INT NOT NULL,
        barcode VARCHAR(100) DEFAULT '',
        movement_type VARCHAR(30) NOT NULL,
        quantity DECIMAL(14,3) NOT NULL,
        unit_cost DECIMAL(12,2) DEFAULT 0,
        total_value DECIMAL(12,2) DEFAULT 0,
        reference_type VARCHAR(30) DEFAULT '',
        reference_id BIGINT DEFAULT 0,
        date DATETIME NOT NULL,
        user VARCHAR(100) DEFAULT '',
        note VARCHAR(255) DEFAULT ''
    )");
    $conn->query("SELECT 1 FROM stock_movements LIMIT 1");
} catch (Throwable $e) {
    file_put_contents('pos_debug.log', date('Y-m-d H:i:s') . " - DB INIT ERROR (stock_movements): " . $e->getMessage() . "\n", FILE_APPEND);
}

// --- EXPIRY BATCHES ---
try {
    $conn->query("CREATE TABLE IF NOT EXISTS stock_batches (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        product_id BIGINT NOT NULL,
        expiry_date DATE NOT NULL,
        qty DECIMAL(14,3) NOT NULL DEFAULT 0,
        unit_cost DECIMAL(12,2) DEFAULT 0,
        source_type VARCHAR(30) DEFAULT 'purchase',
        source_id BIGINT DEFAULT 0,
        transaction_id VARCHAR(50) DEFAULT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_batch_product_expiry (product_id, expiry_date),
        INDEX idx_batch_expiry (expiry_date),
        INDEX idx_batch_qty (qty)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $conn->query("SELECT 1 FROM stock_batches LIMIT 1");
} catch (Throwable $e) {
    file_put_contents('pos_debug.log', date('Y-m-d H:i:s') . " - DB INIT ERROR (stock_batches): " . $e->getMessage() . "\n", FILE_APPEND);
}

// Ensure cashier column exists in sales for reports
checkAndAddCol($conn, 'sales', 'cashier', "VARCHAR(100)");

// --- AUTO-FIX: UPGRADE ID COLUMNS TO BIGINT (Bo qebilkirina ID yen mezin yen JSON) ---
$tablesToUpgrade = ['products', 'sales', 'companies', 'supplies', 'ledger', 'users', 'shifts', 'expenses', 'tables'];
foreach($tablesToUpgrade as $tbl) {
    try {
        $conn->query("ALTER TABLE $tbl MODIFY COLUMN id BIGINT AUTO_INCREMENT");
    } catch(Throwable $e) {}
}
try {
    $conn->query("ALTER TABLE sales MODIFY COLUMN id BIGINT NOT NULL AUTO_INCREMENT");
} catch(Throwable $e) {}
try {
    $conn->query("ALTER TABLE supplies MODIFY COLUMN prodId BIGINT");
} catch(Throwable $e) {}
try { $conn->query("ALTER TABLE products MODIFY COLUMN qty DECIMAL(14,3) DEFAULT 0"); } catch(Throwable $e) {}
try { $conn->query("ALTER TABLE supplies MODIFY COLUMN qtyAdded DECIMAL(14,3) DEFAULT 0"); } catch(Throwable $e) {}
try { $conn->query("ALTER TABLE stock_movements MODIFY COLUMN quantity DECIMAL(14,3) NOT NULL DEFAULT 0"); } catch(Throwable $e) {}
try { $conn->query("ALTER TABLE stock_batches MODIFY COLUMN qty DECIMAL(14,3) NOT NULL DEFAULT 0"); } catch(Throwable $e) {}
try {
    $conn->query("ALTER TABLE ledger MODIFY COLUMN companyId BIGINT");
} catch(Throwable $e) {}
checkAndAddCol($conn, 'products', 'expiry', "VARCHAR(50)");
checkAndAddCol($conn, 'products', 'item_type', "VARCHAR(20) DEFAULT 'constant'");
checkAndAddCol($conn, 'products', 'is_active', "TINYINT(1) DEFAULT 1");
checkAndAddCol($conn, 'companies', 'is_active', "TINYINT(1) DEFAULT 1");
checkAndAddCol($conn, 'users', 'is_active', "TINYINT(1) DEFAULT 1");
checkAndAddCol($conn, 'customers', 'is_active', "TINYINT(1) DEFAULT 1");

// Ensure items_json can hold large data
try {
    $conn->query("ALTER TABLE sales MODIFY COLUMN items_json LONGTEXT");
} catch(Throwable $e) {}

// Ensure Default Admin User exists (Fix for Login Error)
// FIX: Cleanup duplicates first (Remove duplicate Managers)
$conn->query("DELETE t1 FROM users t1 INNER JOIN users t2 WHERE t1.id > t2.id AND t1.name = t2.name");
try { $conn->query("ALTER TABLE users ADD UNIQUE INDEX idx_user_name (name)"); } catch(Throwable $e) {}

$chk = $conn->query("SELECT id FROM users WHERE name = 'Manager' LIMIT 1");
if($chk && $chk->num_rows == 0) {
    $conn->query("INSERT INTO users (name, pin, role, hourlyRate) VALUES ('Manager', '2026', 'admin', 0)");
}

// --- OPTIMIZATION: ADD INDEXES (Bo leztr kirina databse) ---
try {
    $conn->query("CREATE INDEX idx_products_barcode ON products (barcode)");
    $conn->query("CREATE INDEX idx_products_name ON products (name)");
    $conn->query("CREATE INDEX idx_sales_date ON sales (created_at)");
} catch(Throwable $e) {}
try { $conn->query("CREATE UNIQUE INDEX idx_sales_request_key ON sales (sale_request_key)"); } catch(Throwable $e) {}
try { $conn->query("CREATE INDEX idx_sales_cashier_date ON sales (cashier, created_at)"); } catch(Throwable $e) {}
try { $conn->query("CREATE INDEX idx_sales_transaction_id ON sales (transaction_id)"); } catch(Throwable $e) {}
try { $conn->query("CREATE INDEX idx_expenses_date ON expenses (`date`)"); } catch(Throwable $e) {}
try { $conn->query("CREATE INDEX idx_expenses_user_date ON expenses (`user`, `date`)"); } catch(Throwable $e) {}
try { $conn->query("CREATE INDEX idx_ledger_type_date ON ledger (type, date)"); } catch(Throwable $e) {}
try { $conn->query("CREATE INDEX idx_ledger_date ON ledger (`date`)"); } catch(Throwable $e) {}
try { $conn->query("CREATE INDEX idx_sales_created_at ON sales (created_at)"); } catch(Throwable $e) {}
try { $conn->query("CREATE INDEX idx_customer_ledger_target_date ON customer_ledger (target_id, target_type, date)"); } catch(Throwable $e) {}
try { $conn->query("CREATE INDEX idx_products_track_qty ON products (trackStock, qty)"); } catch(Throwable $e) {}
try { $conn->query("CREATE INDEX idx_stock_movements_product_date ON stock_movements (product_id, date)"); } catch(Throwable $e) {}
try { $conn->query("CREATE INDEX idx_stock_batches_product_qty ON stock_batches (product_id, qty)"); } catch(Throwable $e) {}
try { $conn->query("CREATE INDEX idx_sales_archive_created_at ON sales_archive (created_at)"); } catch(Throwable $e) {}
try { $conn->query("CREATE INDEX idx_sales_archive_cashier_date ON sales_archive (cashier, created_at)"); } catch(Throwable $e) {}
try { $conn->query("CREATE INDEX idx_expenses_archive_date ON expenses_archive (`date`)"); } catch(Throwable $e) {}
try { $conn->query("CREATE INDEX idx_audit_logs_created_at ON audit_logs (created_at)"); } catch(Throwable $e) {}
try { $conn->query("CREATE INDEX idx_print_log_created_at ON print_log (created_at)"); } catch(Throwable $e) {}

// Indexes to speed up login and avoid full table scans under concurrency
try { $conn->query("CREATE INDEX idx_users_pin ON users (pin)"); } catch (Throwable $e) {}
try { $conn->query("CREATE INDEX idx_users_id_pin ON users (id, pin)"); } catch (Throwable $e) {}

// Large-shop entity + catalog search (phase 5)
try { $conn->query("CREATE INDEX idx_customers_balance_name ON customers (balance, name)"); } catch (Throwable $e) {}
try { $conn->query("CREATE INDEX idx_customers_name ON customers (name)"); } catch (Throwable $e) {}
try { $conn->query("CREATE INDEX idx_customers_phone ON customers (phone)"); } catch (Throwable $e) {}
try { $conn->query("CREATE INDEX idx_companies_balance_name ON companies (balance, name)"); } catch (Throwable $e) {}
try { $conn->query("CREATE INDEX idx_products_sku ON products (sku)"); } catch (Throwable $e) {}
try { $conn->query("CREATE INDEX idx_products_barcode_pack ON products (barcode_pack)"); } catch (Throwable $e) {}
try { $conn->query("CREATE INDEX idx_products_barcode_carton ON products (barcode_carton)"); } catch (Throwable $e) {}
try { $conn->query("CREATE INDEX idx_products_pinned_id ON products (isPinned, id)"); } catch (Throwable $e) {}
try { $conn->query("CREATE INDEX idx_supplies_id_desc ON supplies (id)"); } catch (Throwable $e) {}
try { $conn->query("CREATE INDEX idx_products_active_pinned_id ON products (is_active, isPinned, id)"); } catch (Throwable $e) {}
try { $conn->query("CREATE INDEX idx_deliveries_driver_id ON deliveries (driver_id)"); } catch (Throwable $e) {}
try { $conn->query("CREATE INDEX idx_deliveries_driver_name ON deliveries (driver)"); } catch (Throwable $e) {}
try { $conn->query("CREATE INDEX idx_deliveries_status_date ON deliveries (status, date)"); } catch (Throwable $e) {}
try { $conn->query("CREATE INDEX idx_deliveries_date ON deliveries (date)"); } catch (Throwable $e) {}

// Unique installation serial for Supabase license (one row per deployed copy)
try {
    $existing = pos_db_get_setting_value($conn, 'pos_license_serial');
    if ($existing === null || trim((string)$existing) === '') {
        $initSerial = function_exists('pos_generate_installation_license_serial')
            ? pos_generate_installation_license_serial()
            : bin2hex(random_bytes(16));
        pos_db_set_setting_value($conn, 'pos_license_serial', $initSerial);
    }
    $sec = pos_db_get_setting_value($conn, 'pos_license_security_code');
    if ($sec === null || trim((string)$sec) === '') {
        pos_db_set_setting_value($conn, 'pos_license_security_code', str_pad((string)random_int(100000, 999999), 6, '0', STR_PAD_LEFT));
    }
} catch (Throwable $e) {}

// v9: Base currency lock follows catalog size — clear stale currencyBaseLocked when there are zero products.
try {
    $cnt = 0;
    $cntRes = $conn->query("SELECT COUNT(*) AS c FROM products");
    if ($cntRes && ($row = $cntRes->fetch_assoc())) {
        $cnt = (int)($row['c'] ?? 0);
    }
    if ($cnt === 0) {
        $rawApp = pos_db_get_setting_value($conn, 'app_settings');
        if ($rawApp !== null && $rawApp !== '') {
            $decApp = json_decode($rawApp, true);
            if (is_array($decApp) && !empty($decApp['currencyBaseLocked'])) {
                unset($decApp['currencyBaseLocked']);
                pos_db_set_setting_value($conn, 'app_settings', json_encode($decApp, JSON_UNESCAPED_UNICODE));
            }
        }
    }
} catch (Throwable $e) {}

// v10: USD base-currency stabilization.
// Backfill *_usd once for legacy rows where USD references are missing.
try {
    $ratePerOne = 1500.0;
    $rawApp = pos_db_get_setting_value($conn, 'app_settings');
    if ($rawApp !== null && $rawApp !== '') {
        $decApp = json_decode($rawApp, true);
        if (is_array($decApp)) {
            $rawRate = isset($decApp['usdRate']) ? (float)$decApp['usdRate'] : 150000.0;
            if ($rawRate > 0) {
                $ratePerOne = $rawRate >= 100 ? ($rawRate / 100.0) : $rawRate;
            }
            // Do not overwrite currencyMode here (allows USD/IQD base per shop settings).
        }
    }
    $shopMode = 'IQD';
    if (isset($decApp) && is_array($decApp)) {
        $m = strtoupper(trim((string)($decApp['currencyMode'] ?? 'IQD')));
        $shopMode = ($m === 'USD') ? 'USD' : 'IQD';
    }
    if ($ratePerOne <= 0) $ratePerOne = 1500.0;
    $rateSql = (float)$ratePerOne;
    if ($shopMode === 'USD') {
        $conn->query("
            UPDATE products
            SET
                price_usd = CASE WHEN price_usd IS NULL THEN ROUND((COALESCE(price, 0) / {$rateSql}), 6) ELSE price_usd END,
                cost_usd = CASE WHEN cost_usd IS NULL THEN ROUND((COALESCE(cost, 0) / {$rateSql}), 6) ELSE cost_usd END,
                price_pack_usd = CASE WHEN price_pack_usd IS NULL AND price_pack IS NOT NULL THEN ROUND((price_pack / {$rateSql}), 6) ELSE price_pack_usd END,
                price_carton_usd = CASE WHEN price_carton_usd IS NULL AND price_carton IS NOT NULL THEN ROUND((price_carton / {$rateSql}), 6) ELSE price_carton_usd END,
                cost_pack_usd = CASE WHEN cost_pack_usd IS NULL AND cost_pack IS NOT NULL THEN ROUND((cost_pack / {$rateSql}), 6) ELSE cost_pack_usd END,
                cost_carton_usd = CASE WHEN cost_carton_usd IS NULL AND cost_carton IS NOT NULL THEN ROUND((cost_carton / {$rateSql}), 6) ELSE cost_carton_usd END
            WHERE
                price_usd IS NULL OR cost_usd IS NULL OR price_pack_usd IS NULL OR price_carton_usd IS NULL OR cost_pack_usd IS NULL OR cost_carton_usd IS NULL
        ");
    }
} catch (Throwable $e) {}

// v11: Exchange rate change log (optional audit trail; current rate remains in app_settings.usdRate).
try {
    $conn->query("CREATE TABLE IF NOT EXISTS exchange_rate_history (
        id INT AUTO_INCREMENT PRIMARY KEY,
        rate_bundle INT NOT NULL COMMENT 'IQD total for 100 USD, same encoding as app_settings.usdRate',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        user_name VARCHAR(100) NOT NULL DEFAULT '',
        note VARCHAR(255) NOT NULL DEFAULT ''
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Throwable $e) {}

// v12: Widen customer/company/supplier debt columns — USD→IQD storage can exceed DECIMAL(10,2) (e.g. high limits × rate).
try { $conn->query("ALTER TABLE companies MODIFY COLUMN balance DECIMAL(18,3) DEFAULT 0"); } catch (Throwable $e) {}
try { $conn->query("ALTER TABLE companies MODIFY COLUMN debt_limit DECIMAL(18,3) DEFAULT 0"); } catch (Throwable $e) {}
try { $conn->query("ALTER TABLE companies MODIFY COLUMN opening_balance DECIMAL(18,3) DEFAULT 0"); } catch (Throwable $e) {}
try { $conn->query("ALTER TABLE customers MODIFY COLUMN balance DECIMAL(18,3) DEFAULT 0"); } catch (Throwable $e) {}
try { $conn->query("ALTER TABLE customers MODIFY COLUMN debt_limit DECIMAL(18,3) DEFAULT 0"); } catch (Throwable $e) {}
try { $conn->query("ALTER TABLE customers MODIFY COLUMN opening_balance DECIMAL(18,3) DEFAULT 0"); } catch (Throwable $e) {}
try { $conn->query("ALTER TABLE users MODIFY COLUMN balance DECIMAL(18,3) DEFAULT 0"); } catch (Throwable $e) {}

// v13: Re-run debt column widen (idempotent) so installs that had schema_version 12 before v12 ALTER landed still upgrade.
try { $conn->query("ALTER TABLE companies MODIFY COLUMN balance DECIMAL(18,3) DEFAULT 0"); } catch (Throwable $e) {}
try { $conn->query("ALTER TABLE companies MODIFY COLUMN debt_limit DECIMAL(18,3) DEFAULT 0"); } catch (Throwable $e) {}
try { $conn->query("ALTER TABLE companies MODIFY COLUMN opening_balance DECIMAL(18,3) DEFAULT 0"); } catch (Throwable $e) {}
try { $conn->query("ALTER TABLE customers MODIFY COLUMN balance DECIMAL(18,3) DEFAULT 0"); } catch (Throwable $e) {}
try { $conn->query("ALTER TABLE customers MODIFY COLUMN debt_limit DECIMAL(18,3) DEFAULT 0"); } catch (Throwable $e) {}
try { $conn->query("ALTER TABLE customers MODIFY COLUMN opening_balance DECIMAL(18,3) DEFAULT 0"); } catch (Throwable $e) {}
try { $conn->query("ALTER TABLE users MODIFY COLUMN balance DECIMAL(18,3) DEFAULT 0"); } catch (Throwable $e) {}

// v14: expenses rows for historical company debt payments (drawer / daily summary).
try {
    pos_backfill_company_debt_payment_expenses($conn);
} catch (Throwable $e) {}

// v16: link debt_payment expenses to company_id for daily summary / reports.
try {
    pos_backfill_expenses_company_id($conn);
} catch (Throwable $e) {}

// v20: Multi-warehouse (کۆگای فرە) — locations, per-warehouse stock, transfers.
try {
    pos_ensure_multi_warehouse_schema($conn);
} catch (Throwable $e) {
    pos_migrations_log('multi_warehouse_v20: ' . $e->getMessage());
}

try {
    if (function_exists('pos_backfill_catalog_only_merged')) {
        pos_backfill_catalog_only_merged($conn);
    }
} catch (Throwable $e) {
    pos_migrations_log('catalog_only_backfill: ' . $e->getMessage());
}

// v27: IQD shops — drop USD catalog mirrors so dinar never follows dollar.
try {
    $rawIso = pos_db_get_setting_value($conn, 'app_settings');
    $decIso = ($rawIso !== null && $rawIso !== '') ? json_decode($rawIso, true) : [];
    $isoMode = 'IQD';
    if (is_array($decIso)) {
        $mIso = strtoupper(trim((string)($decIso['currencyMode'] ?? 'IQD')));
        $isoMode = ($mIso === 'USD') ? 'USD' : 'IQD';
    }
    if ($isoMode === 'IQD') {
        $conn->query("UPDATE products SET price_usd=NULL, cost_usd=NULL, price_pack_usd=NULL, price_carton_usd=NULL, cost_pack_usd=NULL, cost_carton_usd=NULL");
    }
} catch (Throwable $e) {
    pos_migrations_log('iqd_usd_isolate_v27: ' . $e->getMessage());
}

// v28: Per-product base_price + base_currency. FX changes must never rewrite these.
try {
    checkAndAddCol($conn, 'products', 'base_currency', "VARCHAR(3) NOT NULL DEFAULT 'IQD'");
    checkAndAddCol($conn, 'products', 'base_price', "DECIMAL(18,6) NOT NULL DEFAULT 0");
    checkAndAddCol($conn, 'products', 'base_cost', "DECIMAL(18,6) NOT NULL DEFAULT 0");
    $doneBase = pos_db_get_setting_value($conn, 'base_price_backfill_v28');
    if ($doneBase !== '1') {
        $rawBase = pos_db_get_setting_value($conn, 'app_settings');
        $decBase = ($rawBase !== null && $rawBase !== '') ? json_decode($rawBase, true) : [];
        $shopBase = 'IQD';
        $rateBase = 1500.0;
        if (is_array($decBase)) {
            $mBase = strtoupper(trim((string)($decBase['currencyMode'] ?? 'IQD')));
            $shopBase = ($mBase === 'USD') ? 'USD' : 'IQD';
            $rawRateB = isset($decBase['usdRate']) ? (float)$decBase['usdRate'] : 150000.0;
            if ($rawRateB > 0) {
                $rateBase = $rawRateB >= 100 ? ($rawRateB / 100.0) : $rawRateB;
            }
        }
        if ($rateBase <= 0) {
            $rateBase = 1500.0;
        }
        $rateSqlB = (float)$rateBase;
        $shopEsc = ($shopBase === 'USD') ? 'USD' : 'IQD';
        if ($shopEsc === 'USD') {
            $conn->query("
                UPDATE products
                SET
                    base_currency = 'USD',
                    base_price = CASE
                        WHEN price_usd IS NOT NULL AND price_usd <> 0 THEN price_usd
                        ELSE ROUND((COALESCE(price, 0) / {$rateSqlB}), 6)
                    END,
                    base_cost = CASE
                        WHEN cost_usd IS NOT NULL AND cost_usd <> 0 THEN cost_usd
                        ELSE ROUND((COALESCE(cost, 0) / {$rateSqlB}), 6)
                    END
            ");
        } else {
            $conn->query("
                UPDATE products
                SET
                    base_currency = 'IQD',
                    base_price = COALESCE(price, 0),
                    base_cost = COALESCE(cost, 0)
            ");
        }
        pos_db_set_setting_value($conn, 'base_price_backfill_v28', '1');
    }
} catch (Throwable $e) {
    pos_migrations_log('base_price_v28: ' . $e->getMessage());
}

// v29: Shop default_currency (IQD|USD) — display + new-product default; FX stays live for mixed carts.
try {
    $rawDef = pos_db_get_setting_value($conn, 'app_settings');
    $decDef = ($rawDef !== null && $rawDef !== '') ? json_decode($rawDef, true) : [];
    if (!is_array($decDef)) {
        $decDef = [];
    }
    $modeDef = 'IQD';
    $dPosted = strtoupper(trim((string)($decDef['defaultCurrency'] ?? $decDef['default_currency'] ?? '')));
    if ($dPosted === 'USD' || $dPosted === 'IQD') {
        $modeDef = $dPosted;
    } else {
        $mDef = strtoupper(trim((string)($decDef['currencyMode'] ?? 'IQD')));
        $modeDef = ($mDef === 'USD') ? 'USD' : 'IQD';
    }
    $decDef['defaultCurrency'] = $modeDef;
    $decDef['default_currency'] = $modeDef;
    $decDef['currencyMode'] = $modeDef;
    $decDef['currencyBaseLocked'] = false;
    $outDef = json_encode($decDef, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    if ($outDef !== false) {
        pos_db_set_setting_value($conn, 'app_settings', $outDef);
    }
    pos_db_set_setting_value($conn, 'default_currency', $modeDef);
} catch (Throwable $e) {
    pos_migrations_log('default_currency_v29: ' . $e->getMessage());
}
}

// v30: Freeze expense base amount + currency + rate at record time.
try {
    pos_ensure_expense_currency_columns($conn);
    $doneExpFx = pos_db_get_setting_value($conn, 'expense_fx_backfill_v30');
    if ($doneExpFx !== '1') {
        $rateExp = 1500.0;
        try {
            $rawExp = pos_db_get_setting_value($conn, 'app_settings');
            $decExp = ($rawExp !== null && $rawExp !== '') ? json_decode($rawExp, true) : [];
            if (is_array($decExp) && function_exists('pos_settings_usd_rate_per_one_from_array')) {
                $rateExp = (float)pos_settings_usd_rate_per_one_from_array($decExp);
            } elseif (is_array($decExp) && isset($decExp['usdRate'])) {
                $rawR = (float)$decExp['usdRate'];
                $rateExp = $rawR >= 100 ? ($rawR / 100.0) : $rawR;
            }
        } catch (Throwable $eRate) {}
        if ($rateExp <= 0) {
            $rateExp = 1500.0;
        }
        $rateSql = (float)$rateExp;
        @$conn->query("UPDATE expenses SET currency = 'IQD' WHERE currency IS NULL OR currency = '' OR UPPER(TRIM(currency)) NOT IN ('IQD','USD')");
        @$conn->query("UPDATE expenses SET exchange_rate = {$rateSql} WHERE exchange_rate IS NULL OR exchange_rate <= 0");
        @$conn->query("UPDATE expenses_archive SET currency = 'IQD' WHERE currency IS NULL OR currency = '' OR UPPER(TRIM(currency)) NOT IN ('IQD','USD')");
        @$conn->query("UPDATE expenses_archive SET exchange_rate = {$rateSql} WHERE exchange_rate IS NULL OR exchange_rate <= 0");
        pos_db_set_setting_value($conn, 'expense_fx_backfill_v30', '1');
    }
} catch (Throwable $e) {
    pos_migrations_log('expense_fx_v30: ' . $e->getMessage());
}

// v31: Freeze purchase + customer-debt FX columns. Shop FX must never rewrite these rows.
try {
    pos_ensure_txn_fx_columns($conn);
    $doneTxnFx = pos_db_get_setting_value($conn, 'txn_fx_backfill_v31');
    if ($doneTxnFx !== '1') {
        $rateTxn = 1500.0;
        try {
            $rawTxn = pos_db_get_setting_value($conn, 'app_settings');
            $decTxn = ($rawTxn !== null && $rawTxn !== '') ? json_decode($rawTxn, true) : [];
            if (is_array($decTxn) && function_exists('pos_settings_usd_rate_per_one_from_array')) {
                $rateTxn = (float)pos_settings_usd_rate_per_one_from_array($decTxn);
            }
        } catch (Throwable $eRateT) {}
        if ($rateTxn <= 0) {
            $rateTxn = 1500.0;
        }
        $rateTxnSql = (float)$rateTxn;
        foreach (['supplies', 'customer_ledger', 'customers', 'companies'] as $tblFx) {
            @$conn->query("UPDATE `{$tblFx}` SET currency = 'IQD' WHERE currency IS NULL OR currency = '' OR UPPER(TRIM(currency)) NOT IN ('IQD','USD')");
            @$conn->query("UPDATE `{$tblFx}` SET exchange_rate = {$rateTxnSql} WHERE exchange_rate IS NULL OR exchange_rate <= 0");
        }
        pos_db_set_setting_value($conn, 'txn_fx_backfill_v31', '1');
    }
} catch (Throwable $e) {
    pos_migrations_log('txn_fx_v31: ' . $e->getMessage());
}

// v32: Unified FX engine columns. Copy existing amounts 1:1 — never multiply/divide live prices.
try {
    $needFxHeal = function_exists('pos_fx_schema_needs_heal') && pos_fx_schema_needs_heal($conn);
    $doneFxEng = pos_db_get_setting_value($conn, 'fx_engine_backfill_v32');
    if ($needFxHeal || $doneFxEng !== '1') {
        if (function_exists('pos_heal_currency_schema')) {
            pos_heal_currency_schema($conn);
        } elseif (function_exists('pos_ensure_fx_engine_schema')) {
            pos_ensure_fx_engine_schema($conn);
        }
    }
} catch (Throwable $e) {
    pos_migrations_log('fx_engine_v32: ' . $e->getMessage());
}

// v33: Restored old catalogs had currency/base_price empty → $0.00 / IQD 0. Copy price 1:1.
try {
    $doneV33 = pos_db_get_setting_value($conn, 'restored_catalog_price_repair_v33');
    if ($doneV33 !== '1' && function_exists('pos_repair_restored_catalog_prices')) {
        pos_repair_restored_catalog_prices($conn);
    }
} catch (Throwable $e) {
    pos_migrations_log('catalog_price_repair_v33: ' . $e->getMessage());
}

try {
    if (function_exists('pos_ensure_hot_search_indexes')) {
        pos_ensure_hot_search_indexes($conn);
    }
} catch (Throwable $e) {
    pos_migrations_log('hot_search_indexes_v34: ' . $e->getMessage());
}

/**
 * Ledger company payments (type payment) must have matching expenses (debt_payment) for drawer/summary.
 */
/**
 * Multi-warehouse tables + backfill default location from products.qty (idempotent).
 */
function pos_ensure_multi_warehouse_schema($conn) {
    static $done = false;
    if ($done) return;
    $done = true;
    if (!$conn || !($conn instanceof mysqli)) return;

    $conn->query("CREATE TABLE IF NOT EXISTS warehouses (
        id INT AUTO_INCREMENT PRIMARY KEY,
        code VARCHAR(20) NOT NULL DEFAULT '',
        name VARCHAR(100) NOT NULL,
        address VARCHAR(255) NOT NULL DEFAULT '',
        is_default TINYINT(1) NOT NULL DEFAULT 0,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        sort_order INT NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_warehouses_code (code)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $conn->query("CREATE TABLE IF NOT EXISTS warehouse_stock (
        warehouse_id INT NOT NULL,
        product_id INT NOT NULL,
        qty DECIMAL(14,3) NOT NULL DEFAULT 0,
        min_stock INT NOT NULL DEFAULT 5,
        PRIMARY KEY (warehouse_id, product_id),
        INDEX idx_ws_product (product_id),
        INDEX idx_ws_wh_qty (warehouse_id, qty)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $conn->query("CREATE TABLE IF NOT EXISTS stock_transfers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        from_warehouse_id INT NOT NULL,
        to_warehouse_id INT NOT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'completed',
        transaction_id VARCHAR(50) NOT NULL DEFAULT '',
        total_qty DECIMAL(14,3) NOT NULL DEFAULT 0,
        date DATETIME NOT NULL,
        user VARCHAR(100) NOT NULL DEFAULT '',
        note VARCHAR(255) NOT NULL DEFAULT ''
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $conn->query("CREATE TABLE IF NOT EXISTS stock_transfer_lines (
        id INT AUTO_INCREMENT PRIMARY KEY,
        transfer_id INT NOT NULL,
        product_id INT NOT NULL,
        qty DECIMAL(14,3) NOT NULL DEFAULT 0,
        unit_cost DECIMAL(12,2) NOT NULL DEFAULT 0,
        INDEX idx_stl_transfer (transfer_id),
        INDEX idx_stl_product (product_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    if (function_exists('checkAndAddCol')) {
        checkAndAddCol($conn, 'stock_movements', 'warehouse_id', 'INT NOT NULL DEFAULT 1');
        checkAndAddCol($conn, 'stock_movements', 'to_warehouse_id', 'INT NULL DEFAULT NULL');
        checkAndAddCol($conn, 'supplies', 'warehouse_id', 'INT NOT NULL DEFAULT 1');
        checkAndAddCol($conn, 'stock_batches', 'warehouse_id', 'INT NOT NULL DEFAULT 1');
        checkAndAddCol($conn, 'waste', 'warehouse_id', 'INT NOT NULL DEFAULT 1');
        checkAndAddCol($conn, 'warehouses', 'pin_hash', "VARCHAR(255) NOT NULL DEFAULT ''");
        checkAndAddCol($conn, 'sales', 'warehouse_id', 'INT NOT NULL DEFAULT 0');
    }

    $chk = $conn->query("SELECT id FROM warehouses WHERE is_default = 1 LIMIT 1");
    $defaultId = 0;
    if ($chk && ($row = $chk->fetch_assoc())) {
        $defaultId = (int)$row['id'];
    }
    if ($defaultId <= 0) {
        $chkAny = $conn->query("SELECT id FROM warehouses ORDER BY id ASC LIMIT 1");
        if ($chkAny && ($row = $chkAny->fetch_assoc())) {
            $defaultId = (int)$row['id'];
            $conn->query("UPDATE warehouses SET is_default = 1 WHERE id = $defaultId");
        } else {
            $conn->query("INSERT INTO warehouses (code, name, address, is_default, is_active, sort_order) VALUES ('MAIN', 'کۆگەی سەرەکی', '', 1, 1, 0)");
            $defaultId = (int)$conn->insert_id;
        }
    }

    if (pos_db_get_setting_value($conn, 'multi_warehouse_backfill_v1') !== '1') {
        $res = $conn->query("SELECT id, qty, minStock, trackStock FROM products WHERE trackStock = 1 OR trackStock IS NULL");
        if ($res) {
            $ins = $conn->prepare("INSERT INTO warehouse_stock (warehouse_id, product_id, qty, min_stock) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE qty = VALUES(qty), min_stock = VALUES(min_stock)");
            if ($ins) {
                while ($p = $res->fetch_assoc()) {
                    $pid = (int)$p['id'];
                    $qty = round((float)($p['qty'] ?? 0), 3);
                    $min = (int)($p['minStock'] ?? 5);
                    $ins->bind_param('iidi', $defaultId, $pid, $qty, $min);
                    $ins->execute();
                }
            }
        }
        pos_db_set_setting_value($conn, 'multi_warehouse_backfill_v1', '1');
        pos_db_set_setting_value($conn, 'default_warehouse_id', (string)$defaultId);
    }

    if (pos_db_get_setting_value($conn, 'stock_transfer_seq_backfill_v1') !== '1') {
        @$conn->query("UPDATE stock_transfers SET transaction_id = LPAD(id, 6, '0') WHERE transaction_id LIKE 'TXF%' OR transaction_id = '' OR transaction_id = '0'");
        pos_db_set_setting_value($conn, 'stock_transfer_seq_backfill_v1', '1');
    }

    if (pos_db_get_setting_value($conn, 'sales_warehouse_id_backfill_v1') !== '1') {
        @$conn->query("UPDATE sales s
            INNER JOIN (
                SELECT reference_id, MIN(warehouse_id) AS wid
                FROM stock_movements
                WHERE reference_type = 'sale' AND warehouse_id > 0
                GROUP BY reference_id
            ) m ON m.reference_id = s.id
            SET s.warehouse_id = m.wid
            WHERE COALESCE(s.warehouse_id, 0) = 0");
        pos_db_set_setting_value($conn, 'sales_warehouse_id_backfill_v1', '1');
    }
}

function pos_backfill_expenses_company_id($conn) {
    try {
        @$conn->query("
            UPDATE expenses e
            INNER JOIN ledger l ON l.transaction_id = e.transaction_id AND l.transaction_id <> ''
                AND l.type = 'payment' AND l.companyId > 0
            SET e.company_id = l.companyId
            WHERE e.type = 'debt_payment' AND (e.company_id IS NULL OR e.company_id = 0)
        ");
    } catch (Throwable $e) {}
}

/** Reclassify + link company name from note for payments recorded before debt_payment type existed. */
function pos_reclassify_legacy_company_debt_expenses($conn) {
    try {
        @$conn->query("
            UPDATE expenses
            SET type = 'debt_payment'
            WHERE (type IS NULL OR type = '' OR type = 'operational')
            AND (
                note LIKE '%دانەڤا قەرزی%'
                OR note LIKE '%Company Payment%'
                OR note LIKE '%تسديد دين%'
            )
        ");
    } catch (Throwable $e) {}
}

function pos_backfill_expenses_company_id_from_note($conn) {
    $res = @$conn->query("SELECT e.id, e.note FROM expenses e WHERE e.type = 'debt_payment' AND (e.company_id IS NULL OR e.company_id = 0) AND e.note IS NOT NULL AND e.note <> ''");
    if (!$res) {
        return;
    }
    $compRes = @$conn->query('SELECT id, name FROM companies WHERE name IS NOT NULL AND name <> \'\'');
    $companies = [];
    if ($compRes) {
        while ($c = $compRes->fetch_assoc()) {
            $companies[] = ['id' => (int)$c['id'], 'name' => trim((string)$c['name'])];
        }
    }
    if (!$companies) {
        return;
    }
    $upd = $conn->prepare('UPDATE expenses SET company_id = ? WHERE id = ? LIMIT 1');
    if (!$upd) {
        return;
    }
    while ($row = $res->fetch_assoc()) {
        $note = (string)($row['note'] ?? '');
        $name = '';
        if (preg_match('/دانەڤا قەرزی کۆمپانیا:\s*([^|]+)/u', $note, $m)) {
            $name = trim($m[1]);
        } elseif (preg_match('/دانەڤا قەرزی\s*\([^)]*\)\s*:\s*([^|]+)/u', $note, $m)) {
            $name = trim($m[1]);
        } elseif (preg_match('/Company Payment[^:]*:\s*([^|]+)/i', $note, $m)) {
            $name = trim($m[1]);
        }
        if ($name === '') {
            continue;
        }
        $cid = 0;
        foreach ($companies as $c) {
            if ($c['name'] === $name) {
                $cid = $c['id'];
                break;
            }
        }
        if ($cid <= 0) {
            continue;
        }
        $eid = (int)$row['id'];
        $upd->bind_param('ii', $cid, $eid);
        @$upd->execute();
    }
}

/**
 * Idempotent: repair historical company debt payments for daily summary / cash drawer.
 * Runs on every DB connect (not only schema_version bump).
 */
/**
 * One-time: build stock_batches from legacy supplies / products.expiry (safe on updates).
 */
function pos_backfill_stock_batches_from_history($conn) {
    if (pos_db_get_setting_value($conn, 'stock_batches_backfill_v1') === '1') {
        return;
    }
    try {
        $conn->query("SELECT 1 FROM stock_batches LIMIT 1");
    } catch (Throwable $e) {
        return;
    }
    $ins = $conn->prepare("INSERT INTO stock_batches (product_id, expiry_date, qty, unit_cost, source_type, source_id, transaction_id) VALUES (?, ?, ?, ?, 'backfill', 0, ?)");
    if (!$ins) {
        return;
    }
    $chk = $conn->prepare("SELECT id, qty FROM stock_batches WHERE product_id = ? AND expiry_date = ? LIMIT 1");
    $resS = @$conn->query("SELECT prodId, expiry_date, SUM(qtyAdded) AS sq, SUM(totalCost) AS tc FROM supplies WHERE expiry_date IS NOT NULL AND expiry_date != '' AND (type IS NULL OR type != 'return') GROUP BY prodId, expiry_date");
    if ($resS) {
        while ($row = $resS->fetch_assoc()) {
            $pid = (int)($row['prodId'] ?? 0);
            $exp = trim((string)($row['expiry_date'] ?? ''));
            $sq = (float)($row['sq'] ?? 0);
            if ($pid <= 0 || $sq <= 0 || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $exp)) {
                continue;
            }
            $exists = false;
            if ($chk) {
                $chk->bind_param('is', $pid, $exp);
                $chk->execute();
                $rchk = $chk->get_result();
                if ($rchk && $rchk->fetch_assoc()) {
                    $exists = true;
                }
            }
            if ($exists) {
                continue;
            }
            $tc = (float)($row['tc'] ?? 0);
            $uc = $sq > 0 ? round($tc / $sq, 2) : 0;
            $txn = 'BFS-' . $pid . '-' . str_replace('-', '', $exp);
            $ins->bind_param('isdds', $pid, $exp, $sq, $uc, $txn);
            @$ins->execute();
        }
    }
    $resP = @$conn->query("SELECT id, qty, cost, expiry FROM products WHERE (trackStock IS NULL OR trackStock = 1) AND qty > 0 AND expiry IS NOT NULL AND expiry != '' AND expiry NOT LIKE '0000%' AND id NOT IN (SELECT DISTINCT product_id FROM stock_batches)");
    if ($resP && $ins) {
        while ($row = $resP->fetch_assoc()) {
            $pid = (int)($row['id'] ?? 0);
            $exp = trim((string)($row['expiry'] ?? ''));
            $sq = (float)($row['qty'] ?? 0);
            if ($pid <= 0 || $sq <= 0 || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $exp)) {
                continue;
            }
            $uc = (float)($row['cost'] ?? 0);
            $txn = 'BFP-' . $pid;
            $ins->bind_param('isdds', $pid, $exp, $sq, $uc, $txn);
            @$ins->execute();
        }
    }
    pos_db_set_setting_value($conn, 'stock_batches_backfill_v1', '1');
}

function pos_ensure_stock_batch_history($conn) {
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    try {
        pos_backfill_stock_batches_from_history($conn);
    } catch (Throwable $e) {
        pos_migrations_log('stock_batches_backfill: ' . $e->getMessage());
    }
}

function pos_ensure_stocktake_history_schema($conn) {
    if (!$conn instanceof mysqli) return;
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        $conn->query("CREATE TABLE IF NOT EXISTS stocktake_sessions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            period VARCHAR(20) NOT NULL DEFAULT 'spot',
            warehouse_id INT NOT NULL DEFAULT 1,
            date DATETIME NOT NULL,
            user VARCHAR(100) DEFAULT '',
            note VARCHAR(255) DEFAULT '',
            items_changed INT NOT NULL DEFAULT 0,
            items_short INT NOT NULL DEFAULT 0,
            items_surplus INT NOT NULL DEFAULT 0,
            items_ok INT NOT NULL DEFAULT 0,
            short_qty DECIMAL(14,3) NOT NULL DEFAULT 0,
            surplus_qty DECIMAL(14,3) NOT NULL DEFAULT 0,
            short_value DECIMAL(14,2) NOT NULL DEFAULT 0,
            surplus_value DECIMAL(14,2) NOT NULL DEFAULT 0,
            net_value DECIMAL(14,2) NOT NULL DEFAULT 0,
            INDEX idx_st_sess_date (date)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $conn->query("CREATE TABLE IF NOT EXISTS stocktake_lines (
            id INT AUTO_INCREMENT PRIMARY KEY,
            session_id INT NOT NULL,
            product_id INT NOT NULL,
            product_name VARCHAR(255) DEFAULT '',
            system_qty DECIMAL(14,3) NOT NULL DEFAULT 0,
            actual_qty DECIMAL(14,3) NOT NULL DEFAULT 0,
            variance DECIMAL(14,3) NOT NULL DEFAULT 0,
            unit_cost DECIMAL(12,2) NOT NULL DEFAULT 0,
            value DECIMAL(14,2) NOT NULL DEFAULT 0,
            INDEX idx_st_line_sess (session_id),
            INDEX idx_st_line_prod (product_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) {
        pos_migrations_log('stocktake_history_schema: ' . $e->getMessage());
    }
}

function pos_cleanup_purchase_linked_debt_payment_duplicates($conn) {
    try {
        @$conn->query("DELETE e FROM expenses e
            INNER JOIN expenses p ON p.type = 'purchase' AND p.transaction_id IS NOT NULL AND p.transaction_id <> '' AND p.transaction_id = e.transaction_id
            WHERE e.type = 'debt_payment'");
        @$conn->query("DELETE FROM expenses WHERE type = 'debt_payment' AND (
            note LIKE '%پێشەکی بۆ وەسڵ%' OR note LIKE '%split payment%' OR note LIKE '%کڕین (نەقد)%'
        )");
    } catch (Throwable $e) {
        pos_migrations_log('cleanup_purchase_linked_debt: ' . $e->getMessage());
    }
}

function pos_ensure_company_debt_history($conn) {
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    try {
        checkAndAddCol($conn, 'expenses', 'company_id', 'INT NULL DEFAULT NULL');
    } catch (Throwable $e) {}

    // One-shot backfill — never re-scan full ledger on every login / schema ensure
    $flag = null;
    try {
        if (function_exists('pos_db_get_setting_value')) {
            $flag = pos_db_get_setting_value($conn, 'pos_company_debt_history_v1');
        }
    } catch (Throwable $e) {}
    if ($flag === '1' || $flag === 1 || $flag === true) {
        return;
    }

    try {
        pos_reclassify_legacy_company_debt_expenses($conn);
        pos_cleanup_purchase_linked_debt_payment_duplicates($conn);
        pos_backfill_company_debt_payment_expenses($conn);
        pos_backfill_expenses_company_id($conn);
        pos_backfill_expenses_company_id_from_note($conn);
        if (function_exists('pos_db_set_setting_value')) {
            pos_db_set_setting_value($conn, 'pos_company_debt_history_v1', '1');
        }
    } catch (Throwable $e) {
        pos_migrations_log('company_debt_history: ' . $e->getMessage());
    }
}

function pos_backfill_company_debt_payment_expenses($conn) {
    $res = @$conn->query("SELECT l.companyId, l.amount, l.`date`, l.note, l.transaction_id FROM ledger l WHERE l.type = 'payment' AND l.companyId IS NOT NULL AND l.companyId > 0 AND l.amount > 0");
    if (!$res) {
        return;
    }
    $ins = $conn->prepare("INSERT INTO expenses (note, amount, `date`, user, type, transaction_id, company_id) VALUES (?, ?, ?, ?, 'debt_payment', ?, ?)");
    if (!$ins) {
        return;
    }
    $chk = $conn->prepare("SELECT id FROM expenses WHERE type = 'debt_payment' AND transaction_id = ? AND transaction_id <> '' LIMIT 1");
    $chkPurchase = $conn->prepare("SELECT id FROM expenses WHERE type = 'purchase' AND transaction_id = ? AND transaction_id <> '' LIMIT 1");
    $nameSt = $conn->prepare("SELECT name FROM companies WHERE id = ? LIMIT 1");
    while ($row = $res->fetch_assoc()) {
        $txn = trim((string)($row['transaction_id'] ?? ''));
        $cid = (int)($row['companyId'] ?? 0);
        $amount = round((float)($row['amount'] ?? 0), 2);
        if ($amount <= 0 || $cid <= 0) {
            continue;
        }
        $ledNote = trim((string)($row['note'] ?? ''));
        if ($ledNote !== '' && preg_match('/پێشەکی بۆ وەسڵ|split payment|کڕین \(نەقد\)|Bulk Invoice|وەسڵ #/ui', $ledNote)) {
            continue;
        }
        if ($txn !== '' && $chkPurchase) {
            $chkPurchase->bind_param('s', $txn);
            $chkPurchase->execute();
            if ($chkPurchase->get_result()->fetch_assoc()) {
                continue;
            }
        }
        if ($txn !== '' && $chk) {
            $chk->bind_param('s', $txn);
            $chk->execute();
            if ($chk->get_result()->fetch_assoc()) {
                continue;
            }
        }
        static $chkAmt = null;
        if ($chkAmt === null) {
            $chkAmt = @$conn->prepare("SELECT id FROM expenses WHERE type = 'debt_payment' AND company_id = ? AND ABS(amount - ?) < 0.02 AND DATE(`date`) = DATE(?) LIMIT 1");
        }
        $dateForChk = !empty($row['date']) ? (string)$row['date'] : date('Y-m-d H:i:s');
        if ($chkAmt) {
            $chkAmt->bind_param('ids', $cid, $amount, $dateForChk);
            $chkAmt->execute();
            if ($chkAmt->get_result()->fetch_assoc()) {
                continue;
            }
        }
        $compName = '';
        if ($nameSt && $cid > 0) {
            $nameSt->bind_param('i', $cid);
            $nameSt->execute();
            $nr = $nameSt->get_result()->fetch_assoc();
            if ($nr && !empty($nr['name'])) {
                $compName = trim((string)$nr['name']);
            }
        }
        $expNote = 'دانەڤا قەرزی کۆمپانیا: ' . ($compName !== '' ? $compName : ('#' . $cid));
        $ledNote = trim((string)($row['note'] ?? ''));
        if ($ledNote !== '') {
            $expNote .= ' | ' . $ledNote;
        }
        $date = !empty($row['date']) ? (string)$row['date'] : date('Y-m-d H:i:s');
        $user = 'System';
        $txnIns = $txn !== '' ? $txn : ('TXL_BF_' . $cid . '_' . strtotime($date));
        $ins->bind_param('sdsssi', $expNote, $amount, $date, $user, $txnIns, $cid);
        @$ins->execute();
    }
}

/**
 * Run migrations once per schema version (guarded by MySQL lock).
 * This prevents request-time ALTER TABLE churn under concurrent traffic.
 */
function pos_run_migrations_if_needed($conn) {
    static $did = false;
    if ($did) return;
    $did = true;

    $start = microtime(true);
    $lockName = 'pos_migrate_v1';

    // Fast path: schema already current — do NOT wait on GET_LOCK (was up to 10s and
    // made get_sales_history hang on «داتا دهێتە بارکرن»). Ensure/heal at most every 30 min.
    $cur = 0;
    $target = (int)POS_SCHEMA_VERSION;
    try {
        $curRaw = pos_db_get_setting_value($conn, 'schema_version');
        $cur = $curRaw === null ? 0 : (int)$curRaw;
    } catch (Throwable $e) {
        $cur = 0;
    }
    if ($cur >= $target) {
        $needsFxHeal = function_exists('pos_fx_schema_needs_heal') && pos_fx_schema_needs_heal($conn);
        $ensureTs = 0;
        try {
            $ensureTs = (int)(pos_db_get_setting_value($conn, 'pos_schema_ensure_ts') ?: 0);
        } catch (Throwable $e2) {}
        // Old backup restore can leave schema_version current while FX columns are missing.
        if (!$needsFxHeal && $ensureTs > 0 && (time() - $ensureTs) < 1800) {
            return;
        }
        // Non-blocking lock — if another request is busy, skip (safe; schema already OK)
        $locked = pos_db_try_get_lock($conn, $lockName, 0);
        if (!$locked) {
            return;
        }
        try {
            pos_ensure_debt_columns_wide($conn);
            pos_ensure_payment_due_schema($conn);
            pos_ensure_product_catalog_columns($conn);
            pos_ensure_expenses_archive_columns($conn);
            if (function_exists('pos_ensure_txn_fx_columns')) {
                pos_ensure_txn_fx_columns($conn);
            }
            if (function_exists('pos_ensure_fx_engine_schema')) {
                pos_ensure_fx_engine_schema($conn);
            }
            if (!empty($needsFxHeal) && function_exists('pos_heal_currency_schema')) {
                pos_heal_currency_schema($conn);
            } elseif (function_exists('pos_repair_restored_catalog_prices') && pos_db_get_setting_value($conn, 'restored_catalog_price_repair_v33') !== '1') {
                pos_repair_restored_catalog_prices($conn);
            }
            pos_ensure_manufacturers_schema($conn);
            pos_ensure_drivers_schema($conn);
            // Column only — heavy debt backfill is one-shot inside pos_ensure_company_debt_history
            pos_ensure_company_debt_history($conn);
            pos_ensure_stock_batch_history($conn);
            pos_ensure_multi_warehouse_schema($conn);
            pos_ensure_sale_followup_schema($conn);
            if (function_exists('pos_ensure_sales_checkout_columns')) {
                pos_ensure_sales_checkout_columns($conn);
            }
            if (function_exists('pos_ensure_hot_search_indexes')) {
                pos_ensure_hot_search_indexes($conn);
            }
            pos_db_set_setting_value($conn, 'pos_schema_ensure_ts', (string)time());
        } catch (Throwable $e3) {
            pos_migrations_log('ensure_error: ' . $e3->getMessage());
        } finally {
            pos_db_release_lock($conn, $lockName);
        }
        return;
    }

    // Schema behind: migrate (non-blocking lock — never stall cashiers for 10s)
    $locked = pos_db_try_get_lock($conn, $lockName, 0);
    if (!$locked) {
        pos_migrations_log('skip (lock busy)');
        return;
    }
    try {
        pos_ensure_debt_columns_wide($conn);
        pos_ensure_payment_due_schema($conn);
        pos_ensure_product_catalog_columns($conn);
        pos_ensure_expenses_archive_columns($conn);
        if (function_exists('pos_ensure_txn_fx_columns')) {
            pos_ensure_txn_fx_columns($conn);
        }
        if (function_exists('pos_ensure_fx_engine_schema')) {
            pos_ensure_fx_engine_schema($conn);
        }
        if (function_exists('pos_repair_restored_catalog_prices') && pos_db_get_setting_value($conn, 'restored_catalog_price_repair_v33') !== '1') {
            pos_repair_restored_catalog_prices($conn);
        }
        pos_ensure_manufacturers_schema($conn);
        pos_ensure_drivers_schema($conn);
        pos_ensure_company_debt_history($conn);
        pos_ensure_stock_batch_history($conn);
        pos_ensure_stocktake_history_schema($conn);
        pos_ensure_multi_warehouse_schema($conn);
        pos_ensure_sale_followup_schema($conn);
        if (function_exists('pos_ensure_hot_search_indexes')) {
            pos_ensure_hot_search_indexes($conn);
        }
        if (!function_exists('pos_heal_single_warehouse_stock_bulk')) {
            $auditHelper = __DIR__ . '/../api/all-helpers-audit.php';
            if (is_file($auditHelper)) {
                require_once $auditHelper;
            }
        }
        if (function_exists('pos_heal_single_warehouse_stock_bulk')) {
            pos_heal_single_warehouse_stock_bulk($conn);
        }
        try {
            $conn->query("CREATE TABLE IF NOT EXISTS settings (setting_key VARCHAR(50) PRIMARY KEY, setting_value LONGTEXT)");
        } catch (Throwable $e) {}

        $curRaw = pos_db_get_setting_value($conn, 'schema_version');
        $cur = $curRaw === null ? 0 : (int)$curRaw;
        if ($cur >= $target) {
            pos_db_set_setting_value($conn, 'pos_schema_ensure_ts', (string)time());
            $moneyHelper = __DIR__ . '/../api/all-helpers-money.php';
            if (!function_exists('pos_ensure_old_debt_repair_v2') && is_file($moneyHelper)) {
                require_once $moneyHelper;
            }
            if (function_exists('pos_ensure_old_debt_repair_v2')) {
                pos_ensure_old_debt_repair_v2($conn);
            }
            return;
        }

        pos_migrations_log("start cur=$cur target=$target");
        pos_run_migrations_body($conn);
        pos_db_set_setting_value($conn, 'schema_version', (string)$target);
        pos_db_set_setting_value($conn, 'pos_schema_ensure_ts', (string)time());
        $ms = (int)round((microtime(true) - $start) * 1000);
        pos_migrations_log("done cur=$cur target=$target ms=$ms");
        if (function_exists('pos_ensure_old_debt_repair_v2')) {
            pos_ensure_old_debt_repair_v2($conn);
        }
    } catch (Throwable $e) {
        pos_migrations_log('error: ' . $e->getMessage());
    } finally {
        pos_db_release_lock($conn, $lockName);
    }
}

// Auto-run when loaded after DB connect (e.g. from config/database.php).
if (defined('POS_RUN_MIGRATIONS') && POS_RUN_MIGRATIONS === true && isset($conn) && $conn instanceof mysqli) {
    pos_run_migrations_if_needed($conn);
}
