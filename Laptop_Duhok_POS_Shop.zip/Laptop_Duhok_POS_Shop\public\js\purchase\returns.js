// purchase/returns.js — purchase returns
        // --- PURCHASE RETURNS SCREEN (زڤراندنا کەرەستان بۆ کۆمپانیێ) ---
        var purchaseReturnCart = [];
        var purchaseReturnSelectedUnit = 'piece';
        var purchaseReturnGridTimeout = null;

        function setPurchaseReturnUnit(unit) {
            purchaseReturnSelectedUnit = unit || 'piece';
            ['carton', 'pack', 'piece'].forEach(function(u) {
                var btn = document.getElementById('btn-purchase-returns-unit-' + u);
                if (btn) { btn.classList.toggle('active', u === purchaseReturnSelectedUnit); btn.setAttribute('aria-pressed', u === purchaseReturnSelectedUnit ? 'true' : 'false'); }
            });
            debouncedRenderPurchaseReturnsProductGrid();
        }
        function onPurchaseReturnSupplierChange() {
            debouncedRenderPurchaseReturnsProductGrid();
            renderPurchaseReturnCart();
            var sel = document.getElementById('purchase-returns-supplier-select');
            if (sel && sel.value && typeof window.maybeCollapseTxnMetaAfterValid === 'function') {
                window.maybeCollapseTxnMetaAfterValid('purchase-returns', ['purchase-returns-supplier-select', 'purchase-return-supplier-invoice-ref']);
            }
            if (typeof window.updateTxnPeekBar === 'function') window.updateTxnPeekBar('purchase-returns');
            var afterSupplies = function () {
                debouncedRenderPurchaseReturnsProductGrid();
                renderPurchaseReturnCart();
            };
            if (typeof window.posEnsureSuppliesPoolLoaded === 'function') {
                window.posEnsureSuppliesPoolLoaded().then(afterSupplies).catch(afterSupplies);
            } else if (typeof connectToDB === 'function') {
                connectToDB(true).then(afterSupplies).catch(afterSupplies);
            }
        }
        function debouncedRenderPurchaseReturnsProductGrid() {
            if (purchaseReturnGridTimeout) clearTimeout(purchaseReturnGridTimeout);
            var _gMs = (typeof posTxnGridDebounceMs === 'function') ? posTxnGridDebounceMs() : 120;
            purchaseReturnGridTimeout = setTimeout(renderPurchaseReturnsProductGrid, _gMs);
        }
        function getPurchaseReturnSuppliesList() {
            if (typeof window.posGetSuppliesPool === 'function') return window.posGetSuppliesPool();
            return (db && db.supplies) ? db.supplies : [];
        }

        function buildPurchaseReturnPurchasedItemsMap(supplierName, invRefTrimmed) {
            var purchasedItems = {};
            var invRef = invRefTrimmed != null ? String(invRefTrimmed).trim() : '';
            if (!supplierName) return purchasedItems;
            var seen = {};
            var suppliesList = getPurchaseReturnSuppliesList();
            suppliesList.forEach(function(s) {
                if (!supplyMatchesPurchaseReturnCompany(s, supplierName) || !s.prodId) return;
                if (s.type === 'opening') return;
                if (invRef && !supplyMatchesPurchaseReturnInvoiceRef(s, invRef)) return;
                var fp = typeof window.posSupplyFingerprint === 'function' ? window.posSupplyFingerprint(s) : String(s.id);
                if (fp && seen[fp]) return;
                if (fp) seen[fp] = 1;
                var pidKey = String(s.prodId);
                if (!purchasedItems[pidKey]) {
                    purchasedItems[pidKey] = { qty: 0, costSum: 0, costQty: 0, lastCost: 0, returnedCost: 0 };
                }
                var qtyAdded = parseFloat(s.qtyAdded) || 0;
                purchasedItems[pidKey].qty += qtyAdded;
                if (qtyAdded > 0 && s.type !== 'return') {
                    purchasedItems[pidKey].costSum += parseFloat(s.totalCost) || 0;
                    purchasedItems[pidKey].costQty += qtyAdded;
                } else if (s.type === 'return' || qtyAdded < 0) {
                    purchasedItems[pidKey].returnedCost = (purchasedItems[pidKey].returnedCost || 0) + Math.abs(parseFloat(s.totalCost) || 0);
                }
            });
            Object.keys(purchasedItems).forEach(function (k) {
                var row = purchasedItems[k];
                var avail = Math.max(0, parseFloat(row.qty) || 0);
                var costLeft = Math.max(0, (parseFloat(row.costSum) || 0) - (parseFloat(row.returnedCost) || 0));
                row.lastCost = avail > 0 ? (costLeft / avail) : (row.costQty > 0 ? row.costSum / row.costQty : 0);
            });
            return purchasedItems;
        }
        function purchaseReturnRowPieces(row) {
            if (!row) return 0;
            var p = row.productRef || (db.products || []).find(function (x) { return String(x.id) === String(row.productId); });
            var mult = typeof getPiecesMultiplierForUnit === 'function'
                ? getPiecesMultiplierForUnit(p, row.unit || 'piece')
                : 1;
            return (parseFloat(row.qty) || 0) * (mult || 1);
        }
        function allocPurchaseReturnLinesGross(rows) {
            var roundM = typeof roundMoney === 'function' ? roundMoney : function (x) { return Math.round(Number(x)); };
            var ctx = getPurchaseReturnSupplierContext();
            var map = buildPurchaseReturnPurchasedItemsMap(ctx.supplierName, getPurchaseReturnInvoiceRef());
            var alloc = {};
            return (rows || []).map(function (row) {
                var discount = Math.max(0, parseFloat(row.discount) || 0);
                var gross = 0;
                var pData = map[String(row.productId)];
                if (pData) {
                    var pid = String(row.productId);
                    if (!alloc[pid]) alloc[pid] = { pieces: 0, cost: 0 };
                    var avail = Math.max(0, (parseFloat(pData.qty) || 0) - alloc[pid].pieces);
                    var costLeft = roundM(Math.max(0, (pData.costSum || 0) - (pData.returnedCost || 0) - alloc[pid].cost));
                    var take = purchaseReturnRowPieces(row);
                    if (take > avail + 0.0001) take = Math.max(0, avail);
                    if (take <= 0) gross = 0;
                    else if (take + 0.0001 >= avail) gross = costLeft;
                    else if (avail > 0) gross = roundM(costLeft * take / avail);
                    alloc[pid].pieces += take;
                    alloc[pid].cost = roundM(alloc[pid].cost + gross);
                } else {
                    gross = roundM(Math.max(0, (row.qty || 0) * (row.costPerUnit || 0)));
                }
                return { gross: gross, net: roundM(Math.max(0, gross - discount)), discount: discount };
            });
        }
        function purchaseReturnLineTotal(row) {
            var cart = purchaseReturnCart || [];
            var idx = -1;
            for (var i = 0; i < cart.length; i++) {
                if (cart[i] === row) { idx = i; break; }
            }
            var lines = allocPurchaseReturnLinesGross(idx >= 0 ? cart : [row]);
            if (idx >= 0) return lines[idx] ? lines[idx].net : 0;
            return lines[0] ? lines[0].net : 0;
        }
        function getPurchaseReturnInvoiceOriginalTotal(companyName, invoiceRef) {
            var roundM = typeof roundMoney === 'function' ? roundMoney : function (x) { return Math.round(Number(x)); };
            if (!companyName || !invoiceRef) return 0;
            var seen = {};
            var total = 0;
            getPurchaseReturnSuppliesList().forEach(function (s) {
                if (!supplyMatchesPurchaseReturnCompany(s, companyName)) return;
                if (!supplyMatchesPurchaseReturnInvoiceRef(s, invoiceRef)) return;
                if (s.type === 'opening' || s.type === 'return') return;
                if ((parseFloat(s.qtyAdded) || 0) <= 0) return;
                var fp = typeof window.posSupplyFingerprint === 'function' ? window.posSupplyFingerprint(s) : String(s.id);
                if (fp && seen[fp]) return;
                if (fp) seen[fp] = 1;
                total += parseFloat(s.totalCost) || 0;
            });
            return roundM(total);
        }
        function getPurchaseReturnCartGrandTotal() {
            var roundM = typeof roundMoney === 'function' ? roundMoney : function (x) { return Math.round(Number(x)); };
            return purchaseReturnCart.reduce(function (sum, row) {
                return roundM(sum + purchaseReturnLineTotal(row));
            }, 0);
        }
        function resolvePurchaseReturnCartUnit(p, preferredUnit, availablePieces, piecesAlreadyInCart) {
            var left = Math.max(0, (parseFloat(availablePieces) || 0) - (parseFloat(piecesAlreadyInCart) || 0));
            if (left <= 0) return preferredUnit || 'piece';
            var order = [];
            var pref = preferredUnit || 'piece';
            if (pref === 'carton' || pref === 'pack' || pref === 'piece') order.push(pref);
            ['piece', 'pack', 'carton'].forEach(function (u) {
                if (order.indexOf(u) < 0) order.push(u);
            });
            for (var i = 0; i < order.length; i++) {
                var mult = typeof getPiecesMultiplierForUnit === 'function'
                    ? getPiecesMultiplierForUnit(p, order[i])
                    : 1;
                if (mult <= left + 0.0001) return order[i];
            }
            return 'piece';
        }
        function getPurchaseReturnInvoiceRef() {
            var refInput = document.getElementById('purchase-return-supplier-invoice-ref');
            return (refInput && refInput.value) ? String(refInput.value).trim() : '';
        }
        function getPurchaseReturnSupplierContext() {
            var sel = document.getElementById('purchase-returns-supplier-select');
            var supplierId = sel && sel.value ? parseInt(sel.value, 10) : null;
            var comp = supplierId ? (db.companies || []).find(function(c) { return c.id === supplierId; }) : null;
            return { comp: comp, supplierName: comp ? comp.name : '' };
        }
        function getPurchaseReturnAvailablePieces(pid, supplierName, invoiceRef) {
            supplierName = supplierName || getPurchaseReturnSupplierContext().supplierName;
            invoiceRef = invoiceRef != null ? invoiceRef : getPurchaseReturnInvoiceRef();
            if (!supplierName || !invoiceRef) return 0;
            var map = buildPurchaseReturnPurchasedItemsMap(supplierName, invoiceRef);
            var entry = map[String(pid)];
            return entry ? Math.max(0, parseFloat(entry.qty) || 0) : 0;
        }
        function getPurchaseReturnCostForUnit(pid, unit, supplierName, invoiceRef) {
            var roundM = typeof roundMoney === 'function' ? roundMoney : function (x) { return Math.round(Number(x)); };
            var p = (db.products || []).find(function(x) { return String(x.id) === String(pid); });
            if (!p) return 0;
            supplierName = supplierName || getPurchaseReturnSupplierContext().supplierName;
            invoiceRef = invoiceRef != null ? invoiceRef : getPurchaseReturnInvoiceRef();
            var map = buildPurchaseReturnPurchasedItemsMap(supplierName, invoiceRef);
            var pData = map[String(pid)];
            if (pData && ((parseFloat(pData.qty) || 0) > 0)) {
                var mult = typeof getPiecesMultiplierForUnit === 'function'
                    ? getPiecesMultiplierForUnit(p, unit || 'piece')
                    : 1;
                var avail = Math.max(0, parseFloat(pData.qty) || 0);
                var costLeft = Math.max(0, (pData.costSum || 0) - (pData.returnedCost || 0));
                return roundM(avail > 0 ? (costLeft * mult / avail) : 0);
            }
            var basePieceCost = (pData && pData.lastCost > 0) ? pData.lastCost : (parseFloat(p.cost) || 0);
            var multFallback = typeof getPiecesMultiplierForUnit === 'function'
                ? getPiecesMultiplierForUnit(p, unit || 'piece')
                : 1;
            return roundM(basePieceCost * multFallback);
        }
        function getPurchaseReturnMaxQtyInUnit(pid, unit, supplierName, invoiceRef) {
            var p = (db.products || []).find(function(x) { return String(x.id) === String(pid); });
            var pieces = getPurchaseReturnAvailablePieces(pid, supplierName, invoiceRef);
            if (!p || pieces <= 0) return 0;
            var mult = typeof getPiecesMultiplierForUnit === 'function'
                ? getPiecesMultiplierForUnit(p, unit || 'piece')
                : 1;
            if (!mult || mult <= 0) mult = 1;
            return pieces / mult;
        }
        window.getPurchaseReturnMaxQtyForCartRow = function(idx) {
            var row = purchaseReturnCart[idx];
            if (!row) return 0;
            var ctx = getPurchaseReturnSupplierContext();
            var maxUnit = getPurchaseReturnMaxQtyInUnit(row.productId, row.unit || 'piece', ctx.supplierName, getPurchaseReturnInvoiceRef());
            var piecesInCartOthers = 0;
            purchaseReturnCart.forEach(function(r, i) {
                if (i === idx || String(r.productId) !== String(row.productId)) return;
                var rp = r.productRef || (db.products || []).find(function(x) { return String(x.id) === String(r.productId); });
                var rMult = typeof getPiecesMultiplierForUnit === 'function'
                    ? getPiecesMultiplierForUnit(rp, r.unit || 'piece')
                    : 1;
                piecesInCartOthers += (parseFloat(r.qty) || 0) * rMult;
            });
            var piecesLeft = Math.max(0, getPurchaseReturnAvailablePieces(row.productId, ctx.supplierName, getPurchaseReturnInvoiceRef()) - piecesInCartOthers);
            var rowMult = typeof getPiecesMultiplierForUnit === 'function'
                ? getPiecesMultiplierForUnit(row.productRef || row, row.unit || 'piece')
                : 1;
            if (!rowMult || rowMult <= 0) rowMult = 1;
            return Math.min(maxUnit, piecesLeft / rowMult);
        };
        function initPurchaseReturnsScreen() {
            var sel = document.getElementById('purchase-returns-supplier-select');
            if (!sel) return;
            
            // بەشێ ژمارا پسوولا کۆمپانیێ دئینیتە تەنیشت لیستا کۆمپانیان (50% ب 50%)
            var topRow = sel.closest('.purchase-top-supplier-row');
            var refWrap = document.querySelector('#view-purchase-returns .purchase-return-invoice-ref-wrap') || document.querySelector('.purchase-return-invoice-ref-wrap');
            if (topRow && refWrap && refWrap.parentNode !== topRow) {
                topRow.appendChild(refWrap);
                var suppWrap = sel.closest('.purchase-top-field');
                if (suppWrap) {
                    suppWrap.style.flex = "1 1 48%";
                }
                refWrap.style.flex = "1 1 48%";
                refWrap.classList.add('purchase-top-field');
                refWrap.style.margin = "0";
            }

            sel.innerHTML = '<option value="">-- کۆمپانیایەکێ هەلبژێرە --</option>';
            (db.companies || []).slice().sort(function(a,b){ return (a.name||'').localeCompare(b.name||''); }).forEach(function(c) {
                sel.innerHTML += '<option value="' + c.id + '">' + escapeHtml(c.name || '') + '</option>';
            });
            var pendingRet = window._pendingPurchaseReturnFromHistory;
            if (!pendingRet) {
                purchaseReturnCart = [];
                var refInput = document.getElementById('purchase-return-supplier-invoice-ref');
                if (refInput) { refInput.value = ''; refInput.classList.remove('input-error'); }
            }
            setPurchaseReturnUnit('piece');
            var bootPurchaseReturnUi = function () {
                if (window._pendingPurchaseReturnFromHistory && typeof applyPendingPurchaseReturnFromHistory === 'function') {
                    applyPendingPurchaseReturnFromHistory();
                } else {
                    renderPurchaseReturnsProductGrid();
                    renderPurchaseReturnCart();
                }
                var searchEl = document.getElementById('purchase-returns-search');
                if (searchEl && window.innerWidth > 768) setTimeout(function() { searchEl.focus(); }, 150);
            };
            if (typeof window.posEnsureFifoSupplyPoolLoaded === 'function') {
                window.posEnsureFifoSupplyPoolLoaded().then(bootPurchaseReturnUi);
            } else if (typeof window.posEnsureSuppliesPoolLoaded === 'function') {
                window.posEnsureSuppliesPoolLoaded().then(bootPurchaseReturnUi);
            } else {
                bootPurchaseReturnUi();
            }
        }
        function renderPurchaseReturnsProductGrid() {
            var grid = document.getElementById('purchase-returns-product-grid');
            var sel = document.getElementById('purchase-returns-supplier-select');
            var q = (document.getElementById('purchase-returns-search') && document.getElementById('purchase-returns-search').value) || '';
            
            var invRefInput = document.getElementById('purchase-return-supplier-invoice-ref');
            var invRef = (invRefInput && invRefInput.value) ? String(invRefInput.value).trim() : '';

            if (!grid) return;
            var supplierId = sel && sel.value ? parseInt(sel.value, 10) : null;
            var comp = supplierId ? (db.companies || []).find(function(c) { return c.id === supplierId; }) : null;
            var supplierName = comp ? comp.name : null;

            function paintPurchaseReturnProductGrid() {
            grid.innerHTML = '';
            
            if (!supplierName) {
                grid.innerHTML = '<div class="txn-grid-empty-state"><i class="fas fa-building"></i><span>هیڤییە کۆمپانیایەکێ هەلبژێرە بۆ دیتنا کەرەستەیان.</span></div>';
                return;
            }
            if (!invRef) {
                var invHint = (typeof t === 'function') ? t('purchase_return_invoice_required_hint') : 'ژمارا پسوولێ بنووسە بۆ دیتنا کەرەستەیان.';
                grid.innerHTML = '<div class="txn-grid-empty-state"><i class="fas fa-file-invoice"></i><span>' + escapeHtml(invHint) + '</span></div>';
                return;
            }

            var purchasedItems = buildPurchaseReturnPurchasedItemsMap(supplierName, invRef);

            var activeUnit = typeof purchaseReturnSelectedUnit !== 'undefined' ? purchaseReturnSelectedUnit : 'piece';

            var list = (db.products || []).filter(function(p) {
                var pData = purchasedItems[String(p.id)];
                if (!pData || pData.qty <= 0) return false;
                if (q.trim() && typeof window.productMatchesBarcodeOrNameSearch === 'function' && !window.productMatchesBarcodeOrNameSearch(p, q)) return false;
                return true;
            });
            
            var _prMax = (typeof posTxnGridProductLimit === 'function') ? posTxnGridProductLimit(q) : 50;
            if (list.length > _prMax) list = list.slice(0, _prMax);

            var countBadgePr = document.getElementById('purchase-returns-products-count');
            if (countBadgePr) countBadgePr.textContent = String(list.length);

            if (list.length === 0) {
                var hints = listPurchaseReturnInvoiceHints(supplierName);
                var hintHtml = hints.length
                    ? '<br><small style="opacity:.85;margin-top:8px;display:block;">پسوولە بەردەست: ' + hints.map(function (h) { return escapeHtml(h); }).join(' · ') + '</small>'
                    : '';
                grid.innerHTML = '<div class="txn-grid-empty-state pos-empty-products"><i class="fas fa-search"></i><span>چ ئایتمێک بۆ زڤڕاندن نەدۆزرایەوە' + hintHtml + '</span></div>';
                return;
            }
            var activeUnit = typeof purchaseReturnSelectedUnit !== 'undefined' ? purchaseReturnSelectedUnit : 'piece';
            var cardIconPr = activeUnit === 'carton' ? 'fa-box' : (activeUnit === 'pack' ? 'fa-boxes' : 'fa-cube');
            list.forEach(function(p) {
                var pData = purchasedItems[String(p.id)];
                var basePieceCost = pData.lastCost > 0 ? pData.lastCost : (parseFloat(p.cost) || 0);
                var displayUnit = (typeof productMatchesUnitFilter === 'function' && productMatchesUnitFilter(p, activeUnit, true))
                    ? activeUnit
                    : 'piece';
                var unitLabel = getProductUnitLabel(p, displayUnit);
                
                var f = typeof getProductUnitFactors === 'function' ? getProductUnitFactors(p) : { piecesPerPack: 1, piecesPerCarton: 1 };
                var mult = 1;
                if (displayUnit === 'carton') mult = f.piecesPerCarton;
                else if (displayUnit === 'pack') mult = f.piecesPerPack;
                
                var costActive = (pData.costQty > 0 && pData.costSum > 0)
                    ? (typeof roundMoney === 'function' ? roundMoney(pData.costSum * mult / pData.costQty) : Math.round(pData.costSum * mult / pData.costQty))
                    : (typeof roundMoney === 'function' ? roundMoney(pData.lastCost * mult) : Math.round(pData.lastCost * mult));
                var displayQty = pData.qty > 0 ? (pData.qty / mult).toFixed(2).replace(/\.00$/, '') : 0;
                
                var priceLine = unitLabel + ': ' + (costActive > 0 ? formatCurrency(costActive) : '-');
                var qtyLine = 'ژمارا کڕی: <b>' + displayQty + '</b> ' + unitLabel;

                var card = document.createElement('div');
                card.className = 'unified-product-card txn-product-card txn-product-card--purchase-return';
                card.style.height = 'auto';
                card.style.minHeight = '180px';
                var pid = p.id;
                card.setAttribute('data-product-id', String(pid));
                card.setAttribute('data-sale-unit', displayUnit);
                card.setAttribute('data-return-cost', String(costActive));
                card.innerHTML = '<div class="unified-card-header"><div class="unified-card-icon"><i class="fas ' + cardIconPr + '"></i></div><div class="unified-card-barcode">' + escapeHtml((p.barcode || '').substring(0, 12) || '---') + '</div></div>' +
                    '<div class="unified-card-name">' + escapeHtml(p.name || 'ئایتم') + '</div>' +
                    '<div class="unified-card-price">' + escapeHtml(priceLine) + '</div>' +
                    '<div class="txn-card-meta">' + qtyLine + '</div>' +
                    '<div class="unified-card-cta"><i class="fas fa-undo-alt"></i> ' + escapeHtml((typeof t === 'function') ? t('unified_card_cta_return') : 'کلیک بکە بۆ زڤڕاندن') + '</div>';
                grid.appendChild(card);
            });
            updatePurchaseReturnDebtSummary(getPurchaseReturnCartGrandTotal());
            }

            if (supplierName && invRef && getPurchaseReturnSuppliesList().length === 0 && typeof window.posEnsureFifoSupplyPoolLoaded === 'function') {
                grid.innerHTML = '<div class="txn-grid-empty-state"><i class="fas fa-spinner fa-spin"></i><span>بارکردنی پسوولە…</span></div>';
                window.posEnsureFifoSupplyPoolLoaded().then(paintPurchaseReturnProductGrid);
                return;
            }
            if (supplierName && invRef && getPurchaseReturnSuppliesList().length === 0 && typeof window.posEnsureSuppliesPoolLoaded === 'function') {
                grid.innerHTML = '<div class="txn-grid-empty-state"><i class="fas fa-spinner fa-spin"></i><span>بارکردنی پسوولە…</span></div>';
                window.posEnsureSuppliesPoolLoaded().then(paintPurchaseReturnProductGrid);
                return;
            }
            paintPurchaseReturnProductGrid();
        }
        function getPurchaseAvailablePieces(pid) {
            var ctx = getPurchaseReturnSupplierContext();
            return getPurchaseReturnAvailablePieces(pid, ctx.supplierName, getPurchaseReturnInvoiceRef());
        }

        function addToPurchaseReturnCart(pid, unitOverride, customCost) {
            if (!requirePurchaseReturnSupplierInvoiceRef()) return;
            var p = (db.products || []).find(function(x) { return String(x.id) === String(pid); });
            if (!p) return;
            var unit = (unitOverride === 'carton' || unitOverride === 'pack' || unitOverride === 'piece') ? unitOverride : (typeof purchaseReturnSelectedUnit !== 'undefined' ? purchaseReturnSelectedUnit : 'piece');
            var requestedUnit = unit;
            var ctx = getPurchaseReturnSupplierContext();

            var piecesInCart = 0;
            purchaseReturnCart.forEach(function(row) {
                if (String(row.productId) === String(pid)) {
                    var rMult = typeof getPiecesMultiplierForUnit === 'function'
                        ? getPiecesMultiplierForUnit(row.productRef || p, row.unit || 'piece')
                        : 1;
                    piecesInCart += (row.qty || 0) * rMult;
                }
            });

            // VALIDATION — scoped to selected supplier invoice only (supplies qty is in pieces)
            let availablePieces = getPurchaseReturnAvailablePieces(pid, ctx.supplierName, getPurchaseReturnInvoiceRef());
            unit = resolvePurchaseReturnCartUnit(p, unit, availablePieces, piecesInCart);

            var costPerUnit = getPurchaseReturnCostForUnit(pid, unit, ctx.supplierName, getPurchaseReturnInvoiceRef());
            if (customCost !== undefined && requestedUnit === unit) costPerUnit = customCost;
            if (typeof roundMoney === 'function') costPerUnit = roundMoney(costPerUnit);

            var piecesPerUnit = typeof getPiecesMultiplierForUnit === 'function'
                ? getPiecesMultiplierForUnit(p, unit)
                : 1;

            if (piecesInCart + piecesPerUnit > availablePieces + 0.0001) {
                if (typeof showToast === 'function') showToast('⚠️ نەشێی زێدەتر ژ بڕێ کڕی بزڤڕینی!', 'warning');
                return;
            }

            var existing = purchaseReturnCart.find(function(row) { return String(row.productId) === String(pid) && (row.unit || 'piece') === unit; });
            if (existing) {
                existing.qty = normalizeQtyForProduct(p, (existing.qty || 0) + 1);
            } else {
                purchaseReturnCart.push({ productId: p.id, productName: p.name || '', qty: 1, unit: unit, costPerUnit: costPerUnit, discount: 0, productRef: p });
            }
            schedulePurchaseReturnCartRender();
            if (typeof window.expandTxnSheet === 'function') window.expandTxnSheet('purchase-returns');
        }
        function updatePurchaseReturnCartLine(idx, field, value, rerender) {
            var row = purchaseReturnCart[idx];
            if (!row) return;
            if (typeof rerender === 'undefined') rerender = true;

            if (field === 'qty') {
                let newQty = normalizeQtyForProduct(row.productRef || null, value);
                if (newQty > (row.qty || 0)) {
                    var rp = row.productRef || (db.products || []).find(function(x) { return String(x.id) === String(row.productId); });
                    var piecesPerUnit = typeof getPiecesMultiplierForUnit === 'function'
                        ? getPiecesMultiplierForUnit(rp, row.unit || 'piece')
                        : 1;
                    var ctx = getPurchaseReturnSupplierContext();
                    let availablePieces = getPurchaseReturnAvailablePieces(row.productId, ctx.supplierName, getPurchaseReturnInvoiceRef());
                    let piecesInCartOthers = 0;
                    purchaseReturnCart.forEach(function(r, i) {
                        if (i !== idx && String(r.productId) === String(row.productId)) {
                            var rMult = typeof getPiecesMultiplierForUnit === 'function'
                                ? getPiecesMultiplierForUnit(r.productRef || r, r.unit || 'piece')
                                : 1;
                            piecesInCartOthers += (r.qty || 0) * rMult;
                        }
                    });

                    if (piecesInCartOthers + (newQty * piecesPerUnit) > availablePieces + 0.0001) {
                        var maxRow = typeof window.getPurchaseReturnMaxQtyForCartRow === 'function'
                            ? window.getPurchaseReturnMaxQtyForCartRow(idx)
                            : (availablePieces - piecesInCartOthers) / (piecesPerUnit || 1);
                        if (typeof showToast === 'function') {
                            showToast('⚠️ زۆرترین: ' + (typeof formatQtyForInput === 'function' ? formatQtyForInput(maxRow, row.productRef || row) : maxRow), 'warning');
                        }
                        newQty = normalizeQtyForProduct(row.productRef || null, maxRow);
                        if (rerender) schedulePurchaseReturnCartRender();
                        if (newQty <= (row.qty || 0)) return;
                    }
                }
                row.qty = newQty;
            }
            if (field === 'costPerUnit') return;
            if (field === 'discount') row.discount = typeof purchaseDisplayToIqd === 'function' ? purchaseDisplayToIqd(value) : Math.max(0, parseFloat(value) || 0);
            if (rerender) {
                schedulePurchaseReturnCartRender();
                return;
            }
            var roundM3 = typeof roundMoney === 'function' ? roundMoney : function(x){ return Math.round(Number(x)); };
            var grandTotal = 0;
            purchaseReturnCart.forEach(function(r) {
                grandTotal = roundM3(grandTotal + purchaseReturnLineTotal(r));
            });
            var totalEl = document.getElementById('purchase-returns-cart-total');
            if (totalEl) totalEl.innerText = purchaseReturnCart.length ? purchaseFormatMoneyWithSymbol(grandTotal) : '0';
            updatePurchaseReturnDebtSummary(grandTotal);
            var rowTotalEl = document.querySelector('[data-purchase-return-row-total="' + idx + '"]');
            if (rowTotalEl) {
                rowTotalEl.textContent = purchaseFormatMoneyWithSymbol(purchaseReturnLineTotal(row));
            }
        }
        function removeFromPurchaseReturnCart(idx) {
            purchaseReturnCart.splice(idx, 1);
            schedulePurchaseReturnCartRender();
        }
        function clearPurchaseReturnCart() {
            purchaseReturnCart = [];
            schedulePurchaseReturnCartRender();
        }
        function renderPurchaseReturnCart() {
            var tbody = document.getElementById('purchase-returns-cart-rows');
            var totalEl = document.getElementById('purchase-returns-cart-total');
            if (!tbody) return;
            var grandTotal = 0;
            var roundM3 = typeof roundMoney === 'function' ? roundMoney : function(x){ return Math.round(Number(x)); };
            let activeFocusId = null;
            let activeFocusStart = null;
            let activeFocusEnd = null;
            if (document.activeElement && document.activeElement.classList.contains('pur-ret-cart-input')) {
                activeFocusId = document.activeElement.id;
                try { activeFocusStart = document.activeElement.selectionStart; activeFocusEnd = document.activeElement.selectionEnd; } catch(e) {}
            }
        var unitIconFor = function(u) {
            return (typeof window.getPosUnitIconHtml === 'function') ? window.getPosUnitIconHtml(u, true) : '';
        };
        
        if (purchaseReturnCart.length === 0) {
            tbody.innerHTML = '<div class="returns-empty-state" style="padding:40px 10px;"><i class="fas fa-undo"></i><span>سەبەتە یا ڤالایە</span></div>';
            if (totalEl) totalEl.innerText = '0';
            updatePurchaseReturnDebtSummary(0);
            if (typeof window.updateTxnPeekBar === 'function') window.updateTxnPeekBar('purchase-returns');
            return;
        }
        tbody.innerHTML = '';
            var moneyLines = allocPurchaseReturnLinesGross(purchaseReturnCart);
            purchaseReturnCart.forEach(function(row, idx) {
                var lineMoney = moneyLines[idx] || { net: 0, gross: 0 };
                var lineTotal = lineMoney.net;
                grandTotal = roundM3(grandTotal + lineTotal);
                var unitQty = parseFloat(row.qty) || 0;
                var shownCost = unitQty > 0 ? ((lineMoney.gross || 0) / unitQty) : (row.costPerUnit || 0);
            var unitIcon = unitIconFor(row.unit || 'piece');
            var isWeightQty = isWeightProduct(row.productRef || null);
            var qtyStep = '0.001';
            var qtyDelta = isWeightQty ? 0.25 : 1;
            var kiloQtyChips = renderKiloQtyPresetChips(row.productRef || row, function(v) {
                return "updatePurchaseReturnCartLine(" + idx + ",'qty'," + v + ",true)";
            });
            var div = document.createElement('div');
            div.className = 'returns-cart-row returns-cart-row-slim';
            div.innerHTML =
                '<span class="returns-row-name" title="' + escapeHtml(row.productName || 'ئایتم') + '">' + unitIcon + escapeHtml(row.productName || 'ئایتم') + '</span>' +
                    '<input type="text" inputmode="decimal" dir="ltr" id="pur_ret_cart_' + idx + '_disc" class="pur-ret-cart-input returns-row-disc" value="' + formatPurchaseCartPriceDisplay(row.discount || 0) + '" onkeydown="if(event.key===\'Enter\') this.blur();" onchange="updatePurchaseReturnCartLine(' + idx + ',\'discount\',this.value,true)" oninput="updatePurchaseReturnCartLine(' + idx + ',\'discount\',this.value,false)" onfocus="this.select()" title="' + (isPurchaseUsdMode() ? '$ داشکاندن (USD)' : 'داشکاندن') + '">' +
                    '<input type="text" inputmode="decimal" dir="ltr" id="pur_ret_cart_' + idx + '_price" class="pur-ret-cart-input returns-row-price" readonly value="' + formatPurchaseCartPriceDisplay(shownCost) + '" title="' + (isPurchaseUsdMode() ? 'نرخ ژ پسوولێ (USD) — ناهێتە گوهۆڕین' : 'نرخ ژ پسوولێ — ناهێتە گوهۆڕین') + '">' +
                '<div class="returns-row-qty-wrap">' +
                    '<button type="button" onclick="updatePurchaseReturnCartLine(' + idx + ',\'qty\',' + ((row.qty || 0) - qtyDelta) + ')"><i class="fas fa-minus"></i></button>' +
                        '<input type="number" id="pur_ret_cart_' + idx + '_qty" class="pur-ret-cart-input" min="0" step="' + qtyStep + '" inputmode="decimal" readonly value="' + formatQtyForInput((row.qty || 0), row.productRef || row) + '" onclick="openPurchaseReturnCartQtyPrompt(' + idx + ',' + (row.qty || 0) + '); return false;" onkeydown="if(event.key===\'Enter\') this.blur();" onchange="updatePurchaseReturnCartLine(' + idx + ',\'qty\',this.value,true)" oninput="updatePurchaseReturnCartLine(' + idx + ',\'qty\',this.value,false)" onfocus="this.select()">' +
                    '<button type="button" onclick="updatePurchaseReturnCartLine(' + idx + ',\'qty\',' + ((row.qty || 0) + qtyDelta) + ')"><i class="fas fa-plus"></i></button>' +
                    kiloQtyChips +
                '</div>' +
                '<span class="returns-row-total" data-purchase-return-row-total="' + idx + '">' + purchaseFormatMoneyWithSymbol(lineTotal) + '</span>' +
                '<button type="button" class="returns-row-del" onclick="removeFromPurchaseReturnCart(' + idx + ')" title="سڕینەوە"><i class="fas fa-times"></i></button>';
            tbody.appendChild(div);
            stampTxnMobileCartLabels(div);
            });
            if (totalEl) totalEl.innerText = purchaseReturnCart.length ? purchaseFormatMoneyWithSymbol(grandTotal) : '0';
            updatePurchaseReturnDebtSummary(grandTotal);
            if (activeFocusId) {
                setTimeout(() => {
                    const el = document.getElementById(activeFocusId);
                    if (el) { el.focus(); try { el.setSelectionRange(activeFocusStart, activeFocusEnd); } catch(e){} }
                }, 10);
            }
            if (typeof window.updateTxnPeekBar === 'function') window.updateTxnPeekBar('purchase-returns');
            if (!(typeof isPosTxnLiteMode === 'function' && isPosTxnLiteMode()) && typeof window.bounceTxnSheet === 'function' && purchaseReturnCart.length) window.bounceTxnSheet('purchase-returns');
        }
        function getPurchaseReturnSupplierPreviousDebt() {
            var sel = document.getElementById('purchase-returns-supplier-select');
            var supplierId = sel && sel.value ? parseInt(sel.value, 10) : null;
            var comp = supplierId && db && db.companies ? (db.companies.find(function(c) { return c.id === supplierId; })) : null;
            return comp ? (parseFloat(comp.balance) || 0) : 0;
        }
        function getPurchaseInvoicePaymentType(companyName, invoiceRef) {
            var ref = String(invoiceRef || '').trim();
            if (!companyName || !ref) return 'cash';
            var rows = getPurchaseReturnSuppliesList().filter(function(s) {
                return supplyMatchesPurchaseReturnCompany(s, companyName)
                    && supplyMatchesPurchaseReturnInvoiceRef(s, ref)
                    && s.type !== 'return' && s.type !== 'opening' && (parseFloat(s.qtyAdded) || 0) > 0;
            });
            if (!rows.length) return 'cash';
            var t = String(rows[0].type || 'cash').toLowerCase();
            if (t === 'credit' || t === 'split') return t;
            return 'cash';
        }
        function getPurchaseReturnFinancialSplit(returnTotal, paymentType, companyName, invoiceRef) {
            var roundM = typeof roundMoney === 'function' ? roundMoney : function(x) { return Math.round(Number(x)); };
            var total = roundM(Math.max(0, Number(returnTotal) || 0));
            return { paymentType: 'credit', debtAdjusted: total, cashRefunded: 0 };
        }
        function updatePurchaseReturnDebtSummary(returnTotal) {
            var prevEl = document.getElementById('purchase-return-previous-debt');
            var totalEl = document.getElementById('purchase-return-total-value');
            var balEl = document.getElementById('purchase-return-updated-balance');
            var roundM = typeof roundMoney === 'function' ? roundMoney : function(x){ return Math.round(Number(x)); };
            var prevDebt = getPurchaseReturnSupplierPreviousDebt();
            var retTotal = typeof returnTotal === 'number' ? returnTotal : 0;
            var sel = document.getElementById('purchase-returns-supplier-select');
            var supplierId = sel && sel.value ? parseInt(sel.value, 10) : null;
            var comp = supplierId && db && db.companies ? db.companies.find(function(c) { return c.id === supplierId; }) : null;
            var refInput = document.getElementById('purchase-return-supplier-invoice-ref');
            var invoiceRef = refInput && refInput.value ? String(refInput.value).trim() : '';
            var split = getPurchaseReturnFinancialSplit(retTotal, null, comp ? comp.name : '', invoiceRef);
            var updatedBalance = roundM(prevDebt - split.debtAdjusted);
            var invoiceOriginal = getPurchaseReturnInvoiceOriginalTotal(comp ? comp.name : '', invoiceRef);
            var sym = typeof getCurrencySymbol === 'function' ? getCurrencySymbol() : '';
            if (prevEl) prevEl.textContent = formatCurrency(prevDebt) + ' ' + sym;
            if (totalEl) {
                totalEl.textContent = invoiceRef
                    ? (formatCurrency(invoiceOriginal) + ' ' + sym)
                    : ('0 ' + sym);
            }
            if (balEl) {
                balEl.textContent = formatCurrency(updatedBalance) + ' ' + sym;
                var compactBal = document.getElementById('purchase-return-updated-balance-compact');
                if (compactBal) compactBal.textContent = balEl.textContent;
            }
        }
        window.togglePurchaseReturnDebtDetails = function(forceOpen) {
            var body = document.getElementById('purchase-return-debt-expanded-rows');
            var btn = document.getElementById('btn-toggle-purchase-return-debt');
            if (!body) return;
            var isCollapsed = body.classList.contains('is-collapsed');
            var shouldOpen = typeof forceOpen === 'boolean' ? forceOpen : isCollapsed;
            body.classList.toggle('is-collapsed', !shouldOpen);
            if (btn) {
                btn.setAttribute('aria-expanded', shouldOpen ? 'true' : 'false');
                var icon = btn.querySelector('.txn-details-chevron');
                if (icon) {
                    icon.className = shouldOpen ? 'fas fa-chevron-up txn-details-chevron' : 'fas fa-chevron-down txn-details-chevron';
                }
            }
        };
        function handlePurchaseReturnBarcode(event) {
            if (event.key !== 'Enter') return;
            var input = document.getElementById('purchase-returns-search');
            var val = (input && input.value) ? input.value.trim() : '';
            if (!val) return;
            var sel = document.getElementById('purchase-returns-supplier-select');
            var supplierId = sel && sel.value ? parseInt(sel.value, 10) : null;
            var comp = supplierId ? (db.companies || []).find(function(c) { return c.id === supplierId; }) : null;
            if (!comp) {
                if (typeof showToast === 'function') showToast('کۆمپانیایەکێ هەلبژێرە', 'warning');
                event.preventDefault();
                return;
            }
            if (!requirePurchaseReturnSupplierInvoiceRef()) {
                event.preventDefault();
                return;
            }
            var refInput = document.getElementById('purchase-return-supplier-invoice-ref');
            var invRefRaw = (refInput && refInput.value) ? refInput.value.trim() : '';
            var purchasedItems = buildPurchaseReturnPurchasedItemsMap(comp.name, invRefRaw);

            var activeUnit = typeof purchaseReturnSelectedUnit !== 'undefined' ? purchaseReturnSelectedUnit : 'piece';
            var candidates = (db.products || []).filter(function(p) {
                var pData = purchasedItems[String(p.id)];
                if (!pData || pData.qty <= 0) return false;
                return true;
            });
            var resolved = typeof window.resolveBarcodeForTxnAdd === 'function'
                ? window.resolveBarcodeForTxnAdd(val, activeUnit, { isPurchase: true, candidates: candidates })
                : null;
            if (resolved && resolved.ambiguous) {
                if (typeof showToast === 'function') showToast('پتر ژ ئێک ئایتم هاتە دیتن! ئێکێ هەلبژێرە.', 'info');
                event.preventDefault();
                return;
            }
            if (resolved && resolved.p) {
                var p = resolved.p;
                var rowUnit = resolved.unit;
                if (typeof productMatchesUnitFilter === 'function' && !productMatchesUnitFilter(p, rowUnit, true)) {
                    if (typeof showToast === 'function') showToast('ئەم یەکەیە بۆ ئەم ئایتمە پێناسە نەکراوە.', 'warning');
                    event.preventDefault();
                    return;
                }
                var customCost = getPurchaseReturnCostForUnit(p.id, rowUnit, comp.name, invRefRaw);
                addToPurchaseReturnCart(p.id, rowUnit, customCost);
                if (input) input.value = '';
                event.preventDefault();
                return;
            }
            if (typeof showToast === 'function') showToast('ئەڤ کەرەستە ژ ڤێ کۆمپانیێ نەهاتیە کڕین یان بارکۆد/ناڤ نەدۆزرایەوە.', 'warning');
            event.preventDefault();
        }
        function processPurchaseReturn() {
            if (typeof window.collapseTxnSheet === 'function') window.collapseTxnSheet('purchase-returns');
            var sel = document.getElementById('purchase-returns-supplier-select');
            var supplierId = sel && sel.value ? parseInt(sel.value, 10) : null;
            var comp = supplierId ? (db.companies || []).find(function(c) { return c.id === supplierId; }) : null;
            if (!comp) {
                if (typeof window.highlightTxnMetaFields === 'function') {
                    window.highlightTxnMetaFields('purchase-returns', ['purchase-returns-supplier-select']);
                }
                if (typeof showToast === 'function') showToast('کۆمپانیایەکێ هەلبژێرە', 'error');
                else alert('کۆمپانیایەکێ هەلبژێرە');
                return;
            }
            var validRows = purchaseReturnCart.filter(function(row) { return (row.qty || 0) > 0; });
            if (validRows.length === 0) { if (typeof showToast === 'function') showToast('سەبەتا زڤراندن بەتاڵە', 'error'); else alert('سەبەتا زڤراندن بەتاڵە'); return; }
            var roundMSubmit = typeof roundMoney === 'function' ? roundMoney : function (x) { return Math.round(Number(x)); };
            var moneySubmit = allocPurchaseReturnLinesGross(validRows);
            validRows.forEach(function (row, idx) {
                var gross = moneySubmit[idx] ? moneySubmit[idx].gross : 0;
                var pq = parseFloat(row.qty) || 0;
                if (pq > 0) {
                    row.costPerUnit = roundMSubmit(gross / pq);
                }
            });
            var refInput = document.getElementById('purchase-return-supplier-invoice-ref');
            var supplierInvoiceRef = (refInput && refInput.value) ? String(refInput.value).trim() : '';
            if (!supplierInvoiceRef) {
                requirePurchaseReturnSupplierInvoiceRef();
                return;
            }
            var invCtx = resolvePurchaseReturnInvoiceContext(comp.name, supplierInvoiceRef);
            if (!invCtx) {
                if (typeof showToast === 'function') {
                    showToast('پسوولە نەدۆزرایەوە — ژمارا پسوولێ کۆمپانیا یان ژمارا کڕینێ (000045) بنووسە', 'error');
                } else {
                    alert('پسوولە نەدۆزرایەوە');
                }
                if (refInput) refInput.classList.add('input-error');
                return;
            }
            supplierInvoiceRef = invCtx.canonical;
            if (refInput) refInput.classList.remove('input-error');
            if (typeof window.clearTxnMetaErrors === 'function') window.clearTxnMetaErrors('purchase-returns');
            var btn = document.getElementById('btn-complete-purchase-return');
            if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ...'; }
            var user = (typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : 'System';
            var itemsPayload = validRows.map(function(row) {
                return { productId: row.productId, productName: row.productName, qty: row.qty, unit: row.unit || 'piece', costPerUnit: row.costPerUnit, discount: row.discount || 0 };
            });
            var formData = new FormData();
            formData.append('action', 'save_purchase_return');
            formData.append('company_id', comp.id);
            formData.append('items', JSON.stringify(itemsPayload));
            formData.append('user', user);
            formData.append('supplier_invoice_number', supplierInvoiceRef);
            fetch('?action=save_purchase_return', { method: 'POST', body: formData })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-check-circle"></i> تەواوکردنی زڤراندن (Complete Return)'; }
                    if (data.status === 'success') {
                        var totalAmount = validRows.reduce(function (s, r) {
                            return s + purchaseReturnLineTotal(r);
                        }, 0);
                        var roundM2 = typeof roundMoney === 'function' ? roundMoney : function(x){ return Math.round(Number(x)); };
                        totalAmount = roundM2(totalAmount);
                        if (data.total != null && !isNaN(parseFloat(data.total))) {
                            totalAmount = roundM2(parseFloat(data.total));
                        }
                        var nowIso = (data && data.date) ? data.date : new Date().toISOString();
                        var localTxnId = 'TXPR_LOCAL_' + (data && data.id ? data.id : Date.now());
                        purchaseReturnCart = [];
                        window._pendingPurchaseReturnFromHistory = null;
                        if (typeof updatePurchaseReturnFromHistoryBanner === 'function') updatePurchaseReturnFromHistoryBanner(null);
                        var refInputAfter = document.getElementById('purchase-return-supplier-invoice-ref');
                        if (refInputAfter) refInputAfter.value = '';
                        renderPurchaseReturnCart();
                        if (typeof window.collapseTxnSheet === 'function') window.collapseTxnSheet('purchase-returns');
                        if (typeof showToast === 'function') showToast('زڤڕاندن تۆمارکرا — ژ قەرزی کۆمپانیێ هاتە کێمکرن');
                        if (data.company_balance != null && !isNaN(parseFloat(data.company_balance))) {
                            comp.balance = parseFloat(data.company_balance) || 0;
                        } else {
                            var debtAdj = parseFloat(data.debt_adjusted);
                            if (!isNaN(debtAdj) && debtAdj > 0) comp.balance = (parseFloat(comp.balance) || 0) - debtAdj;
                        }
                        validRows.forEach(function(row) {
                            var p = row.productRef || (db.products || []).find(function(x) { return x.id === row.productId; });
                            if (p && p.trackStock) {
                                var mult = typeof getPiecesMultiplierForUnit === 'function' ? getPiecesMultiplierForUnit(p, row.unit || 'piece') : 1;
                                p.qty = db.settings.allowNegativeStock ? ((p.qty || 0) - Math.round((row.qty || 0) * mult)) : Math.max(0, (p.qty || 0) - Math.round((row.qty || 0) * mult));
                            }
                        });
                        // Keep purchase history and supplier return availability in sync without refresh.
                        validRows.forEach(function(row, idx) {
                            var p = row.productRef || (db.products || []).find(function(x) { return x.id === row.productId; });
                            var factors = (typeof getProductUnitFactors === 'function') ? getProductUnitFactors(p) : { piecesPerPack: 1, piecesPerCarton: 1 };
                            var mult = 1;
                            if ((row.unit || 'piece') === 'carton') mult = factors.piecesPerCarton || 1;
                            else if ((row.unit || 'piece') === 'pack') mult = factors.piecesPerPack || 1;
                            var pieces = Math.round((row.qty || 0) * mult);
                            var lineTotal = (moneySubmit[idx] && moneySubmit[idx].net != null)
                                ? roundM2(moneySubmit[idx].net)
                                : roundM2(Math.max(0, (row.qty || 0) * (row.costPerUnit || 0) - (row.discount || 0)));
                            if (!db.supplies) db.supplies = [];
                            db.supplies.push({
                                id: Date.now() + Math.floor(Math.random() * 1000),
                                company: comp.name,
                                prodId: row.productId,
                                itemName: row.productName,
                                qtyAdded: -pieces,
                                totalCost: lineTotal,
                                date: nowIso,
                                type: 'return',
                                transaction_id: localTxnId,
                                supplier_invoice_number: supplierInvoiceRef
                            });
                        });
                        if (db.purchase_returns) db.purchase_returns.unshift({
                            id: data.id,
                            company_id: comp.id,
                            company_name: comp.name,
                            items: itemsPayload,
                            total: totalAmount,
                            date: data.date,
                            user: user,
                            transaction_id: data.transaction_id || localTxnId,
                            supplier_invoice_number: supplierInvoiceRef,
                            cash_refunded: parseFloat(data.cash_refunded) || 0,
                            debt_adjusted: parseFloat(data.debt_adjusted) || 0,
                            payment_type: data.payment_type || ''
                        });
                        if (!db.ledger) db.ledger = [];
                        var debtAdjLocal = parseFloat(data.debt_adjusted) || 0;
                        if (debtAdjLocal > 0) {
                            db.ledger.push({
                                id: Date.now(),
                                companyId: comp.id,
                                type: 'return_to_supplier',
                                amount: debtAdjLocal,
                                date: nowIso,
                                note: 'Purchase Return #' + (data && data.id ? data.id : 'NEW') + ' | Supplier Inv: ' + supplierInvoiceRef + ' | items=' + itemsPayload.length + ' | قەرز=' + debtAdjLocal,
                                transaction_id: data.transaction_id || localTxnId
                            });
                        }
                        if ((parseFloat(data.cash_refunded) || 0) > 0) {
                            if (!db.expenses) db.expenses = [];
                            db.expenses.unshift({
                                id: Date.now(),
                                note: 'زڤڕاندنا کڕینێ (نەقد): ' + comp.name + ' | پسوول=' + supplierInvoiceRef,
                                amount: -roundM2(parseFloat(data.cash_refunded) || 0),
                                date: nowIso,
                                user: user,
                                type: 'purchase_return',
                                transaction_id: data.transaction_id || localTxnId
                            });
                        }
                        if (typeof renderPurchaseReturnsProductGrid === 'function') renderPurchaseReturnsProductGrid();
                        if (typeof renderCompanyHistory === 'function') renderCompanyHistory(comp.name);
                        if (typeof renderGlobalPurchaseHistory === 'function') {
                            if (typeof loadGlobalPurchaseHistory === 'function') {
                                loadGlobalPurchaseHistory(renderGlobalPurchaseHistory, 'gph');
                            } else {
                                renderGlobalPurchaseHistory();
                            }
                        }
                        if (typeof renderLedgerHistory === 'function') renderLedgerHistory(comp.id);
                        if (typeof printPurchaseReturnInvoice === 'function') {
                            if ((typeof db !== 'undefined' && db.settings && db.settings.autoPrintPurchaseInvoice) || confirm("چاپکرنا وەسڵا زڤڕاندنێ؟ (Print Return Invoice?)")) {
                                printPurchaseReturnInvoice(validRows, comp, supplierInvoiceRef, data.id);
                            }
                        }
                        if (document.getElementById('purchase-returns-search')) document.getElementById('purchase-returns-search').focus();
                    } else {
                        if (typeof showToast === 'function') showToast(data.message || 'هەڵە', 'error'); else alert(data.message || 'هەڵە');
                    }
                })
                .catch(function(err) {
                    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-check-circle"></i> تەواوکردنی زڤراندن (Complete Return)'; }
                    if (typeof showToast === 'function') showToast('هەڵە د پاراستنێ دا', 'error'); else alert('هەڵە د پاراستنێ دا');
                });
        }

        if (typeof window !== 'undefined') {
            window.handlePurchaseReturnProductCardTap = handlePurchaseReturnProductCardTap;
            window.addToPurchaseReturnCart = addToPurchaseReturnCart;
            window.processPurchaseReturn = processPurchaseReturn;
            window.clearPurchaseReturnCart = clearPurchaseReturnCart;
            window.renderPurchaseReturnsProductGrid = renderPurchaseReturnsProductGrid;
            window.debouncedRenderPurchaseReturnsProductGrid = debouncedRenderPurchaseReturnsProductGrid;
            window.initPurchaseReturnsScreen = initPurchaseReturnsScreen;
            window.setPurchaseReturnUnit = setPurchaseReturnUnit;
            window.onPurchaseReturnSupplierChange = onPurchaseReturnSupplierChange;
            window.updatePurchaseReturnCartLine = updatePurchaseReturnCartLine;
            window.removeFromPurchaseReturnCart = removeFromPurchaseReturnCart;
            window.renderPurchaseReturnCart = renderPurchaseReturnCart;
            window.handlePurchaseReturnBarcode = handlePurchaseReturnBarcode;
        }
