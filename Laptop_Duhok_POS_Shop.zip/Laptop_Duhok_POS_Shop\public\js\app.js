/**
 * Legacy loader stub. Scripts live in folders under public/js/:
 *   core, i18n, settings, sync, purchase, inventory, sales, reports
 * Normally loaded via main.js. Rebuild monolith: scripts/merge-app-js.ps1
 */
(function () {
    if (window.__posAppScriptsLoading || window.__posAppScriptsLoaded) return;
    window.__posAppScriptsLoading = true;

    var parts = [
        'core/startup.js',
        'core/login-db.js',
        'core/catalog.js',
        'i18n/badini.js',
        'i18n/ar.js',
        'i18n/runtime.js',
        'i18n/tech-specs.js',
        'settings/print-labels.js',
        'settings/printers.js',
        'sync/live.js',
        'sync/theme-home.js',
        'sync/companies.js',
        'sync/delivery.js',
        'sync/customers.js',
        'sync/company-profile.js',
        'purchase/cart.js',
        'purchase/payment.js',
        'purchase/returns.js',
        'purchase/company-docs.js',
        'inventory/warehouse.js',
        'inventory/stocktake.js',
        'inventory/products.js',
        'inventory/dashboard.js',
        'inventory/scale-barcode.js',
        'sales/barcode-nav.js',
        'sales/qty-cart.js',
        'sales/add-to-bill.js',
        'sales/edit-sale.js',
        'sales/debt-bill.js',
        'sales/virtual-menu.js',
        'sales/filter-worker.js',
        'sales/print.js',
        'sales/payment-modal.js',
        'sales/complete-sale.js',
        'sales/pos-return.js',
        'reports/expenses.js',
        'reports/shifts.js',
        'reports/backup.js',
        'reports/backup-restore.js',
        'reports/ota-update.js',
        'reports/calendar.js',
        'reports/history.js',
        'reports/print.js',
        'reports/revenue.js',
        'reports/telegram.js',
        'reports/modals.js',
        'reports/sale-followup.js',
        'reports/purchase-history.js',
        'reports/nav-menus.js',
        'reports/exports.js',
        'reports/shop-ai.js'
    ];
    var me = document.currentScript;
    var base = me && me.src ? me.src.replace(/\/app\.js(\?.*)?$/, '/') : 'public/js/';
    var v = encodeURIComponent(String(typeof window.POS_APP_VERSION !== 'undefined' ? window.POS_APP_VERSION : '1'));

    function loadPart(index) {
        if (index >= parts.length) {
            window.__posAppScriptsLoaded = true;
            window.__posAppScriptsLoading = false;
            return;
        }
        var script = document.createElement('script');
        script.src = base + parts[index] + '?v=' + v;
        script.onload = function () { loadPart(index + 1); };
        script.onerror = function () {
            window.__posAppScriptsLoading = false;
            console.error('Failed to load POS script:', parts[index]);
        };
        document.head.appendChild(script);
    }

    loadPart(0);
})();
