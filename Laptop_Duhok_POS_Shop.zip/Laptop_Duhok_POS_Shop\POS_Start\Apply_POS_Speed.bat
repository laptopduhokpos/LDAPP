@echo off
chcp 65001 >nul
echo Laptop Duhok POS — خێراتر کرنا MySQL/PHP
echo داتا و کۆگەه ناگوهۆڕن. پێدڤی ب ڤەکرنا دوبارە یا XAMPP هەیە.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\tools\Apply_POS_Speed.ps1"
echo.
pause
