# Currency model (POS) — developer reference

This document describes how IQD and USD interact in the codebase. For UX copy aimed at shop owners, keep explanations aligned with this model.

## Base currency (`settings.currencyMode`)

- The shop chooses **USD** or **IQD** as the **catalog base** while the product catalog is empty. After the first product exists, `currencyMode` is locked; only `usdRate` (exchange bundle) remains editable from settings.
- **USD base (`currencyMode === 'USD'`)**: Canonical sell/cost references are optional `*_usd` columns (`price_usd`, `cost_usd`, …). When set, IQD shown at runtime is derived as `round(price_usd * ratePerOne)` where `ratePerOne = usdRate / 100` when `usdRate >= 100` (same encoding as “IQD for 100 USD”).
- **IQD base (`currencyMode === 'IQD'`)**: Canonical values are the IQD columns (`price`, `cost`, …). `*_usd` are cleared on save. Approximate USD for display is `IQD / ratePerOne` (see `formatApproxUsdFromIqd`, `getCatalogPieceSellUsd` in `public/js/app.js`).

## Exchange rate usage (`settings.usdRate`)

- `usdRate` stores **IQD total for 100 USD** (e.g. `150000`). Per-one IQD: `usdRate / 100` when `usdRate >= 100`.
- Changing `usdRate` does not change the **principal** stored in the catalog (USD in USD base, IQD in IQD base). It changes derived display amounts and payment conversion.
- Optional audit: table `exchange_rate_history` (schema v11) receives a row when `save_settings` or `save_exchange_rate` (POS quick modal) persists a new `usdRate`. `GET ?action=get_exchange_rate_history` returns recent rows for review (permission: `set_exchange_rate`, `reports_view`, or admin).

## Product save behavior (`api/all.php` `save_product`)

- **USD mode**: Computes/stores `*_usd` and derives IQD columns from the current rate for DB compatibility.
- **IQD mode**: Clears `*_usd` and keeps IQD columns as entered.

## Debt and ledger

- Existing debt/ledger flows may still treat stored balances as IQD in many screens (`formatCurrency` + totals). When extending IQD-base shops, validate debt workflows independently if you rely on USD-only debt semantics.

## Historical rows (sales, returns, supplies, …)

- Financial tables store `fx_usd_rate` and `fx_currency_mode` snapshots where applicable (`api/all.php` insert/restore paths).
- When formatting a **past** row for display, pass `formatFxOpts` / `fxUsdRate` so `formatCurrency` uses the **snapshot rate**, not today’s `getUsdRatePerOne()`.

## Related files

- `public/js/modules/utils.js` — `formatCurrency`, `getActiveCurrency`, `getUsdRatePerOne`, `formatApproxUsdFromIqd`, `getCurrencySymbol`
- `public/js/app.js` — `catalogIqdFromUsdField`, `getCatalogPieceSellIqd`, `getCatalogPieceSellUsd`, `productFormDisplayMoneyInput`, `refreshAfterCurrencySettingsSave`, `updateProductFormFxHints`
- `api/all.php` — `pos_settings_currency_mode_from_array`, `save_product`, `save_settings`, `commit_currency_mode`, `pos_exchange_rate_history_append`, `import_products`
- `config/migrations.php` — `POS_SCHEMA_VERSION`, `exchange_rate_history`, product `*_usd` columns
