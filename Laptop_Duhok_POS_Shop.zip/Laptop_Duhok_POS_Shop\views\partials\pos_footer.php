    <!-- JAVASCRIPT LOGIC -->
    <script src="public/js/sales/txn-mobile.js?v=<?php echo $pos_asset_v; ?>"></script>
    <script src="public/js/returns/screen.js?v=<?php echo $pos_asset_v; ?>"></script>
    <script src="public/js/returns/cart-save.js?v=<?php echo $pos_asset_v; ?>"></script>
    <script>
    (function () {
        var STORAGE_KEY = "pos_notifications_inbox";
        var READ_KEY = "pos_notifications_read";
        var MAX_ITEMS = 80;
        var inbox = [];
        var readMap = {};
        var toastTimer = null;

        var fab = document.getElementById("pos-notification-fab");
        var countEl = document.getElementById("pos-notification-count");
        var panel = document.getElementById("pos-notification-panel");
        var list = document.getElementById("pos-notification-list");
        var markReadBtn = document.getElementById("pos-notification-mark-read");
        var toast = document.getElementById("pos-notification-toast");
        var toastTitle = document.getElementById("pos-toast-title");
        var toastMsg = document.getElementById("pos-toast-msg");

        function safeParse(raw, fallback) {
            try {
                var parsed = JSON.parse(raw || "");
                return parsed && typeof parsed === "object" ? parsed : fallback;
            } catch (e) { return fallback; }
        }

        function esc(s) {
            return String(s || "").replace(/[&<>"']/g, function (ch) {
                return ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", "\"":"&quot;", "'":"&#39;" })[ch];
            });
        }

        function loadState() {
            inbox = safeParse(localStorage.getItem(STORAGE_KEY), []);
            if (!Array.isArray(inbox)) inbox = [];
            readMap = safeParse(localStorage.getItem(READ_KEY), {});
        }

        window.deleteNotificationFromFooter = function(id) {
            try {
                loadState();
                var key = String(id || '');
                if (!key) return;
                inbox = inbox.filter(function(n) { return String(n.id) !== key; });
                delete readMap[key];
                saveState();
                render();
                if (typeof updateNotificationBadge === "function") updateNotificationBadge();
                if (typeof renderNotifications === "function") {
                    var view = document.getElementById("view-notifications");
                    if (view && view.style.display !== "none") renderNotifications();
                }
            } catch(e) {}
        };

        function saveState() {
            try { localStorage.setItem(STORAGE_KEY, JSON.stringify(inbox.slice(0, MAX_ITEMS))); } catch (e) {}
            try { localStorage.setItem(READ_KEY, JSON.stringify(readMap)); } catch (e) {}
        }

        function unreadCount() {
            var n = 0;
            for (var i = 0; i < inbox.length; i++) {
                if (!readMap[inbox[i].id]) n++;
            }
            return n;
        }

        function render() {
            fab.style.display = "inline-flex";
            var unread = unreadCount();
            if (unread > 0) {
                countEl.style.display = "inline-flex";
                countEl.textContent = unread > 99 ? "99+" : String(unread);
                fab.classList.add("has-unread");
            } else {
                countEl.style.display = "none";
                countEl.textContent = "0";
                fab.classList.remove("has-unread");
            }

            if (!inbox.length) {
                list.innerHTML = '<div class="item">چ ئاگەهداری نینن.</div>';
                return;
            }
            list.innerHTML = inbox.map(function (m) {
                var isRead = !!readMap[m.id];
                var dt = new Date(Number(m.createdAt || Date.now()));
                var title = esc(m.title || "Notification");
                var msg = esc(m.message || "");
                var meta = esc((m.createdBy || "Admin") + " | " + dt.toLocaleString("ar-IQ"));
                return '<div class="item" data-id="' + esc(m.id) + '" style="position:relative; ' + (isRead ? "opacity:.7;" : "") + '">' +
                    '<div style="font-weight:700; padding-inline-end:24px;">' + title + (isRead ? "" : ' <span style="color:#fca5a5;">●</span>') + '</div>' +
                    '<button type="button" onclick="event.stopPropagation(); if(confirm(\'دڵنیای؟\')) deleteNotificationFromFooter(\'' + esc(m.id).replace(/'/g, "\\'") + '\');" style="position:absolute; left:8px; top:8px; background:none; border:none; color:#fca5a5; cursor:pointer;"><i class="fa fa-trash"></i></button>' +
                    '<div style="margin-top:4px;">' + msg + '</div>' +
                    '<div class="meta">' + meta + '</div>' +
                '</div>';
            }).join("");
        }

        function beep() {
            try {
                var ctx = new (window.AudioContext || window.webkitAudioContext)();
                var oscillator = ctx.createOscillator();
                var gain = ctx.createGain();
                oscillator.type = "sine";
                oscillator.frequency.value = 880;
                gain.gain.value = 0.04;
                oscillator.connect(gain);
                gain.connect(ctx.destination);
                oscillator.start();
                setTimeout(function () {
                    oscillator.stop();
                    ctx.close();
                }, 120);
            } catch (e) {}
        }

        function beepInstallmentAlert(isOverdue) {
            try {
                var ctx = new (window.AudioContext || window.webkitAudioContext)();
                var playTone = function(freq, startMs, durMs) {
                    var oscillator = ctx.createOscillator();
                    var gain = ctx.createGain();
                    oscillator.type = "sine";
                    oscillator.frequency.value = freq;
                    gain.gain.value = isOverdue ? 0.08 : 0.06;
                    oscillator.connect(gain);
                    gain.connect(ctx.destination);
                    oscillator.start(ctx.currentTime + startMs / 1000);
                    oscillator.stop(ctx.currentTime + (startMs + durMs) / 1000);
                };
                playTone(isOverdue ? 660 : 880, 0, 180);
                playTone(isOverdue ? 880 : 988, 220, 180);
                if (isOverdue) playTone(660, 440, 220);
                setTimeout(function () { try { ctx.close(); } catch (e) {} }, 900);
            } catch (e) {
                beep();
                setTimeout(beep, 200);
            }
        }

        function pulseInstallmentFab() {
            if (!fab) return;
            fab.classList.add("installment-alert-pulse");
            setTimeout(function () { fab.classList.remove("installment-alert-pulse"); }, 8000);
        }

        function tryBrowserNotify(msg) {
            if (!msg || !("Notification" in window)) return;
            var title = String(msg.title || "");
            var body = String(msg.message || "");
            var tag = String(msg.id || "pos-installment");
            if (Notification.permission === "granted") {
                try { new Notification(title, { body: body, tag: tag, requireInteraction: true }); } catch (e) {}
                return;
            }
            if (Notification.permission === "default") {
                Notification.requestPermission().then(function (perm) {
                    if (perm === "granted") {
                        try { new Notification(title, { body: body, tag: tag, requireInteraction: true }); } catch (e) {}
                    }
                }).catch(function () {});
            }
        }

        function showToast(msg) {
            toastTitle.textContent = msg.title || "ئاگەهداریەکا نوی";
            toastMsg.textContent = msg.message || "";
            
            var iconEl = document.getElementById("pos-toast-icon");
            var cardEl = document.getElementById("pos-toast-card");
            var type = String(msg.type || "").toLowerCase();
            
            var color = "#3b82f6";
            var iconClass = "fa-bell";
            var toastDuration = 6000;
            
            if (type.indexOf('installment_overdue') !== -1) {
                color = "#ef4444";
                iconClass = "fa-exclamation-circle";
                toastDuration = 14000;
            } else if (type.indexOf('installment_due') !== -1) {
                color = "#f59e0b";
                iconClass = "fa-credit-card";
                toastDuration = 12000;
            } else if (type.indexOf('installment_upcoming') !== -1) {
                color = "#3b82f6";
                iconClass = "fa-calendar-day";
                toastDuration = 9000;
            } else if (type.indexOf('installment') !== -1) {
                color = "#f59e0b";
                iconClass = "fa-credit-card";
                toastDuration = 12000;
            } else if (type.indexOf('warning') !== -1 || type.indexOf('low_stock') !== -1 || type.indexOf('expiry') !== -1) {
                color = "#f59e0b";
                iconClass = "fa-exclamation-triangle";
            } else if (type.indexOf('danger') !== -1 || type.indexOf('error') !== -1) {
                color = "#ef4444";
                iconClass = "fa-exclamation-circle";
            } else if (type.indexOf('success') !== -1) {
                color = "#10b981";
                iconClass = "fa-check-circle";
            } else if (msg.title && (msg.title.indexOf('کێمبوون') !== -1 || msg.title.indexOf('ئێکسپایەر') !== -1 || msg.title.indexOf('بەسەرچوون') !== -1)) {
                color = "#f59e0b";
                iconClass = "fa-exclamation-triangle";
            }

            if (iconEl) {
                iconEl.innerHTML = '<i class="fas ' + iconClass + '"></i>';
                iconEl.style.color = color;
            }
            if (cardEl) cardEl.style.borderRightColor = color;
            if (type.indexOf("installment") !== -1) toast.classList.add("installment-toast-active");
            else toast.classList.remove("installment-toast-active");
            
            toast.style.display = "block";
            toast.style.animation = 'none';
            void toast.offsetWidth; // trigger reflow
            toast.style.animation = "toast-slide-in 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)";

            if (toastTimer) clearTimeout(toastTimer);
            toastTimer = setTimeout(function () {
                toast.style.animation = "toast-slide-out 0.3s ease-in forwards";
                setTimeout(function() {
                    toast.style.display = "none";
                    toast.style.animation = "";
                }, 280);
            }, toastDuration);
        }

        function addMessage(msg) {
            if (!msg || !msg.id) return;
            for (var i = 0; i < inbox.length; i++) {
                if (inbox[i].id === msg.id) return;
            }
            var msgType = String(msg.type || "info").slice(0, 30);
            inbox.unshift({
                id: String(msg.id),
                title: String(msg.title || "Notification").slice(0, 140),
                message: String(msg.message || "").slice(0, 1000),
                type: msgType,
                createdBy: String(msg.createdBy || "Admin").slice(0, 120),
                createdAt: Number(msg.createdAt || Date.now())
            });
            if (inbox.length > MAX_ITEMS) inbox = inbox.slice(0, MAX_ITEMS);
            saveState();
            render();
            showToast(msg);
            var isStrongInstallment = msgType.indexOf("installment_due") !== -1 || msgType.indexOf("installment_overdue") !== -1;
            if (isStrongInstallment) {
                beepInstallmentAlert(msgType.indexOf("overdue") !== -1);
                pulseInstallmentFab();
                tryBrowserNotify(msg);
            } else {
                beep();
            }
            try {
                if (typeof updateNotificationBadge === "function") updateNotificationBadge();
                if (typeof renderNotifications === "function") {
                    var view = document.getElementById("view-notifications");
                    if (view && view.style.display !== "none") renderNotifications();
                }
            } catch (e) {}
        }

        fab.addEventListener("click", function () {
            if (panel.style.display === "block") {
                panel.style.display = "none";
                fab.classList.remove("panel-open");
            } else {
                panel.style.display = "block";
                fab.classList.add("panel-open");
            }
        });

        markReadBtn.addEventListener("click", function () {
            for (var i = 0; i < inbox.length; i++) readMap[inbox[i].id] = 1;
            saveState();
            render();
            try {
                if (typeof updateNotificationBadge === "function") updateNotificationBadge();
                if (typeof renderNotifications === "function") renderNotifications();
            } catch (e) {}
        });

        list.addEventListener("click", function (e) {
            var target = e.target;
            while (target && target !== list && !target.getAttribute("data-id")) {
                target = target.parentNode;
            }
            if (!target || target === list) return;
            var id = target.getAttribute("data-id");
            if (!id) return;
            var clickedMsg = null;
            for (var ci = 0; ci < inbox.length; ci++) {
                if (String(inbox[ci].id) === String(id)) { clickedMsg = inbox[ci]; break; }
            }
            readMap[id] = 1;
            saveState();
            render();
            try {
                if (typeof updateNotificationBadge === "function") updateNotificationBadge();
                if (typeof renderNotifications === "function") renderNotifications();
            } catch (e) {}
            try {
                if (clickedMsg && typeof window.posOtaIsUpdateNotification === "function" && window.posOtaIsUpdateNotification(clickedMsg)) {
                    if (typeof window.posOtaOpenFromNotification === "function") window.posOtaOpenFromNotification();
                }
            } catch (eOta) {}
        });

        loadState();
        render();

        window.POSNotifications = window.POSNotifications || {};
        window.POSNotifications.onMessage = addMessage;
        window.POSNotifications.showToastOnly = showToast;
        window.POSNotifications.alertInstallment = function (msg) {
            if (!msg) return;
            showToast(msg);
            beepInstallmentAlert(String(msg.type || "").indexOf("overdue") !== -1);
            pulseInstallmentFab();
            tryBrowserNotify(msg);
        };
    })();
    </script>
    <script>
    (function () {
        function getDeviceId() {
            try {
                var saved = localStorage.getItem("pos_device_notification_id");
                if (saved) return saved;
                var seed = (location.hostname || "local") + "|" + navigator.userAgent;
                var hash = 0;
                for (var i = 0; i < seed.length; i++) {
                    hash = ((hash << 5) - hash) + seed.charCodeAt(i);
                    hash |= 0;
                }
                var id = "pos-" + Math.abs(hash);
                localStorage.setItem("pos_device_notification_id", id);
                return id;
            } catch (e) {
                return "pos-unknown";
            }
        }

        function apiUrl(action) {
            return "api/all.php?action=" + encodeURIComponent(action) + "&t=" + Date.now();
        }

        function fetchPhpNotifications() {
            var deviceId = getDeviceId();
            fetch(apiUrl("get_pos_notifications") + "&device_id=" + encodeURIComponent(deviceId), { cache: "no-store" })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    if (!data || data.status !== "success" || !Array.isArray(data.notifications)) return;
                    if (!data.notifications.length) return;
                    var ids = [];
                    for (var i = 0; i < data.notifications.length; i++) {
                        var n = data.notifications[i] || {};
                        var id = String(n.id || "");
                        if (!id) continue;
                        ids.push(id);
                        if (window.POSNotifications && typeof window.POSNotifications.onMessage === "function") {
                            window.POSNotifications.onMessage({
                                id: id,
                                title: n.title || "ئاگەهداریەکا نوی",
                                message: n.message || "",
                                type: n.type || "info",
                                createdBy: n.created_by || "Admin",
                                createdAt: (new Date(n.created_at || Date.now())).getTime()
                            });
                        }
                        try {
                            if (typeof window.posOtaIsUpdateNotification === "function"
                                && window.posOtaIsUpdateNotification({ title: n.title || "", message: n.message || "" })
                                && typeof window.posOtaCheckUpdate === "function") {
                                window.posOtaCheckUpdate(false);
                            }
                        } catch (_eOtaIngest) {}
                    }
                    if (!ids.length) return;
                    var form = new URLSearchParams();
                    form.set("action", "mark_pos_notifications_read");
                    form.set("device_id", deviceId);
                    form.set("notification_ids", ids.join(","));
                    fetch("api/all.php", {
                        method: "POST",
                        headers: { "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8" },
                        body: form.toString()
                    }).catch(function(){});
                })
                .catch(function(){});
        }

        function notifPollMs() {
            try {
                var q = localStorage.getItem('pos_graphics_quality');
                if (q === 'low' || q === 'ultra') return 60000;
            } catch (eN) {}
            return 20000;
        }

        fetchPhpNotifications();
        setInterval(fetchPhpNotifications, notifPollMs());
    })();
    </script>
    
</body>
</html>
