/**
 * Mobile transaction UX: bottom-sheet carts for POS, returns, purchase screens (≤768px).
 */
(function () {
    'use strict';
    if (window._txnMobileModuleLoaded) return;
    window._txnMobileModuleLoaded = true;

    var MQ = '(max-width: 768px)';
    var mq = window.matchMedia(MQ);

    var TXN_VIEWS = ['pos', 'purchase', 'purchase-returns', 'returns-new', 'waste'];

    var SHEET_CONFIGS = [
        {
            key: 'pos',
            viewId: 'pos',
            panel: '#pos-bill-panel',
            rows: '#bill-rows',
            total: '#bill-total',
            peekSheetLabel: 'فرۆشتن',
            primaryClass: 'pos-primary',
            primaryIcon: 'fa-cash-register',
            primaryLabel: 'فرۆشتن',
            onPrimary: function () {
                if (typeof window.sellFromPos === 'function') window.sellFromPos();
            }
        },
        {
            key: 'returns',
            viewId: 'returns-new',
            panel: '#returns-bill-panel',
            rows: '#returns-bill-rows',
            total: '#returns-bill-total',
            peekSheetLabel: 'زڤڕاندن',
            primaryClass: 'returns-primary',
            primaryIcon: 'fa-check',
            primaryLabel: 'پەسەند',
            onPrimary: function () {
                if (typeof window.processReturnsCart === 'function') window.processReturnsCart();
            }
        },
        {
            key: 'purchase',
            viewId: 'purchase',
            panel: '#purchase-cart-panel',
            rows: '#purchase-cart-rows',
            total: '#purchase-cart-total',
            peekSheetLabel: 'کڕین',
            primaryClass: 'purchase-primary',
            primaryIcon: 'fa-save',
            primaryLabel: 'پاراستن',
            onPrimary: function () {
                if (typeof window.savePurchaseInvoice === 'function') window.savePurchaseInvoice();
                else if (typeof window.openPurchasePaymentModal === 'function') window.openPurchasePaymentModal();
            }
        },
        {
            key: 'purchase-returns',
            viewId: 'purchase-returns',
            panel: '#purchase-returns-cart-panel',
            rows: '#purchase-returns-cart-rows',
            total: '#purchase-returns-cart-total',
            peekSheetLabel: 'زڤڕاندنا کڕینێ',
            primaryClass: 'purchase-return-primary',
            primaryIcon: 'fa-check-circle',
            primaryLabel: 'تەواو',
            onPrimary: function () {
                if (typeof window.processPurchaseReturn === 'function') window.processPurchaseReturn();
            }
        },
        {
            key: 'waste',
            viewId: 'waste',
            panel: '#waste-bill-panel',
            rows: '#waste-bill-rows',
            total: '#waste-bill-total',
            peekSheetLabel: 'تەلەف',
            primaryClass: 'waste-primary',
            primaryIcon: 'fa-trash-alt',
            primaryLabel: 'تۆمار',
            onPrimary: function () {
                if (typeof window.processWasteCart === 'function') window.processWasteCart();
            }
        }
    ];

    var sheetsByKey = {};
    var swipeState = null;

    function isTxnMobile() {
        return mq.matches;
    }

    function applyBodyClass() {
        document.body.classList.toggle('txn-mobile-active', isTxnMobile());
    }

    function getPanelEl(cfg) {
        return document.querySelector(cfg.panel);
    }

    function ensureSheetChrome(cfg) {
        var panel = getPanelEl(cfg);
        if (!panel) return null;
        panel.classList.add('txn-sheet-panel');

        var backdrop = panel.querySelector('.txn-sheet-backdrop');
        if (!backdrop) {
            backdrop = document.createElement('div');
            backdrop.className = 'txn-sheet-backdrop no-print';
            backdrop.setAttribute('aria-hidden', 'true');
            panel.insertBefore(backdrop, panel.firstChild);
        }

        var handle = panel.querySelector('.txn-sheet-handle');
        if (!handle) {
            handle = document.createElement('button');
            handle.type = 'button';
            handle.className = 'txn-sheet-handle no-print';
            handle.setAttribute('aria-expanded', 'false');
            handle.setAttribute('title', 'سەبەتە');
            handle.innerHTML =
                '<span class="txn-handle-grip" aria-hidden="true"></span>' +
                '<span class="txn-peek-meta">' +
                '<span class="txn-peek-count">0 ئایتم</span>' +
                '<span class="txn-peek-label">سەبەتە</span>' +
                '</span>' +
                '<span class="txn-peek-total">0</span>' +
                '<span class="txn-peek-primary-wrap"></span>';
            var after = backdrop.nextSibling;
            if (after) panel.insertBefore(handle, after);
            else panel.appendChild(handle);
        }

        if (!panel.classList.contains('txn-sheet-collapsed') && !panel.classList.contains('txn-sheet-expanded')) {
            panel.classList.add('txn-sheet-collapsed');
        }

        var primaryWrap = handle.querySelector('.txn-peek-primary-wrap');
        if (!primaryWrap) {
            primaryWrap = document.createElement('span');
            primaryWrap.className = 'txn-peek-primary-wrap';
            handle.appendChild(primaryWrap);
        }
        if (!primaryWrap.querySelector('.txn-peek-primary:not(.txn-peek-primary-secondary)')) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'txn-peek-primary ' + (cfg.primaryClass || '');
            btn.setAttribute('aria-label', cfg.primaryLabel);
            btn.innerHTML = '<i class="fas ' + cfg.primaryIcon + '"></i><span class="txn-peek-primary-text">' + cfg.primaryLabel + '</span>';
            btn.addEventListener('click', function (e) {
                e.stopPropagation();
                if (cfg.onPrimary) cfg.onPrimary();
            });
            primaryWrap.appendChild(btn);
        }

        var labelEl = handle.querySelector('.txn-peek-label');
        if (labelEl && cfg.peekSheetLabel) labelEl.textContent = cfg.peekSheetLabel;

        var sheetObj = { panel: panel, backdrop: backdrop, handle: handle, cfg: cfg };
        if (cfg.key === 'purchase' && typeof syncPurchaseCreditPeek === 'function') syncPurchaseCreditPeek(sheetObj);
        if (cfg.key === 'pos' && typeof syncPosCreditPeek === 'function') syncPosCreditPeek(sheetObj);
        ensurePeekPayToggle(sheetObj);
        return sheetObj;
    }

    function ensurePeekPayToggle(sheet) {
        if (!sheet || !sheet.handle) return;
        var key = sheet.cfg && sheet.cfg.key;
        if (key !== 'pos' && key !== 'purchase') return;
        var wrap = sheet.handle.querySelector('.txn-peek-primary-wrap');
        if (!wrap) return;
        var leftoverFib = wrap.querySelector('.txn-peek-primary-fib');
        if (leftoverFib) leftoverFib.remove();
        var scope = key === 'purchase' ? 'purchase' : 'pos';
        function ensurePeekDeliveryBtn() {
            if (scope !== 'pos') return;
            if (wrap.querySelector('.cart-delivery-toggle-btn')) return;
            var delBtn = document.createElement('button');
            delBtn.type = 'button';
            delBtn.id = 'pos-peek-delivery-toggle';
            delBtn.className = 'cart-delivery-toggle-btn txn-peek-delivery-toggle';
            delBtn.setAttribute('aria-pressed', 'false');
            delBtn.setAttribute('title', 'گەهاندن');
            delBtn.innerHTML = '<i class="fas fa-truck" aria-hidden="true"></i><span class="cart-pay-method-lbl">گەهاندن</span>';
            delBtn.addEventListener('click', function (e) {
                e.stopPropagation();
                if (typeof window.setCartDeliveryOn === 'function') {
                    window.setCartDeliveryOn(!(typeof window.isCartDeliveryOn === 'function' && window.isCartDeliveryOn()));
                }
            });
            wrap.insertBefore(delBtn, wrap.firstChild);
        }
        if (wrap.querySelector('.cart-pay-method-toggle')) {
            ensurePeekDeliveryBtn();
            if (scope === 'pos' && typeof window.syncCartDeliveryUI === 'function') window.syncCartDeliveryUI();
            return;
        }
        var toggle = document.createElement('div');
        toggle.className = 'cart-pay-method-toggle txn-peek-pay-toggle';
        toggle.setAttribute('data-cart-pay', scope);
        toggle.setAttribute('role', 'group');
        toggle.setAttribute('aria-label', 'جۆرێ پارەدانێ');
        function makePayBtn(method, icon, label) {
            var b = document.createElement('button');
            b.type = 'button';
            b.className = 'cart-pay-method-btn' + (method === 'cash' ? ' is-active' : '');
            b.setAttribute('data-pay', method);
            b.setAttribute('title', label);
            b.setAttribute('aria-pressed', method === 'cash' ? 'true' : 'false');
            b.innerHTML = '<i class="fas ' + icon + '" aria-hidden="true"></i><span class="cart-pay-method-lbl">' + label + '</span>';
            b.addEventListener('click', function (e) {
                e.stopPropagation();
                if (typeof window.setCartPayMethod === 'function') window.setCartPayMethod(scope, method);
            });
            return b;
        }
        toggle.appendChild(makePayBtn('cash', 'fa-money-bill-wave', 'کاش'));
        toggle.appendChild(makePayBtn('fib', 'fa-university', 'FIB'));
        wrap.insertBefore(toggle, wrap.firstChild);
        ensurePeekDeliveryBtn();
        if (typeof window.setCartPayMethod === 'function') {
            window.setCartPayMethod(scope, typeof window.getCartPayMethod === 'function' ? window.getCartPayMethod(scope) : 'cash');
        }
        if (scope === 'pos' && typeof window.syncCartDeliveryUI === 'function') window.syncCartDeliveryUI();
    }

    function setSheetExpanded(sheet, expanded) {
        if (!sheet || !sheet.panel) return;
        sheet.panel.classList.toggle('txn-sheet-expanded', !!expanded);
        sheet.panel.classList.toggle('txn-sheet-collapsed', !expanded);
        if (sheet.handle) sheet.handle.setAttribute('aria-expanded', expanded ? 'true' : 'false');
        if (sheet.backdrop) sheet.backdrop.setAttribute('aria-hidden', expanded ? 'false' : 'true');
        syncBodySheetOpenLock();
    }

    function syncBodySheetOpenLock() {
        if (!isTxnMobile()) {
            document.body.classList.remove('txn-sheet-open');
            return;
        }
        var anyOpen = !!document.querySelector('.txn-sheet-panel.txn-sheet-expanded');
        document.body.classList.toggle('txn-sheet-open', anyOpen);
    }

    window.expandTxnSheetForActiveView = function () {
        if (!isTxnMobile()) return;
        var active = document.querySelector('.workspace.active');
        if (!active) return;
        var id = active.id || '';
        if (id.indexOf('view-') === 0) id = id.slice(5);
        if (TXN_VIEWS.indexOf(id) >= 0) window.expandTxnSheet(id);
    };

    window.expandTxnSheet = function (keyOrView) {
        if (!isTxnMobile()) return;
        var cfg = SHEET_CONFIGS.find(function (c) {
            return c.key === keyOrView || c.viewId === keyOrView;
        });
        if (!cfg) return;
        var sheet = sheetsByKey[cfg.key] || ensureSheetChrome(cfg);
        if (!sheet) return;
        sheetsByKey[cfg.key] = sheet;
        setSheetExpanded(sheet, true);
    };

    function collapseSheet(key) {
        var sheet = sheetsByKey[key];
        if (sheet) setSheetExpanded(sheet, false);
        else syncBodySheetOpenLock();
    }

    function collapseActiveTxnSheet() {
        TXN_VIEWS.forEach(function (vid) {
            var cfg = SHEET_CONFIGS.find(function (c) { return c.viewId === vid; });
            if (cfg) collapseSheet(cfg.key);
        });
        syncBodySheetOpenLock();
    }

    function toggleSheet(key) {
        var sheet = sheetsByKey[key];
        if (!sheet || !isTxnMobile()) return;
        var expanded = !sheet.panel.classList.contains('txn-sheet-expanded');
        setSheetExpanded(sheet, expanded);
    }

    function bounceSheet(key) {
        var sheet = sheetsByKey[key];
        if (!sheet || !sheet.panel || sheet.panel.classList.contains('txn-sheet-expanded')) return;
        sheet.panel.classList.remove('txn-sheet-bounce');
        void sheet.panel.offsetWidth;
        sheet.panel.classList.add('txn-sheet-bounce');
        setTimeout(function () {
            if (sheet.panel) sheet.panel.classList.remove('txn-sheet-bounce');
        }, 400);
    }

    function countCartRows(rowsEl) {
        if (!rowsEl) return 0;
        return rowsEl.querySelectorAll('.returns-cart-row, .bill-row').length;
    }

    function readTotalText(totalEl) {
        if (!totalEl) return '0';
        var t = totalEl.textContent || totalEl.innerText || '0';
        if (totalEl.dataset && totalEl.dataset.finalIqd != null && totalEl.dataset.finalIqd !== '') {
            var fmt = typeof window.formatCurrency === 'function' ? window.formatCurrency : String;
            try {
                return fmt(Number(totalEl.dataset.finalIqd));
            } catch (e) { /* ignore */ }
        }
        return t.trim() || '0';
    }

    window.updateTxnPeekBar = function (viewKey) {
        if (!isTxnMobile()) return;
        var cfg = SHEET_CONFIGS.find(function (c) { return c.viewId === viewKey || c.key === viewKey; });
        if (!cfg) return;
        var sheet = sheetsByKey[cfg.key];
        if (!sheet) sheet = ensureSheetChrome(cfg);
        if (!sheet) return;
        sheetsByKey[cfg.key] = sheet;

        var rowsEl = document.querySelector(cfg.rows);
        var totalEl = document.querySelector(cfg.total);
        var count = countCartRows(rowsEl);
        var countEl = sheet.handle && sheet.handle.querySelector('.txn-peek-count');
        var totalPeek = sheet.handle && sheet.handle.querySelector('.txn-peek-total');
        if (countEl) countEl.textContent = count + ' ئایتم';
        if (totalPeek) totalPeek.textContent = readTotalText(totalEl);
        var labelEl = sheet.handle && sheet.handle.querySelector('.txn-peek-label');
        if (labelEl) labelEl.textContent = cfg.peekSheetLabel || 'سەبەتە';
        var wrap = sheet && sheet.handle && sheet.handle.querySelector('.txn-peek-primary-wrap');
        if (wrap) {
            var secondary = wrap.querySelector('.txn-peek-primary-secondary');
            if (secondary) secondary.remove();
        }
        ensurePeekPayToggle(sheet);
        if (cfg.key === 'pos' && typeof window.applyCartDeliverySellLabel === 'function') {
            window.applyCartDeliverySellLabel();
        }
    };

    window.expandTxnMetaForView = function (viewId) {
        if (!isTxnMobile()) return;
        var view = document.getElementById('view-' + viewId);
        if (!view) return;
        var sticky = view.querySelector('.txn-meta-sticky');
        if (sticky) {
            sticky.classList.remove('is-collapsed');
            var toggle = sticky.querySelector('.txn-meta-toggle');
            if (toggle) toggle.setAttribute('aria-expanded', 'true');
        }
    };

    window.collapseTxnMetaForView = function (viewId) {
        if (!isTxnMobile()) return;
        var view = document.getElementById('view-' + viewId);
        if (!view) return;
        var sticky = view.querySelector('.txn-meta-sticky');
        if (!sticky) return;
        sticky.classList.add('is-collapsed');
        var toggle = sticky.querySelector('.txn-meta-toggle');
        if (toggle) toggle.setAttribute('aria-expanded', 'false');
    };

    window.maybeCollapseTxnMetaAfterValid = function (viewId, fieldIds) {
        if (!isTxnMobile() || !viewId) return;
        var ok = true;
        (fieldIds || []).forEach(function (id) {
            var el = document.getElementById(id);
            if (!el || !(String(el.value || '').trim())) ok = false;
        });
        if (ok) window.collapseTxnMetaForView(viewId);
    };

    window.refreshTxnScreen = function (viewId) {
        if (!viewId) return;
        applyBodyClass();
        initTxnToolbars();
        if (isTxnMobile()) {
            initTxnMobileSheets();
            window.resetTxnSheet(viewId);
            scrollTxnMenuToTop(viewId);
            markTxnCategoryTabsSticky();
            window.updateTxnPeekBar(viewId);
        } else if (viewId === 'pos' || viewId === 'purchase') {
            var metaKey = viewId === 'purchase' ? 'purchase' : 'pos';
            var sticky = document.querySelector('#view-' + viewId + ' .txn-meta-sticky[data-txn-meta="' + metaKey + '"]');
            if (sticky) sticky.classList.remove('is-collapsed');
        }
    };

    window.clearTxnMetaErrors = function (viewId) {
        var view = viewId ? document.getElementById('view-' + viewId) : null;
        var root = view || document;
        root.querySelectorAll('.txn-field-error').forEach(function (el) {
            el.classList.remove('txn-field-error');
        });
    };

    window.highlightTxnMetaFields = function (viewId, fieldIds) {
        if (!isTxnMobile()) return false;
        window.clearTxnMetaErrors(viewId);
        window.expandTxnMetaForView(viewId);
        var view = document.getElementById('view-' + viewId);
        if (!view) return false;
        var sticky = view.querySelector('.txn-meta-sticky');
        if (!sticky) return false;
        var ok = true;
        (fieldIds || []).forEach(function (id) {
            var el = document.getElementById(id);
            if (!el) return;
            var wrap = el.closest('.purchase-top-field') || el.parentElement;
            if (wrap) wrap.classList.add('txn-field-error');
            var val = (el.value || '').trim();
            if (!val) ok = false;
        });
        if (!ok) {
            sticky.classList.add('txn-field-error');
            try {
                sticky.scrollIntoView({ block: 'start', behavior: 'smooth' });
            } catch (e) { /* ignore */ }
        }
        return ok;
    };

    window.collapseTxnSheet = function (keyOrView) {
        if (!keyOrView) {
            collapseActiveTxnSheet();
            return;
        }
        var cfg = SHEET_CONFIGS.find(function (c) {
            return c.key === keyOrView || c.viewId === keyOrView;
        });
        if (cfg) collapseSheet(cfg.key);
        else collapseActiveTxnSheet();
    };

    window.resetTxnSheet = function (viewId) {
        if (!isTxnMobile()) return;
        SHEET_CONFIGS.forEach(function (cfg) {
            var sheet = sheetsByKey[cfg.key] || ensureSheetChrome(cfg);
            if (!sheet) return;
            sheetsByKey[cfg.key] = sheet;
            if (!viewId || cfg.viewId === viewId) {
                setSheetExpanded(sheet, false);
                window.updateTxnPeekBar(cfg.viewId);
            }
        });
    };

    function bindSheetEvents(sheet) {
        if (!sheet || !sheet.handle || sheet.handle._txnBound) return;
        sheet.handle._txnBound = true;

        sheet.handle.addEventListener('click', function (e) {
            if (e.target.closest('.txn-peek-primary, .txn-peek-pay-toggle, .cart-pay-method-toggle, .cart-delivery-toggle-btn')) return;
            toggleSheet(sheet.cfg.key);
        });

        sheet.backdrop.addEventListener('click', function () {
            setSheetExpanded(sheet, false);
        });

        var grip = sheet.handle;
        grip.addEventListener('pointerdown', function (e) {
            if (e.target.closest('.txn-peek-primary, .txn-peek-pay-toggle, .cart-pay-method-toggle, .cart-delivery-toggle-btn')) return;
            swipeState = {
                key: sheet.cfg.key,
                startY: e.clientY,
                expanded: sheet.panel.classList.contains('txn-sheet-expanded')
            };
            try { grip.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
        });
        grip.addEventListener('pointerup', function (e) {
            if (!swipeState || swipeState.key !== sheet.cfg.key) return;
            var dy = swipeState.startY - e.clientY;
            if (dy > 40) setSheetExpanded(sheet, true);
            else if (dy < -40) setSheetExpanded(sheet, false);
            swipeState = null;
        });
        grip.addEventListener('pointercancel', function () {
            swipeState = null;
        });
    }

    function initTxnMobileSheets() {
        applyBodyClass();
        if (!isTxnMobile()) {
            SHEET_CONFIGS.forEach(function (cfg) {
                var panel = getPanelEl(cfg);
                if (panel) {
                    panel.classList.remove('txn-sheet-panel', 'txn-sheet-expanded', 'txn-sheet-collapsed', 'txn-sheet-bounce');
                }
            });
            return;
        }

        SHEET_CONFIGS.forEach(function (cfg) {
            var sheet = ensureSheetChrome(cfg);
            if (!sheet) return;
            sheetsByKey[cfg.key] = sheet;
            if (!sheet.panel.classList.contains('txn-sheet-expanded')) {
                sheet.panel.classList.add('txn-sheet-collapsed');
            }
            bindSheetEvents(sheet);
            window.updateTxnPeekBar(cfg.viewId);
        });

        initTxnHeaderActions();
        initTxnToolbars();
        initTxnMetaAccordion();
        initTxnMetaDetailsToggle();
        bindCartInputExpand();
        markTxnCategoryTabsSticky();
    }

    function initTxnMetaAccordion() {
        if (!isTxnMobile()) return;
        document.querySelectorAll('.txn-meta-sticky .txn-meta-toggle').forEach(function (btn) {
            if (btn._txnMetaBound) return;
            btn._txnMetaBound = true;
            var sticky = btn.closest('.txn-meta-sticky');
            if (!sticky) return;
            btn.addEventListener('click', function (e) {
                e.stopPropagation();
                var collapsed = sticky.classList.toggle('is-collapsed');
                btn.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
            });
        });
    }

    function initTxnMetaDetailsToggle() {
        if (!isTxnMobile()) return;
        document.querySelectorAll('.txn-meta-details-toggle').forEach(function (btn) {
            if (btn._txnDetailsBound) return;
            btn._txnDetailsBound = true;
            btn.addEventListener('click', function () {
                var targetId = btn.getAttribute('data-txn-details');
                var row = targetId ? document.getElementById(targetId) : btn.nextElementSibling;
                if (!row || !row.classList.contains('returns-meta-row')) return;
                var hidden = row.classList.toggle('is-collapsed');
                btn.setAttribute('aria-expanded', hidden ? 'false' : 'true');
            });
        });
    }

    function markTxnCategoryTabsSticky() {
        if (!isTxnMobile()) return;
        ['returns-category-tabs', 'purchase-category-tabs', 'purchase-returns-category-tabs', 'category-tabs'].forEach(function (id) {
            var el = document.getElementById(id);
            if (el) el.classList.add('txn-cats-sticky');
        });
    }

    function scrollTxnMenuToTop(viewId) {
        if (!isTxnMobile() || !viewId) return;
        var view = document.getElementById('view-' + viewId);
        if (!view) return;
        var menu = view.querySelector('.returns-menu') || view.querySelector('.pos-menu');
        if (!menu) return;
        var scrollEl = menu.querySelector('.pos-content-wrapper') || menu.querySelector('[style*="overflow-y"]') || menu;
        try {
            scrollEl.scrollTop = 0;
            menu.scrollTop = 0;
        } catch (e) { /* ignore */ }
    }

    function bindCartInputExpand() {
        if (document.body._txnCartFocusBound) return;
        document.body._txnCartFocusBound = true;
        var selectors = [
            '#bill-rows input',
            '#bill-rows select',
            '#returns-bill-rows input',
            '#purchase-cart-rows input',
            '#purchase-returns-cart-rows input',
            '.returns-bill-footer input',
            '.returns-bill-footer select',
            '.bill-footer input'
        ].join(',');
        document.addEventListener('focusin', function (e) {
            if (!isTxnMobile()) return;
            var t = e.target;
            if (!t || !t.matches || !t.matches(selectors)) return;
            var panel = t.closest('.txn-sheet-panel');
            if (!panel) return;
            var cfg = SHEET_CONFIGS.find(function (c) {
                return panel.matches(c.panel);
            });
            if (cfg) {
                var sheet = sheetsByKey[cfg.key] || ensureSheetChrome(cfg);
                if (sheet) {
                    sheetsByKey[cfg.key] = sheet;
                    setSheetExpanded(sheet, true);
                    setTimeout(function () {
                        try {
                            t.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
                        } catch (err) { /* ignore */ }
                    }, 320);
                }
            }
        });
    }

    function initTxnHeaderActions() {
        document.querySelectorAll('.txn-screen-head-actions').forEach(function (actions) {
            if (actions.querySelector('.txn-header-actions-more')) return;
            var btns = actions.querySelectorAll(':scope > .btn');
            if (btns.length < 2) return;
            var more = document.createElement('div');
            more.className = 'txn-toolbar-more txn-header-actions-more no-print';
            btns.forEach(function (btn) { more.appendChild(btn); });
            var toggle = document.createElement('button');
            toggle.type = 'button';
            toggle.className = 'btn btn-sm btn-dark txn-toolbar-toggle no-print';
            toggle.setAttribute('title', 'زیاتر');
            toggle.innerHTML = '<i class="fas fa-ellipsis-h"></i>';
            actions.appendChild(toggle);
            actions.appendChild(more);
        });
    }

    function findToolbarMore(toggle) {
        var wrap = toggle.closest('.pos-header-toolbar, .pos-top-bar-actions, .pos-top-bar, .returns-top-bar, .txn-view-top-bar, .txn-search-bar');
        if (wrap) {
            var inWrap = wrap.querySelector('.txn-toolbar-more');
            if (inWrap) return inWrap;
        }
        var sib = toggle.nextElementSibling;
        if (sib && sib.classList && sib.classList.contains('txn-toolbar-more')) return sib;
        var prev = toggle.previousElementSibling;
        if (prev && prev.classList && prev.classList.contains('txn-toolbar-more')) return prev;
        return null;
    }

    function closeAllTxnToolbars() {
        document.querySelectorAll('.txn-toolbar-more.is-open').forEach(function (more) {
            more.classList.remove('is-open');
        });
        document.querySelectorAll('.txn-toolbar-toggle[aria-expanded="true"]').forEach(function (btn) {
            btn.setAttribute('aria-expanded', 'false');
        });
    }

    function syncPosHeaderToolbar() {
        var toolbar = document.querySelector('#view-pos .pos-header-toolbar');
        if (!toolbar) return;
        var more = toolbar.querySelector('.txn-toolbar-more');
        var toggle = toolbar.querySelector('.txn-toolbar-toggle');
        if (!more || !toggle) return;
        toolbar.classList.add('pos-toolbar-overflow');
        more.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
    }

    function initTxnToolbars() {
        document.querySelectorAll('.txn-toolbar-toggle').forEach(function (toggle) {
            if (toggle._txnBound) return;
            var more = findToolbarMore(toggle);
            if (!more) return;
            toggle._txnBound = true;
            toggle.setAttribute('aria-expanded', 'false');
            toggle.addEventListener('click', function (e) {
                e.stopPropagation();
                var open = !more.classList.contains('is-open');
                closeAllTxnToolbars();
                if (open) {
                    more.classList.add('is-open');
                    toggle.setAttribute('aria-expanded', 'true');
                }
            });
        });
        if (!document._txnToolbarDocBound) {
            document._txnToolbarDocBound = true;
            document.addEventListener('click', function (e) {
                if (e.target.closest('.txn-toolbar-more, .txn-toolbar-toggle')) return;
                closeAllTxnToolbars();
            });
        }
        syncPosHeaderToolbar();
    }

    function hookNav() {
        if (typeof window.nav !== 'function' || window._txnMobileNavHooked) return;
        window._txnMobileNavHooked = true;
        var oldNav = window.nav;
        window.nav = function (id, fromBreadcrumb) {
            oldNav(id, fromBreadcrumb);
            if (TXN_VIEWS.indexOf(id) >= 0) {
                setTimeout(function () {
                    if (typeof window.refreshTxnScreen === 'function') {
                        window.refreshTxnScreen(id === 'returns-new' ? 'returns-new' : id);
                    } else {
                        window.resetTxnSheet(id === 'returns-new' ? 'returns-new' : id);
                        scrollTxnMenuToTop(id);
                        markTxnCategoryTabsSticky();
                    }
                    if (id === 'pos' && typeof syncPosHeaderToolbar === 'function') {
                        syncPosHeaderToolbar();
                    }
                }, 50);
            } else if (isTxnMobile()) {
                collapseActiveTxnSheet();
            }
        };
    }

    function onMediaChange() {
        initTxnMobileSheets();
        initTxnToolbars();
        syncPosHeaderToolbar();
        if (!isTxnMobile()) collapseActiveTxnSheet();
    }

    var resizeTxnTimer = null;
    function debouncedTxnMobileRefresh() {
        if (resizeTxnTimer) clearTimeout(resizeTxnTimer);
        resizeTxnTimer = setTimeout(function () {
            resizeTxnTimer = null;
            applyBodyClass();
            initTxnMobileSheets();
            initTxnToolbars();
            syncPosHeaderToolbar();
        }, 150);
    }

    mq.addEventListener('change', onMediaChange);
    window.addEventListener('resize', debouncedTxnMobileRefresh);
    window.addEventListener('orientationchange', function () {
        setTimeout(function () {
            initTxnMobileSheets();
            initTxnToolbars();
        }, 120);
    });

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
            initTxnMobileSheets();
            initTxnToolbars();
            hookNav();
        });
    } else {
        initTxnMobileSheets();
        initTxnToolbars();
        hookNav();
    }

    window.initTxnMobileSheets = initTxnMobileSheets;
    window.initTxnToolbars = initTxnToolbars;
    window.syncPosHeaderToolbar = syncPosHeaderToolbar;
    window.bounceTxnSheet = bounceSheet;

    window.isTxnMobileViewport = isTxnMobile;
})();
