        <!-- PRODUCTS DEFINITION VIEW -->
        <div id="view-products" class="workspace">
            <div class="products-view-header">
                <h2 class="products-view-title"><i class="fas fa-box-open"></i> <span data-i18n="view_products_title">زێدەکرنا ئایتمان</span></h2>
                <button type="button" id="btn-product-tutorial" class="btn-product-tutorial" onclick="if(typeof posProductTutorialStart==='function')posProductTutorialStart();" data-i18n-title="product_tutorial_btn_title" title="فێرکردن — گام بە گام فێری زێدەکرنا ئایتم ببە">
                    <i class="fas fa-graduation-cap"></i> <span data-i18n="product_tutorial_btn">فێرکردن</span>
                </button>
            </div>

            <!-- Product add-item spotlight tutorial -->
            <div id="pos-product-tutorial-overlay" class="pos-spotlight-tutorial" style="display:none;" hidden aria-hidden="true">
                <div class="pos-spotlight-dim" data-dim="top"></div>
                <div class="pos-spotlight-dim" data-dim="left"></div>
                <div class="pos-spotlight-dim" data-dim="right"></div>
                <div class="pos-spotlight-dim" data-dim="bottom"></div>
                <div id="pos-product-tutorial-ring" class="pos-spotlight-ring" aria-hidden="true"></div>
                <aside id="pos-product-tutorial-visual" class="pos-product-tutorial-visual" hidden aria-hidden="true">
                    <div class="pos-product-tutorial-visual-head">
                        <i class="fas fa-images"></i>
                        <span data-i18n="product_tutorial_visual_heading">ڕوونکردنەوە</span>
                    </div>
                    <div class="pos-tutorial-visual-grid">
                        <article class="pos-tutorial-visual-card pos-tutorial-visual-card--piece" data-unit="piece">
                            <div class="pos-tutorial-visual-icon-wrap">
                                <i class="fas fa-cube pos-tutorial-visual-icon" aria-hidden="true"></i>
                                <span class="pos-tutorial-visual-badge">×١</span>
                            </div>
                            <strong data-i18n="product_tutorial_visual_piece">تاک (دانە)</strong>
                            <p data-i18n="product_tutorial_visual_piece_desc">یەک شت — وەک ١ بطڵ، ١ قوتو، ١ دانە.</p>
                        </article>
                        <article class="pos-tutorial-visual-card pos-tutorial-visual-card--pack" data-unit="pack">
                            <div class="pos-tutorial-visual-icon-wrap">
                                <i class="fas fa-boxes pos-tutorial-visual-icon" aria-hidden="true"></i>
                                <span class="pos-tutorial-visual-badge">×٦</span>
                            </div>
                            <strong data-i18n="product_tutorial_visual_pack">پاکێت</strong>
                            <p data-i18n="product_tutorial_visual_pack_desc">چەند دانە کۆکراون — وەک ٦ بطڵ لە پاکێتێکدا.</p>
                        </article>
                        <article class="pos-tutorial-visual-card pos-tutorial-visual-card--carton" data-unit="carton">
                            <div class="pos-tutorial-visual-icon-wrap">
                                <i class="fas fa-box pos-tutorial-visual-icon" aria-hidden="true"></i>
                                <span class="pos-tutorial-visual-badge">×١٢</span>
                            </div>
                            <strong data-i18n="product_tutorial_visual_carton">کارتۆن</strong>
                            <p data-i18n="product_tutorial_visual_carton_desc">چەند پاکێت کۆکراون — وەک ١٢ پاکێت لە کارتۆنێکدا.</p>
                        </article>
                    </div>
                    <div class="pos-tutorial-visual-diagram" aria-hidden="true">
                        <span class="pos-tutorial-diagram-node pos-tutorial-diagram-node--piece"><i class="fas fa-cube"></i></span>
                        <span class="pos-tutorial-diagram-arrow">→</span>
                        <span class="pos-tutorial-diagram-node pos-tutorial-diagram-node--pack"><i class="fas fa-boxes"></i></span>
                        <span class="pos-tutorial-diagram-arrow">→</span>
                        <span class="pos-tutorial-diagram-node pos-tutorial-diagram-node--carton"><i class="fas fa-box"></i></span>
                    </div>
                    <p id="pos-product-tutorial-visual-caption" class="pos-product-tutorial-visual-caption"></p>
                </aside>
                <div id="pos-product-tutorial-tooltip" class="pos-spotlight-tooltip" role="dialog" aria-live="polite">
                    <div class="pos-spotlight-tooltip-top">
                        <span id="pos-product-tutorial-badge" class="pos-spotlight-badge">١</span>
                        <span id="pos-product-tutorial-progress" class="pos-spotlight-progress">١ / ١٢</span>
                    </div>
                    <div class="pos-spotlight-tooltip-body">
                        <strong id="pos-product-tutorial-title"></strong>
                        <p id="pos-product-tutorial-hint"></p>
                    </div>
                    <div class="pos-spotlight-tooltip-actions">
                        <button type="button" id="pos-product-tutorial-skip" class="btn btn-sm btn-dark"><span data-i18n="product_tutorial_skip">تێپەڕاندن</span></button>
                        <button type="button" id="pos-product-tutorial-next" class="btn btn-sm btn-brand"><span data-i18n="product_tutorial_next">دواتر</span></button>
                    </div>
                </div>
                <div id="pos-product-tutorial-success" class="pos-spotlight-success" style="display:none;">
                    <div class="pos-spotlight-success-card">
                        <span class="pos-spotlight-success-icon"><i class="fas fa-check-circle"></i></span>
                        <strong data-i18n="product_tutorial_success_title">تەواو بوو!</strong>
                        <p data-i18n="product_tutorial_success_msg">ئێستا دەتوانیت بە ئاسانی ئایتم زیاد بکەیت. دووبارە «فێرکردن» بگرە بۆ بینینەوە.</p>
                        <button type="button" id="pos-product-tutorial-close" class="btn btn-brand"><span data-i18n="product_tutorial_close">داخستن</span></button>
                    </div>
                </div>
            </div>

            <!-- Shop default currency (always editable; each product can still be IQD or USD) -->
            <div id="products-catalog-currency-panel" class="card currency-mode-panel" data-allow-iqd="1" style="margin-bottom:16px; border-top:4px solid #f59e0b; padding:12px 16px;">
                <div id="products-catalog-currency-unlocked-block">
                    <div class="currency-mode-panel-inner">
                        <div class="currency-mode-panel-text">
                            <strong data-i18n="shop_default_currency">دراڤێ بنەڕەتی دکانێ</strong>
                            <p class="currency-mode-panel-hint" data-i18n="shop_default_currency_hint">دراڤێ نیشاندان و فۆرما ئایتمێ نوو. هەر کەرەستەیەک دشێت دینار یان دولار بیت.</p>
                        </div>
                        <div class="currency-mode-choices" role="radiogroup" aria-label="دراڤێ بنەڕەتی">
                            <label class="currency-mode-choice">
                                <input type="radio" name="products-catalog-currency-mode" id="products-catalog-currency-iqd" value="IQD" checked onchange="if(typeof applyProductsCatalogCurrency==='function')applyProductsCatalogCurrency();">
                                <span class="currency-mode-choice-body">
                                    <span class="currency-mode-choice-title" data-i18n="currency_iqd">دیناری عێراقی (IQD)</span>
                                    <span class="currency-mode-choice-sub" data-i18n="currency_iqd_sub">نرخ و پارەدان بە دینار — باوە ل عێراق</span>
                                </span>
                            </label>
                            <label class="currency-mode-choice">
                                <input type="radio" name="products-catalog-currency-mode" id="products-catalog-currency-usd" value="USD" onchange="if(typeof applyProductsCatalogCurrency==='function')applyProductsCatalogCurrency();">
                                <span class="currency-mode-choice-body">
                                    <span class="currency-mode-choice-title" data-i18n="currency_usd_label">دۆلاری ئەمریکی (USD)</span>
                                    <span class="currency-mode-choice-sub" data-i18n="currency_usd_sub">نرخ بە دۆلار — پێویستە نرخی گۆڕین دابنێیت</span>
                                </span>
                            </label>
                        </div>
                    </div>
                </div>
                <div id="products-catalog-currency-locked-block" style="display:none;">
                    <p style="margin:0; font-size:0.9rem; color:var(--text-muted);" data-i18n="inventory_base_currency_locked">کەلوپەل تۆمارکراوە — دراڤێ بنەڕەتی ناگۆڕدرێت بۆ پاراستنی حسابەکان.</p>
                </div>
            </div>

            <div class="card" id="product-form-card" style="direction:rtl;" autocomplete="off">
                <input type="hidden" id="p-id">
                <input type="hidden" id="p-unit-structure" value="carton_pack_piece">
                <input type="hidden" id="p-unit-show-pack" value="0">
                <input type="hidden" id="p-unit-show-carton" value="0">
                <input type="checkbox" id="p-multi-barcode" style="display:none;">

                <div id="layout-step-indicator" class="step-indicator" data-layout-id="layout-step-indicator" style="display:flex; align-items:center; gap:12px; flex-wrap:wrap;">
                    <span class="step-dot active" id="step-dot-1" role="button" tabindex="0" onclick="productFormGoToStep(1)" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();productFormGoToStep(1);}">1</span>
                    <span class="step-dot" id="step-dot-2" role="button" tabindex="0" onclick="productFormGoToStep(2)" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();productFormGoToStep(2);}">2</span>
                    <button type="button" id="btn-product-form-all-steps" class="btn btn-sm" style="margin:0; padding:6px 10px;" onclick="toggleProductFormAllSteps()" aria-pressed="false" data-i18n-title="product_form_all_steps_title" title="هەردوو ئاست پێکڤە — هەمی خانە دیار بن"><i class="fas fa-filter"></i> <span data-i18n="product_form_all_steps_btn">فلتر</span></button>
                    <button type="button" id="btn-product-layout" class="btn btn-sm" style="margin:0; padding:6px 10px;" onclick="openProductLayoutManager()" data-i18n-title="product_form_layout_btn_tooltip" title="ڕێکخستن (Alt+F1/F2، Alt+S پاراستن، Alt+Enter داهاتوو)"><i class="fas fa-pen"></i> <span data-i18n="product_form_layout_btn">ڕێکخستن</span></button>
                    <button type="button" id="btn-product-form-clear" class="btn btn-sm" style="margin:0; padding:6px 10px;" onclick="clearProductFormForNewItem()" data-i18n-title="product_form_clear_title" title="هەمی خانە بسڕە — ئایتمێ نوو"><i class="fas fa-eraser"></i> <span data-i18n="product_form_clear_btn">مساح</span></button>
                </div>

                <!-- STEP 1: زانیاری سەرەتایی + تاک/پاکێت/کارتۆن + خشتەی یەکە/بارکۆد/کرین/فرۆتن/کۆگە + بەروار -->
                <div id="product-form-step-1" class="product-form-step active" data-layout-id="layout-step2">
                    <div class="form-section">
                        <div class="form-section-title product-form-section-title" data-layout-id="layout-section-titles"><i class="fas fa-info-circle"></i> <span data-i18n="product_form_section_basic">زانیاریێن سەرەتایی</span></div>
                        <label class="product-form-label" data-layout-id="layout-labels"><i class="fas fa-barcode"></i> <span data-i18n="product_form_label_barcode">بارکۆد</span></label>
                        <div style="display:flex; flex-wrap:wrap; gap:6px; align-items:center;">
                            <input type="text" id="p-barcode" class="input-std" placeholder="—" style="flex:1; min-width:120px;" autocomplete="off" onkeydown="handleProductFormEnter(event)" oninput="if(typeof syncBarcodeToPieceCell==='function') syncBarcodeToPieceCell();">
                            <button type="button" class="btn btn-info btn-sm" onclick="autoGenerateProductBarcode()" onkeydown="handleProductFormEnter(event)"><i class="fas fa-magic"></i> <span data-i18n="product_form_btn_auto">ئۆتۆ</span></button>
                        </div>
                        <input type="hidden" id="p-sku" value="">
                        <div style="display:flex; align-items:center; justify-content:space-between; gap:8px; flex-wrap:wrap;">
                            <label class="product-form-label" data-layout-id="layout-labels" style="margin:0;"><i class="fas fa-tag"></i> <span data-i18n="product_form_label_name">ناڤێ ئایتمی</span> <span id="p-name-required-mark" style="color:var(--danger);">*</span></label>
                            <label for="p-allow-no-name" style="display:flex; align-items:center; gap:6px; margin:0; font-size:0.8rem; cursor:pointer; white-space:nowrap;">
                                <input type="checkbox" id="p-allow-no-name" onchange="if(typeof syncProductNameOptionalUi==='function')syncProductNameOptionalUi();">
                                <span data-i18n="product_form_allow_no_name">بێ ناو (بارکۆد + نرخ)</span>
                            </label>
                        </div>
                        <input type="text" id="p-name" class="input-std" data-i18n-placeholder="product_form_name_placeholder" placeholder="ناڤ" autocomplete="off" onkeydown="handleProductFormEnter(event)">
                        <p id="p-name-optional-hint" class="product-form-optional-desc" style="display:none; font-size:0.72rem; color:var(--text-muted); margin:4px 0 0 0;"><i class="fas fa-info-circle"></i> <span data-i18n="product_form_allow_no_name_hint">ئەگەر ناو نەنووسیت، بارکۆد و نرخ دێ بنە ناڤێ ئایتمی.</span></p>
                        <div id="p-base-currency-row" class="product-form-currency-row" data-layout-id="layout-optional-item-currency" data-allow-iqd="1" style="margin:10px 0 4px 0;">
                            <label class="product-form-label" style="margin-bottom:6px;"><i class="fas fa-coins"></i> <span data-i18n="product_form_currency_label">دراڤێ نرخێ ڤێ کەرەستەی</span></label>
                            <div class="currency-mode-choices currency-mode-choices--compact" role="radiogroup">
                                <label class="currency-mode-choice">
                                    <input type="radio" name="p-base-currency" id="p-base-currency-iqd" value="IQD" onchange="if(typeof onProductFormCurrencyChange==='function')onProductFormCurrencyChange();">
                                    <span class="currency-mode-choice-body">
                                        <span class="currency-mode-choice-title" data-i18n="currency_iqd">دیناری عێراقی (IQD)</span>
                                    </span>
                                </label>
                                <label class="currency-mode-choice">
                                    <input type="radio" name="p-base-currency" id="p-base-currency-usd" value="USD" onchange="if(typeof onProductFormCurrencyChange==='function')onProductFormCurrencyChange();">
                                    <span class="currency-mode-choice-body">
                                        <span class="currency-mode-choice-title" data-i18n="currency_usd_label">دۆلاری ئەمریکی (USD)</span>
                                    </span>
                                </label>
                            </div>
                        </div>
                        <details id="p-tech-specs-box" class="product-tech-specs-box" style="display:none; margin:10px 0 4px 0; padding:8px 10px; border:1px dashed var(--brand); border-radius:10px; background:rgba(14,74,255,0.05);">
                            <summary style="cursor:pointer; font-weight:700; color:var(--brand); list-style:none; display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                                <i class="fas fa-microchip"></i>
                                <span data-i18n="product_form_tech_specs_title">مواسفات — لاپتۆب / مۆبایل</span>
                                <span style="font-weight:500; font-size:0.78rem; color:var(--text-muted);" data-i18n="product_form_tech_specs_optional">(Pro · $50)</span>
                            </summary>
                            <p style="margin:8px 0 8px 0; font-size:0.78rem; color:var(--text-muted);">
                                <i class="fas fa-info-circle"></i>
                                <span data-i18n="product_form_tech_specs_hint">ناڤێ ئایتمی کورت بهێلە (مۆدێل). CPU / RAM / GPU / شاشە ل خوارێ — لزگە خۆکار ڕێک دکەت.</span>
                            </p>
                            <button type="button" class="btn btn-sm btn-info" style="margin:0 0 8px 0;" onclick="if(typeof applyTechSpecsParseFromName==='function')applyTechSpecsParseFromName()">
                                <i class="fas fa-magic"></i> <span data-i18n="product_form_tech_specs_parse">ژ ناڤێ ئایتمی جودا بکە</span>
                            </button>
                            <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
                                <div style="grid-column:1 / -1;">
                                    <label class="product-form-label" for="p-spec-summary"><span data-i18n="product_form_spec_summary">کورت (وەک 10TH R|8 SSD|256)</span></label>
                                    <input type="text" id="p-spec-summary" class="input-std" dir="ltr" placeholder="10TH R|8 SSD|256" autocomplete="off" onkeydown="handleProductFormEnter(event)">
                                </div>
                                <div>
                                    <label class="product-form-label" for="p-spec-cpu">CPU</label>
                                    <input type="text" id="p-spec-cpu" class="input-std" dir="ltr" placeholder="CORE i5 10TH GEN" autocomplete="off" onkeydown="handleProductFormEnter(event)">
                                </div>
                                <div>
                                    <label class="product-form-label" for="p-spec-ram">RAM</label>
                                    <input type="text" id="p-spec-ram" class="input-std" dir="ltr" placeholder="8 GB" autocomplete="off" onkeydown="handleProductFormEnter(event)">
                                </div>
                                <div>
                                    <label class="product-form-label" for="p-spec-storage"><span data-i18n="product_form_spec_storage">هارد / SSD</span></label>
                                    <input type="text" id="p-spec-storage" class="input-std" dir="ltr" placeholder="SSD 256 GB" autocomplete="off" onkeydown="handleProductFormEnter(event)">
                                </div>
                                <div>
                                    <label class="product-form-label" for="p-spec-gpu">GPU</label>
                                    <input type="text" id="p-spec-gpu" class="input-std" dir="ltr" placeholder="INTEL 4 GB SHARE" autocomplete="off" onkeydown="handleProductFormEnter(event)">
                                </div>
                                <div>
                                    <label class="product-form-label" for="p-spec-screen"><span data-i18n="product_form_spec_screen">شاشە / SIZE</span></label>
                                    <input type="text" id="p-spec-screen" class="input-std" dir="ltr" placeholder="14.1 INCHES FHD" autocomplete="off" onkeydown="handleProductFormEnter(event)">
                                </div>
                                <div>
                                    <label class="product-form-label" for="p-spec-extra"><span data-i18n="product_form_spec_extra">تێبینی (باتری / کامێرا…)</span></label>
                                    <input type="text" id="p-spec-extra" class="input-std" dir="ltr" placeholder="" autocomplete="off" onkeydown="handleProductFormEnter(event)">
                                </div>
                            </div>
                        </details>
                        <label class="product-form-label" data-layout-id="layout-labels"><i class="fas fa-folder"></i> <span data-i18n="product_form_label_category">پۆل</span></label>
                        <div id="layout-category-btns" class="product-category-btns-wrap" data-layout-id="layout-category-btns">
                            <div class="product-category-field-row">
                                <input type="text" id="p-cat" class="input-std product-category-readonly" readonly data-i18n-placeholder="product_form_cat_placeholder" placeholder="پۆلێک ل ژێرەوە هەڵبژێرە" data-i18n-title="product_form_cat_field_title" title="تەنها هەڵبژاردن بە دوگمە؛ Backspace یان × بۆ سڕینەوەی هەموو پۆلێک" autocomplete="off" onkeydown="handleProductCategoryFieldKeydown(event); handleProductFormEnter(event);" onpaste="return false;" ondrop="return false;" ondragover="event.preventDefault();" inputmode="none">
                                <button type="button" id="btn-p-cat-clear" class="btn btn-sm btn-dark product-cat-clear-btn" style="display:none;" onclick="clearProductCategoryField()" data-i18n-title="product_form_cat_clear_title" title="سڕینەوەی پۆل" onkeydown="handleProductFormEnter(event)"><i class="fas fa-times"></i></button>
                                <button type="button" class="btn btn-info btn-sm" onclick="addCategory()" onkeydown="handleProductFormEnter(event)"><i class="fas fa-plus"></i></button>
                                <button type="button" class="btn btn-warning btn-sm" onclick="manageCategory()" data-i18n-title="product_form_manage_cat_title" title="دەستکاریکردن / سڕینەوە" onkeydown="handleProductFormEnter(event)"><i class="fas fa-pen"></i></button>
                            </div>
                            <div id="p-cat-pills" class="product-cat-pills" data-i18n-aria-label="product_form_cat_pills_label" aria-label="پۆلەکان"></div>
                        </div>
                        <!-- Jewelry essentials: Step 1 when systemMode=jewelry -->
                        <div id="p-jewelry-section" class="jewelry-only form-section" style="display:none; margin:12px 0; padding:10px; border:1px dashed #c9a227; border-radius:10px; background:rgba(201,162,39,0.08);">
                            <div class="form-section-title product-form-section-title" style="margin-bottom:8px; color:#a67c00;"><i class="fas fa-gem"></i> جۆرێ ئایتم</div>
                            <div style="margin-bottom:12px;">
                                <label class="product-form-label" for="p-jewelry-entry-kind"><i class="fas fa-exchange-alt"></i> زیڤە یان جەدوەلی دانە؟</label>
                                <select id="p-jewelry-entry-kind" class="input-std" onchange="if(typeof syncJewelryEntryKindUi==='function')syncJewelryEntryKindUi()">
                                    <option value="metal" selected>زیڤ / زێر — بە گرام (نرخی ڕۆژانە)</option>
                                    <option value="piece">جەدوەلی دانە — سەعات و شت (نرخی جێگیر)</option>
                                </select>
                                <p style="margin:6px 0 0 0; font-size:0.78rem; color:var(--text-muted);"><i class="fas fa-info-circle"></i> سەعات، قفڵ، قوطی… → جەدوەلی دانە. زێر/زیڤ → بە گرام.</p>
                            </div>
                            <div id="p-jewelry-metal-fields">
                            <div class="form-section-title product-form-section-title" style="margin-bottom:8px; color:#a67c00; font-size:0.95rem;"><i class="fas fa-coins"></i> زیڤ و زێر</div>
                            <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
                                <div>
                                    <label class="product-form-label" for="p-metal-type"><i class="fas fa-coins"></i> جۆر</label>
                                    <select id="p-metal-type" class="input-std" onchange="if(typeof syncJewelryFormMetalUi==='function')syncJewelryFormMetalUi()">
                                        <option value="silver" selected>زیڤ</option>
                                        <option value="gold">زێر</option>
                                    </select>
                                </div>
                                <div id="p-karat-wrap">
                                    <label class="product-form-label" for="p-karat" id="p-karat-label"><i class="fas fa-certificate"></i> <span id="p-karat-label-text">عیار</span></label>
                                    <div style="display:flex; gap:6px; align-items:stretch;">
                                        <select id="p-karat" class="input-std" style="flex:1;" onchange="if(typeof syncJewelryFormPreview==='function')syncJewelryFormPreview(); if(typeof syncJewelrySetPricingFromGrams==='function')syncJewelrySetPricingFromGrams();">
                                            <option value="18">18</option>
                                            <option value="21" selected>21</option>
                                            <option value="22">22</option>
                                            <option value="24">24</option>
                                        </select>
                                        <button type="button" id="p-silver-grade-add-btn" class="btn btn-sm btn-brand" style="display:none; white-space:nowrap;" onclick="if(typeof promptAddSilverGrade==='function')promptAddSilverGrade()" title="دەرجەی نوێ بۆ زیڤ"><i class="fas fa-plus"></i> زیادە</button>
                                    </div>
                                </div>
                                <div id="p-weight-grams-wrap">
                                    <label class="product-form-label" for="p-weight-grams"><i class="fas fa-weight-hanging"></i> کێش (گرام)</label>
                                    <input type="number" id="p-weight-grams" class="input-std" min="0" step="0.001" placeholder="0.000" dir="ltr" oninput="if(typeof syncJewelryFormPreview==='function')syncJewelryFormPreview()" onkeydown="handleProductFormEnter(event)">
                                </div>
                                <div id="p-making-charge-wrap">
                                    <label class="product-form-label" for="p-making-charge"><i class="fas fa-hammer"></i> کرێی کار</label>
                                    <input type="number" id="p-making-charge" class="input-std" min="0" step="1" placeholder="0" dir="ltr" oninput="if(typeof syncJewelryFormPreview==='function')syncJewelryFormPreview(); if(typeof syncJewelrySetPricingFromGrams==='function')syncJewelrySetPricingFromGrams();" onkeydown="handleProductFormEnter(event)">
                                </div>
                                <div style="grid-column:1 / -1;">
                                    <label class="product-form-label" for="p-jewelry-price-mode"><i class="fas fa-tags"></i> شێوازێ نرخێ</label>
                                    <select id="p-jewelry-price-mode" class="input-std" onchange="this.dataset.userPicked='1'; if(typeof syncJewelryFormPreview==='function')syncJewelryFormPreview(); if(typeof syncJewelrySimpleMoneyUi==='function')syncJewelrySimpleMoneyUi();">
                                        <option value="by_weight" selected>بە گرام (نرخی ڕۆژانە)</option>
                                        <option value="fixed">نرخی ئامادە</option>
                                    </select>
                                </div>
                            </div>
                            <div id="p-jewelry-price-preview" style="display:none; margin-top:8px; font-size:0.9rem; color:#a67c00;"></div>
                            <!-- Simple buy / sell / stock — jewelry metal shops -->
                            <div id="p-jewelry-simple-money" style="margin-top:12px; padding-top:10px; border-top:1px dashed rgba(201,162,39,0.45);">
                                <div class="form-section-title product-form-section-title" style="margin-bottom:8px; color:#a67c00; font-size:0.95rem;"><i class="fas fa-money-bill-wave"></i> فرۆشتن و کۆگە</div>
                                <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
                                    <div id="p-jewelry-sell-field-wrap">
                                        <label class="product-form-label" for="p-jewelry-price"><i class="fas fa-tag"></i> فرۆشتن</label>
                                        <input type="text" inputmode="numeric" id="p-jewelry-price" class="input-std pos-money-input" placeholder="بهای فرۆشتن" dir="ltr" oninput="if(typeof syncJewelryMoneyFromSimple==='function')syncJewelryMoneyFromSimple('price')" onkeydown="handleProductFormEnter(event)">
                                    </div>
                                    <div>
                                        <label class="product-form-label" for="p-jewelry-stock"><i class="fas fa-cubes"></i> کۆگەه (دانە)</label>
                                        <input type="number" id="p-jewelry-stock" class="input-std" min="0" step="1" placeholder="چەند دانە هەیە؟ وەک ٥" dir="ltr" oninput="if(typeof syncJewelryMoneyFromSimple==='function')syncJewelryMoneyFromSimple('stock')" onkeydown="handleProductFormEnter(event)">
                                    </div>
                                </div>
                                <input type="hidden" id="p-jewelry-cost" value="">
                                <p style="margin:6px 0 0 0; font-size:0.8rem; color:#a67c00;"><i class="fas fa-info-circle"></i> نرخی کڕینی گرام لە شاشەی فرۆشتن (ئایکۆنی زیڤ/زێر) دابنێ — لێرە پێویست نییە.</p>
                                <p id="p-jewelry-sell-hint" style="display:none; margin:6px 0 0 0; font-size:0.8rem; color:#a67c00;">فرۆشتن = گرام × نرخی ڕۆژ + کرێی کار (خۆکار)</p>
                            </div>
                            <div id="p-jewelry-set-box" style="margin-top:12px; padding-top:10px; border-top:1px dashed rgba(201,162,39,0.45);">
                                <label style="display:flex; align-items:center; gap:8px; margin:0 0 8px 0; font-weight:bold; color:#a67c00;">
                                    <input type="checkbox" id="p-jewelry-sell-set" style="width:16px; height:16px;" onchange="if(typeof syncJewelrySetFormUi==='function')syncJewelrySetFormUi()">
                                    <span><i class="fas fa-layer-group"></i> ئەم ئایتمە سێتە</span>
                                </label>
                                <div id="p-jewelry-set-fields" style="display:none;">
                                    <p style="margin:0 0 8px 0; font-size:0.85rem; color:var(--text-muted);">
                                        ٢ گووهار = یەک ڕیز (دانە = ٢) · گرام = کێشی ئەو ڕیزە · نرخی کڕین خۆکار ژ گرام · نرخی تاک ژ بهای سێت.
                                    </p>
                                    <div style="overflow-x:auto;">
                                        <table class="report-table" style="width:100%; margin:0;">
                                            <thead>
                                                <tr>
                                                    <th style="text-align:right;">جۆر</th>
                                                    <th style="text-align:right;">ناڤ</th>
                                                    <th style="text-align:right;">بارکۆد</th>
                                                    <th style="text-align:right;">دانە</th>
                                                    <th style="text-align:right;">گرام</th>
                                                    <th style="text-align:right;">نرخی تاک</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody id="p-jewelry-set-members-body"></tbody>
                                        </table>
                                    </div>
                                    <div style="display:flex; gap:8px; flex-wrap:wrap; margin-top:8px;">
                                        <button type="button" class="btn btn-sm btn-brand" onclick="if(typeof addJewelrySetMemberRow==='function')addJewelrySetMemberRow({label:'گووهار',name:'گووهار',qty:2})"><i class="fas fa-plus"></i> گووهار (جووت)</button>
                                        <button type="button" class="btn btn-sm btn-brand" onclick="if(typeof addJewelrySetMemberRow==='function')addJewelrySetMemberRow({label:'رستە',name:'رستە',qty:1})"><i class="fas fa-plus"></i> رستە</button>
                                        <button type="button" class="btn btn-sm btn-dark" onclick="if(typeof addJewelrySetMemberRow==='function')addJewelrySetMemberRow({label:'پارچە',name:'پارچە',qty:1})"><i class="fas fa-plus"></i> پارچەی تر</button>
                                    </div>
                                    <div style="margin-top:10px;">
                                        <label class="product-form-label" for="p-jewelry-set-price"><i class="fas fa-tag"></i> نرخی سێت (فرۆشتن)</label>
                                        <input type="text" inputmode="decimal" id="p-jewelry-set-price" class="input-std pos-money-input" placeholder="خۆکار ژ گرام + نرخی ڕۆژ" dir="ltr" oninput="this.dataset.userPicked='1'; if(typeof syncJewelrySetPricingFromGrams==='function')syncJewelrySetPricingFromGrams({keepSetPrice:true})" onkeydown="handleProductFormEnter(event)">
                                        <p id="p-jewelry-set-cost-hint" style="margin:6px 0 0 0; font-size:0.8rem; color:#a67c00;"></p>
                                    </div>
                                </div>
                            </div>
                            </div><!-- /p-jewelry-metal-fields -->
                        </div>
                        <div id="jewelry-step1-home-unit-levels" data-jewelry-home="unit-levels">
                        <div data-layout-id="layout-step1-unit-levels" id="layout-step1-unit-levels" class="jewelry-defer-step2">
                        <label class="product-form-label"><i class="fas fa-layer-group"></i> <span data-i18n="product_form_unit_levels_title">تاک + پاکێت + کارتۆن (هەمیشە)</span></label>
                        <p class="product-form-optional-desc" style="font-size:0.7rem; color:var(--text-muted); margin:0 0 8px 0;"><i class="fas fa-info-circle"></i> <span data-i18n="product_form_unit_levels_desc">سەرەتا تاک هەیە؛ سووچەکە بکەرەوە بۆ پاکێت یان کارتۆن — «هەیە» یان «نینە». دوای پاراستن دەمێنێتەوە.</span></p>
                        <div id="p-add-unit-levels-row" class="p-unit-levels-row" style="margin-bottom:10px;">
                            <div class="p-unit-level-item p-unit-level-item--pack">
                                <span class="p-unit-toggle-label p-unit-toggle-pack"><i class="fas fa-boxes"></i> <span data-i18n="product_form_pack_label">پاکێت</span></span>
                                <button type="button" id="btn-unit-pack-toggle" class="p-unit-level-switch p-unit-level-switch--pack" role="switch" aria-checked="false" onclick="productFormTogglePackLevel()" data-i18n-title="product_form_unit_toggle_title" title="سووچ بکەرەوە — هەیە یان نینە">
                                    <span class="p-unit-level-switch__text p-unit-level-switch__text--off" data-i18n="product_form_unit_no">نینە</span>
                                    <span class="p-unit-level-switch__track" aria-hidden="true"><span class="p-unit-level-switch__thumb"></span></span>
                                    <span class="p-unit-level-switch__text p-unit-level-switch__text--on" data-i18n="product_form_unit_yes">هەیە</span>
                                </button>
                            </div>
                            <div class="p-unit-level-item p-unit-level-item--carton">
                                <span class="p-unit-toggle-label p-unit-toggle-carton"><i class="fas fa-box"></i> <span data-i18n="product_form_carton_label">کارتۆن</span></span>
                                <button type="button" id="btn-unit-carton-toggle" class="p-unit-level-switch p-unit-level-switch--carton" role="switch" aria-checked="false" onclick="productFormToggleCartonLevel()" data-i18n-title="product_form_unit_toggle_title" title="سووچ بکەرەوە — هەیە یان نینە">
                                    <span class="p-unit-level-switch__text p-unit-level-switch__text--off" data-i18n="product_form_unit_no">نینە</span>
                                    <span class="p-unit-level-switch__track" aria-hidden="true"><span class="p-unit-level-switch__thumb"></span></span>
                                    <span class="p-unit-level-switch__text p-unit-level-switch__text--on" data-i18n="product_form_unit_yes">هەیە</span>
                                </button>
                            </div>
                            <div class="p-unit-level-item p-unit-level-item--stock product-form-optional" data-layout-id="layout-optional-track">
                                <span class="p-unit-toggle-label p-unit-toggle-stock"><i class="fas fa-cubes"></i> <span data-i18n="product_form_track_stock">حیسابا کۆگەهی؟</span></span>
                                <input type="checkbox" id="p-track" checked hidden aria-hidden="true" tabindex="-1">
                                <button type="button" id="btn-unit-stock-toggle" class="p-unit-level-switch p-unit-level-switch--stock is-on" role="switch" aria-checked="true" onclick="productFormToggleTrackStock()" data-i18n-title="product_form_unit_toggle_title" title="سووچ بکەرەوە — هەیە یان نینە">
                                    <span class="p-unit-level-switch__text p-unit-level-switch__text--off" data-i18n="product_form_unit_no">نینە</span>
                                    <span class="p-unit-level-switch__track" aria-hidden="true"><span class="p-unit-level-switch__thumb"></span></span>
                                    <span class="p-unit-level-switch__text p-unit-level-switch__text--on" data-i18n="product_form_unit_yes">هەیە</span>
                                </button>
                            </div>
                        </div>
                        </div>
                        </div><!-- /jewelry-step1-home-unit-levels -->
                        <div id="jewelry-step1-home-stock" data-jewelry-home="stock">
                        <div class="form-section jewelry-defer-step2" id="stock-cost-section" data-layout-id="layout-step3-stock" style="margin-top:16px; padding-top:12px; border-top:1px solid var(--border);">
                        <div class="form-section-title product-form-section-title" data-layout-id="layout-section-titles"><i class="fas fa-coins"></i> <span data-i18n="product_form_section_units">یەکە، بارکۆد، کرین، فرۆتن، کۆگەه</span></div>
                        <p id="layout-step3-desc" class="product-form-optional-desc" data-layout-id="layout-step3-desc" style="font-size:0.7rem; color:var(--text-muted); margin:0 0 8px 0;"><i class="fas fa-info-circle"></i> <span data-i18n="product_form_step3_desc">گۆڕانکارییەکانی ژمارە (دانە/پاکێت/کارتۆن) ل سەرەوە هەڵدەبژێریت؛ لێرە بۆ هەر ئاستێک بارکۆد، کرین، فرۆتن و کۆگەه بنووسە.</span></p>
                        <div id="p-warehouse-row" class="product-form-warehouse-row" data-multi-wh-only style="margin:0 0 10px 0;">
                            <label class="product-form-label" for="p-warehouse-select"><i class="fas fa-warehouse"></i> <span>کۆگە (ئەم ئایتمە بۆ کێشە)</span></label>
                            <select id="p-warehouse-select" class="input-std" onchange="if(typeof onProductWarehouseChange==='function')onProductWarehouseChange();"></select>
                            <p class="product-form-optional-desc" style="font-size:0.7rem; color:var(--text-muted); margin:4px 0 0 0;"><i class="fas fa-info-circle"></i> ژمارەی کۆگەه دەچێتە ئەم کۆگەیە</p>
                        </div>
                        <div id="conversion-two-fields" data-layout-id="layout-conversion-row" class="p-conv-row" style="display:none; grid-template-columns: 1fr 1fr; gap:8px; margin-bottom:8px; background:var(--input-bg); padding:8px; border-radius:8px; border:1px solid var(--border);">
                            <div id="conv-wrap-ppp" class="p-conv-pack"><label id="label-pieces-per-pack" class="p-conv-label"><i class="fas fa-link"></i> <span data-i18n="product_form_conv_ppp">دانە ل پاکێتی دا</span></label><input type="number" id="p-pieces-per-pack" class="input-std" min="1" value="1" style="margin:0;" oninput="calcMultiLevelCarton(); syncCostFromLevel(); calcTotalStockFromTable();" onkeydown="handleProductFormEnter(event)"></div>
                            <div id="conv-wrap-ppc" class="p-conv-carton"><label class="p-conv-label"><i class="fas fa-link"></i> <span data-i18n="product_form_conv_ppc">پاکێت ل کارتۆنی دا</span></label><input type="number" id="p-packs-per-carton" class="input-std" min="1" value="1" style="margin:0;" oninput="calcMultiLevelCarton(); syncCostFromLevel(); calcTotalStockFromTable();" onkeydown="handleProductFormEnter(event)"></div>
                        </div>
                        <div id="conv-wrap-carton-only" class="p-conv-carton" style="display:none; margin-bottom:8px; background:var(--input-bg); padding:8px; border-radius:8px; border:1px solid var(--border);"><label class="p-conv-label"><i class="fas fa-link"></i> <span data-i18n="product_form_conv_piece_carton">دانە ل کارتۆنی دا</span></label><input type="number" id="p-pieces-per-carton-only" class="input-std" min="1" value="1" style="margin:0;" oninput="calcMultiLevelCarton(); syncCostFromLevel(); calcTotalStockFromTable();" onkeydown="handleProductFormEnter(event)"></div>
                        <div id="conversion-one-field" class="p-conv-carton" style="display:none; margin-bottom:8px; background:var(--input-bg); padding:8px; border-radius:8px; border:1px solid var(--border);"><label class="p-conv-label"><i class="fas fa-calculator"></i> <span data-i18n="product_form_conv_piece_carton">دانە ل کارتۆنی دا</span></label><input type="number" id="p-pieces-per-carton-single" class="input-std" min="1" value="1" style="margin:0;" oninput="applyCartonPieceConversion(); syncCostFromLevel(); calcTotalStockFromTable();" onkeydown="handleProductFormEnter(event)"></div>
                        <div id="p-pieces-per-carton-preview" class="p-conv-carton-preview"></div>
                        <div class="report-table">
                            <table style="width:100%; border-collapse:collapse;">
                                <thead id="layout-table-header" data-layout-id="layout-table-header"><tr><th style="text-align:right;"><i class="fas fa-ruler"></i> <span data-i18n="product_form_th_unit">یەکە</span></th><th style="text-align:right;"><i class="fas fa-barcode"></i> <span data-i18n="product_form_label_barcode">بارکۆد</span></th><th style="text-align:right;"><i class="fas fa-shopping-cart"></i> <span data-i18n="product_form_th_cost">کرین</span></th><th style="text-align:right;"><i class="fas fa-tag"></i> <span data-i18n="product_form_th_sale">فرۆتن</span></th><th style="text-align:right;" data-layout-id="layout-optional-takeaway"><i id="product-form-alt-price-icon" class="fas fa-shopping-bag"></i> <span id="product-form-alt-price-header" data-i18n="product_form_takeaway_header">جوملە</span></th><th class="product-form-th-stock" style="text-align:right;"><i class="fas fa-cubes"></i> <span data-i18n="product_form_th_stock">کۆگەه</span></th></tr></thead>
                                <tbody>
                                    <tr id="p-ml-row-piece" class="p-ml-row p-ml-row-piece"><td><i class="fas fa-cube"></i> <span data-i18n="product_form_piece_label">تاک</span><br><input type="text" id="p-unit-name-piece" list="unit-names-list" class="input-std p-unit-name-input" data-i18n-placeholder="product_form_unit_placeholder_piece" placeholder="ناڤێ یەکە" style="margin-top:4px;" oninput="if(typeof renderCustomMeasureUnitChips==='function')renderCustomMeasureUnitChips();" onchange="if(typeof syncQtyModeFromUnitNameInput==='function')syncQtyModeFromUnitNameInput(this); else if(typeof renderCustomMeasureUnitChips==='function')renderCustomMeasureUnitChips();" onkeydown="handleProductFormEnter(event)"></td><td><input type="text" id="p-barcode-piece" class="input-std" placeholder="—" autocomplete="off" dir="ltr" data-i18n-title="product_form_barcode_tooltip" title="بارکۆدا تاک ل جەدوەلی ژی دگوهۆڕیت" oninput="if(typeof syncBarcodeFromPieceCell==='function')syncBarcodeFromPieceCell();" onkeydown="handleProductFormEnter(event)"></td><td><input type="text" inputmode="numeric" id="p-cost" class="input-std pos-money-input" placeholder="0" dir="ltr" oninput="syncCostFromLevel();" onkeydown="handleProductFormEnter(event)" data-i18n-title="product_form_cost_tooltip" title="پێشنیار ل کرینی کارتۆن"></td><td><input type="text" inputmode="numeric" id="p-price" class="input-std pos-money-input" placeholder="0" dir="ltr" onkeydown="handleProductFormEnter(event)"></td><td data-layout-id="layout-optional-takeaway"><input type="text" inputmode="numeric" id="p-takeaway-price" class="input-std pos-money-input" placeholder="0" dir="ltr" onkeydown="handleProductFormEnter(event)"></td><td class="product-form-stock-cell"><input type="number" id="p-stock-piece" class="input-std" min="0" placeholder="0" oninput="calcTotalStockFromTable();" onkeydown="handleProductFormEnter(event)"></td></tr>
                                    <tr id="p-ml-row-pack" class="p-ml-row p-ml-row-pack" style="display:none;"><td><i class="fas fa-boxes"></i> <span data-i18n="product_form_pack_label">پاکێت</span><br><input type="text" id="p-unit-name-pack" list="unit-names-list" class="input-std p-unit-name-input" data-i18n-placeholder="product_form_unit_placeholder_pack" placeholder="ناڤێ یەکە" style="margin-top:4px;" onkeydown="handleProductFormEnter(event)"></td><td><input type="text" id="p-barcode-pack" class="input-std" placeholder="—" autocomplete="off" dir="ltr" oninput="if(typeof onLevelBarcodeInput==='function')onLevelBarcodeInput(this);" onblur="if(typeof onLevelBarcodeBlur==='function')onLevelBarcodeBlur(this);" onkeydown="handleProductFormEnter(event)"></td><td><input type="text" inputmode="numeric" id="p-cost-pack" class="input-std pos-money-input" placeholder="0" dir="ltr" oninput="syncCostFromLevel();" onkeydown="handleProductFormEnter(event)"></td><td><input type="text" inputmode="numeric" id="p-price-pack" class="input-std pos-money-input" placeholder="0" dir="ltr" onkeydown="handleProductFormEnter(event)"></td><td data-layout-id="layout-optional-takeaway"><input type="text" inputmode="numeric" id="p-takeaway-price-pack" class="input-std pos-money-input" placeholder="0" dir="ltr" onkeydown="handleProductFormEnter(event)"></td><td class="product-form-stock-cell"><input type="number" id="p-stock-pack" class="input-std" min="0" placeholder="0" oninput="calcTotalStockFromTable();" onkeydown="handleProductFormEnter(event)"></td></tr>
                                    <tr id="p-ml-row-carton" class="p-ml-row p-ml-row-carton" style="display:none;"><td><i class="fas fa-box"></i> <span data-i18n="product_form_carton_label">کارتۆن</span><br><input type="text" id="p-unit-name-carton" list="unit-names-list" class="input-std p-unit-name-input" data-i18n-placeholder="product_form_unit_placeholder_carton" placeholder="ناڤێ یەکە" style="margin-top:4px;" onkeydown="handleProductFormEnter(event)"></td><td><input type="text" id="p-barcode-carton" class="input-std" placeholder="—" autocomplete="off" dir="ltr" oninput="if(typeof onLevelBarcodeInput==='function')onLevelBarcodeInput(this);" onblur="if(typeof onLevelBarcodeBlur==='function')onLevelBarcodeBlur(this);" onkeydown="handleProductFormEnter(event)"></td><td><input type="text" inputmode="numeric" id="p-cost-carton" class="input-std pos-money-input" placeholder="0" dir="ltr" oninput="syncCostFromLevel();" onkeydown="handleProductFormEnter(event)"></td><td><input type="text" inputmode="numeric" id="p-price-carton" class="input-std pos-money-input" placeholder="0" dir="ltr" onkeydown="handleProductFormEnter(event)"></td><td data-layout-id="layout-optional-takeaway"><input type="text" inputmode="numeric" id="p-takeaway-price-carton" class="input-std pos-money-input" placeholder="0" dir="ltr" onkeydown="handleProductFormEnter(event)"></td><td class="product-form-stock-cell"><input type="number" id="p-stock-carton" class="input-std" min="0" placeholder="0" oninput="calcTotalStockFromTable();" onkeydown="handleProductFormEnter(event)"></td></tr>
                                </tbody>
                            </table>
                            <datalist id="unit-names-list"></datalist>
                        </div>
                            <div id="p-total-stock-preview" style="text-align:center; font-size:0.8rem; color:var(--success); font-weight:bold; margin:6px 0;"></div>
                        <p id="p-stock-lock-hint" class="product-stock-lock-hint" style="display:none;"><i class="fas fa-lock"></i> <span data-i18n="product_stock_lock_hint">عەدەدێ کوگەهێ ژ بەشێ کڕین زێدە / کێم بکە — دەستکاری ل ڤێرێ خەلەتیێ دروست دکەت</span></p>
                        </div>
                        </div><!-- /jewelry-step1-home-stock -->
                        <div id="jewelry-step1-home-expiry" data-jewelry-home="expiry">
                        <div class="product-form-optional product-form-expiry-block jewelry-defer-step2" data-layout-id="layout-optional-expiry" id="layout-optional-expiry">
                            <div class="product-form-expiry-toolbar">
                                <label class="product-form-expiry-chk-label" for="p-expiry-enabled" title="تیک = ئایتم بەسەرچوونە">
                                    <input type="checkbox" id="p-expiry-enabled" onchange="syncProductFormExpiryUi()">
                                    <i class="fas fa-calendar-check" aria-hidden="true"></i>
                                    <span data-i18n="product_form_expiry_toggle">بەسەرچوون</span>
                                </label>
                                <div id="p-expiry-field-wrap" class="product-form-expiry-field-wrap is-hidden">
                                    <label class="product-form-label" for="p-expiry" style="margin-bottom:4px;"><i class="fas fa-calendar-times"></i> <span data-i18n="product_form_expiry_label">بەروارا بەسەرچوونێ</span></label>
                                    <input type="text" id="p-expiry" class="input-std product-form-expiry-input" placeholder="YYYY-MM-DD" dir="ltr" style="margin:0 0 6px 0;" autocomplete="off" oninput="if(typeof formatAutoDate==='function')this.value=formatAutoDate(this.value);" onkeydown="handleProductFormEnter(event)">
                                </div>
                            </div>
                        </div>
                        </div><!-- /jewelry-step1-home-expiry -->
                        <div style="display:flex; gap:8px; flex-wrap:wrap; margin-top:12px;">
                            <button type="button" id="btn-save-prod-step1" class="btn btn-brand" style="flex:1; min-width:120px;" onclick="saveProduct()" onkeydown="handleProductFormEnter(event)"><i class="fas fa-save"></i> <span data-i18n="btn_save">پاراستن</span></button>
                            <button type="button" class="btn btn-dark" onclick="productFormGoToStep(2)" id="btn-step1-next" style="flex:1; min-width:120px;" onkeydown="handleProductFormEnter(event)"><i class="fas fa-arrow-left"></i> <span data-i18n="product_form_btn_continue">بەردەوام</span></button>
                            <button type="button" id="btn-product-form-clear-step1" class="btn btn-dark" onclick="clearProductFormForNewItem()" onkeydown="handleProductFormEnter(event)" data-i18n-title="product_form_clear_title" title="هەمی خانە بسڕە — ئایتمێ نوو"><i class="fas fa-eraser"></i> <span data-i18n="product_form_clear_btn">مساح</span></button>
                        </div>
                    </div>
                </div>

                <!-- STEP 2: جۆرێ یەکێ، تێبینی، ئۆپسیەکان و پاراستن (+ شتە کەمتر پێویستەکان بۆ زیڤ و زێر) -->
                <div id="product-form-step-2" class="product-form-step">
                    <div id="jewelry-step2-deferred-slot" class="jewelry-only" style="display:none;"></div>
                    <div class="form-section" id="layout-step2-unit-note" data-layout-id="layout-step2-unit-note">
                        <div class="form-section-title product-form-section-title" data-layout-id="layout-section-titles"><i class="fas fa-sliders-h"></i> <span data-i18n="product_form_section_type_note">جۆر و تێبینی</span></div>
                        <div id="jewelry-qty-mode-wrap" class="jewelry-defer-keep-step2">
                        <label class="product-form-label" data-layout-id="layout-labels"><i class="fas fa-balance-scale"></i> <span data-i18n="product_form_label_qty_mode">جۆرێ ژماردنێ</span></label>
                        <div style="display:flex; gap:12px; align-items:center; flex-wrap:wrap; margin:0 0 8px 0;">
                            <label style="display:flex; align-items:center; gap:6px; margin:0;">
                                <input type="checkbox" id="p-mode-piece" checked onchange="setProductFormQtyMode('piece')">
                                <span data-i18n="product_form_qty_piece">دانە</span>
                            </label>
                            <label style="display:flex; align-items:center; gap:6px; margin:0;">
                                <input type="checkbox" id="p-mode-kilo" onchange="setProductFormQtyMode('kilo')">
                                <span data-i18n="product_form_qty_kilo">کیلۆ</span>
                            </label>
                            <button type="button" id="btn-custom-measure-units" class="btn btn-sm btn-brand" style="padding:4px 10px; font-size:0.8rem;" onclick="if(typeof openCustomMeasureUnitsModal==='function')openCustomMeasureUnitsModal();" title="زێدەکرن و خەزنکرنا یەکەکان">
                                <i class="fas fa-plus"></i> <span data-i18n="product_form_custom_units_btn">یەکە</span>
                            </button>
                        </div>
                        <div id="custom-measure-units-chips" class="custom-measure-units-chips" style="display:flex; flex-wrap:wrap; gap:6px; margin:0 0 6px 0;"></div>
                        <div id="custom-measure-units-active" style="font-size:0.78rem; color:var(--brand); font-weight:700; margin:0 0 10px 0;">یەکێک هەڵبژێرە یان دوگمەی «یەکە» بۆ زێدەکرن</div>
                        </div>
                        <label class="product-form-label" data-layout-id="layout-labels"><i class="fas fa-sticky-note"></i> <span data-i18n="product_form_label_note">تێبینی</span></label>
                        <input type="text" id="p-note" class="input-std" data-i18n-placeholder="product_form_note_placeholder" placeholder="تێبینی یان مەسۆلە (ب حەزا تە)" autocomplete="off" onkeydown="handleProductFormEnter(event)">
                        <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px; margin-top:8px;">
                            <div id="p-min-stock-wrap">
                                <label class="product-form-label" for="p-min-stock"><i class="fas fa-bell"></i> <span id="span-p-min-stock-label" data-i18n="product_form_label_min_stock_default">حد ئاگادارکرنا کۆگەه</span></label>
                                <input type="number" id="p-min-stock" class="input-std" min="0" step="1" placeholder="5" value="5" onkeydown="handleProductFormEnter(event)">
                            </div>
                            <div id="p-expiry-alert-wrap" class="is-hidden">
                                <label class="product-form-label" for="p-expiry-alert-days"><i class="fas fa-calendar-check"></i> <span id="span-p-expiry-alert-label" data-i18n="product_form_label_expiry_alert_default">ئاگادارکرن پێش بەسەرچوون (ڕۆژ)</span></label>
                                <input type="number" id="p-expiry-alert-days" class="input-std" min="1" step="1" placeholder="30" value="30" onkeydown="handleProductFormEnter(event)">
                            </div>
                        </div>
                    </div>
                    <div class="form-section product-form-options-section" data-layout-id="layout-step3-options">
                        <div class="form-section-title product-form-section-title" data-layout-id="layout-section-titles"><i class="fas fa-cog"></i> <span data-i18n="product_form_section_options">ئۆپسیەکان و پاراستن</span></div>
                        <div class="product-form-companies-row product-form-optional" data-layout-id="layout-optional-companies" style="margin:0 0 10px 0;">
                            <label class="product-form-label" for="p-manufacturer"><i class="fas fa-industry"></i> <span data-i18n="product_form_label_manufacturer">کۆمپانیا دروستکەر</span></label>
                            <div class="purchase-supplier-select-row product-mfr-select-row">
                                <button type="button" class="btn btn-brand purchase-supplier-add-btn product-mfr-add-btn" onclick="if(typeof quickAddManufacturer==='function')quickAddManufacturer()" title="زێدەکرنا کۆمپانیا دروستکەرێ نوێ" data-i18n-title="product_form_mfr_add_title"><i class="fas fa-plus"></i></button>
                                <select id="p-manufacturer" class="input-std purchase-supplier-select" onkeydown="handleProductFormEnter(event)">
                                    <option value="" data-i18n-opt="product_form_manufacturer_placeholder">هەلبژێرە...</option>
                                </select>
                            </div>
                        </div>
                        <div class="product-form-optional" style="display:flex; align-items:center; gap:6px; margin:4px 0; background:rgba(245, 158, 11, 0.08); padding:6px 8px; border-radius:6px; border:1px dashed var(--warning);"><input type="checkbox" id="p-requires-recipe-stock" style="width:16px; height:16px;"><label style="margin:0; color:var(--warning); font-weight:bold;"><i class="fas fa-file-prescription"></i> <span data-i18n="product_form_recipe_require">پەیوەست بە ڕەچەتە (ئەگەر موادی ڕەچەتە نەبن، مەفرۆشە)</span></label></div>
                        <div class="product-form-optional" data-layout-id="layout-optional-forsale" style="display:flex; align-items:center; gap:6px; margin:4px 0; background:rgba(16, 185, 129, 0.08); padding:6px 8px; border-radius:6px; border:1px dashed var(--success);"><input type="checkbox" id="p-for-sale" style="width:16px; height:16px;" checked><label style="margin:0; color:var(--success); font-weight:bold;"><i class="fas fa-cash-register"></i> <span data-i18n="product_form_show_pos">پیشاندان لە فرۆتن</span></label></div>
                        <div id="p-takeaway-wrapper" style="display:none;"></div>
                        <div id="p-wholesale-wrapper" class="product-form-optional" data-layout-id="layout-optional-wholesale" style="margin:6px 0; padding:6px; background:rgba(59, 130, 246, 0.05); border-radius:6px; border:1px dashed var(--brand);"><label style="color:var(--brand); font-size:0.75rem;"><i class="fas fa-boxes"></i> <span data-i18n="product_form_wholesale">فرۆتنا بە کۆم</span></label><div style="display:flex; gap:6px;"><input type="text" inputmode="numeric" id="p-wholesale-qty" class="input-std" data-i18n-placeholder="product_form_placeholder_qty" placeholder="ژمارە" style="margin:0; flex:1;" autocomplete="off" onkeydown="handleProductFormEnter(event)"><input type="text" inputmode="numeric" id="p-wholesale-price" class="input-std pos-money-input" data-i18n-placeholder="product_form_placeholder_price" placeholder="نرخ" style="margin:0; flex:1;" autocomplete="off" onkeydown="handleProductFormEnter(event)"></div></div>
                        <div style="display:flex; gap:6px; flex-wrap:wrap; margin-top:8px;"><button type="button" id="btn-step2-back" class="btn btn-dark" data-layout-id="layout-btn-back" onclick="productFormGoToStep(1)" onkeydown="handleProductFormEnter(event)"><i class="fas fa-arrow-right"></i> <span data-i18n="product_form_btn_back">پاش</span></button><button id="btn-save-prod" class="btn btn-brand" style="flex:1; min-width:90px;" onclick="saveProduct()" onkeydown="handleProductFormEnter(event)"><i class="fas fa-save"></i> <span data-i18n="btn_save">پاراستن</span></button><button id="btn-recipe" class="btn btn-warning product-form-optional" style="flex:1; display:none;" onclick="openRecipeModal()"><i class="fas fa-boxes-packing recipe-ui-icon"></i> <span data-i18n="product_form_btn_recipe">ڕەسەپی</span></button><button id="layout-btn-partner" class="btn btn-info product-form-optional" data-layout-id="layout-btn-partner" style="flex:1; min-width:70px;" onclick="saveProduct(true)" onkeydown="handleProductFormEnter(event)"><i class="fas fa-handshake"></i> <span data-i18n="product_form_btn_partner">هاوبەش</span></button><button id="layout-btn-clear" class="btn btn-dark" data-layout-id="layout-btn-clear" onclick="clearProductFormForNewItem()" onkeydown="handleProductFormEnter(event)" data-i18n-title="product_form_clear_title" title="هەمی خانە بسڕە — ئایتمێ نوو"><i class="fas fa-eraser"></i> <span data-i18n="product_form_clear_btn">مساح</span></button></div>
                    </div>
                </div>
            </div>

            <!-- Product Form Layout Manager Modal -->
            <div id="product-layout-modal" class="modal-overlay product-layout-modal-overlay" tabindex="0" style="display:none;" onkeydown="if(event.key==='Escape') closeProductLayoutManager();">
                <div class="glass-card product-layout-modal-card">
                    <div class="product-layout-modal-header">
                        <h3 style="margin:0;"><i class="fas fa-pen"></i> <span data-i18n="product_form_layout_modal_title">ڕێکخستنا فۆرم</span></h3>
                        <button type="button" class="btn btn-sm btn-dark" onclick="closeProductLayoutManager()">✖</button>
                    </div>
                    <p class="product-layout-modal-intro"><span data-i18n="product_form_layout_modal_intro">ئەڤ بەشانە نیشان بدە یان بشارەوە بۆ خێراکردنا نووسین.</span></p>
                    <div id="product-layout-list" class="product-layout-list-scroll"></div>
                    <div class="product-layout-modal-actions">
                        <button type="button" class="btn btn-brand" onclick="saveProductFormLayout(); closeProductLayoutManager();"><i class="fas fa-save"></i> <span data-i18n="btn_save">پاراستن</span></button>
                        <button type="button" class="btn btn-dark" onclick="resetProductFormLayout(); renderProductLayoutList();"><span data-i18n="product_form_layout_reset">ڕێکخستنا بنەڕەتی</span></button>
                    </div>
                </div>
            </div>

            <!-- Custom measure units (لتر، فەردە… + پوینت) -->
            <div id="custom-measure-units-modal" class="modal-overlay" tabindex="0" style="display:none;" onkeydown="if(event.key==='Escape'&&typeof closeCustomMeasureUnitsModal==='function')closeCustomMeasureUnitsModal();" onclick="if(event.target===this&&typeof closeCustomMeasureUnitsModal==='function')closeCustomMeasureUnitsModal();">
                <div class="glass-card" style="width:min(420px,94vw); max-height:85vh; overflow:auto; padding:16px;" role="dialog" aria-labelledby="custom-measure-units-title">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
                        <h3 id="custom-measure-units-title" style="margin:0; font-size:1.05rem;"><i class="fas fa-ruler-combined"></i> <span data-i18n="product_form_custom_units_title">یەکەکان</span></h3>
                        <button type="button" class="btn btn-sm btn-dark" onclick="if(typeof closeCustomMeasureUnitsModal==='function')closeCustomMeasureUnitsModal()">✖</button>
                    </div>
                    <p style="margin:0 0 12px 0; font-size:0.78rem; color:var(--text-muted);"><span data-i18n="product_form_custom_units_hint">ناڤێ یەکێ خەزن بکە بۆ جارێن بهێت؛ بڵێ پوینت هەبێت یان نەبێت.</span></p>
                    <div style="display:grid; grid-template-columns:1fr auto; gap:8px; align-items:end; margin-bottom:10px;">
                        <div>
                            <label class="product-form-label" for="cmu-name-input" style="margin-bottom:4px;"><span data-i18n="product_form_custom_unit_name">ناڤێ یەکێ</span></label>
                            <input type="text" id="cmu-name-input" class="input-std" style="margin:0;" placeholder="وەک: لتر، فەردە، مەتر" autocomplete="off" onkeydown="if(event.key==='Enter'){event.preventDefault(); if(typeof addCustomMeasureUnitFromForm==='function')addCustomMeasureUnitFromForm();}">
                        </div>
                        <button type="button" class="btn btn-brand" style="height:42px; white-space:nowrap;" onclick="if(typeof addCustomMeasureUnitFromForm==='function')addCustomMeasureUnitFromForm();"><i class="fas fa-plus"></i> <span data-i18n="btn_add">زێدەکرن</span></button>
                    </div>
                    <label style="display:flex; align-items:center; gap:8px; margin:0 0 14px 0; font-size:0.9rem; cursor:pointer;">
                        <input type="checkbox" id="cmu-allow-decimal" checked>
                        <span data-i18n="product_form_custom_unit_points">پوینت هەبێت (وەک کیلو / لتر)</span>
                    </label>
                    <div id="custom-measure-units-list" style="display:flex; flex-direction:column; gap:6px;"></div>
                </div>
            </div>
            
            <!-- RECENT ITEMS -->
            <div class="card" id="recent-items-card" style="display:none; border-top: 5px solid var(--info); margin-top:20px;">
                <h3><i class="fas fa-history"></i> <span data-i18n="products_recent_heading">دوماهیک ئایتمێن هاتینە زێدەکرن</span></h3>
                <table class="report-table">
                    <thead><tr><th><i class="fas fa-box-open"></i> <span data-i18n="products_tbl_item">ئایتم</span></th><th><i class="fas fa-barcode"></i> <span data-i18n="products_tbl_barcode">بارکۆد</span></th><th><i class="fas fa-tag"></i> <span data-i18n="products_recent_price">نرخ</span></th><th><i class="fas fa-shopping-cart"></i> <span data-i18n="products_recent_cost">کرین</span></th><th><i class="fas fa-cubes"></i> <span data-i18n="products_tbl_stock">کۆگەه</span></th></tr></thead>
                    <tbody id="recent-items-body"></tbody>
                </table>
            </div>

            <!-- LIST OF ALL PRODUCTS -->
            <div class="card" id="all-products-card" style="border-top: 5px solid var(--warning);">
                <div class="products-list-toolbar" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
                    <h3><i class="fas fa-clipboard-list"></i> <span data-i18n="products_list_heading">لیستا هەمی ئایتمان</span> <span id="total-products-count" style="font-size:0.9rem; background:var(--brand); color:white; padding:2px 8px; border-radius:10px; margin-right:5px;">0</span></h3>
                    <div class="products-list-toolbar-filters" style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                        <select id="products-filter-currency" class="input-std" style="width:auto; min-width:160px; margin:0;" onchange="if(typeof renderProducts==='function')renderProducts();" aria-label="فلتەرا دراڤی">
                            <option value="" data-i18n-opt="wh_filter_currency_all">هەمی کەرەستە</option>
                            <option value="IQD" data-i18n-opt="wh_filter_currency_iqd">کەرەستەیێن ب دینار</option>
                            <option value="USD" data-i18n-opt="wh_filter_currency_usd">کەرەستەیێن ب دۆلار</option>
                        </select>
                        <label class="products-search-wrap" for="products-search-input">
                            <i class="fas fa-search products-search-icon" aria-hidden="true"></i>
                            <input type="text" id="products-search-input" class="input-std" style="width:250px; margin:0;" data-i18n-placeholder="products_search_placeholder" placeholder="لێگەریان..." onkeydown="if(event.key==='Enter'){event.preventDefault();}" oninput="if(typeof convertArabicNumerals==='function')convertArabicNumerals(this); if(typeof debouncedRenderProducts==='function')debouncedRenderProducts(this.value); else if(typeof renderProducts==='function')renderProducts(this.value);" autocomplete="off">
                        </label>
                    </div>
                </div>
                <div id="product-list-container"></div>
            </div>
        </div>

        <!-- POS SYSTEM (UPDATED WITH DISCOUNT & LOGO) -->
        <div id="view-pos" class="workspace txn-mobile-screen txn-view-shell txn-theme txn-theme--sales" style="position:relative;">
            <div id="pos-init-overlay" class="pos-init-overlay" style="display:none;" aria-hidden="true">
                <div class="pos-init-overlay-inner">
                    <i class="fas fa-spinner fa-spin"></i>
                    <span>بارکرنا پشکا فرۆشتنێ...</span>
                </div>
            </div>
            <div class="pos-layout">
                <div id="pos-menu-panel" class="pos-menu no-print">
                    <div class="pos-top-bar txn-view-top-bar pos-header-polished no-print">
                        <div class="pos-header-row pos-header-row-top">
                                <div class="pos-header-brand txn-screen-head-pos">
                                    <div class="txn-screen-head-icon txn-screen-head-icon-brand" aria-hidden="true">
                                        <i class="fas fa-cash-register"></i>
                                    </div>
                                    <h3 class="txn-screen-head-title" data-i18n="view_pos_title">فرۆشتن</h3>
                                </div>
                                <div class="pos-top-bar-actions pos-header-toolbar pos-toolbar-overflow">
                                <button type="button" id="pos-sale-wh-btn" class="pos-sale-wh-btn" style="display:none;" onclick="if(typeof openPosWarehousePicker==='function')openPosWarehousePicker();" title="کۆگەها فرۆتنێ">
                                    <span class="pos-sale-wh-ic" aria-hidden="true"><i class="fas fa-warehouse"></i></span>
                                    <span class="pos-sale-wh-copy">
                                        <span class="pos-sale-wh-kicker" data-i18n="nav_warehouse">کۆگەه</span>
                                        <span id="pos-sale-wh-label" class="pos-sale-wh-name">کۆگەه</span>
                                    </span>
                                    <span class="pos-sale-wh-lock" aria-hidden="true"><i class="fas fa-lock"></i></span>
                                </button>
                                <button type="button" id="btn-pos-jewelry-rates" class="btn btn-sm pos-header-tool-btn jewelry-only" style="display:none; background:rgba(201,162,39,0.18); color:#a67c00; border:1px solid rgba(201,162,39,0.45);" onclick="if(typeof openJewelryDailyRatesModal==='function')openJewelryDailyRatesModal();" title="نرخی ڕۆژانەی زیڤ و زێر — کڕین و فرۆشتن"><i class="fas fa-coins"></i></button>
                                <span id="pos-jewelry-rates-chip" class="jewelry-only" style="display:none; font-size:0.72rem; font-weight:700; color:#a67c00; background:rgba(201,162,39,0.12); border:1px solid rgba(201,162,39,0.35); border-radius:8px; padding:4px 8px; white-space:nowrap; max-width:280px; overflow:hidden; text-overflow:ellipsis;" title="نرخی ڕۆژانە"></span>
                                <button type="button" class="btn btn-sm pos-header-tool-btn txn-toolbar-toggle" title="زیاتر" aria-label="زیاتر" aria-expanded="false"><i class="fas fa-ellipsis-h"></i></button>
                                <div class="txn-toolbar-more">
                                    <button type="button" id="btn-pos-refresh-head" class="btn btn-sm btn-pos-refresh pos-header-tool-btn txn-toolbar-refresh" onclick="if(typeof posPartialRefresh==='function') posPartialRefresh(this);" title="تازەکردنەوە" aria-label="تازەکردنەوە"><i class="fas fa-sync-alt"></i></button>
                                    <button type="button" id="btn-pos-card-tools" class="btn btn-sm pos-header-tool-btn" onclick="if(typeof togglePosCardTools==='function')togglePosCardTools();" title="پین + کرین" aria-label="پین + کرین" aria-pressed="false"><i class="fas fa-pen"></i></button>
                                    <button type="button" id="btn-pos-manual-sale" class="btn btn-sm pos-header-tool-btn" onclick="openManualItemModal()" title="فرۆتنا دەستی" data-i18n-title="pos_manual_item_btn"><i class="fas fa-keyboard"></i></button>
                                    <button class="btn btn-sm pos-header-tool-btn" data-perm="view_daily_summary" onclick="openDailyHistoryModal()" title="مێژوویا ئەڤرۆ"><i class="fas fa-history"></i></button>
                                    <button class="btn btn-sm pos-header-tool-btn" data-perm="send_telegram_report" onclick="sendTelegramReport()" title="ناردن بۆ تیلیگرام"><i class="fab fa-telegram"></i></button>
                                    <button type="button" class="btn btn-sm pos-header-tool-btn pos-header-delivery-btn" onclick="if(typeof nav==='function')nav('delivery')" title="گەهاندن" data-i18n-title="view_delivery_title"><i class="fas fa-truck"></i></button>
                                    <button id="btn-fullscreen-pos" class="btn btn-sm pos-header-tool-btn" onclick="togglePOSFullscreen()" title="Fullscreen"><i class="fas fa-expand-arrows-alt"></i></button>
                                </div>
                                </div>
                        </div>
                        <div class="pos-header-row pos-header-row-fields pos-header-fields-unified">
                            <div class="pos-header-search-box">
                                <div class="pos-search-unit-bar txn-unit-bar">
                                    <label class="pos-search-field" for="pos-barcode-input">
                                        <i class="fas fa-search pos-search-field-icon" aria-hidden="true"></i>
                                        <input type="text" id="pos-barcode-input" class="pos-search-input pos-header-input" data-i18n-placeholder="pos_search_placeholder" placeholder="لێگەریان / بارکۆد..." onkeyup="if(event.key !== 'Enter') debouncedRenderPOSMenu(this.value)" onkeydown="handlePOSBarcode(event)" oninput="convertArabicNumerals(this)">
                                    </label>
                                    <div id="pos-unit-toggles" class="pos-unit-toggles no-print">
                                        <button type="button" id="btn-pos-takeaway-toggle" class="pos-unit-btn" onclick="toggleCartTakeaway()" title="جوملە" data-i18n-title="settings_t_takeaway" style="display:none;"><i class="fas fa-box"></i></button>
                                        <button type="button" id="btn-pos-unit-piece" class="pos-unit-btn active" data-unit="piece" onclick="setPOSUnit('piece')" data-i18n-title="pos_unit_piece" title="تاک"><i class="fas fa-cube"></i></button>
                                        <button type="button" id="btn-pos-unit-pack" class="pos-unit-btn" data-unit="pack" onclick="setPOSUnit('pack')" data-i18n-title="pos_unit_pack" title="پاکێت"><i class="fas fa-boxes"></i></button>
                                        <button type="button" id="btn-pos-unit-carton" class="pos-unit-btn" data-unit="carton" onclick="setPOSUnit('carton')" data-i18n-title="pos_unit_carton" title="کارتۆن"><i class="fas fa-box"></i></button>
                                        <label class="search-inline-toggle pos-payment-wallet-btn" title="شاشەیا پارەدانێ" data-i18n-title="settings_t_payment_modal" style="display:none;">
                                            <input type="checkbox" id="quick-pay-toggle-pos" onchange="window.togglePaymentModalSetting(this.checked)">
                                            <i class="fas fa-wallet" onclick="onPosPaymentWalletClick(event)"></i>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="pos-header-fields-divider" aria-hidden="true"></div>
                            <div class="pos-header-customer-box txn-meta-sticky is-collapsed" data-txn-meta="pos">
                                <span class="pos-header-customer-label no-print" aria-hidden="true"><i class="fas fa-user"></i></span>
                                <button type="button" class="txn-meta-toggle no-print" aria-expanded="false">
                                    <span><i class="fas fa-user"></i> <span data-i18n="pos_meta_customer">کریار</span></span>
                                    <i class="fas fa-chevron-down txn-meta-chevron" aria-hidden="true"></i>
                                </button>
                                <div class="txn-meta-body">
                                    <div class="pos-customer-meta-row txn-meta-fields-row">
                                        <div class="purchase-top-field txn-meta-field pos-customer-name-field pos-entity-ac-wrap">
                                            <label class="purchase-label pos-field-label-desktop-hide" for="pos-customer-name"><i class="fas fa-user"></i> ناڤێ کڕیاری</label>
                                            <input type="text" id="pos-customer-name" class="input-std pos-header-input" placeholder="ناڤێ کڕیاری — کلیک بکە بۆ هەموو لیست" aria-label="ناڤێ کڕیاری" autocomplete="off" oninput="if(typeof toggleCreditButton === 'function') toggleCreditButton(); if(typeof window.updatePosCustomerClearBtnState === 'function') window.updatePosCustomerClearBtnState(); if(typeof window.maybeCollapseTxnMetaAfterValid === 'function') window.maybeCollapseTxnMetaAfterValid('pos', ['pos-customer-name']);">
                                        </div>
                                        <button type="button" class="btn btn-brand pos-customer-add-btn pos-header-icon-btn" onclick="if(typeof quickAddCustomer === 'function') quickAddCustomer()" title="زێدەکرنا کڕیارێ نوێ"><i class="fas fa-plus"></i></button>
                                        <button type="button" id="pos-customer-clear-btn" class="btn btn-danger pos-header-icon-btn pos-customer-clear-btn" onclick="if(typeof clearPosCustomerInput === 'function') clearPosCustomerInput();" title="لابردنا کڕیاری" style="display:none;"><i class="fas fa-times"></i></button>
                                        <input type="hidden" id="pos-customer-phone" value="">
                                        <div class="purchase-top-field txn-meta-field pos-paid-field is-hidden-until-customer">
                                            <label class="purchase-label pos-field-label-desktop-hide" for="pos-customer-paid"><i class="fas fa-money-bill-wave"></i> پارێ دای</label>
                                            <input type="text" inputmode="decimal" id="pos-customer-paid" class="input-std pos-customer-paid-input pos-header-input pos-money-input" placeholder="پارێ دای" aria-label="پارێ دای" dir="ltr" oninput="if(typeof onPosCustomerPaidInput==='function')onPosCustomerPaidInput(this);">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="category-tabs-scroll-wrap" class="category-tabs-scroll-wrap">
                        <button type="button" class="cat-scroll-btn" data-cat-scroll="prev" onclick="if(typeof scrollPOSCategoryTabs==='function')scrollPOSCategoryTabs(false);" title="گەڕانەوە بۆ پۆلێن پێشوو" aria-label="گەڕانەوە بۆ پۆلێن پێشوو"><i class="fas fa-chevron-right"></i></button>
                        <div id="category-tabs" class="category-list-container"></div>
                        <button type="button" class="cat-scroll-btn" data-cat-scroll="next" onclick="if(typeof scrollPOSCategoryTabs==='function')scrollPOSCategoryTabs(true);" title="پۆلێنێن دیکە ببینە" aria-label="پۆلێنێن دیکە ببینە"><i class="fas fa-chevron-left"></i></button>
                    </div>
                    <div class="pos-content-wrapper">
                        <div class="pos-products-toolbar no-print" aria-hidden="false">
                            <span class="pos-products-toolbar-title"><i class="fas fa-th-large" aria-hidden="true"></i> <span data-i18n="pos_products_toolbar_title">کاڵاکان</span></span>
                            <span id="pos-products-count" class="pos-products-count-badge">0</span>
                        </div>
                        <div id="pos-products" class="product-grid"></div>
                    </div>
                </div>
                <div class="cart-resize-divider no-print" data-resize-handle="pos" role="separator" aria-orientation="vertical" aria-valuemin="280" aria-valuemax="960" aria-label="قەبارەی سەبەتە — ڕاکێشە" title="ڕاکێشە بۆ گەورە/بچووککردنی سەبەتە (تاچ یان ماوس)"></div>
                
                <div id="pos-bill-panel" class="pos-bill returns-bill returns-bill-redesign unified-cart-panel txn-sheet-panel txn-sheet-collapsed">
                    <div class="returns-bill-header pos-bill-header-slim no-print">
                        <h2 class="returns-bill-title"><i class="fas fa-shopping-cart" aria-hidden="true"></i> <span data-i18n="pos_cart_title">سەبەتە</span></h2>
                        <div id="basket-usd-visual-rate" class="pos-cart-fx-chip no-print" data-allow-iqd="1" data-i18n-title="cart_fx_rate" title="نرخێ گۆڕینێ" style="display:none;">
                            <i class="fas fa-coins" aria-hidden="true"></i>
                            <input type="text" id="basket-usd-visual-rate-input" inputmode="numeric" autocomplete="off" placeholder="150,000" aria-label="بهایێ 100$ ب دینار" oninput="if(typeof onBasketVisualRateInput==='function') onBasketVisualRateInput(this.value)" onblur="if(typeof commitBasketVisualRateInput==='function') commitBasketVisualRateInput()" onkeydown="if(event.key==='Enter'){event.preventDefault();if(typeof commitBasketVisualRateInput==='function')commitBasketVisualRateInput();}">
                            <span id="basket-usd-visual-rate-suffix" class="pos-cart-fx-chip-sfx">= $100</span>
                            <button type="button" id="basket-usd-visual-rate-save" class="pos-cart-chrome-btn" onclick="if(typeof saveBasketVisualRateFromButton==='function') saveBasketVisualRateFromButton()" title="پاراستن">
                                <i class="fas fa-check"></i>
                            </button>
                            <small id="basket-usd-visual-rate-value"></small>
                        </div>
                        <div class="pos-bill-header-slim-actions pos-cart-chrome no-print">
                            <button type="button" class="pos-cart-chrome-btn" id="btn-quick-telegram-toggle" onclick="if(typeof toggleTelegramQuick==='function')toggleTelegramQuick()" title="ناردن بۆ تێلیگرام (Telegram)" style="display:none;"><i class="fab fa-telegram-plane"></i></button>
                            <button type="button" class="pos-cart-chrome-btn" id="btn-quick-autoprint-toggle" onclick="toggleAutoPrintQuick()" title="چاپکرنا ئۆتۆماتیکی (Auto Print)"><i class="fas fa-print"></i></button>
                            <button type="button" class="pos-cart-chrome-btn" id="btn-quick-printnote-toggle" onclick="if(typeof togglePrintNotePopupQuick==='function')togglePrintNotePopupQuick()" data-i18n-title="pds_print_note_checkbox" title="نیشاندانی پەنجەرەی «تێبینی پێش چاپ» (پێشنیارکراو)" aria-pressed="true"><i class="fas fa-sticky-note"></i></button>
                            <span class="pos-cart-chrome-sep" aria-hidden="true"></span>
                            <div class="pos-cart-size-tools" role="group" aria-label="قەبارەی سەبەتە">
                                <button type="button" class="pos-cart-chrome-btn" onclick="if(typeof adjustCartPanelWidth==='function')adjustCartPanelWidth(-80);" title="بچووکترکردنی سەبەتە" aria-label="بچووکترکردنی سەبەتە"><i class="fas fa-compress-alt" aria-hidden="true"></i></button>
                                <span id="pos-cart-width-peek" class="pos-cart-density-peek" title="پانی سەبەتە">—</span>
                                <button type="button" class="pos-cart-chrome-btn" onclick="if(typeof adjustCartPanelWidth==='function')adjustCartPanelWidth(80);" title="گەورەکردنی سەبەتە" aria-label="گەورەکردنی سەبەتە"><i class="fas fa-expand-alt" aria-hidden="true"></i></button>
                                <span class="pos-cart-chrome-sep" aria-hidden="true"></span>
                                <button type="button" class="pos-cart-chrome-btn" onclick="if(typeof adjustCartDensity==='function')adjustCartDensity(-5);" title="ئایتم بچووکتر" aria-label="ئایتم بچووکتر"><i class="fas fa-minus" aria-hidden="true"></i></button>
                                <span id="pos-cart-density-peek" class="pos-cart-density-peek">100%</span>
                                <button type="button" class="pos-cart-chrome-btn" onclick="if(typeof adjustCartDensity==='function')adjustCartDensity(5);" title="ئایتم گەورەتر" aria-label="ئایتم گەورەتر"><i class="fas fa-plus" aria-hidden="true"></i></button>
                            </div>
                            <button type="button" class="btn btn-sm btn-dark" onclick="togglePosMenu()" title="فراوانکردن / بارکۆد"><i class="fas fa-expand-arrows-alt"></i></button>
                            <button type="button" class="returns-bill-clear" onclick="cancelOrder()" title="پاککردنەوە"><i class="fas fa-trash-alt"></i></button>
                        </div>
                    </div>
                    <!-- Expand mode: left sidebar (compact vertical buttons) -->
                    <div class="bill-expand-sidebar no-print">
                        <div class="bill-sidebar-total-wrap">
                            <span class="bill-sidebar-total-label"><i class="fas fa-calculator" aria-hidden="true"></i> <span data-i18n="bill_total_label">کۆم</span></span>
                            <div id="bill-sidebar-total" class="bill-sidebar-total-value">0</div>
                            <div id="bill-sidebar-total-secondary" class="pos-bill-total-secondary pos-bill-total-secondary--sm" data-allow-iqd="1"></div>
                            <div id="bill-sidebar-fx-rate" class="pos-bill-fx-rate pos-bill-fx-rate--sm" data-allow-iqd="1"></div>
                        </div>
                        <button type="button" class="btn-expand-sidebar sell" onclick="sellFromPos()" title="فروشتن"><i class="fas fa-cash-register"></i><span data-i18n="pos_btn_sell">فروشتن</span></button>
                        <button type="button" class="btn-expand-sidebar" onclick="printProforma()" title="Print"><i class="fas fa-print"></i><span data-i18n="btn_pos_print_proforma">Print</span></button>
                        <button type="button" class="btn-expand-sidebar danger" onclick="cancelOrder()" title="Clear"><i class="fas fa-trash"></i><span data-i18n="btn_pos_clear">Clear</span></button>
                        <button type="button" class="btn-expand-sidebar" onclick="nav('tables')" title="Hold"><i class="fas fa-pause"></i><span data-i18n="btn_pos_hold">Hold</span></button>
                        <button type="button" class="btn-expand-sidebar" id="btn-expand-kitchen" onclick="printKitchen()" title="Kitchen"><i class="fas fa-utensils"></i><span data-i18n="btn_pos_print_kitchen">Kitchen</span></button>
                        <button class="btn-expand-sidebar toggle" onclick="togglePosMenu()" title="Close expand"><i class="fas fa-compress-arrows-alt"></i><span data-i18n="btn_close">Close</span></button>
                    </div>
                    <div class="bill-expand-main">
                    <div class="bill-header pos-bill-header-verbose">
                        <div class="pos-expand-head no-print">
                            <button type="button" class="btn btn-sm btn-dark pos-expand-close-btn" onclick="togglePosMenu()" title="داخستن / گەڕانەوە بۆ کاڵاکان"><i class="fas fa-compress-arrows-alt"></i></button>
                            <div class="pos-expand-head-meta">
                                <button type="button" class="btn btn-sm btn-light" id="btn-quick-autoprint-toggle-expand" onclick="toggleAutoPrintQuick()" title="چاپکرنا ئۆتۆماتیکی (Auto Print)" style="margin-inline-end:6px; border:1px solid var(--border); border-radius:6px; color:var(--text-muted);"><i class="fas fa-print"></i></button>
                                <button type="button" class="btn btn-sm btn-light" id="btn-quick-printnote-toggle-expand" onclick="if(typeof togglePrintNotePopupQuick==='function')togglePrintNotePopupQuick()" data-i18n-title="pds_print_note_checkbox" title="نیشاندانی پەنجەرەی «تێبینی پێش چاپ» (پێشنیارکراو)" style="margin-inline-end:10px; border:1px solid var(--border); border-radius:6px; color:var(--text-muted);" aria-pressed="true"><i class="fas fa-sticky-note"></i></button>
                                <h2 id="bill-cafe-name" class="pos-expand-cafe-name">Infinity Cafe</h2>
                                <p id="bill-cafe-info" class="pos-expand-cafe-info"></p>
                                <div class="pos-expand-table-meta">
                                    <span id="pos-active-table" class="pos-expand-table-label">Meza 1</span>
                                    <span id="pos-takeaway-badge" class="pos-expand-takeaway-badge" data-i18n="pos_takeaway_badge">جوملە</span>
                                    <span id="pos-date" class="pos-expand-date-label">1/7/2026</span>
                                </div>
                            </div>
                        </div>
                        <div class="bill-header-expand-search no-print" id="bill-header-expand-search">
                            <input type="text" id="pos-expand-search-input" class="pos-expand-search-input" data-i18n-placeholder="pos_search_placeholder" placeholder="🔍 لێگەڕیان / Barcode..." autocomplete="off" onkeydown="if(typeof handleExpandSearchInput==='function') handleExpandSearchInput(event);" oninput="if(typeof convertArabicNumerals==='function') convertArabicNumerals(this);">
                            <div id="pos-expand-unit-toggles" class="pos-unit-toggles pos-expand-unit-toggles no-print">
                                <button type="button" id="btn-pos-expand-takeaway-toggle" class="pos-unit-btn" onclick="toggleCartTakeaway()" title="سەفەری" style="display:none;"><i class="fas fa-shopping-bag"></i></button>
                                <button type="button" id="btn-pos-expand-unit-piece" class="pos-unit-btn active" data-unit="piece" onclick="setPOSUnit('piece')" data-i18n-title="pos_unit_piece" title="تاک"><i class="fas fa-cube"></i></button>
                                <button type="button" id="btn-pos-expand-unit-pack" class="pos-unit-btn" data-unit="pack" onclick="setPOSUnit('pack')" data-i18n-title="pos_unit_pack" title="پاکێت"><i class="fas fa-boxes"></i></button>
                                <button type="button" id="btn-pos-expand-unit-carton" class="pos-unit-btn" data-unit="carton" onclick="setPOSUnit('carton')" data-i18n-title="pos_unit_carton" title="کارتۆن"><i class="fas fa-box"></i></button>
                                <label class="search-inline-toggle pos-payment-wallet-btn" title="شاشەیا پارەدانێ" data-i18n-title="settings_t_payment_modal" style="display:none;">
                                    <input type="checkbox" id="quick-pay-toggle-pos-expand" onchange="window.togglePaymentModalSetting(this.checked)">
                                    <i class="fas fa-wallet" onclick="onPosPaymentWalletClick(event)"></i>
                                </label>
                            </div>
                        </div>
                        <div class="pos-expand-customer-bar no-print">
                            <span class="pos-expand-customer-icon" aria-hidden="true"><i class="fas fa-user"></i></span>
                            <input type="text" id="pos-expand-customer-name" class="input-std pos-expand-field" placeholder="ناڤێ کڕیاری — کلیک بکە بۆ هەموو لیست" aria-label="ناڤێ کڕیاری" autocomplete="off">
                            <button type="button" class="btn btn-brand pos-expand-add-customer" onclick="if(typeof quickAddCustomerExpand==='function') quickAddCustomerExpand();" title="زێدەکرنا کڕیار"><i class="fas fa-plus"></i></button>
                            <input type="hidden" id="pos-expand-customer-phone" value="">
                            <input type="text" inputmode="decimal" id="pos-expand-customer-paid" class="input-std pos-expand-field pos-expand-paid pos-money-input" placeholder="پارێ دای" aria-label="پارێ دای" dir="ltr" oninput="if(typeof onPosCustomerPaidInput==='function')onPosCustomerPaidInput(this);">
                        </div>
                    </div>
                    <div class="bill-items returns-bill-items">
                        <div class="returns-cart-header-slim basket-list-header bill-items-header no-print">
                            <span class="returns-h-item basket-h-item"><i class="fas fa-tag" aria-hidden="true"></i> <span data-i18n="returns_h_item">ئایتم</span></span>
                            <span class="returns-h-disc basket-h-disc" data-i18n-title="returns_h_disc_title" title="داشکاندن"><i class="fas fa-percent" aria-hidden="true"></i> <span data-i18n="returns_h_disc">داشـ</span></span>
                            <span class="returns-h-price basket-h-price"><i class="fas fa-coins" aria-hidden="true"></i> <span data-i18n="returns_h_price">نرخ</span></span>
                            <span class="returns-h-qty basket-h-qty"><i class="fas fa-sort-numeric-up" aria-hidden="true"></i> <span data-i18n="returns_h_qty">ژمارە</span></span>
                            <span class="returns-h-total basket-h-total"><i class="fas fa-equals" aria-hidden="true"></i> <span data-i18n="returns_h_total">کۆم</span></span>
                            <span class="returns-h-action basket-h-action"></span>
                        </div>
                        <div id="bill-rows" class="returns-cart-rows-wrap"></div>
                    </div>
                    <div class="bill-footer pos-bill-footer-compact">
                        <!-- Cart-level % discount (read by renderBillTotal / payment sync); keep in DOM even when no visible discount row -->
                        <input type="hidden" id="pos-discount" value="" autocomplete="off">
                        <datalist id="pos-customer-list"></datalist>
                        <div class="bill-total-section pos-bill-total-strip">
                            <div class="pos-bill-total-breakdown">
                                <div class="pos-cart-strip-actions">
                                    <span id="pos-cart-item-count" class="pos-cart-count-badge" title="ژمارەی ئایتم لە سەبەتە">
                                        <i class="fas fa-shopping-basket" aria-hidden="true"></i>
                                        <span id="pos-cart-item-count-val">0</span>
                                    </span>
                                    <div class="cart-pay-method-toggle" data-cart-pay="pos" role="group" aria-label="جۆرێ پارەدانێ">
                                        <button type="button" class="cart-pay-method-btn is-active" data-pay="cash" aria-pressed="true" onclick="if(typeof setCartPayMethod==='function')setCartPayMethod('pos','cash')" title="کاش" data-i18n-title="payment_method_cash"><i class="fas fa-money-bill-wave" aria-hidden="true"></i><span class="cart-pay-method-lbl" data-i18n="payment_method_cash">کاش</span></button>
                                        <button type="button" class="cart-pay-method-btn" data-pay="fib" aria-pressed="false" onclick="if(typeof setCartPayMethod==='function')setCartPayMethod('pos','fib')" title="FIB" data-i18n-title="payment_method_fib"><i class="fas fa-university" aria-hidden="true"></i><span class="cart-pay-method-lbl">FIB</span></button>
                                    </div>
                                    <button type="button" id="pos-cart-delivery-toggle" class="cart-delivery-toggle-btn" aria-pressed="false" onclick="if(typeof setCartDeliveryOn==='function')setCartDeliveryOn(!(typeof isCartDeliveryOn==='function'&&isCartDeliveryOn()))" title="گەهاندن — ON / OFF" data-i18n-title="cart_delivery_toggle"><i class="fas fa-truck" aria-hidden="true"></i><span class="cart-pay-method-lbl" data-i18n="cart_delivery_toggle">گەهاندن</span></button>
                                    <select id="pos-cart-driver-id" class="cart-delivery-driver-select" aria-label="سایێق" hidden onchange="if(typeof onPosCartDriverChange==='function')onPosCartDriverChange()">
                                        <option value="0" data-i18n="del_driver_pick">سایێق — هەلبژێرە</option>
                                    </select>
                                </div>
                                <div id="pos-bill-subtotal-row" class="pos-bill-breakdown-row" style="display:none;">
                                    <span class="pos-bill-breakdown-lbl"><i class="fas fa-receipt" aria-hidden="true"></i> کۆیا پێش داشکاندن</span>
                                    <span id="pos-bill-subtotal-val" class="pos-bill-breakdown-val">0</span>
                                </div>
                                <div id="pos-bill-discount-row" class="pos-bill-breakdown-row pos-bill-breakdown-row--disc" style="display:none;">
                                    <span class="pos-bill-breakdown-lbl"><i class="fas fa-percent" aria-hidden="true"></i> <span data-i18n="bill_discount_label">داشکاندن</span></span>
                                    <span id="pos-bill-discount-val" class="pos-bill-breakdown-val">0</span>
                                </div>
                            </div>
                            <div class="pos-bill-total-main">
                                <span class="bill-total-label"><i class="fas fa-calculator" aria-hidden="true"></i> <span data-i18n="bill_total_label">کۆم</span></span>
                                <h2 id="bill-total" class="bill-total-value">0</h2>
                                <div id="pos-bill-total-secondary" class="pos-bill-total-secondary" data-allow-iqd="1"></div>
                                <div id="pos-bill-fx-rate" class="pos-bill-fx-rate" data-allow-iqd="1"></div>
                            </div>
                            <div id="pos-gift-summary" class="pos-gift-summary is-hidden" aria-live="polite">
                                <div class="pos-gift-summary-main">
                                    <i class="fas fa-gift" aria-hidden="true"></i>
                                    <span class="pos-gift-summary-lbl" data-i18n="pos_gift_summary_label">دیاری:</span>
                                    <strong id="pos-gift-summary-text">0</strong>
                                </div>
                                <div id="pos-gift-summary-detail" class="pos-gift-summary-detail"></div>
                            </div>
                            <div id="pos-debt-remaining-info" class="debt-summary-card returns-debt-summary-compact txn-pos-debt-strip" aria-live="polite" style="display:none;">
                                <div class="debt-summary-compact-bar" onclick="if(typeof togglePosDebtDetails==='function')togglePosDebtDetails();" title="تەفاسیلێن قەرزی" role="button" tabindex="0">
                                    <div class="debt-summary-compact-main">
                                        <span class="debt-summary-label" data-i18n="purchase_debt_remaining">قەرزی ماوە:</span>
                                        <strong class="debt-summary-final-value" id="pos-debt-remaining-compact">0</strong>
                                    </div>
                                    <button type="button" class="btn-toggle-purchase-details" id="btn-toggle-pos-debt" aria-expanded="false" title="تەفاسیل / وردەکاری" onclick="event.stopPropagation(); if(typeof togglePosDebtDetails==='function')togglePosDebtDetails();">
                                        <span class="btn-toggle-purchase-details-txt" data-i18n="purchase_debt_details">تەفاسیل</span>
                                        <i class="fas fa-chevron-down txn-details-chevron" aria-hidden="true"></i>
                                    </button>
                                </div>
                                <div id="pos-debt-expanded-rows" class="purchase-debt-expanded-rows is-collapsed">
                                    <div class="debt-summary-row debt-summary-old">
                                        <span class="debt-summary-label" data-i18n="purchase_debt_old">قەرزی کۆن</span>
                                        <span class="debt-summary-value" id="pos-debt-old-val">0</span>
                                    </div>
                                    <div class="debt-summary-row debt-summary-current">
                                        <span class="debt-summary-label" data-i18n="purchase_debt_this_invoice">ئەڤ وەسڵ</span>
                                        <span class="debt-summary-value" id="pos-debt-invoice-val">0</span>
                                    </div>
                                    <div class="debt-summary-row debt-summary-cash">
                                        <span class="debt-summary-label" data-i18n="purchase_debt_cash_paid">نەقد (پارێ دای)</span>
                                        <span class="debt-summary-value debt-summary-cash-value" id="pos-debt-cash-val">0</span>
                                    </div>
                                    <div class="debt-summary-row debt-summary-credit" id="pos-debt-added-row">
                                        <span class="debt-summary-label" data-i18n="purchase_debt_from_invoice">قەرزی ئەڤ وەسڵ</span>
                                        <span class="debt-summary-value debt-summary-credit-value" id="pos-debt-added-val">0</span>
                                    </div>
                                    <div class="debt-summary-divider"></div>
                                    <div class="debt-summary-row debt-summary-final">
                                        <span class="debt-summary-label" data-i18n="purchase_debt_remaining">قەرزی ماوە</span>
                                        <span class="debt-summary-value debt-summary-final-value" id="pos-debt-remaining-val">0</span>
                                    </div>
                                    <div class="debt-summary-row debt-summary-payment-due" id="pos-payment-due-row" style="display:none;">
                                        <span class="debt-summary-label" data-i18n="payment_due_label">مەوعدێ پارەدانێ</span>
                                        <span class="debt-summary-value debt-summary-payment-due-controls">
                                            <input type="number" id="pos-payment-due-value" class="input-std txn-payment-due-value" min="0" step="1" value="0" inputmode="numeric" dir="ltr" aria-label="مەوعد">
                                            <select id="pos-payment-due-unit" class="input-std txn-payment-due-unit" aria-label="یەکە">
                                                <option value="minute" data-i18n-opt="payment_term_unit_minute">خولەک</option>
                                                <option value="hour" data-i18n-opt="payment_term_unit_hour">دەمژمێر</option>
                                                <option value="day" data-i18n-opt="payment_term_unit_day" selected>ڕۆژ</option>
                                                <option value="month" data-i18n-opt="payment_term_unit_month">مانگ</option>
                                                <option value="year" data-i18n-opt="payment_term_unit_year">ساڵ</option>
                                            </select>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="pos-tabs-container" class="pos-tabs-wrapper no-print"></div>
                        <p id="bill-footer-msg" style="text-align:center; font-size:0.8rem; margin-top:10px; display:none;">سوپاس بۆ سەرەدانا هەوە</p>
                        <div id="pos-actions-default" class="no-print pos-bill-actions-wrap">
                            <div class="pos-action-grid pos-bill-action-grid pos-bill-checkout-bar">
                                <div class="pos-action-left pos-bill-tools" role="group" aria-label="ئامرازەکانی سەبەتە">
                                    <button type="button" class="btn-pos-mini btn-pos-tool danger cashier-only" onclick="cancelOrder()" data-i18n-title="btn_pos_clear" title="ژێبرن"><i class="fas fa-trash-alt" aria-hidden="true"></i><span class="pos-tool-label" data-i18n="btn_pos_clear">ژێبرن</span></button>
                                    <button type="button" class="btn-pos-mini btn-pos-tool cashier-only" onclick="nav('tables')" data-i18n-title="btn_pos_hold" title="هەگرتن"><i class="fas fa-pause" aria-hidden="true"></i><span class="pos-tool-label" data-i18n="btn_pos_hold">هەگرتن</span></button>
                                    <button type="button" class="btn-pos-mini btn-pos-tool cashier-only" onclick="printProforma()" data-i18n-title="btn_pos_print_proforma" title="لیست"><i class="fas fa-print" aria-hidden="true"></i><span class="pos-tool-label" data-i18n="btn_pos_print_proforma">لیست</span></button>
                                    <button type="button" id="btn-quick-printnote-toggle-footer" class="btn-pos-mini btn-pos-tool cashier-only" onclick="if(typeof togglePrintNotePopupQuick==='function')togglePrintNotePopupQuick()" data-i18n-title="pds_print_note_checkbox" title="نیشاندانی پەنجەرەی «تێبینی پێش چاپ» (پێشنیارکراو)" aria-pressed="true"><i class="fas fa-sticky-note" aria-hidden="true"></i></button>
                                    <button type="button" id="btn-pos-kitchen" class="btn-pos-mini btn-pos-tool cashier-only" onclick="printKitchen()" data-i18n-title="btn_pos_print_kitchen" title="چێشتخانە"><i class="fas fa-utensils" aria-hidden="true"></i><span class="pos-tool-label" data-i18n="btn_pos_print_kitchen">چێشتخانە</span></button>
                                </div>
                                <div class="pos-action-right pos-bill-checkout-actions">
                                    <button type="button" class="btn-sell-large btn-sell-primary" onclick="sellFromPos()" data-i18n-title="pos_btn_sell" title="فروشتن"><i class="fas fa-cash-register" aria-hidden="true"></i> <span data-i18n="pos_btn_sell">فروشتن</span></button>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div><!-- /.bill-expand-main -->
                </div>
            </div>
        </div>

        <!-- RETURNS SCREEN (same shell as POS / فرۆشتن) -->
        <div id="view-returns-new" class="workspace txn-mobile-screen txn-view-shell txn-theme txn-theme--sales-return">
            <div class="pos-layout returns-layout">
                <div id="returns-menu-panel" class="pos-menu returns-menu no-print">
                    <div class="pos-top-bar txn-view-top-bar pos-header-polished no-print">
                        <div class="pos-header-row pos-header-row-top">
                            <div class="pos-header-brand txn-screen-head-returns">
                                <div class="txn-screen-head-icon txn-screen-head-icon-danger" aria-hidden="true">
                                    <i class="fas fa-undo"></i>
                                </div>
                                <h3 class="txn-screen-head-title" data-i18n="returns_screen_title">زڤڕاندن</h3>
                            </div>
                            <div class="pos-top-bar-actions pos-header-toolbar">
                                <button type="button" class="btn btn-sm btn-pos-refresh pos-header-tool-btn txn-toolbar-refresh" onclick="if(typeof syncLiveData==='function')syncLiveData();" data-i18n-title="returns_sync_title" title="تازەکردنەوە" aria-label="تازەکردنەوە"><i class="fas fa-sync-alt"></i></button>
                                <div class="txn-toolbar-more">
                                    <button type="button" class="btn btn-sm pos-header-tool-btn" onclick="if(typeof renderReturnsReport==='function')renderReturnsReport(); var m=document.getElementById('returns-history-modal'); if(m)m.style.display='flex';" data-i18n-title="returns_history_title" title="مێژوو"><i class="fas fa-history"></i></button>
                                    <button type="button" id="returns-manual-toggle-btn" class="btn btn-sm pos-header-tool-btn returns-manual-btn" onclick="if(typeof toggleManualReturnMode==='function')toggleManualReturnMode()" data-i18n-title="returns_manual_mode_title" title="زڤراندنا بێ وەسڵ"><i class="fas fa-box-open"></i></button>
                                </div>
                                <button type="button" class="btn btn-sm pos-header-tool-btn txn-toolbar-toggle" title="زیاتر" aria-label="زیاتر"><i class="fas fa-ellipsis-h"></i></button>
                                <button type="button" class="btn btn-sm pos-header-tool-btn" onclick="nav('pos')" title="فرۆشتن" aria-label="فرۆشتن"><i class="fas fa-cash-register"></i></button>
                            </div>
                        </div>
                        <div class="pos-header-row pos-header-row-fields pos-header-fields-unified">
                            <div class="pos-header-search-box">
                                <div class="pos-search-unit-bar txn-unit-bar">
                                    <label class="pos-search-field" for="returns-barcode-input">
                                        <i class="fas fa-search pos-search-field-icon" aria-hidden="true"></i>
                                        <input type="text" id="returns-barcode-input" class="pos-search-input pos-header-input" data-i18n-placeholder="returns_search_placeholder" placeholder="لێگەریان / بارکۆد..." onkeyup="if(event.key !== 'Enter' && typeof debouncedRenderReturnsMenu==='function')debouncedRenderReturnsMenu(this.value)" onkeydown="if(typeof handleReturnsBarcode==='function')handleReturnsBarcode(event)" oninput="convertArabicNumerals(this)">
                                    </label>
                                    <div id="returns-unit-toggles" class="pos-unit-toggles no-print">
                                        <button type="button" id="btn-returns-unit-piece" class="pos-unit-btn active" data-unit="piece" onclick="setReturnsUnit('piece')" data-i18n-title="pos_unit_piece" title="تاک"><i class="fas fa-cube"></i></button>
                                        <button type="button" id="btn-returns-unit-pack" class="pos-unit-btn" data-unit="pack" onclick="setReturnsUnit('pack')" data-i18n-title="pos_unit_pack" title="پاکێت"><i class="fas fa-boxes"></i></button>
                                        <button type="button" id="btn-returns-unit-carton" class="pos-unit-btn" data-unit="carton" onclick="setReturnsUnit('carton')" data-i18n-title="pos_unit_carton" title="کارتۆن"><i class="fas fa-box"></i></button>
                                        <label class="search-inline-toggle pos-payment-wallet-btn" title="شاشەیا پارەدانێ" data-i18n-title="settings_t_payment_modal" style="display:none;">
                                            <input type="checkbox" id="quick-pay-toggle-returns" onchange="window.togglePaymentModalSetting(this.checked)">
                                            <i class="fas fa-wallet"></i>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="pos-header-fields-divider" aria-hidden="true"></div>
                            <div class="pos-header-customer-box txn-meta-sticky is-collapsed" data-txn-meta="returns-new">
                                <span class="pos-header-customer-label no-print" aria-hidden="true"><i class="fas fa-user"></i></span>
                                <button type="button" class="txn-meta-toggle no-print" aria-expanded="false">
                                    <span><i class="fas fa-user"></i> کریار و وەسڵ</span>
                                    <i class="fas fa-chevron-down txn-meta-chevron" aria-hidden="true"></i>
                                </button>
                                <div class="txn-meta-body">
                                    <div class="pos-customer-meta-row txn-meta-fields-row purchase-top-supplier-row">
                                        <div class="purchase-top-field txn-meta-field pos-customer-name-field">
                                            <label class="purchase-label pos-field-label-desktop-hide" for="returns-debt-select"><i class="fas fa-user"></i> <span data-i18n="returns_customer_label">کریار</span></label>
                                            <select id="returns-debt-select" class="input-std purchase-supplier-select pos-header-input" onchange="if(typeof updateReturnsDebtSummary==='function')updateReturnsDebtSummary(); if(typeof renderReturnsMenu==='function')renderReturnsMenu((document.getElementById('returns-barcode-input')&&document.getElementById('returns-barcode-input').value)||''); if(typeof window.maybeCollapseTxnMetaAfterValid==='function')window.maybeCollapseTxnMetaAfterValid('returns-new',['returns-new-invoice-ref']);">
                                                <option value="" data-i18n-opt="returns_select_customer">-- هەڵبژێرە --</option>
                                            </select>
                                        </div>
                                        <div class="purchase-top-field txn-meta-field">
                                            <label class="purchase-label pos-field-label-desktop-hide" for="returns-new-invoice-ref"><span class="required-asterisk">*</span> <span data-i18n="returns_sale_invoice_label">پسوولە</span></label>
                                            <input type="text" id="returns-new-invoice-ref" class="input-std pos-header-input" required data-i18n-placeholder="returns_invoice_ref_placeholder" placeholder="ژمارا وەسڵ..." maxlength="20" dir="ltr" onkeyup="if(typeof renderReturnsMenu==='function')renderReturnsMenu((document.getElementById('returns-barcode-input')&&document.getElementById('returns-barcode-input').value)||''); if(typeof window.maybeCollapseTxnMetaAfterValid==='function')window.maybeCollapseTxnMetaAfterValid('returns-new',['returns-new-invoice-ref']);" oninput="convertArabicNumerals(this)">
                                        </div>
                                    </div>
                                    <div id="returns-manual-warning" class="returns-manual-warning-banner" style="display:none;">
                                        <span data-i18n="returns_manual_warning">دۆخی زڤڕاندنێ دەستی: ئەڤ زڤڕاندنە پەیوەست نینە بە وەسڵێکی فرۆتن.</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="returns-category-tabs-scroll-wrap" class="category-tabs-scroll-wrap">
                        <button type="button" class="cat-scroll-btn" data-cat-scroll="prev" onclick="if(typeof scrollTxnCategoryTabs==='function')scrollTxnCategoryTabs('returns-category-tabs',false);" title="پێشوو" aria-label="پێشوو"><i class="fas fa-chevron-right"></i></button>
                        <div id="returns-category-tabs" class="category-list-container"></div>
                        <button type="button" class="cat-scroll-btn" data-cat-scroll="next" onclick="if(typeof scrollTxnCategoryTabs==='function')scrollTxnCategoryTabs('returns-category-tabs',true);" title="دواتر" aria-label="دواتر"><i class="fas fa-chevron-left"></i></button>
                    </div>
                    <div class="pos-content-wrapper">
                        <div class="pos-products-toolbar no-print">
                            <span class="pos-products-toolbar-title"><i class="fas fa-undo-alt" aria-hidden="true"></i> کاڵا بۆ زڤڕاندن</span>
                            <span id="returns-products-count" class="pos-products-count-badge">0</span>
                        </div>
                        <div id="returns-products" class="product-grid"></div>
                    </div>
                </div>
                <div class="cart-resize-divider no-print" data-resize-handle="returns" role="separator" aria-orientation="vertical" aria-valuemin="280" aria-valuemax="960" aria-label="قەبارەی سەبەتە" title="ڕاکێشە بۆ گەورە/بچووککردنی سەبەتە"></div>
                <div id="returns-bill-panel" class="pos-bill returns-bill returns-bill-redesign unified-cart-panel txn-sheet-panel txn-sheet-collapsed">
                    <div class="returns-bill-header pos-bill-header-slim no-print">
                        <h2 class="returns-bill-title"><i class="fas fa-shopping-basket"></i> <span data-i18n="returns_bill_title">سەبەتە</span></h2>
                        <div class="pos-bill-header-slim-actions pos-cart-chrome no-print">
                            <div class="pos-cart-size-tools" role="group" aria-label="قەبارەی سەبەتە">
                                <button type="button" class="pos-cart-chrome-btn" onclick="if(typeof adjustCartPanelWidth==='function')adjustCartPanelWidth(-80);" title="بچووکتر" aria-label="بچووکتر"><i class="fas fa-compress-alt"></i></button>
                                <button type="button" class="pos-cart-chrome-btn" onclick="if(typeof adjustCartPanelWidth==='function')adjustCartPanelWidth(80);" title="گەورەتر" aria-label="گەورەتر"><i class="fas fa-expand-alt"></i></button>
                                <span class="pos-cart-chrome-sep" aria-hidden="true"></span>
                                <button type="button" class="pos-cart-chrome-btn" onclick="if(typeof adjustCartDensity==='function')adjustCartDensity(-5);" title="ئایتم بچووکتر"><i class="fas fa-minus"></i></button>
                                <span class="pos-cart-density-peek">100%</span>
                                <button type="button" class="pos-cart-chrome-btn" onclick="if(typeof adjustCartDensity==='function')adjustCartDensity(5);" title="ئایتم گەورەتر"><i class="fas fa-plus"></i></button>
                            </div>
                            <button type="button" class="returns-bill-clear" onclick="if(typeof clearReturnsCart==='function')clearReturnsCart()" data-i18n-title="returns_bill_clear_title" title="پاککردنەوە"><i class="fas fa-trash-alt"></i></button>
                        </div>
                    </div>
                    <div class="bill-expand-main">
                    <div class="bill-items returns-bill-items">
                        <div class="returns-cart-header-slim basket-list-header bill-items-header no-print">
                            <span class="returns-h-item basket-h-item" data-i18n="returns_h_item">ئایتم / Item</span>
                            <span class="returns-h-disc basket-h-disc" data-i18n-title="returns_h_disc_title" title="داشکاندن (%)"><span data-i18n="returns_h_disc">داشـ</span></span>
                            <span class="returns-h-price basket-h-price" data-i18n="returns_h_price">نرخ</span>
                            <span class="returns-h-qty basket-h-qty" data-i18n="returns_h_qty">ژمارە / Qty</span>
                            <span class="returns-h-qty basket-h-history" data-i18n="returns_h_history">مێژوو</span>
                            <span class="returns-h-total basket-h-total" data-i18n="returns_h_total">کۆم / Total</span>
                            <span class="returns-h-action basket-h-action"></span>
                        </div>
                        <div id="returns-bill-rows" class="returns-cart-rows-wrap"></div>
                    </div>
                    <div class="bill-footer pos-bill-footer-compact returns-bill-footer">
                        <div class="returns-footer-customer txn-mobile-hide-footer-dup">
                            <span class="returns-footer-label" data-i18n="returns_debt_on_label">قەرز ل سەر</span>
                            <select id="returns-debt-customer" class="returns-debt-select pos-header-input" onchange="if(typeof updateReturnsDebtSummary==='function')updateReturnsDebtSummary(); var selTop=document.getElementById('returns-debt-select'); if(selTop)selTop.value=this.value; if(typeof renderReturnsMenu==='function')renderReturnsMenu((document.getElementById('returns-barcode-input')&&document.getElementById('returns-barcode-input').value)||'');">
                                <option value="" data-i18n-opt="returns_select_payment">نەقد</option>
                            </select>
                        </div>
                        <div class="returns-debt-summary debt-summary-card returns-debt-summary-compact txn-returns-debt-strip" id="returns-debt-summary">
                            <div class="debt-summary-compact-bar" onclick="if(typeof toggleReturnsDebtDetails==='function')toggleReturnsDebtDetails();" title="تەفاسیلێن قەرزی" role="button" tabindex="0">
                                <div class="debt-summary-compact-main">
                                    <span class="debt-summary-label" data-i18n="returns_total_debt_after">کۆی قەرز:</span>
                                    <strong class="debt-summary-final-value" id="returns-new-debt-compact">0</strong>
                                </div>
                                <button type="button" class="btn-toggle-purchase-details" id="btn-toggle-returns-debt" aria-expanded="false" title="تەفاسیل / وردەکاری" onclick="event.stopPropagation(); if(typeof toggleReturnsDebtDetails==='function')toggleReturnsDebtDetails();">
                                    <span class="btn-toggle-purchase-details-txt" data-i18n="purchase_debt_details">تەفاسیل</span>
                                    <i class="fas fa-chevron-down txn-details-chevron" aria-hidden="true"></i>
                                </button>
                            </div>
                            <div id="returns-debt-expanded-rows" class="purchase-debt-expanded-rows is-collapsed">
                                <div class="debt-summary-row debt-summary-old">
                                    <span class="debt-summary-label" data-i18n="returns_old_debt">قەرزێ کەڤن</span>
                                    <span class="debt-summary-value" id="returns-old-debt">0</span>
                                </div>
                                <div class="debt-summary-row debt-summary-current">
                                    <span class="debt-summary-label" data-i18n="returns_return_subtotal">کۆی زڤڕاندنێ</span>
                                    <span class="debt-summary-value" id="returns-total-return">0</span>
                                </div>
                                <div class="debt-summary-divider"></div>
                                <div class="debt-summary-row debt-summary-final">
                                    <span class="debt-summary-label" data-i18n="returns_total_debt_after">کۆی قەرز</span>
                                    <span class="debt-summary-value debt-summary-final-value" id="returns-new-debt">0</span>
                                </div>
                            </div>
                        </div>
                        <button type="button" class="txn-meta-details-toggle no-print" data-txn-details="returns-meta" aria-expanded="false">وردەکاری <i class="fas fa-chevron-down"></i></button>
                        <div class="returns-meta-row is-collapsed" id="returns-meta-details">
                            <span class="returns-meta-item"><span id="returns-cash-deducted">0</span> <span data-i18n="returns_meta_from_drawer">ژ قاسێ</span></span>
                            <span class="returns-meta-item"><span id="returns-profit-lost">0</span> <span data-i18n="returns_meta_profit">ڕبح</span></span>
                            <span class="returns-meta-item"><i class="fas fa-box"></i> <span id="returns-stock-added">0</span> <span data-i18n="returns_meta_piece">تاک</span></span>
                        </div>
                        <div class="bill-total-section pos-bill-total-strip">
                            <div class="pos-bill-total-main">
                                <span class="bill-total-label" data-i18n="returns_total_bar_label">کۆم</span>
                                <h2 id="returns-bill-total" class="bill-total-value">0</h2>
                            </div>
                        </div>
                        <div class="pos-action-grid pos-bill-action-grid pos-bill-checkout-bar no-print">
                            <div class="pos-action-left pos-bill-tools" role="group" aria-label="ئامراز">
                                <button type="button" class="btn-pos-mini btn-pos-tool danger" onclick="if(typeof clearReturnsCart==='function')clearReturnsCart()" title="ژێبرن"><i class="fas fa-trash-alt"></i><span class="pos-tool-label">ژێبرن</span></button>
                            </div>
                            <div class="pos-action-right pos-bill-checkout-actions">
                                <button type="button" class="btn-sell-large btn-sell-primary btn-sell-returns returns-confirm-btn" onclick="if(typeof processReturnsCart==='function')processReturnsCart()" data-i18n-title="returns_confirm_btn" title="پەسەندکرن"><i class="fas fa-check" aria-hidden="true"></i> <span data-i18n="returns_confirm_btn">پەسەندکرن</span></button>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- PURCHASE SCREEN (same shell as POS / فرۆشتن) -->
        <div id="view-purchase" class="workspace txn-mobile-screen txn-view-shell txn-theme txn-theme--purchase">
            <div class="pos-layout returns-layout">
                <div id="purchase-menu-panel" class="pos-menu returns-menu no-print">
                    <div class="pos-top-bar txn-view-top-bar pos-header-polished no-print">
                        <div class="pos-header-row pos-header-row-top">
                            <div class="pos-header-brand txn-screen-head-purchase">
                                <div class="txn-screen-head-icon txn-screen-head-icon-purchase" aria-hidden="true">
                                    <i class="fas fa-truck"></i>
                                </div>
                                <h3 class="txn-screen-head-title" data-i18n="view_purchase_title">کڕین</h3>
                            </div>
                            <div class="pos-top-bar-actions pos-header-toolbar">
                                <button type="button" class="btn btn-sm btn-pos-refresh pos-header-tool-btn txn-toolbar-refresh" onclick="if(typeof debouncedRenderPurchaseProductGrid==='function')debouncedRenderPurchaseProductGrid(); if(typeof renderPurchaseCart==='function')renderPurchaseCart();" title="تازەکردنەوە" aria-label="تازەکردنەوە"><i class="fas fa-sync-alt"></i></button>
                                <button type="button" class="btn btn-sm pos-header-tool-btn" onclick="nav('pos')" title="فرۆشتن / پۆس" aria-label="فرۆشتن"><i class="fas fa-cash-register"></i></button>
                            </div>
                        </div>
                        <div class="pos-header-row pos-header-row-fields purchase-header-layout">
                            <div class="purchase-supplier-panel txn-meta-sticky is-collapsed" data-txn-meta="purchase">
                                <button type="button" class="txn-meta-toggle no-print" aria-expanded="false">
                                    <span><i class="fas fa-building"></i> <span data-i18n="purchase_meta_section_title">دابینکەر و وەسڵ</span></span>
                                    <i class="fas fa-chevron-down txn-meta-chevron" aria-hidden="true"></i>
                                </button>
                                <div class="txn-meta-body purchase-supplier-panel__body">
                                    <div class="purchase-supplier-grid purchase-top-supplier-row">
                                        <div class="purchase-top-field purchase-top-field-supplier txn-meta-field">
                                            <label class="purchase-label" for="purchase-supplier-select"><i class="fas fa-building"></i> <span data-i18n="purchase_supplier_label">دابینکەر</span></label>
                                            <div class="purchase-supplier-select-row">
                                                <button type="button" class="btn btn-brand purchase-supplier-add-btn" onclick="if(typeof quickAddCompany==='function')quickAddCompany()" title="زێدەکرنا کۆمپانیەکێ نوێ"><i class="fas fa-plus"></i></button>
                                                <select id="purchase-supplier-select" class="input-std purchase-supplier-select pos-header-input" onchange="onPurchaseSupplierChange()">
                                                    <option value="">-- هەڵبژێرە --</option>
                                                </select>
                                                <datalist id="purchase-company-list"></datalist>
                                            </div>
                                        </div>
                                        <div class="purchase-top-field purchase-paid-field txn-meta-field is-hidden-until-supplier">
                                            <label class="purchase-label" for="purchase-supplier-paid"><i class="fas fa-money-bill-wave"></i> <span data-i18n="purchase_supplier_paid_label">پارێ دای</span></label>
                                            <input type="text" inputmode="decimal" id="purchase-supplier-paid" class="input-std purchase-supplier-paid-input pos-header-input" placeholder="پارێ دای" data-i18n-placeholder="purchase_supplier_paid_ph_iqd" oninput="if(typeof onPurchaseSupplierPaidInput==='function'){onPurchaseSupplierPaidInput(this);}else if(typeof calculatePurchaseDebtRemaining==='function'){calculatePurchaseDebtRemaining();}" onblur="if(typeof onPurchaseSupplierPaidInput==='function'){onPurchaseSupplierPaidInput(this);}">
                                        </div>
                                        <div class="purchase-top-field purchase-top-field-invoice txn-meta-field">
                                            <label class="purchase-label purchase-inv-batch-label" for="purchase-supplier-invoice-number">
                                                <span class="required-asterisk">*</span>
                                                <i class="fas fa-file-invoice"></i>
                                                <span data-i18n="purchase_invoice_ref_label">ژمارا پسوولێ</span>
                                                <span class="purchase-batch-label-part"><span class="purchase-inv-batch-sep" aria-hidden="true">·</span>
                                                <span data-i18n="purchase_batch_number_label">وەجبە</span>
                                                <span class="required-asterisk purchase-batch-required-mark">*</span></span>
                                            </label>
                                            <div class="purchase-inv-batch-row">
                                                <input type="text" id="purchase-supplier-invoice-number" class="input-std purchase-supplier-invoice-input purchase-inv-batch-main pos-header-input" placeholder="پسوولێ کۆمپانیا" data-i18n-placeholder="purchase_invoice_ref_ph" maxlength="100" dir="ltr" required onkeyup="if(typeof window.maybeCollapseTxnMetaAfterValid==='function')window.maybeCollapseTxnMetaAfterValid('purchase',['purchase-supplier-select','purchase-supplier-invoice-number','purchase-batch-number']);">
                                                <input type="text" id="purchase-batch-number" class="input-std purchase-batch-mini-input pos-header-input" placeholder="26" data-i18n-placeholder="purchase_batch_number_ph" maxlength="100" dir="ltr" required title="ژمارا وەجبێ" onkeyup="if(typeof window.maybeCollapseTxnMetaAfterValid==='function')window.maybeCollapseTxnMetaAfterValid('purchase',['purchase-supplier-select','purchase-supplier-invoice-number','purchase-batch-number']);">
                                                <button type="button" id="purchase-batch-pro-lock" class="purchase-batch-pro-lock" style="display:none;" onclick="if(typeof showPurchaseBatchPurchasePopup==='function')showPurchaseBatchPurchasePopup();" title="Pro · ژمارا وەجبێ"><i class="fas fa-lock"></i> <span data-pos-price="purchase_batch">$25</span></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="purchase-header-search-row">
                                <div class="purchase-warehouse-top-field" data-multi-wh-only>
                                    <label class="purchase-label" for="purchase-warehouse-select"><i class="fas fa-warehouse"></i> <span data-i18n="purchase_wh_default_label">کۆگەی بنەڕەت (ئایتمێن نوێ)</span></label>
                                    <select id="purchase-warehouse-select" class="input-std pos-header-input purchase-warehouse-top-select" onchange="if(typeof onPurchaseWarehouseSelectChange==='function')onPurchaseWarehouseSelectChange();"></select>
                                </div>
                                <div class="pos-search-unit-bar txn-unit-bar purchase-search-bar">
                                    <label class="pos-search-field" for="purchase-search">
                                        <i class="fas fa-search pos-search-field-icon" aria-hidden="true"></i>
                                        <input type="text" id="purchase-search" class="pos-search-input pos-header-input" placeholder="لێگەریان / بارکۆد..." onkeyup="if(typeof debouncedRenderPurchaseProductGrid==='function')debouncedRenderPurchaseProductGrid()" onkeydown="handlePurchaseBarcode(event)" oninput="convertArabicNumerals(this)">
                                    </label>
                                    <div id="purchase-unit-toggles" class="pos-unit-toggles no-print">
                                        <button type="button" id="btn-purchase-unit-piece" class="pos-unit-btn active" data-unit="piece" onclick="setPurchaseUnit('piece')" data-i18n-title="pos_unit_piece" title="تاک"><i class="fas fa-cube"></i></button>
                                        <button type="button" id="btn-purchase-unit-pack" class="pos-unit-btn" data-unit="pack" onclick="setPurchaseUnit('pack')" data-i18n-title="pos_unit_pack" title="پاکێت"><i class="fas fa-boxes"></i></button>
                                        <button type="button" id="btn-purchase-unit-carton" class="pos-unit-btn" data-unit="carton" onclick="setPurchaseUnit('carton')" data-i18n-title="pos_unit_carton" title="کارتۆن"><i class="fas fa-box"></i></button>
                                        <label class="search-inline-toggle pos-payment-wallet-btn" title="شاشەیا پارەدانێ" data-i18n-title="settings_t_payment_modal" style="display:none;">
                                            <input type="checkbox" id="quick-pay-toggle-purchase" onchange="window.togglePaymentModalSetting(this.checked)">
                                            <i class="fas fa-wallet"></i>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="purchase-category-tabs-scroll-wrap" class="category-tabs-scroll-wrap">
                        <button type="button" class="cat-scroll-btn" data-cat-scroll="prev" onclick="if(typeof scrollTxnCategoryTabs==='function')scrollTxnCategoryTabs('purchase-category-tabs',false);" title="پێشوو" aria-label="پێشوو"><i class="fas fa-chevron-right"></i></button>
                        <div id="purchase-category-tabs" class="category-list-container"></div>
                        <button type="button" class="cat-scroll-btn" data-cat-scroll="next" onclick="if(typeof scrollTxnCategoryTabs==='function')scrollTxnCategoryTabs('purchase-category-tabs',true);" title="دواتر" aria-label="دواتر"><i class="fas fa-chevron-left"></i></button>
                    </div>
                    <div class="pos-content-wrapper">
                        <div class="pos-products-toolbar no-print">
                            <span class="pos-products-toolbar-title"><i class="fas fa-boxes" aria-hidden="true"></i> کاڵاکان بۆ کڕین</span>
                            <span id="purchase-products-count" class="pos-products-count-badge">0</span>
                        </div>
                        <div id="purchase-product-grid" class="product-grid"></div>
                    </div>
                </div>
                <div class="cart-resize-divider no-print" data-resize-handle="purchase" role="separator" aria-orientation="vertical" aria-valuemin="280" aria-valuemax="960" aria-label="قەبارەی سەبەتە" title="ڕاکێشە بۆ گەورە/بچووککردنی سەبەتە"></div>
                <div id="purchase-cart-panel" class="pos-bill returns-bill returns-bill-redesign unified-cart-panel txn-sheet-panel txn-sheet-collapsed">
                    <div class="returns-bill-header pos-bill-header-slim no-print">
                        <h2 class="returns-bill-title"><i class="fas fa-shopping-basket"></i> سەبەتە</h2>
                        <div class="pos-bill-header-slim-actions pos-cart-chrome no-print">
                            <div class="pos-cart-size-tools" role="group" aria-label="قەبارەی سەبەتە">
                                <button type="button" class="pos-cart-chrome-btn" onclick="if(typeof adjustCartPanelWidth==='function')adjustCartPanelWidth(-80);" title="بچووکتر" aria-label="بچووکتر"><i class="fas fa-compress-alt"></i></button>
                                <button type="button" class="pos-cart-chrome-btn" onclick="if(typeof adjustCartPanelWidth==='function')adjustCartPanelWidth(80);" title="گەورەتر" aria-label="گەورەتر"><i class="fas fa-expand-alt"></i></button>
                                <span class="pos-cart-chrome-sep" aria-hidden="true"></span>
                                <button type="button" class="pos-cart-chrome-btn" onclick="if(typeof adjustCartDensity==='function')adjustCartDensity(-5);" title="ئایتم بچووکتر"><i class="fas fa-minus"></i></button>
                                <span class="pos-cart-density-peek">100%</span>
                                <button type="button" class="pos-cart-chrome-btn" onclick="if(typeof adjustCartDensity==='function')adjustCartDensity(5);" title="ئایتم گەورەتر"><i class="fas fa-plus"></i></button>
                            </div>
                            <button type="button" class="returns-bill-clear" onclick="if(typeof clearPurchaseCart==='function')clearPurchaseCart()" title="پاککردنەوە"><i class="fas fa-trash-alt"></i></button>
                        </div>
                    </div>
                    <div class="bill-expand-main">
                    <div class="bill-items returns-bill-items">
                        <div class="returns-cart-header-slim basket-list-header bill-items-header purchase-cart-header-slim no-print">
                            <span class="returns-h-exp-chk purchase-h-exp-chk" title="تیک = بەسەرچوون"><i class="fas fa-calendar-check" aria-hidden="true"></i></span>
                            <span class="returns-h-item basket-h-item">ئایتم / Item</span>
                            <span class="returns-h-expiry purchase-h-expiry" title="تاریخا بەسەرچوونێ">بەروار</span>
                            <span class="returns-h-disc basket-h-disc" title="داشکاندن (%)">داشـ</span>
                            <span class="returns-h-price basket-h-price purchase-h-cost" title="نرخێ کڕینێ">کڕین</span>
                            <span class="returns-h-price basket-h-price purchase-h-sell" title="نرخێ فرۆشتنێ">فرۆشتن</span>
                            <span class="returns-h-qty basket-h-qty">ژمارە / Qty</span>
                            <span class="returns-h-total basket-h-total">کۆم / Total</span>
                            <span class="returns-h-action basket-h-action"></span>
                        </div>
                        <div id="purchase-cart-rows" class="returns-cart-rows-wrap"></div>
                    </div>
                    <div class="bill-footer pos-bill-footer-compact returns-bill-footer">
                        <input type="hidden" name="purchase-payment-type" id="purchase-payment-type-value" value="cash">
                        <div class="bill-total-section pos-bill-total-strip">
                            <div class="pos-cart-strip-actions purchase-cart-strip-actions">
                                <div class="cart-pay-method-toggle" data-cart-pay="purchase" role="group" aria-label="جۆرێ پارەدانێ">
                                    <button type="button" class="cart-pay-method-btn is-active" data-pay="cash" aria-pressed="true" onclick="if(typeof setCartPayMethod==='function')setCartPayMethod('purchase','cash')" title="کاش" data-i18n-title="payment_method_cash"><i class="fas fa-money-bill-wave" aria-hidden="true"></i><span class="cart-pay-method-lbl" data-i18n="payment_method_cash">کاش</span></button>
                                    <button type="button" class="cart-pay-method-btn" data-pay="fib" aria-pressed="false" onclick="if(typeof setCartPayMethod==='function')setCartPayMethod('purchase','fib')" title="FIB" data-i18n-title="payment_method_fib"><i class="fas fa-university" aria-hidden="true"></i><span class="cart-pay-method-lbl">FIB</span></button>
                                </div>
                            </div>
                            <div class="pos-bill-total-main purchase-total-editable">
                                <span class="bill-total-label">کۆم</span>
                                <select id="purchase-currency" class="input-std purchase-currency-select" data-allow-iqd="1" onchange="if(typeof onPurchaseCurrencyChange==='function')onPurchaseCurrencyChange();" title="دراڤ" aria-label="دراڤ">
                                    <option value="IQD">IQD</option>
                                    <option value="USD">USD</option>
                                </select>
                                <div class="purchase-total-step-wrap">
                                    <button type="button" class="purchase-price-nudge purchase-total-nudge" onclick="if(typeof nudgePurchaseCartGrandTotal==='function')nudgePurchaseCartGrandTotal(-1)" title="کێمکرنا کۆم" aria-label="کێمکرنا کۆم"><i class="fas fa-minus"></i></button>
                                    <h2 id="purchase-cart-total" class="bill-total-value" role="button" tabindex="0" onclick="if(typeof openPurchaseCartTotalEdit==='function')openPurchaseCartTotalEdit()" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();if(typeof openPurchaseCartTotalEdit==='function')openPurchaseCartTotalEdit();}" data-i18n-title="purchase_total_edit_title" title="کلیک بکە بۆ دەستکاریکرنا کۆم">0</h2>
                                    <button type="button" class="purchase-price-nudge purchase-total-nudge" onclick="if(typeof nudgePurchaseCartGrandTotal==='function')nudgePurchaseCartGrandTotal(1)" title="زێدەکرنا کۆم" aria-label="زێدەکرنا کۆم"><i class="fas fa-plus"></i></button>
                                </div>
                                <div id="purchase-cart-total-secondary" class="pos-bill-total-secondary" data-allow-iqd="1"></div>
                            </div>
                            <div id="purchase-gift-summary" class="purchase-gift-summary is-hidden" aria-live="polite">
                                <div class="purchase-gift-summary-main">
                                    <i class="fas fa-gift" aria-hidden="true"></i>
                                    <span class="purchase-gift-summary-lbl">دیاری:</span>
                                    <strong id="purchase-gift-summary-text">0</strong>
                                </div>
                                <div id="purchase-gift-summary-detail" class="purchase-gift-summary-detail"></div>
                            </div>
                            <div id="purchase-debt-summary" class="debt-summary-card returns-debt-summary-compact txn-purchase-debt-strip is-hidden" aria-live="polite">
                                <div class="debt-summary-compact-bar" onclick="if(typeof togglePurchaseDebtDetails==='function')togglePurchaseDebtDetails();" title="تەفاسیلێن قەرزی" role="button" tabindex="0">
                                    <div class="debt-summary-compact-main">
                                        <span class="debt-summary-label" data-i18n="purchase_debt_remaining">قەرزی ماوە:</span>
                                        <strong class="debt-summary-final-value" id="purchase-new-balance-compact">0</strong>
                                    </div>
                                    <button type="button" class="btn-toggle-purchase-details" id="btn-toggle-purchase-debt" aria-expanded="false" title="تەفاسیل / وردەکاری" onclick="event.stopPropagation(); if(typeof togglePurchaseDebtDetails==='function')togglePurchaseDebtDetails();">
                                        <span class="btn-toggle-purchase-details-txt" data-i18n="purchase_debt_details">تەفاسیل</span>
                                        <i class="fas fa-chevron-down txn-details-chevron" aria-hidden="true"></i>
                                    </button>
                                </div>
                                <div id="purchase-debt-expanded-rows" class="purchase-debt-expanded-rows is-collapsed">
                                    <div class="debt-summary-row debt-summary-old">
                                        <span class="debt-summary-label" data-i18n="purchase_debt_old">قەرزی کۆن</span>
                                        <span class="debt-summary-value" id="purchase-previous-debt">0</span>
                                    </div>
                                    <div class="debt-summary-row debt-summary-current">
                                        <span class="debt-summary-label" data-i18n="purchase_debt_this_invoice">ئەڤ وەسڵ</span>
                                        <span class="debt-summary-value" id="purchase-invoice-total">0</span>
                                    </div>
                                    <div class="debt-summary-row debt-summary-cash">
                                        <span class="debt-summary-label" data-i18n="purchase_debt_cash_paid">نەقد (پارێ دای)</span>
                                        <span class="debt-summary-value debt-summary-cash-value" id="purchase-cash-paid">0</span>
                                    </div>
                                    <div class="debt-summary-row debt-summary-credit" id="purchase-debt-added-row">
                                        <span class="debt-summary-label" data-i18n="purchase_debt_from_invoice">قەرزی ئەڤ وەسڵ</span>
                                        <span class="debt-summary-value debt-summary-credit-value" id="purchase-debt-added">0</span>
                                    </div>
                                    <div class="debt-summary-divider"></div>
                                    <div class="debt-summary-row debt-summary-final">
                                        <span class="debt-summary-label" data-i18n="purchase_debt_remaining">قەرزی ماوە</span>
                                        <span class="debt-summary-value debt-summary-final-value" id="purchase-new-balance">0</span>
                                    </div>
                                    <div class="debt-summary-row debt-summary-payment-due" id="purchase-payment-due-row" style="display:none;">
                                        <span class="debt-summary-label" data-i18n="payment_due_label">مەوعدێ پارەدانێ</span>
                                        <span class="debt-summary-value debt-summary-payment-due-controls">
                                            <input type="number" id="purchase-payment-due-value" class="input-std txn-payment-due-value" min="0" step="1" value="0" inputmode="numeric" dir="ltr" aria-label="مەوعد">
                                            <select id="purchase-payment-due-unit" class="input-std txn-payment-due-unit" aria-label="یەکە">
                                                <option value="minute" data-i18n-opt="payment_term_unit_minute">خولەک</option>
                                                <option value="hour" data-i18n-opt="payment_term_unit_hour">دەمژمێر</option>
                                                <option value="day" data-i18n-opt="payment_term_unit_day" selected>ڕۆژ</option>
                                                <option value="month" data-i18n-opt="payment_term_unit_month">مانگ</option>
                                                <option value="year" data-i18n-opt="payment_term_unit_year">ساڵ</option>
                                            </select>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="pos-action-grid pos-bill-action-grid pos-bill-checkout-bar no-print">
                            <div class="pos-action-left pos-bill-tools" role="group" aria-label="ئامراز">
                                <button type="button" class="btn-pos-mini btn-pos-tool danger" onclick="if(typeof clearPurchaseCart==='function')clearPurchaseCart()" title="ژێبرن"><i class="fas fa-trash-alt"></i><span class="pos-tool-label">ژێبرن</span></button>
                            </div>
                            <div class="pos-action-right pos-bill-checkout-actions">
                                <button type="button" class="btn-sell-large btn-sell-primary btn-sell-purchase" id="btn-save-purchase-invoice" onclick="if(typeof savePurchaseInvoice==='function')savePurchaseInvoice(); else if(typeof openPurchasePaymentModal==='function')openPurchasePaymentModal();" data-i18n-title="purchase_save_invoice" title="پاراستنا وەسڵێ"><i class="fas fa-save" aria-hidden="true"></i> <span data-i18n="purchase_save_invoice">پاراستنا وەسڵێ</span></button>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- PURCHASE RETURNS (same shell as POS / فرۆشتن) -->
        <div id="view-purchase-returns" class="workspace txn-mobile-screen txn-view-shell txn-theme txn-theme--purchase-return">
            <div class="pos-layout returns-layout">
                <div id="purchase-returns-menu-panel" class="pos-menu returns-menu no-print">
                    <div class="pos-top-bar txn-view-top-bar pos-header-polished no-print">
                        <div class="pos-header-row pos-header-row-top">
                            <div class="pos-header-brand txn-screen-head-purchase-return">
                                <div class="txn-screen-head-icon txn-screen-head-icon-return" aria-hidden="true">
                                    <i class="fas fa-undo-alt"></i>
                                </div>
                                <h3 class="txn-screen-head-title" data-i18n="view_purchase_returns_title">زڤڕاندنا کڕینێ</h3>
                            </div>
                            <div class="pos-top-bar-actions pos-header-toolbar">
                                <button type="button" class="btn btn-sm btn-pos-refresh pos-header-tool-btn txn-toolbar-refresh" onclick="if(typeof debouncedRenderPurchaseReturnsProductGrid==='function')debouncedRenderPurchaseReturnsProductGrid(); if(typeof renderPurchaseReturnCart==='function')renderPurchaseReturnCart();" title="تازەکردنەوە" aria-label="تازەکردنەوە"><i class="fas fa-sync-alt"></i></button>
                                <button type="button" class="btn btn-sm pos-header-tool-btn" onclick="nav('purchase')" title="کڕین" aria-label="کڕین"><i class="fas fa-shopping-basket"></i></button>
                            </div>
                        </div>
                        <div class="pos-header-row pos-header-row-fields pos-header-fields-unified">
                            <div class="pos-header-search-box">
                                <div class="pos-search-unit-bar txn-unit-bar">
                                    <label class="pos-search-field" for="purchase-returns-search">
                                        <i class="fas fa-search pos-search-field-icon" aria-hidden="true"></i>
                                        <input type="text" id="purchase-returns-search" class="pos-search-input pos-header-input" placeholder="لێگەریان / بارکۆد..." onkeyup="if(typeof debouncedRenderPurchaseReturnsProductGrid==='function')debouncedRenderPurchaseReturnsProductGrid()" onkeydown="handlePurchaseReturnBarcode(event)" oninput="convertArabicNumerals(this)">
                                    </label>
                                    <div id="purchase-returns-unit-toggles" class="pos-unit-toggles no-print">
                                        <button type="button" id="btn-purchase-returns-unit-piece" class="pos-unit-btn active" data-unit="piece" onclick="setPurchaseReturnUnit('piece')" data-i18n-title="pos_unit_piece" title="تاک"><i class="fas fa-cube"></i></button>
                                        <button type="button" id="btn-purchase-returns-unit-pack" class="pos-unit-btn" data-unit="pack" onclick="setPurchaseReturnUnit('pack')" data-i18n-title="pos_unit_pack" title="پاکێت"><i class="fas fa-boxes"></i></button>
                                        <button type="button" id="btn-purchase-returns-unit-carton" class="pos-unit-btn" data-unit="carton" onclick="setPurchaseReturnUnit('carton')" data-i18n-title="pos_unit_carton" title="کارتۆن"><i class="fas fa-box"></i></button>
                                        <label class="search-inline-toggle pos-payment-wallet-btn" title="شاشەیا پارەدانێ" data-i18n-title="settings_t_payment_modal" style="display:none;">
                                            <input type="checkbox" id="quick-pay-toggle-purchase-returns" onchange="window.togglePaymentModalSetting(this.checked)">
                                            <i class="fas fa-wallet"></i>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="pos-header-fields-divider" aria-hidden="true"></div>
                            <div class="pos-header-customer-box txn-meta-sticky is-collapsed" data-txn-meta="purchase-returns">
                                <span class="pos-header-customer-label no-print" aria-hidden="true"><i class="fas fa-building"></i></span>
                                <button type="button" class="txn-meta-toggle no-print" aria-expanded="false">
                                    <span><i class="fas fa-building"></i> دابینکەر</span>
                                    <i class="fas fa-chevron-down txn-meta-chevron" aria-hidden="true"></i>
                                </button>
                                <div class="txn-meta-body">
                                    <div class="pos-customer-meta-row txn-meta-fields-row purchase-top-supplier-row">
                                        <div class="purchase-top-field purchase-top-field-supplier txn-meta-field pos-customer-name-field">
                                            <label class="purchase-label pos-field-label-desktop-hide" for="purchase-returns-supplier-select"><i class="fas fa-building"></i> دابینکەر</label>
                                            <select id="purchase-returns-supplier-select" class="input-std purchase-supplier-select pos-header-input" onchange="onPurchaseReturnSupplierChange()">
                                                <option value="">-- هەڵبژێرە --</option>
                                            </select>
                                        </div>
                                        <div class="purchase-top-field purchase-return-invoice-ref-wrap txn-meta-field">
                                            <label class="purchase-label purchase-return-invoice-ref-label pos-field-label-desktop-hide" for="purchase-return-supplier-invoice-ref"><span class="required-asterisk">*</span> پسوولە</label>
                                            <input type="text" id="purchase-return-supplier-invoice-ref" class="input-std purchase-return-invoice-ref-input pos-header-input" oninput="if(typeof debouncedRenderPurchaseReturnsProductGrid==='function')debouncedRenderPurchaseReturnsProductGrid();" onkeyup="if(typeof debouncedRenderPurchaseReturnsProductGrid==='function')debouncedRenderPurchaseReturnsProductGrid(); if(typeof window.maybeCollapseTxnMetaAfterValid==='function')window.maybeCollapseTxnMetaAfterValid('purchase-returns',['purchase-returns-supplier-select','purchase-return-supplier-invoice-ref']);" onchange="if(typeof renderPurchaseReturnsProductGrid==='function')renderPurchaseReturnsProductGrid();" placeholder="ژمارا پسوولێ یان کڕین (000045)..." maxlength="100" dir="ltr" required>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="purchase-returns-category-tabs-scroll-wrap" class="category-tabs-scroll-wrap">
                        <button type="button" class="cat-scroll-btn" data-cat-scroll="prev" onclick="if(typeof scrollTxnCategoryTabs==='function')scrollTxnCategoryTabs('purchase-returns-category-tabs',false);" title="پێشوو" aria-label="پێشوو"><i class="fas fa-chevron-right"></i></button>
                        <div id="purchase-returns-category-tabs" class="category-list-container"></div>
                        <button type="button" class="cat-scroll-btn" data-cat-scroll="next" onclick="if(typeof scrollTxnCategoryTabs==='function')scrollTxnCategoryTabs('purchase-returns-category-tabs',true);" title="دواتر" aria-label="دواتر"><i class="fas fa-chevron-left"></i></button>
                    </div>
                    <div class="pos-content-wrapper">
                        <div class="pos-products-toolbar no-print">
                            <span class="pos-products-toolbar-title"><i class="fas fa-undo-alt" aria-hidden="true"></i> کاڵا بۆ زڤڕاندنا کڕینێ</span>
                            <span id="purchase-returns-products-count" class="pos-products-count-badge">0</span>
                        </div>
                        <div id="purchase-returns-product-grid" class="product-grid"></div>
                    </div>
                </div>
                <div class="cart-resize-divider no-print" data-resize-handle="purchase-returns" role="separator" aria-orientation="vertical" aria-valuemin="280" aria-valuemax="960" aria-label="قەبارەی سەبەتە" title="ڕاکێشە بۆ گەورە/بچووککردنی سەبەتە"></div>
                <div id="purchase-returns-cart-panel" class="pos-bill returns-bill returns-bill-redesign unified-cart-panel txn-sheet-panel txn-sheet-collapsed">
                    <div class="returns-bill-header pos-bill-header-slim no-print">
                        <h2 class="returns-bill-title"><i class="fas fa-shopping-basket"></i> سەبەتە</h2>
                        <div class="pos-bill-header-slim-actions pos-cart-chrome no-print">
                            <div class="pos-cart-size-tools" role="group" aria-label="قەبارەی سەبەتە">
                                <button type="button" class="pos-cart-chrome-btn" onclick="if(typeof adjustCartPanelWidth==='function')adjustCartPanelWidth(-80);" title="بچووکتر" aria-label="بچووکتر"><i class="fas fa-compress-alt"></i></button>
                                <button type="button" class="pos-cart-chrome-btn" onclick="if(typeof adjustCartPanelWidth==='function')adjustCartPanelWidth(80);" title="گەورەتر" aria-label="گەورەتر"><i class="fas fa-expand-alt"></i></button>
                                <span class="pos-cart-chrome-sep" aria-hidden="true"></span>
                                <button type="button" class="pos-cart-chrome-btn" onclick="if(typeof adjustCartDensity==='function')adjustCartDensity(-5);" title="ئایتم بچووکتر"><i class="fas fa-minus"></i></button>
                                <span class="pos-cart-density-peek">100%</span>
                                <button type="button" class="pos-cart-chrome-btn" onclick="if(typeof adjustCartDensity==='function')adjustCartDensity(5);" title="ئایتم گەورەتر"><i class="fas fa-plus"></i></button>
                            </div>
                            <button type="button" class="returns-bill-clear" onclick="if(typeof clearPurchaseReturnCart==='function')clearPurchaseReturnCart()" title="پاککردنەوە"><i class="fas fa-trash-alt"></i></button>
                        </div>
                    </div>
                    <div class="bill-expand-main">
                    <div class="bill-items returns-bill-items">
                        <div class="returns-cart-header-slim basket-list-header bill-items-header no-print">
                            <span class="returns-h-item basket-h-item">ئایتم / Item</span>
                            <span class="returns-h-disc basket-h-disc" title="داشکاندن (%)">داشـ</span>
                            <span class="returns-h-price basket-h-price">نرخ</span>
                            <span class="returns-h-qty basket-h-qty">ژمارە / Qty</span>
                            <span class="returns-h-total basket-h-total">کۆم / Total</span>
                            <span class="returns-h-action basket-h-action"></span>
                        </div>
                        <div id="purchase-returns-cart-rows" class="returns-cart-rows-wrap"></div>
                    </div>
                    <div class="bill-footer pos-bill-footer-compact returns-bill-footer">
                        <div class="returns-debt-summary debt-summary-card returns-debt-summary-compact txn-purchase-return-debt-strip" id="purchase-return-debt-summary">
                            <div class="debt-summary-compact-bar" onclick="if(typeof togglePurchaseReturnDebtDetails==='function')togglePurchaseReturnDebtDetails();" title="تەفاسیلێن قەرزی" role="button" tabindex="0">
                                <div class="debt-summary-compact-main">
                                    <span class="debt-summary-label">کۆی قەرز:</span>
                                    <strong class="debt-summary-final-value" id="purchase-return-updated-balance-compact">0</strong>
                                </div>
                                <button type="button" class="btn-toggle-purchase-details" id="btn-toggle-purchase-return-debt" aria-expanded="false" title="تەفاسیل / وردەکاری" onclick="event.stopPropagation(); if(typeof togglePurchaseReturnDebtDetails==='function')togglePurchaseReturnDebtDetails();">
                                    <span class="btn-toggle-purchase-details-txt" data-i18n="purchase_debt_details">تەفاسیل</span>
                                    <i class="fas fa-chevron-down txn-details-chevron" aria-hidden="true"></i>
                                </button>
                            </div>
                            <div id="purchase-return-debt-expanded-rows" class="purchase-debt-expanded-rows is-collapsed">
                                <div class="debt-summary-row debt-summary-old">
                                    <span class="debt-summary-label">قەرزێ کەڤن</span>
                                    <span class="debt-summary-value" id="purchase-return-previous-debt">0</span>
                                </div>
                                <div class="debt-summary-row debt-summary-current">
                                    <span class="debt-summary-label">بەهایێ ڤێ پسوولەیێ</span>
                                    <span class="debt-summary-value" id="purchase-return-total-value">0</span>
                                </div>
                                <div class="debt-summary-divider"></div>
                                <div class="debt-summary-row debt-summary-final">
                                    <span class="debt-summary-label">کۆی قەرز</span>
                                    <span class="debt-summary-value debt-summary-final-value" id="purchase-return-updated-balance">0</span>
                                </div>
                            </div>
                        </div>
                        <div class="bill-total-section pos-bill-total-strip">
                            <div class="pos-bill-total-main">
                                <span class="bill-total-label">کۆم</span>
                                <h2 id="purchase-returns-cart-total" class="bill-total-value">0</h2>
                            </div>
                        </div>
                        <div class="pos-action-grid pos-bill-action-grid pos-bill-checkout-bar no-print">
                            <div class="pos-action-left pos-bill-tools" role="group" aria-label="ئامراز">
                                <button type="button" class="btn-pos-mini btn-pos-tool danger" onclick="if(typeof clearPurchaseReturnCart==='function')clearPurchaseReturnCart()" title="ژێبرن"><i class="fas fa-trash-alt"></i><span class="pos-tool-label">ژێبرن</span></button>
                            </div>
                            <div class="pos-action-right pos-bill-checkout-actions">
                                <button type="button" class="btn-sell-large btn-sell-primary btn-sell-purchase-return returns-confirm-btn" id="btn-complete-purchase-return" onclick="if(typeof processPurchaseReturn==='function')processPurchaseReturn()" title="تەواوکرن"><i class="fas fa-check-circle" aria-hidden="true"></i> <span data-i18n="purchase_return_confirm">تەواوکرن</span></button>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- DELIVERY VIEW -->
        <div id="view-delivery" class="workspace txn-entity-list-view txn-delivery-view">
            <div class="page-action-row txn-entity-page-header">
                <h2 style="margin:0;"><i class="fas fa-truck"></i> <span data-i18n="view_delivery_title">گەهاندن</span></h2>
                <div class="page-actions-standard">
                    <input type="date" id="date-start-delivery" class="input-std" style="width:auto; margin:0;" title="ژ" onchange="if(typeof renderDeliveries==='function')renderDeliveries()">
                    <span data-i18n="del_date_to">تا</span>
                    <input type="date" id="date-end-delivery" class="input-std" style="width:auto; margin:0;" title="تا" onchange="if(typeof renderDeliveries==='function')renderDeliveries()">
                    <button type="button" class="btn btn-brand btn-sm" onclick="printDeliveryList()"><i class="fas fa-print"></i> <span data-i18n="del_btn_print_list">چاپکرنا لیستێ</span></button>
                </div>
            </div>
            <div class="card txn-entity-list-card">
                <div id="drivers-add-box" class="txn-entity-add-row delivery-add-row">
                    <input type="hidden" id="drv-page-edit-id" value="0">
                    <label class="drv-field-ico" title="ناڤ"><i class="fas fa-id-card"></i><input type="text" id="drv-page-name" class="input-std" data-i18n-placeholder="del_ph_driver_name" placeholder="ناڤێ سایێقی"></label>
                    <label class="drv-field-ico" title="تەلەفۆن"><i class="fas fa-phone"></i><input type="text" id="drv-page-phone" class="input-std" data-i18n-placeholder="del_ph_phone" placeholder="تەلەفۆن"></label>
                    <label class="drv-field-ico" title="تێبینی"><i class="fas fa-sticky-note"></i><input type="text" id="drv-page-note" class="input-std" data-i18n-placeholder="del_ph_note" placeholder="تێبینی"></label>
                    <button type="button" class="btn btn-success txn-entity-add-btn" id="drv-page-save-btn" onclick="if(typeof saveDriverFromPage==='function')saveDriverFromPage()"><i class="fas fa-user-plus"></i> <span data-i18n="debt_add_btn">زێدەکرن</span></button>
                    <button type="button" class="btn btn-dark txn-entity-add-btn" id="drv-page-cancel-btn" style="display:none;" onclick="if(typeof cancelDriverPageEdit==='function')cancelDriverPageEdit()"><i class="fas fa-times"></i> <span data-i18n="btn_cancel">پاشگەزبوون</span></button>
                </div>
                <div id="drivers-grid" class="stat-grid txn-entity-list-grid"></div>
            </div>
        </div>

        <!-- EXPENSES (UPDATED WITH COMPANY SELECTOR) -->
        <div id="view-expenses" class="workspace txn-expenses-view">
            <h2 class="expenses-view-title"><i class="fas fa-wallet"></i> <span data-i18n="view_expenses_title">مەزاختن</span></h2>
            
            <!-- NEW: Expense Stats Dashboard (پێداچوون/جەردا مەزاختناتا) -->
            <div class="stat-grid expenses-stats-grid" style="margin-bottom: 20px;">
                <div class="stat-card expenses-stat-card expenses-stat-card--today" style="background:var(--card); border-right: 5px solid var(--danger);">
                    <div class="expenses-stat-head">
                        <span class="expenses-stat-ico expenses-stat-ico--today" aria-hidden="true"><i class="fas fa-calendar-day"></i></span>
                        <h3 style="color:var(--text-muted); font-size:0.9rem;" data-i18n="exp_stat_today">مەزاختنێن ئەڤرۆ (Today)</h3>
                    </div>
                    <h1 id="exp-stat-today" style="color:var(--danger);">0</h1>
                </div>
                <div class="stat-card expenses-stat-card expenses-stat-card--month" style="background:var(--card); border-right: 5px solid var(--warning);">
                    <div class="expenses-stat-head">
                        <span class="expenses-stat-ico expenses-stat-ico--month" aria-hidden="true"><i class="fas fa-calendar"></i></span>
                        <h3 style="color:var(--text-muted); font-size:0.9rem;" data-i18n="exp_stat_month">مەزاختنێن ڤێ هەیڤێ (Month)</h3>
                    </div>
                    <h1 id="exp-stat-month" style="color:var(--warning);">0</h1>
                </div>
                <div class="stat-card expenses-stat-card expenses-stat-card--total" style="background:var(--card); border-right: 5px solid var(--info);">
                    <div class="expenses-stat-head">
                        <span class="expenses-stat-ico expenses-stat-ico--total" aria-hidden="true"><i class="fas fa-coins"></i></span>
                        <h3 style="color:var(--text-muted); font-size:0.9rem;" data-i18n="exp_stat_total">کۆیێ گشتی (Total)</h3>
                    </div>
                    <h1 id="exp-stat-total" style="color:var(--info);">0</h1>
                </div>
                <div class="stat-card expenses-stat-card expenses-stat-card--returns" style="background:var(--card); border-right: 5px solid #a855f7;">
                    <div class="expenses-stat-head">
                        <span class="expenses-stat-ico expenses-stat-ico--returns" aria-hidden="true"><i class="fas fa-rotate-left"></i></span>
                        <h3 style="color:var(--text-muted); font-size:0.9rem;" data-i18n="exp_stat_returns" data-i18n-title="exp_stat_returns_hint" title="هامش الإرجاع اليوم — لا يُجمع مع المصاريف (مدرج في صافي الربح)">ئەوڕێژا زڤڕاندن / أثر المرتجعات (ئەڤرۆ)</h3>
                    </div>
                    <h1 id="exp-stat-returns-impact" style="color:#c084fc;">0</h1>
                </div>
                <div class="stat-card expenses-stat-card expenses-stat-card--advance" style="background:var(--card); border-right: 5px solid #0d9488;">
                    <div class="expenses-stat-head">
                        <span class="expenses-stat-ico expenses-stat-ico--advance" aria-hidden="true"><i class="fas fa-hand-holding-usd"></i></span>
                        <h3 style="color:var(--text-muted); font-size:0.9rem;" data-i18n="exp_stat_advance_month">نزبا یا کاری (ڤێ هەیڤێ)</h3>
                    </div>
                    <h1 id="exp-stat-advance-month" style="color:#0d9488;">0</h1>
                </div>
                <div class="stat-card expenses-stat-card expenses-stat-card--salary" style="background:var(--card); border-right: 5px solid #2563eb;">
                    <div class="expenses-stat-head">
                        <span class="expenses-stat-ico expenses-stat-ico--salary" aria-hidden="true"><i class="fas fa-user-tie"></i></span>
                        <h3 style="color:var(--text-muted); font-size:0.9rem;" data-i18n="exp_stat_salary_month">مووچەی دراو (ڤێ هەیڤێ)</h3>
                    </div>
                    <h1 id="exp-stat-salary-month" style="color:#2563eb;">0</h1>
                </div>
            </div>

            <div class="card expenses-entry-card">
                <div class="expenses-entry-grid" style="display:grid; grid-template-columns: 1fr 2fr minmax(90px, 0.7fr) 1fr auto auto; gap:10px;">
                    <label class="exp-field-ico" title="جۆر"><i class="fas fa-folder-open"></i>
                    <select id="e-comp-select" class="input-std">
                        <option value="" data-i18n-opt="exp_comp_all">مەزاختنێن گشتی</option>
                    </select>
                    </label>
                    <label class="exp-field-ico" title="تێبینی"><i class="fas fa-sticky-note"></i>
                    <input type="text" id="e-note" class="input-std" placeholder="تێبینی" data-i18n-placeholder="exp_note_ph">
                    </label>
                    <label class="exp-field-ico" title="دراڤ" data-i18n-title="exp_currency"><i class="fas fa-coins"></i>
                    <select id="e-currency" class="input-std" onchange="if(typeof onExpenseCurrencyChange==='function')onExpenseCurrencyChange();">
                        <option value="IQD" data-i18n-opt="currency_iqd">IQD</option>
                        <option value="USD" data-i18n-opt="currency_usd_label">USD</option>
                    </select>
                    </label>
                    <label class="exp-field-ico" title="بڕ"><i class="fas fa-money-bill"></i>
                    <input type="text" inputmode="decimal" id="e-amount" class="input-std" placeholder="بڕ" data-i18n-placeholder="exp_amount_ph">
                    </label>
                    <input type="hidden" id="e-edit-id" value="">
                    <button type="button" id="e-cancel-edit-btn" class="btn btn-dark" style="height:46px; display:none;" onclick="cancelExpenseEdit()"><i class="fas fa-times"></i> <span data-i18n="exp_btn_cancel_edit">هەڵوەشاندنەوە</span></button>
                    <button type="button" id="e-save-btn" class="btn btn-danger" style="height:46px" onclick="saveExpense()"><i class="fas fa-floppy-disk"></i> <span data-i18n="exp_btn_save">تۆمارکرن</span></button>
                </div>
            </div>
            <div class="expenses-print-row" style="margin-bottom:10px;display:flex;flex-wrap:wrap;gap:8px;">
                <button type="button" class="btn btn-success" onclick="openPayCompanyDebtModal()"><i class="fas fa-building"></i> <span data-i18n="pcd_btn_open">دانەڤا قەرزی کۆمپانیا</span></button>
                <button class="btn btn-dark" onclick="printExpenses()"><i class="fas fa-print"></i> <span data-i18n="exp_btn_print_list">چاپکرنا لیستێ</span></button>
            </div>
            <div class="expenses-filter-row" style="display:flex; gap:8px; margin-bottom:12px; align-items:center;">
                <label class="exp-field-ico" title="بەروار" style="width:auto; min-width:180px;">
                <i class="fas fa-calendar-days"></i>
                <select id="expenses-history-date-preset" class="input-std" style="width:160px; margin:0;" onchange="applyGlobalDatePreset(this.value, 'expenses', renderExpenses)">
                    <option value="today" selected>☀️ ئەڤرۆ (Today)</option>
                    <option value="week">📅 حەفتییا بۆری (Last 7 Days)</option>
                    <option value="month">🌙 ئەڤ هەیڤە (This Month)</option>
                    <option value="90d">📅 ٩٠ ڕۆژ (Last 90 Days)</option>
                    <option value="1y">📅 ١ ساڵ (1 Year)</option>
                    <option value="all">📅 هەمی دەم (All Time)</option>
                    <option value="custom">✍️ دیارکرنا دەمی (Custom)</option>
                </select>
                </label>
                <input type="date" id="date-start-expenses" class="input-std" style="margin:0; font-size:0.9rem; display:none;" onchange="renderExpenses()">
                <span data-i18n="exp_date_to" style="display:none;">تا</span>
                <input type="date" id="date-end-expenses" class="input-std" style="margin:0; font-size:0.9rem; display:none;" onchange="renderExpenses()">
                <button class="btn btn-sm btn-dark" onclick="resetDateFilter('expenses', renderExpenses)"><i class="fas fa-times"></i></button>
            </div>
            <div id="expense-list" class="expenses-list-shell"></div>
            <div id="expense-deleted-section" class="expense-deleted-audit-panel" style="display:none;" aria-hidden="true">
                <h3 class="expense-deleted-audit-title">
                    <i class="fas fa-history"></i>
                    <span data-i18n="exp_deleted_section">مەزاختنە سڕدراوەکان (شێنوار)</span>
                    <span id="expense-deleted-count" class="expense-deleted-audit-count" aria-label="count"></span>
                </h3>
                <p class="expense-deleted-audit-hint" data-i18n="exp_deleted_hint">مەزاختن لە لیستێ سەرەوە ناچێت؛ لێرە دەمێنێتەوە کێ و کەی سڕیوە.</p>
                <div id="expense-deleted-list" class="expenses-list-shell expense-deleted-list-shell"></div>
            </div>
        </div>

        <!-- MEGA STATISTICS DASHBOARD (ڕاپۆرتی مێگا - Heart of POS) -->
