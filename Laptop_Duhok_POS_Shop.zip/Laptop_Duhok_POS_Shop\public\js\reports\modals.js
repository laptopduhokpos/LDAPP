// POS reports - notifications, basket rate, option modals
        // --- MISSING FUNCTIONS (ADDED) ---
        function setQuickRate(rate) {
            if (typeof isIqdExchangeRateLocked === 'function' && isIqdExchangeRateLocked()) return;
            document.getElementById('modal-usd-rate-input').value = rate;
            updateUSDRatePreview();
        }
        
        function updateUSDRatePreview() {
            const val = parseFloat(document.getElementById('modal-usd-rate-input').value) || 0;
            const oneDollar = val / 100;
            const preview = document.getElementById('usd-rate-preview');
            if(preview) preview.innerText = `1$ = ${oneDollar.toLocaleString()} IQD`;
        }

        function normalizeDigitsToAscii(rawValue) {
            var s = String(rawValue || '');
            // Arabic-Indic and Eastern Arabic-Indic digits -> ASCII digits
            s = s.replace(/[٠-٩]/g, function(ch) { return String(ch.charCodeAt(0) - 1632); });
            s = s.replace(/[۰-۹]/g, function(ch) { return String(ch.charCodeAt(0) - 1776); });
            // Normalize Arabic decimal/thousands separators
            s = s.replace(/[،٬]/g, ',').replace(/٫/g, '.');
            return s;
        }

        var BASKET_VISUAL_RATE_KEY = 'pos_basket_visual_rate_100';
        var _basketVisualRateSqlLoading = false;
        var _basketVisualRateSqlLoaded = false;
        var _visualUsdRateBundleCached = 0;

        function getBasketVisualRate100Value() {
            var input = document.getElementById('basket-usd-visual-rate-input');
            if (!input) return 0;
            var normalized = normalizeDigitsToAscii(input.value || '');
            var raw = String(normalized).replace(/[^\d]/g, '');
            var n = parseInt(raw, 10);
            if (!isFinite(n) || n <= 0) return 0;
            return n;
        }

        function formatBasketVisualRateInput(rawValue) {
            var normalized = normalizeDigitsToAscii(rawValue || '');
            var cleaned = String(normalized).replace(/[^\d]/g, '');
            if (!cleaned) return '';
            var n = parseInt(cleaned, 10);
            if (!isFinite(n) || n <= 0) return '';
            return Number(n).toLocaleString('en-US');
        }

        function loadBasketVisualRate100Value() {
            try {
                var saved = localStorage.getItem(BASKET_VISUAL_RATE_KEY);
                if (saved == null || saved === '') return 0;
                var n = parseInt(normalizeDigitsToAscii(saved).replace(/[^\d]/g, ''), 10);
                if (isFinite(n) && n > 0) _visualUsdRateBundleCached = n;
                return (isFinite(n) && n > 0) ? n : 0;
            } catch (e) { return 0; }
        }

        function saveBasketVisualRate100Value(val) {
            try {
                if (!isFinite(val) || val <= 0) {
                    localStorage.removeItem(BASKET_VISUAL_RATE_KEY);
                    _visualUsdRateBundleCached = 0;
                } else {
                    var n = Math.round(val);
                    localStorage.setItem(BASKET_VISUAL_RATE_KEY, String(n));
                    _visualUsdRateBundleCached = n;
                }
            } catch (e) {}
        }

        function getShopUsdRateBundle100() {
            try {
                if (typeof db !== 'undefined' && db && db.settings && Number(db.settings.usdRate) > 0) {
                    return Math.round(Number(db.settings.usdRate));
                }
            } catch (_eShop) {}
            try {
                var ls = parseInt(localStorage.getItem('pos_usd_rate'), 10);
                if (isFinite(ls) && ls >= 10000) return ls;
            } catch (_eLs) {}
            return 0;
        }

        function getEffectiveVisualUsdRate100() {
            var typed = getBasketVisualRate100Value();
            if (typed >= 10000) return typed;
            if (isFinite(_visualUsdRateBundleCached) && _visualUsdRateBundleCached >= 10000) return _visualUsdRateBundleCached;
            var shop = getShopUsdRateBundle100();
            if (shop >= 10000) return shop;
            var saved = loadBasketVisualRate100Value();
            return saved >= 10000 ? saved : (typed > 0 ? typed : 0);
        }

        function applyBasketRateLocally(val) {
            var n = Math.round(Number(val) || 0);
            if (!(n >= 10000)) return 0;
            saveBasketVisualRate100Value(n);
            _visualUsdRateBundleCached = n;
            try {
                if (typeof db !== 'undefined' && db) {
                    if (!db.settings) db.settings = {};
                    db.settings.usdRate = n;
                }
                localStorage.setItem('pos_usd_rate', String(n));
            } catch (_eLoc) {}
            var setRateEl = document.getElementById('set-exchange-rate');
            if (setRateEl && document.activeElement !== setRateEl) setRateEl.value = String(n);
            return n;
        }

        var _basketRatePreviewTimer = null;
        function previewBasketRateInCart() {
            if (typeof renderBill === 'function') {
                try { renderBill(); return; } catch (_eBill) {}
            }
            if (typeof renderBillTotal === 'function') {
                try { renderBillTotal(); } catch (_eTot) {}
            }
        }

        function onBasketVisualRateInput(v) {
            var input = document.getElementById('basket-usd-visual-rate-input');
            if (input) {
                var formatted = formatBasketVisualRateInput((v != null) ? v : input.value);
                input.value = formatted;
            }
            var val = getBasketVisualRate100Value();
            if (val >= 10000) applyBasketRateLocally(val);
            clearTimeout(_basketRatePreviewTimer);
            _basketRatePreviewTimer = setTimeout(previewBasketRateInCart, 80);
        }

        function commitBasketVisualRateInput() {
            var input = document.getElementById('basket-usd-visual-rate-input');
            if (!input) return;
            var val = getBasketVisualRate100Value();
            if (val > 0) {
                if (typeof normalizeUsdBundleRateFromInput === 'function') {
                    val = normalizeUsdBundleRateFromInput(val);
                }
                input.value = Number(val).toLocaleString('en-US');
                applyBasketRateLocally(val);
            } else {
                var fallback = getEffectiveVisualUsdRate100();
                if (fallback > 0) input.value = Number(fallback).toLocaleString('en-US');
            }
            previewBasketRateInCart();
            if (typeof saveBasketVisualRateFromButton === 'function') saveBasketVisualRateFromButton();
        }

        var _basketExchangeRateSaving = false;
        function saveBasketVisualRateFromButton() {
            if (_basketExchangeRateSaving) return;
            if (typeof canEditExchangeRate === 'function' && !canEditExchangeRate()) {
                if (typeof showToast === 'function') showToast(typeof t === 'function' ? t('toast_perm_denied') : 'Permission denied', true);
                return;
            }
            if (typeof isIqdExchangeRateLocked === 'function' && isIqdExchangeRateLocked()) {
                if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('exchange_rate_iqd_locked') : 'Locked', true);
                return;
            }
            var rawVal = getBasketVisualRate100Value();
            var val = (typeof normalizeUsdBundleRateFromInput === 'function')
                ? normalizeUsdBundleRateFromInput(rawVal)
                : Math.round(Number(rawVal) || 0);
            if (!val || val < 10000) {
                if (typeof showToast === 'function') showToast('⚠️ Enter valid rate');
                return;
            }
            var inputEl = document.getElementById('basket-usd-visual-rate-input');
            if (inputEl) inputEl.value = Number(val).toLocaleString('en-US');
            applyBasketRateLocally(val);
            previewBasketRateInCart();
            _basketExchangeRateSaving = true;
            var saveBtn = document.getElementById('basket-usd-visual-rate-save');
            if (saveBtn) saveBtn.disabled = true;
            // USD-mode POS has no rate modal — this control must persist the real shop FX
            // (settings.usdRate), not only the visual/receipt helper history.
            var formData = new FormData();
            formData.append('action', 'save_exchange_rate');
            formData.append('rate_bundle', String(val));
            formData.append('note', 'pos_basket');
            fetch('?action=save_exchange_rate', { method: 'POST', body: formData, credentials: 'same-origin' })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (data && data.status === 'success') {
                        var saved = (data.usdRate != null) ? Math.round(Number(data.usdRate)) : val;
                        if (typeof db === 'undefined' || !db) { /* ignore */ }
                        else {
                            if (!db.settings) db.settings = {};
                            db.settings.usdRate = saved;
                        }
                        try { localStorage.setItem('pos_usd_rate', String(saved)); } catch (_eLs2) {}
                        saveBasketVisualRate100Value(saved);
                        _visualUsdRateBundleCached = saved;
                        if (inputEl) inputEl.value = Number(saved).toLocaleString('en-US');
                        var setRateEl = document.getElementById('set-exchange-rate');
                        if (setRateEl) setRateEl.value = String(saved);
                        // Keep visual-rate history in sync for receipts / multi-device
                        try {
                            var fdVis = new FormData();
                            fdVis.append('action', 'save_visual_usd_rate');
                            fdVis.append('rate_bundle', String(saved));
                            fdVis.append('note', 'pos_basket_sync');
                            fetch('?action=save_visual_usd_rate', { method: 'POST', body: fdVis, credentials: 'same-origin' }).catch(function() {});
                        } catch (_eVis) {}
                        if (typeof showToast === 'function') {
                            showToast('✅ ' + (typeof t === 'function' ? t('toast_exchange_rate_saved') : 'Saved') + '\n100 USD = ' + Number(saved).toLocaleString('en-US') + ' IQD');
                        }
                        if (typeof refreshAfterCurrencySettingsSave === 'function') {
                            refreshAfterCurrencySettingsSave();
                        } else {
                            updateUSDBadge();
                            if (typeof renderPOSMenu === 'function') {
                                try { renderPOSMenu(); } catch (_eMenu) {}
                            } else if (typeof renderAll === 'function') {
                                try { renderAll(); } catch (_eAll) {}
                            }
                        }
                    } else {
                        if (typeof showToast === 'function') {
                            showToast('❌ ' + ((data && data.message) ? data.message : 'Save failed'), true);
                        }
                        updateUSDBadge();
                    }
                })
                .catch(function(err) {
                    if (typeof showToast === 'function') {
                        showToast('❌ ' + ((err && err.message) ? err.message : 'Save failed'), true);
                    }
                    updateUSDBadge();
                })
                .finally(function() {
                    _basketExchangeRateSaving = false;
                    if (saveBtn) saveBtn.disabled = false;
                });
        }

        function fetchBasketVisualRateFromSqlLatest(force) {
            if (_basketVisualRateSqlLoading) return;
            if (!force && _basketVisualRateSqlLoaded) return;
            _basketVisualRateSqlLoading = true;
            fetch('?action=get_visual_usd_rate_latest', { credentials: 'same-origin' })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    var shop = getShopUsdRateBundle100();
                    var latest = (data && data.status === 'success') ? Number(data.rate_bundle || 0) : 0;
                    // Shop settings.usdRate is source of truth for POS cards; visual history is fallback only.
                    var use = (shop >= 10000) ? shop : ((latest >= 10000) ? latest : 0);
                    if (use >= 10000) {
                        saveBasketVisualRate100Value(use);
                        _visualUsdRateBundleCached = use;
                        var input = document.getElementById('basket-usd-visual-rate-input');
                        if (input && (!input.value || getBasketVisualRate100Value() <= 0 || document.activeElement !== input)) {
                            input.value = Number(use).toLocaleString('en-US');
                        }
                    }
                })
                .catch(function() {})
                .finally(function() {
                    _basketVisualRateSqlLoading = false;
                    _basketVisualRateSqlLoaded = true;
                    updateUSDBadge();
                    if (typeof updatePayReceivedVisualIqdFromUsd === 'function') {
                        updatePayReceivedVisualIqdFromUsd((document.getElementById('pay-usd-input') && document.getElementById('pay-usd-input').value) || '');
                    }
                });
        }
        
        function updateUSDBadge() {
            const visualRate = document.getElementById('basket-usd-visual-rate-value');
            const visualRateInput = document.getElementById('basket-usd-visual-rate-input');
            const visualRateSaveBtn = document.getElementById('basket-usd-visual-rate-save');
            const visualRateSuffix = document.getElementById('basket-usd-visual-rate-suffix');
            var isUsdMode = (typeof getActiveCurrency === 'function') ? (getActiveCurrency() === 'USD') : false;
            var shopRate100 = getShopUsdRateBundle100();
            var manualRate100 = getEffectiveVisualUsdRate100();
            if (!(manualRate100 > 0)) {
                manualRate100 = shopRate100;
            }
            var canRate = (typeof canEditExchangeRate === 'function') ? canEditExchangeRate() : false;
            if (visualRateInput) {
                if (document.activeElement !== visualRateInput && manualRate100 > 0) {
                    visualRateInput.value = Number(manualRate100).toLocaleString('en-US');
                }
                visualRateInput.readOnly = !canRate;
                visualRateInput.disabled = false;
                visualRateInput.style.display = canRate ? '' : 'none';
            }
            if (visualRateSuffix) {
                visualRateSuffix.style.display = canRate ? '' : 'none';
            }
            if (visualRateSaveBtn) {
                visualRateSaveBtn.style.display = canRate ? 'inline-flex' : 'none';
            }
            if (visualRate) {
                if (canRate) {
                    visualRate.innerText = '';
                    visualRate.style.display = 'none';
                } else if (manualRate100 > 0) {
                    visualRate.innerText = Number(manualRate100).toLocaleString('en-US') + ' = $100';
                    visualRate.style.display = '';
                } else {
                    visualRate.innerText = '';
                    visualRate.style.display = 'none';
                }
            }
            var rateVisualWrap = document.getElementById('basket-usd-visual-rate');
            if (rateVisualWrap) {
                var showChip = manualRate100 >= 10000;
                rateVisualWrap.style.display = showChip ? 'flex' : 'none';
            }
            if (isUsdMode) {
                fetchBasketVisualRateFromSqlLatest(false);
            }
            var rateModal = document.getElementById('usd-rate-modal');
            if (isUsdMode && rateModal) {
                rateModal.style.display = 'none';
            }
            renderBillTotal(); // Refresh only; visual rate does not affect accounting math
        }

        var NOTIF_STOCK_PREVIEW = 40;

        function _notifT(key, fallback) {
            if (typeof t === 'function') {
                var s = t(key);
                if (s && s !== key) return s;
            }
            return fallback;
        }

        function _notifReplaceN(tpl, n) {
            return String(tpl || '').replace(/\{n\}/g, String(n));
        }

        function buildNotifStockListHtml(items, opts) {
            opts = opts || {};
            var limit = opts.limit != null ? opts.limit : NOTIF_STOCK_PREVIEW;
            var qtyTone = opts.qtyTone || '';
            var total = items.length;
            var shown = items.slice(0, limit);
            var rows = shown.map(function(p) {
                var qty = p.qty != null ? p.qty : 0;
                return '<li class="notif-stock-row">' +
                    '<span class="notif-stock-name">' + escapeHtml(p.name || 'ئایتم') + '</span>' +
                    '<b class="notif-stock-qty' + (qtyTone ? ' notif-stock-qty--' + qtyTone : '') + '">' + escapeHtml(String(qty)) + '</b>' +
                    '</li>';
            }).join('');
            var meta = '';
            if (total > shown.length) {
                meta += '<p class="notif-stock-more">' + escapeHtml(_notifReplaceN(_notifT('notif_list_more', '+ {n} ئایتمێن دی'), total - shown.length)) + '</p>';
            } else if (total > 0) {
                var showTpl = _notifT('notif_list_showing', 'پیشاندان: {shown} لە {total}');
                meta += '<p class="notif-list-meta">' + escapeHtml(showTpl.replace(/\{shown\}/g, String(shown.length)).replace(/\{total\}/g, String(total))) + '</p>';
            }
            return '<ul class="notif-stock-list">' + rows + '</ul>' + meta;
        }

        function buildNotifCard(opts) {
            opts = opts || {};
            var tone = opts.tone || 'default';
            var headExtra = opts.headExtra || '';
            return '<div class="notif-card notif-card--' + tone + '">' +
                '<div class="notif-card-head">' +
                '<h3 class="notif-card-title"><i class="fas ' + (opts.icon || 'fa-bell') + '"></i> ' + escapeHtml(opts.title || '') + '</h3>' +
                (opts.count != null ? '<span class="notif-card-badge">' + escapeHtml(String(opts.count)) + '</span>' : '') +
                headExtra +
                '</div>' +
                '<div class="notif-card-body">' + (opts.bodyHtml || '') + '</div>' +
                (opts.btnLabel ? '<div class="notif-card-foot"><button type="button" class="btn btn-sm ' + (opts.btnClass || 'btn-dark') + '" onclick="' + (opts.btnOnclick || '') + '"><i class="fas ' + (opts.btnIcon || 'fa-arrow-left') + '"></i> ' + escapeHtml(opts.btnLabel) + '</button></div>' : '') +
                '</div>';
        }

        function renderNotifications() {
            const container = document.getElementById('notification-container');
            if(!container) return;
            if ((!window._expiryAlertsCache || (Date.now() - (window._expiryAlertsLoadedAt || 0) > 120000)) && typeof fetchExpiryAlerts === 'function') {
                fetchExpiryAlerts().then(function() {
                    if (container && container.isConnected) renderNotifications();
                });
            }
            if (typeof isSaleFollowupEnabled === 'function' && isSaleFollowupEnabled()
                && (!window._saleFollowupCache || (Date.now() - (window._saleFollowupLoadedAt || 0) > ((typeof getSaleFollowupRefreshMs === 'function') ? getSaleFollowupRefreshMs() : 120000)))
                && typeof fetchSaleFollowups === 'function') {
                fetchSaleFollowups().then(function() {
                    if (container && container.isConnected) renderNotifications();
                });
            }
            
            let html = '';
            let count = 0;
            let externalUnread = 0;

            function readExternalInbox() {
                try {
                    const inbox = JSON.parse(localStorage.getItem('pos_notifications_inbox') || '[]');
                    const readMap = JSON.parse(localStorage.getItem('pos_notifications_read') || '{}');
                    const safeInbox = Array.isArray(inbox) ? inbox : [];
                    const safeRead = (readMap && typeof readMap === 'object') ? readMap : {};
                    externalUnread = safeInbox.filter(n => !safeRead[String(n.id || '')]).length;
                    return { inbox: safeInbox, readMap: safeRead };
                } catch (e) {
                    externalUnread = 0;
                    return { inbox: [], readMap: {} };
                }
            }
            function markExternalRead(id) {
                try {
                    const key = String(id || '');
                    if (!key) return;
                    const readMap = JSON.parse(localStorage.getItem('pos_notifications_read') || '{}') || {};
                    readMap[key] = 1;
                    localStorage.setItem('pos_notifications_read', JSON.stringify(readMap));
                } catch (e) {}
            }
            function markAllExternalRead(inbox) {
                try {
                    const readMap = JSON.parse(localStorage.getItem('pos_notifications_read') || '{}') || {};
                    (inbox || []).forEach(n => { if (n && n.id != null) readMap[String(n.id)] = 1; });
                    localStorage.setItem('pos_notifications_read', JSON.stringify(readMap));
                } catch (e) {}
            }

            function deleteExternalNotification(id) {
                try {
                    const key = String(id || '');
                    if (!key) return;
                    let inbox = JSON.parse(localStorage.getItem('pos_notifications_inbox') || '[]');
                    if (Array.isArray(inbox)) {
                        inbox = inbox.filter(n => String(n.id) !== key);
                        localStorage.setItem('pos_notifications_inbox', JSON.stringify(inbox));
                        // Also clear from readMap
                        const readMap = JSON.parse(localStorage.getItem('pos_notifications_read') || '{}') || {};
                        delete readMap[key];
                        localStorage.setItem('pos_notifications_read', JSON.stringify(readMap));
                        // Re-render
                        if (typeof renderNotifications === 'function') renderNotifications();
                        if (typeof updateAppBadges === 'function') updateAppBadges();
                        if (typeof updateNotificationBadge === 'function') updateNotificationBadge();
                    }
                } catch (e) {}
            }
            window.deleteExternalNotification = deleteExternalNotification;

            const _loc = (typeof getDateLocale === 'function') ? getDateLocale() : 'ar-IQ';
            function _nearDaysLabel(n) {
                return _notifReplaceN(_notifT('notif_expiry_near_days', '({n}d)'), n);
            }

            if (typeof buildSaleFollowupNotifHtml === 'function') {
                var fuHtml = buildSaleFollowupNotifHtml();
                if (fuHtml) {
                    var fuCache = window._saleFollowupCache;
                    var fuCount = fuCache && typeof fuCache.count === 'number'
                        ? fuCache.count
                        : ((fuCache && fuCache.rows && fuCache.rows.length) || 0);
                    count += fuCount;
                    html += fuHtml;
                }
            }

            // 1. Low Stock + 2. Out of Stock (side-by-side on wide screens)
            const lowStock = db.products.filter(p => p.trackStock && p.qty <= (typeof getMinStock === 'function' ? getMinStock(p) : 5) && p.qty > 0)
                .sort(function(a, b) { return (parseFloat(a.qty) || 0) - (parseFloat(b.qty) || 0); });
            const outStock = db.products.filter(p => p.trackStock && p.qty <= 0)
                .sort(function(a, b) { return String(a.name || '').localeCompare(String(b.name || ''), 'ar'); });
            var stockGridHtml = '';
            if (lowStock.length > 0) {
                count += lowStock.length;
                stockGridHtml += buildNotifCard({
                    tone: 'warn',
                    icon: 'fa-exclamation-triangle',
                    title: _notifT('wh_title_low', 'ئایتمێن کێمبووی'),
                    count: lowStock.length,
                    bodyHtml: buildNotifStockListHtml(lowStock, { qtyTone: 'warn' }),
                    btnLabel: _notifT('notif_go_warehouse_btn', 'چوون بۆ مەخزەنی'),
                    btnClass: 'btn-warning',
                    btnIcon: 'fa-warehouse',
                    btnOnclick: "nav('warehouse'); renderWarehouse('low');"
                });
            }
            if (outStock.length > 0) {
                count += outStock.length;
                stockGridHtml += buildNotifCard({
                    tone: 'danger',
                    icon: 'fa-times-circle',
                    title: _notifT('wh_title_out', 'ئایتمێن نەما'),
                    count: outStock.length,
                    bodyHtml: buildNotifStockListHtml(outStock.map(function(p) { return { name: p.name, qty: 0 }; }), { qtyTone: 'danger' }),
                    btnLabel: _notifT('notif_go_warehouse_btn', 'چوون بۆ مەخزەنی'),
                    btnClass: 'btn-danger',
                    btnIcon: 'fa-warehouse',
                    btnOnclick: "nav('warehouse'); renderWarehouse('out');"
                });
            }
            if (stockGridHtml) {
                html += '<div class="notif-stock-grid">' + stockGridHtml + '</div>';
            }

            // 3. Expiry (batch-based from API cache)
            const expRes = window._expiryAlertsCache || null;
            const expiredRows = expRes && Array.isArray(expRes.expired) ? expRes.expired : [];
            const expSoonRows = expRes && Array.isArray(expRes.expiring_soon) ? expRes.expiring_soon : [];
            const expCount = expiredRows.length + expSoonRows.length;
            if(expCount > 0) {
                count += expCount;
                var expTag = _notifT('notif_expiry_expired_tag', '(Expired)');
                var expRows = expiredRows.slice(0, NOTIF_STOCK_PREVIEW).map(function(r) {
                    return '<li class="notif-stock-row"><span class="notif-stock-name">' + escapeHtml(r.name || ('#' + r.product_id)) +
                        ' <small style="color:#ef4444;">' + escapeHtml(expTag) + '</small></span><b class="notif-stock-qty">' +
                        escapeHtml((r.expiry_date || '') + ' | ' + String(r.qty || 0)) + '</b></li>';
                }).join('');
                var soonRows = expSoonRows.slice(0, Math.max(0, NOTIF_STOCK_PREVIEW - expiredRows.length)).map(function(r) {
                    return '<li class="notif-stock-row"><span class="notif-stock-name">' + escapeHtml(r.name || ('#' + r.product_id)) +
                        ' <small style="color:#f59e0b;">' + escapeHtml(_nearDaysLabel(r.days_left || 0)) + '</small></span><b class="notif-stock-qty">' +
                        escapeHtml((r.expiry_date || '') + ' | ' + String(r.qty || 0)) + '</b></li>';
                }).join('');
                var expMore = '';
                if (expCount > NOTIF_STOCK_PREVIEW) {
                    expMore = '<p class="notif-stock-more">' + escapeHtml(_notifReplaceN(_notifT('notif_list_more', '+ {n} ئایتمێن دی'), expCount - NOTIF_STOCK_PREVIEW)) + '</p>';
                }
                html += buildNotifCard({
                    tone: 'expiry',
                    icon: 'fa-calendar-times',
                    title: _notifT('wh_title_expired', 'بەسەرچوون/نزیك'),
                    count: expCount,
                    bodyHtml: '<ul class="notif-stock-list">' + expRows + soonRows + '</ul>' + expMore,
                    btnLabel: _notifT('notif_go_warehouse_btn', 'چوون بۆ مەخزەنی'),
                    btnClass: 'btn-dark',
                    btnIcon: 'fa-warehouse',
                    btnOnclick: "nav('warehouse');"
                });
            }

            // 4. Pending Deliveries
            const pendingDel = db.deliveries ? db.deliveries.filter(d => d.status === 'pending') : [];
            if(pendingDel.length > 0) {
                count += pendingDel.length;
                var delRows = pendingDel.slice(0, NOTIF_STOCK_PREVIEW).map(function(d) {
                    var _dFx = (typeof fxUsdRateFormatOpts === 'function') ? fxUsdRateFormatOpts(d) : undefined;
                    return '<li class="notif-stock-row"><span class="notif-stock-name">' + escapeHtml(d.customer_name) + '</span><b class="notif-stock-qty">' + escapeHtml(formatCurrency(d.total, _dFx)) + '</b></li>';
                }).join('');
                var delMore = pendingDel.length > NOTIF_STOCK_PREVIEW
                    ? '<p class="notif-stock-more">' + escapeHtml(_notifReplaceN(_notifT('notif_list_more', '+ {n} ئایتمێن دی'), pendingDel.length - NOTIF_STOCK_PREVIEW)) + '</p>'
                    : '';
                html += buildNotifCard({
                    tone: 'info',
                    icon: 'fa-truck',
                    title: _notifT('del_active_heading', 'گەهاندنێن چالاک'),
                    count: pendingDel.length,
                    bodyHtml: '<ul class="notif-stock-list">' + delRows + '</ul>' + delMore,
                    btnLabel: _notifT('notif_go_delivery_btn', 'چوون بۆ گەهاندنێ'),
                    btnClass: 'btn-info',
                    btnIcon: 'fa-truck',
                    btnOnclick: "nav('delivery');"
                });
            }

            // 5. Incoming POS messages (from new notification system)
            const ext = readExternalInbox();
            if (ext.inbox.length > 0) {
                count += externalUnread;
                const top = ext.inbox.slice(0, 30);
                var admUnread = _notifReplaceN(_notifT('notif_unread_suffix', '({n} نەخوێندراو)'), externalUnread);
                var admMarkAll = _notifT('notif_mark_all_read', 'هەموو وەک خوێندراو نیشانە بکە');
                var admMarkOne = _notifT('notif_mark_read', 'خوێندراوە');
                var admFallbackTitle = _notifT('notif_fallback_title', 'ئاگەهداری');
                var admFallbackBy = _notifT('notif_fallback_admin', 'بەڕێوەبەر');
                var msgHtml = top.map(function(n) {
                    const id = String((n && n.id != null) ? n.id : '');
                    const isRead = !!ext.readMap[id];
                    const title = escapeHtml(n && n.title ? n.title : admFallbackTitle);
                    const message = escapeHtml(n && n.message ? n.message : '');
                    const createdBy = escapeHtml(n && n.createdBy ? n.createdBy : admFallbackBy);
                    const dtLabel = new Date(Number((n && n.createdAt) || Date.now())).toLocaleString(_loc);
                    var otaBtn = '';
                    try {
                        if (typeof window.posOtaIsUpdateNotification === 'function' && window.posOtaIsUpdateNotification(n)) {
                            otaBtn = '<button type="button" class="btn btn-sm btn-success" onclick="if(typeof posOtaOpenFromNotification===\'function\')posOtaOpenFromNotification();"><i class="fas fa-cloud-download-alt"></i> نوێکردنەوە</button>';
                        }
                    } catch (_eOtaBtn) {}
                    return '<div class="notif-msg-row' + (isRead ? ' is-read' : '') + '" style="position:relative;">' +
                        '<div class="notif-msg-row-head" style="display:flex; justify-content:space-between; align-items:center;">' +
                        '<b>' + title + (isRead ? '' : ' <span style="color:#fb7185;">●</span>') + '</b>' +
                        '<div style="display:flex; gap:6px; flex-wrap:wrap;">' +
                        otaBtn +
                        '<button type="button" class="btn btn-sm btn-dark" onclick="markPosInboxReadFromView(\'' + id.replace(/'/g, "\\'") + '\')">' + escapeHtml(admMarkOne) + '</button>' +
                        '<button type="button" class="btn btn-sm btn-dark" style="background:rgba(239,68,68,0.15); border-color:rgba(239,68,68,0.3); color:#ef4444;" onclick="if(confirm(\'دڵنیای؟\')) deleteExternalNotification(\'' + id.replace(/'/g, "\\'") + '\')" title="لابردن"><i class="fa fa-trash"></i></button>' +
                        '</div></div>' +
                        '<div class="notif-msg-body">' + message + '</div>' +
                        '<div class="notif-msg-meta">' + createdBy + ' | ' + escapeHtml(dtLabel) + '</div></div>';
                }).join('');
                html += buildNotifCard({
                    tone: 'admin',
                    icon: 'fa-bell',
                    title: _notifT('notif_admin_messages', 'پەیامەکانی بەڕێوەبەر') + ' ' + admUnread,
                    bodyHtml: '<div class="notif-msg-list">' + msgHtml + '</div>',
                    headExtra: '<button type="button" class="btn btn-sm btn-dark" onclick="markAllPosInboxReadFromView()">' + escapeHtml(admMarkAll) + '</button>'
                });
            }

            if(count === 0) {
                html = '<div class="notif-empty">' +
                    '<i class="fas fa-check-circle"></i>' +
                    '<h2>' + escapeHtml(_notifT('notif_empty_title', 'چ ئاگەهدارکرن نینن!')) + '</h2>' +
                    '<p>' + escapeHtml(_notifT('notif_empty_sub', 'هەموو تشت یێ باشە.')) + '</p></div>';
            }
            
            container.innerHTML = html;
            updateNotificationBadge();

            // Expose actions for inline buttons in merged legacy view.
            window.markPosInboxReadFromView = function(id) {
                markExternalRead(id);
                renderNotifications();
            };
            window.markAllPosInboxReadFromView = function() {
                try {
                    var _in = JSON.parse(localStorage.getItem('pos_notifications_inbox') || '[]');
                    markAllExternalRead(Array.isArray(_in) ? _in : []);
                } catch (eAllRead) {}
                renderNotifications();
            };
        } 

        function updateNotificationBadge() {
            if(!db) return;
            const today = new Date();
            let count = 0;
            
            if(db.deliveries) count += db.deliveries.filter(d => d.status === 'pending').length;
            try {
                const inbox = JSON.parse(localStorage.getItem('pos_notifications_inbox') || '[]');
                const readMap = JSON.parse(localStorage.getItem('pos_notifications_read') || '{}');
                const arr = Array.isArray(inbox) ? inbox : [];
                const map = (readMap && typeof readMap === 'object') ? readMap : {};
                count += arr.filter(n => !map[String((n && n.id != null) ? n.id : '')]).length;
            } catch (e) {}
            
            // Include expiry batch counts in nav/sidebar badges
            if (window._expiryAlertsCache) {
                count += (parseInt(window._expiryAlertsCache.expired_count, 10) || 0);
                count += (parseInt(window._expiryAlertsCache.expiring_soon_count, 10) || 0);
            }
            if (typeof isSaleFollowupEnabled === 'function' && isSaleFollowupEnabled()) {
                var fu = window._saleFollowupCache;
                if (fu && typeof fu.count === 'number') count += fu.count;
                else if (fu && Array.isArray(fu.rows)) count += fu.rows.length;
                if ((!window._saleFollowupLoadedAt || (Date.now() - window._saleFollowupLoadedAt > ((typeof getSaleFollowupRefreshMs === 'function') ? getSaleFollowupRefreshMs() : 120000))) && typeof fetchSaleFollowups === 'function') {
                    fetchSaleFollowups();
                }
            }
            const badge = document.getElementById('nav-notif-badge');
            if(badge) { badge.innerText = count; badge.style.display = count > 0 ? 'inline-block' : 'none'; }
            const rightBadge = document.getElementById('right-notif-badge');
            if(rightBadge) { rightBadge.innerText = count; rightBadge.style.display = count > 0 ? 'inline-block' : 'inline-block'; rightBadge.style.visibility = count > 0 ? 'visible' : 'hidden'; }
        }
        
        function paintMobileConnectQr(qrEl, url) {
            if (!qrEl || !url) return false;
            var size = 156;
            qrEl.innerHTML = '';
            var dataUrl = (typeof window.posOfflineQrDataUrl === 'function') ? window.posOfflineQrDataUrl(url, size) : '';
            if (dataUrl) {
                var img = document.createElement('img');
                img.alt = 'QR';
                img.width = size;
                img.height = size;
                img.decoding = 'sync';
                img.src = dataUrl;
                img.className = 'startup-mobile-qr-img';
                qrEl.appendChild(img);
                return true;
            }
            if (typeof window.QRCode !== 'undefined') {
                try {
                    var lvl = (window.QRCode.CorrectLevel && window.QRCode.CorrectLevel.M) ? window.QRCode.CorrectLevel.M : 1;
                    new window.QRCode(qrEl, { text: url, width: size, height: size, colorDark: '#000', colorLight: '#fff', correctLevel: lvl });
                    var canvas = qrEl.querySelector('canvas');
                    var table = qrEl.querySelector('table');
                    if (canvas) canvas.style.display = 'block';
                    if (table || (canvas && canvas.width > 0)) return true;
                } catch (_eQrConn) {}
            }
            qrEl.innerHTML = '<p class="startup-mobile-qr-fallback">QR — لینکێ ل خوارەوە بەکاربینە</p>';
            return false;
        }

        function toggleMobileConnectInfo() {
            var info = document.getElementById('mobile-connect-info');
            if (!info) return;
            var open = info.style.display === 'none' || info.style.display === '' || info.hidden;
            if (open) {
                info.style.display = 'flex';
                info.hidden = false;
                switchMobileConnectQr('pos');
            } else {
                info.style.display = 'none';
                info.hidden = true;
            }
        }

        function switchMobileConnectQr(type) {
            var info = document.getElementById('mobile-connect-info');
            if (!info) return;
            var urlEl = info.querySelector('.startup-mobile-url');
            var qrEl = document.getElementById('mobile-connect-qr');
            var btnPos = document.getElementById('btn-qr-tab-pos');
            var btnEntry = document.getElementById('btn-qr-tab-entry');
            var lblEl = document.getElementById('mobile-qr-instruction-lbl');
            if (!urlEl || !qrEl) return;
            var targetUrl = (type === 'entry') ? urlEl.getAttribute('data-entry-url') : urlEl.getAttribute('data-connect-url');
            if (!targetUrl) return;
            urlEl.textContent = targetUrl;
            if (btnPos && btnEntry) {
                btnPos.style.background = (type === 'pos') ? '#2563eb' : '#1e293b';
                btnPos.style.color = (type === 'pos') ? '#fff' : '#94a3b8';
                btnPos.style.border = (type === 'pos') ? 'none' : '1px solid #334155';
                btnEntry.style.background = (type === 'entry') ? '#10b981' : '#1e293b';
                btnEntry.style.color = (type === 'entry') ? '#fff' : '#94a3b8';
                btnEntry.style.border = (type === 'entry') ? 'none' : '1px solid #334155';
            }
            if (lblEl) {
                lblEl.textContent = (type === 'entry') ? 'ب کامێرەیا مۆبایلێ ئەڤ QR سکان بکە بۆ ئیدخالا کاڵایان د LD Manager دا' : 'ب کەمێرێ مۆبایلەکە ئەڤ QR سکان بکە بۆ فرۆشتنێ';
            }
            paintMobileConnectQr(qrEl, targetUrl);
        }
        window.switchMobileConnectQr = switchMobileConnectQr;
        window.toggleMobileConnectInfo = toggleMobileConnectInfo;
        window.paintMobileConnectQr = paintMobileConnectQr;
        
        function togglePOSFullscreen() {
            const elem = document.getElementById('view-pos');
            if (document.fullscreenElement && document.fullscreenElement === elem) {
                document.exitFullscreen();
            } else {
                elem.requestFullscreen().catch(err => { alert(`Error: ${err.message}`); });
            }
        }
        
        document.addEventListener('fullscreenchange', () => {
            const fab = document.querySelector('.menu-fab');
            const btnIcon = document.querySelector('#btn-fullscreen-pos i');
            const posElem = document.getElementById('view-pos');

            // Handle FAB visibility & Icon (Hide FAB only when POS is fullscreen)
            if (document.fullscreenElement === posElem) {
                if(fab) fab.style.display = 'none';
                if(btnIcon) { btnIcon.className = 'fas fa-compress'; btnIcon.parentElement.title = "Exit Fullscreen"; }
            } else {
                if(typeof applyFabVisibility === 'function') { applyFabVisibility(); } else if(fab) { fab.style.display = 'flex'; }
                if(btnIcon) { btnIcon.className = 'fas fa-expand'; btnIcon.parentElement.title = "Fullscreen"; }
            }
        });

        function openReturnsOptionsModal(e) {
            e = e || window.event;
            if (e) {
                e.preventDefault();
                e.stopPropagation();
            }

            // داخستنا مینیویا فرۆتنێ ئەگەر یا ڤەکری بیت
            let posModal = document.getElementById('pos-options-popover');
            if (posModal) posModal.style.display = 'none';
            let purchModal = document.getElementById('purchase-options-popover');
            if (purchModal) purchModal.style.display = 'none';
            let purchRetModal = document.getElementById('purchase-returns-options-popover');
            if (purchRetModal) purchRetModal.style.display = 'none';

            let modal = document.getElementById('returns-options-popover');
            if (modal && !modal.querySelector('[data-shortcut-id="voided-history"]')) {
                modal.remove();
                modal = null;
            }
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'returns-options-popover';
                modal.style.position = 'absolute';
                modal.style.zIndex = '10000';
                modal.style.background = 'var(--card)';
                modal.style.border = '1px solid var(--border)';
                modal.style.borderRadius = '12px';
                modal.style.boxShadow = '0 8px 30px rgba(0,0,0,0.15)';
                modal.style.padding = '15px';
                modal.style.minWidth = '320px';
                modal.style.display = 'flex';
                modal.style.flexDirection = 'column';
                modal.style.gap = '10px';
                modal.innerHTML = `
                    <div style="font-size:0.95rem; color:var(--text); padding-bottom:10px; border-bottom:1px solid var(--border); margin-bottom:5px; font-weight:bold; text-align:center;">
                        <i class="fas fa-th-large" style="margin-left:5px;"></i> <span data-i18n="popover_returns_menu_title">مینیویا زڤڕاندنێ</span>
                    </div>
                    <div style="display:grid; grid-template-columns: repeat(2, 1fr); gap:12px;">
                        <div data-shortcut-id="returns-new" draggable="true" style="cursor:pointer; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:20px 10px; background:var(--card); border:2px solid var(--border); border-radius:14px; transition:all 0.2s ease;" onmouseover="this.style.borderColor='var(--danger)'; this.style.transform='translateY(-3px)'; this.style.boxShadow='0 6px 15px rgba(220, 38, 38, 0.15)';" onmouseout="this.style.borderColor='var(--border)'; this.style.transform='none'; this.style.boxShadow='none';" onclick="document.getElementById('returns-options-popover').style.display='none'; nav('returns-new');">
                            <i class="fas fa-undo-alt" style="font-size:2.2rem; margin-bottom:12px; color:var(--danger);"></i>
                            <span style="font-size:0.9rem; font-weight:bold; color:var(--text);" data-i18n="popover_screen_returns">شاشا زڤڕاندنێ</span>
                        </div>
                        <div data-shortcut-id="returns-history" draggable="true" style="cursor:pointer; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:20px 10px; background:var(--card); border:2px solid var(--border); border-radius:14px; transition:all 0.2s ease;" onmouseover="this.style.borderColor='var(--warning)'; this.style.transform='translateY(-3px)'; this.style.boxShadow='0 6px 15px rgba(245, 158, 11, 0.15)';" onmouseout="this.style.borderColor='var(--border)'; this.style.transform='none'; this.style.boxShadow='none';" onclick="document.getElementById('returns-options-popover').style.display='none'; openReturnsHistoryOption();">
                            <i class="fas fa-history" style="font-size:2.2rem; margin-bottom:12px; color:var(--warning);"></i>
                            <span style="font-size:0.9rem; font-weight:bold; color:var(--text);" data-i18n="popover_history_returns">مێژوویا زڤڕاندنێ</span>
                        </div>
                        <div data-perm="view_sales_history">
                            <div data-shortcut-id="sales-history" draggable="true" style="cursor:pointer; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:20px 10px; background:var(--card); border:2px solid var(--border); border-radius:14px; transition:all 0.2s ease;" onmouseover="this.style.borderColor='#8b5cf6'; this.style.transform='translateY(-3px)'; this.style.boxShadow='0 6px 15px rgba(139, 92, 246, 0.15)';" onmouseout="this.style.borderColor='var(--border)'; this.style.transform='none'; this.style.boxShadow='none';" onclick="document.getElementById('returns-options-popover').style.display='none'; openSalesHistoryFromReturnsPrompt();">
                                <i class="fas fa-file-invoice-dollar" style="font-size:2.2rem; margin-bottom:12px; color:#8b5cf6;"></i>
                                <span style="font-size:0.9rem; font-weight:bold; color:var(--text);" data-i18n="popover_history_sales">مێژوویا فرۆتنێ</span>
                            </div>
                        </div>
                        <div data-shortcut-id="voided-history" draggable="true" style="cursor:pointer; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:20px 10px; background:var(--card); border:2px solid var(--border); border-radius:14px; transition:all 0.2s ease;" onmouseover="this.style.borderColor='#94a3b8'; this.style.transform='translateY(-3px)'; this.style.boxShadow='0 6px 15px rgba(148, 163, 184, 0.2)';" onmouseout="this.style.borderColor='var(--border)'; this.style.transform='none'; this.style.boxShadow='none';" onclick="document.getElementById('returns-options-popover').style.display='none'; openVoidedSalesHistoryOption();">
                            <i class="fas fa-trash-alt" style="font-size:2.2rem; margin-bottom:12px; color:#94a3b8;"></i>
                            <span style="font-size:0.9rem; font-weight:bold; color:var(--text);" data-i18n="popover_history_voided">مێژوویا ژێبرنێ</span>
                        </div>
                    </div>
                `;
                document.body.appendChild(modal);
                document.addEventListener('click', function(evt) {
                    if (modal.style.display === 'flex' && !modal.contains(evt.target)) {
                        modal.style.display = 'none';
                    }
                });
            }
            if (modal.style.display === 'flex') {
                modal.style.display = 'none';
                return;
            }
            modal.style.display = 'flex';
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
            if (e && e.currentTarget) {
                const rect = e.currentTarget.getBoundingClientRect();
                const isRightSidebar = e.currentTarget.closest('.right-sidebar');
                let top = rect.top;
                let left = rect.left;
                if (isRightSidebar) {
                    left = rect.left - 330; 
                } else {
                    top = rect.bottom + 5;
                    left = rect.left + (rect.width / 2) - 160;
                }
                if (top + 280 > window.innerHeight) top = window.innerHeight - 290;
                if (top < 10) top = 10;
                if (left + 330 > window.innerWidth) left = window.innerWidth - 340;
                if (left < 10) left = 10;
                modal.style.top = top + 'px';
                modal.style.left = left + 'px';
                modal.style.transform = 'none';
            } else {
                modal.style.top = '50%';
                modal.style.left = '50%';
                modal.style.transform = 'translate(-50%, -50%)';
            }
        }

        function openSalesHistoryFromReturnsPrompt() {
            if (currentUser && currentUser.role !== 'admin' && typeof checkPermission === 'function' && !checkPermission('view_sales_history')) {
                if (typeof logSecurityEvent === 'function') logSecurityEvent('access_denied', 'Attempted to open Sales History without permission');
                nav('access-denied');
                return;
            }
            var modal = document.getElementById('sales-history-modal');
            if (modal) {
                modal.classList.add('hist-modal');
                var shell = modal.querySelector('.modal-content, .glass-card');
                if (shell) shell.classList.add('hist-shell');
                modal.style.zIndex = '10000';
                modal.style.display = 'flex';
                applySalesHistoryDateRange();
                window._salesHistoryPage = [];
                window._salesHistoryLocalOnly = false;

                if (typeof renderShiftSummary === 'function') {
                    try { renderShiftSummary(); } catch (_eSs) {}
                }
                // Immediate list fetch only — never kick secondary/get_data (session lock = hang)
                if (typeof window.renderSalesHistory === 'function') {
                    window.renderSalesHistory();
                } else if (typeof fetchSalesHistoryForUi === 'function') {
                    fetchSalesHistoryForUi({});
                }
                var sInput = document.getElementById('sales-search-input');
                if (sInput) setTimeout(function () { sInput.focus(); }, 80);
            } else {
                nav('reports');
            }
        }
        window.openReturnsOptionsModal = openReturnsOptionsModal;
        window.openSalesHistoryFromReturnsPrompt = openSalesHistoryFromReturnsPrompt;
        window.onBasketVisualRateInput = onBasketVisualRateInput;
        window.commitBasketVisualRateInput = commitBasketVisualRateInput;
        window.saveBasketVisualRateFromButton = saveBasketVisualRateFromButton;
        window.getEffectiveVisualUsdRate100 = getEffectiveVisualUsdRate100;
        window.updateUSDBadge = updateUSDBadge;

