<?php
// POST: customer display, misc tail
    if($act == 'toggle_product_pin') {
        $id = (int)$_POST['id'];
        $val = (int)$_POST['val']; // 1 or 0
        $stmt = $conn->prepare("UPDATE products SET isPinned = ? WHERE id = ?");
        $stmt->bind_param("ii", $val, $id);
        $stmt->execute();
        echo json_encode(["status"=>"success"]); exit();
        touchLastUpdate($conn);
        exit();
    }

    // Unknown action: return JSON so frontend always gets a consistent response
    $actVal = trim((string)($_POST['action'] ?? $_GET['action'] ?? ''));
    echo json_encode(["status"=>"error", "message"=>"نەناسراو: action=" . ($actVal !== '' ? htmlspecialchars($actVal, ENT_QUOTES, 'UTF-8') : 'کەلوپەڕ')]);
    exit();
