/**
 * إعدادات Firebase — تُستخدم فقط من صفحات اختيارية (مثل صفحات المزامنة/المؤشرات).
 * واجهة الـ POS الرئيسية لا تحمّل Firebase (انظر firebase_cashier_sync.js).
 */
window.POS_FIREBASE_CONFIG = window.POS_FIREBASE_CONFIG || {
    apiKey: "AIzaSyBsvR9uOFOTJtR_m1bRyakoBPKc5ckfBRo",
    authDomain: "laptopduhokpos.firebaseapp.com",
    databaseURL: "https://laptopduhokpos-default-rtdb.firebaseio.com",
    projectId: "laptopduhokpos",
    storageBucket: "laptopduhokpos.firebasestorage.app",
    messagingSenderId: "189692641233",
    appId: "1:189692641233:web:02f5382d55ddd6cc50aaf0",
    measurementId: "G-H2WDDPXK7N"
};
window.POS_AUTH_USERS_ENDPOINT = window.POS_AUTH_USERS_ENDPOINT || "";
