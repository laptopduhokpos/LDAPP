<?php
/**
 * Premium pricing — single source of truth for POS + owner-admin.
 * À la carte feature codes (FEAT): one locked section = featureUsd.
 */
if (!defined('POS_PREMIUM_FEATURE_PRICE_USD')) {
    define('POS_PREMIUM_FEATURE_PRICE_USD', 50);
}
if (!defined('POS_PREMIUM_PRO_PRICE_USD')) {
    define('POS_PREMIUM_PRO_PRICE_USD', 224);
}
if (!defined('POS_PREMIUM_PRO_PLUS_PRICE_USD')) {
    define('POS_PREMIUM_PRO_PLUS_PRICE_USD', 424);
}
if (!defined('POS_PREMIUM_PURCHASE_BATCH_PRICE_USD')) {
    define('POS_PREMIUM_PURCHASE_BATCH_PRICE_USD', 25);
}
if (!defined('POS_PREMIUM_INSTALLMENTS_PRICE_USD')) {
    define('POS_PREMIUM_INSTALLMENTS_PRICE_USD', 75);
}

/** USD price for à-la-carte FEAT codes (default featureUsd; per-feature overrides). */
function pos_premium_feature_price_usd(string $featureKey): int {
    $fk = strtolower(trim($featureKey));
    if ($fk === 'enablepurchasebatch') {
        return (int) POS_PREMIUM_PURCHASE_BATCH_PRICE_USD;
    }
    if ($fk === 'enablecustomerinstallments') {
        return (int) POS_PREMIUM_INSTALLMENTS_PRICE_USD;
    }
    if ($fk === 'manufacturerslot') {
        return (int) POS_PREMIUM_FEATURE_PRICE_USD;
    }
    return (int) POS_PREMIUM_FEATURE_PRICE_USD;
}

/** @return array{featureUsd:int,proUsd:int,proPlusUsd:int,terminalSlotUsd:int,purchaseBatchUsd:int} */
function pos_premium_pricing_js(): array {
    $terminal = defined('POS_TERMINAL_SLOT_PRICE_USD') ? (int) POS_TERMINAL_SLOT_PRICE_USD : 99;
    return [
        'featureUsd' => (int) POS_PREMIUM_FEATURE_PRICE_USD,
        'proUsd' => (int) POS_PREMIUM_PRO_PRICE_USD,
        'proPlusUsd' => (int) POS_PREMIUM_PRO_PLUS_PRICE_USD,
        'terminalSlotUsd' => $terminal,
        'purchaseBatchUsd' => (int) POS_PREMIUM_PURCHASE_BATCH_PRICE_USD,
        'installmentsUsd' => (int) POS_PREMIUM_INSTALLMENTS_PRICE_USD,
    ];
}
