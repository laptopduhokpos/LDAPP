<?php
// POST: tables, categories, products
    // --- NEW HANDLERS FOR TABLES & USERS ---
    // Helper: compute piece counts per product from cart items (for trackStock items only; piece/pack/carton)
    // Jewelry sets expand into member product quantities (stock lives on pieces).
    if (!function_exists('cartItemsToPieceCounts')) {
        function cartItemsToPieceCounts($cartItems) {
            global $conn;
            $counts = [];
            if (!is_array($cartItems)) return $counts;
            foreach ($cartItems as $prod) {
                $pid = (int)($prod['id'] ?? 0);
                if (!$pid) continue;
                $mult = 1;
                if (isset($prod['saleUnit']) && $prod['saleUnit'] !== 'piece') {
                    $ppp = isset($prod['pieces_per_pack']) ? max(1, (int)$prod['pieces_per_pack']) : 1;
                    $ppc = isset($prod['packs_per_carton']) ? max(1, (int)$prod['packs_per_carton']) : 1;
                    if ($prod['saleUnit'] === 'carton') $mult = $ppp * $ppc;
                    elseif ($prod['saleUnit'] === 'pack') $mult = $ppp;
                }
                $qty = normalizeQtyForProductData($prod, isset($prod['qty']) ? $prod['qty'] : 1);
                if ($qty <= 0) $qty = 1;
                $linePieces = $mult * $qty;

                $members = null;
                if (!empty($prod['jewelry_set_items']) && is_array($prod['jewelry_set_items'])) {
                    $members = $prod['jewelry_set_items'];
                } elseif (!empty($prod['is_jewelry_set']) && isset($conn) && ($conn instanceof mysqli) && function_exists('pos_get_jewelry_set_qty_map')) {
                    $map = pos_get_jewelry_set_qty_map($conn, $pid);
                    if ($map) {
                        $members = [];
                        foreach ($map as $mid => $mq) {
                            $members[] = ['product_id' => (int)$mid, 'qty' => (float)$mq];
                        }
                    }
                }
                if (is_array($members) && count($members)) {
                    foreach ($members as $m) {
                        if (!is_array($m)) continue;
                        $mid = (int)($m['product_id'] ?? ($m['id'] ?? 0));
                        if ($mid <= 0) continue;
                        $mq = isset($m['qty']) ? max(0.001, (float)$m['qty']) : 1;
                        if (!isset($counts[$mid])) $counts[$mid] = 0;
                        $counts[$mid] += ($mq * $linePieces);
                    }
                    continue;
                }

                if (!isset($prod['trackStock']) || ($prod['trackStock'] !== true && $prod['trackStock'] != 1 && $prod['trackStock'] !== '1')) continue;
                if (!isset($counts[$pid])) $counts[$pid] = 0;
                $counts[$pid] += $linePieces;
            }
            return $counts;
        }
    }

    if($act == 'update_table_items') {
        $id = (int)$_POST['id'];
        $newItemsJson = $_POST['items'] ?? '[]';
        $newItems = json_decode($newItemsJson, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode(["status"=>"error", "message"=>"داتایێن ئایتمان د دروست نینن"]); exit();
        }

        $conn->begin_transaction();
        try {
            $stmtT = $conn->prepare("SELECT items_json FROM tables WHERE id = ? FOR UPDATE");
            $stmtT->bind_param("i", $id);
            $stmtT->execute();
            $resT = $stmtT->get_result();
            if (!$resT || !$rowT = $resT->fetch_assoc()) {
                $conn->rollback();
                echo json_encode(["status"=>"error", "message"=>"مێز نەهاتە دیتن"]); exit();
            }
            $oldItemsJson = $rowT['items_json'] ?? '[]';
            $oldItems = json_decode($oldItemsJson, true);
            if (!is_array($oldItems)) $oldItems = [];

            $oldCounts = cartItemsToPieceCounts($oldItems);
            $newCounts = cartItemsToPieceCounts($newItems);

            $allPids = array_unique(array_merge(array_keys($oldCounts), array_keys($newCounts)));
            sort($allPids, SORT_NUMERIC);
            $postedWh = (int)($_POST['warehouse_id'] ?? 0);
            if (function_exists('pos_sale_warehouse_id_or_error')) {
                $whRes = pos_sale_warehouse_id_or_error($conn, $postedWh);
                if (empty($whRes['ok'])) {
                    $conn->rollback();
                    echo json_encode(['status' => 'error', 'message' => (string)($whRes['message'] ?? 'کۆگەه نەهاتە هەلبژارتن')]);
                    exit();
                }
                $cartWarehouseId = (int)$whRes['id'];
            } else {
                $cartWarehouseId = function_exists('pos_resolve_warehouse_id')
                    ? pos_resolve_warehouse_id($conn, $postedWh)
                    : pos_default_warehouse_id($conn);
            }
            foreach ($allPids as $pid) {
                $oldQ = isset($oldCounts[$pid]) ? (float)$oldCounts[$pid] : 0;
                $newQ = isset($newCounts[$pid]) ? (float)$newCounts[$pid] : 0;
                $delta = $newQ - $oldQ;
                if ($delta === 0) continue;

                $stmtP = $conn->prepare("SELECT qty, trackStock FROM products WHERE id = ? FOR UPDATE");
                $stmtP->bind_param("i", $pid);
                $stmtP->execute();
                $resP = $stmtP->get_result();
                if (!$resP || !$p = $resP->fetch_assoc()) continue;
                if (!$p['trackStock']) continue;

                $qty = pos_heal_warehouse_stock_from_product($conn, $cartWarehouseId, (int)$pid);
                if ($delta > 0) {
                    $settings = pos_load_app_settings_array($conn);
                    $allowNegativeStock = !empty($settings['allowNegativeStock']) && ($settings['allowNegativeStock'] === true || $settings['allowNegativeStock'] === 'true' || $settings['allowNegativeStock'] == 1);
                    if (!$allowNegativeStock && ($qty + 0.000001) < $delta) {
                        $stmtName = $conn->prepare("SELECT name FROM products WHERE id = ?");
                        $stmtName->bind_param("i", $pid);
                        $stmtName->execute();
                        $nameRow = $stmtName->get_result()->fetch_assoc();
                        $name = $nameRow ? $nameRow['name'] : '#' . $pid;
                        $conn->rollback();
                        echo json_encode(["status"=>"error", "message"=>"stock_not_enough", "product_id"=>$pid, "product_name"=>$name, "available"=>$qty, "required"=>$delta]); exit();
                    }
                    pos_delta_warehouse_stock($conn, $cartWarehouseId, (int)$pid, -$delta);
                } else {
                    $addBack = (float)(-$delta);
                    pos_delta_warehouse_stock($conn, $cartWarehouseId, (int)$pid, $addBack);
                }
            }

            $stmt = $conn->prepare("UPDATE tables SET items_json = ?, has_new_items = 1 WHERE id = ?");
            $stmt->bind_param("si", $newItemsJson, $id);
            $stmt->execute();
            $conn->commit();
            touchLastUpdate($conn);
            echo json_encode(["status"=>"success"]); exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(["status"=>"error", "message"=>$e->getMessage()]); exit();
        }
    }

    if($act == 'reset_table_notification') {
        $id = (int)$_POST['id'];
        $stmt = $conn->prepare("UPDATE tables SET has_new_items = 0 WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        touchLastUpdate($conn);
        echo json_encode(["status"=>"success"]); exit();
    }

    if($act == 'add_table') {
        $name = trim($_POST['name'] ?? ''); $empty = '[]';
        $isTakeaway = isset($_POST['isTakeaway']) ? (int)$_POST['isTakeaway'] : 0;
        if ($name === '') { echo json_encode(["status"=>"error", "message"=>"ناڤێ مێزێ پێدڤیە."]); exit(); }
        if (function_exists('checkAndAddCol')) {
            checkAndAddCol($conn, 'tables', 'isTakeaway', "TINYINT(1) DEFAULT 0");
            checkAndAddCol($conn, 'tables', 'has_new_items', "TINYINT(1) DEFAULT 0");
        }
        $stmt = $conn->prepare("INSERT INTO tables (name, items_json, isTakeaway) VALUES (?, ?, ?)");
        if (!$stmt) {
            echo json_encode(["status"=>"error", "message"=>($conn->error ?: "ناکۆکی داتابەیس (tables).")]); exit();
        }
        $stmt->bind_param("ssi", $name, $empty, $isTakeaway);
        if($stmt->execute()) { echo json_encode(["status"=>"success", "id"=>$stmt->insert_id]); exit(); }
        else { echo json_encode(["status"=>"error", "message"=>$stmt->error ?: "نەشیا مێزێ زێدەکەت."]); exit(); }
    }

    if($act == 'delete_table') {
        $id = (int)$_POST['id'];
        $stmt = $conn->prepare("DELETE FROM tables WHERE id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) { echo json_encode(["status"=>"success"]); exit(); }
        else { echo json_encode(["status"=>"error", "message"=>$stmt->error ?: "نەشیا مێزێ ژێ ببەت."]); exit(); }
    }

    if($act == 'rename_table') {
        $id = (int)$_POST['id'];
        $name = trim($_POST['name'] ?? '');
        if ($name === '') { echo json_encode(["status"=>"error", "message"=>"ناڤێ نوی پێدڤیە."]); exit(); }
        $stmt = $conn->prepare("UPDATE tables SET name = ? WHERE id = ?");
        $stmt->bind_param("si", $name, $id);
        if($stmt->execute()) { echo json_encode(["status"=>"success"]); exit(); }
        else { echo json_encode(["status"=>"error", "message"=>$stmt->error ?: "نەشیا ناڤی ب گوهۆڕیت."]); exit(); }
    }

    if($act == 'add_user') {
        $name = trim($_POST['name'] ?? ''); $pin = preg_replace('/\D+/', '', (string)($_POST['pin'] ?? '')); $role = $_POST['role'] ?? ''; $rate = $_POST['rate'] ?? 0;
        $perms = $_POST['permissions'] ?? '[]';
        if ($name === '') { echo json_encode(["status"=>"error", "message"=>"ناڤێ کارمەندی پێدڤیە."]); exit(); }
        if ($pin === '' || strlen($pin) > 4) {
            echo json_encode(["status"=>"error", "message"=>"کۆدێ نهێنی: تەنها ٤ ژمارە."], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $settingsForCap = pos_load_app_settings_array($conn);
        $maxStaff = pos_max_staff_allowed_from_settings(is_array($settingsForCap) ? $settingsForCap : []);
        $cntRes = $conn->query("SELECT COUNT(*) AS c FROM users");
        $nUsers = 0;
        if ($cntRes && ($cr = $cntRes->fetch_assoc())) {
            $nUsers = (int)($cr['c'] ?? 0);
        }
        if ($nUsers >= $maxStaff) {
            $tier = function_exists('pos_subscription_tier_from_settings')
                ? pos_subscription_tier_from_settings(is_array($settingsForCap) ? $settingsForCap : [])
                : 'free';
            $capMsg = function_exists('pos_subscription_staff_cap_message')
                ? pos_subscription_staff_cap_message($tier, $maxStaff)
                : ("سنوورێ کارمەند: زیاتر لە " . $maxStaff . " هەژمار ڕێگەپێدراو نییە. بۆ زیادکردن پەیوەندی بە پشتیوانی بکە.");
            echo json_encode([
                "status" => "error",
                "code" => "staff_cap_exceeded",
                "max_staff" => $maxStaff,
                "current_staff" => $nUsers,
                "subscription_tier" => $tier,
                "message" => $capMsg
            ], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $stmt = $conn->prepare("INSERT INTO users (name, pin, role, hourlyRate, permissions) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssds", $name, $pin, $role, $rate, $perms);
        if($stmt->execute()) { touchLastUpdate($conn); echo json_encode(["status"=>"success", "id"=>$stmt->insert_id, "permissions"=>json_decode($perms)]); exit(); }
        else echo json_encode(["status"=>"error", "message"=>$stmt->error ?: "نەشیا کارمەندی زێدەکەت."]); exit();
    }

    if($act == 'update_user') {
        $id = (int)$_POST['id'];
        $name = $_POST['name']; $pin = preg_replace('/\D+/', '', (string)($_POST['pin'] ?? '')); $role = $_POST['role']; $rate = $_POST['rate'];
        $perms = $_POST['permissions'] ?? '[]';
        if ($pin !== '' && strlen($pin) > 4) {
            echo json_encode(["status"=>"error", "message"=>"کۆدێ نهێنی: تەنها ٤ ژمارە."], JSON_UNESCAPED_UNICODE);
            exit();
        }
        if (!pos_session_is_admin() && pos_session_has_perm('edit_staff')) {
            if ($id === 1) {
                echo json_encode(["status"=>"error", "message"=>"نەشێت ئەم هەژمارە بگۆڕیت."]); exit();
            }
            if (is_string($role) && strtolower(trim($role)) === 'admin') {
                echo json_encode(["status"=>"error", "message"=>"تەنها ڕێڤەبەر دەتوانێت ڕۆڵی ئەدمین دابنێت."]); exit();
            }
        }
        
        if(!empty($pin)) {
            $stmt = $conn->prepare("UPDATE users SET name=?, pin=?, role=?, hourlyRate=?, permissions=? WHERE id=?");
            $stmt->bind_param("sssdsi", $name, $pin, $role, $rate, $perms, $id);
        } else {
            $stmt = $conn->prepare("UPDATE users SET name=?, role=?, hourlyRate=?, permissions=? WHERE id=?");
            $stmt->bind_param("ssdsi", $name, $role, $rate, $perms, $id);
        }
        
        if($stmt->execute()) { logAction($conn, $_SESSION['user_name'] ?? 'Staff', 'edit_user', "Edited user profile: $name"); touchLastUpdate($conn); echo json_encode(["status"=>"success"]); exit(); }
        else echo json_encode(["status"=>"error", "message"=>$stmt->error ?: "نەشیا نووی کەت."]); exit();
    }

    if($act == 'delete_user') {
        $id = (int)$_POST['id'];
        $force = !empty($_POST['force']);
        $secretPin = trim((string)($_POST['secret_pin'] ?? ''));

        // Protect Manager from deletion
        $chk = $conn->query("SELECT id, name, role, balance FROM users WHERE id=$id LIMIT 1");
        if(!$chk || !($row = $chk->fetch_assoc())) {
            echo json_encode(["status"=>"error", "message"=>"ئەم بەکارهێنەرە نەدۆزرایەوە!"]);
            exit();
        }

        if(strcasecmp($row['name'], 'Manager') === 0 || $row['role'] === 'admin' || $id === 1) {
            echo json_encode(["status"=>"error", "message"=>"نەشێی ڕێڤەبەری سەرەکی ژێ ببەی!"]);
            exit();
        }

        $shiftCount = 0;
        $chkShift = $conn->query("SELECT COUNT(*) AS c FROM shifts WHERE userId=$id");
        if($chkShift && $rS = $chkShift->fetch_assoc()) {
            $shiftCount = (int)$rS['c'];
        }

        $hasDebt = false;
        $debtBalance = (float)($row['balance'] ?? 0);
        $chkLedger = $conn->query("SELECT 1 FROM customer_ledger WHERE target_id=$id AND target_type='user' LIMIT 1");
        if(($chkLedger && $chkLedger->num_rows > 0) || abs($debtBalance) > 0.001) {
            $hasDebt = true;
        }

        // یاسای توند: ئەگەر هێشتا قەرزی مابێت ڕێگری لێدەکرێت
        if($hasDebt && !$force) {
            echo json_encode([
                "status"=>"error",
                "code"=>"has_debt",
                "message"=>"ئەم کارمەندە قەرز/حیسابی دارایی هەیە (" . number_format($debtBalance, 0) . "). پێویستە سەرەتا حیسابەکەی پاکتاو بکرێت یان بە ژمارەی نهێنی بسڕدرێتەوە."
            ]);
            exit();
        }

        // ئەگەر شیفت هەبوو یان داوای سڕینەوەی مسۆگەر (force) کرا، پێویستە پین کۆدی ڕێکخستنەکان (Secret PIN) وەربگیرێت
        if($shiftCount > 0 || $force) {
            // Verify secret PIN with stored settings PIN (default 2026)
            $actualPin = '2026';
            $setRes = $conn->query("SELECT settings_json FROM settings LIMIT 1");
            if($setRes && $sRow = $setRes->fetch_assoc()) {
                $sData = json_decode($sRow['settings_json'] ?? '{}', true);
                if(!empty($sData['settingsPin'])) {
                    $actualPin = (string)$sData['settingsPin'];
                }
            }

            if($secretPin === '' || $secretPin !== $actualPin) {
                echo json_encode([
                    "status"=>"error",
                    "code"=>"require_secret_pin",
                    "shiftCount"=>$shiftCount,
                    "hasDebt"=>$hasDebt,
                    "message"=>"ئەم کارمەندە " . ($shiftCount > 0 ? "($shiftCount) شیفتی تۆمارکراوی هەیە" : "قەرزی دارایی هەیە") . ".\nبۆ سڕینەوەی یەکجارەکی، پێویستە ژمارەی نهێنی (Secret PIN) لێبدەیت!"
                ]);
                exit();
            }

            // یاسای توند و خاوێنکردنەوە: ئەگەر سڕایەوە، شیفتەکانی بەناوی مێژوویی پارێزراو دەمێننەوە و userId دەکرێتە NULL
            // تاوەکو ڕاپۆرتەکانی پێشوو تێکنەچن و داتا ون نەبێت
            $userNameSafe = $conn->real_escape_string($row['name']);
            $conn->query("UPDATE shifts SET userName = '$userNameSafe', userId = NULL WHERE userId = $id");
        }

        $conn->query("DELETE FROM users WHERE id=$id");
        logAction($conn, $_SESSION['user_name'] ?? 'Admin', 'delete_user', "Permanently deleted user: " . $row['name'] . " (ID: $id)");
        touchLastUpdate($conn); // Trigger Sync
        echo json_encode(["status"=>"success"]);
        exit();
    }

    if($act == 'void_user') {
        $id = (int)$_POST['id'];
        if($id === 1) { echo json_encode(["status"=>"error", "message"=>"نەشێی ڕێڤەبەری ژ کار بێخی"]); exit(); }
        $conn->query("UPDATE users SET is_active = 0 WHERE id = $id");
        logAction($conn, $_POST['user'] ?? 'System', 'void_user', "Voided user ID: $id");
        echo json_encode(["status"=>"success"]); exit();
        touchLastUpdate($conn);
    }

    if($act == 'delete_all_users') {
        // Delete everyone except Manager (ID 1 or Name 'Manager')
        $conn->query("DELETE FROM users WHERE name != 'Manager' AND id != 1");
        echo json_encode(["status"=>"success"]); exit();
        touchLastUpdate($conn);
        exit();
    }

    if($act == 'delete_sale') {
        $id = (int)$_POST['id'];
        $user = $_POST['user'] ?? 'System';
        if (function_exists('pos_ensure_sales_warehouse_column')) {
            pos_ensure_sales_warehouse_column($conn);
        }
        
        $conn->begin_transaction();
        try {
            // Load sale with lock (prevent double-void/races)
            $stmtSale = $conn->prepare("SELECT id, items_json, total, cashier, payment_method, customer_id, customer_type, is_returned, warehouse_id FROM sales WHERE id = ? LIMIT 1 FOR UPDATE");
            if(!$stmtSale) throw new Exception("Prepare sale lock failed");
            $stmtSale->bind_param("i", $id);
            $stmtSale->execute();
            $res = $stmtSale->get_result();
            if(!$res || !($r = $res->fetch_assoc())) {
                throw new Exception("Sale not found");
            }
            if ((int)($r['is_returned'] ?? 0) === 1) {
                throw new Exception("Sale already voided");
            }

            $items = json_decode($r['items_json'], true);
            if(!is_array($items)) $items = [];
                
            // Restore cash/debt portions based on ledger/customer_ledger entries
            $cid = (int)($r['customer_id'] ?? 0);
            $debtAmt = 0; $cashAmt = 0; $creditLedgerAmt = 0;
                
            if($cid > 0) {
                // Debt portion was stored as customer_ledger type='sale' with receipt_id = sale id
                $stmtDebt = $conn->prepare("SELECT COALESCE(SUM(amount),0) as amt FROM customer_ledger WHERE type = 'sale' AND receipt_id = ? AND target_id = ? AND target_type = ?");
                if($stmtDebt) {
                    $receiptIdStr = (string)$id;
                    $targetType = (string)($r['customer_type'] ?? '');
                    $stmtDebt->bind_param("sis", $receiptIdStr, $cid, $targetType);
                    $stmtDebt->execute();
                    $resDebt = $stmtDebt->get_result();
                    if($resDebt && ($rowDebt = $resDebt->fetch_assoc())) $debtAmt = roundMoney((float)($rowDebt['amt'] ?? 0));
                }
            }
                
            // Cash/bank portion in ledger type='sale'
            $stmtCash = $conn->prepare("SELECT COALESCE(SUM(amount),0) as amt FROM ledger WHERE type = 'sale' AND related_id = ?");
            if($stmtCash) {
                $saleIdInt = (int)$id;
                $stmtCash->bind_param("i", $saleIdInt);
                $stmtCash->execute();
                $resCash = $stmtCash->get_result();
                if($resCash && ($rowCash = $resCash->fetch_assoc())) $cashAmt = roundMoney((float)($rowCash['amt'] ?? 0));
            }

            // Debt ledger portion in ledger type='sale_credit'
            $stmtCredit = $conn->prepare("SELECT COALESCE(SUM(amount),0) as amt FROM ledger WHERE type = 'sale_credit' AND related_id = ?");
            if($stmtCredit) {
                $saleIdInt2 = (int)$id;
                $stmtCredit->bind_param("i", $saleIdInt2);
                $stmtCredit->execute();
                $resCredit = $stmtCredit->get_result();
                if($resCredit && ($rowCredit = $resCredit->fetch_assoc())) $creditLedgerAmt = roundMoney((float)($rowCredit['amt'] ?? 0));
            }
                
            if($debtAmt > 0 && $cid > 0) {
                $tbl = ($r['customer_type'] === 'user') ? 'users' : 'customers';
                $stmtV = $conn->prepare("UPDATE $tbl SET balance = balance - ? WHERE id = ?");
                if(!$stmtV) throw new Exception("Balance reverse prepare failed");
                $stmtV->bind_param("di", $debtAmt, $cid);
                if(!$stmtV->execute()) throw new Exception("Balance reverse failed");
                
                // Ledger correction record for debt rollback
                $note = "Voided Sale #$id";
                $stmtL = $conn->prepare("INSERT INTO customer_ledger (target_id, target_type, type, amount, date, note) VALUES (?, ?, 'void', ?, NOW(), ?)");
                if($stmtL) {
                    $stmtL->bind_param("isds", $cid, $r['customer_type'], $debtAmt, $note);
                    $stmtL->execute();
                }
            }

            // Restore stock to the warehouse it was sold from (not only products.qty)
            if (function_exists('pos_void_restore_sale_warehouse_stock')) {
                pos_void_restore_sale_warehouse_stock($conn, (int)$id, $r, (string)$user);
            } else {
            $counts = [];
            if(is_array($items)) {
                foreach($items as $prod) {
                    if (isset($prod['trackStock']) && ($prod['trackStock'] === true || $prod['trackStock'] == 1 || $prod['trackStock'] === "1")) {
                        $pid = (int)($prod['id'] ?? 0);
                        if ($pid <= 0) continue;
                        if(!isset($counts[$pid])) $counts[$pid]=0;
                        $mult = 1;
                        if (isset($prod['saleUnit']) && $prod['saleUnit'] !== 'piece') {
                            $ppp = isset($prod['pieces_per_pack']) ? max(1, (int)$prod['pieces_per_pack']) : 1;
                            $ppc = isset($prod['packs_per_carton']) ? max(1, (int)$prod['packs_per_carton']) : 1;
                            $piecesPerCarton = $ppp * $ppc;
                            if ($piecesPerCarton <= 1 && isset($prod['itemsPerCarton']) && (int)$prod['itemsPerCarton'] > 1) $piecesPerCarton = (int)$prod['itemsPerCarton'];
                            if ($prod['saleUnit'] === 'carton') $mult = $piecesPerCarton;
                            elseif ($prod['saleUnit'] === 'pack') $mult = $ppp;
                        }
                        $rowQty = saleRowQtyForReturnsValidation($prod);
                        $counts[$pid] += ($rowQty * $mult);
                    }
                }
                foreach($counts as $pid => $qty) {
                    $stmtQ = $conn->prepare("UPDATE products SET qty = qty + ? WHERE id = ?");
                    if(!$stmtQ) throw new Exception("Stock restore prepare failed");
                    $stmtQ->bind_param("di", $qty, $pid);
                    if(!$stmtQ->execute()) throw new Exception("Stock restore failed");
                    insertStockMovement($conn, $pid, '', 'sale_void_restore', $qty, 0, 0, 'void', $id, date('Y-m-d H:i:s'), $user, "Voided Sale #$id");
                }
            }
            }

            // Financial reversal ledger entries
            if($cashAmt > 0) {
                $txnId = uniqid('TXV');
                $amt = roundMoney($cashAmt);
                $date = date('Y-m-d H:i:s');
                $note = "Voided Sale #$id";
                $stmtL = $conn->prepare("INSERT INTO ledger (transaction_id, type, amount, note, date) VALUES (?, 'void_sale', ?, ?, ?)");
                if($stmtL) { $stmtL->bind_param("sdss", $txnId, $amt, $note, $date); $stmtL->execute(); }
            }
            if($creditLedgerAmt > 0) {
                $txnId2 = uniqid('TXVCR');
                $amt2 = roundMoney($creditLedgerAmt);
                $date2 = date('Y-m-d H:i:s');
                $note2 = "Voided Credit Sale #$id";
                $stmtLC = $conn->prepare("INSERT INTO ledger (transaction_id, type, amount, note, date) VALUES (?, 'void_sale_credit', ?, ?, ?)");
                if($stmtLC) { $stmtLC->bind_param("sdss", $txnId2, $amt2, $note2, $date2); $stmtLC->execute(); }
            }

            // Mark as voided (excluded from active totals/reports by existing is_returned filters)
            // Soft-delete only — never remove the row so undo / traces remain.
            $stmtVoid = $conn->prepare("UPDATE sales SET is_returned = 1, remaining_debt = 0, payment_due_at = NULL WHERE id = ?");
            if(!$stmtVoid) throw new Exception("Void update prepare failed");
            $stmtVoid->bind_param("i", $id);
            if(!$stmtVoid->execute()) throw new Exception("Void update failed");

            // Security/Audit log — keep full snapshot for traces + restore fallback
            $logDetails = "Voided/Deleted Sale #$id (Total: {$r['total']}) - invoice delete (not sales return); stock/debt/ledger rolled back.";
            $snap = [
                'id' => (int)$id,
                'total' => (float)($r['total'] ?? 0),
                'cashier' => (string)($r['cashier'] ?? ''),
                'payment_method' => (string)($r['payment_method'] ?? 'cash'),
                'customer_id' => (int)($r['customer_id'] ?? 0),
                'customer_type' => (string)($r['customer_type'] ?? 'customer'),
                'items' => $items,
                'kind' => 'sale_void',
            ];
            $oldJson = json_encode($snap, JSON_UNESCAPED_UNICODE);
            logAction($conn, $user, 'void_sale', $logDetails, null, 'sale', $id, $oldJson ?: null, null);

            $conn->commit();
            touchLastUpdate($conn);
            echo json_encode(["status"=>"success","voided"=>true]); exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(["status"=>"error","message"=>$e->getMessage()]); exit();
        }
    }

    if ($act === 'restore_sale') {
        header('Content-Type: application/json; charset=utf-8');
        $id = (int)($_POST['id'] ?? 0);
        $user = trim((string)($_POST['user'] ?? 'System'));
        if ($user === '') $user = 'System';
        if ($id <= 0) {
            echo json_encode(["status" => "error", "message" => "ID پێدڤیە"], JSON_UNESCAPED_UNICODE);
            exit();
        }
        if (function_exists('pos_ensure_sales_warehouse_column')) {
            pos_ensure_sales_warehouse_column($conn);
        }

        $conn->begin_transaction();
        try {
            $stmtSale = $conn->prepare("SELECT id, items_json, total, cashier, payment_method, customer_id, customer_type, is_returned, warehouse_id FROM sales WHERE id = ? LIMIT 1 FOR UPDATE");
            if (!$stmtSale) throw new Exception("Prepare sale lock failed");
            $stmtSale->bind_param("i", $id);
            $stmtSale->execute();
            $res = $stmtSale->get_result();
            if (!$res || !($r = $res->fetch_assoc())) {
                throw new Exception("Sale not found");
            }
            if ((int)($r['is_returned'] ?? 0) !== 1) {
                throw new Exception("ئەڤ وەسڵە ژێبری نینە / یان پێشتر هاتە گەڕاندن");
            }

            $items = json_decode($r['items_json'], true);
            if (!is_array($items)) $items = [];

            $cid = (int)($r['customer_id'] ?? 0);
            $debtAmt = 0.0;
            $cashAmt = 0.0;
            $creditLedgerAmt = 0.0;

            if ($cid > 0) {
                $stmtDebt = $conn->prepare("SELECT COALESCE(SUM(amount),0) as amt FROM customer_ledger WHERE type = 'sale' AND receipt_id = ? AND target_id = ? AND target_type = ?");
                if ($stmtDebt) {
                    $receiptIdStr = (string)$id;
                    $targetType = (string)($r['customer_type'] ?? '');
                    $stmtDebt->bind_param("sis", $receiptIdStr, $cid, $targetType);
                    $stmtDebt->execute();
                    $resDebt = $stmtDebt->get_result();
                    if ($resDebt && ($rowDebt = $resDebt->fetch_assoc())) {
                        $debtAmt = function_exists('roundMoney') ? roundMoney((float)($rowDebt['amt'] ?? 0)) : (float)($rowDebt['amt'] ?? 0);
                    }
                }
            }

            $stmtCash = $conn->prepare("SELECT COALESCE(SUM(amount),0) as amt FROM ledger WHERE type = 'sale' AND related_id = ?");
            if ($stmtCash) {
                $saleIdInt = (int)$id;
                $stmtCash->bind_param("i", $saleIdInt);
                $stmtCash->execute();
                $resCash = $stmtCash->get_result();
                if ($resCash && ($rowCash = $resCash->fetch_assoc())) {
                    $cashAmt = function_exists('roundMoney') ? roundMoney((float)($rowCash['amt'] ?? 0)) : (float)($rowCash['amt'] ?? 0);
                }
            }

            $stmtCredit = $conn->prepare("SELECT COALESCE(SUM(amount),0) as amt FROM ledger WHERE type = 'sale_credit' AND related_id = ?");
            if ($stmtCredit) {
                $saleIdInt2 = (int)$id;
                $stmtCredit->bind_param("i", $saleIdInt2);
                $stmtCredit->execute();
                $resCredit = $stmtCredit->get_result();
                if ($resCredit && ($rowCredit = $resCredit->fetch_assoc())) {
                    $creditLedgerAmt = function_exists('roundMoney') ? roundMoney((float)($rowCredit['amt'] ?? 0)) : (float)($rowCredit['amt'] ?? 0);
                }
            }

            // Re-apply customer debt that was rolled back on void
            if ($debtAmt > 0 && $cid > 0) {
                $tbl = ($r['customer_type'] === 'user') ? 'users' : 'customers';
                $stmtV = $conn->prepare("UPDATE $tbl SET balance = balance + ? WHERE id = ?");
                if (!$stmtV) throw new Exception("Balance restore prepare failed");
                $stmtV->bind_param("di", $debtAmt, $cid);
                if (!$stmtV->execute()) throw new Exception("Balance restore failed");

                $note = "Restored Sale #$id";
                $stmtL = $conn->prepare("INSERT INTO customer_ledger (target_id, target_type, type, amount, date, note) VALUES (?, ?, 'restore', ?, NOW(), ?)");
                if ($stmtL) {
                    $stmtL->bind_param("isds", $cid, $r['customer_type'], $debtAmt, $note);
                    $stmtL->execute();
                }
            }

            // Re-consume stock from the same warehouse
            if (function_exists('pos_restore_sale_reconsume_warehouse_stock')) {
                pos_restore_sale_reconsume_warehouse_stock($conn, (int)$id, $r, $user);
            } else {
            $counts = [];
            foreach ($items as $prod) {
                if (!isset($prod['trackStock']) || !($prod['trackStock'] === true || $prod['trackStock'] == 1 || $prod['trackStock'] === "1")) {
                    continue;
                }
                $pid = (int)($prod['id'] ?? 0);
                if ($pid <= 0) continue;
                if (!isset($counts[$pid])) $counts[$pid] = 0;
                $mult = 1;
                if (isset($prod['saleUnit']) && $prod['saleUnit'] !== 'piece') {
                    $ppp = isset($prod['pieces_per_pack']) ? max(1, (int)$prod['pieces_per_pack']) : 1;
                    $ppc = isset($prod['packs_per_carton']) ? max(1, (int)$prod['packs_per_carton']) : 1;
                    $piecesPerCarton = $ppp * $ppc;
                    if ($piecesPerCarton <= 1 && isset($prod['itemsPerCarton']) && (int)$prod['itemsPerCarton'] > 1) {
                        $piecesPerCarton = (int)$prod['itemsPerCarton'];
                    }
                    if ($prod['saleUnit'] === 'carton') $mult = $piecesPerCarton;
                    elseif ($prod['saleUnit'] === 'pack') $mult = $ppp;
                }
                $rowQty = function_exists('saleRowQtyForReturnsValidation') ? saleRowQtyForReturnsValidation($prod) : (float)($prod['qty'] ?? 1);
                $counts[$pid] += ($rowQty * $mult);
            }
            foreach ($counts as $pid => $qty) {
                $qty = (float)$qty;
                if ($qty <= 0) continue;
                $stmtQ = $conn->prepare("UPDATE products SET qty = qty - ? WHERE id = ? AND trackStock = 1");
                if (!$stmtQ) throw new Exception("Stock deduct prepare failed");
                $stmtQ->bind_param("di", $qty, $pid);
                if (!$stmtQ->execute()) throw new Exception("Stock deduct failed");
                if (function_exists('insertStockMovement')) {
                    insertStockMovement($conn, $pid, '', 'sale_restore_void', -$qty, 0, 0, 'restore', $id, date('Y-m-d H:i:s'), $user, "Restored Sale #$id");
                }
            }
            }

            // Reverse void ledger compensating entries (best-effort by note)
            $voidNote = "Voided Sale #$id";
            $voidNoteCr = "Voided Credit Sale #$id";
            $stDelL = $conn->prepare("DELETE FROM ledger WHERE (type = 'void_sale' AND note = ?) OR (type = 'void_sale_credit' AND note = ?)");
            if ($stDelL) {
                $stDelL->bind_param("ss", $voidNote, $voidNoteCr);
                $stDelL->execute();
            }
            $stDelCl = $conn->prepare("DELETE FROM customer_ledger WHERE type = 'void' AND note = ?");
            if ($stDelCl) {
                $stDelCl->bind_param("s", $voidNote);
                $stDelCl->execute();
            }

            // If original cash/credit ledger rows were never present, re-add restore markers
            if ($cashAmt > 0) {
                $hasSaleLed = false;
                $stChk = $conn->prepare("SELECT 1 FROM ledger WHERE type = 'sale' AND related_id = ? LIMIT 1");
                if ($stChk) {
                    $stChk->bind_param("i", $id);
                    $stChk->execute();
                    $hasSaleLed = (bool)$stChk->get_result()->fetch_row();
                }
                if (!$hasSaleLed) {
                    $txnId = uniqid('TXR');
                    $amt = $cashAmt;
                    $date = date('Y-m-d H:i:s');
                    $noteR = "Restored Sale #$id";
                    $stmtL = $conn->prepare("INSERT INTO ledger (transaction_id, type, amount, related_id, note, date) VALUES (?, 'sale', ?, ?, ?, ?)");
                    if ($stmtL) {
                        $stmtL->bind_param("sdiss", $txnId, $amt, $id, $noteR, $date);
                        $stmtL->execute();
                    }
                }
            }

            $stmtUnvoid = $conn->prepare("UPDATE sales SET is_returned = 0 WHERE id = ?");
            if (!$stmtUnvoid) throw new Exception("Restore update prepare failed");
            $stmtUnvoid->bind_param("i", $id);
            if (!$stmtUnvoid->execute()) throw new Exception("Restore update failed");

            if (function_exists('logAction')) {
                logAction($conn, $user, 'restore_sale', "Restored/Undeleted Sale #$id (Total: {$r['total']})");
            }

            $conn->commit();
            touchLastUpdate($conn);
            echo json_encode([
                "status" => "success",
                "restored" => true,
                "id" => $id,
                "total" => function_exists('roundMoney') ? roundMoney((float)$r['total']) : (float)$r['total']
            ], JSON_UNESCAPED_UNICODE);
            exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(["status" => "error", "message" => $e->getMessage()], JSON_UNESCAPED_UNICODE);
            exit();
        }
    }

    if($act == 'add_category') {
        $name = $_POST['name'];
        $stmt = $conn->prepare("INSERT IGNORE INTO categories (name) VALUES (?)");
        $stmt->bind_param("s", $name);
        $stmt->execute();
        echo json_encode(["status"=>"success"]); exit();
    }

    if($act == 'delete_category') {
        $name = $_POST['name'];
        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("DELETE FROM categories WHERE name = ?");
            $stmt->bind_param("s", $name);
            $stmt->execute();
            $stmt = $conn->prepare("UPDATE products SET category = '' WHERE category = ?");
            $stmt->bind_param("s", $name);
            $stmt->execute();
            $conn->commit();
            echo json_encode(["status"=>"success"]); exit();
        } catch (Exception $e) { $conn->rollback(); echo json_encode(["status"=>"error"]); exit(); }
    }

    if($act == 'rename_category') {
        $old = trim((string)($_POST['oldName'] ?? ''));
        $new = trim((string)($_POST['newName'] ?? ''));
        if ($old === '' || $new === '' || $old === $new) {
            echo json_encode(["status"=>"error","message"=>"Invalid category names"]); exit();
        }
        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("SELECT 1 FROM categories WHERE name = ? LIMIT 1");
            $stmt->bind_param("s", $new);
            $stmt->execute();
            $targetExists = (bool)$stmt->get_result()->fetch_row();

            $stmt = $conn->prepare("UPDATE products SET category = ? WHERE category = ?");
            $stmt->bind_param("ss", $new, $old);
            $stmt->execute();

            if ($targetExists) {
                $stmt = $conn->prepare("DELETE FROM categories WHERE name = ?");
                $stmt->bind_param("s", $old);
                $stmt->execute();
                $conn->commit();
                echo json_encode(["status"=>"success","merged"=>true]); exit();
            }

            $stmt = $conn->prepare("UPDATE categories SET name = ? WHERE name = ?");
            $stmt->bind_param("ss", $new, $old);
            $stmt->execute();
            $conn->commit();
            echo json_encode(["status"=>"success","merged"=>false]); exit();
        } catch (Exception $e) { $conn->rollback(); echo json_encode(["status"=>"error","message"=>$e->getMessage()]); exit(); }
    }

    if ($act === 'commit_currency_mode') {

        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        if (!function_exists('pos_session_is_privileged') || !pos_session_is_privileged()) {
            pos_json_perm_denied();
        }
        $rawMode = isset($_POST['currencyMode']) ? strtoupper(trim((string)$_POST['currencyMode'])) : '';
        if ($rawMode !== 'USD' && $rawMode !== 'IQD') {
            echo json_encode(['status' => 'error', 'message' => 'Invalid currencyMode (use USD or IQD).'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $mode = $rawMode;
        if (function_exists('pos_shop_currency_locked_by_catalog') && pos_shop_currency_locked_by_catalog($conn)) {
            echo json_encode(['status' => 'error', 'message' => 'ئایتم هەن — دراڤێ بنەڕەتی قفڵکرایە. هەمی ئایتمان ژێببە پاشێ دینار/دولار بگوهۆڕە.'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $oldSettings = pos_load_app_settings_array($conn);
        $merged = is_array($oldSettings) ? $oldSettings : [];
        if (function_exists('pos_apply_default_currency_to_settings_array')) {
            pos_apply_default_currency_to_settings_array($merged, $mode);
        } else {
            $merged['currencyMode'] = $mode;
            $merged['defaultCurrency'] = $mode;
            $merged['default_currency'] = $mode;
        }
        $merged['currencyBaseLocked'] = false;
        if (function_exists('pos_apply_exchange_rate_to_settings_array')) {
            pos_apply_exchange_rate_to_settings_array($merged);
        }
        $outJson = json_encode($merged, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
        if ($outJson === false) {
            echo json_encode(['status' => 'error', 'message' => 'Failed to encode settings'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('app_settings', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        $stmt->bind_param("ss", $outJson, $outJson);
        if ($stmt->execute()) {
            if (function_exists('pos_persist_default_currency_row')) {
                pos_persist_default_currency_row($conn, $mode);
            }
            if (function_exists('pos_persist_exchange_rate_row') && isset($merged['exchange_rate'])) {
                pos_persist_exchange_rate_row($conn, $merged['exchange_rate']);
            }
            try {
                logAction($conn, $_SESSION['user_name'] ?? 'Staff', 'commit_currency_mode', 'Shop default currency: ' . $mode);
            } catch (Throwable $e) {}
            touchLastUpdate($conn);
            echo json_encode(['status' => 'success', 'currencyMode' => $mode, 'defaultCurrency' => $mode], JSON_UNESCAPED_UNICODE);
            exit();
        }
        echo json_encode(['status' => 'error', 'message' => $stmt->error ?: 'DB error'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if ($act === 'secret_set_currency_mode') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        if (!pos_session_is_admin()) pos_json_perm_denied();
        $rawMode = isset($_POST['currencyMode']) ? strtoupper(trim((string)$_POST['currencyMode'])) : '';
        if ($rawMode !== 'USD' && $rawMode !== 'IQD') {
            echo json_encode(['status' => 'error', 'message' => 'currencyMode پێویستە USD یان IQD بێت.'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $oldSettings = pos_load_app_settings_array($conn);
        $merged = is_array($oldSettings) ? $oldSettings : [];
        if (function_exists('pos_apply_default_currency_to_settings_array')) {
            pos_apply_default_currency_to_settings_array($merged, $rawMode);
        } else {
            $merged['currencyMode'] = $rawMode;
            $merged['defaultCurrency'] = $rawMode;
            $merged['default_currency'] = $rawMode;
        }
        if (isset($_POST['rate_bundle'])) {
            $newBundle = (int)$_POST['rate_bundle'];
            if ($newBundle >= 10000) {
                $oldRateRounded = isset($merged['usdRate']) ? (int)round((float)$merged['usdRate']) : 0;
                $merged['usdRate'] = $newBundle;
                if ($newBundle !== $oldRateRounded && function_exists('pos_exchange_rate_history_append')) {
                    pos_exchange_rate_history_append(
                        $conn,
                        $newBundle,
                        isset($_SESSION['user_name']) ? (string)$_SESSION['user_name'] : 'System',
                        'secret_set_currency_mode'
                    );
                }
            }
        }
        $merged['currencyBaseLocked'] = false;
        $outJson = json_encode($merged, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
        if ($outJson === false) {
            echo json_encode(['status' => 'error', 'message' => 'Failed to encode settings'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('app_settings', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        $stmt->bind_param('ss', $outJson, $outJson);
        if ($stmt->execute()) {
            if (function_exists('pos_persist_default_currency_row')) {
                pos_persist_default_currency_row($conn, $rawMode);
            }
            try {
                logAction($conn, $_SESSION['user_name'] ?? 'Admin', 'secret_set_currency_mode', 'Secret menu currency: ' . $rawMode);
            } catch (Throwable $e) {}
            touchLastUpdate($conn);
            echo json_encode([
                'status' => 'success',
                'currencyMode' => $rawMode,
                'usdRate' => (int)round((float)($merged['usdRate'] ?? 150000)),
            ], JSON_UNESCAPED_UNICODE);
            exit();
        }
        echo json_encode(['status' => 'error', 'message' => $stmt->error ?: 'DB error'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if ($act === 'get_sale_id_sequence') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        if (!pos_session_is_admin()) pos_json_perm_denied();
        $maxId = 0;
        $r = $conn->query('SELECT COALESCE(MAX(id), 0) AS mx FROM sales');
        if ($r && ($row = $r->fetch_assoc())) {
            $maxId = (int)($row['mx'] ?? 0);
        }
        $archMax = 0;
        $ra = @$conn->query('SELECT COALESCE(MAX(id), 0) AS mx FROM sales_archive');
        if ($ra && ($arow = $ra->fetch_assoc())) {
            $archMax = (int)($arow['mx'] ?? 0);
        }
        $floor = max($maxId, $archMax);
        $autoInc = $floor + 1;
        $dbName = '';
        $rd = $conn->query('SELECT DATABASE() AS d');
        if ($rd && ($drow = $rd->fetch_assoc())) {
            $dbName = (string)($drow['d'] ?? '');
        }
        if ($dbName !== '') {
            $dbEsc = $conn->real_escape_string($dbName);
            $ri = $conn->query("SELECT AUTO_INCREMENT AS ai FROM information_schema.TABLES WHERE TABLE_SCHEMA = '{$dbEsc}' AND TABLE_NAME = 'sales' LIMIT 1");
            if ($ri && ($irow = $ri->fetch_assoc()) && isset($irow['ai']) && $irow['ai'] !== null) {
                $autoInc = max($floor + 1, (int)$irow['ai']);
            }
        }
        $settings = function_exists('pos_load_app_settings_array') ? pos_load_app_settings_array($conn) : [];
        $pad = isset($settings['saleIdDisplayPad']) ? (int)$settings['saleIdDisplayPad'] : 6;
        if ($pad < 1) $pad = 1;
        if ($pad > 10) $pad = 10;
        echo json_encode([
            'status' => 'success',
            'max_id' => $floor,
            'max_sales' => $maxId,
            'max_archive' => $archMax,
            'next_id' => $autoInc,
            'min_allowed' => $floor + 1,
            'display_pad' => $pad,
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if ($act === 'secret_set_next_sale_id') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        if (!pos_session_is_admin()) pos_json_perm_denied();
        $nextId = isset($_POST['next_sale_id']) ? (int)$_POST['next_sale_id'] : 0;
        $pad = isset($_POST['display_pad']) ? (int)$_POST['display_pad'] : 0;
        if ($nextId < 1) {
            echo json_encode(['status' => 'error', 'message' => 'ژمارا داهاتوو دڤێت ١ یان مەزنتر بیت.'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        if ($nextId > 2000000000) {
            echo json_encode(['status' => 'error', 'message' => 'ژمارا گەلەک مەزنە.'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $maxId = 0;
        $r = $conn->query('SELECT COALESCE(MAX(id), 0) AS mx FROM sales');
        if ($r && ($row = $r->fetch_assoc())) {
            $maxId = (int)($row['mx'] ?? 0);
        }
        $archMax = 0;
        $ra = @$conn->query('SELECT COALESCE(MAX(id), 0) AS mx FROM sales_archive');
        if ($ra && ($arow = $ra->fetch_assoc())) {
            $archMax = (int)($arow['mx'] ?? 0);
        }
        $floor = max($maxId, $archMax);
        $minAllowed = $floor + 1;
        if ($nextId < $minAllowed) {
            echo json_encode([
                'status' => 'error',
                'message' => 'ناشێت ژ دوایین وەسڵێ کێمتر بیت. کێمترین: ' . $minAllowed,
                'min_allowed' => $minAllowed,
                'max_id' => $floor,
            ], JSON_UNESCAPED_UNICODE);
            exit();
        }
        // Set next AUTO_INCREMENT for sales (invoice numbers)
        if (!$conn->query('ALTER TABLE sales AUTO_INCREMENT = ' . (int)$nextId)) {
            echo json_encode(['status' => 'error', 'message' => 'ALTER سەرنەکەوت: ' . $conn->error], JSON_UNESCAPED_UNICODE);
            exit();
        }
        if ($pad > 0) {
            if ($pad < 1) $pad = 1;
            if ($pad > 10) $pad = 10;
            $oldSettings = function_exists('pos_load_app_settings_array') ? pos_load_app_settings_array($conn) : [];
            $merged = is_array($oldSettings) ? $oldSettings : [];
            $merged['saleIdDisplayPad'] = $pad;
            $outJson = json_encode($merged, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
            if ($outJson !== false) {
                $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('app_settings', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
                if ($stmt) {
                    $stmt->bind_param('ss', $outJson, $outJson);
                    $stmt->execute();
                }
            }
        }
        try {
            logAction($conn, $_SESSION['user_name'] ?? 'Admin', 'secret_set_next_sale_id', 'Next sale id → ' . $nextId . ($pad > 0 ? (' pad=' . $pad) : ''));
        } catch (Throwable $e) {}
        touchLastUpdate($conn);
        echo json_encode([
            'status' => 'success',
            'next_id' => $nextId,
            'max_id' => $floor,
            'min_allowed' => $minAllowed,
            'display_pad' => $pad > 0 ? $pad : null,
            'message' => 'وەسڵێ داهاتوو دێ بیتە #' . $nextId,
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if ($act === 'save_exchange_rate') {

        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        if (!function_exists('pos_session_can_set_exchange_rate') || !pos_session_can_set_exchange_rate()) {
            pos_json_perm_denied();
        }
        $oldSettingsForLock = function_exists('pos_load_app_settings_array') ? pos_load_app_settings_array($conn) : [];
        $newBundle = isset($_POST['rate_bundle']) ? (int)$_POST['rate_bundle'] : 0;
        if ($newBundle < 10000) {
            echo json_encode(['status' => 'error', 'message' => 'Invalid rate (minimum 10000 IQD per 100 USD).'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $note = trim((string)($_POST['note'] ?? 'pos_quick'));
        if ($note === '') {
            $note = 'pos_quick';
        }
        if (strlen($note) > 200) {
            $note = substr($note, 0, 200);
        }

        $oldSettings = pos_load_app_settings_array($conn);
        $decodedNew = is_array($oldSettings) ? $oldSettings : [];
        $oldRateRounded = isset($decodedNew['usdRate']) ? (int)round((float)$decodedNew['usdRate']) : 0;
        $decodedNew['usdRate'] = $newBundle;
        if (function_exists('pos_apply_default_currency_to_settings_array')) {
            pos_apply_default_currency_to_settings_array($decodedNew);
        }
        if (function_exists('pos_persist_default_currency_row')) {
            pos_persist_default_currency_row($conn, $decodedNew['defaultCurrency'] ?? ($decodedNew['currencyMode'] ?? 'IQD'));
        }
        if (function_exists('pos_apply_exchange_rate_to_settings_array')) {
            pos_apply_exchange_rate_to_settings_array($decodedNew);
        }
        if (function_exists('pos_persist_exchange_rate_row')) {
            pos_persist_exchange_rate_row($conn, $decodedNew['exchange_rate'] ?? ($newBundle / 100.0));
        }

        $settingsJson = json_encode($decodedNew, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
        if ($settingsJson === false) {
            echo json_encode(['status' => 'error', 'message' => 'Invalid settings merge'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $stmt = $conn->prepare('INSERT INTO settings (setting_key, setting_value) VALUES (\'app_settings\', ?) ON DUPLICATE KEY UPDATE setting_value = ?');
        $stmt->bind_param('ss', $settingsJson, $settingsJson);
        if ($stmt->execute()) {
            if ($newBundle >= 10000 && $newBundle !== $oldRateRounded) {
                pos_exchange_rate_history_append(
                    $conn,
                    $newBundle,
                    isset($_SESSION['user_name']) ? (string)$_SESSION['user_name'] : 'Staff',
                    $note
                );
            }
            try {
                logAction($conn, $_SESSION['user_name'] ?? 'Staff', 'exchange_rate_change', 'USD bundle rate: ' . $oldRateRounded . ' -> ' . $newBundle);
            } catch (Throwable $e) {
            }
            touchLastUpdate($conn);
            echo json_encode(['status' => 'success', 'usdRate' => $newBundle], JSON_UNESCAPED_UNICODE);
            exit();
        }
        echo json_encode(['status' => 'error', 'message' => $stmt->error ?: 'DB error'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if ($act === 'save_visual_usd_rate') {

        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        if (!function_exists('pos_session_can_set_exchange_rate') || !pos_session_can_set_exchange_rate()) {
            pos_json_perm_denied();
        }
        $newBundle = isset($_POST['rate_bundle']) ? (int)$_POST['rate_bundle'] : 0;
        if ($newBundle < 10000) {
            echo json_encode(['status' => 'error', 'message' => 'Invalid rate (minimum 10000 IQD per 100 USD).'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $note = trim((string)($_POST['note'] ?? 'basket_visual_manual'));
        if ($note === '') $note = 'basket_visual_manual';
        if (strlen($note) > 200) $note = substr($note, 0, 200);
        $ok = pos_visual_usd_rate_history_append(
            $conn,
            $newBundle,
            isset($_SESSION['user_name']) ? (string)$_SESSION['user_name'] : 'Staff',
            $note
        );
        if (!$ok) {
            echo json_encode(['status' => 'error', 'message' => 'Failed to save visual rate'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        try {
            logAction($conn, $_SESSION['user_name'] ?? 'Staff', 'visual_usd_rate_change', 'Visual USD bundle rate saved: ' . $newBundle);
        } catch (Throwable $e) {}
        touchLastUpdate($conn);
        echo json_encode(['status' => 'success', 'rate_bundle' => $newBundle], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if ($act == 'get_purchase_history') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();

        $today = date('Y-m-d');
        $allTime = isset($_GET['all']) && ($_GET['all'] === '1' || $_GET['all'] === 'true' || $_GET['all'] === 'yes');
        if ($allTime) {
            $dateFrom = '2000-01-01';
            $dateTo = $today;
        } else {
            $dateFrom = pos_parse_history_date_ymd($_GET['date_from'] ?? '', date('Y-m-d', strtotime('-365 days')));
            $dateTo = pos_parse_history_date_ymd($_GET['date_to'] ?? '', $today);
        }
        if ($dateFrom > $dateTo) {
            $tmp = $dateFrom;
            $dateFrom = $dateTo;
            $dateTo = $tmp;
        }
        $limit = (int)($_GET['limit'] ?? ($allTime ? 10000 : 5000));
        if ($limit < 50) $limit = 50;
        if ($limit > 10000) $limit = 10000;
        $dtStart = $dateFrom . ' 00:00:00';
        $dtEnd = $dateTo . ' 23:59:59';

        $totalCount = 0;
        $countStmt = $conn->prepare("SELECT COUNT(*) AS c FROM supplies WHERE `date` >= ? AND `date` <= ?");
        if ($countStmt) {
            $countStmt->bind_param('ss', $dtStart, $dtEnd);
            $countStmt->execute();
            $countRes = $countStmt->get_result();
            if ($countRes && ($countRow = $countRes->fetch_assoc())) {
                $totalCount = (int)($countRow['c'] ?? 0);
            }
        }

        $supplies = [];
        $stmt = $conn->prepare("SELECT * FROM supplies WHERE `date` >= ? AND `date` <= ? ORDER BY `date` DESC, id DESC LIMIT ?");
        if ($stmt) {
            $stmt->bind_param('ssi', $dtStart, $dtEnd, $limit);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($res) {
                while ($r = $res->fetch_assoc()) {
                    $r['id'] = (int)$r['id'];
                    $r['qtyAdded'] = (float)$r['qtyAdded'];
                    $r['totalCost'] = roundMoney($r['totalCost'] ?? 0);
                    $r['prodId'] = (int)$r['prodId'];
                    $supplies[] = $r;
                }
            }
        }

        echo json_encode([
            'status' => 'success',
            'supplies' => $supplies,
            'date_from' => $dateFrom,
            'date_to' => $dateTo,
            'total' => $totalCount,
            'loaded' => count($supplies),
            'truncated' => $totalCount > count($supplies),
            'adjustments' => (function_exists('pos_purchase_history_adjustments')
                ? pos_purchase_history_adjustments($conn, $supplies, $dtStart, $dtEnd)
                : ['by_txn' => [], 'voided' => []]),
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if ($act == 'get_product_fifo_supplies') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();

        $pid = (int)($_GET['product_id'] ?? 0);
        if ($pid <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'product_id required'], JSON_UNESCAPED_UNICODE);
            exit();
        }

        $includeOpening = isset($_GET['include_opening']) && ($_GET['include_opening'] === '1' || $_GET['include_opening'] === 'true');
        $typeSql = $includeOpening
            ? "AND COALESCE(type, '') NOT IN ('return')"
            : "AND COALESCE(type, '') NOT IN ('return', 'opening')";

        $supplies = [];
        $stmt = $conn->prepare(
            "SELECT * FROM supplies
             WHERE prodId = ?
             {$typeSql}
             AND qtyAdded > 0
             ORDER BY `date` DESC, id DESC
             LIMIT 2000"
        );
        if ($stmt) {
            $stmt->bind_param('i', $pid);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($res) {
                while ($r = $res->fetch_assoc()) {
                    $r['id'] = (int)$r['id'];
                    $r['qtyAdded'] = (float)$r['qtyAdded'];
                    $r['totalCost'] = roundMoney($r['totalCost'] ?? 0);
                    $r['prodId'] = (int)$r['prodId'];
                    $supplies[] = $r;
                }
            }
        }

        $stockBatches = [];
        try {
            $stB = $conn->prepare(
                "SELECT id, product_id, expiry_date, qty, unit_cost, transaction_id, source_type, created_at
                 FROM stock_batches
                 WHERE product_id = ? AND qty > 0.000001
                 ORDER BY expiry_date ASC, id ASC
                 LIMIT 500"
            );
            if ($stB) {
                $stB->bind_param('i', $pid);
                $stB->execute();
                $resB = $stB->get_result();
                if ($resB) {
                    while ($b = $resB->fetch_assoc()) {
                        $stockBatches[] = [
                            'id' => (int)($b['id'] ?? 0),
                            'product_id' => (int)($b['product_id'] ?? 0),
                            'expiry_date' => (string)($b['expiry_date'] ?? ''),
                            'qty' => (float)($b['qty'] ?? 0),
                            'unit_cost' => roundMoney($b['unit_cost'] ?? 0),
                            'transaction_id' => (string)($b['transaction_id'] ?? ''),
                            'source_type' => (string)($b['source_type'] ?? ''),
                            'created_at' => (string)($b['created_at'] ?? ''),
                        ];
                    }
                }
            }
        } catch (Throwable $e) { /* stock_batches optional */ }

        echo json_encode([
            'status' => 'success',
            'product_id' => $pid,
            'supplies' => $supplies,
            'stock_batches' => $stockBatches,
            'loaded' => count($supplies),
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if ($act == 'get_product_item_report_sales') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_write_close();
        }

        $pid = (int)($_GET['product_id'] ?? 0);
        if ($pid <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'product_id required'], JSON_UNESCAPED_UNICODE);
            exit();
        }

        // Match common JSON id shapes on sale lines (id / prodId / product_id).
        $likeA = '%"id":' . $pid . '%';
        $likeB = '%"id":"' . $pid . '"%';
        $likeC = '%"id": ' . $pid . '%';
        $likeD = '%"prodId":' . $pid . '%';
        $likeE = '%"prodId":"' . $pid . '"%';
        $likeF = '%"product_id":' . $pid . '%';

        $sales = [];
        $tables = ['sales'];
        try {
            $chk = $conn->query("SHOW TABLES LIKE 'sales_archive'");
            if ($chk && $chk->num_rows > 0) $tables[] = 'sales_archive';
        } catch (Throwable $e) {}

        foreach ($tables as $table) {
            $sql = "SELECT id, total, discount, items_json, created_at, cashier, payment_method, is_returned, fx_usd_rate, fx_currency_mode
                    FROM `{$table}`
                    WHERE (items_json LIKE ? OR items_json LIKE ? OR items_json LIKE ?
                        OR items_json LIKE ? OR items_json LIKE ? OR items_json LIKE ?)
                    ORDER BY created_at DESC, id DESC
                    LIMIT 5000";
            $st = $conn->prepare($sql);
            if (!$st) continue;
            $st->bind_param('ssssss', $likeA, $likeB, $likeC, $likeD, $likeE, $likeF);
            if (!$st->execute()) continue;
            $res = $st->get_result();
            if (!$res) continue;
            while ($r = $res->fetch_assoc()) {
                $decoded = json_decode($r['items_json'] ?? '[]', true);
                if (!is_array($decoded)) $decoded = [];
                unset($r['items_json']);
                $r['id'] = (int)$r['id'];
                $r['total'] = roundMoney($r['total'] ?? 0);
                $r['discount'] = roundMoney($r['discount'] ?? 0);
                $r['is_returned'] = (int)($r['is_returned'] ?? 0);
                $r['items'] = $decoded;
                $r['date'] = $r['created_at'] ?? null;
                $sales[] = $r;
            }
        }

        echo json_encode([
            'status' => 'success',
            'product_id' => $pid,
            'sales' => $sales,
            'loaded' => count($sales),
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if ($act == 'get_product_item_report') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_write_close();
        }

        $pid = (int)($_GET['product_id'] ?? 0);
        if ($pid <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'product_id required'], JSON_UNESCAPED_UNICODE);
            exit();
        }

        @$conn->query("UPDATE supplies s
            INNER JOIN purchase_returns pr
                ON pr.transaction_id = s.transaction_id
               AND TRIM(IFNULL(pr.transaction_id, '')) != ''
            SET s.`date` = pr.`date`
            WHERE s.prodId = {$pid}
              AND COALESCE(s.type, '') = 'return'
              AND pr.`date` IS NOT NULL
              AND NOT (s.`date` <=> pr.`date`)");

        $likeA = '%"id":' . $pid . '%';
        $likeB = '%"id":"' . $pid . '"%';
        $likeC = '%"id": ' . $pid . '%';
        $likeD = '%"prodId":' . $pid . '%';
        $likeE = '%"prodId":"' . $pid . '"%';
        $likeF = '%"product_id":' . $pid . '%';
        $likeG = '%"productId":' . $pid . '%';
        $likeH = '%"productId":"' . $pid . '"%';
        $likeSql = 'items_json LIKE ? OR items_json LIKE ? OR items_json LIKE ? OR items_json LIKE ? OR items_json LIKE ? OR items_json LIKE ? OR items_json LIKE ? OR items_json LIKE ?';
        $bindJsonLikes = function ($st) use (&$likeA, &$likeB, &$likeC, &$likeD, &$likeE, &$likeF, &$likeG, &$likeH) {
            $st->bind_param('ssssssss', $likeA, $likeB, $likeC, $likeD, $likeE, $likeF, $likeG, $likeH);
        };

        $rowMentionsPid = static function ($json) use ($pid) {
            $items = json_decode($json ?? '[]', true);
            if (!is_array($items)) return [false, []];
            $hit = false;
            $out = [];
            foreach ($items as $it) {
                if (!is_array($it)) continue;
                $id = (int)($it['productId'] ?? $it['prodId'] ?? $it['product_id'] ?? $it['id'] ?? 0);
                if ($id !== $pid) continue;
                $hit = true;
                $out[] = $it;
            }
            return [$hit, $out];
        };

        $supplies = [];
        $stSup = $conn->prepare("SELECT * FROM supplies WHERE prodId = ? ORDER BY `date` ASC, id ASC LIMIT 20000");
        if ($stSup) {
            $stSup->bind_param('i', $pid);
            $stSup->execute();
            $resSup = $stSup->get_result();
            if ($resSup) {
                while ($r = $resSup->fetch_assoc()) {
                    $r['id'] = (int)$r['id'];
                    $r['qtyAdded'] = (float)$r['qtyAdded'];
                    $r['totalCost'] = roundMoney($r['totalCost'] ?? 0);
                    $r['prodId'] = (int)$r['prodId'];
                    $supplies[] = $r;
                }
            }
        }

        $sales = [];
        $saleTables = ['sales'];
        try {
            $chk = $conn->query("SHOW TABLES LIKE 'sales_archive'");
            if ($chk && $chk->num_rows > 0) $saleTables[] = 'sales_archive';
        } catch (Throwable $e) {}
        foreach ($saleTables as $table) {
            $sql = "SELECT id, total, discount, items_json, created_at, cashier, payment_method, is_returned, fx_usd_rate, fx_currency_mode
                    FROM `{$table}`
                    WHERE ({$likeSql})
                    ORDER BY created_at DESC, id DESC
                    LIMIT 20000";
            $st = $conn->prepare($sql);
            if (!$st) continue;
            $bindJsonLikes($st);
            if (!$st->execute()) continue;
            $res = $st->get_result();
            if (!$res) continue;
            while ($r = $res->fetch_assoc()) {
                [$hit, $decoded] = $rowMentionsPid($r['items_json'] ?? '[]');
                if (!$hit) continue;
                unset($r['items_json']);
                $r['id'] = (int)$r['id'];
                $r['total'] = roundMoney($r['total'] ?? 0);
                $r['discount'] = roundMoney($r['discount'] ?? 0);
                $r['is_returned'] = (int)($r['is_returned'] ?? 0);
                $r['items'] = $decoded;
                $r['date'] = $r['created_at'] ?? null;
                $sales[] = $r;
            }
        }

        $returns = [];
        $stRet = $conn->prepare("SELECT id, items_json, total, `date`, cashier, note FROM `returns` WHERE ({$likeSql}) ORDER BY id DESC LIMIT 8000");
        if ($stRet) {
            $bindJsonLikes($stRet);
            if ($stRet->execute()) {
                $resRet = $stRet->get_result();
                if ($resRet) {
                    while ($r = $resRet->fetch_assoc()) {
                        [$hit, $decoded] = $rowMentionsPid($r['items_json'] ?? '[]');
                        if (!$hit) continue;
                        $r['id'] = (int)$r['id'];
                        $r['total'] = roundMoney($r['total'] ?? 0);
                        $r['items'] = $decoded;
                        unset($r['items_json']);
                        $returns[] = $r;
                    }
                }
            }
        }

        $purchaseReturns = [];
        $stPr = $conn->prepare("SELECT id, company_id, company_name, items_json, total, `date`, `user`, note, transaction_id, supplier_invoice_number FROM purchase_returns WHERE ({$likeSql}) ORDER BY id DESC LIMIT 8000");
        if ($stPr) {
            $bindJsonLikes($stPr);
            if ($stPr->execute()) {
                $resPr = $stPr->get_result();
                if ($resPr) {
                    while ($r = $resPr->fetch_assoc()) {
                        [$hit, $decoded] = $rowMentionsPid($r['items_json'] ?? '[]');
                        if (!$hit) continue;
                        $r['id'] = (int)$r['id'];
                        $r['company_id'] = (int)($r['company_id'] ?? 0);
                        $r['total'] = roundMoney($r['total'] ?? 0);
                        $r['items'] = $decoded;
                        unset($r['items_json']);
                        $purchaseReturns[] = $r;
                    }
                }
            }
        }

        $waste = [];
        $stW = $conn->prepare("SELECT id, prodId, qty, cost, `date`, reason FROM waste WHERE prodId = ? ORDER BY id DESC LIMIT 8000");
        if ($stW) {
            $stW->bind_param('i', $pid);
            if ($stW->execute()) {
                $resW = $stW->get_result();
                if ($resW) {
                    while ($r = $resW->fetch_assoc()) {
                        $r['id'] = (int)$r['id'];
                        $r['prodId'] = (int)$r['prodId'];
                        $r['qty'] = (float)($r['qty'] ?? 0);
                        $r['cost'] = roundMoney($r['cost'] ?? 0);
                        $waste[] = $r;
                    }
                }
            }
        }

        $qty = null;
        $stQ = $conn->prepare("SELECT qty FROM products WHERE id = ? LIMIT 1");
        if ($stQ) {
            $stQ->bind_param('i', $pid);
            if ($stQ->execute()) {
                $rq = $stQ->get_result();
                if ($rq && ($rowQ = $rq->fetch_assoc())) {
                    $qty = (float)($rowQ['qty'] ?? 0);
                }
            }
        }

        echo json_encode([
            'status' => 'success',
            'product_id' => $pid,
            'qty' => $qty,
            'supplies' => $supplies,
            'sales' => $sales,
            'returns' => $returns,
            'purchase_returns' => $purchaseReturns,
            'waste' => $waste,
            'loaded_supplies' => count($supplies),
            'loaded_sales' => count($sales),
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if ($act == 'get_sale_record') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();

        $id = (int)($_GET['id'] ?? 0);
        $sale = pos_fetch_sale_record_by_id($conn, $id);
        if (!$sale) {
            echo json_encode(['status' => 'error', 'message' => 'Sale not found'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        if (!pos_session_is_privileged()) {
            $name = pos_session_user_name();
            if (($sale['cashier'] ?? '') !== $name) {
                echo json_encode(['status' => 'error', 'message' => 'Access denied'], JSON_UNESCAPED_UNICODE);
                exit();
            }
        }
        echo json_encode(['status' => 'success', 'sale' => $sale], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if ($act == 'get_sales_history') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        // Release session lock so this never waits behind get_data/secondary/long-poll
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_write_close();
        }

        $cashier = '';
        if (!pos_session_is_privileged()) {
            $cashier = pos_session_user_name();
        }

        $payload = pos_fetch_sales_history_rows($conn, [
            'date_from' => $_GET['date_from'] ?? '',
            'date_to' => $_GET['date_to'] ?? '',
            'limit' => $_GET['limit'] ?? 2000,
            'offset' => $_GET['offset'] ?? 0,
            'include_archive' => $_GET['include_archive'] ?? 1,
            'cashier' => $cashier,
            'q' => $_GET['q'] ?? '',
            'customer_id' => $_GET['customer_id'] ?? '',
            'customer_type' => $_GET['customer_type'] ?? '',
        ]);

        if (!empty($payload['error'])) {
            echo json_encode([
                'status' => 'error',
                'message' => 'هەڵە لە خوێندنەوەی مێژوو لە داتابەیس',
                'detail' => $payload['error'],
            ], JSON_UNESCAPED_UNICODE | (defined('JSON_INVALID_UTF8_SUBSTITUTE') ? JSON_INVALID_UTF8_SUBSTITUTE : 0));
            exit();
        }
        unset($payload['error']);

        if (!function_exists('pos_session_can_view_cost') || !pos_session_can_view_cost()) {
            if (!empty($payload['sales']) && is_array($payload['sales'])) {
                foreach ($payload['sales'] as &$shRow) {
                    if (empty($shRow['items']) || !is_array($shRow['items'])) {
                        continue;
                    }
                    foreach ($shRow['items'] as &$shIt) {
                        if (is_array($shIt)) {
                            $shIt['cost'] = 0;
                            unset($shIt['cost_pack'], $shIt['cost_carton'], $shIt['cost_usd']);
                        }
                    }
                    unset($shIt);
                }
                unset($shRow);
            }
        }

        $jsonFlags = JSON_UNESCAPED_UNICODE;
        if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
            $jsonFlags |= JSON_INVALID_UTF8_SUBSTITUTE;
        }
        $json = json_encode(array_merge(['status' => 'success'], $payload), $jsonFlags);
        if (ob_get_length()) ob_clean();
        if ($json === false) {
            echo json_encode(['status' => 'error', 'message' => json_last_error_msg()]);
        } else {
            echo $json;
        }
        exit();
    }

    if ($act == 'get_returns_history') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();

        $today = date('Y-m-d');
        $dateFrom = pos_parse_history_date_ymd($_GET['date_from'] ?? '', $today);
        $dateTo = pos_parse_history_date_ymd($_GET['date_to'] ?? '', $today);
        if ($dateFrom > $dateTo) {
            $tmp = $dateFrom;
            $dateFrom = $dateTo;
            $dateTo = $tmp;
        }
        $limit = (int)($_GET['limit'] ?? 300);
        if ($limit < 50) $limit = 50;
        if ($limit > 2000) $limit = 2000;
        $offset = max(0, (int)($_GET['offset'] ?? 0));
        $fetchLimit = $limit + 1;
        $dtStart = $dateFrom . ' 00:00:00';
        $dtEnd = $dateTo . ' 23:59:59';

        $returns = [];
        $stmt = $conn->prepare("SELECT * FROM returns WHERE `date` >= ? AND `date` <= ? ORDER BY `date` DESC, id DESC LIMIT ? OFFSET ?");
        if ($stmt) {
            $stmt->bind_param('ssii', $dtStart, $dtEnd, $fetchLimit, $offset);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($res) {
                while ($r = $res->fetch_assoc()) {
                    $r['id'] = (int)$r['id'];
                    $r['total'] = roundMoney($r['total'] ?? 0);
                    $r['items'] = json_decode($r['items_json'] ?? '[]');
                    unset($r['items_json']);
                    $returns[] = $r;
                }
            }
        }
        $hasMore = count($returns) > $limit;
        if ($hasMore) {
            array_pop($returns);
        }

        echo json_encode([
            'status' => 'success',
            'returns' => $returns,
            'date_from' => $dateFrom,
            'date_to' => $dateTo,
            'limit' => $limit,
            'offset' => $offset,
            'has_more' => $hasMore,
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if ($act == 'get_voided_sales_history') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_write_close();
        }

        $today = date('Y-m-d');
        $dateFrom = pos_parse_history_date_ymd($_GET['date_from'] ?? '', $today);
        $dateTo = pos_parse_history_date_ymd($_GET['date_to'] ?? '', $today);
        if ($dateFrom > $dateTo) {
            $tmp = $dateFrom;
            $dateFrom = $dateTo;
            $dateTo = $tmp;
        }
        $limit = (int)($_GET['limit'] ?? 200);
        if ($limit < 50) $limit = 50;
        if ($limit > 2000) $limit = 2000;
        $offset = max(0, (int)($_GET['offset'] ?? 0));
        $fetchLimit = $limit + 1;
        $dtStart = $dateFrom . ' 00:00:00';
        $dtEnd = $dateTo . ' 23:59:59';

        $cashier = '';
        if (!pos_session_is_privileged()) {
            $cashier = pos_session_user_name();
        }

        $voids = [];
        $sql = "SELECT id, total, discount, items_json, created_at, cashier, payment_method, customer_id, customer_type, is_returned, transaction_id
                FROM sales
                WHERE is_returned = 1 AND created_at >= ? AND created_at <= ?";
        $types = 'ss';
        $params = [$dtStart, $dtEnd];
        if ($cashier !== '') {
            $sql .= ' AND cashier = ?';
            $types .= 's';
            $params[] = $cashier;
        }
        $sql .= ' ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?';
        $types .= 'ii';
        $params[] = $fetchLimit;
        $params[] = $offset;

        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param($types, ...$params);
            if ($stmt->execute()) {
                $res = $stmt->get_result();
                if ($res) {
                    while ($r = $res->fetch_assoc()) {
                        $row = pos_format_sale_history_row($r, null);
                        $voids[] = [
                            'id' => (int)$row['id'],
                            'date' => $row['date'] ?? $row['created_at'] ?? '',
                            'created_at' => $row['created_at'] ?? '',
                            'items' => $row['items'] ?? [],
                            'total' => roundMoney($row['total'] ?? 0),
                            'cashier' => $row['cashier'] ?? '',
                            'payment_method' => $row['payment_method'] ?? 'cash',
                            'note' => 'ژێبرنا وەسڵێ (Void)',
                            'type' => 'void',
                            'sale_id' => (int)$row['id'],
                            'is_returned' => 1,
                        ];
                    }
                }
            }
        }

        $hasMore = count($voids) > $limit;
        if ($hasMore) {
            array_pop($voids);
        }

        echo json_encode([
            'status' => 'success',
            'voids' => $voids,
            'date_from' => $dateFrom,
            'date_to' => $dateTo,
            'limit' => $limit,
            'offset' => $offset,
            'has_more' => $hasMore,
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if ($act == 'get_sale_edits_history') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        if (!pos_session_is_privileged() && !pos_session_has_perm('view_audit_logs') && !pos_session_has_perm('view_sales_history') && !pos_session_has_perm('returns_manage')) {
            pos_json_perm_denied();
        }
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_write_close();
        }

        $today = date('Y-m-d');
        $saleIdFilter = (int)($_GET['sale_id'] ?? 0);
        $dateFromDefault = $saleIdFilter > 0 ? date('Y-m-d', strtotime('-2 years')) : date('Y-m-d', strtotime('-90 days'));
        $dateFrom = pos_parse_history_date_ymd($_GET['date_from'] ?? '', $dateFromDefault);
        $dateTo = pos_parse_history_date_ymd($_GET['date_to'] ?? '', $today);
        if ($dateFrom > $dateTo) {
            $tmp = $dateFrom;
            $dateFrom = $dateTo;
            $dateTo = $tmp;
        }
        $limit = (int)($_GET['limit'] ?? 300);
        if ($limit < 50) {
            $limit = 50;
        }
        if ($limit > 1000) {
            $limit = 1000;
        }
        $dtStart = $dateFrom . ' 00:00:00';
        $dtEnd = $dateTo . ' 23:59:59';

        $edits = [];
        $sqlEdits = "SELECT id, user, action_type, details, created_at, entity_id, old_value, new_value
             FROM audit_logs
             WHERE action_type IN ('sale_cart_replace','sale_line_edit','sale_line_add','sale_line_delete')
               AND created_at >= ? AND created_at <= ?";
        if ($saleIdFilter > 0) {
            $sqlEdits .= " AND (entity_id = ? OR details LIKE ?)";
        }
        $sqlEdits .= " ORDER BY id DESC LIMIT ?";
        $st = $conn->prepare($sqlEdits);
        if ($st) {
            if ($saleIdFilter > 0) {
                $likeSale = '%#' . $saleIdFilter . '%';
                $st->bind_param('ssisi', $dtStart, $dtEnd, $saleIdFilter, $likeSale, $limit);
            } else {
                $st->bind_param('ssi', $dtStart, $dtEnd, $limit);
            }
            $st->execute();
            $res = $st->get_result();
            while ($res && ($row = $res->fetch_assoc())) {
                $details = (string)($row['details'] ?? '');
                $saleId = (int)($row['entity_id'] ?? 0);
                if ($saleId <= 0 && preg_match('/#(\d+)/', $details, $m)) {
                    $saleId = (int)$m[1];
                }
                $oldTotal = null;
                $newTotal = null;
                $changes = [];
                $ov = null;
                $nv = null;
                if (!empty($row['old_value'])) {
                    $ov = json_decode((string)$row['old_value'], true);
                    if (is_array($ov)) {
                        if (isset($ov['total'])) {
                            $oldTotal = roundMoney($ov['total']);
                        }
                        if (!empty($ov['changes']) && is_array($ov['changes'])) {
                            foreach ($ov['changes'] as $ch) {
                                $ch = trim((string)$ch);
                                if ($ch !== '') {
                                    $changes[] = $ch;
                                }
                            }
                        }
                    } else {
                        $ov = null;
                    }
                }
                if (!empty($row['new_value'])) {
                    $nv = json_decode((string)$row['new_value'], true);
                    if (!is_array($nv)) {
                        $nv = null;
                    } elseif (isset($nv['total'])) {
                        $newTotal = roundMoney($nv['total']);
                    }
                }
                if (empty($changes) && is_array($ov) && !empty($ov['items']) && is_array($nv) && isset($nv['items']) && function_exists('pos_build_sale_cart_edit_diff')) {
                    $rebuilt = pos_build_sale_cart_edit_diff(
                        $ov['items'],
                        $nv['items'],
                        $ov['total'] ?? null,
                        $nv['total'] ?? null,
                        $ov['discount'] ?? null,
                        $nv['discount'] ?? null
                    );
                    if (!empty($rebuilt['lines'])) {
                        $changes = $rebuilt['lines'];
                    }
                }
                if ($oldTotal === null && $newTotal === null && preg_match('/total\s+([\d.]+)\s*(?:→|->)\s*([\d.]+)/u', $details, $tm)) {
                    $oldTotal = roundMoney((float)$tm[1]);
                    $newTotal = roundMoney((float)$tm[2]);
                }
                if (empty($changes) && preg_match('/\|\s*((?:سڕا|زیادکرا|گۆڕا|داشکاندن).+)$/u', $details, $dm)) {
                    $parts = preg_split('/\s*·\s*/u', $dm[1]);
                    foreach ($parts as $p) {
                        $p = trim((string)$p);
                        if ($p !== '' && !preg_match('/^total\s+/i', $p)) {
                            $changes[] = $p;
                        }
                    }
                }
                $edits[] = [
                    'id' => (int)$row['id'],
                    'sale_id' => $saleId,
                    'user' => (string)($row['user'] ?? ''),
                    'action_type' => (string)($row['action_type'] ?? ''),
                    'details' => $details,
                    'created_at' => (string)($row['created_at'] ?? ''),
                    'old_total' => $oldTotal,
                    'new_total' => $newTotal,
                    'changes' => $changes,
                ];
            }
        }

        echo json_encode([
            'status' => 'success',
            'edits' => $edits,
            'date_from' => $dateFrom,
            'date_to' => $dateTo,
            'limit' => $limit,
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if ($act == 'get_voided_purchase_invoices') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        if (!pos_session_is_privileged() && !pos_session_has_perm('view_audit_logs') && !pos_session_has_perm('view_purchase_history') && !pos_session_has_perm('companies_manage')) {
            pos_json_perm_denied();
        }
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_write_close();
        }

        $today = date('Y-m-d');
        $dateFrom = pos_parse_history_date_ymd($_GET['date_from'] ?? '', date('Y-m-d', strtotime('-90 days')));
        $dateTo = pos_parse_history_date_ymd($_GET['date_to'] ?? '', $today);
        if ($dateFrom > $dateTo) {
            $tmp = $dateFrom;
            $dateFrom = $dateTo;
            $dateTo = $tmp;
        }
        $limit = (int)($_GET['limit'] ?? 400);
        if ($limit < 50) {
            $limit = 50;
        }
        if ($limit > 1000) {
            $limit = 1000;
        }
        $scope = strtolower(trim((string)($_GET['scope'] ?? 'return')));
        if (!in_array($scope, ['return', 'purchase', 'all'], true)) {
            $scope = 'return';
        }
        $dtStart = $dateFrom . ' 00:00:00';
        $dtEnd = $dateTo . ' 23:59:59';

        $voids = [];
        $st = $conn->prepare(
            "SELECT id, user, action_type, details, created_at, old_value, new_value
             FROM audit_logs
             WHERE action_type = 'void_purchase_invoice'
               AND created_at >= ? AND created_at <= ?
             ORDER BY id DESC
             LIMIT ?"
        );
        if ($st) {
            $st->bind_param('ssi', $dtStart, $dtEnd, $limit);
            $st->execute();
            $res = $st->get_result();
            while ($res && ($row = $res->fetch_assoc())) {
                $snap = null;
                if (!empty($row['old_value'])) {
                    $decoded = json_decode((string)$row['old_value'], true);
                    if (is_array($decoded)) {
                        $snap = $decoded;
                    }
                }
                if (function_exists('pos_void_purchase_audit_is_active') && !pos_void_purchase_audit_is_active($conn, $row, $snap)) {
                    continue;
                }
                $kind = '';
                if (is_array($snap) && !empty($snap['kind'])) {
                    $kind = strtolower(trim((string)$snap['kind']));
                } elseif (is_array($snap) && !empty($snap['type'])) {
                    $kind = (strtolower(trim((string)$snap['type'])) === 'return') ? 'return' : 'purchase';
                }
                if ($scope === 'return' && $kind !== 'return') {
                    continue;
                }
                if ($scope === 'purchase' && $kind === 'return') {
                    continue;
                }
                $items = [];
                if (is_array($snap) && !empty($snap['items']) && is_array($snap['items'])) {
                    foreach ($snap['items'] as $it) {
                        if (!is_array($it)) {
                            continue;
                        }
                        $items[] = [
                            'id' => (int)($it['id'] ?? 0),
                            'prodId' => (int)($it['prodId'] ?? 0),
                            'name' => (string)($it['name'] ?? ''),
                            'qty' => (float)($it['qty'] ?? 0),
                            'totalCost' => roundMoney($it['totalCost'] ?? 0),
                            'batch' => (string)($it['batch'] ?? ''),
                        ];
                    }
                }
                $voids[] = [
                    'id' => (int)$row['id'],
                    'created_at' => (string)($row['created_at'] ?? ''),
                    'user' => (string)($row['user'] ?? ''),
                    'details' => (string)($row['details'] ?? ''),
                    'txn_id' => is_array($snap) ? (string)($snap['txn_id'] ?? '') : '',
                    'company' => is_array($snap) ? (string)($snap['company'] ?? '') : '',
                    'kind' => $kind !== '' ? $kind : 'purchase',
                    'type' => is_array($snap) ? (string)($snap['type'] ?? '') : '',
                    'total' => is_array($snap) ? roundMoney($snap['total'] ?? 0) : 0,
                    'date' => is_array($snap) ? (string)($snap['date'] ?? '') : '',
                    'supplier_invoice_number' => is_array($snap) ? (string)($snap['supplier_invoice_number'] ?? '') : '',
                    'items_count' => is_array($snap) ? (int)($snap['items_count'] ?? count($items)) : count($items),
                    'items' => $items,
                ];
            }
        }

        echo json_encode([
            'status' => 'success',
            'voids' => $voids,
            'scope' => $scope,
            'date_from' => $dateFrom,
            'date_to' => $dateTo,
            'limit' => $limit,
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if ($act == 'get_purchase_edits_history') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        if (!pos_session_is_privileged() && !pos_session_has_perm('view_audit_logs') && !pos_session_has_perm('view_purchase_history') && !pos_session_has_perm('companies_manage')) {
            pos_json_perm_denied();
        }
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_write_close();
        }

        $today = date('Y-m-d');
        $dateFrom = pos_parse_history_date_ymd($_GET['date_from'] ?? '', date('Y-m-d', strtotime('-90 days')));
        $dateTo = pos_parse_history_date_ymd($_GET['date_to'] ?? '', $today);
        if ($dateFrom > $dateTo) {
            $tmp = $dateFrom;
            $dateFrom = $dateTo;
            $dateTo = $tmp;
        }
        $limit = (int)($_GET['limit'] ?? 300);
        if ($limit < 50) {
            $limit = 50;
        }
        if ($limit > 1000) {
            $limit = 1000;
        }
        $dtStart = $dateFrom . ' 00:00:00';
        $dtEnd = $dateTo . ' 23:59:59';

        $filterTxn = trim((string)($_GET['txn_id'] ?? ''));
        $edits = [];
        $st = null;
        if ($filterTxn !== '') {
            $like = '%#' . $filterTxn . '%';
            $st = $conn->prepare(
                "SELECT id, user, action_type, details, created_at, entity_id, old_value, new_value
                 FROM audit_logs
                 WHERE action_type IN ('purchase_cart_replace','purchase_line_edit','purchase_line_add','purchase_line_delete')
                   AND details LIKE ?
                 ORDER BY id DESC
                 LIMIT ?"
            );
            if ($st) {
                $st->bind_param('si', $like, $limit);
                $st->execute();
            }
        } else {
            $st = $conn->prepare(
                "SELECT id, user, action_type, details, created_at, entity_id, old_value, new_value
                 FROM audit_logs
                 WHERE action_type IN ('purchase_cart_replace','purchase_line_edit','purchase_line_add','purchase_line_delete')
                   AND created_at >= ? AND created_at <= ?
                 ORDER BY id DESC
                 LIMIT ?"
            );
            if ($st) {
                $st->bind_param('ssi', $dtStart, $dtEnd, $limit);
                $st->execute();
            }
        }
        if ($st) {
            $res = $st->get_result();
            while ($res && ($row = $res->fetch_assoc())) {
                $details = (string)($row['details'] ?? '');
                $txnId = '';
                if (preg_match('/#([A-Za-z0-9_-]+)/u', $details, $m)) {
                    $txnId = (string)$m[1];
                }
                if ($txnId === '' && preg_match('/وەسڵ\s+([A-Za-z0-9_-]+)/u', $details, $m2)) {
                    $txnId = (string)$m2[1];
                }
                if ($filterTxn !== '' && $txnId !== $filterTxn) {
                    continue;
                }
                $oldTotal = null;
                $newTotal = null;
                $changes = [];
                $ov = null;
                $nv = null;
                if (!empty($row['old_value'])) {
                    $ov = json_decode((string)$row['old_value'], true);
                    if (is_array($ov)) {
                        if (isset($ov['total'])) {
                            $oldTotal = roundMoney($ov['total']);
                        }
                        if (!empty($ov['changes']) && is_array($ov['changes'])) {
                            foreach ($ov['changes'] as $ch) {
                                $ch = trim((string)$ch);
                                if ($ch !== '') {
                                    $changes[] = $ch;
                                }
                            }
                        }
                    } else {
                        $ov = null;
                    }
                }
                if (!empty($row['new_value'])) {
                    $nv = json_decode((string)$row['new_value'], true);
                    if (!is_array($nv)) {
                        $nv = null;
                    } elseif (isset($nv['total'])) {
                        $newTotal = roundMoney($nv['total']);
                    }
                }
                if (empty($changes) && is_array($ov) && !empty($ov['items']) && is_array($nv) && isset($nv['items']) && function_exists('pos_build_sale_cart_edit_diff')) {
                    $rebuilt = pos_build_sale_cart_edit_diff(
                        $ov['items'],
                        $nv['items'],
                        $ov['total'] ?? null,
                        $nv['total'] ?? null,
                        $ov['discount'] ?? null,
                        $nv['discount'] ?? null
                    );
                    if (!empty($rebuilt['lines'])) {
                        $changes = $rebuilt['lines'];
                    }
                }
                if ($oldTotal === null && $newTotal === null && preg_match('/total\s+([\d.]+)\s*(?:→|->)\s*([\d.]+)/u', $details, $tm)) {
                    $oldTotal = roundMoney((float)$tm[1]);
                    $newTotal = roundMoney((float)$tm[2]);
                }
                if (empty($changes) && preg_match('/\|\s*((?:سڕا|زیادکرا|گۆڕا|داشکاندن).+)$/u', $details, $dm)) {
                    $parts = preg_split('/\s*·\s*/u', $dm[1]);
                    foreach ($parts as $p) {
                        $p = trim((string)$p);
                        if ($p !== '' && !preg_match('/^total\s+/i', $p)) {
                            $changes[] = $p;
                        }
                    }
                }
                $edits[] = [
                    'id' => (int)$row['id'],
                    'txn_id' => $txnId,
                    'user' => (string)($row['user'] ?? ''),
                    'action_type' => (string)($row['action_type'] ?? ''),
                    'details' => $details,
                    'created_at' => (string)($row['created_at'] ?? ''),
                    'old_total' => $oldTotal,
                    'new_total' => $newTotal,
                    'changes' => $changes,
                ];
            }
        }

        echo json_encode([
            'status' => 'success',
            'edits' => $edits,
            'date_from' => $dateFrom,
            'date_to' => $dateTo,
            'limit' => $limit,
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if ($act == 'get_purchase_returns_history') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();

        // Older save_purchase_return bound DATETIME as double, so supply lines
        // landed on 0000-00-00 / year-only dates and vanished from "today" history.
        @$conn->query("UPDATE supplies s
            INNER JOIN purchase_returns pr
                ON pr.transaction_id = s.transaction_id
               AND TRIM(IFNULL(pr.transaction_id, '')) != ''
            SET s.`date` = pr.`date`
            WHERE COALESCE(s.type, '') = 'return'
              AND pr.`date` IS NOT NULL
              AND NOT (s.`date` <=> pr.`date`)");
        
        $purchase_returns = [];
        $res = $conn->query("SELECT * FROM purchase_returns ORDER BY id DESC LIMIT 10000");
        if($res) {
            while($r = $res->fetch_assoc()) {
                $r['id'] = (int)$r['id']; 
                $r['total'] = roundMoney($r['total'] ?? 0);
                $r['items'] = json_decode($r['items_json'] ?? '[]');
                $purchase_returns[] = $r;
            }
        }
        
        echo json_encode(['status' => 'success', 'purchase_returns' => $purchase_returns]);
        exit();
    }

    if ($act == 'create_installment_plan') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        if (!pos_installments_pro_enabled($conn)) {
            pos_installments_pro_required_json($conn);
        }

        $customerId = (int)($_POST['customer_id'] ?? 0);
        $amount = pos_installment_money_iqd((float)($_POST['amount'] ?? 0));
        $months = (int)($_POST['months'] ?? 0);
        $startDate = trim((string)($_POST['start_date'] ?? ''));
        $note = trim((string)($_POST['note'] ?? ''));
        $createdBy = trim((string)($_POST['created_by'] ?? 'System'));
        if ($createdBy === '') $createdBy = 'System';

        if ($customerId <= 0) { echo json_encode(['status' => 'error', 'message' => 'کریار نادروستە']); exit(); }
        if ($amount <= 0) { echo json_encode(['status' => 'error', 'message' => 'بڕی قست نادروستە']); exit(); }
        if ($months < 2 || $months > 24) { echo json_encode(['status' => 'error', 'message' => 'ژمارەی مانگ دەبێت لە 2 تا 24 بێت']); exit(); }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $startDate)) $startDate = date('Y-m-d');

        $stmtC = $conn->prepare("SELECT balance, name FROM customers WHERE id = ? LIMIT 1");
        $stmtC->bind_param('i', $customerId);
        $stmtC->execute();
        $custRes = $stmtC->get_result();
        if (!$custRes || !($cust = $custRes->fetch_assoc())) {
            echo json_encode(['status' => 'error', 'message' => 'کریار نەهاتە دیتن']); exit();
        }
        $balance = roundMoney($cust['balance'] ?? 0);
        if ($balance <= 0) { echo json_encode(['status' => 'error', 'message' => 'چ قەرز ل سەر کریاری نینە']); exit(); }
        if ($amount > $balance + 0.0001) { echo json_encode(['status' => 'error', 'message' => 'بڕی قست ژ قەرزی کریاری مەزنترە']); exit(); }

        $committed = pos_customer_installment_committed_remaining($conn, $customerId);
        $available = pos_installment_money_iqd(max(0, $balance - $committed));
        if ($amount > $available + 0.0001) {
            echo json_encode(['status' => 'error', 'message' => 'بڕی قست ژ قەرزی بەردەست مەزنترە (پلانێن چالاک: ' . number_format($committed) . ')'], JSON_UNESCAPED_UNICODE);
            exit();
        }

        $monthlyAmounts = pos_split_installment_practical_iqd($amount, $months);
        if (count($monthlyAmounts) !== $months) {
            echo json_encode(['status' => 'error', 'message' => 'هەڵە د دابەشکردنا قستێ دا']); exit();
        }
        $monthlyAmount = pos_installment_schedule_amount_iqd($monthlyAmounts[1] ?? $monthlyAmounts[0] ?? 0);

        $conn->begin_transaction();
        try {
            $stmtP = $conn->prepare("INSERT INTO customer_installment_plans (customer_id, total_amount, months, monthly_amount, start_date, status, note, created_by) VALUES (?, ?, ?, ?, ?, 'active', ?, ?)");
            $stmtP->bind_param('ididsss', $customerId, $amount, $months, $monthlyAmount, $startDate, $note, $createdBy);
            $stmtP->execute();
            $planId = (int)$stmtP->insert_id;

            $stmtI = $conn->prepare("INSERT INTO customer_installment_items (plan_id, installment_no, due_date, amount, paid_amount, status) VALUES (?, ?, ?, ?, 0, 'pending')");
            $items = [];
            for ($i = 0; $i < $months; $i++) {
                $no = $i + 1;
                $itemAmount = pos_installment_schedule_amount_iqd($monthlyAmounts[$i] ?? 0);
                $dueDate = date('Y-m-d', strtotime($startDate . ' +' . $i . ' month'));
                $stmtI->bind_param('iisd', $planId, $no, $dueDate, $itemAmount);
                $stmtI->execute();
                $items[] = [
                    'id' => (int)$conn->insert_id,
                    'plan_id' => $planId,
                    'installment_no' => $no,
                    'due_date' => $dueDate,
                    'amount' => $itemAmount,
                    'paid_amount' => 0,
                    'status' => 'pending'
                ];
            }
            $conn->commit();
            echo json_encode([
                'status' => 'success',
                'plan' => [
                    'id' => $planId,
                    'customer_id' => $customerId,
                    'total_amount' => $amount,
                    'months' => $months,
                    'monthly_amount' => $monthlyAmount,
                    'start_date' => $startDate,
                    'status' => 'active',
                    'note' => $note,
                    'created_by' => $createdBy
                ],
                'items' => $items
            ], JSON_UNESCAPED_UNICODE);
            exit();
        } catch (Throwable $e) {
            $conn->rollback();
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
            exit();
        }
    }

    if ($act == 'get_customer_installments') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        if (!pos_installments_pro_enabled($conn)) {
            pos_installments_pro_required_json($conn);
        }

        $customerId = (int)($_GET['customer_id'] ?? $_POST['customer_id'] ?? 0);
        if ($customerId <= 0) { echo json_encode(['status' => 'error', 'message' => 'customer_id required']); exit(); }

        pos_normalize_installment_whole_iqd_in_db($conn);
        pos_update_installment_overdue_status($conn);
        $plan = null;
        $items = [];
        $stmtP = $conn->prepare("SELECT * FROM customer_installment_plans WHERE customer_id = ? AND status = 'active' ORDER BY id DESC LIMIT 1");
        $stmtP->bind_param('i', $customerId);
        $stmtP->execute();
        $planRes = $stmtP->get_result();
        if ($planRes && ($pr = $planRes->fetch_assoc())) {
            $pr['id'] = (int)$pr['id'];
            $pr['customer_id'] = (int)$pr['customer_id'];
            $pr['total_amount'] = pos_installment_money_iqd($pr['total_amount'] ?? 0);
            $pr['monthly_amount'] = pos_installment_schedule_amount_iqd($pr['monthly_amount'] ?? 0);
            $pr['months'] = (int)($pr['months'] ?? 0);
            $plan = $pr;
            $planId = (int)$pr['id'];
            $stmtI = $conn->prepare("SELECT * FROM customer_installment_items WHERE plan_id = ? ORDER BY installment_no ASC");
            $stmtI->bind_param('i', $planId);
            $stmtI->execute();
            $itemsRes = $stmtI->get_result();
            if ($itemsRes) {
                while ($ir = $itemsRes->fetch_assoc()) {
                    $ir['id'] = (int)$ir['id'];
                    $ir['plan_id'] = (int)$ir['plan_id'];
                    $ir['installment_no'] = (int)($ir['installment_no'] ?? 0);
                    $ir['amount'] = pos_installment_schedule_amount_iqd($ir['amount'] ?? 0);
                    $ir['paid_amount'] = pos_installment_money_iqd($ir['paid_amount'] ?? 0);
                    $items[] = $ir;
                }
            }
        }

        $summary = ['paid' => 0, 'pending' => 0, 'overdue' => 0, 'partial' => 0, 'total_paid' => 0, 'total_remaining' => 0];
        foreach ($items as $it) {
            $st = (string)($it['status'] ?? 'pending');
            if (isset($summary[$st])) $summary[$st]++;
            $summary['total_paid'] = roundMoney($summary['total_paid'] + roundMoney($it['paid_amount'] ?? 0));
            $summary['total_remaining'] = roundMoney($summary['total_remaining'] + roundMoney(($it['amount'] ?? 0) - ($it['paid_amount'] ?? 0)));
        }

        echo json_encode(['status' => 'success', 'plan' => $plan, 'items' => $items, 'summary' => $summary], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if ($act == 'cancel_installment_plan') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        if (!pos_installments_pro_enabled($conn)) {
            pos_installments_pro_required_json($conn);
        }

        $planId = (int)($_POST['plan_id'] ?? 0);
        if ($planId <= 0) { echo json_encode(['status' => 'error', 'message' => 'plan_id required']); exit(); }

        $stmtP = $conn->prepare("SELECT id, status FROM customer_installment_plans WHERE id = ? LIMIT 1");
        $stmtP->bind_param('i', $planId);
        $stmtP->execute();
        $planRes = $stmtP->get_result();
        if (!$planRes || !($plan = $planRes->fetch_assoc())) {
            echo json_encode(['status' => 'error', 'message' => 'پلان نەهاتە دیتن']); exit();
        }
        if (($plan['status'] ?? '') !== 'active') {
            echo json_encode(['status' => 'error', 'message' => 'پلان چالاک نییە']); exit();
        }

        $conn->query("UPDATE customer_installment_plans SET status = 'cancelled' WHERE id = $planId");
        echo json_encode(['status' => 'success']); exit();
    }

    if ($act == 'get_customer_ledger') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        
        $customer_id = (int)($_GET['customer_id'] ?? 0);
        $customer_type = $_GET['customer_type'] ?? 'customer';
        
        $entries = [];
        $stmt = $conn->prepare("SELECT * FROM customer_ledger WHERE target_id = ? AND target_type = ? ORDER BY id DESC");
        if ($stmt) {
            $stmt->bind_param('is', $customer_id, $customer_type);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($res) {
                while ($r = $res->fetch_assoc()) {
                    $r['id'] = (int)$r['id'];
                    $r['target_id'] = (int)$r['target_id'];
                    $r['amount'] = roundMoney($r['amount'] ?? 0);
                    $r['invoice_remaining'] = null;
                    $r['sale_id'] = null;
                    if (($r['type'] ?? '') === 'sale') {
                        $saleId = (int)($r['receipt_id'] ?? 0);
                        if ($saleId <= 0 && !empty($r['transaction_id'])) {
                            $stFind = $conn->prepare("SELECT id, remaining_debt FROM sales WHERE transaction_id = ? AND customer_id = ? LIMIT 1");
                            if ($stFind) {
                                $tx = (string)$r['transaction_id'];
                                $stFind->bind_param('si', $tx, $customer_id);
                                $stFind->execute();
                                $sf = $stFind->get_result()->fetch_assoc();
                                if ($sf) {
                                    $saleId = (int)$sf['id'];
                                    $r['invoice_remaining'] = roundMoney((float)($sf['remaining_debt'] ?? 0));
                                }
                            }
                        } elseif ($saleId > 0) {
                            $stFind = $conn->prepare("SELECT remaining_debt FROM sales WHERE id = ? LIMIT 1");
                            if ($stFind) {
                                $stFind->bind_param('i', $saleId);
                                $stFind->execute();
                                $sf = $stFind->get_result()->fetch_assoc();
                                if ($sf) {
                                    $r['invoice_remaining'] = roundMoney((float)($sf['remaining_debt'] ?? 0));
                                }
                            }
                        }
                        if ($saleId > 0) {
                            $r['sale_id'] = $saleId;
                        }
                    }
                    $entries[] = $r;
                }
            }
        }
        
        $jsonFlags = JSON_UNESCAPED_UNICODE;
        if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
            $jsonFlags |= JSON_INVALID_UTF8_SUBSTITUTE;
        }
        $json = json_encode(['status' => 'success', 'entries' => $entries], $jsonFlags);
        if (ob_get_length()) ob_clean();
        if ($json === false) {
            echo json_encode(['status' => 'error', 'message' => json_last_error_msg()]);
        } else {
            echo $json;
        }
        exit();
    }

    if($act == 'save_settings') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();

        header('Content-Type: application/json; charset=utf-8');
        $settingsJson = $_POST['settings'] ?? '';
        $decodedNew = json_decode($settingsJson, true);
        if (!is_array($decodedNew)) {
            echo json_encode(["status"=>"error", "message"=>"تەنزامەکا ڕێکخستنان نادروستە (Invalid settings JSON)."]); exit();
        }
        unset($decodedNew['geminiApiKey'], $decodedNew['geminiModel']);
        $oldSettings = [];
        $sres = $conn->query("SELECT setting_value FROM settings WHERE setting_key = 'app_settings' LIMIT 1");
        if ($sres && $srow = $sres->fetch_assoc()) {
            $oldDec = json_decode($srow['setting_value'], true);
            if (is_array($oldDec)) $oldSettings = $oldDec;
        }
        if (!function_exists('pos_session_can_set_exchange_rate') || !pos_session_can_set_exchange_rate()) {
            if (isset($oldSettings['usdRate'])) {
                $decodedNew['usdRate'] = $oldSettings['usdRate'];
            }
            if (isset($oldSettings['exchange_rate'])) {
                $decodedNew['exchange_rate'] = $oldSettings['exchange_rate'];
            }
        }
        $catalogLocked = function_exists('pos_shop_currency_locked_by_catalog') && pos_shop_currency_locked_by_catalog($conn);
        if ($catalogLocked) {
            $oldMode = function_exists('pos_settings_currency_mode_from_array')
                ? pos_settings_currency_mode_from_array($oldSettings)
                : 'IQD';
            if (function_exists('pos_apply_default_currency_to_settings_array')) {
                pos_apply_default_currency_to_settings_array($decodedNew, $oldMode);
            } else {
                $decodedNew['currencyMode'] = $oldMode;
                $decodedNew['defaultCurrency'] = $oldMode;
                $decodedNew['default_currency'] = $oldMode;
            }
            $decodedNew['currencyBaseLocked'] = true;
        } else {
            $postedDefault = $decodedNew['currencyMode'] ?? $decodedNew['defaultCurrency'] ?? $decodedNew['default_currency'] ?? null;
            if (function_exists('pos_apply_default_currency_to_settings_array')) {
                pos_apply_default_currency_to_settings_array($decodedNew, $postedDefault);
            } else {
                $mode = strtoupper(trim((string)($postedDefault ?: 'IQD')));
                $decodedNew['currencyMode'] = ($mode === 'USD') ? 'USD' : 'IQD';
                $decodedNew['defaultCurrency'] = $decodedNew['currencyMode'];
                $decodedNew['default_currency'] = $decodedNew['currencyMode'];
            }
            $decodedNew['currencyBaseLocked'] = false;
        }
        $oldRateRounded = isset($oldSettings['usdRate']) ? (int)round((float)$oldSettings['usdRate']) : 0;
        $newRateRounded = isset($decodedNew['usdRate']) ? (int)round((float)$decodedNew['usdRate']) : 0;
        if ($newRateRounded < 10000) {
            $newRateRounded = ($oldRateRounded >= 10000) ? $oldRateRounded : 150000;
        }
        $decodedNew['usdRate'] = $newRateRounded;
        if (function_exists('pos_persist_default_currency_row')) {
            pos_persist_default_currency_row($conn, $decodedNew['defaultCurrency'] ?? 'IQD');
        }
        if (function_exists('pos_apply_exchange_rate_to_settings_array')) {
            pos_apply_exchange_rate_to_settings_array($decodedNew);
        }
        if (function_exists('pos_persist_exchange_rate_row')) {
            pos_persist_exchange_rate_row($conn, $decodedNew['exchange_rate'] ?? ($newRateRounded / 100.0));
        }
        $settingsJson = json_encode($decodedNew, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
        if ($settingsJson === false) {
            echo json_encode(["status"=>"error", "message"=>"تەنزامەکا ڕێکخستنان نادروستە (Invalid settings JSON)."]); exit();
        }
        $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('app_settings', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        $stmt->bind_param("ss", $settingsJson, $settingsJson);
        if($stmt->execute()) {
            if (isset($_POST['pos_license_force_unlocked_local'])) {
                $val = ($_POST['pos_license_force_unlocked_local'] === '1') ? '1' : '0';
                pos_db_set_setting_value($conn, 'pos_license_force_unlocked_local', $val);
            }
            logAction($conn, 'System', 'settings_change', 'System settings updated');
            $warehousesCollapsed = false;
            if (empty($decodedNew['enableMultiWarehouse'])
                && function_exists('pos_collapse_extra_warehouse_stock_into_default')) {
                $warehousesCollapsed = pos_collapse_extra_warehouse_stock_into_default($conn);
            }
            if ($newRateRounded >= 10000 && $newRateRounded !== $oldRateRounded) {
                pos_exchange_rate_history_append(
                    $conn,
                    $newRateRounded,
                    isset($_SESSION['user_name']) ? (string)$_SESSION['user_name'] : 'System',
                    'save_settings'
                );
            }
            // FX updates settings only. Catalog base_price / base_currency are never rewritten here.
            touchLastUpdate($conn);
            echo json_encode(["status"=>"success", "warehouses_collapsed"=>$warehousesCollapsed]); exit();
        } else {
            $errMsg = $stmt->error ?: 'نەشیا بپارێزیت (DB error).';
            echo json_encode(["status"=>"error", "message"=>$errMsg]); exit();
        }
    }

    if($act == 'log_client_event') {
        $type = $_POST['type'] ?? '';
        $details = $_POST['details'] ?? '';
        $user = $_POST['user'] ?? 'Unknown';
        $uid = (int)($_POST['user_id'] ?? 0);
        if (!$uid && isset($_SESSION['user_id'])) $uid = (int)$_SESSION['user_id'];
        logAction($conn, $user, $type, $details, $uid);
        echo json_encode(["status"=>"success"]); exit();
    }
