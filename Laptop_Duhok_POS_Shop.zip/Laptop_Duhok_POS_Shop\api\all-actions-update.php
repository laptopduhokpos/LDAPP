<?php
/**
 * OTA self-update: check / download / apply POS package (no AnyDesk).
 * Check works on login screen (no session). Download/apply: admin session OR admin PIN.
 */

/** @return array{ok:bool,user?:array,message?:string} */
if (!function_exists('pos_ota_authorize_admin')) {
function pos_ota_authorize_admin($conn): array {
    if (function_exists('pos_session_is_admin') && pos_session_is_admin()) {
        return ['ok' => true];
    }
    $pin = trim((string)($_POST['admin_pin'] ?? $_POST['pin'] ?? ''));
    $uid = (int)($_POST['user_id'] ?? $_POST['userId'] ?? 0);
    if ($pin === '') {
        return ['ok' => false, 'message' => 'PINـی ئەدمین بنووسە بۆ دانانی ئابدەیت', 'need_pin' => true];
    }
    if ($uid > 0) {
        $stmt = $conn->prepare('SELECT id, name, role FROM users WHERE id = ? AND pin = ? LIMIT 1');
        if ($stmt) $stmt->bind_param('is', $uid, $pin);
    } else {
        $stmt = $conn->prepare('SELECT id, name, role FROM users WHERE pin = ? LIMIT 1');
        if ($stmt) $stmt->bind_param('s', $pin);
    }
    if (!$stmt) {
        return ['ok' => false, 'message' => 'هەڵەی داتابەیس'];
    }
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res ? $res->fetch_assoc() : null;
    $stmt->close();
    if (!$row) {
        return ['ok' => false, 'message' => 'PIN هەڵەیە', 'need_pin' => true];
    }
    $role = strtolower(trim((string)($row['role'] ?? '')));
    if ($role !== 'admin') {
        return ['ok' => false, 'message' => 'تەنها ئەدمین دەتوانێت ئابدەیت دابنێت', 'need_pin' => true];
    }
    return ['ok' => true, 'user' => $row];
}
}

/** Extract ZIP to $destDir. Uses ZipArchive, else Windows tar/PowerShell. */
if (!function_exists('pos_ota_extract_zip')) {
function pos_ota_extract_zip(string $zipPath, string $destDir): array {
    if (!is_dir($destDir) && !@mkdir($destDir, 0755, true)) {
        return ['ok' => false, 'message' => 'نەتوانرا فۆڵدەری کاتی دروست بکرێت'];
    }
    if (class_exists('ZipArchive')) {
        $zip = new ZipArchive();
        if ($zip->open($zipPath) !== true) {
            return ['ok' => false, 'message' => 'نەتوانرا ZIP بکرێتەوە'];
        }
        if (!$zip->extractTo($destDir)) {
            @$zip->close();
            return ['ok' => false, 'message' => 'نەتوانرا ZIP دەربهێنرێت'];
        }
        $zip->close();
        return ['ok' => true, 'via' => 'ZipArchive'];
    }

    // Fallback for shops where php_zip is disabled in XAMPP
    $isWin = strtoupper(substr(PHP_OS, 0, 3)) === 'WIN';
    if ($isWin) {
        $tar = 'C:\\Windows\\System32\\tar.exe';
        if (is_file($tar)) {
            $cmd = escapeshellarg($tar) . ' -xf ' . escapeshellarg($zipPath) . ' -C ' . escapeshellarg($destDir);
            $out = [];
            $code = 1;
            @exec($cmd . ' 2>&1', $out, $code);
            if ($code === 0) {
                return ['ok' => true, 'via' => 'tar'];
            }
        }
        $ps = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe';
        if (is_file($ps)) {
            // Avoid nested quoting issues: pass paths via env-like single-quoted PS literals
            $z = str_replace("'", "''", $zipPath);
            $d = str_replace("'", "''", $destDir);
            $script = "Expand-Archive -LiteralPath '" . $z . "' -DestinationPath '" . $d . "' -Force";
            $cmd = escapeshellarg($ps) . ' -NoProfile -NonInteractive -Command ' . escapeshellarg($script);
            $out = [];
            $code = 1;
            @exec($cmd . ' 2>&1', $out, $code);
            if ($code === 0) {
                return ['ok' => true, 'via' => 'powershell'];
            }
        }
    }

    return [
        'ok' => false,
        'message' => 'ZipArchive لە PHP چالاک نییە. لە XAMPP: php.ini → extension=zip (بێ ;) پاشان Apache Restart',
    ];
}
}

/** @return list<string> relative paths with forward slashes */
if (!function_exists('pos_ota_list_files_recursive')) {
function pos_ota_list_files_recursive(string $dir, string $base = ''): array {
    $out = [];
    if (!is_dir($dir)) return $out;
    $items = @scandir($dir);
    if (!is_array($items)) return $out;
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') continue;
        $full = $dir . DIRECTORY_SEPARATOR . $item;
        $rel = $base === '' ? $item : ($base . '/' . $item);
        $rel = str_replace('\\', '/', $rel);
        if (is_dir($full)) {
            $out = array_merge($out, pos_ota_list_files_recursive($full, $rel));
        } elseif (is_file($full)) {
            $out[] = $rel;
        }
    }
    return $out;
}
}

if (!function_exists('pos_ota_rrmdir')) {
function pos_ota_rrmdir(string $dir): void {
    if (!is_dir($dir)) return;
    $items = @scandir($dir);
    if (!is_array($items)) return;
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') continue;
        $full = $dir . DIRECTORY_SEPARATOR . $item;
        if (is_dir($full)) pos_ota_rrmdir($full);
        else @unlink($full);
    }
    @rmdir($dir);
}
}

if ($act == 'check_pos_app_update') {
    // Allowed on login screen (no session) so shops see "new update" before sign-in.
    header('Content-Type: application/json; charset=utf-8');
    $current = defined('POS_APP_VERSION') ? (string)POS_APP_VERSION : '0';
    if (!empty($_GET['current']) || !empty($_POST['current'])) {
        $current = trim((string)($_GET['current'] ?? $_POST['current'] ?? $current));
    }
    $serial = '';
    if (isset($conn) && function_exists('pos_ensure_license_serial')) {
        $serial = trim((string)pos_ensure_license_serial($conn));
    }
    if (!empty($_GET['serial']) || !empty($_POST['serial'])) {
        $reqSerial = trim((string)($_GET['serial'] ?? $_POST['serial']));
        if ($reqSerial !== '') {
            $serial = $reqSerial;
        }
    }
    $remote = function_exists('pos_supabase_fetch_latest_app_release_remote')
        ? pos_supabase_fetch_latest_app_release_remote($current, $serial)
        : ['ok' => false, 'reason' => 'missing_fn', 'has_update' => false];

    if (empty($remote['ok'])) {
        echo json_encode([
            'status' => 'success',
            'has_update' => false,
            'current' => $current,
            'serial' => $serial,
            'remote_ok' => false,
            'reason' => $remote['reason'] ?? 'error',
            'message' => 'نەتوانرا پشکنینی نوێکردنەوە بکرێت (ئینتەرنێت / Supabase)',
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $latest = isset($remote['latest']) && is_array($remote['latest']) ? $remote['latest'] : null;
    echo json_encode([
        'status' => 'success',
        'has_update' => !empty($remote['has_update']),
        'current' => $current,
        'serial' => $serial,
        'remote_ok' => true,
        'latest' => $latest,
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

if ($act == 'download_pos_app_update') {
    header('Content-Type: application/json; charset=utf-8');
    $auth = pos_ota_authorize_admin($conn);
    if (empty($auth['ok'])) {
        echo json_encode([
            'status' => 'error',
            'need_pin' => !empty($auth['need_pin']),
            'message' => $auth['message'] ?? 'ڕێگەپێدان نییە',
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    ini_set('memory_limit', '1024M');
    ini_set('max_execution_time', '600');

    $url = trim((string)($_POST['package_url'] ?? ''));
    $version = trim((string)($_POST['version'] ?? ''));
    $shaExpected = strtolower(trim((string)($_POST['sha256'] ?? '')));
    if ($url === '' || !preg_match('#^https?://#i', $url)) {
        echo json_encode(['status' => 'error', 'message' => 'لینکی داونلۆد نادروستە (پێویستە http/https بێت)'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    if ($version === '') {
        $version = 'update';
    }
    $safeVer = preg_replace('/[^a-zA-Z0-9._-]/', '_', $version);
    $dir = realpath(__DIR__ . '/../backups');
    if (!$dir) {
        $dir = __DIR__ . '/../backups';
        @mkdir($dir, 0755, true);
    }
    $updDir = rtrim($dir, '/\\') . DIRECTORY_SEPARATOR . 'updates';
    if (!is_dir($updDir)) {
        @mkdir($updDir, 0755, true);
    }
    $dest = $updDir . DIRECTORY_SEPARATOR . 'POS_Update_' . $safeVer . '.zip';

    $bin = false;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_CONNECTTIMEOUT => 20,
            CURLOPT_TIMEOUT => 300,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_USERAGENT => 'LaptopDuhokPOS-Updater/1.0',
        ]);
        $bin = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);
        if ($bin === false || $code < 200 || $code >= 400) {
            // Retry without strict SSL (common on XAMPP Windows)
            $ch2 = curl_init($url);
            curl_setopt_array($ch2, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS => 5,
                CURLOPT_CONNECTTIMEOUT => 20,
                CURLOPT_TIMEOUT => 300,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => 0,
                CURLOPT_USERAGENT => 'LaptopDuhokPOS-Updater/1.0',
            ]);
            $bin = curl_exec($ch2);
            $code = (int)curl_getinfo($ch2, CURLINFO_HTTP_CODE);
            $err = curl_error($ch2);
            curl_close($ch2);
            if ($bin === false || $code < 200 || $code >= 400) {
                echo json_encode([
                    'status' => 'error',
                    'message' => 'داونلۆد سەرنەکەوت (HTTP ' . $code . ')' . ($err ? (': ' . $err) : ''),
                ], JSON_UNESCAPED_UNICODE);
                exit();
            }
        }
    } else {
        $bin = @file_get_contents($url);
        if ($bin === false) {
            echo json_encode(['status' => 'error', 'message' => 'داونلۆد سەرنەکەوت (file_get_contents)'], JSON_UNESCAPED_UNICODE);
            exit();
        }
    }

    if (!is_string($bin) || strlen($bin) < 64) {
        echo json_encode(['status' => 'error', 'message' => 'فایلی نوێکردنەوە بەتاڵ یان زۆر بچووکە'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    // Must look like a ZIP
    if (substr($bin, 0, 2) !== 'PK') {
        echo json_encode(['status' => 'error', 'message' => 'فایل ZIP نییە — لینکی ڕاستەوخۆی داونلۆد بەکاربهێنە (نە پەڕەی Google Drive)'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    if ($shaExpected !== '') {
        $got = hash('sha256', $bin);
        if (!hash_equals($shaExpected, $got)) {
            echo json_encode(['status' => 'error', 'message' => 'SHA256 ناگونجێت — فایل گومانلێکراوە'], JSON_UNESCAPED_UNICODE);
            exit();
        }
    }
    if (@file_put_contents($dest, $bin) === false) {
        echo json_encode(['status' => 'error', 'message' => 'نەتوانرا فایل لە backups/updates پاشەکەوت بکرێت'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    echo json_encode([
        'status' => 'success',
        'path' => 'backups/updates/' . basename($dest),
        'bytes' => strlen($bin),
        'version' => $version,
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

if ($act == 'apply_pos_app_update') {
    header('Content-Type: application/json; charset=utf-8');
    $auth = pos_ota_authorize_admin($conn);
    if (empty($auth['ok'])) {
        echo json_encode([
            'status' => 'error',
            'need_pin' => !empty($auth['need_pin']),
            'message' => $auth['message'] ?? 'ڕێگەپێدان نییە',
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    ini_set('memory_limit', '1024M');
    ini_set('max_execution_time', '600');

    $rel = trim((string)($_POST['zip_name'] ?? $_POST['path'] ?? ''));
    $rel = str_replace(['\\', '..'], ['/', ''], $rel);
    $rel = ltrim($rel, '/');
    if ($rel === '' || !preg_match('#^backups/updates/[A-Za-z0-9._-]+\.zip$#', $rel)) {
        // also allow bare filename
        $base = basename($rel);
        if (!preg_match('/^POS_Update_[A-Za-z0-9._-]+\.zip$/', $base) && !preg_match('/^[A-Za-z0-9._-]+\.zip$/', $base)) {
            echo json_encode(['status' => 'error', 'message' => 'ناوی فایلی ZIP نادروستە'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $rel = 'backups/updates/' . $base;
    }
    $root = realpath(__DIR__ . '/..');
    if (!$root) {
        echo json_encode(['status' => 'error', 'message' => 'ڕێگای POS نەدۆزرایەوە'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $zipPath = $root . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $rel);
    $realZip = realpath($zipPath);
    $updDir = realpath($root . DIRECTORY_SEPARATOR . 'backups' . DIRECTORY_SEPARATOR . 'updates');
    if (!$realZip || !$updDir || strpos($realZip, $updDir) !== 0 || !is_file($realZip)) {
        echo json_encode(['status' => 'error', 'message' => 'فایلی ZIP لە backups/updates نەدۆزرایەوە — سەرەتا داونلۆد بکە'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $extractDir = $updDir . DIRECTORY_SEPARATOR . '_extract_' . preg_replace('/[^A-Za-z0-9._-]/', '_', basename($realZip, '.zip')) . '_' . time();
    $extracted = pos_ota_extract_zip($realZip, $extractDir);
    if (empty($extracted['ok'])) {
        pos_ota_rrmdir($extractDir);
        echo json_encode(['status' => 'error', 'message' => $extracted['message'] ?? 'ZIP extract failed'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $skipExact = [
        'config/database.local.php' => true,
        'config/supabase.local.php' => true,
        '.env' => true,
        '.env.local' => true,
    ];
    $skipPrefix = [
        '_PRIVATE/',
        'backups/',
        'logs/',
        '.git/',
        'node_modules/',
    ];

    $names = pos_ota_list_files_recursive($extractDir);
    // Detect optional single root folder (Laptop_Duhok_POS_Shop/...)
    $prefix = '';
    if ($names) {
        $first = $names[0];
        $slash = strpos($first, '/');
        if ($slash !== false) {
            $cand = substr($first, 0, $slash + 1);
            $all = true;
            foreach ($names as $n) {
                if (strpos($n, $cand) !== 0) {
                    $all = false;
                    break;
                }
            }
            if ($all && !preg_match('#^(api|public|views|config|assets)/#', $cand)) {
                $prefix = $cand;
            }
        }
    }

    // Sort files so supporting files (config, api, public, views) are written first, and entry points (index.php) last.
    // This ensures that if power cuts or process is killed during copy, entry point only switches after dependencies exist.
    usort($names, function($a, $b) {
        $aBase = strtolower(basename($a));
        $bBase = strtolower(basename($b));
        $aIsEntry = ($aBase === 'index.php' || $aBase === 'laptopduhok-pos.php');
        $bIsEntry = ($bBase === 'index.php' || $bBase === 'laptopduhok-pos.php');
        if ($aIsEntry && !$bIsEntry) return 1;
        if (!$aIsEntry && $bIsEntry) return -1;
        return strcmp($a, $b);
    });

    $written = 0;
    $skipped = 0;
    try {
        foreach ($names as $name) {
            $relPath = $prefix !== '' ? substr($name, strlen($prefix)) : $name;
            $relPath = ltrim(str_replace('\\', '/', $relPath), '/');
            if ($relPath === '' || strpos($relPath, '..') !== false) {
                $skipped++;
                continue;
            }
            if (isset($skipExact[$relPath])) {
                $skipped++;
                continue;
            }
            $skip = false;
            foreach ($skipPrefix as $sp) {
                if (strpos($relPath, $sp) === 0) {
                    $skip = true;
                    break;
                }
            }
            if ($skip) {
                $skipped++;
                continue;
            }
            $src = $extractDir . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $name);
            $dest = $root . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relPath);
            $destDirName = dirname($dest);
            if (!is_dir($destDirName)) {
                @mkdir($destDirName, 0755, true);
            }
            if (!is_file($src) || !@copy($src, $dest)) {
                throw new Exception('نەتوانرا بنووسرێت: ' . $relPath);
            }
            $written++;
        }
    } catch (\Throwable $e) {
        pos_ota_rrmdir($extractDir);
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
        exit();
    }
    pos_ota_rrmdir($extractDir);

    if (function_exists('opcache_reset')) {
        @opcache_reset();
    }
    clearstatcache(true);

    if (function_exists('logAction')) {
        logAction($conn, 'System', 'apply_pos_app_update', 'Applied OTA update files=' . $written . ' skip=' . $skipped . ' via=' . ($extracted['via'] ?? '?'));
    }
    echo json_encode([
        'status' => 'success',
        'written' => $written,
        'skipped' => $skipped,
        'extract_via' => $extracted['via'] ?? null,
        'message' => 'نوێکردنەوە جێبەجێ کرا — Ctrl+F5 بکە',
        'reload' => true,
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['action']) && $_GET['action'] === 'check_admin_pin') {
    header('Content-Type: application/json; charset=utf-8');
    $auth = pos_ota_authorize_admin($conn);
    if ($auth['ok']) {
        echo json_encode(['status' => 'success', 'user' => $auth['user'] ?? null]);
    } else {
        http_response_code(403);
        echo json_encode(['status' => 'error', 'message' => $auth['message'] ?? 'PIN نادروستە']);
    }
    exit();
}
