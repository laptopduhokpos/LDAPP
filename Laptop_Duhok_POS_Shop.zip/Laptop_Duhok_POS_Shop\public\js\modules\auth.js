/**
 * Auth, roles, and permissions. Uses state.currentUser and state.db.
 */
import { state } from './state.js';

export const MASTER_PIN = '';
export const MASTER_PASSWORD = '';

export async function hashPIN(pin) {
    const encoder = new TextEncoder();
    const data = encoder.encode(pin);
    const hash = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('');
}

/** Every assignable permission (admin bypasses checks in code). */
export const ALL_STAFF_PERMISSIONS = [
    'view_profit', 'view_cost', 'view_expenses',
    'pos_access', 'warehouse_view', 'products_manage', 'companies_manage', 'debt_view',
    'expenses_manage', 'waste_manage', 'recipes_manage', 'delivery_view', 'reports_view',
    'view_daily_summary', 'send_telegram_report', 'view_sales_history', 'view_purchase_history',
    'returns_manage', 'edit_staff', 'access_settings', 'manage_printers', 'view_audit_logs',
    'pos_sell', 'pos_discount', 'pos_price', 'pos_delete_item', 'pos_void_invoice',
    'pos_open_drawer', 'pos_kitchen',
    'multi_warehouse', 'stock_view', 'stock_edit', 'stock_delete', 'stock_audit',
    'debt_manage', 'manage_debts', 'set_exchange_rate',
];

/** Old/wrong checkbox keys that must still match the real permission. */
export const PERM_ALIASES = {
    warehouse_manage: 'warehouse_view',
    purchase_manage: 'companies_manage',
    settings_manage: 'access_settings',
    pos_void_sales: 'pos_void_invoice'
};

function canonicalizePerm(perm) {
    if (!perm) return perm;
    return PERM_ALIASES[perm] || perm;
}

/** Default permissions per role (`admin` = full access in code, null here). */
export const ROLE_TEMPLATES = {
    admin: null,

    /** ڕێڤەبەر — هەموو بەشەکان + ناردنی تیلیگرام */
    manager: ALL_STAFF_PERMISSIONS.slice(),

    /** سەرپەرشتیار — POS + ڕاپۆرت بینین، بێ تیلیگرام/ڕێکخستن */
    supervisor: [
        'view_profit', 'view_cost', 'view_expenses',
        'pos_access', 'debt_view', 'delivery_view', 'reports_view', 'view_daily_summary', 'view_sales_history',
        'returns_manage',
        'pos_sell', 'pos_discount', 'pos_price', 'pos_delete_item', 'pos_void_invoice', 'pos_open_drawer', 'pos_kitchen',
    ],

    /** کارمەند — فرۆشتن و مێز، بێ قازانج/کرین/تیلیگرام/ڕێکخستن */
    cashier: [
        'pos_access', 'debt_view', 'returns_manage', 'view_sales_history',
        'pos_sell', 'pos_discount', 'pos_delete_item', 'pos_open_drawer', 'pos_kitchen',
    ],

    /** ڕێڤەبەری کۆگە — کۆگە + کڕین، بێ تیلیگرام */
    stock_manager: [
        'warehouse_view', 'products_manage', 'companies_manage', 'waste_manage', 'recipes_manage',
        'view_purchase_history', 'view_cost',
        'multi_warehouse', 'stock_view', 'stock_edit', 'stock_delete', 'stock_audit',
    ],

    /** کارمەندی کۆگە — بینین/دەستکاری کۆگە، بێ سڕینەوە/تیلیگرام */
    inventory_clerk: [
        'warehouse_view', 'products_manage', 'waste_manage',
        'stock_view', 'stock_edit', 'stock_audit',
    ],

    /** ژمێریار — دارایی + ڕاپۆرت + ناردنی تیلیگرام */
    accountant: [
        'view_profit', 'view_cost', 'view_expenses', 'expenses_manage',
        'debt_view', 'debt_manage', 'manage_debts', 'set_exchange_rate',
        'reports_view', 'view_daily_summary', 'send_telegram_report',
        'view_sales_history', 'view_purchase_history',
    ],

    /** بینەری دارایی — تەنها بینین، بێ تیلیگرام */
    finance_viewer: [
        'view_profit', 'view_cost', 'view_expenses', 'debt_view',
        'reports_view', 'view_daily_summary', 'view_sales_history', 'view_purchase_history',
    ],

    /** فرۆشیار — POS + گەیاندن + قەرز */
    sales_rep: [
        'pos_access', 'debt_view', 'debt_manage', 'delivery_view', 'returns_manage', 'view_sales_history',
        'pos_sell', 'pos_discount', 'pos_delete_item', 'pos_open_drawer', 'pos_kitchen',
    ],

    /** بینەری فرۆشتن — ڕاپۆرت بینین، بێ POS */
    sales_viewer: [
        'view_profit', 'view_cost', 'view_expenses',
        'reports_view', 'view_daily_summary', 'view_sales_history',
    ],

    /** گارسۆن — مێز + مەدبەخ */
    waiter: [
        'pos_access',
        'pos_sell', 'pos_delete_item', 'pos_kitchen', 'pos_open_drawer',
    ],
};

export function getRoleTemplate(role) {
    if (!role || role === 'admin') return [];
    const p = ROLE_TEMPLATES[role];
    return Array.isArray(p) ? p.slice() : [];
}

/** Map main nav / view keys to a single permission string (admin bypasses in hasPermission). */
export const VIEW_TO_PERM = {
    pos: 'pos_access',
    tables: 'pos_access',
    debt: 'debt_view',
    companies: 'companies_manage',
    purchase: 'companies_manage',
    'purchase-returns': 'companies_manage',
    warehouse: 'warehouse_view',
    products: 'products_manage',
    delivery: 'delivery_view',
    expenses: 'expenses_manage',
    waste: 'waste_manage',
    recipes: 'recipes_manage',
    calendar: 'reports_view',
    notifications: 'pos_access',
    staff: 'edit_staff',
    settings: 'access_settings',
    'print-design': 'manage_printers',
    'print-history': 'view_audit_logs',
    'returns-new': 'returns_manage',
    'shop-ai': 'reports_view',
    'stock-card': 'stock_view'
};

function normalizeUserPermissions(u) {
    if (!u) return [];
    let list = u.permissions;
    if (typeof list === 'string') {
        try { list = JSON.parse(list); } catch (_e) { list = []; }
        u.permissions = Array.isArray(list) ? list : [];
    }
    if (!Array.isArray(u.permissions)) u.permissions = [];
    const seen = {};
    const out = [];
    u.permissions.forEach(function(p) {
        const key = canonicalizePerm(p);
        if (!key || seen[key]) return;
        seen[key] = true;
        out.push(key);
    });
    u.permissions = out;
    return u.permissions;
}

/** Shop FX: Admin / Manager only. Cashiers cannot change the exchange rate. */
export function canEditExchangeRate() {
    const u = state.currentUser;
    if (!u) return false;
    const role = String(u.role || '').toLowerCase();
    return role === 'admin' || role === 'manager';
}

export function hasPermission(perm) {
    if (!perm) return false;
    const u = state.currentUser;
    if (!u) return false;
    if (u.role === 'admin') return true;
    const list = normalizeUserPermissions(u);
    const want = canonicalizePerm(perm);
    return list.indexOf(want) >= 0;
}

/** Single source of truth for "can the current user see profit (ربح/قازانج) anywhere"
 *  (dashboard cards, calendar cells, daily history modal, reports,
 *   warehouse expected profit, printouts, telegram digests, ...).
 *  Admin always allowed; everyone else needs the explicit `view_profit` permission. */
export function canViewProfit() {
    const u = state.currentUser;
    if (!u) return false;
    if (u.role === 'admin') return true;
    return hasPermission('view_profit');
}

/** Cost / کرین on POS cards (and related). Admin always; else needs `view_cost`
 *  (or legacy `view_profit` so existing managers keep seeing cost). Cashiers have neither. */
export function canViewCost() {
    const u = state.currentUser;
    if (!u) return false;
    if (u.role === 'admin') return true;
    return hasPermission('view_cost') || hasPermission('view_profit');
}

/** Invoice profit tips (sales + purchase history orange coins). Same as view_profit —
 *  cashiers / staff without the permission never see the icon. */
export function canViewInvoiceProfit() {
    return canViewProfit();
}

export function canViewExpenses() {
    const u = state.currentUser;
    if (!u) return false;
    if (u.role === 'admin') return true;
    return hasPermission('view_expenses');
}

export function applyRoleTemplate(role, scope) {
    let selector = '.perm-chk, .edit-perm-chk';
    if (scope === 'edit') selector = '.edit-perm-chk';
    else if (scope === 'new') selector = '.perm-chk';

    if (role === 'admin') {
        document.querySelectorAll(selector).forEach(cb => { cb.checked = false; });
        return;
    }

    const perms = ROLE_TEMPLATES[role];
    const allowed = Array.isArray(perms) ? perms : [];
    document.querySelectorAll(selector).forEach(cb => {
        cb.checked = allowed.indexOf(canonicalizePerm(cb.value)) >= 0;
    });
}

export function canonicalizePermissionList(list) {
    if (!Array.isArray(list)) return [];
    const seen = {};
    const out = [];
    list.forEach(function(p) {
        const key = canonicalizePerm(p);
        if (!key || seen[key]) return;
        seen[key] = true;
        out.push(key);
    });
    return out;
}

export function applyUserPermissions() {
    const currentUser = state.currentUser;
    const db = state.db;
    if (!currentUser) return;
    const isAdmin = currentUser.role === 'admin';
    const isWaiter = currentUser.role === 'waiter';
    document.body.classList.toggle('is-admin', isAdmin);
    document.body.classList.toggle('is-waiter', isWaiter);
    document.body.classList.toggle('can-pos-price', isAdmin || hasPermission('pos_price'));
    document.body.classList.toggle('no-pos-price', !(isAdmin || hasPermission('pos_price')));

    const toggle = (id, perm) => {
        const el = document.getElementById(id);
        if (el) el.style.display = (isAdmin || hasPermission(perm)) ? 'flex' : 'none';
    };
    const rateWrap = document.getElementById('basket-usd-visual-rate');
    if (rateWrap && typeof updateUSDBadge === 'function') {
        try { updateUSDBadge(); } catch (_eRate) {}
    }
    toggle('nav-products', 'products_manage');
    toggle('nav-companies', 'companies_manage');
    toggle('nav-purchase', 'companies_manage');
    toggle('nav-purchase-returns', 'companies_manage');
    toggle('nav-warehouse', 'warehouse_view');
    toggle('nav-expenses', 'expenses_manage');
    toggle('nav-calendar', 'reports_view');
    toggle('nav-staff', 'edit_staff');
    toggle('nav-settings', 'access_settings');
    toggle('nav-print-design', 'manage_printers');
    toggle('nav-returns-new', 'returns_manage');
    if (db && db.settings && db.settings.enableDebt) toggle('nav-debt', 'debt_view');
    if (db && db.settings && db.settings.enableWaste) toggle('nav-waste', 'waste_manage');
    if (typeof isRecipeFeatureEnabled === 'function' ? isRecipeFeatureEnabled() : (db && db.settings && db.settings.enableRecipe)) toggle('nav-recipes', 'recipes_manage');

    const dashSalesCard = document.getElementById('dash-sales-card');
    if (dashSalesCard) dashSalesCard.style.display = (isAdmin || hasPermission('reports_view') || hasPermission('pos_access')) ? '' : 'none';
    const stExp = document.getElementById('st-exp');
    if (stExp && stExp.closest('.stat-card')) stExp.closest('.stat-card').style.display = (isAdmin || hasPermission('view_expenses')) ? '' : 'none';
    const stProfit = document.getElementById('st-profit');
    if (stProfit && stProfit.closest('.stat-card')) stProfit.closest('.stat-card').style.display = (isAdmin || hasPermission('view_profit')) ? '' : 'none';
    const dashCountCard = document.getElementById('dash-count-card');
    if (dashCountCard) dashCountCard.style.display = (isAdmin || hasPermission('pos_access') || hasPermission('reports_view')) ? '' : 'none';
    // Financial Position card includes Net Worth (Assets - Liabilities) which is profit-adjacent.
    // Treat it strictly as profit data: only show when the user explicitly has `view_profit`.
    const dashFp = document.getElementById('dash-financial-position');
    if (dashFp) dashFp.style.display = (isAdmin || hasPermission('view_profit')) ? '' : 'none';

    // Warehouse "expected profit" KPI card — collapse the whole stat tile when the user
    // can't view profit, so cashiers/stock clerks don't see margin numbers.
    const whProfitEl = document.getElementById('wh-total-profit');
    if (whProfitEl && whProfitEl.closest('.stat-card')) {
        whProfitEl.closest('.stat-card').style.display = canViewProfit() ? '' : 'none';
    }

    // Generic data-perm hook (used by many UI fragments).
    document.querySelectorAll('[data-perm]').forEach(el => {
        const perm = el.getAttribute('data-perm');
        el.style.display = (isAdmin || hasPermission(perm)) ? '' : 'none';
    });

    // Generic profit-only hook: any element marked with data-needs="profit" is hidden
    // automatically when the user lacks `view_profit`. Used to guarantee profit
    // cannot leak through dynamically-rendered HTML (calendar, history modal, prints, etc.).
    const showProfit = canViewProfit();
    document.querySelectorAll('[data-needs="profit"]').forEach(el => {
        el.style.display = showProfit ? '' : 'none';
    });
    document.body.classList.toggle('no-profit', !showProfit);

    if (typeof applyMultiWarehouseVisibility === 'function') applyMultiWarehouseVisibility();
    if (typeof window.shopAiUpdateFabVisibility === 'function') window.shopAiUpdateFabVisibility();
}

export function checkPermission(permCode, actionName) {
    if (hasPermission(permCode)) return true;
    if (actionName) {
        const base = typeof window.t === 'function' ? (window.t('toast_perm_denied') || '') : '';
        alert(base
            ? (base + '\n\n«' + actionName + '»')
            : ('⛔ مۆڵەت نینە!\n\nتۆ ڕێگەپێدان بۆ «' + actionName + '» نینیت.\n(Ji kerema xwe serokê xwe agahdar bike)'));
    }
    return false;
}
