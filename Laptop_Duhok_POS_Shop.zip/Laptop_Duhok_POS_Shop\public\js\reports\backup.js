// POS reports - flash/USB backup
        // --- UPDATED BACKUP FUNCTIONS (AVAILABLE FOR CASHIER TOO) ---
        async function posFlushBeforeBackup() {
            try {
                if (typeof flushCartSaveNow === 'function') {
                    await flushCartSaveNow();
                } else {
                    if (typeof activeTableId !== 'undefined' && activeTableId && typeof scheduleSave === 'function') scheduleSave();
                    if (typeof cartSaveQueue !== 'undefined' && cartSaveQueue.length > 0 && typeof processCartSaveQueue === 'function') processCartSaveQueue();
                    await new Promise(function (resolve) { setTimeout(resolve, 500); });
                }
                if (typeof saveSettingsPromise === 'function') await saveSettingsPromise();
                if (typeof cancelPendingPosTabSnapshot === 'function') cancelPendingPosTabSnapshot();
                if (typeof saveActivePosTabSnapshot === 'function') saveActivePosTabSnapshot();
            } catch (e) {
                console.warn('Sync before backup warning:', e);
            }
        }

        async function posAssertBackupZipResponse(res, blob) {
            if (!blob || blob.size < 32) {
                throw new Error('فایلێ باک‌ئەپێ بچووکە یان بەتاڵە');
            }
            var head = new Uint8Array(await blob.slice(0, 4).arrayBuffer());
            var isZip = head[0] === 0x50 && head[1] === 0x4b;
            var isGzip = head[0] === 0x1f && head[1] === 0x8b;
            var isJson = head[0] === 0x7b || head[0] === 0x5b || head[0] === 0xef;
            var isUtf16 = (head[0] === 0xff && head[1] === 0xfe) || (head[0] === 0xfe && head[1] === 0xff);
            if (isZip || isGzip || isJson || isUtf16) return blob;
            var peek = '';
            try { peek = await blob.slice(0, 400).text(); } catch (_ePeek) { peek = ''; }
            throw new Error(posFlashParseServerError(peek, 'فایلێ بک‌ئەپێ دروست نەبوو'));
        }

        /** Parse server error body into a short shop-facing message (never dump JSON). */
        function posFlashParseServerError(text, fallback) {
            var raw = String(text || '').trim();
            if (!raw) return fallback || 'ناردن سەرنەکەوت';
            if (raw.charAt(0) === '{') {
                try {
                    var j = JSON.parse(raw);
                    if (j && (j._format || j.table_data || j._backup_at || j.magic)) {
                        return 'فایلێ بک‌ئەپێ ل سێرڤەر دروست نەبوو';
                    }
                    if (j && (j.message || j.error)) {
                        var m = String(j.message || j.error);
                        if (m.charAt(0) === '{' || m.indexOf('table_data') !== -1 || m.length > 180) {
                            return 'ناردن سەرنەکەوت';
                        }
                        return m;
                    }
                } catch (_e) {}
                return fallback || 'ناردن سەرنەکەوت';
            }
            if (raw.length > 160) raw = raw.slice(0, 160);
            return raw;
        }

        function posFlashSimpleFailHelp() {
            return 'ناردن بۆ فلاش سەرنەکەوت.\n\n'
                + 'بکە ڤان هەنگاڤان (ساناهی):\n'
                + '١) Chrome یان Edge بکە (نە Firefox)\n'
                + '٢) فلاش دایبەستە\n'
                + '٣) Settings → بەڕێوەبردنی داتابەیس → هەڵبژاردنی فلاش\n'
                + '٤) ڕەگی فلاشێ هەڵبژێرە (E: یان F: — نە فۆڵدەرەکا دی)\n'
                + '٥) پاشان دوگمە «ناردن بۆ فلاش ئێستا»';
        }

        async function posFlashFetchErrorMessage(res) {
            try {
                return posFlashParseServerError(await res.text(), 'HTTP ' + res.status);
            } catch (_e2) {
                return 'HTTP ' + (res && res.status ? res.status : '?');
            }
        }

        // --- Flash / USB backup folder (File System Access API + IndexedDB) ---
        var POS_FLASH_IDB = 'pos_flash_backup_v1';
        var POS_FLASH_STORE = 'handles';
        var POS_FLASH_KEY = 'dir';
        var POS_FLASH_NAME_KEY = 'pos_flash_backup_folder_name';
        var POS_FLASH_AUTO_KEY = 'pos_flash_auto_enabled';
        var POS_FLASH_MIGRATE_KEY = 'pos_flash_migrate_v391';
        var POS_FLASH_LAST_OK_KEY = 'pos_flash_last_ok_at';
        var POS_FLASH_LAST_VERIFY_KEY = 'pos_flash_last_verify_v1';
        var POS_FLASH_LAST_FULL_KEY = 'pos_flash_last_full_at';
        var POS_FLASH_DEVICE_ID_KEY = 'pos_flash_device_id';
        var POS_FLASH_PROTECT_KEY = 'pos_flash_write_protect';
        var POS_FLASH_META_FILE = 'pos_flash_meta.json';
        var POS_FLASH_SUBDIR = 'Laptop_Duhok_POS_Backups';
        var POS_FLASH_DEVICE_ID_FILE = '.pos_device_id';
        var POS_FLASH_KEEP = 50;
        var POS_FLASH_AUTO_MS = 10 * 60 * 1000; // if last copy is stale, push complete DB again
        var POS_FLASH_DEBOUNCE_MS = 15 * 1000; // coalesce sales → complete DB → flash ~15s after last change
        var POS_FLASH_BUSY_MAX_MS = 55 * 1000; // short ops
        var POS_FLASH_BUSY_COMPLETE_MS = 5 * 60 * 1000; // complete DB export+USB write
        var POS_FLASH_BUSY_FULL_MS = 20 * 60 * 1000; // ZIP + mysql/data safety net
        var POS_FLASH_HEARTBEAT_MS = 40 * 1000; // if dirty/fail, keep retrying without waiting for next sale
        var POS_FLASH_DELTA_WM_KEY = 'pos_flash_delta_wm_v1';
        var POS_FLASH_DELTA_SUBDIR = 'delta';
        var POS_FLASH_DELTA_FILE = 'changes.jsonl';
        var POS_FLASH_DELTA_WM_FILE = 'watermark.json';
        // Use .posbak on flash — NOT .zip — so Windows Explorer never shows "Multi-Volume set"
        var POS_FLASH_NAME_POS = 'Laptop_Duhok_POS_Latest.posbak';
        var POS_FLASH_NAME_POS_P1 = 'Laptop_Duhok_POS_Latest_part1.posbak';
        var POS_FLASH_NAME_POS_P2 = 'Laptop_Duhok_POS_Latest_part2.posbak';
        var POS_FLASH_NAME_MYSQL_FULL = 'XAMPP_MySQL_Data_FULL_Latest.posbak';
        var POS_FLASH_NAME_MYSQL_DB = 'XAMPP_MySQL_Data_DB_Latest.posbak';
        var POS_FLASH_NAME_ITEMS = 'Laptop_Duhok_POS_Items_Latest.posbak';
        var POS_FLASH_LEGACY_ZIP_NAMES = [
            'Laptop_Duhok_POS_Latest.zip',
            'Laptop_Duhok_POS_Latest_part1.zip',
            'Laptop_Duhok_POS_Latest_part2.zip',
            'XAMPP_MySQL_Data_FULL_Latest.zip',
            'XAMPP_MySQL_Data_DB_Latest.zip',
            'Laptop_Duhok_POS_Items_Latest.zip'
        ];
        var _posFlashAutoTimer = null;
        var _posFlashAutoBusy = false;
        var _posFlashBusyGen = 0;
        var _posFlashDirty = false;
        var _posFlashPendingRetry = false;
        var _posFlashDebounceTimer = null;
        var _posFlashBusyWatchdog = null;
        var _posFlashHeartbeatTimer = null;
        var _posFlashLastFail = '';
        var _posFlashLiveOk = false;
        var _posFlashLiveKnown = false;
        var _posFlashLiveChecking = false;
        var _posFlashLiveCheckTimer = null;
        var _posFlashLastAlertAt = 0;
        var _posFlashLastAlertWhy = '';
        var POS_FLASH_ALERT_MS = 4 * 60 * 1000;
        var POS_FLASH_LIVE_CHECK_MS = 45 * 1000;
        var POS_FLASH_RECONNECT_MS = 8 * 1000;
        var _posFlashLastLiveCheckAt = 0;
        var _posFlashBusyMaxMs = POS_FLASH_BUSY_MAX_MS;

        function posFlashClearBusyWatchdog() {
            if (_posFlashBusyWatchdog) {
                clearTimeout(_posFlashBusyWatchdog);
                _posFlashBusyWatchdog = null;
            }
        }
        function posFlashArmBusyWatchdog(gen) {
            posFlashClearBusyWatchdog();
            var maxMs = _posFlashBusyMaxMs || POS_FLASH_BUSY_MAX_MS;
            var myGen = (gen != null) ? gen : _posFlashBusyGen;
            _posFlashBusyWatchdog = setTimeout(function () {
                _posFlashBusyWatchdog = null;
                if (!_posFlashAutoBusy) return;
                if (myGen !== _posFlashBusyGen) return; // superseded by newer sync
                console.warn('[flash] busy watchdog — force unlock after hang');
                _posFlashAutoBusy = false;
                _posFlashLastFail = 'timeout';
                _posFlashDirty = true;
                posFlashNoteLiveFail('timeout');
                posFlashUpdateSidebarStatus();
                if (posFlashAutoEnabled()) posFlashScheduleSync('watchdog', 2000);
            }, maxMs);
        }
        function posFlashBeginBusy(maxMs) {
            _posFlashBusyGen = (_posFlashBusyGen + 1) >>> 0;
            var gen = _posFlashBusyGen;
            _posFlashAutoBusy = true;
            _posFlashBusyMaxMs = (maxMs && isFinite(maxMs)) ? Number(maxMs) : POS_FLASH_BUSY_MAX_MS;
            posFlashArmBusyWatchdog(gen);
            posFlashUpdateSidebarStatus({ syncing: true });
            return gen;
        }
        function posFlashEndBusy(gen) {
            if (gen != null && gen !== _posFlashBusyGen) return; // older sync finishing late
            _posFlashAutoBusy = false;
            _posFlashBusyMaxMs = POS_FLASH_BUSY_MAX_MS;
            posFlashClearBusyWatchdog();
            posFlashUpdateSidebarStatus();
        }

        function posFlashHasLinkedHint() {
            try {
                return !!(localStorage.getItem(POS_FLASH_NAME_KEY) || localStorage.getItem(POS_FLASH_DEVICE_ID_KEY));
            } catch (_eH) { return false; }
        }
        /** After shop update: old PCs often had auto OFF — turn ON so data keeps going to the same flash. */
        function posFlashMigrateAfterShopUpdate() {
            try {
                if (localStorage.getItem(POS_FLASH_MIGRATE_KEY) === '1') return false;
                localStorage.setItem(POS_FLASH_MIGRATE_KEY, '1');
                if (posFlashHasLinkedHint()) {
                    localStorage.setItem(POS_FLASH_AUTO_KEY, '1');
                    return true;
                }
            } catch (_eM) {}
            return false;
        }
        async function posFlashBootAfterShopUpdate() {
            posFlashMigrateAfterShopUpdate();
            posFlashUpdateAutoOnOffUi();
            posFlashUpdateSidebarStatus();
            var handle = null;
            try { handle = await posFlashLoadDirHandle(); } catch (_eH) { handle = null; }
            if (handle) {
                posFlashUpdateAutoOnOffUi();
                posFlashStartAutoLoop();
                var okPerm = false;
                try { okPerm = await posFlashEnsurePermission(handle, 'readwrite', false); } catch (_eP) { okPerm = false; }
                if (okPerm && posFlashAutoEnabled()) {
                    posFlashScheduleSync('shop_update', 2000);
                    posFlashCheckLiveConnection().catch(function () {});
                } else if (!okPerm) {
                    posFlashNoteLiveFail('permission');
                    posFlashUpdateSidebarStatus();
                }
                return;
            }
            if (posFlashAutoEnabled()) {
                posFlashStartAutoLoop();
                if (posFlashHasLinkedHint()) {
                    posFlashNoteLiveFail('disconnected');
                    posFlashUpdateSidebarStatus();
                }
            }
        }
        function posFlashAutoEnabled() {
            try {
                var v = localStorage.getItem(POS_FLASH_AUTO_KEY);
                if (v === '0') return false;
                if (v === '1') return true;
                // Flash already linked → auto ON (shop data must keep copying)
                return !!(localStorage.getItem(POS_FLASH_NAME_KEY));
            } catch (_e) { return false; }
        }
        function _posFlashPersistAutoFlag(on) {
            try { localStorage.setItem(POS_FLASH_AUTO_KEY, on ? '1' : '0'); } catch (_e2) {}
        }
        function posFlashUpdateAutoOnOffUi() {
            var on = posFlashAutoEnabled();
            var btn = document.getElementById('flash-auto-onoff-btn');
            var label = document.getElementById('flash-auto-onoff-label');
            var chk = document.getElementById('flash-auto-toggle');
            if (chk) chk.checked = on;
            if (label) label.textContent = on ? 'ON — ئۆتۆماتیک چالاکە' : 'OFF — ئۆتۆماتیک ناکارا';
            if (btn) {
                btn.style.background = on ? 'linear-gradient(135deg,#16a34a,#15803d)' : 'linear-gradient(135deg,#64748b,#475569)';
                btn.style.color = '#fff';
                btn.style.border = on ? '2px solid #86efac' : '2px solid #94a3b8';
            }
        }
        function posFlashApplyAutoEnabled(on) {
            on = !!on;
            _posFlashPersistAutoFlag(on);
            posFlashUpdateAutoOnOffUi();
            if (on) {
                posFlashStartAutoLoop();
                posFlashScheduleSync('auto_on', 1500);
            } else {
                posFlashStopAutoLoop();
                _posFlashDirty = false;
                _posFlashPendingRetry = false;
                if (_posFlashDebounceTimer) {
                    clearTimeout(_posFlashDebounceTimer);
                    _posFlashDebounceTimer = null;
                }
            }
            // Only update status text — do not full-refresh (avoids recursion / stack overflow)
            var statusEl = document.getElementById('flash-backup-status');
            if (statusEl && statusEl.textContent) {
                if (on && statusEl.textContent.indexOf('OFF') !== -1) {
                    statusEl.textContent = statusEl.textContent.replace('ئۆتۆماتیک OFF', 'ئۆتۆماتیک ON');
                } else if (!on && statusEl.textContent.indexOf('ON') !== -1) {
                    statusEl.textContent = statusEl.textContent.replace('ئۆتۆماتیک ON', 'ئۆتۆماتیک OFF');
                }
            }
            posFlashUpdateSidebarStatus();
        }

        function posFlashMaybeAlertNotWorking(why) {
            // Status is the USB chip color only — no toast (annoying in the shop).
        }
        function posFlashNoteLiveOk() {
            _posFlashLiveKnown = true;
            _posFlashLiveOk = true;
            _posFlashLastAlertWhy = '';
        }
        async function posFlashPingPhpUsb() {
            var id = '';
            try { id = posFlashGetStoredDeviceId(); } catch (_eId) {}
            if (!id && !posFlashHasLinkedHint()) return { ok: false, reason: 'no_folder' };
            try {
                var res = await fetch(
                    '?action=flash_usb_ping&for_flash=1&device_id=' + encodeURIComponent(id || ''),
                    { credentials: 'same-origin' }
                );
                var data = await res.json();
                if (data && data.ok) return { ok: true, letter: data.letter || '', via: 'php' };
                return { ok: false, reason: (data && data.reason) || 'disconnected' };
            } catch (_ePing) {
                return { ok: false, reason: 'error' };
            }
        }
        async function posFlashExportDirectToUsb() {
            var id = '';
            try { id = posFlashGetStoredDeviceId(); } catch (_eId2) {}
            try {
                var res = await fetch(
                    '?action=export_full_backup&zip=1&save_local=0&include_files=0&for_flash=1&copy_to_usb=1&device_id=' + encodeURIComponent(id || ''),
                    { credentials: 'same-origin' }
                );
                var data = await res.json();
                if (data && data.status === 'success' && data.ok) {
                    posFlashNoteLiveOk();
                    return { ok: true, bytes: data.bytes || 0, name: data.name || POS_FLASH_NAME_POS, via: 'php', mode: 'complete_db' };
                }
                return { ok: false, reason: (data && data.reason) || 'disconnected' };
            } catch (_eExp) {
                return { ok: false, reason: 'error' };
            }
        }
        async function posFlashCopyBlobViaPhp(blob, filename, kind) {
            if (!blob) return { ok: false, reason: 'no_blob' };
            var id = '';
            try { id = posFlashGetStoredDeviceId(); } catch (_eId3) {}
            var safeName = posFlashSanitizeFileName(posFlashStableFileName(filename, kind || 'pos'));
            try {
                var fd = new FormData();
                fd.append('device_id', id || '');
                fd.append('filename', safeName);
                fd.append('file', blob, safeName);
                var res = await fetch('?action=flash_usb_write&for_flash=1', {
                    method: 'POST',
                    body: fd,
                    credentials: 'same-origin'
                });
                var data = await res.json();
                if (data && data.ok) {
                    posFlashNoteLiveOk();
                    return { ok: true, name: data.name || safeName, bytes: data.bytes || blob.size || 0, folder: data.letter || '', via: 'php' };
                }
                return { ok: false, reason: (data && data.reason) || 'disconnected' };
            } catch (_eW) {
                return { ok: false, reason: 'error' };
            }
        }
        async function posFlashCheckLiveConnection() {
            if (_posFlashLiveChecking || _posFlashAutoBusy) return;
            if (!posFlashAutoEnabled()) {
                _posFlashLiveOk = false;
                posFlashUpdateSidebarStatus();
                return;
            }
            var now = Date.now();
            if (_posFlashLiveOk && (now - _posFlashLastLiveCheckAt) < POS_FLASH_LIVE_CHECK_MS) return;
            _posFlashLastLiveCheckAt = now;
            _posFlashLiveChecking = true;
            try {
                var handle = null;
                try { handle = await posFlashLoadDirHandle(); } catch (_eH) { handle = null; }
                var probeTimeout = false;
                var probeGone = false;
                if (handle) {
                    var okPerm = false;
                    try { okPerm = await posFlashEnsurePermission(handle, 'readwrite', false); } catch (_eP) { okPerm = false; }
                    if (okPerm) {
                        try {
                            await Promise.race([
                                posFlashProbeWritable(handle),
                                new Promise(function (_, rej) {
                                    setTimeout(function () { rej(new Error('timeout')); }, 8000);
                                })
                            ]);
                            _posFlashLastFail = '';
                            posFlashNoteLiveOk();
                            posFlashUpdateSidebarStatus();
                            return;
                        } catch (probeErr) {
                            var pmsg = String((probeErr && probeErr.message) || probeErr || '');
                            probeTimeout = /timeout/i.test(pmsg);
                            probeGone = typeof posFlashIsStaleError === 'function' && posFlashIsStaleError(probeErr);
                            if (!probeGone && /NotFound|InvalidState|disconnected|removed/i.test(pmsg)) probeGone = true;
                            if (probeTimeout && _posFlashLiveOk) {
                                posFlashUpdateSidebarStatus();
                                return;
                            }
                        }
                    }
                }
                var php = await posFlashPingPhpUsb();
                if (php && php.ok) {
                    var wasDown = !_posFlashLiveOk;
                    _posFlashLastFail = '';
                    posFlashNoteLiveOk();
                    posFlashUpdateSidebarStatus();
                    if (wasDown && posFlashAutoEnabled()) {
                        posFlashScheduleSync('replug', 800);
                    }
                    return;
                }
                if (_posFlashLiveOk && probeTimeout && !probeGone) {
                    posFlashUpdateSidebarStatus();
                    return;
                }
                posFlashNoteLiveFail(php && php.reason ? php.reason : (posFlashHasLinkedHint() ? 'disconnected' : 'no_folder'));
                posFlashUpdateSidebarStatus();
            } catch (_eChk) {
                posFlashNoteLiveFail('error');
                posFlashUpdateSidebarStatus();
            } finally {
                _posFlashLiveChecking = false;
            }
        }
        function posFlashNoteLiveFail(why, opts) {
            opts = opts || {};
            _posFlashLiveKnown = true;
            _posFlashLiveOk = false;
            if (why) _posFlashLastFail = why;
            if (opts.alert !== false) posFlashMaybeAlertNotWorking(why || _posFlashLastFail || 'error');
        }

        /**
         * USB chip: green only when flash is plugged, auto ON, and writable.
         */
        function posFlashUpdateSidebarStatus(opts) {
            opts = opts || {};
            var el = document.getElementById('right-sidebar-flash-status');
            var txt = document.getElementById('right-sidebar-flash-status-text');
            var headerUsb = document.getElementById('top-header-usb-status');
            var headerUsbTxt = document.getElementById('top-header-usb-text');
            var on = false;
            var last = 0;
            try { on = posFlashAutoEnabled(); } catch (_eOn) {}
            try { last = parseInt(localStorage.getItem(POS_FLASH_LAST_OK_KEY) || '0', 10) || 0; } catch (_eLast) {}
            var copying = !!(opts.syncing || _posFlashAutoBusy);
            var fail = _posFlashLastFail || '';
            var timeStr = '';
            if (last) {
                try { timeStr = new Date(last).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); } catch (_eT) {}
            }

            function paintHeader(cls, label) {
                if (!headerUsb) return;
                headerUsb.classList.remove('usb-hidden', 'usb-syncing', 'usb-ok', 'usb-error', 'usb-off', 'usb-wait', 'usb-copying');
                String(cls || '').split(/\s+/).forEach(function (c) { if (c) headerUsb.classList.add(c); });
                if (headerUsbTxt) headerUsbTxt.textContent = label;
            }
            function paintSide(cls, label, title) {
                if (!el || !txt) return;
                el.classList.remove('flash-off', 'flash-ok', 'flash-wait', 'flash-sync', 'flash-error', 'flash-copying');
                String(cls || '').split(/\s+/).forEach(function (c) { if (c) el.classList.add(c); });
                txt.textContent = label;
                if (title) el.title = title;
            }
            function paintGreen() {
                var cls = copying ? 'usb-ok usb-copying' : 'usb-ok';
                var side = copying ? 'flash-ok flash-copying' : 'flash-ok';
                paintHeader(cls, timeStr || 'OK');
                paintSide(
                    side,
                    timeStr || 'OK',
                    last
                        ? ('فلاش گڕێدایە و کار دکەت · دوایین کۆپی: ' + new Date(last).toLocaleString())
                        : 'فلاش گڕێدایە و کار دکەت'
                );
            }

            if (!on) {
                paintHeader('usb-off', 'فلاش');
                paintSide('flash-off', 'فلاش OFF', 'ئۆتۆماتیک ناکارا — لە سێتینگ ON بکە');
                return;
            }
            if (typeof posFlashIsWriteProtected === 'function' && posFlashIsWriteProtected()) {
                paintHeader('usb-wait', 'پارێز');
                paintSide('flash-wait', 'پارێز', 'داتای فلاش پارێزراوە — سەرەتا گەڕاندنەوە بکە. کلیک = چالاککردنەوە');
                return;
            }
            if (_posFlashLiveKnown && !_posFlashLiveOk) {
                var waitLabel = fail === 'no_folder' ? 'کلیک' : 'نییە';
                var waitTitle = fail === 'no_folder'
                    ? 'فلاش هەڵنەبژێردراوە — ئێک جار هەڵبژێرە'
                    : 'فلاش ژێفەکری یان کێشە هەیە';
                paintHeader(fail === 'error' ? 'usb-error' : 'usb-wait', waitLabel);
                paintSide(fail === 'error' ? 'flash-error' : 'flash-wait', waitLabel, waitTitle);
                return;
            }
            paintGreen();
        }
        function posFlashToggleAuto() {
            var next = !posFlashAutoEnabled();
            posFlashApplyAutoEnabled(next);
            if (typeof showToast === 'function') {
                showToast(
                    next
                        ? '✅ ئۆتۆماتیک ON — هەموو داتا بۆ فلاش (وەک سێرڤەر / تەواو)'
                        : '⏸️ ئۆتۆماتیک OFF — تەنها بە کلیکی دەستی',
                    next ? 'success' : 'error'
                );
            }
        }

        /**
         * Mark flash out of date and sync soon (debounced).
         * Auto path uses light incremental delta — not full ZIP.
         */
        function posFlashScheduleSync(reason, delayMs) {
            if (!posFlashAutoEnabled()) return;
            if (posFlashIsWriteProtected()) {
                _posFlashLastFail = 'protect';
                posFlashUpdateSidebarStatus();
                return;
            }
            _posFlashDirty = true;
            if (_posFlashDebounceTimer) {
                clearTimeout(_posFlashDebounceTimer);
                _posFlashDebounceTimer = null;
            }
            var wait = (delayMs != null && isFinite(delayMs)) ? Math.max(0, Number(delayMs)) : POS_FLASH_DEBOUNCE_MS;
            _posFlashDebounceTimer = setTimeout(function () {
                _posFlashDebounceTimer = null;
                posFlashRunDirtySync().catch(function () {});
            }, wait);
        }

        function posFlashLoadLocalWatermark() {
            try {
                var raw = localStorage.getItem(POS_FLASH_DELTA_WM_KEY);
                if (!raw) return null;
                var o = JSON.parse(raw);
                return (o && typeof o === 'object') ? o : null;
            } catch (_e) { return null; }
        }
        function posFlashSaveLocalWatermark(wm) {
            try {
                if (wm && typeof wm === 'object') {
                    localStorage.setItem(POS_FLASH_DELTA_WM_KEY, JSON.stringify(wm));
                }
            } catch (_e2) {}
        }

        async function posFlashGetDeltaDir(backupsDir, create) {
            if (!backupsDir) return null;
            try {
                return await backupsDir.getDirectoryHandle(POS_FLASH_DELTA_SUBDIR, { create: !!create });
            } catch (_e3) {
                return null;
            }
        }

        async function posFlashReadWatermarkFromFlash(backupsDir) {
            try {
                var deltaDir = await posFlashGetDeltaDir(backupsDir, false);
                if (!deltaDir) return null;
                var fh = await deltaDir.getFileHandle(POS_FLASH_DELTA_WM_FILE);
                var file = await fh.getFile();
                var text = await file.text();
                var o = JSON.parse(text || '{}');
                return (o && typeof o === 'object') ? o : null;
            } catch (_e4) {
                return null;
            }
        }

        async function posFlashWriteWatermarkToFlash(backupsDir, wm) {
            var deltaDir = await posFlashGetDeltaDir(backupsDir, true);
            if (!deltaDir) return false;
            var fh = await deltaDir.getFileHandle(POS_FLASH_DELTA_WM_FILE, { create: true });
            var w = await fh.createWritable();
            await w.write(JSON.stringify(wm || {}, null, 0));
            await w.close();
            return true;
        }

        async function posFlashAppendDeltaToFlash(backupsDir, deltaPayload) {
            var deltaDir = await posFlashGetDeltaDir(backupsDir, true);
            if (!deltaDir) return { ok: false, reason: 'no_delta_dir' };
            var fh = await deltaDir.getFileHandle(POS_FLASH_DELTA_FILE, { create: true });
            var existing = '';
            try {
                var file = await fh.getFile();
                // Cap growth: if huge, keep last ~1.5MB then append
                if (file.size > 2.5 * 1024 * 1024) {
                    existing = await file.text();
                    if (existing.length > 1.5 * 1024 * 1024) {
                        existing = existing.slice(existing.length - (1.5 * 1024 * 1024));
                        var nl = existing.indexOf('\n');
                        if (nl >= 0) existing = existing.slice(nl + 1);
                    }
                } else {
                    existing = await file.text();
                }
            } catch (_e5) {
                existing = '';
            }
            var line = JSON.stringify(deltaPayload) + '\n';
            var w = await fh.createWritable();
            await w.write(existing + line);
            await w.close();
            return { ok: true };
        }

        async function posFlashClearDeltaLog(backupsDir) {
            try {
                var deltaDir = await posFlashGetDeltaDir(backupsDir, true);
                if (!deltaDir) return;
                var fh = await deltaDir.getFileHandle(POS_FLASH_DELTA_FILE, { create: true });
                var w = await fh.createWritable();
                await w.write('');
                await w.close();
            } catch (_e6) {}
        }

        async function posFlashEnsureDeltaWatermark(backupsDir) {
            var wm = await posFlashReadWatermarkFromFlash(backupsDir);
            if (!wm || !wm._ready) wm = posFlashLoadLocalWatermark();
            if (wm && wm._ready) {
                posFlashSaveLocalWatermark(wm);
                return wm;
            }
            // First time: pin cursor at "now" so we do NOT dump all history (full ZIP already has it)
            var res = await fetch('?action=export_flash_delta&init=1', { credentials: 'same-origin' });
            var data = await res.json();
            if (!data || data.status !== 'success' || !data.delta || !data.delta.watermarks) {
                throw new Error((data && data.message) || 'watermark init failed');
            }
            wm = data.delta.watermarks;
            wm._ready = 1;
            posFlashSaveLocalWatermark(wm);
            await posFlashWriteWatermarkToFlash(backupsDir, wm);
            return wm;
        }

        /**
         * Complete POS database → flash (same tables as server backup).
         * Overwrites sql/full_backup.json + Latest.posbak. Skips heavy mysql/data (manual / 2h).
         */
        async function posSyncCompleteDbToFlash(opts) {
            opts = opts || {};
            if (opts.auto && !opts.force && !posFlashAutoEnabled()) {
                return { ok: false, reason: 'auto_off' };
            }
            if (_posFlashAutoBusy) {
                _posFlashPendingRetry = true;
                return { ok: false, reason: 'busy' };
            }
            posFlashBeginBusy(POS_FLASH_BUSY_COMPLETE_MS);
            var busyGen = _posFlashBusyGen;
            var showUi = !(opts.silent || opts.auto);
            var indicator = showUi ? document.getElementById('save-indicator') : null;
            try {
                var ready = await posFlashGetWritable(!!opts.interactive);
                if (!ready.ok) {
                    var phpDirect = await posFlashExportDirectToUsb();
                    if (phpDirect && phpDirect.ok) {
                        posFlashMarkLastOk();
                        if (indicator) {
                            indicator.style.display = 'block';
                            indicator.innerHTML = '<i class="fas fa-check"></i> داتا چووە سەر فلاش';
                            setTimeout(function () { indicator.style.display = 'none'; }, 2200);
                        }
                        if (showUi && typeof showToast === 'function') {
                            showToast('✅ داتا چووە سەر فلاش', 'success');
                        }
                        return phpDirect;
                    }
                    if (showUi) {
                        alert('فلاش ئامادە نییە — «هەڵبژاردنی فلاش» بکە.');
                    }
                    return ready;
                }
                if (indicator) {
                    indicator.style.display = 'block';
                    indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ناردنی هەموو داتای دکانێ بۆ فلاش…';
                }

                var guard = await posFlashGuardOverwrite(ready.dir, {
                    interactive: !!opts.interactive,
                    force: !!opts.force,
                    allowDestroy: !!opts.allowDestroy
                });
                if (!guard.ok) {
                    _posFlashLastFail = 'protect';
                    posFlashUpdateSidebarStatus();
                    return guard;
                }

                _posFlashDirty = false;

                try { await posFlushBeforeBackup(); } catch (_eFlush) {}

                var actionName = ['export', 'full', 'backup'].join('_');
                // Auto: no local disk copy; include_files=0 keeps USB sync practical
                var saveLocal = (opts.auto || opts.silent) ? '0' : '1';
                var res = await fetch(
                    '?action=' + actionName + '&zip=1&download=1&save_local=' + saveLocal + '&include_files=0&for_flash=1',
                    { credentials: 'same-origin' }
                );
                if (!res.ok) throw new Error(await posFlashFetchErrorMessage(res));
                var hdrVerified = String(res.headers.get('X-Backup-Verified') || '');
                if (hdrVerified === '0') {
                    throw new Error('باک‌ئەپ ناتەواوە — خشتەی گرنگ کێمە');
                }
                var hdrTables = parseInt(res.headers.get('X-Backup-Tables') || '0', 10) || 0;
                var hdrRows = parseInt(res.headers.get('X-Backup-Rows') || '0', 10) || 0;
                var filename = 'Laptop_Duhok_POS_Backup_' + new Date().toISOString().slice(0, 10) + '.posbak';
                var disp = res.headers.get('Content-Disposition');
                if (disp && disp.indexOf('filename=') !== -1) {
                    filename = disp.split('filename=')[1].replace(/['"]/g, '');
                }
                var blob;
                try {
                    blob = await posAssertBackupZipResponse(res, await res.blob());
                } catch (zipErr) {
                    var phpDirect2 = await posFlashExportDirectToUsb();
                    if (phpDirect2 && phpDirect2.ok) {
                        posFlashMarkLastOk();
                        if (indicator) {
                            indicator.innerHTML = '<i class="fas fa-check"></i> داتا چووە سەر فلاش';
                            setTimeout(function () { indicator.style.display = 'none'; }, 2200);
                        }
                        if (showUi && typeof showToast === 'function') {
                            showToast('✅ داتا چووە سەر فلاش', 'success');
                        }
                        return phpDirect2;
                    }
                    throw zipErr;
                }
                var flash1 = await posCopyBackupBlobToFlash(blob, filename, {
                    silent: true,
                    interactive: false,
                    skipRefresh: true,
                    force: true,
                    kind: 'pos'
                });
                if (!flash1.ok) throw new Error(flash1.message || flash1.reason || 'ZIP→فلاش');
                if (!flash1.bytes || flash1.bytes < 64) {
                    throw new Error('فایل لسەر فلاش نەهاتە پشتڕاستکرن');
                }

                posFlashSaveLastVerify({
                    at: Date.now(),
                    bytes: flash1.bytes,
                    tables: hdrTables,
                    rows: hdrRows,
                    name: flash1.name || POS_FLASH_NAME_POS
                });

                // Snapshot is complete — clear incremental log so restore stays consistent
                try {
                    var initRes = await fetch('?action=export_flash_delta&init=1', { credentials: 'same-origin' });
                    var initData = await initRes.json();
                    if (initData && initData.status === 'success' && initData.delta && initData.delta.watermarks) {
                        var wm = initData.delta.watermarks;
                        wm._ready = 1;
                        posFlashSaveLocalWatermark(wm);
                        await posFlashWriteWatermarkToFlash(ready.dir, wm);
                        await posFlashClearDeltaLog(ready.dir);
                    }
                } catch (_eWm) {}

                try {
                    var meta = posFlashBuildLocalMeta();
                    meta.bytes = (flash1 && flash1.bytes) || blob.size || 0;
                    meta.tables = hdrTables;
                    meta.serverRows = hdrRows;
                    meta.verified = true;
                    meta.file = (flash1 && flash1.name) || POS_FLASH_NAME_POS;
                    await posFlashWriteMeta(ready.dir, meta);
                } catch (_eMetaW) {}

                posFlashSetWriteProtect(false);
                _posFlashLastFail = '';
                posFlashMarkLastOk();
                if (typeof posFlashUpdateSidebarStatus === 'function') posFlashUpdateSidebarStatus();
                if (indicator) {
                    indicator.innerHTML = '<i class="fas fa-check"></i> داتا چووە سەر فلاش';
                    setTimeout(function () { indicator.style.display = 'none'; }, 2200);
                }
                if (showUi && typeof showToast === 'function') {
                    var sizeMb = (flash1.bytes / (1024 * 1024));
                    var sizeTxt = sizeMb >= 1 ? (sizeMb.toFixed(1) + ' MB') : (Math.max(1, Math.round(flash1.bytes / 1024)) + ' KB');
                    var extra = hdrRows > 0
                        ? (' · ' + hdrTables + ' خشتە · ' + hdrRows.toLocaleString('en-US') + ' ڕیز · ' + sizeTxt)
                        : (' · ' + sizeTxt);
                    showToast('✅ داتا پشتڕاست بوو لسەر فلاش' + extra, 'success');
                }
                if (showUi) {
                    try { await posRefreshFlashBackupUi(true); } catch (_eUiOk) {}
                }
                return { ok: true, mode: 'complete_db', bytes: flash1.bytes, tables: hdrTables, rows: hdrRows };
            } catch (err) {
                _posFlashLastFail = 'error';
                posFlashUpdateSidebarStatus();
                if (indicator) {
                    indicator.innerHTML = '<i class="fas fa-times"></i> فلاش';
                    setTimeout(function () { indicator.style.display = 'none'; }, 3000);
                }
                if (showUi) {
                    alert(posFlashSimpleFailHelp());
                }
                return { ok: false, message: err && err.message ? err.message : String(err) };
            } finally {
                posFlashEndBusy(busyGen);
                if (posFlashAutoEnabled() && (_posFlashDirty || _posFlashPendingRetry)) {
                    _posFlashPendingRetry = false;
                    posFlashScheduleSync('after_complete', Math.min(POS_FLASH_DEBOUNCE_MS, 12000));
                }
            }
        }

        /** Light incremental sync — only new rows; silent; no save-indicator. */
        async function posSyncDeltaToFlash(opts) {
            opts = opts || {};
            if (opts.auto && !opts.force && !posFlashAutoEnabled()) {
                return { ok: false, reason: 'auto_off' };
            }
            if (_posFlashAutoBusy) {
                _posFlashPendingRetry = true;
                return { ok: false, reason: 'busy' };
            }
            posFlashBeginBusy();
            var busyGenDelta = _posFlashBusyGen;
            try {
                var ready = await posFlashGetWritable(!!opts.interactive);
                if (!ready.ok) return ready;
                _posFlashDirty = false;

                var wm = await posFlashEnsureDeltaWatermark(ready.dir);
                var res = await fetch('?action=export_flash_delta', {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ watermarks: wm })
                });
                var data = await res.json();
                if (!data || data.status !== 'success' || !data.delta) {
                    throw new Error((data && data.message) || 'delta failed');
                }
                var delta = data.delta;
                var rows = parseInt(delta.row_total, 10) || 0;
                if (rows > 0) {
                    var wrote = await posFlashAppendDeltaToFlash(ready.dir, delta);
                    if (!wrote.ok) throw new Error(wrote.reason || 'delta write');
                }
                if (delta.watermarks && typeof delta.watermarks === 'object') {
                    wm = delta.watermarks;
                    wm._ready = 1;
                    posFlashSaveLocalWatermark(wm);
                    await posFlashWriteWatermarkToFlash(ready.dir, wm);
                }
                _posFlashLastFail = '';
                posFlashMarkLastOk();
                // Never await flash file listing during auto sync — slow USB can hang the busy lock for 30+ min
                if (!(opts.silent || opts.auto)) {
                    try { await posRefreshFlashBackupUi(false); } catch (_eUi) {}
                }
                return { ok: true, rows: rows, mode: 'delta' };
            } catch (err) {
                return { ok: false, message: err && err.message ? err.message : String(err) };
            } finally {
                posFlashEndBusy(busyGenDelta);
                if (posFlashAutoEnabled() && (_posFlashDirty || _posFlashPendingRetry)) {
                    _posFlashPendingRetry = false;
                    posFlashScheduleSync('after_delta', Math.min(POS_FLASH_DEBOUNCE_MS, 10000));
                }
            }
        }

        async function posFlashRunDirtySync() {
            if (!posFlashAutoEnabled()) {
                _posFlashDirty = false;
                _posFlashPendingRetry = false;
                return { ok: false, reason: 'auto_off' };
            }
            if (_posFlashAutoBusy) {
                _posFlashPendingRetry = true;
                return { ok: false, reason: 'busy' };
            }
            if (!_posFlashDirty && !_posFlashPendingRetry) {
                return { ok: true, reason: 'clean' };
            }
            _posFlashDirty = false;
            _posFlashPendingRetry = false;
            // Complete DB snapshot (all tables) — same content as server backup restore path
            var r = await posSyncCompleteDbToFlash({ silent: true, auto: true, interactive: false });
            if (!r || !r.ok) {
                var why = (r && r.reason) ? r.reason : 'error';
                if (why === 'protect') {
                    _posFlashDirty = false;
                    _posFlashPendingRetry = false;
                    _posFlashLastFail = 'protect';
                    posFlashUpdateSidebarStatus();
                    return r;
                }
                if (why === 'busy') {
                    _posFlashDirty = true;
                    posFlashScheduleSync('busy', 8000);
                } else if (why !== 'auto_off') {
                    _posFlashDirty = true;
                    posFlashNoteLiveFail(why);
                    posFlashUpdateSidebarStatus();
                    if (why === 'permission' || why === 'disconnected' || why === 'stale' || why === 'no_folder') {
                        posFlashScheduleSync(why, 15000);
                    } else {
                        posFlashScheduleSync('retry', 25000);
                    }
                }
            } else {
                _posFlashLastFail = '';
                posFlashNoteLiveOk();
                if (_posFlashDirty) posFlashScheduleSync('during', POS_FLASH_DEBOUNCE_MS);
            }
            return r;
        }
        function posFlashMarkLastOk() {
            try { localStorage.setItem(POS_FLASH_LAST_OK_KEY, String(Date.now())); } catch (_e3) {}
            posFlashNoteLiveOk();
            _posFlashLastFail = '';
            posFlashUpdateSidebarStatus();
        }
        function posFlashMarkLastFull() {
            try { localStorage.setItem(POS_FLASH_LAST_FULL_KEY, String(Date.now())); } catch (_e3b) {}
            posFlashMarkLastOk();
        }
        function posFlashSaveLastVerify(info) {
            try {
                localStorage.setItem(POS_FLASH_LAST_VERIFY_KEY, JSON.stringify(info || {}));
            } catch (_eV) {}
        }
        function posFlashLoadLastVerify() {
            try {
                var o = JSON.parse(localStorage.getItem(POS_FLASH_LAST_VERIFY_KEY) || 'null');
                return (o && typeof o === 'object') ? o : null;
            } catch (_eV2) { return null; }
        }
        function posFlashLastOkLabel() {
            try {
                var t = parseInt(localStorage.getItem(POS_FLASH_LAST_OK_KEY) || '0', 10);
                if (!t) return '';
                return new Date(t).toLocaleString();
            } catch (_e4) { return ''; }
        }

        function posFlashIdbReq(mode, fn) {
            return new Promise(function (resolve, reject) {
                try {
                    var open = indexedDB.open(POS_FLASH_IDB, 1);
                    open.onupgradeneeded = function () {
                        var db = open.result;
                        if (!db.objectStoreNames.contains(POS_FLASH_STORE)) {
                            db.createObjectStore(POS_FLASH_STORE);
                        }
                    };
                    open.onerror = function () { reject(open.error || new Error('IDB open failed')); };
                    open.onsuccess = function () {
                        try {
                            var db = open.result;
                            var tx = db.transaction(POS_FLASH_STORE, mode);
                            var store = tx.objectStore(POS_FLASH_STORE);
                            var result;
                            var req = fn(store);
                            if (req && typeof req === 'object' && 'onsuccess' in req) {
                                req.onsuccess = function () { result = req.result; };
                                req.onerror = function () { reject(req.error || new Error('IDB request failed')); };
                            } else {
                                result = req;
                            }
                            tx.oncomplete = function () { resolve(result); };
                            tx.onerror = function () { reject(tx.error || new Error('IDB tx failed')); };
                        } catch (eInner) {
                            reject(eInner);
                        }
                    };
                } catch (e) {
                    reject(e);
                }
            });
        }

        async function posFlashSaveDirHandle(handle) {
            await posFlashIdbReq('readwrite', function (store) {
                return store.put(handle, POS_FLASH_KEY);
            });
            try {
                localStorage.setItem(POS_FLASH_NAME_KEY, handle && handle.name ? String(handle.name) : '');
            } catch (_e) {}
        }

        async function posFlashLoadDirHandle() {
            return posFlashIdbReq('readonly', function (store) {
                return store.get(POS_FLASH_KEY);
            });
        }

        async function posFlashClearDirHandle(opts) {
            opts = opts || {};
            await posFlashIdbReq('readwrite', function (store) {
                return store.delete(POS_FLASH_KEY);
            });
            try {
                localStorage.removeItem(POS_FLASH_NAME_KEY);
                // keepIdentity: unplug/replug — remember device id + last ok so same flash reconnects easily
                if (!opts.keepIdentity) {
                    localStorage.removeItem(POS_FLASH_LAST_OK_KEY);
                    localStorage.removeItem(POS_FLASH_DEVICE_ID_KEY);
                    localStorage.removeItem(POS_FLASH_PROTECT_KEY);
                    localStorage.setItem(POS_FLASH_AUTO_KEY, '0');
                }
            } catch (_e2) {}
            posFlashUpdateSidebarStatus();
        }

        function posFlashGetStoredDeviceId() {
            try {
                var id = String(localStorage.getItem(POS_FLASH_DEVICE_ID_KEY) || '').trim();
                return id || '';
            } catch (_e) { return ''; }
        }
        function posFlashSetStoredDeviceId(id) {
            try {
                if (id) localStorage.setItem(POS_FLASH_DEVICE_ID_KEY, String(id));
                else localStorage.removeItem(POS_FLASH_DEVICE_ID_KEY);
            } catch (_e2) {}
        }
        function posFlashNewDeviceId() {
            try {
                if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
            } catch (_e3) {}
            return 'pos-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
        }
        async function posFlashReadDeviceIdFromFlash(backupsDir) {
            if (!backupsDir) return '';
            try {
                var fh = await backupsDir.getFileHandle(POS_FLASH_DEVICE_ID_FILE);
                var file = await fh.getFile();
                var text = (await file.text() || '').trim();
                return text || '';
            } catch (_e4) {
                return '';
            }
        }
        async function posFlashWriteDeviceIdToFlash(backupsDir, id) {
            if (!backupsDir || !id) return false;
            var fh = await backupsDir.getFileHandle(POS_FLASH_DEVICE_ID_FILE, { create: true });
            var w = await fh.createWritable();
            await w.write(String(id));
            await w.close();
            return true;
        }
        /**
         * Bind / recognize this physical flash via .pos_device_id marker.
         * same=true → previously linked stick; isNew=true → first bind for this PC↔stick pair.
         */
        async function posFlashEnsureDeviceBinding(backupsDir) {
            var stored = posFlashGetStoredDeviceId();
            var onFlash = await posFlashReadDeviceIdFromFlash(backupsDir);
            if (stored && onFlash && stored === onFlash) {
                return { same: true, isNew: false, id: stored };
            }
            if (stored && onFlash && stored !== onFlash) {
                // Different stick than the one we remembered — take over with flash's id or new
                var takeId = onFlash || stored || posFlashNewDeviceId();
                await posFlashWriteDeviceIdToFlash(backupsDir, takeId);
                posFlashSetStoredDeviceId(takeId);
                return { same: false, isNew: false, replaced: true, id: takeId };
            }
            if (!onFlash && stored) {
                // Same PC memory, flash missing marker (old flash) — stamp known id so next unplug/replug matches
                await posFlashWriteDeviceIdToFlash(backupsDir, stored);
                return { same: true, isNew: false, stamped: true, id: stored };
            }
            if (onFlash && !stored) {
                // Flash already marked (other browser / reinstall) — adopt it
                posFlashSetStoredDeviceId(onFlash);
                return { same: true, isNew: false, adopted: true, id: onFlash };
            }
            var fresh = posFlashNewDeviceId();
            await posFlashWriteDeviceIdToFlash(backupsDir, fresh);
            posFlashSetStoredDeviceId(fresh);
            return { same: false, isNew: true, id: fresh };
        }

        function posFlashIsWriteProtected() {
            try { return localStorage.getItem(POS_FLASH_PROTECT_KEY) === '1'; } catch (_e) { return false; }
        }
        function posFlashSetWriteProtect(on) {
            try {
                if (on) localStorage.setItem(POS_FLASH_PROTECT_KEY, '1');
                else localStorage.removeItem(POS_FLASH_PROTECT_KEY);
            } catch (_e2) {}
            posFlashUpdateSidebarStatus();
        }
        function posFlashLocalDataScore() {
            var sales = 0, products = 0, customers = 0, expenses = 0, supplies = 0;
            try {
                if (typeof db !== 'undefined' && db) {
                    sales = (db.sales && db.sales.length) || 0;
                    products = (db.products && db.products.length) || 0;
                    customers = (db.customers && db.customers.length) || 0;
                    expenses = (db.expenses && db.expenses.length) || 0;
                    supplies = (db.supplies && db.supplies.length) || 0;
                }
            } catch (_e3) {}
            return {
                sales: sales,
                products: products,
                customers: customers,
                expenses: expenses,
                supplies: supplies,
                rows: sales + products + customers + expenses + supplies,
                score: sales * 3 + products + customers + expenses + supplies
            };
        }
        function posFlashBuildLocalMeta() {
            var s = posFlashLocalDataScore();
            return {
                hasBackup: true,
                sales: s.sales,
                products: s.products,
                customers: s.customers,
                expenses: s.expenses,
                supplies: s.supplies,
                rows: s.rows,
                score: s.score,
                at: new Date().toISOString(),
                v: 1
            };
        }
        async function posFlashWriteMeta(backupsDir, meta) {
            if (!backupsDir) return false;
            try {
                var sqlDir = await backupsDir.getDirectoryHandle('sql', { create: true });
                var fh = await sqlDir.getFileHandle(POS_FLASH_META_FILE, { create: true });
                var w = await fh.createWritable();
                await w.write(JSON.stringify(meta || posFlashBuildLocalMeta(), null, 0));
                await w.close();
                return true;
            } catch (_e4) {
                return false;
            }
        }
        async function posFlashReadMeta(backupsDir) {
            var out = { hasBackup: false, sales: 0, products: 0, rows: 0, score: 0, bytes: 0 };
            if (!backupsDir) return out;
            try {
                var sqlDir = await backupsDir.getDirectoryHandle('sql', { create: false });
                try {
                    var mh = await sqlDir.getFileHandle(POS_FLASH_META_FILE);
                    var mo = JSON.parse(await (await mh.getFile()).text() || '{}');
                    if (mo && typeof mo === 'object') {
                        out.hasBackup = true;
                        out.sales = parseInt(mo.sales, 10) || 0;
                        out.products = parseInt(mo.products, 10) || 0;
                        out.rows = parseInt(mo.rows, 10) || 0;
                        out.score = parseInt(mo.score, 10) || (out.sales * 3 + out.products);
                        out.at = mo.at || '';
                        out.fromMeta = true;
                    }
                } catch (_eMeta) {}
                try {
                    var fh = await sqlDir.getFileHandle('full_backup.json');
                    var f = await fh.getFile();
                    out.bytes = Math.max(out.bytes, f.size || 0);
                    if (f.size > 2000) out.hasBackup = true;
                } catch (_eSql) {}
            } catch (_eDir) {}
            try {
                var bak = await backupsDir.getFileHandle(POS_FLASH_NAME_POS);
                var f2 = await bak.getFile();
                out.bytes = Math.max(out.bytes, f2.size || 0);
                if (f2.size > 2000) out.hasBackup = true;
            } catch (_eBak) {}
            // Legacy stick without meta: large backup file ⇒ treat as rich data
            if (out.hasBackup && !out.fromMeta && out.bytes > 80000 && out.sales === 0) {
                out.sales = 50;
                out.rows = 100;
                out.score = 200;
                out.legacyRich = true;
            }
            return out;
        }
        /**
         * After format / empty DB: never overwrite a flash that still holds shop data.
         */
        async function posFlashShouldProtectWrite(backupsDir) {
            if (!backupsDir) return false;
            var flash = await posFlashReadMeta(backupsDir);
            if (!flash.hasBackup) return false;
            var local = posFlashLocalDataScore();
            // Fresh / wiped POS vs flash that still has backups
            if (local.score <= 5 && (flash.sales > 0 || flash.rows > 15 || flash.bytes > 60000 || flash.score > 10)) {
                return true;
            }
            // Flash has clearly more sales than this PC (partial wipe / wrong DB)
            if (flash.sales >= 10 && local.sales < flash.sales && (flash.sales - local.sales) >= 5 && local.sales <= flash.sales * 0.5) {
                return true;
            }
            return false;
        }
        async function posFlashGuardOverwrite(backupsDir, opts) {
            opts = opts || {};
            if (opts.force && opts.allowDestroy) return { ok: true };
            var need = await posFlashShouldProtectWrite(backupsDir);
            if (!need && !posFlashIsWriteProtected()) return { ok: true };
            if (need) posFlashSetWriteProtect(true);
            if (opts.interactive) {
                var go = confirm(
                    '🛡️ داتای فلاش پارێزراوە!\n\n'
                    + 'سیستەم بەتاڵ/کەم داتا دیارە، بەڵام فلاش باک‌ئەپی تێدایە.\n\n'
                    + 'ئەگەر ئێستا بنووسیتە سەر فلاش → داتای فلاش دەفەوتێت.\n\n'
                    + 'OK = گەڕاندنەوە لە فلاش (پێشنیارکراو)\n'
                    + 'Cancel = مەنووسە — فلاش وەک خۆی دەمێنێتەوە'
                );
                if (go && typeof posRestoreFromFlashSqlEasy === 'function') {
                    setTimeout(function () { posRestoreFromFlashSqlEasy(); }, 100);
                }
            }
            return {
                ok: false,
                reason: 'protect',
                message: 'داتای فلاش پارێزرا — سەرەتا گەڕاندنەوە بکە'
            };
        }

        /** silent=true: only queryPermission (no popup). interactive: may requestPermission. */
        async function posFlashEnsurePermission(handle, mode, interactive) {
            if (!handle) return false;
            mode = mode || 'readwrite';
            try {
                var q = await handle.queryPermission({ mode: mode });
                if (q === 'granted') return true;
                if (!interactive) return false;
                var r = await handle.requestPermission({ mode: mode });
                return r === 'granted';
            } catch (_ePerm) {
                return false;
            }
        }

        function posFlashSanitizeFileName(name) {
            name = String(name || 'backup.zip').replace(/[\\\/:*?"<>|]+/g, '_').trim();
            if (!name) name = 'Laptop_Duhok_POS_Backup.zip';
            return name;
        }

        /** Accept gzip .posbak, JSON, or ZIP (legacy). ZIP still needs a valid EOCD. */
        async function posFlashAssertValidZipBlob(blob) {
            if (!blob || blob.size < 32) {
                throw new Error('بک‌ئەپ بەتاڵ یان زۆر بچووکە');
            }
            var head = new Uint8Array(await blob.slice(0, 4).arrayBuffer());
            if (head[0] === 0x1f && head[1] === 0x8b) return true;
            if (head[0] === 0x7b || head[0] === 0x5b || head[0] === 0xef) return true;
            if ((head[0] === 0xff && head[1] === 0xfe) || (head[0] === 0xfe && head[1] === 0xff)) return true;
            var isLocal = head[0] === 0x50 && head[1] === 0x4b && head[2] === 0x03 && head[3] === 0x04;
            var isEmpty = head[0] === 0x50 && head[1] === 0x4b && head[2] === 0x05 && head[3] === 0x06;
            if (!isLocal && !isEmpty) {
                throw new Error('فایلێ بک‌ئەپێ تێکچووە (سەرەتا نادروستە)');
            }
            var tailLen = Math.min(65557, blob.size);
            var tail = new Uint8Array(await blob.slice(blob.size - tailLen).arrayBuffer());
            var foundEocd = false;
            for (var i = tail.length - 22; i >= 0; i--) {
                if (tail[i] === 0x50 && tail[i + 1] === 0x4b && tail[i + 2] === 0x05 && tail[i + 3] === 0x06) {
                    foundEocd = true;
                    break;
                }
            }
            if (!foundEocd) {
                throw new Error('فایل ZIP تێکچووە / نیوەنووسراو (Windows: Multi-Volume)');
            }
            return true;
        }

        /**
         * Write backup blob safely: verify via *.tmp, then write final name from memory.
         * Do NOT use FileSystemFileHandle.move() — fails on USB / without user gesture
         * ("request is not allowed by the user agent...").
         */
        async function posFlashWriteBlobAtomic(dirHandle, safeName, blob) {
            await posFlashAssertValidZipBlob(blob);
            var tmpName = safeName + '.tmp';
            try { await dirHandle.removeEntry(tmpName); } catch (_eRmTmp) {}

            var tmpHandle = await dirHandle.getFileHandle(tmpName, { create: true });
            var writable = await tmpHandle.createWritable();
            try {
                await writable.write(blob);
                await writable.close();
            } catch (wErr) {
                try { await writable.abort(); } catch (_eAb) {}
                try { await dirHandle.removeEntry(tmpName); } catch (_eRm2) {}
                throw wErr;
            }

            var written = await (await dirHandle.getFileHandle(tmpName)).getFile();
            if (!written || written.size !== blob.size) {
                try { await dirHandle.removeEntry(tmpName); } catch (_eRm3) {}
                throw new Error('قەبارەی نووسین لەگەڵ ZIP ناگونجێت');
            }
            await posFlashAssertValidZipBlob(written);

            // Replace final by rewrite (blob still in memory) — no move()
            try { await dirHandle.removeEntry(safeName); } catch (_eRmFinal) {}
            var finalHandle = await dirHandle.getFileHandle(safeName, { create: true });
            var w2 = await finalHandle.createWritable();
            try {
                await w2.write(blob);
                await w2.close();
            } catch (w2Err) {
                try { await w2.abort(); } catch (_eAb2) {}
                // Keep .tmp so a good copy remains if final write failed mid-way
                throw w2Err;
            }
            try { await dirHandle.removeEntry(tmpName); } catch (_eRmTmp2) {}
            var finalFile = await (await dirHandle.getFileHandle(safeName)).getFile();
            if (!finalFile || finalFile.size !== blob.size) {
                throw new Error('فایل لسەر فلاش ناتەواوە (قەبارە جیاوازە)');
            }
            await posFlashAssertValidZipBlob(finalFile);
            return safeName;
        }

        function posFlashIsBackupBlobName(name) {
            var low = String(name || '').toLowerCase();
            return low.endsWith('.posbak') || low.endsWith('.zip') || low.endsWith('.json') || low.endsWith('.jsonl');
        }

        function posFlashIsZipLikeName(name) {
            var low = String(name || '').toLowerCase();
            return low.endsWith('.posbak') || low.endsWith('.zip');
        }

        function posFlashZipToPosbakName(name) {
            var n = String(name || '');
            if (/\.zip$/i.test(n)) return n.replace(/\.zip$/i, '.posbak');
            return n;
        }

        /** Remove leftover .tmp / ALL .zip POS backups on flash (Windows Multi-Volume) + keep valid .posbak. */
        async function posFlashCleanupCorruptZips(dirHandle) {
            if (!dirHandle) return { removed: 0, migrated: 0 };
            var removed = 0;
            var migrated = 0;
            var names = [];
            for await (var entry of dirHandle.values()) {
                if (entry.kind === 'file') names.push(String(entry.name || ''));
            }
            for (var i = 0; i < names.length; i++) {
                var n = names[i];
                var low = n.toLowerCase();
                if (low.endsWith('.tmp') || low.endsWith('.partial') || low.endsWith('.new.zip') || low.endsWith('.zip.tmp')) {
                    try { await dirHandle.removeEntry(n); removed++; } catch (_eT) {}
                    continue;
                }
                var isOurs = n.indexOf('Laptop_Duhok_POS') !== -1 || n.indexOf('XAMPP_MySQL_Data') !== -1;
                if (!isOurs) continue;

                // Any .zip on flash triggers Windows Compressed Folders — remove (optionally migrate Latest once)
                if (low.endsWith('.zip')) {
                    var dest = posFlashZipToPosbakName(n);
                    var isLatest = POS_FLASH_LEGACY_ZIP_NAMES.indexOf(n) !== -1;
                    try {
                        var fZip = await (await dirHandle.getFileHandle(n)).getFile();
                        var canMigrate = isLatest && fZip && fZip.size >= 64;
                        if (canMigrate) {
                            try { await posFlashAssertValidZipBlob(fZip); } catch (_eBadZip) { canMigrate = false; }
                        }
                        if (canMigrate) {
                            var existsPosbak = false;
                            try { await dirHandle.getFileHandle(dest); existsPosbak = true; } catch (_eEx) {}
                            if (!existsPosbak) {
                                await posFlashWriteBlobAtomic(dirHandle, dest, fZip);
                                migrated++;
                            }
                        }
                    } catch (_eRead) {}
                    try { await dirHandle.removeEntry(n); removed++; } catch (_eRm) {}
                    continue;
                }

                if (low.endsWith('.posbak')) {
                    try {
                        var fBak = await (await dirHandle.getFileHandle(n)).getFile();
                        if (!fBak || fBak.size < 64) {
                            await dirHandle.removeEntry(n);
                            removed++;
                            continue;
                        }
                        await posFlashAssertValidZipBlob(fBak);
                    } catch (_eBak) {
                        try { await dirHandle.removeEntry(n); removed++; } catch (_eRm2) {}
                    }
                }
            }
            return { removed: removed, migrated: migrated };
        }

        /** Always overwrite the same files on flash — no new timestamped copies. */
        function posFlashStableFileName(originalName, kindHint) {
            var n = String(originalName || '').toLowerCase();
            var hint = String(kindHint || '').toLowerCase();
            if (hint === 'mysql_full' || n.indexOf('mysql_data_full') !== -1 || n.indexOf('xampp_mysql_data_full') !== -1) {
                return POS_FLASH_NAME_MYSQL_FULL;
            }
            if (hint === 'mysql_db' || n.indexOf('mysql_data_db') !== -1 || n.indexOf('xampp_mysql_data_db') !== -1) {
                return POS_FLASH_NAME_MYSQL_DB;
            }
            if (hint === 'items' || n.indexOf('itemsbackup') !== -1 || n.indexOf('items_') !== -1) {
                return POS_FLASH_NAME_ITEMS;
            }
            if (hint === 'part1' || n.indexOf('part1') !== -1) {
                return POS_FLASH_NAME_POS_P1;
            }
            if (hint === 'part2' || n.indexOf('part2') !== -1) {
                return POS_FLASH_NAME_POS_P2;
            }
            return POS_FLASH_NAME_POS;
        }

        async function posFlashGetBackupsDir(rootHandle, create) {
            return rootHandle.getDirectoryHandle(POS_FLASH_SUBDIR, { create: !!create });
        }

        function posFlashIsStaleError(err) {
            if (!err) return false;
            var name = String(err.name || '');
            var msg = String(err.message || err || '');
            if (name === 'InvalidStateError' || name === 'NotFoundError') return true;
            if (/state cached|state had changed|not found|no longer|unavailable|could not be found/i.test(msg)) return true;
            return false;
        }

        async function posFlashForgetStaleHandle(silent) {
            // Keep IndexedDB handle — same stick remounts without picking again. Chip color only (no toast).
            posFlashNoteLiveFail('disconnected', { alert: false });
        }

        /** Also purge corrupt/legacy .zip sitting in the flash root (not only Backups subfolder). */
        async function posFlashSanitizeRootZips(rootHandle) {
            if (!rootHandle) return { removed: 0 };
            var removed = 0;
            try {
                for await (var entry of rootHandle.values()) {
                    if (entry.kind !== 'file') continue;
                    var n = String(entry.name || '');
                    var low = n.toLowerCase();
                    var isOurs = n.indexOf('Laptop_Duhok_POS') !== -1 || n.indexOf('XAMPP_MySQL_Data') !== -1;
                    if (!isOurs) continue;
                    if (low.endsWith('.tmp') || low.endsWith('.partial') || low.endsWith('.zip')) {
                        try { await rootHandle.removeEntry(n); removed++; } catch (_eR) {}
                    }
                }
            } catch (_eRoot) {}
            return { removed: removed };
        }

        async function posFlashSanitizeAll(opts) {
            opts = opts || {};
            var ready = await posFlashGetWritable(!!opts.interactive);
            if (!ready.ok) {
                if (opts.interactive) {
                    alert('فلاش ئامادە نییە — سەرەتا هەڵبژێرە / چالاککردنەوە.');
                }
                return ready;
            }
            var a = await posFlashCleanupCorruptZips(ready.dir);
            var b = await posFlashSanitizeRootZips(ready.handle);
            try { await posRefreshFlashBackupUi(true); } catch (_eUi) {}
            var msg = 'پاکژکردنەوە: ' + ((a && a.removed) || 0) + ' فایل · گواستنەوە بۆ .posbak: ' + ((a && a.migrated) || 0)
                + (b && b.removed ? (' · ڕەگی فلاش: ' + b.removed) : '');
            if (opts.interactive && typeof showToast === 'function') {
                showToast('🧹 ' + msg, 'success');
            }
            return { ok: true, cleanup: a, root: b, message: msg };
        }
        window.posFlashSanitizeAll = posFlashSanitizeAll;

        /** Probe a directory handle is still alive and writable. */
        async function posFlashProbeWritable(rootHandle) {
            var dir = await posFlashGetBackupsDir(rootHandle, true);
            var fh = await dir.getFileHandle('.pos_flash_ok', { create: true });
            var w = await fh.createWritable();
            await w.write(new Blob([String(Date.now())]));
            await w.close();
            return dir;
        }

        /** Returns { ok, handle, dir, reason } when flash is writable. */
        async function posFlashGetWritable(interactive) {
            var handle;
            try {
                handle = await posFlashLoadDirHandle();
            } catch (_eLoad) {
                return { ok: false, reason: 'idb' };
            }
            if (!handle) {
                posFlashNoteLiveFail('no_folder', { alert: false });
                return { ok: false, reason: 'no_folder' };
            }
            var okPerm = await posFlashEnsurePermission(handle, 'readwrite', !!interactive);
            if (!okPerm) {
                posFlashNoteLiveFail('permission', { alert: false });
                return { ok: false, reason: 'permission', handle: handle, folder: handle.name || '' };
            }
            try {
                var dir = await posFlashProbeWritable(handle);
                // One-time stamp so existing linked sticks get a recognizable id
                try {
                    if (!posFlashGetStoredDeviceId()) await posFlashEnsureDeviceBinding(dir);
                } catch (_eId) {}
                posFlashNoteLiveOk();
                _posFlashLastFail = '';
                return { ok: true, handle: handle, dir: dir, folder: handle.name || '' };
            } catch (err) {
                if (posFlashIsStaleError(err)) {
                    posFlashNoteLiveFail('stale', { alert: false });
                    return {
                        ok: false,
                        reason: 'stale',
                        message: 'فلاش ژێفەکری — پاش دانانەوە خۆکار دهێتە گڕێدان'
                    };
                }
                var msg = (err && err.message) ? String(err.message) : String(err);
                posFlashNoteLiveFail('disconnected', { alert: false });
                return { ok: false, reason: 'disconnected', handle: handle, folder: handle.name || '', message: msg };
            }
        }

        async function posPickFlashBackupFolder(opts) {
            opts = opts || {};
            if (!window.showDirectoryPicker) {
                alert('ئەم تایبەتمەندییە پێویستی بە Chrome یان Edge هەیە.\n\nفلاشەکە بکەرەوە و فۆڵدەرێک هەڵبژێرە.');
                return null;
            }
            try {
                // Drop stale USB handle only — keep device id so same stick is recognized
                try { await posFlashClearDirHandle({ keepIdentity: true }); } catch (_eOld) {}

                var handle = await window.showDirectoryPicker({
                    mode: 'readwrite',
                    startIn: 'documents'
                });
                try {
                    if (typeof handle.requestPermission === 'function') {
                        await handle.requestPermission({ mode: 'readwrite' });
                    }
                } catch (_ePermPick) {}

                // Verify write on the FRESH handle before saving to IDB
                var bakDir = await posFlashProbeWritable(handle);
                var bind = { same: false, isNew: true };
                try {
                    bind = await posFlashEnsureDeviceBinding(bakDir);
                } catch (_eBind) {
                    console.warn('[flash bind]', _eBind);
                }
                await posFlashSaveDirHandle(handle);
                _posFlashLastFail = '';
                try {
                    await posFlashCleanupCorruptZips(bakDir);
                    await posFlashSanitizeRootZips(handle);
                } catch (_eSanPick) {}

                // After format / empty PC: activate flash WITHOUT wiping its backups
                var protect = await posFlashShouldProtectWrite(bakDir);
                if (protect) {
                    posFlashSetWriteProtect(true);
                    if (typeof showToast === 'function') {
                        showToast('🛡️ فلاش چالاک بوو — داتاکەی پارێزرا (ناسڕدرێتەوە). گەڕاندنەوە بکە', 'warning');
                    }
                    try { await posRefreshFlashBackupUi(true); } catch (_eUiPick) {}
                    posFlashUpdateSidebarStatus();
                    posFlashApplyAutoEnabled(true);
                    if (confirm(
                        '🛡️ سیستەم بەتاڵ دیارە، فلاش داتای تێدایە.\n\n'
                        + 'داتای فلاش ناسڕدرێتەوە.\n\n'
                        + 'ئێستا گەڕاندنەوە لە فلاش؟'
                    )) {
                        setTimeout(function () {
                            if (typeof posRestoreFromFlashSqlEasy === 'function') posRestoreFromFlashSqlEasy();
                        }, 200);
                    }
                    return handle;
                }

                if (typeof showToast === 'function') {
                    if (bind.same) {
                        showToast('✅ هەمان فلاش ناسرایەوە — داتا بەردەوام دەچێت (بێ دووبارە ڕێکخستن)', 'success');
                    } else if (bind.replaced) {
                        showToast('💾 فلاشی نوێ بەسترا جێگەی پێشوو', 'success');
                    } else {
                        showToast('💾 فلاش بەسترا: ' + (handle.name || '') + ' / ' + POS_FLASH_SUBDIR, 'success');
                    }
                }
                try { await posRefreshFlashBackupUi(true); } catch (_eUiPick2) {}
                posFlashNoteLiveOk();
                _posFlashLastFail = '';
                posFlashUpdateSidebarStatus();
                posFlashApplyAutoEnabled(true);
                return handle;
            } catch (err) {
                if (err && err.name === 'AbortError') return null;
                try { await posFlashClearDirHandle({ keepIdentity: true }); } catch (_eClr2) {}
                var tip = (err && err.message) ? String(err.message) : String(err);
                if (posFlashIsStaleError(err)) {
                    tip = 'فلاش گۆڕا یان دەرهێنراوە.\n\n١) فلاش دایبەستەوە\n٢) کلیک لەسەر «فلاش» لە لایەن\n٣) هەمان فۆڵدەر هەڵبژێرە';
                }
                alert('❌ هەڵبژاردنی فلاش سەرنەکەوت:\n' + tip);
                return null;
            }
        }

        /**
         * One-click from sidebar: reclaim permission (user gesture) or pick folder.
         * Same physical flash is recognized via .pos_device_id — no re-setup.
         */
        async function posFlashSidebarBind() {
            try {
                if (!posFlashAutoEnabled()) {
                    posFlashApplyAutoEnabled(true);
                }
                var handle = null;
                try { handle = await posFlashLoadDirHandle(); } catch (_eH) { handle = null; }

                if (handle) {
                    var okPerm = await posFlashEnsurePermission(handle, 'readwrite', true);
                    if (okPerm) {
                        try {
                            await posFlashProbeWritable(handle);
                            try {
                                var dir = await posFlashGetBackupsDir(handle, true);
                                await posFlashEnsureDeviceBinding(dir);
                                if (await posFlashShouldProtectWrite(dir)) {
                                    posFlashSetWriteProtect(true);
                                    _posFlashLastFail = 'protect';
                                    if (typeof showToast === 'function') {
                                        showToast('🛡️ فلاش چالاک — داتاکەی پارێزرا. گەڕاندنەوە بکە پێش نووسینەوە', 'warning');
                                    }
                                    posFlashUpdateSidebarStatus();
                                    posFlashStartAutoLoop();
                                    return { ok: true, mode: 'protected' };
                                }
                            } catch (_eBind2) {}
                            _posFlashLastFail = '';
                            posFlashSetWriteProtect(false);
                            posFlashNoteLiveOk();
                            if (typeof showToast === 'function') {
                                showToast('✅ فلاش ئامادەیە — کۆپی بەردەوام دەبێت', 'success');
                            }
                            posFlashUpdateSidebarStatus();
                            posFlashStartAutoLoop();
                            posFlashScheduleSync('sidebar_ok', 500);
                            return { ok: true, mode: 'reused' };
                        } catch (probeErr) {
                            if (posFlashIsStaleError(probeErr)) {
                                await posFlashForgetStaleHandle(true);
                            } else {
                                posFlashNoteLiveFail('disconnected');
                            }
                        }
                    }
                }

                var picked = await posPickFlashBackupFolder({ fromSidebar: true });
                return picked ? { ok: true, mode: 'picked' } : { ok: false, reason: 'cancelled' };
            } catch (err) {
                alert('بەستنەوەی فلاش سەرنەکەوت:\n' + (err && err.message ? err.message : err));
                return { ok: false, message: err && err.message ? err.message : String(err) };
            }
        }
        window.posFlashSidebarBind = posFlashSidebarBind;

        async function posClearFlashBackupFolder() {
            if (!confirm('فلاشی پاشەکەوت لاببرێت؟ (فایلەکان لەسەر فلاش نامرن — تەنها پەیوەندی POS دەپچڕێت)')) return;
            posFlashStopAutoLoop();
            await posFlashClearDirHandle({ keepIdentity: false });
            if (typeof showToast === 'function') showToast('فلاش لابرا', 'success');
            await posRefreshFlashBackupUi(true);
        }

        async function posCopyBackupBlobToFlash(blob, filename, opts) {
            opts = opts || {};
            if (!blob) return { ok: false, reason: 'no_blob' };
            // Automatic paths must respect ON/OFF; manual/force always allowed
            if (opts.auto && !opts.force && !posFlashAutoEnabled()) {
                return { ok: false, reason: 'auto_off' };
            }
            var interactive = opts.interactive !== false && !opts.silent;
            var lastErr = null;
            for (var attempt = 1; attempt <= 3; attempt++) {
                var ready = await posFlashGetWritable(interactive && attempt === 1);
                if (!ready.ok) {
                    lastErr = ready;
                    if (ready.reason === 'no_folder' || ready.reason === 'permission') break;
                    await new Promise(function (r) { setTimeout(r, 400 * attempt); });
                    continue;
                }
                try {
                    var safeName = posFlashSanitizeFileName(
                        opts.keepName ? filename : posFlashStableFileName(filename, opts.kind)
                    );
                    if (posFlashIsZipLikeName(safeName)) {
                        await posFlashAssertValidZipBlob(blob);
                        await posFlashWriteBlobAtomic(ready.dir, safeName, blob);
                    } else {
                        var fileHandle = await ready.dir.getFileHandle(safeName, { create: true });
                        var writable = await fileHandle.createWritable();
                        await writable.write(blob);
                        await writable.close();
                    }
                    var writtenCheck = await (await ready.dir.getFileHandle(safeName)).getFile();
                    if (!writtenCheck || writtenCheck.size < 64 || writtenCheck.size !== blob.size) {
                        throw new Error('فایل لسەر فلاش ناتەواوە — قەبارە نەچووە');
                    }
                    if (posFlashIsZipLikeName(safeName)) {
                        await posFlashAssertValidZipBlob(writtenCheck);
                    }
                    try { await posFlashCleanupCorruptZips(ready.dir); } catch (_eCorrupt) {}
                    if (!opts.keepName) {
                        try { await posFlashCleanupOldTimestamped(ready.dir); } catch (_eClean) {}
                    }
                    if (!opts.skipPrune) {
                        try { await posFlashPruneOldBackups(ready.dir, POS_FLASH_KEEP); } catch (_ePrune) {}
                    }
                    posFlashMarkLastOk();
                    if (!opts.silent && typeof showToast === 'function') {
                        showToast('💾 نوێکرایەوە لە فلاش: ' + safeName, 'success');
                    }
                    if (!opts.skipRefresh) {
                        try { await posRefreshFlashBackupUi(false); } catch (_eUi) {}
                    }
                    return { ok: true, name: safeName, folder: ready.folder || '', bytes: writtenCheck.size };
                } catch (err) {
                    lastErr = { ok: false, reason: 'write', message: (err && err.message) ? err.message : String(err) };
                    await new Promise(function (r) { setTimeout(r, 500 * attempt); });
                }
            }
            var phpFb = await posFlashCopyBlobViaPhp(blob, filename, opts.kind);
            if (phpFb && phpFb.ok) {
                posFlashMarkLastOk();
                return phpFb;
            }
            var fail = lastErr || phpFb || { ok: false, reason: 'write', message: 'flash write failed' };
            if (!opts.silent && fail.reason !== 'disconnected' && fail.reason !== 'stale' && typeof showToast === 'function') {
                var tip = fail.reason === 'permission'
                    ? 'مۆڵەت پێویستە — «هەڵبژاردنی فلاش» بکە'
                    : (fail.message || fail.reason);
                showToast('⚠️ فلاش: ' + tip, 'error');
            }
            return fail;
        }

        async function posFlashPruneOldBackups(dirHandle, keep) {
            keep = keep || POS_FLASH_KEEP;
            var entries = [];
            for await (var entry of dirHandle.values()) {
                if (entry.kind !== 'file') continue;
                var n = String(entry.name || '');
                var low = n.toLowerCase();
                if (low.indexOf('.zip') === -1 && low.indexOf('.posbak') === -1 && low.indexOf('.json') === -1) continue;
                if (
                    n.indexOf('Laptop_Duhok_POS') === -1
                    && n.indexOf('XAMPP_MySQL_Data') === -1
                    && n.indexOf('Backup_') !== 0
                    && n.indexOf('pos_backup_') === -1
                ) continue;
                try {
                    var f = await entry.getFile();
                    entries.push({ name: n, mtime: f.lastModified || 0, handle: entry });
                } catch (_eF) {}
            }
            entries.sort(function (a, b) { return b.mtime - a.mtime; });
            for (var i = keep; i < entries.length; i++) {
                try { await dirHandle.removeEntry(entries[i].name); } catch (_eRm) {}
            }
        }

        /** Delete old timestamped ZIPs; keep only *_Latest*.zip files. */
        async function posFlashCleanupOldTimestamped(dirHandle) {
            if (!dirHandle) return;
            var keepNames = {};
            keepNames[POS_FLASH_NAME_POS] = true;
            keepNames[POS_FLASH_NAME_POS_P1] = true;
            keepNames[POS_FLASH_NAME_POS_P2] = true;
            keepNames[POS_FLASH_NAME_MYSQL_FULL] = true;
            keepNames[POS_FLASH_NAME_MYSQL_DB] = true;
            keepNames[POS_FLASH_NAME_ITEMS] = true;
            for await (var entry of dirHandle.values()) {
                if (entry.kind !== 'file') continue;
                var n = String(entry.name || '');
                if (n.charAt(0) === '.') continue;
                var low = n.toLowerCase();
                if (low.indexOf('.zip') === -1 && low.indexOf('.posbak') === -1 && low.indexOf('.json') === -1) continue;
                if (keepNames[n]) continue;
                if (
                    n.indexOf('Laptop_Duhok_POS') === 0
                    || n.indexOf('XAMPP_MySQL_Data') === 0
                    || n.indexOf('Backup_') === 0
                    || n.indexOf('pos_backup_') === 0
                ) {
                    try { await dirHandle.removeEntry(n); } catch (_eDel) {}
                }
            }
        }

        async function posListFlashBackups() {
            var handle = await posFlashLoadDirHandle();
            if (!handle) return { ok: false, reason: 'no_folder', files: [] };
            var okPerm = await posFlashEnsurePermission(handle, 'read', false);
            if (!okPerm) okPerm = await posFlashEnsurePermission(handle, 'readwrite', false);
            if (!okPerm) return { ok: false, reason: 'permission', files: [], folder: handle.name || '' };
            var dir;
            try {
                dir = await posFlashGetBackupsDir(handle, false);
            } catch (eDir) {
                if (posFlashIsStaleError(eDir)) {
                    posFlashNoteLiveFail('stale', { alert: false });
                    return { ok: false, reason: 'stale', files: [], folder: handle.name || '' };
                }
                return { ok: true, files: [], folder: handle.name || '', emptySub: true };
            }
            var files = [];
            try {
                // Drop half-written / corrupt ZIPs that trigger Windows "Multi-Volume set"
                try {
                    var canWrite = await posFlashEnsurePermission(handle, 'readwrite', false);
                    if (canWrite) await posFlashCleanupCorruptZips(dir);
                } catch (_eCleanList) {}
                for await (var entry of dir.values()) {
                    if (entry.kind !== 'file') continue;
                    var n = String(entry.name || '');
                    if (n.charAt(0) === '.') continue;
                    var low = n.toLowerCase();
                    if (low.endsWith('.tmp') || low.endsWith('.partial')) continue;
                    if (low.indexOf('.zip') === -1 && low.indexOf('.posbak') === -1 && low.indexOf('.json') === -1) continue;
                    try {
                        var f = await entry.getFile();
                        files.push({ name: n, bytes: f.size || 0, mtime: f.lastModified || 0 });
                    } catch (_eGet) {}
                }
            } catch (eIter) {
                if (posFlashIsStaleError(eIter)) {
                    posFlashNoteLiveFail('stale', { alert: false });
                    return { ok: false, reason: 'stale', files: [], folder: handle.name || '' };
                }
                return { ok: false, reason: 'disconnected', files: [], folder: handle.name || '' };
            }
            files.sort(function (a, b) { return b.mtime - a.mtime; });
            return { ok: true, files: files, folder: handle.name || '' };
        }

        var _posFlashRefreshBusy = false;
        async function posRefreshFlashBackupUi(forceList) {
            if (_posFlashRefreshBusy) return;
            _posFlashRefreshBusy = true;
            try {
            var statusEl = document.getElementById('flash-backup-status');
            var listEl = document.getElementById('flash-backups-list');
            posFlashUpdateAutoOnOffUi();
            var autoEl = document.getElementById('flash-auto-toggle');
            if (autoEl) autoEl.checked = posFlashAutoEnabled();
            var savedName = '';
            try { savedName = localStorage.getItem(POS_FLASH_NAME_KEY) || ''; } catch (_eN) {}
            var listed = null;
            try {
                listed = await posListFlashBackups();
            } catch (_eList) {
                listed = { ok: false, reason: 'error', files: [] };
            }
            var lastOk = posFlashLastOkLabel();
            if (statusEl) {
                if (!listed || listed.reason === 'no_folder') {
                    statusEl.textContent = 'هێشتا فلاش هەڵنەبژێردراوە — کلیک «هەڵبژاردنی فلاش»';
                    statusEl.style.color = '#94a3b8';
                } else if (listed.reason === 'permission') {
                    statusEl.textContent = 'فلاش: ' + (listed.folder || savedName || '…') + ' — کلیک «چالاککردنەوە» یان دووبارە هەڵبژێرە'
                        + (lastOk ? (' · دوایین سەرکەوت: ' + lastOk) : '');
                    statusEl.style.color = '#fbbf24';
                } else if (listed.reason === 'disconnected' || listed.reason === 'stale') {
                    statusEl.textContent = 'فلاش نەدۆزرایەوە یان گۆڕا — دایبەستەوە و «هەڵبژاردنی فلاش» بکە'
                        + (lastOk ? (' · دوایین سەرکەوت: ' + lastOk) : '');
                    statusEl.style.color = '#f87171';
                } else {
                    statusEl.textContent = (posFlashAutoEnabled() ? '✅ فلاش ئامادەیە · ئۆتۆماتیک ON' : '✅ فلاش ئامادەیە · ئۆتۆماتیک OFF')
                        + ': ' + (listed.folder || savedName || 'USB') + ' / ' + POS_FLASH_SUBDIR
                        + (listed.files && listed.files.length ? (' · ' + listed.files.length + ' فایل') : '')
                        + (function () {
                            var vrf = posFlashLoadLastVerify();
                            if (vrf && vrf.bytes) {
                                var mb = vrf.bytes / (1024 * 1024);
                                var sz = mb >= 1 ? (mb.toFixed(1) + ' MB') : (Math.max(1, Math.round(vrf.bytes / 1024)) + ' KB');
                                var rowsTxt = vrf.rows ? (' · ' + Number(vrf.rows).toLocaleString('en-US') + ' ڕیز') : '';
                                return ' · پشتڕاست: ' + sz + rowsTxt;
                            }
                            return lastOk ? (' · دوایین: ' + lastOk) : '';
                        })();
                    statusEl.style.color = posFlashAutoEnabled() ? '#86efac' : '#93c5fd';
                }
            }
            if (!listEl) return;
            if (!listed || listed.reason === 'no_folder') {
                listEl.innerHTML = '<span class="pos-db-local-muted">دوای هەڵبژاردنی فلاش، لیستی بک‌ئەپ لێرە دەردەکەوێت</span>';
                return;
            }
            if (listed.reason === 'permission' || listed.reason === 'disconnected' || listed.reason === 'stale') {
                listEl.innerHTML = '<span class="pos-db-local-muted">فلاش ئامادە نییە — دایبەستە / «هەڵبژاردنی فلاش» بکە</span>';
                return;
            }
            if (!listed.files || !listed.files.length) {
                listEl.innerHTML = '<span class="pos-db-local-muted">هێشتا بک‌ئەپ لەسەر فلاش نییە — «هەموو داتا بۆ فلاش» بکە</span>';
                return;
            }
            var html = '';
            listed.files.slice(0, 25).forEach(function (b) {
                var name = String(b.name || '').replace(/"/g, '&quot;');
                var when = b.mtime ? new Date(b.mtime).toISOString().slice(0, 19).replace('T', ' ') : '';
                var isMysqlData = name.indexOf('XAMPP_MySQL_Data') === 0;
                var restoreFn = isMysqlData ? 'posRestoreMysqlDataFromFlash' : 'posRestoreFromFlashFile';
                var btnLabel = isMysqlData ? 'data→XAMPP' : 'گەڕاندنەوە';
                html += '<div class="pos-db-local-row">';
                html += '<div class="pos-db-local-meta"><span class="pos-db-local-name">' + (isMysqlData ? '🗄️ ' : '') + name + '</span>';
                html += '<span class="pos-db-local-sub">' + when + ' · ' + posFormatBackupBytes(b.bytes) + (isMysqlData ? ' · mysql/data' : '') + '</span></div>';
                html += '<button type="button" class="btn btn-sm btn-danger" onclick="' + restoreFn + '(\'' + name.replace(/'/g, "\\'") + '\')"><i class="fas fa-undo"></i> ' + btnLabel + '</button>';
                html += '</div>';
            });
            listEl.innerHTML = html;
            } finally {
                _posFlashRefreshBusy = false;
            }
        }

        async function posReactivateFlashPermission() {
            var handle = await posFlashLoadDirHandle();
            if (!handle) {
                return posPickFlashBackupFolder();
            }
            var ok = await posFlashEnsurePermission(handle, 'readwrite', true);
            if (!ok) {
                alert('مۆڵەت نەدرا — دووبارە فۆڵدەری فلاش هەڵبژێرە.');
                return posPickFlashBackupFolder();
            }
            var ready = await posFlashGetWritable(true);
            if (!ready.ok) {
                alert('فلاش نەدۆزرایەوە — دایبەستەوە و دووبارە هەڵبژێرە.');
                return posPickFlashBackupFolder();
            }
            if (typeof showToast === 'function') showToast('✅ فلاش چالاک بووەوە', 'success');
            try {
                await posFlashEnsureDeviceBinding(ready.dir);
            } catch (_eBindR) {}
            try { await posFlashSanitizeAll({ interactive: false }); } catch (_eSan) {}
            await posRefreshFlashBackupUi(true);
            posFlashStartAutoLoop();
            // Nudge a deep sync on reactivation if it's been a while (> 1 hour)
            var lastFull = 0;
            try { lastFull = parseInt(localStorage.getItem(POS_FLASH_LAST_FULL_KEY) || '0', 10); } catch (_eF) {}
            if (!lastFull || (Date.now() - lastFull) > 3600000) {
                posFlashScheduleSync('reactivate_full', 1500);
            } else {
                posFlashScheduleSync('reactivate', 500);
            }
            return handle;
        }

        function posFlashGetFflate() {
            var f = (typeof window !== 'undefined') ? window.fflate : null;
            if (!f || typeof f.unzipSync !== 'function') {
                throw new Error('کتێبخانەی fflate نەدۆزرایەوە — پەڕە Refresh بکە');
            }
            return f;
        }

        /**
         * Chrome File System Access rejects some names (#innodb_*, .cnf/.pem/.ini, …).
         * Encode for write; decode when restoring back to MySQL.
         */
        function posFlashEncodeFsSegment(name) {
            var s = String(name || '');
            if (!s) return '_empty_';
            s = s.replace(/#/g, '__HASH__');
            // Dangerous / blocked extensions in Chromium FS Access
            if (/\.(cnf|cfg|ini|pem|crt|key|exe|dll|bat|cmd|com|msi|scr|ps1|vbs|js|jar|lnk|reg|inf|sys|drv)$/i.test(s)) {
                s = s + '.possafe';
            }
            s = s.replace(/[<>:"|?*\x00-\x1f]/g, '_');
            s = s.replace(/[\. ]+$/g, '');
            if (!s || s === '.' || s === '..') s = '_empty_';
            if (/^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(\.|$)/i.test(s)) {
                s = '_' + s;
            }
            return s;
        }

        function posFlashDecodeFsSegment(name) {
            var s = String(name || '');
            if (/\.possafe$/i.test(s)) s = s.replace(/\.possafe$/i, '');
            s = s.replace(/__HASH__/g, '#');
            if (s.indexOf('_empty_') === 0 && s.length === 7) s = '';
            return s;
        }

        function posFlashEncodeRelativePath(relativePath) {
            return String(relativePath || '')
                .replace(/\\/g, '/')
                .split('/')
                .filter(function (p) { return p && p !== '.' && p !== '..'; })
                .map(posFlashEncodeFsSegment)
                .join('/');
        }

        function posFlashDecodeRelativePath(relativePath) {
            return String(relativePath || '')
                .replace(/\\/g, '/')
                .split('/')
                .filter(Boolean)
                .map(posFlashDecodeFsSegment)
                .filter(function (p) { return p !== ''; })
                .join('/');
        }

        async function posFlashWriteRelativeFile(rootDir, relativePath, dataUint8) {
            var encoded = posFlashEncodeRelativePath(relativePath);
            var parts = encoded.split('/').filter(Boolean);
            if (!parts.length) return { ok: false, reason: 'empty' };
            var fileName = parts.pop();
            var dir = rootDir;
            for (var i = 0; i < parts.length; i++) {
                dir = await dir.getDirectoryHandle(parts[i], { create: true });
            }
            var fh = await dir.getFileHandle(fileName, { create: true });
            var w = await fh.createWritable();
            try {
                await w.write(dataUint8);
                await w.close();
            } catch (err) {
                try { await w.abort(); } catch (_eAb) {}
                throw err;
            }
            return { ok: true, encoded: encoded };
        }

        async function posFlashClearSubdir(parentDir, name) {
            try {
                await parentDir.removeEntry(name, { recursive: true });
            } catch (_eRm) {
                try { await parentDir.removeEntry(name); } catch (_eRm2) {}
            }
        }

        /**
         * Unpack ZIP blob onto flash as real folders:
         *   data/  = XAMPP mysql/data contents (easy manual restore)
         *   sql/   = full_backup.json + README
         */
        async function posFlashWriteEasyFolders(backupsDir, zipBlob, mode) {
            mode = mode || 'all';
            var fflate = posFlashGetFflate();
            var buf = new Uint8Array(await zipBlob.arrayBuffer());
            var files = fflate.unzipSync(buf);
            var written = 0;
            var skipped = 0;
            var nameMap = {};

            if (mode === 'mysql' || mode === 'all') {
                await posFlashClearSubdir(backupsDir, 'data');
                var dataDir = await backupsDir.getDirectoryHandle('data', { create: true });
                var keys = Object.keys(files);
                for (var i = 0; i < keys.length; i++) {
                    var path = keys[i];
                    var payload = files[path];
                    if (!payload || !payload.length) continue;
                    var rel = String(path).replace(/\\/g, '/');
                    if (rel === 'mysql_data_manifest.json') {
                        try {
                            await posFlashWriteRelativeFile(dataDir, '_pos_mysql_manifest.json', payload);
                            written++;
                        } catch (_eMan) { skipped++; }
                        continue;
                    }
                    if (rel.indexOf('mysql_data/') !== 0) continue;
                    rel = rel.slice('mysql_data/'.length);
                    if (!rel || rel.endsWith('/')) continue;
                    try {
                        var enc = posFlashEncodeRelativePath(rel);
                        if (enc !== rel) nameMap[enc] = rel;
                        await posFlashWriteRelativeFile(dataDir, rel, payload);
                        written++;
                    } catch (_eFile) {
                        skipped++;
                        console.warn('[flash data skip]', rel, _eFile && _eFile.message);
                    }
                }
                try {
                    var mapJson = fflate.strToU8(JSON.stringify({
                        format: 'pos_flash_name_map_v1',
                        map: nameMap,
                        written: written,
                        skipped: skipped,
                        at: new Date().toISOString()
                    }, null, 0));
                    await posFlashWriteRelativeFile(dataDir, '_pos_name_map.json', mapJson);
                } catch (_eMap) {}
            }

            if (mode === 'pos' || mode === 'all') {
                await posFlashClearSubdir(backupsDir, 'sql');
                var sqlDir = await backupsDir.getDirectoryHandle('sql', { create: true });
                var keys2 = Object.keys(files);
                for (var j = 0; j < keys2.length; j++) {
                    var p2 = String(keys2[j]).replace(/\\/g, '/');
                    var body = files[keys2[j]];
                    if (!body || !body.length) continue;
                    try {
                        if (p2 === 'database/full_backup.json' || p2.endsWith('/full_backup.json')) {
                            await posFlashWriteRelativeFile(sqlDir, 'full_backup.json', body);
                            written++;
                        } else if (p2 === 'manifest.json') {
                            await posFlashWriteRelativeFile(sqlDir, 'manifest.json', body);
                            written++;
                        }
                    } catch (_eSqlF) { skipped++; }
                }
                var readme = [
                    'Laptop Duhok POS — گەڕاندنەوە',
                    '',
                    '=== ڕێگای ئاسان (بێ Stop MySQL) ===',
                    'لە POS → «گەڕاندنەوە لە فلاش (sql) — بێ Stop MySQL»',
                    '',
                    '=== فۆڵدەری data ===',
                    'پاراستنی زیادە. گەڕاندنەوە لە POS یان دوای Stop MySQL.',
                    '',
                    'بەروار: ' + new Date().toLocaleString()
                ].join('\n');
                try {
                    await posFlashWriteRelativeFile(sqlDir, 'README_RESTORE.txt', fflate.strToU8(readme));
                    written++;
                } catch (_eReadme) { skipped++; }
            }

            return { ok: true, files: written, skipped: skipped };
        }

        async function posFlashCollectDirFiles(dirHandle, prefix) {
            var out = {};
            for await (var entry of dirHandle.values()) {
                var name = String(entry.name || '');
                if (!name || name.charAt(0) === '.') continue;
                if (name === '_pos_name_map.json' || name === '_pos_mysql_manifest.json') {
                    // handled separately
                    if (entry.kind === 'file') {
                        var metaFile = await entry.getFile();
                        out['__meta__/' + name] = new Uint8Array(await metaFile.arrayBuffer());
                    }
                    continue;
                }
                var decodedName = posFlashDecodeFsSegment(name);
                var rel = prefix ? (prefix + '/' + decodedName) : decodedName;
                if (entry.kind === 'directory') {
                    var sub = await posFlashCollectDirFiles(entry, rel);
                    Object.keys(sub).forEach(function (k) { out[k] = sub[k]; });
                } else {
                    var file = await entry.getFile();
                    out[rel] = new Uint8Array(await file.arrayBuffer());
                }
            }
            return out;
        }

        /** Zip flash/data folder → restore into XAMPP mysql/data via existing API. */
        async function posRestoreMysqlDataFromFlashFolder() {
            var tr = (typeof t === 'function') ? t : function () { return ''; };
            if (typeof posConfirmDataRestore === 'function') {
                var ok0 = await posConfirmDataRestore({
                    source: tr('confirm_data_restore_source_flash') || 'گەڕاندنەوە لە فلاش / data',
                    detail: 'فۆڵدەری data لە USB → XAMPP mysql/data\n١) XAMPP → Stop MySQL'
                });
                if (!ok0) return;
            }
            var ready = await posFlashGetWritable(true);
            if (!ready.ok) {
                alert('فلاش ئامادە نییە — هەڵبژێرە / چالاککردنەوە.');
                return;
            }
            var dataDir;
            try {
                dataDir = await ready.dir.getDirectoryHandle('data', { create: false });
            } catch (_eNo) {
                alert('فۆڵدەری data لەسەر فلاش نییە.\nسەرەتا «data → فلاش» یان «هەموو داتا بۆ فلاش» بکە.');
                return;
            }
            var typed = prompt(
                '⚠️ گەڕاندنەوە لە فۆڵدەری فلاش / data\n\n١) XAMPP → Stop MySQL\n٢) بنووسە: STOP_MYSQL',
                ''
            );
            if (typed !== 'STOP_MYSQL') {
                alert('هەڵوەشایەوە — دەبێت STOP_MYSQL بنووسیت.');
                return;
            }
            var indicator = document.getElementById('save-indicator');
            if (indicator) {
                indicator.style.display = 'block';
                indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> خوێندنەوەی فۆڵدەری data…';
            }
            try {
                var fflate = posFlashGetFflate();
                var tree = await posFlashCollectDirFiles(dataDir, '');
                var zipMap = {};
                Object.keys(tree).forEach(function (rel) {
                    if (rel.indexOf('__meta__/') === 0) {
                        var metaName = rel.slice('__meta__/'.length);
                        if (metaName === '_pos_mysql_manifest.json') {
                            zipMap['mysql_data_manifest.json'] = tree[rel];
                        }
                        return;
                    }
                    zipMap['mysql_data/' + rel] = tree[rel];
                });
                if (!Object.keys(zipMap).filter(function (k) { return k.indexOf('mysql_data/') === 0; }).length) {
                    throw new Error('فۆڵدەری data بەتاڵە');
                }
                if (!zipMap['mysql_data_manifest.json']) {
                    zipMap['mysql_data_manifest.json'] = fflate.strToU8(JSON.stringify({
                        format: 'xampp_mysql_data_v1',
                        scope: 'full',
                        created_at: new Date().toISOString(),
                        note: 'Restored from flash/data folder'
                    }));
                }
                var zipped = fflate.zipSync(zipMap, { level: 0 });
                var blob = new Blob([zipped], { type: 'application/zip' });
                await posPostMysqlDataRestore(blob, 'XAMPP_MySQL_Data_FROM_FLASH_FOLDER.zip', {
                    alreadyConfirmed: true,
                    force: '1'
                });
            } catch (err) {
                if (indicator) indicator.style.display = 'none';
                alert('❌ گەڕاندنەوە لە فۆڵدەری data سەرنەکەوت:\n' + (err && err.message ? err.message : err));
            }
        }
        window.posRestoreMysqlDataFromFlashFolder = posRestoreMysqlDataFromFlashFolder;

        /**
         * Read delta/changes.jsonl from flash (continuous sync after last full snapshot).
         */
        async function posFlashReadDeltaJsonl(backupsDir) {
            try {
                var deltaDir = await posFlashGetDeltaDir(backupsDir, false);
                if (!deltaDir) return '';
                var fh = await deltaDir.getFileHandle(POS_FLASH_DELTA_FILE);
                var file = await fh.getFile();
                if (!file || file.size < 2) return '';
                return await file.text();
            } catch (_e) {
                return '';
            }
        }

        /** Apply flash deltas after full restore — brings back latest sales/stock. */
        async function posFlashApplyDeltaAfterRestore(backupsDir, indicator) {
            var raw = await posFlashReadDeltaJsonl(backupsDir);
            if (!raw || !String(raw).trim()) {
                return { ok: true, rows: 0, skipped: true };
            }
            if (indicator) {
                indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> گەڕاندنەوەی دوایین داتا (delta)…';
            }
            var formData = new FormData();
            formData.append('action', 'apply_flash_delta');
            formData.append('file', new Blob([raw], { type: 'application/x-ndjson' }), 'changes.jsonl');
            var res = await fetch('?action=apply_flash_delta', { method: 'POST', body: formData, credentials: 'same-origin' });
            var text = (await res.text() || '').trim();
            if (!text) throw new Error('وەڵامی delta بەتاڵە');
            var data = JSON.parse(text);
            if (!data || data.status !== 'success') {
                throw new Error((data && data.message) ? data.message : 'delta apply failed');
            }
            return { ok: true, rows: parseInt(data.rows, 10) || 0, chunks: parseInt(data.applied_chunks, 10) || 0 };
        }

        /**
         * Primary restore from flash — full snapshot + continuous deltas (latest sales).
         * MySQL stays RUNNING — no Stop MySQL required.
         */
        async function posRestoreFromFlashSqlEasy() {
            var ready = await posFlashGetWritable(true);
            if (!ready.ok) {
                alert('فلاش ئامادە نییە — هەڵبژێرە / چالاککردنەوە.');
                return;
            }
            var currencyEl = document.getElementById('restore-currency-choice');
            var forceCurrency = (currencyEl && currencyEl.value === 'USD') ? 'USD' : 'IQD';
            var currLabel = forceCurrency === 'USD' ? 'دولار ($)' : 'دینار عێراقی (IQD)';
            var tr = (typeof t === 'function') ? t : function () { return ''; };
            if (typeof posConfirmDataRestore === 'function') {
                var okFlash = await posConfirmDataRestore({
                    source: tr('confirm_data_restore_source_flash') || 'گەڕاندنەوە لە فلاش (sql)',
                    detail: 'MySQL وەک خۆی دەمێنێتەوە — Stop MySQL پێویست نییە.\nfull_backup.json + delta',
                    currencyLabel: currLabel
                });
                if (!okFlash) return;
            } else if (!confirm(
                '✅ گەڕاندنەوە لە فلاش (هەموو داتا + دوایین فرۆشتن)\n\n'
                + 'MySQL وەک خۆی دەمێنێتەوە — Stop MySQL پێویست نییە.\n\n'
                + 'هەموو داتای ئێستا دەگۆڕدرێت.\nدراڤ: ' + currLabel + '\n\nبەردەوام بیت؟'
            )) return;

            var file = null;
            var uploadName = String(POS_FLASH_NAME_POS);
            // Prefer Latest.posbak — that is what auto/one-click actually writes and verifies.
            try {
                var bakFh = await ready.dir.getFileHandle(POS_FLASH_NAME_POS);
                file = await bakFh.getFile();
            } catch (_eBakFirst) {
                file = null;
            }
            if (!file || file.size < 32) {
                try {
                    var sqlDir = await ready.dir.getDirectoryHandle('sql', { create: false });
                    var fh = await sqlDir.getFileHandle('full_backup.json');
                    file = await fh.getFile();
                    uploadName = 'full_backup.json';
                } catch (_eSql) {
                    file = null;
                }
            }
            if (!file || file.size < 32) {
                alert('لەسەر فلاش ' + POS_FLASH_NAME_POS + ' نەدۆزرایەوە.\nسەرەتا «ناردن بۆ فلاش ئێستا» بکە.');
                return;
            }

            var formData = new FormData();
            formData.append('action', 'restore_backup');
            formData.append('file', file, uploadName);
            formData.append('force_currency', forceCurrency);

            var indicator = document.getElementById('save-indicator');
            if (indicator) {
                indicator.style.display = 'block';
                indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ١/٢ گەڕاندنەوەی بنەڕەت…';
            }
            try {
                var res = await fetch('?action=restore_backup', { method: 'POST', body: formData, credentials: 'same-origin' });
                var text = (await res.text() || '').trim();
                if (!text) throw new Error('وەڵامی سێرڤەر بەتاڵە');
                var data = JSON.parse(text);
                if (data.status !== 'success') {
                    if (indicator) indicator.style.display = 'none';
                    alert('❌ ' + (data.message || 'error'));
                    return;
                }

                var deltaInfo = { rows: 0 };
                try {
                    deltaInfo = await posFlashApplyDeltaAfterRestore(ready.dir, indicator);
                } catch (deltaErr) {
                    console.warn('[flash restore delta]', deltaErr);
                    if (indicator) indicator.style.display = 'none';
                    alert(
                        '⚠️ باک‌ئەپی سەرەکی گەڕایەوە، بەڵام دوایین داتا (delta) سەرنەکەوت:\n'
                        + (deltaErr && deltaErr.message ? deltaErr.message : deltaErr)
                        + '\n\nدووبارە هەوڵ بدە یان «هەموو داتا بۆ فلاش» بکە پێش گەڕاندنەوە.'
                    );
                    return;
                }

                // Align local flash cursor with restored DB so auto-sync continues cleanly
                try {
                    localStorage.removeItem(POS_FLASH_DELTA_WM_KEY);
                    var initRes = await fetch('?action=export_flash_delta&init=1', { credentials: 'same-origin' });
                    var initData = await initRes.json();
                    if (initData && initData.status === 'success' && initData.delta && initData.delta.watermarks) {
                        var wm = initData.delta.watermarks;
                        wm._ready = 1;
                        posFlashSaveLocalWatermark(wm);
                        await posFlashWriteWatermarkToFlash(ready.dir, wm);
                        await posFlashClearDeltaLog(ready.dir);
                    }
                } catch (_eWm) {}

                // Restore done — flash and PC match; allow writing again
                posFlashSetWriteProtect(false);
                _posFlashLastFail = '';

                if (indicator) indicator.innerHTML = '<i class="fas fa-check"></i> گەڕایەوە — ڕیفرێش…';
                if (typeof showToast === 'function') {
                    var extra = (deltaInfo && deltaInfo.rows)
                        ? (' + ' + deltaInfo.rows + ' داتای نوێ')
                        : '';
                    showToast('✅ لە فلاش گەڕایەوە' + extra + ' (MySQL وەستاو نەبوو)', 'success');
                }
                Object.keys(localStorage).forEach(function (key) {
                    if (key.startsWith('pos_tabs_state_')) localStorage.removeItem(key);
                });
                setTimeout(function () { location.reload(); }, 1500);
            } catch (err) {
                if (indicator) indicator.style.display = 'none';
                alert('❌ گەڕاندنەوە سەرنەکەوت:\n' + (err && err.message ? err.message : err));
            }
        }
        window.posRestoreFromFlashSqlEasy = posRestoreFromFlashSqlEasy;
        window.posFlashApplyDeltaAfterRestore = posFlashApplyDeltaAfterRestore;

        /** Full sync: POS ZIP + mysql/data → flash folders data/ + sql/ (+ .posbak). */
        async function posSyncAllToFlash(opts) {
            opts = opts || {};
            if (opts.auto && !opts.force && !posFlashAutoEnabled()) {
                return { ok: false, reason: 'auto_off' };
            }
            if (_posFlashAutoBusy) {
                _posFlashPendingRetry = true;
                return { ok: false, reason: 'busy' };
            }
            posFlashBeginBusy(opts.auto ? POS_FLASH_BUSY_FULL_MS : POS_FLASH_BUSY_FULL_MS);
            var busyGenFull = _posFlashBusyGen;
            var showUi = !(opts.silent || opts.auto);
            var indicator = showUi ? document.getElementById('save-indicator') : null;
            try {
                var ready = await posFlashGetWritable(!!opts.interactive);
                if (!ready.ok) {
                    if (opts.interactive) {
                        await posReactivateFlashPermission();
                        ready = await posFlashGetWritable(true);
                    }
                    if (!ready.ok) {
                        if (showUi) {
                            alert('فلاش ئامادە نییە: ' + (ready.reason === 'permission' ? 'مۆڵەت' : (ready.reason === 'disconnected' ? 'فلاش دەربێنراوە' : 'هەڵبژێرە')));
                        }
                        return ready;
                    }
                }

                var guard = await posFlashGuardOverwrite(ready.dir, {
                    interactive: false,
                    force: !!opts.force,
                    allowDestroy: !!opts.allowDestroy
                });
                if (!guard.ok) {
                    if (showUi) {
                        var wipeAnyway = confirm(
                            '🛡️ فلاش داتای زیاتری تێدایە لەم سیستەمە.\n\n'
                            + 'نووسینەوە = داتای فلاش دەفەوتێت!\n\n'
                            + 'OK = بەڵێ بسڕەوە و داتای ئێستا بنووسە\n'
                            + 'Cancel = هەڵوەشاندن (فلاش وەک خۆی)'
                        );
                        if (!wipeAnyway) return guard;
                        // User explicitly chose to overwrite
                    } else {
                        _posFlashLastFail = 'protect';
                        posFlashUpdateSidebarStatus();
                        return guard;
                    }
                }

                if (!opts.quietConfirm && showUi) {
                    var tr = (typeof t === 'function') ? t : function () { return ''; };
                    var msg = tr('modal_db_flash_full_confirm') || 'هەموو داتا (ZIP + mysql/data) بۆ فلاش؟\n\nبەردەوام دەبێت بێ کێشە کاتێک فلاش بەستراوە.';
                    if (!confirm(msg)) {
                        return { ok: false, reason: 'cancelled' };
                    }
                }
                // Starting a full sync clears the dirty flag; sales during sync re-set it
                _posFlashDirty = false;
                if (indicator) {
                    indicator.style.display = 'block';
                    indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ناردنی هەموو داتا بۆ فلاش…';
                }
                await posFlushBeforeBackup();

                // 1) App ZIP backup
                var actionName = ['export', 'full', 'backup'].join('_');
                var saveLocalFull = (opts.auto || opts.silent) ? '0' : '1';
                var res = await fetch('?action=' + actionName + '&zip=1&download=1&save_local=' + saveLocalFull + '&for_flash=1', { credentials: 'same-origin' });
                if (!res.ok) throw new Error(await posFlashFetchErrorMessage(res));
                var filename = 'Laptop_Duhok_POS_Backup_' + new Date().toISOString().slice(0, 10) + '.posbak';
                var disp = res.headers.get('Content-Disposition');
                if (disp && disp.indexOf('filename=') !== -1) {
                    filename = disp.split('filename=')[1].replace(/['"]/g, '');
                }
                var blob = await posAssertBackupZipResponse(res, await res.blob());
                var flash1 = await posCopyBackupBlobToFlash(blob, filename, { silent: true, interactive: false, skipRefresh: true, force: true, kind: 'pos' });
                if (!flash1.ok) throw new Error(flash1.message || flash1.reason || 'ZIP→فلاش');
                // Easy restore folders: sql/full_backup.json (skip on auto / huge — .posbak is authoritative)
                if (!opts.auto && blob.size < 40 * 1024 * 1024) {
                    try {
                        if (indicator) indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> sql/ → فلاش…';
                        await posFlashWriteEasyFolders(ready.dir, blob, 'pos');
                    } catch (_eSqlFold) {
                        console.warn('[flash sql folder]', _eSqlFold);
                    }
                }

                // 2) Raw mysql/data (same as live XAMPP folder snapshot)
                // Auto: DB folder only (smaller, reliable). Manual: full mysql/data.
                if (indicator) indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> mysql/data → فلاش…';
                var mysqlScope = (opts.auto && !opts.forceFullMysql) ? 'db' : 'full';
                var mysqlOk = false;
                var mysqlWarn = '';
                try {
                    var res2 = await fetch(
                        '?action=export_mysql_data_backup&scope=' + encodeURIComponent(mysqlScope) + '&save_local=' + saveLocalFull + '&download=1&for_flash=1',
                        { credentials: 'same-origin' }
                    );
                    if (!res2.ok) throw new Error(await posFlashFetchErrorMessage(res2));
                    var ct2 = res2.headers.get('Content-Type') || '';
                    if (ct2.indexOf('json') !== -1 && ct2.indexOf('zip') === -1) {
                        throw new Error(await posFlashFetchErrorMessage(res2));
                    }
                    var fname2 = mysqlScope === 'db' ? POS_FLASH_NAME_MYSQL_DB : POS_FLASH_NAME_MYSQL_FULL;
                    var blob2 = await res2.blob();
                    if (!blob2 || blob2.size < 64) throw new Error('mysql/data ZIP بەتاڵە');
                    var flash2 = await posCopyBackupBlobToFlash(blob2, fname2, { silent: true, interactive: false, skipRefresh: true, force: true, kind: mysqlScope === 'db' ? 'mysql_db' : 'mysql_full' });
                    if (!flash2.ok) throw new Error(flash2.message || flash2.reason || 'data→فلاش');
                    mysqlOk = true;
                    // Easy restore folder: skip huge browser unzip on auto / big archives (causes hang/OOM)
                    var skipMysqlFolder = !!opts.auto || (blob2.size > 80 * 1024 * 1024);
                    if (!skipMysqlFolder) {
                        if (indicator) indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> فۆڵدەری data/ → فلاش…';
                        try {
                            await posFlashWriteEasyFolders(ready.dir, blob2, 'mysql');
                        } catch (eDataFold) {
                            console.warn('[flash data folder]', eDataFold);
                            mysqlWarn = 'ZIP پاراسترا — فۆڵدەری data سەرکەوتوو نەبوو (گەڕاندنەوە لە .posbak)';
                        }
                    }
                } catch (eMysql) {
                    console.warn('[flash mysql]', eMysql);
                    mysqlWarn = (eMysql && eMysql.message) ? String(eMysql.message) : String(eMysql);
                    // POS ZIP already on flash — do not fail the whole sync
                    if (!opts.auto && showUi) {
                        // keep going; show partial success below
                    }
                }
                if (showUi) {
                    try { await posRefreshFlashBackupUi(false); } catch (_eUi2) {}
                }

                // After full snapshot: reset incremental cursor + clear delta log
                try {
                    var initRes = await fetch('?action=export_flash_delta&init=1', { credentials: 'same-origin' });
                    var initData = await initRes.json();
                    if (initData && initData.status === 'success' && initData.delta && initData.delta.watermarks) {
                        var wm = initData.delta.watermarks;
                        wm._ready = 1;
                        posFlashSaveLocalWatermark(wm);
                        await posFlashWriteWatermarkToFlash(ready.dir, wm);
                        await posFlashClearDeltaLog(ready.dir);
                    }
                } catch (_eWm) {}

                posFlashMarkLastFull();
                try {
                    var metaFull = posFlashBuildLocalMeta();
                    metaFull.bytes = (blob && blob.size) || 0;
                    metaFull.mysql = !!mysqlOk;
                    await posFlashWriteMeta(ready.dir, metaFull);
                } catch (_eMetaF) {}
                posFlashSetWriteProtect(false);
                _posFlashLastFail = mysqlOk ? '' : 'mysql_partial';
                if (typeof loadLocalBackupsList === 'function') loadLocalBackupsList();
                if (indicator) {
                    indicator.innerHTML = mysqlOk
                        ? '<i class="fas fa-check"></i> هەموو داتا لە فلاش پاراسترا'
                        : '<i class="fas fa-check"></i> ZIP لە فلاش — mysql نیمچە';
                    setTimeout(function () { indicator.style.display = 'none'; }, 2500);
                }
                if (showUi && typeof showToast === 'function') {
                    if (mysqlOk && !mysqlWarn) showToast('✅ فلاش: ZIP + mysql/data تەواو', 'success');
                    else if (mysqlOk) showToast('✅ فلاش: ZIP تەواو · ' + mysqlWarn, 'warning');
                    else showToast('⚠️ فلاش: ZIP پاراسترا — mysql: ' + (mysqlWarn || 'هەڵە'), 'warning');
                }
                if (showUi && !mysqlOk && mysqlWarn) {
                    alert('⚠️ ZIP ی POS چووە سەر فلاش.\n\nmysql/data سەرکەوتوو نەبوو:\n' + mysqlWarn);
                }
                return { ok: true, mode: 'full', mysql: mysqlOk, mysqlWarn: mysqlWarn || '' };
            } catch (err) {
                if (indicator) {
                    indicator.innerHTML = '<i class="fas fa-times"></i> فلاش';
                    setTimeout(function () { indicator.style.display = 'none'; }, 3000);
                }
                if (showUi) {
                    alert(posFlashSimpleFailHelp());
                }
                return { ok: false, message: err && err.message ? err.message : String(err) };
            } finally {
                posFlashEndBusy(busyGenFull);
                if (posFlashAutoEnabled() && (_posFlashDirty || _posFlashPendingRetry)) {
                    _posFlashPendingRetry = false;
                    posFlashScheduleSync('after_sync', Math.min(POS_FLASH_DEBOUNCE_MS, 15000));
                }
            }
        }

        async function posFlashAutoTick() {
            if (!posFlashAutoEnabled() || _posFlashAutoBusy) {
                if (_posFlashAutoBusy) _posFlashPendingRetry = true;
                return;
            }
            if (posFlashIsWriteProtected()) {
                _posFlashLastFail = 'protect';
                posFlashUpdateSidebarStatus();
                return;
            }
            var ready = await posFlashGetWritable(false);
            if (!ready.ok) {
                _posFlashLastFail = ready.reason || 'error';
                posFlashUpdateSidebarStatus();
                return;
            }
            // Dirty from sales/debt → complete DB to flash (all tables)
            if (_posFlashDirty || _posFlashPendingRetry) {
                _posFlashDirty = false;
                _posFlashPendingRetry = false;
                await posSyncCompleteDbToFlash({ silent: true, auto: true, interactive: false });
                return;
            }
            // Safety: if last successful copy is stale, push complete DB again (never mysql unzip — hangs the shop)
            try {
                var lastOk = parseInt(localStorage.getItem(POS_FLASH_LAST_OK_KEY) || '0', 10);
                if (lastOk && (Date.now() - lastOk) < POS_FLASH_AUTO_MS) return;
            } catch (_eSkip) {}
            await posSyncCompleteDbToFlash({ silent: true, auto: true, interactive: false });
        }

        function posFlashStopAutoLoop() {
            if (_posFlashAutoTimer) {
                clearInterval(_posFlashAutoTimer);
                _posFlashAutoTimer = null;
            }
            if (_posFlashHeartbeatTimer) {
                clearInterval(_posFlashHeartbeatTimer);
                _posFlashHeartbeatTimer = null;
            }
            if (_posFlashLiveCheckTimer) {
                clearInterval(_posFlashLiveCheckTimer);
                _posFlashLiveCheckTimer = null;
            }
            posFlashClearBusyWatchdog();
        }

        function posFlashStartAutoLoop() {
            if (_posFlashAutoTimer) {
                clearInterval(_posFlashAutoTimer);
                _posFlashAutoTimer = null;
            }
            if (_posFlashHeartbeatTimer) {
                clearInterval(_posFlashHeartbeatTimer);
                _posFlashHeartbeatTimer = null;
            }
            if (_posFlashLiveCheckTimer) {
                clearInterval(_posFlashLiveCheckTimer);
                _posFlashLiveCheckTimer = null;
            }
            if (!posFlashAutoEnabled()) return;
            _posFlashAutoTimer = setInterval(function () {
                posFlashAutoTick().catch(function () {});
            }, POS_FLASH_AUTO_MS);
            // Keep retrying failed/dirty syncs even if no new sale for a while
            _posFlashHeartbeatTimer = setInterval(function () {
                if (!posFlashAutoEnabled() || _posFlashAutoBusy) return;
                if (posFlashIsWriteProtected()) return;
                if (_posFlashDirty || _posFlashPendingRetry || _posFlashLastFail) {
                    posFlashScheduleSync('heartbeat', 500);
                }
            }, POS_FLASH_HEARTBEAT_MS);
            _posFlashLiveCheckTimer = setInterval(function () {
                posFlashCheckLiveConnection().catch(function () {});
            }, POS_FLASH_RECONNECT_MS);
            setTimeout(function () {
                posFlashCheckLiveConnection().catch(function () {});
            }, 1200);
            // Light check soon after start
            setTimeout(function () {
                posFlashAutoTick().catch(function () {});
            }, 20000);
        }

        async function posBackupNowToFlash() {
            return posFlashPushNow();
        }

        /** One click: pick/rebind flash, turn auto ON, copy all shop data now. */
        async function posFlashOneClickBind() {
            var bind = await posFlashSidebarBind();
            if (!bind || !bind.ok) return bind;
            if (bind.mode === 'protected') return bind;
            return posFlashPushNow({ alreadyBound: true });
        }

        /** One click: write complete POS database to the linked flash (no extra dialogs). */
        async function posFlashPushNow(opts) {
            opts = opts || {};
            if (!posFlashAutoEnabled()) {
                _posFlashPersistAutoFlag(true);
                posFlashUpdateAutoOnOffUi();
                posFlashStartAutoLoop();
            }
            if (!opts.alreadyBound) {
                var ready = await posFlashGetWritable(true);
                if (!ready.ok) {
                    var picked = await posPickFlashBackupFolder();
                    if (!picked) return { ok: false, reason: 'cancelled' };
                }
            }
            var waited = 0;
            while (_posFlashAutoBusy && waited < 25000) {
                await new Promise(function (r) { setTimeout(r, 400); });
                waited += 400;
            }
            var r = await posSyncCompleteDbToFlash({ interactive: true, silent: false, auto: false, force: true });
            if (r && r.reason === 'busy' && typeof showToast === 'function') {
                showToast('فلاش یێ سەرقاڵە — خۆکار دووبارە دێنێریت', 'warning');
                posFlashScheduleSync('push_busy', 2000);
            }
            return r;
        }

        async function posRestoreFromFlashFile(fileName) {
            if (!fileName) return;
            var currencyEl = document.getElementById('restore-currency-choice');
            var forceCurrency = (currencyEl && currencyEl.value === 'USD') ? 'USD' : 'IQD';
            var currLabel = forceCurrency === 'USD' ? 'دولار ($)' : 'دینار عێراقی (IQD)';
            var tr = (typeof t === 'function') ? t : function () { return ''; };
            if (typeof posConfirmDataRestore === 'function') {
                var okFile = await posConfirmDataRestore({
                    source: tr('confirm_data_restore_source_flash') || 'گەڕاندنەوە لە فلاش',
                    detail: String(fileName),
                    currencyLabel: currLabel
                });
                if (!okFile) return;
            } else if (!confirm('⚠️ گەڕاندنەوە لە فلاش:\n' + fileName + '\n\nهەموو داتای ئێستا دەگۆڕدرێت.\nدراڤ: ' + currLabel)) return;

            var handle = await posFlashLoadDirHandle();
            if (!handle) {
                alert('فلاش نەدۆزرایەوە — سەرەتا هەڵبژێرە.');
                return;
            }
            if (!(await posFlashEnsurePermission(handle, 'readwrite', true)) && !(await posFlashEnsurePermission(handle, 'read', true))) {
                alert('مۆڵەتی خوێندنەوە نییە — دووبارە فلاش هەڵبژێرە.');
                return;
            }
            var dir = await posFlashGetBackupsDir(handle, false);
            var fileHandle = await dir.getFileHandle(fileName);
            var file = await fileHandle.getFile();

            var formData = new FormData();
            formData.append('action', 'restore_backup');
            formData.append('file', file, String(fileName));
            formData.append('force_currency', forceCurrency);

            var indicator = document.getElementById('save-indicator');
            if (indicator) {
                indicator.style.display = 'block';
                indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> گەڕاندنەوە لە فلاش…';
            }
            try {
                var res = await fetch('?action=restore_backup', { method: 'POST', body: formData, credentials: 'same-origin' });
                var text = (await res.text() || '').trim();
                if (!text) throw new Error('وەڵامی سێرڤەر بەتاڵە');
                var data = JSON.parse(text);
                if (data.status === 'success') {
                    try {
                        await posFlashApplyDeltaAfterRestore(dir, indicator);
                    } catch (deltaErr) {
                        console.warn('[flash file restore delta]', deltaErr);
                        if (indicator) indicator.style.display = 'none';
                        alert(
                            '⚠️ باک‌ئەپی سەرەکی گەڕایەوە، بەڵام دوایین داتا (delta) سەرنەکەوت:\n'
                            + (deltaErr && deltaErr.message ? deltaErr.message : deltaErr)
                        );
                        return;
                    }
                    try {
                        localStorage.removeItem(POS_FLASH_DELTA_WM_KEY);
                        await posFlashClearDeltaLog(dir);
                    } catch (_eClr) {}
                    posFlashSetWriteProtect(false);
                    _posFlashLastFail = '';
                    if (indicator) indicator.innerHTML = '<i class="fas fa-check"></i> لە فلاش گەڕایەوە — ڕیفرێش…';
                    Object.keys(localStorage).forEach(function (key) {
                        if (key.startsWith('pos_tabs_state_')) localStorage.removeItem(key);
                    });
                    setTimeout(function () { location.reload(); }, 1500);
                } else {
                    if (indicator) indicator.style.display = 'none';
                    alert('❌ ' + (data.message || 'error'));
                }
            } catch (err) {
                if (indicator) indicator.style.display = 'none';
                alert('❌ ' + (err && err.message ? err.message : err));
            }
        }

        window.posPickFlashBackupFolder = posPickFlashBackupFolder;
        window.posClearFlashBackupFolder = posClearFlashBackupFolder;
        window.posCopyBackupBlobToFlash = posCopyBackupBlobToFlash;
        window.posRefreshFlashBackupUi = posRefreshFlashBackupUi;
        window.posRestoreFromFlashFile = posRestoreFromFlashFile;
        window.posBackupNowToFlash = posBackupNowToFlash;
        window.posFlashPushNow = posFlashPushNow;
        window.posFlashOneClickBind = posFlashOneClickBind;
        window.posSyncAllToFlash = posSyncAllToFlash;
        window.posSyncDeltaToFlash = posSyncDeltaToFlash;
        window.posSyncCompleteDbToFlash = posSyncCompleteDbToFlash;
        window.posReactivateFlashPermission = posReactivateFlashPermission;
        window.posFlashSetAutoEnabled = posFlashApplyAutoEnabled;
        window.posFlashToggleAuto = posFlashToggleAuto;
        window.posFlashAutoEnabled = posFlashAutoEnabled;
        window.posFlashScheduleSync = posFlashScheduleSync;
        window.posFlashUpdateSidebarStatus = posFlashUpdateSidebarStatus;
        window.posFlashSidebarBind = posFlashSidebarBind;

        // Keep flash alive while POS is open
        try {
            document.addEventListener('visibilitychange', function () {
                if (!document.hidden && posFlashAutoEnabled()) {
                    posFlashUpdateSidebarStatus();
                    posFlashCheckLiveConnection().catch(function () {});
                    // Do not list flash files here — USB listing can stall the tab; only nudge sync
                    if (_posFlashDirty || _posFlashPendingRetry || _posFlashLastFail) {
                        posFlashScheduleSync('visible', 800);
                    } else {
                        posFlashAutoTick().catch(function () {});
                    }
                }
            });
            window.addEventListener('focus', function () {
                if (posFlashAutoEnabled()) {
                    posFlashUpdateSidebarStatus();
                    posFlashCheckLiveConnection().catch(function () {});
                    if (_posFlashDirty || _posFlashPendingRetry || _posFlashLastFail) {
                        posFlashScheduleSync('focus', 800);
                    }
                }
            });
            setTimeout(function () {
                posFlashUpdateSidebarStatus();
                posFlashBootAfterShopUpdate().catch(function () {
                    posFlashStartAutoLoop();
                });
            }, 2500);
            // Immediate light paint (localStorage only)
            setTimeout(function () { posFlashUpdateSidebarStatus(); }, 400);
        } catch (_eBoot) {}

        async function posBackupMysqlDataToFlash(scope) {
            scope = (scope === 'db' || scope === 'db_only') ? 'db' : 'full';
            var handle = await posFlashLoadDirHandle();
            if (!handle) {
                handle = await posPickFlashBackupFolder();
                if (!handle) return;
            } else if (!(await posFlashEnsurePermission(handle, 'readwrite', true))) {
                alert('مۆڵەتی نووسین نییە — دووبارە فلاش هەڵبژێرە.');
                await posPickFlashBackupFolder();
                return;
            }
            if (!confirm(
                scope === 'full'
                    ? '📦 فۆڵدەری C:\\xampp\\mysql\\data دەچێتە سەر فلاش وەک فۆڵدەری data/\n\nگەڕاندنەوە: کۆپیکردنی data بۆ XAMPP یان دوگمەی گەڕاندنەوە.\nبەردەوام بیت؟'
                    : '📦 تەنها فۆڵدەری داتابەیسی POS دەچێتە سەر فلاش/data.\nبەردەوام بیت؟'
            )) return;

            var indicator = document.getElementById('save-indicator');
            if (indicator) {
                indicator.style.display = 'block';
                indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> کۆپیکردنی mysql/data بۆ فلاش…';
            }
            try {
                var url = '?action=export_mysql_data_backup&scope=' + encodeURIComponent(scope) + '&save_local=1&download=1';
                var ctrl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
                var timer = ctrl ? setTimeout(function () { try { ctrl.abort(); } catch (_e) {} }, 15 * 60 * 1000) : null;
                var res = await fetch(url, { credentials: 'same-origin', signal: ctrl ? ctrl.signal : undefined });
                if (timer) clearTimeout(timer);
                if (!res.ok) {
                    throw new Error(await posFlashFetchErrorMessage(res));
                }
                var ct = res.headers.get('Content-Type') || '';
                if (ct.indexOf('json') !== -1 && ct.indexOf('zip') === -1) {
                    throw new Error(await posFlashFetchErrorMessage(res));
                }
                var filename = scope === 'db' ? POS_FLASH_NAME_MYSQL_DB : POS_FLASH_NAME_MYSQL_FULL;
                var blob = await res.blob();
                if (!blob || blob.size < 64) throw new Error('فایلی data زۆر بچووکە یان بەتاڵە');
                var ready = await posFlashGetWritable(true);
                if (!ready.ok) throw new Error(ready.message || ready.reason || 'فلاش ئامادە نییە');
                var flash = await posCopyBackupBlobToFlash(blob, filename, {
                    silent: true,
                    force: true,
                    skipRefresh: true,
                    kind: scope === 'db' ? 'mysql_db' : 'mysql_full'
                });
                if (!flash.ok) throw new Error(flash.message || flash.reason || 'flash write failed');
                var foldInfo = { files: 0, skipped: 0, skippedFolder: false };
                if (blob.size > 80 * 1024 * 1024) {
                    foldInfo.skippedFolder = true;
                } else {
                    if (indicator) indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> فۆڵدەری data/ لەسەر فلاش…';
                    try {
                        foldInfo = await posFlashWriteEasyFolders(ready.dir, blob, 'mysql') || foldInfo;
                    } catch (eFold) {
                        console.warn('[flash data folder]', eFold);
                        foldInfo.skippedFolder = true;
                    }
                }
                try { await posRefreshFlashBackupUi(true); } catch (_eUi) {}
                if (typeof loadLocalBackupsList === 'function') loadLocalBackupsList();
                if (indicator) {
                    indicator.innerHTML = '<i class="fas fa-check"></i> data لە فلاش ئامادەیە';
                    setTimeout(function () { indicator.style.display = 'none'; }, 2500);
                }
                if (typeof showToast === 'function') {
                    showToast(
                        foldInfo.skippedFolder
                            ? '✅ mysql ZIP لە فلاش پاراسترا (.posbak) — فۆڵدەری data بازدرا (زۆر گەورە)'
                            : ('✅ فلاش/data ئامادەیە (' + (foldInfo.files || 0) + ' فایل)'),
                        'success'
                    );
                }
                alert(
                    '✅ تەواو!\n\nلەسەر فلاش:\n'
                    + 'Laptop_Duhok_POS_Backups\\'
                    + (foldInfo.skippedFolder ? (filename + '\n(فۆڵدەری data بازدرا چونکە زۆر گەورەیە — گەڕاندنەوە لە .posbak)') : ('data\\\nفایل: ' + (foldInfo.files || 0)))
                    + (foldInfo.skipped ? (' · پەڕێندرا: ' + foldInfo.skipped) : '')
                    + '\n\nگەڕاندنەوەی ڕۆژانە (بێ Stop MySQL):\n'
                    + '«گەڕاندنەوە لە فلاش (sql)»\n\n'
                    + 'یان گەڕاندنەوە لە فۆڵدەری data (Stop MySQL) بۆ کارەسات.'
                );
            } catch (err) {
                if (indicator) {
                    indicator.innerHTML = '<i class="fas fa-times"></i> data';
                    setTimeout(function () { indicator.style.display = 'none'; }, 3000);
                }
                alert('❌ کۆپیکردنی mysql/data سەرنەکەوت:\n' + (err && err.message ? err.message : err));
            }
        }

        async function posPostMysqlDataRestore(fileOrBlob, fileName, opts) {
            opts = opts || {};
            if (!opts.alreadyConfirmed) {
                if (window._posRestoreMysqlSkipConfirmOnce) {
                    window._posRestoreMysqlSkipConfirmOnce = false;
                } else if (typeof posConfirmDataRestore === 'function') {
                    var tr = (typeof t === 'function') ? t : function () { return ''; };
                    var okMysql = await posConfirmDataRestore({
                        source: tr('confirm_data_restore_source_mysql') || 'گەڕاندنەوەی mysql/data',
                        detail: 'فایل: ' + fileName + '\n١) XAMPP → Stop MySQL'
                    });
                    if (!okMysql) return;
                }
                var typed = prompt(
                    '⚠️ گرنگ!\n\n١) لە XAMPP Control Panel → Stop MySQL\n٢) لێرە بنووسە: STOP_MYSQL\n\nفایل: ' + fileName,
                    ''
                );
                if (typed !== 'STOP_MYSQL') {
                    alert('هەڵوەشایەوە — دەبێت STOP_MYSQL بنووسیت.');
                    return;
                }
            }
            var force = opts.force != null
                ? String(opts.force)
                : (confirm('ئەگەر MySQL وەستاوە OK بکە.\nئەگەر هێشتا mysql.pid هەیە و دڵنیایت وەستاوە → OK بۆ force.') ? '1' : '0');
            var formData = new FormData();
            formData.append('action', 'restore_mysql_data_backup');
            formData.append('confirm', 'STOP_MYSQL');
            formData.append('force', force);
            formData.append('file', fileOrBlob, String(fileName || 'mysql_data.zip').replace(/\.posbak$/i, '.zip'));

            var indicator = document.getElementById('save-indicator');
            if (indicator) {
                indicator.style.display = 'block';
                indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> گەڕاندنەوەی mysql/data بۆ XAMPP…';
            }
            try {
                var res = await fetch('?action=restore_mysql_data_backup', { method: 'POST', body: formData, credentials: 'same-origin' });
                var text = (await res.text() || '').trim();
                if (!text) throw new Error('وەڵامی سێرڤەر بەتاڵە');
                var data = JSON.parse(text);
                if (data.status !== 'success') throw new Error(data.message || 'error');
                if (indicator) indicator.innerHTML = '<i class="fas fa-check"></i> data گەڕایەوە';
                alert(
                    '✅ فۆڵدەری mysql/data گەڕایەوە بۆ XAMPP.\n\n'
                    + 'ئێستا لە XAMPP → Start MySQL\n'
                    + 'پاشان پەڕەکە ڕیفرێش بکە.\n\n'
                    + 'فایل: ' + (data.result && data.result.extracted ? data.result.extracted + ' فایل' : fileName)
                );
                setTimeout(function () { location.reload(); }, 1200);
            } catch (err) {
                if (indicator) indicator.style.display = 'none';
                alert('❌ گەڕاندنەوەی data سەرنەکەوت:\n' + (err && err.message ? err.message : err));
            }
        }
