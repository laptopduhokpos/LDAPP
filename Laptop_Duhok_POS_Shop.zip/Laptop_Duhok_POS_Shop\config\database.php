<?php
// Database configuration and session bootstrap.

// --- DATABASE CONFIGURATION ---
// ئەگەر ل سەر کۆمپیوتەری بوو (Localhost)
$username = "root";
$passwords = ["", "root", "admin", "123456"]; // Try common passwords for Android Servers (KSWEB, AWebServer)
$dbname = "laptop_duhok_pos";

// Auto-detect Port (3306) - خۆدکارانە پۆرتی دەستنیشان دکەت
$conn = null;
$ports = [3306, 3307, 3308, 8889];
$hosts = ["127.0.0.1"]; // IPv4 only — skip "localhost" (Windows IPv6 DNS stall)
$lastError = "";

// Optimize connection to prevent 12-minute timeouts
mysqli_report(MYSQLI_REPORT_OFF);
$tempConn = mysqli_init();
if ($tempConn) {
    $tempConn->options(MYSQLI_OPT_CONNECT_TIMEOUT, 2);
    if (defined('MYSQLI_OPT_READ_TIMEOUT')) { $tempConn->options(MYSQLI_OPT_READ_TIMEOUT, 15); }
    if (@$tempConn->real_connect("127.0.0.1", "root", "", null, 3306)) {
        $tempConn->query("CREATE DATABASE IF NOT EXISTS $dbname");
        if ($tempConn->select_db($dbname)) {
            $conn = $tempConn;
            $servername = "127.0.0.1:3306";
        }
    }
}

if (!$conn) {
    foreach ($ports as $port) {
        foreach ($hosts as $host) {
            foreach ($passwords as $password) {
                try {
                    $tc = mysqli_init();
                    $tc->options(MYSQLI_OPT_CONNECT_TIMEOUT, 1); // 1-second timeout
                    if (defined('MYSQLI_OPT_READ_TIMEOUT')) { $tc->options(MYSQLI_OPT_READ_TIMEOUT, 15); }
                    if (@$tc->real_connect($host, $username, $password, null, $port)) {
                        $tc->query("CREATE DATABASE IF NOT EXISTS $dbname");
                        if ($tc->select_db($dbname)) {
                            $conn = $tc;
                            $servername = "$host:$port";
                            break 3;
                        }
                    } else {
                        $lastError = mysqli_connect_error();
                    }
                } catch (Exception $e) { $lastError = $e->getMessage(); }
            }
        }
    }
}

if (!$conn) {
    die("<div style='text-align:center;padding:50px;font-family:Segoe UI, Tahoma;'>
        <h1 style='color:red'>🔴 ئاریشە: سێرڤەر کار ناکەت!</h1>
        <p style='font-size:1.2rem'>هیڤیە دڵنیابە بەرنامێ <b>XAMPP</b> (ل سەر PC) یان <b>AWebServer/KSWEB</b> (ل سەر تابلێتێ) کار دکەت.</p>
        <p style='font-size:1rem; color:#666;'>پێدڤیە دوگما <b>MySQL Start</b> لێدایە.</p>
        <hr>
        <p style='color:darkred; direction:ltr; font-weight:bold;'>Technical Error Details:</p>
        <p style='color:gray; direction:ltr'>$lastError</p>
    </div>");
}
$conn->set_charset("utf8mb4");

/**
 * Automatic DB schema migrations (no phpMyAdmin step).
 * Any script that includes this file gets a version check: when settings.schema_version
 * is behind POS_SCHEMA_VERSION in config/migrations.php, ALTER/CREATE run under a MySQL lock.
 */
if (!defined('POS_RUN_MIGRATIONS')) {
    define('POS_RUN_MIGRATIONS', true);
}
require_once __DIR__ . '/migrations.php';
// migrations.php invokes pos_run_migrations_if_needed($conn) when POS_RUN_MIGRATIONS is true.

// Concurrency-focused session settings for multi-laptop usage.
try {
    $conn->query("SET SESSION innodb_lock_wait_timeout = 8");
    $conn->query("SET SESSION wait_timeout = 120");
    $conn->query("SET SESSION interactive_timeout = 120");
    $conn->query("SET SESSION sql_mode = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'");
    $conn->query("SET SESSION time_zone = '+03:00'");
} catch (Throwable $e) {
    // Keep startup resilient on older MySQL variants.
}

if (session_status() === PHP_SESSION_NONE && !headers_sent()) {
    $session_path = 'C:/xampp/tmp';
    if (is_dir($session_path) && is_writable($session_path)) {
        session_save_path($session_path);
    }
    session_start();
}
