param(
    [Parameter(Mandatory = $true)]
    [string]$ExePath
)

$ErrorActionPreference = 'Stop'
if (-not (Test-Path -LiteralPath $ExePath)) {
    throw "EXE not found: $ExePath"
}

$exe = (Resolve-Path -LiteralPath $ExePath).Path
$ws = New-Object -ComObject WScript.Shell
$desktops = @(
    [Environment]::GetFolderPath('Desktop'),
    [Environment]::GetFolderPath('CommonDesktopDirectory')
) | Where-Object { $_ -and (Test-Path $_) } | Select-Object -Unique

foreach ($desk in $desktops) {
    try {
        $lnk = Join-Path $desk 'Laptop Duhok POS.lnk'
        $sc = $ws.CreateShortcut($lnk)
        $sc.TargetPath = $exe
        $sc.WorkingDirectory = Split-Path -Parent $exe
        $sc.WindowStyle = 1
        $sc.Description = 'Laptop Duhok POS'
        $sc.IconLocation = "$exe,0"
        $sc.Save()
        Write-Host $lnk
    } catch {
        Write-Host "skip: $desk"
    }
}
