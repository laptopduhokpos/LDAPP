// inventory/dashboard.js — dashboard, tables
        // --- DASHBOARD ---
        function sumTodayPurchasesIqd() {
            var roundM = typeof roundMoney === 'function' ? roundMoney : function (x) { return Math.round(Number(x) || 0); };
            var today = typeof getBusinessDate === 'function' ? getBusinessDate(new Date()) : new Date().toISOString().slice(0, 10);
            var pool = [];
            if (typeof window.posGetSuppliesPool === 'function') {
                try { pool = window.posGetSuppliesPool() || []; } catch (_e) { pool = []; }
            }
            if (!pool.length && db && Array.isArray(db.supplies)) pool = db.supplies;
            var total = 0;
            (pool || []).forEach(function (s) {
                if (!s) return;
                var typ = String(s.type || '').toLowerCase();
                if (typ === 'return' || typ === 'opening') return;
                if ((parseFloat(s.qtyAdded) || 0) <= 0) return;
                var d = typeof getBusinessDate === 'function'
                    ? getBusinessDate(typeof parseSQLDate === 'function' ? parseSQLDate(s.date) : new Date(s.date))
                    : String(s.date || '').slice(0, 10);
                if (d !== today) return;
                total = roundM(total + (parseFloat(s.totalCost) || 0));
            });
            return total;
        }

        function paintTodayFinanceKpis(metrics) {
            if (!metrics) return;
            var roundM = typeof roundMoney === 'function' ? roundMoney : function (x) { return Math.round(Number(x) || 0); };
            var fmt = typeof formatCanonicalMoney === 'function'
                ? function (iqd, usd) { return formatCanonicalMoney(iqd, usd); }
                : (typeof formatCurrency === 'function' ? formatCurrency : String);
            var netSales = roundM((metrics.totalSales || 0) - (metrics.totalReturns || 0));
            var netSalesUsd = (metrics.totalSalesUsd != null && metrics.totalReturnsUsd != null)
                ? (metrics.totalSalesUsd - metrics.totalReturnsUsd)
                : undefined;
            if (db && db.today_stats) {
                var ts = db.today_stats;
                if (netSales <= 0 && (parseFloat(ts.sales) || 0) > 0) {
                    netSales = roundM((parseFloat(ts.sales) || 0) - (parseFloat(ts.returns) || 0));
                    netSalesUsd = undefined;
                }
            }
            var purchases = sumTodayPurchasesIqd();
            if (purchases <= 0 && (metrics.cashPurchases || 0) > 0) purchases = metrics.cashPurchases;
            var purchasesUsd = metrics.cashPurchasesUsd;
            var cashMove = metrics.cashMovement || 0;
            var opExp = metrics.opExpenses || 0;

            function setText(id, val) {
                var el = document.getElementById(id);
                if (el) el.textContent = val;
            }

            setText('home-kpi-sales', fmt(netSales, netSalesUsd));
            setText('home-kpi-purchases', fmt(purchases, purchasesUsd));

            setText('dash-kpi-sales', fmt(netSales, netSalesUsd));
            setText('dash-kpi-purchases', fmt(purchases, purchasesUsd));
            setText('dash-kpi-cash', fmt(cashMove, metrics.cashMovementUsd));
            setText('dash-kpi-exp', fmt(opExp, metrics.opExpensesUsd));

            var stPurch = document.getElementById('st-purchases');
            if (stPurch) stPurch.textContent = fmt(purchases);
        }
        window.paintTodayFinanceKpis = paintTodayFinanceKpis;
        window.sumTodayPurchasesIqd = sumTodayPurchasesIqd;

        function updateStats() {
            if (currentUser && typeof posCanPaintFinancialStats === 'function' && !posCanPaintFinancialStats()) {
                return;
            }
            const isAdmin = currentUser && currentUser.role === 'admin';
            const metrics = typeof getFinancialMetrics === 'function'
                ? getFinancialMetrics(null, isAdmin ? {} : { salesScope: 'report' })
                : null;
            if (!metrics) return;

            const fmt = typeof formatCanonicalMoney === 'function'
                ? function (iqd, usd) { return formatCanonicalMoney(iqd, usd); }
                : (typeof formatCurrency === 'function' ? formatCurrency : String);
            const _t = typeof t === 'function' ? t : (k => k);

            var netSales = metrics.totalSales - metrics.totalReturns;
            var netSalesUsd = (metrics.totalSalesUsd != null) ? (metrics.totalSalesUsd - (metrics.totalReturnsUsd || 0)) : undefined;
            var opExp = metrics.opExpenses;
            
            // Helper for setting text
            const setTxt = (id, val) => { const el = document.getElementById(id); if (el) el.innerText = val; };

            setTxt('st-sales', fmt(netSales, netSalesUsd));
            setTxt('st-exp', fmt(opExp, metrics.opExpensesUsd));
            setTxt('st-cash', fmt(metrics.cashMovement, metrics.cashMovementUsd));
            setTxt('st-profit', fmt(metrics.netProfit, metrics.netProfitUsd));

            var todayCount = metrics.salesCount != null ? metrics.salesCount : (metrics.saleCount || 0);
            setTxt('st-count', String(todayCount));

            // Detail Grid
            setTxt('st-cash-sales', fmt(metrics.cashSales, metrics.cashSalesUsd));
            setTxt('st-debt-sales', fmt(metrics.debtSales, metrics.debtSalesUsd));
            setTxt('st-purchases', fmt(metrics.cashPurchases, metrics.cashPurchasesUsd));
            setTxt('st-returns', fmt(metrics.totalReturns, metrics.totalReturnsUsd));
            setTxt('st-gifts', fmt(metrics.totalGiftsValue || 0, metrics.totalGiftsValueUsd));
            setTxt('st-waste', fmt(metrics.wasteLoss || 0, metrics.wasteLossUsd));
            setTxt('st-voided', fmt(metrics.totalVoidedSales || 0));
            setTxt('st-voided-purchases', fmt(metrics.totalVoidedPurchases || 0));

            // Opening Balance
            const todayStr = getBusinessDate(new Date());
            const dayShifts = (db.shifts || []).filter(s => getBusinessDate(parseSQLDate(s.created_at || s.start_date)) === todayStr);
            let opening = 0;
            if (dayShifts.length > 0) {
                opening = dayShifts.reduce((sum, s) => sum + (parseFloat(s.opening_balance) || 0), 0);
            }
            setTxt('st-opening', fmt(opening));

            // Staff & Top Items
            const staffList = document.getElementById('dash-staff-list');
            if (staffList) {
                const staffNames = [...new Set(dayShifts.map(s => s.userName).filter(n => !!n))];
                staffList.innerHTML = staffNames.length > 0 
                    ? staffNames.map(n => `<span class="dash-staff-chip">${escapeHtml(n)}</span>`).join('')
                    : `<span class="dash-empty-hint">${escapeHtml(_t('daily_summary_no_staff'))}</span>`;
            }

            const topItemsList = document.getElementById('dash-top-items');
            if (topItemsList) {
                const todaySales = (typeof getReportSales === 'function' ? getReportSales() : getAllSales())
                    .filter(s => !s.is_returned && getBusinessDate(parseSQLDate(s.date || s.created_at)) === todayStr);
                
                const itemStats = {};
                todaySales.forEach(s => {
                    if (s.items) s.items.forEach(i => {
                        const nm = i.name || i.title || '—';
                        if (!itemStats[nm]) itemStats[nm] = { qty: 0, total: 0 };
                        const q = typeof getItemQty === 'function' ? getItemQty(i) : 1;
                        itemStats[nm].qty += q;
                        itemStats[nm].total += (parseFloat(i.price) || 0) * q;
                    });
                });

                const topItems = Object.entries(itemStats).sort((a, b) => b[1].total - a[1].total).slice(0, 5);
                topItemsList.innerHTML = topItems.length > 0
                    ? topItems.map((item, i) => `
                        <div class="dash-top-row">
                            <span class="dash-top-rank">${i + 1}</span>
                            <span class="dash-top-name">${escapeHtml(item[0])}</span>
                            <span class="dash-top-qty">${item[1].qty}</span>
                        </div>`).join('')
                    : `<span class="dash-empty-hint">${escapeHtml(_t('daily_summary_no_sales'))}</span>`;
            }

            var todayCount = metrics.salesCount != null ? metrics.salesCount : (metrics.saleCount || 0);
            var dateHint = document.getElementById('st-date-hint');
            if (dateHint) {
                var bizDayLbl = _t('dash_business_day_label');
                var invLbl = _t('dash_invoice_count');
                dateHint.textContent = '(' + bizDayLbl + ' · ' + todayCount + ' ' + invLbl + ')';
            }

            const profitEl = document.getElementById('st-profit');
            const showProfitDash = (typeof canViewProfit === 'function') ? canViewProfit() : isAdmin;
            const profitCard = profitEl ? profitEl.closest('.dash-hero-card') : null;
            if (profitCard) profitCard.style.display = showProfitDash ? '' : 'none';

            // Calculate Assets (Stock Value) — native currency sums (no IQD↔USD round-trip)
            let totalAssetsIqd = 0;
            let totalAssetsUsd = 0;
            let hasError = false;
            let errorItem = '';
            const invVal = (typeof sumInventoryValuationNative === 'function')
                ? sumInventoryValuationNative(db.products || [])
                : null;
            if (invVal) {
                totalAssetsIqd = invVal.costIqd || 0;
                totalAssetsUsd = invVal.costUsd;
            } else {
                (db.products || []).forEach(p => {
                    const cost = parseFloat(p.cost_price || p.cost) || 0;
                    const stock = parseFloat(p.qty) || 0;
                    if (cost < 0 || stock < -999999) { hasError = true; errorItem = p.name || p.title; }
                    totalAssetsIqd += cost * stock;
                });
            }
            (db.products || []).forEach(p => {
                const cost = parseFloat(p.cost_price || p.cost) || 0;
                const stock = parseFloat(p.qty) || 0;
                if (cost < 0 || stock < -999999) { hasError = true; errorItem = p.name || p.title; }
            });

            // Calculate Receivables (Customer + Staff Debt) for Net Worth
            let totalReceivables = 0;
            var roundM5 = typeof roundMoney === 'function' ? roundMoney : function(x){ return Math.round(Number(x)); };
            if(db.customers) db.customers.forEach(c => totalReceivables = roundM5(totalReceivables + (parseFloat(c.balance)||0)));
            if(db.users) db.users.forEach(u => totalReceivables = roundM5(totalReceivables + (parseFloat(u.balance)||0)));

            let totalLiabilities = 0;
            if(db.companies) {
                db.companies.forEach(c => {
                    if(c.balance > 0) totalLiabilities = roundM5(totalLiabilities + (parseFloat(c.balance)||0));
                });
            }
            if(document.getElementById('dash-assets')) {
                let assetsText = fmt(totalAssetsIqd, totalAssetsUsd);
                if (hasError) {
                    assetsText += ` <i class="fas fa-exclamation-triangle" style="color:var(--warning); cursor:pointer;" onclick="alert('⚠️ هەڵە: ئایتمێ (${errorItem}) داتایێن وی خەلەتن! هیڤیە بچە بەشێ ئایتمان و راستڤەکە.')"></i>`;
                }
                document.getElementById('dash-assets').innerHTML = assetsText; 
                document.getElementById('dash-liabilities').innerText = fmt(totalLiabilities);
                // Net Worth = Assets + Receivables - Liabilities + Safe
                document.getElementById('dash-networth').innerText = fmt(roundM5(totalAssetsIqd + totalReceivables - totalLiabilities + (metrics.cashMovement || 0)));
            }

            paintTodayFinanceKpis(metrics);
            
            try {
                if (typeof window.scheduleFirebaseMobilePush === 'function') {
                    window.scheduleFirebaseMobilePush('stats', false);
                }
            } catch (e) {}

            }

        function renderInventoryStats(list) {
            var src = list || (typeof db !== 'undefined' && db && db.products) || [];
            var val = (typeof sumInventoryValuationNative === 'function')
                ? sumInventoryValuationNative(src)
                : { cost: 0, sale: 0, costIqd: 0, costUsd: 0, saleIqd: 0, saleUsd: 0 };
            if (Array.isArray(list) && typeof setWarehouseKpiTotals === 'function') {
                try { setWarehouseKpiTotals(val.cost, val.sale); } catch (_eInv) {}
            }
            var dashAssets = document.getElementById('dash-assets');
            if (dashAssets && typeof formatCanonicalMoney === 'function') {
                dashAssets.textContent = formatCanonicalMoney(val.costIqd, val.costUsd);
            }
            return val;
        }
        window.renderInventoryStats = renderInventoryStats;

        let salesChartInstance = null;
        function renderSalesChart() {
            return; // Disabled as chart was removed from UI
        }

        function renderDashboard() {
            const container = document.getElementById('dash-tables');
            const emptyEl = document.getElementById('dash-tables-empty');
            if (!container) return;
            container.innerHTML = '';
            const mode = (db.settings && db.settings.systemMode) ? db.settings.systemMode : 'general';
            
            let titleText = '<i class="fas fa-shopping-basket" aria-hidden="true"></i> <span>' + escapeHtml((typeof t === 'function') ? t('dash_active_tables') : 'سەبەتەی چالاک') + '</span>';
            let iconBusy = 'fa-shopping-cart';
            let statusLbl = 'چالاک';

            if (mode === 'restaurant') { titleText = '<i class="fas fa-utensils" aria-hidden="true"></i> <span>مێزێن چالاک</span>'; iconBusy = 'fa-utensils'; statusLbl = 'مژوولە'; }
            else if (mode === 'pharmacy') { titleText = '<i class="fas fa-pills" aria-hidden="true"></i> <span>وەسڵێن چالاک</span>'; iconBusy = 'fa-pills'; }
            else if (mode === 'company') { titleText = '<i class="fas fa-clipboard-check" aria-hidden="true"></i> <span>داواکاریێن چالاک</span>'; iconBusy = 'fa-clipboard-check'; }
            else if (mode === 'market') { titleText = '<i class="fas fa-shopping-basket" aria-hidden="true"></i> <span>' + escapeHtml((typeof t === 'function') ? t('dash_active_tables') : 'سەبەتەی چالاک') + '</span>'; iconBusy = 'fa-shopping-cart'; }
            else if (mode === 'jewelry') { titleText = '<i class="fas fa-gem" aria-hidden="true"></i> <span>سەبەتێن چالاک</span>'; iconBusy = 'fa-gem'; }
            else if (mode === 'school') { titleText = '<i class="fas fa-chalkboard-user" aria-hidden="true"></i> <span>پۆلێن چالاک</span>'; iconBusy = 'fa-chalkboard-user'; }
            else if (mode === 'factory') { titleText = '<i class="fas fa-gears" aria-hidden="true"></i> <span>بەشی بەرهەمهێنان</span>'; iconBusy = 'fa-gears'; }
            
            const titleEl = document.getElementById('dash-active-title');
            if (titleEl) titleEl.innerHTML = titleText;

            var activeCount = 0;
            (db.tables || []).forEach(function(tbl) {
                if (!tbl || !tbl.items || !tbl.items.length) return;
                activeCount++;
                var itemQty = tbl.items.reduce(function(s, it) {
                    var q = (it.qty != null ? it.qty : it.count);
                    return s + (Number(q) > 0 ? Number(q) : 1);
                }, 0);
                container.innerHTML += '<button type="button" class="dash-active-tile table-card busy" onclick="openTable(' + tbl.id + ')">' +
                    '<span class="dash-active-tile__icon"><i class="fas ' + iconBusy + '"></i></span>' +
                    '<span class="dash-active-tile__name">' + escapeHtml(tbl.name) + '</span>' +
                    '<span class="dash-active-tile__meta"><i class="fas fa-box"></i> ' + Math.round(itemQty * 10) / 10 + ' ئایتم</span>' +
                    '<span class="dash-active-tile__status"><i class="fas fa-circle"></i> ' + statusLbl + '</span>' +
                    '</button>';
            });

            if (emptyEl) {
                var showEmpty = activeCount === 0;
                emptyEl.style.display = showEmpty ? 'flex' : 'none';
                container.style.display = showEmpty ? 'none' : 'grid';
            }
            if (db && db.settings && db.settings.language === 'ar') {
                var homeView = document.getElementById('view-home');
                if (homeView && typeof localizeHardcodedUiText === 'function') localizeHardcodedUiText(homeView);
            }
        }
        function countTableStats(list) {
            var free = 0, busy = 0;
            (list || []).forEach(function(t) {
                if (!t) return;
                if (t.items && t.items.length > 0) busy++;
                else free++;
            });
            return { free: free, busy: busy, total: (list || []).filter(function(t) { return !!t; }).length };
        }

        function getTableCardTotalIqd(table) {
            if (!table || !table.items || !table.items.length) return 0;
            return table.items.reduce(function(sum, item) {
                var u = typeof getBillLineUnitIqd === 'function' ? getBillLineUnitIqd(item) : (Number(item.price) || 0);
                var q = typeof getItemQty === 'function' ? getItemQty(item) : 1;
                return sum + u * q;
            }, 0);
        }

        function renderTables() {
            const currentTableState = JSON.stringify(db.tables) + isTableEditMode + (db.settings.enableTakeaway) + (db.settings.takeawayAsWholesale);
            if(currentTableState === lastTableState) return; 
            lastTableState = currentTableState;
            const grid = document.getElementById('tables-grid');
            if (!grid) return;
            
            const isTakeawayEnabled = db.settings && db.settings.enableTakeaway;
            const isJumlaMode = !!(db.settings && db.settings.takeawayAsWholesale);
            const mode = (db.settings && db.settings.systemMode) ? db.settings.systemMode : 'general';
            
            let tablesToRender = (db.tables || []).filter(t => t && !t.isTakeaway);
            let takeawayTables = (db.tables || []).filter(t => t && t.isTakeaway);
            var allStats = countTableStats(db.tables);

            var elTotal = document.getElementById('tables-stat-total');
            var elFree = document.getElementById('tables-stat-free');
            var elBusy = document.getElementById('tables-stat-busy');
            if (elTotal) elTotal.textContent = String(allStats.total);
            if (elFree) elFree.textContent = String(allStats.free);
            if (elBusy) elBusy.textContent = String(allStats.busy);

            let sectionTitle = 'سەبەتێن کڕینێ';
            let sectionSub = 'Shopping Carts';
            let sectionIcon = 'fa-shopping-cart';

            if (mode === 'restaurant') { sectionTitle = 'مێزێن نانخوارنێ'; sectionSub = 'Dine-in Tables'; sectionIcon = 'fa-utensils'; }
            else if (mode === 'pharmacy') { sectionTitle = 'وەسڵێن دەرمانان'; sectionSub = 'Prescriptions'; sectionIcon = 'fa-pills'; }
            else if (mode === 'company') { sectionTitle = 'داواکاریێن کۆمپانیێ'; sectionSub = 'Orders'; sectionIcon = 'fa-clipboard-list'; }
            else if (mode === 'market') { sectionTitle = 'سەبەتێن کڕینێ'; sectionSub = 'Shopping Carts'; sectionIcon = 'fa-shopping-basket'; }
            else if (mode === 'jewelry') { sectionTitle = 'سەبەتێن زیڤ و زێر'; sectionSub = 'Jewelry Carts'; sectionIcon = 'fa-gem'; }
            else if (mode === 'school') { sectionTitle = 'پۆلێن خوێندنێ'; sectionSub = 'Classes'; sectionIcon = 'fa-chalkboard-user'; }
            else if (mode === 'factory') { sectionTitle = 'بەچا بەرهەمهێنانێ'; sectionSub = 'Production Batches'; sectionIcon = 'fa-industry'; }
            else if (mode === 'cafe') { sectionTitle = 'مێز و داواکاری'; sectionSub = 'Cafe Tables'; sectionIcon = 'fa-mug-hot'; }

            var dineCards = renderTableCards(tablesToRender, mode);
            var dineEmpty = !tablesToRender.length && !isTableEditMode
                ? '<div class="tables-empty-hint"><i class="fas fa-cart-plus"></i><p>هیچ سەبەتەیەک نییە — دوگمەی <strong>+ سەبەتە</strong> دابگرە</p></div>'
                : '';

            let html = '<section class="tables-section tables-section--dine">' +
                '<div class="tables-section__head">' +
                '<div class="tables-section__brand"><span class="tables-section__icon"><i class="fas ' + sectionIcon + '"></i></span>' +
                '<div><h3 class="tables-section__title">' + escapeHtml(sectionTitle) + '</h3>' +
                '<p class="tables-section__sub">' + escapeHtml(sectionSub) + '</p></div></div>' +
                '<span class="tables-section__count">' + tablesToRender.length + ' سەبەتە</span></div>' +
                '<div class="tables-cards-grid">' + (dineCards || dineEmpty) + '</div></section>';

            if(isTakeawayEnabled || takeawayTables.length > 0) {
                var twCards = renderTableCards(takeawayTables, mode);
                var twTitle = isJumlaMode
                    ? ((typeof t === 'function') ? t('tables_section_jumla') : 'جوملە')
                    : ((typeof t === 'function') ? t('settings_jumla_mode_sefari') : 'سەفەری');
                var twSub = isJumlaMode ? 'Wholesale Orders' : 'Takeaway Orders';
                var twIcon = isJumlaMode ? 'fa-box' : 'fa-shopping-bag';
                html += '<section class="tables-section tables-section--takeaway' + (isJumlaMode ? ' tables-section--jumla' : '') + '">' +
                    '<div class="tables-section__head">' +
                    '<div class="tables-section__brand"><span class="tables-section__icon tables-section__icon--takeaway"><i class="fas ' + twIcon + '"></i></span>' +
                    '<div><h3 class="tables-section__title">' + escapeHtml(twTitle) + '</h3><p class="tables-section__sub">' + escapeHtml(twSub) + '</p></div></div>' +
                    '<button type="button" class="tables-takeaway-add" onclick="addTakeawayOrder()"><i class="fas fa-plus"></i> ' + escapeHtml(isJumlaMode ? ((typeof t === 'function') ? t('tables_add_jumla_order') : 'داواکاری') : 'داواکاری') + '</button></div>' +
                    '<div class="tables-cards-grid">' + (twCards || '<div class="tables-empty-hint tables-empty-hint--sm"><i class="fas ' + twIcon + '"></i><p>' + escapeHtml(isJumlaMode ? ((typeof t === 'function') ? t('tables_empty_jumla') : 'داواکاری جوملە زیاد بکە') : 'داواکاری سەفەری زیاد بکە') + '</p></div>') + '</div></section>';
            }

            grid.innerHTML = html;
            grid.classList.toggle('tables-layout-root--edit', !!isTableEditMode);
        }
        window.refreshTablesView = function() {
            lastTableState = '';
            renderTables();
        };

        function renderTableCards(tables, mode) {
            if (!tables || !tables.length) return '';
            return tables.filter(function(t) { return !!t; }).map(t => {
                const busy = Array.isArray(t.items) && t.items.length > 0;
                const hasNew = t.has_new_items;
                const itemCount = busy ? t.items.length : 0;
                
                let iconEmpty = 'fa-shopping-cart';
                let iconBusy = 'fa-box-open';
                if (mode === 'restaurant') { iconEmpty = 'fa-chair'; iconBusy = 'fa-utensils'; }
                else if (mode === 'cafe') { iconEmpty = 'fa-coffee'; iconBusy = 'fa-mug-hot'; }
                else if (mode === 'pharmacy') { iconEmpty = 'fa-prescription-bottle'; iconBusy = 'fa-pills'; }
                else if (mode === 'company') { iconEmpty = 'fa-clipboard'; iconBusy = 'fa-clipboard-check'; }
                else if (mode === 'market') { iconEmpty = 'fa-shopping-cart'; iconBusy = 'fa-shopping-basket'; }
                else if (mode === 'jewelry') { iconEmpty = 'fa-gem'; iconBusy = 'fa-ring'; }
                else if (mode === 'factory') { iconEmpty = 'fa-boxes'; iconBusy = 'fa-gears'; }

                const iconTakeaway = 'fa-shopping-bag';
                let icon = t.isTakeaway ? iconTakeaway : (busy ? iconBusy : iconEmpty);
                let statusClass = busy ? 'busy' : 'available';
                let statusText = busy ? 'مژوولە' : 'بەردەستە';
                let statusIcon = busy ? 'fa-circle' : 'fa-check-circle';

                if (hasNew && busy) {
                    statusClass = 'new-order';
                    statusText = 'داواکاری نوێ!';
                    statusIcon = 'fa-bell';
                    icon = 'fa-bell';
                }
                
                if (isTableEditMode) {
                    var safeName = String(t.name || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'");
                    return '<div class="table-card table-card--edit">' +
                        '<span class="table-card__edit-badge"><i class="fas fa-pen"></i></span>' +
                        '<div class="table-name">' + escapeHtml(t.name) + '</div>' +
                        '<div class="table-card__edit-actions">' +
                        '<button type="button" class="btn btn-sm btn-info" onclick="event.stopPropagation(); renameTable(' + t.id + ', \'' + safeName + '\')"><i class="fas fa-edit"></i></button>' +
                        '<button type="button" class="btn btn-sm btn-danger" onclick="event.stopPropagation(); deleteTable(' + t.id + ')"><i class="fas fa-trash-alt"></i></button>' +
                        '</div></div>';
                }

                var totalHtml = '';
                if (busy) {
                    var tot = getTableCardTotalIqd(t);
                    totalHtml = '<div class="table-total"><i class="fas fa-coins"></i> ' + formatCurrency(tot) + '</div>';
                }
                
                return '<button type="button" class="table-card table-card--' + statusClass + (t.isTakeaway ? ' table-card--takeaway' : '') + '" onclick="openTable(' + t.id + ')">' +
                    '<span class="table-card__glow" aria-hidden="true"></span>' +
                    '<span class="table-card__icon-wrap"><i class="fas ' + icon + ' table-icon"></i></span>' +
                    '<span class="table-name">' + escapeHtml(t.name) + '</span>' +
                    (busy ? '<span class="table-card__items"><i class="fas fa-box"></i> ' + itemCount + ' ئایتم</span>' : '') +
                    '<span class="table-status"><i class="fas ' + statusIcon + '"></i> ' + statusText + '</span>' +
                    totalHtml +
                    '</button>';
            }).join('');
        }
        function submitAddTableName(n) {
            if (!n || !String(n).trim()) return;
            n = String(n).trim();
            const formData = new FormData();
            formData.append('action', 'add_table');
            formData.append('name', n);
            var addTableUrl = (typeof posRouterUrl === 'function') ? posRouterUrl('action=add_table') : '?action=add_table';
            var addTableFetch = (typeof apiJson === 'function') ? apiJson(addTableUrl, { method: 'POST', body: formData }) : fetch(addTableUrl, { method: 'POST', body: formData, credentials: 'same-origin' }).then(function(r){ return r.json(); });
            addTableFetch
            .then(data => {
                if(data.status === 'success') { db.tables.push({id: data.id, name: n, items: []}); lastTableState = ""; renderTables(); if (typeof showToast === 'function') showToast('✅ ' + (typeof getTablesLabelShort === 'function' ? getTablesLabelShort() : 'مێز') + ' زیادکرا.'); }
                else if (typeof showToast === 'function') showToast('❌ ' + (data.message || 'هەڵە'), 'error');
            })
            .catch(err => { if (typeof showToast === 'function') showToast('❌ هەڵە: ' + (err.message || 'پەیوەندی'), 'error'); });
        }
        function addTable() {
            if (typeof openPosEntityNamePrompt === 'function') {
                openPosEntityNamePrompt({
                    entityType: 'table',
                    icon: 'fa-chair',
                    iconTone: 'table',
                    onConfirm: function(data) { submitAddTableName(data && data.name); }
                });
                return;
            }
            const n = prompt((typeof t === 'function') ? t('pos_entity_table_placeholder') : 'ناڤێ مێز...');
            if (n) submitAddTableName(n);
        }
        function addTakeawayOrder() {
            const n = "Takeaway #" + (Math.floor(Math.random() * 1000));
            const formData = new FormData();
            formData.append('action', 'add_table');
            formData.append('name', n);
            formData.append('isTakeaway', 1);
            var tkUrl = (typeof posRouterUrl === 'function') ? posRouterUrl('action=add_table') : '?action=add_table';
            var tkFetch = (typeof apiJson === 'function') ? apiJson(tkUrl, { method: 'POST', body: formData }) : fetch(tkUrl, { method: 'POST', body: formData, credentials: 'same-origin' }).then(function(r){ return r.json(); });
            tkFetch
            .then(data => {
                if(data.status === 'success') { db.tables.push({id: data.id, name: n, items: [], isTakeaway: true}); lastTableState = ""; renderTables(); openTable(data.id); if (typeof showToast === 'function') showToast('✅ داواکاری زیادکرا.'); }
                else if (typeof showToast === 'function') showToast('❌ ' + (data.message || 'هەڵە'), 'error');
            })
            .catch(err => { if (typeof showToast === 'function') showToast('❌ هەڵە: ' + (err.message || 'پەیوەندی'), 'error'); });
        }
        function transferTableUI() {
            const fromName = prompt("From Table:"); if (!fromName) return; const fromTable = db.tables.find(t => t.name == fromName);
            if (!fromTable || fromTable.items.length === 0) return alert("Empty!");
            const toName = prompt("To Table:"); if (!toName) return; const toTable = db.tables.find(t => t.name == toName);
            if (!toTable) return alert("Not Found!");
            if (confirm("Move?")) { toTable.items = [...toTable.items, ...fromTable.items]; fromTable.items = []; scheduleSave(); lastTableState = ""; renderAll(); }
        }
        
        function toggleTableEditMode() {
            isTableEditMode = !isTableEditMode;
            lastTableState = ""; 
            renderTables();
        }

        function submitRenameTable(id, newName, oldName) {
            if (!newName || newName === oldName) return;
            const formData = new FormData();
            formData.append('action', 'rename_table');
            formData.append('id', id);
            formData.append('name', newName);
            fetch('?action=rename_table', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                if(data.status === 'success') { const t = db.tables.find(x => x.id === id); if(t) t.name = newName; lastTableState = ""; renderTables(); if (typeof showToast === 'function') showToast('✅ ناو گۆڕدرا.'); }
                else if (typeof showToast === 'function') showToast('❌ ' + (data.message || 'هەڵە'), 'error');
            })
            .catch(err => { if (typeof showToast === 'function') showToast('❌ هەڵە: ' + (err.message || 'پەیوەندی'), 'error'); });
        }
        function renameTable(id, oldName) {
            var tFn = function(k, fb) {
                if (typeof t !== 'function') return fb || k;
                var v = t(k);
                return (v && v !== k) ? v : (fb || k);
            };
            if (typeof openPosEntityNamePrompt === 'function') {
                openPosEntityNamePrompt({
                    entityType: 'table',
                    icon: 'fa-pen',
                    iconTone: 'table',
                    defaultValue: oldName,
                    title: tFn('pos_entity_table_rename_title', 'گوهۆڕینا ناڤێ مێز'),
                    hint: tFn('pos_entity_table_rename_hint', 'ناڤێ نوێ بنووسە.'),
                    onConfirm: function(data) { submitRenameTable(id, data && data.name, oldName); }
                });
                return;
            }
            const newName = prompt(tFn('pos_entity_table_rename_hint', 'ناڤێ نوێ:'), oldName);
            if (newName && newName !== oldName) submitRenameTable(id, newName, oldName);
        }

        function deleteTable(id) {
            if(confirm("دڵنیای ژ ژێبرنا ڤێ " + (typeof getTablesLabelShort === 'function' ? getTablesLabelShort() : 'مێز') + "ێ؟")) {
                const formData = new FormData();
                formData.append('action', 'delete_table');
                formData.append('id', id);
                fetch('?action=delete_table', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if(data.status === 'success') { db.tables = db.tables.filter(t => t.id !== id); lastTableState = ""; renderTables(); if (typeof showToast === 'function') showToast('✅ ' + (typeof getTablesLabelShort === 'function' ? getTablesLabelShort() : 'مێز') + ' ژێبرا.'); }
                    else if (typeof showToast === 'function') showToast('❌ ' + (data.message || 'هەڵە'), 'error');
                })
                .catch(err => { if (typeof showToast === 'function') showToast('❌ هەڵە: ' + (err.message || 'پەیوەندی'), 'error'); });
            }
        }

        function printZReport() {
            printDetailedReport('daily');
        }
