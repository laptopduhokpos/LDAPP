/**
 * Global application state - single mutable object so all modules can read/write.
 * Replace global `db`, `currentUser`, etc. with state.db, state.currentUser.
 */
export const state = {
    db: null,
    displaySyncTimeout: null,
    activeTableId: null,
    currentUser: null,
    activeCategory: 'all',
    fileHandle: null,
    isFileConnected: false,
    currentViewingCompanyId: null,
    selectedSupplyProdId: null,
    lastTableState: '',
    saveTimeout: null,
    recentAddedItems: [],
    isTableEditMode: false,
    isReturnMode: false,
    isSupplyReturnMode: false,
    currentWhFilter: 'all',
    settingsClickCount: 0,
    settingsNavTimer: null,
    systemModeUnlocked: false,
    breadcrumbStack: [],
    currentBreadcrumbIndex: 0,
    lastSyncTime: 0,
    currentDebtParams: null,
    isProcessingPayment: false
};

if (typeof window !== 'undefined') {
    window.customerChannel = window.customerChannel || new BroadcastChannel('LAPTOP_DUHOK_POS_customer_display');
}
