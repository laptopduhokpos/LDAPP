// settings/print-labels.js — labels, print design
        // --- CENTRAL PRINT & DESIGN SETTINGS ---
        const PRINT_DESIGN_DEFAULTS = {
            pos_sale: { paper: '80mm', design: '7' },
            proforma: { paper: '80mm', design: '7' },
            kitchen_slip: { paper: '80mm', design: '1' },
            return_receipt: { paper: '80mm', design: '1' },
            delivery_slip: { paper: '80mm', design: '1' },
            inventory_report: { paper: '210mm', design: '1' },
            stock_movement_log: { paper: '210mm', design: '1' },
            stocktake_report: { paper: '210mm', design: '1' },
            stock_transfer_report: { paper: '80mm', design: '1' },
            debt_list: { paper: '210mm', design: '1' },
            company_ledger: { paper: '210mm', design: '1' },
            customer_ledger: { paper: '80mm', design: '1' },
            expenses_report: { paper: '210mm', design: '1' },
            daily_monthly_report: { paper: '210mm', design: '1' },
            purchase_invoice: { paper: '80mm', design: '1' },
            purchase_return: { paper: '80mm', design: '1' }
        };

        var LABEL_PRINT_DEFAULTS = {
            widthMm: 40,
            heightMm: 60,
            fontSize: 'medium',
            design: 'normal',
            printerName: '',
            printerId: '',
            silent: true,
            showName: true,
            showPrice: true,
            showBarcode: true,
            copies: 1,
            nameScale: 10,
            priceScale: 10
        };

        function normalizeLabelDesign(v) {
            v = String(v || '').toLowerCase();
            if (v === 'shop' || v === 'logo') return 'logo';
            if (v === 'logo2') return 'logo2';
            if (v === 'normal2') return 'normal2';
            return 'normal';
        }

        function isLogoLabelDesign(v) {
            var d = normalizeLabelDesign(v);
            return d === 'logo' || d === 'logo2';
        }

        var LABEL_SIZE_PRESETS_BUILTIN = ['40x60', '38x54', '50x30', '38x25'];

        function getLabelPrintSettings() {
            var s = (typeof db !== 'undefined' && db && db.settings && db.settings.labelPrint) ? db.settings.labelPrint : {};
            var w = Math.round(Number(s.widthMm != null ? s.widthMm : LABEL_PRINT_DEFAULTS.widthMm) || 40);
            var h = Math.round(Number(s.heightMm != null ? s.heightMm : LABEL_PRINT_DEFAULTS.heightMm) || 60);
            if (w < 20) w = 20; if (w > 120) w = 120;
            if (h < 15) h = 15; if (h > 100) h = 100;
            try {
                if (!localStorage.getItem('pos_label_portrait_40x60_v1')) {
                    localStorage.setItem('pos_label_portrait_40x60_v1', '1');
                    if (w === 60 && h === 40) {
                        w = 40;
                        h = 60;
                        if (typeof db !== 'undefined' && db && db.settings) {
                            if (!db.settings.labelPrint || typeof db.settings.labelPrint !== 'object') db.settings.labelPrint = {};
                            db.settings.labelPrint.widthMm = 40;
                            db.settings.labelPrint.heightMm = 60;
                        }
                    }
                }
            } catch (ePortrait) {}
            var font = String(s.fontSize || LABEL_PRINT_DEFAULTS.fontSize);
            if (['small', 'medium', 'large', 'xlarge'].indexOf(font) < 0) font = 'medium';
            var copies = Math.round(Number(s.copies) || 1);
            if (copies < 1) copies = 1; if (copies > 50) copies = 50;
            var printerName = String(s.printerName || '').trim().slice(0, 120);
            var printerId = String(s.printerId || '').trim();
            if (!printerName) {
                try { printerName = String(localStorage.getItem('pos_label_printer_name') || '').trim().slice(0, 120); } catch (e1) {}
            }
            if (!printerId) {
                try { printerId = String(localStorage.getItem('pos_label_printer_id') || '').trim(); } catch (e2) {}
            }
            if (!printerId && typeof db !== 'undefined' && db && db.settings && db.settings.printerRouting) {
                var routed = db.settings.printerRouting.product_label;
                if (routed && String(routed).indexOf('p') === 0) printerId = String(routed);
                else if (routed && !printerName) printerName = String(routed).trim();
            }
            if (printerId && !printerName) {
                try {
                    var pr = getPrinters().find(function (p) { return p && String(p.id) === String(printerId); });
                    if (pr) printerName = String(pr.name || '').trim();
                } catch (ePr) {}
            }
            var nameScale = Math.round(Number(s.nameScale != null ? s.nameScale : 10) || 10);
            if (nameScale < 1) nameScale = 1; if (nameScale > 20) nameScale = 20;
            var priceScale = Math.round(Number(s.priceScale != null ? s.priceScale : 10) || 10);
            if (priceScale < 1) priceScale = 1; if (priceScale > 20) priceScale = 20;
            return {
                widthMm: w,
                heightMm: h,
                fontSize: font,
                design: normalizeLabelDesign(s.design || LABEL_PRINT_DEFAULTS.design),
                nameScale: nameScale,
                priceScale: priceScale,
                printerName: printerName,
                printerId: printerId,
                showName: s.showName !== false && s.showName !== 0 && s.showName !== '0',
                showPrice: s.showPrice !== false && s.showPrice !== 0 && s.showPrice !== '0',
                showBarcode: s.showBarcode !== false && s.showBarcode !== 0 && s.showBarcode !== '0',
                silent: s.silent !== false && s.silent !== 0 && s.silent !== '0',
                copies: copies
            };
        }

        function collectDefinedPrinterOptions() {
            var seen = {};
            var out = [];
            function add(name, id, meta) {
                name = String(name || '').trim();
                if (!name) return;
                var key = name.toLowerCase();
                if (seen[key]) return;
                seen[key] = true;
                out.push({
                    name: name,
                    id: id || '',
                    offline: !!(meta && meta.offline),
                    source: (meta && meta.source) ? meta.source : 'defined'
                });
            }
            try {
                getPrinters().forEach(function (p) {
                    if (!p || p.status === 'inactive') return;
                    add(p.name, p.id, { source: 'pos' });
                });
            } catch (e1) {}
            try {
                var wh = [];
                if (typeof getWarehousePrinters === 'function') wh = getWarehousePrinters() || [];
                else if (typeof db !== 'undefined' && db && db.settings && Array.isArray(db.settings.warehouse_printers)) {
                    wh = db.settings.warehouse_printers;
                } else {
                    try { wh = JSON.parse(localStorage.getItem('pos_warehouse_printers') || '[]'); } catch (eLs) { wh = []; }
                }
                (wh || []).forEach(function (item) {
                    if (typeof item === 'string') add(item, '', { source: 'warehouse' });
                    else if (item && item.name) add(item.name, item.id || '', { source: 'warehouse' });
                });
            } catch (e2) {}
            try {
                var winList = (typeof window !== 'undefined' && Array.isArray(window._windowsPrinters))
                    ? window._windowsPrinters
                    : [];
                winList.forEach(function (p) {
                    if (!p) return;
                    var n = typeof p === 'string' ? p : p.name;
                    add(n, '', { source: 'windows', offline: !!(p && p.offline) });
                });
            } catch (e3) {}
            out.sort(function (a, b) {
                // Prefer Xprinter / POS label devices near top
                function rank(n) {
                    n = String(n || '').toLowerCase();
                    if (n.indexOf('xprinter') >= 0 || n.indexOf('xp-') >= 0) return 0;
                    if (n.indexOf('pos-') >= 0 || n.indexOf('label') >= 0) return 1;
                    if (n.indexOf('microsoft') >= 0 || n.indexOf('onenote') >= 0 || n.indexOf('pdf') >= 0 || n.indexOf('xps') >= 0 || n.indexOf('rustdesk') >= 0) return 9;
                    return 5;
                }
                var ra = rank(a.name);
                var rb = rank(b.name);
                if (ra !== rb) return ra - rb;
                return String(a.name).localeCompare(String(b.name), 'en', { sensitivity: 'base' });
            });
            return out;
        }

        function getLabelPrintAgentBase() {
            return 'http://127.0.0.1:9173';
        }
        var LABEL_PRINT_AGENT_BASE = getLabelPrintAgentBase();

        function labelPrintAgentHealth() {
            return fetch('http://127.0.0.1:9173/health', { method: 'GET', cache: 'no-store' })
                .then(function (r) { return r.json(); })
                .then(function (d) {
                    if (d && d.status === 'ok') {
                        LABEL_PRINT_AGENT_BASE = 'http://127.0.0.1:9173';
                        return true;
                    }
                    return false;
                })
                .catch(function () { return false; });
        }

        function loadWindowsPrinters(force) {
            return new Promise(function (resolve) {
                if (!force && typeof window !== 'undefined' && Array.isArray(window._windowsPrinters) && window._windowsPrintersLoaded) {
                    resolve(window._windowsPrinters);
                    return;
                }
                function applyList(list) {
                    list = Array.isArray(list) ? list : [];
                    if (typeof window !== 'undefined') {
                        window._windowsPrinters = list;
                        window._windowsPrintersLoaded = true;
                    }
                    resolve(list);
                }
                // Prefer user-session print agent (sees real Windows printers + can print)
                fetch(LABEL_PRINT_AGENT_BASE + '/printers', { method: 'GET', cache: 'no-store' })
                    .then(function (r) { return r.json(); })
                    .then(function (data) {
                        if (data && Array.isArray(data.printers) && data.printers.length) {
                            applyList(data.printers);
                            return;
                        }
                        throw new Error('empty agent');
                    })
                    .catch(function () {
                        var fd = new FormData();
                        fd.append('action', 'list_windows_printers');
                        fetch('?action=list_windows_printers', { method: 'POST', body: fd })
                            .then(function (r) { return r.json(); })
                            .then(function (data) {
                                applyList((data && Array.isArray(data.printers)) ? data.printers : []);
                            })
                            .catch(function () { applyList([]); });
                    });
            });
        }

        function silentPrintLabelToNamedPrinter(imageDataUrl, cfg, copies) {
            return new Promise(function (resolve) {
                if (!cfg || !cfg.printerName) {
                    resolve({ ok: false, message: 'no printer' });
                    return;
                }
                var sendName = String(cfg.printerName || '').trim();
                try {
                    var winList = (typeof window !== 'undefined' && Array.isArray(window._windowsPrinters))
                        ? window._windowsPrinters
                        : [];
                    var mapped = resolveWindowsPrinterName(sendName, winList);
                    if (mapped) sendName = mapped;
                } catch (eMapP) {}
                var payload = {
                    printer: sendName,
                    width_mm: cfg.widthMm || 50,
                    height_mm: cfg.heightMm || 30,
                    copies: copies || 1,
                    image: imageDataUrl
                };
                // 1) User-session agent (works with Xprinter)
                fetch(LABEL_PRINT_AGENT_BASE + '/print', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                })
                    .then(function (r) { return r.json().then(function (d) { return { httpOk: r.ok, data: d }; }); })
                    .then(function (res) {
                        if (res.data && res.data.status === 'success') {
                            resolve({ ok: true, data: res.data, via: 'agent' });
                            return;
                        }
                        throw new Error((res.data && res.data.message) ? res.data.message : 'agent failed');
                    })
                    .catch(function (agentErr) {
                        // 2) PHP fallback (often fails under Apache service account)
                        var fd = new FormData();
                        fd.append('action', 'silent_print_label');
                        fd.append('printer', sendName);
                        fd.append('width_mm', String(cfg.widthMm || 50));
                        fd.append('height_mm', String(cfg.heightMm || 30));
                        fd.append('copies', String(copies || 1));
                        fd.append('image', imageDataUrl);
                        fetch('?action=silent_print_label', { method: 'POST', body: fd })
                            .then(function (r) { return r.json(); })
                            .then(function (data) {
                                if (data && data.status === 'success') {
                                    resolve({ ok: true, data: data, via: 'php' });
                                } else {
                                    resolve({
                                        ok: false,
                                        message: (data && data.message)
                                            ? data.message
                                            : ((agentErr && agentErr.message) ? agentErr.message : 'failed'),
                                        needAgent: true
                                    });
                                }
                            })
                            .catch(function (err) {
                                resolve({
                                    ok: false,
                                    message: (err && err.message) ? err.message : 'network',
                                    needAgent: true
                                });
                            });
                    });
            });
        }

        function resolveWindowsPrinterName(preferName, list) {
            preferName = String(preferName || '').trim();
            if (!preferName) return '';
            var names = [];
            (list || []).forEach(function (p) {
                var n = typeof p === 'string' ? p : (p && p.name);
                if (n) names.push(String(n));
            });
            if (!names.length) return preferName;
            var lower = preferName.toLowerCase();
            var i;
            for (i = 0; i < names.length; i++) {
                if (names[i].toLowerCase() === lower) return names[i];
            }
            var base = preferName.replace(/\s+#\d+\s*$/, '');
            var baseLower = base.toLowerCase();
            var family = [];
            for (i = 0; i < names.length; i++) {
                var nl = names[i].toLowerCase();
                if (nl === baseLower || nl.indexOf(baseLower + ' #') === 0) family.push(names[i]);
            }
            if (family.length === 1) return family[0];
            if (family.length > 1) {
                family.sort(function (a, b) { return a.toLowerCase().localeCompare(b.toLowerCase()); });
                return family[family.length - 1];
            }
            return preferName;
        }

        function applyPrinterNameToSelect(sel, preferName, preferId, opts) {
            preferName = String(preferName || '').trim();
            preferId = String(preferId || '').trim();
            opts = opts || [];
            var mapped = resolveWindowsPrinterName(preferName, opts);
            if (mapped) {
                sel.value = mapped;
                if (sel.value === mapped) {
                    if (mapped !== preferName && typeof persistLabelPrintSettings === 'function' && sel.id === 'pds-label-printer-select') {
                        try { persistLabelPrintSettings(); } catch (eMap) {}
                    }
                    return;
                }
            }
            if (preferName) {
                sel.value = preferName;
                if (sel.value !== preferName) {
                    var keep = document.createElement('option');
                    keep.value = preferName;
                    keep.textContent = preferName;
                    if (preferId) keep.setAttribute('data-printer-id', preferId);
                    sel.appendChild(keep);
                    sel.value = preferName;
                }
            } else if (preferId) {
                var match = opts.find(function (p) { return p.id && p.id === preferId; });
                if (match) sel.value = match.name;
            }
        }

        function paintNamedPrinterSelect(sel, preferName, preferId) {
            if (!sel) return;
            preferName = String(preferName || '').trim();
            preferId = String(preferId || '').trim();
            var opts = collectDefinedPrinterOptions();
            var html = '<option value="">— هەڵبژێرە —</option>';
            opts.forEach(function (p) {
                var label = p.name;
                if (p.offline) label += ' (Offline)';
                html += '<option value="' + escapeHtml(p.name) + '" data-printer-id="' + escapeHtml(p.id || '') + '">' + escapeHtml(label) + '</option>';
            });
            sel.innerHTML = html;
            applyPrinterNameToSelect(sel, preferName, preferId, opts);
            if (!opts.length && !preferName) {
                var emptyHint = document.createElement('option');
                emptyHint.value = '';
                emptyHint.disabled = true;
                emptyHint.textContent = 'هیچ پرینتەرێک نەهاتە دیتن — نوێکردنەوە بکە';
                sel.appendChild(emptyHint);
            }
        }

        function fillLabelPrinterSelect(preferredName, preferredId) {
            var sel = document.getElementById('pds-label-printer-select');
            if (!sel) return;
            var saved = '';
            var savedId = '';
            try {
                if (typeof db !== 'undefined' && db && db.settings && db.settings.labelPrint) {
                    if (db.settings.labelPrint.printerName) saved = String(db.settings.labelPrint.printerName).trim();
                    if (db.settings.labelPrint.printerId) savedId = String(db.settings.labelPrint.printerId).trim();
                }
            } catch (eS) {}
            try {
                if (!saved) saved = String(localStorage.getItem('pos_label_printer_name') || '').trim();
                if (!savedId) savedId = String(localStorage.getItem('pos_label_printer_id') || '').trim();
            } catch (eLs) {}
            var cur = preferredName != null && String(preferredName).trim() !== ''
                ? String(preferredName).trim()
                : (saved || String(sel.value || '').trim());
            var curId = preferredId != null && String(preferredId).trim() !== '' 
                ? String(preferredId).trim() 
                : savedId;

            function paint(opts, preferName) {
                preferName = String(preferName || '').trim();
                var html = '<option value="">— هەڵبژێرە —</option>';
                opts.forEach(function (p) {
                    var label = p.name;
                    if (p.offline) label += ' (Offline)';
                    html += '<option value="' + escapeHtml(p.name) + '" data-printer-id="' + escapeHtml(p.id || '') + '">' + escapeHtml(label) + '</option>';
                });
                sel.innerHTML = html;
                applyPrinterNameToSelect(sel, preferName, curId, opts);
                if (!opts.length && !preferName) {
                    var emptyHint = document.createElement('option');
                    emptyHint.value = '';
                    emptyHint.disabled = true;
                    emptyHint.textContent = 'هیچ پرینتەرێک نەهاتە دیتن — نوێکردنەوە بکە';
                    sel.appendChild(emptyHint);
                }
            }

            function restoreSelection(preferName) {
                preferName = String(preferName || '').trim();
                if (!preferName) return;
                applyPrinterNameToSelect(sel, preferName, curId, collectDefinedPrinterOptions());
            }

            // Immediately restore from localStorage if available, to prevent flicker
            var _lsName = '';
            try { _lsName = String(localStorage.getItem('pos_label_printer_name') || '').trim(); } catch(e) {}
            var initialName = cur || _lsName;

            paint(collectDefinedPrinterOptions(), initialName);
            restoreSelection(initialName);
            loadWindowsPrinters(false).then(function () {
                var prefer = initialName;
                try {
                    if (typeof getLabelPrintSettings === 'function') {
                        var cfgLp = getLabelPrintSettings();
                        prefer = String(cfgLp.printerName || '').trim() || prefer;
                        if (!curId && cfgLp.printerId) curId = String(cfgLp.printerId);
                    }
                } catch (e2) {}
                try {
                    if (!prefer) prefer = String(localStorage.getItem('pos_label_printer_name') || '').trim();
                } catch (e3) {}
                paint(collectDefinedPrinterOptions(), prefer || initialName);
                restoreSelection(prefer || initialName);
                if (typeof renderPrintersList === 'function') renderPrintersList(true);
            });
        }

        function persistLabelPrintSettings(opts) {
            opts = opts || {};
            var cfg = saveLabelPrintSettingsFromForm();
            if (!cfg) return null;
            try {
                if (cfg.printerName) localStorage.setItem('pos_label_printer_name', cfg.printerName);
                else localStorage.removeItem('pos_label_printer_name');
                if (cfg.printerId) localStorage.setItem('pos_label_printer_id', cfg.printerId);
                else localStorage.removeItem('pos_label_printer_id');
            } catch (eLs) {}
            if (opts.skipServer) return cfg;
            if (typeof saveSettings === 'function') {
                saveSettings().catch(function () {});
            }
            return cfg;
        }

        function applyWindowsLabelPaperSize() {
            /* Windows paper size is set by the shop owner in printer preferences — do not overwrite. */
        }

        function onLabelPrinterSelectChange() {
            var cfg = persistLabelPrintSettings();
            if (typeof showToast === 'function') {
                var name = cfg && cfg.printerName ? cfg.printerName : '';
                if (name) showToast('✅ پرینتەری لزگە هاتە پاراستن: ' + name);
            }
        }

        function refreshLabelPrinterList() {
            if (typeof window !== 'undefined') window._windowsPrintersLoaded = false;
            var cfg = (typeof getLabelPrintSettings === 'function') ? getLabelPrintSettings() : {};
            var sel = document.getElementById('pds-label-printer-select');
            var cur = sel ? String(sel.value || '') : (cfg.printerName || '');
            if (typeof showToast === 'function') showToast('🔄 بارکرنا پرینتەرێن ویندۆز…');
            loadWindowsPrinters(true).then(function (list) {
                fillLabelPrinterSelect(cur, cfg.printerId || '');
                if (typeof showToast === 'function') {
                    showToast(list.length ? ('✅ ' + list.length + ' پرینتەر هاتنە دیتن') : '⚠️ هیچ پرینتەرێک نەهاتە دیتن', !list.length);
                }
            });
        }

        function readLabelPrintSettingsFromForm() {
            function num(id, def, min, max) {
                var el = document.getElementById(id);
                var n = el ? parseFloat(String(el.value || '').replace(/,/g, '')) : def;
                if (!isFinite(n)) n = def;
                n = Math.round(n);
                if (n < min) n = min;
                if (n > max) n = max;
                return n;
            }
            var fontEl = document.getElementById('pds-label-font');
            var designEl = document.getElementById('pds-label-design');
            var sel = document.getElementById('pds-label-printer-select');
            var showName = document.getElementById('pds-label-show-name');
            var showPrice = document.getElementById('pds-label-show-price');
            var showBarcode = document.getElementById('pds-label-show-barcode');
            var silentEl = document.getElementById('pds-label-silent');
            var printerName = sel ? String(sel.value || '').trim().slice(0, 120) : '';
            var printerId = '';
            if (sel && sel.selectedIndex >= 0) {
                var opt = sel.options[sel.selectedIndex];
                if (opt) printerId = String(opt.getAttribute('data-printer-id') || '').trim();
            }
            if (!printerId && printerName) {
                try {
                    var hit = getPrinters().find(function (p) {
                        return p && p.status !== 'inactive' && String(p.name || '').trim().toLowerCase() === printerName.toLowerCase();
                    });
                    if (hit) printerId = hit.id;
                } catch (eHit) {}
            }
            return {
                widthMm: num('pds-label-width', 40, 20, 120),
                heightMm: num('pds-label-height', 60, 15, 100),
                fontSize: (fontEl && fontEl.value) ? fontEl.value : 'medium',
                design: normalizeLabelDesign(designEl && designEl.value),
                nameScale: num('pds-label-name-scale', 10, 1, 20),
                priceScale: num('pds-label-price-scale', 10, 1, 20),
                printerName: printerName,
                printerId: printerId,
                showName: !!(showName && showName.checked),
                showPrice: !!(showPrice && showPrice.checked),
                showBarcode: !!(showBarcode && showBarcode.checked),
                silent: silentEl ? !!silentEl.checked : true,
                copies: num('pds-label-copies', 1, 1, 50)
            };
        }

        function applyLabelPrintSettingsToForm() {
            var cfg = getLabelPrintSettings();
            var map = {
                'pds-label-width': cfg.widthMm,
                'pds-label-height': cfg.heightMm,
                'pds-label-copies': cfg.copies,
                'pds-label-name-scale': cfg.nameScale != null ? cfg.nameScale : 10,
                'pds-label-price-scale': cfg.priceScale != null ? cfg.priceScale : 10
            };
            Object.keys(map).forEach(function (id) {
                var el = document.getElementById(id);
                if (el) el.value = String(map[id]);
            });
            var fontEl = document.getElementById('pds-label-font');
            if (fontEl) fontEl.value = cfg.fontSize;
            var designEl = document.getElementById('pds-label-design');
            if (designEl) designEl.value = normalizeLabelDesign(cfg.design);
            fillLabelPrinterSelect(cfg.printerName, cfg.printerId || '');
            fillLabelPresetSelect(cfg.widthMm + 'x' + cfg.heightMm);
            var sn = document.getElementById('pds-label-show-name');
            if (sn) sn.checked = !!cfg.showName;
            var sp = document.getElementById('pds-label-show-price');
            if (sp) sp.checked = !!cfg.showPrice;
            var sb = document.getElementById('pds-label-show-barcode');
            if (sb) sb.checked = !!cfg.showBarcode;
            var silentEl = document.getElementById('pds-label-silent');
            if (silentEl) silentEl.checked = cfg.silent !== false;
            var preset = document.getElementById('pds-label-preset');
            if (preset) {
                var key = cfg.widthMm + 'x' + cfg.heightMm;
                var found = false;
                Array.prototype.forEach.call(preset.options, function (opt) {
                    if (opt.value === key) found = true;
                });
                preset.value = found ? key : '';
            }
            updateLabelPrintPreview();
            if (typeof checkLabelPrintAgentStatus === 'function') {
                try { checkLabelPrintAgentStatus(); } catch (eSt) {}
            }
        }

        function onLabelDesignChange() {
            if (typeof persistLabelPrintSettings === 'function') persistLabelPrintSettings();
            if (typeof updateLabelPrintPreview === 'function') updateLabelPrintPreview();
        }

        function parseLabelPresetKey(val) {
            var m = String(val || '').trim().toLowerCase().match(/^(\d{2,3})\s*x\s*(\d{2,3})$/);
            if (!m) return null;
            var w = parseInt(m[1], 10);
            var h = parseInt(m[2], 10);
            if (!isFinite(w) || !isFinite(h) || w < 20 || w > 120 || h < 15 || h > 100) return null;
            return { key: w + 'x' + h, w: w, h: h };
        }

        function getLabelCustomPresets() {
            var list = [];
            try {
                var s = (typeof db !== 'undefined' && db && db.settings && db.settings.labelPrint) ? db.settings.labelPrint : null;
                if (s && Array.isArray(s.customPresets)) list = s.customPresets;
            } catch (e1) {}
            if (!list.length) {
                try {
                    list = JSON.parse(localStorage.getItem('pos_label_custom_presets') || '[]');
                } catch (e2) { list = []; }
            }
            var out = [];
            var seen = {};
            LABEL_SIZE_PRESETS_BUILTIN.forEach(function (k) { seen[k] = true; });
            (list || []).forEach(function (raw) {
                var p = parseLabelPresetKey(raw);
                if (!p || seen[p.key]) return;
                seen[p.key] = true;
                out.push(p.key);
            });
            return out;
        }

        function setLabelCustomPresets(list) {
            var clean = [];
            var seen = {};
            LABEL_SIZE_PRESETS_BUILTIN.forEach(function (k) { seen[k] = true; });
            (list || []).forEach(function (raw) {
                var p = parseLabelPresetKey(raw);
                if (!p || seen[p.key]) return;
                seen[p.key] = true;
                clean.push(p.key);
            });
            if (clean.length > 20) clean = clean.slice(0, 20);
            try {
                if (typeof db !== 'undefined' && db) {
                    if (!db.settings) db.settings = {};
                    if (!db.settings.labelPrint || typeof db.settings.labelPrint !== 'object') db.settings.labelPrint = {};
                    db.settings.labelPrint.customPresets = clean;
                }
            } catch (eDb) {}
            try { localStorage.setItem('pos_label_custom_presets', JSON.stringify(clean)); } catch (eLs) {}
            return clean;
        }

        function fillLabelPresetSelect(preferKey) {
            var sel = document.getElementById('pds-label-preset');
            if (!sel) return;
            var custom = getLabelCustomPresets();
            var keep = preferKey || String(sel.value || '');
            sel.innerHTML = '';
            LABEL_SIZE_PRESETS_BUILTIN.forEach(function (k) {
                var p = parseLabelPresetKey(k);
                if (!p) return;
                var opt = document.createElement('option');
                opt.value = p.key;
                opt.textContent = p.w + ' × ' + p.h + ' مم';
                sel.appendChild(opt);
            });
            custom.forEach(function (k) {
                var p = parseLabelPresetKey(k);
                if (!p) return;
                var opt = document.createElement('option');
                opt.value = p.key;
                opt.textContent = p.w + ' × ' + p.h + ' مم (یێ من)';
                sel.appendChild(opt);
            });
            if (keep && Array.prototype.some.call(sel.options, function (o) { return o.value === keep; })) {
                sel.value = keep;
            } else if (sel.options.length) {
                var wEl = document.getElementById('pds-label-width');
                var hEl = document.getElementById('pds-label-height');
                var cur = (wEl && hEl) ? (String(parseInt(wEl.value, 10)) + 'x' + String(parseInt(hEl.value, 10))) : '';
                if (cur && Array.prototype.some.call(sel.options, function (o) { return o.value === cur; })) sel.value = cur;
            }
        }

        function addCurrentLabelSizePreset() {
            var wEl = document.getElementById('pds-label-width');
            var hEl = document.getElementById('pds-label-height');
            var p = parseLabelPresetKey((wEl ? wEl.value : '') + 'x' + (hEl ? hEl.value : ''));
            if (!p) {
                if (typeof showToast === 'function') showToast('⚠️ قەبارە نەدرستە', true);
                return;
            }
            if (LABEL_SIZE_PRESETS_BUILTIN.indexOf(p.key) >= 0) {
                fillLabelPresetSelect(p.key);
                if (typeof showToast === 'function') showToast('ℹ️ ئەڤ قەبارە یا ئەساسیە');
                return;
            }
            var list = getLabelCustomPresets();
            if (list.indexOf(p.key) < 0) list.push(p.key);
            setLabelCustomPresets(list);
            fillLabelPresetSelect(p.key);
            if (typeof persistLabelPrintSettings === 'function') persistLabelPrintSettings();
            if (typeof showToast === 'function') showToast('✅ قەبارە هاتە زێدەکرن: ' + p.w + '×' + p.h);
        }

        function removeSelectedLabelSizePreset() {
            var sel = document.getElementById('pds-label-preset');
            var key = sel ? String(sel.value || '') : '';
            if (!key) return;
            if (LABEL_SIZE_PRESETS_BUILTIN.indexOf(key) >= 0) {
                if (typeof showToast === 'function') showToast('⚠️ قەبارێن ئەساسی ناهێنە ڕاکرن', true);
                return;
            }
            var list = getLabelCustomPresets().filter(function (k) { return k !== key; });
            setLabelCustomPresets(list);
            fillLabelPresetSelect(LABEL_SIZE_PRESETS_BUILTIN[0]);
            applyLabelSizePreset(LABEL_SIZE_PRESETS_BUILTIN[0]);
            if (typeof persistLabelPrintSettings === 'function') persistLabelPrintSettings();
            if (typeof showToast === 'function') showToast('🗑️ قەبارە هاتە ڕاکرن');
        }

        function applyLabelSizePreset(val) {
            if (!val || String(val).indexOf('x') < 0) return;
            var parts = String(val).split('x');
            var w = parseInt(parts[0], 10);
            var h = parseInt(parts[1], 10);
            var wEl = document.getElementById('pds-label-width');
            var hEl = document.getElementById('pds-label-height');
            if (wEl && isFinite(w)) wEl.value = String(w);
            if (hEl && isFinite(h)) hEl.value = String(h);
            updateLabelPrintPreview();
        }

        function labelPrintDpi(cfg) {
            var d = cfg && cfg.dpi != null ? Number(cfg.dpi) : 203;
            if (!isFinite(d) || d < 96) d = 203;
            if (d > 600) d = 600;
            return Math.round(d);
        }

        function getLabelShopName() {
            var n = '';
            try { n = String((typeof db !== 'undefined' && db && db.settings && db.settings.cafeName) || '').trim(); } catch (eN) {}
            if (n) return n.replace(/\s*POS\s*$/i, '').trim() || n;
            var b = (typeof window !== 'undefined' && window.POS_RECEIPT_BRAND && window.POS_RECEIPT_BRAND.name)
                ? String(window.POS_RECEIPT_BRAND.name) : '';
            if (b) return b.replace(/\s*POS\s*$/i, '').trim() || 'Laptop Duhok';
            return 'Laptop Duhok';
        }

        function formatLabelPhoneGroup(raw) {
            var d = String(raw || '').replace(/\D/g, '');
            if (d.length === 11) return d.slice(0, 4) + ' ' + d.slice(4, 7) + ' ' + d.slice(7);
            if (d.length === 10) return d.slice(0, 3) + ' ' + d.slice(3, 6) + ' ' + d.slice(6);
            return String(raw || '').trim();
        }

        function getLabelShopPhones() {
            var phone = '';
            try {
                if (typeof getReceiptContactInfo === 'function') phone = getReceiptContactInfo().phone || '';
            } catch (eC) {}
            if (!phone && typeof window !== 'undefined' && window.POS_RECEIPT_BRAND && window.POS_RECEIPT_BRAND.phone) {
                phone = String(window.POS_RECEIPT_BRAND.phone);
            }
            phone = String(phone || '').trim();
            if (!phone) return '';
            var parts = phone.split(/[-–—|,;]+/).map(function (p) { return p.trim(); }).filter(Boolean);
            if (parts.length >= 2) {
                return formatLabelPhoneGroup(parts[0]) + ' - ' + formatLabelPhoneGroup(parts[1]);
            }
            return formatLabelPhoneGroup(phone);
        }

        function getLabelShopLogoUrl() {
            try {
                if (typeof getPosShopLogoUrl === 'function') {
                    var u = String(getPosShopLogoUrl() || '').trim();
                    if (u) return u;
                }
            } catch (eL) {}
            return '';
        }

        function refreshLabelLogoPreview() {
            try {
                window.__posLabelLogoUrl = '';
                window.__posLabelLogoImg = null;
                window.__posLabelLogoThermalUrl = '';
            } catch (eC) {}
            if (typeof updateLabelPrintPreview === 'function') {
                try { updateLabelPrintPreview(); } catch (eP) {}
            }
        }

        function splitLabelNameLines(name) {
            name = String(name || '').replace(/\s+/g, ' ').trim();
            if (!name) return ['', ''];
            if (name.indexOf('\n') >= 0) {
                var nl = name.split(/\n/).map(function (x) { return x.trim(); }).filter(Boolean);
                return [nl[0] || '', nl[1] || ''];
            }
            if (name.indexOf(' / ') >= 0) {
                var sl = name.split(' / ');
                return [String(sl[0] || '').trim(), sl.slice(1).join(' / ').trim()];
            }
            var words = name.split(' ');
            if (words.length === 1) return [name, ''];
            if (words.length === 2) return [words[0], words[1]];
            var mid = Math.ceil(words.length / 2);
            return [words.slice(0, mid).join(' '), words.slice(mid).join(' ')];
        }

        function measureLabelTextWidth(text, fs, weight, family) {
            var ctx = measureLabelTextWidth._ctx;
            if (!ctx) {
                var c = document.createElement('canvas');
                measureLabelTextWidth._ctx = ctx = c.getContext('2d');
            }
            ctx.font = (weight || '800') + ' ' + Math.max(6, fs) + 'px ' + (family || 'Arial,Tahoma,sans-serif');
            return ctx.measureText(String(text || '')).width;
        }

        function wrapLabelWordsToWidth(text, maxWidth, fs, weight, family) {
            text = String(text || '').replace(/\s+/g, ' ').trim();
            if (!text) return [];
            if (!(maxWidth > 0)) return [text];
            var words = text.split(' ');
            var lines = [];
            var cur = '';
            for (var i = 0; i < words.length; i++) {
                var trial = cur ? (cur + ' ' + words[i]) : words[i];
                if (!cur || measureLabelTextWidth(trial, fs, weight, family) <= maxWidth) {
                    cur = trial;
                } else {
                    lines.push(cur);
                    cur = words[i];
                }
            }
            if (cur) lines.push(cur);
            return lines;
        }

        /** Wrap + shrink so the full name prints (no …). */
        function fitWrappedLabelName(text, maxWidth, startFs, minFs, maxLines, weight, family) {
            weight = weight || '800';
            family = family || 'Arial,Tahoma,sans-serif';
            text = String(text || '').replace(/\s+/g, ' ').trim();
            minFs = Math.max(6, minFs || 6);
            var fs = Math.max(minFs, startFs || minFs);
            maxLines = Math.max(1, maxLines || 3);
            function pack(fsz) {
                return wrapLabelWordsToWidth(text, maxWidth, fsz, weight, family);
            }
            var lines = pack(fs);
            function overflows(fsz, lns) {
                if (lns.length > maxLines) return true;
                for (var i = 0; i < lns.length; i++) {
                    if (measureLabelTextWidth(lns[i], fsz, weight, family) > maxWidth + 0.5) return true;
                }
                return false;
            }
            while (fs > minFs && overflows(fs, lines)) {
                fs -= 1;
                lines = pack(fs);
            }
            if (lines.length > maxLines) {
                var extra = lines.slice(maxLines).join(' ');
                lines = lines.slice(0, maxLines);
                if (extra) lines[maxLines - 1] = (lines[maxLines - 1] + ' ' + extra).trim();
                while (fs > minFs && overflows(fs, lines)) {
                    fs -= 1;
                    lines = pack(fs);
                    if (lines.length > maxLines) {
                        extra = lines.slice(maxLines).join(' ');
                        lines = lines.slice(0, maxLines);
                        if (extra) lines[maxLines - 1] = (lines[maxLines - 1] + ' ' + extra).trim();
                    }
                }
            }
            return { fs: fs, lines: lines.length ? lines : (text ? [text] : []) };
        }

        function formatShopLabelPrice(prod) {
            var usd = false;
            try { usd = typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD'; } catch (eU) {}
            if (usd) {
                var n = 0;
                try { n = (typeof getCatalogPieceSellUsd === 'function') ? getCatalogPieceSellUsd(prod) : 0; } catch (e2) { n = 0; }
                if (!(n > 0) && prod && prod.price_usd != null && prod.price_usd !== '') n = parseFloat(prod.price_usd);
                if (!isFinite(n) || n < 0) n = 0;
                var rounded = Math.round(n * 100) / 100;
                var s = (Math.abs(rounded - Math.round(rounded)) < 0.001) ? String(Math.round(rounded)) : String(rounded);
                return s + '$';
            }
            var iqd = 0;
            try {
                iqd = (typeof getCatalogPieceSellIqd === 'function') ? getCatalogPieceSellIqd(prod) : (Number(prod && prod.price) || 0);
            } catch (e3) { iqd = Number(prod && prod.price) || 0; }
            return (typeof formatCurrency === 'function') ? String(formatCurrency(iqd)) : String(Math.round(iqd));
        }

        function sampleLabelProduct(cfg) {
            if (isLogoLabelDesign(cfg && cfg.design) && (typeof canUseTechSpecs !== 'function' || canUseTechSpecs())) {
                return {
                    id: 28,
                    name: 'LENOVO THINKPAD E14 i5',
                    barcode: 'LD1743',
                    sku: 'LD1743',
                    price: 0,
                    price_usd: 264,
                    tech_specs: {
                        summary: '10TH R|8 SSD|256',
                        cpu: 'CORE i5 10TH GEN',
                        ram: '8 GB',
                        storage: 'SSD 256 GB',
                        gpu: 'INTEL 4 GB SHARE',
                        screen: '14.1 INCHES FHD'
                    }
                };
            }
            return { name: 'نموونەی ئایتم', barcode: '2001234567890', price: 1500 };
        }

        function productLabelSpecInfo(prod) {
            if (typeof getProductTechSpecLines !== 'function') {
                return { lines: [], summary: '', specs: null };
            }
            return getProductTechSpecLines(prod || {});
        }

        function labelTitleLinesForProduct(prod) {
            var title = (typeof getProductLabelTitle === 'function')
                ? getProductLabelTitle(prod)
                : String((prod && prod.name) || '');
            return splitLabelNameLines(title);
        }

        function shopLabelFontMul(cfg) {
            var font = cfg && cfg.fontSize;
            if (font === 'small') return 0.88;
            if (font === 'large') return 1.12;
            if (font === 'xlarge') return 1.22;
            return 1;
        }

        function labelNameScaleMul(cfg) {
            var n = Math.round(Number(cfg && cfg.nameScale != null ? cfg.nameScale : 10) || 10);
            if (n < 1) n = 1;
            if (n > 20) n = 20;
            return n / 10;
        }

        function labelPriceScaleMul(cfg) {
            var n = Math.round(Number(cfg && cfg.priceScale != null ? cfg.priceScale : 10) || 10);
            if (n < 1) n = 1;
            if (n > 20) n = 20;
            return n / 10;
        }

        function labelLaptopIconSvg(px) {
            var h = Math.max(18, Math.round(px));
            var w = Math.round(h * 1.28);
            return '<svg class="pos-label-laptop-ico" width="' + w + '" height="' + h + '" viewBox="0 0 80 62" aria-hidden="true">' +
                '<rect x="16" y="6" width="48" height="32" rx="3" fill="none" stroke="#000" stroke-width="2.4"/>' +
                '<path d="M8 42h64l-6 10H14z" fill="#000"/>' +
                '<circle cx="58" cy="10" r="7" fill="#fff" stroke="#000" stroke-width="2"/>' +
                '<circle cx="58" cy="10" r="2.2" fill="#000"/>' +
                '<circle cx="18" cy="18" r="1.4" fill="#000"/>' +
                '<circle cx="24" cy="14" r="1.2" fill="#000"/>' +
                '<path d="M18 18 L28 22 L36 16" fill="none" stroke="#000" stroke-width="1.4"/>' +
                '</svg>';
        }

        function drawLabelLaptopIcon(ctx, cx, top, size) {
            if (!ctx || !(size > 0)) return top;
            var scale = size / 62;
            ctx.save();
            ctx.translate(cx - (80 * scale) / 2, top);
            ctx.scale(scale, scale);
            ctx.strokeStyle = '#000';
            ctx.fillStyle = '#000';
            ctx.lineWidth = 2.4;
            ctx.lineJoin = 'round';
            if (typeof ctx.roundRect === 'function') {
                ctx.beginPath();
                ctx.roundRect(16, 6, 48, 32, 3);
                ctx.stroke();
            } else {
                ctx.strokeRect(16, 6, 48, 32);
            }
            ctx.beginPath();
            ctx.moveTo(8, 42);
            ctx.lineTo(72, 42);
            ctx.lineTo(66, 52);
            ctx.lineTo(14, 52);
            ctx.closePath();
            ctx.fill();
            ctx.beginPath();
            ctx.arc(58, 10, 7, 0, Math.PI * 2);
            ctx.fillStyle = '#fff';
            ctx.fill();
            ctx.stroke();
            ctx.beginPath();
            ctx.arc(58, 10, 2.2, 0, Math.PI * 2);
            ctx.fillStyle = '#000';
            ctx.fill();
            ctx.beginPath();
            ctx.arc(18, 18, 1.4, 0, Math.PI * 2);
            ctx.fill();
            ctx.beginPath();
            ctx.arc(24, 14, 1.2, 0, Math.PI * 2);
            ctx.fill();
            ctx.beginPath();
            ctx.moveTo(18, 18);
            ctx.lineTo(28, 22);
            ctx.lineTo(36, 16);
            ctx.stroke();
            ctx.restore();
            return top + size;
        }

        function thermalizeLogoForLabel(img) {
            if (!img || !(img.width || img.naturalWidth)) return null;
            var srcW = img.naturalWidth || img.width;
            var srcH = img.naturalHeight || img.height;
            if (!(srcW > 0) || !(srcH > 0)) return null;
            var maxSide = 360;
            var scale = Math.min(maxSide / srcW, maxSide / srcH, 4);
            var w = Math.max(8, Math.round(srcW * scale));
            var h = Math.max(8, Math.round(srcH * scale));
            var c = document.createElement('canvas');
            c.width = w;
            c.height = h;
            var ctx = c.getContext('2d');
            ctx.imageSmoothingEnabled = true;
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 0, w, h);
            try { ctx.drawImage(img, 0, 0, w, h); } catch (eD) { return null; }
            var data;
            try { data = ctx.getImageData(0, 0, w, h); } catch (eG) { return c; }
            var p = data.data;
            for (var i = 0; i < p.length; i += 4) {
                var a = p[i + 3] / 255;
                if (a < 0.08) {
                    p[i] = p[i + 1] = p[i + 2] = 255;
                    p[i + 3] = 255;
                    continue;
                }
                var r = p[i], g = p[i + 1], b = p[i + 2];
                var lum = (0.299 * r + 0.587 * g + 0.114 * b) * a + 255 * (1 - a);
                if (lum < 208) {
                    p[i] = p[i + 1] = p[i + 2] = 0;
                    p[i + 3] = 255;
                } else {
                    p[i] = p[i + 1] = p[i + 2] = 255;
                    p[i + 3] = 255;
                }
            }
            ctx.putImageData(data, 0, 0);
            return c;
        }

        function loadLabelLogoImage(url) {
            return new Promise(function (resolve) {
                if (!url) { resolve(null); return; }
                if (window.__posLabelLogoUrl === url && window.__posLabelLogoImg) {
                    resolve(window.__posLabelLogoImg);
                    return;
                }
                var img = new Image();
                img.onload = function () {
                    var thermal = thermalizeLogoForLabel(img) || img;
                    window.__posLabelLogoUrl = url;
                    window.__posLabelLogoImg = thermal;
                    try {
                        window.__posLabelLogoThermalUrl = (thermal && thermal.toDataURL)
                            ? thermal.toDataURL('image/png')
                            : '';
                    } catch (eT) {
                        window.__posLabelLogoThermalUrl = '';
                    }
                    resolve(thermal);
                };
                img.onerror = function () { resolve(null); };
                img.src = url;
            });
        }

        function labelFontPx(fontSize, cfg) {
            var h = (cfg && cfg.heightMm) ? Number(cfg.heightMm) : 40;
            if (!isFinite(h) || h <= 0) h = 30;
            var base = h / 30;
            var mul = 1;
            if (fontSize === 'small') mul = 0.85;
            else if (fontSize === 'large') mul = 1.2;
            else if (fontSize === 'xlarge') mul = 1.4;
            function px(n) { return Math.max(7, Math.round(n * base * mul)); }
            return {
                name: Math.max(7, Math.round(px(12) * labelNameScaleMul(cfg))),
                price: Math.max(8, Math.round(px(14) * labelPriceScaleMul(cfg))),
                barcodeH: px(28),
                barcodeFs: px(9),
                padMm: Math.max(0.6, Math.min(2, h * 0.05))
            };
        }

        function fitLabelFontsToBox(fonts, cfg, pixelH) {
            if (!fonts || !pixelH || pixelH <= 0) return fonts;
            var pad = Math.max(2, Math.round(pixelH * 0.05)) * 2;
            var total = pad;
            if (cfg.showName) total += fonts.name * 1.15;
            if (cfg.showPrice) total += fonts.price * 1.15 + 2;
            if (cfg.showBarcode) total += fonts.barcodeH + fonts.barcodeFs + 6;
            var maxH = pixelH * 0.94;
            if (total > maxH && total > 0) {
                var sc = maxH / total;
                // Don't shrink too much, but enough to fit
                fonts.name = Math.max(8, Math.round(fonts.name * sc));
                fonts.price = Math.max(9, Math.round(fonts.price * sc));
                fonts.barcodeH = Math.max(16, Math.round(fonts.barcodeH * sc));
                fonts.barcodeFs = Math.max(8, Math.round(fonts.barcodeFs * sc));
            }
            return fonts;
        }

        function buildShopLabelInnerHtml(prod, cfg, opts) {
            opts = opts || {};
            prod = prod || {};
            var esc = (typeof escapeHtml === 'function') ? escapeHtml : function (s) {
                return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
            };
            var pixelW = opts.pixelW ? Number(opts.pixelW) : 0;
            var pixelH = opts.pixelH ? Number(opts.pixelH) : 0;
            var sizeStyle = (pixelW && pixelH)
                ? ('width:' + pixelW + 'px;height:' + pixelH + 'px;')
                : ('width:' + cfg.widthMm + 'mm;height:' + cfg.heightMm + 'mm;');
            var padPx = (pixelH > 0) ? Math.max(3, Math.round(pixelH * 0.035)) : 4;
            var h = pixelH || Math.round((Number(cfg.heightMm) / 25.4) * 96);
            var shop = getLabelShopName();
            var phones = getLabelShopPhones();
            var specInfo = productLabelSpecInfo(prod);
            var hasSpecs = !!(specInfo.summary || (specInfo.lines && specInfo.lines.length));
            var lines = labelTitleLinesForProduct(prod);
            var priceStr = formatShopLabelPrice(prod);
            var barcode = String(prod.barcode || prod.sku || '').split(',')[0].trim();
            var sku = String(prod.sku || '').trim() || barcode;
            var idStr = (prod.id != null && String(prod.id) !== '' && String(prod.id) !== '0') ? String(prod.id) : '';
            var logoUrl = getLabelShopLogoUrl();
            var mul = shopLabelFontMul(cfg) * labelNameScaleMul(cfg);
            var priceMul = shopLabelFontMul(cfg) * labelPriceScaleMul(cfg);
            var icoH = Math.max(22, Math.round(h * 0.22));
            var shopFs = Math.max(8, Math.round(h * 0.05 * mul));
            var phoneFs = Math.max(6, Math.round(h * 0.03 * mul));
            var nameFs = Math.max(7, Math.round(h * 0.048 * mul));
            var priceFs = Math.max(12, Math.round(h * 0.17 * priceMul));
            var footFs = Math.max(6, Math.round(h * 0.036 * mul));
            var specFs = Math.max(6, Math.round(h * 0.032 * mul));
            var barH = Math.max(18, Math.round(h * 0.14));
            var compact = normalizeLabelDesign(cfg.design) === 'logo2';
            if (hasSpecs) {
                icoH = Math.max(16, Math.round(h * 0.14));
                nameFs = Math.max(7, Math.round(h * 0.042 * mul));
                priceFs = Math.max(10, Math.round(h * 0.11 * priceMul));
                barH = Math.max(16, Math.round(h * 0.12));
            }
            if (compact) icoH = Math.max(14, Math.round(icoH * 0.72));
            var logoSrc = (typeof window !== 'undefined' && window.__posLabelLogoThermalUrl)
                ? window.__posLabelLogoThermalUrl
                : logoUrl;
            var logoHtml = logoUrl
                ? ('<img src="' + esc(logoSrc) + '" alt="" style="height:' + icoH + 'px;max-width:92%;width:auto;object-fit:contain;display:block;margin:0 auto;filter:none;">')
                : labelLaptopIconSvg(icoH);
            var parts = [];
            parts.push('<div class="pos-label-sheet pos-label-shop" style="' + sizeStyle +
                'box-sizing:border-box;padding:' + padPx + 'px;display:flex;flex-direction:column;align-items:stretch;' +
                'text-align:center;font-family:Arial,Tahoma,sans-serif;color:#000;overflow:hidden;background:#fff;' +
                'border:1px solid #000;border-radius:' + Math.max(3, Math.round(h * 0.03)) + 'px;max-height:100%;">');
            parts.push('<div style="flex:0 0 auto;line-height:1.05;">' + logoHtml +
                '<div style="font-size:' + shopFs + 'px;font-weight:800;margin-top:1px;letter-spacing:0.2px;">' + esc(shop) + '</div>');
            if (!compact && phones) {
                parts.push('<div style="font-size:' + phoneFs + 'px;font-weight:600;direction:ltr;margin-top:1px;white-space:nowrap;overflow:hidden;">' + esc(phones) + '</div>');
            }
            parts.push('</div>');
            parts.push('<div style="border-top:1px solid #000;margin:3px 0 2px 0;flex:0 0 auto;"></div>');
            if (cfg.showName !== false) {
                var titleFull = hasSpecs
                    ? String(lines[0] || '').trim()
                    : String((lines[0] || '') + ' ' + (lines[1] || '')).replace(/\s+/g, ' ').trim();
                if (!titleFull && prod && prod.name) titleFull = String(prod.name).replace(/\s+/g, ' ').trim();
                var nameMaxW = (pixelW > 0)
                    ? Math.max(20, pixelW - padPx * 2)
                    : Math.max(40, Math.round((Number(cfg.widthMm) / 25.4) * 96) - padPx * 2);
                var nameFit = fitWrappedLabelName(titleFull.toUpperCase(), nameMaxW, nameFs, 6, hasSpecs ? 2 : 4, '800');
                nameFs = nameFit.fs;
                parts.push('<div style="flex:0 0 auto;font-size:' + nameFs + 'px;font-weight:800;line-height:1.12;text-transform:uppercase;overflow:visible;">');
                nameFit.lines.forEach(function (ln) {
                    parts.push('<div style="white-space:nowrap;overflow:visible;text-align:center;">' + esc(ln) + '</div>');
                });
                parts.push('</div>');
            }
            if (hasSpecs) {
                parts.push('<div style="flex:0 0 auto;margin-top:2px;direction:ltr;line-height:1.15;">');
                if (specInfo.summary) {
                    parts.push('<div style="font-size:' + Math.max(6, specFs) + 'px;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">' + esc(specInfo.summary) + '</div>');
                }
                (specInfo.lines || []).forEach(function (ln) {
                    var t = ln.label ? (ln.label + ' : ' + ln.value) : ln.value;
                    parts.push('<div style="font-size:' + specFs + 'px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">' + esc(t) + '</div>');
                });
                parts.push('</div>');
            }
            if (cfg.showPrice !== false && priceStr) {
                parts.push('<div style="flex:1 1 auto;display:flex;align-items:center;justify-content:center;font-size:' + priceFs +
                    'px;font-weight:900;line-height:0.95;letter-spacing:-0.5px;direction:ltr;">' + esc(priceStr) + '</div>');
            } else {
                parts.push('<div style="flex:1 1 auto;"></div>');
            }
            parts.push('<div style="border-top:1px solid #000;margin:2px 0 3px 0;flex:0 0 auto;"></div>');
            if (cfg.showBarcode !== false && barcode) {
                parts.push('<div style="flex:0 0 auto;width:100%;line-height:0;overflow:hidden;max-height:' + barH + 'px;">' +
                    '<svg class="pos-label-barcode" data-barcode="' + esc(barcode) + '" style="width:100%;height:' + barH + 'px;display:block;"></svg></div>');
                parts.push('<div style="flex:0 0 auto;display:flex;justify-content:space-between;align-items:center;direction:ltr;' +
                    'font-size:' + footFs + 'px;font-weight:700;margin-top:2px;letter-spacing:0.3px;">' +
                    '<span>' + esc(sku) + '</span><span>' + esc(idStr) + '</span></div>');
            }
            parts.push('</div>');
            return parts.join('');
        }

        function buildProductLabelInnerHtml(prod, cfg, opts) {
            cfg = cfg || getLabelPrintSettings();
            opts = opts || {};
            prod = prod || {};
            if (isLogoLabelDesign(cfg.design)) {
                return buildShopLabelInnerHtml(prod, cfg, opts);
            }
            var fonts = labelFontPx(cfg.fontSize, cfg);
            if (opts.pixelH) fonts = fitLabelFontsToBox(fonts, cfg, opts.pixelH);
            if (normalizeLabelDesign(cfg.design) === 'normal2') {
                fonts.price = Math.max(fonts.price + 2, Math.round(fonts.price * 1.5));
                fonts.name = Math.max(8, Math.round(fonts.name * 0.9));
            }
            var specInfoN = productLabelSpecInfo(prod);
            var hasSpecsN = !!(specInfoN.summary || (specInfoN.lines && specInfoN.lines.length));
            var name = (typeof getProductLabelTitle === 'function') ? getProductLabelTitle(prod) : (prod.name != null ? String(prod.name).trim() : 'نموونە');
            if (!name) name = 'نموونە';
            var barcode = String(prod.barcode || '1234567890123').split(',')[0].trim() || '1234567890123';
            var priceNum = 0;
            try {
                priceNum = (typeof getCatalogPieceSellIqd === 'function') ? getCatalogPieceSellIqd(prod) : (Number(prod.price) || 0);
            } catch (eP) { priceNum = Number(prod.price) || 0; }
            var priceStr = '';
            if (cfg.showPrice) {
                if (typeof formatCurrency === 'function') priceStr = formatCurrency(priceNum);
                else priceStr = String(Math.round(priceNum));
                if (typeof getCurrencySymbol === 'function') {
                    var sym = getCurrencySymbol();
                    if (sym && priceStr.indexOf(sym) < 0) priceStr = priceStr + ' ' + sym;
                }
            }
            var esc = (typeof escapeHtml === 'function') ? escapeHtml : function (s) {
                return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
            };
            var sizeStyle;
            if (opts.pixelW && opts.pixelH) {
                sizeStyle = 'width:' + opts.pixelW + 'px;height:' + opts.pixelH + 'px;';
            } else {
                sizeStyle = 'width:' + cfg.widthMm + 'mm;height:' + cfg.heightMm + 'mm;';
            }
            var pad = fonts.padMm;
            var padStyle = (opts.pixelW && opts.pixelH)
                ? ('padding:' + Math.max(2, Math.round(opts.pixelH * 0.05)) + 'px;')
                : ('padding:' + pad + 'mm;');
            var parts = [];
            parts.push('<div class="pos-label-sheet" style="' + sizeStyle + 'box-sizing:border-box;' + padStyle + 'display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;font-family:Tahoma,Arial,sans-serif;color:#000;overflow:hidden;background:#fff;max-height:100%;">');
            if (cfg.showName && name) {
                var nMaxW = (opts.pixelW)
                    ? Math.max(20, opts.pixelW - Math.max(4, Math.round((opts.pixelH || 80) * 0.1)))
                    : Math.max(40, Math.round((Number(cfg.widthMm) / 25.4) * 96) - 16);
                var nFit = fitWrappedLabelName(name, nMaxW, fonts.name, 7, hasSpecsN ? 2 : 3, '700', 'Tahoma,Arial,sans-serif');
                parts.push('<div style="font-size:' + nFit.fs + 'px;font-weight:700;line-height:1.12;max-width:100%;overflow:visible;">');
                nFit.lines.forEach(function (ln) {
                    parts.push('<div style="white-space:nowrap;overflow:visible;">' + esc(ln) + '</div>');
                });
                parts.push('</div>');
            }
            if (hasSpecsN && Number(cfg.heightMm) >= 48) {
                var nSpecFs = Math.max(6, Math.round(fonts.name * 0.72));
                if (specInfoN.summary) {
                    parts.push('<div style="font-size:' + nSpecFs + 'px;font-weight:700;direction:ltr;max-width:100%;overflow:hidden;white-space:nowrap;">' + esc(specInfoN.summary) + '</div>');
                }
                (specInfoN.lines || []).slice(0, 4).forEach(function (ln) {
                    var t = ln.label ? (ln.label + ' : ' + ln.value) : ln.value;
                    parts.push('<div style="font-size:' + nSpecFs + 'px;font-weight:700;direction:ltr;max-width:100%;overflow:hidden;white-space:nowrap;">' + esc(t) + '</div>');
                });
            }
            if (cfg.showPrice && priceStr) {
                parts.push('<div style="font-size:' + fonts.price + 'px;font-weight:800;margin-top:1px;line-height:1.05;white-space:nowrap;">' + esc(priceStr) + '</div>');
            }
            if (cfg.showBarcode && barcode) {
                parts.push('<div style="margin-top:1px;width:100%;line-height:0;overflow:hidden;max-height:' + fonts.barcodeH + 'px;"><svg class="pos-label-barcode" data-barcode="' + esc(barcode) + '" style="width:100%;height:' + fonts.barcodeH + 'px;display:block;"></svg></div>');
                parts.push('<div style="font-size:' + fonts.barcodeFs + 'px;letter-spacing:0.3px;margin-top:1px;direction:ltr;line-height:1;white-space:nowrap;">' + esc(barcode) + '</div>');
            }
            parts.push('</div>');
            return parts.join('');
        }

        function renderLabelBarcodesInRoot(root, cfg) {
            if (!root || typeof JsBarcode === 'undefined') return;
            var dpi = labelPrintDpi(cfg || {});
            var wMm = (cfg && cfg.widthMm) ? Number(cfg.widthMm) : 50;
            var wPx = Math.max(40, Math.round((wMm / 25.4) * dpi));
            var barModule = Math.max(1, Math.min(3, wPx / 220));
            root.querySelectorAll('svg.pos-label-barcode[data-barcode]').forEach(function (svg) {
                var code = svg.getAttribute('data-barcode') || '';
                if (!code) return;
                try {
                    JsBarcode(svg, code, {
                        format: 'CODE128',
                        displayValue: false,
                        margin: 0,
                        height: parseInt(svg.style.height, 10) || 34,
                        width: barModule,
                        lineColor: '#000'
                    });
                } catch (eBc) {}
            });
        }

        function updateLabelPrintPreview() {
            var wrap = document.getElementById('pds-label-preview');
            if (!wrap) return;
            var cfg = readLabelPrintSettingsFromForm();
            var sample = sampleLabelProduct(cfg);
            wrap.style.width = cfg.widthMm + 'mm';
            wrap.style.height = cfg.heightMm + 'mm';
            wrap.style.maxWidth = cfg.widthMm + 'mm';
            wrap.style.maxHeight = cfg.heightMm + 'mm';
            wrap.innerHTML = buildProductLabelInnerHtml(sample, cfg);
            renderLabelBarcodesInRoot(wrap, cfg);
            if (isLogoLabelDesign(cfg.design)) {
                var logoUrl = getLabelShopLogoUrl();
                if (logoUrl) {
                    loadLabelLogoImage(logoUrl).then(function () {
                        var src = window.__posLabelLogoThermalUrl || '';
                        if (!src) return;
                        wrap.querySelectorAll('.pos-label-shop img').forEach(function (im) { im.src = src; });
                    });
                }
            }
        }

        function saveLabelPrintSettingsFromForm(intoDb) {
            if (typeof db === 'undefined' || !db) return null;
            if (!db.settings) db.settings = {};
            var cfg = readLabelPrintSettingsFromForm();
            // If select not ready yet, keep previously saved printer
            if (!cfg.printerName) {
                try {
                    var prev = (db.settings.labelPrint && db.settings.labelPrint.printerName) || localStorage.getItem('pos_label_printer_name') || '';
                    if (prev) cfg.printerName = String(prev).trim();
                } catch (eKeep) {}
            }
            if (!cfg.printerId) {
                try {
                    var prevId = (db.settings.labelPrint && db.settings.labelPrint.printerId) || localStorage.getItem('pos_label_printer_id') || '';
                    if (prevId) cfg.printerId = String(prevId).trim();
                } catch (eKeepId) {}
            }
            var customKeep = getLabelCustomPresets();
            db.settings.labelPrint = cfg;
            db.settings.labelPrint.customPresets = customKeep;
            // Keep a printDesignSettings stub so routing keys stay consistent
            db.settings.printDesignSettings = db.settings.printDesignSettings || {};
            db.settings.printDesignSettings.product_label = {
                paper: cfg.widthMm + 'x' + cfg.heightMm,
                design: normalizeLabelDesign(cfg.design),
                widthMm: cfg.widthMm,
                heightMm: cfg.heightMm,
                fontSize: cfg.fontSize,
                printerName: cfg.printerName || ''
            };
            if (cfg.printerId) {
                db.settings.printerRouting = db.settings.printerRouting || {};
                db.settings.printerRouting.product_label = cfg.printerId;
            } else if (cfg.printerName) {
                db.settings.printerRouting = db.settings.printerRouting || {};
                db.settings.printerRouting.product_label = cfg.printerName;
            } else if (db.settings.printerRouting) {
                delete db.settings.printerRouting.product_label;
            }
            try {
                if (cfg.printerName) localStorage.setItem('pos_label_printer_name', cfg.printerName);
                else localStorage.removeItem('pos_label_printer_name');
                if (cfg.printerId) localStorage.setItem('pos_label_printer_id', cfg.printerId);
                else localStorage.removeItem('pos_label_printer_id');
            } catch (eLs) {}
            return cfg;
        }

        function ensureLabelCaptureHost() {
            var host = document.getElementById('pos-label-capture-host');
            if (!host) {
                host = document.createElement('div');
                host.id = 'pos-label-capture-host';
                host.setAttribute('aria-hidden', 'true');
                host.style.cssText = 'position:fixed;left:-12000px;top:0;background:#fff;color:#000;z-index:-1;pointer-events:none;';
                document.body.appendChild(host);
            }
            return host;
        }

        function fitCanvasText(ctx, text, maxWidth) {
            text = String(text || '');
            if (!text || !ctx || !maxWidth) return text;
            if (ctx.measureText(text).width <= maxWidth) return text;
            var trimmed = text;
            while (trimmed.length > 1 && ctx.measureText(trimmed + '…').width > maxWidth) {
                trimmed = trimmed.slice(0, -1);
            }
            return trimmed + '…';
        }

        function renderShopLabelCanvas(prod, cfg, extra) {
            extra = extra || {};
            prod = prod || {};
            var dpi = labelPrintDpi(cfg);
            var wPx = Math.max(40, Math.round((Number(cfg.widthMm) / 25.4) * dpi));
            var hPx = Math.max(30, Math.round((Number(cfg.heightMm) / 25.4) * dpi));
            var canvas = document.createElement('canvas');
            canvas.width = wPx;
            canvas.height = hPx;
            var ctx = canvas.getContext('2d');
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 0, wPx, hPx);
            ctx.strokeStyle = '#000000';
            ctx.fillStyle = '#000000';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'top';
            ctx.imageSmoothingEnabled = true;
            var pad = Math.max(3, Math.round(Math.min(wPx, hPx) * 0.04));
            var radius = Math.max(3, Math.round(hPx * 0.03));
            ctx.lineWidth = Math.max(1, Math.round(hPx * 0.006));
            if (typeof ctx.roundRect === 'function') {
                ctx.beginPath();
                ctx.roundRect(0.5, 0.5, wPx - 1, hPx - 1, radius);
                ctx.stroke();
            } else {
                ctx.strokeRect(1, 1, wPx - 2, hPx - 2);
            }
            var innerW = wPx - pad * 2;
            var cx = wPx / 2;
            var y = pad;
            var shop = getLabelShopName();
            var phones = getLabelShopPhones();
            var specInfo = productLabelSpecInfo(prod);
            var hasSpecs = !!(specInfo.summary || (specInfo.lines && specInfo.lines.length));
            var lines = labelTitleLinesForProduct(prod);
            var priceStr = formatShopLabelPrice(prod);
            var barcode = String(prod.barcode || prod.sku || '').split(',')[0].trim();
            var sku = String(prod.sku || '').trim() || barcode;
            var idStr = (prod.id != null && String(prod.id) !== '' && String(prod.id) !== '0') ? String(prod.id) : '';
            var mul = shopLabelFontMul(cfg) * labelNameScaleMul(cfg);
            var priceMul = shopLabelFontMul(cfg) * labelPriceScaleMul(cfg);
            var icoH = Math.max(22, Math.round(hPx * 0.22));
            var shopFs = Math.max(8, Math.round(hPx * 0.05 * mul));
            var phoneFs = Math.max(6, Math.round(hPx * 0.03 * mul));
            var nameFs = Math.max(7, Math.round(hPx * 0.048 * mul));
            var priceFs = Math.max(12, Math.round(hPx * 0.17 * priceMul));
            var footFs = Math.max(6, Math.round(hPx * 0.036 * mul));
            var specFs = Math.max(6, Math.round(hPx * 0.032 * mul));
            var compact = normalizeLabelDesign(cfg.design) === 'logo2';
            if (hasSpecs) {
                icoH = Math.max(16, Math.round(hPx * 0.14));
                nameFs = Math.max(7, Math.round(hPx * 0.042 * mul));
                priceFs = Math.max(10, Math.round(hPx * 0.11 * priceMul));
            }
            if (compact) icoH = Math.max(14, Math.round(icoH * 0.72));
            var logoImg = extra.logoImg;
            if (logoImg && (logoImg.width || logoImg.naturalWidth)) {
                var lw = Math.min(innerW * 0.92, icoH * ((logoImg.width || logoImg.naturalWidth) / Math.max(1, logoImg.height || logoImg.naturalHeight)));
                var lh = Math.min(icoH * 1.2, lw * ((logoImg.height || logoImg.naturalHeight) / Math.max(1, logoImg.width || logoImg.naturalWidth)));
                ctx.imageSmoothingEnabled = false;
                ctx.drawImage(logoImg, Math.round(cx - lw / 2), y, Math.round(lw), Math.round(lh));
                ctx.imageSmoothingEnabled = true;
                y += Math.round(lh) + 2;
            } else {
                y = drawLabelLaptopIcon(ctx, cx, y, icoH) + 2;
            }
            ctx.textAlign = 'center';
            ctx.fillStyle = '#000';
            ctx.font = '800 ' + shopFs + 'px Arial,Tahoma,sans-serif';
            ctx.fillText(fitCanvasText(ctx, shop, innerW), cx, y, innerW);
            y += shopFs + 2;
            if (!compact && phones) {
                ctx.font = '600 ' + phoneFs + 'px Arial,Tahoma,sans-serif';
                ctx.fillText(fitCanvasText(ctx, phones, innerW), cx, y, innerW);
                y += phoneFs + 3;
            }
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(pad, y);
            ctx.lineTo(wPx - pad, y);
            ctx.stroke();
            y += 4;
            if (cfg.showName !== false) {
                var titleFullC = hasSpecs
                    ? String(lines[0] || '').trim()
                    : String((lines[0] || '') + ' ' + (lines[1] || '')).replace(/\s+/g, ' ').trim();
                if (!titleFullC && prod && prod.name) titleFullC = String(prod.name).replace(/\s+/g, ' ').trim();
                var nameFitC = fitWrappedLabelName(titleFullC.toUpperCase(), innerW, nameFs, 6, hasSpecs ? 2 : 4, '800');
                nameFs = nameFitC.fs;
                ctx.font = '800 ' + nameFs + 'px Arial,Tahoma,sans-serif';
                nameFitC.lines.forEach(function (ln) {
                    ctx.fillText(ln, cx, y, innerW);
                    y += Math.round(nameFs * 1.12);
                });
            }
            if (hasSpecs) {
                ctx.font = '700 ' + specFs + 'px Arial,Tahoma,sans-serif';
                if (specInfo.summary) {
                    ctx.fillText(fitCanvasText(ctx, specInfo.summary, innerW), cx, y, innerW);
                    y += Math.round(specFs * 1.15);
                }
                (specInfo.lines || []).forEach(function (ln) {
                    var t = ln.label ? (ln.label + ' : ' + ln.value) : ln.value;
                    ctx.fillText(fitCanvasText(ctx, t, innerW), cx, y, innerW);
                    y += Math.round(specFs * 1.15);
                });
            }
            var footReserve = (cfg.showBarcode !== false && barcode) ? (Math.max(18, Math.round(hPx * 0.14)) + footFs + 10) : (pad + 4);
            var priceBottom = hPx - footReserve;
            if (cfg.showPrice !== false && priceStr) {
                ctx.font = '900 ' + priceFs + 'px Arial,Tahoma,sans-serif';
                var py = y + Math.max(0, Math.round((priceBottom - y - priceFs) / 2));
                ctx.fillText(fitCanvasText(ctx, priceStr, innerW), cx, py, innerW);
            }
            y = priceBottom;
            ctx.beginPath();
            ctx.moveTo(pad, y);
            ctx.lineTo(wPx - pad, y);
            ctx.stroke();
            y += 4;
            if (cfg.showBarcode !== false && barcode && typeof JsBarcode !== 'undefined') {
                var barH = Math.max(16, Math.round(hPx * 0.13));
                var barCanvas = document.createElement('canvas');
                var estModules = 35 + barcode.length * 11;
                var barModule = Math.max(1, Math.min(3, Math.floor(innerW / estModules)));
                try {
                    JsBarcode(barCanvas, barcode, {
                        format: 'CODE128',
                        displayValue: false,
                        margin: 0,
                        height: barH,
                        width: barModule,
                        lineColor: '#000000',
                        background: '#ffffff'
                    });
                } catch (eBc) {}
                if (barCanvas.width > 0 && barCanvas.height > 0) {
                    var maxBarW = innerW;
                    var dw = barCanvas.width;
                    var dh = barCanvas.height;
                    if (dw > maxBarW) {
                        var sc = maxBarW / dw;
                        dw = maxBarW;
                        dh = Math.round(dh * sc);
                    }
                    ctx.drawImage(barCanvas, Math.round((wPx - dw) / 2), y, dw, dh);
                    y += dh + 2;
                } else {
                    y += barH + 2;
                }
                ctx.font = '700 ' + footFs + 'px Arial,Tahoma,sans-serif';
                ctx.textAlign = 'left';
                ctx.fillText(fitCanvasText(ctx, sku, innerW * 0.7), pad, y, innerW * 0.7);
                ctx.textAlign = 'right';
                if (idStr) ctx.fillText(idStr, wPx - pad, y, innerW * 0.28);
            }
            return canvas;
        }

        function renderProductLabelCanvas(prod, cfg, extra) {
            cfg = cfg || getLabelPrintSettings();
            if (isLogoLabelDesign(cfg.design)) {
                return renderShopLabelCanvas(prod, cfg, extra || {});
            }
            prod = prod || {};
            var dpi = labelPrintDpi(cfg);
            var wPx = Math.max(40, Math.round((Number(cfg.widthMm) / 25.4) * dpi));
            var hPx = Math.max(30, Math.round((Number(cfg.heightMm) / 25.4) * dpi));
            var fonts = labelFontPx(cfg.fontSize, cfg);
            fonts = fitLabelFontsToBox(fonts, cfg, hPx);
            if (normalizeLabelDesign(cfg.design) === 'normal2') {
                fonts.price = Math.max(fonts.price + 2, Math.round(fonts.price * 1.5));
                fonts.name = Math.max(8, Math.round(fonts.name * 0.9));
            }

            var specInfoN = productLabelSpecInfo(prod);
            var hasSpecsN = !!(specInfoN.summary || (specInfoN.lines && specInfoN.lines.length));
            var name = (typeof getProductLabelTitle === 'function') ? getProductLabelTitle(prod) : (prod.name != null ? String(prod.name).trim() : 'نموونە');
            if (!name) name = 'نموونە';
            var barcode = String(prod.barcode || '1234567890123').split(',')[0].trim() || '1234567890123';
            var priceNum = 0;
            try {
                priceNum = (typeof getCatalogPieceSellIqd === 'function') ? getCatalogPieceSellIqd(prod) : (Number(prod.price) || 0);
            } catch (eP) { priceNum = Number(prod.price) || 0; }
            var priceStr = '';
            if (cfg.showPrice) {
                if (typeof formatCurrency === 'function') priceStr = formatCurrency(priceNum);
                else priceStr = String(Math.round(priceNum));
                if (typeof getCurrencySymbol === 'function') {
                    var sym = getCurrencySymbol();
                    if (sym && priceStr.indexOf(sym) < 0) priceStr = priceStr + ' ' + sym;
                }
            }

            var canvas = document.createElement('canvas');
            canvas.width = wPx;
            canvas.height = hPx;
            var ctx = canvas.getContext('2d');
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 0, wPx, hPx);
            ctx.fillStyle = '#000000';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'top';
            ctx.imageSmoothingEnabled = false;

            var nSpecFs = Math.max(6, Math.round(fonts.name * 0.72));
            var showSpecN = hasSpecsN && Number(cfg.heightMm) >= 48;
            var specLineCount = showSpecN ? ((specInfoN.summary ? 1 : 0) + Math.min(4, (specInfoN.lines || []).length)) : 0;
            var pad = Math.max(2, Math.round(hPx * 0.05));
            var maxTextW = wPx - pad * 2;
            var cx = wPx / 2;
            var nameFitN = { fs: fonts.name, lines: [] };
            if (cfg.showName && name) {
                nameFitN = fitWrappedLabelName(name, maxTextW, fonts.name, 7, showSpecN ? 2 : 3, '700', 'Tahoma,Arial,sans-serif');
            }
            var blockH = 0;
            if (cfg.showName && name) blockH += nameFitN.lines.length * Math.round(nameFitN.fs * 1.12) + 2;
            if (showSpecN) blockH += specLineCount * Math.round(nSpecFs * 1.12);
            if (cfg.showPrice && priceStr) blockH += Math.round(fonts.price * 1.08) + 2;
            if (cfg.showBarcode && barcode) blockH += fonts.barcodeH + fonts.barcodeFs + 4;
            var y = Math.max(pad, Math.round((hPx - blockH) / 2));
            
            // Adjust Y if block is larger than height to prevent cutting top
            if (y < pad) y = pad;

            if (cfg.showName && name) {
                ctx.font = '700 ' + nameFitN.fs + 'px Tahoma,Arial,sans-serif';
                nameFitN.lines.forEach(function (ln) {
                    ctx.fillText(ln, cx, y, maxTextW);
                    y += Math.round(nameFitN.fs * 1.12);
                });
                y += 2;
            }
            if (showSpecN) {
                ctx.font = '700 ' + nSpecFs + 'px Tahoma,Arial,sans-serif';
                if (specInfoN.summary) {
                    ctx.fillText(fitCanvasText(ctx, specInfoN.summary, maxTextW), cx, y, maxTextW);
                    y += Math.round(nSpecFs * 1.12);
                }
                (specInfoN.lines || []).slice(0, 4).forEach(function (ln) {
                    var t = ln.label ? (ln.label + ' : ' + ln.value) : ln.value;
                    ctx.fillText(fitCanvasText(ctx, t, maxTextW), cx, y, maxTextW);
                    y += Math.round(nSpecFs * 1.12);
                });
            }
            if (cfg.showPrice && priceStr) {
                ctx.font = '800 ' + fonts.price + 'px Tahoma,Arial,sans-serif';
                ctx.fillText(priceStr, cx, y, maxTextW);
                y += Math.round(fonts.price * 1.08) + 2;
            }
            if (cfg.showBarcode && barcode && typeof JsBarcode !== 'undefined') {
                var barCanvas = document.createElement('canvas');
                var estModules = 35 + barcode.length * 11;
                var barModule = Math.max(2, Math.min(4, Math.floor(maxTextW / estModules)));
                try {
                    JsBarcode(barCanvas, barcode, {
                        format: 'CODE128',
                        displayValue: false,
                        margin: 0,
                        height: fonts.barcodeH,
                        width: barModule,
                        lineColor: '#000000',
                        background: '#ffffff'
                    });
                } catch (eBc) {}
                if (barCanvas.width > 0 && barCanvas.height > 0) {
                    var bx = Math.round((wPx - barCanvas.width) / 2);
                    ctx.drawImage(barCanvas, bx, y);
                }
                y += fonts.barcodeH + 2;
                ctx.font = '600 ' + fonts.barcodeFs + 'px Consolas,monospace';
                ctx.fillText(barcode, cx, y);
            }
            return canvas;
        }

        function renderProductLabelToPng(prod, cfg) {
            cfg = cfg || getLabelPrintSettings();
            if (isLogoLabelDesign(cfg.design)) {
                var url = getLabelShopLogoUrl();
                if (!url) {
                    return Promise.resolve(renderProductLabelCanvas(prod, cfg).toDataURL('image/png'));
                }
                return loadLabelLogoImage(url).then(function (img) {
                    return renderProductLabelCanvas(prod, cfg, { logoImg: img }).toDataURL('image/png');
                });
            }
            return Promise.resolve(renderProductLabelCanvas(prod, cfg).toDataURL('image/png'));
        }

        function captureLabelSheetPng(sheetEl, cfg) {
            if (cfg && cfg._labelProd) {
                return renderProductLabelToPng(cfg._labelProd, cfg);
            }
            return new Promise(function (resolve, reject) {
                if (!sheetEl) {
                    reject(new Error('no sheet'));
                    return;
                }
                var dpi = labelPrintDpi(cfg);
                var wPx = Math.max(40, Math.round((Number(cfg.widthMm) / 25.4) * dpi));
                var hPx = Math.max(30, Math.round((Number(cfg.heightMm) / 25.4) * dpi));
                sheetEl.style.width = wPx + 'px';
                sheetEl.style.height = hPx + 'px';
                sheetEl.style.boxSizing = 'border-box';
                sheetEl.style.overflow = 'hidden';
                sheetEl.style.maxHeight = hPx + 'px';

                function finishCanvas(srcCanvas) {
                    try {
                        var out = document.createElement('canvas');
                        out.width = wPx;
                        out.height = hPx;
                        var ctx = out.getContext('2d');
                        ctx.fillStyle = '#ffffff';
                        ctx.fillRect(0, 0, wPx, hPx);
                        ctx.imageSmoothingEnabled = false;
                        ctx.drawImage(srcCanvas, 0, 0, wPx, hPx);
                        resolve(out.toDataURL('image/png'));
                    } catch (e1) {
                        reject(e1);
                    }
                }

                if (typeof html2canvas === 'function') {
                    requestAnimationFrame(function () {
                        html2canvas(sheetEl, {
                            backgroundColor: '#ffffff',
                            scale: 1,
                            width: wPx,
                            height: hPx,
                            windowWidth: wPx,
                            windowHeight: hPx,
                            logging: false,
                            useCORS: true
                        }).then(finishCanvas).catch(reject);
                    });
                    return;
                }
                try {
                    var c = document.createElement('canvas');
                    c.width = wPx;
                    c.height = hPx;
                    var ctx2 = c.getContext('2d');
                    ctx2.fillStyle = '#fff';
                    ctx2.fillRect(0, 0, wPx, hPx);
                    ctx2.fillStyle = '#000';
                    ctx2.font = 'bold 16px Tahoma,Arial';
                    ctx2.textAlign = 'center';
                    ctx2.fillText(sheetEl.textContent || 'LABEL', wPx / 2, hPx / 2);
                    resolve(c.toDataURL('image/png'));
                } catch (e2) {
                    reject(e2);
                }
            });
        }

        function printLabelViaBrowserDialog(labelsHtml, cfg) {
            cfg = cfg || getLabelPrintSettings();
            var titleHint = cfg.printerName ? ('Label → ' + cfg.printerName) : 'Product Label';
            var css = '@page{size:' + cfg.widthMm + 'mm ' + cfg.heightMm + 'mm;margin:0}' +
                'html,body{margin:0;padding:0;width:' + cfg.widthMm + 'mm;background:#fff;}' +
                '*{box-sizing:border-box;-webkit-print-color-adjust:exact;print-color-adjust:exact;}' +
                '@media print{html,body{width:' + cfg.widthMm + 'mm;}}';
            var frame = document.getElementById('hidden-label-print-frame');
            if (!frame) {
                frame = document.createElement('iframe');
                frame.id = 'hidden-label-print-frame';
                frame.setAttribute('aria-hidden', 'true');
                frame.style.cssText = 'position:fixed;width:0;height:0;border:0;opacity:0;pointer-events:none;left:-9999px;top:-9999px;';
                document.body.appendChild(frame);
            }
            var doc = frame.contentDocument || frame.contentWindow.document;
            doc.open();
            doc.write('<!DOCTYPE html><html><head><meta charset="utf-8"><title>' +
                String(titleHint).replace(/</g, '') + '</title><style>' + css + '</style></head><body>' +
                labelsHtml + '</body></html>');
            doc.close();
            renderLabelBarcodesInRoot(doc.body);
            var win = frame.contentWindow;
            setTimeout(function () {
                try {
                    win.focus();
                    win.print();
                } catch (ePr) {
                    console.error('Label print error', ePr);
                }
            }, 180);
        }

        function printLabelHtmlDocument(oneSheetHtml, cfg, copies) {
            cfg = cfg || getLabelPrintSettings();
            copies = Math.max(1, Math.min(50, Math.round(Number(copies) || 1)));
            var wantSilent = cfg.silent !== false && !!(cfg.printerName);

            function doBrowserFallback(multiHtml) {
                printLabelViaBrowserDialog(multiHtml, cfg);
                if (typeof showToast === 'function') {
                    showToast('🖨️ شاشەی چاپ — پرینتەر: ' + (cfg.printerName || 'هەڵبژێرە') + ' · ' + cfg.widthMm + '×' + cfg.heightMm + ' مم');
                }
            }

            if (!wantSilent) {
                var all = '';
                for (var i = 0; i < copies; i++) all += oneSheetHtml;
                doBrowserFallback(all);
                return;
            }

            if (typeof showToast === 'function') {
                showToast('🖨️ چاپا ڕاستەوخۆ → ' + cfg.printerName + ' …');
            }

            function sendPng(png) {
                return silentPrintLabelToNamedPrinter(png, cfg, copies).then(function (res) {
                    if (res && res.ok) {
                        if (typeof showToast === 'function') {
                            showToast('✅ لزگە هاتە چاپکرن → ' + cfg.printerName);
                        }
                        return;
                    }
                    if (typeof showToast === 'function') {
                        var tip = (res && res.needAgent)
                            ? ' — Start_POS_LabelPrint.bat بکەرەوە و پەنجەرەی Agent بکەرەوە بمێنێت'
                            : '';
                        showToast('⚠️ چاپ سەرنەکەوت: ' + ((res && res.message) || 'پرینتەر') + tip, true);
                    }
                });
            }

            // Sharp path: render directly on canvas at printer DPI (no html2canvas blur)
            if (cfg._labelProd) {
                renderProductLabelToPng(cfg._labelProd, cfg).then(sendPng).catch(function (err) {
                    if (typeof showToast === 'function') {
                        showToast('⚠️ چاپا ڕاستەوخۆ سەرنەکەوت — ' + ((err && err.message) || ''), true);
                    }
                });
                return;
            }

            var host = ensureLabelCaptureHost();
            var dpi = labelPrintDpi(cfg);
            var wPx = Math.max(40, Math.round((Number(cfg.widthMm) / 25.4) * dpi));
            var hPx = Math.max(30, Math.round((Number(cfg.heightMm) / 25.4) * dpi));
            var captureHtml = oneSheetHtml;
            if (cfg._labelProd) {
                captureHtml = buildProductLabelInnerHtml(cfg._labelProd, cfg, { pixelW: wPx, pixelH: hPx });
            }
            host.innerHTML = captureHtml;
            host.style.width = wPx + 'px';
            host.style.height = hPx + 'px';
            host.style.overflow = 'hidden';
            renderLabelBarcodesInRoot(host, cfg);
            var sheet = host.querySelector('.pos-label-sheet');
            if (sheet) {
                sheet.style.width = wPx + 'px';
                sheet.style.height = hPx + 'px';
                sheet.style.overflow = 'hidden';
                sheet.style.maxHeight = hPx + 'px';
            }
            if (!sheet) {
                if (typeof showToast === 'function') showToast('⚠️ نەشێت لزگە ئامادە بکرێت', true);
                return;
            }

            setTimeout(function () {
                captureLabelSheetPng(sheet, cfg).then(sendPng).catch(function (err) {
                    host.innerHTML = '';
                    if (typeof showToast === 'function') {
                        showToast('⚠️ چاپا ڕاستەوخۆ سەرنەکەوت — ' + ((err && err.message) || ''), true);
                    }
                }).then(function () { host.innerHTML = ''; });
            }, 120);
        }

        function printProductLabel(idOrProd, copiesOverride, opts) {
            opts = opts || {};
            var prod = null;
            if (idOrProd && typeof idOrProd === 'object') prod = idOrProd;
            else if (typeof db !== 'undefined' && db && Array.isArray(db.products)) {
                prod = db.products.find(function (p) { return String(p.id) === String(idOrProd); });
            }
            if (!prod) {
                if (typeof showToast === 'function') showToast('⚠️ ئایتم نەهاتە دیتن', true);
                return;
            }
            var cfg = opts.useForm && document.getElementById('pds-label-width')
                ? readLabelPrintSettingsFromForm()
                : getLabelPrintSettings();
            var copies = copiesOverride != null ? copiesOverride : cfg.copies;
            copies = Math.max(1, Math.min(50, Math.round(Number(copies) || 1)));
            if (!cfg.printerName && cfg.silent !== false) {
                if (typeof showToast === 'function') {
                    showToast('⚠️ سەرەتا پرینتەری لزگە لە دیزاینی چاپ هەڵبژێرە', true);
                }
            }
            var one = buildProductLabelInnerHtml(prod, cfg);
            cfg._labelProd = prod;
            printLabelHtmlDocument(one, cfg, copies);
            if (typeof logPrintAction === 'function') {
                try { logPrintAction('product_label', prod.id, 'print', cfg.printerName || '', cfg.widthMm + 'x' + cfg.heightMm); } catch (eL) {}
            }
        }

        function testPrintProductLabel() {
            saveLabelPrintSettingsFromForm();
            var cfg = readLabelPrintSettingsFromForm() || getLabelPrintSettings();
            var sample = sampleLabelProduct(cfg);
            if (!isLogoLabelDesign(cfg.design)) {
                sample = { id: 0, name: 'تاقیکرنا لزگە', barcode: '2001234567890', price: 2500 };
            }
            printProductLabel(sample, 1, { useForm: true });
        }

        function checkLabelPrintAgentStatus(showToastMsg) {
            var el = document.getElementById('pds-label-agent-status');
            labelPrintAgentHealth().then(function (ok) {
                if (el) {
                    el.style.color = ok ? '#059669' : '#dc2626';
                    el.innerHTML = ok
                        ? ('✅ Agent کار دکەت (' + getLabelPrintAgentBase().replace(/^https?:\/\//, '') + ') — چاپا ڕاستەوخۆ ئامادەیە')
                        : '❌ Agent ناچالاکە — <strong>Start_POS.bat</strong> بکەرەوە و پەنجەرەی Agent بکەرەوە بمێنێت';
                }
                if (showToastMsg && typeof showToast === 'function') {
                    showToast(ok ? '✅ Print Agent ئامادەیە' : '❌ Print Agent ناچالاکە — Start_POS.bat بکەرەوە', !ok);
                }
            });
        }

        if (typeof window !== 'undefined') {
            window.getLabelPrintSettings = getLabelPrintSettings;
            window.applyLabelPrintSettingsToForm = applyLabelPrintSettingsToForm;
            window.applyLabelSizePreset = applyLabelSizePreset;
            window.addCurrentLabelSizePreset = addCurrentLabelSizePreset;
            window.removeSelectedLabelSizePreset = removeSelectedLabelSizePreset;
            window.fillLabelPresetSelect = fillLabelPresetSelect;
            window.onLabelDesignChange = onLabelDesignChange;
            window.updateLabelPrintPreview = updateLabelPrintPreview;
            window.saveLabelPrintSettingsFromForm = saveLabelPrintSettingsFromForm;
            window.fillLabelPrinterSelect = fillLabelPrinterSelect;
            window.refreshLabelPrinterList = refreshLabelPrinterList;
            window.loadWindowsPrinters = loadWindowsPrinters;
            window.persistLabelPrintSettings = persistLabelPrintSettings;
            window.applyWindowsLabelPaperSize = applyWindowsLabelPaperSize;
            window.onLabelPrinterSelectChange = onLabelPrinterSelectChange;
            window.checkLabelPrintAgentStatus = checkLabelPrintAgentStatus;
            window.labelPrintAgentHealth = labelPrintAgentHealth;
            window.getLabelPrintAgentBase = getLabelPrintAgentBase;
            window.printProductLabel = printProductLabel;
            window.testPrintProductLabel = testPrintProductLabel;
            window.buildProductLabelInnerHtml = buildProductLabelInnerHtml;
        }

        function getPrinters() { return (db && db.settings && db.settings.printers) ? db.settings.printers : []; }
        function getPrinterRouting() { return (db && db.settings && db.settings.printerRouting) ? db.settings.printerRouting : {}; }
        function getPrinterById(id) { var list = getPrinters(); return list.find(function(p) { return p.id === id && p.status === 'active'; }); }
        function paperSizeToPaper(s) {
            if (s === 'A4') return '210mm';
            if (s === '58mm' || s === '60mm') return '80mm';
            return s || '80mm';
        }
        function pdsMigratePaperValue(paper) {
            var p = String(paper || '80mm');
            if (p === '58mm' || p === '60mm') return '80mm';
            return p;
        }
        function pdsIsSaleDoc(doc) {
            return doc === 'pos_sale' || doc === 'proforma';
        }
        function pdsAutoDesignForPaper(doc, paper) {
            if (pdsIsSaleDoc(doc)) return null;
            if (doc === 'inventory_report' && !isA4PrintPaper(paper)) return 'same_proforma';
            return isA4PrintPaper(paper) ? '1' : '3';
        }
        function pdsSyncDesignFromPaper(doc) {
            var paperEl = document.getElementById('pds-' + doc + '-paper');
            var designEl = document.getElementById('pds-' + doc + '-design');
            if (!paperEl || !designEl) return;
            var paper = pdsMigratePaperValue(paperEl.value);
            if (paper !== paperEl.value) paperEl.value = paper;
            if (pdsIsSaleDoc(doc)) {
                var d = String(designEl.value || '');
                if (isA4PrintPaper(paper)) {
                    if (['3', '4', '5', '6', '7'].indexOf(d) >= 0) designEl.value = '1';
                } else if (['1', '2', '8', 'same_pos_sale'].indexOf(d) >= 0) {
                    designEl.value = '7';
                }
                return;
            }
            var auto = pdsAutoDesignForPaper(doc, paper);
            if (auto) designEl.value = auto;
        }
        function pdsToggleDesignFieldVisibility(doc) {
            var designEl = document.getElementById('pds-' + doc + '-design');
            if (!designEl) return;
            var paperEl = document.getElementById('pds-' + doc + '-paper');
            var paper = paperEl ? pdsMigratePaperValue(paperEl.value) : '80mm';
            var show = pdsIsSaleDoc(doc) && isA4PrintPaper(paper);
            var lbl = designEl.previousElementSibling;
            designEl.style.display = show ? '' : 'none';
            if (lbl && lbl.tagName === 'LABEL') lbl.style.display = show ? '' : 'none';
        }
        function pdsRefreshDesignOptions(doc) {
            if (!pdsIsSaleDoc(doc)) return;
            var paperEl = document.getElementById('pds-' + doc + '-paper');
            var designEl = document.getElementById('pds-' + doc + '-design');
            if (!paperEl || !designEl) return;
            var a4 = isA4PrintPaper(pdsMigratePaperValue(paperEl.value));
            designEl.querySelectorAll('option').forEach(function(opt) {
                var v = opt.value;
                if (v === 'same_pos_sale') { opt.hidden = false; return; }
                if (a4) opt.hidden = (v === '7');
                else opt.hidden = (['1', '2', '8'].indexOf(v) >= 0);
            });
        }
        function pdsOnPaperChange(doc) {
            pdsSyncDesignFromPaper(doc);
            pdsToggleDesignFieldVisibility(doc);
            pdsRefreshDesignOptions(doc);
            doSavePrintDesignSettings();
        }
        if (typeof window !== 'undefined') window.pdsOnPaperChange = pdsOnPaperChange;
        var THERMAL_RECEIPT_OPTIONS_DEFAULTS = window.THERMAL_RECEIPT_OPTIONS_DEFAULTS || { logoPosition: 'center', headerFont: 'medium', bodyFont: 'medium', footerFont: 'small' };
        function getThermalReceiptOptions(docType) {
            var key = (docType === 'proforma') ? 'thermalReceiptOptionsProforma' : 'thermalReceiptOptions';
            if (!db || !db.settings || !db.settings[key]) return THERMAL_RECEIPT_OPTIONS_DEFAULTS;
            var o = db.settings[key];
            return { logoPosition: o.logoPosition || 'center', headerFont: o.headerFont || 'medium', bodyFont: o.bodyFont || 'medium', footerFont: o.footerFont || 'small' };
        }
        function getThermalLogoHtml(docType) {
            // 80mm/thermal: always print shop PNG logo (default brand or uploaded).
            // Preview toggle does not hide print — only logoPosition=none hides.
            var opts = getThermalReceiptOptions(docType || 'pos_sale');
            if (opts.logoPosition === 'none') return '';
            var fallbackRaw = (typeof window.POS_DEFAULT_SHOP_LOGO === 'string' && window.POS_DEFAULT_SHOP_LOGO)
                ? window.POS_DEFAULT_SHOP_LOGO
                : ((typeof window.POS_DEFAULT_LOGO === 'string' && window.POS_DEFAULT_LOGO)
                    ? window.POS_DEFAULT_LOGO
                    : 'public/assets/brand/laptop-duhok-logo.png');
            var fallbackUrl = (typeof absAssetUrl === 'function' && !/^(data:|blob:|https?:|\/\/)/i.test(fallbackRaw))
                ? absAssetUrl(fallbackRaw)
                : fallbackRaw;
            var logoUrl = (typeof getPosShopLogoUrl === 'function')
                ? getPosShopLogoUrl()
                : ((db && db.settings && db.settings.logo) ? String(db.settings.logo).trim() : '');
            if (!logoUrl) logoUrl = fallbackUrl;
            else if (typeof absAssetUrl === 'function' && !/^(data:|blob:|https?:|\/\/)/i.test(logoUrl)) {
                logoUrl = absAssetUrl(logoUrl);
            }
            var onErr = (logoUrl !== fallbackUrl)
                ? (' onerror="this.onerror=null;this.src=\'' + String(fallbackUrl).replace(/'/g, "\\'") + '\'"')
                : '';
            var wrapClass = 'thermal-logo-wrap thermal-logo-' + (opts.logoPosition === 'right' ? 'right' : (opts.logoPosition === 'left' ? 'left' : 'center'));
            return '<div class="' + wrapClass + '"><img src="' + logoUrl + '" class="thermal-logo" alt=""' + onErr + '></div>';
        }
        if (typeof window !== 'undefined') {
            window.getThermalLogoHtml = getThermalLogoHtml;
            window.getThermalReceiptOptions = getThermalReceiptOptions;
        }

        /** Shared logo HTML for any receipt (thermal 80mm → PNG class; A4 → compact img). */
        function getReceiptLogoHtml(opts) {
            opts = opts || {};
            var mode = opts.mode || 'thermal';
            if (mode === 'thermal' || mode === '80mm') {
                return getThermalLogoHtml(opts.docType || 'pos_sale');
            }
            var logoUrl = (typeof getPosShopLogoUrl === 'function') ? getPosShopLogoUrl() : '';
            if (!logoUrl) return '';
            return '<img src="' + logoUrl + '" style="max-height:80px;max-width:150px;object-fit:contain;" alt="">';
        }
        if (typeof window !== 'undefined') window.getReceiptLogoHtml = getReceiptLogoHtml;
        /** Show CODE128 of invoice id on receipt when enabled (separate from POS product barcode scanning). */
        function getPrintInvoiceBarcodeEnabled() {
            return !db || !db.settings || db.settings.printInvoiceBarcode !== false;
        }
        function buildThermalInvoiceBarcodeHtml(saleId) {
            if (!getPrintInvoiceBarcodeEnabled() || saleId == null) return '';
            try {
                if (typeof JsBarcode === 'undefined') return '';
                var canvas = document.createElement('canvas');
                JsBarcode(canvas, String(saleId), { format: 'CODE128', displayValue: true, height: 22, margin: 0, width: 1.1, fontSize: 9, lineColor: '#000' });
                var src = canvas.toDataURL('image/png');
                return '<div class="thermal-invoice-barcode" style="margin-top:3px;text-align:center;"><img src="' + src + '" alt="" style="max-width:100%;height:auto;max-height:36px;"></div>';
            } catch (e) { return ''; }
        }
        /** Invoice note + static terms + optional custom note (single block for 80mm). */
        function buildThermalReceiptTermsHtml() {
            var s = db && db.settings ? db.settings : {};
            var blocks = [];
            if (s.invoiceNote && String(s.invoiceNote).trim()) {
                blocks.push('<p class="thermal-term-line" style="margin:2px 0;font-size:0.78rem;line-height:1.35;">' + escapeHtml(String(s.invoiceNote).trim()) + '</p>');
            }
            if (s.customNote && String(s.customNote).trim()) {
                blocks.push('<p class="thermal-custom-note" style="margin:4px 0;font-weight:600;font-size:0.8rem;">' + escapeHtml(String(s.customNote).trim()) + '</p>');
            }
            ['staticNote1', 'staticNote2', 'staticNote3'].forEach(function(key) {
                var v = s[key];
                if (v && String(v).trim()) blocks.push('<p class="thermal-static-note" style="margin:2px 0;font-size:0.75rem;line-height:1.35;">• ' + escapeHtml(String(v).trim()) + '</p>');
            });
            if (!blocks.length) return '';
            return '<div class="thermal-receipt-terms" style="margin-top:3px;padding:3px 2px;border-top:1px dashed #ccc;text-align:center;">' + blocks.join('') + '</div>';
        }
        function clearReceiptLogo() {
            if (!confirm(typeof t === 'function' ? (t('confirm_clear_logo') || 'Remove store logo from receipts?') : 'Remove store logo from receipts?')) return;
            if (!db.settings) db.settings = {};
            db.settings.logo = '';
            var fi = document.getElementById('set-cafe-logo');
            if (fi) fi.value = '';
            var prev = document.getElementById('pds-logo-preview');
            var wrap = document.getElementById('pds-logo-preview-wrap');
            var fallback = (typeof getPosShopLogoUrl === 'function') ? getPosShopLogoUrl() : 'public/assets/brand/laptop-duhok-logo.png';
            if (prev) { prev.src = fallback; prev.style.display = ''; }
            if (wrap) wrap.style.display = 'inline-block';
            if (typeof syncHomeShopLogo === 'function') syncHomeShopLogo();
            if (typeof saveSettings === 'function') {
                saveSettings().then(function() {
                    if (typeof showToast === 'function') showToast('✅ ' + (typeof t === 'function' ? (t('logo_removed') || 'Logo removed') : 'Logo removed'));
                    if (typeof applyPrintSettings === 'function') applyPrintSettings();
                    if (typeof updateReceiptPreview === 'function') updateReceiptPreview();
                    if (typeof refreshLabelLogoPreview === 'function') refreshLabelLogoPreview();
                }).catch(function() {});
            }
        }
        if (typeof window !== 'undefined') window.clearReceiptLogo = clearReceiptLogo;
        function saveA4Design3LogoLayoutSetting() {
            var el = document.getElementById('set-a4-design3-logo-layout');
            if (!db || !db.settings) return;
            db.settings.a4Design3LogoLayout = (el && el.value) ? el.value : 'center';
            if (typeof saveSettings === 'function') saveSettings().catch(function() {});
            if (typeof updateReceiptPreview === 'function') updateReceiptPreview();
        }
        if (typeof window !== 'undefined') window.saveA4Design3LogoLayoutSetting = saveA4Design3LogoLayoutSetting;
        function getA4AccentTheme() {
            var theme = (db && db.settings && db.settings.a4AccentTheme) ? String(db.settings.a4AccentTheme) : 'amber';
            return (theme === 'navy' || theme === 'blue') ? 'navy' : 'amber';
        }
        function saveA4AccentThemeSetting() {
            var el = document.getElementById('set-a4-accent-theme');
            if (!db || !db.settings) return;
            db.settings.a4AccentTheme = (el && el.value) ? el.value : 'amber';
            if (typeof saveSettings === 'function') saveSettings().catch(function() {});
            if (typeof updateReceiptPreview === 'function') updateReceiptPreview();
        }
        if (typeof window !== 'undefined') {
            window.getA4AccentTheme = getA4AccentTheme;
            window.saveA4AccentThemeSetting = saveA4AccentThemeSetting;
        }
        function applyA4Design3LogoPreview(side, dataUrl) {
            var prev = document.getElementById('pds-a4-design3-logo-' + side + '-preview');
            var wrap = document.getElementById('pds-a4-design3-logo-' + side + '-preview-wrap');
            if (!prev || !wrap) return;
            if (dataUrl) {
                prev.src = dataUrl;
                prev.style.display = '';
                wrap.style.display = 'inline-block';
            } else {
                prev.removeAttribute('src');
                prev.style.display = 'none';
                wrap.style.display = 'none';
            }
        }
        /**
         * Encode shop logos as crisp PNG (keeps transparency). Avoid JPEG — it kills PNG alpha.
         */
        function encodePosLogoDataUrl(canvas, sourceFile) {
            try {
                var png = canvas.toDataURL('image/png');
                if (png && png.indexOf('data:image/png') === 0) return png;
            } catch (_ePng) {}
            try {
                return canvas.toDataURL('image/jpeg', 0.92);
            } catch (_eJpg) {
                return '';
            }
        }
        function resizeImageFileToLogoDataUrl(file, opts) {
            opts = opts || {};
            var maxW = opts.maxW || 720;
            var maxH = opts.maxH || 280;
            return new Promise(function(resolve, reject) {
                if (!file) {
                    reject(new Error('no file'));
                    return;
                }
                var img = new Image();
                var objectUrl = URL.createObjectURL(file);
                img.onload = function() {
                    var w = img.width, h = img.height;
                    if (w > maxW || h > maxH) {
                        if (w / maxW > h / maxH) {
                            w = maxW;
                            h = Math.max(1, Math.round(img.height * maxW / img.width));
                        } else {
                            h = maxH;
                            w = Math.max(1, Math.round(img.width * maxH / img.height));
                        }
                    }
                    var canvas = document.createElement('canvas');
                    canvas.width = w;
                    canvas.height = h;
                    var ctx = canvas.getContext('2d');
                    if (ctx) {
                        ctx.imageSmoothingEnabled = true;
                        ctx.imageSmoothingQuality = 'high';
                        ctx.clearRect(0, 0, w, h);
                        ctx.drawImage(img, 0, 0, w, h);
                    }
                    var dataUrl = encodePosLogoDataUrl(canvas, file);
                    URL.revokeObjectURL(objectUrl);
                    if (!dataUrl) reject(new Error('encode failed'));
                    else resolve(dataUrl);
                };
                img.onerror = function() {
                    URL.revokeObjectURL(objectUrl);
                    reject(new Error('load failed'));
                };
                img.src = objectUrl;
            });
        }
        if (typeof window !== 'undefined') {
            window.encodePosLogoDataUrl = encodePosLogoDataUrl;
            window.resizeImageFileToLogoDataUrl = resizeImageFileToLogoDataUrl;
        }

        function handleA4Design3SideLogoUpload(input, side) {
            if (!input || !input.files || !input.files.length) return;
            if (!db || !db.settings) return;
            side = (side === 'right' || side === 'center') ? side : 'left';
            var key = side === 'right' ? 'a4Design3LogoRight' : (side === 'center' ? 'a4Design3LogoCenter' : 'a4Design3LogoLeft');
            resizeImageFileToLogoDataUrl(input.files[0], { maxW: 520, maxH: 220 }).then(function(dataUrl) {
                db.settings[key] = dataUrl;
                applyA4Design3LogoPreview(side, dataUrl);
                if (typeof saveSettings === 'function') saveSettings().catch(function() {});
                if (typeof updateReceiptPreview === 'function') updateReceiptPreview();
            }).catch(function() {});
        }
        if (typeof window !== 'undefined') window.handleA4Design3SideLogoUpload = handleA4Design3SideLogoUpload;
        function clearA4Design3SideLogo(side) {
            if (!db || !db.settings) return;
            side = (side === 'right' || side === 'center') ? side : 'left';
            var key = side === 'right' ? 'a4Design3LogoRight' : (side === 'center' ? 'a4Design3LogoCenter' : 'a4Design3LogoLeft');
            db.settings[key] = '';
            var input = document.getElementById('set-a4-design3-logo-' + side);
            if (input) input.value = '';
            applyA4Design3LogoPreview(side, '');
            if (typeof saveSettings === 'function') saveSettings().catch(function() {});
            if (typeof updateReceiptPreview === 'function') updateReceiptPreview();
        }
        if (typeof window !== 'undefined') window.clearA4Design3SideLogo = clearA4Design3SideLogo;
        /** Professional pre-print note block — thermal | a4 | wrap (generic). */
        function buildProfessionalPrintNoteHtml(note, variant) {
            var text = note != null ? String(note).trim() : '';
            if (!text) return '';
            var safe = escapeHtml(text);
            var label = typeof t === 'function' ? (t('print_note_label') || 'تێبینیا چاپکرنێ') : 'تێبینیا چاپکرنێ';
            if (variant === 'a4') {
                return '<div class="print-note-pro print-note-pro-a4" role="note">' +
                    '<div class="print-note-pro-accent"></div>' +
                    '<div class="print-note-pro-inner">' +
                    '<div class="print-note-pro-head"><span class="print-note-pro-icon" aria-hidden="true">✎</span><span class="print-note-pro-label">' + escapeHtml(label) + '</span></div>' +
                    '<p class="print-note-pro-text">' + safe + '</p></div></div>';
            }
            if (variant === 'wrap') {
                return '<div class="print-note-pro print-note-pro-wrap"><div class="print-note-pro-inner">' +
                    '<span class="print-note-pro-label">' + escapeHtml(label) + '</span>' +
                    '<p class="print-note-pro-text">' + safe + '</p></div></div>';
            }
            return '<div class="print-note-pro print-note-pro-thermal" role="note">' +
                '<div class="print-note-pro-thermal-bar"></div>' +
                '<div class="print-note-pro-inner">' +
                '<div class="print-note-pro-head"><span class="print-note-pro-icon" aria-hidden="true">✎</span><span class="print-note-pro-label">' + escapeHtml(label) + '</span></div>' +
                '<p class="print-note-pro-text">' + safe + '</p></div></div>';
        }
        function detectPrintNoteVariant(html) {
            var h = String(html || '');
            if (h.indexOf('invoice-a4-') >= 0 || h.indexOf('a4-invoice-v2') >= 0 || h.indexOf('print-a4-container') >= 0) return 'a4';
            return 'thermal';
        }
        /** Replace __NOTE_SLOT__ or inject before footer when note present. */
        function finalizePrintHtmlWithNote(html, note) {
            var h = String(html || '');
            var block = buildProfessionalPrintNoteHtml(note, detectPrintNoteVariant(h));
            if (h.indexOf('__NOTE_SLOT__') >= 0) return h.split('__NOTE_SLOT__').join(block);
            if (!block) return h;
            if (h.indexOf('class="thermal-footer') >= 0) {
                return h.replace(/<div class="thermal-footer/i, block + '<div class="thermal-footer');
            }
            if (h.indexOf('class="a4-page-brand') >= 0) {
                return h.replace(/<div class="a4-page-brand/i, block + '<div class="a4-page-brand');
            }
            if (h.indexOf('class="a4-bottom-split') >= 0) {
                return h.replace(/<div class="a4-bottom-split/i, block + '<div class="a4-bottom-split');
            }
            return h + block;
        }
        function finalizeThermalSaleBill(html, note) {
            return finalizePrintHtmlWithNote(html, note);
        }
        if (typeof window !== 'undefined') {
            window.buildProfessionalPrintNoteHtml = buildProfessionalPrintNoteHtml;
            window.finalizePrintHtmlWithNote = finalizePrintHtmlWithNote;
        }
        /** Phone / address / social for thermal receipts — prefers dedicated fields; falls back safely. */
        function getReceiptContactInfo() {
            var s = (db && db.settings) ? db.settings : {};
            var phone = String(s.cafePhone || s.phone || s.mobile || s.phone1 || '').trim();
            var addr = String(s.cafeAddress || s.address || '').trim();
            var info = String(s.cafeInfo || '').trim();
            if (!phone && info) {
                var digits = info.replace(/[^\d+]/g, '');
                if (digits.length >= 7 && digits.length <= 15) phone = info.trim();
            }
            if (!addr && info && info !== phone) addr = info;
            if (phone && addr && typeof window.phonesReceiptSame === 'function' && window.phonesReceiptSame(addr, phone)) {
                addr = '';
            }
            var social = '';
            if (s.facebook || s.instagram) social = [s.facebook, s.instagram].filter(Boolean).join(' | ');
            else if (s.socialLinks) social = String(s.socialLinks).trim();
            return { phone: phone, address: addr, social: social };
        }
        if (typeof window !== 'undefined') window.getReceiptContactInfo = getReceiptContactInfo;
        function getReceiptCashierName(name) {
            var n = String(name || '').trim();
            if (!n || n === '-') return '-';
            if (n === 'Manager') return 'مدير';
            if (n === 'System') return (typeof t === 'function') ? (t('print_system') || 'System') : 'System';
            return n;
        }
        /** Table-based total row — reliable on thermal printers (no flexbox). */
        function buildThermalTotalRow(label, value) {
            return '<table class="thermal-total-table" style="width:100%;border-collapse:collapse;table-layout:fixed;margin-bottom:1px;"><tr>' +
                '<td style="text-align:right;width:55%;padding:1px 2px;vertical-align:top;">' + escapeHtml(String(label)) + '</td>' +
                '<td style="text-align:left;width:45%;padding:1px 2px;vertical-align:top;direction:ltr;unicode-bidi:isolate;">' + String(value) + '</td>' +
                '</tr></table>';
        }
        /** Compact 24h date — one line on 80mm (avoids AM/PM wrapping). Baghdad wall time. */
        function formatThermalReceiptDateTime(dateInput) {
            var d;
            if (dateInput == null || dateInput === '') d = new Date();
            else if (typeof parseSQLDate === 'function') d = parseSQLDate(dateInput);
            else d = new Date(dateInput);
            if (!d || isNaN(d.getTime())) d = new Date();
            if (typeof getPosTimezoneParts === 'function') {
                var p = getPosTimezoneParts(d);
                return p.day + '/' + p.month + '/' + String(p.year).slice(-2) + ' ' + p.hour + ':' + p.minute;
            }
            if (typeof formatPosDateTime === 'function') {
                return formatPosDateTime(d, 'en-GB').replace(',', '').replace(/\./g, '/').trim();
            }
            var pad = function(n) { return (n < 10 ? '0' : '') + n; };
            return pad(d.getDate()) + '/' + pad(d.getMonth() + 1) + '/' + String(d.getFullYear()).slice(-2) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
        }
        function buildThermalMetaRow(label, valueHtml) {
            return '<table class="meta-row-table" style="width:100%;border-collapse:collapse;table-layout:fixed;margin:0;"><tr>' +
                '<td style="text-align:right;width:38%;padding:0;font-size:inherit;vertical-align:top;line-height:1.1;">' + escapeHtml(String(label)) + '</td>' +
                '<td style="text-align:left;width:62%;padding:0;direction:ltr;unicode-bidi:isolate;font-size:inherit;vertical-align:top;line-height:1.1;white-space:nowrap;"><b>' + valueHtml + '</b></td>' +
                '</tr></table>';
        }
        /** Dense meta block — 2-column table (reliable + tidy on 80mm thermal). */
        function buildThermalMetaCompactBlock(pairs) {
            var items = (pairs || []).filter(function(p) { return p && (p.label || p.valueHtml); });
            if (!items.length) return '';
            var rows = items.map(function(p) {
                var lbl = String(p.label || '').replace(/\s*#+\s*$/, '').trim();
                return '<tr><td class="thermal-meta-td-lbl">' + escapeHtml(lbl) + '</td>' +
                    '<td class="thermal-meta-td-val">' + (p.valueHtml || '') + '</td></tr>';
            }).join('');
            return '<div class="thermal-meta-compact">' +
                '<table class="thermal-meta-compact-table" cellpadding="0" cellspacing="0"><tbody>' + rows + '</tbody></table>' +
                '</div>';
        }
        function isGenericCustomerLabel(name) {
            if (name == null || name === '') return true;
            var s = String(name).trim().toLowerCase();
            return s === 'گشتی' || s === 'عام' || s === 'general' || s === 'public' || s === 'walk-in' || s === 'walk in' || s === '-' || s === '—';
        }
        function resolveSaleCustomerName(sale, fallback) {
            if (!sale) return fallback || '';
            var direct = sale.customer || sale.customer_name || '';
            if (direct && !isGenericCustomerLabel(direct)) return String(direct).trim();
            var cid = parseInt(sale.customer_id, 10) || 0;
            if (cid > 0 && typeof db !== 'undefined' && db) {
                var ctype = String(sale.customer_type || 'customer').toLowerCase();
                if (ctype === 'user') {
                    var u = (db.users || []).find(function (x) { return Number(x.id) === cid; });
                    if (u && u.name) return String(u.name).trim();
                } else {
                    var c = (db.customers || []).find(function (x) { return Number(x.id) === cid; });
                    if (c && c.name) return String(c.name).trim();
                }
            }
            if (direct && String(direct).trim()) return String(direct).trim();
            return fallback || '';
        }
        function enrichSaleForPrint(sale) {
            if (!sale) return sale;
            var name = resolveSaleCustomerName(sale);
            if (name) sale.customer = name;
            return sale;
        }
        if (typeof window !== 'undefined') {
            window.isGenericCustomerLabel = isGenericCustomerLabel;
            window.resolveSaleCustomerName = resolveSaleCustomerName;
            window.enrichSaleForPrint = enrichSaleForPrint;
        }
        /** Standard professional thermal receipt (80/60/58mm) — designs 3–7. */
        function formatThermalSaleGrandTotalHtml(sale) {
            var totalIqd = Math.round(parseFloat(sale && sale.total) || 0);
            var usdNet = 0;
            var ratePerOne = 0;
            var fxBundle = sale && sale.fx_usd_rate != null ? Math.round(Number(sale.fx_usd_rate)) : 0;
            if (Number.isFinite(fxBundle) && fxBundle >= 1000) ratePerOne = fxBundle / 100;
            if (typeof resolveSaleBasketPrintMoney === 'function') {
                var m = resolveSaleBasketPrintMoney(sale, sale && sale.items);
                if (m) {
                    if (m.hasBasketUsd && m.usdNet > 0) usdNet = m.usdNet;
                    var usdShop = false;
                    try {
                        var fxMode = String((sale && sale.fx_currency_mode) || '').toUpperCase();
                        if (fxMode === 'USD') usdShop = true;
                        else if (fxMode === 'IQD') usdShop = false;
                        else if (typeof isUsdMoneySystem === 'function') usdShop = isUsdMoneySystem();
                    } catch (_eUsdShop) {}
                    if (usdShop && m.basketIqd > 0) totalIqd = Math.round(m.basketIqd);
                    if (!(ratePerOne > 0) && m.visualPerOne > 0) ratePerOne = m.visualPerOne;
                }
            }
            if (!(ratePerOne > 0) && typeof getUsdRatePerOne === 'function') ratePerOne = getUsdRatePerOne();
            if (!(usdNet > 0) && ratePerOne > 0 && totalIqd > 0) usdNet = totalIqd / ratePerOne;
            var dual = (typeof formatDualCurrencyLines === 'function')
                ? formatDualCurrencyLines(totalIqd, usdNet, ratePerOne)
                : null;
            var rateLbl = (typeof t === 'function') ? t('receipt_fx_rate') : 'نرخێ گۆڕینێ';
            if (dual) {
                var extra = dual.secondary
                    ? ('<br><span dir="ltr" data-allow-iqd="1" style="font-size:0.85em;font-weight:700;">' + dual.secondary + '</span>')
                    : '';
                var rateLine = dual.rate
                    ? ('<br><span dir="ltr" data-allow-iqd="1" style="font-size:0.72em;font-weight:600;">' + rateLbl + ': ' + dual.rate + '</span>')
                    : '';
                return '<span dir="ltr">' + dual.primary + '</span>' + extra + rateLine;
            }
            var fx = (typeof fxUsdRateFormatOpts === 'function') ? fxUsdRateFormatOpts(sale) : undefined;
            return formatCurrency(sale.total, fx) + ' ' + (typeof getCurrencySymbol === 'function' ? getCurrencySymbol() : '');
        }
        function buildThermalStandardSaleBillHtml(opts) {
            opts = opts || {};
            var sale = opts.sale || {};
            var grouped = opts.grouped || {};
            var printFx = opts.printFx;
            var subTotal = opts.subTotal != null ? opts.subTotal : ((parseFloat(sale.total) || 0) + (parseFloat(sale.discount) || 0));
            var discount = opts.discount != null ? opts.discount : (parseFloat(sale.discount) || 0);
            var cfg = opts.cfg || { paper: '80mm', design: '7' };
            var width = cfg.paper || '80mm';
            var tf = typeof t === 'function';
            var L = function(key, fb) {
                if (!tf) return fb;
                var v = t(key);
                if (!v || v === key) return fb;
                return v;
            };
            var lang = typeof getCurrentLanguage === 'function' ? getCurrentLanguage() : 'badini';
            var taxLabel = lang === 'ar' ? 'الضريبة' : 'باج';
            var contact = getReceiptContactInfo();
            var taxValue = (typeof roundMoney === 'function') ? roundMoney(parseFloat(sale.tax || sale.tax_amount || 0) || 0) : 0;
            var cashierName = getReceiptCashierName(sale.cashier);
            var customerDefault = L('print_customer_general', lang === 'ar' ? 'عام' : 'گشتی');
            var isProforma = !!opts.isProforma;
            var reprintBanner = (!isProforma && opts.isReprint) ? ('<p style="text-align:center;margin:1px 0;font-weight:700;font-size:0.7rem;">' + L('print_copy_reprint', 'COPY - REPRINT') + '</p>') : '';
            var preBillBanner = isProforma ? ('<h2 style="text-align:center;margin:2px 0 0;font-size:0.9rem;">' + L('print_pre_bill', 'ژمێریاری') + '</h2>') : '';

            // Compact rows — smaller type + tight padding = less paper on 80mm
            var rowsHtml = Object.values(grouped).map(function(g) {
                var unitPrice = g.count > 0 ? (g.sub / g.count) : g.sub;
                var nameHtml = (typeof formatSaleItemNameHtml === 'function') ? formatSaleItemNameHtml(g, { skipPriceTypeLabel: true }) : (escapeHtml(g.name || 'ئایتم') + getSaleItemUnitSuffix(g, { skipPriceTypeLabel: true }));
                return '<tr>' +
                    '<td style="text-align:right;padding:1px 2px;border-bottom:1px dotted #999;font-weight:700;color:#000;font-size:0.78rem;line-height:1.2;">' + nameHtml + (g.note ? '<br><small style="font-size:0.65rem;font-weight:500;">* ' + escapeHtml(g.note) + '</small>' : '') + '</td>' +
                    '<td style="text-align:center;padding:1px 1px;border-bottom:1px dotted #999;font-weight:700;color:#000;font-size:0.78rem;vertical-align:top;white-space:nowrap;">' + formatQtyForDisplay(g.count, g) + '</td>' +
                    '<td style="text-align:center;padding:1px 1px;border-bottom:1px dotted #999;font-weight:600;color:#000;direction:ltr;font-size:0.72rem;vertical-align:top;white-space:nowrap;">' + (g.isGift ? ((typeof t === 'function') ? t('pos_gift_label') : 'دیاری') : formatCurrency(unitPrice, printFx)) + '</td>' +
                    '<td style="text-align:left;padding:1px 2px;border-bottom:1px dotted #999;font-weight:800;color:#000;direction:ltr;font-size:0.78rem;vertical-align:top;white-space:nowrap;">' + (g.isGift ? ((typeof t === 'function') ? t('pos_gift_label') : 'دیاری') : formatCurrency(g.sub, printFx)) + '</td>' +
                    '</tr>';
            }).join('');

            var displaySaleId = (typeof formatSaleIdForDisplay === 'function')
                ? formatSaleIdForDisplay(sale.id)
                : String(sale.id || '').slice(-8);
            var metaDateVal = escapeHtml(formatThermalReceiptDateTime(isProforma ? new Date() : sale.date));
            var metaPairs = [];
            if (isProforma) {
                metaPairs.push({
                    label: (typeof getTablesLabelShort === 'function' ? getTablesLabelShort() : L('bill_header_table', 'مێز')),
                    valueHtml: escapeHtml(String(sale.table || sale.tableName || '—'))
                });
                metaPairs.push({ label: L('print_date', 'بەروار'), valueHtml: metaDateVal });
            } else {
                metaPairs.push({ label: L('print_invoice', 'پسوولە'), valueHtml: '#' + escapeHtml(displaySaleId) });
                metaPairs.push({ label: L('print_date', 'بەروار'), valueHtml: metaDateVal });
                metaPairs.push({ label: L('print_cashier', 'کاشێر'), valueHtml: escapeHtml(cashierName) });
                var resolvedCustomer = resolveSaleCustomerName(sale);
                metaPairs.push({
                    label: L('print_customer', 'کريار'),
                    valueHtml: escapeHtml(resolvedCustomer || customerDefault)
                });
                var debtAmtMeta = parseFloat(sale.debt_added != null ? sale.debt_added : (sale.debt_amount || 0)) || 0;
                var cashAmtMeta = parseFloat(sale.cash_paid != null ? sale.cash_paid : (sale.paid_amount || 0)) || 0;
                var pmMeta = String(sale.payment_method || 'cash');
                var payMetaLabel = L('payment_method_cash', 'کاش');
                var bankAmtMeta = parseFloat(sale.bank_amount != null ? sale.bank_amount : (sale.paid_bank || 0)) || 0;
                if (pmMeta === 'fib' || pmMeta === 'bank' || pmMeta === 'bankcard' || (bankAmtMeta > 0 && cashAmtMeta <= 0 && debtAmtMeta <= 0)) payMetaLabel = L('payment_method_fib', 'FIB');
                else if (debtAmtMeta > 0 && (cashAmtMeta > 0 || bankAmtMeta > 0)) payMetaLabel = L('print_status_split', lang === 'ar' ? 'نقد ودين (مختلط)' : 'نەقد و قەرز (تێکەڵ)');
                else if (pmMeta === 'debt' || debtAmtMeta > 0) payMetaLabel = L('payment_method_debt', 'قەرز');
                else if (bankAmtMeta > 0) payMetaLabel = L('payment_method_fib', 'FIB') + (cashAmtMeta > 0 ? ' + ' + L('payment_method_cash', 'کاش') : '');
                metaPairs.push({
                    label: L('print_type', 'جۆر'),
                    valueHtml: escapeHtml(payMetaLabel)
                });
            }

            var metaBlockHtml = '<table style="width:100%;font-weight:700;font-size:0.72rem;margin:0;border-collapse:collapse;line-height:1.2;">';
            metaPairs.forEach(function(p) {
                metaBlockHtml += '<tr>' +
                    '<td style="text-align:right;padding:0;font-weight:800;color:#000;width:38%;white-space:nowrap;">' + escapeHtml(p.label || '') + '</td>' +
                    '<td style="text-align:left;padding:0;font-weight:700;color:#000;direction:ltr;width:62%;">' + (p.valueHtml || '') + '</td>' +
                    '</tr>';
            });
            metaBlockHtml += '</table>';

            var debtSectionHtml = opts.debtSectionHtml || '';
            var thermalTermsHtml = opts.thermalTermsHtml || '';
            var thermalBarcodeBlock = opts.thermalBarcodeBlock || '';
            var qrBlock = opts.qrBlock || '';

            var phoneStr = contact.phone || '';
            var addrStr = contact.address || '';
            var storeName = (db.settings && db.settings.cafeName) ? db.settings.cafeName : 'Store';
            var contactBits = [];
            if (addrStr) contactBits.push(escapeHtml(addrStr));
            if (phoneStr) contactBits.push(escapeHtml(phoneStr));

            var footerThanks = isProforma
                ? ('<div style="text-align:center;font-weight:700;font-size:0.78rem;margin-top:4px;color:#000;padding:3px;border:1px dashed #000;">' + L('print_please_pay_cash', 'هیڤیە پارەی بدەنە کاشێری') + '</div>')
                : ('<div style="text-align:center;font-weight:700;font-size:0.78rem;margin-top:4px;color:#000;">' + L('print_thanks_visit', 'سوپاس بۆ سەرەدانا وە') + '</div>');

            var thermalLogoHtml = opts.thermalLogoHtml || (typeof getThermalLogoHtml === 'function' ? getThermalLogoHtml(isProforma ? 'proforma' : 'pos_sale') : '');
            var thermalFontClasses = opts.thermalFontClasses || '';

            return '<div class="print-thermal-container thermal-compact thermal-dense' + thermalFontClasses + '" style="max-width:' + width + ';width:100%;font-family:\'Rudaw\',Tahoma,sans-serif;color:#000!important;direction:rtl;padding:0 2px;" data-skip-print-localize="1">' +
                '<style>.print-thermal-container,.print-thermal-container *{font-family:\'Rudaw\',Tahoma,sans-serif!important;}.print-thermal-container{color:#000!important;}</style>' +
                thermalLogoHtml +
                '<div style="text-align:center;margin:0 0 3px;padding:3px 4px;border:1.5px solid #000;">' +
                '<div style="font-weight:900;font-size:1.05rem;margin:0;line-height:1.15;text-transform:uppercase;color:#000;">' + escapeHtml(storeName) + '</div>' +
                (contactBits.length ? ('<div style="font-weight:600;font-size:0.68rem;margin-top:1px;line-height:1.2;color:#000;">' + contactBits.join(' · ') + '</div>') : '') +
                '</div>' +

                reprintBanner + preBillBanner +

                '<div style="border:1px solid #000;padding:2px 3px;margin-bottom:3px;">' +
                metaBlockHtml +
                '</div>' +

                '<table style="width:100%;font-weight:700;font-size:0.72rem;text-align:center;border-collapse:collapse;color:#000;margin:0;table-layout:fixed;">' +
                '<tbody><tr style="border-bottom:1.5px solid #000;">' +
                '<td style="text-align:right;width:40%;padding:1px 2px;color:#000;font-weight:900;font-size:0.7rem;">' + L('th_item', 'کەلوپەل') + '</td>' +
                '<td style="text-align:center;width:12%;padding:1px 1px;color:#000;font-weight:900;font-size:0.7rem;">' + L('th_qty', 'ژ') + '</td>' +
                '<td style="text-align:center;width:24%;padding:1px 1px;color:#000;font-weight:900;font-size:0.7rem;">' + L('th_price', 'بها') + '</td>' +
                '<td style="text-align:left;width:24%;padding:1px 2px;color:#000;font-weight:900;font-size:0.7rem;">' + L('th_total', 'کۆ') + '</td>' +
                '</tr>' + rowsHtml + '</tbody></table>' +

                '<div style="border-top:1.5px solid #000;margin:3px 0 2px;"></div>' +
                '<table style="width:100%;font-size:0.78rem;margin:0;font-weight:700;color:#000;table-layout:fixed;line-height:1.25;">' +
                '<tr><td style="text-align:right;padding:0;">' + L('print_subtotal', 'کۆی') + '</td><td style="text-align:left;direction:ltr;padding:0;">' + formatCurrency(subTotal, printFx) + '</td></tr>' +
                (discount > 0 ? '<tr><td style="text-align:right;padding:0;">' + L('print_discount', 'داشکاندن') + '</td><td style="text-align:left;direction:ltr;padding:0;">' + formatCurrency(discount, printFx) + '</td></tr>' : '') +
                (taxValue > 0 ? '<tr><td style="text-align:right;padding:0;">' + taxLabel + '</td><td style="text-align:left;direction:ltr;padding:0;">' + formatCurrency(taxValue, printFx) + '</td></tr>' : '') +
                '</table>' +

                '<div class="receipt-grand-total-bar" style="text-align:center;font-weight:900;font-size:0.95rem;margin:4px 0 3px;padding:4px 2px;border-top:2px solid #000;border-bottom:2px solid #000;background:#fff;color:#000!important;-webkit-print-color-adjust:exact;print-color-adjust:exact;">' +
                '<div style="color:#000!important;font-weight:900!important;line-height:1.2;font-size:0.78rem;">' + L('print_grand_total', 'کۆیا گشتی') + '</div>' +
                '<div style="color:#000!important;font-weight:900!important;font-size:1.15rem;direction:ltr;unicode-bidi:isolate;line-height:1.2;">' + formatThermalSaleGrandTotalHtml(sale) + '</div>' +
                '</div>' +

                footerThanks +
                (isProforma ? '' : debtSectionHtml) + (isProforma ? '' : qrBlock) + (isProforma ? '' : thermalTermsHtml) + '__NOTE_SLOT__' + (isProforma ? '' : thermalBarcodeBlock) +
                '<div style="text-align:center;margin-top:4px;padding-top:3px;border-top:1px dashed #000;font-size:0.68rem;color:#000!important;font-weight:800;">' +
                (typeof buildPosReceiptBrandFooterHtml === 'function' ? buildPosReceiptBrandFooterHtml() : '') +
                '</div></div>';
        }
        function buildThermalDesign7SaleBillHtml(opts) {
            opts = opts || {};
            opts.cfg = opts.cfg || { paper: '80mm', design: '7' };
            opts.cfg.design = '7';
            return buildThermalStandardSaleBillHtml(opts);
        }
        if (typeof window !== 'undefined') {
            window.formatThermalReceiptDateTime = formatThermalReceiptDateTime;
            window.buildThermalMetaCompactBlock = buildThermalMetaCompactBlock;
            window.buildThermalStandardSaleBillHtml = buildThermalStandardSaleBillHtml;
            window.buildThermalDesign7SaleBillHtml = buildThermalDesign7SaleBillHtml;
        }
        function getThermalFontClasses(docType) {
            var o = getThermalReceiptOptions(docType || 'pos_sale');
            var c = [];
            if (o.headerFont === 'small') c.push('thermal-font-header-small'); else if (o.headerFont === 'large') c.push('thermal-font-header-large');
            if (o.bodyFont === 'small') c.push('thermal-font-body-small'); else if (o.bodyFont === 'large') c.push('thermal-font-body-large');
            if (o.footerFont === 'small') c.push('thermal-font-footer-small'); else if (o.footerFont === 'large') c.push('thermal-font-footer-large');
            return c.length ? ' ' + c.join(' ') : '';
        }
        function saveThermalReceiptOptions(docType, skipPersist) {
            if (!db.settings) db.settings = {};
            docType = docType || 'pos_sale';
            var prefix = docType === 'proforma' ? 'thermal-proforma-' : 'thermal-';
            var key = docType === 'proforma' ? 'thermalReceiptOptionsProforma' : 'thermalReceiptOptions';
            var pos = document.getElementById(prefix + 'logo-position');
            var hf = document.getElementById(prefix + 'header-font');
            var bf = document.getElementById(prefix + 'body-font');
            var ff = document.getElementById(prefix + 'footer-font');
            if (!pos && !hf && !bf && !ff) return;
            db.settings[key] = {
                logoPosition: (pos && pos.value) || 'center',
                headerFont: (hf && hf.value) || 'medium',
                bodyFont: (bf && bf.value) || 'medium',
                footerFont: (ff && ff.value) || 'small'
            };
            if (!skipPersist && typeof saveSettings === 'function') saveSettings().catch(function() {});
            if (typeof updateReceiptPreview === 'function') updateReceiptPreview();
        }
        function applyThermalReceiptOptions() {
            ['pos_sale', 'proforma'].forEach(function(docType) {
                var o = getThermalReceiptOptions(docType);
                var prefix = docType === 'proforma' ? 'thermal-proforma-' : 'thermal-';
                var pos = document.getElementById(prefix + 'logo-position');
                var hf = document.getElementById(prefix + 'header-font');
                var bf = document.getElementById(prefix + 'body-font');
                var ff = document.getElementById(prefix + 'footer-font');
                if (pos) pos.value = o.logoPosition;
                if (hf) hf.value = o.headerFont;
                if (bf) bf.value = o.bodyFont;
                if (ff) ff.value = o.footerFont;
            });
        }
        function isA4PrintPaper(paper) {
            return paper === '210mm' || paper === 'A4';
        }
        function normalizePosSalePrintConfig(paper, design) {
            var p = pdsMigratePaperValue(paper || '80mm');
            var d = String(design || '7');
            if (!isA4PrintPaper(p)) {
                if (d === '1' || d === '2' || d === '8' || d === 'same_pos_sale') return { paper: p, design: '7' };
                if (['3', '4', '5', '6'].indexOf(d) >= 0) return { paper: p, design: '7' };
                return { paper: p, design: d };
            }
            if (d === '3' || d === '4' || d === '5' || d === '6' || d === '7' || d === 'same_pos_sale') return { paper: p, design: '1' };
            return { paper: p, design: d };
        }
        function normalizeProformaPrintConfig(paper, design) {
            return normalizePosSalePrintConfig(paper, design);
        }
        function getStoredPrintDesign(docType) {
            if (!db || !db.settings) return null;
            var pds = db.settings.printDesignSettings || {};
            var def = PRINT_DESIGN_DEFAULTS[docType] || { paper: '80mm', design: '1' };
            var doc = pds[docType] || {};
            return {
                paper: doc.paper || def.paper,
                design: String(doc.design != null ? doc.design : def.design)
            };
        }
        function usesSalesListProformaDesign(docType) {
            var stored = getStoredPrintDesign(docType);
            return !!(stored && stored.design === 'same_proforma');
        }
        /** Thermal list layout like sales «لیست» (proforma) button. */
        function buildProformaStyleListDocumentHtml(title, subtitle, bodyHtml, cfg) {
            cfg = cfg || (typeof getPrintConfig === 'function' ? getPrintConfig('proforma') : { paper: '80mm', design: '1' });
            var thermalLogoHtml = typeof getThermalLogoHtml === 'function' ? getThermalLogoHtml('proforma') : '';
            var thermalFontClasses = typeof getThermalFontClasses === 'function' ? getThermalFontClasses('proforma') : '';
            var width = cfg.paper || '80mm';
            var showName = !thermalLogoHtml || (typeof getThermalReceiptOptions === 'function' && getThermalReceiptOptions('proforma').logoPosition === 'none');
            var cafeName = (db && db.settings && db.settings.cafeName) ? db.settings.cafeName : 'POS';
            var cafeInfo = (db && db.settings && db.settings.cafeInfo) ? db.settings.cafeInfo : '';
            var dateStr = new Date().toLocaleString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ');
            var dateLbl = (typeof t === 'function') ? t('print_date') : 'بەروار';
            return '<div class="print-thermal-container design-' + (cfg.design || '1') + thermalFontClasses + '" style="max-width:' + width + ';width:100%;">' +
                thermalLogoHtml +
                '<div class="thermal-header">' +
                (showName ? '<h1>' + escapeHtml(cafeName) + '</h1>' : '') +
                '<p>' + escapeHtml(cafeInfo || '') + '</p>' +
                '<h2 style="margin-top:5px;font-size:1.1rem;">' + escapeHtml(title || '') + '</h2>' +
                '</div>' +
                '<div class="thermal-divider"></div>' +
                (subtitle ? '<div class="thermal-info"><span>' + escapeHtml(subtitle) + '</span></div>' : '') +
                '<div class="thermal-info"><span>' + dateLbl + ': ' + dateStr + '</span></div>' +
                '<div class="thermal-divider"></div>' +
                (bodyHtml || '') +
                '<div class="thermal-footer">' + (typeof buildPosReceiptBrandFooterHtml === 'function' ? buildPosReceiptBrandFooterHtml() : '') + '</div>' +
                '</div>';
        }
        function adaptTableHtmlForThermalList(tableHtml) {
            if (!tableHtml) return '';
            return String(tableHtml)
                .replace(/class="print-table"/g, 'class="thermal-table print-unified-table print-table"')
                .replace(/class='print-table'/g, "class='thermal-table print-unified-table print-table'");
        }
        /** A4 report or sales-list (proforma) thermal — per print-design settings. */
        function buildFlexibleReportPrintHtml(docType, title, subtitle, summaryHtml, tableHtml, cfgOverride) {
            var cfg = cfgOverride || (typeof getPrintConfig === 'function' ? getPrintConfig(docType) : { paper: '210mm', design: '1' });
            var body = (summaryHtml || '') + adaptTableHtmlForThermalList(tableHtml || '');
            if (!isA4PrintPaper(cfg.paper)) {
                return buildProformaStyleListDocumentHtml(title, subtitle, body, cfg);
            }
            if (typeof buildReportHtml === 'function') {
                return buildReportHtml(title, subtitle, summaryHtml, tableHtml);
            }
            return body;
        }
        var PDS_LIST_DOC_TYPES = ['inventory_report', 'stock_movement_log', 'stocktake_report', 'stock_transfer_report', 'debt_list', 'company_ledger', 'customer_ledger', 'expenses_report', 'daily_monthly_report', 'delivery_slip'];
        var PDS_REPORT_DOC_TYPES = ['inventory_report', 'stock_movement_log', 'stock_transfer_report', 'debt_list', 'company_ledger', 'customer_ledger', 'expenses_report', 'daily_monthly_report', 'delivery_slip'];
        var PDS_SALE_PREVIEW_DOCS = ['pos_sale', 'proforma', 'return_receipt', 'purchase_invoice', 'purchase_return'];
        function ensureSameProformaDesignOption() {
            PDS_LIST_DOC_TYPES.forEach(function(doc) {
                var el = document.getElementById('pds-' + doc + '-design');
                if (!el || el.querySelector('option[value="same_proforma"]')) return;
                var opt = document.createElement('option');
                opt.value = 'same_proforma';
                opt.setAttribute('data-i18n-opt', 'pds_d_same_proforma');
                opt.textContent = (typeof t === 'function') ? t('pds_d_same_proforma') : 'هەمان دیزاینی لیستا فرۆشتن';
                el.insertBefore(opt, el.firstChild);
            });
        }
        function getPrintConfig(docType) {
            if (!db || !db.settings) {
                var rawDef = PRINT_DESIGN_DEFAULTS[docType] || { paper: '80mm', design: '1' };
                if (docType === 'pos_sale') return Object.assign({}, rawDef, normalizePosSalePrintConfig(rawDef.paper, rawDef.design));
                if (docType === 'proforma') return Object.assign({}, rawDef, normalizeProformaPrintConfig(rawDef.paper, rawDef.design));
                return rawDef;
            }
            const pds = db.settings.printDesignSettings || {};
            const def = PRINT_DESIGN_DEFAULTS[docType] || { paper: '80mm', design: '1' };
            const doc = pds[docType] || {};
            const routing = getPrinterRouting();
            const printerId = routing[docType];
            const printer = printerId ? getPrinterById(printerId) : null;
            const rawDesign = String(doc.design != null ? doc.design : def.design);
            let paper = printer ? paperSizeToPaper(printer.paperSize) : (doc.paper || def.paper);
            let design = rawDesign;
            var linkedProforma = false;
            if (rawDesign === 'same_proforma') {
                linkedProforma = true;
                const pf = pds.proforma || {};
                const pfDef = PRINT_DESIGN_DEFAULTS.proforma || { paper: '80mm', design: '1' };
                if (!printer) paper = pf.paper || pfDef.paper;
                design = String(pf.design != null ? pf.design : pfDef.design);
            }
            var cfg = { paper: paper, design: design, printerId: printerId || null, printerName: printer ? printer.name : null, linkedProforma: linkedProforma };
            if (docType === 'proforma' && rawDesign === 'same_pos_sale') {
                const ps = pds.pos_sale || {};
                const psDef = PRINT_DESIGN_DEFAULTS.pos_sale || { paper: '80mm', design: '3' };
                if (!printer) paper = ps.paper || psDef.paper;
                design = String(ps.design != null ? ps.design : psDef.design);
                cfg.linkedPosSale = true;
            }
            if (docType === 'pos_sale') {
                var norm = normalizePosSalePrintConfig(cfg.paper, cfg.design);
                cfg.paper = norm.paper;
                cfg.design = norm.design;
            }
            if (docType === 'proforma') {
                var normPf = normalizeProformaPrintConfig(cfg.paper, cfg.design);
                cfg.paper = normPf.paper;
                cfg.design = normPf.design;
            }
            return cfg;
        }
        if (typeof window !== 'undefined') {
            window.buildFlexibleReportPrintHtml = buildFlexibleReportPrintHtml;
            window.buildProformaStyleListDocumentHtml = buildProformaStyleListDocumentHtml;
            window.usesSalesListProformaDesign = usesSalesListProformaDesign;
        }
        function buildPosSaleA4Html(sale, docTypeOrCfg) {
            if (!sale) return '';
            var cfg = (docTypeOrCfg && docTypeOrCfg.paper) ? docTypeOrCfg : getPrintConfig(typeof docTypeOrCfg === 'string' ? docTypeOrCfg : 'pos_sale');
            var d = buildA4InvoiceData(sale);
            var design = String(cfg.design || '1');
            return (design === '2') ? buildA4InvoiceMinimal(d) : (design === '8' ? buildA4InvoiceDesign3(d) : buildA4InvoiceClassic(d));
        }
        function buildPosSaleReceiptHtml(sale, grouped, opts) {
            opts = opts || {};
            var isProforma = opts.docKind === 'proforma';
            var thermalDoc = isProforma ? 'proforma' : 'pos_sale';
            var printSaleFx = opts.printSaleFx;
            var subTotal = opts.subTotal != null ? opts.subTotal : ((parseFloat(sale.total) || 0) + (parseFloat(sale.discount) || 0));
            var discount = opts.discount != null ? opts.discount : (parseFloat(sale.discount) || 0);
            var discountPercent = opts.discountPercent != null ? opts.discountPercent : (sale.discountPercent || 0);
            var isReprint = !!opts.isReprint;
            var posCfg = opts.posCfg || getPrintConfig(thermalDoc);
            var width = posCfg.paper;
            var thermalLogoHtml = typeof getThermalLogoHtml === 'function' ? getThermalLogoHtml(thermalDoc) : ((typeof getPosShopLogoUrl === 'function' && getPosShopLogoUrl()) ? '<div class="thermal-logo-wrap thermal-logo-center"><img src="' + getPosShopLogoUrl() + '" class="thermal-logo" alt=""></div>' : '');
            var thermalFontClasses = typeof getThermalFontClasses === 'function' ? getThermalFontClasses(thermalDoc) : '';
            var showNameInHeader = !thermalLogoHtml || (typeof getThermalReceiptOptions === 'function' && getThermalReceiptOptions(thermalDoc).logoPosition === 'none');
            var debtSnap80 = (typeof window.resolveSaleDebtBreakdown === 'function') ? window.resolveSaleDebtBreakdown(sale) : null;
            var debtAdded80 = debtSnap80 ? debtSnap80.debtAdded : (parseFloat(sale.debt_added != null ? sale.debt_added : sale.debt_amount) || 0);
            var cashPaid80 = debtSnap80 ? debtSnap80.cashPaid : (parseFloat(sale.cash_paid != null ? sale.cash_paid : sale.paid_amount) || 0);
            var previousDebt80 = debtSnap80 ? debtSnap80.previousDebt : (parseFloat(sale.previous_debt) || 0);
            var totalDebt80 = debtSnap80 ? debtSnap80.totalOutstandingDebt : (parseFloat(sale.total_outstanding_debt) || 0);
            var debtSectionHtml = '';
            if (!isProforma && (debtAdded80 > 0 || totalDebt80 > 0)) {
                debtSectionHtml = '<div class="thermal-divider" style="margin:3px 0;"></div>' +
                    '<div style="border:1px dashed #999;padding:3px 4px;margin-top:2px;font-size:0.72rem;line-height:1.25;">' +
                    '<div style="display:flex;justify-content:space-between;gap:6px;"><span>کۆیا گشتی:</span><b>' + formatCurrency(sale.total, printSaleFx) + '</b></div>' +
                    '<div style="display:flex;justify-content:space-between;gap:6px;"><span>نەقد:</span><b>' + formatCurrency(cashPaid80, printSaleFx) + '</b></div>' +
                    (debtAdded80 > 0 ? '<div style="display:flex;justify-content:space-between;gap:6px;"><span>قەرزی نوی:</span><b>' + formatCurrency(debtAdded80, printSaleFx) + '</b></div>' : '') +
                    (previousDebt80 != 0 ? '<div style="display:flex;justify-content:space-between;gap:6px;"><span>قەرزی پێشوو:</span><b>' + formatCurrency(previousDebt80, printSaleFx) + '</b></div>' : '') +
                    '<div style="display:flex;justify-content:space-between;gap:6px;border-top:1px solid #ccc;padding-top:2px;margin-top:2px;"><span>کۆیا قەرزی:</span><b>' + formatCurrency(totalDebt80, printSaleFx) + '</b></div>' +
                    '</div>';
            }
            var qrSrc = '';
            if (!isProforma && typeof isReceiptQrPrintEnabled === 'function' && isReceiptQrPrintEnabled()) {
                var qrPayload = buildReceiptQrPayload(sale);
                qrSrc = getReceiptQrImageSrc(qrPayload, 72);
            }
            var receiptContact = getReceiptContactInfo();
            var thermalTermsHtml = (!isProforma && typeof buildThermalReceiptTermsHtml === 'function') ? buildThermalReceiptTermsHtml() : '';
            var thermalBarcodeBlock = (!isProforma && typeof buildThermalInvoiceBarcodeHtml === 'function') ? buildThermalInvoiceBarcodeHtml(sale.id) : '';
            var qrBlock = (!isProforma && typeof isReceiptQrPrintEnabled === 'function' && isReceiptQrPrintEnabled() && qrSrc)
                ? ('<div class="receipt-qr-wrap"><img src="' + qrSrc + '" alt="QR" class="receipt-qr-img"><div class="receipt-qr-caption">' + ((typeof t === 'function') ? (t('print_qr_verify') || 'Scan for invoice verification') : 'Scan for invoice verification') + '</div></div>')
                : '';
            var tf = typeof t === 'function';
            var reprintBanner = (!isProforma && isReprint) ? ('<p style="font-weight:bold;">' + (tf ? (t('print_copy_reprint') || 'COPY - REPRINT') : 'COPY - REPRINT') + '</p>') : '';
            var preBillTitle = isProforma ? ('<h2 style="margin-top:5px;font-size:1.1rem;">' + (tf ? t('print_pre_bill') : 'ژمێریاری') + '</h2>') : '';
            var dateLabel = tf ? t('print_date') : 'بەروار';
            var invoiceLabel = tf ? t('print_invoice') : 'وەسڵ';
            var subtotalLabel = tf ? t('print_subtotal') : 'کۆمێ گشتی';
            var discountLabel = tf ? t('print_discount') : 'داشکاندن';
            var netLabel = tf ? t('print_net_total') : 'کۆیا سافی';
            var localeStr = typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ';
            var compactDate = escapeHtml(formatThermalReceiptDateTime(isProforma ? new Date() : sale.date));
            var legacyMetaPairs = [];
            if (isProforma) {
                legacyMetaPairs.push({
                    label: (typeof getTablesLabelShort === 'function' ? getTablesLabelShort() : (tf ? t('bill_header_table') : 'مێز')),
                    valueHtml: escapeHtml(String(sale.table || sale.tableName || '—'))
                });
                legacyMetaPairs.push({ label: dateLabel, valueHtml: compactDate });
            } else {
                legacyMetaPairs.push({
                    label: invoiceLabel,
                    valueHtml: '<span class="thermal-meta-inv-no">#' + escapeHtml(String(sale.id || '').toString().slice(-8)) + '</span>'
                });
                legacyMetaPairs.push({ label: dateLabel, valueHtml: compactDate });
                legacyMetaPairs.push({ label: (tf ? t('print_cashier') : 'کاشێر'), valueHtml: escapeHtml(getReceiptCashierName(sale.cashier)) });
                var legacyCustomer = resolveSaleCustomerName(sale);
                var legacyCustomerDefault = tf ? (t('print_customer_general') || 'گشتی') : 'گشتی';
                if (legacyCustomer || (parseInt(sale.customer_id, 10) > 0) || sale.payment_method === 'debt' || sale.payment_method === 'split' || (parseFloat(sale.debt_added || sale.debt_amount || 0) > 0)) {
                    legacyMetaPairs.push({ label: (tf ? t('print_customer') : 'کڕیار'), valueHtml: escapeHtml(legacyCustomer || legacyCustomerDefault) });
                }
                var legDebt = parseFloat(sale.debt_added != null ? sale.debt_added : (sale.debt_amount || 0)) || 0;
                var legCash = parseFloat(sale.cash_paid != null ? sale.cash_paid : (sale.paid_amount || 0)) || 0;
                var legPm = String(sale.payment_method || 'cash');
                var legPay = tf ? (t('payment_method_cash') || 'کاش') : 'کاش';
                var legBank = parseFloat(sale.bank_amount != null ? sale.bank_amount : (sale.paid_bank || 0)) || 0;
                if (legPm === 'fib' || legPm === 'bank' || legPm === 'bankcard' || (legBank > 0 && legCash <= 0 && legDebt <= 0)) legPay = tf ? (t('payment_method_fib') || 'FIB') : 'FIB';
                else if (legDebt > 0 && (legCash > 0 || legBank > 0)) legPay = tf ? ((t('print_status_split') && t('print_status_split') !== 'print_status_split') ? t('print_status_split') : 'نەقد و قەرز (تێکەڵ)') : 'نەقد و قەرز (تێکەڵ)';
                else if (legPm === 'debt' || legDebt > 0) legPay = tf ? (t('payment_method_debt') || 'قەرز') : 'قەرز';
                else if (legBank > 0) legPay = 'FIB';
                legacyMetaPairs.push({ label: (tf ? (t('print_type') || 'جۆر') : 'جۆر'), valueHtml: escapeHtml(legPay) });
                if (sale.table) {
                    legacyMetaPairs.push({
                        label: (typeof getTablesLabelShort === 'function' ? getTablesLabelShort() : 'مێز'),
                        valueHtml: escapeHtml(String(sale.table))
                    });
                }
            }
            var infoBlock = buildThermalMetaCompactBlock(legacyMetaPairs);
            var footerMain = isProforma
                ? ('<p style="margin:4px 0;font-weight:600;">' + (tf ? t('print_please_pay_cash') : 'هیڤیە پارەی بدەنە کاشێری') + '</p>')
                : ('<p style="margin:4px 0;">' + (db.settings ? escapeHtml(db.settings.footer || '') : '') + '</p>' +
                    '<p style="margin:2px 0;font-size:0.85rem;">سوپاس بۆ سەرەدانا وە</p>');
            var billHtml = '<div class="print-thermal-container thermal-compact design-' + (posCfg.design || '3') + thermalFontClasses + '" style="max-width: ' + width + '; width: 100%;" data-skip-print-localize="1">' +
                thermalLogoHtml +
                '<div class="thermal-header">' +
                (showNameInHeader ? '<h1>' + (db.settings ? db.settings.cafeName : 'Cafe') + '</h1>' : '') +
                reprintBanner +
                '<p>' + (db.settings ? db.settings.cafeInfo : '') + '</p>' +
                preBillTitle +
                '</div>' +
                '<div class="thermal-divider"></div>' +
                infoBlock +
                '<div class="thermal-divider"></div>' +
                '<table class="thermal-table print-unified-table">' +
                '<thead><tr><th style="text-align:right; padding-bottom:4px;">' + (tf ? (t('print_item') || 'ئایتم') : 'ئایتم') + '</th><th style="text-align:center; padding-bottom:4px;">' + (tf ? (t('print_qty') || 'ژمارە') : 'ژمارە') + '</th><th style="text-align:left; padding-bottom:4px;">' + (tf ? (t('print_price') || 'نرخ') : 'نرخ') + '</th></tr></thead>' +
                '<tbody>' +
                Object.values(grouped).map(function (g) {
                    var nameHtml = (typeof formatSaleItemNameHtml === 'function') ? formatSaleItemNameHtml(g, { skipPriceTypeLabel: true }) : ((g.name || 'ئایتم') + getSaleItemUnitSuffix(g, { skipPriceTypeLabel: true }));
                    return '<tr><td class="row-item" style="padding: 2px 0; line-height: 1.1;">' + nameHtml + (g.note ? '<br><small>* ' + escapeHtml(g.note) + '</small>' : '') + '</td><td class="row-qty" style="padding: 2px 0;">x' + formatQtyForDisplay(g.count, g) + '</td><td class="row-price" style="padding: 2px 0;">' + (g.isGift ? ((typeof t === 'function') ? t('pos_gift_label') : 'دیاری') : formatCurrency(g.sub, printSaleFx)) + '</td></tr>';
                }).join('') +
                '</tbody></table>' +
                '<div class="thermal-divider"></div>' +
                '<div class="thermal-totals-rtl">' +
                '<div class="total-row"><span>' + subtotalLabel + ':</span><span>' + formatCurrency(subTotal, printSaleFx) + '</span></div>' +
                (discount > 0 ? '<div class="total-row" style="color:black"><span>' + discountLabel + ' (' + discountPercent + '%):</span><span>-' + formatCurrency(discount, printSaleFx) + '</span></div>' : '') +
                '<div class="grand-total grand-total-compact" style="font-size:1.1rem; border-top:1px solid #000; padding-top:4px; margin-top:4px;">' + netLabel + ': ' + formatThermalSaleGrandTotalHtml(sale) + '</div>' +
                '</div>' +
                debtSectionHtml +
                thermalTermsHtml +
                '__NOTE_SLOT__' +
                thermalBarcodeBlock +
                qrBlock +
                '<div class="thermal-footer thermal-footer-compact" style="margin-top:8px;padding-top:6px;border-top:1px dashed #ccc;">' +
                footerMain +
                (typeof buildPosReceiptBrandFooterHtml === 'function' ? buildPosReceiptBrandFooterHtml() : '') +
                '</div></div>';
            var thermalDesign = String(posCfg.design || '3');
            if (!isA4PrintPaper(width) && ['3', '4', '5', '6', '7'].indexOf(thermalDesign) >= 0) {
                billHtml = buildThermalStandardSaleBillHtml({
                    sale: sale,
                    grouped: grouped,
                    printFx: printSaleFx,
                    subTotal: subTotal,
                    discount: discount,
                    cfg: posCfg,
                    thermalLogoHtml: thermalLogoHtml,
                    thermalFontClasses: thermalFontClasses,
                    debtSectionHtml: debtSectionHtml,
                    thermalTermsHtml: thermalTermsHtml,
                    thermalBarcodeBlock: thermalBarcodeBlock,
                    qrBlock: qrBlock,
                    isReprint: isReprint,
                    isProforma: isProforma
                });
            }
            return billHtml;
        }
        function buildProformaReceiptHtml(table, grouped, calc) {
            calc = calc || {};
            var pseudoSale = {
                id: 'P-' + String(table && table.id != null ? table.id : ''),
                date: new Date().toISOString(),
                table: table && table.name ? table.name : '',
                tableName: table && table.name ? table.name : '',
                total: calc.total != null ? calc.total : 0,
                discount: calc.discount != null ? calc.discount : 0,
                discountPercent: calc.discountPercent != null ? calc.discountPercent : 0
            };
            return buildPosSaleReceiptHtml(pseudoSale, grouped, {
                docKind: 'proforma',
                subTotal: calc.subTotal,
                discount: calc.discount,
                discountPercent: calc.discountPercent,
                posCfg: getPrintConfig('proforma')
            });
        }
        function buildProformaA4Html(table, grouped, calc) {
            calc = calc || {};
            var pseudoSale = {
                id: 'P-' + String(table && table.id != null ? table.id : ''),
                date: new Date().toISOString(),
                table: table && table.name ? table.name : '',
                customer: (typeof t === 'function') ? (t('print_pre_bill') || 'ژمێریاری') : 'ژمێریاری',
                items: Object.values(grouped || {}).map(function(g) {
                    return { name: g.name || 'ئایتم', qty: g.count, price: g.count > 0 ? g.sub / g.count : g.sub, total: g.sub, note: g.note, isGift: g.isGift };
                }),
                total: calc.total != null ? calc.total : 0,
                discount: calc.discount != null ? calc.discount : 0,
                subtotal: calc.subTotal != null ? calc.subTotal : 0
            };
            return buildPosSaleA4Html(pseudoSale, getPrintConfig('proforma'));
        }
        if (typeof window !== 'undefined') {
            window.buildProformaReceiptHtml = buildProformaReceiptHtml;
            window.buildProformaA4Html = buildProformaA4Html;
        }
        function executePosSalePrint(sale, grouped, opts) {
            opts = opts || {};
            if (!db || !db.settings || db.settings.autoPrint === false) return;
            sale = sale || {};
            grouped = grouped || {};
            // Rebuild grouped lines if print raced before cart snapshot had items
            try {
                var gKeys = Object.keys(grouped);
                if ((!gKeys.length) && sale.items && sale.items.length && typeof buildSaleReceiptGrouped === 'function') {
                    grouped = buildSaleReceiptGrouped(sale.items);
                    gKeys = Object.keys(grouped);
                }
                if (!gKeys.length && !(sale.items && sale.items.length)) {
                    console.warn('executePosSalePrint: skip blank receipt (no items)');
                    return;
                }
            } catch (eGrp) {}
            var posCfg = getPrintConfig('pos_sale');
            var fastTiming = opts.fastTiming === true;
            if (isA4PrintPaper(posCfg.paper)) {
                var a4Base = buildPosSaleA4Html(sale);
                if (!a4Base) return;
                if (typeof printWithOptionalNote === 'function') {
                    printWithOptionalNote({
                        docType: 'pos_sale',
                        docId: sale.id,
                        details: 'pos-a4',
                        skipNotePopup: opts.skipNotePopup === true,
                        fast: fastTiming,
                        docLabel: typeof t === 'function' ? t('pds_card_pos_sale_title') : 'فرۆشتن',
                        buildHtml: function (note) {
                            return typeof finalizePrintHtmlWithNote === 'function' ? finalizePrintHtmlWithNote(a4Base, note || '') : a4Base;
                        }
                    });
                } else {
                    printContent(a4Base, { fast: fastTiming });
                }
                return;
            }
            var billHtml = buildPosSaleReceiptHtml(sale, grouped, opts);
            if (typeof printWithOptionalNote === 'function') {
                printWithOptionalNote({
                    docType: 'pos_sale',
                    docId: sale.id,
                    details: 'pos-thermal',
                    skipNotePopup: opts.skipNotePopup === true,
                    fast: fastTiming,
                    buildHtml: function (note) {
                        return typeof finalizeThermalSaleBill === 'function' ? finalizeThermalSaleBill(billHtml, note || '') : billHtml;
                    }
                });
            } else {
                printContent(
                    typeof finalizeThermalSaleBill === 'function' ? finalizeThermalSaleBill(billHtml, '') : billHtml,
                    { fast: fastTiming }
                );
            }
        }
        function savePrintDesignSettings() {
            if (!db.settings) db.settings = {};
            var nameEl = document.getElementById('set-cafe-name');
            if (nameEl && nameEl.value.trim() !== (db.settings.cafeName || '')) {
                if (typeof verifySecretPin === 'function' && !verifySecretPin("تغییر نام فروشگاه / گوهۆڕینا ناڤێ دکانێ")) return;
            }
            if (nameEl) db.settings.cafeName = nameEl.value.trim();
            var infoEl = document.getElementById('set-cafe-info');
            if (infoEl) db.settings.cafeInfo = infoEl.value.trim();
            var phoneEl = document.getElementById('set-cafe-phone');
            if (phoneEl) db.settings.cafePhone = phoneEl.value.trim();
            var addrEl = document.getElementById('set-cafe-address');
            if (addrEl) db.settings.cafeAddress = addrEl.value.trim();
            var footerEl = document.getElementById('set-cafe-footer');
            if (footerEl) db.settings.footer = footerEl.value.trim();
            var noteEl = document.getElementById('set-invoice-note');
            if (noteEl) db.settings.invoiceNote = noteEl.value.trim();
            var customNoteEl = document.getElementById('set-custom-note');
            if (customNoteEl) db.settings.customNote = customNoteEl.value.trim();
            var sn1 = document.getElementById('set-static-note1'); if (sn1) db.settings.staticNote1 = sn1.value.trim();
            var sn2 = document.getElementById('set-static-note2'); if (sn2) db.settings.staticNote2 = sn2.value.trim();
            var sn3 = document.getElementById('set-static-note3'); if (sn3) db.settings.staticNote3 = sn3.value.trim();
            var taxEl = document.getElementById('set-tax-number');
            if (taxEl) db.settings.taxNumber = taxEl.value.trim();
            var webEl = document.getElementById('set-website');
            if (webEl) db.settings.website = webEl.value.trim();
            var socialEl = document.getElementById('set-social-links');
            if (socialEl) db.settings.socialLinks = socialEl.value.trim();
            var fileInput = document.getElementById('set-cafe-logo');
            if (fileInput && fileInput.files.length > 0) {
                resizeImageFileToLogoDataUrl(fileInput.files[0], { maxW: 720, maxH: 280 }).then(function(dataUrl) {
                    db.settings.logo = dataUrl;
                    if (typeof syncHomeShopLogo === 'function') syncHomeShopLogo();
                    if (typeof refreshLabelLogoPreview === 'function') refreshLabelLogoPreview();
                    doSavePrintDesignSettings();
                }).catch(function() {
                    alert("هەڵە د خاندنا وێنەی دا.");
                    doSavePrintDesignSettings();
                });
                return;
            }
            doSavePrintDesignSettings();
        }
        function normalizeListDocPrintDesign(paper, design) {
            var d = String(design != null ? design : '1');
            if (d === 'same_proforma' || d === 'same_pos_sale') return d;
            if (isA4PrintPaper(paper)) {
                if (d === '3' || d === '4' || d === '5' || d === '6' || d === '7') return '1';
                return d;
            }
            if (d === '1' || d === '2' || d === '8') return 'same_proforma';
            return d || '3';
        }
        function normalizeSimpleThermalDocDesign(paper, design) {
            var d = String(design != null ? design : '1');
            if (isA4PrintPaper(paper)) {
                if (d === '3' || d === '4' || d === '5' || d === '6' || d === '7') return '1';
                return d;
            }
            if (d === '1' || d === '2' || d === '8') return '3';
            return d || '3';
        }
        function setPaperSelectBestMatch(selectEl, targetPaper) {
            if (!selectEl) return false;
            var wantA4 = isA4PrintPaper(targetPaper);
            var candidates = wantA4 ? ['210mm', 'A4'] : ['80mm'];
            for (var i = 0; i < candidates.length; i++) {
                if (selectEl.querySelector('option[value="' + candidates[i] + '"]')) {
                    selectEl.value = candidates[i];
                    return true;
                }
            }
            return false;
        }
        function normalizePrintDesignForDoc(doc, paper, design) {
            if (doc === 'pos_sale' || doc === 'proforma') {
                return normalizePosSalePrintConfig(paper, design).design;
            }
            if (doc === 'kitchen_slip' || doc === 'return_receipt' || doc === 'delivery_slip' || doc === 'purchase_invoice' || doc === 'purchase_return') {
                return normalizeSimpleThermalDocDesign(paper, design);
            }
            return normalizeListDocPrintDesign(paper, design);
        }
        function setAllPrintDesignPaper(targetPaper) {
            var wantA4 = isA4PrintPaper(targetPaper) || String(targetPaper || '').toLowerCase() === 'a4';
            var docTypes = ['pos_sale', 'proforma', 'kitchen_slip', 'return_receipt', 'delivery_slip', 'inventory_report', 'stock_movement_log', 'stocktake_report', 'stock_transfer_report', 'debt_list', 'company_ledger', 'customer_ledger', 'expenses_report', 'daily_monthly_report', 'purchase_invoice', 'purchase_return'];
            var changed = 0;
            docTypes.forEach(function(doc) {
                var paperEl = document.getElementById('pds-' + doc + '-paper');
                var designEl = document.getElementById('pds-' + doc + '-design');
                if (!paperEl) return;
                if (!setPaperSelectBestMatch(paperEl, wantA4 ? '210mm' : '80mm')) return;
                changed++;
                if (designEl) {
                    designEl.value = normalizePrintDesignForDoc(doc, paperEl.value, designEl.value);
                }
            });
            ['pos_sale', 'proforma'].forEach(function(doc) {
                pdsSyncDesignFromPaper(doc);
                pdsToggleDesignFieldVisibility(doc);
                pdsRefreshDesignOptions(doc);
            });
            if (typeof updateReceiptPreview === 'function') updateReceiptPreview();
            if (typeof showToast === 'function') {
                var msgKey = wantA4 ? 'pds_global_paper_applied_a4' : 'pds_global_paper_applied_80';
                var fb = wantA4 ? 'هەموو دیزاینەکان گۆڕدران بۆ A4' : 'هەموو دیزاینەکان گۆڕدران بۆ 80mm';
                var msg = (typeof t === 'function') ? t(msgKey) : fb;
                if (!msg || msg === msgKey) msg = fb;
                showToast('✅ ' + msg + (changed ? '' : ''));
            }
        }
        window.setAllPrintDesignPaper = setAllPrintDesignPaper;
        function applyPrintPresetAll() {
            var paperEl = document.getElementById('pds-global-paper');
            if (paperEl && paperEl.value) {
                setAllPrintDesignPaper(paperEl.value);
                var designEl = document.getElementById('pds-global-design');
                if (designEl && designEl.value) {
                    var docTypes = ['pos_sale', 'proforma', 'kitchen_slip', 'return_receipt', 'delivery_slip', 'inventory_report', 'stock_movement_log', 'stocktake_report', 'stock_transfer_report', 'debt_list', 'company_ledger', 'customer_ledger', 'expenses_report', 'daily_monthly_report', 'purchase_invoice', 'purchase_return'];
                    docTypes.forEach(function(doc) {
                        var d = document.getElementById('pds-' + doc + '-design');
                        if (d) d.value = designEl.value;
                    });
                }
                return;
            }
            setAllPrintDesignPaper('80mm');
        }
        window.applyPrintPresetAll = applyPrintPresetAll;
        function doSavePrintDesignSettings() {
            var docTypes = ['pos_sale', 'proforma', 'kitchen_slip', 'return_receipt', 'delivery_slip', 'inventory_report', 'stock_movement_log', 'stocktake_report', 'stock_transfer_report', 'debt_list', 'company_ledger', 'customer_ledger', 'expenses_report', 'daily_monthly_report', 'purchase_invoice', 'purchase_return'];
            db.settings.printDesignSettings = db.settings.printDesignSettings || {};
            db.settings.printerRouting = db.settings.printerRouting || {};
            docTypes.forEach(function(doc) {
                var paperEl = document.getElementById('pds-' + doc + '-paper');
                var designEl = document.getElementById('pds-' + doc + '-design');
                var printerEl = document.getElementById('pds-' + doc + '-printer');
                if (paperEl && designEl) {
                    var paper = pdsMigratePaperValue(paperEl.value);
                    var design = designEl.value;
                    if (doc === 'pos_sale' || doc === 'proforma') {
                        var norm = normalizePosSalePrintConfig(paper, design);
                        paper = norm.paper;
                        design = norm.design;
                    } else {
                        var autoDesign = pdsAutoDesignForPaper(doc, paper);
                        if (autoDesign) design = autoDesign;
                    }
                    db.settings.printDesignSettings[doc] = { paper: paper, design: design };
                }
                if (printerEl && printerEl.value) db.settings.printerRouting[doc] = printerEl.value; else if (db.settings.printerRouting) delete db.settings.printerRouting[doc];
            });
            if (typeof saveThermalReceiptOptions === 'function') {
                saveThermalReceiptOptions('pos_sale', true);
                saveThermalReceiptOptions('proforma', true);
            }
            var d3LayoutEl = document.getElementById('set-a4-design3-logo-layout');
            if (d3LayoutEl) db.settings.a4Design3LogoLayout = d3LayoutEl.value || 'center';
            var accentEl = document.getElementById('set-a4-accent-theme');
            if (accentEl) db.settings.a4AccentTheme = accentEl.value || 'amber';
            var pibSave = document.getElementById('set-print-invoice-barcode');
            if (pibSave) db.settings.printInvoiceBarcode = !!pibSave.checked;
            if (typeof saveLabelPrintSettingsFromForm === 'function') saveLabelPrintSettingsFromForm();
            saveSettings().then(function() {
                showToast('✅ ' + (typeof t === 'function' ? t('pds_save_print_ok') : ''));
                applyPrintSettings();
                updateReceiptPreview();
            }).catch(function(e) { var msg = (e && e.message && e.message !== 'Unknown') ? e.message : ((typeof t === 'function') ? t('pds_save_print_error') : ''); showToast('❌ ' + msg, true); });
        }
        function applyPrintDesignSettings() {
            if (!db || !db.settings) return;

            // Auto-inject Sales Return Design Card if it doesn't exist in HTML
            var existingRetCard = document.querySelector('.pds-card[data-doc="return_receipt"]');
            if (!existingRetCard) {
                var posSaleCard = document.querySelector('.pds-card[data-doc="pos_sale"]');
                if (posSaleCard && posSaleCard.parentNode) {
                    var divRet = document.createElement('div');
                    divRet.className = 'pds-card';
                    divRet.setAttribute('data-doc', 'return_receipt');
                    divRet.innerHTML = '<div class="pds-card-header" onclick="togglePdsCard(\'return_receipt\')">' +
                        '<span><i class="fas fa-undo"></i> <span data-i18n="pds_card_return_title">پسولەیا زڤڕاندنێ</span></span>' +
                        '<i class="fas fa-chevron-down toggle-icon"></i>' +
                        '</div>' +
                        '<div class="pds-card-body">' +
                        '<label><span data-i18n="pds_lbl_paper_size">قەبارەی کاغەز</span></label>' +
                        '<select id="pds-return_receipt-paper" class="input-std">' +
                        '<option value="80mm" data-i18n-opt="pds_paper_sel_80">٨٠ مم (ترمەڵ)</option>' +
                        '<option value="210mm" data-i18n-opt="pds_paper_sel_a4">A4</option>' +
                        '</select>' +
                        '<label class="pds-design-field"><span data-i18n="pds_lbl_design">دیزاین</span></label>' +
                        '<select id="pds-return_receipt-design" class="input-std pds-design-field">' +
                        '<option value="1" data-i18n-opt="pds_d_a4_1">A4</option>' +
                        '<option value="3" data-i18n-opt="pds_d_80_thermal">٨٠ مم</option>' +
                        '</select>' +
                        '<label><span data-i18n="pds_lbl_printer_route">پرێنتەر</span></label>' +
                        '<select id="pds-return_receipt-printer" class="input-std pds-printer-select"></select>' +
                        '</div>';
                    posSaleCard.parentNode.insertBefore(divRet, posSaleCard.nextSibling);
                    if (typeof applyI18nSubtree === 'function') applyI18nSubtree(divRet);
                }
            }

            // Auto-inject Purchase Return Design Card if it doesn't exist in HTML
            var existingCard = document.querySelector('.pds-card[data-doc="purchase_return"]');
            if (!existingCard) {
                var lastCard = document.querySelector('.pds-card[data-doc="purchase_invoice"]');
                if (lastCard && lastCard.parentNode) {
                    var div = document.createElement('div');
                    div.className = 'pds-card';
                    div.setAttribute('data-doc', 'purchase_return');
                    div.innerHTML = '<div class="pds-card-header" onclick="togglePdsCard(\'purchase_return\')">' +
                        '<span><i class="fas fa-undo"></i> <span data-i18n="pds_inject_purchase_return_title">زڤڕاندنی کڕین</span></span>' +
                        '<i class="fas fa-chevron-down toggle-icon"></i>' +
                        '</div>' +
                        '<div class="pds-card-body">' +
                        '<label><span data-i18n="pds_lbl_paper_size">قەبارەی کاغەز</span></label>' +
                        '<select id="pds-purchase_return-paper" class="input-std">' +
                        '<option value="80mm" data-i18n-opt="pds_paper_sel_80">٨٠ مم (ترمەڵ)</option>' +
                        '<option value="210mm" data-i18n-opt="pds_paper_sel_a4">A4</option>' +
                        '</select>' +
                        '<label class="pds-design-field"><span data-i18n="pds_lbl_design">دیزاین</span></label>' +
                        '<select id="pds-purchase_return-design" class="input-std pds-design-field">' +
                        '<option value="1" data-i18n-opt="pds_d_a4_1">A4</option>' +
                        '<option value="3" data-i18n-opt="pds_d_80_thermal">٨٠ مم</option>' +
                        '</select>' +
                        '<label><span data-i18n="pds_lbl_printer_route">پرێنتەر</span></label>' +
                        '<select id="pds-purchase_return-printer" class="input-std pds-printer-select"></select>' +
                        '</div>';
                    lastCard.parentNode.insertBefore(div, lastCard.nextSibling);
                    if (typeof applyI18nSubtree === 'function') applyI18nSubtree(div);
                }
            }

            const pds = db.settings.printDesignSettings || {};
            const routing = db.settings.printerRouting || {};
            const docTypes = ['pos_sale', 'proforma', 'kitchen_slip', 'return_receipt', 'delivery_slip', 'inventory_report', 'stock_movement_log', 'stocktake_report', 'stock_transfer_report', 'debt_list', 'company_ledger', 'customer_ledger', 'expenses_report', 'daily_monthly_report', 'purchase_invoice', 'purchase_return'];
            if (typeof renderPrintersList === 'function') renderPrintersList();
            if (typeof applyLabelPrintSettingsToForm === 'function') applyLabelPrintSettingsToForm();
            docTypes.forEach(doc => {
                const d = pds[doc] || PRINT_DESIGN_DEFAULTS[doc];
                const paperEl = document.getElementById('pds-' + doc + '-paper');
                const designEl = document.getElementById('pds-' + doc + '-design');
                const printerEl = document.getElementById('pds-' + doc + '-printer');
                if (paperEl) {
                    var migrated = pdsMigratePaperValue((d && d.paper) || PRINT_DESIGN_DEFAULTS[doc].paper);
                    paperEl.value = migrated;
                    if (!paperEl.dataset.pdsWired) {
                        paperEl.dataset.pdsWired = '1';
                        paperEl.addEventListener('change', function() { pdsOnPaperChange(doc); });
                    }
                }
                if (designEl) {
                    designEl.value = (d && d.design) || PRINT_DESIGN_DEFAULTS[doc].design;
                    pdsSyncDesignFromPaper(doc);
                    if (!designEl.dataset.pdsWired) {
                        designEl.dataset.pdsWired = '1';
                        designEl.addEventListener('change', function() { doSavePrintDesignSettings(); });
                    }
                }
                pdsToggleDesignFieldVisibility(doc);
                pdsRefreshDesignOptions(doc);
                if (printerEl) {
                    if (routing[doc]) {
                        printerEl.value = routing[doc];
                        if (printerEl.value !== routing[doc]) {
                            var keep = document.createElement('option');
                            keep.value = routing[doc];
                            keep.textContent = routing[doc];
                            printerEl.appendChild(keep);
                            printerEl.value = routing[doc];
                        }
                    } else {
                        printerEl.value = '';
                    }
                    if (!printerEl.dataset.pdsWired) {
                        printerEl.dataset.pdsWired = '1';
                        printerEl.addEventListener('change', function() { doSavePrintDesignSettings(); });
                    }
                }
            });
            if (typeof applyThermalReceiptOptions === 'function') applyThermalReceiptOptions();
            if (typeof ensureSameProformaDesignOption === 'function') ensureSameProformaDesignOption();
            if (typeof applyPrintNotePremiumUI === 'function') applyPrintNotePremiumUI();
            if (typeof pdsEnsurePreviewButtons === 'function') pdsEnsurePreviewButtons();
        }
