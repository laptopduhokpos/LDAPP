<!DOCTYPE html>
<html lang="ku" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover, interactive-widget=resizes-content">
    <!-- PWA / MOBILE APP MODE -->
    <link rel="manifest" href="manifest.json">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="pos-app-version" content="<?php echo htmlspecialchars(POS_APP_VERSION, ENT_QUOTES, 'UTF-8'); ?>">
    <?php
    // Absolute path to API router so fetch(?action=…) never hits HTML from a wrong DOCUMENT_URI (e.g. opening views/pos_main.php directly).
    $pos_script_name = isset($_SERVER['SCRIPT_NAME']) ? str_replace('\\', '/', (string) $_SERVER['SCRIPT_NAME']) : '/index.php';
    $pos_base_name = basename($pos_script_name);
    if ($pos_base_name === 'index.php') {
        $pos_dir = dirname($pos_script_name);
        $pos_index_path = ($pos_dir === '/' || $pos_dir === '.' || $pos_dir === '') ? '/index.php' : rtrim($pos_dir, '/') . '/index.php';
    } else {
        $pos_parent = dirname(dirname($pos_script_name));
        $pos_index_path = ($pos_parent === '/' || $pos_parent === '.' || $pos_parent === '') ? '/index.php' : rtrim($pos_parent, '/') . '/index.php';
    }
    ?>
    <script>
    window.POS_APP_VERSION=<?php echo json_encode(POS_APP_VERSION); ?>;
    window.POS_APP_RELEASE_LABEL=<?php echo json_encode(defined('POS_APP_RELEASE_LABEL') ? POS_APP_RELEASE_LABEL : ('Laptop Duhok POS v' . POS_APP_VERSION . ' - Production Certified')); ?>;
    window.POS_RECEIPT_BRAND=<?php echo json_encode([
        'name' => defined('POS_RECEIPT_BRAND_NAME') ? POS_RECEIPT_BRAND_NAME : 'Laptop Duhok POS',
        'phone' => defined('POS_RECEIPT_BRAND_PHONE') ? POS_RECEIPT_BRAND_PHONE : '07507367680',
    ], JSON_UNESCAPED_UNICODE); ?>;
    window.POS_PREMIUM_PRICING=<?php echo json_encode(pos_premium_pricing_js(), JSON_UNESCAPED_UNICODE); ?>;
    (function posSyncVersionLabelsEarly() {
        var v = String(window.POS_APP_VERSION || '');
        if (!v) return;
        function sync() {
            document.querySelectorAll('.startup-version-num, [data-pos-app-version]').forEach(function (el) {
                el.textContent = 'v' + v;
            });
            var title = document.querySelector('title');
            if (title && title.textContent.indexOf('Laptop Duhok POS') >= 0) {
                title.textContent = 'Laptop Duhok POS v' + v;
            }
        }
        if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', sync);
        else sync();
    })();
    window.POS_DEFAULT_LOGO=<?php echo json_encode($pos_default_logo_url, JSON_UNESCAPED_UNICODE); ?>;
    window.POS_DEFAULT_SHOP_LOGO=<?php echo json_encode(isset($pos_default_shop_logo_url) ? $pos_default_shop_logo_url : (defined('POS_DEFAULT_SHOP_LOGO_PATH') ? POS_DEFAULT_SHOP_LOGO_PATH : 'public/assets/brand/laptop-duhok-logo.png'), JSON_UNESCAPED_UNICODE); ?>;
    window.__POS_INDEX_PATH__=<?php echo json_encode($pos_index_path); ?>;
    window.__POS_PUBLIC_INSTALL_SERIAL__=<?php echo json_encode($pos_public_install_serial ?? '', JSON_UNESCAPED_UNICODE); ?>;
    window.posRouterUrl=function(q){var qs=String(q||'').replace(/^\?/,'');var b=typeof window.__POS_INDEX_PATH__==='string'?window.__POS_INDEX_PATH__:'';if(!b)return qs?'?'+qs:'?';return qs?(b+'?'+qs):b;};
    (function posBootstrapClientDevice(){
        function isRemotePosHost(){
            var h=String(location.hostname||'').toLowerCase();
            if(h===''||h==='localhost'||h==='127.0.0.1') return false;
            if(/android|iphone|ipad|ipod|mobile/i.test(navigator.userAgent||'')) return true;
            // Laptop/tablet opened via store LAN IP (e.g. 192.168.x.x) — terminal (TERM) path, not primary 6-digit code
            if(/^\d{1,3}(\.\d{1,3}){3}$/.test(h)) return true;
            if(h.indexOf(':')!==-1) return true;
            return false;
        }
        window.__posDeviceBootstrapPromise=new Promise(function(resolve){
            var isTerminal=false;
            var clientSeed='';
            try {
                var KEY='pos_client_device_key';
                var serverKeys={
                    primary:<?php echo json_encode((string)($pos_machine_device_keys['primary'] ?? ''), JSON_UNESCAPED_UNICODE); ?>,
                    terminal:<?php echo json_encode((string)($pos_machine_device_keys['terminal'] ?? ''), JSON_UNESCAPED_UNICODE); ?>
                };
                var isRemote=isRemotePosHost();
                try{
                    if(/[?&]fragi=1(?:&|$)/.test(String(location.search||''))) localStorage.setItem('pos_fragi_device_mode','1');
                    if(isRemote){
                        localStorage.setItem('pos_fragi_device_mode','1');
                        clientSeed=localStorage.getItem('pos_fragi_client_seed')||'';
                        if(!clientSeed){
                            clientSeed=(typeof crypto!=='undefined'&&typeof crypto.randomUUID==='function')?crypto.randomUUID():('cs'+String(Date.now()));
                            localStorage.setItem('pos_fragi_client_seed',clientSeed);
                        }
                        window.__posFragiClientSeed=clientSeed;
                        isTerminal=true;
                    }else if(localStorage.getItem('pos_fragi_device_mode')==='1'){
                        isTerminal=true;
                    }
                    if(!isTerminal){
                        localStorage.setItem('pos_enable_multi_device','0');
                        if(String(localStorage.getItem('pos_client_device_key')||'').indexOf('pos-term-')===0&&serverKeys.primary){
                            localStorage.setItem('pos_client_device_key',serverKeys.primary);
                        }
                    }
                }catch(eT){}
                var v='';
                if(isTerminal&&!isRemote){
                    if(serverKeys.terminal&&String(serverKeys.terminal).length>=8){
                        v=serverKeys.terminal;
                    }else{
                        window.__posTerminalMacMissing=true;
                    }
                }else if(!isTerminal){
                    v=serverKeys.primary||'';
                    if(v&&String(v).length>=8){
                        try{
                            localStorage.setItem(KEY,v);
                            localStorage.setItem('pos_enable_multi_device','0');
                            localStorage.removeItem('pos_fragi_device_mode');
                        }catch(ePk){}
                    }
                }
                if(!isTerminal&&(!v||String(v).length<8)){
                    v=typeof localStorage!=='undefined'?localStorage.getItem(KEY):null;
                    if(v&&String(v).indexOf('pos-term-')===0&&serverKeys.primary){
                        v=serverKeys.primary;
                    }
                }
                function done(){
                    if(!v||String(v).length<8){
                        if(typeof crypto!=='undefined'&&typeof crypto.randomUUID==='function')v=crypto.randomUUID();
                        else v='dk'+String(Date.now())+Math.random().toString(36).slice(2,14);
                    }
                    try{localStorage.setItem(KEY,v);}catch(e0){}
                    window.__posDeviceKey=v;
                    window.__posBootstrapIsTerminal=!!isTerminal;
                    resolve();
                }
                if(isRemote&&clientSeed){
                    var u=(typeof window.posRouterUrl==='function')
                        ?window.posRouterUrl('action=get_fragi_client_device_key&client_seed='+encodeURIComponent(clientSeed))
                        :('?action=get_fragi_client_device_key&client_seed='+encodeURIComponent(clientSeed));
                    fetch(u,{credentials:'same-origin',headers:{'X-POS-Client-Seed':clientSeed}})
                        .then(function(r){return r.json();})
                        .then(function(d){
                            if(d&&d.status==='success'&&d.device_key)v=String(d.device_key);
                            else window.__posTerminalMacMissing=true;
                            done();
                        })
                        .catch(function(){ window.__posTerminalMacMissing=true; done(); });
                    return;
                }
                done();
            } catch(e) {
                window.__posDeviceKey='';
                window.__posBootstrapIsTerminal=false;
                resolve();
            }
        });
        window.__posDeviceRegisterPromise=window.__posDeviceBootstrapPromise.then(function(){
            try{
                var isTerminal=!!window.__posBootstrapIsTerminal;
                var dk=window.__posDeviceKey||''; if(!dk) return Promise.resolve({status:'error',message:'no device key'});
                var regSkipMs=300000;
                try{
                    var lastReg=parseInt(sessionStorage.getItem('pos_dev_reg_at')||'0',10);
                    if(lastReg>0&&(Date.now()-lastReg)<regSkipMs){
                        var cached=window.__posDeviceRegisterResult;
                        if(cached&&typeof cached==='object') return Promise.resolve(cached);
                        return Promise.resolve({status:'success',skipped:true});
                    }
                }catch(eSkip){}
                var fd=new FormData();
                fd.append('action','register_pos_client_device');
                fd.append('device_key',dk);
                try{ fd.append('platform',typeof navigator!=='undefined'?(navigator.platform||''):''); }catch(e2){}
                try{ if(isTerminal) fd.append('device_role','terminal'); }catch(eMd){}
                if(window.__posFragiClientSeed) fd.append('client_seed',String(window.__posFragiClientSeed));
                var regHeaders={'X-POS-Device-Key':dk};
                try{ if(isTerminal) regHeaders['X-POS-Device-Role']='terminal'; }catch(eMdH){}
                try{ if(window.__posFragiClientSeed) regHeaders['X-POS-Client-Seed']=String(window.__posFragiClientSeed); }catch(eCs){}
                var url=typeof window.posRouterUrl==='function'?window.posRouterUrl('action=register_pos_client_device'):'?action=register_pos_client_device';
                var regOpts={method:'POST',body:fd,credentials:'same-origin',headers:regHeaders};
                try{
                    if(typeof AbortSignal!=='undefined'&&typeof AbortSignal.timeout==='function'){
                        regOpts.signal=AbortSignal.timeout(8000);
                    }
                }catch(eTo){}
                return fetch(url,regOpts)
                    .then(function(r){ return r.json().catch(function(){ return {status:'error',message:'invalid json'}; }); })
                    .then(function(d){
                        window.__posDeviceRegisterResult = d || {};
                        try{ if(d&&d.status!=='error') sessionStorage.setItem('pos_dev_reg_at', String(Date.now())); }catch(eRegTs){}
                        if(!d || d.status === 'error') {
                            console.warn('[POS] Device register:', d && d.message ? d.message : 'failed');
                        }
                        return d;
                    })
                    .catch(function(err){
                        window.__posDeviceRegisterResult = {status:'error',message:String(err&&err.message||'network')};
                        return window.__posDeviceRegisterResult;
                    });
            }catch(e3){ return Promise.resolve({status:'error',message:'register bootstrap failed'}); }
        })();
    })();
    </script>
    <title><?php echo htmlspecialchars('Laptop Duhok POS v' . POS_APP_VERSION, ENT_QUOTES, 'UTF-8'); ?></title>
    <link rel="preload" href="<?php echo htmlspecialchars($pos_default_logo_url, ENT_QUOTES, 'UTF-8'); ?>" as="image" type="image/png" fetchpriority="high">
    <!-- Offline-first: icons/fonts local only (run scripts/download-offline-vendor.ps1 -IconsOnly) -->
    <link rel="preload" href="public/fonts/rudaw/Rudaw-Regular.ttf" as="font" type="font/ttf" crossorigin>
    <link rel="preload" href="public/vendor/fontawesome/webfonts/fa-solid-900.woff2" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="public/vendor/fontawesome/webfonts/fa-brands-400.woff2" as="font" type="font/woff2" crossorigin>
    <link rel="stylesheet" href="public/vendor/fontawesome/css/all.min.css">
    <script src="public/vendor/jspdf/jspdf.umd.min.js"></script>
    <script src="public/vendor/jspdf/jspdf.plugin.autotable.min.js"></script>
    <script src="public/vendor/html2canvas/html2canvas.min.js"></script>
    <script src="public/vendor/chartjs/chart.umd.min.js"></script>
    <script src="public/vendor/qrcode/qrcode.min.js"></script>
    <script src="public/vendor/jsbarcode/JsBarcode.all.min.js"></script>
    <script src="public/vendor/fflate/fflate.min.js"></script>
    <?php
    $pos_asset_v = rawurlencode((string) POS_APP_VERSION);
    $pos_css_bundle = [
        'pos-00-fonts',
        'pos-01-base',
        'pos-02-shell',
        'pos-02-shell-b',
        'pos-03-cards',
        'pos-04-txn',
        'pos-05-workspaces',
        'pos-06-warehouse',
        'pos-07-menus',
        'pos-08-performance',
        /* last: beats mobile .glass-card width:100% and default glass padding */
        'pos-history-standard',
    ];
    foreach ($pos_css_bundle as $pos_css_part) {
        echo '<link rel="stylesheet" href="public/css/' . $pos_css_part . '.css?v=' . $pos_asset_v . '">';
    }
    ?>
    <script src="public/js/core/business-profiles.js?v=<?php echo $pos_asset_v; ?>"></script>
    <script src="public/js/core/jewelry.js?v=<?php echo $pos_asset_v; ?>"></script>
    <script src="public/js/sync/firebase-config.js?v=<?php echo $pos_asset_v; ?>"></script>
    <script src="public/js/sync/firebase-cashier.js?v=<?php echo $pos_asset_v; ?>"></script>
    <script type="module" src="public/js/main.js?v=<?php echo $pos_asset_v; ?>"></script>
    <style>
        /* OTA bottom dock — optional update while shop keeps working */
        .pos-ota-dock {
            position: fixed;
            left: 50%;
            bottom: 12px;
            transform: translateX(-50%);
            z-index: 20005;
            display: none;
            align-items: center;
            gap: 8px;
            max-width: min(560px, calc(100vw - 24px));
            padding: 8px 10px;
            border-radius: 16px;
            background: linear-gradient(135deg, rgba(6, 78, 59, 0.94), rgba(4, 47, 46, 0.96));
            border: 1px solid rgba(52, 211, 153, 0.45);
            box-shadow: 0 10px 28px rgba(0, 0, 0, 0.28);
            color: #ecfdf5;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            direction: rtl;
        }
        .pos-ota-dock.is-visible { display: flex !important; }
        .pos-ota-dock.is-minimized {
            left: auto;
            right: 12px;
            transform: none;
            max-width: none;
            padding: 6px 8px;
            border-radius: 999px;
        }
        .pos-ota-dock.is-minimized .pos-ota-dock__text,
        .pos-ota-dock.is-minimized .pos-ota-dock__copy,
        .pos-ota-dock.is-minimized .pos-ota-dock__apply,
        .pos-ota-dock.is-minimized .pos-ota-dock__min,
        .pos-ota-dock.is-minimized .pos-ota-dock__progress { display: none !important; }
        .pos-ota-dock.is-minimized .pos-ota-dock__main {
            padding: 4px 8px;
            gap: 6px;
        }
        .pos-ota-dock.is-progressing {
            left: 50%;
            right: auto;
            transform: translateX(-50%);
            max-width: min(640px, calc(100vw - 24px));
            padding: 10px 12px;
            border-radius: 16px;
        }
        .pos-ota-dock.is-progressing .pos-ota-dock__apply { display: none !important; }
        .pos-ota-dock.is-progressing .pos-ota-dock__badge { display: none !important; }
        .pos-ota-dock__main {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            border: 0;
            background: transparent;
            color: inherit;
            cursor: pointer;
            text-align: right;
            padding: 2px 4px;
            min-width: 0;
            flex: 1;
        }
        .pos-ota-dock__copy {
            display: flex;
            flex-direction: column;
            gap: 6px;
            min-width: 0;
            flex: 1;
            text-align: right;
        }
        .pos-ota-dock__progress {
            display: flex;
            flex-direction: column;
            gap: 4px;
            width: 100%;
        }
        .pos-ota-dock__progress-track {
            display: block;
            height: 7px;
            border-radius: 999px;
            background: rgba(148, 163, 184, 0.28);
            overflow: hidden;
        }
        .pos-ota-dock__progress-bar {
            display: block;
            height: 100%;
            width: 0%;
            border-radius: 999px;
            background: linear-gradient(90deg, #34d399, #10b981);
            transition: width .28s ease;
        }
        .pos-ota-dock__progress-text {
            font-size: 0.75rem;
            font-weight: 700;
            color: #fde68a;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .pos-ota-dock__badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 22px;
            height: 22px;
            padding: 0 6px;
            border-radius: 999px;
            background: #fbbf24;
            color: #78350f;
            font-weight: 800;
            font-size: 0.8rem;
            flex-shrink: 0;
        }
        .pos-ota-dock__text {
            font-size: 0.86rem;
            font-weight: 600;
            line-height: 1.35;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .pos-ota-dock__apply {
            border: 0;
            border-radius: 12px;
            padding: 8px 12px;
            background: #10b981;
            color: #042f2e;
            font-weight: 800;
            cursor: pointer;
            white-space: nowrap;
            flex-shrink: 0;
        }
        .pos-ota-dock__apply:hover { filter: brightness(1.06); }
        .pos-ota-dock__min {
            border: 0;
            background: rgba(255,255,255,0.1);
            color: #a7f3d0;
            width: 32px;
            height: 32px;
            border-radius: 10px;
            cursor: pointer;
            flex-shrink: 0;
        }
        @media (max-width: 640px) {
            .pos-ota-dock { bottom: 8px; padding: 7px 8px; }
            .pos-ota-dock__text { font-size: 0.78rem; max-width: 42vw; }
            .pos-ota-dock__apply { padding: 7px 9px; font-size: 0.8rem; }
        }

        #pos-notification-fab {
            position: fixed;
            right: 12px;
            top: 8px;
            z-index: 20010;
            width: 44px;
            height: 44px;
            border-radius: 999px;
            border: 1px solid rgba(51, 65, 85, 0.45);
            background: rgba(15, 23, 42, 0.38);
            color: #e2e8f0;
            display: none;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.18);
            opacity: 0.2;
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            transition: opacity 0.25s ease, box-shadow 0.25s ease, border-color 0.25s ease, background 0.25s ease;
        }
        #pos-notification-fab:hover {
            opacity: 0.72;
            background: rgba(15, 23, 42, 0.62);
            border-color: rgba(100, 116, 139, 0.65);
        }
        #pos-notification-fab.panel-open {
            opacity: 0.82;
            background: rgba(15, 23, 42, 0.72);
        }
        #pos-notification-fab.has-unread {
            opacity: 0.48;
            border-color: rgba(248, 113, 113, 0.4);
            background: rgba(15, 23, 42, 0.5);
            box-shadow: 0 4px 14px rgba(220, 38, 38, 0.16);
        }
        #pos-notification-fab.has-unread:hover {
            opacity: 0.68;
        }
        #pos-notification-fab.installment-alert-pulse {
            opacity: 1 !important;
            animation: pos-installment-fab-pulse 1.1s ease-in-out infinite;
            border-color: rgba(245, 158, 11, 0.95) !important;
            box-shadow: 0 0 0 0 rgba(245, 158, 11, 0.55), 0 8px 24px rgba(245, 158, 11, 0.35) !important;
        }
        @keyframes pos-installment-fab-pulse {
            0%, 100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(245, 158, 11, 0.5); }
            50% { transform: scale(1.08); box-shadow: 0 0 0 10px rgba(245, 158, 11, 0); }
        }
        #pos-notification-toast.installment-toast-active #pos-toast-card {
            border-right-width: 5px !important;
            box-shadow: 0 12px 32px rgba(245, 158, 11, 0.28);
        }
        #pos-init-overlay {
            position: absolute;
            inset: 0;
            z-index: 5000;
            display: none;
            align-items: center;
            justify-content: center;
            background: rgba(15, 23, 42, 0.72);
            backdrop-filter: blur(2px);
            pointer-events: all;
        }
        #pos-init-overlay .pos-init-overlay-inner {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 12px;
            color: #e2e8f0;
            font-size: 1rem;
        }
        #pos-init-overlay .pos-init-overlay-inner i {
            font-size: 2rem;
            color: var(--brand, #3b82f6);
        }
        #pos-notification-fab .count {
            position: absolute;
            top: -5px;
            right: -5px;
            min-width: 18px;
            height: 18px;
            border-radius: 999px;
            background: #dc2626;
            color: #fff;
            font-size: 11px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0 4px;
        }
        #pos-notification-panel {
            position: fixed;
            right: 12px;
            top: 58px;
            z-index: 20010;
            width: min(360px, calc(100vw - 24px));
            max-height: 56vh;
            background: #0b1220;
            border: 1px solid #334155;
            border-radius: 12px;
            overflow: hidden;
            display: none;
        }
        #pos-notification-panel .head {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            border-bottom: 1px solid #1f2937;
            color: #cbd5e1;
        }
        #pos-notification-list {
            overflow: auto;
            max-height: calc(56vh - 46px);
        }
        #pos-notification-list .item {
            padding: 10px;
            border-bottom: 1px solid #1f2937;
            color: #e2e8f0;
            font-size: 13px;
        }
        #pos-notification-list .item:last-child { border-bottom: 0; }
        #pos-notification-list .meta {
            color: #94a3b8;
            font-size: 11px;
            margin-top: 4px;
        }
        #pos-notification-toast {
            position: fixed;
            top: 70px;
            right: 14px;
            z-index: 20020;
            width: min(350px, calc(100vw - 28px));
            display: none;
            animation: toast-slide-in 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }
        @keyframes toast-slide-in {
            from { transform: translateX(120%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        @keyframes toast-slide-out {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(120%); opacity: 0; }
        }
        #pos-notification-toast .toast-card {
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
            border-right: 4px solid var(--brand, #3b82f6);
            border-radius: 12px;
            padding: 16px;
            color: #f1f5f9;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: flex-start;
            gap: 14px;
            cursor: pointer;
            transition: transform 0.2s;
        }
        #pos-notification-toast .toast-card:hover {
            transform: scale(1.02);
        }
        #pos-notification-toast .toast-icon {
            font-size: 1.6rem;
            color: var(--brand, #3b82f6);
            margin-top: 2px;
            background: rgba(255,255,255,0.05);
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        #pos-notification-toast .toast-content {
            flex: 1;
        }
        #pos-notification-toast .toast-title { font-weight: 600; margin-bottom: 6px; font-size: 1.05rem; color: #fff; }
        #pos-notification-toast .toast-msg { color: #cbd5e1; font-size: 0.95rem; line-height: 1.5; }
    </style>
    <script>
    (function(){
        try {
            var DEFAULT_APP_LOGO = (typeof window.POS_DEFAULT_LOGO === 'string' && window.POS_DEFAULT_LOGO) ? window.POS_DEFAULT_LOGO : 'public/assets/brand/laptop-duhok-logo.png';
            var storedLogo = typeof localStorage !== 'undefined' && localStorage.getItem('pos_startup_logo');
            if (storedLogo && /blogger\.googleusercontent\.com/i.test(String(storedLogo))) {
                try { localStorage.removeItem('pos_startup_logo'); } catch(eRm) {}
                storedLogo = '';
            }
            var logo = storedLogo || DEFAULT_APP_LOGO;
            var appName = "Laptop Duhok POS";
            try { 
                var storedDB = localStorage.getItem('pos_db');
                if (storedDB) {
                    var parsed = JSON.parse(storedDB);
                    if (parsed.settings && parsed.settings.cafeName) appName = parsed.settings.cafeName;
                }
            } catch(e) {}
            if (logo) {
                var link = document.querySelector("link[rel~='icon']");
                if (!link) {
                    link = document.createElement('link');
                    link.rel = 'icon';
                    document.head.appendChild(link);
                }
                link.href = logo;
                
                var appleLink = document.querySelector("link[rel='apple-touch-icon']");
                if (!appleLink) {
                    appleLink = document.createElement('link');
                    appleLink.rel = 'apple-touch-icon';
                    document.head.appendChild(appleLink);
                }
                appleLink.href = logo;
                
                var manifest = {
                    "name": appName,
                    "short_name": appName,
                    "start_url": ".",
                    "display": "standalone",
                    "background_color": "#000000",
                    "theme_color": "#000000",
                    "icons": [{
                        "src": logo,
                        "sizes": "192x192 512x512",
                        "type": "image/png",
                        "purpose": "any maskable"
                    }]
                };
                var manifestBlob = new Blob([JSON.stringify(manifest)], {type: 'application/json'});
                var manifestUrl = URL.createObjectURL(manifestBlob);
                var manifestLink = document.querySelector("link[rel='manifest']");
                if (!manifestLink) {
                    manifestLink = document.createElement('link');
                    manifestLink.rel = 'manifest';
                    document.head.appendChild(manifestLink);
                }
                manifestLink.href = manifestUrl;
            }
            
            // Register Service Worker — updateViaCache:'none' skips HTTP cache for SW script; update() checks for new SW after deploy
            if ('serviceWorker' in navigator) {
                window.addEventListener('load', function() {
                    navigator.serviceWorker.register('service-worker.js', { updateViaCache: 'none' }).then(function(registration) {
                        registration.update();
                    }).catch(function() { /* SW optional offline cache */ });
                });
            }
        } catch(e) {}
    })();
    </script>
</head>
<body id="pos-body">
    <script>
    (function(){ try {
        // --- CRITICAL: EARLY LANGUAGE & ZOOM LOCK ---
        var L = typeof localStorage !== 'undefined' ? localStorage.getItem('pos_language') : null;
        if (L === 'ar' || L === 'badini') {
            document.documentElement.setAttribute('lang', L === 'ar' ? 'ar' : 'ku');
            document.documentElement.setAttribute('dir', 'rtl');
            document.documentElement.setAttribute('data-pos-language', L);
        }
        if (L === 'ar') {
            function posApplyBootLoaderAr() {
                var map = { app_boot_loading: 'جاري تحميل النظام...', app_boot_sub: 'يرجى الانتظار' };
                var boot = document.getElementById('app-boot-loader');
                if (!boot) return;
                boot.querySelectorAll('[data-i18n]').forEach(function(el) {
                    var k = el.getAttribute('data-i18n');
                    if (map[k]) el.textContent = map[k];
                });
            }
            if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', posApplyBootLoaderAr);
            else posApplyBootLoaderAr();
        }
        var Z = typeof localStorage !== 'undefined' ? parseInt(localStorage.getItem('pos_zoom'), 10) : null;
        if (Z && Z >= 70 && Z <= 150) {
            document.documentElement.setAttribute('data-pos-zoom', String(Z));
            document.documentElement.style.setProperty('--pos-ui-scale', String(Z / 100));
        }
        (function posAutoDetectGraphicsEarly() {
            try {
                if (localStorage.getItem('pos_graphics_user_override') === '1') return;
                if (localStorage.getItem('pos_graphics_auto_v1') === '1') return;
                var cores = navigator.hardwareConcurrency || 2;
                var mem = navigator.deviceMemory || 0;
                var w = 0;
                if (cores <= 2) w += 4; else if (cores < 4) w += 2; else if (cores <= 4) w += 1;
                if (mem > 0 && mem <= 2) w += 4; else if (mem > 0 && mem <= 4) w += 3; else if (mem > 0 && mem <= 6) w += 1; else if (mem > 0 && mem <= 8) w += 1;
                var q = 'low';
                localStorage.setItem('pos_graphics_quality', q);
                localStorage.setItem('pos_graphics_auto_v1', '1');
            } catch (eGfxAuto) {}
        })();
        var GQ = typeof localStorage !== 'undefined' ? localStorage.getItem('pos_graphics_quality') : null;
        GQ = 'low';
        try { localStorage.setItem('pos_graphics_quality', GQ); } catch (eGfxQ) {}
        document.documentElement.setAttribute('data-pos-graphics', GQ);
        document.documentElement.classList.add('pos-cpu-save');
        document.documentElement.classList.add('pos-cpu-ultra');
        document.body.style.zoom = '';
        try {
            if (typeof sessionStorage !== 'undefined' && sessionStorage.getItem('pos_session_active') === '1') {
                document.documentElement.classList.add('app-booting', 'pos-pre-auth');
            } else {
                document.documentElement.classList.add('pos-pre-auth');
            }
        } catch (_eBootEarly) {}
        function posHideStartupOnResume() {
            var st = document.getElementById('startup-screen');
            if (st) st.style.display = 'none';
        }
        try {
            if (typeof sessionStorage !== 'undefined' && sessionStorage.getItem('pos_session_active') === '1') {
                if (document.readyState === 'loading') {
                    document.addEventListener('DOMContentLoaded', posHideStartupOnResume);
                } else {
                    posHideStartupOnResume();
                }
            }
        } catch (_eStHide) {}
    } catch(e) { console.error('Early script error:', e); } })();
    </script>
    <div id="app-zoom-wrapper">
    <div id="app-zoom-inner">
    <script>document.body.style.zoom = '';</script>
