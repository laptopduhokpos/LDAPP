# List installed Windows printers as JSON array of {name, offline, default}
$ErrorActionPreference = 'SilentlyContinue'
$out = @()

try {
    $printers = Get-Printer -ErrorAction Stop
    foreach ($p in $printers) {
        $offline = $false
        try {
            if ($p.PrinterStatus -and ([string]$p.PrinterStatus -match 'Offline|Error|Paused')) { $offline = $true }
        } catch {}
        $out += [PSCustomObject]@{
            name    = [string]$p.Name
            offline = [bool]$offline
            default = [bool]$p.Default
        }
    }
} catch {
    try {
        $printers = Get-CimInstance -ClassName Win32_Printer
        foreach ($p in $printers) {
            $out += [PSCustomObject]@{
                name    = [string]$p.Name
                offline = [bool]$p.WorkOffline
                default = [bool]$p.Default
            }
        }
    } catch {
        Write-Output '[]'
        exit 0
    }
}

$out | ConvertTo-Json -Compress -Depth 3
