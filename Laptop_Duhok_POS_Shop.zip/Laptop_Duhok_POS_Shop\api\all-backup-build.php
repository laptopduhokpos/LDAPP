<?php
// Backup ZIP/JSON build helpers
function getBackupTableList($conn) {
    $tables = [];
    $res = $conn->query("SHOW TABLES");
    if ($res) {
        while ($row = $res->fetch_array(MYSQLI_NUM)) {
            if (!empty($row[0])) $tables[] = $row[0];
        }
    }
    return $tables;
}

/**
 * Tables for «download items only» — catalog only (no stock history).
 * Stock qty/expiry are zeroed/cleared in pos_sanitize_items_catalog_backup().
 */
function pos_backup_items_tables($conn = null) {
    $wanted = [
        'products',
        'categories',
        'manufacturers',
        'recipes',
    ];
    if (!($conn instanceof mysqli)) {
        return ['products', 'categories', 'manufacturers'];
    }
    $existing = array_flip(getBackupTableList($conn));
    $out = [];
    foreach ($wanted as $t) {
        if (isset($existing[$t])) $out[] = $t;
    }
    return $out ?: ['products', 'categories', 'manufacturers'];
}

/**
 * Items ZIP for transfer: qty=0, no expiry/dates, no warehouse stock history.
 */
function pos_sanitize_items_catalog_backup(array $payload) {
    $tableData = isset($payload['table_data']) && is_array($payload['table_data'])
        ? $payload['table_data']
        : [];

    // Drop stock/history tables if present
    unset($tableData['stock_batches'], $tableData['warehouse_stock'], $tableData['supplies'], $tableData['stock_movements']);

    if (isset($tableData['products']) && is_array($tableData['products'])) {
        foreach ($tableData['products'] as &$row) {
            if (!is_array($row)) continue;
            $row['qty'] = 0;
            if (array_key_exists('expiry', $row)) $row['expiry'] = '';
            if (array_key_exists('expiry_date', $row)) $row['expiry_date'] = '';
            if (array_key_exists('created_at', $row)) $row['created_at'] = null;
            if (array_key_exists('updated_at', $row)) $row['updated_at'] = null;
        }
        unset($row);
    }

    $counts = [];
    foreach ($tableData as $t => $rows) {
        $counts[$t] = is_array($rows) ? count($rows) : 0;
    }
    $payload['table_data'] = $tableData;
    $payload['table_counts'] = $counts;
    $payload['_profile'] = 'items_catalog_zero_stock';
    $payload['_note'] = 'Catalog only: product qty=0, expiry cleared, no stock history.';
    return $payload;
}

function getBackupFilesystemTargets($baseDir) {
    $targets = [];
    $dirs = ['uploads', 'public/uploads', 'public/images', 'public/assets'];
    foreach ($dirs as $rel) {
        $abs = $baseDir . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $rel);
        if (is_dir($abs)) $targets[] = ['type' => 'dir', 'abs' => realpath($abs)];
    }
    $files = ['realtime_database.rules.json', 'public/js/sync/firebase-config.js'];
    foreach ($files as $rel) {
        $abs = $baseDir . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $rel);
        if (is_file($abs)) $targets[] = ['type' => 'file', 'abs' => realpath($abs)];
    }
    return $targets;
}

function normalizeBackupRelativePath($baseDir, $absPath) {
    $base = rtrim(str_replace('\\', '/', realpath($baseDir)), '/');
    $abs = str_replace('\\', '/', realpath($absPath));
    if ($abs === false || strpos($abs, $base . '/') !== 0) return null;
    return ltrim(substr($abs, strlen($base)), '/');
}

function collectFilesystemBackupEntries($baseDir) {
    $entries = [];
    foreach (getBackupFilesystemTargets($baseDir) as $target) {
        if ($target['type'] === 'file') {
            $rel = normalizeBackupRelativePath($baseDir, $target['abs']);
            if ($rel && is_readable($target['abs'])) {
                $entries[$rel] = $target['abs'];
            }
            continue;
        }
        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($target['abs'], FilesystemIterator::SKIP_DOTS)
        );
        foreach ($it as $f) {
            if (!$f->isFile()) continue;
            $abs = $f->getPathname();
            if (!is_readable($abs)) continue;
            $rel = normalizeBackupRelativePath($baseDir, $abs);
            if ($rel) $entries[$rel] = $abs;
        }
    }
    ksort($entries);
    return $entries;
}

function pos_get_backup_exclude_tables(array $options = []) {
    // Rollback snapshots duplicate the live DB — omit from full backup (~40% smaller).
    $exclude = ['system_snapshots'];
    if (!empty($options['slim'])) {
        $exclude = array_merge($exclude, ['audit_logs', 'print_log']);
    }
    if (!empty($options['exclude_movements'])) {
        $exclude[] = 'stock_movements';
    }
    return array_values(array_unique($exclude));
}

/** Compress snapshot JSON for system_snapshots.data (prefix gzb64:). */
function pos_encode_snapshot_data($json) {
    if (!is_string($json) || $json === '') return $json;
    if (function_exists('gzencode')) {
        $packed = @gzencode($json, 6);
        if ($packed !== false) {
            return 'gzb64:' . base64_encode($packed);
        }
    }
    return $json;
}

function pos_decode_snapshot_data($raw) {
    $raw = (string)$raw;
    if ($raw === '') return null;
    if (strncmp($raw, 'gzb64:', 6) === 0) {
        $bin = base64_decode(substr($raw, 6), true);
        if ($bin !== false && function_exists('gzdecode')) {
            $json = @gzdecode($bin);
            if ($json !== false) {
                $decoded = json_decode($json, true);
                if (is_array($decoded)) return $decoded;
            }
        }
    }
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : null;
}

/** Admin dashboard: which tables grow fastest (MB + row counts). */
function pos_get_database_size_report($conn) {
    $report = ['total_mb' => 0.0, 'tables' => [], 'tips' => []];
    $dbRes = $conn->query('SELECT DATABASE()');
    $dbName = ($dbRes && ($dbRow = $dbRes->fetch_row())) ? (string)$dbRow[0] : '';
    if ($dbName === '') return $report;

    $stmt = $conn->prepare(
        'SELECT table_name, ROUND((data_length + index_length) / 1024 / 1024, 2) AS mb, table_rows
         FROM information_schema.tables
         WHERE table_schema = ?
         ORDER BY (data_length + index_length) DESC'
    );
    if (!$stmt) return $report;
    $stmt->bind_param('s', $dbName);
    $stmt->execute();
    $res = $stmt->get_result();
    $total = 0.0;
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $mb = (float)($row['mb'] ?? 0);
            $total += $mb;
            $report['tables'][] = [
                'name' => (string)($row['table_name'] ?? ''),
                'mb' => $mb,
                'rows' => (int)($row['table_rows'] ?? 0),
            ];
        }
    }
    $report['total_mb'] = round($total, 2);

    $byName = [];
    foreach ($report['tables'] as $t) {
        $byName[$t['name']] = $t;
    }
    if (($byName['system_snapshots']['mb'] ?? 0) > 5) {
        $report['tips'][] = 'system_snapshots: وێنەی rollback ـە — لە backup دەرکراوە؛ پاککردن یان کەمکردنیان قەبارە کەم دەکات.';
    }
    if (($byName['sales']['mb'] ?? 0) > 20 || ($byName['sales_archive']['mb'] ?? 0) > 20) {
        $report['tips'][] = 'sales: فرۆشتنێن >١ ساڵ ئەرشیف بکە، پاش backup ساڵانە ئەرشیف بسڕەوە.';
    }
    if (($byName['stock_movements']['mb'] ?? 0) > 15) {
        $report['tips'][] = 'stock_movements: logـێ کۆن (>٣ ساڵ) دەتوانرێت پاک بکرێت — ledger دەمێنێتەوە.';
    }
    if (($byName['audit_logs']['mb'] ?? 0) + ($byName['print_log']['mb'] ?? 0) > 3) {
        $report['tips'][] = 'audit_logs / print_log: logـێ >١ ساڵ پاک بکە.';
    }

    $salesMb = (float)($byName['sales']['mb'] ?? 0);
    $salesRows = (int)($byName['sales']['rows'] ?? 0);
    if ($salesRows > 100 && $salesMb > 5) {
        $estPer10y = round($salesMb * 5, 0);
        $report['projection'] = [
            'sales_mb_now' => $salesMb,
            'estimate_10y_no_archive_mb' => $estPer10y,
            'estimate_10y_with_yearly_mb' => max(40, round($salesMb * 0.8, 0)),
        ];
        $report['tips'][] = 'بەبێ ئەرشیف ساڵانە backup لە ~' . $estPer10y . 'MB دەگات — «پاککردنی ساڵانە» + backup ساڵانە بەکاربێنە.';
    }
    $report['ten_year_plan'] = [
        'step1' => 'هەر ساڵ: پاککردنی ساڵانە (archive + log)',
        'step2' => 'هەر ساڵ: ZIP ساڵانە لە USB/Cloud پارێزە',
        'step3' => 'دوای پاراستن: ئەرشیفی کۆن بسڕەوە',
        'step4' => 'گەڕاندنەوە: تەنها دوایین Full ZIP',
    ];
    return $report;
}

/** Purge operational noise; optional old stock_movements (ledger kept). */
function pos_cleanup_operational_data($conn, array $opts = []) {
    $auditDays = max(30, (int)($opts['audit_days'] ?? 365));
    $printDays = max(30, (int)($opts['print_days'] ?? 365));
    $movementYears = max(0, (int)($opts['movement_years'] ?? 0));
    $snapshotKeep = max(3, min(15, (int)($opts['snapshot_keep'] ?? 10)));
    $deleted = [
        'audit_logs' => 0,
        'print_log' => 0,
        'stock_movements' => 0,
        'system_snapshots' => 0,
    ];

    $auditLimit = date('Y-m-d H:i:s', strtotime("-{$auditDays} days"));
    $stmt = $conn->prepare('DELETE FROM audit_logs WHERE created_at < ?');
    if ($stmt) {
        $stmt->bind_param('s', $auditLimit);
        $stmt->execute();
        $deleted['audit_logs'] = $stmt->affected_rows;
    }

    $printLimit = date('Y-m-d H:i:s', strtotime("-{$printDays} days"));
    $stmt = $conn->prepare('DELETE FROM print_log WHERE created_at < ?');
    if ($stmt) {
        $stmt->bind_param('s', $printLimit);
        $stmt->execute();
        $deleted['print_log'] = $stmt->affected_rows;
    }

    $keep = $snapshotKeep;
    $conn->query(
        "DELETE FROM system_snapshots WHERE id NOT IN (
            SELECT id FROM (SELECT id FROM system_snapshots ORDER BY id DESC LIMIT {$keep}) x
        )"
    );
    $deleted['system_snapshots'] = $conn->affected_rows;

    if ($movementYears > 0) {
        $moveLimit = date('Y-m-d H:i:s', strtotime("-{$movementYears} years"));
        $stmt = $conn->prepare('DELETE FROM stock_movements WHERE date < ?');
        if ($stmt) {
            $stmt->bind_param('s', $moveLimit);
            $stmt->execute();
            $deleted['stock_movements'] = $stmt->affected_rows;
        }
    }

    return $deleted;
}

/** Move old sales/expenses to archive tables (same logic as UI archive). */
function pos_archive_old_data($conn, $days) {
    $days = (int)$days;
    $archived_sales = 0;
    $archived_expenses = 0;
    $now = date('Y-m-d H:i:s');

    if ($days === 0) {
        $conn->query("INSERT INTO sales_archive (id, total, discount, items_json, created_at, cashier, payment_method, customer_id, customer_type, is_returned, transaction_id, archived_at, fx_usd_rate, fx_currency_mode) SELECT id, total, discount, items_json, created_at, cashier, payment_method, customer_id, customer_type, is_returned, transaction_id, '$now', fx_usd_rate, fx_currency_mode FROM sales");
        $archived_sales = (int)$conn->affected_rows;
        $conn->query('DELETE FROM sales');

        $conn->query("INSERT INTO expenses_archive (id, note, amount, `date`, user, type, transaction_id, archived_at) SELECT id, note, amount, `date`, user, type, transaction_id, '$now' FROM expenses");
        $archived_expenses = (int)$conn->affected_rows;
        $conn->query('DELETE FROM expenses');
    } else {
        $date_limit = date('Y-m-d H:i:s', strtotime("-{$days} days"));

        $stmt = $conn->prepare("INSERT INTO sales_archive (id, total, discount, items_json, created_at, cashier, payment_method, customer_id, customer_type, is_returned, transaction_id, archived_at, fx_usd_rate, fx_currency_mode) SELECT id, total, discount, items_json, created_at, cashier, payment_method, customer_id, customer_type, is_returned, transaction_id, ?, fx_usd_rate, fx_currency_mode FROM sales WHERE created_at < ?");
        if ($stmt) {
            $stmt->bind_param('ss', $now, $date_limit);
            $stmt->execute();
            $archived_sales = (int)$stmt->affected_rows;
            $stmt->close();
        }

        $stmt_del = $conn->prepare('DELETE FROM sales WHERE created_at < ?');
        if ($stmt_del) {
            $stmt_del->bind_param('s', $date_limit);
            $stmt_del->execute();
            $stmt_del->close();
        }

        $stmt2 = $conn->prepare("INSERT INTO expenses_archive (id, note, amount, `date`, user, type, transaction_id, archived_at) SELECT id, note, amount, `date`, user, type, transaction_id, ? FROM expenses WHERE `date` < ?");
        if ($stmt2) {
            $stmt2->bind_param('ss', $now, $date_limit);
            $stmt2->execute();
            $archived_expenses = (int)$stmt2->affected_rows;
            $stmt2->close();
        }

        $stmt2_del = $conn->prepare('DELETE FROM expenses WHERE `date` < ?');
        if ($stmt2_del) {
            $stmt2_del->bind_param('s', $date_limit);
            $stmt2_del->execute();
            $stmt2_del->close();
        }
    }

    return [
        'archived_sales' => $archived_sales,
        'archived_expenses' => $archived_expenses,
        'archive_days' => $days,
    ];
}

/**
 * Long-term DB hygiene for multi-year shops (archive + log cleanup).
 * movement_years=0 skips stock_movements purge (ledger-safe default).
 */
function pos_run_ten_year_maintenance($conn, array $opts = []) {
    $archiveDays = max(90, (int)($opts['archive_days'] ?? 365));
    $out = [
        'archive' => pos_archive_old_data($conn, $archiveDays),
        'cleanup' => pos_cleanup_operational_data($conn, [
            'audit_days' => max(90, (int)($opts['audit_days'] ?? 365)),
            'print_days' => max(90, (int)($opts['print_days'] ?? 365)),
            'movement_years' => max(0, (int)($opts['movement_years'] ?? 0)),
            'snapshot_keep' => max(3, min(15, (int)($opts['snapshot_keep'] ?? 10))),
        ]),
    ];
    return $out;
}

function pos_backup_table_date_filter_sql($table, array $options) {
    $yearsKeep = max(0, (int)($options['years_keep'] ?? 0));
    if ($yearsKeep <= 0) {
        return ['sql' => "SELECT * FROM `$table`", 'types' => '', 'params' => []];
    }
    $cutoff = date('Y-m-d H:i:s', strtotime('-' . $yearsKeep . ' years'));
    $dateCol = null;
    if ($table === 'sales' || $table === 'sales_archive') {
        $dateCol = 'created_at';
    } elseif ($table === 'expenses' || $table === 'expenses_archive') {
        $dateCol = 'date';
    } elseif ($table === 'supplies') {
        $dateCol = 'date';
    } elseif ($table === 'stock_movements') {
        $dateCol = 'date';
    } elseif ($table === 'returns') {
        $dateCol = 'created_at';
    } elseif ($table === 'ledger') {
        $dateCol = 'created_at';
    }
    if ($dateCol === null) {
        return ['sql' => "SELECT * FROM `$table`", 'types' => '', 'params' => []];
    }
    return [
        'sql' => "SELECT * FROM `$table` WHERE `$dateCol` >= ?",
        'types' => 's',
        'params' => [$cutoff],
    ];
}

function pos_fetch_backup_table_rows($conn, $table, array $options = []) {
    $rows = [];
    $q = pos_backup_table_date_filter_sql($table, $options);
    if (!empty($q['params'])) {
        $stmt = $conn->prepare($q['sql']);
        if ($stmt) {
            $stmt->bind_param($q['types'], ...$q['params']);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($res) {
                while ($row = $res->fetch_assoc()) {
                    $rows[] = $row;
                }
            }
            $stmt->close();
        }
        return $rows;
    }
    $res = @$conn->query($q['sql']);
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $rows[] = $row;
        }
    }
    return $rows;
}

/** Yearly cold-storage backup (store one ZIP per year on disk/USB). */
function buildYearlyBackupPayload($conn, $year, array $options = []) {
    $year = (int)$year;
    if ($year < 2000 || $year > 2100) {
        throw new Exception('ساڵ نادروستە.');
    }
    $from = sprintf('%04d-01-01 00:00:00', $year);
    $to = sprintf('%04d-01-01 00:00:00', $year + 1);

    $alwaysFull = [
        'products', 'categories', 'settings', 'customers', 'companies', 'warehouses',
        'users', 'warehouse_stock', 'stock_batches', 'tables',
    ];
    $tableData = [];
    $tableCounts = [];

    foreach ($alwaysFull as $table) {
        $tableData[$table] = pos_fetch_backup_table_rows($conn, $table, []);
        $tableCounts[$table] = count($tableData[$table]);
    }

    $yearPairs = [
        ['sales', 'created_at'],
        ['sales_archive', 'created_at'],
        ['expenses', 'date'],
        ['expenses_archive', 'date'],
        ['supplies', 'date'],
        ['returns', 'created_at'],
    ];
    foreach ($yearPairs as $pair) {
        $table = $pair[0];
        $col = $pair[1];
        $tableData[$table] = [];
        $stmt = $conn->prepare("SELECT * FROM `$table` WHERE `$col` >= ? AND `$col` < ?");
        if ($stmt) {
            $stmt->bind_param('ss', $from, $to);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($res) {
                while ($row = $res->fetch_assoc()) {
                    $tableData[$table][] = $row;
                }
            }
            $stmt->close();
        }
        $tableCounts[$table] = count($tableData[$table]);
    }

    return [
        '_backup_at' => date('Y-m-d H:i:s'),
        '_version' => 2,
        '_format' => 'yearly_archive_v1',
        '_year' => $year,
        'table_data' => $tableData,
        'table_counts' => $tableCounts,
        '_note' => 'Cold storage for year ' . $year . ' — keep on USB/cloud; use full backup for restore.',
    ];
}

function buildDatabaseBackupPayload($conn, $tables, array $options = []) {
    $exclude = pos_get_backup_exclude_tables($options);
    $excludeMap = array_flip($exclude);
    $yearsKeep = max(0, (int)($options['years_keep'] ?? 0));
    $tableData = [];
    $tableCounts = [];
    foreach ($tables as $table) {
        if (isset($excludeMap[$table])) {
            $tableData[$table] = [];
            $tableCounts[$table] = 0;
            continue;
        }
        $fetchOpts = $yearsKeep > 0 ? ['years_keep' => $yearsKeep] : [];
        $tableData[$table] = pos_fetch_backup_table_rows($conn, $table, $fetchOpts);
        $tableCounts[$table] = count($tableData[$table]);
    }
    $payload = [
        '_backup_at' => date('Y-m-d H:i:s'),
        '_version' => 2,
        '_format' => 'full_zip_package_v2',
        'table_data' => $tableData,
        'table_counts' => $tableCounts,
    ];
    if (!empty($exclude)) {
        $payload['_excluded_tables'] = $exclude;
    }
    if ($yearsKeep > 0) {
        $payload['_years_keep'] = $yearsKeep;
        $payload['_note'] = 'Only last ' . $yearsKeep . ' years of dated tables; use yearly ZIP for older years.';
    }
    $payload['_backup_profile'] = (string)($options['profile'] ?? 'full');
    $verify = pos_verify_backup_payload($payload, $conn);
    $payload['_backup_verified'] = $verify['ok'];
    if (!$verify['ok']) {
        $payload['_backup_missing'] = $verify['missing'];
    }
    return $payload;
}

/** Tables required for a valid full restore (business data). */
function pos_backup_critical_tables() {
    return [
        'products', 'categories', 'settings', 'sales', 'sales_archive', 'ledger', 'supplies',
        'customers', 'companies', 'warehouses', 'warehouse_stock', 'stock_batches', 'users',
        'manufacturers', 'customer_ledger', 'returns', 'purchase_returns', 'recipes', 'tables',
        'expenses', 'shifts', 'stock_transfers', 'stock_transfer_lines',
    ];
}

function pos_verify_backup_payload(array $payload, $conn = null) {
    $tableData = $payload['table_data'] ?? [];
    $required = pos_backup_critical_tables();
    if ($conn instanceof mysqli && function_exists('getBackupTableList')) {
        $existing = array_flip(getBackupTableList($conn));
        $required = array_values(array_filter($required, function ($t) use ($existing) {
            return isset($existing[$t]);
        }));
    }
    $missing = [];
    foreach ($required as $tbl) {
        if (!array_key_exists($tbl, $tableData)) {
            $missing[] = $tbl;
        }
    }
    return ['ok' => count($missing) === 0, 'missing' => $missing, 'table_counts' => $payload['table_counts'] ?? []];
}

/**
 * Split large DB into 2 ZIP parts for Telegram (50MB bot limit).
 * Part1 = core/live; Part2 = history + EVERY remaining table (so nothing is dropped).
 */
function pos_get_backup_split_groups($conn = null) {
    $part1 = [
        'products', 'categories', 'settings', 'customers', 'companies', 'manufacturers', 'warehouses', 'users',
        'warehouse_stock', 'stock_batches', 'tables', 'ledger', 'customer_ledger', 'shifts',
        'waste', 'returns', 'purchase_returns', 'expenses', 'expenses_archive', 'deliveries', 'drivers',
        'customer_installment_plans', 'customer_installment_items', 'company_documents',
        'exchange_rate_history', 'pos_notifications', 'pos_notification_reads', 'stock_transfers',
        'stock_transfer_lines', 'recipes',
    ];
    $part2Seed = [
        'sales', 'sales_archive', 'stock_movements', 'supplies', 'audit_logs', 'print_log',
    ];
    $part2 = $part2Seed;
    if ($conn instanceof mysqli && function_exists('getBackupTableList')) {
        $exclude = array_flip(pos_get_backup_exclude_tables([]));
        $part1Map = array_flip($part1);
        $part2Map = array_flip($part2);
        foreach (getBackupTableList($conn) as $table) {
            if ($table === '' || isset($exclude[$table]) || isset($part1Map[$table]) || isset($part2Map[$table])) {
                continue;
            }
            $part2[] = $table;
            $part2Map[$table] = true;
        }
    }
    return [1 => $part1, 2 => $part2];
}

function pos_backup_split_missing_tables($conn, array $groups) {
    if (!($conn instanceof mysqli) || !function_exists('getBackupTableList')) return [];
    $exclude = array_flip(pos_get_backup_exclude_tables([]));
    $covered = array_flip(array_merge($groups[1] ?? [], $groups[2] ?? []));
    $missing = [];
    foreach (getBackupTableList($conn) as $table) {
        if ($table === '' || isset($exclude[$table])) continue;
        if (!isset($covered[$table])) $missing[] = $table;
    }
    return $missing;
}

function buildPartialBackupPayload($conn, array $includeTables, array $options, $partNum, $partTotal) {
    $exclude = pos_get_backup_exclude_tables($options);
    $excludeMap = array_flip($exclude);
    $includeMap = array_flip($includeTables);
    $tableData = [];
    $tableCounts = [];
    $allTables = getBackupTableList($conn);
    foreach ($allTables as $table) {
        if (isset($excludeMap[$table]) || !isset($includeMap[$table])) {
            continue;
        }
        $fetchOpts = !empty($options['years_keep']) ? ['years_keep' => (int)$options['years_keep']] : [];
        $tableData[$table] = pos_fetch_backup_table_rows($conn, $table, $fetchOpts);
        $tableCounts[$table] = count($tableData[$table]);
    }
    return [
        '_backup_at' => date('Y-m-d H:i:s'),
        '_version' => 2,
        '_format' => 'full_zip_package_v2',
        '_backup_part' => (int)$partNum,
        '_backup_parts_total' => (int)$partTotal,
        'table_data' => $tableData,
        'table_counts' => $tableCounts,
        '_excluded_tables' => $exclude,
    ];
}

function pos_send_backup_download_headers($contentType, $downloadFileName, $outputData, array $extraHeaders = []) {
    while (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: ' . $contentType);
    header('Content-Disposition: attachment; filename="' . $downloadFileName . '"');
    header('Content-Length: ' . strlen($outputData));
    header('X-Backup-Bytes: ' . strlen($outputData));
    foreach ($extraHeaders as $hk => $hv) {
        header($hk . ': ' . $hv);
    }
    echo $outputData;
}

/** One-file POS backup: gzip JSON. No ZipArchive, no nested folders. */
function pos_backup_json_flags() {
    $flags = JSON_UNESCAPED_UNICODE;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
        $flags |= JSON_INVALID_UTF8_SUBSTITUTE;
    }
    return $flags;
}

function pos_backup_wrap_envelope(array $data, $kind = 'full') {
    $kind = ($kind === 'items') ? 'items' : 'full';
    $data['magic'] = 'LD_POSBAK_V1';
    $data['kind'] = $kind;
    $data['_format'] = 'posbak_gzip_v1';
    if (!isset($data['_backup_at'])) {
        $data['_backup_at'] = date('Y-m-d H:i:s');
    }
    if (!isset($data['_version'])) {
        $data['_version'] = 2;
    }
    if (defined('POS_APP_VERSION')) {
        $data['app_version'] = POS_APP_VERSION;
    }
    return $data;
}

/**
 * Encode catalog/full payload as .posbak (gzip JSON, or raw JSON if zlib missing).
 * @return array{binary:string,filename:string,content_type:string,format:string}
 */
function pos_encode_posbak(array $data, $filenameBase, $kind = 'full') {
    $data = pos_backup_wrap_envelope($data, $kind);
    $json = json_encode($data, pos_backup_json_flags());
    if ($json === false) {
        throw new Exception('JSON encode failed: ' . json_last_error_msg());
    }
    $base = preg_replace('/[^a-zA-Z0-9._-]/', '_', (string)$filenameBase);
    if ($base === '') {
        $base = 'Laptop_Duhok_POS_Backup';
    }
    $filename = $base . '.posbak';
    if (function_exists('gzencode')) {
        $gz = @gzencode($json, 6);
        if (is_string($gz) && strlen($gz) >= 16) {
            return [
                'binary' => $gz,
                'filename' => $filename,
                'content_type' => 'application/octet-stream',
                'format' => 'posbak_gzip_v1',
            ];
        }
    }
    return [
        'binary' => $json,
        'filename' => $filename,
        'content_type' => 'application/octet-stream',
        'format' => 'posbak_json_v1',
    ];
}

function pos_backup_bytes_to_utf8($raw) {
    if (!is_string($raw) || $raw === '') {
        return $raw;
    }
    if (strncmp($raw, "\xEF\xBB\xBF", 3) === 0) {
        $raw = substr($raw, 3);
    }
    if (strncmp($raw, "\xFF\xFE", 2) === 0 && function_exists('mb_convert_encoding')) {
        $out = @mb_convert_encoding($raw, 'UTF-8', 'UTF-16LE');
        return is_string($out) ? $out : $raw;
    }
    if (strncmp($raw, "\xFE\xFF", 2) === 0 && function_exists('mb_convert_encoding')) {
        $out = @mb_convert_encoding($raw, 'UTF-8', 'UTF-16BE');
        return is_string($out) ? $out : $raw;
    }
    return $raw;
}

function pos_json_decode_lenient($raw) {
    $raw = pos_backup_bytes_to_utf8((string)$raw);
    $decoded = json_decode($raw, true);
    if (is_array($decoded)) {
        return $decoded;
    }
    $trim = ltrim($raw);
    if ($trim !== '' && ($trim[0] === '{' || $trim[0] === '[')) {
        $decoded = json_decode($trim, true);
        if (is_array($decoded)) {
            return $decoded;
        }
    }
    return null;
}

/**
 * Pull table_data / products from any POS-ish JSON shape.
 */
function pos_normalize_decoded_backup($decoded) {
    if (!is_array($decoded)) {
        return null;
    }
    if (isset($decoded['table_data']) && is_array($decoded['table_data'])) {
        return $decoded;
    }
    foreach (['data', 'payload', 'backup', 'db'] as $nest) {
        if (isset($decoded[$nest]) && is_array($decoded[$nest]) && isset($decoded[$nest]['table_data']) && is_array($decoded[$nest]['table_data'])) {
            $inner = $decoded[$nest];
            foreach (['magic', 'kind', '_format', '_version', '_backup_at', 'app_version', 'table_counts'] as $k) {
                if (!isset($inner[$k]) && isset($decoded[$k])) {
                    $inner[$k] = $decoded[$k];
                }
            }
            return $inner;
        }
    }
    $td = [];
    foreach (['products', 'categories', 'manufacturers', 'recipes', 'items'] as $k) {
        if (!empty($decoded[$k]) && is_array($decoded[$k])) {
            $td[$k === 'items' ? 'products' : $k] = $decoded[$k];
        }
    }
    if ($td) {
        $decoded['table_data'] = $td;
        if (!isset($decoded['table_counts'])) {
            $decoded['table_counts'] = [];
            foreach ($td as $t => $rows) {
                $decoded['table_counts'][$t] = is_array($rows) ? count($rows) : 0;
            }
        }
        return $decoded;
    }
    if (isset($decoded[0]) && is_array($decoded[0])) {
        $row0 = $decoded[0];
        if (isset($row0['name']) || isset($row0['barcode']) || isset($row0['qty']) || isset($row0['price'])) {
            return [
                'magic' => 'LD_POSBAK_V1',
                'kind' => 'items',
                '_format' => 'posbak_gzip_v1',
                'table_data' => ['products' => array_values($decoded)],
                'table_counts' => ['products' => count($decoded)],
            ];
        }
    }
    return $decoded;
}

function pos_loaded_package_from_decoded(array $decoded) {
    $decoded = pos_normalize_decoded_backup($decoded);
    if (!is_array($decoded)) {
        throw new Exception('داتای بک‌ئەپێ نەهاتە خاندن.');
    }
    $hasTd = isset($decoded['table_data']) && is_array($decoded['table_data']);
    if ($hasTd) {
        return [
            'mode' => 'package',
            'data' => $decoded,
            'manifest' => [
                'format' => 'full_zip_package_v2',
                'table_counts' => $decoded['table_counts'] ?? [],
                'files' => [],
            ],
            'zip' => null,
            'extract_dir' => null,
            'files_restored' => 0,
        ];
    }
    return [
        'mode' => 'legacy',
        'data' => $decoded,
        'manifest' => null,
        'zip' => null,
        'files_restored' => 0,
    ];
}

function pos_backup_dir_path() {
    $dir = realpath(__DIR__ . '/../backups');
    return $dir ?: (__DIR__ . '/../backups');
}

/**
 * Rolling local names inside pos/backups/ — overwrite same file, do not pile timestamped ZIPs.
 */
function pos_local_backup_stable_name($downloadFileName) {
    $safe = basename((string)$downloadFileName);
    $safe = preg_replace('/[^a-zA-Z0-9._-]/', '_', $safe);
    if ($safe === '' || $safe === '.' || $safe === '..') {
        return 'Laptop_Duhok_POS_Latest.zip';
    }
    $low = strtolower($safe);
    if (preg_match('/\.json$/i', $safe)) {
        $ext = 'json';
    } elseif (preg_match('/\.posbak$/i', $safe)) {
        $ext = 'posbak';
    } elseif (strpos($low, 'xampp_mysql_data') !== false) {
        $ext = 'zip';
    } else {
        $ext = 'posbak';
    }
    if (strpos($low, 'xampp_mysql_data_db') !== false) {
        return 'XAMPP_MySQL_Data_DB_Latest.zip';
    }
    if (strpos($low, 'xampp_mysql_data') !== false) {
        return 'XAMPP_MySQL_Data_FULL_Latest.zip';
    }
    if (preg_match('/_part1\.(zip|json|posbak)$/i', $safe) || preg_match('/part1/i', $safe)) {
        return 'Laptop_Duhok_POS_Latest_part1.' . $ext;
    }
    if (preg_match('/_part2\.(zip|json|posbak)$/i', $safe) || preg_match('/part2/i', $safe)) {
        return 'Laptop_Duhok_POS_Latest_part2.' . $ext;
    }
    if (preg_match('/^(laptop_duhok_pos_|pos_backup_)/i', $safe)) {
        return 'Laptop_Duhok_POS_Latest.' . $ext;
    }
    return $safe;
}

/** Remove old timestamped ZIPs after switching to *_Latest overwrite mode. */
function pos_prune_timestamped_local_backups() {
    $dir = pos_backup_dir_path();
    if (!is_dir($dir)) return;
    $keep = [
        'Laptop_Duhok_POS_Latest.zip' => true,
        'Laptop_Duhok_POS_Latest.json' => true,
        'Laptop_Duhok_POS_Latest.posbak' => true,
        'Laptop_Duhok_POS_Latest_part1.zip' => true,
        'Laptop_Duhok_POS_Latest_part2.zip' => true,
        'Laptop_Duhok_POS_Latest_part1.posbak' => true,
        'Laptop_Duhok_POS_Latest_part2.posbak' => true,
        'XAMPP_MySQL_Data_FULL_Latest.zip' => true,
        'XAMPP_MySQL_Data_DB_Latest.zip' => true,
    ];
    $patterns = [
        'Laptop_Duhok_POS_*.zip',
        'Laptop_Duhok_POS_*.json',
        'pos_backup_*.zip',
        'pos_backup_*.json',
        'XAMPP_MySQL_Data_*.zip',
    ];
    foreach ($patterns as $pat) {
        foreach (glob($dir . DIRECTORY_SEPARATOR . $pat) ?: [] as $f) {
            if (!is_file($f)) continue;
            $base = basename($f);
            if (isset($keep[$base])) continue;
            if (stripos($base, '_Latest') !== false) continue;
            @unlink($f);
        }
    }
}

function pos_prune_backup_folder($retainDays = 14) {
    $retainDays = max(1, (int)$retainDays);
    $dir = pos_backup_dir_path();
    if (!is_dir($dir)) return;
    // Prefer rolling Latest files — clear dated pile first
    pos_prune_timestamped_local_backups();
    $cutoff = strtotime('-' . $retainDays . ' days');
    $patterns = [
        'Laptop_Duhok_POS_*.zip',
        'Laptop_Duhok_POS_*.json',
        'pos_backup_*.zip',
        'pos_backup_*.json',
        'XAMPP_MySQL_Data_*.zip',
    ];
    foreach ($patterns as $pat) {
        foreach (glob($dir . DIRECTORY_SEPARATOR . $pat) ?: [] as $f) {
            $base = basename($f);
            // Never age-delete the rolling Latest copies
            if (stripos($base, '_Latest') !== false) continue;
            if (@filemtime($f) < $cutoff) {
                @unlink($f);
            }
        }
    }
}

/** Save backup ZIP/JSON inside pos/backups/ (customer shop folder). */
function pos_save_backup_to_folder($outputData, $downloadFileName, $retainDays = 14) {
    $backupDir = pos_backup_dir_path();
    if (!is_dir($backupDir)) {
        @mkdir($backupDir, 0755, true);
    }
    $safe = pos_local_backup_stable_name($downloadFileName);
    $path = rtrim($backupDir, '/\\') . DIRECTORY_SEPARATOR . $safe;
    if (@file_put_contents($path, $outputData) === false) {
        return null;
    }
    pos_prune_backup_folder($retainDays);
    return [
        'name' => $safe,
        'path' => $path,
        'bytes' => strlen($outputData),
        'mtime' => @filemtime($path) ?: time(),
    ];
}

function pos_flash_usb_normalize_device_id($id) {
    $id = trim((string)$id);
    if ($id === '' || strlen($id) > 80) {
        return '';
    }
    if (!preg_match('/^[A-Za-z0-9._-]+$/', $id)) {
        return '';
    }
    return $id;
}

function pos_flash_usb_forbidden_letters() {
    $skip = ['C' => true];
    $app = realpath(__DIR__ . '/..');
    if ($app && preg_match('/^([A-Za-z]):/', $app, $m)) {
        $skip[strtoupper($m[1])] = true;
    }
    return $skip;
}

function pos_flash_usb_allowed_name($name) {
    $safe = basename((string)$name);
    $ok = [
        'Laptop_Duhok_POS_Latest.posbak' => true,
        'Laptop_Duhok_POS_Latest.zip' => true,
        'Laptop_Duhok_POS_Latest.json' => true,
        'Laptop_Duhok_POS_Latest_part1.posbak' => true,
        'Laptop_Duhok_POS_Latest_part2.posbak' => true,
        'XAMPP_MySQL_Data_FULL_Latest.posbak' => true,
        'XAMPP_MySQL_Data_DB_Latest.posbak' => true,
        'Laptop_Duhok_POS_Items_Latest.posbak' => true,
        '.pos_flash_ok' => true,
        '.pos_device_id' => true,
    ];
    return isset($ok[$safe]) ? $safe : 'Laptop_Duhok_POS_Latest.posbak';
}

/** Find Laptop_Duhok_POS_Backups on a plugged USB (Windows). Never C: or the POS disk. */
function pos_flash_usb_find_dir($deviceId = '') {
    $deviceId = pos_flash_usb_normalize_device_id($deviceId);
    $skip = pos_flash_usb_forbidden_letters();
    $hits = [];
    for ($i = ord('D'); $i <= ord('Z'); $i++) {
        $letter = chr($i);
        if (!empty($skip[$letter])) {
            continue;
        }
        $root = $letter . ':\\';
        if (!is_dir($root)) {
            continue;
        }
        $dir = $root . 'Laptop_Duhok_POS_Backups';
        if (!is_dir($dir) || !is_writable($dir)) {
            continue;
        }
        $idFile = $dir . DIRECTORY_SEPARATOR . '.pos_device_id';
        $onStick = is_file($idFile) ? trim((string)@file_get_contents($idFile)) : '';
        $hits[] = [
            'letter' => $letter,
            'dir' => $dir,
            'device_id' => $onStick,
        ];
    }
    if ($deviceId !== '') {
        foreach ($hits as $hit) {
            if (strcasecmp((string)$hit['device_id'], $deviceId) === 0) {
                return $hit;
            }
        }
    }
    if (count($hits) === 1) {
        return $hits[0];
    }
    return null;
}

function pos_flash_usb_ping($deviceId = '') {
    $hit = pos_flash_usb_find_dir($deviceId);
    if (!$hit) {
        return ['ok' => false, 'reason' => 'disconnected'];
    }
    $probe = $hit['dir'] . DIRECTORY_SEPARATOR . '.pos_flash_ok';
    if (@file_put_contents($probe, (string)round(microtime(true) * 1000)) === false) {
        return ['ok' => false, 'reason' => 'write', 'letter' => $hit['letter']];
    }
    return [
        'ok' => true,
        'letter' => $hit['letter'],
        'device_id' => $hit['device_id'],
    ];
}

function pos_flash_usb_copy_bytes($bytes, $fileName, $deviceId = '') {
    $hit = pos_flash_usb_find_dir($deviceId);
    if (!$hit) {
        return ['ok' => false, 'reason' => 'disconnected'];
    }
    $safe = pos_flash_usb_allowed_name($fileName);
    $dest = $hit['dir'] . DIRECTORY_SEPARATOR . $safe;
    $tmp = $dest . '.tmp';
    $len = is_string($bytes) ? strlen($bytes) : 0;
    if ($len < 64 && $safe !== '.pos_flash_ok' && $safe !== '.pos_device_id') {
        return ['ok' => false, 'reason' => 'empty'];
    }
    if (@file_put_contents($tmp, $bytes) === false) {
        return ['ok' => false, 'reason' => 'write', 'letter' => $hit['letter']];
    }
    if (is_file($dest)) {
        @unlink($dest);
    }
    if (!@rename($tmp, $dest)) {
        @unlink($tmp);
        return ['ok' => false, 'reason' => 'write', 'letter' => $hit['letter']];
    }
    return [
        'ok' => true,
        'letter' => $hit['letter'],
        'name' => $safe,
        'bytes' => $len,
        'dir' => $hit['dir'],
    ];
}

function pos_flash_usb_copy_uploaded($tmpPath, $fileName, $deviceId = '') {
    $hit = pos_flash_usb_find_dir($deviceId);
    if (!$hit) {
        return ['ok' => false, 'reason' => 'disconnected'];
    }
    $safe = pos_flash_usb_allowed_name($fileName);
    $dest = $hit['dir'] . DIRECTORY_SEPARATOR . $safe;
    $tmp = $dest . '.tmp';
    if (!is_file($tmpPath) || !@copy($tmpPath, $tmp)) {
        return ['ok' => false, 'reason' => 'write', 'letter' => $hit['letter']];
    }
    $len = (int)@filesize($tmp);
    if (is_file($dest)) {
        @unlink($dest);
    }
    if (!@rename($tmp, $dest)) {
        @unlink($tmp);
        return ['ok' => false, 'reason' => 'write', 'letter' => $hit['letter']];
    }
    return [
        'ok' => true,
        'letter' => $hit['letter'],
        'name' => $safe,
        'bytes' => $len,
        'dir' => $hit['dir'],
    ];
}

function pos_list_local_backups($limit = 20) {
    $dir = pos_backup_dir_path();
    if (!is_dir($dir)) {
        return [];
    }
    $files = [];
    foreach (['Laptop_Duhok_POS_*.zip', 'Laptop_Duhok_POS_*.json', 'pos_backup_*.zip', 'pos_backup_*.json', 'XAMPP_MySQL_Data_*.zip'] as $pat) {
        foreach (glob($dir . DIRECTORY_SEPARATOR . $pat) ?: [] as $f) {
            if (!is_file($f)) continue;
            $files[] = $f;
        }
    }
    $files = array_unique($files);
    usort($files, function ($a, $b) {
        return (@filemtime($b) ?: 0) <=> (@filemtime($a) ?: 0);
    });
    $out = [];
    $limit = max(1, min(50, (int)$limit));
    foreach (array_slice($files, 0, $limit) as $f) {
        $out[] = [
            'name' => basename($f),
            'bytes' => (int)@filesize($f),
            'mtime' => (int)@filemtime($f),
            'mtime_iso' => date('Y-m-d H:i:s', @filemtime($f) ?: time()),
        ];
    }
    return $out;
}

function pos_resolve_local_backup_path($name) {
    $name = basename((string)$name);
    if ($name === '' || !preg_match('/\.(zip|json)$/i', $name)) {
        throw new Exception('ناوی فایلی backup نادروستە.');
    }
    if (!preg_match('/^(Laptop_Duhok_POS_|pos_backup_)/i', $name)) {
        throw new Exception('تەنها backupـێ POS قبوڵ دەکرێت.');
    }
    $path = rtrim(pos_backup_dir_path(), '/\\') . DIRECTORY_SEPARATOR . $name;
    if (!is_file($path) || !is_readable($path)) {
        throw new Exception('فایل لە backups/ نەدۆزرایەوە.');
    }
    $realDir = realpath(pos_backup_dir_path());
    $realFile = realpath($path);
    if (!$realDir || !$realFile || strpos($realFile, $realDir) !== 0) {
        throw new Exception('ڕێگای backup نادروستە.');
    }
    return $realFile;
}

function pos_save_app_settings_array($conn, array $settings) {
    $json = json_encode($settings, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    if ($json === false) {
        throw new Exception('Failed to encode app settings');
    }
    $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('app_settings', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
    $stmt->bind_param('ss', $json, $json);
    $stmt->execute();
}

function pos_regenerate_mobile_backup_pin($conn) {
    $pin = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $settings = function_exists('pos_load_app_settings_array') ? pos_load_app_settings_array($conn) : [];
    $settings['mobileBackupPin'] = $pin;
    pos_save_app_settings_array($conn, $settings);
    return $pin;
}

function pos_get_mobile_backup_pin($conn, $autoCreate = true) {
    $settings = function_exists('pos_load_app_settings_array') ? pos_load_app_settings_array($conn) : [];
    $pin = preg_replace('/\D/', '', (string)($settings['mobileBackupPin'] ?? ''));
    if (strlen($pin) >= 4) {
        return $pin;
    }
    if ($autoCreate) {
        return pos_regenerate_mobile_backup_pin($conn);
    }
    $fallback = preg_replace('/\D/', '', (string)($settings['settingsPin'] ?? ''));
    if (strlen($fallback) >= 4) {
        return $fallback;
    }
    return '';
}

function pos_verify_mobile_backup_pin($conn, $pin) {
    $pin = preg_replace('/\D/', '', (string)$pin);
    if (strlen($pin) < 4) {
        return false;
    }
    $expected = pos_get_mobile_backup_pin($conn, false);
    if ($expected === '' || strlen($expected) < 4) {
        return false;
    }
    return hash_equals($expected, $pin);
}

/** Client IP for mobile backup rate limiting (LAN / reverse proxy aware). */
function pos_mobile_backup_client_ip() {
    foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $key) {
        if (empty($_SERVER[$key])) {
            continue;
        }
        $ip = trim(explode(',', (string)$_SERVER[$key])[0]);
        if (filter_var($ip, FILTER_VALIDATE_IP)) {
            return $ip;
        }
    }
    return '0.0.0.0';
}

function pos_mobile_backup_rate_limit_path($ip) {
    $dir = rtrim(sys_get_temp_dir(), '/\\') . DIRECTORY_SEPARATOR . 'pos_mm_rl';
    if (!is_dir($dir)) {
        @mkdir($dir, 0700, true);
    }
    return $dir . DIRECTORY_SEPARATOR . 'pin_' . md5((string)$ip) . '.json';
}

/** Max failed PIN attempts per IP before temporary lockout. */
function pos_mobile_backup_rate_limit_check($ip) {
    $maxFails = 8;
    $windowSec = 900;
    $lockSec = 900;
    $now = time();
    $path = pos_mobile_backup_rate_limit_path($ip);
    $data = ['fails' => 0, 'first' => $now, 'locked_until' => 0];
    if (is_file($path)) {
        $raw = @file_get_contents($path);
        $decoded = $raw ? json_decode($raw, true) : null;
        if (is_array($decoded)) {
            $data = array_merge($data, $decoded);
        }
    }
    if ((int)($data['locked_until'] ?? 0) > $now) {
        return ['ok' => false, 'retry_after' => (int)$data['locked_until'] - $now];
    }
    if ((int)($data['first'] ?? 0) + $windowSec < $now) {
        $data = ['fails' => 0, 'first' => $now, 'locked_until' => 0];
    }
    if ((int)($data['fails'] ?? 0) >= $maxFails) {
        $data['locked_until'] = $now + $lockSec;
        @file_put_contents($path, json_encode($data), LOCK_EX);
        return ['ok' => false, 'retry_after' => $lockSec];
    }
    return ['ok' => true, 'retry_after' => 0, 'data' => $data, 'path' => $path];
}

function pos_mobile_backup_rate_limit_fail($ip) {
    $check = pos_mobile_backup_rate_limit_check($ip);
    $path = $check['path'] ?? pos_mobile_backup_rate_limit_path($ip);
    $data = $check['data'] ?? ['fails' => 0, 'first' => time(), 'locked_until' => 0];
    $data['fails'] = (int)($data['fails'] ?? 0) + 1;
    @file_put_contents($path, json_encode($data), LOCK_EX);
}

function pos_mobile_backup_rate_limit_success($ip) {
    $path = pos_mobile_backup_rate_limit_path($ip);
    if (is_file($path)) {
        @unlink($path);
    }
}

/** PIN from header (preferred), POST body, or GET (legacy). */
function pos_read_mobile_backup_pin_from_request() {
    if (!empty($_SERVER['HTTP_X_POS_MOBILE_PIN'])) {
        return (string)$_SERVER['HTTP_X_POS_MOBILE_PIN'];
    }
    if (isset($_POST['pin'])) {
        return (string)$_POST['pin'];
    }
    if (isset($_GET['pin'])) {
        return (string)$_GET['pin'];
    }
    return '';
}

/**
 * Verify mobile backup PIN with per-IP rate limit. Exits with JSON on failure.
 */
function pos_mobile_backup_require_pin_or_exit($conn) {
    header('Cache-Control: no-store, no-cache, must-revalidate');
    header('Pragma: no-cache');
    $ip = pos_mobile_backup_client_ip();
    $rl = pos_mobile_backup_rate_limit_check($ip);
    if (!$rl['ok']) {
        http_response_code(429);
        header('Content-Type: application/json; charset=utf-8');
        header('Retry-After: ' . (int)$rl['retry_after']);
        $mins = max(1, (int)ceil(((int)$rl['retry_after']) / 60));
        echo json_encode([
            'status' => 'error',
            'message' => 'زۆر هەوڵی PINـی هەڵە — دووبارە بکەرەوە دوای ' . $mins . ' خولەک',
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $pin = pos_read_mobile_backup_pin_from_request();
    if (!pos_verify_mobile_backup_pin($conn, $pin)) {
        pos_mobile_backup_rate_limit_fail($ip);
        http_response_code(403);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['status' => 'error', 'message' => 'PIN نادروستە'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    pos_mobile_backup_rate_limit_success($ip);
}

function pos_save_backup_to_git_folder($outputData, $downloadFileName) {
    $saved = pos_save_backup_to_folder($outputData, $downloadFileName);
    if (!$saved) return null;
    $workspace = realpath(__DIR__ . '/../');
    if ($workspace && is_dir($workspace . '/.git')) {
        @exec('cd ' . escapeshellarg($workspace) . ' && git add backups/ && git commit -m "Auto backup: ' . date('Y-m-d H:i:s') . '"');
    }
    return $saved;
}

function buildZipBackupPackage($baseDir, $dbPayload, $filenameBase, $includeFiles = true) {
    $jsonFlags = JSON_UNESCAPED_UNICODE;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
        $jsonFlags |= JSON_INVALID_UTF8_SUBSTITUTE;
    }
    $dbJson = json_encode($dbPayload, $jsonFlags);
    if ($dbJson === false) {
        throw new Exception('Failed to encode database payload: ' . json_last_error_msg());
    }

    $fileManifest = [];
    $diskEntries = [];
    if ($includeFiles) {
        foreach (collectFilesystemBackupEntries($baseDir) as $rel => $abs) {
            $zipEntry = 'files/' . str_replace('\\', '/', $rel);
            if (!is_readable($abs) || !is_file($abs)) {
                continue;
            }
            if (strpos($rel, 'backups/') === 0 && filesize($abs) > 5 * 1024 * 1024) {
                continue;
            }
            $diskEntries[] = ['zip' => $zipEntry, 'abs' => $abs];
            $fileManifest[] = [
                'path' => str_replace('\\', '/', $rel),
                'size' => filesize($abs),
                'sha256' => @hash_file('sha256', $abs),
            ];
        }
    }

    $manifest = [
        'format' => 'full_zip_package_v2',
        'created_at' => date('c'),
        'app' => 'Laptop_Duhok_POS',
        'db_version' => 2,
        'table_counts' => $dbPayload['table_counts'] ?? [],
        'database' => [
            'path' => 'database/full_backup.json',
            'sha256' => hash('sha256', $dbJson),
            'bytes' => strlen($dbJson),
        ],
        'files' => $fileManifest,
    ];
    $manifestJson = json_encode($manifest, JSON_UNESCAPED_UNICODE);

    $zipPath = rtrim(sys_get_temp_dir(), '/\\') . DIRECTORY_SEPARATOR
        . preg_replace('/[^a-zA-Z0-9._-]/', '_', (string)$filenameBase)
        . '_' . bin2hex(random_bytes(3)) . '.zip';

    $made = pos_zip_create_archive($zipPath, $diskEntries, [
        'database/full_backup.json' => $dbJson,
        'manifest.json' => $manifestJson,
    ]);
    if (empty($made['ok'])) {
        throw new Exception($made['message'] ?? 'ZIP package failed');
    }

    if (!is_file($zipPath)) {
        throw new Exception('ZIP file was not created');
    }
    $filesize = (int)filesize($zipPath);
    if ($filesize > 500 * 1024 * 1024) {
        @unlink($zipPath);
        throw new Exception('ZIP package is too large (' . round($filesize / 1024 / 1024, 2) . ' MB).');
    }

    $binary = @file_get_contents($zipPath);
    @unlink($zipPath);
    if ($binary === false || strlen($binary) < 64) {
        throw new Exception('Failed to read ZIP package. size=' . $filesize . ' mem=' . ini_get('memory_limit'));
    }
    return [$binary, $manifest];
}

/** Resolve XAMPP root (parent of mysql/ and htdocs/). */
function pos_xampp_root_path() {
    // api/ → pos/ → htdocs/ → xampp/
    $guess = dirname(__DIR__, 3);
    if (is_dir($guess . DIRECTORY_SEPARATOR . 'mysql' . DIRECTORY_SEPARATOR . 'data')) {
        return $guess;
    }
    foreach (['C:\\xampp', 'C:/xampp', 'D:\\xampp', 'D:/xampp'] as $p) {
        if (is_dir($p . DIRECTORY_SEPARATOR . 'mysql' . DIRECTORY_SEPARATOR . 'data')) {
            return $p;
        }
    }
    return null;
}

/** Absolute path to XAMPP mysql/data */
function pos_mysql_data_dir() {
    $root = pos_xampp_root_path();
    if (!$root) return null;
    $dir = $root . DIRECTORY_SEPARATOR . 'mysql' . DIRECTORY_SEPARATOR . 'data';
    return is_dir($dir) ? (realpath($dir) ?: $dir) : null;
}

function pos_mysql_data_zip_should_skip($relativePath) {
    $base = strtolower(basename(str_replace('\\', '/', $relativePath)));
    static $skip = [
        'mysql.pid' => true,
        'ibtmp1' => true,
        '.ds_store' => true,
        'desktop.ini' => true,
        'thumbs.db' => true,
    ];
    return isset($skip[$base]);
}

/**
 * Create a ZIP on disk. Prefer PHP ZipArchive; on Windows fall back to .NET ZipFile
 * when php_zip is disabled (common on some XAMPP installs).
 *
 * @param string $zipPath absolute output path
 * @param array $diskEntries list of ['zip' => 'path/in.zip', 'abs' => 'C:\\file']
 * @param array $stringEntries map zipPath => string contents
 * @return array{ok:bool,via?:string,message?:string}
 */
function pos_zip_create_archive($zipPath, array $diskEntries, array $stringEntries = []) {
    @unlink($zipPath);
    if (class_exists('ZipArchive')) {
        $zip = new ZipArchive();
        $opened = $zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE);
        if ($opened === true) {
            foreach ($stringEntries as $zp => $body) {
                $zip->addFromString((string)$zp, (string)$body);
            }
            foreach ($diskEntries as $row) {
                $zp = (string)($row['zip'] ?? '');
                $abs = (string)($row['abs'] ?? '');
                if ($zp === '' || $abs === '' || !is_file($abs)) continue;
                if (!$zip->addFile($abs, $zp)) {
                    $bin = @file_get_contents($abs);
                    if ($bin !== false) $zip->addFromString($zp, $bin);
                }
            }
            $zip->close();
            if (is_file($zipPath) && filesize($zipPath) >= 32) {
                return ['ok' => true, 'via' => 'ZipArchive'];
            }
            @unlink($zipPath);
        }
    }

    $isWin = strtoupper(substr(PHP_OS, 0, 3)) === 'WIN';
    if (!$isWin) {
        return ['ok' => false, 'message' => 'ZipArchive لە PHP چالاک نییە — لە php.ini: extension=zip پاشان Apache Restart'];
    }

    $stage = rtrim(sys_get_temp_dir(), '/\\') . DIRECTORY_SEPARATOR . 'pos_zip_stage_' . bin2hex(random_bytes(4));
    if (!@mkdir($stage, 0755, true) && !is_dir($stage)) {
        return ['ok' => false, 'message' => 'نەتوانرا فۆڵدەری کاتی ZIP دروست بکرێت'];
    }
    try {
        foreach ($stringEntries as $zp => $body) {
            $rel = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, (string)$zp);
            $dest = $stage . DIRECTORY_SEPARATOR . $rel;
            $parent = dirname($dest);
            if (!is_dir($parent) && !@mkdir($parent, 0755, true) && !is_dir($parent)) {
                throw new Exception('stage mkdir failed');
            }
            if (@file_put_contents($dest, (string)$body) === false) {
                throw new Exception('stage write failed');
            }
        }
        foreach ($diskEntries as $row) {
            $zp = (string)($row['zip'] ?? '');
            $abs = (string)($row['abs'] ?? '');
            if ($zp === '' || $abs === '' || !is_file($abs) || !is_readable($abs)) continue;
            $rel = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $zp);
            $dest = $stage . DIRECTORY_SEPARATOR . $rel;
            $parent = dirname($dest);
            if (!is_dir($parent) && !@mkdir($parent, 0755, true) && !is_dir($parent)) continue;
            if (!@copy($abs, $dest)) {
                $bin = @file_get_contents($abs);
                if ($bin === false || @file_put_contents($dest, $bin) === false) continue;
            }
        }

        $ps = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe';
        $tar = 'C:\\Windows\\System32\\tar.exe';
        $ok = false;
        $via = '';
        if (is_file($tar)) {
            $cmd = escapeshellarg($tar) . ' -a -cf ' . escapeshellarg($zipPath) . ' -C ' . escapeshellarg($stage) . ' .';
            $out = [];
            $code = 1;
            @exec($cmd . ' 2>&1', $out, $code);
            if ($code === 0 && is_file($zipPath) && filesize($zipPath) >= 32) {
                $ok = true;
                $via = 'tar';
            }
        }
        if (!$ok && is_file($ps)) {
            @unlink($zipPath);
            $z = str_replace("'", "''", $zipPath);
            $s = str_replace("'", "''", $stage);
            $script = "Compress-Archive -Path (Join-Path '" . $s . "' '*') -DestinationPath '" . $z . "' -Force";
            $cmd = escapeshellarg($ps) . ' -NoProfile -NonInteractive -Command ' . escapeshellarg($script);
            $out = [];
            $code = 1;
            @exec($cmd . ' 2>&1', $out, $code);
            if ($code === 0 && is_file($zipPath) && filesize($zipPath) >= 32) {
                $ok = true;
                $via = 'powershell';
            }
        }
        if (!$ok) {
            return [
                'ok' => false,
                'message' => 'ZipArchive لە PHP چالاک نییە و tar/PowerShellش سەرکەوتوو نەبوو. لە php.ini: extension=zip پاشان Apache Restart',
            ];
        }
        return ['ok' => true, 'via' => $via];
    } catch (\Throwable $e) {
        return ['ok' => false, 'message' => $e->getMessage()];
    } finally {
        try {
            $it = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($stage, FilesystemIterator::SKIP_DOTS),
                RecursiveIteratorIterator::CHILD_FIRST
            );
            foreach ($it as $f) {
                /** @var SplFileInfo $f */
                $p = $f->getPathname();
                if ($f->isDir()) @rmdir($p);
                else @unlink($p);
            }
            @rmdir($stage);
        } catch (\Throwable $eClean) {}
    }
}

/**
 * Build ZIP of XAMPP mysql/data (full) or only POS database folder.
 * Returns absolute path to temp ZIP (caller must unlink).
 * Zip root: mysql_data/...
 */
function pos_build_mysql_data_zip($scope = 'full', $conn = null) {
    $dataDir = pos_mysql_data_dir();
    if (!$dataDir || !is_dir($dataDir)) {
        throw new Exception('فۆڵدەری XAMPP mysql/data نەدۆزرایەوە.');
    }
    global $dbname;
    $dbFolder = is_string($dbname) && $dbname !== '' ? $dbname : 'laptop_duhok_pos';
    $scope = ($scope === 'db' || $scope === 'db_only') ? 'db' : 'full';
    $sourceRoot = $dataDir;
    if ($scope === 'db') {
        $sourceRoot = $dataDir . DIRECTORY_SEPARATOR . $dbFolder;
        if (!is_dir($sourceRoot)) {
            throw new Exception('فۆڵدەری داتابەیس نەدۆزرایەوە: ' . $dbFolder);
        }
    }

    // Best-effort consistency while MySQL is running
    $locked = false;
    if ($conn instanceof mysqli) {
        try {
            if (@$conn->query('FLUSH TABLES WITH READ LOCK')) {
                $locked = true;
            }
        } catch (\Throwable $eLock) {
            $locked = false;
        }
    }

    $tmpZip = rtrim(sys_get_temp_dir(), '/\\') . DIRECTORY_SEPARATOR . 'pos_mysql_data_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.zip';
    $meta = [
        'format' => 'xampp_mysql_data_v1',
        'scope' => $scope,
        'db_name' => $dbFolder,
        'source' => $dataDir,
        'created_at' => date('c'),
        'note' => 'Restore only into the same XAMPP mysql/data after stopping MySQL.',
    ];
    $stringEntries = [
        'mysql_data_manifest.json' => json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
    ];
    $diskEntries = [];
    $fileCount = 0;
    $byteCount = 0;
    $created = ['ok' => false];

    try {
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($sourceRoot, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($iterator as $item) {
            /** @var SplFileInfo $item */
            $full = $item->getPathname();
            $relFromSource = substr($full, strlen($sourceRoot) + 1);
            if ($relFromSource === false || $relFromSource === '') {
                continue;
            }
            $relFromSource = str_replace('\\', '/', $relFromSource);
            if (pos_mysql_data_zip_should_skip($relFromSource)) {
                continue;
            }
            if ($item->isDir()) {
                continue;
            }
            if (!$item->isFile() || !is_readable($full)) {
                continue;
            }
            if ($scope === 'full') {
                $zipPath = 'mysql_data/' . $relFromSource;
            } else {
                $zipPath = 'mysql_data/' . $dbFolder . '/' . $relFromSource;
            }
            $diskEntries[] = ['zip' => $zipPath, 'abs' => $full];
            $byteCount += (int)$item->getSize();
            $fileCount++;
        }

        $created = pos_zip_create_archive($tmpZip, $diskEntries, $stringEntries);
        if (empty($created['ok'])) {
            throw new Exception($created['message'] ?? 'نەتوانرا ZIP ی mysql/data دروست بکرێت.');
        }
    } finally {
        if ($locked && $conn instanceof mysqli) {
            @$conn->query('UNLOCK TABLES');
        }
    }

    if (!is_file($tmpZip) || filesize($tmpZip) < 64) {
        @unlink($tmpZip);
        throw new Exception('ZIP ی mysql/data بەتاڵە یان دروست نەبوو.');
    }

    return [
        'path' => $tmpZip,
        'bytes' => (int)filesize($tmpZip),
        'files' => $fileCount,
        'payload_bytes' => $byteCount,
        'scope' => $scope,
        'data_dir' => $dataDir,
        'db_name' => $dbFolder,
        'via' => $created['via'] ?? '',
    ];
}

/**
 * Restore XAMPP mysql/data from a xampp_mysql_data_v1 ZIP.
 * Requires MySQL stopped for a clean restore (files not locked).
 */
function pos_restore_mysql_data_from_zip($zipPath, array $options = []) {
    $dataDir = pos_mysql_data_dir();
    if (!$dataDir || !is_dir($dataDir)) {
        throw new Exception('فۆڵدەری XAMPP mysql/data نەدۆزرایەوە.');
    }
    if (!class_exists('ZipArchive')) {
        // Try extract via Windows tools into temp, then copy — keep simple error for now
        throw new Exception('ZipArchive نییە — لە php.ini پێوەکراوی zip چالاک بکە (Apache Restart).');
    }
    $pidFile = $dataDir . DIRECTORY_SEPARATOR . 'mysql.pid';
    if (is_file($pidFile) && empty($options['force'])) {
        throw new Exception(
            'MySQL هێشتا کاردەکات (mysql.pid هەیە). لە XAMPP Control Panel → Stop MySQL، پاشان دووبارە هەوڵ بدە. '
            . 'یان force=1 ئەگەر دڵنیایت وەستاوە.'
        );
    }

    $zip = new ZipArchive();
    if ($zip->open($zipPath) !== true) {
        throw new Exception('نەتوانرا فایلی ZIP بکرێتەوە.');
    }

    $manifestRaw = $zip->getFromName('mysql_data_manifest.json');
    $manifest = $manifestRaw ? json_decode($manifestRaw, true) : null;
    if (!is_array($manifest) || ($manifest['format'] ?? '') !== 'xampp_mysql_data_v1') {
        // Accept zips that still have mysql_data/ prefix without manifest
        $hasPrefix = false;
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $n = str_replace('\\', '/', (string)$zip->getNameIndex($i));
            if (strpos($n, 'mysql_data/') === 0) {
                $hasPrefix = true;
                break;
            }
        }
        if (!$hasPrefix) {
            $zip->close();
            throw new Exception('ئەم ZIPـە بک‌ئەپی mysql/data نییە (mysql_data_v1).');
        }
    }

    $staging = rtrim(sys_get_temp_dir(), '/\\') . DIRECTORY_SEPARATOR . 'pos_mysql_restore_' . bin2hex(random_bytes(4));
    if (!@mkdir($staging, 0755, true) && !is_dir($staging)) {
        $zip->close();
        throw new Exception('نەتوانرا فۆڵدەری کاتی دروست بکرێت.');
    }

    $extracted = 0;
    try {
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = str_replace('\\', '/', (string)$zip->getNameIndex($i));
            if ($name === '' || substr($name, -1) === '/') {
                continue;
            }
            if ($name === 'mysql_data_manifest.json') {
                continue;
            }
            if (strpos($name, 'mysql_data/') !== 0) {
                continue;
            }
            $rel = substr($name, strlen('mysql_data/'));
            if ($rel === '' || strpos($rel, '..') !== false) {
                continue;
            }
            if (pos_mysql_data_zip_should_skip($rel)) {
                continue;
            }
            $dest = $dataDir . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $rel);
            $destDir = dirname($dest);
            if (!is_dir($destDir) && !@mkdir($destDir, 0755, true) && !is_dir($destDir)) {
                throw new Exception('نەتوانرا فۆڵدەر دروست بکرێت: ' . $rel);
            }
            $content = $zip->getFromIndex($i);
            if ($content === false) {
                throw new Exception('نەتوانرا فایل بخوێنرێتەوە: ' . $rel);
            }
            // Write via staging then rename for slightly safer replace
            $tmpOut = $staging . DIRECTORY_SEPARATOR . str_replace(['/', '\\'], '_', $rel);
            if (@file_put_contents($tmpOut, $content) === false) {
                throw new Exception('نووسین سەرنەکەوت (staging): ' . $rel);
            }
            if (!@rename($tmpOut, $dest)) {
                if (@copy($tmpOut, $dest) === false) {
                    @unlink($tmpOut);
                    throw new Exception(
                        'نووسین بۆ mysql/data سەرنەکەوت: ' . $rel
                        . ' — MySQL بوەستێنە لە XAMPP و دووبارە هەوڵ بدە.'
                    );
                }
                @unlink($tmpOut);
            }
            $extracted++;
        }
    } finally {
        $zip->close();
        // cleanup staging
        foreach (glob($staging . DIRECTORY_SEPARATOR . '*') ?: [] as $f) {
            @unlink($f);
        }
        @rmdir($staging);
    }

    if ($extracted < 1) {
        throw new Exception('هیچ فایلێک لە ZIP وەرنەگیرا.');
    }

    return [
        'extracted' => $extracted,
        'data_dir' => $dataDir,
        'scope' => is_array($manifest) ? ($manifest['scope'] ?? 'full') : 'full',
    ];
}

/**
 * Incremental flash backup: only rows newer than watermarks (id cursors).
 * Keeps POS fast — no full dump / no mysql/data zip on every sale.
 */
function pos_flash_delta_id_tables() {
    return [
        'sales',
        'returns',
        'ledger',
        'customer_ledger',
        'expenses',
        'supplies',
        'stock_movements',
        'purchase_returns',
        'shifts',
        'waste',
        'deliveries',
        'stock_transfers',
        'stock_transfer_lines',
        'audit_logs',
    ];
}

function pos_flash_table_exists($conn, $table) {
    if (!($conn instanceof mysqli) || $table === '') return false;
    $safe = $conn->real_escape_string($table);
    $res = @$conn->query("SHOW TABLES LIKE '{$safe}'");
    return $res && $res->num_rows > 0;
}

function pos_flash_table_has_id($conn, $table) {
    if (!pos_flash_table_exists($conn, $table)) return false;
    $safe = $conn->real_escape_string($table);
    $res = @$conn->query("SHOW COLUMNS FROM `{$safe}` LIKE 'id'");
    return $res && $res->num_rows > 0;
}

function pos_flash_delta_current_watermarks($conn) {
    $wm = [];
    foreach (pos_flash_delta_id_tables() as $table) {
        if (!pos_flash_table_has_id($conn, $table)) continue;
        $safe = $conn->real_escape_string($table);
        $max = 0;
        $res = @$conn->query("SELECT MAX(`id`) AS m FROM `{$safe}`");
        if ($res && ($row = $res->fetch_assoc())) {
            $max = (int)($row['m'] ?? 0);
        }
        $wm[$table] = $max;
    }
    $wm['_ready'] = 1;
    $wm['_at'] = date('c');
    return $wm;
}

function pos_flash_fetch_rows_after_id($conn, $table, $sinceId, $limit = 3000) {
    $rows = [];
    if (!pos_flash_table_has_id($conn, $table)) return $rows;
    $sinceId = max(0, (int)$sinceId);
    $limit = max(1, min(8000, (int)$limit));
    $safe = $conn->real_escape_string($table);
    $stmt = $conn->prepare("SELECT * FROM `{$safe}` WHERE `id` > ? ORDER BY `id` ASC LIMIT ?");
    if (!$stmt) return $rows;
    $stmt->bind_param('ii', $sinceId, $limit);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $rows[] = $row;
        }
    }
    $stmt->close();
    return $rows;
}

function pos_flash_collect_ids_from_items_json($itemsJson, array &$productIds) {
    if (!is_string($itemsJson) || $itemsJson === '') return;
    $items = json_decode($itemsJson, true);
    if (!is_array($items)) return;
    foreach ($items as $it) {
        if (!is_array($it)) continue;
        $pid = (int)($it['id'] ?? $it['product_id'] ?? 0);
        if ($pid > 0) $productIds[$pid] = true;
    }
}

function pos_flash_fetch_rows_by_ids($conn, $table, array $ids, $idCol = 'id') {
    $rows = [];
    $ids = array_values(array_unique(array_filter(array_map('intval', $ids), function ($n) { return $n > 0; })));
    if (!$ids || !pos_flash_table_exists($conn, $table)) return $rows;
    $safe = $conn->real_escape_string($table);
    $col = preg_replace('/[^a-zA-Z0-9_]/', '', $idCol);
    if ($col === '') $col = 'id';
    $chunks = array_chunk($ids, 400);
    foreach ($chunks as $chunk) {
        $in = implode(',', $chunk);
        $res = @$conn->query("SELECT * FROM `{$safe}` WHERE `{$col}` IN ({$in})");
        if ($res) {
            while ($row = $res->fetch_assoc()) {
                $rows[] = $row;
            }
        }
    }
    return $rows;
}

function pos_flash_fetch_warehouse_stock_for_products($conn, array $productIds) {
    $rows = [];
    $productIds = array_values(array_unique(array_filter(array_map('intval', $productIds), function ($n) { return $n > 0; })));
    if (!$productIds || !pos_flash_table_exists($conn, 'warehouse_stock')) return $rows;
    $chunks = array_chunk($productIds, 400);
    foreach ($chunks as $chunk) {
        $in = implode(',', $chunk);
        $res = @$conn->query("SELECT * FROM `warehouse_stock` WHERE `product_id` IN ({$in})");
        if ($res) {
            while ($row = $res->fetch_assoc()) {
                $rows[] = $row;
            }
        }
    }
    return $rows;
}

/**
 * @param array<string,mixed> $since Watermark map (table => last id)
 * @return array<string,mixed>
 */
function pos_build_flash_delta_payload($conn, array $since, array $options = []) {
    $initOnly = !empty($options['init']);
    if ($initOnly) {
        return [
            '_format' => 'flash_delta_v1',
            '_backup_at' => date('Y-m-d H:i:s'),
            '_init' => true,
            'table_data' => new stdClass(),
            'table_counts' => new stdClass(),
            'watermarks' => pos_flash_delta_current_watermarks($conn),
            'row_total' => 0,
        ];
    }

    $tableData = [];
    $tableCounts = [];
    $watermarks = $since;
    $productIds = [];
    $customerIds = [];
    $userIds = [];
    $rowTotal = 0;

    foreach (pos_flash_delta_id_tables() as $table) {
        if (!pos_flash_table_has_id($conn, $table)) continue;
        $from = (int)($since[$table] ?? 0);
        $rows = pos_flash_fetch_rows_after_id($conn, $table, $from);
        $tableData[$table] = $rows;
        $tableCounts[$table] = count($rows);
        $rowTotal += count($rows);
        $maxId = $from;
        foreach ($rows as $r) {
            $rid = (int)($r['id'] ?? 0);
            if ($rid > $maxId) $maxId = $rid;
            if ($table === 'sales' || $table === 'returns') {
                pos_flash_collect_ids_from_items_json($r['items_json'] ?? '', $productIds);
                $cid = (int)($r['customer_id'] ?? $r['target_id'] ?? 0);
                $ctype = strtolower((string)($r['customer_type'] ?? $r['target_type'] ?? 'customer'));
                if ($cid > 0) {
                    if ($ctype === 'user') $userIds[$cid] = true;
                    else $customerIds[$cid] = true;
                }
            }
            if ($table === 'customer_ledger') {
                $tid = (int)($r['target_id'] ?? 0);
                $tt = strtolower((string)($r['target_type'] ?? 'customer'));
                if ($tid > 0) {
                    if ($tt === 'user') $userIds[$tid] = true;
                    else $customerIds[$tid] = true;
                }
            }
            if ($table === 'stock_movements' || $table === 'stock_transfer_lines') {
                $pid = (int)($r['product_id'] ?? 0);
                if ($pid > 0) $productIds[$pid] = true;
            }
            if ($table === 'supplies') {
                // supplies items may be in items_json
                pos_flash_collect_ids_from_items_json($r['items_json'] ?? ($r['items'] ?? ''), $productIds);
            }
        }
        $watermarks[$table] = $maxId;
    }

    if ($productIds) {
        $pids = array_keys($productIds);
        $prods = pos_flash_fetch_rows_by_ids($conn, 'products', $pids, 'id');
        if ($prods) {
            $tableData['products'] = $prods;
            $tableCounts['products'] = count($prods);
            $rowTotal += count($prods);
        }
        $ws = pos_flash_fetch_warehouse_stock_for_products($conn, $pids);
        if ($ws) {
            $tableData['warehouse_stock'] = $ws;
            $tableCounts['warehouse_stock'] = count($ws);
            $rowTotal += count($ws);
        }
        if (pos_flash_table_exists($conn, 'stock_batches')) {
            $batches = [];
            $chunks = array_chunk($pids, 400);
            foreach ($chunks as $chunk) {
                $in = implode(',', $chunk);
                $res = @$conn->query("SELECT * FROM `stock_batches` WHERE `product_id` IN ({$in})");
                if ($res) {
                    while ($row = $res->fetch_assoc()) {
                        $batches[] = $row;
                    }
                }
            }
            if ($batches) {
                $tableData['stock_batches'] = $batches;
                $tableCounts['stock_batches'] = count($batches);
                $rowTotal += count($batches);
            }
        }
    }

    if ($customerIds) {
        $custs = pos_flash_fetch_rows_by_ids($conn, 'customers', array_keys($customerIds), 'id');
        if ($custs) {
            $tableData['customers'] = $custs;
            $tableCounts['customers'] = count($custs);
            $rowTotal += count($custs);
        }
    }
    if ($userIds) {
        $users = pos_flash_fetch_rows_by_ids($conn, 'users', array_keys($userIds), 'id');
        if ($users) {
            $tableData['users'] = $users;
            $tableCounts['users'] = count($users);
            $rowTotal += count($users);
        }
    }

    $watermarks['_ready'] = 1;
    $watermarks['_at'] = date('c');

    return [
        '_format' => 'flash_delta_v1',
        '_backup_at' => date('Y-m-d H:i:s'),
        'table_data' => $tableData,
        'table_counts' => $tableCounts,
        'watermarks' => $watermarks,
        'row_total' => $rowTotal,
        '_from' => $since,
    ];
}

