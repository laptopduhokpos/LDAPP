// POS reports - daily modal, sales & general history
        // --- DAILY HISTORY MODAL (NEW) ---
        function dailyDetailCacheKey(dateFrom, dateTo, selectedUser) {
            return String(dateFrom || '') + '_' + String(dateTo || dateFrom || '') + '_' + String(selectedUser || 'all');
        }

        function normalizeDailySummaryRange(dateFrom, dateTo) {
            var from = String(dateFrom || '').trim();
            var to = String(dateTo || '').trim();
            if (!/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to)) {
                return null;
            }
            if (from > to) {
                var tmp = from;
                from = to;
                to = tmp;
            }
            var a = from.split('-').map(Number);
            var b = to.split('-').map(Number);
            var ms = Date.UTC(b[0], b[1] - 1, b[2]) - Date.UTC(a[0], a[1] - 1, a[2]);
            var days = Math.round(ms / 86400000);
            if (days > 30) {
                return { error: 'range_too_long', from: from, to: to, days: days + 1 };
            }
            return { from: from, to: to, days: days + 1 };
        }

        function fetchDailyDetailForModal(dateFrom, uid, opts) {
            opts = opts || {};
            var selectedUser = opts.user || 'all';
            var dateTo = opts.dateTo || opts.date_to || dateFrom;
            window._dailyDetailCache = window._dailyDetailCache || {};
            window._dailyDetailPending = window._dailyDetailPending || {};
            var force = !!opts.force;
            var reqKey = dailyDetailCacheKey(dateFrom, dateTo, selectedUser) + (opts.lite === false ? '_full' : '_lite');
            if (!force && window._dailyDetailPending[reqKey]) {
                return window._dailyDetailPending[reqKey];
            }
            var epochAtStart = window._dailyDetailEpoch || 0;
            var qs = 'action=get_daily_detail&lite=1&date_from=' + encodeURIComponent(dateFrom)
                + '&date_to=' + encodeURIComponent(dateTo)
                + '&user=' + encodeURIComponent(selectedUser)
                + '&_=' + Date.now();
            if (dateFrom === dateTo) {
                qs += '&date=' + encodeURIComponent(dateFrom);
            }
            var url = (typeof window.posRouterUrl === 'function') ? window.posRouterUrl(qs) : ('?' + qs);
            var ctrl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
            var toId = setTimeout(function () {
                if (ctrl) try { ctrl.abort(); } catch (_eAb) {}
            }, 25000);
            var fetchOpts = { credentials: 'same-origin', cache: 'no-store' };
            if (ctrl) fetchOpts.signal = ctrl.signal;
            var p = fetch(url, fetchOpts)
                .then(function(r) {
                    return r.json().catch(function() {
                        return { status: 'error' };
                    });
                })
                .then(function(dd) {
                    clearTimeout(toId);
                    // Still accept ok payloads after epoch bump — modal needs server cards
                    if (dd && dd.status === 'ok' && dd.pools) {
                        var cacheKey = dailyDetailCacheKey(dateFrom, dateTo, selectedUser);
                        window._dailyDetailCache[cacheKey] = { ts: Date.now(), data: dd, userId: uid, epoch: (window._dailyDetailEpoch || 0), reqUser: selectedUser, dateFrom: dateFrom, dateTo: dateTo };
                        return dd;
                    }
                    if ((window._dailyDetailEpoch || 0) !== epochAtStart) {
                        return { status: 'stale' };
                    }
                    return dd;
                })
                .catch(function() {
                    clearTimeout(toId);
                    return { status: 'error', message: 'timeout_or_network' };
                })
                .finally(function() {
                    clearTimeout(toId);
                    if (window._dailyDetailPending[reqKey] === p) {
                        delete window._dailyDetailPending[reqKey];
                    }
                });
            window._dailyDetailPending[reqKey] = p;
            return p;
        }
        window.fetchDailyDetailForModal = fetchDailyDetailForModal;

        function dailySummaryRowOnDate(raw, dateFrom, dateTo) {
            var s = String(raw || '');
            if (s.length >= 10) {
                var iso = s.slice(0, 10);
                if (iso >= dateFrom && iso <= dateTo) return true;
            }
            try {
                if (typeof getBusinessDate === 'function' && typeof parseSQLDate === 'function') {
                    var d = getBusinessDate(parseSQLDate(raw));
                    if (d && d >= dateFrom && d <= dateTo) return true;
                }
            } catch (_e) {}
            return false;
        }

        function dailySummarySplitSale(s) {
            var total = parseFloat(s && s.total) || 0;
            var pm = String((s && s.payment_method) || '').toLowerCase();
            var debt = Math.max(0, parseFloat(s && s.debt_amount) || 0);
            var bank = Math.max(0, parseFloat(s && (s.bank_amount != null ? s.bank_amount : s.paid_bank)) || 0);
            if (pm === 'debt') return { cash: 0, debt: total, fib: 0 };
            if (pm === 'fib' || pm === 'bank' || pm === 'bankcard' || pm === 'card') return { cash: 0, debt: 0, fib: total };
            var cash = 0;
            if (s && s.paid_cash != null && s.paid_cash !== '' && isFinite(parseFloat(s.paid_cash))) {
                var pc = Math.max(0, parseFloat(s.paid_cash) || 0);
                if (pc > 0) cash = pc;
                else if (pm === 'split' || debt > 0 || bank > 0) cash = 0;
                else cash = Math.max(0, total - debt - bank);
            } else if (s && s.paid_amount != null && s.paid_amount !== '' && isFinite(parseFloat(s.paid_amount))) {
                var pa = Math.max(0, parseFloat(s.paid_amount) || 0);
                if (pa > 0) cash = Math.max(0, pa - bank);
                else if (pm === 'split' || debt > 0 || bank > 0) cash = 0;
                else cash = Math.max(0, total - debt - bank);
            } else {
                cash = Math.max(0, total - debt - bank);
            }
            return { cash: cash, debt: debt, fib: bank };
        }

        function dailySummaryLineItems(row) {
            if (!row) return [];
            var raw = row.items;
            if (raw == null || raw === '') raw = row.items_json;
            if (typeof raw === 'string') {
                try { raw = JSON.parse(raw); } catch (_e) { return []; }
            }
            if (Array.isArray(raw)) return raw;
            if (raw && typeof raw === 'object') return Object.keys(raw).map(function(k) { return raw[k]; });
            return [];
        }

        function dailySummaryLineCogs(row) {
            var sum = 0;
            dailySummaryLineItems(row).forEach(function(it) {
                if (!it) return;
                var q = parseFloat(it.qty != null ? it.qty : it.count);
                if (!(q > 0)) q = 1;
                var c = (typeof saleLineHasExplicitCost === 'function' && saleLineHasExplicitCost(it))
                    ? Number(it.cost)
                    : (parseFloat(it.cost) || 0);
                if (!Number.isFinite(c) || c < 0) c = 0;
                sum += c * q;
            });
            return sum;
        }

        /** IQD daily cards from window.db — does not use getFinancialMetrics. */
        function paintDailySummaryFromLocalDb(dateFrom, dateTo, todayPretty, selectedUser) {
            if (typeof finalizeDailyModalContent !== 'function') return false;
            var _db = (typeof window !== 'undefined' && window.db) ? window.db : null;
            if (!_db) return false;
            try {
                var src = _db.sales || [];
                var sales = [];
                var i;
                for (i = 0; i < src.length; i++) {
                    var s = src[i];
                    if (!s) continue;
                    if (s.is_returned == 1 || s.is_returned === true || s.is_returned === '1') continue;
                    if (!dailySummaryRowOnDate(s.date || s.created_at, dateFrom, dateTo)) continue;
                    sales.push(s);
                }
                var filterUser = selectedUser && selectedUser !== 'all' ? selectedUser : null;
                var cu = (typeof window !== 'undefined') ? window.currentUser : null;
                if (cu && cu.role !== 'admin' && cu.role !== 'manager') filterUser = cu.name;
                if (filterUser) {
                    sales = sales.filter(function(row) { return row.cashier === filterUser; });
                }
                var totalSales = 0, cashSales = 0, debtSales = 0, fibSales = 0, cogs = 0;
                var lastId = '';
                sales.forEach(function(row) {
                    totalSales += parseFloat(row.total) || 0;
                    var sp = dailySummarySplitSale(row);
                    cashSales += sp.cash;
                    debtSales += sp.debt;
                    fibSales += sp.fib;
                    cogs += dailySummaryLineCogs(row);
                    if (row.id != null && String(row.id) > String(lastId)) lastId = String(row.id);
                });
                var returns = (_db.returns || []).filter(function(r) {
                    return dailySummaryRowOnDate(r.date, dateFrom, dateTo);
                });
                if (filterUser) returns = returns.filter(function(r) { return r.cashier === filterUser; });
                var retTotal = 0, retCogs = 0, cashRefunds = 0;
                returns.forEach(function(r) {
                    var tot = parseFloat(r.total) || 0;
                    retTotal += tot;
                    var pm = String(r.payment_method || '').toLowerCase();
                    if (pm !== 'debt' && pm !== 'fib' && pm !== 'bank' && pm !== 'bankcard' && pm !== 'card') cashRefunds += tot;
                    retCogs += dailySummaryLineCogs(r);
                });
                var cl = (_db.customer_ledger || []).filter(function(x) {
                    if (!x) return false;
                    var ty = String(x.type || '').toLowerCase();
                    return (ty === 'payment' || ty === 'pay') && dailySummaryRowOnDate(x.date || x.created_at, dateFrom, dateTo);
                });
                var debtIn = 0;
                cl.forEach(function(x) { debtIn += parseFloat(x.amount) || 0; });
                var expenses = (_db.expenses || []).filter(function(e) {
                    return dailySummaryRowOnDate(e.date, dateFrom, dateTo);
                });
                var opExp = 0, cashPurch = 0, companyDebt = 0;
                expenses.forEach(function(e) {
                    var ty = e.type;
                    var amt = (typeof expenseAmountIqd === 'function') ? expenseAmountIqd(e) : (parseFloat(e.amount) || 0);
                    if (ty === 'purchase') cashPurch += amt;
                    else if (ty === 'debt_payment') companyDebt += amt;
                    else if (!ty || ty === 'operational') opExp += amt;
                });
                var shifts = (_db.shifts || []).filter(function(sh) {
                    return dailySummaryRowOnDate(sh.startTime || sh.start_time, dateFrom, dateFrom);
                });
                var ts = _db.today_stats || {};
                var isToday = false;
                try {
                    var todayIso = (typeof getBusinessDate === 'function') ? getBusinessDate(new Date()) : dateFrom;
                    isToday = (dateFrom === dateTo && (dateFrom === todayIso || dateFrom === String(new Date().getFullYear() + '-' + String(new Date().getMonth() + 1).padStart(2, '0') + '-' + String(new Date().getDate()).padStart(2, '0'))));
                } catch (_eT) {}
                if (!sales.length && isToday && (parseFloat(ts.sales) || 0) > 0) {
                    totalSales = parseFloat(ts.sales) || 0;
                    cashSales = parseFloat(ts.cash_sales) || 0;
                    debtSales = parseFloat(ts.debt_sales) || 0;
                    fibSales = parseFloat(ts.fib_sales) || 0;
                    retTotal = parseFloat(ts.returns) || retTotal;
                    cashRefunds = parseFloat(ts.cash_refunds) || cashRefunds;
                    debtIn = parseFloat(ts.debt_payments_in) || debtIn;
                    cogs = parseFloat(ts.total_cogs) || cogs;
                    opExp = parseFloat(ts.expenses) || opExp;
                    cashPurch = parseFloat(ts.purchases_cash) || cashPurch;
                    if (ts.last_receipt_id) lastId = String(ts.last_receipt_id);
                } else if (isToday) {
                    if (!(cashSales > 0) && (parseFloat(ts.cash_sales) || 0) > 0) cashSales = parseFloat(ts.cash_sales) || 0;
                    if (!(debtSales > 0) && (parseFloat(ts.debt_sales) || 0) > 0) debtSales = parseFloat(ts.debt_sales) || 0;
                    if (!(debtIn > 0) && (parseFloat(ts.debt_payments_in) || 0) > 0) debtIn = parseFloat(ts.debt_payments_in) || 0;
                    if (!lastId && ts.last_receipt_id) lastId = String(ts.last_receipt_id);
                }
                var netProfit = (totalSales - retTotal) - (cogs - retCogs) - opExp;
                if (isToday && !(cogs > 0) && ts.net_profit != null && ts.net_profit !== '') {
                    netProfit = parseFloat(ts.net_profit) || netProfit;
                }
                var cashMovement = (cashSales + debtIn) - (opExp + cashPurch + companyDebt + cashRefunds);
                if (isToday && !(cashSales > 0) && ts.cash_movement != null) {
                    cashMovement = parseFloat(ts.cash_movement) || cashMovement;
                }
                if (!(totalSales > 0) && !(sales.length) && !(isToday && (parseFloat(ts.sales) || 0))) {
                    return false;
                }
                return !!finalizeDailyModalContent(dateFrom, todayPretty, {
                    metricsScoped: {
                        totalSales: totalSales,
                        cashSales: cashSales,
                        debtSales: debtSales,
                        fibSales: fibSales,
                        totalReturns: retTotal,
                        cashRefunds: cashRefunds,
                        opExpenses: opExp,
                        cashPurchases: cashPurch,
                        companyDebtPayments: companyDebt,
                        debtPaymentsIn: debtIn,
                        purchaseReturnsIn: 0,
                        totalPurchaseReturns: 0,
                        totalGiftsValue: 0,
                        giftsCount: 0,
                        wasteLoss: 0,
                        wasteCount: 0,
                        cashMovement: cashMovement,
                        netProfit: netProfit,
                        grossProfit: (totalSales - retTotal) - (cogs - retCogs),
                        totalCogs: cogs
                    },
                    daySalesScoped: sales,
                    dayExpensesList: expenses,
                    dayReturnsList: returns,
                    dayVoidedPurchasesList: [],
                    dayPurchaseReturnsList: [],
                    dayPurchasesList: [],
                    dayLedgerList: [],
                    dayShifts: shifts,
                    dayCustomerDebtList: cl,
                    dayWasteList: [],
                    lastReceiptIdShop: lastId,
                    usedLocalFallback: false,
                    provisional: false,
                    dateFrom: dateFrom,
                    dateTo: dateTo
                });
            } catch (_eLocPaint) {
                return false;
            }
        }

        function paintDailySummaryFromCalendarCache(dateFrom, dateTo, todayPretty, selectedUser) {
            if (typeof finalizeDailyModalContent !== 'function') return false;
            if (!dateFrom || dateFrom !== dateTo) return false;
            var rec = (typeof getCalendarDayStatsRecord === 'function')
                ? getCalendarDayStatsRecord(dateFrom, selectedUser)
                : null;
            if (!rec) return false;
            var sales = parseFloat(rec.sales_total) || 0;
            var exp = parseFloat(rec.exp_total) || 0;
            var ret = parseFloat(rec.returns_total) || 0;
            var cogs = parseFloat(rec.cogs) || 0;
            var retCogs = parseFloat(rec.returns_cogs) || 0;
            var waste = parseFloat(rec.waste_total) || 0;
            var gifts = parseFloat(rec.gifts) || 0;
            var saleCount = parseInt(rec.sale_count, 10) || 0;
            if (!(sales > 0) && !(saleCount > 0) && !(exp > 0) && !(ret > 0) && !(waste > 0) && !(gifts > 0)) {
                return false;
            }
            var profit = (rec.profit != null && rec.profit !== '')
                ? (parseFloat(rec.profit) || 0)
                : (sales - ret - (cogs - retCogs) - exp - waste);
            try {
                return !!finalizeDailyModalContent(dateFrom, todayPretty, {
                    metricsScoped: {
                        totalSales: sales,
                        cashSales: rec.cash_sales != null ? (parseFloat(rec.cash_sales) || 0) : sales,
                        debtSales: parseFloat(rec.debt_sales) || 0,
                        fibSales: parseFloat(rec.fib_sales) || 0,
                        totalReturns: ret,
                        cashRefunds: parseFloat(rec.cash_refunds) || 0,
                        opExpenses: exp,
                        cashPurchases: parseFloat(rec.purchases_cash) || 0,
                        companyDebtPayments: parseFloat(rec.company_debt_payments) || 0,
                        debtPaymentsIn: parseFloat(rec.debt_payments_in) || 0,
                        purchaseReturnsIn: 0,
                        totalPurchaseReturns: 0,
                        totalGiftsValue: gifts,
                        giftsCount: parseFloat(rec.gifts_count) || 0,
                        wasteLoss: waste,
                        wasteCount: parseInt(rec.waste_count, 10) || 0,
                        cashMovement: parseFloat(rec.cash_movement) || 0,
                        netProfit: profit,
                        grossProfit: (sales - ret) - (cogs - retCogs),
                        totalCogs: cogs,
                        totalSalesUsd: rec.sales_usd != null ? parseFloat(rec.sales_usd) : undefined,
                        netProfitUsd: rec.profit_usd != null ? parseFloat(rec.profit_usd) : undefined
                    },
                    daySalesScoped: [],
                    dayExpensesList: [],
                    dayReturnsList: [],
                    dayVoidedPurchasesList: [],
                    dayPurchaseReturnsList: [],
                    dayPurchasesList: [],
                    dayLedgerList: [],
                    dayShifts: [],
                    dayCustomerDebtList: [],
                    dayWasteList: [],
                    lastReceiptIdShop: '',
                    usedLocalFallback: false,
                    provisional: true,
                    dateFrom: dateFrom,
                    dateTo: dateTo
                });
            } catch (_eCalPaint) {
                return false;
            }
        }

        function paintDailySummarySkeleton(dateFrom, dateTo, todayPretty, selectedUser) {
            if (typeof finalizeDailyModalContent !== 'function') return false;
            try {
                var _dbSk = (typeof window !== 'undefined' && window.db) ? window.db : (typeof db !== 'undefined' ? db : null);
                var ts = (_dbSk && _dbSk.today_stats) ? _dbSk.today_stats : {};
                var isToday = false;
                try {
                    var todayIso = (typeof getBusinessDate === 'function') ? getBusinessDate(new Date()) : '';
                    isToday = (dateFrom === dateTo && dateFrom === todayIso);
                } catch (_eT) {}
                var sales = isToday ? (parseFloat(ts.sales) || 0) : 0;
                var expenses = isToday ? (parseFloat(ts.expenses) || 0) : 0;
                var returns = isToday ? (parseFloat(ts.returns) || 0) : 0;
                var cashSales = isToday ? (parseFloat(ts.cash_sales) || 0) : 0;
                var debtSales = isToday ? (parseFloat(ts.debt_sales) || 0) : 0;
                var fibSales = isToday ? (parseFloat(ts.fib_sales) || 0) : 0;
                var debtIn = isToday ? (parseFloat(ts.debt_payments_in) || 0) : 0;
                var cashRefunds = isToday ? (parseFloat(ts.cash_refunds) || 0) : 0;
                var cashPurch = isToday ? (parseFloat(ts.purchases_cash) || 0) : 0;
                var cashMove = isToday && ts.cash_movement != null ? (parseFloat(ts.cash_movement) || 0) : 0;
                var netP = (isToday && ts.net_profit != null && ts.net_profit !== '') ? (parseFloat(ts.net_profit) || 0) : null;
                var metrics = {
                    totalSales: sales,
                    cashSales: cashSales,
                    debtSales: debtSales,
                    fibSales: fibSales,
                    totalReturns: returns,
                    cashRefunds: cashRefunds,
                    opExpenses: expenses,
                    cashPurchases: cashPurch,
                    companyDebtPayments: 0,
                    debtPaymentsIn: debtIn,
                    purchaseReturnsIn: 0,
                    totalPurchaseReturns: 0,
                    totalGiftsValue: 0,
                    giftsCount: 0,
                    wasteLoss: 0,
                    wasteCount: 0,
                    cashMovement: cashMove,
                    netProfit: netP,
                    grossProfit: netP
                };
                var skPurchTotal = isToday ? (parseFloat(ts.purchases) || 0) : 0;
                var skPurchCash = isToday ? (parseFloat(ts.purchases_cash) || 0) : 0;
                var skPurchDebt = isToday ? (parseFloat(ts.purchases_debt) || Math.max(0, skPurchTotal - skPurchCash)) : 0;
                return !!finalizeDailyModalContent(dateFrom, todayPretty, {
                    metricsScoped: metrics,
                    daySalesScoped: [],
                    dayExpensesList: [],
                    dayReturnsList: [],
                    dayVoidedPurchasesList: [],
                    dayPurchaseReturnsList: [],
                    dayPurchasesList: [],
                    dayLedgerList: [],
                    dayShifts: (_dbSk && Array.isArray(_dbSk.shifts)) ? _dbSk.shifts.filter(function(s) {
                        try {
                            var raw = s.startTime || s.start_time || '';
                            var iso = String(raw).slice(0, 10);
                            if (iso === dateFrom) return true;
                            return getBusinessDate(parseSQLDate(raw)) === dateFrom;
                        } catch (_e) { return false; }
                    }).slice(0, 20) : [],
                    dayCustomerDebtList: [],
                    dayWasteList: [],
                    lastReceiptIdShop: (isToday && ts.last_receipt_id) ? String(ts.last_receipt_id) : '',
                    serverPurchaseStats: skPurchTotal > 0 ? {
                        purchases_total: skPurchTotal,
                        purchases_cash: skPurchCash,
                        purchases_debt: skPurchDebt,
                        purchase_count: 0
                    } : null,
                    serverPurchaseInvoices: [],
                    // today_stats comes from server bootstrap — not a scary "offline" warning
                    usedLocalFallback: false,
                    provisional: !(cashSales > 0 || debtSales > 0 || netP != null),
                    dateFrom: dateFrom,
                    dateTo: dateTo
                });
            } catch (_eSk) {
                return false;
            }
        }

        function paintDailySummaryContent(dateFrom, todayPretty, uid, opts) {
            opts = opts || {};
            var dateTo = opts.dateTo || opts.date_to || dateFrom;
            var rangeOpts = { user: opts.user, dateFrom: dateFrom, dateTo: dateTo };
            var isToday = false;
            try {
                var todayIso = (typeof getBusinessDate === 'function') ? getBusinessDate(new Date()) : '';
                isToday = (dateFrom === dateTo && dateFrom === todayIso);
            } catch (_eToday) {}
            try {
                if (paintDailySummaryFromLocalDb(dateFrom, dateTo, todayPretty, opts.user)) {
                    return true;
                }
                if (paintDailySummaryFromCalendarCache(dateFrom, dateTo, todayPretty, opts.user)) {
                    return true;
                }
                var cached = window._dailyDetailCache && (
                    window._dailyDetailCache[dailyDetailCacheKey(dateFrom, dateTo, opts.user || 'all')]
                    || (dateFrom === dateTo ? window._dailyDetailCache[dateFrom] : null)
                );
                var cacheTtl = opts.force ? 0 : 20000;
                if (cached && cached.data && cached.userId === uid && (Date.now() - cached.ts < cacheTtl)) {
                    if (typeof applyDailyDetailFromServer === 'function') {
                        try {
                            if (applyDailyDetailFromServer(cached.data, dateFrom, todayPretty, rangeOpts)) {
                                return true;
                            }
                        } catch (_eCache) {}
                    }
                }
                if (typeof buildDailySummaryFromLocal === 'function') {
                    try {
                        if (buildDailySummaryFromLocal(dateFrom, todayPretty, opts.user, rangeOpts)) {
                            return true;
                        }
                    } catch (_eLoc) {}
                }
                if (isToday && paintDailySummarySkeleton(dateFrom, dateTo, todayPretty, opts.user)) {
                    return true;
                }
            } catch (_ePaint) {
                try {
                    if (paintDailySummaryFromCalendarCache(dateFrom, dateTo, todayPretty, opts.user)) return true;
                    if (isToday && paintDailySummarySkeleton(dateFrom, dateTo, todayPretty, opts.user)) return true;
                } catch (_e2) {}
            }
            return false;
        }

        function applyDailyHistoryDateRange() {
            var inpFrom = document.getElementById('date-start-daily');
            var inpTo = document.getElementById('date-end-daily');
            var from = inpFrom && inpFrom.value ? inpFrom.value : '';
            var to = inpTo && inpTo.value ? inpTo.value : '';
            if (!from || !to) return;
            var norm = normalizeDailySummaryRange(from, to);
            if (!norm || norm.error === 'range_too_long') {
                var msg = (typeof t === 'function') ? t('daily_summary_range_too_long') : 'مەودا زۆر درێژە (زێدەتری 31 رۆژ ناهێتە قبووڵکرن).';
                if (typeof showToast === 'function') showToast(msg, 'error');
                else alert(msg);
                // Keep inputs but do not paint a zeroed multi-month skeleton
                return;
            }
            openDailyHistoryModal(norm.from, {
                dateFrom: norm.from,
                dateTo: norm.to,
                force: true,
                user: window._dailyDetailLastUser || 'all'
            });
        }

        function openDailyHistoryModal(targetDateStr, opts) {
            opts = opts || {};
            if (currentUser && currentUser.role !== 'admin' && typeof checkPermission === 'function' && !checkPermission('view_daily_summary')) {
                if (typeof logSecurityEvent === 'function') logSecurityEvent('access_denied', 'Attempted to open Daily Summary without permission');
                nav('access-denied');
                return;
            }
            const modal = document.getElementById('daily-history-modal');
            const content = document.getElementById('daily-history-content');
            if (!modal || !content) return;
            modal.classList.add('hist-modal');
            var dhShell = modal.querySelector('.hist-shell, .glass-card, .modal-content');
            if (dhShell) {
                dhShell.classList.add('hist-shell');
                dhShell.classList.remove('is-detail-open');
            }

            if (opts.detailSection) {
                window._dailySummaryPendingSheet = opts.detailSection;
                window._dailySummaryDetailOnly = !!opts.detailOnly;
            } else if (!opts.keepDetail) {
                window._dailySummaryPendingSheet = null;
                window._dailySummaryDetailOnly = false;
                if (typeof closeDailySummaryDetailSheet === 'function') {
                    closeDailySummaryDetailSheet({ keepModal: true, keepFlags: true });
                }
            }

            const fallbackDay = targetDateStr || getBusinessDate(new Date());
            const selectedUser = opts.user || window._dailyDetailLastUser || 'all';
            var dateFrom = opts.dateFrom || opts.date_from || null;
            var dateTo = opts.dateTo || opts.date_to || null;

            // Refresh while open: keep the current from/to from inputs when not explicitly passed.
            if ((!dateFrom || !dateTo) && (!!opts.refresh || !!opts.force) && modal.style.display === 'flex') {
                var keepFrom = document.getElementById('date-start-daily');
                var keepTo = document.getElementById('date-end-daily');
                if (!dateFrom && keepFrom && keepFrom.value) dateFrom = keepFrom.value;
                if (!dateTo && keepTo && keepTo.value) dateTo = keepTo.value;
            }
            if (!dateFrom) dateFrom = fallbackDay;
            if (!dateTo) dateTo = fallbackDay;

            var norm = normalizeDailySummaryRange(dateFrom, dateTo);
            if (!norm || norm.error === 'range_too_long') {
                var msgLong = (typeof t === 'function') ? t('daily_summary_range_too_long') : 'مەودا زۆر درێژە (زێدەتری 31 رۆژ ناهێتە قبووڵکرن).';
                if (typeof showToast === 'function') showToast(msgLong, 'error');
                else alert(msgLong);
                return;
            }
            dateFrom = norm.from;
            dateTo = norm.to;
            const todayIso = dateFrom;

            var inpStart = document.getElementById('date-start-daily');
            var inpEnd = document.getElementById('date-end-daily');
            if (inpStart) inpStart.value = dateFrom;
            if (inpEnd) inpEnd.value = dateTo;

            var localeRaw = typeof getDateLocale === 'function' ? getDateLocale() : 'ku';
            var localePretty = (localeRaw === 'ar-IQ' || localeRaw === 'ar') ? 'ar-IQ' : 'ku-IQ';
            var todayPretty = todayIso;
            if (dateFrom === dateTo) {
                var ym = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(todayIso || ''));
                if (ym) {
                    try {
                        todayPretty = new Date(parseInt(ym[1], 10), parseInt(ym[2], 10) - 1, parseInt(ym[3], 10), 12, 0, 0).toLocaleDateString(localePretty, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
                    } catch (_ePd) {}
                }
            } else {
                var rangeTpl = (typeof t === 'function') ? t('daily_summary_range_heading') : 'ژ {from} تا {to}';
                todayPretty = String(rangeTpl || 'ژ {from} تا {to}').replace('{from}', dateFrom).replace('{to}', dateTo);
            }
            if (selectedUser !== 'all') {
                todayPretty += ' (' + selectedUser + ')';
            }

            var tgBtn = document.getElementById('daily-history-tg-btn');
            if (tgBtn) {
                if (dateFrom === dateTo) {
                    tgBtn.style.display = '';
                    tgBtn.onclick = function() { sendTelegramReport(dateFrom); };
                } else {
                    tgBtn.style.display = 'none';
                }
            }

            window._dailySummaryFromServer = false;
            var force = !!opts.force;
            var reqKey = dailyDetailCacheKey(dateFrom, dateTo, selectedUser);
            var refreshInPlace = (!!opts.refresh || force) && modal.style.display === 'flex' && window._dailyDetailLastDate === reqKey;
            window._dailyDetailLastDate = reqKey;
            window._dailyDetailLastUser = selectedUser;
            window._dailyDetailLastFrom = dateFrom;
            window._dailyDetailLastTo = dateTo;
            window._dailyPurchaseSheetTried = false;
            window._dailyPurchaseSheetRefreshing = false;
            modal.style.display = 'flex';
            if (modal && typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
            var uid = currentUser && currentUser.id;
            window._dailyDetailCache = window._dailyDetailCache || {};
            var loadId = (window._dailyDetailLoadId = (window._dailyDetailLoadId || 0) + 1);
            var epochAtOpen = window._dailyDetailEpoch || 0;
            var rangeOpts = { force: force, user: selectedUser, dateFrom: dateFrom, dateTo: dateTo };

            if (force && typeof posInvalidateDailyDetailCache === 'function') {
                posInvalidateDailyDetailCache(dateFrom);
                epochAtOpen = window._dailyDetailEpoch || 0;
            }

            // Paint instantly (never leave spinner) — local/skeleton, then lite server refresh
            if (!refreshInPlace) {
                content.innerHTML = '<div style="text-align:center;padding:36px 20px;color:var(--text-muted)"><i class="fas fa-spinner fa-spin" style="font-size:2rem;display:block;margin:0 auto 12px;"></i><div style="font-size:0.95rem;">' + escapeHtml((typeof t === 'function') ? t('daily_summary_loading') : 'بارکرنا پوختەیا ڕۆژێ…') + '</div></div>';
            }

            window._dailySummaryPaintedIqd = 0;
            window._dailySummaryFromServer = false;

            function cleanProvisionalRefreshingMessage() {
                try {
                    var el = content.querySelector('.daily-sum-offline');
                    if (el && el.innerHTML && (el.innerHTML.indexOf('fa-sync-alt') !== -1 || el.innerHTML.indexOf('نوێدەبێت') !== -1)) {
                        el.style.opacity = '0.7';
                        el.innerHTML = '<i class="fas fa-database"></i> ' + escapeHtml((typeof t === 'function') ? t('daily_summary_offline_cached', 'داتاکان ژ کاشێ کاتی نە') : 'داتاکان ژ کاشێ کاتی نە');
                    }
                } catch (_e) {}
            }

            function paintDailySummaryFallbackCards() {
                if (window._dailySummaryFromServer) return true;
                if (window._dailySummaryPaintedIqd > 0.0001) return true;
                try {
                    if (paintDailySummaryFromCalendarCache(dateFrom, dateTo, todayPretty, selectedUser)) return true;
                    if (paintDailySummaryFromLocalDb(dateFrom, dateTo, todayPretty, selectedUser)) return true;
                    if (typeof buildDailySummaryFromLocal === 'function' && buildDailySummaryFromLocal(dateFrom, todayPretty, selectedUser, rangeOpts)) return true;
                } catch (_eFbPaint) {}
                return false;
            }

            var painted = false;
            try {
                painted = !!paintDailySummaryContent(dateFrom, todayPretty, uid, rangeOpts);
            } catch (_eP0) {
                painted = false;
            }
            if (!painted) {
                painted = !!paintDailySummaryFallbackCards();
            }

            setTimeout(function() {
                if (loadId !== window._dailyDetailLoadId) return;
                if (window._dailySummaryFromServer) return;
                paintDailySummaryFallbackCards();
            }, 800);

            function applyDailyDetailOrFallback(dd) {
                if (loadId !== window._dailyDetailLoadId || !modal || modal.style.display === 'none') return;
                if (dd && dd.status === 'ok' && dd.pools && typeof applyDailyDetailFromServer === 'function') {
                    try {
                        if (applyDailyDetailFromServer(dd, dateFrom, todayPretty, rangeOpts)) {
                            window._dailySummaryFromServer = true;
                            return;
                        }
                    } catch (_eApply) {}
                }
                if (!window._dailySummaryFromServer) {
                    paintDailySummaryFallbackCards();
                    cleanProvisionalRefreshingMessage();
                }
            }

            // Do NOT kick secondary fetch here — it bumps epoch and races the daily lite request.
            fetchDailyDetailForModal(dateFrom, uid, { force: true, user: selectedUser, dateTo: dateTo, lite: true }).then(function(dd) {
                if (loadId !== window._dailyDetailLoadId || !modal || modal.style.display === 'none') return;
                if (dd && dd.status === 'ok' && dd.pools && typeof applyDailyDetailFromServer === 'function') {
                    try {
                        if (applyDailyDetailFromServer(dd, dateFrom, todayPretty, rangeOpts)) {
                            window._dailySummaryFromServer = true;
                            return;
                        }
                    } catch (_eApply) {}
                }
                if (dd && dd.status === 'stale') {
                    return fetchDailyDetailForModal(dateFrom, uid, { force: true, user: selectedUser, dateTo: dateTo, lite: true }).then(function(dd2) {
                        if (loadId !== window._dailyDetailLoadId || !modal || modal.style.display === 'none') return;
                        applyDailyDetailOrFallback(dd2);
                    }).catch(function() {
                        if (loadId !== window._dailyDetailLoadId || !modal || modal.style.display === 'none') return;
                        paintDailySummaryFallbackCards();
                        cleanProvisionalRefreshingMessage();
                    });
                }
                if (dd && dd.status === 'error' && dd.max_days) {
                    var msgLong2 = (typeof t === 'function') ? t('daily_summary_range_too_long') : 'مەودا زۆر درێژە (زێدەتری 31 رۆژ ناهێتە قبووڵکرن).';
                    if (typeof showToast === 'function') showToast(msgLong2, 'error');
                }
                paintDailySummaryFallbackCards();
                cleanProvisionalRefreshingMessage();
            }).catch(function() {
                if (loadId !== window._dailyDetailLoadId || !modal || modal.style.display === 'none') return;
                paintDailySummaryFallbackCards();
                cleanProvisionalRefreshingMessage();
            });
        }

        function closeDailyHistoryModal() {
            window._dailySummaryDetailOnly = false;
            window._dailySummaryPendingSheet = null;
            const modalDh = document.getElementById('daily-history-modal');
            if (modalDh) modalDh.style.display = 'none';
            if (typeof closeDailySummaryDetailSheet === 'function') {
                closeDailySummaryDetailSheet({ keepModal: true, keepFlags: true });
            }
        }

        // --- REPORTING (ENHANCED) ---
        function openSecurityModal() {
            if (currentUser && currentUser.role !== 'admin' && !hasPermission('view_audit_logs')) {
                if (typeof logSecurityEvent === 'function') logSecurityEvent('access_denied', 'Attempted to open Security/Audit logs without permission');
                nav('access-denied');
                return;
            }
            document.getElementById('security-modal').style.display = 'flex';
            var container = document.getElementById('security-logs-body');
            if (container) {
                container.innerHTML = '<div style="text-align:center; padding:40px; color:#94a3b8;"><i class="fas fa-spinner fa-spin fa-2x"></i><br><span style="margin-top:12px;display:inline-block;">نوێکردنەوەی تۆمارەکان...</span></div>';
            }
            refreshAuditLogs(function() {
                renderSecurityLogs();
            });
        }

        function secActionLabelKu(actionType) {
            const at = String(actionType || '').toLowerCase();
            const map = {
                alert_underprice_sale: '⚠️ فرۆشتن ب نرخێ کەمتر',
                manual_price_sale: 'نرخێ دەستی (فرۆشتن)',
                manual_price_edit: 'گۆڕینا نرخێ',
                alert_manual_discount: '⚠️ داشکاندن / نرخێ کەمتر',
                manual_discount_total: 'داشکاندنا کۆی گشتی',
                edit_product: 'دەستکاری ئایتم',
                create_product: 'زیادکرنا ئایتم',
                waste_report: 'تەلەف',
                void_item: 'ژێبرنا ئایتم',
                void_order: 'هەلوەشاندنا فرۆشتن',
                void_sale: 'ژێبرنا وەسڵێ',
                refund_sale: 'ژێبرنا وەسڵێ',
                settings_change: 'گۆڕینا ڕێکخستن',
                login_success: 'چوونەژوور',
                login_failed: 'چوونەژوور سەرنەکەوت',
                access_denied: 'ڕێگەپێدان نەدرا'
            };
            if (map[at]) return map[at];
            if (at.includes('underprice') || at.includes('discount')) return '⚠️ نرخ / داشکاندن';
            if (at.includes('delete')) return 'ژێبرن';
            if (at.includes('waste')) return 'تەلەف';
            if (at.includes('sale') || at.includes('refund')) return 'فرۆشتن';
            if (at.includes('edit')) return 'دەستکاری';
            if (at.includes('create') || at.includes('add')) return 'زیادکرن';
            if (at.includes('login')) return 'چوونەژوور';
            if (at.includes('alert') || at.includes('void') || at.includes('failed')) return '⚠️ ئاگەهداری';
            return actionType || '—';
        }

        function renderSecurityLogs() {
            const container = document.getElementById('security-logs-body');
            if (!container) return;
            const qEl = document.getElementById('sec-search');
            const filterEl = document.getElementById('sec-filter');
            const q = (qEl && qEl.value) ? qEl.value.toLowerCase() : '';
            const filter = (filterEl && filterEl.value) ? filterEl.value : 'all';
            
            if(!db.logs || db.logs.length === 0) {
                container.innerHTML = '<div style="text-align:center; padding:50px; color:#64748b;"><i class="fas fa-shield-alt" style="font-size:4rem; margin-bottom:10px;"></i><br>چ تۆمارێن ئەمنی نینن.</div>';
                return;
            }
            
            let filtered = db.logs.filter(l => {
                const matchesQ = (l.user && (l.user||'').toLowerCase().includes(q)) || 
                       (l.action_type && (l.action_type||'').toLowerCase().includes(q)) || 
                       (l.details && (l.details||'').toLowerCase().includes(q));
                
                if(!matchesQ) return false;
                
                const at = (l.action_type || '').toLowerCase();
                const et = (l.entity_type || '').toLowerCase();

                if(filter === 'delete') return at.includes('delete');
                if(filter === 'alert') return at.includes('alert') || at.includes('failed') || at.includes('void') || at.includes('underprice');
                if(filter === 'edit') return at.includes('edit');
                if(filter === 'login') return at.includes('login');
                if(filter === 'sale') return at.includes('sale') || at.includes('refund') || at.includes('void');
                if(filter === 'product') return et === 'product' || at.includes('product') || at.includes('create_product');
                if(filter === 'settings') return at.includes('settings');
                if(filter === 'staff') {
                    const u = (l.user || '').toLowerCase().trim();
                    return u !== 'system' && u !== '';
                }
                if(filter === 'price') return at.includes('price') || at.includes('discount') || at.includes('underprice');
                if(filter === 'waste') return at.includes('waste');
                
                return true;
            });

            if (filtered.length === 0) {
                container.innerHTML = '<div style="text-align:center; padding:40px; color:#64748b;"><i class="fas fa-filter" style="font-size:3rem; margin-bottom:10px;"></i><br>بۆ فلتەر یان گەڕانێ نوێ هەلبژاردنی چ ئەنجام نەهاتە دیتن.</div>';
                return;
            }

            container.innerHTML = filtered.map(l => {
                const at = (l.action_type || '').toLowerCase();
                const actionLabel = secActionLabelKu(l.action_type);
                let typeClass = 'sec-type-system';
                let icon = 'fa-info';
                
                if(at.includes('underprice') || at.includes('alert') || at.includes('failed') || at.includes('void')) { typeClass = 'sec-type-alert'; icon = 'fa-exclamation-triangle'; }
                else if(at.includes('delete')) { typeClass = 'sec-type-delete'; icon = 'fa-trash-alt'; }
                else if(at.includes('edit')) { typeClass = 'sec-type-edit'; icon = 'fa-edit'; }
                else if(at.includes('create') || at.includes('add')) { typeClass = 'sec-type-create'; icon = 'fa-plus'; }
                else if(at.includes('login')) { typeClass = 'sec-type-login'; icon = 'fa-user-check'; }
                else if(at.includes('refund') || at.includes('sale') || at.includes('price')) { typeClass = 'sec-type-login'; icon = at.includes('underprice') ? 'fa-tag' : 'fa-cash-register'; }
                else if(at.includes('waste')) { typeClass = 'sec-type-alert'; icon = 'fa-trash'; }
                else if(at.includes('settings')) { typeClass = 'sec-type-system'; icon = 'fa-cog'; }

                var entityBadge = '';
                if (l.entity_type && String(l.entity_type).trim() !== '') {
                    entityBadge = '<span style="font-size:0.7rem; margin-inline-start:8px; opacity:0.85;">[' + escapeHtml(String(l.entity_type)) + (l.entity_id != null && l.entity_id !== '' ? '#' + escapeHtml(String(l.entity_id)) : '') + ']</span>';
                }

                return `
                <div class="sec-log-card ${typeClass}">
                    <div class="sec-icon"><i class="fas ${icon}"></i></div>
                    <div style="flex:1;">
                        <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap; margin-bottom:4px;">
                            <span style="font-size:0.75rem; font-weight:700; padding:2px 8px; border-radius:6px; background:rgba(0,0,0,0.35); color:#38bdf8;">${escapeHtml(actionLabel)}</span>
                        </div>
                        <div style="font-weight:bold; font-size:1rem; color:#f1f5f9;">${escapeHtml(l.details)}${entityBadge}</div>
                        <div style="color:#94a3b8; font-size:0.8rem; margin-top:4px;">
                            <span style="color:#cbd5e1"><i class="fas fa-user"></i> ${escapeHtml(l.user)}</span>
                            <span style="margin:0 8px; opacity:0.3">|</span>
                            <span><i class="fas fa-clock"></i> ${new Date(l.created_at).toLocaleString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ')}</span>
                        </div>
                    </div>
                </div>`;
            }).join(''); 
        }

        // --- GENERAL HISTORY (Print + Delete, non-sales) ---
        var GH_SALES_DOC_TYPES = { pos_sale: 1, proforma: 1, kitchen_slip: 1, return_receipt: 1 };

        function findPrintLogRecord(id) {
            if (!db || !Array.isArray(db.print_log)) return null;
            return db.print_log.find(function(r) { return String(r.id) === String(id); }) || null;
        }

        function normalizeGhDocType(docType) {
            var dt = String(docType || '').toLowerCase();
            if (dt === 'debt_report') return 'debt_list';
            return dt;
        }

        function ghDocTypeMatchesFilter(docType, filter, rec) {
            if (!filter) return true;
            var dt = normalizeGhDocType(docType);
            var f = normalizeGhDocType(filter);
            if (dt === f) return true;
            if (f === 'daily_report') {
                if (dt === 'daily_report') return true;
                if (dt === 'daily_monthly_report') {
                    var docId = rec && rec.doc_id != null ? String(rec.doc_id).toLowerCase() : '';
                    return docId !== 'monthly';
                }
            }
            if (f === 'monthly_report') {
                if (dt === 'monthly_report') return true;
                if (dt === 'daily_monthly_report') {
                    var docIdM = rec && rec.doc_id != null ? String(rec.doc_id).toLowerCase() : '';
                    return docIdM === 'monthly';
                }
            }
            return false;
        }

        function formatGeneralHistoryDocLabel(docType) {
            var dt = normalizeGhDocType(docType);
            if (!dt) return '—';
            if (dt === 'daily_monthly_report') {
                return (typeof t === 'function') ? (t('gh_doc_daily_monthly_report') || t('gh_doc_daily_report')) : 'ڕاپۆرت';
            }
            var key = 'gh_doc_' + dt;
            if (typeof t === 'function') {
                var tr = t(key);
                if (tr && tr !== key) return tr;
            }
            var fb = {
                expense: 'مەزاختن',
                expenses_report: 'ڕاپۆرتا مەزاختنان',
                stocktake_report: 'ڕاپۆرتی پێداچوون',
                stock_movement_log: 'لڤینێن کۆگەهێ',
                stock_transfer_report: 'گواستنەوەی کۆگە',
                inventory_report: 'لیستا کۆگەه',
                company_ledger: 'کۆمپانیا',
                delivery_slip: 'گەهاندن',
                debt_list: 'قەرزان',
                daily_report: 'ڕاپۆرتێ رۆژانە',
                monthly_report: 'ڕاپۆرتێ مانگانە',
                product: 'کاڵا',
                company: 'کۆمپانیا',
                customer: 'کڕیار',
                waste_report: 'ڕاپۆرتا بەفیڕۆ',
                stock_card: 'کارتی کۆگە',
                category_report: 'ڕاپۆرتا پۆلان',
                purchase_invoice: 'پسوولەی کڕین',
                purchase_return: 'زڤڕاندنی کڕین'
            };
            return fb[dt] || docType || '—';
        }

        function formatGeneralHistoryActionLabel(action) {
            var a = String(action || '').toLowerCase();
            if (a === 'delete') return (typeof t === 'function') ? t('gh_filter_delete') : 'ژێبرن';
            if (a === 'update') return (typeof t === 'function') ? t('gh_filter_update') : 'نویکرن';
            if (a === 'print') return (typeof t === 'function') ? t('gh_filter_print') : 'چاپ';
            return action || '—';
        }

        function parseGeneralHistoryDetails(rec) {
            if (!rec || rec.details == null || rec.details === '') return null;
            try {
                return typeof rec.details === 'string' ? JSON.parse(rec.details) : rec.details;
            } catch (e) {
                return { raw: String(rec.details) };
            }
        }

        function generalHistoryCanReprint(rec) {
            if (!rec) return false;
            if (String(rec.action || '').toLowerCase() !== 'print') return false;
            var docType = normalizeGhDocType(rec.doc_type);
            if (!docType || docType === 'product' || docType === 'company' || docType === 'customer' || docType === 'expense') return false;
            return true;
        }

        function buildGeneralHistoryPreviewBody(rec) {
            if (!rec) return '';
            var action = String(rec.action || '').toLowerCase();
            var docType = normalizeGhDocType(rec.doc_type);
            var note = rec.note || '';
            var parsed = parseGeneralHistoryDetails(rec);
            var lblNote = (typeof t === 'function') ? t('gh_th_note') : 'تێبینی';
            var lblDetails = (typeof t === 'function') ? t('gh_preview_details') : 'وردەکاری';

            function detailGrid(items) {
                return '<div class="gh-preview-detail-grid">' + items.map(function(item) {
                    return '<div class="gh-preview-detail-item"><span>' + escapeHtml(item.label) + '</span><strong' + (item.cls ? ' class="' + item.cls + '"' : '') + '>' + escapeHtml(item.value) + '</strong></div>';
                }).join('') + '</div>';
            }

            if (docType === 'expense' && action === 'delete') {
                var amount = (parsed && (typeof formatExpenseAmountDisplay === 'function'))
                    ? formatExpenseAmountDisplay(parsed)
                    : (parsed && parsed.amount != null ? formatCurrency(parsed.amount) : '—');
                var origDate = parsed && parsed.date ? (typeof parseSQLDate === 'function' ? parseSQLDate(parsed.date).toLocaleString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ') : parsed.date) : '—';
                var origUser = parsed && parsed.user ? parsed.user : '—';
                return detailGrid([
                    { label: lblNote, value: note || (parsed && parsed.note) || '—' },
                    { label: (typeof t === 'function') ? t('exp_amount_ph') : 'بڕ', value: amount, cls: 'gh-preview-amount' },
                    { label: (typeof t === 'function') ? t('gh_th_date') : 'بەروار', value: origDate },
                    { label: (typeof t === 'function') ? t('gh_th_user') : 'بەکارهێنەر', value: origUser }
                ]);
            }

            if (docType === 'expense' && action === 'update' && parsed) {
                return detailGrid([
                    { label: lblNote, value: note || '—' },
                    { label: lblDetails, value: typeof parsed === 'object' ? JSON.stringify(parsed, null, 2) : String(parsed) }
                ]);
            }

            if (action === 'delete' && (docType === 'product' || docType === 'company' || docType === 'customer')) {
                var rows = [{ label: lblNote, value: note || '—' }];
                if (parsed && parsed.raw) rows.push({ label: lblDetails, value: parsed.raw });
                else if (parsed && typeof parsed === 'object') {
                    Object.keys(parsed).forEach(function(k) {
                        rows.push({ label: k, value: String(parsed[k]) });
                    });
                }
                return detailGrid(rows);
            }

            if (parsed && typeof parsed === 'object') {
                var summaryRows = [];
                if (parsed.from && parsed.to) summaryRows.push({ label: (typeof t === 'function') ? t('gh_preview_from_to') : 'ل / بۆ', value: parsed.from + ' → ' + parsed.to });
                if (parsed.items != null) summaryRows.push({ label: (typeof t === 'function') ? t('gh_preview_items') : 'ئایتەم', value: String(parsed.items) });
                if (parsed.rows != null) summaryRows.push({ label: (typeof t === 'function') ? t('gh_preview_rows') : 'ڕیز', value: String(parsed.rows) });
                if (parsed.type) summaryRows.push({ label: (typeof t === 'function') ? t('gh_th_action') : 'جۆر', value: String(parsed.type) });
                if (parsed.raw) summaryRows.push({ label: lblDetails, value: parsed.raw });
                if (summaryRows.length) {
                    var html = detailGrid(summaryRows);
                    if (note) html += '<div class="gh-preview-note-box"><span>' + escapeHtml(lblNote) + '</span><p>' + escapeHtml(note) + '</p></div>';
                    return html;
                }
            }

            if (note || (parsed && parsed.raw)) {
                return '<div class="gh-preview-note-box"><span>' + escapeHtml(lblNote) + '</span><p>' + escapeHtml(note || (parsed && parsed.raw) || '—') + '</p></div>';
            }
            return '<p class="gh-preview-empty">' + escapeHtml((typeof t === 'function') ? t('gh_preview_no_extra') : 'وردەکاری زیاتر نییە.') + '</p>';
        }

        function ensurePrintLogLoaded(done, force) {
            if (!db) {
                if (typeof done === 'function') done();
                return;
            }
            if (!force && window._printLogLoaded && Array.isArray(db.print_log)) {
                if (typeof done === 'function') done();
                return;
            }
            fetch('?action=get_print_log&limit=200&t=' + Date.now())
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    window._printLogDenied = !!(data && data.status === 'denied');
                    if (data && data.status === 'success' && Array.isArray(data.print_log)) {
                        db.print_log = data.print_log;
                    } else if (!db.print_log) {
                        db.print_log = [];
                    }
                    window._printLogLoaded = true;
                    if (typeof done === 'function') done();
                })
                .catch(function() {
                    if (!db.print_log) db.print_log = [];
                    window._printLogLoaded = true;
                    if (typeof done === 'function') done();
                });
        }

        function refreshGeneralHistory() {
            window._printLogLoaded = false;
            renderGeneralHistory();
        }

        function getGeneralHistoryItems() {
            var items = (db && db.print_log ? db.print_log.slice() : []);
            items = items.filter(function(r) {
                var t = normalizeGhDocType(r.doc_type);
                return !GH_SALES_DOC_TYPES[t];
            });
            return items;
        }

        function renderGeneralHistory() {
            var body = document.getElementById('general-history-body');
            var countEl = document.getElementById('gh-count');
            if (!body || !db) return;
            if (!window._printLogLoaded) {
                body.innerHTML = '<tr><td colspan="8" class="gh-empty"><i class="fas fa-spinner fa-spin"></i></td></tr>';
                ensurePrintLogLoaded(function() { renderGeneralHistory(); });
                return;
            }
            if (window._printLogDenied) {
                body.innerHTML = '<tr><td colspan="8" class="gh-empty">' + escapeHtml((typeof t === 'function') ? t('gh_permission_denied') : 'مۆڵەت نییە بۆ بینینی ئەم تۆمارە.') + '</td></tr>';
                if (countEl) countEl.textContent = '';
                return;
            }
            var searchInput = document.getElementById('gh-search');
            var actionFilterEl = document.getElementById('gh-action-filter');
            var docFilterEl = document.getElementById('gh-doc-filter');
            var q = searchInput && searchInput.value ? searchInput.value.toLowerCase() : '';
            var actionFilter = actionFilterEl ? actionFilterEl.value : '';
            var docFilter = docFilterEl ? docFilterEl.value : '';
            var items = getGeneralHistoryItems();
            if (actionFilter) {
                items = items.filter(function(r) { return (r.action || '').toLowerCase() === actionFilter; });
            }
            if (docFilter) {
                items = items.filter(function(r) { return ghDocTypeMatchesFilter(r.doc_type, docFilter, r); });
            }
            if (q) {
                items = items.filter(function(r) {
                    var txt = ((r.doc_type || '') + ' ' + (r.doc_id || '') + ' ' + (r.user || '') + ' ' + (r.note || '') + ' ' + (r.details || '')).toLowerCase();
                    return txt.indexOf(q) !== -1;
                });
            }
            if (countEl) {
                var total = getGeneralHistoryItems().length;
                countEl.textContent = (typeof t === 'function')
                    ? (t('gh_count_label') || '').replace('{shown}', String(items.length)).replace('{total}', String(total))
                    : (items.length + ' / ' + total);
            }
            if (items.length === 0) {
                body.innerHTML = '<tr><td colspan="8" class="gh-empty">' + escapeHtml((typeof t === 'function') ? t('gh_empty') : 'هیچ تۆمارێکی چاپ/ژێبرینی عام نییە.') + '</td></tr>';
                return;
            }
            var viewLbl = (typeof t === 'function') ? t('gh_preview_view') : 'بینین';
            body.innerHTML = items.map(function(r) {
                var createdAt = r.created_at ? new Date(String(r.created_at).replace(' ', 'T')).toLocaleString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ') : '';
                var actionLabel = formatGeneralHistoryActionLabel(r.action);
                var docType = r.doc_type || '';
                var docLabel = formatGeneralHistoryDocLabel(docType);
                var actionClass = String(r.action || 'print').toLowerCase();
                if (actionClass !== 'delete' && actionClass !== 'print') actionClass = 'update';
                var rowId = String(r.id != null ? r.id : '');
                var jsId = rowId.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
                var btnHtml = '<button type="button" class="btn btn-sm btn-info gh-btn-view" onclick="openGeneralHistoryPreview(\'' + jsId + '\'); event.stopPropagation();" title="' + escapeHtml(viewLbl) + '"><i class="fas fa-eye"></i></button>';
                return '<tr class="gh-row" data-id="' + escapeHtml(rowId) + '" onclick="openGeneralHistoryPreview(\'' + jsId + '\')">' +
                    '<td class="gh-td-id">' + escapeHtml(rowId || '—') + '</td>' +
                    '<td class="gh-td-doc"><span class="badge badge-doc">' + escapeHtml(docLabel) + '</span></td>' +
                    '<td class="gh-td-ref">' + escapeHtml(r.doc_id || '—') + '</td>' +
                    '<td class="gh-td-action"><span class="badge badge-' + (actionClass === 'delete' ? 'delete' : (actionClass === 'update' ? 'update' : 'print')) + '">' + escapeHtml(actionLabel) + '</span></td>' +
                    '<td class="gh-td-user">' + escapeHtml(r.user || '') + '</td>' +
                    '<td class="gh-td-date">' + escapeHtml(createdAt) + '</td>' +
                    '<td class="gh-td-note">' + escapeHtml(r.note || '—') + '</td>' +
                    '<td class="gh-td-btn" onclick="event.stopPropagation();">' + btnHtml + '</td>' +
                    '</tr>';
            }).join('');
        }
        if (typeof window !== 'undefined') {
            window.renderGeneralHistory = renderGeneralHistory;
            window.refreshGeneralHistory = refreshGeneralHistory;
        }

        function openGeneralHistoryPreview(id) {
            var modal = document.getElementById('gh-preview-modal');
            var titleTextEl = document.getElementById('gh-preview-title-text');
            var metaEl = document.getElementById('gh-preview-meta');
            var hintEl = document.getElementById('gh-preview-hint');
            var bodyEl = document.getElementById('gh-preview-body');
            var badgeEl = document.getElementById('gh-preview-action-badge');
            var reprintBtn = document.getElementById('gh-preview-reprint-btn');
            if (!modal || !db) return;
            var rec = findPrintLogRecord(id);
            if (!rec) {
                if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('gh_record_not_found') : 'تۆمار نەدۆزرایەوە.', true);
                return;
            }
            var docType = rec.doc_type || '';
            var docId = rec.doc_id || '';
            var action = String(rec.action || '').toLowerCase();
            var when = rec.created_at ? new Date(String(rec.created_at).replace(' ', 'T')).toLocaleString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ') : '';
            var docLabel = formatGeneralHistoryDocLabel(docType);
            var actionLabel = formatGeneralHistoryActionLabel(rec.action);
            if (titleTextEl) titleTextEl.textContent = docLabel + (docId ? ' #' + docId : '');
            if (metaEl) metaEl.textContent = (rec.user || 'System') + ' — ' + when;
            if (badgeEl) {
                badgeEl.hidden = false;
                badgeEl.textContent = actionLabel;
                var badgeCls = action === 'delete' ? 'delete' : (action === 'update' ? 'update' : 'print');
                badgeEl.className = 'gh-preview-action-badge badge-' + badgeCls;
            }
            if (bodyEl) bodyEl.innerHTML = buildGeneralHistoryPreviewBody(rec);
            if (hintEl) {
                var normType = normalizeGhDocType(docType);
                var liveTypes = ['stocktake_report', 'inventory_report', 'stock_movement_log', 'stock_transfer_report', 'delivery_slip', 'company_ledger', 'daily_report', 'monthly_report', 'daily_monthly_report', 'expenses_report', 'debt_list'];
                if (action === 'print' && liveTypes.indexOf(normType) !== -1) {
                    hintEl.textContent = (typeof t === 'function') ? t('gh_preview_hint_live_data') : 'تێبینی: دووبارە چاپ بە داتای ئێستا دەبێت، نەک وێنەیەکی کەڤن.';
                    hintEl.style.display = '';
                } else if (docType === 'expense' && action === 'delete') {
                    hintEl.textContent = (typeof t === 'function') ? t('gh_preview_expense_deleted_hint') : 'ئەم تۆمارە ژێبرینی مەزاختنێکە.';
                    hintEl.style.display = '';
                } else {
                    hintEl.textContent = '';
                    hintEl.style.display = 'none';
                }
            }
            if (reprintBtn) reprintBtn.style.display = generalHistoryCanReprint(rec) ? '' : 'none';
            modal.style.display = 'flex';
            if (typeof window.bringOverlayToFront === 'function') window.bringOverlayToFront(modal);
            else modal.style.zIndex = '10050';
            modal.setAttribute('data-doc-type', docType);
            modal.setAttribute('data-doc-id', docId);
            modal.setAttribute('data-log-id', String(id || ''));
            modal.setAttribute('data-action', action);
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
        }
        if (typeof window !== 'undefined') window.openGeneralHistoryPreview = openGeneralHistoryPreview;

        function closeGeneralHistoryPreview() {
            var modal = document.getElementById('gh-preview-modal');
            if (modal) modal.style.display = 'none';
        }
        if (typeof window !== 'undefined') window.closeGeneralHistoryPreview = closeGeneralHistoryPreview;

        function reprintFromGeneralHistory() {
            var modal = document.getElementById('gh-preview-modal');
            if (!modal) return;
            var docType = normalizeGhDocType(modal.getAttribute('data-doc-type') || '');
            var docId = modal.getAttribute('data-doc-id') || '';
            var action = (modal.getAttribute('data-action') || '').toLowerCase();
            if (!docType || action !== 'print') return;
            closeGeneralHistoryPreview();

            if (docType === 'stock_transfer_report') {
                var whTid = parseInt(docId, 10) || 0;
                if (whTid > 0 && typeof openWhTransferDetail === 'function') openWhTransferDetail(whTid, false);
                else if (typeof printWhTransferReport === 'function') printWhTransferReport(docId);
                return;
            }
            if (docType === 'delivery_slip') {
                var did = parseInt(docId, 10) || 0;
                if (did > 0 && typeof printDeliverySlip === 'function') printDeliverySlip(did);
                else if (typeof printDeliveryList === 'function') printDeliveryList();
                return;
            }
            if (docType === 'stocktake_report' && typeof printStocktakeReport === 'function') { printStocktakeReport(); return; }
            if (docType === 'stock_movement_log' && typeof printStockMovementLog === 'function') { printStockMovementLog(); return; }
            if (docType === 'inventory_report' && typeof printInventoryList === 'function') { printInventoryList(); return; }
            if (docType === 'company_ledger') {
                if (typeof printCompaniesReport === 'function') { printCompaniesReport(); return; }
                if (typeof printSuppliersList === 'function') { printSuppliersList(); return; }
            }
            if (docType === 'expenses_report' && typeof printExpenses === 'function') { printExpenses(); return; }
            if (docType === 'debt_list') {
                if (typeof printCustomersReport === 'function') { printCustomersReport(); return; }
                if (typeof printDebtReport === 'function') { printDebtReport(); return; }
            }
            if (docType === 'waste_report' && typeof printWasteReport === 'function') { printWasteReport(); return; }
            if (docType === 'daily_report' || docType === 'monthly_report' || docType === 'daily_monthly_report') {
                var rt = 'daily';
                if (docType === 'monthly_report') rt = 'monthly';
                else if (docType === 'daily_monthly_report' && String(docId).toLowerCase() === 'monthly') rt = 'monthly';
                if (typeof printDetailedReport === 'function') printDetailedReport(rt);
                return;
            }
            if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('gh_reprint_unsupported') : 'دووبارە چاپ بۆ ئەم جۆرە بەردەست نییە.', true);
        }
        if (typeof window !== 'undefined') window.reprintFromGeneralHistory = reprintFromGeneralHistory;

        var _salesHistoryFetchTimer = null;
        var _salesHistoryFetchSeq = 0;
        var _returnsHistoryFetchSeq = 0;
        window._salesHistoryBatchSize = 0;

        function posSalesHistoryDefaultDays() {
            // تەنها ئەمڕۆ — خێراتر، بێ دواکەوتن لە دووکانی گەورە
            return 0;
        }
        function posSalesHistoryFetchLimit() {
            // Same-day default: keep first page small for speed
            var sEl = document.getElementById('date-start-sales');
            var eEl = document.getElementById('date-end-sales');
            if (sEl && eEl && sEl.value && eEl.value && sEl.value === eEl.value) return 80;
            if (typeof window.isPosLargeShopMode === 'function' && window.isPosLargeShopMode()) return 100;
            if (typeof window.isPosUltraGraphicsMode === 'function' && window.isPosUltraGraphicsMode()) return 120;
            if (typeof window.isPosCpuSaveMode === 'function' && window.isPosCpuSaveMode()) return 150;
            return 200;
        }
        function posSalesHistoryActiveLimit() {
            var batch = parseInt(window._salesHistoryBatchSize, 10) || 0;
            if (batch > 0) return Math.min(batch, 1000);
            return posSalesHistoryFetchLimit();
        }
        function applySalesHistoryDatePreset(preset) {
            if (preset === '1d' || preset === 'today') {
                window._salesHistoryBatchSize = 0;
            } else if (preset === '90d') {
                window._salesHistoryBatchSize = 0;
            } else if (preset === '7d' || preset === 'week') {
                window._salesHistoryBatchSize = 100;
            } else if (preset === 'month') {
                window._salesHistoryBatchSize = 250;
            } else if (preset === '1y') {
                window._salesHistoryBatchSize = 400;
            } else if (preset === '8y') {
                window._salesHistoryBatchSize = 500;
            } else if (preset === 'all') {
                window._salesHistoryBatchSize = 500;
            }

            if (typeof applyGlobalDatePreset === 'function') {
                applyGlobalDatePreset(preset, 'sales', function() {
                    renderSalesHistory();
                });
            } else {
                // Fallback for extreme cases
                var end = new Date();
                var start = new Date();
                if (preset === '1d') {
                    /* today */
                } else if (preset === '90d') {
                    start.setDate(start.getDate() - 90);
                } else if (preset === '1y') {
                    start.setFullYear(start.getFullYear() - 1);
                } else if (preset === '8y') {
                    start.setFullYear(start.getFullYear() - 8);
                } else if (preset === 'all') {
                    start = new Date(2000, 0, 1);
                } else {
                    applySalesHistoryDateRange();
                    return;
                }
                var sEl = document.getElementById('date-start-sales');
                var eEl = document.getElementById('date-end-sales');
                if (sEl) sEl.value = salesHistoryDateFmt(start);
                if (eEl) eEl.value = salesHistoryDateFmt(end);
                renderSalesHistory();
            }
        }
        window.applySalesHistoryDatePreset = applySalesHistoryDatePreset;
        function updateSalesHistoryMoreUi() {
            var statusEl = document.getElementById('sales-history-more-status');
            var btn = document.getElementById('sales-history-more-btn');
            var count = window._salesHistoryPage ? window._salesHistoryPage.length : 0;
            if (statusEl) {
                statusEl.textContent = count
                    ? ('پیشاندراو: ' + count + (window._salesHistoryHasMore ? ' — زیاتر هەیە' : ' — کۆتایی'))
                    : '—';
            }
            if (btn) {
                btn.style.display = window._salesHistoryHasMore ? '' : 'none';
                btn.disabled = !!window._salesHistoryLoading;
                btn.innerHTML = window._salesHistoryLoading
                    ? '<i class="fas fa-spinner fa-spin"></i> …'
                    : '<i class="fas fa-chevron-down"></i> زیاتر';
            }
        }
        function posLoadExtendedDataUi(section) {
            section = section || 'supplies';
            var btn = document.getElementById('sales-history-extended-btn');
            if (btn) {
                btn.disabled = true;
                btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> …';
            }
            if (typeof posLoadExtendedData !== 'function') {
                if (typeof showToast === 'function') showToast('بارکردنی زیاتر بەردەست نییە.', true);
                return;
            }
            posLoadExtendedData({ section: section, append: true, limit: 3000 }).then(function (data) {
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-database"></i> زیاتر — کڕین/مەسرەف';
                }
                var meta = data && data.extended_meta ? data.extended_meta : {};
                var msg = 'داتای زیاتر بارکرا';
                if (section === 'supplies' && db && db.supplies) msg += ' — کڕین: ' + db.supplies.length;
                if (meta.has_more) msg += ' (هێشتا زیاتر هەیە — دووبارە بکە)';
                if (typeof showToast === 'function') showToast(msg);
            }).catch(function () {
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-database"></i> زیاتر — کڕین/مەسرەف';
                }
                if (typeof showToast === 'function') showToast('هەڵە لە بارکردنی داتای زیاتر.', true);
            });
        }
        window.posLoadExtendedDataUi = posLoadExtendedDataUi;
        function salesHistoryDateFmt(d) {
            var pad = function(n) { return String(n).padStart(2, '0'); };
            return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
        }
        function applySalesHistoryDateRange(daysBack) {
            var sEl = document.getElementById('date-start-sales');
            var eEl = document.getElementById('date-end-sales');
            if (!sEl || !eEl) return;
            var days = daysBack != null ? daysBack : posSalesHistoryDefaultDays();
            var end = new Date();
            var start = new Date();
            start.setDate(start.getDate() - days);
            eEl.value = salesHistoryDateFmt(end);
            sEl.value = salesHistoryDateFmt(start);
        }
        function ensureSalesHistoryDateDefaults() {
            var sEl = document.getElementById('date-start-sales');
            var eEl = document.getElementById('date-end-sales');
            if (!sEl || !eEl) return;
            if (sEl.value && eEl.value) return;
            applySalesHistoryDateRange();
        }
        function filterSalesHistoryLocal(dates, q, offset, limit) {
            if (!db || typeof getAllSales !== 'function') return { rows: [], hasMore: false };
            dates = dates || getSalesHistoryDateParams();
            offset = offset || 0;
            limit = limit || posSalesHistoryFetchLimit();
            q = (q || '').trim().toLowerCase();
            var dtStart = dates.date_from ? new Date(dates.date_from + 'T00:00:00') : null;
            var dtEnd = dates.date_to ? new Date(dates.date_to + 'T23:59:59') : null;
            var cashierName = '';
            if (currentUser && currentUser.role !== 'admin') {
                cashierName = (currentUser.name || '').trim();
            }
            var pool = getAllSales(true).filter(function(s) {
                if (!s) return false;
                var sd = parseSQLDate(s.date || s.created_at);
                if (!sd || isNaN(sd.getTime())) return false;
                var t = sd.getTime();
                if (dtStart && t < dtStart.getTime()) return false;
                if (dtEnd && t > dtEnd.getTime()) return false;
                if (cashierName && String(s.cashier || '').trim() !== cashierName) return false;
                if (!q) return true;
                if (/^\d+$/.test(q) && String(s.id) === q) return true;
                var blob = (String(s.cashier || '') + ' ' + (s.customer || '') + ' ' + JSON.stringify(s.items || [])).toLowerCase();
                return blob.indexOf(q) !== -1;
            });
            pool.sort(function(a, b) {
                return parseSQLDate(b.date || b.created_at) - parseSQLDate(a.date || a.created_at);
            });
            var slice = pool.slice(offset, offset + limit + 1);
            var hasMore = slice.length > limit;
            if (hasMore) slice.pop();
            return { rows: slice, hasMore: hasMore, source: 'local' };
        }
        function salesHistoryShowError(list, msg, tryLocal) {
            if (!list) return;
            var hint = tryLocal ? '<p style="margin-top:8px; font-size:0.85rem; color:var(--text-muted);">هەوڵ دەدرێت لە کۆگای ناوخۆیی پیشان بدرێت…</p>' : '';
            list.innerHTML = '<p style="text-align:center; color:var(--danger); padding:20px;">' + escapeHtml(msg || 'هەڵە لە بارکردنی مێژوو.') + '</p>' + hint;
        }
        function getSalesHistoryDateParams() {
            ensureSalesHistoryDateDefaults();
            var sEl = document.getElementById('date-start-sales');
            var eEl = document.getElementById('date-end-sales');
            return {
                date_from: sEl ? sEl.value : '',
                date_to: eEl ? eEl.value : ''
            };
        }
        function buildSalesHistoryQueryParams(offset, q) {
            var dates = getSalesHistoryDateParams();
            var params = new URLSearchParams();
            params.set('action', 'get_sales_history');
            if (dates.date_from) params.set('date_from', dates.date_from);
            if (dates.date_to) params.set('date_to', dates.date_to);
            params.set('limit', String(posSalesHistoryActiveLimit()));
            params.set('offset', String(offset || 0));
            // Archive only for wide ranges — same-day / short lookback stays fast
            var useArchive = '0';
            if (dates.date_from && dates.date_to) {
                var a = new Date(dates.date_from + 'T00:00:00');
                var b = new Date(dates.date_to + 'T00:00:00');
                var daySpan = Math.round((b - a) / 86400000);
                if (daySpan > 7) useArchive = '1';
            }
            params.set('include_archive', useArchive);
            if (q) params.set('q', q);
            return params.toString();
        }
        function fetchSaleRecordById(id, cb) {
            if (!id) { if (typeof cb === 'function') cb(null); return; }
            window._saleDetailCache = window._saleDetailCache || {};
            if (window._saleDetailCache[id]) {
                var cached = window._saleDetailCache[id];
                if (typeof enrichSaleForPrint === 'function') enrichSaleForPrint(cached);
                if (typeof cb === 'function') cb(cached);
                return;
            }
            fetch('?action=get_sale_record&id=' + encodeURIComponent(id))
                .then(function(r) { return r.json(); })
                .then(function(d) {
                    if (d.status === 'success' && d.sale) {
                        if (typeof enrichSaleForPrint === 'function') enrichSaleForPrint(d.sale);
                        window._saleDetailCache[id] = d.sale;
                        if (typeof cb === 'function') cb(d.sale);
                    } else if (typeof cb === 'function') cb(null);
                })
                .catch(function() { if (typeof cb === 'function') cb(null); });
        }
        function withSaleRecord(id, fn) {
            if (typeof fn !== 'function') return;
            var want = String(id);
            var local = null;
            // Prefer sale already shown in daily summary (has items)
            try {
                if (window._dailySummarySalesById && window._dailySummarySalesById[want]) {
                    local = window._dailySummarySalesById[want];
                }
            } catch (_eDs) {}
            if (!local && typeof getAllSales === 'function') {
                local = getAllSales(true).find(function(s) { return String(s.id) === want; }) || null;
            }
            if (!local && window.db && Array.isArray(db.sales)) {
                local = db.sales.find(function(s) { return String(s.id) === want; }) || null;
            }
            if (local && local.items && local.items.length) {
                if (typeof enrichSaleForPrint === 'function') enrichSaleForPrint(local);
                fn(local);
                return;
            }
            fetchSaleRecordById(id, fn);
        }
        window.withSaleRecord = withSaleRecord;
        window.fetchSaleRecordById = fetchSaleRecordById;
        function computeSaleInvoiceProfit(s) {
            var items = (s && Array.isArray(s.items)) ? s.items : [];
            var map = window._salesHistoryProductById;
            if (!map || !(map instanceof Map)) {
                map = new Map();
                var prods = (window.db && Array.isArray(db.products)) ? db.products : [];
                for (var pi = 0; pi < prods.length; pi++) {
                    if (prods[pi] && prods[pi].id != null) map.set(Number(prods[pi].id), prods[pi]);
                }
                window._salesHistoryProductById = map;
            }
            var resolveCost = (typeof resolveSaleLineCost === 'function')
                ? resolveSaleLineCost
                : function (i) { return parseFloat(i && i.cost) || 0; };
            var getQty = (typeof getSaleLineQty === 'function')
                ? getSaleLineQty
                : function (i) {
                    var q = parseFloat(i && (i.qty != null ? i.qty : i.count));
                    return (!isNaN(q) && q > 0) ? q : 1;
                };
            var cogs = 0;
            var reservedByPid = {};
            for (var i = 0; i < items.length; i++) {
                var it = items[i];
                var pid = it && it.id != null ? Number(it.id) : 0;
                var reserved = (pid && reservedByPid[pid]) ? reservedByPid[pid] : 0;
                cogs += resolveCost(it, map, { sale: s, useFifo: true, reservedPieces: reserved }) * getQty(it);
                if (pid) {
                    var p = map && map.get ? map.get(pid) : null;
                    var addPcs = (typeof piecesInSaleUnit === 'function' && p)
                        ? piecesInSaleUnit(p, it.saleUnit || 'piece') * getQty(it)
                        : getQty(it);
                    reservedByPid[pid] = reserved + addPcs;
                }
            }
            var total = parseFloat(s && s.total) || 0;
            return { profit: total - cogs, cogs: cogs, total: total };
        }
        window.computeSaleInvoiceProfit = computeSaleInvoiceProfit;

        function showSaleProfitTip(btn, evt, opts) {
            opts = opts || {};
            try {
                if (evt && evt.stopPropagation) evt.stopPropagation();
                if (evt && evt.cancelable && (evt.type === 'pointerdown' || evt.type === 'click')) evt.preventDefault();
            } catch (e0) {}
            if (!btn) return;
            if (typeof canViewInvoiceProfit === 'function') {
                if (!canViewInvoiceProfit()) return;
            } else if (typeof canViewProfit === 'function' && !canViewProfit()) {
                return;
            }
            var sticky = !!opts.sticky;
            var sid = btn.getAttribute('data-sale-id');

            function paintTip(s) {
                var profitLabel = (typeof t === 'function') ? t('sale_hist_profit') : 'قازانج';
                var costLabel = (typeof t === 'function') ? t('sale_hist_invoice_cost') : 'کرینا وەسڵێ';
                var tip = (typeof ensurePosCostTipEl === 'function')
                    ? ensurePosCostTipEl()
                    : (function () {
                        var el = document.getElementById('pos-cost-hover-tip');
                        if (!el) {
                            el = document.createElement('div');
                            el.id = 'pos-cost-hover-tip';
                            el.className = 'pos-cost-hover-tip';
                            el.setAttribute('role', 'tooltip');
                            document.body.appendChild(el);
                        }
                        return el;
                    })();
                if (!s) {
                    tip.textContent = profitLabel + ': —';
                } else {
                    var calc = computeSaleInvoiceProfit(s);
                    var fxOpts = typeof fxUsdRateFormatOpts === 'function' ? fxUsdRateFormatOpts(s) : undefined;
                    var fmt = function (n) {
                        return (typeof formatCurrency === 'function') ? formatCurrency(n, fxOpts) : String(Math.round(n));
                    };
                    tip.innerHTML =
                        '<div class="pos-tip-row"><span class="pos-tip-lab">' + profitLabel + '</span><span class="pos-tip-val">' + fmt(calc.profit) + '</span></div>' +
                        '<div class="pos-tip-row"><span class="pos-tip-lab">' + costLabel + '</span><span class="pos-tip-val">' + fmt(calc.cogs) + '</span></div>';
                }
                if (sticky) tip.classList.add('is-sticky');
                else tip.classList.remove('is-sticky');
                window.__posCostTipSticky = sticky;
                window.__posCostTipActiveBtn = btn;
                if (typeof placePosCostTip === 'function') placePosCostTip(tip, btn);
                else {
                    tip.style.zIndex = '600000';
                    tip.style.visibility = 'hidden';
                    tip.style.display = 'block';
                    var rect = btn.getBoundingClientRect();
                    var tipW = tip.offsetWidth || 180;
                    var tipH = tip.offsetHeight || 48;
                    var left = rect.left + (rect.width / 2) - (tipW / 2);
                    var top = rect.top - tipH - 8;
                    if (left < 6) left = 6;
                    if (left + tipW > window.innerWidth - 6) left = window.innerWidth - tipW - 6;
                    if (top < 6) top = rect.bottom + 8;
                    tip.style.left = Math.round(left) + 'px';
                    tip.style.top = Math.round(top) + 'px';
                    tip.style.visibility = 'visible';
                }
                if (sticky && typeof bindPosCostTipOutside === 'function') {
                    bindPosCostTipOutside();
                } else if (sticky) {
                    if (!window.__posCostTipOutsideBound) {
                        window.__posCostTipOutsideBound = true;
                        setTimeout(function () {
                            document.addEventListener('pointerdown', function outside(e) {
                                if (typeof hidePosCostTipOutside === 'function') hidePosCostTipOutside(e);
                                else if (typeof hidePosCostTip === 'function') hidePosCostTip();
                            }, true);
                        }, 0);
                    }
                }
            }

            var rows = window._salesHistoryPage || [];
            var s = null;
            for (var i = 0; i < rows.length; i++) {
                if (String(rows[i].id) === String(sid)) { s = rows[i]; break; }
            }
            if (!s && window.db && Array.isArray(db.sales)) {
                for (var j = 0; j < db.sales.length; j++) {
                    if (String(db.sales[j].id) === String(sid)) { s = db.sales[j]; break; }
                }
            }
            if (s && s.items && s.items.length) {
                paintTip(s);
                return;
            }
            if (typeof withSaleRecord === 'function' && sid) {
                withSaleRecord(parseInt(sid, 10) || sid, function (full) {
                    paintTip(full || s);
                });
                return;
            }
            paintTip(s);
        }
        window.showSaleProfitTip = showSaleProfitTip;

        function toggleSaleProfitTip(btn, evt) {
            try {
                if (evt && evt.stopPropagation) evt.stopPropagation();
                if (evt && evt.preventDefault) evt.preventDefault();
            } catch (e0) {}
            if (!btn) return;
            if (window.__posCostTipSticky && window.__posCostTipActiveBtn === btn && document.getElementById('pos-cost-hover-tip')) {
                if (typeof hidePosCostTip === 'function') hidePosCostTip();
                return;
            }
            showSaleProfitTip(btn, evt, { sticky: true });
        }
        window.toggleSaleProfitTip = toggleSaleProfitTip;

        if (typeof window.hidePosCostTip !== 'function') {
            window.hidePosCostTip = function () {
                var tip = document.getElementById('pos-cost-hover-tip');
                if (tip && tip.parentNode) tip.parentNode.removeChild(tip);
                window.__posCostTipActiveBtn = null;
                window.__posCostTipSticky = false;
            };
        }

        function posHistWarehouseName(s) {
            if (!s) return '';
            var name = String(s.warehouse_name || '').trim();
            if (name) return name;
            if (s.items && s.items.length) {
                var it0 = s.items[0];
                if (it0 && it0.warehouse_name) return String(it0.warehouse_name).trim();
            }
            var id = parseInt(s.warehouse_id, 10) || 0;
            if (!id && s.items && s.items[0]) id = parseInt(s.items[0].warehouse_id, 10) || 0;
            if (id > 0 && typeof db !== 'undefined' && db && Array.isArray(db.warehouses)) {
                var w = db.warehouses.find(function(x) { return x && parseInt(x.id, 10) === id; });
                if (w) return String(w.name || '').trim();
            }
            return '';
        }
        function _dHist(k, fb) {
            if (typeof t !== 'function') return fb;
            var v = t(k);
            return (v && v !== k) ? v : fb;
        }
        function posHistSaleHasReturn(s) {
            if (!s) return false;
            if (Number(s.has_return) === 1 || Number(s.return_count) > 0) return true;
            var id = Number(s.id);
            var list = (typeof db !== 'undefined' && db && Array.isArray(db.returns)) ? db.returns : [];
            return list.some(function(r) { return r && Number(r.sale_id) === id; });
        }
        function posHistSaleHasEdits(s) {
            return !!(s && (Number(s.has_edits) === 1 || Number(s.edit_count) > 0));
        }
        function renderSalesHistoryTable(rows, meta) {
            meta = meta || {};
            var list = document.getElementById('sales-history-list');
            if (!list) return;
            if (!rows || rows.length === 0) {
                list.innerHTML = '<p style="text-align:center; color:var(--text-muted); padding:20px;">چ وەسڵ نەهاتنە دیتن بۆ ئەم بەروارانە. بەروارەکان فراوان بکە یان «نوێکردنەوە» بکە.</p>';
                return;
            }
            try {
                window._salesHistoryProductById = null;
                var canSeeProfit = (typeof canViewInvoiceProfit === 'function')
                    ? canViewInvoiceProfit()
                    : ((typeof canViewProfit === 'function') ? canViewProfit() : (currentUser && currentUser.role === 'admin'));
                var profitTip = (typeof t === 'function') ? t('sale_hist_profit_hold') : 'قازانج و کرینا وەسڵێ — کلیک بکە';
                var html = '<table class="hist-table report-table"><thead><tr><th>ID</th><th>بەروار</th><th>کریار</th><th>ئایتم</th><th>جۆر</th><th style="text-align:left;">کۆم</th><th style="text-align:center;">کردار</th></tr></thead><tbody>';
                html += rows.map(function(s) {
                    var itemCount = s.items ? s.items.length : 0;
                    var itemNames = s.items ? s.items.map(function(i) { return i.name; }).slice(0, 2).join(', ') + (itemCount > 2 ? '...' : '') : '-';
                    var payMethod = s.payment_method === 'debt' ? '<span style="color:red; font-weight:bold;">قەرز</span>' : (s.payment_method === 'fib' || s.payment_method === 'bank' || s.payment_method === 'bankcard' ? '<span style="color:#2563eb; font-weight:bold;">FIB</span>' : (s.payment_method === 'split' ? '<span style="color:#f59e0b; font-weight:bold;">قەرز + نەقد</span>' : '<span style="color:green">نەقد</span>'));
                    var notVoided = !s.is_returned;
                    var fxOpts = typeof fxUsdRateFormatOpts === 'function' ? fxUsdRateFormatOpts(s) : undefined;
                    var canEditSale = notVoided && (
                        (typeof currentUser !== 'undefined' && currentUser && (currentUser.role === 'admin' || currentUser.role === 'manager')) ||
                        (typeof checkPermission === 'function' && checkPermission('returns_manage'))
                    );
                    var editSaleBtn = canEditSale ? '<button class="btn btn-sm btn-primary" onclick="startEditSaleInPos(' + s.id + ')" title="دەستکاری ئایتم — تەعدیل لە سەبەتە"><i class="fas fa-edit"></i></button>' : '';
                    var profitBtn = '';
                    if (canSeeProfit) {
                        profitBtn = '<button type="button" class="btn btn-sm pos-sale-profit-btn" data-perm="view_profit" data-sale-id="' + s.id + '"' +
                            ' onpointerenter="showSaleProfitTip(this,event)"' +
                            ' onpointerleave="if(!window.__posCostTipSticky)hidePosCostTip()"' +
                            ' onclick="toggleSaleProfitTip(this,event)"' +
                            ' title="' + escapeHtml(profitTip) + '" aria-label="' + escapeHtml(profitTip) + '">' +
                            '<i class="fas fa-coins" aria-hidden="true"></i></button>';
                    }
                    var badges = '';
                    if (!notVoided) {
                        badges += '<span class="hist-sale-badge hist-sale-badge--void">' + escapeHtml(_dHist('sale_hist_badge_void', 'ژێبرای')) + '</span>';
                    }
                    if (posHistSaleHasReturn(s)) {
                        badges += '<span class="hist-sale-badge hist-sale-badge--return">' + escapeHtml(_dHist('sale_hist_badge_return', 'زڤڕاندن')) + '</span>';
                    }
                    if (posHistSaleHasEdits(s)) {
                        badges += '<span class="hist-sale-badge hist-sale-badge--edit">' + escapeHtml(_dHist('sale_hist_badge_edit', 'تەعدیلکری')) + '</span>';
                    }
                    var whName = posHistWarehouseName(s);
                    var whHtml = whName
                        ? ('<div class="hist-sale-wh" title="' + escapeHtml(_dHist('sale_hist_warehouse', 'کوگەه')) + '"><i class="fas fa-warehouse"></i> ' + escapeHtml(whName) + '</div>')
                        : '';
                    var adjTitle = escapeHtml(_dHist('sale_hist_print_adjust', 'چاپا تەعدیل / ژێبرن'));
                    var showAdjPrint = !notVoided || posHistSaleHasReturn(s) || posHistSaleHasEdits(s);
                    var adjPrintBtn = showAdjPrint
                        ? '<button class="btn btn-sm btn-warning" onclick="printSaleAdjustmentSlip(' + s.id + ')" title="' + adjTitle + '"><i class="fas fa-file-invoice"></i></button>'
                        : '';
                    return '<tr class="' + (!notVoided ? 'hist-sale-row--void' : '') + '"><td><b>#' + s.id + '</b>' + (badges ? ('<div class="hist-sale-badges">' + badges + '</div>') : '') + whHtml + '</td><td style="font-size:0.75rem; color:var(--text-muted);">' + (typeof formatPosDateTime === 'function' ? formatPosDateTime(s.date || s.created_at, typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ') : parseSQLDate(s.date || s.created_at).toLocaleString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ')) + '</td><td><span style="background:rgba(16,185,129,0.05); padding:4px 8px; border-radius:6px; font-weight:500;">' + escapeHtml(s.customer || 'General') + '</span></td><td title="' + (s.items ? escapeHtml(s.items.map(function(i) { return i.name; }).join(', ')) : '') + '">' + escapeHtml(itemNames) + ' <span style="background:var(--input-bg); border:1px solid var(--border); padding:2px 6px; border-radius:6px; font-size:0.75rem; color:var(--text-muted);">(' + itemCount + ')</span></td><td>' + payMethod + '</td><td style="font-weight:900; color:var(--brand); font-size:1rem;">' + formatCurrency(s.total, fxOpts) + '</td><td><div style="display:flex; gap:4px; flex-wrap:wrap;">' + profitBtn + editSaleBtn + '<button class="btn btn-sm btn-dark" onclick="reprintBillFromHistory(' + s.id + ')" title="چاپکرن"><i class="fas fa-print"></i></button>' + adjPrintBtn + (notVoided ? '<button class="btn btn-sm btn-return-invoice" onclick="openSalesReturnWithInvoice(' + s.id + ')" title="زڤراندنا وەسڵ"><i class="fas fa-undo"></i></button>' : '') + '</div></td></tr>';
                }).join('');
                html += '</tbody></table>';
                if (meta.localFallback) {
                    html = '<p style="text-align:center; font-size:0.8rem; color:var(--text-muted); padding:8px 12px; margin:0 0 8px 0; background:var(--input-bg); border-radius:8px;"><i class="fas fa-database"></i> پیشاندان لە کۆگای ناوخۆیی (پەیوەندی سێرڤەر سنووردارە)</p>' + html;
                }
                list.innerHTML = html;
                updateSalesHistoryMoreUi();
                if (db && db.settings && db.settings.language === 'ar') {
                    var reportsView = document.getElementById('view-reports');
                    if (reportsView && typeof localizeHardcodedUiText === 'function') localizeHardcodedUiText(reportsView);
                }
            } catch (renderErr) {
                console.error('renderSalesHistoryTable', renderErr);
                salesHistoryShowError(list, 'هەڵە لە پیشاندانی مێژوو — دووبارە هەوڵ بدە.');
            }
        }
        function applySalesHistoryRows(rows, append, meta) {
            window._salesHistoryHasMore = !!(meta && meta.hasMore);
            window._salesHistoryPage = append && window._salesHistoryPage ? window._salesHistoryPage.concat(rows) : rows;
            window._salesHistoryLocalOnly = !!(meta && meta.localFallback);
            window._fullSalesHistory = null;
            renderSalesHistoryTable(window._salesHistoryPage, meta);
        }
        function salesHistoryTryLocalFallback(opts, append, list) {
            var dates = getSalesHistoryDateParams();
            var q = (opts.q != null ? opts.q : '').trim();
            var offset = append && window._salesHistoryPage ? window._salesHistoryPage.length : 0;
            var loc = filterSalesHistoryLocal(dates, q, offset, posSalesHistoryActiveLimit());
            if (loc.rows && loc.rows.length) {
                applySalesHistoryRows(loc.rows, append, { hasMore: loc.hasMore, localFallback: true });
                return true;
            }
            if (list && !append) {
                list.innerHTML = '<p style="text-align:center; color:var(--text-muted); padding:28px;">چ وەسڵ نەهاتنە دیتن بۆ ئەم ڕۆژە.<br><span style="font-size:0.85rem;">بەروار بگۆڕە یان دووبارە هەوڵ بدە.</span></p>';
                updateSalesHistoryMoreUi();
            }
            return false;
        }
        function fetchSalesHistoryForUi(opts) {
            opts = opts || {};
            var append = !!opts.append;
            var q = (opts.q != null ? opts.q : (document.getElementById('sales-search-input') ? document.getElementById('sales-search-input').value : '')).trim();
            var list = document.getElementById('sales-history-list');
            window._salesHistoryLoading = true;
            updateSalesHistoryMoreUi();

            // Paint local rows immediately (even large shop) so modal never sits on spinner
            if (!append) {
                var paintedLocal = false;
                if (typeof filterSalesHistoryLocal === 'function') {
                    try {
                        var locQuick = filterSalesHistoryLocal(getSalesHistoryDateParams(), q, 0, posSalesHistoryActiveLimit());
                        if (locQuick && locQuick.rows && locQuick.rows.length) {
                            applySalesHistoryRows(locQuick.rows, false, { hasMore: !!locQuick.hasMore, localFallback: true });
                            paintedLocal = true;
                        }
                    } catch (_eLoc) {}
                }
                if (!paintedLocal && list) {
                    var keepRows = window._salesHistoryPage && window._salesHistoryPage.length;
                    if (!keepRows) {
                        list.innerHTML = '<div style="text-align:center; padding:40px; background:var(--card);"><i class="fas fa-spinner fa-spin fa-2x" style="color:var(--brand);"></i><p style="margin-top:15px; color:var(--text-muted);">' + escapeHtml(typeof t === 'function' ? t('msg_data_loading') : 'داتا باردەکرێت…') + '</p><p style="margin-top:8px; font-size:0.8rem; color:var(--text-muted);">١ ڕۆژ — چاوەڕێی سێرڤەر…</p></div>';
                    }
                }
            }

            var offset = append && window._salesHistoryPage ? window._salesHistoryPage.length : 0;
            var seq = ++_salesHistoryFetchSeq;
            if (append && window._salesHistoryLocalOnly) {
                var locMore = filterSalesHistoryLocal(getSalesHistoryDateParams(), q, offset, posSalesHistoryActiveLimit());
                window._salesHistoryLoading = false;
                applySalesHistoryRows(locMore.rows, true, { hasMore: locMore.hasMore, localFallback: true });
                return;
            }

            var ctrl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
            var timedOut = false;
            var toId = setTimeout(function () {
                timedOut = true;
                if (ctrl) try { ctrl.abort(); } catch (_eAb) {}
            }, 4000);

            var fetchOpts = { credentials: 'same-origin', cache: 'no-store' };
            if (ctrl) fetchOpts.signal = ctrl.signal;

            fetch('?' + buildSalesHistoryQueryParams(offset, q), fetchOpts)
                .then(function(res) {
                    return res.text().then(function(text) {
                        var data = {};
                        try {
                            data = text ? JSON.parse(text) : {};
                        } catch (parseErr) {
                            data = { status: 'error', message: 'parse', _raw: (text || '').slice(0, 200) };
                        }
                        if (!res.ok && data.status !== 'success') {
                            data.status = data.status || 'error';
                            if (!data.message) data.message = 'HTTP ' + res.status;
                        }
                        return data;
                    });
                })
                .then(function(data) {
                    clearTimeout(toId);
                    if (seq !== _salesHistoryFetchSeq) return;
                    window._salesHistoryLoading = false;
                    if (data.status === 'success') {
                        var rows = data.sales || [];
                        applySalesHistoryRows(rows, append, { hasMore: !!data.has_more });
                        return;
                    }
                    var msg = data.message || data.status || 'هەڵە لە بارکردنی مێژوو.';
                    if (data.status === 'license_blocked') msg = 'پەیوەندی ڕێگەپێدان (لایسنس) — ' + (data.message || '');
                    if (data.status === 'device_blocked') msg = 'ئامێر ڕێگری کراوە — ' + (data.message || '');
                    if (data.status === 'error' && data.message === 'Login required') msg = 'دووبارە بچۆ ژوورەوە.';
                    if (!append && window._salesHistoryPage && window._salesHistoryPage.length) {
                        updateSalesHistoryMoreUi();
                        return;
                    }
                    salesHistoryShowError(list, msg, true);
                    salesHistoryTryLocalFallback({ q: q }, append, list);
                })
                .catch(function(err) {
                    clearTimeout(toId);
                    if (seq !== _salesHistoryFetchSeq) return;
                    window._salesHistoryLoading = false;
                    updateSalesHistoryMoreUi();
                    if (!append && window._salesHistoryPage && window._salesHistoryPage.length) {
                        return;
                    }
                    console.warn('fetchSalesHistoryForUi', timedOut ? 'timeout' : err);
                    salesHistoryShowError(list, timedOut
                        ? 'سێرڤەر خاو بوو — داتای ناوخۆیی بەکاردەهێنرێت.'
                        : 'پەیوەندی سێرڤەر نەگەیشت — داتای ناوخۆیی بەکاردەهێنرێت.', true);
                    salesHistoryTryLocalFallback({ q: q }, append, list);
                });
        }
        function loadMoreSalesHistory() {
            if (window._salesHistoryLoading) return;
            var q = document.getElementById('sales-search-input') ? document.getElementById('sales-search-input').value : '';
            fetchSalesHistoryForUi({ append: true, q: q });
        }
        window.loadMoreSalesHistory = loadMoreSalesHistory;
        function resetSalesHistoryDateFilter() {
            if (typeof resetDateFilter === 'function') {
                resetDateFilter('sales', renderSalesHistory);
            } else {
                applySalesHistoryDateRange();
                renderSalesHistory();
            }
        }
        function filterHistory(q) {
            if (_salesHistoryFetchTimer) clearTimeout(_salesHistoryFetchTimer);
            _salesHistoryFetchTimer = setTimeout(function() {
                fetchSalesHistoryForUi({ q: (q || '').trim() });
            }, typeof window.isPosCpuSaveMode === 'function' && window.isPosCpuSaveMode() ? 600 : 350);
        }
        function renderSalesHistory() {
            if (typeof renderShiftSummary === 'function') renderShiftSummary();
            fetchSalesHistoryForUi({});
        }
        function updateReturnsHistoryMoreUi() {
            var statusEl = document.getElementById('returns-history-more-status');
            var btn = document.getElementById('returns-history-more-btn');
            var count = window._returnsHistoryPage ? window._returnsHistoryPage.length : 0;
            if (statusEl) {
                statusEl.textContent = count
                    ? ('پیشاندراو: ' + count + (window._returnsHistoryHasMore ? ' — زیاتر هەیە' : ' — کۆتایی'))
                    : '—';
            }
            if (btn) {
                btn.style.display = window._returnsHistoryHasMore ? '' : 'none';
                btn.disabled = !!window._returnsHistoryLoading;
                btn.innerHTML = window._returnsHistoryLoading
                    ? '<i class="fas fa-spinner fa-spin"></i> …'
                    : '<i class="fas fa-chevron-down"></i> زیاتر';
            }
        }
        function renderReturnsHistoryTable(rows) {
            const container = document.getElementById('returns-history-list');
            if (!container) return;
            rows = rows || [];
            var mode = window._returnsHistoryMode || 'returns';
            var isVoidRow = function(r) {
                if (!r) return false;
                if (r.type === 'void') return true;
                var note = String(r.note || '');
                return note.indexOf('Deleted Invoice') !== -1 || note.indexOf('ژێبرنا وەسڵ') !== -1;
            };
            if (mode === 'void') {
                rows = rows.filter(isVoidRow);
            } else if (mode === 'returns') {
                rows = rows.filter(function(r) { return !isVoidRow(r); });
            }
            if (!rows.length) {
                var emptyMsg = mode === 'void' ? 'چ وەسڵێن ژێبری نینن.' : 'چ زڤڕاندن نینن.';
                container.innerHTML = '<div style="text-align:center; color:var(--text-muted); padding:32px; background:var(--input-bg); border-radius:12px; border:1px dashed var(--border);"><i class="fas fa-inbox" style="font-size:2rem; opacity:0.5;"></i><p style="margin:12px 0 0 0;">' + emptyMsg + '</p></div>';
                updateReturnsHistoryMoreUi();
                return;
            }
            const totalCount = rows.length;
            const totalAmount = rows.reduce((s, r) => s + (parseFloat(r.total) || 0), 0);
            let html = `
            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:12px; margin-bottom:16px;">
                <div style="background:linear-gradient(135deg,#ef4444,#b91c1c); color:white; padding:14px 16px; border-radius:12px; box-shadow:0 2px 8px rgba(0,0,0,0.1);">
                    <div style="font-size:0.8rem; opacity:0.9;">ژمارا زڤڕاندنان</div>
                    <div style="font-size:1.4rem; font-weight:700;">${totalCount}</div>
                </div>
                <div style="background:linear-gradient(135deg,#0ea5e9,#0369a1); color:white; padding:14px 16px; border-radius:12px; box-shadow:0 2px 8px rgba(0,0,0,0.1);">
                    <div style="font-size:0.8rem; opacity:0.9;">کۆی پارە ژێبراو</div>
                    <div style="font-size:1.2rem; font-weight:700;">${formatCurrency(totalAmount)} ${getCurrencySymbol()}</div>
                </div>
            </div>
            <div style="overflow-x:auto; border:1px solid var(--border); border-radius:12px; background:var(--card);">
            <table class="report-table" style="font-size:0.85rem; width:100%; margin:0;">
                <thead>
                    <tr style="background:var(--input-bg);">
                        <th style="padding:12px 10px; border-bottom:1px solid var(--border);">#</th>
                        <th style="padding:12px 10px; border-bottom:1px solid var(--border);">بەروار (Date)</th>
                        <th style="padding:12px 10px; border-bottom:1px solid var(--border);">وەسڵ (Receipt)</th>
                        <th style="padding:12px 10px; border-bottom:1px solid var(--border);">ئایتم (Items)</th>
                        <th style="padding:12px 10px; border-bottom:1px solid var(--border);">تێبینی (Note)</th>
                        <th style="padding:12px 10px; border-bottom:1px solid var(--border); color:#ef4444; font-weight:900;">کۆم (Total)</th>
                        <th style="padding:12px 10px; border-bottom:1px solid var(--border);">کردار (Actions)</th>
                    </tr>
                </thead>
                <tbody>`;
            html += rows.map(r => {
                const itemCount = r.items ? r.items.length : 0;
                const itemNames = r.items ? r.items.map(i => i.name).slice(0, 2).join(', ') + (itemCount > 2 ? '...' : '') : '-';
                const isVoid = r.type === 'void';
                const badge = isVoid ? '<span style="background:#ef4444; color:white; padding:2px 8px; border-radius:6px; font-size:0.7rem;">ژێبراو</span>' : '<span style="background:#10b981; color:white; padding:2px 8px; border-radius:6px; font-size:0.7rem;">زڤڕاندن</span>';
                const saleLink = (r.sale_id != null && r.sale_id !== '' && parseInt(r.sale_id, 10) > 0) ? '<span style="background:var(--input-bg); padding:4px 8px; border-radius:6px; font-size:0.8rem;" title="وەسڵا سەرەتایی">#'+ parseInt(r.sale_id, 10) +'</span>' : '<span style="color:var(--text-muted);">—</span>';
                return `
                <tr style="border-bottom:1px solid var(--border); ${isVoid ? 'background:rgba(239,68,68,0.06);' : ''}">
                    <td style="padding:10px;"><b>#${r.id}</b></td>
                    <td style="padding:10px;">${new Date(r.date).toLocaleString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ')}</td>
                    <td style="padding:10px;">${saleLink}</td>
                    <td style="padding:10px;" title="${r.items ? r.items.map(i=>i.name).join(', ') : ''}">${escapeHtml(itemNames)} <span style="color:var(--text-muted); font-size:0.8rem;">(${itemCount})</span></td>
                    <td style="padding:10px; max-width:140px; overflow:hidden; text-overflow:ellipsis;">${escapeHtml((r.note || '').slice(0, 40))}${(r.note && r.note.length > 40) ? '...' : ''}</td>
                    <td style="padding:10px; color:#ef4444; font-weight:bold;">${formatCurrency(r.total, typeof fxUsdRateFormatOpts === 'function' ? fxUsdRateFormatOpts(r) : undefined)}</td>
                    <td style="padding:10px;">${badge}
                        <button class="btn btn-sm btn-info" style="margin-right:4px;" onclick="showReturnDetails(${r.id})" title="وردەکاری"><i class="fas fa-eye"></i></button>
                        <button class="btn btn-sm btn-dark" onclick="printReturnReceipt(${r.id})" title="چاپ"><i class="fas fa-print"></i></button>
                    </td>
                </tr>`;
            }).join('');
            html += '</tbody></table></div>';
            container.innerHTML = html;
            updateReturnsHistoryMoreUi();
            if (db && db.settings && db.settings.language === 'ar') {
                var reportsView = document.getElementById('view-reports');
                if (reportsView && typeof localizeHardcodedUiText === 'function') localizeHardcodedUiText(reportsView);
            }
        }
        function getReturnsHistoryDateParams() {
            var sEl = document.getElementById('date-start-returns');
            var eEl = document.getElementById('date-end-returns');
            var today = (typeof getTodayDateInputValue === 'function')
                ? getTodayDateInputValue()
                : salesHistoryDateFmt(new Date());
            return {
                date_from: sEl && sEl.value ? sEl.value : today,
                date_to: eEl && eEl.value ? eEl.value : today
            };
        }
        function fetchReturnsHistoryForUi(opts) {
            opts = opts || {};
            var append = !!opts.append;
            var container = document.getElementById('returns-history-list');
            window._returnsHistoryLoading = true;
            updateReturnsHistoryMoreUi();
            if (!append && container) {
                container.innerHTML = '<div style="text-align:center; padding:40px;"><i class="fas fa-spinner fa-spin fa-2x" style="color:var(--brand);"></i></div>';
            }
            var dates = getReturnsHistoryDateParams();
            var offset = append && window._returnsHistoryPage ? window._returnsHistoryPage.length : 0;
            var limit = 300;
            var seq = ++_returnsHistoryFetchSeq;
            var params = new URLSearchParams();
            params.set('action', 'get_returns_history');
            params.set('date_from', dates.date_from);
            params.set('date_to', dates.date_to);
            params.set('limit', String(limit));
            params.set('offset', String(offset));
            var qStr = params.toString();
            var url = (typeof window.posRouterUrl === 'function') ? window.posRouterUrl(qStr) : ('?' + qStr);
            fetch(url, { credentials: 'same-origin', cache: 'no-store' })
                .then(function (r) { return r.json().catch(function () { return { status: 'error' }; }); })
                .then(function (data) {
                    if (seq !== _returnsHistoryFetchSeq) return;
                    window._returnsHistoryLoading = false;
                    if (data.status === 'success') {
                        var rows = data.returns || [];
                        window._returnsHistoryHasMore = !!data.has_more;
                        window._returnsHistoryPage = append && window._returnsHistoryPage
                            ? window._returnsHistoryPage.concat(rows)
                            : rows;
                        renderReturnsHistoryTable(window._returnsHistoryPage);
                        return;
                    }
                    renderReturnsReportLocalFallback(append);
                })
                .catch(function () {
                    if (seq !== _returnsHistoryFetchSeq) return;
                    window._returnsHistoryLoading = false;
                    renderReturnsReportLocalFallback(append);
                });
        }
        function renderReturnsReportLocalFallback(append) {
            if (!db) return;
            if (!db.returns) db.returns = [];
            if (window._returnsHistoryMode === 'void') {
                var voidsOnly = (typeof collectLocalVoidedSalesRows === 'function')
                    ? collectLocalVoidedSalesRows()
                    : getAllSales(true).filter(s => s.is_returned == 1).map(s => ({
                        id: s.id, date: s.date, items: s.items, total: s.total,
                        note: 'ژێبرنا وەسڵێ (Void)', cashier: s.cashier, type: 'void', sale_id: s.id
                    }));
                var sortedV = voidsOnly.filter(r => isDateInScope(r.date || r.created_at, 'returns')).sort((a, b) => new Date(b.date || b.created_at) - new Date(a.date || a.created_at));
                window._returnsHistoryHasMore = false;
                window._returnsHistoryPage = sortedV;
                window._voidedSalesHistoryPage = sortedV;
                if (typeof renderReturnsHistoryModalContent === 'function') renderReturnsHistoryModalContent();
                else renderReturnsHistoryTable(sortedV);
                return;
            }
            const voidedSales = getAllSales(true).filter(s => s.is_returned == 1).map(s => ({
                id: s.id, date: s.date, items: s.items, total: s.total,
                note: 'ژێبرنا وەسڵێ (Void)', cashier: s.cashier, type: 'void'
            }));
            const allReturns = [...db.returns, ...voidedSales];
            const sorted = allReturns.filter(r => isDateInScope(r.date, 'returns')).sort((a, b) => new Date(b.date) - new Date(a.date));
            window._returnsHistoryHasMore = false;
            window._returnsHistoryPage = sorted;
            renderReturnsHistoryTable(sorted);
        }
        function loadMoreReturnsHistory() {
            if (window._returnsHistoryLoading) return;
            fetchReturnsHistoryForUi({ append: true });
        }
        window.loadMoreReturnsHistory = loadMoreReturnsHistory;
        function renderReturnsReport() {
            if (window._returnsHistoryMode === 'void') {
                if (typeof loadVoidedSalesHistoryForUi === 'function') {
                    loadVoidedSalesHistoryForUi({});
                    return;
                }
            }
            fetchReturnsHistoryForUi({});
        }

        function showReturnDetails(id) {
            // FIX: Check both manual returns and voided sales
            let ret = (window._returnsHistoryPage || []).find(r => r.id === id);
            if (!ret && db.returns) ret = db.returns.find(r => r.id === id);
            if(!ret) {
                const sale = getAllSales(true).find(s => s.id === id && s.is_returned == 1);
                if(sale) {
                    ret = { id: sale.id, date: sale.date, items: sale.items, total: sale.total, note: 'ژێبرنا وەسڵێ (Void)', cashier: sale.cashier, type: 'void' };
                }
            }
            if(!ret) return;
            
            const container = document.getElementById('return-details-content');
            const isVoid = ret.type === 'void' || String(ret.note || '').indexOf('Deleted Invoice') !== -1 || String(ret.note || '').indexOf('ژێبرنا وەسڵ') !== -1;
            
            // Group items
            const grouped = {};
            if(ret.items && Array.isArray(ret.items)) {
                ret.items.forEach(i => {
                    const key = i.id + (i.name || '');
                    if(!grouped[key]) grouped[key] = { ...i, count: 0, subtotal: 0 };
                    var lineQ = getItemQty(i);
                    grouped[key].count += lineQ;
                    grouped[key].subtotal += (Number(i.price) || 0) * lineQ;
                });
            }

            container.innerHTML = `
                <div style="background:var(--input-bg); padding:10px; border-radius:8px; margin-bottom:10px; font-size:0.9rem;">
                    ${isVoid ? '<p style="margin:0 0 8px;padding:6px 8px;border-radius:6px;background:rgba(148,163,184,0.2);color:#cbd5e1;font-size:0.85rem;"><b>ژێبرنا وەسڵێ</b> — نە زڤڕاندنا فرۆتنێ</p>' : ''}
                    <p style="margin:5px 0;"><b>ID:</b> #${ret.id}</p>
                    <p style="margin:5px 0;"><b>بەروار:</b> ${new Date(ret.date).toLocaleString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ')}</p>
                    <p style="margin:5px 0;"><b>کاشێر:</b> ${escapeHtml(ret.cashier || 'System')}</p>
                    <p style="margin:5px 0;"><b>تێبینی:</b> ${escapeHtml(isVoid ? 'ژێبرنا وەسڵێ (Void)' : (ret.note || ''))}</p>
                    <h3 style="color:var(--danger); margin-top:10px; border-top:1px solid var(--border); padding-top:5px;">کۆم: ${formatCurrency(ret.total, typeof fxUsdRateFormatOpts === 'function' ? fxUsdRateFormatOpts(ret) : undefined)} ${getCurrencySymbol()}</h3>
                </div>
                <h4 style="margin-bottom:5px;">${isVoid ? 'ئایتمێن وەسڵێ ژێبری:' : 'ئایتمێن زڤڕاندی:'}</h4>
                <div style="background:var(--card); border:1px solid var(--border); border-radius:8px; padding:5px;">
                    ${Object.keys(grouped).length ? Object.values(grouped).map(g => `
                        <div style="display:flex; justify-content:space-between; border-bottom:1px solid var(--border); padding:8px 5px;">
                            <span>${escapeHtml(g.name || 'ئایتم')} ${g.isGift ? '<span style="color:var(--danger); font-size:0.8rem; font-weight:bold;">(دیاری)</span> ' : ''}<span style="background:var(--brand); color:white; padding:0 5px; border-radius:4px; font-size:0.8rem;">x${formatQtyForDisplay(g.count, g)}</span></span>
                            <span style="font-weight:bold;">${g.isGift ? '0' : formatCurrency(g.subtotal)}</span>
                        </div>
                    `).join('') : '<p style="text-align:center;color:var(--text-muted);padding:10px;margin:0;">ئایتم نەدۆزرایەوە</p>'}
                </div>
            `;
            const modal = document.getElementById('return-details-modal');
            var titleEl = document.getElementById('return-details-modal-title');
            var titleTextEl = document.getElementById('return-details-modal-title-text');
            var voidTitle = (typeof t === 'function') ? t('return_details_void_title') : 'وردەکاریێن ژێبرنێ (Void Details)';
            var retTitle = (typeof t === 'function') ? t('return_details_return_title') : 'وردەکاریێن زڤڕاندنێ (Return Details)';
            if (titleTextEl) {
                titleTextEl.textContent = isVoid ? voidTitle : retTitle;
            } else if (titleEl) {
                titleEl.innerHTML = '<i class="fas ' + (isVoid ? 'fa-trash-alt' : 'fa-undo') + '"></i> ' + (isVoid ? voidTitle : retTitle);
            }
            if (titleEl) {
                var icon = titleEl.querySelector('i');
                if (icon) {
                    icon.className = isVoid ? 'fas fa-trash-alt' : 'fas fa-undo';
                }
            }
            if (modal) {
                modal.style.display = 'flex';
                if (typeof window.bringOverlayToFront === 'function') window.bringOverlayToFront(modal);
                else modal.style.zIndex = '10050';
            }
        }

        function openSalesReturnWithInvoice(saleId) {
            withSaleRecord(saleId, function(sale) {
            if (!sale || !sale.items || !sale.items.length) {
                if (typeof showToast === 'function') showToast('وەسڵ نەدۆزرایەوە یان بەتاڵە.', 'error');
                return;
            }
            if (sale.is_returned == 1) {
                if (typeof showToast === 'function') showToast('ئەم وەسڵە پێشتر ژێبراوە.', 'error');
                return;
            }
            window.pendingReturnFromSale = sale;
            if (typeof rememberReturnsSale === 'function') rememberReturnsSale(sale);
            else {
                window._returnsLoadedSale = sale;
                window._returnsSaleById = window._returnsSaleById || {};
                window._returnsSaleById[String(sale.id)] = sale;
            }
            var modal = document.getElementById('sales-history-modal');
            if (modal) modal.style.display = 'none';
            if (typeof closeDailySummaryDetailSheet === 'function') closeDailySummaryDetailSheet();
            if (typeof closeDailyHistoryModal === 'function') closeDailyHistoryModal();
            nav('returns-new');
            });
        }


        function getReturnRecord(id) {
            let ret = (window._returnsHistoryPage || []).find(r => r.id === id);
            if (!ret && db.returns) ret = db.returns.find(r => r.id === id);
            if (!ret) {
                const sale = getAllSales(true).find(s => s.id === id && s.is_returned == 1);
                if (sale) ret = { id: sale.id, date: sale.date, items: sale.items, total: sale.total, note: 'ژێبرنا وەسڵێ (Void)', cashier: sale.cashier, type: 'void' };
            }
            return ret;
        }
        function buildReturnReceiptThermalHtml(ret, printNote) {
            const rc2 = getPrintConfig('return_receipt');
            const thermalFontClasses = typeof getThermalFontClasses === 'function' ? getThermalFontClasses() : '';
            let itemsHtml = '';
            if (ret.items && Array.isArray(ret.items)) {
                const grouped = {};
                ret.items.forEach(i => {
                    const key = i.id + '_' + (i.note || '') + '_' + i.price + '_' + (i.saleUnit || 'piece') + '_' + (i.isGift ? 'gift' : 'normal');
                    if (!grouped[key]) grouped[key] = { id: i.id, name: i.name, price: i.price, count: 0, sub: 0, note: i.note, saleUnit: i.saleUnit || 'piece', productRef: i.productRef || null, isGift: !!i.isGift };
                    const lineQty = typeof getItemQty === 'function' ? getItemQty(i) : Math.max(1, parseFloat(i.qty || i.count) || 1);
                    grouped[key].count += lineQty;
                    grouped[key].sub += (i.isGift ? 0 : (Number(i.price) || 0)) * lineQty;
                });
                itemsHtml = Object.values(grouped).map(g => {
                    const nameHtml = (typeof formatSaleItemNameHtml === 'function') ? formatSaleItemNameHtml(g, { skipPriceTypeLabel: true }) : (escapeHtml(g.name || 'ئایتم') + getSaleItemUnitSuffix(g, { skipPriceTypeLabel: true }));
                    return `<tr><td class="row-item">${nameHtml}${g.note ? `<br><small>* ${escapeHtml(g.note)}</small>` : ''}</td><td class="row-qty" style="text-align:center;">${formatQtyForDisplay(g.count, g)}</td><td class="row-price" style="text-align:left;">${g.isGift ? '0' : formatCurrency(g.sub)}</td></tr>`;
                }).join('');
            }

            const targetId = (ret.target_id && parseInt(ret.target_id, 10) > 0) ? parseInt(ret.target_id, 10) : 0;
            const targetType = (ret.target_type || '').toString();
            let currentDebt = 0;
            if (targetId > 0) {
                if (targetType === 'user') {
                    const u = (db.users || []).find(x => Number(x.id) === targetId);
                    currentDebt = parseFloat(u?.balance || 0) || 0;
                } else {
                    const c = (db.customers || []).find(x => Number(x.id) === targetId);
                    currentDebt = parseFloat(c?.balance || 0) || 0;
                }
            }

            const retTotal = parseFloat(ret.total) || 0;
            let cashPaid = ret.cash_refunded != null ? (parseFloat(ret.cash_refunded) || 0) : 0;
            let debtReduced = ret.debt_adjusted != null ? (parseFloat(ret.debt_adjusted) || 0) : 0;
            if (ret.cash_refunded == null && ret.debt_adjusted == null && ret.sale_id && typeof getSaleReturnFinancialSplit === 'function') {
                const linkedSale = (db.sales || []).find(s => String(s.id) === String(ret.sale_id));
                const split = getSaleReturnFinancialSplit(retTotal, linkedSale);
                cashPaid = split.cashRefunded;
                debtReduced = split.debtAdjusted;
            } else if (ret.cash_refunded == null && ret.debt_adjusted == null) {
                const paymentMethod = (ret.payment_method || '').toString();
                if (paymentMethod === 'cash') cashPaid = retTotal;
                else if (paymentMethod === 'debt') debtReduced = retTotal;
            }
            const debtAdded = debtReduced > 0 ? -debtReduced : 0;
            const previousDebt = currentDebt - debtAdded;
            const totalOutstandingDebt = previousDebt + debtAdded;
            const showDebtBox = debtReduced > 0 || (cashPaid <= 0 && targetId > 0 && currentDebt > 0);

            const logoHtml = (typeof getThermalLogoHtml === 'function')
                ? getThermalLogoHtml('pos_sale')
                : ((typeof getReceiptLogoHtml === 'function') ? getReceiptLogoHtml({ mode: 'thermal' }) : '');
            const cafeName = db.settings ? db.settings.cafeName : '';
            return `<div class="print-thermal-container design-${rc2.design || '1'}${thermalFontClasses}" style="max-width: ${rc2.paper}; width: 100%; font-family: 'Rudaw', sans-serif;">
                ${logoHtml}
                <div class="thermal-header">
                    <h1 style="margin: 5px 0;">${escapeHtml(cafeName)}</h1>
                </div>
                <div class="thermal-divider"></div>
                <h3 style="margin:5px 0; background:#fef2f2; border:1px dashed #ef4444; padding:5px; border-radius:4px; color:#b91c1c; text-align:center;">
                    زڤڕاندن (RETURN)
                </h3>
                <div class="thermal-info"><span>بەروار:</span> <span>${new Date(ret.date).toLocaleString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ')}</span></div>
                <div class="thermal-info"><span>کاشێر:</span> <span>${escapeHtml(ret.cashier || 'System')}</span></div>
                <div class="thermal-info"><span>ژمارا مە:</span> <span>#${ret.id}</span></div>
                ${ret.sale_id ? '<div class="thermal-info"><span>پسوولا دەرەکی (کڕیار):</span> <span>#' + ret.sale_id + '</span></div>' : ''}
                <div class="thermal-divider"></div>
                <table class="thermal-table print-unified-table">
                    <thead><tr><th style="text-align:right">ئایتم</th><th style="text-align:center">ژ</th><th style="text-align:left">نرخ</th></tr></thead>
                    <tbody>${itemsHtml}</tbody>
                </table>
                <div class="thermal-divider" style="opacity:1; border-top:2px solid #000;"></div>
                <div class="grand-total" style="background:#fef2f2; color:#b91c1c; border: 2px solid #ef4444; border-radius: 6px;">کۆی زڤڕاندن: ${formatCurrency(ret.total, typeof fxUsdRateFormatOpts === 'function' ? fxUsdRateFormatOpts(ret) : undefined)}</div>
                <div style="margin-top:10px; background:#f8fafc; border:1px dashed #cbd5e1; border-radius:10px; padding:10px;">
                    <div style="display:flex; justify-content:space-between; gap:10px; font-size:0.9rem; color:#64748b;"><span>کۆیا گشتی (Grand Total):</span><b style="color:#0f172a;">${formatCurrency(ret.total || 0, typeof fxUsdRateFormatOpts === 'function' ? fxUsdRateFormatOpts(ret) : undefined)}</b></div>
                    ${cashPaid > 0 ? `<div style="display:flex; justify-content:space-between; gap:10px; font-size:0.9rem; color:#64748b; margin-top:6px;"><span>نەقد وەرگیراو (Cash Refund):</span><b style="color:#059669;">${formatCurrency(cashPaid)}</b></div>` : ''}
                    ${debtReduced > 0 ? `<div style="display:flex; justify-content:space-between; gap:10px; font-size:0.9rem; color:#64748b; margin-top:6px;"><span>کێمکرنا قەرزی (Debt Reduced):</span><b style="color:#dc2626;">${formatCurrency(debtAdded)}</b></div>` : ''}
                    ${showDebtBox && previousDebt != 0 ? `<div style="display:flex; justify-content:space-between; gap:10px; font-size:0.9rem; color:#64748b; margin-top:6px;"><span>قەرزی پێشوو (Prev Debt):</span><b style="color:#0f172a;">${formatCurrency(previousDebt)}</b></div>` : ''}
                    ${showDebtBox ? `<div style="display:flex; justify-content:space-between; gap:10px; font-size:0.95rem; color:#64748b; margin-top:6px; border-top:1px solid #e2e8f0; padding-top:8px;"><span>کۆیا قەرزی (Total Debt):</span><b style="color:#0f172a;">${formatCurrency(totalOutstandingDebt)}</b></div>` : (cashPaid > 0 ? '<div style="margin-top:6px; font-size:0.85rem; color:#64748b;">فرۆشتن بە نەقد بوو — تەنها پارە دەگەڕێتەوە.</div>' : '')}
                </div>
                <p style="margin-top:10px; font-size:0.85rem; border:1px dashed #ccc; padding:6px; background:#f9fafb;"><b>ئەگەر:</b> ${escapeHtml(ret.note || '---')}</p>
                __NOTE_SLOT__
                <div class="thermal-footer">
                    <p>سوپاس بۆ سەرەدانا وە</p>
                    ${typeof buildPosReceiptBrandFooterHtml === 'function' ? buildPosReceiptBrandFooterHtml() : ''}
                </div>
            </div>`;
        }
        function buildReturnReceiptA4Html(ret, printNote) {
            const logoHtml = (typeof getReceiptLogoHtml === 'function')
                ? getReceiptLogoHtml({ mode: 'a4' })
                : ((typeof getPosShopLogoUrl === 'function' && getPosShopLogoUrl()) ? `<img src="${getPosShopLogoUrl()}" style="max-height: 80px; max-width: 150px;" alt="">` : '');

            // Debt history breakdown for sales return (customer/user)
            const targetId = (ret.target_id && parseInt(ret.target_id, 10) > 0) ? parseInt(ret.target_id, 10) : 0;
            const targetType = (ret.target_type || '').toString();
            let currentDebt = 0;
            if (targetId > 0) {
                if (targetType === 'user') {
                    const u = (db.users || []).find(x => Number(x.id) === targetId);
                    currentDebt = parseFloat(u?.balance || 0) || 0;
                } else {
                    const c = (db.customers || []).find(x => Number(x.id) === targetId);
                    currentDebt = parseFloat(c?.balance || 0) || 0;
                }
            }

            const retTotalA4 = parseFloat(ret.total) || 0;
            let cashPaid = ret.cash_refunded != null ? (parseFloat(ret.cash_refunded) || 0) : 0;
            let debtReduced = ret.debt_adjusted != null ? (parseFloat(ret.debt_adjusted) || 0) : 0;
            if (ret.cash_refunded == null && ret.debt_adjusted == null && ret.sale_id && typeof getSaleReturnFinancialSplit === 'function') {
                const linkedSale = (db.sales || []).find(s => String(s.id) === String(ret.sale_id));
                const split = getSaleReturnFinancialSplit(retTotalA4, linkedSale);
                cashPaid = split.cashRefunded;
                debtReduced = split.debtAdjusted;
            } else if (ret.cash_refunded == null && ret.debt_adjusted == null) {
                const paymentMethod = (ret.payment_method || '').toString();
                if (paymentMethod === 'cash') cashPaid = retTotalA4;
                else if (paymentMethod === 'debt') debtReduced = retTotalA4;
            }
            const debtAdded = debtReduced > 0 ? -debtReduced : 0;
            const previousDebt = currentDebt - debtAdded;
            const totalOutstandingDebt = previousDebt + debtAdded;
            const showDebtBox = debtReduced > 0 || (cashPaid <= 0 && targetId > 0 && currentDebt > 0);

            return `<div class="print-a4-container" style="direction:rtl; font-family:'Rudaw', sans-serif;">
                <div class="print-header" style="display:flex; justify-content:space-between; align-items:flex-start; border-bottom:3px solid #ef4444; padding-bottom:15px; margin-bottom:20px;">
                    <div style="text-align:right;">
                        <h1 style="color: #1e293b; margin: 0; font-size: 26px; font-weight:800;">${escapeHtml(db.settings ? db.settings.cafeName : '')}</h1>
                        <p style="color:#64748b; margin: 5px 0; font-size: 14px;">${escapeHtml(db.settings ? db.settings.cafeInfo : '')}</p>
                    </div>
                    <div style="text-align:center;">${logoHtml}</div>
                    <div style="text-align:left; background:#fef2f2; padding:10px 15px; border-radius:8px; border:1px solid #fecaca;">
                        <h2 style="color: #dc2626; margin: 0; font-size: 22px; font-weight:800;">پسوولەیا زڤڕاندنێ</h2>
                        <p style="color:#7f1d1d; margin: 5px 0 2px; font-weight:bold;">ژمارا مە: #${ret.id}</p>
                        ${ret.sale_id ? '<p style="color:#7f1d1d; margin: 0 0 2px; font-size:0.9rem;">پسوولا دەرەکی (کڕیار): #' + ret.sale_id + '</p>' : ''}
                        <p style="color:#7f1d1d; margin: 0; font-size:0.9rem;">بەروار: ${new Date(ret.date).toLocaleDateString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ')}</p>
                    </div>
                </div>
                
                <div class="section-title" style="color:#0f172a; font-size:1.2rem; border-bottom:2px solid #e2e8f0; padding-bottom:8px; margin-bottom:15px;">ئایتمێن زڤڕاندی</div>
                
                <table class="print-table print-unified-table" style="width:100%; border-collapse:collapse; margin-bottom:20px;">
                    <thead>
                        <tr style="background:#0f172a; color:#fff;">
                            <th style="padding:10px; text-align:right; border:1px solid #1e293b; border-radius:0 6px 0 0;">ئایتم (Item)</th>
                            <th style="padding:10px; text-align:center; border:1px solid #1e293b;">ژمارە (Qty)</th>
                            <th style="padding:10px; text-align:left; border:1px solid #1e293b; border-radius:6px 0 0 0;">نرخ (Price)</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${(()=>{
                            const grouped = {};
                            (ret.items || []).forEach(i => {
                                const key = i.id + '_' + (i.note || '') + '_' + i.price + '_' + (i.saleUnit || 'piece') + '_' + (i.isGift ? 'gift' : 'normal');
                                if (!grouped[key]) grouped[key] = { id: i.id, name: i.name, price: i.price, count: 0, sub: 0, note: i.note, saleUnit: i.saleUnit || 'piece', productRef: i.productRef || null, isGift: !!i.isGift };
                                const lineQty = Math.max(1, parseFloat(i.qty) || 1);
                                grouped[key].count += lineQty;
                                grouped[key].sub += (i.isGift ? 0 : (Number(i.price) || 0)) * lineQty;
                            });
                            return Object.values(grouped).map(g => {
                                const nameHtml = (typeof formatSaleItemNameHtml === 'function') ? formatSaleItemNameHtml(g, { skipPriceTypeLabel: true }) : (escapeHtml(g.name || 'ئایتم') + getSaleItemUnitSuffix(g, { skipPriceTypeLabel: true }));
                                return `
                                <tr>
                                    <td style="padding:10px; text-align:right; border:1px solid #e2e8f0;">${nameHtml}${g.note ? `<br><small>* ${escapeHtml(g.note)}</small>` : ''}</td>
                                    <td style="padding:10px; text-align:center; border:1px solid #e2e8f0; font-weight:bold;">${formatQtyForDisplay(g.count, g)}</td>
                                    <td style="padding:10px; text-align:left; border:1px solid #e2e8f0;">${g.isGift ? '0' : formatCurrency(g.sub)}</td>
                                </tr>`;
                            }).join('');
                        })()}
                    </tbody>
                    <tfoot>
                        <tr style="background:#fef2f2;">
                            <td colspan="2" style="padding:12px 10px; text-align:left; font-weight:bold; font-size:1.1rem; color:#b91c1c; border:1px solid #fecaca;">کۆیا گشتی (Total Refund)</td>
                            <td style="padding:12px 10px; text-align:left; font-weight:900; font-size:1.3rem; color:#dc2626; border:1px solid #fecaca;">${formatCurrency(ret.total, typeof fxUsdRateFormatOpts === 'function' ? fxUsdRateFormatOpts(ret) : undefined)} ${typeof getCurrencySymbol === 'function' ? getCurrencySymbol() : ''}</td>
                        </tr>
                    </tfoot>
                </table>
                
                <div style="margin-top:20px; border:1px dashed #cbd5e1; padding:15px; border-radius:8px; background:#f8fafc; color:#334155;">
                    <b style="color:#0f172a;">ئەگەرێ زڤڕاندنێ (Reason):</b> ${escapeHtml(ret.note || '---')}
                </div>
                <div style="margin-top:15px; background:#f8fafc; border:1px dashed #cbd5e1; padding:15px; border-radius:10px; color:#475569;">
                    <div style="font-weight:800; color:#0f172a; margin-bottom:10px; border-bottom:1px solid #e2e8f0; padding-bottom:8px;">Invoice Totals Breakdown</div>
                    <div style="display:flex; justify-content:space-between; gap:10px; font-size:0.95rem; margin-top:6px;"><span>Grand Total:</span><b style="color:#0f172a;">${formatCurrency(ret.total || 0, typeof fxUsdRateFormatOpts === 'function' ? fxUsdRateFormatOpts(ret) : undefined)}</b></div>
                    ${cashPaid > 0 ? `<div style="display:flex; justify-content:space-between; gap:10px; font-size:0.95rem; margin-top:6px;"><span>Cash Refund:</span><b style="color:#059669;">${formatCurrency(cashPaid)}</b></div>` : ''}
                    ${debtReduced > 0 ? `<div style="display:flex; justify-content:space-between; gap:10px; font-size:0.95rem; margin-top:6px;"><span>Debt Reduced:</span><b style="color:#dc2626;">${formatCurrency(debtAdded)}</b></div>` : ''}
                    ${showDebtBox && previousDebt != 0 ? `<div style="display:flex; justify-content:space-between; gap:10px; font-size:0.95rem; margin-top:6px;"><span>Previous Debt:</span><b style="color:#0f172a;">${formatCurrency(previousDebt)}</b></div>` : ''}
                    ${showDebtBox ? `<div style="display:flex; justify-content:space-between; gap:10px; font-size:1.0rem; margin-top:8px; border-top:1px solid #e2e8f0; padding-top:10px;"><span>Total Outstanding Debt:</span><b style="color:#0f172a;">${formatCurrency(totalOutstandingDebt)}</b></div>` : (cashPaid > 0 ? '<div style="margin-top:6px; font-size:0.9rem; color:#64748b;">Cash sale — refund only, debt unchanged.</div>' : '')}
                </div>
                
                __NOTE_SLOT__
                
                <div style="margin-top:40px; display:flex; justify-content:space-between; border-top:1px solid #e2e8f0; padding-top:15px; color:#64748b; font-size:0.85rem;">
                    <div>کاشێر: ${escapeHtml(ret.cashier || 'System')}</div>
                    <div>Printed using ${window.posBrandWithVersion()}</div>
                </div>
            </div>`;
        }
        function printReturnReceipt(id) {
            const ret = getReturnRecord(id);
            if (!ret) return;
            if (typeof printWithOptionalNote === 'function') {
                printWithOptionalNote({ 
                    docType: 'return_receipt', 
                    docId: ret.id, 
                    details: 'total=' + ret.total, 
                    buildHtml: function(note) {
                        const rc = typeof getPrintConfig === 'function' ? getPrintConfig('return_receipt') : { design: '1', paper: '80mm' };
                        const isA4 = (rc.paper === '210mm' || rc.paper === 'A4');
                        const base = isA4 ? buildReturnReceiptA4Html(ret, '') : buildReturnReceiptThermalHtml(ret, '');
                        return typeof finalizePrintHtmlWithNote === 'function' ? finalizePrintHtmlWithNote(base, note || '') : base;
                    },
                    docLabel: typeof t === 'function' ? t('pds_card_return_title') : 'زڤڕاندن' 
                });
            } else {
                const rc = typeof getPrintConfig === 'function' ? getPrintConfig('return_receipt') : { design: '1', paper: '80mm' };
                const isA4 = (rc.paper === '210mm' || rc.paper === 'A4');
                printContent(isA4 ? buildReturnReceiptA4Html(ret, '') : buildReturnReceiptThermalHtml(ret, ''), { docType: 'return_receipt' });
            }
        }

        function saleHistoryYmd(raw) {
            if (!raw) return '';
            var dt = new Date(raw);
            if (isNaN(dt.getTime())) return '';
            var pad = function (n) { return String(n).padStart(2, '0'); };
            return dt.getFullYear() + '-' + pad(dt.getMonth() + 1) + '-' + pad(dt.getDate());
        }

        function findSaleInHistoryPools(saleId) {
            saleId = parseInt(saleId, 10);
            var pools = [window._salesHistoryPage, window._fullSalesHistory];
            if (typeof getAllSales === 'function') pools.push(getAllSales(true));
            if (window.db && window.db.sales) pools.push(window.db.sales);
            for (var p = 0; p < pools.length; p++) {
                if (!Array.isArray(pools[p])) continue;
                var hit = pools[p].find(function (s) { return parseInt(s.id, 10) === saleId; });
                if (hit) return hit;
            }
            return null;
        }

        function patchSaleInHistoryPools(saleId, patchFn) {
            saleId = parseInt(saleId, 10);
            [window._salesHistoryPage, window._fullSalesHistory, window.db && window.db.sales].forEach(function (list) {
                if (!Array.isArray(list)) return;
                for (var i = 0; i < list.length; i++) {
                    if (parseInt(list[i].id, 10) === saleId) patchFn(list[i]);
                }
            });
            if (typeof getAllSales === 'function') {
                var all = getAllSales(true);
                if (Array.isArray(all)) {
                    for (var j = 0; j < all.length; j++) {
                        if (parseInt(all[j].id, 10) === saleId) patchFn(all[j]);
                    }
                }
            }
        }

        function applySaleLineEditLocally(payload) {
            if (!payload || !payload.sale) return;
            var sale = payload.sale;
            var saleId = parseInt(sale.id, 10);
            patchSaleInHistoryPools(saleId, function (row) {
                row.total = sale.total;
                row.items = sale.items;
                row.date = sale.date || sale.created_at;
                row.created_at = sale.created_at || sale.date;
                if (sale.payment_method) row.payment_method = sale.payment_method;
            });
            if (window._saleDetailCache) delete window._saleDetailCache[saleId];
            if (payload.customer_id && window.db) {
                var ctype = payload.customer_type || 'customer';
                var list = ctype === 'user' ? window.db.users : window.db.customers;
                if (Array.isArray(list) && typeof payload.customer_balance === 'number') {
                    var cust = list.find(function (c) { return parseInt(c.id, 10) === parseInt(payload.customer_id, 10); });
                    if (cust) cust.balance = payload.customer_balance;
                }
            }
            var totalEl = document.getElementById('sale-invoice-detail-total');
            if (totalEl && typeof formatCurrency === 'function') {
                totalEl.textContent = formatCurrency(sale.total);
            }
        }

        function sleEditProduct() {
            var modal = document.getElementById('sale-line-edit-modal');
            if (!modal || !modal.dataset.sleProdId) return null;
            return (window.db && window.db.products || []).find(function (p) {
                return String(p.id) === String(modal.dataset.sleProdId);
            }) || null;
        }

        function sleEditCurrentUnit() {
            var modal = document.getElementById('sale-line-edit-modal');
            var u = modal && modal.dataset.sleUnit ? modal.dataset.sleUnit : 'piece';
            return (typeof window.normalizePosUnitCode === 'function') ? window.normalizePosUnitCode(u) : u;
        }

        function sleGetStoredTotalIqd(modal) {
            if (modal && modal.dataset.sleTotalIqd != null && modal.dataset.sleTotalIqd !== '') {
                return parseFloat(modal.dataset.sleTotalIqd) || 0;
            }
            var totalEl = document.getElementById('sle-total');
            if (!totalEl) return 0;
            var display = parseFloat(totalEl.value) || 0;
            return (typeof debtFormAmountToStoredIqd === 'function') ? debtFormAmountToStoredIqd(display) : display;
        }

        function sleSetStoredTotalIqd(modal, totalIqd) {
            if (!modal) return;
            var roundM = (typeof roundMoney === 'function') ? roundMoney : function (x) { return Math.round(Number(x)); };
            totalIqd = roundM(Math.max(0, parseFloat(totalIqd) || 0));
            modal.dataset.sleTotalIqd = String(totalIqd);
            var totalEl = document.getElementById('sle-total');
            if (!totalEl) return;
            var usd = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
            var display = (typeof storedIqdToDebtFormAmount === 'function') ? storedIqdToDebtFormAmount(totalIqd) : totalIqd;
            totalEl.value = usd ? (parseFloat(display) || 0).toFixed(2) : String(Math.round(display));
        }

        function sleFmtUnitPriceDisplay(unitIqd, unitQty, totalIqd) {
            var usd = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
            var display = (typeof storedIqdToDebtFormAmount === 'function') ? storedIqdToDebtFormAmount(unitIqd) : unitIqd;
            if (usd) return (parseFloat(display) || 0).toFixed(2);
            var rounded = Math.round(display);
            if (unitQty > 0 && Math.abs(rounded * unitQty - totalIqd) >= 0.5) {
                for (var dec = 6; dec >= 1; dec--) {
                    var pow = Math.pow(10, dec);
                    var d = Math.round(display * pow) / pow;
                    if (Math.abs(d * unitQty - totalIqd) < 0.5) return String(d);
                }
                return String(Math.round(display * 1000000) / 1000000);
            }
            return String(rounded);
        }

        function sleEditSyncQtyFromPieces(pieces) {
            var modal = document.getElementById('sale-line-edit-modal');
            var qtyEl = document.getElementById('sle-qty');
            var unitEl = document.getElementById('sle-unit-price');
            if (!modal || !qtyEl) return;
            var prod = sleEditProduct();
            var unit = sleEditCurrentUnit();
            var unitQty = (typeof window.purchasePiecesToUnitQty === 'function')
                ? window.purchasePiecesToUnitQty(pieces, unit, prod)
                : pieces;
            qtyEl.value = (typeof formatQtyForInput === 'function') ? formatQtyForInput(unitQty, prod) : unitQty;
            var totalIqd = parseFloat(modal.dataset.sleTotalIqd) || sleGetStoredTotalIqd(modal);
            sleSetStoredTotalIqd(modal, totalIqd);
            if (unitEl && unitQty > 0) {
                unitEl.value = sleFmtUnitPriceDisplay(totalIqd / unitQty, unitQty, totalIqd);
                unitEl.step = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD') ? '0.01' : '0.001';
            }
            modal.dataset.slePieces = String(pieces);
        }

        window.setSaleLineEditUnit = function (unit) {
            var modal = document.getElementById('sale-line-edit-modal');
            if (!modal) return;
            var pieces = parseFloat(modal.dataset.slePieces) || 0;
            if (!pieces) {
                var qtyEl = document.getElementById('sle-qty');
                var prod = sleEditProduct();
                var oldUnit = sleEditCurrentUnit();
                pieces = (typeof window.purchaseUnitQtyToPieces === 'function')
                    ? window.purchaseUnitQtyToPieces(parseFloat(qtyEl && qtyEl.value) || 0, oldUnit, prod)
                    : (parseFloat(qtyEl && qtyEl.value) || 0);
            }
            modal.dataset.sleUnit = (typeof window.normalizePosUnitCode === 'function') ? window.normalizePosUnitCode(unit) : unit;
            var wrap = document.getElementById('sle-unit-toggles');
            if (wrap) {
                wrap.querySelectorAll('.pos-unit-btn').forEach(function (btn) {
                    btn.classList.toggle('active', btn.getAttribute('data-unit') === modal.dataset.sleUnit);
                });
            }
            var prod = sleEditProduct();
            var lbl = (typeof window.getProductUnitLabel === 'function')
                ? window.getProductUnitLabel(prod, modal.dataset.sleUnit)
                : modal.dataset.sleUnit;
            ['sle-unit-label', 'sle-unit-label-price', 'sle-unit-label-hint'].forEach(function (id) {
                var el = document.getElementById(id);
                if (el) el.textContent = lbl;
            });
            sleEditSyncQtyFromPieces(pieces);
        };

        window.adjustSaleLineEditQty = function (direction) {
            var qtyEl = document.getElementById('sle-qty');
            if (!qtyEl) return;
            var prod = sleEditProduct();
            var cur = parseFloat(qtyEl.value) || 0;
            var step = (prod && typeof isWeightProduct === 'function' && isWeightProduct(prod)) ? 0.25 : 1;
            var d = (direction < 0) ? -step : step;
            var next = cur + d;
            if (typeof normalizeQtyForProduct === 'function') next = normalizeQtyForProduct(prod, next);
            if (next <= 0) {
                if (typeof showToast === 'function') showToast('ژمارە دڤێت گەورەتر بیت لە ٠', 'warning');
                return;
            }
            qtyEl.value = (typeof formatQtyForInput === 'function') ? formatQtyForInput(next, prod) : next;
            if (typeof window.recalcSaleLineEditTotal === 'function') window.recalcSaleLineEditTotal();
        };

        function refreshSalesHistoryViews(saleId) {
            if (typeof renderSalesHistoryTable === 'function' && window._salesHistoryPage) {
                renderSalesHistoryTable(window._salesHistoryPage, { localFallback: !!window._salesHistoryLocalOnly });
            }
            if (typeof renderShiftSummary === 'function') renderShiftSummary();
            if (typeof updateStats === 'function') updateStats();
        }

        /**
         * وردەکاری وەسڵ retired permanently.
         * Edit → سەبەتە; view → چاپ/پێشبینین.
         */
        window.openSaleInvoiceDetailModal = function (saleId, opts) {
            opts = opts || {};
            saleId = parseInt(saleId, 10);
            if (!saleId) return;
            var det = document.getElementById('sale-invoice-detail-modal');
            if (det) {
                try { det.style.display = 'none'; det.remove(); } catch (_e) {}
            }
            var canEdit = !opts.readonly && (
                (typeof currentUser !== 'undefined' && currentUser && (currentUser.role === 'admin' || currentUser.role === 'manager')) ||
                (typeof checkPermission === 'function' && checkPermission('returns_manage'))
            );
            if (canEdit && typeof startEditSaleInPos === 'function') {
                startEditSaleInPos(saleId);
                return;
            }
            if (typeof previewSaleInvoice === 'function') previewSaleInvoice(saleId);
            else if (typeof reprintBill === 'function') reprintBill(saleId);
        };

        window.openEditSaleLineModal = function () {
            if (typeof showToast === 'function') {
                showToast((typeof t === 'function') ? t('sale_detail_retired') : 'تەعدیل لە سەبەتە بەکاربهێنە', 'info');
            }
        };
        window.openAddSaleLineModal = function (saleId) {
            if (typeof startEditSaleInPos === 'function') startEditSaleInPos(saleId);
        };
        window.deleteSaleLineItem = function () {
            if (typeof showToast === 'function') {
                showToast((typeof t === 'function') ? t('sale_detail_retired') : 'تەعدیل لە سەبەتە بەکاربهێنە', 'info');
            }
        };

        window.recalcSaleLineEditTotal = function () {
            var qtyEl = document.getElementById('sle-qty');
            var unitEl = document.getElementById('sle-unit-price');
            var modal = document.getElementById('sale-line-edit-modal');
            if (!qtyEl || !unitEl || !modal) return;
            var qty = parseFloat(qtyEl.value) || 0;
            var unitDisplay = parseFloat(unitEl.value) || 0;
            var unitIqd = (typeof debtFormAmountToStoredIqd === 'function') ? debtFormAmountToStoredIqd(unitDisplay) : unitDisplay;
            var roundM = (typeof roundMoney === 'function') ? roundMoney : function (x) { return Math.round(Number(x)); };
            var totalIqd = roundM(qty * unitIqd);
            sleSetStoredTotalIqd(modal, totalIqd);
            var prod = sleEditProduct();
            var pieces = (typeof window.purchaseUnitQtyToPieces === 'function')
                ? window.purchaseUnitQtyToPieces(qty, sleEditCurrentUnit(), prod)
                : qty;
            modal.dataset.slePieces = String(pieces);
        };

        window.recalcSaleLineEditUnitPrice = function () {
            var qtyEl = document.getElementById('sle-qty');
            var unitEl = document.getElementById('sle-unit-price');
            var totalEl = document.getElementById('sle-total');
            var modal = document.getElementById('sale-line-edit-modal');
            if (!qtyEl || !unitEl || !totalEl || !modal) return;
            var qty = parseFloat(qtyEl.value) || 0;
            var totalDisplay = parseFloat(totalEl.value) || 0;
            var totalIqd = (typeof debtFormAmountToStoredIqd === 'function')
                ? debtFormAmountToStoredIqd(totalDisplay)
                : totalDisplay;
            sleSetStoredTotalIqd(modal, totalIqd);
            if (qty > 0) {
                unitEl.value = sleFmtUnitPriceDisplay(totalIqd / qty, qty, totalIqd);
            } else {
                unitEl.value = '0';
            }
            var prod = sleEditProduct();
            var pieces = (typeof window.purchaseUnitQtyToPieces === 'function')
                ? window.purchaseUnitQtyToPieces(qty, sleEditCurrentUnit(), prod)
                : qty;
            modal.dataset.slePieces = String(pieces);
        };

        window.openEditSaleLineModal = function (saleId, itemIndex) {
            saleId = parseInt(saleId, 10);
            if (saleId && typeof startEditSaleInPos === 'function') {
                startEditSaleInPos(saleId);
                return;
            }
            if (typeof showToast === 'function') {
                showToast((typeof t === 'function') ? t('sale_detail_retired') : 'تەعدیل لە سەبەتە بەکاربهێنە', 'info');
            }
            return;
            itemIndex = parseInt(itemIndex, 10);
            var open = function (sale) {
                if (!sale || !sale.items || !sale.items[itemIndex]) return;
                var it = sale.items[itemIndex];
                if (it.isGift) {
                    if (typeof showToast === 'function') showToast('دەستکارییا هدیە ناکرێت', 'error');
                    return;
                }
                var unitQty = (typeof getItemQty === 'function') ? getItemQty(it) : (parseFloat(it.qty != null ? it.qty : it.count) || 0);
                var prod = (window.db && window.db.products || []).find(function (p) { return String(p.id) === String(it.id); });
                var saleUnit = (typeof window.inferSaleLineDisplayUnit === 'function')
                    ? window.inferSaleLineDisplayUnit(it, prod)
                    : (it.saleUnit || 'piece');
                var pieces = (typeof window.purchaseUnitQtyToPieces === 'function')
                    ? window.purchaseUnitQtyToPieces(unitQty, saleUnit, prod)
                    : unitQty;
                var lineTotalIqd = (parseFloat(it.price) || 0) * unitQty;
                var unitPriceIqd = unitQty ? (lineTotalIqd / unitQty) : 0;
                var usd = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
                var moneyUnit = usd ? '$' : 'IQD';
                var displayTotal = (typeof storedIqdToDebtFormAmount === 'function') ? storedIqdToDebtFormAmount(lineTotalIqd) : lineTotalIqd;
                var displayUnitPriceStr = sleFmtUnitPriceDisplay(unitPriceIqd, unitQty, lineTotalIqd);
                var fmtTotal = function (n) {
                    n = parseFloat(n) || 0;
                    return usd ? n.toFixed(2) : String(Math.round(n));
                };
                var unitLabel = (typeof window.getProductUnitLabel === 'function')
                    ? window.getProductUnitLabel(prod, saleUnit)
                    : saleUnit;
                var breakdownHtml = (typeof window.formatPiecesUnitSummary === 'function')
                    ? window.formatPiecesUnitSummary(pieces, prod, { showPiecesHint: false })
                    : String(unitQty);
                var availUnits = (typeof window.availableSaleUnitsForProduct === 'function')
                    ? window.availableSaleUnitsForProduct(prod)
                    : ['piece', 'pack', 'carton'];
                var unitToggles = (typeof window.buildPosUnitToggleHtml === 'function')
                    ? window.buildPosUnitToggleHtml({ available: availUnits, current: saleUnit, onSet: 'setSaleLineEditUnit' })
                    : '';
                var dateYmd = saleHistoryYmd(sale.date || sale.created_at);
                var modal = document.getElementById('sale-line-edit-modal');
                if (!modal) {
                    modal = document.createElement('div');
                    modal.id = 'sale-line-edit-modal';
                    modal.style.cssText = 'display:none; position:fixed; inset:0; z-index:10030; background:rgba(0,0,0,0.65); align-items:center; justify-content:center; padding:20px;';
                    document.body.appendChild(modal);
                    modal.onclick = function (e) { if (e.target === modal) modal.style.display = 'none'; };
                }
                modal.innerHTML =
                    '<div class="glass-card" style="max-width:480px; width:96%; padding:22px; border-radius:16px;" onclick="event.stopPropagation();">' +
                        '<h3 style="margin:0 0 12px; color:var(--brand);"><i class="fas fa-edit"></i> دەستکارییا ئایتمێ</h3>' +
                        '<p style="margin:0 0 6px; color:var(--text-main); font-size:0.95rem; font-weight:600;">' + escapeHtml(it.name || '') + '</p>' +
                        '<p style="margin:0 0 12px; color:var(--text-muted); font-size:0.82rem;"><i class="fas fa-cubes"></i> ئێستا: ' + breakdownHtml + '</p>' +
                        '<label style="display:block; margin-bottom:6px; font-size:0.85rem;">بەروار</label>' +
                        '<input type="date" id="sle-date" class="input-std" value="' + escapeHtml(dateYmd || '') + '" style="margin:0 0 12px;">' +
                        '<label style="display:block; margin-bottom:6px; font-size:0.85rem;">یەکە</label>' +
                        '<div id="sle-unit-toggles" class="pos-unit-toggles" style="margin:0 0 10px; display:flex; gap:6px;">' + unitToggles + '</div>' +
                        '<label style="display:block; margin-bottom:6px; font-size:0.85rem;">ژمار (<span id="sle-unit-label">' + escapeHtml(unitLabel) + '</span>)</label>' +
                        '<div class="returns-row-qty-wrap sle-qty-step-wrap" style="display:flex;align-items:stretch;gap:8px;margin:0 0 12px;">' +
                            '<button type="button" class="btn btn-sm btn-dark" style="min-width:44px;" onclick="adjustSaleLineEditQty(-1)" title="کەمکردن"><i class="fas fa-minus"></i></button>' +
                            '<input type="number" id="sle-qty" class="input-std" min="0.01" step="0.01" value="' + ((typeof formatQtyForInput === 'function') ? formatQtyForInput(unitQty, prod) : unitQty) + '" style="margin:0; flex:1; text-align:center;" oninput="recalcSaleLineEditTotal()">' +
                            '<button type="button" class="btn btn-sm btn-dark" style="min-width:44px;" onclick="adjustSaleLineEditQty(1)" title="زیادکردن"><i class="fas fa-plus"></i></button>' +
                        '</div>' +
                        '<label style="display:block; margin-bottom:6px; font-size:0.85rem;">نرخ / <span id="sle-unit-label-price">' + escapeHtml(unitLabel) + '</span> (' + moneyUnit + ')</label>' +
                        '<input type="number" id="sle-unit-price" class="input-std" min="0" step="' + (usd ? '0.01' : '0.001') + '" value="' + escapeHtml(displayUnitPriceStr) + '" style="margin:0 0 12px;" oninput="recalcSaleLineEditTotal()">' +
                        '<label style="display:block; margin-bottom:6px; font-size:0.85rem;">کۆ (' + moneyUnit + ')</label>' +
                        '<input type="number" id="sle-total" class="input-std" min="0" step="' + (usd ? '0.01' : '1') + '" value="' + fmtTotal(displayTotal) + '" style="margin:0 0 8px;" oninput="recalcSaleLineEditUnitPrice()">' +
                        '<p style="margin:0 0 16px; color:var(--text-muted); font-size:0.78rem;"><i class="fas fa-info-circle"></i> +/− بۆ ژمارە. گۆڕینی یەکە کۆی سەرەتایی دەپارێزێت.</p>' +
                        '<div style="display:flex; gap:10px; justify-content:flex-end;">' +
                            '<button type="button" class="btn btn-dark" onclick="document.getElementById(\'sale-line-edit-modal\').style.display=\'none\'">پاشگەز</button>' +
                            '<button type="button" class="btn btn-brand" id="sle-save-btn" onclick="saveSaleLineEdit(' + saleId + ',' + itemIndex + ')"><i class="fas fa-save"></i> پاراستن</button>' +
                        '</div></div>';
                modal.style.display = 'flex';
                modal.dataset.sleProdId = String(it.id || '');
                modal.dataset.sleUnit = saleUnit;
                modal.dataset.slePieces = String(pieces);
                modal.dataset.sleTotalIqd = String((typeof roundMoney === 'function') ? roundMoney(lineTotalIqd) : Math.round(lineTotalIqd));
            };
            var local = findSaleInHistoryPools(saleId);
            if (local && local.items) { open(local); return; }
            if (typeof withSaleRecord === 'function') withSaleRecord(saleId, open);
        };

        window.saveSaleLineEdit = function (saleId, itemIndex) {
            var qtyEl = document.getElementById('sle-qty');
            var totalEl = document.getElementById('sle-total');
            var dateEl = document.getElementById('sle-date');
            var btn = document.getElementById('sle-save-btn');
            var modal = document.getElementById('sale-line-edit-modal');
            if (!qtyEl || !totalEl) return;
            var unitQty = parseFloat(qtyEl.value) || 0;
            var qty = unitQty;
            var totalDisplay = parseFloat(totalEl.value) || 0;
            var total = (typeof debtFormAmountToStoredIqd === 'function')
                ? debtFormAmountToStoredIqd(totalDisplay)
                : totalDisplay;
            if (typeof roundMoney === 'function') total = roundMoney(total);
            var saleUnit = modal && modal.dataset.sleUnit ? modal.dataset.sleUnit : 'piece';
            var dateVal = dateEl ? String(dateEl.value || '').trim() : '';
            if (qty <= 0) { if (typeof showToast === 'function') showToast('ژمارە دڤێت گەورەتر بیت لە ٠', 'error'); return; }
            if (total < 0) { if (typeof showToast === 'function') showToast('کۆ نابیت نەرێنی', 'error'); return; }
            if (!dateVal) { if (typeof showToast === 'function') showToast('بەروار پێدڤیە', 'error'); return; }
            var user = (typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : 'System';
            var formData = new FormData();
            formData.append('action', 'update_sale_line');
            formData.append('sale_id', String(saleId));
            formData.append('item_index', String(itemIndex));
            formData.append('qty', String(qty));
            formData.append('sale_unit', saleUnit);
            formData.append('line_total', String(total));
            formData.append('date', dateVal);
            formData.append('user', user);
            if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>'; }
            fetch('?action=update_sale_line', { method: 'POST', body: formData, credentials: 'same-origin' })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-save"></i> پاراستن'; }
                    if (data.status !== 'success') {
                        alert('هەڵە: ' + (data.message || 'Error'));
                        return;
                    }
                    applySaleLineEditLocally(data);
                    var m = document.getElementById('sale-line-edit-modal');
                    if (m) m.style.display = 'none';
                    if (typeof showToast === 'function') {
                        showToast(data.stock_skipped ? '⚠️ مێژوو نوێکرایەوە — کۆگا نەگۆڕدرا' : '✅ ئایتم هاتە نویکرن', data.stock_skipped ? 'warning' : 'success');
                    }
                    refreshSalesHistoryViews(saleId);
                    setTimeout(function () { if (typeof syncLiveData === 'function') syncLiveData(false); }, 150);
                })
                .catch(function (err) {
                    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-save"></i> پاراستن'; }
                    alert('هەڵە: ' + (err.message || err));
                });
        };

        window.deleteSaleLineItem = function (saleId, itemIndex) {
            saleId = parseInt(saleId, 10);
            if (saleId && typeof startEditSaleInPos === 'function') {
                startEditSaleInPos(saleId);
                return;
            }
            if (typeof showToast === 'function') {
                showToast((typeof t === 'function') ? t('sale_detail_retired') : 'تەعدیل لە سەبەتە بەکاربهێنە', 'info');
            }
            return;
            itemIndex = parseInt(itemIndex, 10);
            if (!saleId || itemIndex < 0) return;
            var sale = typeof findSaleInHistoryPools === 'function' ? findSaleInHistoryPools(saleId) : null;
            var isLast = !!(sale && sale.items && sale.items.length <= 1);
            var msg = isLast
                ? 'ئەمە دوایین ئایتمە — هەموو وەسڵەکە دەسڕدرێتەوە. بەردەوام بیت؟'
                : 'ئەم ئایتمە بسڕدرێتەوە لە وەسڵ؟ کۆگا و قەرز نوێ دەکرێتەوە.';
            if (!confirm(msg)) return;
            var user = (typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : 'System';
            var formData = new FormData();
            formData.append('action', 'delete_sale_line');
            formData.append('sale_id', String(saleId));
            formData.append('item_index', String(itemIndex));
            formData.append('user', user);
            fetch('?action=delete_sale_line', { method: 'POST', body: formData, credentials: 'same-origin' })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    if (data.status !== 'success') {
                        alert('هەڵە: ' + (data.message || 'Error'));
                        return;
                    }
                    if (data.sale_deleted || data.sale_voided || data.voided) {
                        [window._salesHistoryPage, window._fullSalesHistory, window.db && window.db.sales].forEach(function (list) {
                            if (!Array.isArray(list)) return;
                            for (var i = 0; i < list.length; i++) {
                                if (parseInt(list[i].id, 10) === saleId) {
                                    list[i].is_returned = 1;
                                }
                            }
                        });
                        if (window._saleDetailCache) delete window._saleDetailCache[saleId];
                        var det = document.getElementById('sale-invoice-detail-modal');
                        if (det) det.style.display = 'none';
                        if (typeof showToast === 'function') {
                            showToast((typeof t === 'function') ? t('void_sale_kept_trace') : ('وەسڵ #' + saleId + ' هاتە ژێبرن — شینوار پاراستینە'), 'success', {
                                actionLabel: (typeof t === 'function') ? t('btn_undo_void') : 'پەشێمان بم',
                                durationMs: 12000,
                                onAction: function () {
                                    if (typeof restoreVoidedSale === 'function') restoreVoidedSale(saleId);
                                }
                            });
                        }
                        if (typeof renderSalesHistory === 'function') renderSalesHistory();
                        else if (typeof renderSalesHistoryTable === 'function' && window._salesHistoryPage) {
                            renderSalesHistoryTable(window._salesHistoryPage, { localFallback: !!window._salesHistoryLocalOnly });
                        }
                    } else {
                        applySaleLineEditLocally(data);
                        if (typeof showToast === 'function') showToast('✅ ئایتم هاتە سڕینەوە', 'success');
                        refreshSalesHistoryViews(saleId);
                    }
                    setTimeout(function () { if (typeof syncLiveData === 'function') syncLiveData(false); }, 150);
                })
                .catch(function (err) {
                    alert('هەڵە: ' + (err.message || err));
                });
        };

        function salAddProduct() {
            var modal = document.getElementById('sale-add-line-modal');
            if (!modal || !modal.dataset.salProdId) return null;
            return (window.db && window.db.products || []).find(function (p) {
                return String(p.id) === String(modal.dataset.salProdId);
            }) || null;
        }

        function salCurrentUnit() {
            var modal = document.getElementById('sale-add-line-modal');
            var u = modal && modal.dataset.salUnit ? modal.dataset.salUnit : 'piece';
            return (typeof window.normalizePosUnitCode === 'function') ? window.normalizePosUnitCode(u) : u;
        }

        window.setSaleAddLineUnit = function (unit) {
            var modal = document.getElementById('sale-add-line-modal');
            if (!modal) return;
            modal.dataset.salUnit = (typeof window.normalizePosUnitCode === 'function') ? window.normalizePosUnitCode(unit) : unit;
            var wrap = document.getElementById('sal-unit-toggles');
            if (wrap) {
                wrap.querySelectorAll('.pos-unit-btn').forEach(function (btn) {
                    btn.classList.toggle('active', btn.getAttribute('data-unit') === modal.dataset.salUnit);
                });
            }
            var prod = salAddProduct();
            var lbl = (typeof window.getProductUnitLabel === 'function')
                ? window.getProductUnitLabel(prod, modal.dataset.salUnit)
                : modal.dataset.salUnit;
            ['sal-unit-label', 'sal-unit-label-price'].forEach(function (id) {
                var el = document.getElementById(id);
                if (el) el.textContent = lbl;
            });
            if (prod && typeof getPriceForUnit === 'function') {
                var unitEl = document.getElementById('sal-unit-price');
                if (unitEl) {
                    var priceIqd = getPriceForUnit(prod, modal.dataset.salUnit) || 0;
                    var display = (typeof storedIqdToDebtFormAmount === 'function') ? storedIqdToDebtFormAmount(priceIqd) : priceIqd;
                    var usd = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
                    unitEl.value = usd ? (parseFloat(display) || 0).toFixed(2) : String(Math.round(display));
                }
            }
            if (typeof window.recalcSaleAddLineTotal === 'function') window.recalcSaleAddLineTotal();
        };

        window.recalcSaleAddLineTotal = function () {
            var qtyEl = document.getElementById('sal-qty');
            var unitEl = document.getElementById('sal-unit-price');
            var totalEl = document.getElementById('sal-total');
            if (!qtyEl || !unitEl || !totalEl) return;
            var qty = parseFloat(qtyEl.value) || 0;
            var unitDisplay = parseFloat(unitEl.value) || 0;
            var totalDisplay = qty * unitDisplay;
            var usd = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
            totalEl.value = usd ? totalDisplay.toFixed(2) : String(Math.round(totalDisplay));
        };

        window.lookupSaleAddLineBarcode = function () {
            var bcEl = document.getElementById('sal-barcode');
            var modal = document.getElementById('sale-add-line-modal');
            if (!bcEl || !modal) return;
            var raw = String(bcEl.value || '').trim();
            if (!raw) return;

            var applyProd = function (prod) {
                var details = document.getElementById('sal-product-details');
                var nameEl = document.getElementById('sal-product-name');
                if (!prod) {
                    if (typeof showToast === 'function') showToast('ئایتم نەهاتە دیتن', 'error');
                    modal.dataset.salProdId = '';
                    if (details) details.style.display = 'none';
                    return;
                }
                modal.dataset.salProdId = String(prod.id);
                if (details) details.style.display = 'block';
                if (nameEl) nameEl.textContent = prod.name || ('#' + prod.id);
                var unit = salCurrentUnit();
                if (typeof window.buildPosUnitToggleHtml === 'function') {
                    var toggles = document.getElementById('sal-unit-toggles');
                    var avail = ['piece'];
                    if (prod.unit_show_pack || (prod.pieces_per_pack && prod.pieces_per_pack > 1)) avail.push('pack');
                    if (prod.unit_show_carton || (prod.itemsPerCarton && prod.itemsPerCarton > 1) || (prod.packs_per_carton && prod.packs_per_carton > 1)) avail.push('carton');
                    if (toggles) {
                        toggles.innerHTML = window.buildPosUnitToggleHtml({
                            available: avail,
                            current: unit,
                            onSet: 'setSaleAddLineUnit'
                        });
                    }
                }
                window.setSaleAddLineUnit(unit);
                var qtyEl = document.getElementById('sal-qty');
                if (qtyEl && (!qtyEl.value || parseFloat(qtyEl.value) <= 0)) qtyEl.value = '1';
                window.recalcSaleAddLineTotal();
            };

            var resolved = (typeof window.resolveBarcodeForTxnAdd === 'function')
                ? window.resolveBarcodeForTxnAdd(raw, salCurrentUnit(), { isPurchase: false })
                : null;
            var prod = resolved && resolved.p ? resolved.p : null;
            if (!prod && typeof window.findProductByBarcode === 'function') {
                prod = window.findProductByBarcode(raw);
            }
            if (!prod && window.db && Array.isArray(window.db.products)) {
                var q = raw.toLowerCase();
                prod = window.db.products.find(function (p) {
                    return String(p.barcode || '').toLowerCase() === q
                        || String(p.sku || '').toLowerCase() === q
                        || String(p.name || '').toLowerCase().indexOf(q) >= 0;
                }) || null;
            }
            if (prod) {
                applyProd(prod);
                return;
            }
            // Server fallback (large shop / partial catalog)
            if (typeof window.posEnsureProductByBarcode === 'function') {
                window.posEnsureProductByBarcode(raw).then(function (p) {
                    applyProd(p || null);
                }).catch(function () { applyProd(null); });
                return;
            }
            if (typeof window.posLookupProductByBarcode === 'function') {
                window.posLookupProductByBarcode(raw).then(function (p) {
                    applyProd(p || null);
                }).catch(function () { applyProd(null); });
                return;
            }
            applyProd(null);
        };

        window.openAddSaleLineModal = function (saleId) {
            saleId = parseInt(saleId, 10);
            if (saleId && typeof startEditSaleInPos === 'function') {
                startEditSaleInPos(saleId);
                return;
            }
            if (typeof showToast === 'function') {
                showToast((typeof t === 'function') ? t('sale_detail_retired') : 'تەعدیل لە سەبەتە بەکاربهێنە', 'info');
            }
            return;
            if (!saleId) return;
            var usd = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
            var moneyUnit = usd ? '$' : 'IQD';
            var modal = document.getElementById('sale-add-line-modal');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'sale-add-line-modal';
                modal.style.cssText = 'display:none; position:fixed; inset:0; z-index:10026; background:rgba(0,0,0,0.55); align-items:center; justify-content:center; padding:20px;';
                document.body.appendChild(modal);
                modal.onclick = function (e) { if (e.target === modal) modal.style.display = 'none'; };
            }
            modal.innerHTML =
                '<div class="glass-card" style="max-width:520px; width:96%; padding:24px; border-radius:16px;" onclick="event.stopPropagation();">' +
                    '<h3 style="margin:0 0 14px 0; color:var(--brand); font-size:1.3rem;"><i class="fas fa-cart-plus" style="margin-left:8px;"></i> زیادکردنی ئایتم بۆ وەسڵی فرۆشتن</h3>' +
                    '<p style="margin:0 0 16px; color:var(--text-muted); font-size:0.9rem;">بارکۆد بنووسە و Enter — ئایتمێ نوێ بۆ هەمان وەسڵ.</p>' +
                    '<div style="background:var(--input-bg); border:1px solid var(--border); border-radius:10px; padding:12px; margin-bottom:16px;">' +
                        '<label style="display:block; margin-bottom:8px; font-size:0.9rem; font-weight:bold;">بارکۆد / گەڕان</label>' +
                        '<div style="display:flex; gap:8px;">' +
                            '<input type="text" id="sal-barcode" class="input-std" placeholder="لێرە سکان بکە…" style="margin:0; flex:1;" onkeydown="if(event.key===\'Enter\'){event.preventDefault();lookupSaleAddLineBarcode();}">' +
                            '<button type="button" class="btn btn-info" onclick="lookupSaleAddLineBarcode()" style="padding:0 16px;"><i class="fas fa-search"></i></button>' +
                        '</div>' +
                    '</div>' +
                    '<div id="sal-product-details" style="margin:0 0 16px; min-height:40px; background:rgba(37,99,235,0.05); padding:10px; border-radius:8px; border:1px dashed var(--brand); display:none;">' +
                        '<p id="sal-product-name" style="margin:0; font-weight:800; font-size:1.1rem; color:var(--brand);">—</p>' +
                    '</div>' +
                    '<div style="margin-bottom:16px;">' +
                        '<label style="display:block; margin-bottom:6px; font-size:0.9rem; font-weight:bold;">یەکە (Unit)</label>' +
                        '<div id="sal-unit-toggles" class="pos-unit-toggles" style="display:flex; gap:6px;"></div>' +
                    '</div>' +
                    '<div style="display:flex; gap:12px; margin-bottom:16px;">' +
                        '<div style="flex:1;">' +
                            '<label style="display:block; margin-bottom:6px; font-size:0.9rem; font-weight:bold;">بڕ / ژمارە (<span id="sal-unit-label" style="color:var(--brand);">تاک</span>)</label>' +
                            '<input type="number" id="sal-qty" class="input-std" min="0.01" step="0.01" value="1" style="margin:0; font-weight:bold; font-size:1.1rem;" oninput="recalcSaleAddLineTotal()">' +
                        '</div>' +
                        '<div style="flex:1.5;">' +
                            '<label style="display:block; margin-bottom:6px; font-size:0.9rem; font-weight:bold;">نرخی یەکە (<span id="sal-unit-label-price" style="color:var(--brand);">تاک</span>) / ' + moneyUnit + '</label>' +
                            '<input type="number" id="sal-unit-price" class="input-std" min="0" step="' + (usd ? '0.01' : '1') + '" value="0" style="margin:0; font-weight:bold; font-size:1.1rem;" oninput="recalcSaleAddLineTotal()">' +
                        '</div>' +
                    '</div>' +
                    '<label style="display:block; margin-bottom:6px; font-size:0.9rem; font-weight:bold;">کۆی گشتی (' + moneyUnit + ')</label>' +
                    '<input type="number" id="sal-total" class="input-std" min="0" step="' + (usd ? '0.01' : '1') + '" value="0" style="margin:0 0 20px; font-weight:bold; font-size:1.2rem; background:var(--bg-color);" readonly>' +
                    '<div style="display:flex; gap:12px; justify-content:flex-end;">' +
                        '<button type="button" class="btn btn-dark" onclick="document.getElementById(\'sale-add-line-modal\').style.display=\'none\'" style="padding:10px 20px;">پاشگەز</button>' +
                        '<button type="button" class="btn btn-brand" id="sal-save-btn" onclick="saveAddSaleLineToInvoice(' + saleId + ')" style="padding:10px 24px;"><i class="fas fa-save"></i> زیادکردن</button>' +
                    '</div>' +
                '</div>';
            modal.dataset.saleId = String(saleId);
            modal.dataset.salProdId = '';
            modal.dataset.salUnit = 'piece';
            var toggles = document.getElementById('sal-unit-toggles');
            if (toggles && typeof window.buildPosUnitToggleHtml === 'function') {
                toggles.innerHTML = window.buildPosUnitToggleHtml({
                    available: ['piece', 'pack', 'carton'],
                    current: 'piece',
                    onSet: 'setSaleAddLineUnit'
                });
            }
            modal.style.display = 'flex';
            setTimeout(function () {
                var bc = document.getElementById('sal-barcode');
                if (bc) bc.focus();
            }, 50);
        };

        window.saveAddSaleLineToInvoice = function (saleId) {
            var modal = document.getElementById('sale-add-line-modal');
            var btn = document.getElementById('sal-save-btn');
            var bcInput = document.getElementById('sal-barcode');
            if (modal && !modal.dataset.salProdId && bcInput && bcInput.value.trim() !== '') {
                lookupSaleAddLineBarcode();
            }
            var prodId = modal ? parseInt(modal.dataset.salProdId, 10) : 0;
            if (!prodId) {
                if (typeof showToast === 'function') showToast('سەرەتا کاڵا هەڵبژێرە (بارکۆد)', 'error');
                return;
            }
            var qtyEl = document.getElementById('sal-qty');
            var totalEl = document.getElementById('sal-total');
            var qty = parseFloat(qtyEl && qtyEl.value) || 0;
            var totalDisplay = parseFloat(totalEl && totalEl.value) || 0;
            var total = (typeof debtFormAmountToStoredIqd === 'function')
                ? debtFormAmountToStoredIqd(totalDisplay)
                : totalDisplay;
            if (typeof roundMoney === 'function') total = roundMoney(total);
            var saleUnit = salCurrentUnit();
            if (qty <= 0) { if (typeof showToast === 'function') showToast('ژمارە دڤێت گەورەتر بیت لە ٠', 'error'); return; }
            if (total < 0) { if (typeof showToast === 'function') showToast('کۆ نابیت نەرێنی', 'error'); return; }
            var user = (typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : 'System';
            var formData = new FormData();
            formData.append('action', 'add_sale_line');
            formData.append('sale_id', String(saleId));
            formData.append('product_id', String(prodId));
            formData.append('qty', String(qty));
            formData.append('sale_unit', saleUnit);
            formData.append('line_total', String(total));
            formData.append('user', user);
            if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>'; }
            fetch('?action=add_sale_line', { method: 'POST', body: formData, credentials: 'same-origin' })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-save"></i> زیادکردن'; }
                    if (data.status !== 'success') {
                        alert('هەڵە: ' + (data.message || 'Error'));
                        return;
                    }
                    applySaleLineEditLocally(data);
                    if (modal) modal.style.display = 'none';
                    if (typeof showToast === 'function') {
                        showToast(data.stock_skipped ? '⚠️ زیادکرا — کۆگا نەگۆڕدرا (کەمە)' : '✅ ئایتم زیادکرا', data.stock_skipped ? 'warning' : 'success');
                    }
                    refreshSalesHistoryViews(saleId);
                    setTimeout(function () { if (typeof syncLiveData === 'function') syncLiveData(false); }, 150);
                })
                .catch(function (err) {
                    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-save"></i> زیادکردن'; }
                    alert('هەڵە: ' + (err.message || err));
                });
        };

