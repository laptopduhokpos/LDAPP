// core/startup.js — startup, license, helpers
// Global state and API are provided by main.js (ES6 module). Use window.db, window.apiJson, etc.
        (function(){
            // FIX: Ensure wide content like tables in workspaces is horizontally scrollable instead of overflowing the page.
            var style = document.createElement('style');
            style.id = 'overflow-fix';
            style.innerHTML = '.workspace { overflow-x: auto !important; }';
            document.head.appendChild(style);
        })();
        (function(){ try { var w=document.getElementById('app-content-wrap'); if(w){ var p=(typeof localStorage!=='undefined'&&localStorage.getItem('pos_sidebar_position'))||'right'; if(p==='left')w.classList.add('sidebar-on-left'); else w.classList.remove('sidebar-on-left'); } } catch(e){} })();
        if (typeof window._posCartOperationLock === 'undefined') window._posCartOperationLock = false;
        if (typeof window._isCartSaving === 'undefined') window._isCartSaving = false;
        let cartSaveQueue = [];
        let isSavingCartNetwork = false;
        if (typeof window.__state === 'undefined') { var db = null; var displaySyncTimeout = null; var activeTableId = null; var currentUser = null; var activeCategory = 'all'; var posSelectedUnit = 'piece'; var fileHandle = null; var isFileConnected = false; var currentViewingCompanyId = null; var selectedSupplyProdId = null; var lastTableState = ""; var saveTimeout = null; var recentAddedItems = []; var isTableEditMode = false; var isReturnMode = false; var isSupplyReturnMode = false; var currentWhFilter = 'all'; var settingsClickCount = 0; var settingsNavTimer = null; var systemModeUnlocked = false; var breadcrumbStack = []; var currentBreadcrumbIndex = 0; var lastSyncTime = 0; var currentDebtParams = null; var isProcessingPayment = false; }
        if (typeof window.customerChannel === 'undefined') window.customerChannel = new BroadcastChannel('LAPTOP_DUHOK_POS_customer_display');
        var THERMAL_RECEIPT_OPTIONS_DEFAULTS = { logoPosition: 'center', headerFont: 'medium', bodyFont: 'medium', footerFont: 'small' };
        if (typeof window !== 'undefined') window.THERMAL_RECEIPT_OPTIONS_DEFAULTS = THERMAL_RECEIPT_OPTIONS_DEFAULTS;

        /** Release label from PHP (`window.POS_APP_VERSION`); keep fallback aligned with `config/version.php`. */
        if (typeof window.getPosAppVersion !== 'function') {
            window.getPosAppVersion = function() {
                if (typeof window !== 'undefined' && window.POS_APP_VERSION) return String(window.POS_APP_VERSION);
                try {
                    var meta = document.querySelector('meta[name="pos-app-version"]');
                    if (meta && meta.getAttribute('content')) return String(meta.getAttribute('content'));
                } catch (_eVer) {}
                return '3.16.8';
            };
        }
        if (typeof window.syncPosVersionLabels !== 'function') {
            window.syncPosVersionLabels = function() {
                var v = window.getPosAppVersion();
                if (!v) return;
                document.querySelectorAll('.startup-version-num, [data-pos-app-version]').forEach(function (el) {
                    el.textContent = 'v' + v;
                });
            };
        }
        /** Shop logo for prints/UI: custom upload, else Laptop Duhok brand logo.
         * File paths are absolute — print iframe is about:blank so relative src breaks. */
        if (typeof window.absAssetUrl !== 'function') {
            window.absAssetUrl = function(path) {
                var p = String(path || '');
                if (!p) return '';
                if (/^(data:|blob:|https?:|\/\/)/i.test(p)) return p;
                try { return new URL(p, window.location.href).href; }
                catch (_eAbs) { return p; }
            };
        }
        if (typeof window.getPosShopLogoUrl !== 'function') {
            window.getPosShopLogoUrl = function(opts) {
                opts = opts || {};
                var raw = '';
                try {
                    var s = (typeof db !== 'undefined' && db && db.settings) ? db.settings : null;
                    if (s) {
                        var custom = String(s.logo || s.cafeLogo || s.receiptLogo || '').trim();
                        if (custom) raw = custom;
                    }
                } catch (_eLogo) {}
                if (!raw) {
                    if (typeof window.POS_DEFAULT_SHOP_LOGO === 'string' && window.POS_DEFAULT_SHOP_LOGO) {
                        raw = window.POS_DEFAULT_SHOP_LOGO;
                    } else if (typeof window.POS_DEFAULT_LOGO === 'string' && window.POS_DEFAULT_LOGO) {
                        raw = window.POS_DEFAULT_LOGO;
                    } else {
                        raw = 'public/assets/brand/laptop-duhok-logo.png';
                    }
                }
                if (opts.raw) return raw;
                if (/^(data:|blob:|https?:|\/\/)/i.test(raw)) return raw;
                return window.absAssetUrl(raw);
            };
        }
        if (typeof window.syncHomeShopLogo !== 'function') {
            window.syncHomeShopLogo = function() {
                var img = document.getElementById('home-shop-logo-img');
                if (!img) return;
                var url = typeof window.getPosShopLogoUrl === 'function' ? window.getPosShopLogoUrl() : '';
                if (url && !/^(data:|blob:)/i.test(url) && url.indexOf('?') < 0) {
                    var v = (typeof window.getPosAppVersion === 'function') ? window.getPosAppVersion() : '';
                    if (v) url += (url.indexOf('?') >= 0 ? '&' : '?') + 'v=' + encodeURIComponent(v);
                }
                if (url) img.src = url;
                var wrap = img.closest ? img.closest('.view-home-hero-icon--logo') : img.parentElement;
                if (wrap) wrap.style.display = url ? '' : 'none';
            };
        }
        if (typeof window.posBrandWithVersion !== 'function') {
            window.posBrandWithVersion = function() {
                return 'Laptop Duhok POS v' + window.getPosAppVersion();
            };
        }
        window.POS_FONT_FAMILY = "'Rudaw', 'Segoe UI', Tahoma, sans-serif";
        if (typeof window.posUiFontFamily !== 'function') {
            window.posUiFontFamily = function() { return window.POS_FONT_FAMILY; };
        }

        /** Normalize phone for duplicate checks on receipts. */
        if (typeof window.normalizeReceiptPhoneDigits !== 'function') {
            window.normalizeReceiptPhoneDigits = function(phone) {
                var d = String(phone || '').replace(/\D/g, '');
                if (d.indexOf('964') === 0 && d.length >= 12) d = '0' + d.slice(3);
                return d;
            };
        }
        if (typeof window.phonesReceiptSame !== 'function') {
            window.phonesReceiptSame = function(a, b) {
                var da = window.normalizeReceiptPhoneDigits(a);
                var db = window.normalizeReceiptPhoneDigits(b);
                if (!da || !db) return false;
                if (da === db) return true;
                if (da.length >= 10 && db.length >= 10) return da.slice(-10) === db.slice(-10);
                return false;
            };
        }

        /** Subtle receipt brand (name + phone) — all thermal/A4 prints. */
        if (typeof window.getPosReceiptBrandInfo !== 'function') {
            window.getPosReceiptBrandInfo = function() {
                var b = (typeof window !== 'undefined' && window.POS_RECEIPT_BRAND) ? window.POS_RECEIPT_BRAND : {};
                return {
                    name: String(b.name || 'Laptop Duhok POS').trim(),
                    phone: String(b.phone || '07507367680').trim()
                };
            };
        }
        if (typeof window.buildPosReceiptBrandFooterHtml !== 'function') {
            window.buildPosReceiptBrandFooterHtml = function(opts) {
                opts = opts || {};
                var info = window.getPosReceiptBrandInfo();
                var esc = (typeof escapeHtml === 'function') ? escapeHtml : function(s) {
                    return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
                };
                var tf = typeof t === 'function';
                var tagLabel = tf ? (t('print_receipt_developer_tag') || 'سیستەمێ POS · پەرەپێدەر') : 'سیستەمێ POS · پەرەپێدەر';
                var variant = opts.variant === 'a4' ? 'a4' : 'thermal';
                var proBar = opts.proBar === true ? ' pos-receipt-brand-footer--pro-bar' : '';
                return '<div class="pos-receipt-brand-footer pos-receipt-brand-footer--' + variant + proBar + '" data-receipt-role="developer" style="color:#000 !important; opacity:1 !important; font-weight:800 !important;">' +
                    '<span class="pos-receipt-brand-tag" style="color:#000 !important; opacity:1 !important;">' + esc(tagLabel) + '</span>' +
                    '<span class="pos-receipt-brand-line-main" style="color:#000 !important;">' +
                    (info.phone ? '<span class="pos-receipt-brand-phone" dir="ltr" style="color:#000 !important; font-weight:800 !important;">' + esc(info.phone) + '</span><span class="pos-receipt-brand-sep" style="color:#000 !important; opacity:1 !important;"> · </span>' : '') +
                    '<span class="pos-receipt-brand-name" style="color:#000 !important; font-weight:800 !important;">' + esc(info.name) + '</span>' +
                    '</span></div>';
            };
        }
        if (typeof window.ensurePosReceiptBrandInHtml !== 'function') {
            window.ensurePosReceiptBrandInHtml = function(html) {
                var h = String(html || '');
                if (!h || h.indexOf('pos-receipt-brand-footer') >= 0) return h;
                if (typeof window.buildPosReceiptBrandFooterHtml !== 'function') return h;
                h = h.replace(/<div class="receipt-brand-line">[^<]*<\/div>/gi, '');
                h = h.replace(/<div style="margin-top:15px;[^"]*"[^>]*>\s*<b>\s*Laptop Duhok POS\s*<\/b>\s*<\/div>/gi, '');
                var variant = (/invoice-a4-|a4-invoice|print-a4-container/i.test(h)) ? 'a4' : 'thermal';
                var brand = window.buildPosReceiptBrandFooterHtml({ variant: variant });
                if (/print-thermal-container|print-a4-container|a4-invoice/i.test(h)) {
                    return h.replace(/(<\/div>\s*)$/, brand + '$1');
                }
                return h + brand;
            };
        }

        /** USB barcode scanners — skip auto-focus on narrow touch phones (soft keyboard). */
        if (typeof window.shouldAutoFocusScannerInput !== 'function') {
            window.shouldAutoFocusScannerInput = function() {
                try {
                    if (window.matchMedia('(pointer: coarse)').matches && window.innerWidth < 900) return false;
                } catch (_eCoarse) {}
                if ((navigator.maxTouchPoints || 0) > 0 && window.innerWidth < 900) return false;
                return true;
            };
        }
        /** Focus POS / purchase search for continuous barcode scanning. */
        if (typeof window.focusTxnScannerInput !== 'function') {
            window.focusTxnScannerInput = function(screen, opts) {
                if (!window.shouldAutoFocusScannerInput()) return;
                opts = opts || {};
                var delay = opts.delay != null ? opts.delay : 80;
                var clear = opts.clear !== false;
                var force = opts.force === true;
                var id = String(screen || '');
                if (id === 'pos') {
                    var bill = document.getElementById('pos-bill-panel');
                    if (bill && bill.classList.contains('expanded')) id = 'pos-expand-search-input';
                    else id = 'pos-barcode-input';
                } else if (id === 'purchase') id = 'purchase-search';
                else if (id === 'purchase-returns') id = 'purchase-returns-search';
                else if (id === 'returns') id = 'returns-barcode-input';
                else if (id === 'waste') id = 'waste-barcode-input-main';
                setTimeout(function() {
                    var el = document.getElementById(id);
                    if (!el) return;
                    var ae = document.activeElement;
                    if (!force && ae && ae !== el && (ae.tagName === 'INPUT' || ae.tagName === 'TEXTAREA' || ae.tagName === 'SELECT') && !ae.readOnly && !ae.disabled && ae.id !== 'pos-barcode-input' && ae.id !== 'pos-expand-search-input') {
                        if (ae.id === 'pos-customer-name' || ae.id === 'pos-customer-phone' || ae.id === 'pos-discount' || ae.id === 'pos-expand-customer-name' || ae.id === 'pos-expand-customer-phone' || ae.id === 'pos-expand-customer-paid') {
                            return;
                        }
                    }
                    if (clear && el.value !== '') {
                        el.value = '';
                        if (screen === 'pos' && typeof debouncedRenderPOSMenu === 'function') debouncedRenderPOSMenu('');
                        if (screen === 'waste' && typeof debouncedRenderWasteMenu === 'function') debouncedRenderWasteMenu('');
                    } else if (clear) {
                        el.value = '';
                    }
                    try { el.focus({ preventScroll: true }); } catch (_eFocus) { el.focus(); }
                    if (screen === 'purchase' && typeof debouncedRenderPurchaseProductGrid === 'function') debouncedRenderPurchaseProductGrid();
                    if (screen === 'purchase-returns' && typeof debouncedRenderPurchaseReturnsProductGrid === 'function') debouncedRenderPurchaseReturnsProductGrid();
                }, delay);
            };
        }

        // Financial precision guard: avoid float-drift with integer-math normalization (IQD scale=3).
        if (typeof window.roundMoney !== 'function') {
            window.roundMoney = function(v) {
                if (v == null) return 0;
                var val = parseFloat(String(v).replace(/,/g, '')) || 0;
                // Use a small epsilon to handle precision issues before rounding to 3 decimals
                return Math.round((val + 0.0000001) * 1000) / 1000;
            };
        }

        // --- MOBILE WAKE UP SYNC ---
        var _posVisibilitySyncTimer = null;
        document.addEventListener("visibilitychange", () => {
            if (document.visibilityState !== "visible") return;
            if (typeof isPosCpuSaveMode === 'function' && isPosCpuSaveMode()) {
                if (_posVisibilitySyncTimer) clearTimeout(_posVisibilitySyncTimer);
                var _visMs = (typeof posPollIntervalMs === 'function') ? posPollIntervalMs(60000) : 60000;
                _posVisibilitySyncTimer = setTimeout(function () {
                    _posVisibilitySyncTimer = null;
                    if (typeof syncLiveData === 'function') syncLiveData(false);
                }, _visMs);
                return;
            }
            if (typeof syncLiveData === 'function') syncLiveData(false);
        });

        // --- AUTO-CONVERT ARABIC/KURDISH NUMERALS ---
        document.addEventListener('input', function(e) {
            const el = e.target;
            if ((el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') && el.type !== 'file' && el.type !== 'checkbox' && el.type !== 'radio') {
                const val = el.value;
                if (/[\u0660-\u0669\u06F0-\u06F9]/.test(val)) {
                    const converted = val.replace(/[\u0660-\u0669]/g, function(d) { return d.charCodeAt(0) - 0x0660; })
                                         .replace(/[\u06F0-\u06F9]/g, function(d) { return d.charCodeAt(0) - 0x06F0; });
                    let start = null, end = null;
                    try { start = el.selectionStart; end = el.selectionEnd; } catch(err) {}
                    
                    el.value = converted;
                    var pk = (typeof resolveMoneyInputFormatKind === 'function')
                        ? resolveMoneyInputFormatKind(el)
                        : null;
                    if (pk == null) {
                        const payFmtKind = { 'pay-received': 'iqd', 'pay-usd-input': 'usd', 'pay-debt-amount': null, 'pay-bank-card-amount': null, 'ppay-received': 'iqd', 'ppay-usd-input': 'usd', 'ppay-debt-amount': null, 'ppay-bank-card-amount': null, 'purchase-supplier-paid': null };
                        pk = payFmtKind[el.id];
                        if (pk == null && el.id === 'purchase-supplier-paid') {
                            pk = (typeof getPurchasePaymentInputKind === 'function') ? getPurchasePaymentInputKind() : ((typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD') ? 'usd' : 'int');
                        }
                        if (pk == null && (el.id === 'pay-debt-amount' || el.id === 'pay-bank-card-amount')) {
                            pk = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD') ? 'usd' : 'int';
                        }
                        if (pk == null && (el.id === 'ppay-debt-amount' || el.id === 'ppay-bank-card-amount')) {
                            pk = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD') ? 'usd' : 'int';
                        }
                    }
                    if (pk && typeof formatPaymentInputElement === 'function') {
                        formatPaymentInputElement(el, pk);
                    } else if (start !== null && el.setSelectionRange) { try { el.setSelectionRange(start, end); } catch(err) {} }
                }
                if (el.classList && el.classList.contains('pos-money-input') && typeof formatPaymentInputElement === 'function') {
                    var mk = (typeof resolveMoneyInputFormatKind === 'function') ? resolveMoneyInputFormatKind(el) : null;
                    if (mk) formatPaymentInputElement(el, mk);
                }
                if (el.id === 'cc-edit-opening-balance' || el.id === 'cc-edit-debt-limit' || el.id === 'c-opening-balance' || el.id === 'new-cust-opening-balance') {
                    if (typeof syncDuhokPaperUsdInputHints === 'function') syncDuhokPaperUsdInputHints();
                }
                if (el.id && /^(p-price|p-cost|p-price-pack|p-cost-pack|p-price-carton|p-cost-carton)$/.test(el.id)) {
                    if (typeof updateProductFormFxHints === 'function') updateProductFormFxHints();
                }
            }
        });

        // Clear numeric fields on click/tap so cashier can type a new value quickly.
        function isClearOnClickNumericInput(el) {
            if (!el || el.tagName !== 'INPUT' || el.disabled || el.readOnly) return false;
            // Do not auto-clear cart row editors; they should always show current values.
            if (
                el.classList.contains('returns-row-disc') ||
                el.classList.contains('returns-row-price') ||
                el.classList.contains('bill-inline-price') ||
                el.classList.contains('bill-inline-qty') ||
                (el.closest && (
                    el.closest('#purchase-cart-rows') ||
                    el.closest('#purchase-returns-cart-rows') ||
                    el.closest('#returns-bill-rows') ||
                    el.closest('#bill-rows') ||
                    el.closest('.returns-row-qty-wrap')
                ))
            ) return false;
            var type = (el.type || '').toLowerCase();
            var inputMode = (el.getAttribute('inputmode') || '').toLowerCase();
            if (el.id === 'cc-edit-name' || el.id === 'cc-edit-phone' || el.id === 'cc-edit-address') return false;
            if (type === 'number') return true;
            if (inputMode === 'numeric' || inputMode === 'decimal') return true;
            // Numeric-like text fields used in payment and product pricing.
            if (type === 'text' && /(price|cost|qty|quantity|amount|discount|rate|received|debt|bank|usd)/i.test(el.id || '')) return true;
            return false;
        }

        document.addEventListener('pointerdown', function(e) {
            var el = e.target;
            if (!isClearOnClickNumericInput(el)) return;
            el.dataset.clearOnClickPending = '1';
        }, true);

        document.addEventListener('focusin', function(e) {
            var el = e.target;
            if (!isClearOnClickNumericInput(el)) return;
            if (el.dataset.clearOnClickPending !== '1') return;
            if (!el.value) {
                el.dataset.clearOnClickPending = '0';
                return;
            }
            el.value = '';
            // Keep dependent totals/previews synced.
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dataset.clearOnClickPending = '0';
        });

        document.addEventListener('blur', function(e) {
            var el = e.target;
            if (!el || el.tagName !== 'INPUT') return;
            if (el.dataset && el.dataset.clearOnClickPending) el.dataset.clearOnClickPending = '0';
        }, true);

        // (normalizeForSearch, auth, currency, getAllSales, getFinancialMetrics, getReportSales, getBusinessDate, parseSQLDate, getBusinessMonth provided by main.js from modules)

        // --- STARTUP LOGIC ---
        function posSetLicenseBlockedUi(active) {
            var wrap = document.getElementById('app-content-wrap');
            if (wrap) wrap.style.display = active ? 'none' : '';
        }

        function posShowLicenseBlocked(data) {
            if (typeof hideAppBootLoader === 'function') hideAppBootLoader();
            var msg = (data && data.message) ? data.message : 'الترخيص غير مفعّل.';
            var serial = (data && data.license_serial) ? data.license_serial : '';
            var secCode = (data && data.license_security_code) ? String(data.license_security_code) : '';
            var ov = document.getElementById('license-block-screen');
            var mEl = document.getElementById('license-block-msg');
            var sEl = document.getElementById('license-block-serial');
            var secEl = document.getElementById('license-block-security');
            var techEl = document.getElementById('license-block-tech');
            var startup = document.getElementById('startup-screen');
            var login = document.getElementById('login-screen');
            if (startup) startup.style.display = 'none';
            if (login) login.style.display = 'none';
            posSetLicenseBlockedUi(true);
            try {
                currentUser = null;
            } catch (_eCu) {}
            if (ov && mEl && sEl) {
                mEl.textContent = msg;
                sEl.textContent = serial || '(غير متوفر — راجع قاعدة البيانات settings.pos_license_serial)';
                if (secEl) secEl.textContent = secCode || '(غير متوفر — راجع settings.pos_license_security_code)';
                if (techEl) {
                    var bits = [];
                    if (data && data.license_http_code != null && data.license_http_code !== '') bits.push('HTTP ' + data.license_http_code);
                    if (data && data.license_detail) bits.push(String(data.license_detail));
                    if (data && data.license_curl_error) bits.push(String(data.license_curl_error));
                    if (bits.length) {
                        techEl.style.display = 'block';
                        techEl.textContent = bits.join(' · ');
                    } else {
                        techEl.style.display = 'none';
                        techEl.textContent = '';
                    }
                }
                ov.style.display = 'flex';
            } else {
                var s2 = (data && data.license_security_code) ? String(data.license_security_code) : '';
                var both = serial ? ('\n\nSerial: ' + serial) : '';
                if (s2) both += '\nSecurity: ' + s2;
                alert(msg + both);
            }
            if (typeof posStartLicenseRecheckPoll === 'function') posStartLicenseRecheckPoll();
        }

        function posHideDeviceBlockedScreen() {
            try {
                var ov = document.getElementById('device-block-screen');
                if (ov) ov.style.display = 'none';
            } catch (_eDb) {}
            posStopDeviceApprovalPoll();
        }

        function posIsTerminalProPlusBlock(data) {
            if (!data || !posIsFragiDeviceMode()) return false;
            if (data.status === 'terminal_pro_required' || data.status === 'terminal_pro_plus_required') return true;
            var det = '';
            try {
                det = String(data.device_register_detail || data.device_detail || data.device_status || '');
            } catch (_eDet) { det = ''; }
            if (det === 'pro_required' || det === 'pro_plus_required') return true;
            return false;
        }

        function posHideTerminalProPlusRequiredScreen() {
            try {
                var ov = document.getElementById('terminal-pro-plus-screen');
                if (ov) ov.style.display = 'none';
            } catch (_eTp) {}
            posStopDeviceApprovalPoll();
        }

        function posShowTerminalProPlusRequiredScreen(data) {
            if (posIsRemoteLanPosClient() || posIsFragiDeviceMode()) {
                posShowTerminalActivationScreen(Object.assign({}, data || {}, {
                    terminal_activation_required: true,
                    device_detail: (data && data.device_detail) ? data.device_detail : 'slot_required',
                    message: (typeof t === 'function')
                        ? t('terminal_mobile_enter_term')
                        : 'کۆدێ TERM ژ لاپتۆپێ سەرەکی ل ڤێرێ بنڤیسە'
                }));
                return;
            }
            posHideDeviceBlockedScreen();
            posStopDeviceApprovalPoll();
            var msg = (data && data.message) ? String(data.message) : '';
            if (!msg && typeof t === 'function') {
                msg = t('terminal_pro_required_msg');
            }
            if (!msg) {
                msg = 'Pro plan is required to enable sub-device/terminal (branch) access. Upgrade from Basic, then purchase $99 slots per device.';
            }
            var serial = '';
            try {
                if (data && data.license_serial) serial = String(data.license_serial);
            } catch (_eSer) { serial = ''; }
            if (!serial && typeof window.__POS_PUBLIC_INSTALL_SERIAL__ !== 'undefined') {
                serial = String(window.__POS_PUBLIC_INSTALL_SERIAL__ || '');
            }
            var startup = document.getElementById('startup-screen');
            var login = document.getElementById('login-screen');
            if (startup) startup.style.display = 'none';
            if (login) login.style.display = 'none';
            try {
                var lic = document.getElementById('license-block-screen');
                if (lic) lic.style.display = 'none';
            } catch (_eLc) {}
            var ov = document.getElementById('terminal-pro-plus-screen');
            var mEl = document.getElementById('terminal-pro-plus-msg');
            var sEl = document.getElementById('terminal-pro-plus-serial');
            if (ov) {
                if (mEl) mEl.textContent = msg;
                if (sEl) sEl.textContent = serial || '(—)';
                ov.style.display = 'flex';
            } else {
                alert(msg);
            }
        }

        function posGoProPlusUpgradeFromTerminalScreen() {
            if (typeof selectPremiumLockPlan === 'function') {
                selectPremiumLockPlan('pro_plus');
            }
            if (typeof showPremiumLockedPurchasePopup === 'function') {
                showPremiumLockedPurchasePopup('');
            }
        }
        window.posShowTerminalProPlusRequiredScreen = posShowTerminalProPlusRequiredScreen;
        window.posHideTerminalProPlusRequiredScreen = posHideTerminalProPlusRequiredScreen;
        window.posGoProPlusUpgradeFromTerminalScreen = posGoProPlusUpgradeFromTerminalScreen;
        window.posIsTerminalProPlusBlock = posIsTerminalProPlusBlock;

        function posIsRemoteMobilePosClient() {
            try {
                var h = String(location.hostname || '').toLowerCase();
                if (h === '' || h === 'localhost' || h === '127.0.0.1') {
                    return false;
                }
                return /android|iphone|ipad|ipod|mobile/i.test(navigator.userAgent || '');
            } catch (_eRh) {
                return false;
            }
        }

        /** POS opened via LAN IP (not localhost) — server treats as sub-device (TERM code). */
        function posIsRemoteLanPosClient() {
            try {
                var h = String(location.hostname || '').toLowerCase();
                if (h === '' || h === 'localhost' || h === '127.0.0.1') {
                    return false;
                }
                if (/^\d{1,3}(\.\d{1,3}){3}$/.test(h)) {
                    return true;
                }
                if (h.indexOf(':') !== -1) {
                    return true;
                }
                return posIsRemoteMobilePosClient();
            } catch (_eLan) {
                return false;
            }
        }

        function posLooksLikeTerminalActivationCode(code) {
            var c = String(code || '').trim().toUpperCase();
            if (!c) {
                return false;
            }
            if (c.indexOf('TERM') === 0) {
                return true;
            }
            return /^[A-Z0-9]{4}[\s-]+[A-Z0-9]{4,}$/.test(c);
        }

        function posFormatDeviceDetail(detail) {
            var d = String(detail || '').trim();
            if (!d) {
                return '';
            }
            if (typeof t === 'function') {
                var key = 'terminal_' + d;
                var msg = t(key);
                if (msg && msg !== key) {
                    return msg;
                }
            }
            return d;
        }

        function posIsFragiDeviceMode() {
            try {
                if (localStorage.getItem('pos_fragi_device_mode') === '1') {
                    return true;
                }
                var k = (typeof window.__posDeviceKey === 'string' && window.__posDeviceKey)
                    ? String(window.__posDeviceKey)
                    : (localStorage.getItem('pos_client_device_key') || '');
                return k.indexOf('pos-term-') === 0;
            } catch (_eFm) {
                return false;
            }
        }

        function posIsTerminalConnectionAttempt() {
            return posIsFragiDeviceMode();
        }

        function posShouldShowTerminalActivationScreen(data) {
            if (posIsTerminalProPlusBlock(data) && (posIsRemoteLanPosClient() || posIsFragiDeviceMode())) {
                return true;
            }
            if (posIsTerminalProPlusBlock(data)) return false;
            if (data && (data.terminal_open_access === true || data.terminal_security_required === false)) {
                return false;
            }
            var det = String((data && data.device_detail) || '');
            var needsTerm = !!(data && data.terminal_activation_required)
                || det === 'slot_required'
                || det === 'remote_fragi_required'
                || det === 'network_mac_required'
                || det === 'pending';
            var isTermCtx = posIsTerminalConnectionAttempt() || posIsRemoteLanPosClient();
            if (!isTermCtx) {
                return false;
            }
            if (needsTerm) {
                return true;
            }
            if (data && data.status === 'device_blocked' && posIsTerminalConnectionAttempt()) {
                if (data.terminal_security_required === false) return false;
                if (det === '' || det === 'pending') return true;
            }
            return false;
        }

        function posHideTerminalActivationScreen() {
            try {
                var ov = document.getElementById('terminal-activation-screen');
                if (ov) ov.style.display = 'none';
            } catch (_eTa) {}
        }

        function posLoadTerminalNetworkIdentity() {
            if (typeof apiJson !== 'function') return Promise.resolve(null);
            var qs = 'action=get_terminal_network_identity&t=' + Date.now();
            try {
                var seed = window.__posFragiClientSeed || localStorage.getItem('pos_fragi_client_seed') || '';
                if (seed) qs += '&client_seed=' + encodeURIComponent(seed);
            } catch (_eSn) {}
            var url = typeof window.posRouterUrl === 'function'
                ? window.posRouterUrl(qs)
                : ('?' + qs);
            return apiJson(url).catch(function () { return null; });
        }

        function posNormalizeTerminalSecurityCode(raw) {
            var c = String(raw || '').trim().toUpperCase().replace(/\s+/g, '');
            if (!c) return '';
            if (c.indexOf('TERM') === 0) {
                var rest = c.replace(/^TERM[-]?/i, '').replace(/[^A-Z0-9]/g, '');
                if (rest.length >= 8) {
                    return 'TERM-' + rest.slice(0, 4) + '-' + rest.slice(4, 8);
                }
                if (rest.length >= 4) {
                    return 'TERM-' + rest.slice(0, 4) + (rest.length > 4 ? '-' + rest.slice(4) : '');
                }
            }
            return c;
        }
        window.posNormalizeTerminalSecurityCode = posNormalizeTerminalSecurityCode;

        function posShowTerminalActivationScreen(data) {
            posHideDeviceBlockedScreen();
            posHideTerminalProPlusRequiredScreen();
            posStopDeviceApprovalPoll();
            try {
                localStorage.setItem('pos_fragi_device_mode', '1');
            } catch (_eFrMode) {}
            var serial = '';
            try {
                if (data && data.license_serial) serial = String(data.license_serial);
            } catch (_eS) { serial = ''; }
            if (!serial && typeof window.__POS_PUBLIC_INSTALL_SERIAL__ !== 'undefined') {
                serial = String(window.__POS_PUBLIC_INSTALL_SERIAL__ || '');
            }
            var startup = document.getElementById('startup-screen');
            var login = document.getElementById('login-screen');
            if (startup) startup.style.display = 'none';
            if (login) login.style.display = 'none';
            try {
                var lic = document.getElementById('license-block-screen');
                if (lic) lic.style.display = 'none';
            } catch (_eLc) {}
            var ov = document.getElementById('terminal-activation-screen');
            var macEl = document.getElementById('terminal-activation-mac');
            var serialEl = document.getElementById('terminal-activation-serial');
            var msgEl = document.getElementById('terminal-activation-status-msg');
            if (serialEl) serialEl.textContent = serial || '(—)';
            if (msgEl) { msgEl.style.display = 'none'; msgEl.textContent = ''; msgEl.style.color = ''; }
            var descEl = document.getElementById('terminal-activation-msg');
            if (descEl && data && data.message) {
                descEl.textContent = String(data.message);
            }
            if (ov) ov.style.display = 'flex';
            if (typeof posBindTerminalActivationFormHandlers === 'function') posBindTerminalActivationFormHandlers();
            if (typeof applyTerminalSecuritySettingsUI === 'function') applyTerminalSecuritySettingsUI();
            var macFromData = (data && data.network_mac) ? String(data.network_mac) : '';
            if (macEl) macEl.textContent = macFromData || '…';
            posLoadTerminalNetworkIdentity().then(function (net) {
                if (!net || net.status !== 'success') return;
                if (macEl && net.network_mac) macEl.textContent = String(net.network_mac);
                window.__posTerminalNetworkIdentity = net;
            });
            var termInpFocus = document.getElementById('terminal-activation-code-input');
            if (termInpFocus) {
                setTimeout(function () { try { termInpFocus.focus(); } catch (_eFc) {} }, 120);
            }
        }

        function posFocusTerminalCodeInput() {
            var inp = document.getElementById('terminal-activation-code-input');
            if (!inp) return;
            inp.focus();
            inp.select();
        }
        window.posFocusTerminalCodeInput = posFocusTerminalCodeInput;

        function posPasteTerminalCodeFromClipboard() {
            var inp = document.getElementById('terminal-activation-code-input');
            if (!inp) return;
            if (navigator.clipboard && navigator.clipboard.readText) {
                navigator.clipboard.readText().then(function (txt) {
                    if (txt) {
                        inp.value = (typeof posNormalizeTerminalSecurityCode === 'function')
                            ? posNormalizeTerminalSecurityCode(txt)
                            : String(txt).trim();
                        inp.focus();
                    }
                }).catch(function () { posFocusTerminalCodeInput(); });
            } else {
                posFocusTerminalCodeInput();
            }
        }
        window.posPasteTerminalCodeFromClipboard = posPasteTerminalCodeFromClipboard;

        function posRedeemTerminalActivationCode(opts) {
            opts = opts || {};
            var inp = opts.inputEl || document.getElementById('terminal-activation-code-input');
            var msgEl = opts.msgEl || document.getElementById('terminal-activation-status-msg');
            var btn = opts.btnEl || document.getElementById('terminal-activation-submit-btn');
            var code = inp ? posNormalizeTerminalSecurityCode(inp.value) : '';
            if (inp && code && inp.value !== code) {
                inp.value = code;
            }
            if (!code) {
                if (msgEl) {
                    msgEl.style.display = 'block';
                    msgEl.style.color = '#fca5a5';
                    msgEl.textContent = (typeof t === 'function') ? t('terminal_activation_code_empty') : 'Enter terminal code.';
                }
                if (inp) inp.focus();
                return;
            }
            try {
                localStorage.setItem('pos_fragi_device_mode', '1');
            } catch (_eFrRedeem) {}
            if (btn) {
                btn.disabled = true;
                if (!btn.dataset._termBtnHtml) btn.dataset._termBtnHtml = btn.innerHTML;
                btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ' + ((typeof t === 'function') ? (t('terminal_activation_activating') || 'چالاکدەکرێت…') : 'چالاکدەکرێت…');
            }
            if (msgEl) {
                msgEl.style.display = 'block';
                msgEl.style.color = '#94a3b8';
                msgEl.textContent = (typeof t === 'function') ? (t('terminal_activation_activating') || 'چالاکدەکرێت…') : 'چالاکدەکرێت…';
            }
            var fd = new FormData();
            fd.append('action', 'redeem_terminal_activation_code');
            fd.append('code', code);
            var dk = '';
            try {
                if (typeof window.__posDeviceKey === 'string' && window.__posDeviceKey) {
                    dk = window.__posDeviceKey;
                    fd.append('device_key', dk);
                }
            } catch (_eDk) {}
            var net = window.__posTerminalNetworkIdentity || {};
            if (net.network_mac) fd.append('network_mac', String(net.network_mac));
            if (net.network_type) fd.append('network_type', String(net.network_type));
            try {
                var cs = window.__posFragiClientSeed || localStorage.getItem('pos_fragi_client_seed') || '';
                if (cs) fd.append('client_seed', String(cs));
            } catch (_eCs) {}
            var url = typeof window.posRouterUrl === 'function'
                ? window.posRouterUrl('action=redeem_terminal_activation_code')
                : '?action=redeem_terminal_activation_code';
            var headers = { 'X-POS-Device-Role': 'terminal' };
            if (dk) headers['X-POS-Device-Key'] = dk;
            try {
                var csH = window.__posFragiClientSeed || localStorage.getItem('pos_fragi_client_seed') || '';
                if (csH) headers['X-POS-Client-Seed'] = String(csH);
            } catch (_eCsH) {}
            var fetchOpts = { method: 'POST', body: fd, credentials: 'same-origin', headers: headers };
            if (typeof AbortSignal !== 'undefined' && typeof AbortSignal.timeout === 'function') {
                try { fetchOpts.signal = AbortSignal.timeout(15000); } catch (_eSig) {}
            }
            var fetchReq = fetch(url, fetchOpts);
            if (!fetchOpts.signal) {
                fetchReq = Promise.race([
                    fetchReq,
                    new Promise(function (_r, reject) {
                        setTimeout(function () { reject(new Error('terminal_activation_timeout')); }, 15000);
                    })
                ]);
            }
            fetchReq
                .then(function (r) {
                    return r.text().then(function (t) {
                        try { return JSON.parse(t); } catch (_e) { return { status: 'error', message: t.slice(0, 200) || 'Invalid response' }; }
                    });
                })
                .then(function (data) {
                    if (data && data.status === 'success') {
                        try {
                            localStorage.setItem('pos_fragi_device_mode', '1');
                            localStorage.setItem('pos_enable_multi_device', '0');
                        } catch (_eFr) {}
                        if (msgEl) {
                            msgEl.style.display = 'block';
                            msgEl.style.color = '#86efac';
                            msgEl.textContent = data.message || ((typeof t === 'function') ? t('terminal_activation_success') : 'فرعێ ل سەر ئەم ئامێرە دروستکرا.');
                        }
                        posHideTerminalActivationScreen();
                        setTimeout(function () {
                            if (typeof connectToDB === 'function') connectToDB(false, { fromTerminalCodeRedeem: true });
                            else location.reload();
                        }, 400);
                        return;
                    }
                    if (msgEl) {
                        msgEl.style.display = 'block';
                        msgEl.style.color = '#fca5a5';
                        msgEl.textContent = (data && data.message) ? data.message : 'Terminal activation failed.';
                    }
                })
                .catch(function (err) {
                    if (msgEl) {
                        msgEl.style.display = 'block';
                        msgEl.style.color = '#fca5a5';
                        msgEl.textContent = (err && err.message === 'terminal_activation_timeout')
                            ? ((typeof t === 'function') ? t('terminal_activation_timeout') : 'پەیوەندی درێژ بوو — دووبارە هەوڵ بدە')
                            : ((typeof t === 'function') ? t('activation_code_network_error') : 'Network error.');
                    }
                })
                .finally(function () {
                    if (btn) {
                        btn.disabled = false;
                        if (btn.dataset._termBtnHtml) {
                            btn.innerHTML = btn.dataset._termBtnHtml;
                        }
                    }
                });
        }

        window.posShowTerminalActivationScreen = posShowTerminalActivationScreen;
        window.posHideTerminalActivationScreen = posHideTerminalActivationScreen;
        function posRedeemTerminalActivationCodeFromSettings() {
            posRedeemTerminalActivationCode({
                inputEl: document.getElementById('settings-terminal-security-code-input'),
                msgEl: document.getElementById('settings-terminal-security-msg'),
                btnEl: document.getElementById('settings-terminal-security-submit-btn')
            });
        }

        function applyTerminalSecuritySettingsUI() {
            var card = document.getElementById('settings-terminal-security-card');
            if (!card) return;
            var isTerm = posIsTerminalConnectionAttempt();
            card.style.display = isTerm ? '' : 'none';
            if (!isTerm) return;
            var macEl = document.getElementById('settings-terminal-security-mac');
            if (macEl) {
                var macTxt = (typeof t === 'function') ? t('subdev_network_lan') : 'LAN/Wi‑Fi';
                macEl.textContent = 'MAC: …';
                if (typeof posLoadTerminalNetworkIdentity === 'function') {
                    posLoadTerminalNetworkIdentity().then(function (net) {
                        if (net && net.network_mac && macEl) {
                            macEl.textContent = 'MAC: ' + String(net.network_mac) + (net.network_type ? (' · ' + net.network_type) : '');
                        }
                    });
                }
            }
        }

        window.posRedeemTerminalActivationCode = posRedeemTerminalActivationCode;
        window.posRedeemTerminalActivationCodeFromSettings = posRedeemTerminalActivationCodeFromSettings;
        window.applyTerminalSecuritySettingsUI = applyTerminalSecuritySettingsUI;
        window.posIsFragiDeviceMode = posIsFragiDeviceMode;
        window.posIsTerminalConnectionAttempt = posIsTerminalConnectionAttempt;
        window.posIsRemoteLanPosClient = posIsRemoteLanPosClient;

        function posSyncLanTerminalChrome() {
            var onLan = false;
            var fragi = false;
            try {
                onLan = typeof posIsRemoteLanPosClient === 'function' && posIsRemoteLanPosClient();
                fragi = typeof posIsFragiDeviceMode === 'function' && posIsFragiDeviceMode();
            } catch (_eLanUi) {}
            var badge = document.getElementById('lan-terminal-badge');
            if (badge) {
                badge.style.display = onLan ? 'inline-flex' : 'none';
                if (onLan) {
                    badge.textContent = (typeof t === 'function') ? t('lan_terminal_badge') : 'فرعی · گرێدای سەرەکی';
                }
            }
            var warn = document.getElementById('lan-localhost-warn');
            if (warn) {
                var bad = !onLan && fragi;
                warn.style.display = bad ? 'block' : 'none';
                if (bad) {
                    warn.textContent = (typeof t === 'function')
                        ? t('lan_localhost_warn')
                        : 'لاپتۆبێ فرعی نابیت localhost ڤەکەیت. د Chrome بنڤیسە http://IP-سەرەکی/pos/ — ئەگەر نا، داتە ناچیتە داتابەیسا سەرەکی.';
                }
            }
        }
        window.posSyncLanTerminalChrome = posSyncLanTerminalChrome;

        var _posDeviceApprovalPollTimer = null;
        function posStopDeviceApprovalPoll() {
            if (_posDeviceApprovalPollTimer) {
                clearInterval(_posDeviceApprovalPollTimer);
                _posDeviceApprovalPollTimer = null;
            }
        }

        function posPollDeviceApprovalOnce() {
            if (typeof apiJson !== 'function') return Promise.resolve();
            var url = typeof window.posRouterUrl === 'function'
                ? window.posRouterUrl('action=check_pos_client_device_status&t=' + Date.now())
                : ('?action=check_pos_client_device_status&t=' + Date.now());
            return apiJson(url).then(function (d) {
                if (d && posIsTerminalProPlusBlock(d)) {
                    posShowTerminalProPlusRequiredScreen(d);
                    posStopDeviceApprovalPoll();
                    return;
                }
                if (d && d.ok === true && d.device_status === 'approved') {
                    posStopDeviceApprovalPoll();
                    posHideTerminalProPlusRequiredScreen();
                    if (typeof connectToDB === 'function') connectToDB(false, { fromApprovalPoll: true });
                }
            }).catch(function () {});
        }

        function posStartDeviceApprovalPoll() {
            posStopDeviceApprovalPoll();
            var _devPollMs = (typeof posPollIntervalMs === 'function') ? posPollIntervalMs(15000) : 15000;
            _posDeviceApprovalPollTimer = setInterval(posPollDeviceApprovalOnce, _devPollMs);
        }

        var _posLicenseRecheckTimer = null;
        function posStopLicenseRecheckPoll() {
            if (_posLicenseRecheckTimer) {
                clearInterval(_posLicenseRecheckTimer);
                _posLicenseRecheckTimer = null;
            }
        }

        function posPollLicenseOnce() {
            if (typeof apiJson !== 'function') return Promise.resolve();
            var url = typeof window.posRouterUrl === 'function'
                ? window.posRouterUrl('action=get_login_data&license_recheck=1&t=' + Date.now())
                : ('?action=get_login_data&license_recheck=1&t=' + Date.now());
            return apiJson(url).then(function (d) {
                if (d && d.status === 'license_blocked') {
                    posShowLicenseBlocked(d);
                    return;
                }
                var licOv = document.getElementById('license-block-screen');
                var licVisible = licOv && licOv.style.display && licOv.style.display !== 'none';
                if (licVisible && d && d.status === 'ok') {
                    posSetLicenseBlockedUi(false);
                    if (licOv) licOv.style.display = 'none';
                    if (typeof connectToDB === 'function') {
                        connectToDB(true);
                    } else {
                        location.reload();
                    }
                }
            }).catch(function () {});
        }

        function posStartLicenseRecheckPoll() {
            posStopLicenseRecheckPoll();
            posPollLicenseOnce();
            var _licPollMs = (typeof posPollIntervalMs === 'function') ? posPollIntervalMs(15000) : 15000;
            _posLicenseRecheckTimer = setInterval(posPollLicenseOnce, _licPollMs);
        }

        window.posRestartPollsForGraphics = function () {
            if (_posDeviceApprovalPollTimer) {
                posStopDeviceApprovalPoll();
                posStartDeviceApprovalPoll();
            }
            if (_posLicenseRecheckTimer) {
                posStopLicenseRecheckPoll();
                posStartLicenseRecheckPoll();
            }
        };

        window.posStartLicenseRecheckPoll = posStartLicenseRecheckPoll;
        window.posStopLicenseRecheckPoll = posStopLicenseRecheckPoll;

        function posShowDeviceBlocked(data) {
            if (posIsTerminalProPlusBlock(data)) {
                posShowTerminalProPlusRequiredScreen(data);
                return;
            }
            if (posShouldShowTerminalActivationScreen(data)) {
                posShowTerminalActivationScreen(data);
                return;
            }
            var msg = (data && data.message) ? data.message : 'هذا الجهاز غير معتمد بعد.';
            var serial = '';
            try {
                if (data && data.license_serial) serial = String(data.license_serial);
            } catch (e) { serial = ''; }
            if (!serial && typeof window.__POS_PUBLIC_INSTALL_SERIAL__ !== 'undefined') {
                serial = String(window.__POS_PUBLIC_INSTALL_SERIAL__ || '');
            }
            var hint = (data && data.device_key_hint) ? String(data.device_key_hint) : '';
            if (!hint && typeof window.__posDeviceKey === 'string' && window.__posDeviceKey.length > 16) {
                var dk = window.__posDeviceKey;
                hint = dk.slice(0, 8) + '…' + dk.slice(-4);
            }
            var ov = document.getElementById('device-block-screen');
            var mEl = document.getElementById('device-block-msg');
            var insEl = document.getElementById('device-block-install-serial');
            var keyEl = document.getElementById('device-block-key-hint');
            var techEl = document.getElementById('device-block-tech');
            var startup = document.getElementById('startup-screen');
            var login = document.getElementById('login-screen');
            if (startup) startup.style.display = 'none';
            if (login) login.style.display = 'none';
            if (ov && mEl && insEl && keyEl) {
                mEl.textContent = msg;
                insEl.textContent = serial || '(غير متوفر)';
                keyEl.textContent = hint || '—';
                if (techEl) {
                    var bits = [];
                    if (data && data.device_http_code != null && data.device_http_code !== '') bits.push('HTTP ' + data.device_http_code);
                    if (data && data.device_detail) bits.push(posFormatDeviceDetail(data.device_detail));
                    if (bits.length) {
                        techEl.style.display = 'block';
                        techEl.textContent = bits.join(' · ');
                    } else {
                        techEl.style.display = 'none';
                        techEl.textContent = '';
                    }
                }
                try {
                    var actForm = document.getElementById('device-activation-form');
                    var detHide = String((data && data.device_detail) || '');
                    if (actForm) {
                        actForm.style.display = (detHide === 'remote_fragi_required' && posIsRemoteLanPosClient()) ? 'none' : '';
                    }
                } catch (_eAf) {}
                ov.style.display = 'flex';
            } else {
                alert(msg + (serial ? ('\n\nInstall serial: ' + serial) : '') + (hint ? ('\nDevice: ' + hint) : ''));
            }
            try {
                var lic = document.getElementById('license-block-screen');
                if (lic) lic.style.display = 'none';
            } catch (eLc) {}
            try {
                var actMsg = document.getElementById('device-activation-msg');
                if (actMsg) { actMsg.style.display = 'none'; actMsg.textContent = ''; actMsg.style.color = ''; }
            } catch (eAm) {}
            if (!posIsTerminalSlotRegisterBlock(data)) {
                posStartDeviceApprovalPoll();
            }
        }

        function posIsTerminalSlotRegisterBlock(data) {
            if (!data) return false;
            var r = String(data.reason || data.device_register_detail || '');
            return r === 'terminal_slot_limit' || r === 'mac_bound_to_other_device';
        }

        function posRedeemDeviceActivationCode() {
            var inp = document.getElementById('device-activation-code-input');
            var msgEl = document.getElementById('device-activation-msg');
            var btn = document.getElementById('device-activation-submit-btn');
            var code = inp ? String(inp.value || '').trim() : '';
            if (!code) {
                if (msgEl) {
                    msgEl.style.display = 'block';
                    msgEl.style.color = '#fca5a5';
                    msgEl.textContent = 'أدخل كود التفعيل.';
                }
                return;
            }
            if (posIsRemoteLanPosClient() && !posLooksLikeTerminalActivationCode(code)) {
                if (msgEl) {
                    msgEl.style.display = 'block';
                    msgEl.style.color = '#fca5a5';
                    msgEl.textContent = (typeof t === 'function')
                        ? t('terminal_remote_fragi_required')
                        : 'کۆدی TERM (TERM-XXXX-XXXX) پێویستە — کۆدی ٦ ژمارەیی تەنها بۆ لاپتۆپی سەرەکییە.';
                }
                var termInp = document.getElementById('terminal-activation-code-input');
                if (termInp) {
                    termInp.value = code;
                }
                posShowTerminalActivationScreen({
                    status: 'device_blocked',
                    device_detail: 'remote_fragi_required',
                    terminal_activation_required: true,
                    license_serial: (typeof window.__POS_PUBLIC_INSTALL_SERIAL__ !== 'undefined')
                        ? String(window.__POS_PUBLIC_INSTALL_SERIAL__ || '')
                        : '',
                    message: (typeof t === 'function') ? t('terminal_remote_fragi_required') : ''
                });
                return;
            }
            if (posLooksLikeTerminalActivationCode(code)) {
                posRedeemTerminalActivationCode({ inputEl: inp, msgEl: msgEl, btnEl: btn });
                return;
            }
            if (btn) btn.disabled = true;
            var fd = new FormData();
            fd.append('action', 'redeem_device_activation_code');
            fd.append('code', code);
            var dk = '';
            try {
                if (typeof window.__posDeviceKey === 'string' && window.__posDeviceKey) {
                    dk = window.__posDeviceKey;
                    fd.append('device_key', dk);
                }
            } catch (eDk) {}
            var url = typeof window.posRouterUrl === 'function'
                ? window.posRouterUrl('action=redeem_device_activation_code')
                : '?action=redeem_device_activation_code';
            var fetchOpts = { method: 'POST', body: fd, credentials: 'same-origin', headers: {} };
            if (dk) {
                fetchOpts.headers['X-POS-Device-Key'] = dk;
            }
            fetch(url, fetchOpts)
                .then(function (r) {
                    return r.text().then(function (t) {
                        try { return JSON.parse(t); } catch (e) { return { status: 'error', message: t.slice(0, 200) || 'Invalid response' }; }
                    });
                })
                .then(function (data) {
                    if (data && data.status === 'success') {
                        if (msgEl) {
                            msgEl.style.display = 'block';
                            msgEl.style.color = '#86efac';
                            msgEl.textContent = data.message || 'تم التفعيل — جاري فتح النظام…';
                        }
                        posStopDeviceApprovalPoll();
                        posHideDeviceBlockedScreen();
                        setTimeout(function () {
                            if (typeof connectToDB === 'function') {
                                connectToDB(false, { fromCodeRedeem: true });
                            } else {
                                location.reload();
                            }
                        }, 400);
                        return;
                    }
                    if (msgEl) {
                        msgEl.style.display = 'block';
                        msgEl.style.color = '#fca5a5';
                        msgEl.textContent = (data && data.message) ? data.message : 'فشل التفعيل — تأكد من الكود ومن تسجيل الاسم في الأدمن (③).';
                    }
                })
                .catch(function () {
                    if (msgEl) {
                        msgEl.style.display = 'block';
                        msgEl.style.color = '#fca5a5';
                        msgEl.textContent = 'تعذر الاتصال بالخادم.';
                    }
                })
                .finally(function () {
                    if (btn) btn.disabled = false;
                });
        }

        function posBindTerminalActivationFormHandlers() {
            var termBtn = document.getElementById('terminal-activation-submit-btn');
            var termInp = document.getElementById('terminal-activation-code-input');
            if (termBtn && !termBtn.__posTermClickBound) {
                termBtn.__posTermClickBound = true;
                termBtn.addEventListener('click', function (e) {
                    e.preventDefault();
                    posRedeemTerminalActivationCode();
                });
            }
            if (termInp && !termInp.__posTermKeyBound) {
                termInp.__posTermKeyBound = true;
                termInp.addEventListener('keydown', function (e) {
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        posRedeemTerminalActivationCode();
                    }
                });
            }
        }
        window.posBindTerminalActivationFormHandlers = posBindTerminalActivationFormHandlers;

        function posBindDeviceActivationFormHandlers() {
            var actBtn = document.getElementById('device-activation-submit-btn');
            var actInp = document.getElementById('device-activation-code-input');
            if (actBtn && !actBtn.__posDevActBound) {
                actBtn.__posDevActBound = true;
                actBtn.addEventListener('click', function (e) {
                    e.preventDefault();
                    posRedeemDeviceActivationCode();
                });
            }
            if (actInp && !actInp.__posDevActKeyBound) {
                actInp.__posDevActKeyBound = true;
                actInp.addEventListener('keydown', function (e) {
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        posRedeemDeviceActivationCode();
                    }
                });
            }
        }

        function posInitActivationFormHandlers() {
            posBindDeviceActivationFormHandlers();
            posBindTerminalActivationFormHandlers();
        }
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', posInitActivationFormHandlers);
        } else {
            posInitActivationFormHandlers();
        }

        /** Fill installation serial + security code at bottom of Settings (per installation). */
        function refreshInstallationCodesInSettings(data) {
            var serialEl = document.getElementById('settings-install-serial');
            var secEl = document.getElementById('settings-install-security');
            if (!serialEl && !secEl) return;
            var serial = '';
            var sec = '';
            if (data) {
                if (data.license_serial) serial = String(data.license_serial);
                if (data.license_security_code) sec = String(data.license_security_code);
            }
            if (!serial && typeof db !== 'undefined' && db && db.license_serial) serial = String(db.license_serial);
            if (!sec && typeof db !== 'undefined' && db && db.license_security_code) sec = String(db.license_security_code);
            if (!serial && typeof window.__POS_PUBLIC_INSTALL_SERIAL__ !== 'undefined') {
                serial = String(window.__POS_PUBLIC_INSTALL_SERIAL__ || '');
            }
            var na = (typeof t === 'function') ? t('settings_code_unavailable') : '—';
            if (serialEl) serialEl.textContent = serial || na;
            if (secEl) secEl.textContent = sec || na;
        }
        window.refreshInstallationCodesInSettings = refreshInstallationCodesInSettings;

        function openSettingsInstallCodesModal() {
            var modal = document.getElementById('settings-install-codes-modal');
            if (modal) modal.style.display = 'flex';
            if (typeof refreshInstallationCodesInSettings === 'function') {
                refreshInstallationCodesInSettings(typeof db !== 'undefined' ? db : null);
            }
            var sic = document.getElementById('settings-install-codes');
            if (sic && typeof applyI18nSubtree === 'function') applyI18nSubtree(sic);
        }
        function closeSettingsInstallCodesModal() {
            var modal = document.getElementById('settings-install-codes-modal');
            if (modal) modal.style.display = 'none';
        }
        window.openSettingsInstallCodesModal = openSettingsInstallCodesModal;
        window.closeSettingsInstallCodesModal = closeSettingsInstallCodesModal;

        function getPosPremiumPricing() {
            var d = (typeof window !== 'undefined' && window.POS_PREMIUM_PRICING) ? window.POS_PREMIUM_PRICING : {};
            return {
                featureUsd: parseInt(d.featureUsd, 10) || 50,
                proUsd: parseInt(d.proUsd, 10) || 224,
                proPlusUsd: parseInt(d.proPlusUsd, 10) || 424,
                terminalSlotUsd: parseInt(d.terminalSlotUsd, 10) || 99,
                purchaseBatchUsd: parseInt(d.purchaseBatchUsd, 10) || 25,
                installmentsUsd: parseInt(d.installmentsUsd, 10) || 75
            };
        }
        function getPosFeaturePriceUsd(featureKey) {
            var fk = String(featureKey || '').toLowerCase();
            var p = getPosPremiumPricing();
            if (fk === 'enablepurchasebatch') return p.purchaseBatchUsd;
            if (fk === 'enablecustomerinstallments') return p.installmentsUsd;
            if (fk === 'manufacturerslot') return p.featureUsd;
            return p.featureUsd;
        }
        function formatPosPremiumUsd(amount) {
            var n = parseInt(amount, 10);
            if (isNaN(n)) n = 0;
            return '$' + n;
        }
        function posPremiumFeaturePriceLabel() {
            return formatPosPremiumUsd(getPosPremiumPricing().featureUsd);
        }
        function posPremiumProPriceLabel() {
            return formatPosPremiumUsd(getPosPremiumPricing().proUsd);
        }
        function posPremiumProPlusPriceLabel() {
            return formatPosPremiumUsd(getPosPremiumPricing().proPlusUsd);
        }
        /** Replace $50 / $224 / $424 in already-translated UI text. */
        function posPremiumPriceInText(text) {
            var p = getPosPremiumPricing();
            return String(text || '')
                .replace(/\$50/g, formatPosPremiumUsd(p.featureUsd))
                .replace(/\$75/g, formatPosPremiumUsd(p.installmentsUsd))
                .replace(/\$224/g, formatPosPremiumUsd(p.proUsd))
                .replace(/\$424/g, formatPosPremiumUsd(p.proPlusUsd));
        }
        function applyPosPremiumPricingLabels(root) {
            var p = getPosPremiumPricing();
            var scope = (root && root.querySelectorAll) ? root : document;
            scope.querySelectorAll('[data-pos-price="feature"]').forEach(function (el) {
                el.textContent = formatPosPremiumUsd(p.featureUsd);
            });
            scope.querySelectorAll('[data-pos-price="pro"]').forEach(function (el) {
                el.textContent = formatPosPremiumUsd(p.proUsd);
            });
            scope.querySelectorAll('[data-pos-price="pro_plus"]').forEach(function (el) {
                el.textContent = formatPosPremiumUsd(p.proPlusUsd);
            });
            scope.querySelectorAll('[data-pos-price="terminal"]').forEach(function (el) {
                el.textContent = formatPosPremiumUsd(p.terminalSlotUsd);
            });
            scope.querySelectorAll('[data-pos-price="purchase_batch"]').forEach(function (el) {
                el.textContent = formatPosPremiumUsd(p.purchaseBatchUsd);
            });
            scope.querySelectorAll('[data-pos-price="installments"]').forEach(function (el) {
                el.textContent = formatPosPremiumUsd(p.installmentsUsd);
            });
            scope.querySelectorAll('[data-i18n]').forEach(function (el) {
                var txt = el.textContent || '';
                if (txt.indexOf('$') >= 0) el.textContent = posPremiumPriceInText(txt);
            });
        }
        if (typeof window !== 'undefined') {
            window.getPosPremiumPricing = getPosPremiumPricing;
            window.formatPosPremiumUsd = formatPosPremiumUsd;
            window.posPremiumFeaturePriceLabel = posPremiumFeaturePriceLabel;
            window.posPremiumProPriceLabel = posPremiumProPriceLabel;
            window.posPremiumProPlusPriceLabel = posPremiumProPlusPriceLabel;
            window.posPremiumPriceInText = posPremiumPriceInText;
            window.applyPosPremiumPricingLabels = applyPosPremiumPricingLabels;
            window.getPosFeaturePriceUsd = getPosFeaturePriceUsd;
        }

        /** Subscription tier synced from Supabase via get_data. */
        function getSubscriptionTier() {
            if (!db) return 'free';
            var t = String(db.subscription_tier || (db.settings && db.settings.subscription_tier) || 'free').toLowerCase();
            if (t === 'pro' || t === 'pro_plus') return t;
            return 'free';
        }
        function hasPremiumEntitlement() {
            var tier = getSubscriptionTier();
            return tier === 'pro' || tier === 'pro_plus';
        }
        /** Customer installment plans (قست) — Pro / Pro Plus or à la carte FEAT ($75). */
        function canUseInstallments() {
            if (hasPremiumEntitlement()) return true;
            if (typeof hasPurchasedFeature === 'function' && hasPurchasedFeature('enableCustomerInstallments')) return true;
            if (db && db.settings && db.settings.enableCustomerInstallments === true) {
                var pu = db.settings.premiumFeatureUnlocks;
                var pf = db.settings.purchasedFeatures;
                if ((pu && pu.enableCustomerInstallments) || (pf && pf.enableCustomerInstallments)) return true;
            }
            return false;
        }
        /** Pre-print receipt notes — Pro / Pro Plus or à la carte FEAT ($50). */
        function canUsePrintNotes() {
            if (hasPremiumEntitlement()) return true;
            if (typeof hasPurchasedFeature === 'function' && hasPurchasedFeature('showPrintNotePopup')) return true;
            return false;
        }
        /** À la carte feature purchased ($50) without Pro — entitlements + persisted settings.purchasedFeatures */
        function hasPurchasedFeature(featureKey) {
            if (!featureKey || hasPremiumEntitlement()) return false;
            var k = String(featureKey);
            var kl = k.toLowerCase();
            if (db && db.settings && db.settings.purchasedFeatures && typeof db.settings.purchasedFeatures === 'object') {
                var pf = db.settings.purchasedFeatures;
                if (pf[k] === true || pf[kl] === true) return true;
            }
            if (!db || !db.subscription_entitlements || !db.subscription_entitlements.features) return false;
            var feats = db.subscription_entitlements.features;
            if (feats[k] === true) return true;
            return feats[kl] === true;
        }
        function getSubscriptionEntitlements() {
            return (db && db.subscription_entitlements) ? db.subscription_entitlements : null;
        }
        if (typeof window !== 'undefined') {
            window.hasPurchasedFeature = hasPurchasedFeature;
            window.getSubscriptionEntitlements = getSubscriptionEntitlements;
        }
        function getSubscriptionStaffCap() {
            var tier = getSubscriptionTier();
            if (tier === 'pro_plus') return 99;
            if (tier === 'pro') return 5;
            return 3;
        }
        function canUseMultiDeviceTerminal() {
            return hasPremiumEntitlement();
        }
        /** Default 3 staff; Pro 5; Pro Plus 99; secret menu override only on free tier. */
        function getPosMaxStaffAllowed() {
            var tier = getSubscriptionTier();
            if (tier !== 'free') return getSubscriptionStaffCap();
            var def = 3;
            if (!db || !db.settings) return def;
            if (db.settings.maxStaffAllowed != null && db.settings.maxStaffAllowed !== '') {
                var n = parseInt(db.settings.maxStaffAllowed, 10);
                if (!isNaN(n) && n >= 1 && n <= 999) return n;
            }
            if (db.settings.unlockStaffBeyondFive === true) return 99;
            return def;
        }
        function normalizePosMaxStaffSettings() {
            if (!db || !db.settings) return;
            if (db.settings.maxStaffAllowed == null || db.settings.maxStaffAllowed === '') {
                db.settings.maxStaffAllowed = (db.settings.unlockStaffBeyondFive === true) ? 99 : 3;
            } else {
                var n = parseInt(db.settings.maxStaffAllowed, 10);
                if (isNaN(n) || n < 1) db.settings.maxStaffAllowed = 3;
                else if (n > 999) db.settings.maxStaffAllowed = 999;
                else db.settings.maxStaffAllowed = n;
            }
        }
        function staffCapPurchasePopupMessage() {
            if (getSubscriptionTier() === 'pro') {
                return (typeof t === 'function') ? t('staff_cap_pro_plus_upgrade') : 'Pro: max 5 staff — upgrade to Pro Plus for unlimited.';
            }
            var max = getPosMaxStaffAllowed();
            var tpl = (typeof t === 'function') ? t('staff_cap_purchase_feature') : '';
            if (tpl && tpl !== 'staff_cap_purchase_feature') {
                return tpl.replace(/\{max\}/g, String(max));
            }
            return 'حد الموظفين: ' + max + ' — للزيادة تواصل مع الدعم';
        }
        function showStaffCapPurchasePopup() {
            if (typeof showPremiumLockedPurchasePopup === 'function') {
                showPremiumLockedPurchasePopup(staffCapPurchasePopupMessage());
            } else {
                alert(staffCapPurchasePopupMessage());
            }
        }
        window.getPosMaxStaffAllowed = getPosMaxStaffAllowed;
        window.getSubscriptionTier = getSubscriptionTier;
        window.hasPremiumEntitlement = hasPremiumEntitlement;
        window.canUsePrintNotes = canUsePrintNotes;
        window.canUseInstallments = canUseInstallments;
        window.canUseMultiDeviceTerminal = canUseMultiDeviceTerminal;
        window.showStaffCapPurchasePopup = showStaffCapPurchasePopup;

        /** Default 2 POS cart tabs; secret menu → maxCartTabsAllowed (max 8). Tab index 0 = cart 1. */
        var POS_CART_TABS_HARD_MAX = 8;
        function getPosMaxCartTabsAllowed() {
            // Paid tiers unlock all cart tabs automatically.
            if (typeof getSubscriptionTier === 'function') {
                var tier = getSubscriptionTier();
                if (tier === 'pro' || tier === 'pro_plus') return POS_CART_TABS_HARD_MAX;
            }
            var def = 3;
            if (!db || !db.settings) return def;
            if (db.settings.maxCartTabsAllowed != null && db.settings.maxCartTabsAllowed !== '') {
                var n = parseInt(db.settings.maxCartTabsAllowed, 10);
                if (!isNaN(n) && n >= 1 && n <= POS_CART_TABS_HARD_MAX) return Math.max(n, 3);
            }
            return def;
        }
        function normalizePosMaxCartTabsSettings() {
            if (!db || !db.settings) return;
            if (db.settings.maxCartTabsAllowed == null || db.settings.maxCartTabsAllowed === '') {
                db.settings.maxCartTabsAllowed = 3;
            } else {
                var n = parseInt(db.settings.maxCartTabsAllowed, 10);
                if (isNaN(n) || n < 1) db.settings.maxCartTabsAllowed = 3;
                else if (n > POS_CART_TABS_HARD_MAX) db.settings.maxCartTabsAllowed = POS_CART_TABS_HARD_MAX;
                else db.settings.maxCartTabsAllowed = Math.max(n, 3);
            }
        }
        function isPosCartTabAllowed(tabIndex) {
            var idx = parseInt(tabIndex, 10);
            if (isNaN(idx) || idx < 0) return false;
            return idx < getPosMaxCartTabsAllowed();
        }
        function cartTabsCapPurchasePopupMessage() {
            var max = getPosMaxCartTabsAllowed();
            var tpl = (typeof t === 'function') ? t('cart_tabs_cap_upgrade_feature') : '';
            if (tpl && tpl !== 'cart_tabs_cap_upgrade_feature') {
                return tpl.replace(/\{max\}/g, String(max));
            }
            return 'قم بالترقية لنسخة Pro — السلات المسموحة: ' + max;
        }
        function showCartTabsCapPurchasePopup() {
            if (typeof showPremiumLockedPurchasePopup === 'function') {
                showPremiumLockedPurchasePopup(cartTabsCapPurchasePopupMessage());
            } else {
                alert(cartTabsCapPurchasePopupMessage());
            }
        }
        window.getPosMaxCartTabsAllowed = getPosMaxCartTabsAllowed;
        window.showCartTabsCapPurchasePopup = showCartTabsCapPurchasePopup;

        /** Manufacturer companies: Pro unlimited; one-time $50 pack = up to 100 companies. */
        var POS_MFR_PACK_MAX = 100;
        function isManufacturerPackUnlocked() {
            if (!db || !db.settings) return false;
            if (typeof hasPremiumEntitlement === 'function' && hasPremiumEntitlement()) return true;
            var unlocks = db.settings.premiumFeatureUnlocks;
            if (unlocks && (unlocks.manufacturerSlot === true || unlocks.manufacturerSlot === 1 || unlocks.manufacturerSlot === 'true')) return true;
            var pf = db.settings.purchasedFeatures;
            if (pf && pf.manufacturerSlot) return true;
            return getPosManufacturerSlotsPurchased() >= POS_MFR_PACK_MAX;
        }
        function getPosManufacturerSlotsPurchased() {
            if (!db || !db.settings) return 0;
            var n = parseInt(db.settings.manufacturerSlotsPurchased, 10);
            return isNaN(n) || n < 0 ? 0 : n;
        }
        function normalizePosManufacturerSlotSettings() {
            if (!db || !db.settings) return;
            if (typeof isManufacturerPackUnlocked === 'function' && isManufacturerPackUnlocked()) {
                db.settings.manufacturerSlotsPurchased = POS_MFR_PACK_MAX;
                return;
            }
            if (db.settings.manufacturerSlotsPurchased == null || db.settings.manufacturerSlotsPurchased === '') {
                if (typeof hasPremiumEntitlement === 'function' && hasPremiumEntitlement()) {
                    db.settings.manufacturerSlotsPurchased = 0;
                } else {
                    var cur = Array.isArray(db.manufacturers) ? db.manufacturers.length : 0;
                    db.settings.manufacturerSlotsPurchased = cur;
                }
            } else {
                var n = parseInt(db.settings.manufacturerSlotsPurchased, 10);
                db.settings.manufacturerSlotsPurchased = isNaN(n) || n < 0 ? 0 : n;
            }
        }
        function getPosMaxManufacturersAllowed() {
            if (typeof hasPremiumEntitlement === 'function' && hasPremiumEntitlement()) return 9999;
            if (typeof isManufacturerPackUnlocked === 'function' && isManufacturerPackUnlocked()) return POS_MFR_PACK_MAX;
            return getPosManufacturerSlotsPurchased();
        }
        function getPosManufacturerSlotsUsed() {
            return Array.isArray(db && db.manufacturers) ? db.manufacturers.length : 0;
        }
        function canAddManufacturer() {
            return getPosManufacturerSlotsUsed() < getPosMaxManufacturersAllowed();
        }
        function canUseManufacturerCompanies() {
            if (typeof isPremiumSettingsFeatureEnabled === 'function') {
                return isPremiumSettingsFeatureEnabled('premium-mfr-slot');
            }
            if (typeof hasPremiumEntitlement === 'function' && hasPremiumEntitlement()) return true;
            if (typeof isManufacturerPackUnlocked === 'function' && isManufacturerPackUnlocked()) return true;
            return getPosManufacturerSlotsUsed() > 0 || getPosManufacturerSlotsPurchased() > 0;
        }
        function manufacturerSlotPurchasePopupMessage() {
            if (typeof hasPremiumEntitlement === 'function' && hasPremiumEntitlement()) return '';
            var used = getPosManufacturerSlotsUsed();
            var max = getPosMaxManufacturersAllowed();
            var packUnlocked = typeof isManufacturerPackUnlocked === 'function' && isManufacturerPackUnlocked();
            if (packUnlocked && max >= POS_MFR_PACK_MAX && used >= max) {
                return 'سنووری پاکێتا گەیشتی (' + used + '/' + max + ') — Pro بکڕە بۆ بێسنوور.';
            }
            var price = (typeof formatPosPremiumUsd === 'function' && typeof getPosPremiumPricing === 'function')
                ? formatPosPremiumUsd(getPosPremiumPricing().featureUsd)
                : '$50';
            var tpl = (typeof t === 'function') ? t('mfr_slot_purchase_feature') : '';
            if (tpl && tpl !== 'mfr_slot_purchase_feature') {
                return tpl.replace(/\{used\}/g, String(used)).replace(/\{max\}/g, String(max)).replace(/\{price\}/g, price);
            }
            return 'کۆمپانیا دروستکەر: ' + used + '/' + max + ' — یەکجار ' + price + ' بکڕە (تا ' + POS_MFR_PACK_MAX + ' کۆمپانیا) یان Pro.';
        }
        function showManufacturerSlotPurchasePopup() {
            if (typeof showPremiumLockedPurchasePopup === 'function') {
                showPremiumLockedPurchasePopup(manufacturerSlotPurchasePopupMessage(), 'premium-mfr-slot');
            } else {
                alert(manufacturerSlotPurchasePopupMessage());
            }
        }
        window.getPosManufacturerSlotsPurchased = getPosManufacturerSlotsPurchased;
        window.isManufacturerPackUnlocked = isManufacturerPackUnlocked;
        window.POS_MFR_PACK_MAX = POS_MFR_PACK_MAX;
        window.normalizePosManufacturerSlotSettings = normalizePosManufacturerSlotSettings;
        window.getPosMaxManufacturersAllowed = getPosMaxManufacturersAllowed;
        window.getPosManufacturerSlotsUsed = getPosManufacturerSlotsUsed;
        window.canAddManufacturer = canAddManufacturer;
        window.canUseManufacturerCompanies = canUseManufacturerCompanies;
        window.showManufacturerSlotPurchasePopup = showManufacturerSlotPurchasePopup;

        /** Purchase batch/lot (وەجبە): Pro/Pro Plus or à-la-carte FEAT ($25) — user toggle enablePurchaseBatch. */
        function canUsePurchaseBatch() {
            if (typeof isPremiumSettingsFeatureEnabled === 'function') {
                return isPremiumSettingsFeatureEnabled('premium-purchase-batch');
            }
            return !!(db && db.settings && db.settings.enablePurchaseBatch === true);
        }
        function purchaseBatchPurchasePopupMessage() {
            if (canUsePurchaseBatch()) return '';
            var price = (typeof getPosFeaturePriceUsd === 'function')
                ? formatPosPremiumUsd(getPosFeaturePriceUsd('enablePurchaseBatch'))
                : '$25';
            var tpl = (typeof t === 'function') ? t('purchase_batch_purchase_feature') : '';
            if (tpl && tpl !== 'purchase_batch_purchase_feature') {
                return tpl.replace(/\{price\}/g, price);
            }
            return 'ژمارا وەجبێ (batch) تایبەتمەندییەکی Pro یە — Pro بکڕە یان چالاک بکە (' + price + ').';
        }
        function showPurchaseBatchPurchasePopup() {
            if (typeof showPremiumLockedPurchasePopup === 'function') {
                var title = (typeof t === 'function') ? t('purchase_batch_number_label') : 'ژمارا وەجبێ';
                showPremiumLockedPurchasePopup(title + ' · ' + ((typeof getPosFeaturePriceUsd === 'function') ? formatPosPremiumUsd(getPosFeaturePriceUsd('enablePurchaseBatch')) : '$25'), 'premium-purchase-batch');
            } else {
                alert(purchaseBatchPurchasePopupMessage());
            }
        }
        window.canUsePurchaseBatch = canUsePurchaseBatch;
        window.purchaseBatchPurchasePopupMessage = purchaseBatchPurchasePopupMessage;
        window.showPurchaseBatchPurchasePopup = showPurchaseBatchPurchasePopup;

        /** Laptop/phone tech specs (مواسفات): Pro/Pro Plus + toggle, or à-la-carte FEAT ($50). */
        function canUseTechSpecs() {
            if (typeof isPremiumSettingsFeatureEnabled === 'function') {
                return isPremiumSettingsFeatureEnabled('premium-tech-specs');
            }
            return !!(db && db.settings && db.settings.enableTechSpecs === true);
        }
        function techSpecsPurchasePopupMessage() {
            if (canUseTechSpecs()) return '';
            var price = (typeof getPosFeaturePriceUsd === 'function')
                ? formatPosPremiumUsd(getPosFeaturePriceUsd('enableTechSpecs'))
                : '$50';
            var tpl = (typeof t === 'function') ? t('tech_specs_purchase_feature') : '';
            if (tpl && tpl !== 'tech_specs_purchase_feature') {
                return tpl.replace(/\{price\}/g, price);
            }
            return 'مواسفات لاپتۆب / مۆبایل تایبەتمەندییەکی Pro یە — Pro بکڕە یان چالاک بکە (' + price + ').';
        }
        function showTechSpecsPurchasePopup() {
            if (typeof showPremiumLockedPurchasePopup === 'function') {
                var title = (typeof t === 'function') ? t('settings_t_tech_specs') : 'مواسفات لاپتۆب / مۆبایل';
                showPremiumLockedPurchasePopup(title + ' · ' + ((typeof getPosFeaturePriceUsd === 'function') ? formatPosPremiumUsd(getPosFeaturePriceUsd('enableTechSpecs')) : '$50'), 'premium-tech-specs');
            } else {
                alert(techSpecsPurchasePopupMessage());
            }
        }
        window.canUseTechSpecs = canUseTechSpecs;
        window.techSpecsPurchasePopupMessage = techSpecsPurchasePopupMessage;
        window.showTechSpecsPurchasePopup = showTechSpecsPurchasePopup;

        /** After-sale WhatsApp follow-up: Pro/Pro Plus + toggle, or à-la-carte FEAT ($50). */
        function canUseSaleFollowup() {
            if (typeof isPremiumSettingsFeatureEnabled === 'function') {
                return isPremiumSettingsFeatureEnabled('premium-sale-followup');
            }
            return !!(db && db.settings && db.settings.enableSaleFollowup === true);
        }
        function saleFollowupPurchasePopupMessage() {
            if (canUseSaleFollowup()) return '';
            var price = (typeof getPosFeaturePriceUsd === 'function')
                ? formatPosPremiumUsd(getPosFeaturePriceUsd('enableSaleFollowup'))
                : '$50';
            var tpl = (typeof t === 'function') ? t('sale_followup_purchase_feature') : '';
            if (tpl && tpl !== 'sale_followup_purchase_feature') {
                return tpl.replace(/\{price\}/g, price);
            }
            return 'پەیوەندیا پشتی فرۆتنێ تایبەتمەندییەکی Pro یە — Pro بکڕە یان چالاک بکە (' + price + ').';
        }
        function showSaleFollowupPurchasePopup() {
            if (typeof showPremiumLockedPurchasePopup === 'function') {
                var title = (typeof t === 'function') ? t('settings_t_sale_followup') : 'پەیوەندیا پشتی فرۆتنێ';
                showPremiumLockedPurchasePopup(title + ' · ' + ((typeof getPosFeaturePriceUsd === 'function') ? formatPosPremiumUsd(getPosFeaturePriceUsd('enableSaleFollowup')) : '$50'), 'premium-sale-followup');
            } else {
                alert(saleFollowupPurchasePopupMessage());
            }
        }
        window.canUseSaleFollowup = canUseSaleFollowup;
        window.saleFollowupPurchasePopupMessage = saleFollowupPurchasePopupMessage;
        window.showSaleFollowupPurchasePopup = showSaleFollowupPurchasePopup;

        /** Default 5 completed sales per business day; secret menu → maxDailySalesAllowed. */
        function getPosMaxDailySalesAllowed() {
            var def = 5;
            if (!db || !db.settings) return def;
            if (db.settings.maxDailySalesAllowed != null && db.settings.maxDailySalesAllowed !== '') {
                var n = parseInt(db.settings.maxDailySalesAllowed, 10);
                if (!isNaN(n) && n >= 1 && n <= 99999) return n;
            }
            return def;
        }
        function normalizePosMaxDailySalesSettings() {
            if (!db || !db.settings) return;
            if (db.settings.maxDailySalesAllowed == null || db.settings.maxDailySalesAllowed === '') {
                db.settings.maxDailySalesAllowed = 5;
            } else {
                var n = parseInt(db.settings.maxDailySalesAllowed, 10);
                if (isNaN(n) || n < 1) db.settings.maxDailySalesAllowed = 5;
                else if (n > 99999) db.settings.maxDailySalesAllowed = 99999;
                else db.settings.maxDailySalesAllowed = n;
            }
        }
        function getPosBusinessDayKey(d) {
            d = d || new Date();
            var startHour = 0;
            if (db && db.settings && db.settings.businessDayStartHour != null) {
                startHour = parseInt(db.settings.businessDayStartHour, 10);
                if (isNaN(startHour)) startHour = 0;
            }
            var adj = new Date(d.getTime());
            if (adj.getHours() < startHour) adj.setDate(adj.getDate() - 1);
            var m = adj.getMonth() + 1;
            var day = adj.getDate();
            return adj.getFullYear() + '-' + (m < 10 ? '0' : '') + m + '-' + (day < 10 ? '0' : '') + day;
        }
        function getPosDailyCompletedSalesCount() {
            var key = getPosBusinessDayKey();
            var count = 0;
            if (!db || !Array.isArray(db.sales)) return count;
            db.sales.forEach(function (s) {
                if (!s) return;
                var raw = s.created_at || s.date;
                if (!raw) return;
                var d = new Date(raw);
                if (isNaN(d.getTime())) {
                    var s2 = String(raw).replace(' ', 'T');
                    d = new Date(s2);
                    if (isNaN(d.getTime())) return;
                }
                if (getPosBusinessDayKey(d) === key) count++;
            });
            return count;
        }
        function getPosPaymentModalUsesStorageKey() {
            return 'pos_payment_modal_uses_' + getPosBusinessDayKey();
        }
        function getPosDailyPaymentModalUsesCount() {
            try {
                return parseInt(localStorage.getItem(getPosPaymentModalUsesStorageKey()) || '0', 10) || 0;
            } catch (e) {
                return 0;
            }
        }
        function incrementPosDailyPaymentModalUses() {
            try {
                var n = getPosDailyPaymentModalUsesCount() + 1;
                localStorage.setItem(getPosPaymentModalUsesStorageKey(), String(n));
            } catch (e) {}
        }
        function isPosPaymentScreenPremiumUnlocked() {
            return typeof isPremiumFeatureUnlocked === 'function' && isPremiumFeatureUnlocked('set-show-payment-modal');
        }
        /** Secret menu: maxDailySalesAllowed >= 99 → unlimited payment-screen sales after vault unlock. */
        function isPosPaymentModalSalesUnlimited() {
            if (!isPosPaymentScreenPremiumUnlocked()) return false;
            return getPosMaxDailySalesAllowed() >= 99;
        }
        function isPosDailyPaymentModalCapExceeded() {
            if (!isPosPaymentScreenPremiumUnlocked()) return false;
            if (isPosPaymentModalSalesUnlimited()) return false;
            return getPosDailyPaymentModalUsesCount() >= getPosMaxDailySalesAllowed();
        }
        function paymentScreenPremiumFeatureLabel() {
            var card = document.querySelector('.setting-locked-card[data-locked-sync="set-show-payment-modal"] .stc-info h4');
            if (card && card.textContent.trim()) return card.textContent.trim();
            return (typeof t === 'function') ? t('settings_t_payment_modal') : 'شاشة الدفع';
        }
        function paymentDailyCapPopupMessage() {
            var max = getPosMaxDailySalesAllowed();
            var used = getPosDailyPaymentModalUsesCount();
            var tpl = (typeof t === 'function') ? t('payment_daily_cap_upgrade_feature') : '';
            if (tpl && tpl !== 'payment_daily_cap_upgrade_feature') {
                return tpl.replace(/\{max\}/g, String(max)).replace(/\{used\}/g, String(used));
            }
            return 'شاشة الدفع: ' + used + '/' + max + ' — قم بالترقية لنسخة Pro';
        }
        function showPaymentDailyCapPurchasePopup() {
            if (typeof showPremiumLockedPurchasePopup === 'function') {
                showPremiumLockedPurchasePopup(paymentDailyCapPopupMessage());
            } else {
                alert(paymentDailyCapPopupMessage());
            }
        }
        function showPaymentScreenPremiumPopup() {
            if (typeof showPremiumLockedPurchasePopup === 'function') {
                showPremiumLockedPurchasePopup(paymentScreenPremiumFeatureLabel());
            } else {
                alert(paymentScreenPremiumFeatureLabel());
            }
        }
        /**
         * Payment screen (استلام الدفعة): requires secret vault unlock; then max N sales/day (default 5).
         * Set secret maxDailySalesAllowed to 99+ for unlimited Pro. Sell button is never gated here.
         */
        function assertPosPaymentModalAllowed() {
            if (!isPosPaymentScreenPremiumUnlocked()) return 'premium';
            if (isPosPaymentModalSalesUnlimited()) return null;
            if (isPosDailyPaymentModalCapExceeded()) return 'daily_cap';
            return null;
        }
        function showPosSaleGatePopup(reason) {
            if (reason === 'daily_cap') showPaymentDailyCapPurchasePopup();
            else if (reason === 'premium') showPaymentScreenPremiumPopup();
        }
        function isAutoPaymentModalEnabled() {
            if (typeof isPremiumSettingsFeatureEnabled === 'function') {
                return isPremiumSettingsFeatureEnabled('set-show-payment-modal');
            }
            return !!(db && db.settings && db.settings.showPaymentModal === true);
        }
        window._cartPayMethod = { pos: 'cash', purchase: 'cash' };
        try {
            var _payPos = sessionStorage.getItem('pos_cart_pay_pos');
            var _payPur = sessionStorage.getItem('pos_cart_pay_purchase');
            if (_payPos === 'fib' || _payPos === 'cash') window._cartPayMethod.pos = _payPos;
            if (_payPur === 'fib' || _payPur === 'cash') window._cartPayMethod.purchase = _payPur;
        } catch (_ePayStore) {}
        function getCartPayMethod(scope) {
            var s = String(scope || 'pos');
            return (window._cartPayMethod && window._cartPayMethod[s] === 'fib') ? 'fib' : 'cash';
        }
        function setCartPayMethod(scope, method) {
            var s = String(scope || 'pos');
            var m = String(method || '').toLowerCase() === 'fib' ? 'fib' : 'cash';
            if (!window._cartPayMethod) window._cartPayMethod = { pos: 'cash', purchase: 'cash' };
            window._cartPayMethod[s] = m;
            try { sessionStorage.setItem('pos_cart_pay_' + s, m); } catch (_eSet) {}
            document.querySelectorAll('.cart-pay-method-toggle[data-cart-pay="' + s + '"]').forEach(function (g) {
                g.querySelectorAll('.cart-pay-method-btn').forEach(function (btn) {
                    var on = String(btn.getAttribute('data-pay') || '') === m;
                    btn.classList.toggle('is-active', on);
                    btn.setAttribute('aria-pressed', on ? 'true' : 'false');
                });
            });
            if (s === 'purchase') {
                var hid = document.getElementById('purchase-payment-type-value');
                if (hid) hid.value = m;
            }
        }
        function syncCartPayMethodButtons() {
            setCartPayMethod('pos', getCartPayMethod('pos'));
            setCartPayMethod('purchase', getCartPayMethod('purchase'));
        }
        window.getCartPayMethod = getCartPayMethod;
        window.setCartPayMethod = setCartPayMethod;
        window.syncCartPayMethodButtons = syncCartPayMethodButtons;
        window._cartDeliveryOn = false;
        try {
            if (sessionStorage.getItem('pos_cart_delivery_on') === '1') window._cartDeliveryOn = true;
        } catch (_eDelStore) {}
        function isDeliveryFeatureEnabled() {
            if (typeof isPremiumSettingsFeatureEnabled === 'function') {
                return isPremiumSettingsFeatureEnabled('set-enable-delivery');
            }
            return !!(typeof db !== 'undefined' && db && db.settings && db.settings.enableDelivery === true);
        }
        function isCartDeliveryOn() {
            return !!window._cartDeliveryOn && isDeliveryFeatureEnabled();
        }
        function applyCartDeliverySellLabel() {
            var on = isCartDeliveryOn();
            var sellLbl = on
                ? ((typeof t === 'function') ? t('pos_btn_sell_delivery') : 'گەهاندن')
                : ((typeof t === 'function') ? (t('pos_btn_sell') || t('btn_pos_sell')) : 'فروشتن');
            if (sellLbl === 'pos_btn_sell_delivery' || sellLbl === 'pos_btn_sell' || sellLbl === 'btn_pos_sell') {
                sellLbl = on ? 'گەهاندن' : 'فروشتن';
            }
            var icon = on ? 'fa-truck' : 'fa-cash-register';
            var editing = !!(window._posEditingSale && window._posEditingSale.id);
            var returning = typeof isReturnMode !== 'undefined' && isReturnMode;
            if (editing || returning) return;
            document.querySelectorAll('#view-pos .btn-sell-large.btn-sell-primary, #view-pos .btn-expand-sidebar.sell').forEach(function (btn) {
                if (!btn || btn.classList.contains('btn-sell-returns')) return;
                btn.innerHTML = '<i class="fas ' + icon + '" aria-hidden="true"></i> <span>' + sellLbl + '</span>';
                btn.title = sellLbl;
                btn.setAttribute('data-i18n-title', on ? 'pos_btn_sell_delivery' : 'pos_btn_sell');
            });
            document.querySelectorAll('.txn-peek-primary.pos-primary').forEach(function (btn) {
                var txt = btn.querySelector('.txn-peek-primary-text');
                var ic = btn.querySelector('i');
                if (txt) txt.textContent = sellLbl;
                if (ic) ic.className = 'fas ' + icon;
                btn.setAttribute('aria-label', sellLbl);
            });
        }
        function fillPosCartDriverSelect() {
            var sel = document.getElementById('pos-cart-driver-id');
            if (!sel) return;
            var pickD = (typeof t === 'function') ? t('del_driver_pick') : 'سایێق — هەلبژێرە';
            var keep = String(sel.value || '0');
            try {
                var stored = sessionStorage.getItem('pos_last_driver_id');
                if ((!keep || keep === '0') && stored) keep = stored;
            } catch (_eKeep) {}
            var drivers = (typeof db !== 'undefined' && db && Array.isArray(db.drivers) ? db.drivers : []).filter(function (d) {
                return d && (d.is_active == null || Number(d.is_active) !== 0);
            });
            var html = '<option value="0">' + (typeof escapeHtml === 'function' ? escapeHtml(pickD) : pickD) + '</option>';
            drivers.forEach(function (d) {
                var label = (d.name || '') + (d.phone ? ' — ' + d.phone : '');
                html += '<option value="' + d.id + '">' + (typeof escapeHtml === 'function' ? escapeHtml(label) : label) + '</option>';
            });
            sel.innerHTML = html;
            if (keep && keep !== '0') sel.value = keep;
            if ((!sel.value || sel.value === '0') && drivers.length === 1) sel.value = String(drivers[0].id);
        }
        function syncCartDeliveryUI() {
            var featureOn = isDeliveryFeatureEnabled();
            var on = !!window._cartDeliveryOn && featureOn;
            if (!featureOn) window._cartDeliveryOn = false;
            var view = document.getElementById('view-pos');
            var panel = document.getElementById('pos-bill-panel');
            if (view) {
                view.classList.toggle('cart-delivery-on', on);
                view.classList.toggle('pos-delivery-feature-off', !featureOn);
            }
            if (panel) panel.classList.toggle('cart-delivery-on', on);
            document.querySelectorAll('.cart-delivery-toggle-btn').forEach(function (btn) {
                btn.classList.toggle('is-on', on);
                btn.setAttribute('aria-pressed', on ? 'true' : 'false');
                btn.style.display = featureOn ? '' : 'none';
            });
            var drv = document.getElementById('pos-cart-driver-id');
            if (drv) {
                if (on) {
                    fillPosCartDriverSelect();
                    drv.hidden = false;
                    drv.removeAttribute('hidden');
                } else {
                    drv.hidden = true;
                    drv.setAttribute('hidden', '');
                }
            }
            applyCartDeliverySellLabel();
        }
        function setCartDeliveryOn(on) {
            var featureOn = isDeliveryFeatureEnabled();
            window._cartDeliveryOn = !!(on && featureOn);
            try { sessionStorage.setItem('pos_cart_delivery_on', window._cartDeliveryOn ? '1' : '0'); } catch (_eSetDel) {}
            syncCartDeliveryUI();
            var drivers = (typeof db !== 'undefined' && db && Array.isArray(db.drivers) ? db.drivers : []).filter(function (d) {
                return d && (d.is_active == null || Number(d.is_active) !== 0);
            });
            if (window._cartDeliveryOn && !drivers.length && typeof openDriverModal === 'function') {
                var need = (typeof t === 'function') ? t('del_empty_drivers') : 'چ سایێق نینن. دوگمەی سایێق بکە.';
                if (typeof showToast === 'function') showToast(need, 'info');
                openDriverModal();
            }
        }
        function onPosCartDriverChange() {
            var sel = document.getElementById('pos-cart-driver-id');
            var id = sel ? String(sel.value || '0') : '0';
            if (id && id !== '0') {
                try { sessionStorage.setItem('pos_last_driver_id', id); } catch (_eD) {}
            }
            var modalSel = document.getElementById('del-driver-id');
            if (modalSel && id && id !== '0') {
                modalSel.value = id;
                if (typeof onDeliveryDriverChange === 'function') onDeliveryDriverChange();
            }
        }
        window.isDeliveryFeatureEnabled = isDeliveryFeatureEnabled;
        window.isCartDeliveryOn = isCartDeliveryOn;
        window.setCartDeliveryOn = setCartDeliveryOn;
        window.syncCartDeliveryUI = syncCartDeliveryUI;
        window.fillPosCartDriverSelect = fillPosCartDriverSelect;
        window.onPosCartDriverChange = onPosCartDriverChange;
        window.applyCartDeliverySellLabel = applyCartDeliverySellLabel;
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', function () {
                syncCartPayMethodButtons();
                syncCartDeliveryUI();
            });
        } else {
            setTimeout(function () {
                syncCartPayMethodButtons();
                syncCartDeliveryUI();
            }, 0);
        }
        function onPosPaymentWalletClick(ev) {
            if (ev) {
                ev.preventDefault();
                ev.stopPropagation();
            }
            if (!isAutoPaymentModalEnabled()) {
                var offMsg = (typeof t === 'function') ? t('payment_modal_toggle_off') : 'شاشا پارەدانێ نەچالاکە (دوگمەی سەوز)';
                if (typeof showToast === 'function') showToast(offMsg, 'info');
                else alert(offMsg);
                return false;
            }
            var payBlock = typeof assertPosPaymentModalAllowed === 'function' ? assertPosPaymentModalAllowed() : null;
            if (payBlock) {
                if (typeof showPosSaleGatePopup === 'function') showPosSaleGatePopup(payBlock);
                return false;
            }
            if (typeof openPaymentModal === 'function') openPaymentModal();
            return false;
        }
        /**
         * Sell: always completes a sale (cash path if payment screen unavailable).
         * Payment screen (وەرگرتنا پارەی): green toggle ON + Pro unlocked in secret vault → open modal first.
         */
        function sellFromPos() {
            var table = db && db.tables ? db.tables.find(function (t) { return t.id === activeTableId; }) : null;
            if (!table || !table.items || table.items.length === 0) {
                var emptyMsg = (typeof t === 'function') ? t('pos_empty_cart') : '';
                if (!emptyMsg || emptyMsg === 'pos_empty_cart') emptyMsg = 'سەبەتە بەتاڵە!';
                if (typeof showToast === 'function') showToast(emptyMsg, true);
                else alert(emptyMsg);
                return;
            }
            // Edit mode: update existing invoice — do not create a new sale
            if (window._posEditingSale && window._posEditingSale.id && typeof window.savePosEditedSale === 'function') {
                if (typeof window.collapseTxnSheet === 'function') window.collapseTxnSheet('pos');
                window.savePosEditedSale();
                return;
            }
            if (typeof isCartDeliveryOn === 'function' && isCartDeliveryOn()) {
                if (typeof window.sellFromPosAsDelivery === 'function') window.sellFromPosAsDelivery();
                return;
            }
            if (typeof window.syncPosCustomerFieldsForCheckout === 'function') {
                window.syncPosCustomerFieldsForCheckout();
            } else if (typeof window.syncPosExpandCustomerFields === 'function') {
                var _billForSale = document.getElementById('pos-bill-panel');
                window.syncPosExpandCustomerFields(_billForSale && _billForSale.classList.contains('expanded'));
            }
            var _namedIntentName = (typeof getPosCustomerNameValue === 'function') ? getPosCustomerNameValue() : '';
            var _namedIntentId = (typeof window.getPosActiveCustomerId === 'function')
                ? (window.getPosActiveCustomerId() || 0)
                : (parseInt(window.__posActiveCustomerId, 10) || 0);
            var _hasNamedCustomerIntent = !!(_namedIntentName || _namedIntentId > 0);
            if (typeof window.collapseTxnSheet === 'function') window.collapseTxnSheet('pos');
            /* Customer + پارێ دای first — FIB toggle must not swallow unpaid remainder as bank. */
            if (typeof window.completePosSaleForNamedCustomer === 'function') {
                if (window.completePosSaleForNamedCustomer()) return;
            }
            // Named / debt intent must never silently fall through to guest cash.
            if (_hasNamedCustomerIntent) {
                var warnNamed = (typeof t === 'function')
                    ? (t('pos_named_customer_checkout_blocked') || 'کریار هەلبژێردراوە — ناتوانیت وەک میوان (کاش) بفرۆشیت. کریار دووبارە هەلبژێرە.')
                    : 'کریار هەلبژێردراوە — ناتوانیت وەک میوان (کاش) بفرۆشیت. کریار دووبارە هەلبژێرە.';
                if (typeof showToast === 'function') showToast('⚠️ ' + warnNamed, 'warning');
                else alert(warnNamed);
                return;
            }
            if (typeof getCartPayMethod === 'function' && getCartPayMethod('pos') === 'fib') {
                if (typeof sellFromPosFib === 'function') sellFromPosFib();
                else if (typeof processPayment === 'function') processPayment('fib');
                return;
            }
            if (isAutoPaymentModalEnabled()) {
                var payBlock = typeof assertPosPaymentModalAllowed === 'function' ? assertPosPaymentModalAllowed() : null;
                if (!payBlock && typeof openPaymentModal === 'function') {
                    openPaymentModal();
                    return;
                }
            }
            processPayment();
        }
        /** Instant FIB sale — no payment modal, no Pro. Does not enter قاسە. */
        function sellFromPosFib() {
            var table = db && db.tables ? db.tables.find(function (t) { return t.id === activeTableId; }) : null;
            if (!table || !table.items || table.items.length === 0) {
                var emptyMsg = (typeof t === 'function') ? t('pos_empty_cart') : '';
                if (!emptyMsg || emptyMsg === 'pos_empty_cart') emptyMsg = 'سەبەتە بەتاڵە!';
                if (typeof showToast === 'function') showToast(emptyMsg, true);
                else alert(emptyMsg);
                return;
            }
            if (window._posEditingSale && window._posEditingSale.id && typeof window.savePosEditedSale === 'function') {
                if (typeof window.collapseTxnSheet === 'function') window.collapseTxnSheet('pos');
                window.savePosEditedSale();
                return;
            }
            if (typeof window.collapseTxnSheet === 'function') window.collapseTxnSheet('pos');
            if (typeof window.syncPosCustomerFieldsForCheckout === 'function') {
                window.syncPosCustomerFieldsForCheckout();
            }
            var customerId = (typeof window.getPosActiveCustomerId === 'function')
                ? (window.getPosActiveCustomerId() || 0)
                : 0;
            var customerType = '';
            var customerName = typeof getPosCustomerNameValue === 'function' ? getPosCustomerNameValue() : '';
            if (customerId > 0 && db && db.customers) {
                var custById = db.customers.find(function (c) { return c && parseInt(c.id, 10) === customerId; });
                if (custById && custById.id) {
                    customerId = custById.id;
                    customerType = 'customer';
                }
            }
            if (!(customerId > 0) && customerName && db && db.customers) {
                var needle = String(customerName).trim().toLowerCase();
                var cust = db.customers.find(function (c) {
                    return c && String(c.name || '').trim().toLowerCase() === needle;
                });
                if (cust && cust.id) {
                    customerId = cust.id;
                    customerType = 'customer';
                }
            }
            if (typeof processPayment === 'function') processPayment('fib', customerId, customerType);
        }
        window.getPosMaxDailySalesAllowed = getPosMaxDailySalesAllowed;
        window.getPosDailyPaymentModalUsesCount = getPosDailyPaymentModalUsesCount;
        window.isAutoPaymentModalEnabled = isAutoPaymentModalEnabled;
        window.onPosPaymentWalletClick = onPosPaymentWalletClick;
        window.sellFromPos = sellFromPos;
        window.sellFromPosFib = sellFromPosFib;

        window._posScannerReady = false;
        window.__posAppShellReady = false;
        var _cartRestoreNotified = false;

        function showAppBootLoader() {
            document.documentElement.classList.add('app-booting', 'pos-pre-auth');
            var st = document.getElementById('startup-screen');
            if (st) st.style.display = 'none';
        }

        function hideAppBootLoader() {
            window.__posAppShellReady = true;
            document.documentElement.classList.remove('app-booting');
            var loader = document.getElementById('app-boot-loader');
            if (loader) loader.setAttribute('aria-busy', 'false');
        }
        window.showAppBootLoader = showAppBootLoader;
        window.hideAppBootLoader = hideAppBootLoader;

        function posHideStartupScreens() {
            var st = document.getElementById('startup-screen');
            if (st) st.style.display = 'none';
            var login = document.getElementById('login-screen');
            if (login) login.style.display = 'none';
            var mc = document.getElementById('mobile-connect-info');
            if (mc) {
                mc.style.display = 'none';
                mc.hidden = true;
            }
        }
        window.posHideStartupScreens = posHideStartupScreens;

        /** End boot state and paint home/sidebar (fixes stuck skeleton on main screen). */
        function posMarkShellReadyAndPaint() {
            if (typeof hideAppBootLoader === 'function') hideAppBootLoader();
            if (typeof renderRightSidebar === 'function') renderRightSidebar();
            if (typeof renderHomeView === 'function') renderHomeView();
            if (typeof shopAiUpdateFabVisibility === 'function') shopAiUpdateFabVisibility();
            if (typeof schedulePosEnhanceIcons === 'function') schedulePosEnhanceIcons();
        }
        window.posMarkShellReadyAndPaint = posMarkShellReadyAndPaint;

        function showPosInitOverlay() {
            window._posScannerReady = false;
            var el = document.getElementById('pos-init-overlay');
            if (el) {
                el.style.display = 'flex';
                el.setAttribute('aria-hidden', 'false');
            }
        }

        function hidePosInitOverlay() {
            var el = document.getElementById('pos-init-overlay');
            if (el) {
                el.style.display = 'none';
                el.setAttribute('aria-hidden', 'true');
            }
            window._posScannerReady = true;
        }

        function isPosScannerBlocked() {
            if (!window._posScannerReady) return true;
            var modalIds = ['opening-balance-modal', 'first-run-currency-modal', 'first-run-business-modal', 'payment-modal', 'purchase-payment-modal'];
            for (var i = 0; i < modalIds.length; i++) {
                var m = document.getElementById(modalIds[i]);
                if (m && m.style.display !== 'none' && m.offsetParent !== null) return true;
            }
            // Any visible modal overlay blocks headless scan (prevents ghost adds under dialogs)
            try {
                var overlays = document.querySelectorAll('.modal-overlay');
                for (var oi = 0; oi < overlays.length; oi++) {
                    var ov = overlays[oi];
                    if (!ov) continue;
                    var disp = (ov.style && ov.style.display) || '';
                    if (disp === 'none') continue;
                    if (ov.offsetParent !== null || (ov.getClientRects && ov.getClientRects().length)) return true;
                }
            } catch (_eOv) {}
            var ae = document.activeElement;
            if (ae) {
                var tag = ae.tagName;
                if (tag === 'SELECT' || tag === 'BUTTON') return true;
                if (ae.closest && ae.closest('.modal-overlay, .modal, [role="dialog"]')) return true;
            }
            return false;
        }

        /** True when a workspace view (view-pos, view-purchase, …) is the active screen. */
        function isWorkspaceViewActive(viewId) {
            if (!viewId) return false;
            var el = document.getElementById('view-' + viewId);
            return !!(el && el.classList.contains('active'));
        }
        window.isWorkspaceViewActive = isWorkspaceViewActive;

        /** Wipe transactional pools so login/refresh never shows another session's sales or cash figures. */
        function posClearDbTransactionalData() {
            if (!db) return;
            ['sales', 'expenses', 'expenses_deleted', 'supplies', 'ledger', 'customer_ledger', 'waste', 'recipes', 'returns', 'purchase_returns', 'deliveries', 'warehouse_movements', 'unified_ledger', 'logs', 'print_log'].forEach(function (f) {
                db[f] = [];
            });
            db.treasury = 0;
            // Keep today_stats until server bootstrap/secondary replaces them (prevents false-zero dashboard during login).
            delete db.capital_report;
            window._posDriverDeliveryCache = {};
            window._posDeliveryPrefetchStarted = false;
            window._posDeliveryFetchBusy = 0;
            if (typeof window.invalidateSalesPoolCache === 'function') window.invalidateSalesPoolCache();
        }
        window.posClearDbTransactionalData = posClearDbTransactionalData;

        /** Merge a server delivery row without wiping local line items when the payload omitted them. */
        function posMergeDeliveryRow(list, srvD) {
            if (!Array.isArray(list) || !srvD || srvD.id == null) return;
            var sid = Number(srvD.id);
            var idx = list.findIndex(function (x) { return x && Number(x.id) === sid; });
            if (idx > -1) {
                var prev = list[idx];
                if (Array.isArray(srvD.items) && srvD.items.length === 0 && prev && Array.isArray(prev.items) && prev.items.length) {
                    srvD = Object.assign({}, srvD, { items: prev.items });
                }
                list[idx] = Object.assign({}, prev, srvD);
            } else {
                list.push(srvD);
            }
        }
        window.posMergeDeliveryRow = posMergeDeliveryRow;

        function posInvalidateFinancialCaches(forUserId) {
            window._dailyDetailCache = {};
            window._dailyDetailPending = {};
            window._dailyDetailEpoch = (window._dailyDetailEpoch || 0) + 1;
            window.__posBootstrapPrefetchPromise = null;
            window.__posSecondaryHeavyLoaded = false;
            window.__posFinancialDataReady = false;
            window.__posFinancialDataUserId = forUserId != null ? forUserId : (currentUser && currentUser.id);
            if (typeof window.invalidateSalesPoolCache === 'function') window.invalidateSalesPoolCache();
        }
        window.posInvalidateFinancialCaches = posInvalidateFinancialCaches;

        /** Bust daily-summary cache so weak laptops never paint stale totals after a write. */
        function posInvalidateDailyDetailCache(dateIso) {
            window._dailyDetailCache = window._dailyDetailCache || {};
            window._dailyDetailPending = window._dailyDetailPending || {};
            window._dailyDetailEpoch = (window._dailyDetailEpoch || 0) + 1;
            if (dateIso) {
                var needle = String(dateIso);
                try {
                    Object.keys(window._dailyDetailCache).forEach(function(k) {
                        if (k === needle || k.indexOf(needle) !== -1) {
                            try { delete window._dailyDetailCache[k]; } catch (_eDel) {}
                        }
                    });
                } catch (_e1) {}
                try {
                    Object.keys(window._dailyDetailPending).forEach(function(k) {
                        if (k === needle || k.indexOf(needle) !== -1) {
                            try { delete window._dailyDetailPending[k]; } catch (_eDel2) {}
                        }
                    });
                } catch (_e2) {}
            } else {
                window._dailyDetailCache = {};
                window._dailyDetailPending = {};
            }
            return window._dailyDetailEpoch;
        }
        window.posInvalidateDailyDetailCache = posInvalidateDailyDetailCache;

        /** Re-paint open financial UI after sale/expense/return (no F5 needed). */
        function posRefreshOpenFinancialScreens() {
            if (typeof updateStats === 'function') {
                try { updateStats(); } catch (_eUs) {}
            }
            var calView = document.getElementById('view-calendar');
            var calActive = !!(calView && calView.classList.contains('active'));
            if (calActive && typeof invalidateCalendarMonthCache === 'function') {
                try { invalidateCalendarMonthCache(); } catch (_eCal) {}
            } else {
                window._calMonthCacheStale = true;
            }
            var dm = document.getElementById('daily-history-modal');
            if (dm && dm.style.display === 'flex' && typeof openDailyHistoryModal === 'function') {
                var day = (typeof getBusinessDate === 'function') ? getBusinessDate(new Date()) : null;
                try { openDailyHistoryModal(day, { refresh: true, force: true }); } catch (_eDh) {}
            }
            var vrep = document.getElementById('view-reports');
            if (vrep && vrep.classList.contains('active')) {
                if (typeof renderShopOverview === 'function') {
                    try { renderShopOverview(); } catch (_eSo) {}
                }
                if (typeof renderSalesHistory === 'function') {
                    try { renderSalesHistory(); } catch (_eSh) {}
                }
                if (typeof renderShiftSummary === 'function') {
                    try { renderShiftSummary(); } catch (_eSs) {}
                }
            }
            var vexp = document.getElementById('view-expenses');
            if (vexp && vexp.classList.contains('active') && typeof renderExpenses === 'function') {
                try { renderExpenses(); } catch (_eEx) {}
            }
            var cal = document.getElementById('view-calendar');
            if (cal && cal.classList.contains('active') && typeof renderWorkCalendar === 'function') {
                try { renderWorkCalendar(0); } catch (_eWc) {}
            }
        }
        window.posRefreshOpenFinancialScreens = posRefreshOpenFinancialScreens;

        function posIsFinancialDataReady() {
            return !!window.__posFinancialDataReady
                && window.__posFinancialDataUserId === (currentUser && currentUser.id);
        }
        window.posIsFinancialDataReady = posIsFinancialDataReady;

        /** Dashboard/calendar may paint from bootstrap today_stats or daily-detail cache before secondary lists load. */
        function posCanPaintFinancialStats() {
            if (posIsFinancialDataReady()) return true;
            if (db && db.today_stats) {
                var ts = db.today_stats;
                if ((parseInt(ts.count, 10) || 0) > 0 || (parseFloat(ts.sales) || 0) > 0 || (parseFloat(ts.expenses) || 0) > 0) {
                    return true;
                }
            }
            if (typeof getBusinessDate !== 'function' || !window._dailyDetailCache) return false;
            var todayIso = getBusinessDate(new Date());
            var cached = window._dailyDetailCache[todayIso];
            var uid = currentUser && currentUser.id;
            return !!(cached && cached.data && cached.data.pools && cached.userId === uid);
        }
        window.posCanPaintFinancialStats = posCanPaintFinancialStats;

        /** Load sales/ledger/expenses — must finish before login UI shows financial figures. */
        function posSecondaryFetchUrl(mode) {
            var lite = ((typeof isPosCpuSaveMode === 'function' && isPosCpuSaveMode())
                || (typeof isPosLargeShopMode === 'function' && isPosLargeShopMode()))
                ? '&lite_secondary=1' : '';
            // Always prefer lite after hard refresh — smaller JSON, faster login
            if (!lite) lite = '&lite_secondary=1';
            var qs;
            if (mode === 'heavy') {
                qs = 'action=get_data&secondary_heavy=1' + lite + '&t=' + Date.now();
            } else {
                qs = 'action=get_data&secondary=1' + lite + '&t=' + Date.now();
            }
            return (typeof window.posRouterUrl === 'function') ? window.posRouterUrl(qs) : ('?' + qs);
        }

        function posWarmTodayDetailCache() {
            if (typeof getBusinessDate !== 'function' || typeof fetch !== 'function') return Promise.resolve();
            var todayIso = getBusinessDate(new Date());
            window._dailyDetailCache = window._dailyDetailCache || {};
            var uid = currentUser && currentUser.id;
            var cached = window._dailyDetailCache[todayIso];
            if (cached && cached.data && cached.userId === uid && (Date.now() - (cached.ts || 0) < 8000)) {
                if (typeof updateStats === 'function') updateStats();
                return Promise.resolve(cached.data);
            }
            var epochAtStart = window._dailyDetailEpoch || 0;
            var qs = 'action=get_daily_detail&lite=1&date=' + encodeURIComponent(todayIso) + '&_=' + Date.now();
            var url = (typeof window.posRouterUrl === 'function') ? window.posRouterUrl(qs) : ('?' + qs);
            return fetch(url, { credentials: 'same-origin', cache: 'no-store' })
                .then(function (r) { return r.json().catch(function () { return null; }); })
                .then(function (dd) {
                    if ((window._dailyDetailEpoch || 0) !== epochAtStart) return null;
                    if (!dd || dd.status !== 'ok' || !dd.pools) return null;
                    var warmEpoch = window._dailyDetailEpoch || 0;
                    window._dailyDetailCache[todayIso] = { ts: Date.now(), data: dd, userId: uid, epoch: warmEpoch };
                    // Same key shape as daily modal so paintDailySummaryContent can reuse warm data
                    try {
                        var modalKey = todayIso + '_' + todayIso + '_all';
                        window._dailyDetailCache[modalKey] = { ts: Date.now(), data: dd, userId: uid, epoch: warmEpoch, reqUser: 'all', dateFrom: todayIso, dateTo: todayIso };
                    } catch (_eWarmKey) {}
                    if (typeof updateStats === 'function') updateStats();
                    return dd;
                })
                .catch(function () { return null; });
        }
        window.posWarmTodayDetailCache = posWarmTodayDetailCache;

        function posFetchSecondaryDataOnce() {
            if (typeof apiJson !== 'function') return Promise.resolve({ ok: false });
            return apiJson(posSecondaryFetchUrl('lite')).then(function (sec) {
                if (!sec || sec.status === 'auth_required' || !db) {
                    return { ok: false, status: sec && sec.status };
                }
                var mergedOk = mergeSecondaryData(sec);
                return { ok: mergedOk !== false };
            });
        }

        function posAfterSecondaryFetchSuccess() {
            posRefreshSecondaryViews();
            posWarmTodayDetailCache();
            scheduleDataSecondaryHeavyFetch();
            if (typeof checkInstallmentDueReminders === 'function') checkInstallmentDueReminders();
            var isLanTerm = (typeof posIsRemoteLanPosClient === 'function' && posIsRemoteLanPosClient())
                || (typeof posIsFragiDeviceMode === 'function' && posIsFragiDeviceMode());
            if (!isLanTerm && typeof window.scheduleFirebaseMobilePush === 'function') {
                window.scheduleFirebaseMobilePush('secondary_data', true);
            }
        }

        function posAfterSecondaryFetchFailure() {
            posWarmTodayDetailCache();
            if (db && db.today_stats && typeof updateStats === 'function') {
                setTimeout(function () { updateStats(); }, 300);
            }
            if (typeof showToast === 'function') {
                showToast(typeof t === 'function' ? t('toast_secondary_load_retry') : '⚠️ بارکردنی فرۆشتن سەرنەکەوت — F5 یان دووبارە چوونەژوورەوە');
            }
        }

        function posFetchSecondaryDataNow(retryLeft) {
            if (typeof apiJson !== 'function') return Promise.resolve();
            if (retryLeft == null) retryLeft = 3;
            return posFetchSecondaryDataOnce().then(function (res) {
                if (res && res.ok) {
                    posAfterSecondaryFetchSuccess();
                    return;
                }
                if (retryLeft > 1) {
                    var waitMs = 600 * (4 - retryLeft);
                    return new Promise(function (resolve) { setTimeout(resolve, waitMs); }).then(function () {
                        return posFetchSecondaryDataNow(retryLeft - 1);
                    });
                }
                posAfterSecondaryFetchFailure();
            }).catch(function () {
                if (retryLeft > 1) {
                    var waitMs = 600 * (4 - retryLeft);
                    return new Promise(function (resolve) { setTimeout(resolve, waitMs); }).then(function () {
                        return posFetchSecondaryDataNow(retryLeft - 1);
                    });
                }
                posAfterSecondaryFetchFailure();
            });
        }
        window.posFetchSecondaryDataNow = posFetchSecondaryDataNow;

        function mergeSecondaryData(sec) {
            if (!db || !sec) return false;
            var health = db._db_health || {};
            var salesN = parseInt(health.sales_count, 10) || 0;
            var blockedEmptySales = false;
            if (Array.isArray(sec.sales) && sec.sales.length === 0 && salesN > 10) {
                blockedEmptySales = true;
                if (!window.__posSecondaryEmptyRetry) {
                    window.__posSecondaryEmptyRetry = true;
                    setTimeout(function () {
                        window.__posSecondaryEmptyRetry = false;
                        if (typeof posFetchSecondaryDataNow === 'function') posFetchSecondaryDataNow(2);
                    }, 1200);
                }
            }
            var fields = ['sales', 'expenses', 'expenses_deleted', 'supplies', 'ledger', 'customer_ledger', 'installment_plans', 'installment_items', 'waste', 'recipes', 'returns', 'purchase_returns', 'deliveries', 'warehouse_movements', 'unified_ledger', 'stock_transfers'];
            fields.forEach(function(f) {
                if (f === 'sales' && blockedEmptySales) return;
                if (sec[f] === undefined) return;
                if (f === 'deliveries' && Array.isArray(sec.deliveries)) {
                    if (!Array.isArray(db.deliveries)) db.deliveries = [];
                    if (!sec.deliveries.length && db.deliveries.length) return;
                    sec.deliveries.forEach(function (srvD) {
                        if (typeof window.posMergeDeliveryRow === 'function') window.posMergeDeliveryRow(db.deliveries, srvD);
                    });
                    return;
                }
                db[f] = sec[f];
            });
            if (Array.isArray(sec.drivers) && sec.drivers.length) db.drivers = sec.drivers;
            if (sec.treasury !== undefined) db.treasury = sec.treasury;
            if (sec.capital_report !== undefined) db.capital_report = sec.capital_report;
            if (Array.isArray(sec.warehouses)) db.warehouses = sec.warehouses;
            if (Array.isArray(sec.warehouse_stock)) db.warehouse_stock = sec.warehouse_stock;
            if (typeof window.applyOpenWarehouseFromPayload === 'function') window.applyOpenWarehouseFromPayload(sec);
            else if (sec.open_warehouse_id != null) db.open_warehouse_id = Number(sec.open_warehouse_id) || 0;
            if (sec.today_stats) db.today_stats = sec.today_stats;
            if (typeof window.invalidateSalesPoolCache === 'function') window.invalidateSalesPoolCache();
            if (!blockedEmptySales) {
                window.__posFinancialDataReady = true;
                window.__posFinancialDataUserId = currentUser && currentUser.id;
            }
            if (typeof window.posAfterWarehouseDataLoaded === 'function') {
                window.posAfterWarehouseDataLoaded('secondary_data');
            }
            if (typeof window.posNotifyMobileDebtSync === 'function') {
                window.posNotifyMobileDebtSync('secondary_data');
            }
            return !blockedEmptySales;
        }

        function posRefreshSecondaryViews() {
            if (typeof updateStats === 'function') updateStats();
            var shm = document.getElementById('sales-history-modal');
            if (shm && shm.style.display === 'flex' && typeof renderShiftSummary === 'function') renderShiftSummary();
            if (typeof posRefreshOpenFinancialScreens === 'function') {
                posRefreshOpenFinancialScreens();
            } else {
                var dm = document.getElementById('daily-history-modal');
                if (dm && dm.style.display === 'flex' && typeof openDailyHistoryModal === 'function') {
                    openDailyHistoryModal(typeof getBusinessDate === 'function' ? getBusinessDate(new Date()) : null, { refresh: true });
                }
            }
            var vexp = document.getElementById('view-expenses');
            if (vexp && vexp.classList.contains('active') && typeof renderExpenses === 'function') renderExpenses();
            var vrep = document.getElementById('view-reports');
            if (vrep && vrep.classList.contains('active')) {
                if (typeof renderSalesHistory === 'function') renderSalesHistory();
                if (typeof renderShiftSummary === 'function') renderShiftSummary();
                if (typeof renderReturnsReport === 'function') renderReturnsReport();
            }
            var vdel = document.getElementById('view-delivery');
            if (vdel && vdel.classList.contains('active') && typeof renderDeliveries === 'function') {
                try { renderDeliveries(); } catch (_eDelSec) {}
            }
            var vph = document.getElementById('view-print-history');
            if (vph && vph.classList.contains('active') && typeof renderGeneralHistory === 'function') renderGeneralHistory();
            var vwaste = document.getElementById('view-waste');
            if (vwaste && vwaste.classList.contains('active')) {
                if (typeof renderWasteMenu === 'function') renderWasteMenu((document.getElementById('waste-barcode-input-main') || {}).value || '');
                if (typeof renderWasteCart === 'function') renderWasteCart();
                if (typeof renderWasteList === 'function') renderWasteList();
                if (typeof renderWasteCandidates === 'function') renderWasteCandidates();
            }
        }

        /** Paint catalog-dependent screens (warehouse / POS / products) for the active workspace. */
        function posRefreshActiveWorkspaceData() {
            if (!db) return;
            var vwh = document.getElementById('view-warehouse');
            if (vwh && vwh.classList.contains('active') && typeof renderWarehouse === 'function') {
                renderWarehouse(typeof currentWhFilter !== 'undefined' ? (currentWhFilter || 'all') : 'all');
            }
            var vpos = document.getElementById('view-pos');
            if (vpos && vpos.classList.contains('active')) {
                if (typeof renderPOSCategories === 'function') renderPOSCategories();
                if (typeof renderPOSMenu === 'function') {
                    var searchEl = document.getElementById('pos-barcode-input');
                    renderPOSMenu(searchEl ? searchEl.value : '', true);
                }
                if (typeof renderBill === 'function') renderBill();
            }
            var vprod = document.getElementById('view-products');
            if (vprod && vprod.classList.contains('active')) {
                if (typeof renderCategorySelect === 'function') renderCategorySelect();
                if (typeof renderProducts === 'function') {
                    var prodSearch = document.getElementById('products-search-input');
                    renderProducts(prodSearch ? prodSearch.value : '');
                }
            }
            var vstaff = document.getElementById('view-staff');
            if (vstaff && vstaff.classList.contains('active')) {
                if (typeof renderUsers === 'function') renderUsers();
            }
        }
        window.posRefreshActiveWorkspaceData = posRefreshActiveWorkspaceData;

        function posBootstrapPrefetchUsable(data) {
            if (!data || data.status === 'auth_required' || data.status === 'license_blocked' || data.status === 'device_blocked') return false;
            if (data.status === 'error') return false;
            return Array.isArray(data.products);
        }

        /** Reload product catalog if bootstrap/login left db.products empty.
         *  opts.allowPartial: resolve immediately with whatever is already loaded (fast login). */
        function posEnsureCatalogLoaded(opts) {
            opts = opts || {};
            if (db && Array.isArray(db.products) && db.products.length > 0) {
                if (window.__posCatalogTier === 'full') return Promise.resolve(db);
                // Never freeze the shop waiting for the rest of the catalog unless the caller asked.
                if (opts.requireFull
                    && typeof posIsCatalogPartial === 'function' && posIsCatalogPartial()
                    && typeof posEnsureFullCatalogLoaded === 'function') {
                    return posEnsureFullCatalogLoaded();
                }
                return Promise.resolve(db);
            }
            if (typeof connectToDB !== 'function') return Promise.resolve(db);
            return connectToDB(true, { fullData: true, skipRenderOnRefresh: true, skipPaintAfterLoad: true });
        }
        window.posEnsureCatalogLoaded = posEnsureCatalogLoaded;

        /** End boot overlay and paint UI once catalog is available (fixes empty screens until F5). */
        function posForceDataPaint(opts) {
            opts = opts || {};
            if (typeof hideAppBootLoader === 'function') hideAppBootLoader();
            var ws = document.querySelector('.workspace.active');
            var stayPut = !!(ws && ws.id && typeof currentUser !== 'undefined' && currentUser
                && ws.id !== 'login-screen');
            if (!stayPut) {
                if (typeof posMarkShellReadyAndPaint === 'function') posMarkShellReadyAndPaint();
                if (typeof renderMainNav === 'function') renderMainNav();
            } else if (ws.id === 'view-home' && typeof renderHomeView === 'function') {
                renderHomeView();
            }
            if (typeof posRefreshActiveWorkspaceData === 'function') posRefreshActiveWorkspaceData();
            if (stayPut) return;
            if (opts.full && typeof renderAll === 'function') {
                window.__posBootRenderLight = false;
                renderAll();
            } else if (typeof renderAll === 'function') {
                renderAll({ bootLight: true });
            }
        }
        window.posForceDataPaint = posForceDataPaint;

        function posAfterDataLoadPaint(opts) {
            opts = opts || {};
            if (!currentUser || !db) return Promise.resolve();
            return posEnsureCatalogLoaded().then(function () {
                if (opts.defer) {
                    requestAnimationFrame(function () {
                        posForceDataPaint({ full: !!opts.full });
                    });
                } else {
                    posForceDataPaint({ full: !!opts.full });
                }
            });
        }
        window.posAfterDataLoadPaint = posAfterDataLoadPaint;

        function scheduleDataSecondaryFetch(opts) {
            opts = opts || {};
            if (typeof apiJson !== 'function') return;
            var _secDelay = opts.immediate ? 0 : ((typeof posStartupDeferMs === 'function') ? posStartupDeferMs(400) : 400);
            setTimeout(function() {
                apiJson(posSecondaryFetchUrl('lite')).then(function(sec) {
                    if (!sec || sec.status === 'auth_required' || !db) return;
                    mergeSecondaryData(sec);
                    posRefreshSecondaryViews();
                    posWarmTodayDetailCache();
                    scheduleDataSecondaryHeavyFetch();
                    if (typeof checkInstallmentDueReminders === 'function') checkInstallmentDueReminders();
                    if (typeof renderAll === 'function') {
                        if (document.getElementById('view-pos') && document.getElementById('view-pos').classList.contains('active')) {
                            if (typeof updateNotificationBadge === 'function') updateNotificationBadge();
                        }
                    }
                }).catch(function() {});
            }, _secDelay);
        }

        function scheduleDataSecondaryHeavyFetch() {
            if (window.__posSecondaryHeavyLoaded || typeof apiJson !== 'function') return;
            var delay = (typeof posStartupDeferMs === 'function') ? posStartupDeferMs(3500) : 3500;
            setTimeout(function () {
                if (window.__posSecondaryHeavyLoaded) return;
                apiJson(posSecondaryFetchUrl('heavy')).then(function (sec) {
                    if (!sec || sec.status === 'auth_required' || !db) return;
                    window.__posSecondaryHeavyLoaded = true;
                    mergeSecondaryData(sec);
                    var vwh = document.getElementById('view-warehouse');
                    if (vwh && vwh.classList.contains('active') && typeof renderWarehouse === 'function') {
                        renderWarehouse(typeof currentWhFilter !== 'undefined' ? (currentWhFilter || 'all') : 'all');
                    }
                }).catch(function () {});
            }, delay);
        }
        window.scheduleDataSecondaryHeavyFetch = scheduleDataSecondaryHeavyFetch;

        /** Stable key so db.supplies + _fullPurchaseHistory never double-count the same line. */
        function posSupplyFingerprint(s) {
            if (!s) return '';
            var idNum = Number(s.id);
            if (s.id != null && Number.isFinite(idNum) && idNum > 0 && idNum < 9000000000000) {
                return 'id:' + String(s.id);
            }
            return [
                String(s.transaction_id || '').trim(),
                String(s.prodId || ''),
                String(s.qtyAdded != null ? s.qtyAdded : ''),
                String(s.totalCost != null ? s.totalCost : ''),
                String(s.type || ''),
                String(s.date || '').slice(0, 19),
                String(s.company || '').trim().toLowerCase(),
                String(s.supplier_invoice_number || '').trim()
            ].join('|');
        }
        window.posSupplyFingerprint = posSupplyFingerprint;

        /** Merge db.supplies + purchase-history cache for purchase return / invoice lookup. */
        function posGetSuppliesPool() {
            var a = (db && Array.isArray(db.supplies)) ? db.supplies : [];
            var b = (typeof window !== 'undefined' && Array.isArray(window._fullPurchaseHistory)) ? window._fullPurchaseHistory : [];
            var seen = {};
            var out = [];
            function ingest(list) {
                (list || []).forEach(function (s) {
                    if (!s) return;
                    var fp = posSupplyFingerprint(s);
                    if (!fp || seen[fp]) return;
                    seen[fp] = 1;
                    out.push(s);
                });
            }
            ingest(a);
            ingest(b);
            if (!out.length) return [];
            return out.sort(function (x, y) {
                return (Number(y.id) || 0) - (Number(x.id) || 0);
            });
        }
        window.posGetSuppliesPool = posGetSuppliesPool;

        function posEnsureSuppliesPoolLoaded() {
            if (posGetSuppliesPool().length > 0) {
                return Promise.resolve(posGetSuppliesPool());
            }
            if (typeof apiJson !== 'function') {
                return Promise.resolve([]);
            }
            var url = posSecondaryFetchUrl('heavy');
            return apiJson(url).then(function (sec) {
                if (sec && sec.status !== 'auth_required' && sec.status !== 'license_blocked' && sec.status !== 'device_blocked') {
                    mergeSecondaryData(sec);
                    window.__posSecondaryHeavyLoaded = true;
                }
                return posGetSuppliesPool();
            }).catch(function () {
                return posGetSuppliesPool();
            });
        }
        window.posEnsureSuppliesPoolLoaded = posEnsureSuppliesPoolLoaded;

        /** Full purchase history for FIFO / warehouse (restored shadow data needs all rows, not last 1800). */
        function posEnsureFifoSupplyPoolLoaded() {
            if (window.__posFifoFullHistoryLoaded) {
                return Promise.resolve(posGetSuppliesPool());
            }
            var params = new URLSearchParams();
            params.set('action', 'get_purchase_history');
            params.set('all', '1');
            params.set('limit', '10000');
            var url = (typeof window.posRouterUrl === 'function')
                ? window.posRouterUrl(params.toString())
                : ('?' + params.toString());
            return fetch(url, { credentials: 'same-origin' })
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    if (data && data.status === 'success' && Array.isArray(data.supplies)) {
                        window._fullPurchaseHistory = data.supplies;
                        window.__posFifoFullHistoryLoaded = true;
                        window.__posFifoHistoryMeta = {
                            total: data.total || data.supplies.length,
                            loaded: data.loaded || data.supplies.length,
                            truncated: !!data.truncated
                        };
                    }
                    return posGetSuppliesPool();
                })
                .catch(function () {
                    return posEnsureSuppliesPoolLoaded();
                });
        }
        window.posEnsureFifoSupplyPoolLoaded = posEnsureFifoSupplyPoolLoaded;

        window._fifoSuppliesByProduct = window._fifoSuppliesByProduct || {};

        function posMergeFifoProductSupplies(productId, rows) {
            productId = parseInt(productId, 10);
            if (!productId || !Array.isArray(rows) || !rows.length) return;
            var seen = {};
            var merged = [];
            function ingest(list) {
                (list || []).forEach(function (s) {
                    if (!s || String(s.prodId) !== String(productId)) return;
                    var fp = posSupplyFingerprint(s);
                    if (!fp || seen[fp]) return;
                    seen[fp] = 1;
                    merged.push(s);
                });
            }
            ingest((window._fifoSuppliesByProduct[productId] && window._fifoSuppliesByProduct[productId].rows) || []);
            ingest(rows);
            merged.sort(function (a, b) { return (Number(b.id) || 0) - (Number(a.id) || 0); });
            window._fifoSuppliesByProduct[productId] = { _loaded: true, rows: merged };
        }

        function posEnsureProductFifoSupplies(productId, opts) {
            productId = parseInt(productId, 10);
            opts = opts || {};
            if (!productId) return Promise.resolve([]);

            var cached = window._fifoSuppliesByProduct[productId];
            if (!opts.force && cached && cached._loaded && Array.isArray(cached.rows) && cached.rows.length > 0) {
                return Promise.resolve(cached.rows);
            }

            function fromPool() {
                return posEnsureFifoSupplyPoolLoaded().then(function (pool) {
                    var inPool = (pool || []).filter(function (s) {
                        return s && String(s.prodId) === String(productId)
                            && s.type !== 'return'
                            && (opts.includeOpening || s.type !== 'opening')
                            && (parseFloat(s.qtyAdded) || 0) > 0;
                    });
                    if (inPool.length) {
                        if (!opts.includeOpening) {
                            posMergeFifoProductSupplies(productId, inPool);
                            return window._fifoSuppliesByProduct[productId].rows;
                        }
                        return inPool;
                    }
                    return [];
                });
            }

            function fetchProductSupplies() {
                var params = new URLSearchParams();
                params.set('action', 'get_product_fifo_supplies');
                params.set('product_id', String(productId));
                if (opts.includeOpening) params.set('include_opening', '1');
                if (opts.force) params.set('_', String(Date.now()));
                var url = (typeof window.posRouterUrl === 'function')
                    ? window.posRouterUrl(params.toString())
                    : ('?' + params.toString());
                return fetch(url, { credentials: 'same-origin' })
                    .then(function (res) { return res.json(); })
                    .then(function (data) {
                        if (data && data.status === 'success' && Array.isArray(data.supplies) && data.supplies.length) {
                            if (opts.includeOpening) return data.supplies;
                            posMergeFifoProductSupplies(productId, data.supplies);
                            if (data.stock_batches && data.stock_batches.length) {
                                window._fifoStockBatchesByProduct = window._fifoStockBatchesByProduct || {};
                                window._fifoStockBatchesByProduct[productId] = data.stock_batches;
                            }
                            return window._fifoSuppliesByProduct[productId].rows;
                        }
                        return null;
                    });
            }

            // Product endpoint first (complete for this item) — do not wait on full purchase history.
            return fetchProductSupplies().then(function (rows) {
                if (rows && rows.length) return rows;
                return fromPool();
            }).catch(function () {
                return fromPool();
            });
        }
        window.posEnsureProductFifoSupplies = posEnsureProductFifoSupplies;

        function posInvalidateFifoSupplyCache() {
            window.__posFifoFullHistoryLoaded = false;
            window.__posFifoHistoryMeta = null;
            window._fifoSuppliesByProduct = {};
            window._fifoStockBatchesByProduct = {};
        }
        window.posInvalidateFifoSupplyCache = posInvalidateFifoSupplyCache;

        function posMergeExtendedRows(field, incoming, idKey) {
            idKey = idKey || 'id';
            if (!Array.isArray(incoming) || !incoming.length) return false;
            var map = {};
            (db[field] || []).forEach(function (row) {
                if (row && row[idKey] != null) map[String(row[idKey])] = row;
            });
            incoming.forEach(function (row) {
                if (row && row[idKey] != null) map[String(row[idKey])] = row;
            });
            db[field] = Object.values(map).sort(function (a, b) {
                return (Number(b[idKey]) || 0) - (Number(a[idKey]) || 0);
            });
            return true;
        }

        function posLoadExtendedData(opts) {
            opts = opts || {};
            var section = opts.section || 'supplies';
            var offset = opts.offset != null ? opts.offset : 0;
            if (opts.append && section === 'supplies' && db && Array.isArray(db.supplies)) {
                offset = db.supplies.length;
            } else if (opts.append && section === 'expenses' && db && Array.isArray(db.expenses)) {
                offset = db.expenses.length;
            } else if (opts.append && section === 'returns' && db && Array.isArray(db.returns)) {
                offset = db.returns.length;
            } else if (opts.append && section === 'warehouse' && db && Array.isArray(db.warehouse_movements)) {
                offset = db.warehouse_movements.length;
            }
            var limit = opts.limit || 3000;
            var url = '?action=get_data&secondary_extended=1&section=' + encodeURIComponent(section) +
                '&offset=' + encodeURIComponent(String(offset)) +
                '&limit=' + encodeURIComponent(String(limit)) + '&t=' + Date.now();
            return apiJson(url).then(function (data) {
                if (!data || data.status === 'auth_required' || !db) return data;
                if (Array.isArray(data.supplies)) posMergeExtendedRows('supplies', data.supplies);
                if (Array.isArray(data.expenses)) posMergeExtendedRows('expenses', data.expenses);
                if (Array.isArray(data.returns)) posMergeExtendedRows('returns', data.returns);
                if (Array.isArray(data.warehouse_movements)) posMergeExtendedRows('warehouse_movements', data.warehouse_movements);
                if (typeof window.invalidateSalesPoolCache === 'function') window.invalidateSalesPoolCache();
                return data;
            });
        }
        window.posLoadExtendedData = posLoadExtendedData;

        function posFetchEntitySearch(entityType, q, limit, offset) {
            limit = limit || 50;
            offset = offset || 0;
            var qs = 'action=search_entities&type=' + encodeURIComponent(entityType || 'customers')
                + '&q=' + encodeURIComponent(q || '')
                + '&limit=' + encodeURIComponent(String(limit))
                + '&offset=' + encodeURIComponent(String(offset));
            var url = (typeof window.posRouterUrl === 'function')
                ? window.posRouterUrl(qs)
                : ('?' + qs);
            var ctrl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
            var toId = setTimeout(function() {
                if (ctrl) try { ctrl.abort(); } catch (_eAb) {}
            }, 8000);
            var opts = { credentials: 'same-origin', cache: 'no-store' };
            if (ctrl) opts.signal = ctrl.signal;
            return fetch(url, opts)
                .then(function(r) { return r.json().catch(function() { return { status: 'error' }; }); })
                .then(function(data) {
                    if (data && Array.isArray(data.rows)) {
                        data.rows = data.rows.filter(function(x) {
                            return x && (x.is_active == null || Number(x.is_active) !== 0);
                        });
                    }
                    return data;
                })
                .catch(function() { return { status: 'error' }; })
                .finally(function() { clearTimeout(toId); });
        }
        window.posFetchEntitySearch = posFetchEntitySearch;

        function deferPosBackgroundTasks() {
            var _d = function (ms) {
                return (typeof posStartupDeferMs === 'function') ? posStartupDeferMs(ms) : ms;
            };
            var _lanTerm = (typeof isPosLanTerminalClient === 'function' && isPosLanTerminalClient())
                || (typeof posIsRemoteLanPosClient === 'function' && posIsRemoteLanPosClient());
            setTimeout(function() {
                if (typeof startAutoRefresh === 'function') startAutoRefresh();
            }, _lanTerm ? 200 : _d(2000));
            setTimeout(function() {
                if (typeof checkExpiryPopup === 'function') checkExpiryPopup();
                if (typeof checkLowStockPopup === 'function') checkLowStockPopup();
            }, _d(3000));
        }

        function scheduleWarmPrintFrameDeferred() {
            try {
                if (document.fonts && document.fonts.load) {
                    document.fonts.load('400 16px Rudaw');
                    document.fonts.load('700 16px Rudaw');
                }
            } catch (ePreFont) {}
            var run = function () {
                if (typeof warmPrintFrame === 'function') warmPrintFrame();
            };
            if (typeof isPosUltraGraphicsMode === 'function' && isPosUltraGraphicsMode()) {
                setTimeout(run, 400);
            } else {
                run();
            }
        }

        /** Ensure table rows from SQL never crash UI when items is null or row is malformed. */
        function normalizePosTables(tables) {
            if (!Array.isArray(tables)) return [];
            return tables.filter(function (t) { return t && typeof t === 'object'; }).map(function (t) {
                if (!Array.isArray(t.items)) t.items = [];
                return t;
            });
        }
        window.normalizePosTables = normalizePosTables;

        /** Resolve active POS table/cart regardless of id type (number vs string). */
        function findActivePosTable() {
            if (!db || !db.tables || activeTableId == null) return null;
            return db.tables.find(function (t) { return String(t.id) === String(activeTableId); }) || null;
        }
        window.findActivePosTable = findActivePosTable;

        function schedulePosScanIndexBuild() {
            var run = function () {
                if (typeof rebuildPosScanIndex === 'function') rebuildPosScanIndex();
            };
            if (typeof isPosCpuSaveMode === 'function' && isPosCpuSaveMode()) {
                setTimeout(run, (typeof posStartupDeferMs === 'function') ? posStartupDeferMs(800) : 1500);
            } else {
                run();
            }
        }

        function maybeNotifyCartRestored() {
            if (_cartRestoreNotified || !db || !activeTableId) return;
            var table = db.tables.find(function(t) { return t.id === activeTableId; });
            if (!table || !Array.isArray(table.items) || table.items.length === 0) return;
            _cartRestoreNotified = true;
            var count = table.items.length;
            var msg = 'سەبەتێ پێشوو هاتە بارکرن — ' + count + ' ئایتم';
            if (typeof showToast === 'function') showToast(msg, 'info');
        }

        function finalizePosInit() {
            requestAnimationFrame(function() {
                if (typeof renderBill === 'function') renderBill();
                maybeNotifyCartRestored();
                hidePosInitOverlay();
            });
        }

        function loginStaffIconClass(role) {
            var r = String(role || '').toLowerCase();
            if (r === 'admin' || r === 'manager') return 'fa-user-shield';
            if (r === 'cashier') return 'fa-cash-register';
            return 'fa-user-tie';
        }
        function loginStaffRoleLabel(role) {
            var r = String(role || '').toLowerCase();
            if (typeof getRoleLabel === 'function') {
                var fromStaff = getRoleLabel(r);
                if (fromStaff) return fromStaff;
            }
            if (typeof t === 'function') {
                var s = t('role_short_' + r);
                if (s && s !== ('role_short_' + r)) return s;
            }
            var fb = { admin: 'ڕێڤەبەر', manager: 'بەڕێوەبەر', supervisor: 'سەرپەرشتیار', cashier: 'کارمەند', stock_manager: 'کۆگە', inventory_clerk: 'کۆگە', accountant: 'ژمێریار', finance_viewer: 'دارایی', sales_rep: 'فرۆشیار', sales_viewer: 'بینەر', waiter: 'گارصۆن' };
            return fb[r] || role || '';
        }

        function selectLoginStaff(userId, btnEl) {
            var hidden = document.getElementById('login-user-select');
            if (hidden) hidden.value = userId ? String(userId) : '';
            var list = document.getElementById('login-staff-list');
            if (list) {
                list.querySelectorAll('.login-staff-btn').forEach(function (b) {
                    var on = btnEl ? (b === btnEl) : (b.getAttribute('data-user-id') === String(userId));
                    b.classList.toggle('is-selected', on);
                    b.setAttribute('aria-selected', on ? 'true' : 'false');
                    
                    var check = b.querySelector('.login-staff-btn__check');
                    if(check) {
                        check.style.display = on ? 'flex' : 'none';
                    }

                    var ic = b.querySelector('.login-staff-btn__ic');
                    if (ic) {
                        ic.style.background = on ? 'var(--brand)' : '#f1f5f9';
                        ic.style.color = on ? '#ffffff' : '#64748b';
                    }
                });
            }
            var err = document.getElementById('login-error');
            if (err) err.textContent = '';
            var pin = document.getElementById('pin-code');
            if (pin) {
                requestAnimationFrame(function () { pin.focus(); try { pin.select(); } catch (_ePin) {} });
            }
        }
        window.selectLoginStaff = selectLoginStaff;

        function initLoginStaffPickerDelegation() {
            if (window.__posLoginStaffPickerInit) return;
            var list = document.getElementById('login-staff-list');
            if (!list) return;
            window.__posLoginStaffPickerInit = true;
            function pickFromEvent(e) {
                var btn = e.target && e.target.closest ? e.target.closest('.login-staff-btn') : null;
                if (!btn || !list.contains(btn)) return;
                var uid = btn.getAttribute('data-user-id');
                if (!uid) return;
                if (e.type === 'keydown' && e.key !== 'Enter' && e.key !== ' ') return;
                if (e.type === 'keydown') e.preventDefault();
                selectLoginStaff(uid, btn);
            }
            list.addEventListener('click', pickFromEvent, false);
            list.addEventListener('pointerup', pickFromEvent, false);
            list.addEventListener('keydown', pickFromEvent, false);
        }
        window.initLoginStaffPickerDelegation = initLoginStaffPickerDelegation;

        function populateLoginUserSelect(users) {
            initLoginStaffPickerDelegation();
            var hidden = document.getElementById('login-user-select');
            var list = document.getElementById('login-staff-list');
            if (!hidden || !list) return;
            hidden.value = '';
            list.innerHTML = '';
            if (!users || !users.length) {
                var empty = document.createElement('p');
                empty.className = 'login-staff-empty';
                empty.textContent = (typeof t === 'function') ? t('login_no_staff') : 'هیچ کارمەندێک نییە';
                list.appendChild(empty);
                return;
            }
            var frag = document.createDocumentFragment();
            users.forEach(function (u) {
                if (!u || u.id == null) return;
                var uid = String(u.id);
                var btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'login-staff-btn';
                btn.setAttribute('data-user-id', uid);
                btn.setAttribute('role', 'option');
                btn.setAttribute('aria-selected', 'false');
                btn.setAttribute('onclick', 'selectLoginStaff(' + JSON.stringify(uid) + ', this); return false;');
                var name = (typeof escapeHtml === 'function') ? escapeHtml(String(u.name || '')) : String(u.name || '');
                var roleRaw = loginStaffRoleLabel(u.role);
                var role = (typeof escapeHtml === 'function') ? escapeHtml(String(roleRaw || '')) : String(roleRaw || '');
                var ic = loginStaffIconClass(u.role);
                btn.innerHTML = '<span class="login-staff-btn__ic" aria-hidden="true"><i class="fas ' + ic + '"></i></span>' +
                    '<span class="login-staff-btn__text"><span class="login-staff-btn__name">' + name + '</span>' +
                    (role ? '<span class="login-staff-btn__role">' + role + '</span>' : '') + '</span>' +
                    '<span class="login-staff-btn__check" aria-hidden="true" style="display:none; position:absolute; top:-6px; right:-6px; width:24px; height:24px; background:var(--brand); color:white; border-radius:50%; align-items:center; justify-content:center; font-size:0.8rem; box-shadow:0 2px 5px rgba(0,0,0,0.2);"><i class="fas fa-check"></i></span>';
                btn.style.position = 'relative';
                frag.appendChild(btn);
            });
            list.appendChild(frag);
            if (users.length === 1) {
                var only = list.querySelector('.login-staff-btn');
                if (only) selectLoginStaff(users[0].id, only);
            }
        }
        window.populateLoginUserSelect = populateLoginUserSelect;

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initLoginStaffPickerDelegation);
        } else {
            initLoginStaffPickerDelegation();
        }

        /** Show staff picker immediately on weak laptops (before heavy theme/nav work). */
        function revealLoginScreenFast(users) {
            if (window.__posLoginRevealed) return;
            window.__posLoginRevealed = true;
            document.documentElement.classList.add('pos-pre-auth');
            document.documentElement.classList.remove('app-booting');
            var st = document.getElementById('startup-screen');
            var login = document.getElementById('login-screen');
            if (st) st.style.display = 'none';
            if (login) login.style.display = 'flex';
            if (typeof hideAppBootLoader === 'function') hideAppBootLoader();
            if (users && typeof populateLoginUserSelect === 'function') populateLoginUserSelect(users);
            if (typeof posSyncLanTerminalChrome === 'function') posSyncLanTerminalChrome();
            requestAnimationFrame(function () {
                var hidden = document.getElementById('login-user-select');
                var first = document.querySelector('#login-staff-list .login-staff-btn');
                if (first && hidden && !hidden.value) first.focus();
                else {
                    var pin = document.getElementById('pin-code');
                    if (pin) pin.focus();
                }
            });
        }
        window.revealLoginScreenFast = revealLoginScreenFast;

        function deferPostLoginChromeWork(fn) {
            if (typeof fn !== 'function') return;
            var delay = 0;
            if (typeof posLoginChromeDeferMs === 'function') delay = posLoginChromeDeferMs();
            if (delay > 0) {
                setTimeout(fn, delay);
                return;
            }
            if (typeof requestAnimationFrame === 'function') {
                requestAnimationFrame(function () { setTimeout(fn, 0); });
            } else {
                setTimeout(fn, 0);
            }
        }

        function finishLoginAndOpenPOS(user) {
            posHideDeviceBlockedScreen();
            try { sessionStorage.setItem('pos_session_active', '1'); } catch (_eSessLogin) {}
            document.documentElement.classList.remove('pos-pre-auth');
            var loginScreen = document.getElementById('login-screen');
            if (loginScreen) loginScreen.style.display = 'none';
            var frMod = document.getElementById('first-run-currency-modal');
            if (frMod) frMod.style.display = 'none';
            var frBiz = document.getElementById('first-run-business-modal');
            if (frBiz) frBiz.style.display = 'none';
            var userLabel = typeof getUserDisplayLabel === 'function' ? getUserDisplayLabel(user) : (user.name + " (" + user.role + ")");
            var ud = document.getElementById('user-display');
            if (ud) ud.innerText = userLabel;
            var _su = document.getElementById('right-sidebar-user-name');
            if (_su) _su.innerText = userLabel;
            if (typeof applyMenuSectionsState === 'function') applyMenuSectionsState();
            var _weakLogin = (typeof window.isPosCpuSaveMode === 'function' && window.isPosCpuSaveMode());
            // Defer fullscreen — it blocks paint on many laptops.
            setTimeout(function () {
                if (_weakLogin) return;
                try {
                    if (!document.fullscreenElement && document.documentElement.requestFullscreen) {
                        document.documentElement.requestFullscreen().catch(function () {});
                    }
                } catch (_eFs) {}
            }, _weakLogin ? 2500 : 600);
            if (typeof persistSystemFeaturesToStorage === 'function') persistSystemFeaturesToStorage();
            applyUserPermissions();
            // Apply Market/business mode BEFORE first paint — avoid wrong menu for a few seconds
            if (typeof applySystemMode === 'function') {
                try { applySystemMode({ deferNav: false }); } catch (_eModeLogin) {}
            }

            var openPosShell = function () {
                window.__posBootRenderLight = true;
                if (typeof posHideStartupScreens === 'function') posHideStartupScreens();
                if (typeof applyPrintSettings === 'function') applyPrintSettings();
                // Re-apply mode right before nav (settings may have loaded mid-login)
                if (typeof applySystemMode === 'function') {
                    try { applySystemMode({ deferNav: false }); } catch (_eModeShell) {}
                }
                if (db && db.settings && db.settings.showTables !== true) {
                    if (typeof showPosInitOverlay === 'function') showPosInitOverlay();
                    if (typeof openDirectPOS === 'function') openDirectPOS({ markReady: true });
                } else {
                    if (typeof nav === 'function') nav('calendar');
                    if (typeof hidePosInitOverlay === 'function') hidePosInitOverlay();
                }
                // Paint immediately — do not wait for daily-detail / secondary network.
                if (typeof posForceDataPaint === 'function') {
                    posForceDataPaint({ full: false });
                } else if (typeof posMarkShellReadyAndPaint === 'function') {
                    posMarkShellReadyAndPaint();
                }
                if (typeof updateUSDBadge === 'function') updateUSDBadge();
                if (typeof hidePosInitOverlay === 'function') {
                    setTimeout(function () { hidePosInitOverlay(); }, 80);
                }

                // Background: warm stats, secondary books, full catalog, heavier paint.
                var bgDelay = _weakLogin
                    ? ((typeof posLoginDeferMs === 'function') ? posLoginDeferMs(350) : 350)
                    : 120;
                setTimeout(function () {
                    if (typeof posWarmTodayDetailCache === 'function') {
                        posWarmTodayDetailCache().then(function () {
                            if (typeof updateStats === 'function') updateStats();
                            if (typeof renderHomeView === 'function') renderHomeView();
                        });
                    }
                    if (typeof posIsFinancialDataReady === 'function' && !posIsFinancialDataReady()
                        && typeof posFetchSecondaryDataNow === 'function') {
                        posFetchSecondaryDataNow().then(function () {
                            if (typeof updateStats === 'function') updateStats();
                            if (typeof renderHomeView === 'function') renderHomeView();
                        });
                    }
                    if (typeof posIsCatalogPartial === 'function' && posIsCatalogPartial()
                        && typeof posEnsureFullCatalogLoaded === 'function') {
                        posEnsureFullCatalogLoaded().then(function () {
                            if (typeof posRefreshActiveWorkspaceData === 'function') posRefreshActiveWorkspaceData();
                        }).catch(function () {});
                    }
                    window.__posBootRenderLight = false;
                    if (typeof posForceDataPaint === 'function') posForceDataPaint({ full: !_weakLogin });
                    if (typeof posSyncLanTerminalChrome === 'function') posSyncLanTerminalChrome();
                }, bgDelay);

                deferPosBackgroundTasks();
                deferPostLoginChromeWork(function () {
                    if (typeof applySystemMode === 'function') applySystemMode({ deferNav: false });
                    if (typeof renderRightSidebar === 'function') renderRightSidebar();
                    if (typeof applyPremiumStartup === 'function') applyPremiumStartup();
                    scheduleWarmPrintFrameDeferred();
                });
            };

            // Open shell ASAP — partial catalog is enough for first paint.
            var hasCatalog = !!(db && Array.isArray(db.products) && db.products.length > 0);
            var go = function () {
                if (_weakLogin && typeof requestAnimationFrame === 'function') {
                    requestAnimationFrame(openPosShell);
                } else {
                    openPosShell();
                }
                if (typeof posTelegramConfigured === 'function' ? posTelegramConfigured() : (db && db.settings && db.settings.tgToken && db.settings.tgChatId)) {
                    var _tgDelay = _weakLogin
                        ? ((typeof posStartupDeferMs === 'function') ? posStartupDeferMs(8000) : 8000)
                        : 1500;
                    setTimeout(function () {
                        sendTelegramLoginNotification(user).catch(function (e) { console.error('Telegram login notify', e); });
                    }, _tgDelay);
                }
            };
            if (hasCatalog) {
                go();
            } else if (typeof posEnsureCatalogLoaded === 'function') {
                posEnsureCatalogLoaded({ allowPartial: true }).then(go).catch(go);
            } else {
                go();
            }
        }

        function applySessionShellAfterData(options) {
            options = options || {};
            if (typeof hideAppBootLoader === 'function') hideAppBootLoader();
            applyUserPermissions();
            if (typeof applyMenuSectionsState === 'function') applyMenuSectionsState();
            applyBreadcrumbVisibility();
            applySidebarPosition();
            applyRightSidebarVisibility();
            applyFabVisibility();
            applyTheme();
            var zoomVal = (db && db.settings) ? (db.settings.zoomLevel || 100) : 100;
            if (typeof applyZoomLevel === 'function') applyZoomLevel(zoomVal);
            if (typeof initGraphicsQualityFromStorage === 'function') initGraphicsQualityFromStorage();
            if (typeof applyLanguage === 'function') applyLanguage({ deferNav: !!options.deferHeavyRender });
            // Never defer business-mode nav on login — menu must match Market immediately
            if (typeof applySystemMode === 'function') applySystemMode({ deferNav: false });
            if (typeof applyPremiumStartup === 'function') applyPremiumStartup();
            var finishShell = function () {
                if (typeof hideAppBootLoader === 'function') hideAppBootLoader();
                if (typeof applyPrintSettings === 'function') applyPrintSettings();
                if (typeof renderRightSidebar === 'function') renderRightSidebar();
                if (typeof renderAll === 'function') renderAll({ bootLight: !!options.deferHeavyRender });
                if (typeof posRefreshActiveWorkspaceData === 'function') posRefreshActiveWorkspaceData();
                scheduleWarmPrintFrameDeferred();
                if (typeof renderHomeView === 'function') renderHomeView();
                if (typeof consumeAutoGraphicsNotify === 'function' && typeof showToast === 'function') {
                    var _autoGfx = consumeAutoGraphicsNotify();
                    if (_autoGfx === 'low' || _autoGfx === 'ultra') {
                        showToast(typeof t === 'function' ? t('toast_graphics_auto_low') : 'ئامێرەکەت کەمە — کوالێتی گرافیک خۆکار «کوالێتی نزم» کرا.');
                    }
                }
            };
            if (options.deferHeavyRender) {
                if (typeof window.isPosCpuSaveMode === 'function' && window.isPosCpuSaveMode()) {
                    window.__posBootRenderLight = true;
                }
                requestAnimationFrame(function () {
                    setTimeout(finishShell, 0);
                });
            } else {
                finishShell();
            }
        }

