// core/input-focus.js — input focus scroll
/**
 * Keep focused inputs visible above the on-screen keyboard (staff, settings, forms).
 */
(function () {
    'use strict';
    if (window._posInputFocusScrollLoaded) return;
    window._posInputFocusScrollLoaded = true;

    var FOCUSABLE = 'input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]):not([type="file"]), textarea, select';
    var EXCLUDE = [
        '#pos-barcode-input',
        '#returns-barcode-input',
        '#purchase-barcode-input',
        '#purchase-returns-barcode-input',
        '.pos-scanner-input'
    ].join(',');

    var activeField = null;
    var scrollTimers = [];
    var winScrollLock = 0;

    function isTouchOrNarrow() {
        try {
            if (window.matchMedia('(pointer: coarse)').matches) return true;
            if (window.matchMedia('(max-width: 900px)').matches) return true;
        } catch (e) {}
        return (navigator.maxTouchPoints || 0) > 0;
    }

    function shouldHandle(el) {
        if (!el || !el.matches || !isTouchOrNarrow()) return false;
        if (!el.matches(FOCUSABLE)) return false;
        if (el.matches(EXCLUDE)) return false;
        if (el.disabled) return false;
        if (el.readOnly && el.tagName !== 'SELECT') return false;
        if (el.closest('.txn-sheet-panel')) return false;
        return true;
    }

    function getViewportMetrics() {
        var vv = window.visualViewport;
        if (!vv) return { top: 0, height: window.innerHeight };
        return { top: vv.offsetTop, height: vv.height };
    }

    function findScrollParent(el) {
        var node = el.parentElement;
        while (node && node !== document.body) {
            if (node.classList && node.classList.contains('workspace') && node.classList.contains('active')) {
                return node;
            }
            var style = window.getComputedStyle(node);
            var oy = style.overflowY;
            if ((oy === 'auto' || oy === 'scroll') && node.scrollHeight > node.clientHeight + 4) {
                return node;
            }
            node = node.parentElement;
        }
        var ws = document.querySelector('.workspace.active');
        return ws || document.scrollingElement || document.documentElement;
    }

    function scrollFieldIntoView(el) {
        if (!el || !document.body.contains(el)) return;
        var rect = el.getBoundingClientRect();
        var vp = getViewportMetrics();
        var topPad = 80;
        var bottomPad = 28;
        var visibleTop = vp.top + topPad;
        var visibleBottom = vp.top + vp.height - bottomPad;

        if (rect.top >= visibleTop && rect.bottom <= visibleBottom) return;

        var scrollParent = findScrollParent(el);
        if (!scrollParent) return;

        var delta = 0;
        if (rect.bottom > visibleBottom) {
            delta = rect.bottom - visibleBottom;
        } else if (rect.top < visibleTop) {
            delta = rect.top - visibleTop;
        }
        if (Math.abs(delta) < 3) return;

        try {
            scrollParent.scrollBy({ top: delta, left: 0, behavior: 'smooth' });
        } catch (e) {
            scrollParent.scrollTop += delta;
        }
    }

    function clearScrollTimers() {
        scrollTimers.forEach(function (t) { clearTimeout(t); });
        scrollTimers = [];
    }

    function scheduleScroll(el) {
        clearScrollTimers();
        activeField = el;
        document.body.classList.add('pos-form-input-focused');
        winScrollLock = window.scrollY || 0;
        scrollFieldIntoView(el);
        scrollTimers.push(setTimeout(function () { scrollFieldIntoView(el); }, 120));
        scrollTimers.push(setTimeout(function () { scrollFieldIntoView(el); }, 320));
        scrollTimers.push(setTimeout(function () { scrollFieldIntoView(el); }, 520));
    }

    function releaseFocusState() {
        activeField = null;
        document.body.classList.remove('pos-form-input-focused');
        clearScrollTimers();
    }

    document.addEventListener('focusin', function (e) {
        var el = e.target;
        if (!shouldHandle(el)) return;
        scheduleScroll(el);
    }, true);

    document.addEventListener('focusout', function (e) {
        var el = e.target;
        if (!shouldHandle(el)) return;
        setTimeout(function () {
            var ae = document.activeElement;
            if (!ae || !shouldHandle(ae)) releaseFocusState();
        }, 80);
    }, true);

    window.addEventListener('scroll', function () {
        if (!activeField || !document.body.classList.contains('pos-form-input-focused')) return;
        if (Math.abs((window.scrollY || 0) - winScrollLock) > 2) {
            window.scrollTo(0, winScrollLock);
        }
    }, { passive: true });

    if (window.visualViewport) {
        window.visualViewport.addEventListener('resize', function () {
            if (activeField && document.activeElement === activeField) {
                scrollFieldIntoView(activeField);
            }
        });
    }

    window.posScrollFieldIntoView = scrollFieldIntoView;
})();
