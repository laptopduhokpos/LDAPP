/**
 * Reports: reports view, statistics, comparisons.
 * Logic currently lives in app.js; getFinancialMetrics, getReportSales are in utils.js.
 */
import { state } from './state.js';

// Placeholder: report rendering remains in app.js.
