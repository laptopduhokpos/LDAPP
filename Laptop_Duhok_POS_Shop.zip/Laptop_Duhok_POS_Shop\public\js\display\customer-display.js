(function() {
    'use strict';

    var POLL_MS = 1500;
    var SUCCESS_MS = 2200;
    var CHANNEL_NAME = 'LAPTOP_DUHOK_POS_customer_display';
    var STORAGE_KEY = 'LAPTOP_DUHOK_POS_display_sync';
    var lastTimestamp = 0;
    var pollTimer = null;
    var statusTimer = null;

    function $(id) { return document.getElementById(id); }

    function escapeHtml(v) {
        return String(v == null ? '' : v)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function parseNum(v) {
        var n = Number(String(v == null ? '' : v).replace(/,/g, ''));
        return Number.isFinite(n) ? n : 0;
    }

    function formatIqd(v) {
        var amount = Math.round(parseNum(v));
        try { return amount.toLocaleString('en-US') + ' IQD'; }
        catch (e) { return String(amount) + ' IQD'; }
    }

    function formatUsd(v) {
        var amount = Math.round(parseNum(v) * 100) / 100;
        var cents = Math.round(Math.abs(amount) * 100) % 100;
        try {
            if (cents === 0) return '$' + Math.round(amount).toLocaleString('en-US');
            return '$' + amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        } catch (e) {
            return cents === 0 ? ('$' + String(Math.round(amount))) : ('$' + amount.toFixed(2));
        }
    }

    function lineUsdIqd(it, fxRate) {
        var qty = Math.max(1, parseNum(it && (it.count || it.qty) || 1));
        var iqd = parseNum(it && (it.subtotal != null ? it.subtotal : it.price));
        var usd = parseNum(it && it.bill_unit_usd) * (it && it.subtotal != null ? qty : 1);
        if (it && it.subtotal == null && it.price != null) iqd = parseNum(it.price) * qty;
        var r = parseNum(fxRate);
        if (usd > 0 && iqd > 0 && r > 0 && Math.abs(usd - iqd) / Math.max(iqd, 1) < 0.02) {
            iqd = Math.round(usd);
            usd = usd / r;
        } else if (usd > 0 && iqd > 0 && r > 0 && usd >= (r * 10) && Math.abs((usd * r) - iqd) / Math.max(iqd, 1) < 0.05) {
            iqd = Math.round(usd);
            usd = usd / r;
        }
        if (!(usd > 0) && iqd > 0 && r > 0) usd = iqd / r;
        if (!(iqd > 0) && usd > 0 && r > 0) iqd = Math.round(usd * r);
        return { usd: usd, iqd: iqd };
    }

    function formatPair(usd, iqd) {
        if (usd > 0 && iqd > 0) return formatUsd(usd) + ' · ' + formatIqd(iqd);
        if (usd > 0) return formatUsd(usd);
        return formatIqd(iqd);
    }

    function formatCurrency(v) {
        return formatIqd(v);
    }

    function setConn(ok) {
        var el = $('conn-status');
        if (!el) return;
        el.style.background = ok ? '#10b981' : '#ef4444';
        if (statusTimer) clearTimeout(statusTimer);
        statusTimer = setTimeout(function() {
            el.style.background = '#ef4444';
        }, 3000);
    }

    function showIdle() {
        var idle = $('idle-screen');
        var active = $('active-screen');
        if (idle) idle.classList.remove('hidden');
        if (active) active.classList.remove('visible');
    }

    function showActive() {
        var idle = $('idle-screen');
        var active = $('active-screen');
        if (idle) idle.classList.add('hidden');
        if (active) active.classList.add('visible');
    }

    function renderUpdate(payload) {
        var items = Array.isArray(payload.items) ? payload.items : [];
        var cart = $('cart-list');
        var totalEl = $('total-display');
        var countEl = $('item-count-badge');
        var lastName = $('last-name');
        var lastPrice = $('last-price');
        var lastBox = $('last-item-box');
        if (!cart || !totalEl || !countEl) return;

        if (!items.length) {
            cart.innerHTML = '';
            totalEl.textContent = '0';
            countEl.textContent = '0 Items';
            showIdle();
            return;
        }

        var total = parseNum(payload.total);
        if (total <= 0) {
            for (var i = 0; i < items.length; i++) total += parseNum(items[i].subtotal);
        }
        var fx = parseNum(payload.fxRate);
        var totalUsd = parseNum(payload.totalUsd);
        if (!(totalUsd > 0) && total > 0 && fx > 0) totalUsd = total / fx;
        totalEl.textContent = formatPair(totalUsd, total);

        var rows = [];
        var count = 0;
        for (var j = 0; j < items.length; j++) {
            var it = items[j] || {};
            var qty = Math.max(0, parseNum(it.count || it.qty || 0));
            count += qty;
            var lm = lineUsdIqd(it, fx);
            rows.push(
                '<div class="cart-item">' +
                    '<div class="item-info">' +
                        '<div class="item-name">' + escapeHtml(it.name || it.productName || 'ئایتم') + '</div>' +
                        '<div class="item-qty">x ' + qty + '</div>' +
                    '</div>' +
                    '<div class="item-price">' + formatPair(lm.usd, lm.iqd) + '</div>' +
                '</div>'
            );
        }
        cart.innerHTML = rows.join('');
        countEl.textContent = count + ' Items';

        var last = items[items.length - 1] || {};
        if (lastBox && lastName && lastPrice) {
            lastName.textContent = String(last.name || last.productName || 'ئایتم');
            var lastM = lineUsdIqd(last, fx);
            lastPrice.textContent = formatPair(lastM.usd, lastM.iqd);
            lastBox.style.opacity = '1';
        }
        showActive();
    }

    function renderSuccess(payload) {
        var success = $('success-screen');
        var change = $('change-display');
        if (!success) return;
        if (change) {
            var changeVal = parseNum(payload && payload.change);
            var changeUsd = parseNum(payload && payload.changeUsd);
            change.textContent = changeVal > 0 ? ('Change: ' + formatPair(changeUsd, changeVal)) : '';
        }
        success.classList.add('show');
        setTimeout(function() {
            success.classList.remove('show');
            showIdle();
        }, SUCCESS_MS);
    }

    function applyState(payload) {
        if (!payload || typeof payload !== 'object') return;
        var ts = parseNum(payload.timestamp || 0);
        if (ts && ts < lastTimestamp) return;
        if (ts) lastTimestamp = ts;

        if (payload.type === 'clear') {
            showIdle();
            var cart = $('cart-list');
            if (cart) cart.innerHTML = '';
            var totalEl = $('total-display');
            if (totalEl) totalEl.textContent = '0';
            var countEl = $('item-count-badge');
            if (countEl) countEl.textContent = '0 Items';
            return;
        }
        if (payload.type === 'success') {
            renderSuccess(payload);
            return;
        }
        renderUpdate(payload);
    }

    function parseStored(v) {
        try { return JSON.parse(v); } catch (e) { return null; }
    }

    function resolveAppBasePath() {
        var path = window.location.pathname || '/';
        var segments = path.split('/').filter(Boolean);
        var lastSeg = segments.length ? segments[segments.length - 1] : '';
        var looksLikeFile = /\.\w{1,12}$/.test(lastSeg);
        if (!path.endsWith('/')) {
            return looksLikeFile ? path.replace(/\/[^/]+$/, '/') : (path + '/');
        }
        return path;
    }

    function fetchState() {
        var t = Date.now();
        var urlA = '?action=get_customer_display_state&t=' + t;
        var urlB = resolveAppBasePath() + 'api/all.php?action=get_customer_display_state&t=' + t;
        return fetch(urlA, { cache: 'no-store' })
            .then(function(r) {
                if (!r.ok) throw new Error('endpointA');
                return r.json();
            })
            .catch(function() {
                return fetch(urlB, { cache: 'no-store' }).then(function(r) { return r.json(); });
            })
            .then(function(res) {
                setConn(true);
                if (res && res.status === 'success' && res.data) applyState(res.data);
            })
            .catch(function() {
                setConn(false);
            });
    }

    function startPolling() {
        if (pollTimer) clearInterval(pollTimer);
        fetchState();
        pollTimer = setInterval(fetchState, POLL_MS);
    }

    function initBroadcast() {
        try {
            if ('BroadcastChannel' in window) {
                var ch = new BroadcastChannel(CHANNEL_NAME);
                ch.onmessage = function(ev) {
                    if (!ev || !ev.data) return;
                    applyState(ev.data);
                    setConn(true);
                };
            }
        } catch (e) {}
    }

    function initStorageListener() {
        window.addEventListener('storage', function(ev) {
            if (!ev || ev.key !== STORAGE_KEY || !ev.newValue) return;
            var payload = parseStored(ev.newValue);
            if (!payload) return;
            applyState(payload);
            setConn(true);
        });
    }

    function bootstrapFromStorage() {
        try {
            var payload = parseStored(localStorage.getItem(STORAGE_KEY));
            if (payload) applyState(payload);
        } catch (e) {}
    }

    document.addEventListener('visibilitychange', function() {
        if (document.visibilityState === 'visible') fetchState();
    });

    bootstrapFromStorage();
    initBroadcast();
    initStorageListener();
    startPolling();
})();

