/**
 * Central API helper: fetch URL, parse response as JSON.
 * Throws friendly Error on non-JSON (e.g. HTML). Use for all ?action=... calls.
 */
export function apiJson(url, options) {
    if (typeof url === 'string' && /localhost:\d+/i.test(url)) {
        url = url.replace(/https?:\/\/localhost(?=:\d+)/gi, function (m) {
            return /^https:/i.test(m) ? 'https://127.0.0.1' : 'http://127.0.0.1';
        });
    }
    const opts = options || {};
    opts.credentials = opts.credentials || 'same-origin';
        try {
        if (typeof window !== 'undefined' && window.__posDeviceKey) {
            const headers = new Headers(opts.headers || undefined);
            if (!headers.has('X-POS-Device-Key')) {
                headers.set('X-POS-Device-Key', window.__posDeviceKey);
            }
            try {
                let fragi = false;
                if (typeof localStorage !== 'undefined' && localStorage.getItem('pos_fragi_device_mode') === '1') {
                    fragi = true;
                }
                const dk = (typeof window !== 'undefined' && window.__posDeviceKey)
                    ? String(window.__posDeviceKey)
                    : (typeof localStorage !== 'undefined' ? (localStorage.getItem('pos_client_device_key') || '') : '');
                if (dk.indexOf('pos-term-') === 0) {
                    fragi = true;
                }
                if (fragi && !headers.has('X-POS-Device-Role')) {
                    headers.set('X-POS-Device-Role', 'terminal');
                }
                const seed = (typeof window !== 'undefined' && window.__posFragiClientSeed)
                    ? String(window.__posFragiClientSeed)
                    : (typeof localStorage !== 'undefined' ? (localStorage.getItem('pos_fragi_client_seed') || '') : '');
                if (seed && !headers.has('X-POS-Client-Seed')) {
                    headers.set('X-POS-Client-Seed', seed);
                }
            } catch (_eRole) { /* noop */ }
            opts.headers = headers;
        }
    } catch (_eHdr) { /* noop */ }
    return fetch(url, opts).then(function (res) {
        return res.text().then(function (t) {
            const raw = (t || '').trim();
            try {
                return JSON.parse(raw);
            } catch (e) {
                if (raw && (raw.indexOf('<!DOCTYPE') !== -1 || raw.indexOf('<') === 0))
                    throw new Error('سێرڤەر وەڵامێ HTML گەڕاندەوە. پەڕەکە نوێ بکەرەوە.');
                // Some endpoints (or proxies) may return plain-text errors.
                // Normalize them to a predictable JSON-like shape to avoid noisy parse toasts.
                if (raw) {
                    const lower = raw.toLowerCase();
                    if (lower === 'unauthorized' || lower.indexOf('access denied') >= 0 || lower.indexOf('دەستوور نینە') >= 0) {
                        return { status: 'unauthorized', message: 'Unauthorized' };
                    }
                    return { status: 'error', message: String(raw).slice(0, 200) };
                }
                return { status: 'error', message: 'وەڵامێ نادروست (Not valid JSON).' };
            }
        });
    });
}
