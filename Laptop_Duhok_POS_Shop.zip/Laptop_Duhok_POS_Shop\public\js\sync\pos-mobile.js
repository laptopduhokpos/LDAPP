/**
 * Supabase mobile sync (read-only push): KPI + daily detail + inventory + debt for mobile_manager/.
 * One-way laptop → Supabase only (Firebase removed).
 */
(function () {
    if (window.__posMobileSyncLoaded) return;
    window.__posMobileSyncLoaded = true;

    var MIN_PUSH_MS = 12000;
    var PUSH_INTERVAL_MS = 12000;
    var LS_LAST_SYNC = "pos_mobile_last_sync_ms";
    var LS_LAST_ERR = "pos_mobile_last_err";

    var syncState = {
        client: null,
        loadPromise: null,
        session: null,
        lastPushAt: 0,
        lastDebtPushAt: 0,
        pushing: false,
        authUnsub: null,
        pushIntervalId: null
    };

    function sbCfg() {
        return window.POS_SUPABASE_MOBILE || null;
    }

    function sbEnabled() {
        var c = sbCfg();
        return !!(c && c.enabled !== false && c.url && c.anonKey);
    }

    function loadSupabase() {
        if (!sbEnabled()) return Promise.reject(new Error("Missing POS_SUPABASE_MOBILE"));
        if (syncState.client) return Promise.resolve(syncState.client);
        if (syncState.loadPromise) return syncState.loadPromise;
        syncState.loadPromise = import("https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.49.1/+esm")
            .catch(function () {
                return import("https://esm.sh/@supabase/supabase-js@2.49.1");
            })
            .then(function (mod) {
                var c = sbCfg();
                syncState.client = mod.createClient(c.url, c.anonKey, {
                    auth: {
                        persistSession: true,
                        autoRefreshToken: true,
                        detectSessionInUrl: false
                    }
                });
                if (!syncState.authUnsub) {
                    var sub = syncState.client.auth.onAuthStateChange(function (event, session) {
                        syncState.session = session;
                        if (session && session.user && session.user.email) {
                            startPeriodicMobilePush();
                            window.scheduleFirebaseMobilePush("auth", true);
                            scheduleDebtPushRetries();
                            setTimeout(function () {
                                if (typeof window.pushFirebaseMobileDebtOnly === "function") {
                                    window.pushFirebaseMobileDebtOnly(true).catch(function () {});
                                }
                            }, 2500);
                        } else {
                            stopPeriodicMobilePush();
                        }
                        notifyUi();
                    });
                    syncState.authUnsub = function () {
                        try { sub.data.subscription.unsubscribe(); } catch (e) {}
                    };
                    syncState.client.auth.getSession().then(function (res) {
                        syncState.session = res && res.data ? res.data.session : null;
                        notifyUi();
                    });
                }
                return syncState.client;
            })
            .catch(function (err) {
                syncState.loadPromise = null;
                throw err;
            });
        return syncState.loadPromise;
    }

    function ensureMobileSync() {
        return loadSupabase();
    }

    function currentUser() {
        var s = syncState.session;
        return s && s.user ? s.user : null;
    }

    function nowIso() {
        return new Date().toISOString();
    }

    function stripTs(obj) {
        if (!obj || typeof obj !== "object") return obj;
        if (Array.isArray(obj)) return obj.map(stripTs);
        var out = {};
        Object.keys(obj).forEach(function (k) {
            var v = obj[k];
            if (v && typeof v === "object" && (v._methodName === "serverTimestamp" || typeof v.toDate === "function")) {
                out[k] = nowIso();
            } else {
                out[k] = stripTs(v);
            }
        });
        return out;
    }

    function sbUpsert(table, row, onConflict) {
        return ensureMobileSync().then(function (client) {
            return client.from(table).upsert(row, { onConflict: onConflict });
        });
    }

    function getPosDb() {
        try {
            if (typeof window.db !== "undefined" && window.db) return window.db;
        } catch (e) {}
        return null;
    }

    function scheduleDebtPushRetries() {
        [1500, 5000, 15000, 45000].forEach(function (ms) {
            setTimeout(function () {
                if (!currentUser() || !currentUser().email) {
                    return;
                }
                if (typeof window.pushFirebaseMobileDebtOnly === "function") {
                    window.pushFirebaseMobileDebtOnly(true).catch(function () {});
                }
            }, ms);
        });
    }
    window.scheduleDebtPushRetries = scheduleDebtPushRetries;

    function startPeriodicMobilePush() {
        if (syncState.pushIntervalId) return;
        syncState.pushIntervalId = setInterval(function () {
            var u = currentUser();
            if (u && u.email) {
                window.scheduleFirebaseMobilePush("interval", false);
                if (typeof window.pushFirebaseMobileDebtOnly === "function") {
                    window.pushFirebaseMobileDebtOnly(false).catch(function () {});
                }
            }
        }, PUSH_INTERVAL_MS);
    }

    function stopPeriodicMobilePush() {
        if (syncState.pushIntervalId) {
            clearInterval(syncState.pushIntervalId);
            syncState.pushIntervalId = null;
        }
    }

    function getConfig() {
        return sbCfg();
    }

    function channelIdFromUser(user) {
        if (!user || !user.email) return "";
        return String(user.email).toLowerCase();
    }

    function lastSyncDisplay() {
        try {
            var ms = parseInt(localStorage.getItem(LS_LAST_SYNC) || "0", 10);
            if (!ms) {
                if (typeof window.t === "function") {
                    var none = window.t("firebase_sync_last_none");
                    if (none && none !== "firebase_sync_last_none") return none;
                }
                return "—";
            }
            var d = new Date(ms);
            var loc = typeof window.getDateLocale === "function" ? window.getDateLocale() : "ar-IQ";
            if (typeof window.formatProfileDateTime === "function") {
                return window.formatProfileDateTime(d, loc);
            }
            return d.toLocaleString(loc, {
                year: "numeric",
                month: "short",
                day: "numeric",
                hour: "2-digit",
                minute: "2-digit",
                second: "2-digit",
                hour12: false
            });
        } catch (e) {
            return "—";
        }
    }

    window.getFirebaseSyncStatus = function () {
        var u = currentUser();
        return {
            connected: !!(u && u.email),
            email: u && u.email ? u.email : "",
            kioskId: u ? channelIdFromUser(u) : "—",
            lastSync: lastSyncDisplay()
        };
    };

    function formatSbLoginError(err) {
        var code = String((err && (err.code || err.error_code)) || "").toLowerCase();
        var msg = String((err && err.message) || "").toLowerCase();
        if (code === "email_not_confirmed" || msg.indexOf("email not confirmed") >= 0) {
            return "ئیمێیل پشتڕاست نەکراوە — لە Supabase بەکارهێنەرەکە Auto Confirm بکە.";
        }
        if (code === "invalid_credentials" || msg.indexOf("invalid login") >= 0) {
            return "ئیمێیل/تێپەڕەوشە هەڵەیە — یان بەکارهێنەر لە Supabase دروست نەکراوە.\n" +
                "Supabase → Authentication → Users → Add user (Auto Confirm ✓)";
        }
        if (code === "user_banned" || msg.indexOf("banned") >= 0) {
            return "ئەم هەژمارە قەدەغەکراوە لە Supabase.";
        }
        if (err && err.message) return err.message;
        return typeof window.t === "function"
            ? window.t("firebase_err_login_failed")
            : "چوونەژوورەوە سەرکەوتوو نەبوو.";
    }

    function notifyUi() {
        if (typeof window.updateFirebaseSyncUI === "function") {
            try {
                window.updateFirebaseSyncUI();
            } catch (e) {}
        }
    }

    function removeStaleFirebaseLocks() {
        try {
            var o = document.getElementById("pos-access-lock-overlay");
            if (o) o.remove();
            var old = document.getElementById("firebase-cashier-auth-modal");
            if (old) old.remove();
        } catch (e) {}
    }

    removeStaleFirebaseLocks();
    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", removeStaleFirebaseLocks);
    }

    function safeParseItems(items) {
        if (!items) return [];
        if (typeof items === "string") {
            try {
                var p = JSON.parse(items);
                return Array.isArray(p) ? p : [];
            } catch (e) {
                return [];
            }
        }
        return Array.isArray(items) ? items : [];
    }

    function todayBusinessDateStr() {
        if (typeof window.getBusinessDate === "function") {
            return window.getBusinessDate(new Date());
        }
        return new Date().toISOString().slice(0, 10);
    }

    /** Canonical IQD for mobile — DB always stores IQD even when POS display is USD. */
    function mobileStoredIqd(val) {
        if (typeof normalizeStoredIqdValue === "function") {
            return normalizeStoredIqdValue(val);
        }
        if (typeof roundMoney === "function") {
            return roundMoney(val, "IQD");
        }
        return Math.round(Number(val) || 0);
    }

    function getMobilePrivacyFlags() {
        var db = getPosDb();
        var s = db && db.settings ? db.settings : {};
        return {
            hideProfit: !!(
                s.mobileHideProfit === true ||
                s.mobileHideProfit === 1 ||
                s.mobileHideProfit === "true"
            ),
            hideSalesDetail: !!(
                s.mobileHideSalesDetail === true ||
                s.mobileHideSalesDetail === 1 ||
                s.mobileHideSalesDetail === "true"
            )
        };
    }

    function mobileSyncMeta(businessDateStr, extra) {
        var meta = {
            businessDate: businessDateStr,
            app: "pos_web",
            amountCurrency: "IQD",
            posDisplayCurrency:
                typeof getActiveCurrency === "function"
                    ? getActiveCurrency()
                    : "IQD",
            usdRatePerOne:
                typeof getUsdRatePerOne === "function" ? getUsdRatePerOne() : 0,
            v: 3
        };
        if (extra) {
            Object.keys(extra).forEach(function (k) {
                meta[k] = extra[k];
            });
        }
        return meta;
    }

    function buildExtendedPayload(businessDateStr) {
        var metrics =
            typeof window.getFinancialMetrics === "function"
                ? window.getFinancialMetrics(businessDateStr)
                : null;
        if (!metrics) {
            return null;
        }

        var netSales = Number(metrics.netProfit) > 0 ? (Number(metrics.totalSales) || 0) : ((Number(metrics.totalSales) || 0) - (Number(metrics.totalReturns) || 0));
        var kpi = {
            salesToday: mobileStoredIqd(metrics.totalSales),
            expensesToday: mobileStoredIqd(metrics.totalOpExpenses || metrics.opExpenses),
            netProfitToday: mobileStoredIqd(metrics.netProfit),
            invoicesCountToday: 0
        };

        var salesRaw =
            typeof window.getAllSales === "function"
                ? window.getAllSales(false).filter(function (s) {
                      if (typeof window.getBusinessDate !== "function") return false;
                      var d =
                          typeof window.parseSQLDate === "function"
                              ? window.parseSQLDate(s.date || s.created_at)
                              : new Date(s.date || s.created_at);
                      return window.getBusinessDate(d) === businessDateStr;
                  })
                : [];
        kpi.invoicesCountToday = salesRaw.length;

        var privacy = getMobilePrivacyFlags();
        if (privacy.hideProfit) {
            kpi.netProfitToday = null;
        }

        function groupSaleLineItems(rawItems) {
            var grouped = {};
            (rawItems || []).forEach(function (it) {
                var qty =
                    Number(it.qty) > 0
                        ? Number(it.qty)
                        : Number(it.count) > 0
                          ? Number(it.count)
                          : 1;
                var price = mobileStoredIqd(Number(it.price) || 0);
                var saleUnit = it.saleUnit || "piece";
                var note = String(it.note || "");
                var key =
                    String(it.id || it.name || "") +
                    "_" +
                    note +
                    "_" +
                    price +
                    "_" +
                    saleUnit;
                if (!grouped[key]) {
                    grouped[key] = {
                        name: String(it.name || "").slice(0, 200),
                        qty: 0,
                        price: price,
                        saleUnit: saleUnit
                    };
                }
                grouped[key].qty += qty;
            });
            return Object.keys(grouped).map(function (k) {
                return grouped[k];
            });
        }

        var salesOut = [];
        var maxSales = privacy.hideSalesDetail ? 0 : 100;
        for (var i = 0; i < salesRaw.length && salesOut.length < maxSales; i++) {
            var s = salesRaw[i];
            var items = groupSaleLineItems(safeParseItems(s.items)).slice(0, 100);
            salesOut.push({
                id: s.id,
                date: s.date,
                total: mobileStoredIqd(s.total),
                cashier: String(s.cashier || "").slice(0, 80),
                payment_method: String(s.payment_method || "").slice(0, 40),
                is_returned: s.is_returned == 1,
                items: items
            });
        }

        var db = getPosDb();
        var returnsOut = [];
        var expensesOut = [];
        if (db) {
            if (db.returns && db.returns.length) {
                db.returns.forEach(function (r) {
                    if (
                        typeof window.getBusinessDate === "function" &&
                        window.getBusinessDate(new Date(r.date)) === businessDateStr
                    ) {
                        returnsOut.push({
                            id: r.id,
                            date: r.date,
                            total: mobileStoredIqd(r.total),
                            sale_id: r.sale_id
                        });
                    }
                });
            }
            if (db.expenses && db.expenses.length) {
                db.expenses.forEach(function (e) {
                    if (
                        typeof window.getBusinessDate === "function" &&
                        window.getBusinessDate(new Date(e.date)) === businessDateStr && 
                        e.type !== 'capital'
                    ) {
                        expensesOut.push({
                            id: e.id,
                            date: e.date,
                            amount: mobileStoredIqd(e.amount),
                            type: e.type || "operational",
                            note: String(e.note || "").slice(0, 200)
                        });
                    }
                });
            }
            var purchasesGrouped = {};
            if (db.supplies && db.supplies.length) {
                db.supplies.forEach(function (s) {
                    if (s.type === "return") return;
                    if (
                        typeof window.getBusinessDate !== "function" ||
                        window.getBusinessDate(new Date(s.date)) !== businessDateStr
                    ) {
                        return;
                    }
                    var key =
                        s.transaction_id ||
                        "OLD_" + String(s.date) + "_" + String(s.prodId || "");
                    if (!purchasesGrouped[key]) {
                        var invNo = "";
                        if (typeof resolveCompanyInvoiceDisplayNumber === "function") {
                            invNo = resolveCompanyInvoiceDisplayNumber(
                                s.supplier_invoice_number,
                                s.transaction_id
                            );
                        } else {
                            invNo = String(
                                s.supplier_invoice_number || s.transaction_id || ""
                            ).trim();
                        }
                        purchasesGrouped[key] = {
                            invoiceNo: String(invNo || "---").slice(0, 80),
                            company: String(s.company || "").slice(0, 120),
                            total: 0
                        };
                    }
                    purchasesGrouped[key].total += mobileStoredIqd(s.totalCost);
                });
            }
            var purchasesOut = Object.keys(purchasesGrouped).map(function (k) {
                return purchasesGrouped[k];
            });
            purchasesOut.sort(function (a, b) {
                return String(b.invoiceNo || "").localeCompare(
                    String(a.invoiceNo || ""),
                    undefined,
                    { numeric: true }
                );
            });
        }

        var purchasesOutFinal =
            typeof purchasesOut !== "undefined" ? purchasesOut.slice(0, 100) : [];

        return {
            kpi: kpi,
            sales: salesOut,
            returns: returnsOut.slice(0, 100),
            expenses: expensesOut.slice(0, 100),
            purchases: purchasesOutFinal,
            privacy: privacy,
            meta: mobileSyncMeta(businessDateStr, {
                truncatedSales: !privacy.hideSalesDetail && salesRaw.length > maxSales,
                salesTotalRows: salesRaw.length,
                purchasesCount: purchasesOutFinal.length,
                hideProfit: privacy.hideProfit,
                hideSalesDetail: privacy.hideSalesDetail
            })
        };
    }

    function resolveDefaultWarehouseId(db) {
        if (!db || !db.warehouses || !db.warehouses.length) return 0;
        var def = db.warehouses.find(function (w) {
            return Number(w.is_default) === 1;
        });
        return def ? Number(def.id) : Number(db.warehouses[0].id);
    }

    function resolveWarehouseName(db, whId) {
        if (!db || !db.warehouses || !whId) return "";
        var w = db.warehouses.find(function (x) {
            return Number(x.id) === Number(whId);
        });
        return w ? String(w.name || "") : "";
    }

    function productQtyForWarehouseSync(p, whId, db) {
        if (!p) return 0;
        var whCount = db && db.warehouses ? db.warehouses.length : 0;
        var strictMulti =
            whCount > 1 &&
            ((typeof window.canUseMultiWarehouse === "function" &&
                window.canUseMultiWarehouse()) ||
                (db.settings &&
                    (db.settings.enableMultiWarehouse === true ||
                        db.settings.enableMultiWarehouse === 1 ||
                        db.settings.enableMultiWarehouse === "true")));
        if (!strictMulti && whCount <= 1) return parseFloat(p.qty) || 0;
        if (!whId) return parseFloat(p.qty) || 0;
        if (typeof window.getProductQtyForWarehouse === "function") {
            return window.getProductQtyForWarehouse(p, whId);
        }
        var whQty = 0;
        var rows = db && db.warehouse_stock ? db.warehouse_stock : [];
        for (var i = 0; i < rows.length; i++) {
            if (
                Number(rows[i].product_id) === Number(p.id) &&
                Number(rows[i].warehouse_id) === Number(whId)
            ) {
                whQty = parseFloat(rows[i].qty) || 0;
                break;
            }
        }
        var productQty = parseFloat(p.qty) || 0;
        if (!strictMulti && productQty > whQty + 0.000001) return productQty;
        return whQty;
    }

    function minStockForProductSync(p, db) {
        if (typeof window.getMinStock === "function") return window.getMinStock(p);
        if (
            db &&
            db.settings &&
            (db.settings.useGlobalMinStock == true ||
                db.settings.useGlobalMinStock == "true" ||
                db.settings.useGlobalMinStock == 1)
        ) {
            return db.settings.globalMinStockThreshold !== undefined &&
                db.settings.globalMinStockThreshold !== null
                ? parseInt(db.settings.globalMinStockThreshold, 10)
                : 5;
        }
        return p &&
            p.minStock !== undefined &&
            p.minStock !== null &&
            p.minStock !== ""
            ? parseInt(p.minStock, 10)
            : 5;
    }

    function movementBusinessDate(m) {
        if (!m || !m.date) return "";
        if (typeof window.getBusinessDate === "function") {
            try {
                return window.getBusinessDate(new Date(m.date));
            } catch (e) {}
        }
        return String(m.date).slice(0, 10);
    }

    function productCostSync(p) {
        if (typeof window.getCatalogPieceCostIqd === "function") {
            return Number(window.getCatalogPieceCostIqd(p)) || 0;
        }
        return parseFloat(p.cost) || 0;
    }

    function productSellSync(p) {
        if (typeof window.getCatalogPieceSellIqd === "function") {
            return Number(window.getCatalogPieceSellIqd(p)) || 0;
        }
        return parseFloat(p.price) || 0;
    }

    function productExpirySync(p) {
        if (typeof window.getProductCatalogExpiryDisplay === "function") {
            var d = window.getProductCatalogExpiryDisplay(p);
            if (d && d !== "-") return String(d).slice(0, 24);
        }
        var raw = p.expiry || p.expiry_date || "";
        return raw ? String(raw).slice(0, 24) : "";
    }

    function buildInventoryPayload(businessDateStr) {
        var db = getPosDb();
        if (!db || !db.products) return null;

        var whId = resolveDefaultWarehouseId(db);
        var whName = resolveWarehouseName(db, whId);
        var warehouses = (db.warehouses || []).map(function (w) {
            return {
                id: Number(w.id),
                name: String(w.name || "").slice(0, 120),
                isDefault: Number(w.is_default) === 1,
                itemCount: (function () {
                    var n = 0;
                    (db.warehouse_stock || []).forEach(function (r) {
                        if (
                            Number(r.warehouse_id) === Number(w.id) &&
                            (parseFloat(r.qty) || 0) > 0
                        ) {
                            n++;
                        }
                    });
                    return n;
                })()
            };
        });

        var tracked = db.products.filter(function (p) {
            return p && p.trackStock;
        });
        var inStock = 0;
        var lowStock = 0;
        var outOfStock = 0;
        var expiringSoon = 0;
        var productsOut = [];
        var maxProducts = 250;

        tracked.forEach(function (p) {
            var qty = productQtyForWarehouseSync(p, whId, db);
            var minS = minStockForProductSync(p, db);
            var cost = productCostSync(p);
            var price = productSellSync(p);
            var lossPrice = cost > price;
            var status = "ok";
            var statusLabel = "باشە";
            if (qty <= 0) {
                outOfStock++;
                status = "out";
                statusLabel = (typeof t === 'function' ? t('wh_status_stockout') : 'نەما');
            } else {
                inStock++;
                if (qty <= minS) {
                    lowStock++;
                    status = "low";
                    statusLabel = "کەم";
                }
            }
            var expSoon = false;
            if (
                qty > 0 &&
                typeof window.productCatalogExpiryDaysLeft === "function"
            ) {
                var days = window.productCatalogExpiryDaysLeft(p);
                if (days != null && days <= 60) {
                    expiringSoon++;
                    expSoon = true;
                }
            }
            if (productsOut.length < maxProducts) {
                productsOut.push({
                    id: Number(p.id),
                    name: String(p.name || "").slice(0, 200),
                    barcode: String(p.barcode || "").slice(0, 64),
                    category: String(p.cat || p.category || "").slice(0, 80),
                    manufacturer: String(p.manufacturer || "").trim().slice(0, 80),
                    cost: cost,
                    price: price,
                    qty: qty,
                    minStock: minS,
                    expiry: productExpirySync(p),
                    status: status,
                    statusLabel: statusLabel,
                    lossPrice: lossPrice,
                    expSoon: expSoon
                });
            }
        });

        productsOut.sort(function (a, b) {
            if (a.qty <= 0 && b.qty > 0) return -1;
            if (a.qty > 0 && b.qty <= 0) return 1;
            return String(a.name).localeCompare(String(b.name), "ku", {
                sensitivity: "base"
            });
        });

        var movs = (db.warehouse_movements || []).filter(function (m) {
            return m && m.movement_type === "stocktake";
        });
        var stocktakeCountTotal = movs.length;
        var stocktakeCountToday = 0;
        var recentStocktakes = [];
        var sessionMap = Object.create(null);
        var maxRecent = 80;
        var maxSessions = 40;

        movs.forEach(function (m, idx) {
            var bd = movementBusinessDate(m);
            if (bd === businessDateStr) stocktakeCountToday++;
            if (idx < maxRecent) {
                recentStocktakes.push({
                    id: Number(m.id),
                    date: String(m.date || "").slice(0, 19),
                    businessDate: bd,
                    productId: Number(m.product_id),
                    productName: String(m.product_name || "").slice(0, 200),
                    qty: Number(m.quantity) || 0,
                    user: String(m.user || "").slice(0, 80),
                    warehouseId: Number(m.warehouse_id) || whId
                });
            }
            var sk = bd + "|" + (Number(m.warehouse_id) || whId);
            if (!sessionMap[sk]) {
                sessionMap[sk] = {
                    businessDate: bd,
                    warehouseId: Number(m.warehouse_id) || whId,
                    warehouseName: resolveWarehouseName(
                        db,
                        Number(m.warehouse_id) || whId
                    ),
                    itemCount: 0,
                    netVariance: 0
                };
            }
            sessionMap[sk].itemCount++;
            sessionMap[sk].netVariance += Number(m.quantity) || 0;
        });

        var stocktakeSessions = Object.keys(sessionMap)
            .map(function (k) {
                return sessionMap[k];
            })
            .sort(function (a, b) {
                return String(b.businessDate).localeCompare(String(a.businessDate));
            })
            .slice(0, maxSessions);

        var catSeen = Object.create(null);
        (db.categories || []).forEach(function (c) {
            var s = String(c || "").trim();
            if (s) catSeen[s] = 1;
        });
        tracked.forEach(function (p) {
            var c = String((p && (p.cat || p.category)) || "").trim();
            if (c) catSeen[c] = 1;
        });
        var categories = Object.keys(catSeen).sort(function (a, b) {
            return a.localeCompare(b, "ku", { sensitivity: "base" });
        });

        return {
            summary: {
                warehouseId: whId,
                warehouseName: whName,
                totalTracked: tracked.length,
                inStock: inStock,
                lowStock: lowStock,
                outOfStock: outOfStock,
                expiringSoon: expiringSoon,
                stocktakeCountTotal: stocktakeCountTotal,
                stocktakeCountToday: stocktakeCountToday,
                stocktakeSessionCount: stocktakeSessions.length
            },
            warehouses: warehouses,
            categories: categories,
            products: productsOut,
            recentStocktakes: recentStocktakes,
            stocktakeSessions: stocktakeSessions,
            meta: mobileSyncMeta(businessDateStr, {
                truncatedProducts: tracked.length > maxProducts,
                productsTotalRows: tracked.length
            })
        };
    }

    function buildDebtPayload() {
        var db = getPosDb();
        if (!db) return null;
        var roundM = mobileStoredIqd;

        function buildNameMap(rows) {
            var map = Object.create(null);
            (rows || []).forEach(function (r) {
                if (!r || r.id == null) return;
                map[String(r.id)] = String(r.name || "").slice(0, 120);
            });
            return map;
        }

        function buildLedgerByKey(entries, keyField, nameMap, maxPerKey, maxKeys) {
            var out = Object.create(null);
            var keyCount = 0;
            for (var i = entries.length - 1; i >= 0; i--) {
                var e = entries[i];
                if (!e) continue;
                var key = String(e[keyField]);
                if (!key || key === "0" || key === "NaN") continue;
                if (!out[key]) {
                    if (keyCount >= maxKeys) continue;
                    out[key] = [];
                    keyCount++;
                }
                if (out[key].length >= maxPerKey) continue;
                out[key].push({
                    type: String(e.type || "").slice(0, 24),
                    amount: roundM(e.amount || 0),
                    date: String(e.date || "").slice(0, 19),
                    note: String(e.note || "").slice(0, 120),
                    name: nameMap[key] || ""
                });
            }
            return out;
        }

        var customerReceivables = 0;
        var customerDebtorCount = 0;
        var customersOut = [];
        (db.customers || []).forEach(function (c) {
            var bal = roundM(c.balance || 0);
            var limit = roundM(c.debt_limit || 0);
            if (bal > 0) {
                customerReceivables += bal;
                customerDebtorCount++;
            }
            if (bal <= 0) return;
            customersOut.push({
                id: Number(c.id),
                name: String(c.name || "").slice(0, 120),
                phone: String(c.phone || "").slice(0, 40),
                balance: bal,
                debtLimit: limit,
                openingBalance: roundM(c.opening_balance || 0),
                overLimit: limit > 0 && bal > limit,
                hasDebt: true
            });
        });
        customersOut.sort(function (a, b) {
            return b.balance - a.balance;
        });
        var maxCust = 200;
        var custTruncated = customersOut.length > maxCust;
        customersOut = customersOut.slice(0, maxCust);

        var supplierPayables = 0;
        var supplierDebtCount = 0;
        var companiesOut = [];
        (db.companies || []).forEach(function (c) {
            var bal = roundM(c.balance || 0);
            if (bal > 0) {
                supplierPayables += bal;
                supplierDebtCount++;
            }
            if (bal <= 0) return;
            var limitC = roundM(c.debt_limit || 0);
            companiesOut.push({
                    id: Number(c.id),
                    name: String(c.name || "").slice(0, 120),
                    phone: String(c.phone || "").slice(0, 40),
                    balance: bal,
                    debtLimit: limitC,
                    openingBalance: roundM(c.opening_balance || 0),
                    overLimit: limitC > 0 && bal > limitC,
                    hasDebt: true
                });
        });
        companiesOut.sort(function (a, b) {
            return b.balance - a.balance;
        });
        var maxComp = 200;
        var compTruncated = companiesOut.length > maxComp;
        companiesOut = companiesOut.slice(0, maxComp);

        var customerLedgerRecent = [];
        var companyLedgerRecent = [];
        var maxLedger = 50;
        var cl = db.customer_ledger || [];
        for (var i = cl.length - 1; i >= 0 && customerLedgerRecent.length < maxLedger; i--) {
            var e = cl[i];
            if (!e) continue;
            var tid = String(e.target_id);
            customerLedgerRecent.push({
                targetId: Number(e.target_id),
                targetType: String(e.target_type || "customer").slice(0, 16),
                type: String(e.type || "").slice(0, 24),
                amount: roundM(e.amount || 0),
                date: String(e.date || "").slice(0, 19),
                note: String(e.note || "").slice(0, 120),
                name: buildNameMap(db.customers)[tid] || ""
            });
        }
        var lg = db.ledger || [];
        for (var j = lg.length - 1; j >= 0 && companyLedgerRecent.length < maxLedger; j--) {
            var le = lg[j];
            if (!le) continue;
            var cid = String(le.companyId);
            companyLedgerRecent.push({
                companyId: Number(le.companyId),
                type: String(le.type || "").slice(0, 24),
                amount: roundM(le.amount || 0),
                date: String(le.date || "").slice(0, 19),
                note: String(le.note || "").slice(0, 120),
                name: buildNameMap(db.companies)[cid] || ""
            });
        }

        var customerNameMap = buildNameMap(db.customers);
        var companyNameMap = buildNameMap(db.companies);
        var customerLedgerById = buildLedgerByKey(cl, "target_id", customerNameMap, 12, 80);
        var companyLedgerById = buildLedgerByKey(lg, "companyId", companyNameMap, 12, 80);

        return {
            summary: {
                customerReceivables: roundM(customerReceivables),
                customerDebtorCount: customerDebtorCount,
                supplierPayables: roundM(supplierPayables),
                supplierDebtCount: supplierDebtCount
            },
            customers: customersOut,
            companies: companiesOut,
            customerLedgerRecent: customerLedgerRecent,
            companyLedgerRecent: companyLedgerRecent,
            customerLedgerById: customerLedgerById,
            companyLedgerById: companyLedgerById,
            meta: mobileSyncMeta(todayBusinessDateStr(), {
                truncatedCustomers: custTruncated,
                truncatedCompanies: compTruncated,
                customersTotalRows: customerDebtorCount,
                companiesTotalRows: supplierDebtCount
            })
        };
    }

    function buildDebtSnapshotLite(debt) {
        if (!debt) return null;
        return {
            summary: debt.summary,
            customers: debt.customers,
            companies: debt.companies,
            customerLedgerRecent: debt.customerLedgerRecent || [],
            companyLedgerRecent: debt.companyLedgerRecent || [],
            meta: debt.meta
        };
    }

    function buildDebtStoragePayload(debt) {
        if (!debt) return null;
        return {
            summary: debt.summary,
            customers: debt.customers,
            companies: debt.companies,
            customerLedgerRecent: debt.customerLedgerRecent,
            companyLedgerRecent: debt.companyLedgerRecent,
            customerLedgerById: debt.customerLedgerById,
            companyLedgerById: debt.companyLedgerById,
            meta: debt.meta,
            updatedAt: nowIso()
        };
    }

    function pushDebtToSupabase(ch, debtPayload) {
        return sbUpsert("pos_mobile_debt", {
            channel_id: ch,
            data: stripTs(debtPayload)
        }, "channel_id");
    }

    function pushSnapshotToSupabase(ch, bd, dashPayload, detailPayload, invPayload, debtPayload) {
        var jobs = [];
        if (dashPayload && detailPayload) {
            jobs.push(sbUpsert("pos_mobile_dashboard", {
                channel_id: ch,
                data: stripTs(dashPayload)
            }, "channel_id"));
            jobs.push(sbUpsert("pos_mobile_daily_detail", {
                channel_id: ch,
                day_key: bd,
                data: stripTs(detailPayload)
            }, "channel_id,day_key"));
        }
        if (invPayload) {
            jobs.push(sbUpsert("pos_mobile_inventory", {
                channel_id: ch,
                data: stripTs(invPayload)
            }, "channel_id"));
        }
        if (debtPayload) {
            jobs.push(pushDebtToSupabase(ch, debtPayload));
        }
        if (!jobs.length) return Promise.resolve({ skipped: true, reason: "no_payload" });
        return Promise.all(jobs).then(function (results) {
            var err = null;
            (results || []).forEach(function (r) {
                if (r && r.error) err = r.error;
            });
            if (err) throw err;
            return { ok: true };
        });
    }

    window.pushFirebaseMobileDebtOnly = function (force) {
        return ensureMobileSync()
            .then(function () {
                var user = currentUser();
                if (!user || !user.email) {
                    return { skipped: true, reason: "not_authed" };
                }
                var now = Date.now();
                if (!force && now - syncState.lastDebtPushAt < MIN_PUSH_MS) {
                    return { skipped: true, reason: "debounce" };
                }
                var debt = buildDebtPayload();
                if (!debt) {
                    return { skipped: true, reason: "no_db" };
                }
                var ch = channelIdFromUser(user);
                var debtPayload = buildDebtStoragePayload(debt);
                return pushDebtToSupabase(ch, debtPayload)
                    .then(function () {
                        syncState.lastDebtPushAt = Date.now();
                        syncState.lastPushAt = Date.now();
                        try {
                            localStorage.setItem(LS_LAST_SYNC, String(syncState.lastPushAt));
                            localStorage.removeItem(LS_LAST_ERR);
                        } catch (e) {}
                        notifyUi();
                        return { ok: true, debt: true };
                    })
                    .catch(function (err) {
                        try {
                            localStorage.setItem(
                                LS_LAST_ERR,
                                String(err && err.message ? err.message : err)
                            );
                        } catch (e) {}
                        return { ok: false, error: err };
                    });
            })
            .catch(function (err) {
                return { ok: false, error: err };
            });
    };

    window.pushFirebaseMobileSnapshot = function (force) {
        return ensureMobileSync()
            .then(function () {
                var user = currentUser();
                if (!user || !user.email) {
                    return { skipped: true, reason: "not_authed" };
                }
                var now = Date.now();
                if (!force && now - syncState.lastPushAt < MIN_PUSH_MS) {
                    return { skipped: true, reason: "debounce" };
                }
                if (syncState.pushing) {
                    return { skipped: true, reason: "busy" };
                }
                syncState.pushing = true;

                var bd = todayBusinessDateStr();
                var ext = buildExtendedPayload(bd);
                var ch = channelIdFromUser(user);
                var inv = buildInventoryPayload(bd);
                var debt = buildDebtPayload();

                if (!ext && !inv && !debt) {
                    syncState.pushing = false;
                    return { skipped: true, reason: "no_payload" };
                }

                var dashPayload = null;
                var detailPayload = null;
                if (ext) {
                    var k = ext.kpi;
                    var posDb = getPosDb();
                    var bizStartHour = 0;
                    if (posDb && posDb.settings && posDb.settings.businessDayStartHour !== undefined) {
                        var sh = parseInt(posDb.settings.businessDayStartHour, 10);
                        if (Number.isFinite(sh) && sh >= 0 && sh <= 23) bizStartHour = sh;
                    }
                    dashPayload = {
                        salesToday: k.salesToday,
                        expensesToday: k.expensesToday,
                        netProfitToday: ext.privacy && ext.privacy.hideProfit ? null : k.netProfitToday,
                        invoicesCountToday: k.invoicesCountToday,
                        businessDate: bd,
                        businessDayStartHour: bizStartHour,
                        privacy: ext.privacy || getMobilePrivacyFlags(),
                        amountCurrency: "IQD",
                        posDisplayCurrency:
                            typeof getActiveCurrency === "function"
                                ? getActiveCurrency()
                                : "IQD",
                        usdRatePerOne:
                            typeof getUsdRatePerOne === "function"
                                ? getUsdRatePerOne()
                                : 0,
                        syncVersion: 3,
                        updatedAt: nowIso()
                    };
                    detailPayload = {
                        kpi: k,
                        sales: ext.sales,
                        returns: ext.returns,
                        expenses: ext.expenses,
                        purchases: ext.purchases,
                        privacy: ext.privacy || getMobilePrivacyFlags(),
                        meta: ext.meta,
                        pushedAt: nowIso()
                    };
                }

                var invPayload = inv
                    ? {
                          summary: inv.summary,
                          warehouses: inv.warehouses,
                          categories: inv.categories,
                          products: inv.products,
                          recentStocktakes: inv.recentStocktakes,
                          stocktakeSessions: inv.stocktakeSessions,
                          meta: inv.meta,
                          debtSnapshot: debt ? buildDebtSnapshotLite(debt) : null,
                          updatedAt: nowIso()
                      }
                    : null;

                var debtPayload = buildDebtStoragePayload(debt);
                if (debtPayload && debt && debt.meta) {
                    debtPayload.posDisplayCurrency = debt.meta.posDisplayCurrency;
                    debtPayload.usdRatePerOne = debt.meta.usdRatePerOne;
                }

                return pushSnapshotToSupabase(ch, bd, dashPayload, detailPayload, invPayload, debtPayload)
                    .then(function () {
                        syncState.lastPushAt = Date.now();
                        try {
                            localStorage.setItem(LS_LAST_SYNC, String(syncState.lastPushAt));
                            localStorage.removeItem(LS_LAST_ERR);
                        } catch (e) {}
                        notifyUi();
                        return { ok: true };
                    })
                    .catch(function (err) {
                        try {
                            localStorage.setItem(
                                LS_LAST_ERR,
                                String(err && err.message ? err.message : err)
                            );
                        } catch (e) {}
                        return { ok: false, error: err };
                    })
                    .finally(function () {
                        syncState.pushing = false;
                    });
            })
            .catch(function (err) {
                syncState.pushing = false;
                return { ok: false, error: err };
            });
    };

    window.scheduleFirebaseMobilePush = function (reason, force) {
        try {
            if (!navigator.onLine) return;
            if (!force && !getPosDb()) return;
        } catch (e) {
            return;
        }
        var run = function () {
            window.pushFirebaseMobileSnapshot(!!force).catch(function () {});
        };
        if (force) {
            run();
            return;
        }
        if (typeof window.requestIdleCallback === "function") {
            window.requestIdleCallback(run, { timeout: 800 });
        } else {
            setTimeout(run, 50);
        }
    };

    window.posFirebaseMobilePushAfterChange = function (reason) {
        window.scheduleFirebaseMobilePush(reason || "change", false);
    };

    window.posNotifyMobileDebtSync = function (reason) {
        if (typeof window.pushFirebaseMobileDebtOnly === "function") {
            window.pushFirebaseMobileDebtOnly(true).catch(function () {});
        } else {
            window.scheduleFirebaseMobilePush(reason || "debt", true);
        }
        scheduleDebtPushRetries();
    };

    window.posFirebaseSyncNow = function () {
        return ensureMobileSync()
            .then(function () {
                return window.pushFirebaseMobileSnapshot(true);
            })
            .then(function (r) {
                if (typeof window.pushFirebaseMobileDebtOnly === "function") {
                    return window.pushFirebaseMobileDebtOnly(true).then(function (dr) {
                        return { snap: r, debt: dr };
                    });
                }
                return { snap: r, debt: null };
            })
            .then(function (pack) {
                var r = pack.snap;
                var dr = pack.debt;
                notifyUi();
                if (typeof window.showToast !== "function") return pack;
                if (r && r.ok) {
                    window.showToast("✅ داشبۆرد + کۆگە + قەرز نێردرا بۆ Supabase", "success");
                } else if (r && r.reason === "not_authed") {
                    window.showToast("❌ سەرەتا Supabase sync پەیوەست بکە", "error");
                } else if (r && r.reason === "no_db") {
                    window.showToast("❌ داتای POS هێشتا بارنەبووە — چاوەڕێ بکە", "error");
                } else if (r && r.reason === "no_payload") {
                    window.showToast("❌ هیچ داتایەک بۆ ناردن نییە — فرۆشتن/کۆگە بپشکنە", "error");
                } else if (r && !r.ok && r.error) {
                    window.showToast("❌ هاوکات: " + String(r.error.message || r.error), "error");
                } else if (dr && dr.ok) {
                    window.showToast("✅ قەرز نێردرا (داشبۆرد — دووبارە هەوڵ بدە)", "success");
                }
                return pack;
            })
            .catch(function (err) {
                if (typeof window.showToast === "function") {
                    window.showToast("❌ هاوکات: " + String((err && err.message) || err), "error");
                }
                return { ok: false, error: err };
            });
    };

    window.logoutFirebaseSync = function () {
        return ensureMobileSync()
            .then(function (client) {
                return client.auth.signOut();
            })
            .then(function () {
                syncState.session = null;
                notifyUi();
            })
            .catch(function () {
                return Promise.resolve();
            });
    };

    window.openFirebaseSyncLogin = function () {
        ensureMobileSync().catch(function () {
            if (typeof window.showToast === "function") {
                window.showToast("Supabase config نییە.", "error");
            }
        });

        var existing = document.getElementById("firebase-cashier-auth-modal");
        if (existing) {
            existing.style.display = "flex";
            var ec = document.getElementById("firebase-cashier-auth-card");
            if (ec && typeof window.applyI18nSubtree === "function") {
                window.applyI18nSubtree(ec);
            }
            return;
        }

        var wrap = document.createElement("div");
        wrap.id = "firebase-cashier-auth-modal";
        wrap.style.cssText =
            "position:fixed;inset:0;z-index:30000;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center;padding:16px;";
        wrap.innerHTML =
            '<div id="firebase-cashier-auth-card" style="background:var(--card,#fff);color:var(--text,#111);max-width:400px;width:100%;padding:20px;border-radius:16px;box-shadow:0 20px 50px rgba(0,0,0,.3);">' +
            '<h3 style="margin:0 0 12px;font-size:1.1rem;"><span data-i18n="firebase_modal_title"></span></h3>' +
            '<p style="margin:0 0 8px;font-size:0.9rem;opacity:.85;"><span data-i18n="firebase_modal_desc"></span></p>' +
            '<p style="margin:0 0 12px;font-size:0.75rem;opacity:.7;line-height:1.45;"><span data-i18n="firebase_modal_supabase_hint"></span></p>' +
            '<label style="display:block;margin-bottom:6px;font-size:0.85rem;"><span data-i18n="firebase_modal_email"></span></label>' +
            '<input type="email" id="fb-sync-email-in" class="input-std" style="width:100%;margin-bottom:10px;" autocomplete="username" />' +
            '<label style="display:block;margin-bottom:6px;font-size:0.85rem;"><span data-i18n="firebase_modal_password"></span></label>' +
            '<input type="password" id="fb-sync-pass-in" class="input-std" style="width:100%;margin-bottom:14px;" autocomplete="current-password" />' +
            '<div style="display:flex;gap:10px;flex-wrap:wrap;">' +
            '<button type="button" id="fb-sync-login-btn" class="btn btn-brand" style="flex:1;"><span data-i18n="firebase_modal_connect"></span></button>' +
            '<button type="button" id="fb-sync-cancel-btn" class="btn btn-dark"><span data-i18n="firebase_modal_cancel"></span></button>' +
            '</div>' +
            '<p id="fb-sync-msg" style="margin:10px 0 0;font-size:0.85rem;color:var(--danger,#b91c1c);min-height:1.2em;"></p>' +
            "</div>";

        document.body.appendChild(wrap);

        var fbCard = document.getElementById("firebase-cashier-auth-card");
        if (fbCard && typeof window.applyI18nSubtree === "function") {
            window.applyI18nSubtree(fbCard);
        }

        document.getElementById("fb-sync-cancel-btn").onclick = function () {
            wrap.remove();
        };
        wrap.addEventListener("click", function (e) {
            if (e.target === wrap) wrap.remove();
        });

        document.getElementById("fb-sync-login-btn").onclick = function () {
            var em = (
                document.getElementById("fb-sync-email-in") || {}
            ).value || "";
            var pw = (
                document.getElementById("fb-sync-pass-in") || {}
            ).value || "";
            var msg = document.getElementById("fb-sync-msg");
            if (!em || !pw) {
                if (msg)
                    msg.textContent =
                        typeof window.t === "function"
                            ? window.t("firebase_err_enter_credentials")
                            : "Enter email and password.";
                return;
            }
            var emNorm = String(em).trim().toLowerCase();
            var dom = emNorm.split("@")[1] || "";
            if (!dom || dom.indexOf(".") < 1 || dom === "0") {
                if (msg)
                    msg.textContent =
                        "ئیمێیل هەڵەیە. دەبێت وەک hakar01@pos.laptopduhok.com بێت (نە com.0@0).";
                return;
            }
            ensureMobileSync()
                .then(function (client) {
                    return client.auth.signInWithPassword({ email: emNorm, password: pw });
                })
                .then(function (res) {
                    if (res.error) throw res.error;
                    syncState.session = res.data.session;
                    if (msg) msg.textContent = "";
                    wrap.remove();
                    notifyUi();
                    window.scheduleFirebaseMobilePush("login", true);
                    window.pushFirebaseMobileDebtOnly(true).catch(function () {});
                    scheduleDebtPushRetries();
                    if (typeof window.showToast === "function") {
                        window.showToast("✅ Supabase پەیوەست کرا", "success");
                    }
                })
                .catch(function (err) {
                    if (msg) {
                        msg.style.whiteSpace = "pre-line";
                        msg.textContent = formatSbLoginError(err);
                    }
                });
        };
    };

    ensureMobileSync()
        .then(function () {
            notifyUi();
        })
        .catch(function () {});

    var POS_MOBILE_MANAGER_PUBLIC_URL = 'https://laptopduhokpos.github.io/LP/mobile_manager/';

    function getPosMobileManagerUrl(opts) {
        opts = opts || {};
        var url;
        if (typeof db !== 'undefined' && db.settings) {
            var custom = String(db.settings.mobileManagerUrl || '').trim();
            if (custom) url = custom.replace(/\/?$/, '/');
        }
        if (!url) url = POS_MOBILE_MANAGER_PUBLIC_URL;
        if (opts.cacheBust) {
            var ver = (typeof window.getPosAppVersion === 'function') ? String(window.getPosAppVersion()) : '';
            if (!ver && typeof window.POS_APP_VERSION !== 'undefined') ver = String(window.POS_APP_VERSION);
            if (!ver) ver = String(Date.now());
            url += (url.indexOf('?') >= 0 ? '&' : '?') + 'v=' + encodeURIComponent(ver);
        }
        return url;
    }

    function refreshMobileManagerAppUi() {
        var urlEl = document.getElementById('firebase-mobile-app-url');
        var qrEl = document.getElementById('firebase-mobile-app-qr');
        var url = getPosMobileManagerUrl();
        if (urlEl) urlEl.textContent = url;
        applyMobileSyncPrivacyUi();
        if (!qrEl) return;
        var qrPayload = url;
        var dataUrl = '';
        if (typeof window.posOfflineQrDataUrl === 'function') {
            dataUrl = window.posOfflineQrDataUrl(qrPayload, 120);
        }
        if (dataUrl) {
            qrEl.src = dataUrl;
            qrEl.style.display = 'block';
            qrEl.alt = 'QR — Mobile Manager';
            return;
        }
        qrEl.onerror = function () {
            qrEl.onerror = null;
            qrEl.src = 'https://api.qrserver.com/v1/create-qr-code/?size=120x120&margin=8&data=' + encodeURIComponent(qrPayload);
        };
        qrEl.src = 'https://api.qrserver.com/v1/create-qr-code/?size=120x120&margin=8&data=' + encodeURIComponent(qrPayload);
        qrEl.style.display = 'block';
        qrEl.alt = 'QR — Mobile Manager';
    }

    window.getPosMobileManagerUrl = getPosMobileManagerUrl;
    window.refreshMobileManagerAppUi = refreshMobileManagerAppUi;
    window.getMobilePrivacyFlags = getMobilePrivacyFlags;

    function applyMobileSyncPrivacyUi() {
        var db = getPosDb();
        var s = db && db.settings ? db.settings : {};
        var profitEl = document.getElementById('set-mobile-hide-profit');
        var salesEl = document.getElementById('set-mobile-hide-sales-detail');
        if (profitEl) {
            profitEl.checked = !!(
                s.mobileHideProfit === true ||
                s.mobileHideProfit === 1 ||
                s.mobileHideProfit === "true"
            );
        }
        if (salesEl) {
            salesEl.checked = !!(
                s.mobileHideSalesDetail === true ||
                s.mobileHideSalesDetail === 1 ||
                s.mobileHideSalesDetail === "true"
            );
        }
    }
    window.applyMobileSyncPrivacyUi = applyMobileSyncPrivacyUi;

    window.onMobileSyncPrivacyChange = function (key) {
        var db = getPosDb();
        if (!db) return;
        if (!db.settings) db.settings = {};
        var profitEl = document.getElementById('set-mobile-hide-profit');
        var salesEl = document.getElementById('set-mobile-hide-sales-detail');
        if (key === "profit" && profitEl) db.settings.mobileHideProfit = !!profitEl.checked;
        if (key === "salesDetail" && salesEl) {
            db.settings.mobileHideSalesDetail = !!salesEl.checked;
        }
        var done = function () {
            if (typeof window.scheduleFirebaseMobilePush === "function") {
                window.scheduleFirebaseMobilePush("privacy", true);
            }
            if (typeof window.showToast === "function") {
                window.showToast(
                    typeof window.t === "function"
                        ? window.t("firebase_mobile_privacy_saved")
                        : "ڕێکخستن پاشەکەوت کرا — هاوکاتکردن…",
                    "success"
                );
            }
        };
        if (typeof saveSettings === "function") {
            saveSettings().then(done).catch(function () {
                if (typeof window.showToast === "function") {
                    window.showToast("هەڵە د پاراستنێ دا", "error");
                }
            });
        } else {
            done();
        }
    };

    window.openMobileManagerApp = function () {
        var url = getPosMobileManagerUrl({ cacheBust: true });
        window.open(url, '_blank', 'noopener');
    };

    window.copyMobileManagerUrl = function () {
        var url = getPosMobileManagerUrl();
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(url).then(function () {
                if (typeof showToast === 'function') {
                    showToast(typeof t === 'function' ? t('firebase_mobile_copied') : 'لینک کۆپی کرا ✓');
                }
            }).catch(function () {
                window.prompt(typeof t === 'function' ? t('firebase_mobile_copy_prompt') : 'لینک:', url);
            });
        } else {
            window.prompt(typeof t === 'function' ? t('firebase_mobile_copy_prompt') : 'لینک:', url);
        }
    };

    function getPosApiBase() {
        var path = String(location.pathname || '');
        var lower = path.toLowerCase();
        var root = '/pos';
        var idx = lower.indexOf('/pos');
        if (idx >= 0) {
            root = path.substring(0, idx + 4);
        }
        root = root.replace(/\/$/, '');
        return location.origin + root;
    }

    window.refreshMobileBackupPinUi = function () {
        var pinEl = document.getElementById('mobile-backup-pin');
        if (!pinEl) return;
        fetch(getPosApiBase() + '/?action=get_mobile_backup_info', { credentials: 'same-origin' })
            .then(function (res) { return res.json(); })
            .then(function (data) {
                if (data.status === 'success' && data.pin) {
                    pinEl.textContent = data.pin;
                }
            })
            .catch(function () {});
    };

    window.regenerateMobileBackupPin = function () {
        if (!confirm('PINـی نوێ دروست بکرێت؟')) return;
        var fd = new FormData();
        fd.append('action', 'regenerate_mobile_backup_pin');
        fetch(getPosApiBase() + '/?action=regenerate_mobile_backup_pin', { method: 'POST', body: fd, credentials: 'same-origin' })
            .then(function (res) { return res.json(); })
            .then(function (data) {
                if (data.status === 'success' && data.pin) {
                    var pinEl = document.getElementById('mobile-backup-pin');
                    if (pinEl) pinEl.textContent = data.pin;
                    if (typeof showToast === 'function') showToast('✓ PIN نوێ: ' + data.pin);
                } else {
                    alert('❌ ' + (data.message || 'error'));
                }
            })
            .catch(function (err) { alert('❌ ' + err); });
    };

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", refreshMobileManagerAppUi);
    } else {
        refreshMobileManagerAppUi();
    }

    if (typeof document !== "undefined") {
        document.addEventListener("visibilitychange", function () {
            if (document.visibilityState !== "visible") return;
            if (!currentUser() || !currentUser().email) return;
            window.scheduleFirebaseMobilePush("visible", true);
        });
    }
})();
