// core/catalog.js — product catalog helpers
/**
 * Partial catalog for large shops: server search, barcode lookup, background page load.
 * Barcode scans always fall back to SQL when product is not in local db.products yet.
 */
(function () {
    'use strict';

    var _barcodeLookupCache = Object.create(null);
    var _barcodeLookupInflight = Object.create(null);
    var _serverSearchInflight = null;
    var _serverSearchKey = '';
    var _serverSearchRows = null;
    var _catalogFetchTail = Promise.resolve();
    var _scanIndexRebuildTimer = null;

    function posCatalogFetchRun(taskFn) {
        var run = _catalogFetchTail.then(function () { return taskFn(); });
        _catalogFetchTail = run.then(function () { }, function () { });
        return run;
    }

    function posScheduleScanIndexRebuild() {
        if (typeof window.rebuildPosScanIndex !== 'function') return;
        if (_scanIndexRebuildTimer) clearTimeout(_scanIndexRebuildTimer);
        _scanIndexRebuildTimer = setTimeout(function () {
            _scanIndexRebuildTimer = null;
            window.rebuildPosScanIndex();
        }, 80);
    }

    function posCatalogBackgroundPaused() {
        if (window.__posCatalogBgPaused) return true;
        if (window._posScanQueueBusy) return true;
        return false;
    }

    function posPauseCatalogBackground() {
        window.__posCatalogBgPaused = true;
    }

    function posResumeCatalogBackgroundLoad() {
        if (window._posScanQueueBusy) return;
        window.__posCatalogBgPaused = false;
        if (posIsCatalogPartial() && !window.__posCatalogBgLoading) {
            scheduleCatalogBackgroundLoad();
        }
    }

    function posCatalogLoadedCount() {
        if (!window.db || !Array.isArray(window.db.products)) return 0;
        return window.db.products.length;
    }

    function posCatalogTotal() {
        if (!window.db) return 0;
        var h = parseInt((window.db._db_health || {}).products_count, 10) || 0;
        var ct = parseInt(window.db._catalog_total, 10) || 0;
        var best = Math.max(h, ct);
        if (best > 0) return best;
        return posCatalogLoadedCount();
    }

    function posSyncCatalogTotalFromResponse(data) {
        if (!window.db || !data) return;
        var t = parseInt(data.total, 10);
        if (!Number.isFinite(t) || t <= 0) return;
        var cur = parseInt(window.db._catalog_total, 10) || 0;
        if (t > cur) window.db._catalog_total = t;
        if (!window.db._db_health) window.db._db_health = {};
        var hc = parseInt(window.db._db_health.products_count, 10) || 0;
        if (t > hc) window.db._db_health.products_count = t;
        posReconcileCatalogPartial();
    }

    function posReconcileCatalogPartial() {
        if (!window.db) return;
        var loaded = posCatalogLoadedCount();
        var total = posCatalogTotal();
        window.db._catalog_loaded = loaded;
        // Only mark complete when every active product is in memory — never leave a 5-item gap.
        if (total > 0 && loaded >= total) {
            window.db._catalog_partial = false;
            window.db._catalog_server_offset = total;
            window.db._catalog_total = loaded;
            if (window.db._db_health) window.db._db_health.products_count = loaded;
            return;
        }
        if (total > 0 && loaded > 0 && loaded < total) {
            window.db._catalog_partial = true;
        }
    }

    /** If server total includes inactive/deleted rows, snap total down after gap-fill fails. */
    function posCatalogAcceptNearComplete(loaded, total) {
        loaded = parseInt(loaded, 10) || 0;
        total = parseInt(total, 10) || 0;
        var gap = total - loaded;
        if (loaded <= 0 || gap <= 0 || gap > 25) return false;
        if (!window.db) return false;
        window.db._catalog_total = loaded;
        if (!window.db._db_health) window.db._db_health = {};
        window.db._db_health.products_count = loaded;
        window.db._catalog_partial = false;
        window.db._catalog_loaded = loaded;
        window.db._catalog_server_offset = loaded;
        return true;
    }

    function posIsCatalogPartial() {
        if (!window.db) return false;
        posReconcileCatalogPartial();
        var total = posCatalogTotal();
        var loaded = posCatalogLoadedCount();
        if (total > 0 && loaded >= total) return false;
        if (window.db._catalog_partial === true) return true;
        return total > 0 && loaded > 0 && loaded < total;
    }

    function posScheduleWarehouseRefreshIfActive() {
        if (window._wmsCatalogRefreshTimer) return;
        window._wmsCatalogRefreshTimer = setTimeout(function () {
            window._wmsCatalogRefreshTimer = null;
            if (typeof window.invalidateWmsWarehouseCache === 'function') window.invalidateWmsWarehouseCache();
            var vwh = document.getElementById('view-warehouse');
            if (vwh && vwh.classList.contains('active') && typeof window.renderWarehouse === 'function') {
                window.renderWarehouse();
            }
        }, 400);
    }

    function posMarkCatalogMeta(data) {
        if (!window.db || !data) return;
        if (data.catalog_tier) window.__posCatalogTier = String(data.catalog_tier);
        if (data.catalog_partial === true) {
            window.db._catalog_partial = true;
            if (data.catalog_total != null) window.db._catalog_total = parseInt(data.catalog_total, 10) || 0;
            if (data.catalog_loaded != null) {
                window.db._catalog_loaded = parseInt(data.catalog_loaded, 10) || 0;
                window.db._catalog_server_offset = window.db._catalog_loaded;
            }
            // Restart id-DESC walk after every partial bootstrap so no SKU is skipped.
            window.db._catalog_before_id = 2147483647;
            window.__posCatalogBgRetries = 0;
        } else if (Array.isArray(data.products) && data.products.length > 0) {
            var total = posCatalogTotal();
            if (!total || data.products.length >= total) {
                window.db._catalog_partial = false;
                window.db._catalog_total = data.products.length;
                window.db._catalog_loaded = data.products.length;
                window.db._catalog_server_offset = data.products.length;
            }
        }
    }

    function posCatalogServerOffset() {
        if (!window.db) return 0;
        if (window.db._catalog_server_offset != null) return parseInt(window.db._catalog_server_offset, 10) || 0;
        if (window.db._catalog_loaded != null) return parseInt(window.db._catalog_loaded, 10) || 0;
        return Array.isArray(window.db.products) ? window.db.products.length : 0;
    }

    function posAdvanceCatalogServerOffset(n) {
        if (!window.db) return;
        var cur = posCatalogServerOffset();
        window.db._catalog_server_offset = cur + (parseInt(n, 10) || 0);
    }

    function posBarcodeNeedsServerLookup(val) {
        val = String(val || '').trim();
        if (!val) return false;
        var nv = (typeof window.normalizeBarcodeSearchInput === 'function')
            ? window.normalizeBarcodeSearchInput(val)
            : val.toLowerCase();
        if (window._posScanIndex && window._posScanIndex.exact && window._posScanIndex.exact[nv] && window._posScanIndex.exact[nv].length) {
            return false;
        }
        if (window.db && Array.isArray(window.db.products) && typeof window.productMatchesPosScanCode === 'function') {
            for (var i = 0; i < window.db.products.length; i++) {
                if (window.productMatchesPosScanCode(window.db.products[i], val)) return false;
            }
        }
        // Local miss → always SQL. Never skip the database even if the in-memory catalog looks complete.
        return true;
    }

    function posUpsertProducts(rows, opts) {
        opts = opts || {};
        if (!window.db || !Array.isArray(rows) || !rows.length) return 0;
        if (!Array.isArray(window.db.products)) window.db.products = [];
        var byId = Object.create(null);
        window.db.products.forEach(function (p) {
            if (p && p.id != null) byId[String(p.id)] = p;
        });
        var added = 0;
        rows.forEach(function (r) {
            if (!r || r.id == null) return;
            var k = String(r.id);
            if (!byId[k]) added++;
            byId[k] = r;
        });
        window.db.products = Object.keys(byId).map(function (k) { return byId[k]; });
        window._posProductById = null;
        posReconcileCatalogPartial();
        if (typeof window.invalidatePosMenuListCache === 'function') window.invalidatePosMenuListCache();
        if (!opts.skipScanIndexRebuild) {
            if (opts.incrementalScanIndex && typeof window.registerProductInScanIndex === 'function') {
                rows.forEach(function (r) {
                    if (r && r.id != null) window.registerProductInScanIndex(r);
                });
            } else {
                posScheduleScanIndexRebuild();
            }
        }
        if (typeof window.invalidateWmsWarehouseCache === 'function') window.invalidateWmsWarehouseCache();
        if (!opts.skipWarehouseRefresh) posScheduleWarehouseRefreshIfActive();
        return added;
    }

    /** Patch one product into local cache without full catalog download or full scan rebuild. */
    function posPatchLocalProduct(product, opts) {
        opts = opts || {};
        if (!product || product.id == null) return false;
        if (!window.db) window.db = {};
        if (!Array.isArray(window.db.products)) window.db.products = [];
        var idStr = String(product.id);
        var idx = -1;
        for (var i = 0; i < window.db.products.length; i++) {
            if (window.db.products[i] && String(window.db.products[i].id) === idStr) {
                idx = i;
                break;
            }
        }
        if (idx > -1) {
            var merged = Object.assign({}, window.db.products[idx], product);
            window.db.products[idx] = merged;
            product = merged;
        } else if (opts.prepend !== false) {
            window.db.products.unshift(product);
        } else {
            window.db.products.push(product);
        }
        window._posProductById = null;
        if (typeof window.invalidatePosMenuListCache === 'function') window.invalidatePosMenuListCache();
        if (typeof window.registerProductInScanIndex === 'function') {
            window.registerProductInScanIndex(product);
        } else if (!opts.skipScanIndex) {
            posScheduleScanIndexRebuild();
        }
        return true;
    }

    function posCatalogSearchUrl(params) {
        var lite = '';
        if ((typeof window.isPosCpuSaveMode === 'function' && window.isPosCpuSaveMode())
            || (typeof window.isPosLargeShopMode === 'function' && window.isPosLargeShopMode())
            || window.__posProductsLiteLoaded) {
            lite = '&lite_products=1';
        }
        return '?action=search_products' + params + lite + '&t=' + Date.now();
    }

    function posFetchProductSearch(q, limit, offset) {
        limit = limit || 60;
        offset = offset || 0;
        var url = posCatalogSearchUrl(
            '&q=' + encodeURIComponent(q || '')
            + '&limit=' + encodeURIComponent(String(limit))
            + '&offset=' + encodeURIComponent(String(offset))
        );
        return fetch(url, { credentials: 'same-origin' })
            .then(function (r) { return r.json().catch(function () { return { status: 'error' }; }); })
            .then(function (data) {
                posSyncCatalogTotalFromResponse(data);
                if (data && data.status === 'ok') {
                    posOfferReactivateInactiveProducts(data.inactive_rows || [], q);
                }
                return data;
            });
    }

    /** Walk search_products pages so warehouse/admin lists never hide matching SKUs. */
    function posFetchProductSearchAll(q, pageLimit, maxRows) {
        q = String(q || '').trim();
        pageLimit = parseInt(pageLimit, 10) || 100;
        if (pageLimit < 20) pageLimit = 20;
        if (pageLimit > 200) pageLimit = 200;
        maxRows = parseInt(maxRows, 10) || 8000;
        var all = [];
        var seen = Object.create(null);
        var offset = 0;
        var matchTotal = 0;
        var lastInactive = [];
        function step() {
            return posFetchProductSearch(q, pageLimit, offset).then(function (data) {
                if (!data || data.status !== 'ok' || !Array.isArray(data.rows)) {
                    return { status: 'ok', rows: all, inactive_rows: lastInactive, has_more: false, match_total: matchTotal || all.length };
                }
                if (data.match_total != null) matchTotal = parseInt(data.match_total, 10) || matchTotal;
                if (Array.isArray(data.inactive_rows) && data.inactive_rows.length) lastInactive = data.inactive_rows;
                data.rows.forEach(function (r) {
                    if (!r || r.id == null) return;
                    var k = String(r.id);
                    if (seen[k]) return;
                    seen[k] = 1;
                    all.push(r);
                });
                if (data.rows.length) posUpsertProducts(data.rows);
                if (data.has_more && all.length < maxRows) {
                    offset += pageLimit;
                    return step();
                }
                return {
                    status: 'ok',
                    rows: all,
                    inactive_rows: lastInactive,
                    has_more: !!(data.has_more && all.length >= maxRows),
                    match_total: matchTotal || all.length,
                    total: data.total
                };
            });
        }
        return step();
    }

    function posReactivateProduct(id) {
        id = parseInt(id, 10) || 0;
        if (id <= 0) return Promise.resolve(null);
        var fd = new FormData();
        fd.append('action', 'reactivate_product');
        fd.append('id', String(id));
        fd.append('user', (window.currentUser && window.currentUser.name) ? window.currentUser.name : 'System');
        return fetch('?action=reactivate_product', { method: 'POST', body: fd, credentials: 'same-origin' })
            .then(function (r) { return r.json().catch(function () { return { status: 'error' }; }); })
            .then(function (data) {
                if (!data || data.status !== 'success') {
                    var msg = (data && data.message) ? data.message : 'نەشیا ئایتم چالاک بکرێتەوە';
                    if (typeof showToast === 'function') showToast(msg, 'error');
                    return null;
                }
                if (data.product && typeof posUpsertProducts === 'function') {
                    posUpsertProducts([data.product]);
                }
                if (typeof invalidateWmsWarehouseCache === 'function') invalidateWmsWarehouseCache();
                if (typeof invalidatePosMenuListCache === 'function') invalidatePosMenuListCache();
                if (typeof rebuildPosScanIndex === 'function') rebuildPosScanIndex();
                if (typeof showToast === 'function') {
                    showToast('✅ ئایتم چالاک کرایەوە — ئێستا لە کۆگە و فرۆشتن دیارە', 'success');
                }
                return data.product || { id: id };
            })
            .catch(function () {
                if (typeof showToast === 'function') showToast('نەشیا ئایتم چالاک بکرێتەوە', 'error');
                return null;
            });
    }

    var _inactiveOfferKey = '';
    var _inactiveOfferAt = 0;
    function posOfferReactivateInactiveProducts(inactiveRows, searchQ) {
        if (!inactiveRows || !inactiveRows.length) return;
        var first = inactiveRows[0];
        var pid = first && first.id != null ? first.id : 0;
        if (!pid) return;
        var key = String(searchQ || '') + '|' + String(pid);
        var now = Date.now();
        if (_inactiveOfferKey === key && (now - _inactiveOfferAt) < 8000) return;
        _inactiveOfferKey = key;
        _inactiveOfferAt = now;
        var name = (first.name || searchQ || ('#' + pid)).trim();
        var qty = parseFloat(first.qty) || 0;
        var msg = '«' + name + '» ناچالاک کراوە (ژێبرن) — لە مێژووی کڕین دەردەکەوێت بەڵام لە کۆگە/فرۆشتن نا.'
            + (qty > 0 ? ('\nکۆگە: ' + qty) : '')
            + '\n\nدەتەوێت چالاک بکەیتەوە؟';
        if (!window.confirm(msg)) return;
        posReactivateProduct(pid).then(function (p) {
            if (!p) return;
            if (typeof renderWarehouse === 'function') {
                var vwh = document.getElementById('view-warehouse');
                if (vwh && vwh.classList.contains('active')) renderWarehouse();
            }
            if (typeof renderPOSMenu === 'function') {
                var pin = document.getElementById('pos-barcode-input');
                renderPOSMenu(pin ? pin.value : (searchQ || ''));
            }
            if (typeof renderProducts === 'function') {
                var vpr = document.getElementById('view-products');
                if (vpr && vpr.classList.contains('active')) renderProducts();
            }
        });
    }

    function posFetchProductPage(offset, limit, opts) {
        limit = limit || 120;
        offset = offset || 0;
        opts = opts || {};
        var extra = '&limit=' + encodeURIComponent(String(limit));
        if (opts.beforeId > 0) {
            extra += '&before_id=' + encodeURIComponent(String(opts.beforeId));
        } else {
            extra += '&offset=' + encodeURIComponent(String(offset));
        }
        var url = posCatalogSearchUrl(extra);
        return posCatalogFetchRun(function () {
            return fetch(url, { credentials: 'same-origin' })
                .then(function (r) { return r.json().catch(function () { return { status: 'error' }; }); })
                .then(function (data) { posSyncCatalogTotalFromResponse(data); return data; });
        });
    }

    function posCatalogMinLoadedId() {
        if (!window.db || !Array.isArray(window.db.products) || !window.db.products.length) return 0;
        var minId = 0;
        for (var i = 0; i < window.db.products.length; i++) {
            var id = parseInt(window.db.products[i] && window.db.products[i].id, 10) || 0;
            if (id > 0 && (minId === 0 || id < minId)) minId = id;
        }
        return minId;
    }

    function posCatalogMaxLoadedId() {
        if (!window.db || !Array.isArray(window.db.products) || !window.db.products.length) return 0;
        var maxId = 0;
        for (var i = 0; i < window.db.products.length; i++) {
            var id = parseInt(window.db.products[i] && window.db.products[i].id, 10) || 0;
            if (id > maxId) maxId = id;
        }
        return maxId;
    }

    function posLookupProductByBarcode(val) {
        val = String(val || '').trim();
        if (!val) return Promise.resolve(null);
        var nv = (typeof window.normalizeBarcodeSearchInput === 'function')
            ? window.normalizeBarcodeSearchInput(val)
            : val.toLowerCase();
        if (_barcodeLookupCache[nv]) {
            return Promise.resolve(_barcodeLookupCache[nv]);
        }
        if (_barcodeLookupInflight[nv]) {
            return _barcodeLookupInflight[nv];
        }
        var url = posCatalogSearchUrl('&barcode=' + encodeURIComponent(val));
        var p = fetch(url, { credentials: 'same-origin' })
            .then(function (r) { return r.json().catch(function () { return { status: 'error' }; }); })
            .then(function (data) {
                delete _barcodeLookupInflight[nv];
                if (data && data.status === 'ok' && Array.isArray(data.inactive_rows) && data.inactive_rows.length
                    && (!data.rows || !data.rows.length)) {
                    posOfferReactivateInactiveProducts(data.inactive_rows, val);
                    return null;
                }
                if (!data || data.status !== 'ok' || !Array.isArray(data.rows) || !data.rows.length) {
                    return null;
                }
                posUpsertProducts(data.rows);
                var found = null;
                if (typeof window.normalizeBarcodeSearchInput === 'function' && typeof window.productMatchesPosScanCode === 'function') {
                    for (var i = 0; i < data.rows.length; i++) {
                        if (window.productMatchesPosScanCode(data.rows[i], val)) {
                            found = data.rows[i];
                            break;
                        }
                    }
                }
                if (!found) found = data.rows[0];
                _barcodeLookupCache[nv] = found;
                return found;
            })
            .catch(function () {
                delete _barcodeLookupInflight[nv];
                return null;
            });
        _barcodeLookupInflight[nv] = p;
        return p;
    }

    /** Before local scan fails: ensure barcode exists in db.products (server SQL). */
    function posEnsureProductByBarcode(val) {
        val = String(val || '').trim();
        if (typeof window.sanitizeScannerBarcodeInput === 'function') {
            val = window.sanitizeScannerBarcodeInput(val);
        }
        if (!val) return Promise.resolve(null);
        var nv = (typeof window.normalizeBarcodeSearchInput === 'function')
            ? window.normalizeBarcodeSearchInput(val)
            : val.toLowerCase();
        if (window._posScanIndex && window._posScanIndex.exact && window._posScanIndex.exact[nv] && window._posScanIndex.exact[nv].length) {
            return Promise.resolve(window._posScanIndex.exact[nv][0].p);
        }
        if (window.db && Array.isArray(window.db.products)) {
            for (var i = 0; i < window.db.products.length; i++) {
                var p = window.db.products[i];
                if (p && typeof window.productMatchesPosScanCode === 'function' && window.productMatchesPosScanCode(p, val)) {
                    return Promise.resolve(p);
                }
            }
        }
        return posLookupProductByBarcode(val);
    }

    function posEnsureScalePluProduct(itemCode) {
        var pluNorm = (typeof window.normalizeScalePlu === 'function')
            ? window.normalizeScalePlu(itemCode)
            : String(itemCode || '').trim();
        if (!pluNorm) return Promise.resolve(null);
        var local = (typeof window.findProductByScalePlu === 'function')
            ? window.findProductByScalePlu(itemCode)
            : null;
        if (local) return Promise.resolve(local);
        return posLookupProductByBarcode(pluNorm).then(function (p) {
            if (p) return p;
            return posLookupProductByBarcode(String(itemCode));
        });
    }

    function posServerSearchForMenu(q) {
        q = String(q || '').trim();
        if (!q) {
            _serverSearchKey = '';
            _serverSearchRows = null;
            return Promise.resolve(null);
        }
        if (_serverSearchKey === q && _serverSearchRows) {
            return Promise.resolve(_serverSearchRows);
        }
        if (_serverSearchInflight && _serverSearchInflight._q === q) {
            return _serverSearchInflight;
        }
        var lim = (typeof window.posMaxPosMenuProducts === 'function') ? Math.max(window.posMaxPosMenuProducts() * 2, 80) : 80;
        var inflight = posFetchProductSearch(q, lim, 0).then(function (data) {
            _serverSearchInflight = null;
            if (!data || data.status !== 'ok' || !Array.isArray(data.rows)) return null;
            posUpsertProducts(data.rows);
            _serverSearchKey = q;
            _serverSearchRows = data.rows;
            return data.rows;
        }).catch(function () {
            _serverSearchInflight = null;
            return null;
        });
        inflight._q = q;
        _serverSearchInflight = inflight;
        return inflight;
    }

    function posGetServerMenuSearchRows() {
        return _serverSearchRows;
    }

    function posClearServerMenuSearch() {
        _serverSearchKey = '';
        _serverSearchRows = null;
    }

    var _whServerSearchKey = '';
    var _whServerSearchInflight = null;

    function posWarehouseNeedsServerSearch(q) {
        q = String(q || '').trim();
        if (!q || q.length < 2) return false;
        return true;
    }

    function posClearWarehouseServerSearch() {
        _whServerSearchKey = '';
        _whServerSearchInflight = null;
    }

    function posWarehouseServerSearch(q) {
        q = String(q || '').trim();
        if (!q) return Promise.resolve(null);
        if (_whServerSearchKey === q) return Promise.resolve(null);
        if (_whServerSearchInflight && _whServerSearchInflight._q === q) {
            return _whServerSearchInflight;
        }
        var isBarcode = /^\d{3,}$/.test(q.replace(/\s/g, ''));
        var inflight;
        if (isBarcode) {
            inflight = posLookupProductByBarcode(q).then(function (p) {
                if (p) return [p];
                return posFetchProductSearchAll(q, 200, 8000).then(function (data) {
                    if (!data || !Array.isArray(data.rows)) return [];
                    return data.rows;
                });
            });
        } else {
            inflight = posFetchProductSearchAll(q, 200, 8000).then(function (data) {
                if (!data || !Array.isArray(data.rows)) return [];
                return data.rows;
            });
        }
        inflight = inflight.then(function (rows) {
            _whServerSearchInflight = null;
            _whServerSearchKey = q;
            return rows;
        }).catch(function () {
            _whServerSearchInflight = null;
            return null;
        });
        inflight._q = q;
        _whServerSearchInflight = inflight;
        return inflight;
    }

    function scheduleCatalogBackgroundLoad() {
        if (window.__posCatalogTier === 'full') return;
        if (!posIsCatalogPartial()) return;
        if (window.__posCatalogBgLoading) return;
        if (posCatalogBackgroundPaused()) {
            setTimeout(scheduleCatalogBackgroundLoad, 4000);
            return;
        }
        window.__posCatalogBgLoading = true;

        var loadNext = function () {
            if (posCatalogBackgroundPaused()) {
                window.__posCatalogBgLoading = false;
                setTimeout(scheduleCatalogBackgroundLoad, 3000);
                return;
            }
            posReconcileCatalogPartial();
            if (!posIsCatalogPartial()) {
                window.__posCatalogBgLoading = false;
                posScheduleWarehouseRefreshIfActive();
                return;
            }
            var total = posCatalogTotal();
            var loaded = posCatalogLoadedCount();
            var pageLimit = window.__posCatalogWarehousePriority ? 250 : 180;
            // Always walk id DESC from top (or resume cursor) so mid-range SKUs are never skipped.
            var beforeId = parseInt(window.db && window.db._catalog_before_id, 10) || 0;
            if (!(beforeId > 0)) beforeId = 2147483647;
            posFetchProductPage(0, pageLimit, { beforeId: beforeId }).then(function (data) {
                if (!data || data.status !== 'ok' || !Array.isArray(data.rows)) {
                    window.__posCatalogBgLoading = false;
                    setTimeout(scheduleCatalogBackgroundLoad, 2500);
                    return;
                }
                posSyncCatalogTotalFromResponse(data);
                var added = 0;
                var minRowId = 0;
                if (data.rows.length) {
                    added = posUpsertProducts(data.rows);
                    for (var ri = 0; ri < data.rows.length; ri++) {
                        var rid = parseInt(data.rows[ri] && data.rows[ri].id, 10) || 0;
                        if (rid > 0 && (minRowId === 0 || rid < minRowId)) minRowId = rid;
                    }
                    if (minRowId > 0) window.db._catalog_before_id = minRowId;
                    posAdvanceCatalogServerOffset(data.rows.length);
                    window.__posCatalogBgRetries = 0;
                }
                loaded = posCatalogLoadedCount();
                total = posCatalogTotal();
                posReconcileCatalogPartial();
                if (!posIsCatalogPartial()) {
                    window.__posCatalogBgLoading = false;
                    posScheduleWarehouseRefreshIfActive();
                    return;
                }
                // End of id walk with gap remaining → restart from top and gap-fill until complete.
                if (!data.has_more || !data.rows.length || (data.rows.length && added === 0 && !data.has_more)) {
                    window.__posCatalogBgRetries = (window.__posCatalogBgRetries || 0) + 1;
                    if (loaded < total) {
                        window.db._catalog_before_id = 2147483647;
                        if (window.__posCatalogBgRetries <= 12) {
                            posCatalogGapFill(loaded, total).then(function (got) {
                                loaded = posCatalogLoadedCount();
                                total = posCatalogTotal();
                                if (loaded < total && (got === 0 || window.__posCatalogBgRetries >= 6)) {
                                    if (posCatalogAcceptNearComplete(loaded, total)) {
                                        window.__posCatalogBgLoading = false;
                                        posScheduleWarehouseRefreshIfActive();
                                        return;
                                    }
                                }
                                setTimeout(loadNext, window.__posCatalogWarehousePriority ? 80 : 200);
                            });
                            return;
                        }
                        if (posCatalogAcceptNearComplete(loaded, total)) {
                            window.__posCatalogBgLoading = false;
                            posScheduleWarehouseRefreshIfActive();
                            return;
                        }
                    }
                    window.__posCatalogBgLoading = false;
                    if (loaded < total) {
                        setTimeout(scheduleCatalogBackgroundLoad, 3000);
                    }
                    return;
                }
                var vwh = document.getElementById('view-warehouse');
                var whActive = !!(vwh && vwh.classList.contains('active')) || window.__posCatalogWarehousePriority;
                // Near-complete: pull remaining ASAP (no long delay)
                var gapLeft = Math.max(0, total - loaded);
                var delay = gapLeft <= 80 ? 40 : (whActive ? 80 : ((typeof window.posStartupDeferMs === 'function') ? window.posStartupDeferMs(400) : 500));
                setTimeout(loadNext, delay);
            }).catch(function () {
                window.__posCatalogBgLoading = false;
                setTimeout(scheduleCatalogBackgroundLoad, 3000);
            });
        };

        var startDelay = (typeof window.posStartupDeferMs === 'function') ? window.posStartupDeferMs(1200) : 1500;
        if (window.__posCatalogWarehousePriority) startDelay = Math.min(startDelay, 400);
        setTimeout(loadNext, startDelay);
    }

    function posCatalogGapFill(loaded, total) {
        var need = Math.max(0, (parseInt(total, 10) || 0) - (parseInt(loaded, 10) || 0));
        if (need <= 0) return Promise.resolve(0);
        var beforeId = window.db && window.db._catalog_before_id > 0
            ? window.db._catalog_before_id
            : (posCatalogMaxLoadedId() + 1 || 2147483647);
        var limit = Math.min(250, Math.max(need + 20, 80));
        return posFetchProductPage(0, limit, { beforeId: beforeId }).then(function (data) {
            if (!data || data.status !== 'ok' || !Array.isArray(data.rows)) {
                // Fallback: classic offset page from current loaded count
                return posFetchProductPage(posCatalogLoadedCount(), limit).then(function (data2) {
                    if (!data2 || data2.status !== 'ok' || !Array.isArray(data2.rows) || !data2.rows.length) return 0;
                    posSyncCatalogTotalFromResponse(data2);
                    posUpsertProducts(data2.rows);
                    posAdvanceCatalogServerOffset(data2.rows.length);
                    posReconcileCatalogPartial();
                    return data2.rows.length;
                });
            }
            posSyncCatalogTotalFromResponse(data);
            if (data.rows.length) {
                posUpsertProducts(data.rows);
                var minRowId = 0;
                for (var i = 0; i < data.rows.length; i++) {
                    var id = parseInt(data.rows[i] && data.rows[i].id, 10) || 0;
                    if (id > 0 && (minRowId === 0 || id < minRowId)) minRowId = id;
                }
                if (minRowId > 0 && window.db) window.db._catalog_before_id = minRowId;
                posAdvanceCatalogServerOffset(data.rows.length);
            } else if (window.db) {
                window.db._catalog_before_id = 2147483647;
            }
            posReconcileCatalogPartial();
            return data.rows.length;
        }).catch(function () { return 0; });
    }

    function posPrioritizeCatalogLoadForWarehouse() {
        window.__posCatalogWarehousePriority = true;
        if (posIsCatalogPartial()) scheduleCatalogBackgroundLoad();
    }

    function posFetchWarehouseStats() {
        if (window._wmsServerStatsInflight) return window._wmsServerStatsInflight;
        var p = fetch('?action=warehouse_stats&t=' + Date.now(), { credentials: 'same-origin' })
            .then(function (r) { return r.json().catch(function () { return null; }); })
            .then(function (data) {
                window._wmsServerStatsInflight = null;
                if (data && data.status === 'ok') {
                    window._wmsServerStats = data;
                    posSyncCatalogTotalFromResponse(data);
                }
                return data;
            })
            .catch(function () {
                window._wmsServerStatsInflight = null;
                return null;
            });
        window._wmsServerStatsInflight = p;
        return p;
    }

    function posEnsureFullCatalogLoaded() {
        if (!posIsCatalogPartial()) return Promise.resolve(window.db);
        if (window.__posCatalogFullPromise) return window.__posCatalogFullPromise;
        window.__posCatalogFullPromise = new Promise(function (resolve) {
            var tryDone = function () {
                posReconcileCatalogPartial();
                if (!posIsCatalogPartial()) {
                    window.__posCatalogFullPromise = null;
                    window.__posCatalogWarehousePriority = false;
                    resolve(window.db);
                    return true;
                }
                return false;
            };
            if (tryDone()) return;
            posPrioritizeCatalogLoadForWarehouse();
            // Small remaining gap: force gap-fill immediately then accept near-complete
            var loaded0 = posCatalogLoadedCount();
            var total0 = posCatalogTotal();
            var gap0 = Math.max(0, total0 - loaded0);
            var kick = (gap0 > 0 && gap0 <= 100)
                ? posCatalogGapFill(loaded0, total0)
                : Promise.resolve(0);
            kick.then(function () {
                if (tryDone()) return;
                var loaded1 = posCatalogLoadedCount();
                var total1 = posCatalogTotal();
                if (loaded1 < total1 && (total1 - loaded1) <= 25) {
                    posCatalogAcceptNearComplete(loaded1, total1);
                    if (tryDone()) return;
                }
                scheduleCatalogBackgroundLoad();
                var attempts = 0;
                var poll = function () {
                    if (tryDone()) return;
                    attempts++;
                    if (attempts > 80) {
                        var L = posCatalogLoadedCount();
                        var T = posCatalogTotal();
                        if (L < T && (T - L) <= 25) posCatalogAcceptNearComplete(L, T);
                        window.__posCatalogFullPromise = null;
                        resolve(window.db);
                        posScheduleWarehouseRefreshIfActive();
                        return;
                    }
                    if (attempts % 8 === 0 && posIsCatalogPartial()) {
                        scheduleCatalogBackgroundLoad();
                    }
                    setTimeout(poll, 250);
                };
                setTimeout(poll, 120);
            });
        });
        return window.__posCatalogFullPromise;
    }

    /* --- Phase 2: customers / companies partial bootstrap --- */

    function posCustomersTotal() {
        if (!window.db) return 0;
        var h = window.db._db_health || {};
        var n = parseInt(h.customers_count, 10);
        if (Number.isFinite(n) && n > 0) return n;
        if (window.db._customers_total != null) return parseInt(window.db._customers_total, 10) || 0;
        return Array.isArray(window.db.customers) ? window.db.customers.length : 0;
    }

    function posCompaniesTotal() {
        if (!window.db) return 0;
        var h = window.db._db_health || {};
        var n = parseInt(h.companies_count, 10);
        if (Number.isFinite(n) && n > 0) return n;
        if (window.db._companies_total != null) return parseInt(window.db._companies_total, 10) || 0;
        return Array.isArray(window.db.companies) ? window.db.companies.length : 0;
    }

    function posIsCustomersPartial() {
        if (!window.db) return false;
        if (window.db._customers_partial === true) return true;
        var total = posCustomersTotal();
        var loaded = Array.isArray(window.db.customers) ? window.db.customers.length : 0;
        return total > 0 && loaded > 0 && loaded < total;
    }

    function posIsCompaniesPartial() {
        if (!window.db) return false;
        if (window.db._companies_partial === true) return true;
        var total = posCompaniesTotal();
        var loaded = Array.isArray(window.db.companies) ? window.db.companies.length : 0;
        return total > 0 && loaded > 0 && loaded < total;
    }

    function posMarkEntitiesMeta(data) {
        if (!window.db || !data) return;
        if (data.customers_partial === true) {
            window.db._customers_partial = true;
            if (data.customers_total != null) window.db._customers_total = parseInt(data.customers_total, 10) || 0;
            if (data.customers_loaded != null) {
                window.db._customers_loaded = parseInt(data.customers_loaded, 10) || 0;
                window.db._customers_server_offset = window.db._customers_loaded;
            }
        } else if (Array.isArray(data.customers) && data.customers.length > 0) {
            var ct = posCustomersTotal();
            if (!ct || data.customers.length >= ct) {
                window.db._customers_partial = false;
                window.db._customers_total = data.customers.length;
                window.db._customers_loaded = data.customers.length;
                window.db._customers_server_offset = data.customers.length;
            }
        }
        if (data.companies_partial === true) {
            window.db._companies_partial = true;
            if (data.companies_total != null) window.db._companies_total = parseInt(data.companies_total, 10) || 0;
            if (data.companies_loaded != null) {
                window.db._companies_loaded = parseInt(data.companies_loaded, 10) || 0;
                window.db._companies_server_offset = window.db._companies_loaded;
            }
        } else if (Array.isArray(data.companies) && data.companies.length > 0) {
            var coc = posCompaniesTotal();
            if (!coc || data.companies.length >= coc) {
                window.db._companies_partial = false;
                window.db._companies_total = data.companies.length;
                window.db._companies_loaded = data.companies.length;
                window.db._companies_server_offset = data.companies.length;
            }
        }
    }

    function posDedupeCustomersInPlace() {
        if (!window.db || !Array.isArray(window.db.customers)) return 0;
        var byId = Object.create(null);
        window.db.customers.forEach(function (c) {
            if (!c || c.id == null) return;
            if (c.is_active != null && Number(c.is_active) === 0) return;
            var k = String(parseInt(c.id, 10) || c.id);
            if (!byId[k]) {
                byId[k] = c;
                byId[k].id = parseInt(c.id, 10) || c.id;
                return;
            }
            var prev = byId[k];
            var next = Object.assign({}, prev, c);
            if (!next.name && prev.name) next.name = prev.name;
            if ((next.phone == null || next.phone === '') && prev.phone) next.phone = prev.phone;
            next.id = parseInt(prev.id, 10) || prev.id;
            byId[k] = next;
        });
        var before = window.db.customers.length;
        window.db.customers = Object.keys(byId).map(function (k) { return byId[k]; });
        return before - window.db.customers.length;
    }

    function posUpsertCustomers(rows) {
        if (!window.db || !Array.isArray(rows) || !rows.length) return 0;
        if (!Array.isArray(window.db.customers)) window.db.customers = [];
        posDedupeCustomersInPlace();
        var byId = Object.create(null);
        window.db.customers.forEach(function (c) {
            if (c && c.id != null && (c.is_active == null || Number(c.is_active) !== 0)) {
                byId[String(parseInt(c.id, 10) || c.id)] = c;
            }
        });
        var added = 0;
        rows.forEach(function (r) {
            if (!r || r.id == null) return;
            var k = String(parseInt(r.id, 10) || r.id);
            r.id = parseInt(r.id, 10) || r.id;
            if (r.is_active != null && Number(r.is_active) === 0) {
                delete byId[k];
                return;
            }
            if (!byId[k]) added++;
            var prev = byId[k] || {};
            var next = Object.assign({}, prev, r);
            if (!next.name && prev.name) next.name = prev.name;
            if ((next.phone == null || next.phone === '') && prev.phone) next.phone = prev.phone;
            if ((next.address == null || next.address === '') && prev.address) next.address = prev.address;
            if (next.opening_balance == null && prev.opening_balance != null) next.opening_balance = prev.opening_balance;
            if (next.debt_limit == null && prev.debt_limit != null) next.debt_limit = prev.debt_limit;
            next.id = parseInt(next.id, 10) || next.id;
            byId[k] = next;
        });
        window.db.customers = Object.keys(byId).map(function (k) { return byId[k]; });
        var total = posCustomersTotal();
        window.db._customers_loaded = window.db.customers.length;
        if (total > 0 && window.db.customers.length >= total) window.db._customers_partial = false;
        if (typeof window.refreshEntityDatalists === 'function') window.refreshEntityDatalists();
        return added;
    }

    function posUpsertCompanies(rows) {
        if (!window.db || !Array.isArray(rows) || !rows.length) return 0;
        if (!Array.isArray(window.db.companies)) window.db.companies = [];
        var byId = Object.create(null);
        window.db.companies.forEach(function (c) {
            if (c && c.id != null && (c.is_active == null || Number(c.is_active) !== 0)) {
                byId[String(c.id)] = c;
            }
        });
        var added = 0;
        rows.forEach(function (r) {
            if (!r || r.id == null) return;
            var k = String(r.id);
            if (r.is_active != null && Number(r.is_active) === 0) {
                delete byId[k];
                return;
            }
            if (!byId[k]) added++;
            var prev = byId[k] || {};
            var next = Object.assign({}, prev, r);
            if (!next.name && prev.name) next.name = prev.name;
            if ((next.phone == null || next.phone === '') && prev.phone) next.phone = prev.phone;
            if ((next.address == null || next.address === '') && prev.address) next.address = prev.address;
            if (next.opening_balance == null && prev.opening_balance != null) next.opening_balance = prev.opening_balance;
            if (next.debt_limit == null && prev.debt_limit != null) next.debt_limit = prev.debt_limit;
            byId[k] = next;
        });
        window.db.companies = Object.keys(byId).map(function (k) { return byId[k]; });
        var total = posCompaniesTotal();
        window.db._companies_loaded = window.db.companies.length;
        if (total > 0 && window.db.companies.length >= total) window.db._companies_partial = false;
        if (typeof window.refreshEntityDatalists === 'function') window.refreshEntityDatalists();
        return added;
    }

    function posFetchEntityPage(entityType, offset, limit) {
        if (typeof window.posFetchEntitySearch !== 'function') {
            return Promise.resolve({ status: 'error' });
        }
        return posCatalogFetchRun(function () {
            return window.posFetchEntitySearch(entityType, '', limit || 80, offset || 0);
        });
    }

    function posEnsureCustomerById(id) {
        id = parseInt(id, 10);
        if (!id || !window.db) return Promise.resolve(null);
        var found = (window.db.customers || []).find(function (c) { return c && parseInt(c.id, 10) === id; });
        if (found) return Promise.resolve(found);
        if (typeof window.posFetchEntitySearch !== 'function') return Promise.resolve(null);
        return posCatalogFetchRun(function () {
            return window.posFetchEntitySearch('customers', String(id), 8, 0);
        }).then(function (res) {
            if (!res || res.status !== 'ok' || !Array.isArray(res.rows) || !res.rows.length) return null;
            posUpsertCustomers(res.rows);
            return (window.db.customers || []).find(function (c) { return c && parseInt(c.id, 10) === id; }) || res.rows[0];
        });
    }

    function posEnsureCompanyById(id) {
        id = parseInt(id, 10);
        if (!id || !window.db) return Promise.resolve(null);
        var found = (window.db.companies || []).find(function (c) { return c && parseInt(c.id, 10) === id; });
        if (found) return Promise.resolve(found);
        if (typeof window.posFetchEntitySearch !== 'function') return Promise.resolve(null);
        return posCatalogFetchRun(function () {
            return window.posFetchEntitySearch('companies', String(id), 8, 0);
        }).then(function (res) {
            if (!res || res.status !== 'ok' || !Array.isArray(res.rows) || !res.rows.length) return null;
            posUpsertCompanies(res.rows);
            return (window.db.companies || []).find(function (c) { return c && parseInt(c.id, 10) === id; }) || res.rows[0];
        });
    }

    function scheduleEntitiesBackgroundLoad() {
        if (!posIsCustomersPartial() && !posIsCompaniesPartial()) return;
        if (window.__posEntitiesBgLoading) return;
        if (window._posScanQueueBusy) {
            setTimeout(scheduleEntitiesBackgroundLoad, 4000);
            return;
        }
        window.__posEntitiesBgLoading = true;

        var step = function () {
            if (window._posScanQueueBusy) {
                window.__posEntitiesBgLoading = false;
                setTimeout(scheduleEntitiesBackgroundLoad, 3000);
                return;
            }
            var didWork = false;
            var chain = Promise.resolve();

            if (posIsCustomersPartial()) {
                var cOff = window.db._customers_server_offset != null
                    ? parseInt(window.db._customers_server_offset, 10) || 0
                    : (window.db._customers_loaded || 0);
                var cTotal = posCustomersTotal();
                if (cTotal > 0 && cOff < cTotal) {
                    didWork = true;
                    chain = chain.then(function () {
                        return posFetchEntityPage('customers', cOff, 80).then(function (res) {
                            if (!res || res.status !== 'ok' || !Array.isArray(res.rows)) return;
                            if (res.rows.length) {
                                posUpsertCustomers(res.rows);
                                window.db._customers_server_offset = cOff + res.rows.length;
                            }
                            if (!res.has_more || !res.rows.length) window.db._customers_partial = false;
                        });
                    });
                } else {
                    window.db._customers_partial = false;
                }
            }

            if (posIsCompaniesPartial()) {
                var coOff = window.db._companies_server_offset != null
                    ? parseInt(window.db._companies_server_offset, 10) || 0
                    : (window.db._companies_loaded || 0);
                var coTotal = posCompaniesTotal();
                if (coTotal > 0 && coOff < coTotal) {
                    didWork = true;
                    chain = chain.then(function () {
                        return posFetchEntityPage('companies', coOff, 60).then(function (res) {
                            if (!res || res.status !== 'ok' || !Array.isArray(res.rows)) return;
                            if (res.rows.length) {
                                posUpsertCompanies(res.rows);
                                window.db._companies_server_offset = coOff + res.rows.length;
                            }
                            if (!res.has_more || !res.rows.length) window.db._companies_partial = false;
                        });
                    });
                } else {
                    window.db._companies_partial = false;
                }
            }

            chain.then(function () {
                if (!posIsCustomersPartial() && !posIsCompaniesPartial()) {
                    window.__posEntitiesBgLoading = false;
                    return;
                }
                if (!didWork) {
                    window.__posEntitiesBgLoading = false;
                    return;
                }
                var delay = (typeof window.posStartupDeferMs === 'function') ? window.posStartupDeferMs(1200) : 1500;
                setTimeout(step, delay);
            }).catch(function () {
                window.__posEntitiesBgLoading = false;
            });
        };

        var startDelay = (typeof window.posStartupDeferMs === 'function') ? window.posStartupDeferMs(4000) : 5000;
        setTimeout(step, startDelay);
    }

    window.posIsCatalogPartial = posIsCatalogPartial;
    window.posCatalogLoadedCount = posCatalogLoadedCount;
    window.posReconcileCatalogPartial = posReconcileCatalogPartial;
    window.posSyncCatalogTotalFromResponse = posSyncCatalogTotalFromResponse;
    window.posCatalogGapFill = posCatalogGapFill;
    window.posPrioritizeCatalogLoadForWarehouse = posPrioritizeCatalogLoadForWarehouse;
    window.posFetchWarehouseStats = posFetchWarehouseStats;
    window.posMarkCatalogMeta = posMarkCatalogMeta;
    window.posCatalogServerOffset = posCatalogServerOffset;
    window.posAdvanceCatalogServerOffset = posAdvanceCatalogServerOffset;
    window.posBarcodeNeedsServerLookup = posBarcodeNeedsServerLookup;
    window.posUpsertProducts = posUpsertProducts;
    window.posPatchLocalProduct = posPatchLocalProduct;
    window.posFetchProductSearch = posFetchProductSearch;
    window.posFetchProductSearchAll = posFetchProductSearchAll;
    window.posFetchProductPage = posFetchProductPage;
    window.posLookupProductByBarcode = posLookupProductByBarcode;
    window.posEnsureProductByBarcode = posEnsureProductByBarcode;
    window.posEnsureScalePluProduct = posEnsureScalePluProduct;
    window.posServerSearchForMenu = posServerSearchForMenu;
    window.posGetServerMenuSearchRows = posGetServerMenuSearchRows;
    window.posClearServerMenuSearch = posClearServerMenuSearch;
    window.posCatalogTotal = posCatalogTotal;
    window.posWarehouseNeedsServerSearch = posWarehouseNeedsServerSearch;
    window.posWarehouseServerSearch = posWarehouseServerSearch;
    window.posClearWarehouseServerSearch = posClearWarehouseServerSearch;
    window.posReactivateProduct = posReactivateProduct;
    window.posOfferReactivateInactiveProducts = posOfferReactivateInactiveProducts;
    window.scheduleCatalogBackgroundLoad = scheduleCatalogBackgroundLoad;
    window.posEnsureFullCatalogLoaded = posEnsureFullCatalogLoaded;
    window.posPauseCatalogBackground = posPauseCatalogBackground;
    window.posResumeCatalogBackgroundLoad = posResumeCatalogBackgroundLoad;
    window.posCatalogFetchRun = posCatalogFetchRun;
    window.posGetProductById = function (id) {
        if (id == null || id === '') return null;
        var list = (window.db && Array.isArray(window.db.products)) ? window.db.products : [];
        var cache = window._posProductById;
        if (!cache || cache._len !== list.length) {
            cache = Object.create(null);
            for (var i = 0; i < list.length; i++) {
                var p = list[i];
                if (p && p.id != null) cache[String(p.id)] = p;
            }
            cache._len = list.length;
            window._posProductById = cache;
        }
        return cache[String(id)] || null;
    };
    window.posIsCustomersPartial = posIsCustomersPartial;
    window.posIsCompaniesPartial = posIsCompaniesPartial;
    window.posMarkEntitiesMeta = posMarkEntitiesMeta;
    window.posDedupeCustomersInPlace = posDedupeCustomersInPlace;
    window.posUpsertCustomers = posUpsertCustomers;
    window.posUpsertCompanies = posUpsertCompanies;
    window.posEnsureCustomerById = posEnsureCustomerById;
    window.posEnsureCompanyById = posEnsureCompanyById;
    window.scheduleEntitiesBackgroundLoad = scheduleEntitiesBackgroundLoad;
})();
