/* eslint-disable no-restricted-globals */
/** Filter POS product menu in background thread (large catalogs). */
(function () {
    'use strict';

    function norm(s) {
        return String(s || '').toLowerCase().trim();
    }

    function normDigits(s) {
        var t = norm(s);
        t = t.replace(/[٠-٩]/g, function (d) { return String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)); });
        return t.replace(/[\u06f0-\u06f9\u0660-\u0669]/g, function (ch) {
            var c = ch.charCodeAt(0);
            if (c >= 0x06f0 && c <= 0x06f9) return String(c - 0x06f0);
            if (c >= 0x0660 && c <= 0x0669) return String(c - 0x0660);
            return ch;
        });
    }

    function haystack(raw, term) {
        var str = String(raw || '');
        if (!str.trim()) return false;
        if (normDigits(str).indexOf(term) >= 0) return true;
        var parts = str.split(',');
        for (var i = 0; i < parts.length; i++) {
            var seg = normDigits(parts[i]);
            if (seg && (seg === term || seg.indexOf(term) >= 0)) return true;
        }
        return false;
    }

    function matchesSearch(e, q) {
        var rawTerm = String(q || '').trim();
        if (!rawTerm) return true;
        var t = normDigits(rawTerm);
        var tl = rawTerm.toLowerCase();
        if (e.lowerName && e.lowerName.indexOf(tl) >= 0) return true;
        if (e.normName && e.normName.indexOf(norm(rawTerm)) >= 0) return true;
        if (e.lowerBarcode && haystack(e.lowerBarcode, t)) return true;
        if (e.lowerSku && (e.lowerSku.indexOf(tl) >= 0 || (e.normSku && e.normSku.indexOf(norm(rawTerm)) >= 0))) return true;
        if (String(e.id).indexOf(t) >= 0) return true;
        return false;
    }

    function matchesCategory(e, category) {
        if (!category || category === 'all') return true;
        return e.cat === category;
    }

    function matchesUnit(e, unit) {
        if (!unit || unit === 'piece') return true;
        if (unit === 'pack') return e.packOk !== false;
        if (unit === 'carton') return e.cartonOk !== false;
        return true;
    }

    self.onmessage = function (ev) {
        var d = ev.data || {};
        var entries = d.entries || [];
        var q = d.q || '';
        var category = d.category || 'all';
        var unit = d.unit || 'piece';
        var ids = [];
        for (var i = 0; i < entries.length; i++) {
            var e = entries[i];
            if (!e || e.id == null || !e.forSale) continue;
            var searching = String(q || '').trim().length > 0;
            if (searching) {
                if (matchesSearch(e, q)) ids.push(e.id);
                continue;
            }
            if (!matchesCategory(e, category)) continue;
            if (!matchesUnit(e, unit)) continue;
            ids.push(e.id);
        }
        self.postMessage({ reqId: d.reqId, ids: ids });
    };
})();
