<?php
$act = trim((string)($_POST['action'] ?? $_GET['action'] ?? ''));
if ($act !== '') {

    header('Content-Type: application/json; charset=utf-8');
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }
    require_once __DIR__ . '/all-actions-auth.php';
    require_once __DIR__ . '/all-actions-import.php';
    require_once __DIR__ . '/all-actions-sales.php';
    require_once __DIR__ . '/all-actions-purchase.php';
    require_once __DIR__ . '/all-actions-catalog.php';
    require_once __DIR__ . '/all-actions-debt.php';
    require_once __DIR__ . '/all-actions-restore.php';
    require_once __DIR__ . '/all-actions-update.php';
    require_once __DIR__ . '/all-actions-tail.php';
}
