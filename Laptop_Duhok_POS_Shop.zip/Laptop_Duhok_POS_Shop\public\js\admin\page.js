import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.49.4';

const SUPABASE_URL = 'https://aqykjjitfyxiqwzmyewr.supabase.co';
const SUPABASE_ANON_KEY =
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFxeWtqaml0Znl4aXF3em15ZXdyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU3Mzk1ODUsImV4cCI6MjA5MTMxNTU4NX0.ppd7Nyj5kb5jxdhXglkoqJjdIl3P0QQx70PAI94R8X8';

function showConfigWarning(text) {
    const el = document.getElementById('config-msg');
    el.className = 'msg warn';
    el.style.display = 'block';
    el.textContent = text;
}

if (!SUPABASE_ANON_KEY) {
    showConfigWarning('تکایە لە `admin.html` نێریت SUPABASE_ANON_KEY (Publishable یان anon) لە Supabase → Settings → API Keys.');
}

const supabase = SUPABASE_ANON_KEY
    ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
        auth: { persistSession: true, autoRefreshToken: true }
      })
    : null;

let licensesChannel = null;

function escapeHtml(s) {
    const d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML;
}

function nullIfEmpty(v) {
    const t = typeof v === 'string' ? v.trim() : v;
    return t === '' || t == null ? null : t;
}

function buildMetaPreview(row) {
    const parts = [];
    if (row.person_name) parts.push('ناو: ' + row.person_name);
    if (row.phone) parts.push('تەلەفۆن: ' + row.phone);
    if (row.location) parts.push('شوێن: ' + row.location);
    if (row.contact_email) parts.push('ئیمێل: ' + row.contact_email);
    if (row.telegram_id) parts.push('TG ID: ' + row.telegram_id);
    if (row.telegram_bot) parts.push('بۆت: ' + row.telegram_bot);
    if (row.map_url) parts.push('نەخشە: ✓');
    if (row.note) parts.push('تێبینی: ✓');
    if (row.contact_password) parts.push('وشە نهێنی: •••');
    if (!parts.length) return '—';
    return parts.join(' · ');
}

async function loadLicenses() {
    const listBody = document.getElementById('licenses-list');
    if (!supabase) {
        listBody.innerHTML = '<tr><td colspan="6" style="text-align: center;">تەنزیمات تەواو نینە.</td></tr>';
        return;
    }
    const { data, error } = await supabase
        .from('licenses')
        .select(
            'serial,status,security_code,internal_tick,person_name,phone,location,map_url,telegram_bot,telegram_id,contact_email,contact_password,note'
        )
        .order('serial', { ascending: true });

    if (error) {
        listBody.innerHTML = '<tr><td colspan="6" style="text-align: center;">هەڵە: ' + escapeHtml(error.message) + '</td></tr>';
        return;
    }

    listBody.innerHTML = '';
    if (data && data.length) {
        data.forEach(function (row) {
            const serial = row.serial;
            const status = row.status;
            const statusClass = status === 'active' ? 'status-active' : 'status-blocked';
            const statusLabel = status === 'active' ? 'Active' : 'Blocked';
            const tr = document.createElement('tr');
            const tickOn = !!row.internal_tick;
            const tdTick = document.createElement('td');
            tdTick.className = 'td-tick';
            const tickBtn = document.createElement('button');
            tickBtn.type = 'button';
            tickBtn.className = 'tick-toggle' + (tickOn ? ' on' : '');
            tickBtn.textContent = tickOn ? '✓' : '';
            tickBtn.setAttribute('aria-pressed', tickOn ? 'true' : 'false');
            tickBtn.setAttribute('aria-label', 'تەواو');
            tickBtn.title = 'تۆماری ناوخۆ';
            tickBtn.addEventListener('click', async function () {
                if (!supabase || tickBtn.disabled) return;
                tickBtn.disabled = true;
                const next = !tickOn;
                const msgBox = document.getElementById('action-msg');
                const { error } = await supabase
                    .from('licenses')
                    .update({ internal_tick: next, updated_at: new Date().toISOString() })
                    .eq('serial', serial);
                tickBtn.disabled = false;
                if (error) {
                    msgBox.className = 'msg error';
                    msgBox.style.display = 'block';
                    msgBox.textContent = 'هەڵە: ' + error.message;
                } else {
                    msgBox.style.display = 'none';
                    loadLicenses();
                }
            });
            tdTick.appendChild(tickBtn);
            const tdSn = document.createElement('td');
            tdSn.style.fontFamily = "'Rudaw', sans-serif";
            tdSn.style.letterSpacing = '1px';
            tdSn.textContent = serial;
            const tdSec = document.createElement('td');
            tdSec.style.fontFamily = "'Rudaw', sans-serif";
            tdSec.style.textAlign = 'center';
            tdSec.style.letterSpacing = '0.12em';
            tdSec.style.color = '#fde68a';
            tdSec.textContent = row.security_code ? String(row.security_code) : '—';
            const tdMeta = document.createElement('td');
            tdMeta.className = 'meta-preview';
            tdMeta.textContent = buildMetaPreview(row);
            const tdSt = document.createElement('td');
            const span = document.createElement('span');
            span.className = statusClass;
            span.textContent = statusLabel;
            tdSt.appendChild(span);
            const tdAct = document.createElement('td');
            const editBtn = document.createElement('button');
            editBtn.type = 'button';
            editBtn.className = 'btn-small';
            editBtn.textContent = 'دەستکاری';
            editBtn.addEventListener('click', function () {
                document.getElementById('serial-input').value = serial || '';
                var secInput = document.getElementById('security-code-input');
                if (secInput) secInput.value = row.security_code || '';
                document.getElementById('person-name-input').value = row.person_name || '';
                document.getElementById('phone-input').value = row.phone || '';
                document.getElementById('location-input').value = row.location || '';
                document.getElementById('map-url-input').value = row.map_url || '';
                document.getElementById('telegram-bot-input').value = row.telegram_bot || '';
                document.getElementById('telegram-id-input').value = row.telegram_id || '';
                document.getElementById('contact-email-input').value = row.contact_email || '';
                document.getElementById('contact-password-input').value = row.contact_password || '';
                document.getElementById('note-input').value = row.note || '';
                document.getElementById('internal-tick-input').checked = !!row.internal_tick;
                document.getElementById('status-input').value = status || 'active';
                window.scrollTo(0, 0);
            });
            tdAct.appendChild(editBtn);
            tr.appendChild(tdTick);
            tr.appendChild(tdSn);
            tr.appendChild(tdSec);
            tr.appendChild(tdMeta);
            tr.appendChild(tdSt);
            tr.appendChild(tdAct);
            listBody.appendChild(tr);
        });
    } else {
        listBody.innerHTML = '<tr><td colspan="6" style="text-align: center;">چ دکان نەهاتینە تۆمارکرن.</td></tr>';
    }
}

function subscribeLicensesRealtime() {
    if (!supabase || licensesChannel) return;
    licensesChannel = supabase
        .channel('licenses-admin')
        .on(
            'postgres_changes',
            { event: '*', schema: 'public', table: 'licenses' },
            function () {
                loadLicenses();
            }
        )
        .subscribe();
}

function unsubscribeLicensesRealtime() {
    if (supabase && licensesChannel) {
        supabase.removeChannel(licensesChannel);
        licensesChannel = null;
    }
}

supabase.auth.onAuthStateChange(function (_event, session) {
    if (session) {
        document.getElementById('login-section').style.display = 'none';
        document.getElementById('dashboard-section').style.display = 'block';
        loadLicenses();
        subscribeLicensesRealtime();
    } else {
        unsubscribeLicensesRealtime();
        document.getElementById('login-section').style.display = 'block';
        document.getElementById('dashboard-section').style.display = 'none';
    }
});

window.login = async function () {
    const msgBox = document.getElementById('login-msg');
    if (!supabase) {
        msgBox.className = 'msg error';
        msgBox.innerHTML = 'Supabase ڕێک نەکراوە (anon key).';
        return;
    }
    const email = document.getElementById('admin-email').value.trim();
    const pass = document.getElementById('admin-password').value;
    if (!email || !pass) {
        msgBox.className = 'msg error';
        msgBox.innerHTML = 'تکایە ئیمێل و پاسوۆرد پڕ بکە!';
        return;
    }
    const { error } = await supabase.auth.signInWithPassword({ email: email, password: pass });
    if (error) {
        msgBox.className = 'msg error';
        msgBox.innerHTML = 'ئیمێل یان پاسوۆرد خەلەتە!';
    } else {
        msgBox.style.display = 'none';
    }
};

window.logout = async function () {
    if (supabase) await supabase.auth.signOut();
};

window.saveLicense = async function () {
    const serial = document.getElementById('serial-input').value.trim();
    const status = document.getElementById('status-input').value;
    const msgBox = document.getElementById('action-msg');
    const btn = document.getElementById('save-btn');

    if (!supabase) {
        msgBox.className = 'msg error';
        msgBox.innerHTML = 'Supabase ڕێک نەکراوە.';
        return;
    }
    if (!serial) {
        msgBox.className = 'msg error';
        msgBox.innerHTML = 'سێریاڵ نەمبەر بنووسە!';
        return;
    }

    btn.disabled = true;
    btn.innerHTML = 'دەهێتە ناردن...';

    const payload = {
        serial: serial,
        status: status,
        updated_at: new Date().toISOString(),
        security_code: nullIfEmpty(document.getElementById('security-code-input') && document.getElementById('security-code-input').value),
        person_name: nullIfEmpty(document.getElementById('person-name-input').value),
        phone: nullIfEmpty(document.getElementById('phone-input').value),
        location: nullIfEmpty(document.getElementById('location-input').value),
        map_url: nullIfEmpty(document.getElementById('map-url-input').value),
        telegram_bot: nullIfEmpty(document.getElementById('telegram-bot-input').value),
        telegram_id: nullIfEmpty(document.getElementById('telegram-id-input').value),
        contact_email: nullIfEmpty(document.getElementById('contact-email-input').value),
        contact_password: nullIfEmpty(document.getElementById('contact-password-input').value),
        note: nullIfEmpty(document.getElementById('note-input').value),
        internal_tick: document.getElementById('internal-tick-input').checked
    };

    const { error } = await supabase.from('licenses').upsert(payload, { onConflict: 'serial' });

    if (error) {
        msgBox.className = 'msg error';
        msgBox.innerHTML = 'هەڵەیەک ڕوویدا: ' + escapeHtml(error.message);
    } else {
        msgBox.className = 'msg success';
        msgBox.innerHTML =
            'سێریاڵ نەمبەر <b>' +
            escapeHtml(serial) +
            '</b> ب سەرکەفتیانە بوو ب ' +
            (status === 'active' ? 'چالاک 🟢' : 'ڕاگیراو 🔴') +
            '!';
        document.getElementById('serial-input').value = '';
        var secClear = document.getElementById('security-code-input');
        if (secClear) secClear.value = '';
        document.getElementById('person-name-input').value = '';
        document.getElementById('phone-input').value = '';
        document.getElementById('location-input').value = '';
        document.getElementById('map-url-input').value = '';
        document.getElementById('telegram-bot-input').value = '';
        document.getElementById('telegram-id-input').value = '';
        document.getElementById('contact-email-input').value = '';
        document.getElementById('contact-password-input').value = '';
        document.getElementById('note-input').value = '';
        document.getElementById('internal-tick-input').checked = false;
        loadLicenses();
    }
    btn.disabled = false;
    btn.innerHTML = 'جێبەجێ بکە';
};
