/**
 * Entry point (ES6 module). Exposes state and module APIs on window so legacy app scripts and HTML onclick handlers work.
 */
import { state } from './modules/state.js';
import { apiJson } from './modules/api.js';
import * as utils from './modules/utils.js';
import * as auth from './modules/auth.js';
import * as ui from './modules/ui.js';
import { posIconHtml, posEnhanceUiIcons, schedulePosEnhanceIcons } from './modules/pos-icons.js';

// Expose state for legacy app scripts (app-core.js, etc.)
window.__state = state;

// Getters/setters so legacy app scripts can use global db, currentUser, etc.
function bindStateProp(name) {
    Object.defineProperty(window, name, {
        get() { return state[name]; },
        set(v) { state[name] = v; },
        configurable: true
    });
}
bindStateProp('db');
bindStateProp('currentUser');
bindStateProp('activeTableId');
bindStateProp('displaySyncTimeout');
bindStateProp('activeCategory');
bindStateProp('fileHandle');
bindStateProp('isFileConnected');
bindStateProp('currentViewingCompanyId');
bindStateProp('selectedSupplyProdId');
bindStateProp('lastTableState');
bindStateProp('saveTimeout');
bindStateProp('recentAddedItems');
bindStateProp('isTableEditMode');
bindStateProp('isReturnMode');
bindStateProp('isSupplyReturnMode');
bindStateProp('currentWhFilter');
bindStateProp('settingsClickCount');
bindStateProp('settingsNavTimer');
bindStateProp('systemModeUnlocked');
bindStateProp('breadcrumbStack');
bindStateProp('currentBreadcrumbIndex');
bindStateProp('lastSyncTime');
bindStateProp('currentDebtParams');
bindStateProp('isProcessingPayment');

// Utils
window.apiJson = apiJson;
window.formatCurrency = utils.formatCurrency;
window.escapeHtml = utils.escapeHtml;
window.getBusinessDate = utils.getBusinessDate;
window.parseSQLDate = utils.parseSQLDate;
window.formatPosDateTime = utils.formatPosDateTime;
window.getPosDateKey = utils.getPosDateKey;
window.getPosTimezoneParts = utils.getPosTimezoneParts;
window.POS_TIMEZONE = utils.POS_TIMEZONE;
window.getBusinessMonth = utils.getBusinessMonth;
window.getUsdRatePerOne = utils.getUsdRatePerOne;
window.getFxRatePerOne = utils.getFxRatePerOne;
window.getDefaultCurrency = utils.getDefaultCurrency;
window.getActiveCurrency = utils.getActiveCurrency;
window.roundIqd = utils.roundIqd;
window.roundUsd = utils.roundUsd;
window.convertCurrency = utils.convertCurrency;
window.usdToIqd = utils.usdToIqd;
window.iqdToUsd = utils.iqdToUsd;
window.storedIqdToUsdAmount = utils.iqdToUsd;
window.formatIqdAmount = utils.formatIqdAmount;
window.formatUsdNumberPlain = utils.formatUsdNumberPlain;
window.formatUsdAmount = utils.formatUsdAmount;
window.formatFxRateDisplay = utils.formatFxRateDisplay;
window.formatDualCurrencyLines = utils.formatDualCurrencyLines;
window.joinDualCurrencyText = utils.joinDualCurrencyText;
window.isShowBothCurrenciesEnabled = utils.isShowBothCurrenciesEnabled;
window.formatCanonicalMoney = utils.formatCanonicalMoney;
window.formatTxnMoney = utils.formatTxnMoney;
window.productStockValueIqd = utils.productStockValueIqd;
window.productStockValueUsd = utils.productStockValueUsd;
window.inventoryItemNativeCurrency = utils.inventoryItemNativeCurrency;
window.inventoryNativeUnitIqd = utils.inventoryNativeUnitIqd;
window.inventoryNativeUnitUsd = utils.inventoryNativeUnitUsd;
window.finalizeInventoryValuationBuckets = utils.finalizeInventoryValuationBuckets;
window.sumInventoryValuationNative = utils.sumInventoryValuationNative;
window.renderInventoryStats = utils.renderInventoryStats;
window.isUsdMoneySystem = utils.isUsdMoneySystem;
window.isIqdMoneySystem = utils.isIqdMoneySystem;
window.getExchangeRate = utils.getExchangeRate;
window.fxUsdRateFormatOpts = utils.fxUsdRateFormatOpts;
window.storedIqdToUsdDisplayAmount = utils.storedIqdToUsdDisplayAmount;
window.fxUsdRateFormatOptsForEntityBalance = utils.fxUsdRateFormatOptsForEntityBalance;
window.formatReportAmount = utils.formatReportAmount;
window.storedAmountToActiveCurrency = utils.storedAmountToActiveCurrency;
window.txnFxCurrencyMode = utils.txnFxCurrencyMode;
window.getCurrencySymbol = utils.getCurrencySymbol;
window.formatApproxUsdFromIqd = utils.formatApproxUsdFromIqd;
window.catalogIqdFromUsdField = utils.catalogIqdFromUsdField;
window.catalogUsdFromBaseField = utils.catalogUsdFromBaseField;
window.catalogFieldBaseAmount = utils.catalogFieldBaseAmount;
window.usdValueLooksLikeIqdSnapshot = utils.usdValueLooksLikeIqdSnapshot;
window.getProductBaseCurrency = utils.getProductBaseCurrency;
window.getCatalogPieceSellIqd = utils.getCatalogPieceSellIqd;
window.getCatalogPieceCostIqd = utils.getCatalogPieceCostIqd;
window.getCatalogPieceSellUsd = utils.getCatalogPieceSellUsd;
window.getCatalogPieceCostUsd = utils.getCatalogPieceCostUsd;
window.getCatalogPieceSellActive = utils.getCatalogPieceSellActive;
window.getCatalogPieceCostActive = utils.getCatalogPieceCostActive;
window.formatActiveCurrencyAmount = utils.formatActiveCurrencyAmount;
window.usdAmountToStoredIqd = utils.usdAmountToStoredIqd;
window.getPosFrozenFxRatePerOne = utils.getPosFrozenFxRatePerOne;
window.roundMoney = utils.roundMoney;
window.debtFormAmountToStoredIqd = utils.debtFormAmountToStoredIqd;
window.storedIqdToDebtFormAmount = utils.storedIqdToDebtFormAmount;
window.roundMoneyForDisplay = utils.roundMoneyForDisplay;
window.stripAmountThousands = utils.stripAmountThousands;
window.parseAmountInput = utils.parseAmountInput;
window.formatPaymentAmountNumber = utils.formatPaymentAmountNumber;
window.formatPaymentInputElement = utils.formatPaymentInputElement;
window.normalizeForSearch = utils.normalizeForSearch;
window.resetDateFilter = utils.resetDateFilter;
window.applyGlobalDatePreset = utils.applyGlobalDatePreset;
window.isDateInScope = utils.isDateInScope;
window.ensureDateFilterToday = utils.ensureDateFilterToday;
window.ensureDateInputsToday = utils.ensureDateInputsToday;
window.getTodayDateInputValue = utils.getTodayDateInputValue;
window.convertArabicNumerals = utils.convertArabicNumerals;
window.getAllSales = utils.getAllSales;
window.invalidateSalesPoolCache = utils.invalidateSalesPoolCache;
window.getFinancialMetrics = utils.getFinancialMetrics;
window.isOperationalExpenseRow = utils.isOperationalExpenseRow;
window.isCustomerDebtPaymentRow = utils.isCustomerDebtPaymentRow;
window.customerDebtPaymentChannel = utils.customerDebtPaymentChannel;
window.saleCashInAmount = utils.saleCashInAmount;
window.saleFibAmount = utils.saleFibAmount;
window.saleDebtAmount = utils.saleDebtAmount;
window.filterOperationalExpenses = utils.filterOperationalExpenses;
window.staffPayExpenseKind = utils.staffPayExpenseKind;
window.staffPayExpenseStaffName = utils.staffPayExpenseStaffName;
window.expenseTargetsStaff = utils.expenseTargetsStaff;
window.sumStaffPayExpenses = utils.sumStaffPayExpenses;
window.listStaffPayExpenses = utils.listStaffPayExpenses;
window.expenseRecordCurrency = utils.expenseRecordCurrency;
window.expenseRecordRatePerOne = utils.expenseRecordRatePerOne;
window.expenseAmountIqd = utils.expenseAmountIqd;
window.expenseAmountUsd = utils.expenseAmountUsd;
window.formatExpenseAmountDisplay = utils.formatExpenseAmountDisplay;
window.formatFrozenIqdAmount = utils.formatFrozenIqdAmount;
window.formatFrozenIqdRowsSum = utils.formatFrozenIqdRowsSum;
window.isReportablePurchaseSupply = utils.isReportablePurchaseSupply;
window.filterReportablePurchases = utils.filterReportablePurchases;
window.mergeCompanyDebtExpensesFromLedger = utils.mergeCompanyDebtExpensesFromLedger;
window.isPurchaseLinkedDebtPayment = utils.isPurchaseLinkedDebtPayment;
window.getSaleLineQty = utils.getSaleLineQty;
window.saleOrReturnItems = utils.saleOrReturnItems;
window.resolveSaleLineCost = utils.resolveSaleLineCost;
window.catalogCostForSaleUnit = utils.catalogCostForSaleUnit;
window.enteredCatalogCostForSaleUnit = utils.enteredCatalogCostForSaleUnit;
window.inventoryFifoSaleUnitCost = utils.inventoryFifoSaleUnitCost;
window.saleLineHasExplicitCost = utils.saleLineHasExplicitCost;
window.piecesInSaleUnit = utils.piecesInSaleUnit;
window.getReportSales = utils.getReportSales;

// Auth
window.hasPermission = auth.hasPermission;
window.canEditExchangeRate = auth.canEditExchangeRate;
window.applyUserPermissions = auth.applyUserPermissions;
window.applyRoleTemplate = auth.applyRoleTemplate;
window.checkPermission = auth.checkPermission;
window.canViewProfit = auth.canViewProfit;
window.canViewInvoiceProfit = auth.canViewInvoiceProfit;
window.canViewCost = auth.canViewCost;
window.canViewExpenses = auth.canViewExpenses;
window.getRoleTemplate = auth.getRoleTemplate;
window.canonicalizePermissionList = auth.canonicalizePermissionList;
window.ROLE_TEMPLATES = auth.ROLE_TEMPLATES;
window.VIEW_TO_PERM = auth.VIEW_TO_PERM;
window.MASTER_PIN = auth.MASTER_PIN;
window.MASTER_PASSWORD = auth.MASTER_PASSWORD;
window.hashPIN = auth.hashPIN;

// UI (theme, zoom)
window.applyTheme = ui.applyTheme;
window.applyZoomLevel = ui.applyZoomLevel;
window.adjustZoomLevel = ui.adjustZoomLevel;
window.applyCartDensity = ui.applyCartDensity;
window.adjustCartDensity = ui.adjustCartDensity;
window.applyCartPanelWidthPos = ui.applyCartPanelWidthPos;
window.adjustCartPanelWidth = ui.adjustCartPanelWidth;
window.initCartAppearanceFromStorage = ui.initCartAppearanceFromStorage;
window.applyGraphicsQuality = ui.applyGraphicsQuality;
window.posPickGraphicsQuality = ui.posPickGraphicsQuality;
window.initGraphicsQualityFromStorage = ui.initGraphicsQualityFromStorage;
window.normalizeGraphicsQuality = ui.normalizeGraphicsQuality;
window.scheduleGraphicsSettingsSave = ui.scheduleGraphicsSettingsSave;
window.isPosUltraGraphicsMode = ui.isPosUltraGraphicsMode;
window.isPosLowGraphicsMode = ui.isPosLowGraphicsMode;
window.isPosCpuSaveMode = ui.isPosCpuSaveMode;
window.isPosLargeCatalogMode = ui.isPosLargeCatalogMode;
window.isPosLargeShopMode = ui.isPosLargeShopMode;
window.posDbHealthCount = ui.posDbHealthCount;
window.posCatalogProductCount = ui.posCatalogProductCount;
window.posListRenderLimit = ui.posListRenderLimit;
window.posEntityPickLimit = ui.posEntityPickLimit;
window.posEntityPickNeedsQuery = ui.posEntityPickNeedsQuery;
window.posDebouncedListRenderMs = ui.posDebouncedListRenderMs;
window.shouldPosUseLongPoll = ui.shouldPosUseLongPoll;
window.isPosLanTerminalClient = ui.isPosLanTerminalClient;
window.isPosFastLanSync = ui.isPosFastLanSync;
window.isPosPrivateLanHost = ui.isPosPrivateLanHost;
window.posCatalogBootstrapTier = ui.posCatalogBootstrapTier;
window.posCatalogTierQueryString = ui.posCatalogTierQueryString;
window.posPollIntervalMs = ui.posPollIntervalMs;
window.posAutoRefreshDelayMs = ui.posAutoRefreshDelayMs;
window.posBackgroundRefreshDelayMs = ui.posBackgroundRefreshDelayMs;
window.posAfterWriteRefreshDelayMs = ui.posAfterWriteRefreshDelayMs;
window.isPosTxnViewActive = ui.isPosTxnViewActive;
window.updatePosTxnActiveClass = ui.updatePosTxnActiveClass;
window.posLiveSyncDelayMs = ui.posLiveSyncDelayMs;
window.isPosTxnLiteMode = ui.isPosTxnLiteMode;
window.posMaxPosMenuProducts = ui.posMaxPosMenuProducts;
window.posTxnGridProductLimit = ui.posTxnGridProductLimit;
window.posTxnMenuDebounceMs = ui.posTxnMenuDebounceMs;
window.posTxnGridDebounceMs = ui.posTxnGridDebounceMs;
window.posTxnCartRenderDebounceMs = ui.posTxnCartRenderDebounceMs;
window.posSkipCustomerDisplaySync = ui.posSkipCustomerDisplaySync;
window.posCustomerDisplaySyncMs = ui.posCustomerDisplaySyncMs;
window.posStartupDeferMs = ui.posStartupDeferMs;
window.posCartSaveDebounceMs = ui.posCartSaveDebounceMs;
window.posLoginDeferMs = ui.posLoginDeferMs;
window.posLoginChromeDeferMs = ui.posLoginChromeDeferMs;
window.posDeviceBootstrapWaitMs = ui.posDeviceBootstrapWaitMs;
window.enforceWeakDeviceGraphicsProfile = ui.enforceWeakDeviceGraphicsProfile;
window.markPosGraphicsUserOverride = ui.markPosGraphicsUserOverride;
window.consumeAutoGraphicsNotify = ui.consumeAutoGraphicsNotify;
window.autoConfigureGraphicsQualityIfNeeded = ui.autoConfigureGraphicsQualityIfNeeded;

window.posIconHtml = posIconHtml;
window.posEnhanceUiIcons = posEnhanceUiIcons;
window.schedulePosEnhanceIcons = schedulePosEnhanceIcons;

// Payment Modal Toggle Logic
window.syncPaymentToggles = function() {
    var checked = false;
    if (typeof isAutoPaymentModalEnabled === 'function') {
        checked = !!isAutoPaymentModalEnabled();
    } else if (typeof window.db !== 'undefined' && window.db && window.db.settings) {
        checked = window.db.settings.showPaymentModal === true;
    }

    document.querySelectorAll('[id^="quick-pay-toggle-"]').forEach(function(el) {
        if (el.checked !== checked) el.checked = checked;
    });

    document.querySelectorAll('.pos-payment-wallet-btn').forEach(function(wrapper) {
        wrapper.style.display = checked ? '' : 'none';
        if (checked) {
            wrapper.style.opacity = '1';
            wrapper.classList.add('active-toggle');
        } else {
            wrapper.style.opacity = '';
            wrapper.classList.remove('active-toggle');
        }
    });
};

window.togglePaymentModalSetting = function(checked) {
    if (typeof window.db !== 'undefined' && window.db) {
        if (!window.db.settings) window.db.settings = {};
        window.db.settings.showPaymentModal = checked;
        if (typeof window.saveDB === 'function') window.saveDB();
    }
    
    // Sync all checkboxes immediately
    window.syncPaymentToggles();
};

// Initial sync on load (as soon as possible)
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', window.syncPaymentToggles);
} else {
    window.syncPaymentToggles();
}

// Initial zoom: #app-zoom-wrapper (Chrome-like) + viewport height compensation
(function () {
    const z = parseInt(localStorage.getItem('pos_zoom'), 10);
    const zoom = (isNaN(z) || z < 70 || z > 150) ? 100 : z;
    if (typeof ui.applyZoomLevel === 'function') {
        ui.applyZoomLevel(zoom);
    } else {
        document.documentElement.style.setProperty('--pos-ui-scale', String(zoom / 100));
        document.documentElement.setAttribute('data-pos-zoom', String(zoom));
        document.body.style.zoom = '';
    }
})();

(function () {
    if (typeof ui.initCartAppearanceFromStorage === 'function') {
        ui.initCartAppearanceFromStorage();
    }
})();

(function () {
    if (typeof ui.initGraphicsQualityFromStorage === 'function') {
        ui.initGraphicsQualityFromStorage();
    }
})();

// Load legacy app by folder (core, i18n, settings, sync, purchase, inventory, sales, reports)
const APP_SCRIPT_PARTS = [
    'core/startup.js',
    'core/login-db.js',
    'core/catalog.js',
    'core/input-focus.js',
    'i18n/badini.js',
    'i18n/ar.js',
    'i18n/runtime.js',
    'core/entity-datalist.js',
    'i18n/changelog.js',
    'i18n/changelog-old.js',
    'i18n/shop-guide.js',
    'i18n/product-tutorial.js',
    'i18n/tech-specs.js',
    'settings/print-labels.js',
    'settings/printers.js',
    'sync/live.js',
    'sync/theme-home.js',
    'sync/companies.js',
    'sync/delivery.js',
    'sync/customers.js',
    'sync/company-profile.js',
    'purchase/cart.js',
    'purchase/payment.js',
    'purchase/returns.js',
    'purchase/company-docs.js',
    'inventory/warehouse.js',
    'inventory/stocktake.js',
    'inventory/products.js',
    'inventory/dashboard.js',
    'inventory/scale-barcode.js',
    'sales/barcode-nav.js',
    'sales/qty-cart.js',
    'sales/add-to-bill.js',
    'sales/edit-sale.js',
    'sales/debt-bill.js',
    'sales/virtual-menu.js',
    'sales/filter-worker.js',
    'sales/print.js',
    'sales/payment-modal.js',
    'sales/complete-sale.js',
    'sales/pos-return.js',
    'sales/txn-mobile.js',
    'reports/expenses.js',
    'reports/shifts.js',
    'reports/backup.js',
    'reports/backup-restore.js',
    'reports/ota-update.js',
    'reports/calendar.js',
    'reports/history.js',
    'reports/print.js',
    'reports/revenue.js',
    'reports/telegram.js',
    'reports/modals.js',
    'reports/sale-followup.js',
    'reports/purchase-history.js',
    'reports/nav-menus.js',
    'reports/exports.js',
    'reports/shop-ai.js'
];

function loadLegacyAppScripts(index) {
    if (index >= APP_SCRIPT_PARTS.length) {
        window.__posLegacyScriptsReady = true;
        try {
            window.dispatchEvent(new Event('pos-legacy-scripts-ready'));
        } catch (_eReady) {}
        return;
    }
    const script = document.createElement('script');
    const me = document.currentScript;
    const base = me && me.src ? me.src.replace(/\/main\.js.*$/, '/') : '';
    const v = encodeURIComponent(String(typeof window.POS_APP_VERSION !== 'undefined' ? window.POS_APP_VERSION : '1'));
    script.src = (base || 'public/js/') + APP_SCRIPT_PARTS[index] + '?v=' + v;
    script.onload = function () { loadLegacyAppScripts(index + 1); };
    script.onerror = function () {
        console.error('Failed to load POS script:', APP_SCRIPT_PARTS[index]);
        // Keep loading remaining scripts so one missing file cannot blank calendar/reports
        loadLegacyAppScripts(index + 1);
    };
    document.head.appendChild(script);
}

loadLegacyAppScripts(0);
