// core/entity-datalist.js — entity name lists
/**
 * Pick-list for POS customer + purchase supplier.
 * Panel renders on document.body (fixed) so overflow:hidden parents cannot clip it.
 */
(function () {
    'use strict';

    var activePick = null;
    var ignoreBlurUntil = 0;

    var CUSTOMER_PICK_ICONS = [
        'fa-user', 'fa-user-tie', 'fa-user-check', 'fa-user-tag', 'fa-user-circle',
        'fa-id-badge', 'fa-star', 'fa-heart', 'fa-gem', 'fa-crown', 'fa-leaf',
        'fa-home', 'fa-store', 'fa-truck', 'fa-car', 'fa-mug-hot', 'fa-shopping-bag',
        'fa-briefcase', 'fa-hard-hat', 'fa-graduation-cap', 'fa-smile', 'fa-bolt',
        'fa-sun', 'fa-moon', 'fa-cloud', 'fa-tree', 'fa-apple-alt', 'fa-coffee'
    ];

    function pickVisualSeed(item, index) {
        var raw = String(item.id != null && item.id !== '' ? item.id : (item.name || index));
        var h = 0;
        for (var i = 0; i < raw.length; i++) {
            h = ((h << 5) - h) + raw.charCodeAt(i);
            h |= 0;
        }
        return Math.abs(h);
    }

    function resolveCustomerPickVisual(item, index) {
        var seed = pickVisualSeed(item, index);
        return {
            icon: CUSTOMER_PICK_ICONS[seed % CUSTOMER_PICK_ICONS.length],
            colorIndex: seed % 12
        };
    }

    function resolveCompanyPickVisual(item, index) {
        var icons = ['fa-building', 'fa-warehouse', 'fa-industry', 'fa-truck-loading', 'fa-store', 'fa-boxes', 'fa-pallet', 'fa-dolly'];
        var seed = pickVisualSeed(item, index);
        return {
            icon: icons[seed % icons.length],
            colorIndex: seed % 12
        };
    }

    function norm(s) {
        if (typeof window.normalizeForSearch === 'function') return window.normalizeForSearch(String(s || ''));
        return String(s || '').toLowerCase().trim();
    }

    function findCompanyByName(text) {
        var dbRef = window.db;
        if (!dbRef || !dbRef.companies || !text) return null;
        var q = String(text).trim().toLowerCase();
        return dbRef.companies.find(function (c) {
            return c && String(c.name || '').trim().toLowerCase() === q;
        }) || null;
    }

    function syncPurchaseSupplierInputFromSelect() {
        var sel = document.getElementById('purchase-supplier-select');
        var input = document.getElementById('purchase-supplier-search');
        if (!sel || !input) return;
        // Never wipe what the cashier is typing.
        if (document.activeElement === input) return;
        var id = sel.value;
        if (!id) {
            if (window._posEditingPurchase && window._posEditingPurchase.txnId) return;
            input.value = '';
            return;
        }
        var dbRef = window.db;
        var comp = dbRef && dbRef.companies
            ? dbRef.companies.find(function (c) { return String(c.id) === String(id); })
            : null;
        input.value = comp ? (comp.name || '') : '';
    }

    function syncPurchaseSupplierSelectFromInput(text) {
        var sel = document.getElementById('purchase-supplier-select');
        var input = document.getElementById('purchase-supplier-search');
        if (!sel) return;
        var raw = String(text != null ? text : (input ? input.value : '')).trim();
        var typing = input && document.activeElement === input;
        if (!raw) {
            var had = !!sel.value;
            sel.value = '';
            if (!typing && input) input.value = '';
            if (had && typeof window.onPurchaseSupplierChange === 'function') window.onPurchaseSupplierChange();
            return;
        }
        var comp = findCompanyByName(raw);
        if (comp) {
            var same = String(sel.value) === String(comp.id);
            sel.value = String(comp.id);
            if (!typing && input) input.value = comp.name || '';
            if (!same && typeof window.onPurchaseSupplierChange === 'function') window.onPurchaseSupplierChange();
            return;
        }
        // Partial search text — keep typed value; only clear selected id.
        if (sel.value) {
            if (window._posEditingPurchase && window._posEditingPurchase.txnId) return;
            sel.value = '';
            if (typeof window.onPurchaseSupplierChange === 'function') window.onPurchaseSupplierChange();
        }
    }

    function positionPickPanel(panel, input) {
        var rect = input.getBoundingClientRect();
        var gap = 6;
        var maxH = Math.min(480, Math.max(160, window.innerHeight - rect.bottom - gap - 12));
        var openUp = maxH < 120 && rect.top > window.innerHeight * 0.45;
        if (openUp) {
            maxH = Math.min(480, Math.max(160, rect.top - gap - 12));
            panel.style.top = Math.max(8, rect.top - gap - maxH) + 'px';
        } else {
            panel.style.top = (rect.bottom + gap) + 'px';
        }
        panel.style.left = Math.max(8, Math.min(rect.left, window.innerWidth - Math.max(rect.width, 220) - 8)) + 'px';
        panel.style.width = Math.max(rect.width, 220) + 'px';
        panel.style.maxHeight = maxH + 'px';
    }

    function closeActivePick() {
        if (!activePick) return;
        if (activePick.panel && activePick.panel.parentNode) activePick.panel.parentNode.removeChild(activePick.panel);
        if (activePick.onScroll) window.removeEventListener('scroll', activePick.onScroll, true);
        if (activePick.onResize) window.removeEventListener('resize', activePick.onResize);
        activePick = null;
    }

    window.closePosEntityPickList = closeActivePick;

    function isPickInputVisible(input) {
        if (!input || !input.isConnected) return false;
        var view = input.closest('.workspace');
        // Allow when the host workspace is active, or when this input currently has focus.
        if (view && !view.classList.contains('active')) {
            if (document.activeElement !== input) return false;
        }
        var st = window.getComputedStyle(input);
        if (st.display === 'none' || st.visibility === 'hidden') return false;
        // Expanded cart/barcode fullscreen: input can be focusable even if briefly 0×0 during layout.
        var bill = document.getElementById('pos-bill-panel');
        var inExpandedCart = !!(bill && bill.classList.contains('expanded') && bill.contains(input));
        if (inExpandedCart && (document.activeElement === input || input.id === 'pos-expand-customer-name')) {
            return true;
        }
        var rect = input.getBoundingClientRect();
        return rect.width >= 2 && rect.height >= 2;
    }

    function buildPickItemButton(item, input, onPick, options) {
        options = options || {};
        var iconClass = options.iconClass || '';
        var colorIndex = null;
        if (typeof options.resolveItemVisual === 'function') {
            var visual = options.resolveItemVisual(item, options.itemIndex || 0);
            if (visual && visual.icon) iconClass = visual.icon;
            if (visual && visual.colorIndex != null) colorIndex = visual.colorIndex;
        }
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'pos-entity-ac-item pos-entity-pick-item';
        btn.setAttribute('role', 'option');

        if (iconClass) {
            var iconWrap = document.createElement('span');
            iconWrap.className = 'pos-entity-ac-item__icon';
            if (colorIndex != null) {
                iconWrap.classList.add('pos-entity-ac-item__icon--c' + (colorIndex % 12));
            }
            iconWrap.setAttribute('aria-hidden', 'true');
            var ic = document.createElement('i');
            ic.className = 'fas ' + iconClass;
            iconWrap.appendChild(ic);

            var body = document.createElement('span');
            body.className = 'pos-entity-ac-item__body';
            var label = document.createElement('span');
            label.className = 'pos-entity-ac-item__label';
            label.textContent = item.name || '';
            body.appendChild(label);

            btn.appendChild(iconWrap);
            btn.appendChild(body);
        } else {
            btn.textContent = item.name || '';
        }

        btn.addEventListener('mousedown', function (e) { e.preventDefault(); });
        btn.addEventListener('click', function () {
            if (typeof onPick === 'function') onPick(item, input);
            else input.value = item.name || '';
            closeActivePick();
            try { input.focus({ preventScroll: true }); } catch (_eF) { input.focus(); }
        });
        return btn;
    }

    function shouldServerPickEntity(entityType, q, localCount) {
        if (!entityType || typeof window.posFetchEntitySearch !== 'function') return false;
        var large = (typeof window.isPosLargeShopMode === 'function') && window.isPosLargeShopMode();
        if (entityType === 'companies') {
            // Local-first (instant). Server only when cache is incomplete/empty.
            if (!(localCount > 0)) return true;
            if (typeof window.posIsCompaniesPartial === 'function' && window.posIsCompaniesPartial()) return true;
            return false;
        }
        if (entityType === 'customers') {
            if (!(localCount > 0)) return true;
            if (typeof window.posIsCustomersPartial === 'function' && window.posIsCustomersPartial()) return true;
            if (large && String(q || '').length >= 1) return true;
        }
        return false;
    }

    /** Click/browse with an already-selected name should show the full list, not filter to one row. */
    function resolvePickQuery(input, entityType, forceBrowseAll) {
        var raw = String(input && input.value != null ? input.value : '').trim();
        if (forceBrowseAll) return '';
        if (!raw) return '';
        if (entityType === 'companies' && findCompanyByName(raw)) return '';
        return raw;
    }

    function paintPickPanelRows(panel, rows, input, onPick, options, hasMore, q) {
        panel.innerHTML = '';
        rows = (rows || []).filter(function (item) {
            return item && (item.is_active == null || Number(item.is_active) !== 0);
        });
        if (!rows.length) {
            var empty = document.createElement('div');
            empty.className = 'pos-entity-ac-empty';
            empty.textContent = q ? 'هیچ ئەنجامێک نەدۆزرایەوە' : 'لیست بەتاڵە — دوگمەیا + بۆ زێدەکرنا کریاری';
            panel.appendChild(empty);
            return;
        }
        rows.forEach(function (item, idx) {
            var itemOpts = Object.assign({}, options, { itemIndex: idx });
            panel.appendChild(buildPickItemButton(item, input, onPick, itemOpts));
        });
        if (hasMore) {
            var more = document.createElement('div');
            more.className = 'pos-entity-ac-empty';
            more.style.fontSize = '0.82rem';
            more.textContent = q ? 'گەڕان بکە بۆ وردتر…' : ('زیاتر هەیە — ناڤ بنڤیسە بۆ گەڕان (' + rows.length + '+)');
            panel.appendChild(more);
        }
    }

    function openServerPickList(input, onPick, options, q, pickLimit, getItemsFallback) {
        var entityType = options.entityType || '';
        var panel = document.createElement('div');
        panel.className = 'pos-entity-ac-panel pos-entity-pick-panel pos-entity-pick-portal';
        if (options.panelClass) {
            String(options.panelClass).split(/\s+/).forEach(function (cls) {
                if (cls) panel.classList.add(cls);
            });
        }
        panel.setAttribute('data-no-i18n', '1');
        panel.setAttribute('role', 'listbox');

        function filterLocal(rawQ) {
            var localAll = typeof getItemsFallback === 'function' ? (getItemsFallback() || []) : [];
            var nq = norm(rawQ);
            var rows = nq
                ? localAll.filter(function (item) {
                    return norm(item.name).indexOf(nq) !== -1 || (item.phone && norm(item.phone).indexOf(nq) !== -1);
                })
                : localAll;
            return rows.slice(0, pickLimit);
        }

        // Show local matches immediately — never leave a stuck spinner.
        var instant = filterLocal(q);
        if (instant.length) {
            paintPickPanelRows(panel, instant, input, onPick, options, false, q);
        } else {
            panel.innerHTML = '<div class="pos-entity-ac-empty"><i class="fas fa-spinner fa-spin"></i> د بارکرنا لیستێ دایە...</div>';
        }
        document.body.appendChild(panel);
        positionPickPanel(panel, input);
        ignoreBlurUntil = Date.now() + 500;

        var seq = (window._posEntityPickSeq = (window._posEntityPickSeq || 0) + 1);
        var done = false;
        var finish = function (rows, hasMore) {
            if (done || seq !== window._posEntityPickSeq || !panel.parentNode) return;
            done = true;
            if (rows.length && entityType === 'companies') {
                // Upsert quietly — avoid refreshEntityDatalists wiping the search box.
                if (typeof window.posUpsertCompanies === 'function') {
                    var prevRefresh = window.refreshEntityDatalists;
                    window.refreshEntityDatalists = function () {};
                    try { window.posUpsertCompanies(rows); } finally { window.refreshEntityDatalists = prevRefresh; }
                    refreshPurchaseSupplierSelectOptions();
                }
            } else if (rows.length && entityType === 'customers' && typeof window.posUpsertCustomers === 'function') {
                var prevRefreshC = window.refreshEntityDatalists;
                window.refreshEntityDatalists = function () {};
                try { window.posUpsertCustomers(rows); } finally { window.refreshEntityDatalists = prevRefreshC; }
            }
            paintPickPanelRows(panel, rows, input, onPick, options, !!hasMore, q);
            positionPickPanel(panel, input);
        };

        var timeoutId = setTimeout(function () {
            if (done) return;
            finish(instant.length ? instant : filterLocal(q), false);
        }, 2500);

        window.posFetchEntitySearch(entityType, q, pickLimit, 0).then(function (res) {
            clearTimeout(timeoutId);
            if (seq !== window._posEntityPickSeq || !panel.parentNode) return;
            var rows = (res && res.status === 'ok' && res.rows) ? res.rows : [];
            if (!rows.length) rows = filterLocal(q);
            finish(rows, !!(res && res.has_more));
        }).catch(function () {
            clearTimeout(timeoutId);
            finish(filterLocal(q), false);
        });

        var onScroll = function () {
            if (activePick && activePick.panel && activePick.input) positionPickPanel(activePick.panel, activePick.input);
        };
        activePick = { input: input, panel: panel, onScroll: onScroll, onResize: onScroll };
        window.addEventListener('scroll', onScroll, true);
        window.addEventListener('resize', onScroll);
    }

    function refreshPurchaseSupplierSelectOptions() {
        var sel = document.getElementById('purchase-supplier-select');
        if (!sel || !window.db || !Array.isArray(window.db.companies)) return;
        var prev = sel.value;
        var html = '<option value="">-- هەڵبژێرە --</option>';
        window.db.companies.slice().filter(function (c) {
            return c && (c.is_active == null || Number(c.is_active) !== 0);
        }).sort(function (a, b) {
            return String(a.name || '').localeCompare(String(b.name || ''), 'ku', { sensitivity: 'base' });
        }).forEach(function (c) {
            if (!c || c.id == null) return;
            var esc = (typeof window.escapeHtml === 'function')
                ? window.escapeHtml(c.name || '')
                : String(c.name || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
            html += '<option value="' + c.id + '">' + esc + '</option>';
        });
        sel.innerHTML = html;
        if (prev) sel.value = prev;
    }

    function openPickList(input, getItems, onPick, options) {
        options = options || {};
        if (!input || !isPickInputVisible(input)) return;
        closeActivePick();

        var all = typeof getItems === 'function' ? (getItems() || []) : [];
        var needsQuery = (typeof window.posEntityPickNeedsQuery === 'function') && window.posEntityPickNeedsQuery();
        var pickLimit = (typeof window.posEntityPickLimit === 'function') ? window.posEntityPickLimit() : 100;
        if (options.entityType === 'companies') pickLimit = Math.max(pickLimit, 120);
        var entityType = options.entityType || '';
        var rawQ = resolvePickQuery(input, entityType, !!options.browseAll);
        var q = norm(rawQ);
        var useServerPick = shouldServerPickEntity(entityType, rawQ, all.length);

        if (useServerPick) {
            openServerPickList(input, onPick, options, rawQ, pickLimit, getItems);
            return;
        }

        var list = q
            ? all.filter(function (item) {
                var name = norm(item.name);
                var phone = norm(item.phone);
                return name.indexOf(q) !== -1 || (phone && phone.indexOf(q) !== -1);
            })
            : all;

        var panel = document.createElement('div');
        panel.className = 'pos-entity-ac-panel pos-entity-pick-panel pos-entity-pick-portal';
        if (options.panelClass) {
            String(options.panelClass).split(/\s+/).forEach(function (cls) {
                if (cls) panel.classList.add(cls);
            });
        }
        panel.setAttribute('data-no-i18n', '1');
        panel.setAttribute('role', 'listbox');

        if (!list.length) {
            var empty = document.createElement('div');
            empty.className = 'pos-entity-ac-empty';
            if (needsQuery && !q && all.length > pickLimit) {
                empty.textContent = 'ناڤ یان ژمارە بنڤیسە بۆ گەڕان…';
            } else {
                empty.textContent = q ? 'هیچ ئەنجامێک نەدۆزرایەوە' : 'لیست بەتاڵە — دوگمەیا + بۆ زێدەکرنا کریاری';
            }
            panel.appendChild(empty);
        } else {
            var shown = list.slice(0, pickLimit);
            shown.forEach(function (item, idx) {
                var itemOpts = Object.assign({}, options, { itemIndex: idx });
                panel.appendChild(buildPickItemButton(item, input, onPick, itemOpts));
            });
            if (list.length > pickLimit) {
                var more = document.createElement('div');
                more.className = 'pos-entity-ac-empty';
                more.style.fontSize = '0.82rem';
                more.textContent = 'گەڕان بکە بۆ زیاتر — ' + pickLimit + ' / ' + list.length;
                panel.appendChild(more);
            }
        }

        document.body.appendChild(panel);
        positionPickPanel(panel, input);
        ignoreBlurUntil = Date.now() + 500;

        var onScroll = function () {
            if (activePick && activePick.panel && activePick.input) positionPickPanel(activePick.panel, activePick.input);
        };
        var onResize = onScroll;

        activePick = { input: input, panel: panel, onScroll: onScroll, onResize: onResize };
        window.addEventListener('scroll', onScroll, true);
        window.addEventListener('resize', onResize);
    }

    if (!window.__posEntityPickGlobalBound) {
        window.__posEntityPickGlobalBound = true;
        document.addEventListener('mousedown', function (e) {
            if (!activePick) return;
            var t = e.target;
            if (activePick.input && (t === activePick.input || (activePick.input.contains && activePick.input.contains(t)))) return;
            if (activePick.panel && activePick.panel.contains(t)) return;
            // Clicks on the customer field chrome (icon / wrap) should not dismiss before reopen.
            if (t && t.closest && (
                t.closest('.pos-customer-name-field') ||
                t.closest('.pos-header-customer-label') ||
                t.closest('.pos-header-customer-box') ||
                t.closest('.pos-expand-customer-bar') ||
                t.closest('.pos-expand-customer-icon')
            )) return;
            closeActivePick();
        });
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') closeActivePick();
        });
    }

    function bindPickList(input, getItems, onPick, options) {
        if (!input) return;
        options = options || {};
        var openOnFocus = options.openOnFocus !== false;
        input.setAttribute('autocomplete', 'off');
        input.removeAttribute('list');

        function showList(extraOpts) {
            var opts = Object.assign({}, options, extraOpts || {});
            openPickList(input, getItems, onPick, opts);
        }

        // Always (re)bind — safe if called after DOM refreshes.
        if (input._posPickShowList) {
            input.removeEventListener('focus', input._posPickOnFocus);
            input.removeEventListener('click', input._posPickOnClick);
            input.removeEventListener('input', input._posPickOnInput);
            input.removeEventListener('blur', input._posPickOnBlur);
        }

        input._posPickShowList = showList;
        input._posPickOnFocus = function () {
            if (openOnFocus) showList({ browseAll: true });
        };
        input._posPickOnClick = function () {
            showList({ browseAll: true });
        };
        input._posPickOnInput = function () {
            if (document.activeElement !== input) return;
            if (input._posPickInputTimer) clearTimeout(input._posPickInputTimer);
            var localN = typeof getItems === 'function' ? ((getItems() || []).length) : 0;
            var needServer = shouldServerPickEntity(options.entityType || '', input.value, localN);
            var delay = needServer ? 220 : 0;
            input._posPickInputTimer = setTimeout(function () {
                if (document.activeElement === input) showList({ browseAll: false });
            }, delay);
        };
        input._posPickOnBlur = function () {
            setTimeout(function () {
                if (Date.now() < ignoreBlurUntil) return;
                if (activePick && activePick.input === input && document.activeElement !== input) {
                    if (activePick.panel && activePick.panel.contains(document.activeElement)) return;
                    closeActivePick();
                }
            }, 220);
        };

        if (openOnFocus) input.addEventListener('focus', input._posPickOnFocus);
        input.addEventListener('click', input._posPickOnClick);
        input.addEventListener('input', input._posPickOnInput);
        input.addEventListener('blur', input._posPickOnBlur);
        input._posPickBound = true;

        input._posPickRefresh = function () {
            if (activePick && activePick.input === input) showList({ browseAll: !String(input.value || '').trim() });
        };
    }

    function getSortedCustomers() {
        var dbRef = window.db;
        if (!dbRef || !dbRef.customers) return [];
        return dbRef.customers.filter(function (c) {
            return c && (c.is_active == null || Number(c.is_active) !== 0);
        }).sort(function (a, b) {
            return String(a.name || '').localeCompare(String(b.name || ''), 'ku', { sensitivity: 'base' });
        }).map(function (c) {
            return { id: c.id, name: String(c.name || '').trim(), phone: c.phone || '', is_active: c.is_active };
        }).filter(function (c) { return c.name; });
    }

    function getSortedCompanies() {
        var dbRef = window.db;
        if (!dbRef || !dbRef.companies) return [];
        return dbRef.companies.filter(function (c) {
            return c && (c.is_active == null || Number(c.is_active) !== 0);
        }).sort(function (a, b) {
            return String(a.name || '').localeCompare(String(b.name || ''), 'ku', { sensitivity: 'base' });
        }).map(function (c) {
            return { id: c.id, name: String(c.name || '').trim(), phone: c.phone || '', is_active: c.is_active };
        }).filter(function (c) { return c.name; });
    }

    function onCustomerPicked(item, input) {
        input.value = item.name || '';
        var pickedId = item && item.id != null ? (parseInt(item.id, 10) || 0) : 0;
        if (pickedId > 0 && typeof window.setPosActiveCustomer === 'function') {
            window.setPosActiveCustomer(pickedId, item.name || '');
        } else if (typeof window.clearPosActiveCustomer === 'function') {
            window.clearPosActiveCustomer();
        }
        if (input.id === 'pos-expand-customer-name') {
            if (typeof window.syncPosExpandCustomerFields === 'function') window.syncPosExpandCustomerFields(true);
        } else if (input.id === 'pos-customer-name') {
            if (typeof window.syncPosExpandCustomerFields === 'function') window.syncPosExpandCustomerFields(false);
        }
        if (typeof window.updatePosCustomerClearBtnState === 'function') window.updatePosCustomerClearBtnState();
        if (typeof window.toggleCreditButton === 'function') window.toggleCreditButton();
        if (input.id === 'pos-customer-name' || input.id === 'pos-expand-customer-name') {
            var cust = null;
            if (typeof db !== 'undefined' && db && Array.isArray(db.customers)) {
                if (pickedId > 0) {
                    cust = db.customers.find(function (c) { return c && parseInt(c.id, 10) === pickedId; });
                }
                if (!cust) {
                    var needle = String(item.name || '').trim().toLowerCase();
                    cust = db.customers.find(function (c) {
                        return c && String(c.name || '').trim().toLowerCase() === needle;
                    });
                }
            }
            if (cust) {
                if (pickedId <= 0 && typeof window.setPosActiveCustomer === 'function') {
                    window.setPosActiveCustomer(cust.id, cust.name || item.name || '');
                }
                if (typeof maybeToastPaymentDueOverdue === 'function') maybeToastPaymentDueOverdue('customer', cust);
            }
        }
        if (typeof window.maybeCollapseTxnMetaAfterValid === 'function') {
            window.maybeCollapseTxnMetaAfterValid('pos', ['pos-customer-name']);
        }
    }

    function openCustomerPickForInput(input) {
        if (!input) return;
        bindPickList(input, getSortedCustomers, onCustomerPicked, {
            resolveItemVisual: resolveCustomerPickVisual,
            entityType: 'customers'
        });
        try { input.focus({ preventScroll: true }); } catch (_e) { try { input.focus(); } catch (_e2) {} }
        if (typeof input._posPickShowList === 'function') {
            input._posPickShowList({ browseAll: true });
        }
    }

    function bindCustomerPickLists() {
        ['pos-customer-name', 'pos-expand-customer-name'].forEach(function (id) {
            var el = document.getElementById(id);
            if (!el) return;
            bindPickList(el, getSortedCustomers, onCustomerPicked, { resolveItemVisual: resolveCustomerPickVisual, entityType: 'customers' });
            if (!el._posActiveCustTypeClearBound) {
                el._posActiveCustTypeClearBound = true;
                el.addEventListener('input', function () {
                    // Manual typing invalidates the previously picked ID until a list pick restores it.
                    if (typeof window.clearPosActiveCustomer === 'function') window.clearPosActiveCustomer();
                });
            }
        });
    }

    window.populateCustomerDatalist = function () {
        bindCustomerPickLists();
    };
    window.openPosCustomerPickList = function () {
        openCustomerPickForInput(document.getElementById('pos-customer-name'));
    };

    window.populatePurchaseCompanyDatalist = function () {
        var input = document.getElementById('purchase-supplier-search');
        if (input && typeof input._posPickRefresh === 'function') input._posPickRefresh();
    };

    window.ensurePurchaseSupplierDatalist = function () {
        var sel = document.getElementById('purchase-supplier-select');
        if (!sel) return;
        var row = sel.closest('.purchase-supplier-select-row');
        if (!row) return;

        var input = document.getElementById('purchase-supplier-search');
        if (!input) {
            input = document.createElement('input');
            input.type = 'text';
            input.id = 'purchase-supplier-search';
            input.className = 'input-std purchase-supplier-search pos-header-input';
            input.placeholder = 'ناڤی دابینکەر — کلیک بکە بۆ هەموو لیست';
            input.setAttribute('autocomplete', 'off');
            row.insertBefore(input, sel);
        }

        sel.classList.add('pos-entity-ac-native-select');

        bindPickList(input, getSortedCompanies, function (item) {
            sel.value = String(item.id);
            input.value = item.name || '';
            if (typeof window.onPurchaseSupplierChange === 'function') window.onPurchaseSupplierChange();
        }, { openOnFocus: false, resolveItemVisual: resolveCompanyPickVisual, panelClass: 'purchase-supplier-ac', entityType: 'companies' });

        if (!input._purchaseBlurBound) {
            input._purchaseBlurBound = true;
            input.addEventListener('blur', function () {
                setTimeout(function () {
                    syncPurchaseSupplierSelectFromInput(input.value);
                }, 180);
            });
        }

        syncPurchaseSupplierInputFromSelect();
    };

    window.syncPurchaseSupplierSearchFromSelect = syncPurchaseSupplierInputFromSelect;

    function bootEntityPickLists() {
        bindCustomerPickLists();
        if (document.getElementById('purchase-supplier-select')) {
            window.ensurePurchaseSupplierDatalist();
        }
    }

    // Delegation: icon / field chrome / late-bound inputs always open the list.
    if (!window.__posCustomerPickDelegateBound) {
        window.__posCustomerPickDelegateBound = true;
        document.addEventListener('click', function (e) {
            var t = e.target;
            if (!t || !t.closest) return;
            var input = null;
            if (t.id === 'pos-customer-name' || t.id === 'pos-expand-customer-name') {
                input = t;
            } else {
                // Expanded barcode/cart fullscreen uses .pos-expand-customer-bar (not header field).
                var expandWrap = t.closest('.pos-expand-customer-bar, .pos-expand-customer-icon');
                if (expandWrap) {
                    if (t.closest && t.closest('#pos-expand-customer-paid, .pos-expand-paid, .pos-expand-add-customer')) return;
                    input = document.getElementById('pos-expand-customer-name');
                } else {
                    var wrap = t.closest('.pos-customer-name-field, .pos-header-customer-label, .pos-header-customer-box');
                    if (wrap) {
                        // Only open when click is on chrome (icon/label), not when typing in paid field.
                        if (t.closest && t.closest('#pos-customer-paid, .pos-paid-field, .pos-customer-add-btn')) return;
                        input = wrap.querySelector('#pos-customer-name') || document.getElementById('pos-customer-name');
                    }
                }
            }
            if (!input) return;
            // Let native focus happen; then force-open list (covers missed bindings).
            setTimeout(function () {
                openCustomerPickForInput(input);
            }, 0);
        }, true);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', bootEntityPickLists);
    } else {
        bootEntityPickLists();
    }
    window.addEventListener('pos-legacy-scripts-ready', bootEntityPickLists);
})();
