// sales/barcode-nav.js — sales, barcode, menu nav
        // --- POS ---
        function isAlternatePricingActive(table) {
            return !!(table && table.isTakeaway);
        }
        window.isAlternatePricingActive = isAlternatePricingActive;

        window.updateTakeawayToggleUI = function() {
            const btn = document.getElementById('btn-pos-takeaway-toggle');
            const btnExpand = document.getElementById('btn-pos-expand-takeaway-toggle');
            const table = db.tables.find(t => t.id === activeTableId);
            var featureEnabled = (typeof isJumlaSystemFeatureEnabled === 'function')
                ? isJumlaSystemFeatureEnabled()
                : ((typeof isPremiumSettingsFeatureEnabled === 'function')
                    ? isPremiumSettingsFeatureEnabled('set-enable-takeaway')
                    : !!(db.settings && db.settings.enableTakeaway));
            var isJumlaPriceMode = !!(db.settings && db.settings.takeawayAsWholesale);
            var sefariLbl = (typeof t === 'function') ? t('settings_jumla_mode_sefari') : 'سەفەری';
            if (!sefariLbl || sefariLbl === 'settings_jumla_mode_sefari') sefariLbl = 'سەفەری';
            var jumlaLbl = (typeof t === 'function') ? t('settings_jumla_mode_jumla') : 'جوملە';
            if (!jumlaLbl || jumlaLbl === 'settings_jumla_mode_jumla') jumlaLbl = 'جوملە';
            const labelText = isJumlaPriceMode ? jumlaLbl : sefariLbl;
            const iconClass = isJumlaPriceMode ? 'fas fa-box' : 'fas fa-shopping-bag';
            
            // Update POS labels only (not product form table header)
            document.querySelectorAll('#view-pos [data-layout-id="layout-optional-takeaway"]').forEach(el => {
                const label = el.querySelector('label') || el.querySelector('th') || el;
                if (label.innerHTML) {
                    label.innerHTML = label.innerHTML.replace(/سەفەری|جوملە|Takeaway|Wholesale/gi, labelText);
                    const i = label.querySelector('i');
                    if (i) i.className = iconClass;
                }
            });
            const badge = document.getElementById('pos-takeaway-badge');
            if (badge) {
                badge.innerText = labelText;
                badge.style.display = (featureEnabled && table && isAlternatePricingActive(table)) ? 'inline-block' : 'none';
            }

            if (btn) {
                if (featureEnabled) {
                    btn.style.display = 'inline-flex';
                    var altOn = !!(table && table.isTakeaway);
                    var toggleTitle = altOn
                        ? ((typeof t === 'function') ? t('jumla_toggle_to_retail') : 'تاک — کلیک بکە')
                        : ((typeof t === 'function') ? t('jumla_toggle_to_jumla') : 'جوملە — کلیک بکە');
                    btn.title = toggleTitle;
                    btn.innerHTML = `<i class="${iconClass}"></i>`;
                    if (altOn) {
                        btn.classList.add('active');
                        btn.style.backgroundColor = 'var(--warning)';
                        btn.style.color = 'white';
                        btn.style.borderColor = 'var(--warning)';
                    } else {
                        btn.classList.remove('active');
                        btn.style.backgroundColor = 'var(--success)';
                        btn.style.color = 'white';
                        btn.style.borderColor = 'var(--success)';
                    }
                } else {
                    btn.style.display = 'none';
                }
            }
            
            if (btnExpand) {
                if (featureEnabled) {
                    btnExpand.style.display = 'inline-flex';
                    var altOnExpand = !!(table && table.isTakeaway);
                    var toggleTitleExpand = altOnExpand
                        ? ((typeof t === 'function') ? t('jumla_toggle_to_retail') : 'تاک — کلیک بکە')
                        : ((typeof t === 'function') ? t('jumla_toggle_to_jumla') : 'جوملە — کلیک بکە');
                    btnExpand.title = toggleTitleExpand;
                    btnExpand.innerHTML = `<i class="${iconClass}"></i>`;
                    if (altOnExpand) {
                        btnExpand.classList.add('active');
                        btnExpand.style.backgroundColor = 'var(--warning)';
                        btnExpand.style.color = 'white';
                        btnExpand.style.borderColor = 'var(--warning)';
                    } else {
                        btnExpand.classList.remove('active');
                        btnExpand.style.backgroundColor = 'var(--success)';
                        btnExpand.style.color = 'white';
                        btnExpand.style.borderColor = 'var(--success)';
                    }
                } else {
                    btnExpand.style.display = 'none';
                }
            }
        };

        window.toggleCartTakeaway = function() {
            if (!activeTableId) ensureDefaultCart();
            const table = db.tables.find(t => t.id === activeTableId);
            if (!table) return;
            
            // Toggle table state: تاک (retail) ↔ جوملە/سەفەری (alternate price)
            table.isTakeaway = !table.isTakeaway;
            
            // Re-render UI
            window.updateTakeawayToggleUI();
            
            // Also update the badge
            const badge = document.getElementById('pos-takeaway-badge');
            if (badge) badge.style.display = table.isTakeaway ? 'inline-block' : 'none';
            
            if (typeof renderPOSMenu === 'function') renderPOSMenu('', true);
            if (typeof recalcBulkPrices === 'function') recalcBulkPrices();
            if (typeof renderBill === 'function') renderBill();
            
            // Update table state locally in background
            const formData = new FormData();
            formData.append('action', 'save_tables');
            formData.append('tables', JSON.stringify(db.tables));
            fetch('?action=save_tables', { method: 'POST', body: formData }).catch(e => {});
        };

        function openTable(id) {
            activeTableId = (id != null && !isNaN(Number(id))) ? Number(id) : id;
            const t = db.tables.find(function (x) { return String(x.id) === String(id); });
            
            if(t && t.has_new_items) {
                t.has_new_items = false;
            }

            document.getElementById('pos-actions-default').style.display = 'block'; 
            var posLocale = (typeof getDateLocale === 'function') ? getDateLocale() : 'ar-IQ';
            document.getElementById('pos-date').innerText = (typeof formatPosDateTime === 'function')
                ? formatPosDateTime(new Date(), posLocale)
                : new Date().toLocaleString(posLocale);
            
            // Show Default Cart indicator if tables are hidden
            if (db.settings && db.settings.showTables !== true) {
                showDefaultCartIndicator();
            } else {
                document.getElementById('pos-active-table').innerText = t.name;
            }
            
            document.getElementById('nav-pos').style.display = 'flex'; nav('pos'); applyPrintSettings(); if (typeof updatePOSUnitButtons === 'function') updatePOSUnitButtons(); if (typeof updatePosCardToolsBtn === 'function') updatePosCardToolsBtn(); renderPOSCategories(); renderPOSMenu(); renderBill(); if (typeof bindPosExpandCustomerFields === 'function') bindPosExpandCustomerFields();
            
            // Reset Return Mode
            isReturnMode = false;
            updatePOSModeUI();

            // Show Takeaway Badge
            const badge = document.getElementById('pos-takeaway-badge');
            if (badge) badge.style.display = (t && t.isTakeaway) ? 'inline-block' : 'none';
            if (typeof window.updateTakeawayToggleUI === 'function') window.updateTakeawayToggleUI();
            
            // Reset discount field when opening table
            const posDiscEl = document.getElementById('pos-discount');
            if (posDiscEl) posDiscEl.value = '';
            if (typeof window.clearPosCustomerCheckoutState === 'function') {
                window.clearPosCustomerCheckoutState({ skipToggle: false });
            } else {
                const posCustEl = document.getElementById('pos-customer-name');
                if (posCustEl) posCustEl.value = '';
                const posCustPhone = document.getElementById('pos-customer-phone');
                if (posCustPhone) posCustPhone.value = '';
                const posExpandCust = document.getElementById('pos-expand-customer-name');
                if (posExpandCust) posExpandCust.value = '';
                const posExpandPhone = document.getElementById('pos-expand-customer-phone');
                if (posExpandPhone) posExpandPhone.value = '';
                const posExpandPaid = document.getElementById('pos-expand-customer-paid');
                if (posExpandPaid) posExpandPaid.value = '';
                if (typeof toggleCreditButton === 'function') toggleCreditButton();
            }
            
            // Focus on barcode input
            if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('pos');
            updateUSDBadge();
            
            // لادانا دوگمەیا بەرێ یا خەلەت
            var oldBtn = document.getElementById('btn-pos-sales-history');
            if (oldBtn) oldBtn.remove();
            if (db && db.settings && db.settings.language === 'ar') {
                var posView = document.getElementById('view-pos');
                if (posView && typeof localizeHardcodedUiText === 'function') localizeHardcodedUiText(posView);
            }
            if (typeof window.populateCustomerDatalist === 'function') window.populateCustomerDatalist();
        }

        function getPosCustomerNameValue() {
            var bill = document.getElementById('pos-bill-panel');
            var expandName = document.getElementById('pos-expand-customer-name');
            var mainName = document.getElementById('pos-customer-name');
            if (bill && bill.classList.contains('expanded') && expandName) {
                return String(expandName.value || '').trim();
            }
            if (mainName) {
                return String(mainName.value || '').trim();
            }
            return expandName ? String(expandName.value || '').trim() : '';
        }
        window.getPosCustomerNameValue = getPosCustomerNameValue;

        function getPosActiveCustomerId() {
            var custName = typeof getPosCustomerNameValue === 'function' ? getPosCustomerNameValue() : '';
            if (!custName) {
                window.__posActiveCustomerId = null;
                var mn = document.getElementById('pos-customer-name');
                var en = document.getElementById('pos-expand-customer-name');
                if (mn) mn.removeAttribute('data-customer-id');
                if (en) en.removeAttribute('data-customer-id');
                return 0;
            }
            var fromMem = parseInt(window.__posActiveCustomerId, 10) || 0;
            if (fromMem > 0) return fromMem;
            var mainName = document.getElementById('pos-customer-name');
            var expandName = document.getElementById('pos-expand-customer-name');
            var fromMain = mainName ? (parseInt(mainName.getAttribute('data-customer-id'), 10) || 0) : 0;
            if (fromMain > 0) return fromMain;
            var fromExpand = expandName ? (parseInt(expandName.getAttribute('data-customer-id'), 10) || 0) : 0;
            return fromExpand > 0 ? fromExpand : 0;
        }
        window.getPosActiveCustomerId = getPosActiveCustomerId;

        /** Persist selected customer by ID so consecutive debt sales do not rely on name alone. */
        window.setPosActiveCustomer = function (customerId, customerName) {
            var id = parseInt(customerId, 10) || 0;
            var name = customerName != null ? String(customerName).trim() : '';
            window.__posActiveCustomerId = id > 0 ? id : null;
            var mainName = document.getElementById('pos-customer-name');
            var expandName = document.getElementById('pos-expand-customer-name');
            [mainName, expandName].forEach(function (el) {
                if (!el) return;
                if (id > 0) el.setAttribute('data-customer-id', String(id));
                else el.removeAttribute('data-customer-id');
                el.value = name;
            });
            if (typeof window.updatePosCustomerClearBtnState === 'function') window.updatePosCustomerClearBtnState();
        };

        window.clearPosActiveCustomer = function () {
            window.__posActiveCustomerId = null;
            ['pos-customer-name', 'pos-expand-customer-name'].forEach(function (id) {
                var el = document.getElementById(id);
                if (el) el.removeAttribute('data-customer-id');
            });
        };

        window.updatePosCustomerClearBtnState = function () {
            var btn = document.getElementById('pos-customer-clear-btn');
            var mainName = document.getElementById('pos-customer-name');
            if (!btn) return;
            var hasVal = mainName && String(mainName.value || '').trim().length > 0;
            btn.style.display = hasVal ? 'inline-flex' : 'none';
        };

        window.clearPosCustomerInput = function () {
            var mainName = document.getElementById('pos-customer-name');
            var expandName = document.getElementById('pos-expand-customer-name');
            var mainPaid = document.getElementById('pos-customer-paid');
            var expandPaid = document.getElementById('pos-expand-customer-paid');
            var mainPhone = document.getElementById('pos-customer-phone');
            var expandPhone = document.getElementById('pos-expand-customer-phone');
            if (mainName) {
                mainName.value = '';
                mainName.removeAttribute('data-customer-id');
            }
            if (expandName) {
                expandName.value = '';
                expandName.removeAttribute('data-customer-id');
            }
            if (mainPaid) mainPaid.value = '';
            if (expandPaid) expandPaid.value = '';
            if (mainPhone) mainPhone.value = '';
            if (expandPhone) expandPhone.value = '';
            window.__posActiveCustomerId = null;

            if (typeof posTabs !== 'undefined' && Array.isArray(posTabs) && typeof activePosTabIndex === 'number' && posTabs[activePosTabIndex]) {
                posTabs[activePosTabIndex].customerName = '';
                posTabs[activePosTabIndex].customerId = null;
            }
            if (typeof saveActivePosTabSnapshot === 'function') saveActivePosTabSnapshot();

            if (typeof window.updatePosCustomerClearBtnState === 'function') window.updatePosCustomerClearBtnState();
            if (typeof window.toggleCreditButton === 'function') window.toggleCreditButton();
            if (typeof window.calculateDebtRemaining === 'function') window.calculateDebtRemaining();
            if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('pos', { clear: false, delay: 20 });
        };

        /** Full main+expand customer DOM + in-memory ID reset (post-sale / new table). */
        window.clearPosCustomerCheckoutState = function (opts) {
            opts = opts || {};
            window.__posActiveCustomerId = null;
            [
                'pos-customer-name', 'pos-expand-customer-name',
                'pos-customer-paid', 'pos-expand-customer-paid',
                'pos-customer-phone', 'pos-expand-customer-phone'
            ].forEach(function (id) {
                var el = document.getElementById(id);
                if (!el) return;
                el.value = '';
                if (el.removeAttribute) el.removeAttribute('data-customer-id');
            });
            if (typeof window.updatePosCustomerClearBtnState === 'function') window.updatePosCustomerClearBtnState();
            if (!opts.skipToggle && typeof window.toggleCreditButton === 'function') {
                window.toggleCreditButton();
            }
            if (typeof window.calculateDebtRemaining === 'function') {
                window.calculateDebtRemaining();
            }
        };

        function parsePosCustomerPaidField(el) {
            if (!el) return 0;
            var parsed = (typeof parseAmountInput === 'function')
                ? parseAmountInput(el.value || '')
                : parseFloat(String(el.value || '').replace(/,/g, ''));
            return Number.isFinite(parsed) ? Math.max(0, parsed) : 0;
        }
        function getPosCustomerPaidValue() {
            var bill = document.getElementById('pos-bill-panel');
            var expandPaid = document.getElementById('pos-expand-customer-paid');
            var mainPaid = document.getElementById('pos-customer-paid');
            if (bill && bill.classList.contains('expanded') && expandPaid) {
                return parsePosCustomerPaidField(expandPaid);
            }
            if (mainPaid) return parsePosCustomerPaidField(mainPaid);
            return 0;
        }
        window.getPosCustomerPaidValue = getPosCustomerPaidValue;

        window.syncPosExpandCustomerFields = function (fromExpand) {
            var mainName = document.getElementById('pos-customer-name');
            var expandName = document.getElementById('pos-expand-customer-name');
            var mainPaid = document.getElementById('pos-customer-paid');
            var expandPaid = document.getElementById('pos-expand-customer-paid');
            var mainPhone = document.getElementById('pos-customer-phone');
            var expandPhone = document.getElementById('pos-expand-customer-phone');
            if (!mainName || !expandName) return;
            if (fromExpand) {
                mainName.value = expandName.value;
                if (mainPaid && expandPaid) mainPaid.value = expandPaid.value;
                if (mainPhone && expandPhone) mainPhone.value = expandPhone.value;
                var expandId = expandName.getAttribute('data-customer-id') || '';
                if (expandId) mainName.setAttribute('data-customer-id', expandId);
                else mainName.removeAttribute('data-customer-id');
            } else {
                expandName.value = mainName.value;
                if (mainPaid && expandPaid) expandPaid.value = mainPaid.value;
                if (mainPhone && expandPhone) expandPhone.value = mainPhone.value;
                var mainId = mainName.getAttribute('data-customer-id') || '';
                if (mainId) expandName.setAttribute('data-customer-id', mainId);
                else expandName.removeAttribute('data-customer-id');
            }
            var syncedId = parseInt(mainName.getAttribute('data-customer-id') || expandName.getAttribute('data-customer-id') || '0', 10) || 0;
            window.__posActiveCustomerId = syncedId > 0 ? syncedId : null;
            if (typeof window.toggleCreditButton === 'function') window.toggleCreditButton();
        };

        /** Prefer whichever side still has a name/ID so checkout never drops a stale expand-only customer. */
        window.syncPosCustomerFieldsForCheckout = function () {
            var bill = document.getElementById('pos-bill-panel');
            var mainName = document.getElementById('pos-customer-name');
            var expandName = document.getElementById('pos-expand-customer-name');
            var mainVal = mainName ? String(mainName.value || '').trim() : '';
            var expandVal = expandName ? String(expandName.value || '').trim() : '';
            var mainId = mainName ? (parseInt(mainName.getAttribute('data-customer-id'), 10) || 0) : 0;
            var expandId = expandName ? (parseInt(expandName.getAttribute('data-customer-id'), 10) || 0) : 0;
            if ((!mainVal && expandVal) || (!mainId && expandId)) {
                window.syncPosExpandCustomerFields(true);
            } else if ((mainVal && !expandVal) || (mainId && !expandId)) {
                window.syncPosExpandCustomerFields(false);
            } else {
                window.syncPosExpandCustomerFields(!!(bill && bill.classList.contains('expanded')));
            }
        };

        function bindPosExpandCustomerFields() {
            var expandName = document.getElementById('pos-expand-customer-name');
            var expandPaid = document.getElementById('pos-expand-customer-paid');
            var expandPhone = document.getElementById('pos-expand-customer-phone');
            var mainName = document.getElementById('pos-customer-name');
            if (mainName && !mainName._posActiveCustInputBound) {
                mainName._posActiveCustInputBound = true;
                var onMainCustomerInput = function () {
                    var val = mainName.value;
                    if (expandName && expandName.value !== val) {
                        expandName.value = val;
                    }
                    if (!val.trim()) {
                        if (typeof window.clearPosActiveCustomer === 'function') window.clearPosActiveCustomer();
                        var paidInput = document.getElementById('pos-customer-paid');
                        if (paidInput) paidInput.value = '';
                        if (expandPaid) expandPaid.value = '';
                        var phoneInput = document.getElementById('pos-customer-phone');
                        if (phoneInput) phoneInput.value = '';
                        if (expandPhone) expandPhone.value = '';
                    } else {
                        if (typeof window.clearPosActiveCustomer === 'function') window.clearPosActiveCustomer();
                        if (typeof db !== 'undefined' && db && Array.isArray(db.customers)) {
                            var needle = val.trim().toLowerCase();
                            var found = db.customers.find(function (c) {
                                return c && String(c.name || '').trim().toLowerCase() === needle;
                            });
                            if (found && typeof window.setPosActiveCustomer === 'function') {
                                window.setPosActiveCustomer(found.id, found.name);
                            }
                        }
                    }
                    if (typeof window.updatePosCustomerClearBtnState === 'function') window.updatePosCustomerClearBtnState();
                    if (typeof window.toggleCreditButton === 'function') window.toggleCreditButton();
                    if (typeof window.calculateDebtRemaining === 'function') window.calculateDebtRemaining();
                };
                mainName.addEventListener('input', onMainCustomerInput);
                mainName.addEventListener('change', onMainCustomerInput);
            }
            if (expandName && !expandName._posExpandBound) {
                expandName._posExpandBound = true;
                var onExpandCustomerInput = function () {
                    var val = expandName.value;
                    if (mainName && mainName.value !== val) {
                        mainName.value = val;
                    }
                    if (!val.trim()) {
                        if (typeof window.clearPosActiveCustomer === 'function') window.clearPosActiveCustomer();
                        var paidInput = document.getElementById('pos-customer-paid');
                        if (paidInput) paidInput.value = '';
                        if (expandPaid) expandPaid.value = '';
                        var phoneInput = document.getElementById('pos-customer-phone');
                        if (phoneInput) phoneInput.value = '';
                        if (expandPhone) expandPhone.value = '';
                    } else {
                        if (typeof window.clearPosActiveCustomer === 'function') window.clearPosActiveCustomer();
                        if (typeof db !== 'undefined' && db && Array.isArray(db.customers)) {
                            var needle = val.trim().toLowerCase();
                            var found = db.customers.find(function (c) {
                                return c && String(c.name || '').trim().toLowerCase() === needle;
                            });
                            if (found && typeof window.setPosActiveCustomer === 'function') {
                                window.setPosActiveCustomer(found.id, found.name);
                            }
                        }
                    }
                    if (typeof window.updatePosCustomerClearBtnState === 'function') window.updatePosCustomerClearBtnState();
                    if (typeof window.toggleCreditButton === 'function') window.toggleCreditButton();
                    if (typeof window.calculateDebtRemaining === 'function') window.calculateDebtRemaining();
                };
                expandName.addEventListener('input', onExpandCustomerInput);
                expandName.addEventListener('change', onExpandCustomerInput);
                expandName.addEventListener('focus', function () {
                    if (typeof populateCustomerDatalist === 'function') populateCustomerDatalist();
                });
            }
            if (expandPaid && !expandPaid._posExpandBound) {
                expandPaid._posExpandBound = true;
                expandPaid.addEventListener('input', function () {
                    window.syncPosExpandCustomerFields(true);
                    if (typeof calculateDebtRemaining === 'function') calculateDebtRemaining();
                });
            }
            if (expandPhone && !expandPhone._posExpandBound) {
                expandPhone._posExpandBound = true;
                expandPhone.addEventListener('input', function () {
                    window.syncPosExpandCustomerFields(true);
                });
            }
            if (typeof window.updatePosCustomerClearBtnState === 'function') window.updatePosCustomerClearBtnState();
        }

        window.quickAddCustomerExpand = function () {
            var expandName = document.getElementById('pos-expand-customer-name');
            var mainName = document.getElementById('pos-customer-name');
            if (expandName && mainName && expandName.value.trim() && !mainName.value.trim()) {
                mainName.value = expandName.value.trim();
            }
            if (typeof window.quickAddCustomer === 'function') window.quickAddCustomer();
            setTimeout(function () { window.syncPosExpandCustomerFields(false); }, 300);
        };

        function togglePosMenu() {
            if (typeof window.isTxnMobileViewport === 'function' && window.isTxnMobileViewport()) {
                if (typeof window.bounceTxnSheet === 'function') window.bounceTxnSheet('pos');
                return;
            }
            const menu = document.getElementById('pos-menu-panel');
            const bill = document.getElementById('pos-bill-panel');
            if (!menu || !bill) return;
            const wasExpanded = bill.classList.contains('expanded');
            menu.classList.toggle('collapsed');
            bill.classList.toggle('expanded');
            if (bill.classList.contains('expanded')) {
                // Move outside #app-zoom-inner so position:fixed is not trapped by transform:scale
                try {
                    if (!bill._posExpandPlaceholder) {
                        var ph = document.createElement('div');
                        ph.id = 'pos-bill-expand-placeholder';
                        ph.setAttribute('aria-hidden', 'true');
                        ph.style.cssText = 'display:none;flex:0 0 0;width:0;height:0;overflow:hidden;';
                        if (bill.parentNode) bill.parentNode.insertBefore(ph, bill);
                        bill._posExpandPlaceholder = ph;
                    }
                    document.body.appendChild(bill);
                    document.body.classList.add('pos-cart-fullscreen');
                } catch (ePortal) {}
                bill.style.setProperty('flex', 'none', 'important');
                bill.style.setProperty('width', '100vw', 'important');
                bill.style.setProperty('max-width', '100vw', 'important');
                bill.style.setProperty('min-width', '0', 'important');
                bill.style.setProperty('height', '100dvh', 'important');
                bill.style.setProperty('position', 'fixed', 'important');
                bill.style.setProperty('inset', '0', 'important');
                bill.style.setProperty('z-index', '100000', 'important');
                bindPosExpandCustomerFields();
                window.syncPosExpandCustomerFields(false);
                try {
                    var mainInput = document.getElementById('pos-barcode-input');
                    var expandInputSync = document.getElementById('pos-expand-search-input');
                    if (mainInput && expandInputSync) {
                        expandInputSync.value = mainInput.value || '';
                    }
                } catch (eSync) {}
                setTimeout(function() {
                    var expandInput = document.getElementById('pos-expand-search-input');
                    if (expandInput) expandInput.focus();
                }, 100);
                if (typeof showToast === 'function') showToast('⛶ سەبەتە تەمام شاشە', 'info');
            } else if (wasExpanded) {
                document.body.classList.remove('pos-cart-fullscreen');
                try {
                    var phBack = bill._posExpandPlaceholder || document.getElementById('pos-bill-expand-placeholder');
                    if (phBack && phBack.parentNode) {
                        phBack.parentNode.insertBefore(bill, phBack);
                        phBack.parentNode.removeChild(phBack);
                    }
                    bill._posExpandPlaceholder = null;
                } catch (eBackPortal) {}
                bill.style.removeProperty('position');
                bill.style.removeProperty('inset');
                bill.style.removeProperty('z-index');
                bill.style.removeProperty('height');
                try {
                    var mainInputBack = document.getElementById('pos-barcode-input');
                    var expandInputBack = document.getElementById('pos-expand-search-input');
                    if (mainInputBack && expandInputBack) {
                        mainInputBack.value = expandInputBack.value || '';
                    }
                } catch (eBack) {}
                window.syncPosExpandCustomerFields(true);
                try {
                    var storedW = parseInt(localStorage.getItem('cart_panel_width_pos'), 10);
                    if (typeof window.applyCartPanelWidthPos === 'function') {
                        window.applyCartPanelWidthPos(isFinite(storedW) && storedW > 0 ? storedW : 380, { toast: false });
                    }
                } catch (eRestore) {}
            }
        }
        window.togglePosMenu = togglePosMenu;
        window.openPosCartQtyPrompt = function(idP, noteEsc, price, saleUnitEsc, currentQty, isGift = false) {
            window.openManualQtyPrompt(null, currentQty, function(v) {
                commitCartItemQty(idP, noteEsc, price, saleUnitEsc, v, isGift);
            });
        };
        window.openPurchaseCartQtyPrompt = function(idx, currentQty) {
            window.openManualQtyPrompt(null, currentQty, function(v) {
                updatePurchaseCartLine(idx, 'qty', v, true);
            });
        };
        window.openPurchaseReturnCartQtyPrompt = function(idx, currentQty) {
            var maxQty = (typeof window.getPurchaseReturnMaxQtyForCartRow === 'function')
                ? window.getPurchaseReturnMaxQtyForCartRow(idx)
                : null;
            var title = null;
            if (maxQty != null && maxQty >= 0) {
                title = ((typeof t === 'function') ? t('pos_qty_prompt_title') : 'ژمارە بنووسە') +
                    ' · زۆرترین: ' + (typeof formatQtyForInput === 'function' ? formatQtyForInput(maxQty) : maxQty);
            }
            window.openManualQtyPrompt(title, currentQty, function(v) {
                var capped = v;
                if (maxQty != null && capped > maxQty + 0.0001) {
                    capped = maxQty;
                    if (typeof showToast === 'function') showToast('⚠️ ژمارە سنووردار کرا', 'warning');
                }
                updatePurchaseReturnCartLine(idx, 'qty', capped, true);
            });
        };

        function initCartPanelResizers() {
            var configs = [
                { key: 'pos', layout: '#view-pos .pos-layout', handle: '#view-pos [data-resize-handle="pos"]', bill: '#pos-bill-panel' },
                { key: 'returns', layout: '#view-returns-new .pos-layout, #view-returns-new .returns-layout', handle: '#view-returns-new [data-resize-handle="returns"]', bill: '#returns-bill-panel' },
                { key: 'purchase', layout: '#view-purchase .pos-layout, #view-purchase .returns-layout', handle: '#view-purchase [data-resize-handle="purchase"]', bill: '#purchase-cart-panel' },
                { key: 'purchase-returns', layout: '#view-purchase-returns .pos-layout, #view-purchase-returns .returns-layout', handle: '#view-purchase-returns [data-resize-handle="purchase-returns"]', bill: '#purchase-returns-cart-panel' },
                { key: 'waste', layout: '#view-waste .pos-layout, #view-waste .returns-layout', handle: '#view-waste [data-resize-handle="waste"]', bill: '#waste-bill-panel' }
            ];

            function readPx(value, fallback) {
                var parsed = parseFloat(value);
                return isFinite(parsed) ? parsed : fallback;
            }

            function uiScale() {
                try {
                    var s = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--pos-ui-scale'));
                    if (isFinite(s) && s >= 0.5 && s <= 2.5) return s;
                } catch (e) {}
                return 1;
            }

            function applyPanelWidth(layoutEl, billEl, widthPx, storageKey) {
                var width = Math.round(widthPx);
                if (width < 280) width = 280;
                if (width > 960) width = 960;
                if (cfgKeyIsPos(storageKey) && typeof window.applyCartPanelWidthPos === 'function') {
                    window.applyCartPanelWidthPos(width, { toast: false });
                    return width;
                }
                var wPx = width + 'px';
                layoutEl.style.setProperty('--cart-panel-width', wPx);
                layoutEl.style.setProperty('--cart-panel-max-width', '960px');
                billEl.style.setProperty('--cart-panel-width', wPx);
                billEl.style.setProperty('--cart-panel-max-width', '960px');
                if (!billEl.classList.contains('expanded')) {
                    billEl.style.setProperty('flex', '0 0 ' + wPx, 'important');
                    billEl.style.setProperty('width', wPx, 'important');
                    billEl.style.setProperty('min-width', '280px', 'important');
                    billEl.style.setProperty('max-width', '960px', 'important');
                }
                return width;
            }

            function cfgKeyIsPos(storageKey) {
                return storageKey === 'cart_panel_width_pos';
            }

            function getBounds(layoutEl) {
                var measuredLayout = layoutEl.clientWidth || 0;
                var layoutWidth = measuredLayout > 80 ? measuredLayout : (window.innerWidth || 1200);
                var minWidth = 280;
                var maxWidth = Math.min(960, Math.max(minWidth + 40, layoutWidth * 0.72));
                return { minWidth: minWidth, maxWidth: maxWidth };
            }

            function canResize(layoutEl, billEl) {
                if (!layoutEl || !billEl) return false;
                if (billEl.classList.contains('expanded')) return false;
                if (document.body.classList.contains('pos-cart-fullscreen')) return false;
                // Allow whenever layout is laid out horizontally (row / row-reverse)
                try {
                    var st = window.getComputedStyle(layoutEl);
                    var dir = String(st.flexDirection || '');
                    if (dir.indexOf('column') === 0) return false;
                    if (layoutEl.clientWidth < 120) return false;
                } catch (e) {
                    return false;
                }
                return true;
            }

            function widthFromPointer(layoutEl, billEl, clientX) {
                var layoutRect = layoutEl.getBoundingClientRect();
                var billRect = billEl.getBoundingClientRect();
                var scale = uiScale();
                // Cart on the visual left (RTL default) vs right
                var billCenter = billRect.left + billRect.width / 2;
                var layoutCenter = layoutRect.left + layoutRect.width / 2;
                var billOnLeft = billCenter <= layoutCenter;
                var visualW = billOnLeft
                    ? (clientX - layoutRect.left)
                    : (layoutRect.right - clientX);
                // Convert visual px → CSS px when UI zoom scales the shell
                var cssW = visualW / (scale || 1);
                return cssW;
            }

            configs.forEach(function(cfg) {
                var layoutEl = document.querySelector(cfg.layout);
                var handleEl = document.querySelector(cfg.handle);
                var billEl = document.querySelector(cfg.bill);
                if (!layoutEl || !handleEl || !billEl) return;

                var storageKey = 'cart_panel_width_' + cfg.key;
                try {
                    var storedWidth = readPx(localStorage.getItem(storageKey), NaN);
                    if (isFinite(storedWidth)) {
                        var bounds0 = getBounds(layoutEl);
                        var clamped0 = Math.min(bounds0.maxWidth, Math.max(bounds0.minWidth, storedWidth));
                        if (!(layoutEl.clientWidth > 80)) clamped0 = Math.min(960, Math.max(280, storedWidth));
                        applyPanelWidth(layoutEl, billEl, clamped0, storageKey);
                    }
                } catch (e) {}

                if (handleEl.dataset.resizeBound === '1') return;
                handleEl.dataset.resizeBound = '1';
                handleEl.setAttribute('title', 'ڕاکێشە ب ماوس — گەورە / بچووککرنا سەبەتێ');
                handleEl.style.cursor = 'col-resize';

                var dragging = false;
                var activePointerId = null;

                function startDrag(clientX, pointerId, ev) {
                    if (!canResize(layoutEl, billEl)) return false;
                    dragging = true;
                    activePointerId = pointerId != null ? pointerId : null;
                    handleEl.classList.add('is-active');
                    document.body.classList.add('pos-cart-resizing');
                    document.body.style.cursor = 'col-resize';
                    document.body.style.userSelect = 'none';
                    try {
                        if (ev && ev.target && typeof ev.target.setPointerCapture === 'function' && pointerId != null) {
                            ev.target.setPointerCapture(pointerId);
                        }
                    } catch (eCap) {}
                    return true;
                }

                function moveDrag(clientX) {
                    if (!dragging) return;
                    if (!canResize(layoutEl, billEl)) return;
                    var bounds = getBounds(layoutEl);
                    var raw = widthFromPointer(layoutEl, billEl, clientX);
                    var clamped = Math.min(bounds.maxWidth, Math.max(bounds.minWidth, raw));
                    var w = applyPanelWidth(layoutEl, billEl, clamped, storageKey);
                    handleEl.setAttribute('aria-valuenow', String(w));
                    try { localStorage.setItem(storageKey, String(w)); } catch (e) {}
                    var peek = document.getElementById('pos-cart-density-peek');
                    // temporarily show width on peek while dragging if density peek exists near POS tools
                    if (cfg.key === 'pos') {
                        var wPeek = document.getElementById('pos-cart-width-peek');
                        if (wPeek) wPeek.textContent = w + 'px';
                    }
                }

                function endDrag() {
                    if (!dragging) return;
                    dragging = false;
                    activePointerId = null;
                    handleEl.classList.remove('is-active');
                    document.body.classList.remove('pos-cart-resizing');
                    document.body.style.cursor = '';
                    document.body.style.userSelect = '';
                    var currentWidth = readPx(window.getComputedStyle(billEl).width, NaN);
                    var scale = uiScale();
                    if (isFinite(currentWidth) && scale > 0) {
                        // getComputedStyle width is CSS px (pre-transform)
                        var finalW = Math.round(currentWidth);
                        try { localStorage.setItem(storageKey, String(finalW)); } catch (e) {}
                        if (cfg.key === 'pos' && typeof window.showToast === 'function') {
                            window.showToast('🧺 سەبەتە: ' + finalW + 'px', 'info');
                        }
                    }
                }

                handleEl.addEventListener('pointerdown', function(event) {
                    if (event.pointerType === 'mouse' && event.button !== 0) return;
                    if (!startDrag(event.clientX, event.pointerId, event)) return;
                    event.preventDefault();
                    event.stopPropagation();
                });

                // Fallback for environments where pointer events are flaky
                handleEl.addEventListener('mousedown', function(event) {
                    if (event.button !== 0) return;
                    if (window.PointerEvent) return; // pointer path already handles it
                    if (!startDrag(event.clientX, null, event)) return;
                    event.preventDefault();
                });

                window.addEventListener('pointermove', function(event) {
                    if (!dragging) return;
                    if (activePointerId != null && event.pointerId !== activePointerId) return;
                    moveDrag(event.clientX);
                }, true);

                window.addEventListener('mousemove', function(event) {
                    if (!dragging) return;
                    if (window.PointerEvent && activePointerId != null) return;
                    moveDrag(event.clientX);
                }, true);

                window.addEventListener('pointerup', function(event) {
                    if (!dragging) return;
                    if (activePointerId != null && event.pointerId !== activePointerId) return;
                    endDrag();
                }, true);

                window.addEventListener('pointercancel', function() {
                    if (dragging) endDrag();
                }, true);

                window.addEventListener('mouseup', function() {
                    if (!dragging) return;
                    if (window.PointerEvent && activePointerId != null) return;
                    endDrag();
                }, true);
            });
        }
        window.initCartPanelResizers = initCartPanelResizers;

        function initCartPanelPinchDensity() {
            var panel = document.getElementById('pos-bill-panel');
            if (!panel || panel.dataset.cartPinchBound === '1') return;
            panel.dataset.cartPinchBound = '1';
            var startDist = 0;
            var startDensity = 100;
            panel.addEventListener('touchstart', function(e) {
                if (e.touches.length === 2) {
                    var dx = e.touches[0].clientX - e.touches[1].clientX;
                    var dy = e.touches[0].clientY - e.touches[1].clientY;
                    startDist = Math.hypot(dx, dy);
                    startDensity = parseInt(document.documentElement.getAttribute('data-cart-density'), 10) || 100;
                }
            }, { passive: true });
            panel.addEventListener('touchmove', function(e) {
                if (e.touches.length !== 2 || !(startDist > 0)) return;
                var dx = e.touches[0].clientX - e.touches[1].clientX;
                var dy = e.touches[0].clientY - e.touches[1].clientY;
                var dist = Math.hypot(dx, dy);
                var ratio = dist / startDist;
                if (typeof window.applyCartDensity === 'function') {
                    window.applyCartDensity(Math.round(startDensity * ratio));
                }
                e.preventDefault();
            }, { passive: false });
            panel.addEventListener('touchend', function() { startDist = 0; }, { passive: true });
            panel.addEventListener('touchcancel', function() { startDist = 0; }, { passive: true });
        }
        window.initCartPanelPinchDensity = initCartPanelPinchDensity;

        let isNavEditMode = false;
        let navEditModeHiddenSet = new Set();
        const MAIN_NAV_DEFAULT_ORDER = ['calendar','tables','pos','returns-new','debt','companies','warehouse','products','purchase','purchase-returns','delivery','expenses','waste','recipes','notifications','staff','settings','print-design','print-history'];

        function getMainNavHiddenIds() {
            try { return JSON.parse(localStorage.getItem('main_nav_hidden_ids') || '[]'); } catch(e) { return []; }
        }
        function setMainNavHiddenIds(arr) { try { localStorage.setItem('main_nav_hidden_ids', JSON.stringify(arr)); } catch(e) {} }

        /** Show/hide a section in the top menu bar (main-nav). */
        function setMainNavItemVisible(sectionId, visible) {
            if (!sectionId) return;
            var hidden = getMainNavHiddenIds();
            var idx = hidden.indexOf(sectionId);
            if (visible) {
                if (idx >= 0) {
                    hidden.splice(idx, 1);
                    setMainNavHiddenIds(hidden);
                }
            } else if (idx < 0) {
                hidden.push(sectionId);
                setMainNavHiddenIds(hidden);
            }
            if (typeof applyMenuSectionsState === 'function') applyMenuSectionsState();
            else {
                if (typeof renderMainNav === 'function') renderMainNav();
                if (typeof renderRightSidebar === 'function') renderRightSidebar();
            }
        }
        window.setMainNavItemVisible = setMainNavItemVisible;
        function isSettingTruthy(val) {
            return val === true || val === 1 || val === '1' || val === 'true';
        }
        /** Recipes / ڕەچەتە: تەنها کاتێک لە ڕێکخستن چالاک بکرێت. */
        function isRecipeFeatureEnabled() {
            var s = {};
            if (db && db.settings) {
                s = db.settings;
            } else {
                try {
                    var stored = localStorage.getItem('pos_system_features');
                    if (stored) s = JSON.parse(stored);
                } catch(e) {}
            }
            return isSettingTruthy(s.enableRecipe);
        }
        window.isRecipeFeatureEnabled = isRecipeFeatureEnabled;
        window.isSettingTruthy = isSettingTruthy;

        /** Nav item allowed for current business profile (user-enabled features override profile omissions). */
        function isNavItemAllowedByProfile(id, profile) {
            if (id === 'recipes') return isRecipeFeatureEnabled();
            if (!profile || !profile.visibleSections) return true;
            if (profile.visibleSections.indexOf(id) >= 0) return true;
            if (id === 'returns-new') return true;
            if (id === 'purchase' || id === 'purchase-returns') return true;
            return false;
        }

        function getFeatureHiddenNavIds() {
            var s = {};
            if (db && db.settings) s = db.settings;
            else {
                try {
                    var stored = localStorage.getItem('pos_system_features');
                    if (stored) s = JSON.parse(stored);
                } catch(e) {}
            }
            var hidden = [];
            if (!isRecipeFeatureEnabled()) hidden.push('recipes');
            if (s.enableDebt === false) hidden.push('debt');
            if (s.enableWaste === false) hidden.push('waste');
            if (s.showTables !== true) hidden.push('tables');
            if (s.enableWarehouse === false) hidden.push('warehouse');
            if (s.enableCompanies === false) hidden.push('companies');
            if (s.enablePurchase === false) { hidden.push('purchase'); hidden.push('purchase-returns'); }
            var deliveryOn = (typeof isPremiumSettingsFeatureEnabled === 'function')
                ? isPremiumSettingsFeatureEnabled('set-enable-delivery')
                : (s.enableDelivery === true);
            if (!deliveryOn) hidden.push('delivery');
            if (s.enableExpenses === false) hidden.push('expenses');
            if (s.enableCalendar === false) hidden.push('calendar');
            if (s.enableNotifications === false) hidden.push('notifications');
            if (s.enableStaff === false) hidden.push('staff');
            if (s.enableReturns === false) hidden.push('returns-new');
            
            // Also hide sections not in the current business profile
            var mode = (db && db.settings && db.settings.systemMode) ? db.settings.systemMode : 'general';
            var profile = (typeof getBusinessProfile === 'function') ? getBusinessProfile(mode) : null;
            if (profile && profile.visibleSections) {
                MAIN_NAV_DEFAULT_ORDER.forEach(function(id) {
                    if (isNavItemAllowedByProfile(id, profile)) return;
                    if (hidden.indexOf(id) < 0) hidden.push(id);
                });
            }
            
            return hidden;
        }
        function persistSystemFeaturesToStorage() {
            if (!db || !db.settings) return;
            try {
                var o = {
                    enableRecipe: isSettingTruthy(db.settings.enableRecipe),
                    enableDebt: !!db.settings.enableDebt,
                    enableWaste: !!db.settings.enableWaste,
                    showTables: db.settings.showTables === true,
                    enableWarehouse: db.settings.enableWarehouse !== false,
                    enableCompanies: db.settings.enableCompanies !== false,
                    enablePurchase: db.settings.enablePurchase !== false,
                    enableReports: db.settings.enableReports !== false,
                    enableDelivery: db.settings.enableDelivery === true,
                    enableExpenses: db.settings.enableExpenses !== false,
                    enableCalendar: db.settings.enableCalendar !== false,
                    enableNotifications: db.settings.enableNotifications !== false,
                    enableStaff: db.settings.enableStaff !== false
                };
                localStorage.setItem('pos_system_features', JSON.stringify(o));
            } catch(e) {}
        }
        function applyFeatureVisibility() {
            var hidden = getFeatureHiddenNavIds();
            var active = document.querySelector('.workspace.active');
            var viewId = active && active.id ? active.id.replace('view-', '') : '';
            var mainNavId = (viewId && viewId.indexOf('warehouse') === 0) ? 'warehouse' : viewId;
            if (mainNavId && hidden.indexOf(mainNavId) >= 0 && typeof nav === 'function') nav('dash');
            if (typeof renderMainNav === 'function') renderMainNav();
            if (typeof renderRightSidebar === 'function') renderRightSidebar();
            active = document.querySelector('.workspace.active');
            if (active) {
                if (active.id === 'view-dash' && typeof renderDashboard === 'function') renderDashboard();
                if (active.id === 'view-home' && typeof renderHomeView === 'function') renderHomeView();
            }
            if (typeof updatePosCardToolsBtn === 'function') updatePosCardToolsBtn();
            if (typeof window.syncPaymentToggles === 'function') window.syncPaymentToggles();
            if (typeof window.syncCartDeliveryUI === 'function') window.syncCartDeliveryUI();
        }
        function getMainNavOrder() {
            var mode = (db && db.settings && db.settings.systemMode) ? db.settings.systemMode : 'general';
            var profile = (typeof getBusinessProfile === 'function') ? getBusinessProfile(mode) : null;
            var order = (profile && profile.navOrder && profile.navOrder.length) ? profile.navOrder.slice() : null;
            
            // If the user has a saved order, we should only use it if it matches the current profile's items
            // But to ensure distinct modes have distinct menus, we will prioritize the profile's navOrder
            if (!order) {
                try {
                    var saved = localStorage.getItem('main_nav_order');
                    if (saved) { var o = JSON.parse(saved); if (Array.isArray(o) && o.length) order = o; }
                } catch(e) {}
            }
            if (!order) order = MAIN_NAV_DEFAULT_ORDER.slice();
            
            // If we are using a specific profile, only include items that are in the profile's visibleSections
            if (profile && profile.visibleSections) {
                order = order.filter(function(id) {
                    return isNavItemAllowedByProfile(id, profile);
                });
            }

            // Ensure every default nav item appears even if saved order was from an older version
            var defaultIds = MAIN_NAV_DEFAULT_ORDER.filter(function(id) { return id !== 'zakat'; });
            defaultIds.forEach(function(id) {
                if (order.indexOf(id) < 0) {
                    if (isNavItemAllowedByProfile(id, profile)) {
                        var defIdx = MAIN_NAV_DEFAULT_ORDER.indexOf(id);
                        var prevId = defIdx > 0 ? MAIN_NAV_DEFAULT_ORDER[defIdx - 1] : null;
                        var insertIdx = prevId ? order.indexOf(prevId) : -1;
                        if (insertIdx >= 0) {
                            order.splice(insertIdx + 1, 0, id);
                        } else {
                            order.push(id);
                        }
                    }
                }
            });
            order = order.filter(function(id) { return id !== 'zakat' && id !== 'shop-ai' && id !== 'dash' && id !== 'mega-stats' && id !== 'home' && id !== 'reports'; });

            // Force calendar to the first position if it exists
            var calIdx = order.indexOf('calendar');
            if (calIdx > 0) {
                order.splice(calIdx, 1);
                order.unshift('calendar');
            } else if (calIdx < 0) {
                // If somehow it's not in the list (filtered out or missing), 
                // and it's allowed, add it at the start.
                if (isNavItemAllowedByProfile('calendar', profile)) {
                    order.unshift('calendar');
                }
            }
            return order;
        }
        function setMainNavOrder(arr) { try { localStorage.setItem('main_nav_order', JSON.stringify(arr)); } catch(e) {} }

        function getNavItemLabel(id) {
            if (id !== 'tables') return getBreadcrumbLabel(id);
            var mode = (db && db.settings && db.settings.systemMode) ? db.settings.systemMode : 'general';
            var profile = (typeof getBusinessProfile === 'function') ? getBusinessProfile(mode) : null;
            return (profile && profile.tablesLabel) ? profile.tablesLabel : getBreadcrumbLabel(id);
        }
        /** Short label for table/cart (e.g. سەبەت for market, مێز for restaurant) - used in toasts, bill header, buttons */
        function getTablesLabelShort() {
            var mode = (db && db.settings && db.settings.systemMode) ? db.settings.systemMode : 'general';
            var profile = (typeof getBusinessProfile === 'function') ? getBusinessProfile(mode) : null;
            var full = (profile && profile.tablesLabel) ? profile.tablesLabel : 'مێز';
            var short = (full.indexOf(' (') >= 0) ? full.substring(0, full.indexOf(' (')).trim() : full;
            return short || 'مێز';
        }
        /** Apply table/cart labels and icons from business profile (market = سلة/سەبەت, restaurant = مێز) */
        function applyTablesViewLabels() {
            if (!db || !db.settings) return;
            var mode = db.settings.systemMode || 'general';
            var profile = (typeof getBusinessProfile === 'function') ? getBusinessProfile(mode) : null;
            if (!profile) return;
            var label = profile.tablesLabel || 'مێز';
            var short = getTablesLabelShort();
            var icon = (profile.icons && profile.icons.tables) ? profile.icons.tables : 'fa-th';
            var viewTables = document.getElementById('view-tables');
            if (viewTables) {
                var titleWrap = viewTables.querySelector('.tables-page-title, h2');
                if (titleWrap) {
                    var span = titleWrap.querySelector('span[data-i18n="view_tables_title"]');
                    if (span) {
                        var viewTitle = (mode === 'market') ? 'نەخشێ سەبەتان' : (mode === 'pharmacy' ? 'وەسڵێن دەرمانان' : (mode === 'company' ? 'داواکاریێن کۆمپانیێ' : (mode === 'school' ? 'نەخشێ پۆلان' : 'نەخشێ ' + short + 'ان')));
                        span.textContent = viewTitle;
                    }
                    var iconEl = viewTables.querySelector('.tables-page-icon i, .tables-page-title i, h2 i');
                    if (iconEl && iconEl.classList && iconEl.classList.contains('fas')) { iconEl.className = 'fas ' + icon; }
                }
                var addBtn = viewTables.querySelector('[data-i18n="btn_add_table"]');
                if (addBtn) addBtn.textContent = '+ ' + short;
            }
            var dashCard = document.querySelector('#dash-active-title [data-i18n="dash_active_tables"], #dash-active-title span');
            if (dashCard) dashCard.textContent = short + 'ێن چالاک';
        }

        function renderMainNav() {
            var mainNav = document.getElementById('main-nav');
            if (!mainNav) return;
            var order = getMainNavOrder();
            var featureHidden = getFeatureHiddenNavIds();
            var html = '';
            var isFirst = true;
            var activeWs = document.querySelector('.workspace.active');
            var activeNavId = '';
            if (activeWs && activeWs.id && activeWs.id.indexOf('view-') === 0) {
                activeNavId = activeWs.id.slice(5);
                if (activeNavId === 'home') activeNavId = '';
                if (activeNavId.indexOf('warehouse') === 0) activeNavId = 'warehouse';
                if (activeNavId === 'dash') activeNavId = 'calendar';
            }
            for (var i = 0; i < order.length; i++) {
                var id = order[i];
                if (featureHidden.indexOf(id) >= 0) continue;
                if (!canAccessView(id)) continue;
                var icon = getBreadcrumbIcon(id);
                var label = getNavItemLabel(id);
                var onclick = (id === 'settings') ? 'handleSettingsNavClick()' : (id === 'returns-new' ? 'openReturnsOptionsModal(event)' : (id === 'pos' ? 'openPosOptionsModal(event)' : (id === 'purchase' ? 'openPurchaseOptionsModal(event)' : (id === 'purchase-returns' ? 'openPurchaseReturnsOptionsModal(event)' : (id === 'companies' ? "window._companyProfileDefaultTab='inventory'; nav('companies')" : "nav('" + id.replace(/'/g, "\\'") + "')")))));
                var markActive = activeNavId ? (id === activeNavId) : isFirst;
                var cls = 'nav-item' + (id === 'print-history' || id === 'print-design' ? ' protected' : '') + (markActive ? ' active' : '');
                isFirst = false;
                var badge = (id === 'notifications') ? ' <span id="nav-notif-badge" style="display:none; background:#ef4444; color:white; padding:2px 6px; border-radius:10px; font-size:0.7rem; margin-right:auto;">0</span>' : '';
                html += '<div class="' + cls + '" id="nav-' + escapeHtml(id) + '" data-nav="' + escapeHtml(id) + '" onclick="' + onclick + '"><span class="nav-item-drag-handle" draggable="true" data-i18n-title="nav_drag_reorder_title"><i class="fas fa-grip-vertical"></i></span><i class="fas ' + icon + '"></i> ' + navLabelSpanHtml(id, label) + badge + '</div>';
            }
            mainNav.innerHTML = html || '';
            if (typeof applyMenuSectionsState === 'function') applyMenuSectionsState();
        }

        function applyMainNavOrder() {
            const mainNav = document.getElementById('main-nav');
            if (!mainNav) return;
            const order = getMainNavOrder();
            const items = mainNav.querySelectorAll('.nav-item[data-nav]');
            const byId = {};
            items.forEach(el => { const id = el.getAttribute('data-nav'); if (id) byId[id] = el; });
            const seen = new Set();
            order.forEach(id => { if (byId[id] && !seen.has(id)) { mainNav.appendChild(byId[id]); seen.add(id); } });
            items.forEach(el => { const id = el.getAttribute('data-nav'); if (id && !seen.has(id)) { mainNav.appendChild(el); seen.add(id); } });
        }

        function saveMainNavOrderFromDOM() {
            const mainNav = document.getElementById('main-nav');
            if (!mainNav) return;
            const order = Array.from(mainNav.querySelectorAll('.nav-item[data-nav]')).map(el => el.getAttribute('data-nav')).filter(Boolean);
            if (order.length) setMainNavOrder(order);
        }

        function toggleMenuSections() {
            const mainNav = document.getElementById('main-nav');
            if (!mainNav) return;
            if (isNavEditMode) {
                exitNavEditMode();
            } else {
                enterNavEditMode(); 
            }
        }

        let navDragSourceEl = null; 
        let navDropTargetEl = null;

        function enterNavEditMode() {
            const mainNav = document.getElementById('main-nav');
            const labelEl = document.getElementById('label-toggle-menu-sections');
            if (!mainNav) return;
            isNavEditMode = true;
            mainNav.classList.add('nav-edit-mode');
            mainNav.querySelectorAll('.nav-item').forEach(el => el.classList.remove('nav-item-hidden'));
            navEditModeHiddenSet = new Set(getMainNavHiddenIds());
            updateNavItemsMarkedState(); 
            /* کێشان بتنێ ژ دەستکی: draggable ل سەر کارتێ دانەنێ */
            if (labelEl) labelEl.textContent = 'پاشکەفتکرن و دەرکەفتن';
            document.getElementById('btn-toggle-menu-sections').title = 'پاشکەفتکرنا هەلبژاردنێ و دەرکەفتن ژ دۆخێ دەستکاریێ';
        }

        function exitNavEditMode() {
            const mainNav = document.getElementById('main-nav');
            const labelEl = document.getElementById('label-toggle-menu-sections');
            if (!mainNav) return;
            setMainNavHiddenIds(Array.from(navEditModeHiddenSet));
            mainNav.querySelectorAll('.nav-item').forEach(el => {
                el.classList.remove('nav-item-dragging', 'nav-item-drop-target');
            });
            navDragSourceEl = null;
            navDropTargetEl = null;
            isNavEditMode = false;
            mainNav.classList.remove('nav-edit-mode');
            if (labelEl) labelEl.textContent = 'بەشێن لیستێ';
            document.getElementById('btn-toggle-menu-sections').title = 'ڤەشارتن یان نیشاندانا بەشێن لیستا سەرەکی';
            applyMenuSectionsState();
        }

        function updateNavItemsMarkedState() {
            const mainNav = document.getElementById('main-nav');
            if (!mainNav) return;
            mainNav.querySelectorAll('.nav-item[data-nav]').forEach(el => {
                const key = el.getAttribute('data-nav');
                if (navEditModeHiddenSet.has(key)) el.classList.add('nav-item-marked-hidden');
                else el.classList.remove('nav-item-marked-hidden');
            });
        }

        function toggleNavItemInEditMode(key) {
            if (!key) return;
            if (navEditModeHiddenSet.has(key)) navEditModeHiddenSet.delete(key);
            else navEditModeHiddenSet.add(key);
            const el = document.querySelector('#main-nav .nav-item[data-nav="' + key + '"]');
            if (el) {
                if (navEditModeHiddenSet.has(key)) el.classList.add('nav-item-marked-hidden');
                else el.classList.remove('nav-item-marked-hidden');
            }
        }

        function applyMenuSectionsState() {
            const mainNav = document.getElementById('main-nav');
            const iconEl = document.getElementById('icon-toggle-menu-sections');
            const labelEl = document.getElementById('label-toggle-menu-sections');
            if (mainNav) {
                if (typeof applyMainNavOrder === 'function') applyMainNavOrder();
                const hiddenIds = getMainNavHiddenIds();
                mainNav.querySelectorAll('.nav-item[data-nav]').forEach(el => {
                    const key = el.getAttribute('data-nav');
                    if (hiddenIds.indexOf(key) >= 0) el.classList.add('nav-item-hidden');
                    else el.classList.remove('nav-item-hidden');
                    el.classList.remove('nav-item-marked-hidden');
                });
            }
            if (labelEl && !isNavEditMode) labelEl.textContent = 'بەشێن لیستێ';
            if (typeof renderRightSidebar === 'function') renderRightSidebar();
        }
        window.applyMenuSectionsState = applyMenuSectionsState;

        (function initNavEditModeClick() {
            const mainNav = document.getElementById('main-nav');
            if (!mainNav) return;
            mainNav.addEventListener('click', function(e) { /* کلیککرنا لسەر دەستکی ڤەشارتنێ ناگوهۆریت */
                if (!mainNav.classList.contains('nav-edit-mode')) return; 
                if (navDragSourceEl) return;
                if (e.target.closest('.nav-item-drag-handle')) return; /* النقر على المقبض لا يبدل الإخفاء */
                const item = e.target.closest('.nav-item');
                if (!item) return;
                const key = item.getAttribute('data-nav');
                if (!key) return;
                e.preventDefault();
                e.stopPropagation();
                toggleNavItemInEditMode(key);
            }, true);
        })();

        (function initNavDragDrop() {
            const mainNav = document.getElementById('main-nav');
            if (!mainNav) return;
            mainNav.addEventListener('dragstart', function(e) { /* کێشان بتنێ ژ دەستکی کار دکەت */
                if (!mainNav.classList.contains('nav-edit-mode')) return;
                if (!e.target.closest('.nav-item-drag-handle')) return; /* کێشان بتنێ ژ دەستکی کار دکەت */
                const item = e.target.closest('.nav-item[data-nav]');
                if (!item) return;
                navDragSourceEl = item;
                item.classList.add('nav-item-dragging');
                e.dataTransfer.effectAllowed = 'move';
                e.dataTransfer.setData('text/plain', item.getAttribute('data-nav'));
                e.dataTransfer.setDragImage(item, 0, 0);
                setTimeout(function() { if (item.parentNode) item.classList.add('nav-item-dragging'); }, 0);
            }, false);
            mainNav.addEventListener('dragover', function(e) {
                if (!mainNav.classList.contains('nav-edit-mode') || !navDragSourceEl) return; 
                e.preventDefault();
                e.dataTransfer.dropEffect = 'move';
                const item = e.target.closest('.nav-item[data-nav]');
                if (item && item !== navDragSourceEl) {
                    if (navDropTargetEl && navDropTargetEl !== item) navDropTargetEl.classList.remove('nav-item-drop-target');
                    navDropTargetEl = item;
                    item.classList.add('nav-item-drop-target');
                }
            }, false);
            mainNav.addEventListener('dragleave', function(e) {
                const item = e.target.closest('.nav-item[data-nav]');
                if (item && item === navDropTargetEl && (!e.relatedTarget || !mainNav.contains(e.relatedTarget))) { 
                    item.classList.remove('nav-item-drop-target');
                    navDropTargetEl = null;
                }
            }, false);
            mainNav.addEventListener('drop', function(e) {
                if (!mainNav.classList.contains('nav-edit-mode') || !navDragSourceEl) return; 
                e.preventDefault();
                if (navDropTargetEl) {
                    navDropTargetEl.classList.remove('nav-item-drop-target');
                    if (navDropTargetEl !== navDragSourceEl) {
                        mainNav.insertBefore(navDragSourceEl, navDropTargetEl);
                        saveMainNavOrderFromDOM();
                    }
                    navDropTargetEl = null;
                }
                navDragSourceEl.classList.remove('nav-item-dragging');
                navDragSourceEl = null;
            }, false);
            mainNav.addEventListener('dragend', function(e) {
                const item = e.target.closest('.nav-item[data-nav]');
                if (item) item.classList.remove('nav-item-dragging'); 
                if (navDropTargetEl) {
                    navDropTargetEl.classList.remove('nav-item-drop-target');
                    navDropTargetEl = null;
                }
                navDragSourceEl = null;
            }, false);
        })();
        
        function toggleFooterPos() {
            const bill = document.getElementById('pos-bill-panel');
            if(bill) {
                bill.classList.toggle('footer-right');
            }
        }

        function renderPOSCategories() {
            const container = document.getElementById('category-tabs');
            if (!container) return;
            var html = [
                '<button type="button" class="cat-btn' + (activeCategory === 'all' ? ' active' : '') + '" data-pos-cat="all" onclick="setCategory(\'all\')"><i class="fas fa-border-all" aria-hidden="true"></i> ' + escapeHtml((typeof t === 'function') ? t('pos_category_all') : 'هەمی') + '</button>',
                '<button type="button" class="cat-btn cat-btn--hot' + (activeCategory === 'top_selling' ? ' active' : '') + '" data-pos-cat="top_selling" onclick="setCategory(\'top_selling\')"><i class="fas fa-fire" aria-hidden="true"></i> ' + escapeHtml((typeof t === 'function') ? t('pos_category_top') : 'پڕفرۆشترین') + '</button>'
            ];
            const usedCategories = new Set((db.products || []).map(function (p) { return String(p.cat || '').trim(); }).filter(Boolean));
            let sourceCats = (db.categories && db.categories.length) ? db.categories.slice() : Array.from(usedCategories);
            const cats = sourceCats.map(function(c) { return String(c || '').trim(); }).filter(function (c) { return c && usedCategories.has(c); }).sort();
            cats.forEach(function (c) {
                var safeArg = c.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
                html.push('<button type="button" class="cat-btn' + (activeCategory === c ? ' active' : '') + '" data-pos-cat="' + escapeHtml(c) + '" onclick="setCategory(\'' + escapeHtml(safeArg) + '\')"><i class="fas fa-folder-open" aria-hidden="true"></i> ' + escapeHtml(c) + '</button>');
            });
            container.innerHTML = html.join('');
            if (typeof refreshPOSCategoryTabsScrollUi === 'function') {
                requestAnimationFrame(function() { refreshPOSCategoryTabsScrollUi(); });
            }
        }

        function highlightPOSCategoryTab(cat) {
            var container = document.getElementById('category-tabs');
            if (!container) return;
            var catStr = String(cat == null ? 'all' : cat);
            var btns = container.querySelectorAll('.cat-btn');
            for (var i = 0; i < btns.length; i++) {
                var btn = btns[i];
                var val = btn.getAttribute('data-pos-cat');
                if (val == null) {
                    var oc = btn.getAttribute('onclick') || '';
                    var m = oc.match(/setCategory\('([^']*)'\)/);
                    val = m ? m[1] : '';
                }
                if (val === catStr) btn.classList.add('active');
                else btn.classList.remove('active');
            }
        }
        window.highlightPOSCategoryTab = highlightPOSCategoryTab;

        function scrollPOSCategoryTabs(towardVisualLeft) {
            scrollTxnCategoryTabs('category-tabs', towardVisualLeft);
        }
        window.scrollPOSCategoryTabs = scrollPOSCategoryTabs;

        function scrollTxnCategoryTabs(tabsId, towardVisualLeft) {
            var el = document.getElementById(tabsId);
            if (!el) return;
            var amount = Math.min(340, Math.max(80, Math.floor(el.clientWidth * 0.55)));
            el.scrollBy({ left: towardVisualLeft ? -amount : amount, behavior: 'smooth' });
        }
        window.scrollTxnCategoryTabs = scrollTxnCategoryTabs;

        function refreshPOSCategoryTabsScrollButtons() {
            var el = document.getElementById('category-tabs');
            var wrap = document.getElementById('category-tabs-scroll-wrap');
            if (!el || !wrap) return;
            var tol = 4;
            var maxS = el.scrollWidth - el.clientWidth;
            if (maxS <= 0) return;
            var sl = el.scrollLeft;
            var atStart = Math.abs(sl) <= tol;
            var atEnd = Math.abs(sl - maxS) <= tol;
            var prevBtn = wrap.querySelector('[data-cat-scroll="prev"]');
            var nextBtn = wrap.querySelector('[data-cat-scroll="next"]');
            if (prevBtn) prevBtn.disabled = atStart;
            if (nextBtn) nextBtn.disabled = atEnd;
        }

        function refreshPOSCategoryTabsScrollUi() {
            refreshTxnCategoryTabsScrollUi('category-tabs');
        }
        window.refreshPOSCategoryTabsScrollUi = refreshPOSCategoryTabsScrollUi;

        function refreshTxnCategoryTabsScrollUi(tabsId) {
            var id = tabsId || 'category-tabs';
            var el = document.getElementById(id);
            var wrap = document.getElementById(id + '-scroll-wrap');
            if (!el || !wrap) return;
            var overflow = el.scrollWidth > el.clientWidth + 3;
            wrap.classList.toggle('category-tabs-scroll--overflow', overflow);
            if (!overflow) {
                var prev = wrap.querySelector('[data-cat-scroll="prev"]');
                var next = wrap.querySelector('[data-cat-scroll="next"]');
                if (prev) prev.disabled = false;
                if (next) next.disabled = false;
                return;
            }
            if (el.dataset.catScrollBound !== '1') {
                el.dataset.catScrollBound = '1';
                el.addEventListener('scroll', function() {
                    var tol = 4;
                    var maxS = el.scrollWidth - el.clientWidth;
                    if (maxS <= 0) return;
                    var sl = el.scrollLeft;
                    var atStart = Math.abs(sl) <= tol;
                    var atEnd = Math.abs(sl - maxS) <= tol;
                    var prevBtn = wrap.querySelector('[data-cat-scroll="prev"]');
                    var nextBtn = wrap.querySelector('[data-cat-scroll="next"]');
                    if (prevBtn) prevBtn.disabled = atStart;
                    if (nextBtn) nextBtn.disabled = atEnd;
                }, { passive: true });
            }
            var tol2 = 4;
            var maxS2 = el.scrollWidth - el.clientWidth;
            var sl2 = el.scrollLeft;
            var prevBtn2 = wrap.querySelector('[data-cat-scroll="prev"]');
            var nextBtn2 = wrap.querySelector('[data-cat-scroll="next"]');
            if (prevBtn2) prevBtn2.disabled = Math.abs(sl2) <= tol2;
            if (nextBtn2) nextBtn2.disabled = Math.abs(sl2 - maxS2) <= tol2;
        }
        window.refreshTxnCategoryTabsScrollUi = refreshTxnCategoryTabsScrollUi;

        (function bindPOSCategoryTabsResizeRefresh() {
            if (window.__posCatTabsResizeBound) return;
            window.__posCatTabsResizeBound = true;
            var t;
            window.addEventListener('resize', function() {
                clearTimeout(t);
                t = setTimeout(function() { refreshPOSCategoryTabsScrollUi(); }, 120);
            });
        })();

        /** One listener — survives renderPOSMenu innerHTML; fixes missed taps on weak laptops. */
        (function bindPosProductCardClicks() {
            if (window.__posProductClickDelegate) return;
            window.__posProductClickDelegate = true;
            function handlePosProductCardTap(e) {
                if (e.type !== 'click') return;
                if (e.__posAddHandled) return;
                if (window._posCardTouchMoved) return;
                var t = e.target;
                if (!t || !t.closest) return;
                var viewPos = document.getElementById('view-pos');
                if (!viewPos || !viewPos.classList.contains('active')) return;
                if (t.closest('.pos-pin-btn')) return;
                if (t.closest('.pos-cost-btn')) return;
                var card = t.closest('#pos-products .unified-product-card.pos-sale-card:not(.unified-card-disabled)');
                if (!card) return;
                var pid = card.getAttribute('data-product-id');
                if (!pid) return;
                e.__posAddHandled = true;
                if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
                var unit = card.getAttribute('data-sale-unit') || (typeof posSelectedUnit !== 'undefined' ? posSelectedUnit : 'piece');
                if (typeof window.addToBill === 'function') window.addToBill(pid, unit);
            }
            document.addEventListener('click', handlePosProductCardTap, true);
            var _posCardTouchStartY = 0;
            document.addEventListener('touchstart', function(ev) {
                if (!ev.touches || !ev.touches.length) return;
                var card = ev.target && ev.target.closest ? ev.target.closest('#pos-products .unified-product-card') : null;
                window._posCardTouchMoved = !card;
                if (card) _posCardTouchStartY = ev.touches[0].clientY;
            }, { passive: true, capture: true });
            document.addEventListener('touchmove', function(ev) {
                if (!ev.touches || !ev.touches.length) return;
                if (Math.abs(ev.touches[0].clientY - _posCardTouchStartY) > 12) window._posCardTouchMoved = true;
            }, { passive: true, capture: true });
            document.addEventListener('touchend', function() {
                setTimeout(function() { window._posCardTouchMoved = false; }, 0);
            }, { passive: true, capture: true });
        })();

        function setCategory(cat) {
            if (cat == null || cat === '') cat = 'all';
            activeCategory = String(cat).trim() || 'all';
            if (typeof highlightPOSCategoryTab === 'function') highlightPOSCategoryTab(activeCategory);
            var q = (typeof getCurrentPOSSearch === 'function') ? getCurrentPOSSearch() : '';
            if (typeof renderPOSMenu === 'function') renderPOSMenu(q || '', true);
            if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('pos', { clear: false, delay: 30 });
        }
        window.setCategory = setCategory;

        function setPOSUnit(unit) {
            posSelectedUnit = unit;
            updatePOSUnitButtons();
            if (typeof renderPOSMenu === 'function') {
                var searchInput = document.getElementById('pos-barcode-input');
                renderPOSMenu(searchInput ? searchInput.value : '');
            }
            if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('pos', { clear: false, delay: 30 });
        }
        function isProductForSale(p) {
            if (!p) return false;
            var v = p.forSale;
            return v !== false && v !== 0 && v !== '0' && v !== 'false';
        }
        window.isProductForSale = isProductForSale;

        function productMatchesUnitFilter(p, unit, isPurchase = false) {
            if (!p) return false;
            if (!isPurchase && !isProductForSale(p)) return false;
            if (unit === 'piece') return true;
            if (unit === 'carton') {
                if (p.unit_show_carton !== undefined && p.unit_show_carton !== null && Number(p.unit_show_carton) === 0) return false;
                var pc = typeof catalogIqdFromUsdField === 'function' ? catalogIqdFromUsdField(p, 'price_carton_usd', 'price_carton') : Number(p.price_carton);
                var pcc = Number(p.packs_per_carton);
                var cost_c = typeof catalogIqdFromUsdField === 'function' ? catalogIqdFromUsdField(p, 'cost_carton_usd', 'cost_carton') : Number(p.cost_carton);
                var hasCarton = (!isNaN(pcc) && pcc > 1);
                if (isPurchase) return hasCarton || (!isNaN(cost_c) && cost_c > 0);
                return hasCarton || (!isNaN(pc) && pc > 0);
            }
            if (unit === 'pack') {
                if (p.unit_show_pack !== undefined && p.unit_show_pack !== null && Number(p.unit_show_pack) === 0) return false;
                var pp = typeof catalogIqdFromUsdField === 'function' ? catalogIqdFromUsdField(p, 'price_pack_usd', 'price_pack') : Number(p.price_pack);
                var ppp = Number(p.pieces_per_pack);
                var cost_p = typeof catalogIqdFromUsdField === 'function' ? catalogIqdFromUsdField(p, 'cost_pack_usd', 'cost_pack') : Number(p.cost_pack);
                var hasPack = (!isNaN(ppp) && ppp > 1);
                if (isPurchase) return hasPack || (!isNaN(cost_p) && cost_p > 0);
                return hasPack || (!isNaN(pp) && pp > 0);
            }
            return true;
        }
        window.productMatchesUnitFilter = productMatchesUnitFilter;
        function updatePOSUnitButtons() {
            var u = typeof posSelectedUnit !== 'undefined' ? posSelectedUnit : 'piece';
            ['carton', 'pack', 'piece'].forEach(function(unit) {
                var btn = document.getElementById('btn-pos-unit-' + unit);
                if (btn) {
                    if (unit === u) { btn.classList.add('active'); btn.setAttribute('aria-pressed', 'true'); }
                    else { btn.classList.remove('active'); btn.setAttribute('aria-pressed', 'false'); }
                }
                var btnExpand = document.getElementById('btn-pos-expand-unit-' + unit);
                if (btnExpand) {
                    if (unit === u) { btnExpand.classList.add('active'); btnExpand.setAttribute('aria-pressed', 'true'); }
                    else { btnExpand.classList.remove('active'); btnExpand.setAttribute('aria-pressed', 'false'); }
                }
            });
            if (typeof applyJewelryUnitLabels === 'function') applyJewelryUnitLabels();
        }
        /** Update only qty badges and card state for all visible POS cards — no innerHTML, zero flicker. */
        function updatePOSMenuUnitOnly() {
            var container = document.getElementById('pos-products');
            if (!container) return;
            var cards = container.querySelectorAll('.p-card[data-product-id]');
            var prods = db.products || [];
            cards.forEach(function(card) {
                var pid = parseInt(card.getAttribute('data-product-id'), 10);
                var prod = prods.find(function(p) { return String(p.id) === String(pid); });
                if (prod && typeof updateProductCardQty === 'function') updateProductCardQty(pid, typeof getDisplayQty === 'function' ? getDisplayQty(prod) : (prod.qty || 0), prod.trackStock);
            });
        }
        
        /** Lowercase + trim + Arabic/Persian digits → Latin (barcode / SKU search & hardware scanners). */
        function normalizeBarcodeSearchInput(s) {
            if (s == null) return '';
            var t = String(s).trim();
            if (!t) return '';
            t = t.replace(/[٠-٩]/g, function(d) { return String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)); });
            t = t.replace(/[\u06F0-\u06F9]/g, function(ch) { return String(ch.charCodeAt(0) - 0x06F0); });
            t = t.replace(/[\u0660-\u0669]/g, function(ch) { return String(ch.charCodeAt(0) - 0x0660); });
            return t.toLowerCase();
        }

        /** Fix double-fire scanner input (same barcode twice in one field). */
        function sanitizeScannerBarcodeInput(val) {
            val = String(val || '').trim();
            if (!val) return '';
            
            // Check for exact literal repetition first (works for both numeric and alphanumeric).
            if (val.length >= 16 && val.length % 2 === 0) {
                var half = val.length / 2;
                if (val.slice(0, half) === val.slice(half)) {
                    return val.slice(0, half);
                }
            }
            
            var eanLens = [13, 12, 14, 8];
            for (var ei = 0; ei < eanLens.length; ei++) {
                var len = eanLens[ei];
                if (val.length >= len * 2 && val.slice(0, len) === val.slice(len, len * 2)) {
                    return val.slice(0, len);
                }
            }

            // Alphanumeric barcodes (containing letters/dashes/chars) should NOT have non-digits stripped.
            var hasNonDigits = /\D/.test(val);
            if (hasNonDigits) {
                return val;
            }

            // Purely numeric barcode: execute original sanitization logic
            var digits = val;
            if (digits.length > 15 && window._posScanIndex && window._posScanIndex.exact) {
                for (var si = 0; si < eanLens.length; si++) {
                    var slen = eanLens[si];
                    if (digits.length >= slen) {
                        var sub = digits.slice(0, slen);
                        if (window._posScanIndex.exact[sub]) return sub;
                    }
                }
            }
            if (digits.length > 20) return digits.slice(0, 14);
            return digits;
        }
        window.sanitizeScannerBarcodeInput = sanitizeScannerBarcodeInput;

        var _posScanQueue = [];
        var _posScanDraining = false;

        function posDrainBarcodeScanQueue() {
            if (!_posScanQueue.length) {
                _posScanDraining = false;
                window._posScanQueueBusy = false;
                if (typeof posResumeCatalogBackgroundLoad === 'function') posResumeCatalogBackgroundLoad();
                return;
            }
            _posScanDraining = true;
            window._posScanQueueBusy = true;
            if (typeof posPauseCatalogBackground === 'function') posPauseCatalogBackground();
            var job = _posScanQueue.shift();
            processBarcodeOrSearchAsync(job.val, job.inputEl, job.opts).then(function () {
                // Drain ASAP for burst scanning (was 30ms — felt slow on multi-scan)
                if (typeof queueMicrotask === 'function') queueMicrotask(posDrainBarcodeScanQueue);
                else setTimeout(posDrainBarcodeScanQueue, 0);
            }).catch(function () {
                if (typeof queueMicrotask === 'function') queueMicrotask(posDrainBarcodeScanQueue);
                else setTimeout(posDrainBarcodeScanQueue, 0);
            });
        }

        function posEnqueueBarcodeScan(val, inputEl, opts) {
            opts = opts || {};
            val = sanitizeScannerBarcodeInput(val);
            if (!val) return;
            if (inputEl) {
                inputEl.value = '';
                try { inputEl.focus(); } catch (eFocus) {}
            }
            // Fast path: exact barcode already in memory — sync add (no queue/async delay)
            var nv = typeof normalizeBarcodeSearchInput === 'function'
                ? normalizeBarcodeSearchInput(val)
                : String(val).trim().toLowerCase();
            var indexed = !!(window._posScanIndex && window._posScanIndex.exact && window._posScanIndex.exact[nv] && window._posScanIndex.exact[nv].length);
            if (indexed && typeof tryAddPosScanBySelectedUnit === 'function') {
                var scanOpts = opts.exactOnly || opts.exactBarcodeOnly ? { exactBarcodeOnly: true } : opts;
                if (tryAddPosScanBySelectedUnit(val, inputEl, scanOpts)) return;
            }
            _posScanQueue.push({ val: val, inputEl: inputEl, opts: opts });
            if (!_posScanDraining) posDrainBarcodeScanQueue();
        }
        window.posEnqueueBarcodeScan = posEnqueueBarcodeScan;

        /** Normalized unique barcode codes on product (piece comma-list, pack, carton). */
        function getProductNormalizedBarcodeCodes(p) {
            if (!p) return [];
            var packOff = p.unit_show_pack != null && Number(p.unit_show_pack) === 0;
            var cartonOff = p.unit_show_carton != null && Number(p.unit_show_carton) === 0;
            var seen = Object.create(null);
            function addRaw(raw) {
                var str = String(raw || '').trim();
                if (!str) return;
                str.split(',').forEach(function(c) {
                    var t = c.trim();
                    if (!t) return;
                    var nv = normalizeBarcodeSearchInput(t);
                    if (nv) seen[nv] = true;
                });
            }
            addRaw(p.barcode);
            if (!packOff) addRaw(p.barcode_pack);
            if (!cartonOff) addRaw(p.barcode_carton);
            return Object.keys(seen);
        }

        /** 'distinct' = multiple different codes; 'shared' = one code for all units; 'none' = no barcodes. */
        function productBarcodesAreShared(p) {
            var codes = getProductNormalizedBarcodeCodes(p);
            if (!codes.length) return 'none';
            if (codes.length === 1) return 'shared';
            return 'distinct';
        }
        window.productBarcodesAreShared = productBarcodesAreShared;

        /** True if val equals piece barcode (any comma code), pack, carton, or exact SKU (digit-normalized). */
        function productMatchesPosScanCode(p, val) {
            val = String(val || '').trim();
            if (!val || !p) return false;
            var nv = normalizeBarcodeSearchInput(val);
            if (!nv) return false;
            var packOff = p.unit_show_pack != null && Number(p.unit_show_pack) === 0;
            var cartonOff = p.unit_show_carton != null && Number(p.unit_show_carton) === 0;
            function fieldExactCodes(raw) {
                var str = String(raw || '').trim();
                if (!str) return false;
                if (normalizeBarcodeSearchInput(str) === nv) return true;
                var parts = str.split(',');
                for (var i = 0; i < parts.length; i++) {
                    if (normalizeBarcodeSearchInput(parts[i]) === nv) return true;
                }
                return false;
            }
            if (fieldExactCodes(p.barcode)) return true;
            if (!packOff && fieldExactCodes(p.barcode_pack)) return true;
            if (!cartonOff && fieldExactCodes(p.barcode_carton)) return true;
            if (p.sku && normalizeBarcodeSearchInput(String(p.sku).trim()) === nv) return true;
            return false;
        }

        /** Which unit level does this scan code belong to (distinct barcodes only)? */
        function detectUnitFromBarcodeScan(p, val) {
            if (!p || !val) return null;
            var nv = normalizeBarcodeSearchInput(val);
            if (!nv) return null;
            var packOff = p.unit_show_pack != null && Number(p.unit_show_pack) === 0;
            var cartonOff = p.unit_show_carton != null && Number(p.unit_show_carton) === 0;
            var matches = [];
            function fieldExactCodes(raw) {
                var str = String(raw || '').trim();
                if (!str) return false;
                if (normalizeBarcodeSearchInput(str) === nv) return true;
                var parts = str.split(',');
                for (var i = 0; i < parts.length; i++) {
                    if (normalizeBarcodeSearchInput(parts[i]) === nv) return true;
                }
                return false;
            }
            if (fieldExactCodes(p.barcode)) matches.push('piece');
            if (!packOff && fieldExactCodes(p.barcode_pack)) matches.push('pack');
            if (!cartonOff && fieldExactCodes(p.barcode_carton)) matches.push('carton');
            if (!matches.length) return null;
            if (matches.length === 1) return matches[0];
            if (productBarcodesAreShared(p) === 'shared') return null;
            if (matches.indexOf('carton') >= 0) return 'carton';
            if (matches.indexOf('pack') >= 0) return 'pack';
            return 'piece';
        }
        window.detectUnitFromBarcodeScan = detectUnitFromBarcodeScan;

        /** Pack↔carton fallback only when requested unit is not defined on product. */
        function resolveSmartUnitForProduct(p, requestedUnit, isPurchase) {
            requestedUnit = requestedUnit || 'piece';
            if (!p) return { unit: 'piece', defined: false, fallback: false };
            if (productMatchesUnitFilter(p, requestedUnit, isPurchase)) {
                return { unit: requestedUnit, defined: true, fallback: false };
            }
            if (requestedUnit === 'carton' && productMatchesUnitFilter(p, 'pack', isPurchase)) {
                return { unit: 'pack', defined: false, fallback: true };
            }
            if (requestedUnit === 'pack' && productMatchesUnitFilter(p, 'carton', isPurchase)) {
                return { unit: 'carton', defined: false, fallback: true };
            }
            return { unit: requestedUnit, defined: false, fallback: false };
        }
        window.resolveSmartUnitForProduct = resolveSmartUnitForProduct;

        function getPosPiecesNeededForUnit(unit, p) {
            var f = typeof getProductUnitFactors === 'function' ? getProductUnitFactors(p) : { piecesPerPack: 1, piecesPerCarton: 1 };
            if (unit === 'carton') return Math.max(1, f.piecesPerCarton || 1);
            if (unit === 'pack') return Math.max(1, f.piecesPerPack || 1);
            return 1;
        }

        /** Piece count for a sale/cart line (edit mode + reservations). */
        function getPosCartLinePieceCount(item, prod) {
            if (!item || item.trackStock === false || item.isManualItem) return 0;
            var qty = typeof getItemQty === 'function' ? getItemQty(item) : (parseFloat(item.qty || item.count) || 0);
            if (!(qty > 0)) return 0;
            var p = prod;
            if (!p && db && db.products) {
                p = db.products.find(function (x) { return String(x.id) === String(item.id); });
            }
            var unit = item.saleUnit || item.sale_unit || 'piece';
            return getPosPiecesNeededForUnit(unit, p || item) * qty;
        }
        window.getPosCartLinePieceCount = getPosCartLinePieceCount;

        /** During sale edit, original invoice qty is restored on save — count as available for delta checks. */
        function getPosEditSaleReleasedPieces(productId) {
            var meta = window._posEditingSale;
            if (!meta || !meta.id || !meta.originalPiecesByPid) return 0;
            return parseFloat(meta.originalPiecesByPid[String(productId)]) || 0;
        }
        window.getPosEditSaleReleasedPieces = getPosEditSaleReleasedPieces;

        /** Reserved pieces across active cart + other POS invoice tabs. */
        function getReservedPiecesForProduct(productId) {
            var reserved = 0;
            var multi = db && db.settings && db.settings.enableMultiCartTabs !== false;
            if (multi && typeof posTabs !== 'undefined' && Array.isArray(posTabs) && posTabs.length > 0) {
                posTabs.forEach(function(tab, idx) {
                    if (!tab || !Array.isArray(tab.items)) return;
                    if (idx === activePosTabIndex) {
                        var table = (typeof findActivePosTable === 'function') ? findActivePosTable() : null;
                        if (table && Array.isArray(table.items)) {
                            reserved += getReservedPiecesInCart(table.items, productId);
                        } else {
                            reserved += getReservedPiecesInCart(tab.items, productId);
                        }
                    } else {
                        reserved += getReservedPiecesInCart(tab.items, productId);
                    }
                });
                return reserved;
            }
            var tableOnly = (typeof findActivePosTable === 'function') ? findActivePosTable() : null;
            if (tableOnly && tableOnly.items) {
                reserved += getReservedPiecesInCart(tableOnly.items, productId);
            }
            return reserved;
        }

        /** Sellable warehouse pieces minus reservations (single source for POS stock checks). */
        function getPosAvailablePieces(product) {
            if (!product) return 0;
            var enforceJewelry = (typeof jewelryEnforcesStock === 'function' && jewelryEnforcesStock(product));
            if (!product.trackStock && !enforceJewelry) return parseFloat(product.qty) || 0;
            var pieces = typeof getSellablePieceQty === 'function' ? getSellablePieceQty(product) : (parseFloat(product.qty) || 0);
            // Jewelry without trackStock: still use raw qty (don't treat as unlimited)
            if (!product.trackStock && enforceJewelry) {
                pieces = parseFloat(product.qty) || 0;
            }
            pieces -= getReservedPiecesForProduct(product.id);
            if (window._posEditingSale && window._posEditingSale.id) {
                pieces += getPosEditSaleReleasedPieces(product.id);
            }
            var isNegAllowed = (db && db.settings && (db.settings.allowNegativeStock == true || db.settings.allowNegativeStock == 'true' || db.settings.allowNegativeStock == 1));
            return isNegAllowed ? pieces : Math.max(0, pieces);
        }
        window.getPosAvailablePieces = getPosAvailablePieces;

        function posOutOfStockToastMessage(p, unit, availablePieces) {
            var av = Math.max(0, Math.floor(availablePieces || 0));
            var need = getPosPiecesNeededForUnit(unit, p);
            var unitLbl = (typeof getProductUnitLabel === 'function') ? getProductUnitLabel(p, unit) : unit;
            var elseHint = '';
            if (typeof getOtherWarehouseStockLines === 'function' && p) {
                var saleWh = typeof getSaleWarehouseId === 'function' ? getSaleWarehouseId() : 0;
                var elseLines = getOtherWarehouseStockLines(p, saleWh);
                if (elseLines.length) {
                    elseHint = ' — ل ' + elseLines.map(function (x) {
                        var qn = (Math.abs(x.qty - Math.round(x.qty)) < 0.0001) ? String(Math.round(x.qty)) : String(x.qty);
                        return x.name + ': ' + qn;
                    }).join(' · ') + '. کۆگەهێ بگوهێزە یان گواستنەوە بکە.';
                }
            }
            var tpl = (typeof t === 'function') ? t('toast_out_of_stock_detail') : '';
            if (tpl && tpl !== 'toast_out_of_stock_detail') {
                return tpl.replace(/\{available\}/g, String(av)).replace(/\{needed\}/g, String(need)).replace(/\{unit\}/g, unitLbl) + elseHint;
            }
            if (unit !== 'piece' && av > 0) {
                return 'کەلوپەل بۆ ' + unitLbl + ' تێنەکەوت — تەنها ' + av + ' تاک ماوە (پێویست: ' + need + ' تاک)' + elseHint;
            }
            return ((typeof t === 'function') ? t('toast_out_of_stock') : 'کەلوپەل نەماینە!') + elseHint;
        }

        function checkSaleStockForUnit(p, unit) {
            if (!p) return { ok: true };
            var enforceJewelry = (typeof jewelryEnforcesStock === 'function' && jewelryEnforcesStock(p));
            var jewelrySet = (typeof isJewelrySetProduct === 'function' && isJewelrySetProduct(p));
            if (!p.trackStock && !enforceJewelry && !jewelrySet) return { ok: true };
            var allowNeg = db.settings && (db.settings.allowNegativeStock == true || db.settings.allowNegativeStock == 'true' || db.settings.allowNegativeStock == 1);
            if (allowNeg) return { ok: true };
            var piecesNeeded = jewelrySet ? 1 : getPosPiecesNeededForUnit(unit, p);
            var available;
            if (jewelrySet && typeof jewelrySetAvailableCompleteSets === 'function') {
                available = jewelrySetAvailableCompleteSets(p);
            } else {
                available = typeof getPosAvailablePieces === 'function' ? getPosAvailablePieces(p) : Math.max(0, parseFloat(p.qty) || 0);
            }
            if (available <= 0.000001 || available < piecesNeeded) return { ok: false, available: available, needed: piecesNeeded, unit: unit };
            return { ok: true, available: available, needed: piecesNeeded, unit: unit };
        }
        window.checkSaleStockForUnit = checkSaleStockForUnit;

        /** Stock check for shared-barcode products (same math, tagged for messaging). */
        function checkSharedBarcodeSaleStock(p, unit) {
            var st = checkSaleStockForUnit(p, unit);
            if (st && typeof st === 'object') st.sharedMode = true;
            return st;
        }
        window.checkSharedBarcodeSaleStock = checkSharedBarcodeSaleStock;

        function posSaleStockToastMessage(p, unit, availablePieces) {
            if (p && productBarcodesAreShared(p) === 'shared') {
                return posSharedBarcodeStockMessage(p, unit, availablePieces);
            }
            return posOutOfStockToastMessage(p, unit, availablePieces);
        }
        window.posSaleStockToastMessage = posSaleStockToastMessage;

        /** Toast text when shared-barcode sale unit lacks full pack/carton stock (no piece fallback). */
        function posSharedBarcodeStockMessage(p, unit, availablePieces) {
            var av = Math.max(0, Math.floor(availablePieces || 0));
            unit = unit || 'piece';
            if (unit === 'pack') {
                var tplPack = (typeof t === 'function') ? t('pos_shared_stock_pack_insufficient') : '';
                if (tplPack && tplPack !== 'pos_shared_stock_pack_insufficient') {
                    return tplPack.replace(/\{available\}/g, String(av));
                }
                return 'بڕی پێویست بۆ پاکێت نییە، تەنها (' + av + ') دانەی تاک ماوە';
            }
            if (unit === 'carton') {
                var tplCarton = (typeof t === 'function') ? t('pos_shared_stock_carton_insufficient') : '';
                if (tplCarton && tplCarton !== 'pos_shared_stock_carton_insufficient') {
                    return tplCarton;
                }
                return 'بڕی پێویست بۆ کارتۆن نییە';
            }
            return (typeof t === 'function') ? t('toast_out_of_stock') : 'کەلوپەل نەماینە!';
        }
        window.posSharedBarcodeStockMessage = posSharedBarcodeStockMessage;

        function posCheckSaleStockForProduct(p, unit) {
            if (p && productBarcodesAreShared(p) === 'shared') {
                return checkSharedBarcodeSaleStock(p, unit);
            }
            return checkSaleStockForUnit(p, unit);
        }

        function buildResolvedUnitForProduct(p, val, selectedUnit, isPurchase) {
            var mode = productBarcodesAreShared(p);
            if (mode === 'shared' || mode === 'none') {
                var smartShared = resolveSmartUnitForProduct(p, selectedUnit, isPurchase);
                return {
                    p: p,
                    unit: smartShared.unit,
                    unitFromBarcode: false,
                    requestedUnit: selectedUnit,
                    unitDefined: smartShared.defined,
                    unitFallback: smartShared.fallback
                };
            }
            var detected = detectUnitFromBarcodeScan(p, val);
            if (detected) {
                return { p: p, unit: detected, unitFromBarcode: true, requestedUnit: selectedUnit };
            }
            var smart = resolveSmartUnitForProduct(p, selectedUnit, isPurchase);
            return {
                p: p,
                unit: smart.unit,
                unitFromBarcode: false,
                requestedUnit: selectedUnit,
                unitDefined: smart.defined,
                unitFallback: smart.fallback
            };
        }

        /**
         * Resolve barcode: distinct code → auto unit; same/unknown → selected tab + smart pack/carton fallback.
         * @returns {{p,unit,unitFromBarcode?,unitDefined?,unitFallback?,requestedUnit?}|{ambiguous:true}|null}
         */
        window.resolveBarcodeForTxnAdd = function(val, selectedUnit, opts) {
            opts = opts || {};
            var isPurchase = !!opts.isPurchase;
            selectedUnit = selectedUnit || 'piece';
            val = String(val || '').trim();
            if (!val || !db || !db.products) return null;
            var pool = opts.candidates || db.products;
            var nv = normalizeBarcodeSearchInput(val);
            var entries = (window._posScanIndex && window._posScanIndex.exact && window._posScanIndex.exact[nv]) ? window._posScanIndex.exact[nv] : null;
            if (entries && entries.length) {
                var filtered = entries.filter(function(e) {
                    if (!e || !e.p) return false;
                    if (pool === db.products) return true;
                    return pool.some(function(p) { return String(p.id) === String(e.p.id); });
                });
                if (filtered.length === 1) {
                    return buildResolvedUnitForProduct(filtered[0].p, val, selectedUnit, isPurchase);
                }
                if (filtered.length > 1) {
                    var pid0 = String(filtered[0].p.id);
                    if (filtered.every(function(e) { return String(e.p.id) === pid0; })) {
                        return buildResolvedUnitForProduct(filtered[0].p, val, selectedUnit, isPurchase);
                    }
                    return { ambiguous: true };
                }
            }
            var hit = typeof window.matchProductInListByScanOrName === 'function'
                ? window.matchProductInListByScanOrName(pool, val, selectedUnit, opts)
                : null;
            if (!hit) return null;
            if (hit.ambiguous) return { ambiguous: true };
            return buildResolvedUnitForProduct(hit.p, val, selectedUnit, isPurchase);
        };

        function applyPosBarcodeResolved(resolved, inputEl) {
            var viewPos = document.getElementById('view-pos');
            if (!viewPos || !viewPos.classList.contains('active')) return false;
            if (!resolved || !resolved.p) return false;
            var p = resolved.p;
            var unit = resolved.unit;
            var isPurchase = false;
            if (typeof productMatchesUnitFilter === 'function' && !productMatchesUnitFilter(p, unit, isPurchase)) {
                if (typeof showToast === 'function') showToast('ئەم بەرهەمە بە یەکەیا هەڵبژاردوو نافرۆشرێت. یەکە بگۆڕە.', 'warning');
                return true;
            }
            var st = posCheckSaleStockForProduct(p, unit);
            if (st.ok) {
                addToBill(p.id, unit);
                if (inputEl) { inputEl.value = ''; inputEl.focus(); }
                return true;
            }
            if (typeof showToast === 'function') {
                showToast(posSaleStockToastMessage(p, unit, st.available), 'error');
            }
            return true;
        }

        /**
         * Scale EAN-13 scan: PLU from barcode field, qty from embedded total price.
         * @returns {boolean} true if handled
         */
        function tryAddScaleBarcodeScan(parsed, inputEl) {
            if (!parsed || !parsed.isScale) return false;
            var prod = typeof window.findProductByScalePlu === 'function'
                ? window.findProductByScalePlu(parsed.itemCode)
                : null;
            function _scaleMsg(key, fallback) {
                if (typeof t === 'function') {
                    var s = t(key);
                    if (s && s !== key) return s;
                }
                return fallback;
            }
            if (!prod) {
                if (typeof showToast === 'function') showToast(_scaleMsg('scale_barcode_plu_not_found', 'PLU نەدۆزرایەوە'), 'warning');
                if (inputEl) { inputEl.value = ''; inputEl.focus(); }
                return true;
            }
            if (typeof getProductQtyMode === 'function' && getProductQtyMode(prod) !== 'kilo') {
                if (typeof showToast === 'function') showToast(_scaleMsg('scale_barcode_not_kilo', 'ئەم PLU‑ە بۆ کیلۆ نییە'), 'warning');
                if (inputEl) { inputEl.value = ''; inputEl.focus(); }
                return true;
            }
            var table = (typeof findActivePosTable === 'function') ? findActivePosTable() : null;
            var unitPrice = typeof getPriceForUnit === 'function'
                ? getPriceForUnit(prod, 'piece', table)
                : (parseFloat(prod.price) || 0);
            if (!(unitPrice > 0)) {
                if (typeof showToast === 'function') showToast(_scaleMsg('scale_barcode_no_price', 'نرخی کیلۆ ٠ە'), 'error');
                if (inputEl) { inputEl.value = ''; inputEl.focus(); }
                return true;
            }
            var qty = normalizeQtyForProduct(prod, parsed.totalPrice / unitPrice);
            if (!(qty > 0)) {
                if (typeof showToast === 'function') showToast(_scaleMsg('scale_barcode_invalid', 'بارکۆدی تەرازوو نادروست'), 'error');
                if (inputEl) { inputEl.value = ''; inputEl.focus(); }
                return true;
            }
            var ok = addToBill(prod.id, 'piece', { qtyOverride: qty });
            if (ok && inputEl) { inputEl.value = ''; inputEl.focus(); }
            return true;
        }

        /**
         * POS scan: distinct barcode → auto unit; else selected tab + smart fallback; stock when unit defined.
         * @returns {boolean} true if handled (added, warned, or multi-product menu); false if no product matched.
         */
        function tryAddPosScanBySelectedUnit(val, inputEl, opts) {
            opts = opts || {};
            val = String(val || '').trim();
            if (!val || !db || !db.products) return false;
            var scanU = typeof posSelectedUnit !== 'undefined' ? posSelectedUnit : 'piece';
            var nv = normalizeBarcodeSearchInput(val);
            var hasExact = !!(window._posScanIndex && window._posScanIndex.exact && window._posScanIndex.exact[nv] && window._posScanIndex.exact[nv].length);
            if (!hasExact && typeof window.parseEan13ScaleBarcode === 'function') {
                var scaleParsed = window.parseEan13ScaleBarcode(val);
                if (scaleParsed && scaleParsed.isScale) {
                    return tryAddScaleBarcodeScan(scaleParsed, inputEl);
                }
            }
            var resolved = typeof window.resolveBarcodeForTxnAdd === 'function'
                ? window.resolveBarcodeForTxnAdd(val, scanU, Object.assign({ isPurchase: false }, opts))
                : null;
            if (!resolved) return false;
            if (resolved.ambiguous) {
                if (inputEl) { inputEl.value = val; inputEl.focus(); }
                if (typeof renderPOSMenu === 'function') renderPOSMenu(val);
                if (typeof playBeep === 'function') playBeep();
                if (typeof showToast === 'function') showToast('پتر ژ ئێک ئایتم هاتە دیتن! ئێکێ هەلبژێرە.', 'info');
                return true;
            }
            return applyPosBarcodeResolved(resolved, inputEl);
        }

        /** True when text looks like a scanner code (not a product-name search). */
        function posLooksLikeScannerCode(val) {
            val = String(val || '').trim();
            if (!val) return false;
            var nv = typeof normalizeBarcodeSearchInput === 'function'
                ? normalizeBarcodeSearchInput(val)
                : val.toLowerCase();
            if (window._posScanIndex && window._posScanIndex.exact && window._posScanIndex.exact[nv] && window._posScanIndex.exact[nv].length) {
                return true;
            }
            // Pure numeric barcode — any length (scanner may send 1–13+ digits)
            if (/^\d+$/.test(nv)) return true;
            // Alphanumeric SKU/barcode: no spaces, has a digit
            if (val.length >= 2 && !/\s/.test(val) && /[0-9]/.test(val) && /^[A-Za-z0-9\-_.\/]+$/.test(val)) return true;
            return false;
        }
        window.posLooksLikeScannerCode = posLooksLikeScannerCode;
        window.tryAddPosScanBySelectedUnit = tryAddPosScanBySelectedUnit;

        /** Grid/search: name, id, SKU, piece (comma) barcodes, pack/carton (case + Arabic digit tolerant). */
        window.productMatchesBarcodeOrNameSearch = function(p, term) {
            if (!term || !String(term).trim()) return true;
            var rawTerm = String(term).trim();
            var t = normalizeBarcodeSearchInput(rawTerm);
            if (!t) return true;
            var tl = rawTerm.toLowerCase();
            if ((p.name || '').toLowerCase().indexOf(tl) >= 0) return true;
            if (typeof normalizeForSearch === 'function') {
                var nt = normalizeForSearch(rawTerm);
                var nn = normalizeForSearch(p.name || '');
                if (nt && nn.indexOf(nt) >= 0) return true;
            }
            if (normalizeBarcodeSearchInput(String(p.id)).indexOf(t) >= 0 || String(p.id).indexOf(t) >= 0) return true;
            if (p.sku && normalizeBarcodeSearchInput(String(p.sku)).indexOf(t) >= 0) return true;
            function barcodeHaystack(raw) {
                var str = String(raw || '');
                if (!str.trim()) return false;
                if (normalizeBarcodeSearchInput(str).indexOf(t) >= 0) return true;
                var parts = str.split(',');
                for (var i = 0; i < parts.length; i++) {
                    var seg = normalizeBarcodeSearchInput(parts[i]);
                    if (seg && (seg === t || seg.indexOf(t) >= 0)) return true;
                }
                return false;
            }
            if (barcodeHaystack(p.barcode)) return true;
            if (barcodeHaystack(p.barcode_pack)) return true;
            if (barcodeHaystack(p.barcode_carton)) return true;
            return false;
        };

        /**
         * Among pre-filtered candidates: exact barcode (piece codes, pack, carton) or single name substring match.
         * @returns {{p:object, unit:string}|{ambiguous:true}|null}
         */
        window.matchProductInListByScanOrName = function(candidates, val, preferredUnit, opts) {
            opts = opts || {};
            preferredUnit = preferredUnit || 'piece';
            val = String(val || '').trim();
            if (!val || !candidates || !candidates.length) return null;
            var seen = {};
            var matches = [];
            function add(p, u) {
                var k = String(p.id) + '\0' + u;
                if (seen[k]) return;
                seen[k] = true;
                matches.push({ p: p, unit: u });
            }
            var nv = typeof normalizeBarcodeSearchInput === 'function' ? normalizeBarcodeSearchInput(val) : val.toLowerCase();
            for (var ci = 0; ci < candidates.length; ci++) {
                var pr = candidates[ci];
                var packOff = pr.unit_show_pack != null && Number(pr.unit_show_pack) === 0;
                var cartonOff = pr.unit_show_carton != null && Number(pr.unit_show_carton) === 0;
                function fieldExactCodes(raw) {
                    var str = String(raw || '').trim();
                    if (!str) return false;
                    if (normalizeBarcodeSearchInput(str) === nv) return true;
                    var parts = str.split(',');
                    for (var i = 0; i < parts.length; i++) {
                        if (normalizeBarcodeSearchInput(parts[i]) === nv) return true;
                    }
                    return false;
                }
                if (fieldExactCodes(pr.barcode)) add(pr, 'piece');
                if (!packOff && fieldExactCodes(pr.barcode_pack)) add(pr, 'pack');
                if (!cartonOff && fieldExactCodes(pr.barcode_carton)) add(pr, 'carton');
                var skuExact = String(pr.sku || '').trim();
                if (skuExact && normalizeBarcodeSearchInput(skuExact) === nv) add(pr, preferredUnit);
            }
            if (matches.length === 1) return { p: matches[0].p, unit: matches[0].unit };
            if (matches.length > 1) {
                var pid0 = String(matches[0].p.id);
                var allSameProduct = matches.every(function(m) { return String(m.p.id) === pid0; });
                if (allSameProduct) return { p: matches[0].p, unit: preferredUnit };
                return { ambiguous: true };
            }
            // Name/SKU substring — NEVER for headless / accidental Enter (causes ghost cart adds)
            if (opts.exactBarcodeOnly) return null;
            var lower = val.toLowerCase();
            var nameHits = [];
            for (var ni = 0; ni < candidates.length; ni++) {
                var c = candidates[ni];
                if ((c.name || '').toLowerCase().indexOf(lower) >= 0) nameHits.push(c);
                else if (c.sku && String(c.sku).toLowerCase().indexOf(lower) >= 0) nameHits.push(c);
            }
            if (nameHits.length === 1) return { p: nameHits[0], unit: preferredUnit };
            return null;
        };

        /** Shared: process barcode or product name search, add to cart or open quick define. Used by main POS input and expand-mode search. */
        function processBarcodeOrSearch(val, inputEl, opts) {
            opts = opts || {};
            var viewPos = document.getElementById('view-pos');
            if (!viewPos || !viewPos.classList.contains('active')) return;
            if (!val || !db || !db.products) return;
            if (typeof tryAddPosScanBySelectedUnit === 'function' && tryAddPosScanBySelectedUnit(val, inputEl, opts)) return;
            if (opts.exactOnly || opts.exactBarcodeOnly) {
                var looksLikeBarcode = typeof posLooksLikeScannerCode === 'function'
                    ? posLooksLikeScannerCode(val)
                    : /^\d+$/.test(val);
                if (looksLikeBarcode && typeof showToast === 'function') {
                    var nowFail = Date.now();
                    if (!window._posScanFailToastAt || (nowFail - window._posScanFailToastAt) > 600) {
                        window._posScanFailToastAt = nowFail;
                        showToast(typeof t === 'function' ? t('qd_sales_use_purchase') : 'ئایتم نەهاتە دیتن. لە بەشی کڕین بارکۆد سکان بکە بۆ پێناسەکردن.', 'warning');
                    }
                }
                if (inputEl) { inputEl.value = ''; inputEl.focus(); }
                return;
            }

            var byName = (db.products || []).filter(function(p) {
                if (typeof productMatchesBarcodeOrNameSearch === 'function') {
                    return productMatchesBarcodeOrNameSearch(p, val);
                }
                if (typeof productMatchesPosScanCode === 'function' && productMatchesPosScanCode(p, val)) return true;
                var n = (p.name || '').toLowerCase();
                var v = val.toLowerCase();
                if (n.indexOf(v) >= 0) return true;
                if (p.sku && String(p.sku).toLowerCase().indexOf(v) >= 0) return true;
                return false;
            });
            if (byName.length === 1) {
                var p0 = byName[0];
                var scanUName = typeof posSelectedUnit !== 'undefined' ? posSelectedUnit : 'piece';
                var smartName = resolveSmartUnitForProduct(p0, scanUName, false);
                var resolvedName = {
                    p: p0,
                    unit: smartName.unit,
                    unitFromBarcode: false,
                    requestedUnit: scanUName,
                    unitDefined: smartName.defined,
                    unitFallback: smartName.fallback
                };
                if (applyPosBarcodeResolved(resolvedName, inputEl)) {
                    return;
                }
                return;
            }
            if (byName.length > 1) {
                if (inputEl) { inputEl.value = val; inputEl.focus(); }
                renderPOSMenu(val);
                if (typeof playBeep === 'function') playBeep();
                if (typeof showToast === 'function') showToast('پتر ژ ئێک ئایتم هاتە دیتن! ئێکێ هەلبژێرە.', 'info');
                return;
            }
            var looksLikeBarcode = /^\d{4,}$/.test(val);
            if (looksLikeBarcode && typeof showToast === 'function') {
                showToast(typeof t === 'function' ? t('qd_sales_use_purchase') : 'ئایتم نەهاتە دیتن. لە بەشی کڕین بارکۆد سکان بکە بۆ پێناسەکردن.', 'warning');
            } else if (typeof showToast === 'function') {
                showToast('ئایتم نەهاتە دیتن.', 'warning');
            }
            if (inputEl) { inputEl.value = ''; inputEl.focus(); }
        }

        function posScanNeedsServerLookup(val) {
            if (typeof window.posBarcodeNeedsServerLookup === 'function') {
                return window.posBarcodeNeedsServerLookup(val);
            }
            val = String(val || '').trim();
            if (!val) return false;
            return /^\d{3,}$/.test(val);
        }

        /** Barcode scan with SQL fallback — product not in partial bootstrap still resolves. */
        function processBarcodeOrSearchAsync(val, inputEl, opts) {
            opts = opts || {};
            val = typeof sanitizeScannerBarcodeInput === 'function' ? sanitizeScannerBarcodeInput(val) : String(val || '').trim();
            if (!val) return Promise.resolve();
            var viewPos = document.getElementById('view-pos');
            if (!viewPos || !viewPos.classList.contains('active')) return Promise.resolve();
            if (!db) return Promise.resolve();
            var scanOpts = opts.exactOnly || opts.exactBarcodeOnly ? { exactBarcodeOnly: true } : {};
            if (typeof tryAddPosScanBySelectedUnit === 'function' && tryAddPosScanBySelectedUnit(val, inputEl, scanOpts)) {
                return Promise.resolve();
            }
            var nv = typeof normalizeBarcodeSearchInput === 'function' ? normalizeBarcodeSearchInput(val) : String(val).trim().toLowerCase();
            var hasExact = !!(window._posScanIndex && window._posScanIndex.exact && window._posScanIndex.exact[nv] && window._posScanIndex.exact[nv].length);
            if (!hasExact && typeof window.parseEan13ScaleBarcode === 'function') {
                var scaleParsed = window.parseEan13ScaleBarcode(val);
                if (scaleParsed && scaleParsed.isScale && typeof posEnsureScalePluProduct === 'function') {
                    return posEnsureScalePluProduct(scaleParsed.itemCode).then(function () {
                        if (tryAddPosScanBySelectedUnit(val, inputEl, scanOpts)) return;
                        processBarcodeOrSearch(val, inputEl, opts);
                    });
                }
            }
            if (posScanNeedsServerLookup(val) && !hasExact && typeof posEnsureProductByBarcode === 'function') {
                return posEnsureProductByBarcode(val).then(function () {
                    if (typeof tryAddPosScanBySelectedUnit === 'function' && tryAddPosScanBySelectedUnit(val, inputEl, scanOpts)) return;
                    processBarcodeOrSearch(val, inputEl, opts);
                });
            }
            if (!hasExact && (opts.exactOnly || opts.exactBarcodeOnly) && typeof posEnsureProductByBarcode === 'function') {
                return posEnsureProductByBarcode(val).then(function (p) {
                    if (p && typeof tryAddPosScanBySelectedUnit === 'function' && tryAddPosScanBySelectedUnit(val, inputEl, scanOpts)) return;
                    processBarcodeOrSearch(val, inputEl, opts);
                });
            }
            // Name search SQL fallback — skip when barcode-only
            if (opts.exactOnly || opts.exactBarcodeOnly) {
                processBarcodeOrSearch(val, inputEl, opts);
                return Promise.resolve();
            }
            // Name search: SQL fallback (partial catalog + voided/inactive SKUs with reactivate prompt).
            var localNameHit = false;
            if (db.products && db.products.length && typeof productMatchesBarcodeOrNameSearch === 'function') {
                for (var li = 0; li < db.products.length; li++) {
                    if (productMatchesBarcodeOrNameSearch(db.products[li], val)) { localNameHit = true; break; }
                }
            }
            if (!localNameHit && val.length >= 2 && typeof posFetchProductSearch === 'function') {
                return posFetchProductSearch(val, 40, 0).then(function (data) {
                    if (data && data.status === 'ok' && Array.isArray(data.rows) && data.rows.length
                        && typeof posUpsertProducts === 'function') {
                        posUpsertProducts(data.rows);
                        if (typeof rebuildPosScanIndex === 'function') rebuildPosScanIndex();
                    }
                    if (typeof tryAddPosScanBySelectedUnit === 'function' && tryAddPosScanBySelectedUnit(val, inputEl, scanOpts)) return;
                    processBarcodeOrSearch(val, inputEl, opts);
                }).catch(function () {
                    processBarcodeOrSearch(val, inputEl, opts);
                });
            }
            processBarcodeOrSearch(val, inputEl, opts);
            return Promise.resolve();
        }
        window.processBarcodeOrSearchAsync = processBarcodeOrSearchAsync;

        function handlePOSBarcode(e) {
            if (e.key === 'Enter' || e.key === 'Tab' || e.keyCode === 13) {
                if (typeof isPosScannerBlocked === 'function' && isPosScannerBlocked()) return;
                e.preventDefault();
                if (typeof posMenuTimeout !== 'undefined' && posMenuTimeout) clearTimeout(posMenuTimeout);
                var input = e.target;
                var val = (input.value || '').trim();
                if (!val) return;
                // Typing a product name then Enter used to auto-add the only match — ghost cart adds.
                // Only enqueue as a scan when it looks like a barcode/SKU code.
                if (typeof posLooksLikeScannerCode === 'function' && !posLooksLikeScannerCode(val)) {
                    if (typeof debouncedRenderPOSMenu === 'function') debouncedRenderPOSMenu(val);
                    else if (typeof renderPOSMenu === 'function') renderPOSMenu(val);
                    return;
                }
                if (typeof posEnqueueBarcodeScan === 'function') {
                    posEnqueueBarcodeScan(val, input, { exactBarcodeOnly: true });
                } else if (typeof processBarcodeOrSearchAsync === 'function') {
                    processBarcodeOrSearchAsync(val, input, { exactOnly: true, exactBarcodeOnly: true });
                } else {
                    processBarcodeOrSearch(val, input, { exactOnly: true, exactBarcodeOnly: true });
                }
            }
        }

        function handleExpandSearchInput(e) {
            if (typeof isPosScannerBlocked === 'function' && isPosScannerBlocked()) return;
            var inputLive = document.getElementById('pos-expand-search-input');
            var mainLive = document.getElementById('pos-barcode-input');
            if (inputLive && mainLive && e.key !== 'Enter' && e.key !== 'Tab' && e.keyCode !== 13) {
                // Use setTimeout to get the value after keydown updates it
                setTimeout(function() {
                    mainLive.value = inputLive.value || '';
                    if (typeof debouncedRenderPOSMenu === 'function') debouncedRenderPOSMenu(mainLive.value || '');
                }, 0);
            }
            if (e.key === 'Enter' || e.key === 'Tab' || e.keyCode === 13) {
                e.preventDefault();
                if (typeof posMenuTimeout !== 'undefined' && posMenuTimeout) clearTimeout(posMenuTimeout);
                var input = document.getElementById('pos-expand-search-input');
                if (!input) return;
                var val = (input.value || '').trim();
                if (!val) return;
                if (typeof posLooksLikeScannerCode === 'function' && !posLooksLikeScannerCode(val)) {
                    if (typeof debouncedRenderPOSMenu === 'function') debouncedRenderPOSMenu(val);
                    else if (typeof renderPOSMenu === 'function') renderPOSMenu(val);
                    return;
                }
                input.value = '';
                var bigBasket = document.getElementById('pos-barcode-input');
                if (bigBasket) {
                    bigBasket.value = val;
                    if (typeof posEnqueueBarcodeScan === 'function') {
                        posEnqueueBarcodeScan(val, bigBasket, { exactBarcodeOnly: true });
                    } else if (typeof processBarcodeOrSearchAsync === 'function') {
                        processBarcodeOrSearchAsync(val, bigBasket, { exactOnly: true, exactBarcodeOnly: true });
                    } else {
                        processBarcodeOrSearch(val, bigBasket, { exactOnly: true, exactBarcodeOnly: true });
                    }
                } else if (typeof posEnqueueBarcodeScan === 'function') {
                    posEnqueueBarcodeScan(val, input, { exactBarcodeOnly: true });
                } else if (typeof processBarcodeOrSearchAsync === 'function') {
                    processBarcodeOrSearchAsync(val, input, { exactOnly: true, exactBarcodeOnly: true });
                } else {
                    processBarcodeOrSearch(val, input, { exactOnly: true, exactBarcodeOnly: true });
                }
            }
        }

        let posMenuTimeout = null;
        function posLooksLikeBarcodeTyping(q) {
            var s = String(q || '').trim();
            if (!s) return false;
            // USB scanners type digits quickly; skip full menu filter mid-burst
            if (/^\d{4,}$/.test(s)) return true;
            if (s.length >= 8 && !/\s/.test(s) && /[0-9]/.test(s)) return true;
            return false;
        }
        function debouncedRenderPOSMenu(q = '') {
            if (posMenuTimeout) clearTimeout(posMenuTimeout);
            var searchTrim = String(q || '').trim();
            var barcodeBurst = posLooksLikeBarcodeTyping(searchTrim);
            var _menuMs = barcodeBurst
                ? 220
                : 300;
            posMenuTimeout = setTimeout(function () {
                searchTrim = String(q || '').trim();
                if (posLooksLikeBarcodeTyping(searchTrim) && searchTrim.length >= 6) {
                    return;
                }
                if (searchTrim && typeof posServerSearchForMenu === 'function') {
                    posServerSearchForMenu(searchTrim).then(function () {
                        renderPOSMenu(q);
                    }).catch(function () {
                        renderPOSMenu(q);
                    });
                } else {
                    if (!searchTrim && typeof posClearServerMenuSearch === 'function') posClearServerMenuSearch();
                    renderPOSMenu(q);
                }
            }, _menuMs);
        }

        function getCurrentPOSSearch() {
            var bill = document.getElementById('pos-bill-panel');
            if (bill && bill.classList.contains('expanded')) {
                var ex = document.getElementById('pos-expand-search-input');
                if (ex) return ex.value || '';
            }
            var el = document.getElementById('pos-barcode-input');
            return el ? (el.value || '') : '';
        }

        /** Partial sync: re-fetch data and re-draw POS items + cart. No full page reload. */
        function posPartialRefresh(btnEl) {
            if (typeof connectToDB !== 'function') return;
            var btn = btnEl && btnEl.nodeType === 1 ? btnEl : document.getElementById('btn-pos-refresh');
            var icon = btn ? btn.querySelector('i.fa-sync-alt') : null;
            if (icon) icon.classList.add('pos-refresh-spin');
            connectToDB(true, { silentFail: true }).then(function() {
                if (typeof getCurrentPOSSearch === 'function' && typeof renderPOSMenu === 'function') renderPOSMenu(getCurrentPOSSearch(), true);
                if (activeTableId && typeof renderBill === 'function') renderBill();
                if (typeof refreshAllStockDisplaysFromState === 'function') refreshAllStockDisplaysFromState();
                if (icon) icon.classList.remove('pos-refresh-spin');
                if (typeof showToast === 'function') showToast(typeof t === 'function' ? t('toast_refreshed') : 'تم التحديث', 'success');
            }).catch(function() {
                if (icon) icon.classList.remove('pos-refresh-spin');
            });
        }

        // =========================================================================
        // CONTINUOUS AUTO-FOCUS KEEPER & GLOBAL HARDWARE SCANNER INTERCEPTOR (POS)
        // =========================================================================
        (function initPosContinuousScannerAutoFocus() {
            function isEditableTextInput(el) {
                if (!el) return false;
                var tag = el.tagName;
                if (tag === 'TEXTAREA' || el.isContentEditable) return true;
                if (tag === 'INPUT') {
                    if (el.readOnly || el.disabled) return false;
                    var type = (el.type || 'text').toLowerCase();
                    if (type === 'button' || type === 'submit' || type === 'reset' || type === 'checkbox' || type === 'radio' || type === 'file') return false;
                    if (el.id === 'pos-barcode-input' || el.id === 'pos-expand-search-input') return false;
                    return true;
                }
                if (tag === 'SELECT') return true;
                return false;
            }

            function isAnyModalActive() {
                var modals = document.querySelectorAll('.modal, .modal-overlay, [role="dialog"], .swal2-container');
                for (var i = 0; i < modals.length; i++) {
                    var m = modals[i];
                    var style = window.getComputedStyle(m);
                    if (style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0') {
                        return true;
                    }
                }
                return false;
            }

            // Return focus to barcode input when clicking anywhere in POS view (buttons, +, -, tabs, cards, whitespace)
            document.addEventListener('pointerup', function(ev) {
                var viewPos = document.getElementById('view-pos');
                if (!viewPos || !viewPos.classList.contains('active')) return;
                if (isAnyModalActive()) return;

                var target = ev.target;
                if (!target) return;
                // If user deliberately tapped an editable text input (customer name, discount, etc.), do not pull focus away
                if (isEditableTextInput(target)) return;
                if (target.closest && (target.closest('.pos-header-customer-box') || target.closest('.customer-dropdown-menu') || target.closest('.datalist-container') || target.closest('.modal') || target.closest('.modal-overlay'))) {
                    return;
                }

                setTimeout(function() {
                    if (isAnyModalActive()) return;
                    var ae = document.activeElement;
                    if (isEditableTextInput(ae)) return;
                    if (typeof window.focusTxnScannerInput === 'function') {
                        window.focusTxnScannerInput('pos', { clear: false, delay: 0 });
                    }
                }, 40);
            }, true);

            // Re-focus on window focus (e.g. returning from print dialog, second monitor, or alt-tab)
            window.addEventListener('focus', function() {
                var viewPos = document.getElementById('view-pos');
                if (viewPos && viewPos.classList.contains('active')) {
                    if (!isAnyModalActive() && typeof window.focusTxnScannerInput === 'function') {
                        window.focusTxnScannerInput('pos', { clear: false, delay: 60 });
                    }
                }
            });

            // Accidental scan protector: if cashier left cursor in customer name or discount and fires scanner gun
            document.addEventListener('keydown', function(e) {
                if (e.key !== 'Enter' && e.key !== 'Tab' && e.keyCode !== 13) return;
                var viewPos = document.getElementById('view-pos');
                if (!viewPos || !viewPos.classList.contains('active')) return;
                var target = e.target;
                if (!target) return;
                if (target.id === 'pos-barcode-input' || target.id === 'pos-expand-search-input') return;
                if (target.closest && target.closest('.modal, .modal-overlay, [role="dialog"], .swal2-container')) return;

                var val = String(target.value || '').trim();
                if (!val) return;
                // Barcode scanner fired into non-search input: detect numeric code (length >= 6) or SKU
                if (typeof posLooksLikeScannerCode === 'function' && posLooksLikeScannerCode(val) && val.length >= 6) {
                    e.preventDefault();
                    e.stopPropagation();
                    target.value = '';
                    var bill = document.getElementById('pos-bill-panel');
                    var bigBasket = (bill && bill.classList.contains('expanded'))
                        ? document.getElementById('pos-expand-search-input')
                        : document.getElementById('pos-barcode-input');
                    if (typeof posEnqueueBarcodeScan === 'function') {
                        posEnqueueBarcodeScan(val, bigBasket, { exactBarcodeOnly: true });
                    } else if (typeof processBarcodeOrSearchAsync === 'function') {
                        processBarcodeOrSearchAsync(val, bigBasket, { exactOnly: true, exactBarcodeOnly: true });
                    }
                    if (typeof window.focusTxnScannerInput === 'function') {
                        window.focusTxnScannerInput('pos', { clear: true, delay: 0 });
                    }
                }
            }, true);
        })();

