// sync/company-profile.js — company profile, supply
        // --- PROFILE & SUPPLY & DEBT ---
        function _compProfileT(key, fb) {
            if (typeof getCurrentLanguage === 'function' && getCurrentLanguage() === 'ar' && typeof t === 'function') {
                var v = t(key);
                if (v && v !== key) return v;
            }
            return fb;
        }
        function applyCompanyProfileUi() {
            var root = document.getElementById('company-profile-modal');
            if (!root) return;
            root.querySelectorAll('[data-comp-i18n]').forEach(function(el) {
                var key = el.getAttribute('data-comp-i18n');
                if (!key) return;
                var fb = el.getAttribute('data-comp-fb');
                if (!fb) {
                    fb = (el.textContent || '').trim();
                    if (fb) el.setAttribute('data-comp-fb', fb);
                }
                el.textContent = _compProfileT(key, fb);
            });
            root.querySelectorAll('[data-comp-i18n-placeholder]').forEach(function(el) {
                var key = el.getAttribute('data-comp-i18n-placeholder');
                if (!key) return;
                var fb = el.getAttribute('data-comp-fb') || el.getAttribute('placeholder') || '';
                if (fb && !el.getAttribute('data-comp-fb')) el.setAttribute('data-comp-fb', fb);
                el.setAttribute('placeholder', _compProfileT(key, fb));
            });
        }
        window.applyCompanyProfileUi = applyCompanyProfileUi;

        function openCompanyProfile(id) {
            const comp = (db.companies || []).find(function(c) { return c && String(c.id) === String(id); });
            if(!comp) return;
            currentViewingCompanyId = comp.id;
            
            document.getElementById('cp-name').innerText = comp.name || '';
            var cpIdEl = document.getElementById('cp-id');
            if (cpIdEl) cpIdEl.textContent = comp.id != null ? ('#' + String(comp.id)) : '';
            document.getElementById('cp-phone').innerText = comp.phone || '';
            document.getElementById('cp-address').innerText = comp.address ? (' | ' + comp.address) : '';
            
            var compBalFx = (typeof fxUsdRateFormatOptsForEntityBalance === 'function')
                ? fxUsdRateFormatOptsForEntityBalance(comp.id, 'company', comp.balance)
                : undefined;
            if (typeof fillElWithCurrencyAndDuhokPaper === 'function') fillElWithCurrencyAndDuhokPaper(document.getElementById('cp-balance'), comp.balance || 0, compBalFx);
            else document.getElementById('cp-balance').innerText = formatCurrency(comp.balance || 0, compBalFx) + " " + getCurrencySymbol();
            var debtBtn = document.getElementById('btn-company-debt-action');
            if (debtBtn) {
                var bal = parseFloat(comp.balance) || 0;
                var tf = (typeof t === 'function');
                if (bal > 0) {
                    debtBtn.innerHTML = '<i class="fas fa-money-bill-wave"></i> ' + escapeHtml(tf ? t('comp_pay_supplier_debt') : 'دانەڤا قەرزی');
                    debtBtn.classList.remove('btn-warning');
                    debtBtn.classList.add('btn-success');
                } else if (bal < 0) {
                    debtBtn.innerHTML = '<i class="fas fa-hand-holding-usd"></i> ' + escapeHtml(tf ? t('comp_debt_receive_credit') : 'وەرگرتنا قەرزێ لە کۆمپانیا');
                    debtBtn.classList.remove('btn-success');
                    debtBtn.classList.add('btn-warning');
                } else {
                    debtBtn.innerHTML = '<i class="fas fa-check-circle"></i> ' + escapeHtml(tf ? t('comp_debt_no_balance') : 'قەرز نییە');
                    debtBtn.classList.remove('btn-warning');
                    debtBtn.classList.add('btn-success');
                }
            }
            
            const targetTab = window._companyProfileDefaultTab || 'inventory';
            switchTab(targetTab); 
            renderCompanyInventory(comp.name); 
            renderCompanyHistory(comp.name);
            renderLedgerHistory(id); 
            renderCompanyReceipts();
            renderCompanyReceiptsArchive();
            // Docs are loaded when tab is clicked to save bandwidth
            var _cpM = document.getElementById('company-profile-modal');
            if (_cpM && typeof applyI18nSubtree === 'function') applyI18nSubtree(_cpM);
            if (typeof applyCompanyProfileUi === 'function') applyCompanyProfileUi();
            document.getElementById('cp-name').innerText = comp.name;
            _cpM.style.display = 'flex';
        }

        function switchTab(tabName) {
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.getElementById('tab-' + tabName).classList.add('active');
            document.getElementById('tab-btn-' + tabName).classList.add('active');
            if(tabName === 'docs') loadCompanyDocs();
            if(tabName === 'receipts' && typeof renderCompanyReceipts === 'function') renderCompanyReceipts();
            if(tabName === 'receipts-archive' && typeof renderCompanyReceiptsArchive === 'function') renderCompanyReceiptsArchive();
            if (typeof applyCompanyProfileUi === 'function') applyCompanyProfileUi();
            if (typeof applyI18nSubtree === 'function') {
                var cpRoot = document.getElementById('company-profile-modal');
                if (cpRoot) applyI18nSubtree(cpRoot);
            }
        }

        function renderCompanyInventory(compName) {
            const suppliedProdIds = new Set(
                (db.supplies || [])
                    .filter(s => s && s.company === compName && s.prodId)
                    .map(s => Number(s.prodId))
            );
            const products = (db.products || []).filter(p => p && (p.supplier === compName || suppliedProdIds.has(Number(p.id))));
            const isUsdInv = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
            const totalValue = products.reduce(function (sum, p) {
                var qty = p.trackStock ? (parseFloat(p.qty) || 0) : 0;
                if (!(qty > 0)) return sum;
                if (isUsdInv) {
                    var u = (typeof getCatalogPieceCostUsd === 'function') ? getCatalogPieceCostUsd(p) : (parseFloat(p.cost_usd) || 0);
                    return sum + (u * qty);
                }
                var cIqd = (typeof getCatalogPieceCostIqd === 'function') ? getCatalogPieceCostIqd(p) : (parseFloat(p.cost) || 0);
                return sum + (cIqd * qty);
            }, 0);
            var totalEl = document.getElementById('cp-total-stock-value');
            if (totalEl) {
                if (isUsdInv && typeof formatActiveCurrencyAmount === 'function') {
                    totalEl.innerText = formatActiveCurrencyAmount(totalValue);
                } else if (isUsdInv) {
                    totalEl.innerText = '$' + (typeof formatUsdNumberPlain === 'function' ? formatUsdNumberPlain(totalValue) : Number(totalValue).toLocaleString('en-US'));
                } else {
                    totalEl.innerText = formatCurrency(totalValue);
                }
            }
            const list = document.getElementById('cp-items-list');
            const _showProfitCols = (typeof canViewProfit === 'function') ? canViewProfit() : true;
            list.innerHTML = products.map(p => {
                let stockTxt = p.trackStock ? (p.itemsPerCarton > 1 ? `${Math.floor(p.qty/p.itemsPerCarton)} ک، ${p.qty%p.itemsPerCarton} د` : `${p.qty} د`) : '∞';
                var costActive = (typeof getCatalogPieceCostActive === 'function') ? getCatalogPieceCostActive(p) : (p.cost || 0);
                var sellActive = (typeof getCatalogPieceSellActive === 'function') ? getCatalogPieceSellActive(p) : (p.price || 0);
                var unitProfit = sellActive - costActive;
                var fmtCat = function (n) {
                    return (typeof formatActiveCurrencyAmount === 'function') ? formatActiveCurrencyAmount(n) : formatCurrency(n);
                };
                const costCell = _showProfitCols ? `<td>${fmtCat(costActive)}</td>` : '<td>---</td>';
                const profitCell = _showProfitCols ? `<td style="color:${unitProfit > 0 ? 'green':'red'}">${fmtCat(unitProfit)}</td>` : '<td>---</td>';
                return `<tr><td><b>${escapeHtml(p.name || 'ئایتم')}</b></td><td style="color:${p.trackStock && p.qty<=(typeof getMinStock === 'function' ? getMinStock(p) : 5) ? 'red' : 'black'}">${stockTxt}</td>${costCell}<td>${fmtCat(sellActive)}</td>${profitCell}<td><button class="btn btn-brand btn-sm" onclick="editProdFromProfile(${p.id})"><i class="fas fa-edit"></i></button><button class="btn btn-danger btn-sm" onclick="deleteProdFromProfile(${p.id}, '${escapeHtml(compName)}')"><i class="fas fa-trash"></i></button></td></tr>`;
            }).join('');
        }

        function editProdFromProfile(id) { closeCompanyProfile(); nav('products'); editProd(id); }
        function deleteProdFromProfile(id, compName) {
            const isActive = (db.tables || []).some(t => t && Array.isArray(t.items) && t.items.some(i => i && i.id === id));
            if (isActive) return alert("⛔ نەشێی ڤی ئایتمی ژێ ببەی! نوکە ل سەر " + (typeof getTablesLabelShort === 'function' ? getTablesLabelShort() + 'ەکێ' : 'مێزەکێ') + " یێ هاتیە داواکرن.");
            if(!confirm("دڵنیای ژ ژێبرنێ؟")) return;
            const formData = new FormData();
            formData.append('action', 'delete_product');
            formData.append('id', id);
            formData.append('user', currentUser ? currentUser.name : 'System');
            fetch('?action=delete_product', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                if(data.status === 'success') {
                    db.products = db.products.filter(p => p.id !== id);
                    if (typeof updateCurrencyLockUI === 'function') updateCurrencyLockUI();
                    scheduleSave();
                    renderCompanyInventory(compName);
                    const searchVal = (document.getElementById('products-search-input') && document.getElementById('products-search-input').value) || '';
                    renderProducts(searchVal);
                    if (typeof renderPOSMenu === 'function') renderPOSMenu(document.getElementById('pos-barcode-input') ? document.getElementById('pos-barcode-input').value : '');
                    showToast('✅ ئایتم ژێبرا', 'success');
                } else if(data.message) showToast(data.message || 'هەڵە', 'error');
            }).catch(() => showToast('هەڵە ل پەیوەندیدا', 'error'));
        }

        function renderCompanyHistory(compName) {
            if (typeof ensureDateFilterToday === 'function') ensureDateFilterToday('cp-history');
            if(!compName && currentViewingCompanyId) {
                const c = db.companies.find(x => x.id === currentViewingCompanyId);
                if(c) compName = c.name;
            }
            if(!compName) return;
            const list = document.getElementById('cp-history-list');
            if(!db.supplies) db.supplies = [];
            
            // Group supplies by transaction_id
            const history = db.supplies.filter(s => s.company === compName && isDateInScope(s.date, 'cp-history'));
            const grouped = {};
            history.forEach(s => {
                const key = s.transaction_id || ('OLD_' + s.date + '_' + s.prodId);
                if (!grouped[key]) grouped[key] = { txnId: s.transaction_id, date: s.date, type: s.type, total: 0, itemsCount: 0, items: [], invNum: s.supplier_invoice_number, batchNum: '' };
                var lineBatch = String(s.batch_number != null ? s.batch_number : '').trim();
                if (lineBatch) grouped[key].batchNum = lineBatch;
                grouped[key].total += (parseFloat(s.totalCost) || 0);
                grouped[key].itemsCount++;
                grouped[key].items.push(s);
            });
            
            const invoices = Object.values(grouped).sort((a, b) => new Date(b.date) - new Date(a.date));

            if(invoices.length === 0) { list.innerHTML = '<tr><td colspan="5" style="text-align:center; color:#999;">' + escapeHtml(_compProfileT('comp_profile_hist_empty', 'چ تۆمار نینن')) + '</td></tr>'; return; }
            
            const canEditPurchaseLine = (typeof currentUser !== 'undefined' && currentUser && currentUser.role === 'admin') || (typeof checkPermission === 'function' && checkPermission('companies_manage'));

            list.innerHTML = invoices.map(inv => {
                var badgeDebt = _compProfileT('comp_profile_hist_badge_debt', 'قەرز');
                var badgeCash = _compProfileT('comp_profile_hist_badge_cash', 'نەقد');
                var badgeReturn = _compProfileT('comp_profile_hist_badge_return', 'زڤڕاندن');
                var badgeSplit = _compProfileT('comp_profile_hist_badge_split', 'قەرز + نەقد');
                var badgeFib = 'FIB';
                let typeBadge = inv.type === 'credit'
                    ? '<span style="background:#fee2e2; color:#b91c1c; padding:3px 8px; border-radius:6px; font-weight:bold;">' + escapeHtml(badgeDebt) + '</span>'
                    : (inv.type === 'return'
                        ? '<span style="background:#000; color:white; padding:3px 8px; border-radius:6px; font-weight:bold;">' + escapeHtml(badgeReturn) + '</span>'
                        : (inv.type === 'split'
                            ? '<span style="background:#fef3c7; color:#b45309; padding:3px 8px; border-radius:6px; font-weight:bold;">' + escapeHtml(badgeSplit) + '</span>'
                            : ((inv.type === 'fib' || inv.type === 'bank' || inv.type === 'bankcard')
                                ? '<span style="background:#dbeafe; color:#1d4ed8; padding:3px 8px; border-radius:6px; font-weight:bold;">' + escapeHtml(badgeFib) + '</span>'
                                : '<span style="background:#d1fae5; color:#065f46; padding:3px 8px; border-radius:6px; font-weight:bold;">' + escapeHtml(badgeCash) + '</span>')));
                const invFallback = (typeof resolveCompanyInvoiceDisplayNumber === 'function') ? resolveCompanyInvoiceDisplayNumber(inv.invNum, inv.txnId) : (inv.txnId || '---');
                const invDisplay = inv.invNum ? `<b>${inv.invNum}</b>` : `<small style="opacity:0.6;">#${invFallback}</small>`;
                var batchSub = '';
                if (String(inv.batchNum || '').trim()) {
                    batchSub = '<br><small style="color:#0E4AFF;"><i class="fas fa-layer-group"></i> وەجبە: <b>' + escapeHtml(inv.batchNum) + '</b></small>';
                }
                var itemUnit = _compProfileT('comp_profile_hist_item_unit', 'ئایتم');
                var btnEdit = _compProfileT('comp_profile_hist_btn_edit', 'دەستکاری');
                var btnView = _compProfileT('comp_profile_hist_btn_view', 'بینین');
                var btnDelete = _compProfileT('comp_profile_hist_btn_delete', 'ژێبرن');
                var editBtnHtml = (canEditPurchaseLine && inv.type !== 'return') ? `<button class="btn btn-sm btn-primary" onclick="startEditPurchaseInCart('${inv.txnId}')" title="${escapeHtml(btnEdit)}"><i class="fas fa-edit"></i></button>` : '';
                var btnReturn = _compProfileT('comp_profile_hist_btn_return', 'زڤڕاندن');
                var returnBtnHtml = (canEditPurchaseLine && inv.type !== 'return') ? `<button class="btn btn-sm btn-return-invoice" onclick="startPurchaseReturnFromHistory('${inv.txnId}')" title="${escapeHtml(btnReturn)}"><i class="fas fa-undo"></i></button>` : '';
                var badgesHtml = (typeof posPurchaseInvBadgesHtml === 'function') ? posPurchaseInvBadgesHtml(inv) : '';
                
                return `<tr>
                    <td>${new Date(inv.date).toLocaleDateString()}${badgesHtml}</td>
                    <td>${invDisplay}${batchSub} <br><small>${inv.itemsCount} ${escapeHtml(itemUnit)}</small></td>
                    <td>${typeBadge}</td>
                    <td>${formatCurrency(inv.total, (typeof fxUsdRateFormatOpts === 'function' && inv.items && inv.items[0]) ? fxUsdRateFormatOpts(inv.items[0]) : undefined)}</td>
                    <td style="white-space:nowrap;">
                        ${editBtnHtml}
                        ${returnBtnHtml}
                        <button class="btn btn-sm btn-dark" onclick="viewInvoiceHistoryDetails('${inv.txnId}')" title="${escapeHtml(btnView)}"><i class="fas fa-eye"></i></button>
                        <button class="btn btn-sm btn-danger" onclick="voidPurchaseInvoice('${inv.txnId}')" title="${escapeHtml(btnDelete)}"><i class="fas fa-trash"></i></button>
                    </td>
                </tr>`;
            }).join('');
            if (typeof applyCompanyProfileUi === 'function') applyCompanyProfileUi();
        }

        function purchaseLinePool() {
            return window._fullPurchaseHistory || (window.db && window.db.supplies) || [];
        }

        function refreshPurchaseHistoryViews(txnId) {
            if (typeof renderCompanyHistory === 'function') renderCompanyHistory();
            if (typeof renderLedgerHistory === 'function') renderLedgerHistory();
            if (typeof renderGlobalPurchaseHistory === 'function') renderGlobalPurchaseHistory();
            if (typeof renderGlobalPurchaseReturnsHistory === 'function') renderGlobalPurchaseReturnsHistory();
            if (typeof renderCurrentModule === 'function') renderCurrentModule();
            if (txnId && typeof openPurchaseInvoiceDetailModal === 'function') {
                openPurchaseInvoiceDetailModal(txnId, { reopen: true });
            }
        }

        function applyPurchaseLineEditLocally(updated) {
            if (!updated || !updated.id) return;
            var txnId = updated.transaction_id || '';
            var oldLine = null;
            [window._fullPurchaseHistory, window.db && window.db.supplies].forEach(function (list) {
                if (!Array.isArray(list) || oldLine) return;
                var hit = list.find(function (s) { return String(s.id) === String(updated.id); });
                if (hit) oldLine = Object.assign({}, hit);
            });
            var qtyDelta = 0;
            var costDelta = 0;
            if (oldLine) {
                qtyDelta = (parseFloat(updated.qtyAdded) || 0) - (parseFloat(oldLine.qtyAdded) || 0);
                costDelta = (parseFloat(updated.totalCost) || 0) - (parseFloat(oldLine.totalCost) || 0);
            }
            var patch = function (list) {
                if (!Array.isArray(list)) return;
                for (var i = 0; i < list.length; i++) {
                    if (String(list[i].id) === String(updated.id)) {
                        list[i].qtyAdded = updated.qtyAdded;
                        list[i].totalCost = updated.totalCost;
                        if (updated.date) list[i].date = updated.date;
                        if (Object.prototype.hasOwnProperty.call(updated, 'expiry_date')) {
                            list[i].expiry_date = updated.expiry_date || '';
                        }
                        if (Object.prototype.hasOwnProperty.call(updated, 'supplier_invoice_number')) {
                            list[i].supplier_invoice_number = updated.supplier_invoice_number;
                        }
                        if (Object.prototype.hasOwnProperty.call(updated, 'batch_number')) {
                            list[i].batch_number = updated.batch_number;
                        }
                        if (updated.type) list[i].type = updated.type;
                    } else if (txnId && String(list[i].transaction_id || '') === String(txnId)) {
                        if (updated.date) list[i].date = updated.date;
                        if (Object.prototype.hasOwnProperty.call(updated, 'supplier_invoice_number')) {
                            list[i].supplier_invoice_number = updated.supplier_invoice_number;
                        }
                        if (Object.prototype.hasOwnProperty.call(updated, 'batch_number')) {
                            list[i].batch_number = updated.batch_number;
                        }
                    }
                }
            };
            patch(window._fullPurchaseHistory);
            if (window.db && window.db.supplies) patch(window.db.supplies);

            var invoiceTotal = typeof updated.invoice_total === 'number' ? updated.invoice_total : null;
            if (invoiceTotal == null && txnId) {
                var pool = window._fullPurchaseHistory || (window.db && window.db.supplies) || [];
                invoiceTotal = pool.filter(function (s) { return String(s.transaction_id || '') === String(txnId); })
                    .reduce(function (a, s) { return a + (parseFloat(s.totalCost) || 0); }, 0);
            }

            var prodId = updated.prodId || (oldLine && oldLine.prodId);
            if (prodId && Math.abs(qtyDelta) >= 0.0001 && window.db && Array.isArray(window.db.products)) {
                var prod = window.db.products.find(function (p) { return String(p.id) === String(prodId); });
                if (prod && prod.trackStock) {
                    prod.qty = (parseFloat(prod.qty) || 0) + qtyDelta;
                }
            }

            var payType = String(updated.type || (oldLine && oldLine.type) || 'cash').toLowerCase();
            if (txnId && window.db) {
                if (updated.date) {
                    if (Array.isArray(window.db.ledger)) {
                        window.db.ledger.forEach(function (l) {
                            if (String(l.transaction_id || '') === String(txnId)) l.date = updated.date;
                        });
                    }
                    if (Array.isArray(window.db.expenses)) {
                        window.db.expenses.forEach(function (e) {
                            if (String(e.transaction_id || '') === String(txnId)) e.date = updated.date;
                        });
                    }
                }
                if (Array.isArray(window.db.ledger)) {
                    window.db.ledger.forEach(function (l) {
                        if (String(l.transaction_id || '') !== String(txnId)) return;
                        var lt = String(l.type || '').toLowerCase();
                        if (payType === 'credit' && lt === 'credit_purchase') {
                            if (String(l.related_id) === String(updated.id)) {
                                l.amount = updated.totalCost;
                            } else if (invoiceTotal != null) {
                                l.amount = invoiceTotal;
                            }
                        }
                        if ((payType === 'cash' || payType === 'split') && lt === 'purchase' && invoiceTotal != null) {
                            l.amount = invoiceTotal;
                        }
                    });
                }
                if (Array.isArray(window.db.expenses) && (payType === 'cash' || payType === 'split') && invoiceTotal != null) {
                    window.db.expenses.forEach(function (e) {
                        if (String(e.transaction_id || '') === String(txnId) && String(e.type || '') === 'purchase') {
                            e.amount = invoiceTotal;
                        }
                    });
                }
            }
            if (updated.company && window.db && window.db.companies && typeof updated.company_balance === 'number') {
                var comp = window.db.companies.find(function (c) { return c.name === updated.company; });
                if (comp) comp.balance = updated.company_balance;
            }
            var totalEl = document.getElementById('purchase-invoice-detail-total');
            if (totalEl && txnId && typeof formatCurrency === 'function') {
                var gtLines = (window._fullPurchaseHistory || (window.db && window.db.supplies) || [])
                    .filter(function (s) { return String(s.transaction_id || '') === String(txnId); });
                var gt = gtLines.reduce(function (a, s) { return a + (parseFloat(s.totalCost) || 0); }, 0);
                var gtFx = (typeof fxUsdRateFormatOpts === 'function' && gtLines[0]) ? fxUsdRateFormatOpts(gtLines[0]) : undefined;
                totalEl.textContent = formatCurrency(gt, gtFx);
            }
        }

        window.openPurchaseInvoiceDetailModal = function (txnId, opts) {
            opts = opts || {};
            if (!txnId) return;
            // Purchase edit like sales: cart only (no line-edit modal).
            var canEditEarly = !opts.readonly && (
                (typeof currentUser !== 'undefined' && currentUser && (currentUser.role === 'admin' || currentUser.role === 'manager')) ||
                (typeof checkPermission === 'function' && checkPermission('companies_manage'))
            );
            var detEarly = document.getElementById('purchase-invoice-detail-modal');
            if (detEarly) {
                try { detEarly.style.display = 'none'; } catch (_eDet) {}
            }
            if (canEditEarly && typeof startEditPurchaseInCart === 'function') {
                startEditPurchaseInCart(txnId);
                return;
            }
            if (typeof viewInvoiceHistoryDetails === 'function') {
                viewInvoiceHistoryDetails(txnId);
                return;
            }
            var items = purchaseLinePool().filter(function (s) { return String(s.transaction_id || '') === String(txnId); });
            if (!items.length) {
                if (typeof showToast === 'function') showToast('ئایتم نەهاتە دیتن', 'error');
                return;
            }

            var compName = items[0].company || '';
            var company = (window.db && window.db.companies || []).find(function (c) { return c.name === compName; }) || { name: compName, phone: '' };
            var payType = items[0].type || 'cash';
            var invNum = (typeof resolveCompanyInvoiceDisplayNumber === 'function')
                ? resolveCompanyInvoiceDisplayNumber(items[0].supplier_invoice_number, txnId)
                : (items[0].supplier_invoice_number || txnId);
            var batchNumHdr = String(items[0].batch_number || '').trim();
            if (!batchNumHdr) {
                var batchHdrSib = items.find(function (s) { return String(s.batch_number || '').trim(); });
                if (batchHdrSib) batchNumHdr = String(batchHdrSib.batch_number).trim();
            }
            var dateStr = new Date(items[0].date).toLocaleString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ');
            var grandTotal = items.reduce(function (s, it) { return s + (parseFloat(it.totalCost) || 0); }, 0);
            var canEdit = !opts.readonly && payType !== 'return' && (
                (typeof currentUser !== 'undefined' && currentUser && currentUser.role === 'admin') ||
                (typeof checkPermission === 'function' && checkPermission('companies_manage'))
            );
            var typeLabel = payType === 'credit' ? 'قەرز' : (payType === 'split' ? 'پێچەوان' : 'نەقد');
            var showExpiryCol = true;

            var modal = document.getElementById('purchase-invoice-detail-modal');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'purchase-invoice-detail-modal';
                modal.style.cssText = 'display:none; position:fixed; inset:0; z-index:10020; background:rgba(0,0,0,0.65); align-items:center; justify-content:center; padding:20px;';
                document.body.appendChild(modal);
                modal.onclick = function (e) { if (e.target === modal) modal.style.display = 'none'; };
            }

            var rowsHtml = items.map(function (it) {
                var qty = parseFloat(it.qtyAdded) || 0;
                var total = parseFloat(it.totalCost) || 0;
                var isGiftLine = (typeof window.isSupplyItemGift === 'function')
                    ? window.isSupplyItemGift(it)
                    : !!(it && (it.isGift === true || it.is_gift === 1 || it.is_gift === '1' || it.is_gift === true));
                var prod = (window.db && window.db.products || []).find(function (p) { return String(p.id) === String(it.prodId); });
                var prodMissing = !prod && it.prodId;
                var displayUnit = (typeof window.inferPurchaseDisplayUnit === 'function')
                    ? window.inferPurchaseDisplayUnit(qty, prod)
                    : 'piece';
                var unitQty = (typeof window.purchasePiecesToUnitQty === 'function')
                    ? window.purchasePiecesToUnitQty(qty, displayUnit, prod)
                    : qty;
                var unitLabel = (typeof window.getProductUnitLabel === 'function')
                    ? window.getProductUnitLabel(prod, displayUnit)
                    : displayUnit;
                var qtySummary = (typeof window.formatPiecesUnitSummary === 'function')
                    ? window.formatPiecesUnitSummary(qty, prod, { showPiecesHint: true })
                    : String(qty);
                var unitCost = isGiftLine ? 0 : (unitQty ? (total / unitQty) : 0);
                var lineFx = (typeof fxUsdRateFormatOpts === 'function') ? fxUsdRateFormatOpts(it) : undefined;
                var giftBadge = isGiftLine ? ' <span style="color:#ec4899; font-weight:bold; font-size:0.85em;">(هدیە · فری)</span>' : '';
                var inactiveBadge = prodMissing
                    ? ' <span style="color:#dc2626; font-weight:700; font-size:0.8em;">(ناچالاک / ون لە کۆگە)</span>'
                    : '';
                var editBtn = canEdit
                    ? '<div style="display:flex; gap:6px; justify-content:center; flex-wrap:wrap;">' +
                      (prodMissing
                        ? '<button type="button" class="btn btn-sm btn-brand" onclick="posReactivateProduct(' + parseInt(it.prodId, 10) + ').then(function(p){ if(p && typeof openPurchaseInvoiceDetailModal===\'function\') openPurchaseInvoiceDetailModal(\'' + String(txnId).replace(/'/g, "\\'") + '\', { reopen: true }); })" title="چالاککردنەوە"><i class="fas fa-undo"></i> چالاککردنەوە</button>'
                        : '') +
                      '<button type="button" class="btn btn-sm btn-primary" onclick="openEditPurchaseLineModal(' + it.id + ', \'' + String(txnId).replace(/'/g, "\\'") + '\')" title="دەستکاری"><i class="fas fa-edit"></i></button>' +
                      '<button type="button" class="btn btn-sm btn-danger" onclick="deletePurchaseLineItem(' + it.id + ', \'' + String(txnId).replace(/'/g, "\\'") + '\')" title="سڕینەوەی ئەم ئایتمە"><i class="fas fa-trash-alt"></i></button>' +
                      '</div>'
                    : (prodMissing
                        ? '<button type="button" class="btn btn-sm btn-brand" onclick="posReactivateProduct(' + parseInt(it.prodId, 10) + ').then(function(p){ if(p && typeof openPurchaseInvoiceDetailModal===\'function\') openPurchaseInvoiceDetailModal(\'' + String(txnId).replace(/'/g, "\\'") + '\', { reopen: true }); })"><i class="fas fa-undo"></i> چالاککردنەوە</button>'
                        : '');
                var expCell = showExpiryCol
                    ? '<td style="padding:10px 12px; text-align:center; font-size:0.85rem; color:var(--text-muted);">' + escapeHtml(String(it.expiry_date || '').trim() || '—') + '</td>'
                    : '';
                var rowBg = prodMissing ? ' background:rgba(220,38,38,0.08);' : '';
                return '<tr style="border-bottom:1px solid var(--border);' + rowBg + '">' +
                    '<td style="padding:10px 12px;">' + escapeHtml(it.itemName || '') + giftBadge + inactiveBadge + '</td>' +
                    (showExpiryCol ? expCell : '') +
                    '<td style="padding:10px 12px; text-align:center; line-height:1.45;">' +
                        '<div style="font-weight:700;">' + qtySummary + '</div>' +
                        '<div style="font-size:0.78rem; color:var(--text-muted); margin-top:2px;">' +
                            escapeHtml(String((typeof formatQtyForInput === 'function') ? formatQtyForInput(unitQty, prod) : unitQty)) +
                            ' ' + escapeHtml(unitLabel) + '</div>' +
                    '</td>' +
                    '<td style="padding:10px 12px; text-align:left; white-space:nowrap;">' +
                        (isGiftLine ? '<span style="color:#ec4899;font-weight:bold;">0</span>' : (formatCurrency(unitCost, lineFx) + ' <small style="opacity:.75;">/ ' + escapeHtml(unitLabel) + '</small>')) +
                    '</td>' +
                    '<td style="padding:10px 12px; text-align:left; font-weight:bold; color:#0E4AFF;">' + (isGiftLine ? '<span style="color:#ec4899;">0</span>' : formatCurrency(total, lineFx)) + '</td>' +
                    '<td style="padding:10px 12px; text-align:center;">' + editBtn + '</td>' +
                    '</tr>';
            }).join('');

            modal.innerHTML =
                '<div class="glass-card" style="max-width:980px; width:96%; max-height:92vh; display:flex; flex-direction:column; padding:22px; border-radius:16px;">' +
                    '<div style="display:flex; justify-content:space-between; align-items:flex-start; gap:12px; border-bottom:1px solid var(--border); padding-bottom:14px; margin-bottom:14px;">' +
                        '<div>' +
                            '<h2 style="margin:0 0 6px 0; color:var(--warning); font-size:1.35rem;"><i class="fas fa-file-invoice" style="margin-left:8px;"></i> وردەکاری وەسڵێ</h2>' +
                            '<div style="color:var(--text-muted); font-size:0.9rem; line-height:1.7;">' +
                                '<div><b>پسوول:</b> ' + escapeHtml(String(invNum)) + '</div>' +
                                (batchNumHdr
                                    ? '<div><b>وەجبە:</b> <span style="color:#0E4AFF; font-weight:bold;">' + escapeHtml(batchNumHdr) + '</span></div>'
                                    : '') +
                                '<div><b>کۆمپانیا:</b> ' + escapeHtml(compName) + '</div>' +
                                '<div><b>بەروار:</b> ' + escapeHtml(dateStr) + ' · <b>جۆر:</b> ' + escapeHtml(typeLabel) + '</div>' +
                            '</div>' +
                        '</div>' +
                        '<div style="display:flex; gap:8px; flex-shrink:0;">' +
                            '<button type="button" class="btn btn-sm btn-dark" onclick="viewInvoiceHistoryDetails(\'' + String(txnId).replace(/'/g, "\\'") + '\')"><i class="fas fa-print"></i> چاپ</button>' +
                            '<button type="button" class="btn btn-sm btn-danger" onclick="document.getElementById(\'purchase-invoice-detail-modal\').style.display=\'none\'"><i class="fas fa-times"></i></button>' +
                        '</div>' +
                    '</div>' +
                    '<div style="flex:1; overflow:auto; border:1px solid var(--border); border-radius:12px; background:var(--card);">' +
                        '<table class="report-table" style="width:100%; margin:0; font-size:0.92rem;">' +
                            '<thead><tr style="background:var(--input-bg);">' +
                                '<th style="padding:12px; text-align:right;">ئایتم</th>' +
                                (showExpiryCol ? '<th style="padding:12px; text-align:center;">بەسەرچوون</th>' : '') +
                                '<th style="padding:12px; text-align:center;">یەکە / ژمار</th>' +
                                '<th style="padding:12px; text-align:left;">نرخ / یەکە</th>' +
                                '<th style="padding:12px; text-align:left;">کۆ</th>' +
                                '<th style="padding:12px; text-align:center;">کردار</th>' +
                            '</tr></thead>' +
                            '<tbody id="purchase-invoice-detail-tbody">' + rowsHtml + '</tbody>' +
                            '<tfoot><tr style="background:var(--input-bg); font-weight:900;">' +
                                '<td colspan="' + (showExpiryCol ? 4 : 3) + '" style="padding:12px; text-align:left;">کۆی گشتی</td>' +
                                '<td style="padding:12px; text-align:left; color:#0E4AFF;" id="purchase-invoice-detail-total">' + formatCurrency(grandTotal, (typeof fxUsdRateFormatOpts === 'function' && items[0]) ? fxUsdRateFormatOpts(items[0]) : undefined) + '</td>' +
                                '<td></td>' +
                            '</tr></tfoot>' +
                        '</table>' +
                    '</div>' +
                    (canEdit
                        ? '<div style="display:flex; flex-wrap:wrap; gap:10px; align-items:center; justify-content:space-between; margin-top:14px;">' +
                            '<p style="margin:0; color:var(--text-muted); font-size:0.82rem; flex:1; min-width:200px;"><i class="fas fa-info-circle"></i> دەستکاری یەک ئایتم — یان ئایتمێ نوێ زیاد بکە ئەگەر لە کڕیندا لەبیر چووە.</p>' +
                            '<button type="button" class="btn btn-brand btn-sm" onclick="openAddPurchaseLineModal(\'' + String(txnId).replace(/'/g, "\\'") + '\')"><i class="fas fa-plus"></i> زیادکردنی ئایتم</button>' +
                          '</div>'
                        : '') +
                '</div>';

            modal.style.display = 'flex';
            modal.dataset.txnId = txnId;
        };

        function purchaseLineYmdFromValue(raw) {
            if (!raw) return '';
            var dt = new Date(raw);
            if (isNaN(dt.getTime())) return '';
            var pad = function (n) { return String(n).padStart(2, '0'); };
            return dt.getFullYear() + '-' + pad(dt.getMonth() + 1) + '-' + pad(dt.getDate());
        }

        function pleEditProduct() {
            var modal = document.getElementById('purchase-line-edit-modal');
            if (!modal || !modal.dataset.pleProdId) return null;
            return (window.db && window.db.products || []).find(function (p) {
                return String(p.id) === String(modal.dataset.pleProdId);
            }) || null;
        }

        function pleEditCurrentUnit() {
            var modal = document.getElementById('purchase-line-edit-modal');
            var u = modal && modal.dataset.pleUnit ? modal.dataset.pleUnit : 'piece';
            return (typeof window.normalizePosUnitCode === 'function') ? window.normalizePosUnitCode(u) : u;
        }

        function pleGetStoredTotalIqd(modal) {
            if (modal && modal.dataset.pleTotalIqd != null && modal.dataset.pleTotalIqd !== '') {
                return parseFloat(modal.dataset.pleTotalIqd) || 0;
            }
            var totalEl = document.getElementById('ple-total');
            if (!totalEl) return 0;
            var display = parseFloat(totalEl.value) || 0;
            return (typeof debtFormAmountToStoredIqd === 'function') ? debtFormAmountToStoredIqd(display) : display;
        }

        function pleSetStoredTotalIqd(modal, totalIqd) {
            if (!modal) return;
            var roundM = (typeof roundMoney === 'function') ? roundMoney : function (x) { return Math.round(Number(x)); };
            totalIqd = roundM(Math.max(0, parseFloat(totalIqd) || 0));
            modal.dataset.pleTotalIqd = String(totalIqd);
            var totalEl = document.getElementById('ple-total');
            if (!totalEl) return;
            var usd = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
            var display = (typeof storedIqdToDebtFormAmount === 'function') ? storedIqdToDebtFormAmount(totalIqd) : totalIqd;
            totalEl.value = usd ? (parseFloat(display) || 0).toFixed(2) : String(Math.round(display));
        }

        /** Unit price display that does not drift total (e.g. 112000/720 → 155.556 not 156). */
        function pleFmtUnitCostDisplay(unitIqd, unitQty, totalIqd) {
            var usd = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
            var display = (typeof storedIqdToDebtFormAmount === 'function') ? storedIqdToDebtFormAmount(unitIqd) : unitIqd;
            if (usd) return (parseFloat(display) || 0).toFixed(2);
            var rounded = Math.round(display);
            if (unitQty > 0 && Math.abs(rounded * unitQty - totalIqd) >= 0.5) {
                for (var dec = 6; dec >= 1; dec--) {
                    var pow = Math.pow(10, dec);
                    var d = Math.round(display * pow) / pow;
                    if (Math.abs(d * unitQty - totalIqd) < 0.5) return String(d);
                }
                return String(Math.round(display * 1000000) / 1000000);
            }
            return String(rounded);
        }

        function pleEditSyncQtyFromPieces(pieces, opts) {
            opts = opts || {};
            var modal = document.getElementById('purchase-line-edit-modal');
            var qtyEl = document.getElementById('ple-qty');
            var unitEl = document.getElementById('ple-unit-cost');
            if (!modal || !qtyEl) return;
            var prod = pleEditProduct();
            var unit = pleEditCurrentUnit();
            var unitQty = (typeof window.purchasePiecesToUnitQty === 'function')
                ? window.purchasePiecesToUnitQty(pieces, unit, prod)
                : pieces;
            qtyEl.value = (typeof formatQtyForInput === 'function') ? formatQtyForInput(unitQty, prod) : unitQty;
            var totalIqd = parseFloat(modal.dataset.pleTotalIqd) || pleGetStoredTotalIqd(modal);
            pleSetStoredTotalIqd(modal, totalIqd);
            if (unitEl && unitQty > 0) {
                var unitIqd = totalIqd / unitQty;
                unitEl.value = pleFmtUnitCostDisplay(unitIqd, unitQty, totalIqd);
                unitEl.step = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD') ? '0.01' : '0.001';
            }
            modal.dataset.plePieces = String(pieces);
        }

        window.setPurchaseLineEditUnit = function (unit) {
            var modal = document.getElementById('purchase-line-edit-modal');
            if (!modal) return;
            var pieces = parseFloat(modal.dataset.plePieces) || 0;
            if (!pieces) {
                var qtyEl = document.getElementById('ple-qty');
                var prod = pleEditProduct();
                var oldUnit = pleEditCurrentUnit();
                pieces = (typeof window.purchaseUnitQtyToPieces === 'function')
                    ? window.purchaseUnitQtyToPieces(parseFloat(qtyEl && qtyEl.value) || 0, oldUnit, prod)
                    : (parseFloat(qtyEl && qtyEl.value) || 0);
            }
            modal.dataset.pleUnit = (typeof window.normalizePosUnitCode === 'function') ? window.normalizePosUnitCode(unit) : unit;
            var wrap = document.getElementById('ple-unit-toggles');
            if (wrap) {
                wrap.querySelectorAll('.pos-unit-btn').forEach(function (btn) {
                    btn.classList.toggle('active', btn.getAttribute('data-unit') === modal.dataset.pleUnit);
                });
            }
            var unitLbl = document.getElementById('ple-unit-label');
            var prod = pleEditProduct();
            var lbl = (typeof window.getProductUnitLabel === 'function')
                ? window.getProductUnitLabel(prod, modal.dataset.pleUnit)
                : modal.dataset.pleUnit;
            ['ple-unit-label', 'ple-unit-label-cost', 'ple-unit-label-hint'].forEach(function (id) {
                var el = document.getElementById(id);
                if (el) el.textContent = lbl;
            });
            if (unitLbl) unitLbl.textContent = lbl;
            pleEditSyncQtyFromPieces(pieces);
        };

        window.openEditPurchaseLineModal = function (supplyId, txnId) {
            if (txnId && typeof startEditPurchaseInCart === 'function') {
                startEditPurchaseInCart(txnId);
                return;
            }
            supplyId = parseInt(supplyId, 10);
            if (!supplyId) return;
            var line = purchaseLinePool().find(function (s) { return parseInt(s.id, 10) === supplyId; });
            if (!line) {
                if (typeof showToast === 'function') showToast('ئایتم نەهاتە دیتن', 'error');
                return;
            }
            if (line.transaction_id && typeof startEditPurchaseInCart === 'function') {
                startEditPurchaseInCart(line.transaction_id);
                return;
            }
            txnId = txnId || line.transaction_id || '';
            var pieces = parseFloat(line.qtyAdded) || 0;
            var totalIqd = parseFloat(line.totalCost) || 0;
            var prod = (window.db && window.db.products || []).find(function (p) { return String(p.id) === String(line.prodId); });
            var displayUnit = (typeof window.inferPurchaseDisplayUnit === 'function')
                ? window.inferPurchaseDisplayUnit(pieces, prod)
                : 'piece';
            var unitQty = (typeof window.purchasePiecesToUnitQty === 'function')
                ? window.purchasePiecesToUnitQty(pieces, displayUnit, prod)
                : pieces;
            var unitCostIqd = unitQty ? (totalIqd / unitQty) : 0;
            var usd = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
            var moneyUnit = usd ? '$' : 'IQD';
            var displayTotal = (typeof storedIqdToDebtFormAmount === 'function') ? storedIqdToDebtFormAmount(totalIqd) : totalIqd;
            var displayUnitCostStr = pleFmtUnitCostDisplay(unitCostIqd, unitQty, totalIqd);
            var fmtTotal = function (n) {
                n = parseFloat(n) || 0;
                return usd ? n.toFixed(2) : String(Math.round(n));
            };
            var unitLabel = (typeof window.getProductUnitLabel === 'function')
                ? window.getProductUnitLabel(prod, displayUnit)
                : displayUnit;
            var breakdownHtml = (typeof window.formatPiecesUnitSummary === 'function')
                ? window.formatPiecesUnitSummary(pieces, prod, { showPiecesHint: false })
                : String(pieces);
            var availUnits = (typeof window.availablePurchaseUnitsForProduct === 'function')
                ? window.availablePurchaseUnitsForProduct(prod)
                : ['piece', 'pack', 'carton'];
            var unitToggles = (typeof window.buildPosUnitToggleHtml === 'function')
                ? window.buildPosUnitToggleHtml({ available: availUnits, current: displayUnit, onSet: 'setPurchaseLineEditUnit' })
                : '';
            var batchNum = String(line.batch_number || '').trim();
            if (!batchNum && txnId) {
                var batchSibEarly = purchaseLinePool().find(function (s) {
                    return String(s.transaction_id || '') === String(txnId) && String(s.batch_number || '').trim();
                });
                if (batchSibEarly) batchNum = String(batchSibEarly.batch_number).trim();
            }
            var batchAllowed = (typeof canUsePurchaseBatch === 'function') ? canUsePurchaseBatch() : true;
            var batchBlock = batchAllowed
                ? '<label style="display:block; margin-bottom:6px; font-size:0.85rem;"><span style="color:#ef4444;">*</span> ژمارا وەجبێ</label>' +
                    '<input type="text" id="ple-batch-number" class="input-std" value="' + escapeHtml(batchNum || '') + '" placeholder="وەک: 26" dir="ltr" maxlength="100" style="margin:0 0 4px;" required>' +
                    '<p style="margin:0 0 12px; color:var(--text-muted); font-size:0.78rem;">وەجبە ٢٦ — جیا لە پسوولێ کۆمپانیا. بۆ هەموو ئایتمەکانی هەمان وەسڵ دەگۆڕدرێت.</p>'
                : '';
            var dateYmd = purchaseLineYmdFromValue(line.date);
            if (!dateYmd && txnId) {
                var sib = purchaseLinePool().find(function (s) {
                    return String(s.transaction_id || '') === String(txnId) && s.date;
                });
                if (sib) dateYmd = purchaseLineYmdFromValue(sib.date);
            }
            var expYmd = String(line.expiry_date || '').trim();
            if (expYmd.length >= 10) expYmd = expYmd.substring(0, 10);
            var expOn = !!expYmd;
            var supInv = String(line.supplier_invoice_number || '').trim();
            if (!supInv && txnId) {
                var invSib = purchaseLinePool().find(function (s) {
                    return String(s.transaction_id || '') === String(txnId) && String(s.supplier_invoice_number || '').trim();
                });
                if (invSib) supInv = String(invSib.supplier_invoice_number).trim();
            }
            var expiryBlock =
                '<label style="display:flex; align-items:center; gap:8px; margin:0 0 8px; font-size:0.85rem; cursor:pointer;">' +
                    '<input type="checkbox" id="ple-expiry-chk"' + (expOn ? ' checked' : '') + ' onchange="togglePurchaseLineEditExpiry(this.checked)"> بەسەرچوون (مەواد)' +
                '</label>' +
                '<div id="ple-expiry-wrap" style="margin:0 0 4px;' + (expOn ? '' : ' display:none;') + '">' +
                    '<input type="date" id="ple-expiry" class="input-std" value="' + escapeHtml(expYmd || '') + '" style="margin:0;">' +
                '</div>' +
                '<p style="margin:0 0 12px; color:var(--text-muted); font-size:0.78rem;"><i class="fas fa-info-circle"></i> بێ تیک = ئایتم بێ بەسەرچوون (جل، ئامێر…)</p>';

            var modal = document.getElementById('purchase-line-edit-modal');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'purchase-line-edit-modal';
                modal.style.cssText = 'display:none; position:fixed; inset:0; z-index:10025; background:rgba(0,0,0,0.55); align-items:center; justify-content:center; padding:20px;';
                document.body.appendChild(modal);
                modal.onclick = function (e) { if (e.target === modal) modal.style.display = 'none'; };
            }

            modal.innerHTML =
                '<div class="glass-card" style="max-width:480px; width:94%; padding:22px; border-radius:14px;" onclick="event.stopPropagation();">' +
                    '<h3 style="margin:0 0 14px 0; color:var(--brand);"><i class="fas fa-edit" style="margin-left:8px;"></i> دەستکارییا ئایتمێ</h3>' +
                    '<p style="margin:0 0 6px; color:var(--text-main); font-size:0.95rem; font-weight:600;">' + escapeHtml(line.itemName || '') + '</p>' +
                    '<p style="margin:0 0 14px; color:var(--text-muted); font-size:0.82rem;"><i class="fas fa-cubes"></i> ئێستا: ' + breakdownHtml + '</p>' +
                    '<label style="display:block; margin-bottom:6px; font-size:0.85rem;"><span style="color:#ef4444;">*</span> ژمارا پسوولێ (کۆمپانیا)</label>' +
                    '<input type="text" id="ple-supplier-invoice" class="input-std" value="' + escapeHtml(supInv || '') + '" placeholder="ژمارا پسوولێ لە کۆمپانیا" dir="ltr" maxlength="100" style="margin:0 0 4px;" required>' +
                    '<p style="margin:0 0 10px; color:var(--text-muted); font-size:0.78rem;">پسوولێ کۆمپانیا — نا ژمارا وەجبێ</p>' +
                    batchBlock +
                    '<label style="display:block; margin-bottom:6px; font-size:0.85rem;">بەروار (وەسڵ)</label>' +
                    '<input type="date" id="ple-date" class="input-std" value="' + escapeHtml(dateYmd || '') + '" style="margin:0 0 12px;">' +
                    '<p style="margin:-6px 0 12px; color:var(--text-muted); font-size:0.78rem;"><i class="fas fa-info-circle"></i> بەروار بۆ هەموو ئایتمەکانی هەمان پسوولە دەگۆڕدرێت.</p>' +
                    expiryBlock +
                    '<label style="display:block; margin-bottom:6px; font-size:0.85rem;">یەکە</label>' +
                    '<div id="ple-unit-toggles" class="pos-unit-toggles" style="margin:0 0 10px; display:flex; gap:6px;">' + unitToggles + '</div>' +
                    '<label style="display:block; margin-bottom:6px; font-size:0.85rem;">ژمار (<span id="ple-unit-label">' + escapeHtml(unitLabel) + '</span>)</label>' +
                    '<div class="returns-row-qty-wrap ple-qty-step-wrap" style="display:flex;align-items:stretch;gap:8px;margin:0 0 12px;">' +
                        '<button type="button" class="btn btn-sm btn-dark" style="min-width:44px;" onclick="adjustPurchaseLineEditQty(-1)" title="کەمکردن" aria-label="کەمکردن"><i class="fas fa-minus"></i></button>' +
                        '<input type="number" id="ple-qty" class="input-std" min="0.01" step="0.01" value="' + ((typeof formatQtyForInput === 'function') ? formatQtyForInput(unitQty, prod) : unitQty) + '" style="margin:0; flex:1; text-align:center;" oninput="recalcPurchaseLineEditTotal()">' +
                        '<button type="button" class="btn btn-sm btn-dark" style="min-width:44px;" onclick="adjustPurchaseLineEditQty(1)" title="زیادکردن" aria-label="زیادکردن"><i class="fas fa-plus"></i></button>' +
                    '</div>' +
                    '<label style="display:block; margin-bottom:6px; font-size:0.85rem;">نرخ / <span id="ple-unit-label-cost">' + escapeHtml(unitLabel) + '</span> (' + moneyUnit + ')</label>' +
                    '<input type="number" id="ple-unit-cost" class="input-std" min="0" step="' + (usd ? '0.01' : '0.001') + '" value="' + escapeHtml(displayUnitCostStr) + '" style="margin:0 0 12px;" oninput="recalcPurchaseLineEditTotal()">' +
                    '<label style="display:block; margin-bottom:6px; font-size:0.85rem;">کۆ (' + moneyUnit + ')</label>' +
                    '<input type="number" id="ple-total" class="input-std" min="0" step="' + (usd ? '0.01' : '1') + '" value="' + fmtTotal(displayTotal) + '" style="margin:0 0 8px;" oninput="recalcPurchaseLineEditUnitCost()">' +
                    '<p style="margin:0 0 16px; color:var(--text-muted); font-size:0.78rem;"><i class="fas fa-info-circle"></i> +/− بۆ گۆڕینی ژمارە (720→719). گۆڕینی یەکە کۆی سەرەتایی دەپارێزێت.</p>' +
                    '<div style="display:flex; gap:10px; justify-content:flex-end;">' +
                        '<button type="button" class="btn btn-dark" onclick="document.getElementById(\'purchase-line-edit-modal\').style.display=\'none\'">پاشگەز</button>' +
                        '<button type="button" class="btn btn-brand" id="ple-save-btn" onclick="savePurchaseLineEdit(' + supplyId + ', \'' + String(txnId).replace(/'/g, "\\'") + '\')"><i class="fas fa-save"></i> پاراستن</button>' +
                    '</div>' +
                '</div>';
            modal.style.display = 'flex';
            modal.dataset.pleProdId = String(line.prodId || '');
            modal.dataset.pleUnit = displayUnit;
            modal.dataset.plePieces = String(pieces);
            modal.dataset.pleTotalIqd = String((typeof roundMoney === 'function') ? roundMoney(totalIqd) : Math.round(totalIqd));
        };

        window.togglePurchaseLineEditExpiry = function (checked) {
            var wrap = document.getElementById('ple-expiry-wrap');
            if (wrap) wrap.style.display = checked ? 'block' : 'none';
            if (!checked) {
                var inp = document.getElementById('ple-expiry');
                if (inp) inp.value = '';
            }
        };

        function palEditProduct() {
            var modal = document.getElementById('purchase-add-line-modal');
            if (!modal || !modal.dataset.palProdId) return null;
            return (window.db && window.db.products || []).find(function (p) {
                return String(p.id) === String(modal.dataset.palProdId);
            }) || null;
        }

        function palCurrentUnit() {
            var modal = document.getElementById('purchase-add-line-modal');
            var u = modal && modal.dataset.palUnit ? modal.dataset.palUnit : 'piece';
            return (typeof window.normalizePosUnitCode === 'function') ? window.normalizePosUnitCode(u) : u;
        }

        window.setPurchaseAddLineUnit = function (unit) {
            var modal = document.getElementById('purchase-add-line-modal');
            if (!modal) return;
            modal.dataset.palUnit = (typeof window.normalizePosUnitCode === 'function') ? window.normalizePosUnitCode(unit) : unit;
            var wrap = document.getElementById('pal-unit-toggles');
            if (wrap) {
                wrap.querySelectorAll('.pos-unit-btn').forEach(function (btn) {
                    btn.classList.toggle('active', btn.getAttribute('data-unit') === modal.dataset.palUnit);
                });
            }
            var prod = palEditProduct();
            var lbl = (typeof window.getProductUnitLabel === 'function')
                ? window.getProductUnitLabel(prod, modal.dataset.palUnit)
                : modal.dataset.palUnit;
            ['pal-unit-label', 'pal-unit-label-cost'].forEach(function (id) {
                var el = document.getElementById(id);
                if (el) el.textContent = lbl;
            });
            
            if (prod) {
                var cost = (typeof getPurchaseCostForUnit === 'function') ? getPurchaseCostForUnit(prod, modal.dataset.palUnit) : (parseFloat(prod.cost) || 0);
                var costEl = document.getElementById('pal-unit-cost');
                if (costEl) {
                    var display = (typeof storedIqdToDebtFormAmount === 'function') ? storedIqdToDebtFormAmount(cost) : cost;
                    var usd = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
                    costEl.value = usd ? (parseFloat(display) || 0).toFixed(2) : String(Math.round(display));
                }
            }
            
            if (typeof window.recalcPurchaseAddLineTotal === 'function') window.recalcPurchaseAddLineTotal();
        };

        window.lookupPurchaseAddLineBarcode = function () {
            var inp = document.getElementById('pal-barcode');
            var modal = document.getElementById('purchase-add-line-modal');
            if (!inp || !modal) return;
            var val = (inp.value || '').trim();
            if (!val) return;
            
            // Avoid redundant lookup if it's the exact same item already loaded
            if (modal.dataset.palLastLookedUp === val) return;
            
            var resolved = (typeof window.resolveBarcodeForTxnAdd === 'function')
                ? window.resolveBarcodeForTxnAdd(val, palCurrentUnit(), { isPurchase: true })
                : null;
            if (!resolved || !resolved.p) {
                if (typeof showToast === 'function') showToast('ئایتم نەهاتە دیتن', 'error');
                return;
            }
            if (resolved.ambiguous) {
                if (typeof showToast === 'function') showToast('پتر ژ ئێک — بارکۆدێ تایبەت بنووسە', 'warning');
                return;
            }
            var p = resolved.p;
            modal.dataset.palProdId = String(p.id);
            modal.dataset.palLastLookedUp = val; // Remember so we don't overwrite if they just blur
            var nameEl = document.getElementById('pal-product-name');
            var detailsEl = document.getElementById('pal-product-details');
            var metaEl = document.getElementById('pal-product-meta');
            
            if (detailsEl) detailsEl.style.display = 'block';
            if (nameEl) nameEl.textContent = p.name || '—';
            
            if (metaEl) {
                var qtyDisplay = (typeof formatQtyForDisplay === 'function') ? formatQtyForDisplay(parseFloat(p.qty) || 0, p) : (p.qty || 0);
                metaEl.innerHTML = 
                    '<span><strong>بڕی کۆگە:</strong> ' + escapeHtml(qtyDisplay) + '</span> | ' +
                    '<span><strong>کرینی تاک:</strong> ' + formatCurrency(parseFloat(p.cost) || 0) + '</span> | ' +
                    '<span><strong>نرخی فرۆشتن:</strong> ' + formatCurrency(parseFloat(p.price) || 0) + '</span>';
            }
            
            var unit = resolved.unit || palCurrentUnit();
            if (typeof window.setPurchaseAddLineUnit === 'function') window.setPurchaseAddLineUnit(unit);
            
            // Note: costEl update is now handled inside setPurchaseAddLineUnit to ensure consistency
            
            var qtyEl = document.getElementById('pal-qty');
            if (qtyEl && !(parseFloat(qtyEl.value) > 0)) qtyEl.value = '1';
            
            // Handle expiry
            var expYmd = String(p.expiry_date || '').trim();
            if (expYmd.length >= 10) expYmd = expYmd.substring(0, 10);
            var chk = document.getElementById('pal-expiry-chk');
            if (chk) {
                if (typeof productUsesExpiryTracking === 'function' && productUsesExpiryTracking(p)) {
                    chk.checked = true;
                    togglePurchaseAddLineExpiry(true);
                } else if (expYmd) {
                    chk.checked = true;
                    togglePurchaseAddLineExpiry(true);
                } else {
                    chk.checked = false;
                    togglePurchaseAddLineExpiry(false);
                }
            }
            
            if (typeof window.recalcPurchaseAddLineTotal === 'function') window.recalcPurchaseAddLineTotal();
        };

        window.recalcPurchaseAddLineTotal = function () {
            var qtyEl = document.getElementById('pal-qty');
            var unitEl = document.getElementById('pal-unit-cost');
            var totalEl = document.getElementById('pal-total');
            if (!qtyEl || !unitEl || !totalEl) return;
            var qty = parseFloat(qtyEl.value) || 0;
            var unitDisplay = parseFloat(unitEl.value) || 0;
            var unitIqd = (typeof debtFormAmountToStoredIqd === 'function') ? debtFormAmountToStoredIqd(unitDisplay) : unitDisplay;
            var roundM = (typeof roundMoney === 'function') ? roundMoney : function (x) { return Math.round(Number(x)); };
            var totalIqd = roundM(qty * unitIqd);
            var usd = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
            var display = (typeof storedIqdToDebtFormAmount === 'function') ? storedIqdToDebtFormAmount(totalIqd) : totalIqd;
            totalEl.value = usd ? (parseFloat(display) || 0).toFixed(2) : String(Math.round(display));
        };

        window.deletePurchaseLineItem = function (supplyId, txnId) {
            if (txnId && typeof startEditPurchaseInCart === 'function') {
                startEditPurchaseInCart(txnId);
                return;
            }
            if (typeof posConfirm === 'function') {
                posConfirm({
                    title: 'سڕینەوەی ئایتم',
                    message: 'دڵنیای دڤێت ڤی ئایتمی ژ ڤێ پسوولێ (قایمێ) ڕەش بکەی؟\n(ئەڤە دێ ڕاستەوخۆ ژ کۆگەهێ ژی کێم کەت)',
                    tone: 'danger',
                    confirmText: 'بەڵێ، ڕەش بکە'
                }).then(function(confirmed) {
                    if (confirmed) _doDeletePurchaseLineItem(supplyId, txnId);
                });
            } else {
                if (!confirm('دڵنیای دڤێت ڤی ئایتمی ژ ڤێ پسوولێ (قایمێ) ڕەش بکەی؟\n(ئەڤە دێ ڕاستەوخۆ ژ کۆگەهێ ژی کێم کەت)')) return;
                _doDeletePurchaseLineItem(supplyId, txnId);
            }
        };

        function _doDeletePurchaseLineItem(supplyId, txnId) {
            var formData = new FormData();
            formData.append('action', 'delete_purchase_line_item');
            formData.append('supply_id', String(supplyId));
            formData.append('user', (typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : 'System');

            fetch('?action=delete_purchase_line_item', { method: 'POST', body: formData })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    if (data.status !== 'success') {
                        if (typeof showToast === 'function') showToast('هەڵە: ' + (data.message || 'Error'), 'error');
                        else alert('هەڵە: ' + (data.message || 'Error'));
                        return;
                    }
                    if (typeof showToast === 'function') showToast('✅ ئایتم هاتە سڕینەوە');
                    
                    // Remove locally from state
                    if (window._fullPurchaseHistory) {
                        window._fullPurchaseHistory = window._fullPurchaseHistory.filter(function(s) { return String(s.id) !== String(supplyId); });
                    }
                    if (window.db && window.db.supplies) {
                        window.db.supplies = window.db.supplies.filter(function(s) { return String(s.id) !== String(supplyId); });
                    }
                    // We don't try to auto-deduct local product qty perfectly, syncLiveData will fix it in 150ms
                    
                    // Force a reload of the modal to reflect the deletion
                    if (typeof refreshPurchaseHistoryViews === 'function') refreshPurchaseHistoryViews(txnId);
                    
                    // Re-open modal to render the updated items list (or close if it was the last one)
                    setTimeout(function() {
                        var remainingItems = purchaseLinePool().filter(function (s) { return String(s.transaction_id || '') === String(txnId); });
                        if (remainingItems.length > 0) {
                            openPurchaseInvoiceDetailModal(txnId);
                        } else {
                            var modal = document.getElementById('purchase-invoice-detail-modal');
                            if (modal) modal.style.display = 'none';
                        }
                    }, 50);

                    setTimeout(function () { if (typeof syncLiveData === 'function') syncLiveData(false); }, 150);
                })
                .catch(function (err) {
                    if (typeof showToast === 'function') showToast('هەڵە: ' + (err.message || err), 'error');
                    else alert('هەڵە: ' + (err.message || err));
                });
        };

        window.openAddPurchaseLineModal = function (txnId) {
            if (txnId && typeof startEditPurchaseInCart === 'function') {
                startEditPurchaseInCart(txnId);
                return;
            }
            if (!txnId) return;
            var items = purchaseLinePool().filter(function (s) { return String(s.transaction_id || '') === String(txnId); });
            if (!items.length) {
                if (typeof showToast === 'function') showToast('پسوولە نەهاتە دیتن', 'error');
                return;
            }
            if (items[0].type === 'return') {
                if (typeof showToast === 'function') showToast('زیادکردن تەنها بۆ کڕینێ — نە زڤڕاندن', 'error');
                return;
            }
            var usd = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
            var moneyUnit = usd ? '$' : 'IQD';
            var modal = document.getElementById('purchase-add-line-modal');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'purchase-add-line-modal';
                modal.style.cssText = 'display:none; position:fixed; inset:0; z-index:10026; background:rgba(0,0,0,0.55); align-items:center; justify-content:center; padding:20px;';
                document.body.appendChild(modal);
                modal.onclick = function (e) { if (e.target === modal) modal.style.display = 'none'; };
            }
            modal.innerHTML =
                '<div class="glass-card" style="max-width:520px; width:96%; padding:24px; border-radius:16px;" onclick="event.stopPropagation();">' +
                    '<h3 style="margin:0 0 14px 0; color:var(--brand); font-size:1.3rem;"><i class="fas fa-cart-plus" style="margin-left:8px;"></i> زیادکردنی ئایتم بۆ پسوولە</h3>' +
                    '<p style="margin:0 0 16px; color:var(--text-muted); font-size:0.9rem;">بارکۆد بنووسە و Enter — ئایتمێ نوێ بۆ هەمان پسوولە.</p>' +
                    
                    '<div style="background:var(--input-bg); border:1px solid var(--border); border-radius:10px; padding:12px; margin-bottom:16px;">' +
                        '<label style="display:block; margin-bottom:8px; font-size:0.9rem; font-weight:bold;">بارکۆد / گەڕان</label>' +
                        '<div style="display:flex; gap:8px;">' +
                            '<input type="text" id="pal-barcode" class="input-std" placeholder="لێرە سکان بکە…" style="margin:0; flex:1;" onkeydown="if(event.key===\'Enter\'){event.preventDefault();lookupPurchaseAddLineBarcode();}" onblur="if(this.value.trim() !== \'\') lookupPurchaseAddLineBarcode();">' +
                            '<button type="button" class="btn btn-info" onclick="lookupPurchaseAddLineBarcode()" style="padding:0 16px;"><i class="fas fa-search"></i></button>' +
                        '</div>' +
                    '</div>' +
                    
                    '<div id="pal-product-details" style="margin:0 0 16px; min-height:40px; background:rgba(37,99,235,0.05); padding:10px; border-radius:8px; border:1px dashed var(--brand); display:none;">' +
                        '<p id="pal-product-name" style="margin:0 0 6px; font-weight:800; font-size:1.1rem; color:var(--brand);">—</p>' +
                        '<div id="pal-product-meta" style="display:flex; gap:12px; font-size:0.85rem; color:var(--text-main);"></div>' +
                    '</div>' +
                    
                    '<div style="display:flex; gap:16px; margin-bottom:16px; align-items:center;">' +
                        '<div style="flex:1;">' +
                            '<label style="display:block; margin-bottom:6px; font-size:0.9rem; font-weight:bold;">یەکە (Unit)</label>' +
                            '<div id="pal-unit-toggles" class="pos-unit-toggles" style="display:flex; gap:6px;"></div>' +
                        '</div>' +
                        '<div style="flex:1;">' +
                            '<label style="display:flex; align-items:center; gap:8px; font-size:0.9rem; font-weight:bold; cursor:pointer; margin-bottom:6px;">' +
                                '<input type="checkbox" id="pal-expiry-chk" onchange="togglePurchaseAddLineExpiry(this.checked)" style="width:16px;height:16px;"> بەسەرچوون (ئێکسپایەر)' +
                            '</label>' +
                            '<div id="pal-expiry-wrap" style="display:none;">' +
                                '<input type="date" id="pal-expiry" class="input-std" style="margin:0;">' +
                            '</div>' +
                        '</div>' +
                    '</div>' +
                    
                    '<div style="display:flex; gap:12px; margin-bottom:16px;">' +
                        '<div style="flex:1;">' +
                            '<label style="display:block; margin-bottom:6px; font-size:0.9rem; font-weight:bold;">بڕ / ژمارە (<span id="pal-unit-label" style="color:var(--brand);">تاک</span>)</label>' +
                            '<input type="number" id="pal-qty" class="input-std" min="0.01" step="0.01" value="1" style="margin:0; font-weight:bold; font-size:1.1rem;" oninput="recalcPurchaseAddLineTotal()">' +
                        '</div>' +
                        '<div style="flex:1.5;">' +
                            '<label style="display:block; margin-bottom:6px; font-size:0.9rem; font-weight:bold;">کرینیێ یەکەیەک (<span id="pal-unit-label-cost" style="color:var(--brand);">تاک</span>) / ' + moneyUnit + '</label>' +
                            '<input type="number" id="pal-unit-cost" class="input-std" min="0" step="' + (usd ? '0.01' : '1') + '" value="0" style="margin:0; font-weight:bold; font-size:1.1rem;" oninput="recalcPurchaseAddLineTotal()">' +
                        '</div>' +
                    '</div>' +
                    
                    '<label style="display:block; margin-bottom:6px; font-size:0.9rem; font-weight:bold;">کۆی گشتی کرین (' + moneyUnit + ')</label>' +
                    '<input type="number" id="pal-total" class="input-std" min="0" step="' + (usd ? '0.01' : '1') + '" value="0" style="margin:0 0 20px; font-weight:bold; font-size:1.2rem; background:var(--bg-color);" readonly>' +
                    
                    '<div style="display:flex; gap:12px; justify-content:flex-end;">' +
                        '<button type="button" class="btn btn-dark" onclick="document.getElementById(\'purchase-add-line-modal\').style.display=\'none\'" style="padding:10px 20px; font-size:1.05rem;">پاشگەز</button>' +
                        '<button type="button" class="btn btn-brand" id="pal-save-btn" onclick="saveAddPurchaseLineToInvoice(\'' + String(txnId).replace(/'/g, "\\'") + '\')" style="padding:10px 24px; font-size:1.05rem;"><i class="fas fa-save"></i> زیادکردن</button>' +
                    '</div>' +
                '</div>';
            modal.dataset.txnId = txnId;
            modal.dataset.palProdId = '';
            modal.dataset.palUnit = 'piece';
            modal.dataset.palLastLookedUp = '';
            var toggles = document.getElementById('pal-unit-toggles');
            if (toggles && typeof window.buildPosUnitToggleHtml === 'function') {
                toggles.innerHTML = window.buildPosUnitToggleHtml({
                    available: ['piece', 'pack', 'carton'],
                    current: 'piece',
                    onSet: 'setPurchaseAddLineUnit'
                });
            }
            modal.style.display = 'flex';
            setTimeout(function () {
                var bc = document.getElementById('pal-barcode');
                if (bc) bc.focus();
            }, 50);
        };

        window.togglePurchaseAddLineExpiry = function (checked) {
            var wrap = document.getElementById('pal-expiry-wrap');
            if (wrap) wrap.style.display = checked ? 'block' : 'none';
            if (!checked) {
                var inp = document.getElementById('pal-expiry');
                if (inp) inp.value = '';
            }
        };

        window.saveAddPurchaseLineToInvoice = function (txnId) {
            var modal = document.getElementById('purchase-add-line-modal');
            var btn = document.getElementById('pal-save-btn');
            
            var bcInput = document.getElementById('pal-barcode');
            
            // Auto-resolve barcode if user clicked Add without pressing Enter
            if (modal && !modal.dataset.palProdId && bcInput && bcInput.value.trim() !== '') {
                var resolved = (typeof window.resolveBarcodeForTxnAdd === 'function')
                    ? window.resolveBarcodeForTxnAdd(bcInput.value.trim(), palCurrentUnit(), { isPurchase: true })
                    : null;
                if (!resolved || !resolved.p) {
                    if (typeof showToast === 'function') showToast('ئایتم نەهاتە دیتن بۆ ڤی بارکۆدی', 'error');
                    else alert('ئایتم نەهاتە دیتن بۆ ڤی بارکۆدی');
                    bcInput.focus(); bcInput.style.border = '2px solid red';
                    return;
                }
                if (resolved.ambiguous) {
                    if (typeof showToast === 'function') showToast('پتر ژ ئێک ئایتم دیتن — بارکۆدێ تایبەت بنووسە', 'warning');
                    return;
                }
                // Silently set it so the save can proceed
                modal.dataset.palProdId = String(resolved.p.id);
            }

            if (!modal || !modal.dataset.palProdId) {
                if (typeof showToast === 'function') showToast('تکایە سەرەتا بارکۆدی سکان بکە یان بنڤیسە!', 'error');
                else alert('تکایە سەرەتا بارکۆدی سکان بکە یان بنڤیسە!');
                if (bcInput) { bcInput.focus(); bcInput.style.border = '2px solid red'; }
                return;
            }
            if (bcInput) bcInput.style.border = '';
            var prod = palEditProduct();
            var qtyEl = document.getElementById('pal-qty');
            var totalEl = document.getElementById('pal-total');
            if (!qtyEl || !totalEl) return;
            var unitQty = parseFloat(qtyEl.value) || 0;
            var pieces = (typeof window.purchaseUnitQtyToPieces === 'function')
                ? window.purchaseUnitQtyToPieces(unitQty, palCurrentUnit(), prod)
                : unitQty;
            var totalDisplay = parseFloat(totalEl.value) || 0;
            var total = (typeof debtFormAmountToStoredIqd === 'function')
                ? debtFormAmountToStoredIqd(totalDisplay)
                : totalDisplay;
            if (typeof roundMoney === 'function') total = roundMoney(total);
            if (unitQty <= 0 || pieces <= 0) {
                if (typeof showToast === 'function') showToast('ژمارە دڤێت گەورەتر بیت لە ٠', 'error');
                return;
            }
            if (total < 0) {
                if (typeof showToast === 'function') showToast('کۆ نابیت نەرێنی', 'error');
                return;
            }
            
            var expChk = document.getElementById('pal-expiry-chk');
            var expVal = '';
            if (expChk && expChk.checked) {
                var expInput = document.getElementById('pal-expiry');
                if (expInput) expVal = String(expInput.value || '').trim();
                
                if (!expVal) {
                    if (typeof showToast === 'function') showToast('بەروارا بەسەرچوونێ بنووسە یان تیک لاببە', 'error');
                    else alert('بەروارا بەسەرچوونێ بنووسە یان تیک لاببە');
                    if (expInput) { expInput.focus(); expInput.style.border = '2px solid red'; }
                    return;
                }
            }
            var user = (typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : 'System';
            var formData = new FormData();
            formData.append('action', 'add_purchase_line_to_invoice');
            formData.append('transaction_id', txnId);
            formData.append('prodId', modal.dataset.palProdId);
            formData.append('qtyAdded', String(pieces));
            formData.append('totalCost', String(total));
            if (expVal) {
                formData.append('expiry_date', expVal);
            }
            formData.append('user', user);
            if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>'; }
            fetch('?action=add_purchase_line_to_invoice', { method: 'POST', body: formData })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-save"></i> زیادکردن'; }
                    if (data.status !== 'success') {
                        if (typeof showToast === 'function') showToast('هەڵە: ' + (data.message || 'Error'), 'error');
                        else alert('هەڵە: ' + (data.message || 'Error'));
                        return;
                    }
                    if (typeof applyPurchaseLineAddLocally === 'function') applyPurchaseLineAddLocally(data.supply, data);
                    modal.style.display = 'none';
                    if (typeof showToast === 'function') showToast('✅ ئایتم زیادکرا');
                    if (typeof refreshPurchaseHistoryViews === 'function') refreshPurchaseHistoryViews(txnId);
                    setTimeout(function () { if (typeof syncLiveData === 'function') syncLiveData(false); }, 150);
                })
                .catch(function (err) {
                    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-save"></i> زیادکردن'; }
                    if (typeof showToast === 'function') showToast('هەڵە: ' + (err.message || err), 'error');
                    else alert('هەڵە: ' + (err.message || err));
                });
        };

        function applyPurchaseLineAddLocally(supply, meta) {
            if (!supply || !supply.id) return;
            meta = meta || {};
            var pushLine = function (list) {
                if (!Array.isArray(list)) return;
                if (list.some(function (s) { return String(s.id) === String(supply.id); })) return;
                list.push(Object.assign({}, supply));
            };
            pushLine(window._fullPurchaseHistory);
            if (window.db && window.db.supplies) pushLine(window.db.supplies);
            var prodId = supply.prodId;
            var qty = parseFloat(supply.qtyAdded) || 0;
            if (prodId && qty > 0 && window.db && Array.isArray(window.db.products)) {
                var prod = window.db.products.find(function (p) { return String(p.id) === String(prodId); });
                if (prod && prod.trackStock) prod.qty = (parseFloat(prod.qty) || 0) + qty;
            }
            if (typeof meta.company_balance === 'number' && window.db && Array.isArray(window.db.companies) && supply.company) {
                var comp = window.db.companies.find(function (c) { return c.name === supply.company; });
                if (comp) comp.balance = meta.company_balance;
            }
        }
        window.applyPurchaseLineAddLocally = applyPurchaseLineAddLocally;

        window.adjustPurchaseLineEditQty = function (direction) {
            var qtyEl = document.getElementById('ple-qty');
            if (!qtyEl) return;
            var prod = pleEditProduct();
            var cur = parseFloat(qtyEl.value) || 0;
            var step = (prod && typeof isWeightProduct === 'function' && isWeightProduct(prod)) ? 0.25 : 1;
            var d = (direction < 0) ? -step : step;
            var next = cur + d;
            if (typeof normalizeQtyForProduct === 'function') next = normalizeQtyForProduct(prod, next);
            if (next <= 0) {
                if (typeof showToast === 'function') showToast('ژمارە دڤێت گەورەتر بیت لە ٠', 'warning');
                return;
            }
            qtyEl.value = (typeof formatQtyForInput === 'function') ? formatQtyForInput(next, prod) : next;
            if (typeof window.recalcPurchaseLineEditTotal === 'function') window.recalcPurchaseLineEditTotal();
        };

        window.recalcPurchaseLineEditTotal = function () {
            var qtyEl = document.getElementById('ple-qty');
            var unitEl = document.getElementById('ple-unit-cost');
            var modal = document.getElementById('purchase-line-edit-modal');
            if (!qtyEl || !unitEl || !modal) return;
            var qty = parseFloat(qtyEl.value) || 0;
            var unitDisplay = parseFloat(unitEl.value) || 0;
            var unitIqd = (typeof debtFormAmountToStoredIqd === 'function') ? debtFormAmountToStoredIqd(unitDisplay) : unitDisplay;
            var roundM = (typeof roundMoney === 'function') ? roundMoney : function (x) { return Math.round(Number(x)); };
            var totalIqd = roundM(qty * unitIqd);
            pleSetStoredTotalIqd(modal, totalIqd);
            var prod = pleEditProduct();
            var pieces = (typeof window.purchaseUnitQtyToPieces === 'function')
                ? window.purchaseUnitQtyToPieces(qty, pleEditCurrentUnit(), prod)
                : qty;
            modal.dataset.plePieces = String(pieces);
        };

        window.recalcPurchaseLineEditUnitCost = function () {
            var qtyEl = document.getElementById('ple-qty');
            var unitEl = document.getElementById('ple-unit-cost');
            var totalEl = document.getElementById('ple-total');
            var modal = document.getElementById('purchase-line-edit-modal');
            if (!qtyEl || !unitEl || !totalEl || !modal) return;
            var qty = parseFloat(qtyEl.value) || 0;
            var totalDisplay = parseFloat(totalEl.value) || 0;
            var totalIqd = (typeof debtFormAmountToStoredIqd === 'function')
                ? debtFormAmountToStoredIqd(totalDisplay)
                : totalDisplay;
            pleSetStoredTotalIqd(modal, totalIqd);
            if (qty > 0) {
                unitEl.value = pleFmtUnitCostDisplay(totalIqd / qty, qty, totalIqd);
            } else {
                unitEl.value = '0';
            }
            var prod = pleEditProduct();
            var pieces = (typeof window.purchaseUnitQtyToPieces === 'function')
                ? window.purchaseUnitQtyToPieces(qty, pleEditCurrentUnit(), prod)
                : qty;
            modal.dataset.plePieces = String(pieces);
        };

        window.savePurchaseLineEdit = function (supplyId, txnId) {
            var qtyEl = document.getElementById('ple-qty');
            var totalEl = document.getElementById('ple-total');
            var dateEl = document.getElementById('ple-date');
            var btn = document.getElementById('ple-save-btn');
            var modal = document.getElementById('purchase-line-edit-modal');
            if (!qtyEl || !totalEl) return;
            var unitQty = parseFloat(qtyEl.value) || 0;
            var prod = pleEditProduct();
            var qty = modal && modal.dataset.plePieces
                ? parseFloat(modal.dataset.plePieces) || 0
                : ((typeof window.purchaseUnitQtyToPieces === 'function')
                    ? window.purchaseUnitQtyToPieces(unitQty, pleEditCurrentUnit(), prod)
                    : unitQty);
            var totalDisplay = parseFloat(totalEl.value) || 0;
            var total = (typeof debtFormAmountToStoredIqd === 'function')
                ? debtFormAmountToStoredIqd(totalDisplay)
                : totalDisplay;
            if (typeof roundMoney === 'function') total = roundMoney(total);
            var dateVal = dateEl ? String(dateEl.value || '').trim() : '';
            if (qty <= 0) {
                if (typeof showToast === 'function') showToast('ژمارە دڤێت گەورەتر بیت لە ٠', 'error');
                return;
            }
            if (total < 0) {
                if (typeof showToast === 'function') showToast('کۆ نابیت نەرێنی', 'error');
                return;
            }
            if (!dateVal) {
                if (typeof showToast === 'function') showToast('بەروار پێدڤیە', 'error');
                return;
            }
            var supInvEl = document.getElementById('ple-supplier-invoice');
            var supInvVal = supInvEl ? String(supInvEl.value || '').trim() : '';
            if (!supInvVal) {
                if (typeof showToast === 'function') showToast('پێدڤیە ژمارا پسوولێ بنڤیسی — هەموو کۆمپانیێ دڤێت پسوول بدەت', 'error');
                if (supInvEl) { supInvEl.focus(); supInvEl.classList.add('input-error'); }
                return;
            }
            if (supInvEl) supInvEl.classList.remove('input-error');
            var batchAllowedSave = (typeof canUsePurchaseBatch === 'function') ? canUsePurchaseBatch() : true;
            var batchEl = document.getElementById('ple-batch-number');
            var batchVal = batchEl ? String(batchEl.value || '').trim() : '';
            if (batchAllowedSave) {
                if (!batchVal) {
                    if (typeof showToast === 'function') showToast('پێدڤیە ژمارا وەجبێ بنڤیسی', 'error');
                    if (batchEl) { batchEl.focus(); batchEl.classList.add('input-error'); }
                    return;
                }
                if (batchEl) batchEl.classList.remove('input-error');
            }

            var user = (typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : 'System';
            var formData = new FormData();
            formData.append('action', 'update_purchase_line');
            formData.append('supply_id', String(supplyId));
            formData.append('qtyAdded', String(qty));
            formData.append('totalCost', String(total));
            formData.append('date', dateVal);
            formData.append('supplier_invoice_number', supInvVal);
            if (batchAllowedSave) formData.append('batch_number', batchVal);
            var expChk = document.getElementById('ple-expiry-chk');
            if (expChk) {
                if (expChk.checked) {
                    var expVal = (document.getElementById('ple-expiry') || {}).value || '';
                    expVal = String(expVal).trim();
                    if (!expVal) {
                        if (typeof showToast === 'function') showToast('بەروارا بەسەرچوونێ بنووسە یان تیک لاببە', 'error');
                        return;
                    }
                    formData.append('expiry_date', expVal);
                } else {
                    formData.append('expiry_date', '');
                }
            } else {
                formData.append('expiry_date', '');
            }
            formData.append('user', user);

            if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>'; }

            fetch('?action=update_purchase_line', { method: 'POST', body: formData })
                .then(function (r) {
                    return r.text().then(function (txt) {
                        try {
                            return JSON.parse(txt);
                        } catch (e) {
                            throw new Error((txt && txt.indexOf('<') >= 0) ? 'هەڵە لە سێرڤەر — دووبارە هەوڵ بدە (Ctrl+F5)' : (txt || 'Invalid JSON'));
                        }
                    });
                })
                .then(function (data) {
                    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-save"></i> پاراستن'; }
                    if (data.status !== 'success') {
                        alert('هەڵە: ' + (data.message || 'Error'));
                        return;
                    }
                    var updated = data.supply || {};
                    updated.company_balance = data.company_balance;
                    applyPurchaseLineEditLocally(updated);
                    var editModal = document.getElementById('purchase-line-edit-modal');
                    if (editModal) editModal.style.display = 'none';
                    if (typeof showToast === 'function') {
                        if (data.stock_skipped) {
                            showToast('⚠️ مێژوو نوێکرایەوە — مەخزەن نەگۆڕدرا (پێشتر بەکارهاتووە)', 'warning');
                        } else {
                            showToast('✅ ئایتم هاتە نویکرن');
                        }
                    }
                    refreshPurchaseHistoryViews(txnId);
                    setTimeout(function () {
                        if (typeof syncLiveData === 'function') syncLiveData(false);
                    }, 150);
                })
                .catch(function (err) {
                    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-save"></i> پاراستن'; }
                    alert('هەڵە: ' + (err.message || err));
                });
        };

        window.viewInvoiceHistoryDetails = function(txnId) {
            if (!txnId) return;
            txnId = String(txnId);
            const pool = window._fullPurchaseHistory || db.supplies || [];
            let items = pool.filter(s => String(s.transaction_id || '') === txnId);
            if (items.length === 0 && Array.isArray(window._dailySummaryPurchaseLines)) {
                items = window._dailySummaryPurchaseLines.filter(s => String(s.transaction_id || '') === txnId);
            }
            if (items.length === 0 && Array.isArray(window._gphInvoices)) {
                var gInv = window._gphInvoices.find(function (x) { return String(x.txnId || '') === txnId; });
                if (gInv && Array.isArray(gInv.items) && gInv.items.length) {
                    items = gInv.items.map(function (it) {
                        return {
                            company: gInv.company || it.company || '',
                            prodId: it.prodId || 0,
                            itemName: it.itemName || it.name || '',
                            qtyAdded: parseFloat(it.qtyAdded != null ? it.qtyAdded : it.qty) || 0,
                            totalCost: parseFloat(it.totalCost) || 0,
                            date: gInv.date || it.date,
                            type: gInv.type || it.type || 'cash',
                            transaction_id: txnId,
                            supplier_invoice_number: gInv.invNum || it.supplier_invoice_number || ''
                        };
                    });
                }
            }
            if (items.length === 0) {
                var prPool = window._fullPurchaseReturnsHistory || (db && db.purchase_returns) || [];
                var pr = prPool.find(function (r) { return String(r.transaction_id || '') === txnId; });
                if (pr) {
                    var prItems = Array.isArray(pr.items) ? pr.items : [];
                    items = prItems.map(function (it) {
                        return {
                            company: pr.company_name || pr.company || '',
                            prodId: it.productId || it.prodId || 0,
                            itemName: it.productName || it.itemName || '',
                            qtyAdded: -(parseFloat(it.pieces != null ? it.pieces : it.qty) || 0),
                            totalCost: parseFloat(it.lineTotal != null ? it.lineTotal : ((it.qty || 0) * (it.costPerUnit || 0) - (it.discount || 0))) || 0,
                            date: pr.date,
                            type: 'return',
                            transaction_id: txnId,
                            supplier_invoice_number: pr.supplier_invoice_number || ''
                        };
                    });
                    if (!items.length) {
                        items = [{
                            company: pr.company_name || pr.company || '',
                            prodId: 0,
                            itemName: '',
                            qtyAdded: 0,
                            totalCost: parseFloat(pr.total) || 0,
                            date: pr.date,
                            type: 'return',
                            transaction_id: txnId,
                            supplier_invoice_number: pr.supplier_invoice_number || ''
                        }];
                    }
                }
            }
            if (items.length === 0) return;
            
            const compName = items[0].company;
            const company = (db.companies || []).find(c => c.name === compName) || { name: compName, phone: '' };
            const payType = items[0].type === 'credit' ? _compProfileT('comp_profile_hist_badge_debt', 'قەرز') : _compProfileT('comp_profile_hist_badge_cash', 'نەقد');
            const invNum = (typeof resolveCompanyInvoiceDisplayNumber === 'function')
                ? resolveCompanyInvoiceDisplayNumber(items[0].supplier_invoice_number, txnId)
                : (items[0].supplier_invoice_number || txnId);
            const dateStr = new Date(items[0].date).toLocaleString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ');
            const grandTotal = items.reduce((s,it) => s + (parseFloat(it.totalCost)||0), 0);

            // Debt history breakdown for purchase / supplier return transactions
            const companyCurrent = (db && db.companies && db.companies.find) ? (db.companies.find(c => c.name === compName) || company) : company;
            const companyBalance = parseFloat(companyCurrent?.balance || 0) || 0;
            const txType = (items[0].type || '').toString();
            const breakdownDebtAdded = (txType === 'credit') ? grandTotal : (txType === 'return' ? -grandTotal : 0);
            const breakdownCashPaid = (txType === 'cash') ? grandTotal : (txType === 'credit' ? 0 : (txType === 'return' ? 0 : 0));
            const breakdownPreviousDebt = companyBalance - breakdownDebtAdded;
            const breakdownTotalOutstandingDebt = breakdownPreviousDebt + breakdownDebtAdded;
            const supplyFxOpts = (typeof fxUsdRateFormatOpts === 'function') ? fxUsdRateFormatOpts(items[0]) : undefined;

            let a4Html = (typeof buildCompanyPurchaseA4FromSupplies === 'function')
                ? buildCompanyPurchaseA4FromSupplies(items, company, txnId, invNum)
                : '';
            if (!a4Html) {
                const logoHtml = (typeof getReceiptLogoHtml === 'function')
                    ? getReceiptLogoHtml({ mode: 'a4' })
                    : ((typeof getPosShopLogoUrl === 'function' && getPosShopLogoUrl()) ? `<img src="${getPosShopLogoUrl()}" style="max-height: 80px; max-width: 150px; object-fit: contain;" alt="">` : '');
                a4Html = `<div class="print-a4-container" style="direction:rtl; padding:20px;">${logoHtml}<p>${escapeHtml(company.name)}</p></div>`;
            }

            let modal = document.getElementById('purchase-invoice-preview-modal');
            if(!modal) {
                modal = document.createElement('div');
                modal.id = 'purchase-invoice-preview-modal';
                modal.className = 'modal-overlay';
                modal.style.cssText = 'display:none; position:fixed; inset:0; background:rgba(0,0,0,0.6); align-items:center; justify-content:center; padding:20px;';
                modal.innerHTML = `
                <div style="background:var(--card); border-radius:12px; max-width:95vw; width: 800px; max-height:90vh; display:flex; flex-direction:column; box-shadow:0 10px 40px rgba(0,0,0,0.3); position:relative;">
                    <div style="display:flex; justify-content:space-between; align-items:center; padding:15px 20px; border-bottom:1px solid var(--border); background:var(--input-bg); border-radius:12px 12px 0 0;">
                        <h3 style="margin:0; color:var(--text);">پێشبینینا وەسڵێ (Invoice Preview)</h3>
                        <div style="display:flex; gap:10px;">
                            <button class="btn btn-sm btn-dark" onclick="if(typeof printContent === 'function') printContent(document.getElementById('purchase-invoice-preview-body').innerHTML, { docType: 'purchase_invoice' });" title="چاپکرن"><i class="fas fa-print"></i> چاپکرن</button>
                            <button class="btn btn-sm btn-danger" onclick="document.getElementById('purchase-invoice-preview-modal').style.display='none';"><i class="fas fa-times"></i> داخستن</button>
                        </div>
                    </div>
                    <div id="purchase-invoice-preview-body" style="padding:20px; overflow-y:auto; flex:1; background: #94a3b8;">
                    </div>
                </div>`;
                document.body.appendChild(modal);
                modal.onclick = function(e) { if(e.target === modal) modal.style.display = 'none'; };
                if (typeof window._posWatchOverlay === 'function') window._posWatchOverlay(modal);
            }

            const body = document.getElementById('purchase-invoice-preview-body');
            if(body) body.innerHTML = `<div style="max-width:210mm; margin:0 auto; box-shadow:0 5px 15px rgba(0,0,0,0.2);">${a4Html}</div>`;
            
            modal.style.display = 'flex';
            if (typeof window.bringOverlayToFront === 'function') window.bringOverlayToFront(modal);
        };

        window.voidPurchaseInvoice = function(txnId) {
            if (!txnId) return;
            var msg = 'دڵنیای تە دڤێت ڤێ پسوولێ ژێ ببەی؟\n(ئەڤە دێ بیتە ئەگەرێ کێمکرنا مەخزەنی و گۆڕینا حساباتێن کۆمپانیێ)';
            var title = (typeof t === 'function') ? t('confirm_void_purchase_title') : 'سڕینەوەی پسوولەیا کڕینێ';
            var go = function() { _doVoidPurchaseInvoice(txnId); };
            if (typeof posConfirmDangerous === 'function') {
                posConfirmDangerous({
                    title: title,
                    message: msg,
                    confirmText: (typeof t === 'function') ? t('confirm_void_btn') : 'بەڵێ، ژێ ببە'
                }).then(function(confirmed) {
                    if (confirmed) go();
                });
            } else if (typeof posConfirm === 'function') {
                posConfirm({
                    title: title,
                    message: msg,
                    tone: 'danger',
                    confirmText: 'بەڵێ، ژێ ببە',
                    requirePhrase: String(1000 + Math.floor(Math.random() * 9000)),
                    phraseNumeric: true,
                    confirmDelayMs: 1500
                }).then(function(confirmed) {
                    if (confirmed) go();
                });
            } else {
                if (!confirm('⚠️ ' + msg)) return;
                go();
            }
        };

        function _doVoidPurchaseInvoice(txnId) {
            var user = (typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : 'System';
            var formData = new FormData();
            formData.append('action', 'delete_purchase_invoice');
            formData.append('transaction_id', txnId);
            formData.append('user', user);
            formData.append('log_void', '1');

            fetch('?action=delete_purchase_invoice', { method: 'POST', body: formData })
                .then(r => r.json())
                .then(data => {
                    if (data.status === 'success') {
                        if (typeof showToast === 'function') {
                            showToast('✅ پسوولە هاتە ژێبرن', 'success', {
                                actionLabel: (typeof t === 'function') ? t('btn_undo_void') : 'پەشێمان بم',
                                durationMs: 12000,
                                onAction: function() {
                                    if (typeof restoreVoidedPurchase === 'function') restoreVoidedPurchase(txnId);
                                }
                            });
                        } else alert('✅ پسوولە ب سەرکەفتیانە هاتە ژێبرن');
                        var voidDateIso = null;
                        try {
                            var voidSrc = (window._dailySummaryPurchaseLines || db.supplies || []).find(function(s) {
                                return s && String(s.transaction_id || '') === String(txnId);
                            });
                            if (voidSrc && voidSrc.date && typeof getBusinessDate === 'function' && typeof parseSQLDate === 'function') {
                                voidDateIso = getBusinessDate(parseSQLDate(voidSrc.date));
                            }
                        } catch (_eVd) {}
                        db.supplies = db.supplies.filter(s => s.transaction_id !== txnId);
                        if (window._fullPurchaseHistory) {
                            window._fullPurchaseHistory = window._fullPurchaseHistory.filter(s => s.transaction_id !== txnId);
                        }
                        if (window._dailySummaryPurchaseLines) {
                            window._dailySummaryPurchaseLines = window._dailySummaryPurchaseLines.filter(function(s) {
                                return !s || String(s.transaction_id || '') !== String(txnId);
                            });
                        }
                        if (db.purchase_returns && Array.isArray(db.purchase_returns)) {
                            db.purchase_returns = db.purchase_returns.filter(function (r) {
                                return !r || r.transaction_id !== txnId;
                            });
                        }
                        db.ledger = db.ledger.filter(l => l.transaction_id !== txnId);
                        if (typeof renderCompanyHistory === 'function') renderCompanyHistory();
                        if (typeof renderLedgerHistory === 'function') renderLedgerHistory();
                        if (typeof renderCurrentModule === 'function') renderCurrentModule();
                        var dailyModal = document.getElementById('daily-history-modal');
                        if (dailyModal && dailyModal.style.display === 'flex' && typeof openDailyHistoryModal === 'function') {
                            try {
                                if (window._dailyDetailCache) {
                                    Object.keys(window._dailyDetailCache).forEach(function(k) {
                                        try { delete window._dailyDetailCache[k]; } catch (_e) {}
                                    });
                                }
                            } catch (_eCache) {}
                            openDailyHistoryModal(voidDateIso || undefined);
                            setTimeout(function() {
                                if (typeof openDailySummaryDetailSheet === 'function') {
                                    openDailySummaryDetailSheet('daily-sec-purchases');
                                }
                            }, 350);
                        }
                        setTimeout(function() { if (typeof syncLiveData === 'function') syncLiveData(false); }, 150);
                    } else {
                        if (typeof window.posAlert === 'function') window.posAlert({ message: data.message || 'Error deleting invoice', tone: 'danger' });
                        else alert('هەڵە: ' + (data.message || 'Error deleting invoice'));
                    }
                })
                .catch(err => {
                    if (typeof window.posAlert === 'function') window.posAlert({ message: err.message, tone: 'danger' });
                    else alert('هەڵە: ' + err.message);
                });
        }

        window.editPurchaseInvoice = function(txnId) {
            if (!txnId) return;
            if (typeof startEditPurchaseInCart === 'function') {
                startEditPurchaseInCart(txnId);
                return;
            }
            if (!confirm("⚠️ بۆ دەستکاریکرنێ، پسوولەیا کەڤن دێ هێتە ژێبرن و دێ چیتە سەبەتا کرینێ. بەردەوام دبی؟")) return;
            
            const pool = window._fullPurchaseHistory || db.supplies || [];
            const items = pool.filter(s => s.transaction_id === txnId);
            if (!items || items.length === 0) return;
            const compName = items[0].company;
            const payType = items[0].type;
            const invNum = items[0].supplier_invoice_number || '';
            
            var user = (typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : 'System';
            var formData = new FormData();
            formData.append('action', 'delete_purchase_invoice');
            formData.append('transaction_id', txnId);
            formData.append('user', user);

            fetch('?action=delete_purchase_invoice', { method: 'POST', body: formData })
                .then(r => r.json())
                .then(data => {
                    if (data.status === 'success') {
                        db.supplies = db.supplies.filter(s => s.transaction_id !== txnId);
                        db.ledger = db.ledger.filter(l => l.transaction_id !== txnId);
                        
                        if (typeof closeCompanyProfile === 'function') closeCompanyProfile();
                        if (typeof nav === 'function') nav('purchase');
                        
                        setTimeout(() => {
                            purchaseCart = [];
                            items.forEach(it => {
                                purchaseCart.push({
                                    productId: it.prodId,
                                    productName: it.itemName,
                                    qty: it.qtyAdded,
                                    unit: 'piece', 
                                    costPerUnit: it.totalCost / it.qtyAdded,
                                    discount: 0
                                });
                            });
                            
                            var sel = document.getElementById('purchase-supplier-select');
                            if (sel && compName) {
                                const c = db.companies.find(x => x.name === compName);
                                if (c) sel.value = c.id;
                            }
                            
                            var payTypeHid = document.getElementById('purchase-payment-type-value');
                            if (payTypeHid) payTypeHid.value = payType;
                            
                            var invNumEl = document.getElementById('purchase-supplier-invoice-number');
                            if (invNumEl) invNumEl.value = invNum;
                            
                            if (typeof renderPurchaseCart === 'function') renderPurchaseCart();
                        }, 50);
                        
                    } else {
                        alert('هەڵە: ' + (data.message || 'Error deleting invoice'));
                    }
                })
                .catch(err => alert('هەڵە: ' + err.message));
        };

        function renderLedgerHistory(compId) {
            if (typeof ensureDateFilterToday === 'function') ensureDateFilterToday('cp-ledger');
            if(!compId) compId = currentViewingCompanyId;
            if(!compId) return;
            const list = document.getElementById('cp-ledger-list');
            if(!db.ledger) db.ledger = [];
            
            const comp = db.companies.find(c => c.id === compId);
            if (!comp) return;

            // Step 1: Get all ledger entries for this company, sort newest first
            const allEntries = db.ledger.filter(l => l.companyId === compId).sort((a, b) => b.id - a.id);
            
            // Step 2: Calculate running balance working backwards from current balance
            let currentBal = parseFloat(comp.balance) || 0;
            var startBalFx = (typeof fxUsdRateFormatOptsForEntityBalance === 'function')
                ? fxUsdRateFormatOptsForEntityBalance(comp.id, 'company', currentBal)
                : undefined;
            var currentBalUsd = (typeof storedIqdToUsdDisplayAmount === 'function')
                ? storedIqdToUsdDisplayAmount(currentBal, startBalFx)
                : 0;
            if (startBalFx && startBalFx.directUsd != null && Number.isFinite(Number(startBalFx.directUsd))) {
                currentBalUsd = Number(startBalFx.directUsd);
            }
            var lockUsdPerIqd = (currentBal > 0.0001 && currentBalUsd) ? (currentBalUsd / currentBal) : 0;
            allEntries.forEach(l => {
                l._running_balance = currentBal;
                l._running_balance_usd = currentBalUsd;
                l._line_fx = (typeof fxUsdRateFormatOpts === 'function') ? fxUsdRateFormatOpts(l) : undefined;
                let amt = Math.abs(parseFloat(l.amount) || 0);
                let amtUsd = (typeof storedIqdToUsdDisplayAmount === 'function')
                    ? storedIqdToUsdDisplayAmount(amt, l._line_fx)
                    : amt;
                if (!(amtUsd > 0) && amt > 0 && lockUsdPerIqd > 0) {
                    amtUsd = Math.round(amt * lockUsdPerIqd * 100) / 100;
                }
                let effect = 0;
                let effectUsd = 0;
                // 'credit_purchase' and 'receive' increase our debt to the supplier
                if (l.type === 'credit_purchase' || l.type === 'receive') {
                    effect = amt;
                    effectUsd = amtUsd;
                }
                // 'payment' and 'return_to_supplier' decrease our debt to the supplier
                else if (l.type === 'payment' || l.type === 'pay' || l.type === 'return_to_supplier') {
                    effect = -amt;
                    effectUsd = -amtUsd;
                }
                currentBal = currentBal - effect;
                currentBalUsd = currentBalUsd - effectUsd;
            });

            // Step 3: Filter by date scope for display
            const entries = allEntries.filter(l => isDateInScope(l.date, 'cp-ledger'));
            
            const balance = comp ? (parseFloat(comp.balance) || 0) : 0;
            const totalDebt = entries.filter(l => l.type === 'credit_purchase').reduce((s, l) => s + Math.abs(parseFloat(l.amount) || 0), 0);
            const totalPaid = entries.filter(l => l.type === 'payment' || l.type === 'pay').reduce((s, l) => s + Math.abs(parseFloat(l.amount) || 0), 0);
            const totalReturn = entries.filter(l => l.type === 'return_to_supplier').reduce((s, l) => s + Math.abs(parseFloat(l.amount) || 0), 0);
            var sumUsdRows = function (rows) {
                return rows.reduce(function (s, l) {
                    var amt = Math.abs(parseFloat(l.amount) || 0);
                    var fx = l._line_fx || ((typeof fxUsdRateFormatOpts === 'function') ? fxUsdRateFormatOpts(l) : undefined);
                    var u = (typeof storedIqdToUsdDisplayAmount === 'function') ? storedIqdToUsdDisplayAmount(amt, fx) : 0;
                    return s + u;
                }, 0);
            };
            var fmtBal = formatCurrency(balance, startBalFx);
            var fmtDebt = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD')
                ? formatCurrency(0, { directUsd: sumUsdRows(entries.filter(function (l) { return l.type === 'credit_purchase'; })) })
                : formatCurrency(totalDebt);
            var fmtPaid = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD')
                ? formatCurrency(0, { directUsd: sumUsdRows(entries.filter(function (l) { return l.type === 'payment' || l.type === 'pay'; })) })
                : formatCurrency(totalPaid);
            var fmtRet = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD')
                ? formatCurrency(0, { directUsd: sumUsdRows(entries.filter(function (l) { return l.type === 'return_to_supplier'; })) })
                : formatCurrency(totalReturn);
            var summaryInner = 'کەشفێ حیسابا دابینکەری: ڕەسیدێ نوکە (قەرزێ مە): ' + fmtBal + ' | کۆیا کڕینێ (قەرز): ' + fmtDebt + ' | پارەیێ هاتیە دان: ' + fmtPaid + ' | زڤڕاندن: ' + fmtRet;
            if (typeof t === 'function') {
                var tpl = String(t('comp_supplier_ledger_summary_tpl') || '');
                if (tpl && tpl !== 'comp_supplier_ledger_summary_tpl') {
                    summaryInner = tpl.replace(/\{b\}/g, fmtBal).replace(/\{d\}/g, fmtDebt).replace(/\{p\}/g, fmtPaid).replace(/\{r\}/g, fmtRet);
                }
            }
            const summaryRow = '<tr style="background:var(--input-bg); font-weight:bold;"><td colspan="6" style="padding:10px; border-radius:8px;">' + escapeHtml(summaryInner) + '</td></tr>';
            
            var emptyLed = (typeof t === 'function') ? t('comp_ledger_no_entries') : 'چ لڤین نینن';
            if(entries.length === 0) { list.innerHTML = summaryRow + '<tr><td colspan="6" style="text-align:center;color:#999">' + escapeHtml(emptyLed) + '</td></tr>'; return; }

            function mapLedgerType(type) {
                var tf = (typeof t === 'function');
                if (type === 'credit_purchase') return { label: tf ? t('sup_led_credit_purchase') : 'کڕین (قەرز)', color: '#dc2626', icon: 'fa-arrow-down' };
                if (type === 'return_to_supplier') return { label: tf ? t('sup_led_return_supplier') : 'زڤڕاندن بۆ کۆمپانیێ', color: '#f59e0b', icon: 'fa-undo' };
                if (type === 'payment' || type === 'pay') return { label: tf ? t('sup_led_payment') : 'پارە هاتە دان', color: '#16a34a', icon: 'fa-arrow-up' };
                if (type === 'purchase') return { label: tf ? t('sup_led_purchase_cash') : 'کڕین ب کاش', color: '#2563eb', icon: 'fa-cash-register' };
                if (type === 'receive') return { label: tf ? t('sup_led_receive') : 'پارە هاتە وەرگرتن (قەرزێ مە زێدەبوو)', color: '#dc2626', icon: 'fa-arrow-down' };
                return { label: (type ? (tf ? t('sup_led_movement') + ': ' + type : type) : (tf ? t('sup_led_movement') : 'لڤین')), color: 'var(--text-muted)', icon: 'fa-receipt' };
            }
            function txSummary(l) {
                var tx = l && l.transaction_id ? String(l.transaction_id) : '';
                if (!tx) return { qty: 0, lines: 0, items: '', invNo: '' };
                var lines = (db.supplies || []).filter(function(s) {
                    return String(s.transaction_id || '') === tx && String(s.company || '') === String(comp.name || '');
                });
                if (!lines.length) return { qty: 0, lines: 0, items: '', invNo: '' };
                var qty = 0;
                var names = [];
                var invNo = '';
                lines.forEach(function(s) {
                    qty += Math.abs(parseFloat(s.qtyAdded) || 0);
                    if (s.itemName && names.indexOf(s.itemName) < 0) names.push(s.itemName);
                    if (!invNo && s.supplier_invoice_number) invNo = s.supplier_invoice_number;
                });
                return { qty: qty, lines: lines.length, items: names.slice(0, 5).join('، '), invNo: invNo };
            }

            const canEditPurchaseLine = (typeof currentUser !== 'undefined' && currentUser && currentUser.role === 'admin') || (typeof checkPermission === 'function' && checkPermission('companies_manage'));

            list.innerHTML = summaryRow + entries.map(l => {
                const meta = mapLedgerType(l.type);
                const sx = txSummary(l);
                const typeHtml = '<span style="color:' + meta.color + '; font-weight:bold"><i class="fas ' + meta.icon + '"></i> ' + escapeHtml(meta.label) + '</span>';
                var noteParts = [];
                if (l.transaction_id) noteParts.push('<div><b>TX:</b> <code style="background:none;padding:0;">' + escapeHtml(String(l.transaction_id)) + '</code></div>');
                if (sx.invNo) noteParts.push('<div><b>' + escapeHtml(_compProfileT('comp_ledger_note_invoice', 'وەسڵا کۆمپانیێ:')) + '</b> ' + escapeHtml(String(sx.invNo)) + '</div>');
                if (sx.lines > 0) noteParts.push('<div><b>' + escapeHtml(_compProfileT('comp_ledger_note_items', 'ئایتم:')) + '</b> ' + sx.lines + ' | <b>' + escapeHtml(_compProfileT('comp_ledger_note_qty', 'دانە:')) + '</b> ' + formatCurrency(sx.qty) + '</div>');
                if (sx.items) noteParts.push('<div style="white-space:normal;"><b>' + escapeHtml(_compProfileT('comp_ledger_note_names', 'ناڤ:')) + '</b> ' + escapeHtml(sx.items) + '</div>');
                if (l.related_id) noteParts.push('<div><b>Ref:</b> #' + escapeHtml(String(l.related_id)) + '</div>');
                if (l.note) noteParts.push('<div style="white-space:normal; margin-top:4px;"><b>' + escapeHtml(_compProfileT('comp_profile_ledger_col_note', 'تێبینی:')) + '</b> ' + escapeHtml(l.note) + '</div>');
                
                let amountColor = '#16a34a'; 
                let amountPrefix = '';
                if (l.type === 'credit_purchase' || l.type === 'receive') {
                    amountColor = '#dc2626';
                    amountPrefix = '+ ';
                } else if (l.type === 'payment' || l.type === 'pay' || l.type === 'return_to_supplier') {
                    amountColor = '#16a34a';
                    amountPrefix = '- ';
                } else {
                    amountColor = 'var(--text)';
                }

                let rowAction = '';
                if (l.transaction_id && typeof viewInvoiceHistoryDetails === 'function') {
                    rowAction = `onclick="viewInvoiceHistoryDetails('${String(l.transaction_id).replace(/'/g, "\\'")}')" style="cursor:pointer; transition:0.2s;" onmouseover="this.style.background='var(--input-bg)'" onmouseout="this.style.background='transparent'" title="${escapeHtml(_compProfileT('comp_profile_hist_btn_view', 'بینینا وەسڵێ'))}"`;
                }

                var actionBtns = '';
                if (l.type === 'credit_purchase' || l.type === 'purchase') {
                    var purchaseTxn = String(l.transaction_id || '');
                    if (purchaseTxn) {
                        var invRemCo = (typeof window.getCompanyInvoiceRemainingDebt === 'function')
                            ? window.getCompanyInvoiceRemainingDebt(purchaseTxn)
                            : 0;
                        actionBtns = '<div style="display:flex; gap:6px; justify-content:center; flex-wrap:wrap;">';
                        if (l.type === 'credit_purchase' && invRemCo > 0.0001) {
                            actionBtns += '<button type="button" class="btn btn-sm btn-success" onclick="payCompanyInvoiceDebt(' + JSON.stringify(purchaseTxn) + ',' + invRemCo + ')" title="' + escapeHtml((typeof t === 'function' && t('cdm_pay_invoice') !== 'cdm_pay_invoice') ? t('cdm_pay_invoice') : 'پارەدانی فاتورە') + '"><i class="fas fa-hand-holding-usd"></i></button>';
                        }
                        actionBtns += (canEditPurchaseLine ? '<button type="button" class="btn btn-sm btn-primary" onclick="editCompanyPurchaseInLedger(\'' + purchaseTxn.replace(/'/g, "\\'") + '\')" title="تەعدیل (Edit)"><i class="fas fa-edit"></i></button>' : '') +
                            '<button type="button" class="btn btn-sm btn-danger" onclick="deleteCompanyPurchaseInLedger(\'' + purchaseTxn.replace(/'/g, "\\'") + '\')" title="ژێبرن (Delete)"><i class="fas fa-trash-alt"></i></button>' +
                        '</div>';
                    }
                } else if (l.type === 'payment' || l.type === 'pay' || l.type === 'receive') {
                    actionBtns = '<div style="display:flex; gap:6px; justify-content:center;">' +
                        '<button type="button" class="btn btn-sm btn-primary" onclick="editCompanyPayment(' + l.id + ', ' + Math.abs(l.amount) + ')" title="تەعدیل (Edit)"><i class="fas fa-edit"></i></button>' +
                        '<button type="button" class="btn btn-sm btn-danger" onclick="deleteCompanyPayment(' + l.id + ')" title="ژێبرن (Delete)"><i class="fas fa-trash-alt"></i></button>' +
                    '</div>';
                }

                return `<tr ${rowAction}>
                    <td style="white-space:nowrap;">${new Date(l.date).toLocaleString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ')}</td>
                    <td>${typeHtml}</td>
                    <td style="font-weight:900; color:${amountColor}; font-size:1.05rem;" dir="ltr">${amountPrefix}${formatCurrency(Math.abs(l.amount), l._line_fx)}</td>
                    <td style="font-weight:900; color:var(--brand); font-size:1.1rem; background:var(--input-bg); border-radius:6px; text-align:center;" dir="ltr">${(typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD' && l._running_balance_usd != null) ? formatCurrency(0, { directUsd: l._running_balance_usd }) : formatCurrency(l._running_balance)}</td>
                    <td style="font-size:0.85rem; line-height:1.6; max-width:250px;">${noteParts.join('')}</td>
                    <td style="text-align:center;" onclick="event.stopPropagation()">${actionBtns}</td>
                </tr>`;
            }).join('');
            if (typeof applyCompanyProfileUi === 'function') applyCompanyProfileUi();
        }

        window.deleteCompanyPurchaseInLedger = function(txnId) {
            if (!txnId) return;
            if (typeof voidPurchaseInvoice === 'function') voidPurchaseInvoice(txnId);
        };

        window.editCompanyPurchaseInLedger = function(txnId) {
            if (!txnId) return;
            if (typeof startEditPurchaseInCart === 'function') {
                startEditPurchaseInCart(txnId);
                return;
            }
            if (typeof openPurchaseInvoiceDetailModal === 'function') {
                openPurchaseInvoiceDetailModal(txnId);
            } else if (typeof viewInvoiceHistoryDetails === 'function') {
                viewInvoiceHistoryDetails(txnId);
            } else if (typeof window.posAlert === 'function') {
                window.posAlert({ message: 'مۆدالا دەستکاری بەردەست نییە', tone: 'warning' });
            }
        };

        window.deleteCompanyPayment = function(id) {
            var msg = 'دڵنیای دڤێت ڤی پارەی ڕەش بکەی؟\n(دێ ڕاستەوخۆ کار کەتە سەر قەرزێ کۆمپانیایێ و خەزنەی)';
            var go = function() { _doDeleteCompanyPayment(id); };
            if (typeof posConfirmDangerous === 'function') {
                posConfirmDangerous({
                    title: 'سڕینەوەی پارەدان',
                    message: msg,
                    confirmText: 'بەڵێ، ڕەش بکە'
                }).then(function(confirmed) {
                    if (confirmed) go();
                });
            } else if (typeof posConfirm === 'function') {
                posConfirm({
                    title: 'سڕینەوەی پارەدان',
                    message: msg,
                    tone: 'danger',
                    confirmText: 'بەڵێ، ڕەش بکە',
                    requirePhrase: String(1000 + Math.floor(Math.random() * 9000)),
                    phraseNumeric: true,
                    confirmDelayMs: 1500
                }).then(function(confirmed) {
                    if (confirmed) go();
                });
            } else {
                if (!confirm(msg)) return;
                go();
            }
        };

        function _doDeleteCompanyPayment(id) {
            var formData = new FormData();
            formData.append('action', 'delete_company_payment');
            formData.append('id', String(id));
            formData.append('user', (typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : 'System');
            
            fetch('?action=delete_company_payment', { method: 'POST', body: formData })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (data.status !== 'success') {
                        if (typeof window.posAlert === 'function') window.posAlert({ message: data.message || 'Error', tone: 'danger' });
                        else if (typeof showToast === 'function') showToast('هەڵە: ' + (data.message || 'Error'), 'error');
                        else alert('هەڵە: ' + (data.message || 'Error'));
                        return;
                    }
                    if (typeof showToast === 'function') showToast('✅ پارە هاتە سڕینەوە');
                    setTimeout(function() { if (typeof syncLiveData === 'function') syncLiveData(false); }, 150);
                    setTimeout(function() { if (typeof renderLedgerHistory === 'function') renderLedgerHistory(); }, 500);
                })
                .catch(function(err) {
                    if (typeof window.posAlert === 'function') window.posAlert({ message: err.message || String(err), tone: 'danger' });
                    else if (typeof showToast === 'function') showToast('هەڵە: ' + (err.message || err), 'error');
                    else alert('هەڵە: ' + (err.message || err));
                });
        };

        window.editCompanyPayment = function(id, currentAmount) {
            var modal = document.getElementById('edit-payment-modal');
            if (!modal) return;
            
            document.getElementById('epm-payment-id').value = id;
            document.getElementById('epm-current-amount').value = currentAmount;
            
            // Re-use the customer edit payment modal UI, but with a different save function flag
            // Let's use a dataset attribute to distinguish
            modal.dataset.mode = 'company';
            
            var sym = (typeof getCurrencySymbol === 'function') ? getCurrencySymbol() : 'IQD';
            document.getElementById('epm-currency-sym').textContent = sym;
            
            var displayAmt = (typeof formatCurrency === 'function') ? formatCurrency(currentAmount) : currentAmount;
            document.getElementById('epm-old-amount-display').textContent = displayAmt + ' ' + sym;
            
            var inputEl = document.getElementById('epm-new-amount');
            inputEl.value = currentAmount;
            
            modal.style.display = 'flex';
            setTimeout(function() {
                inputEl.focus();
                inputEl.select();
            }, 100);
        };

        window.renderCompanyReceipts = function() {
            var tbody = document.getElementById('cp-receipts-list');
            if (!tbody) return;
            var comp = (db.companies || []).find(function(c) { return c.id === currentViewingCompanyId; });
            if (!comp) { tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;">چ کۆمپانی دیارنەکرینە.</td></tr>'; return; }
            var q = ((document.getElementById('cp-receipts-search') || {}).value || '').trim().toLowerCase();
            var ledgerRows = (db.ledger || []).filter(function(l) { return l.companyId === comp.id; }).map(function(l) {
                return {
                    date: l.date,
                    type: l.type || '',
                    ref: l.transaction_id || ('#' + (l.id || '')),
                    details: l.note || '',
                    amount: parseFloat(l.amount) || 0,
                    raw: l
                };
            });
            var supplyRows = (db.supplies || []).filter(function(s) { return s.company === comp.name; }).map(function(s) {
                var kind = (s.type === 'return') ? 'purchase_return_line' : 'purchase_line';
                return {
                    date: s.date,
                    type: kind,
                    ref: s.transaction_id || ('SUP-' + (s.id || '')),
                    details: (s.itemName || '-') + ' | qty=' + (s.qtyAdded || 0) + (s.supplier_invoice_number ? (' | inv=' + s.supplier_invoice_number) : ''),
                    amount: parseFloat(s.totalCost) || 0,
                    raw: s
                };
            });
            var purchaseReturnRows = (db.purchase_returns || []).filter(function(pr) { return Number(pr.company_id) === Number(comp.id); }).map(function(pr) {
                return {
                    date: pr.date,
                    type: 'purchase_return_receipt',
                    ref: pr.transaction_id || ('PR-' + (pr.id || '')),
                    details: 'items=' + ((pr.items && pr.items.length) ? pr.items.length : 0) + (pr.supplier_invoice_number ? (' | inv=' + pr.supplier_invoice_number) : ''),
                    amount: parseFloat(pr.total) || 0,
                    raw: pr
                };
            });
            var rows = ledgerRows.concat(supplyRows).concat(purchaseReturnRows).sort(function(a, b) { return new Date(b.date || 0) - new Date(a.date || 0); });
            if (q) {
                rows = rows.filter(function(r) {
                    var txt = (String(r.type) + ' ' + String(r.ref) + ' ' + String(r.details) + ' ' + String(r.amount)).toLowerCase();
                    return txt.indexOf(q) >= 0;
                });
            }
            if (!rows.length) { tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; color:var(--text-muted);">چ وەسڵ بۆ ڤێ کۆمپانیێ نینن.</td></tr>'; return; }
            tbody.innerHTML = rows.slice(0, 500).map(function(r) {
                var t = (r.type || '').toLowerCase();
                var label = (t === 'credit_purchase') ? 'کڕین ب قەرز' : (t === 'payment' || t === 'pay') ? 'دانەڤا قەرزی' : (t === 'receive') ? 'وەرگرتنا قەرزی' : (t === 'return_to_supplier') ? 'زڤڕاندنا کڕینێ' : (t === 'purchase') ? 'کڕین ب کاش' : (t === 'purchase_return_receipt') ? 'وەسڵا زڤڕاندنا کڕینێ' : (t === 'purchase_line') ? 'هویرکاریا کڕینێ' : (t === 'purchase_return_line') ? 'هویرکاریا زڤڕاندنێ' : (r.type || 'لڤین');
                return '<tr>' +
                    '<td>' + new Date(r.date).toLocaleString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ') + '</td>' +
                    '<td><span class="badge badge-doc">' + escapeHtml(label) + '</span></td>' +
                    '<td><code>' + escapeHtml(String(r.ref || '-')) + '</code></td>' +
                    '<td style="font-size:0.9rem;">' + escapeHtml(String(r.details || '-')) + '</td>' +
                    '<td style="font-weight:800;">' + formatCurrency(r.amount || 0) + '</td>' +
                    '<td><button class="btn btn-sm btn-dark" onclick="printCompanyReceiptFromRow(\'' + String(r.ref || '').replace(/'/g, "\\'") + '\')" title="چاپکرن"><i class="fas fa-print"></i></button></td>' +
                '</tr>';
            }).join('');
        }

        function renderCompanyReceiptsArchive() {
            var tbody = document.getElementById('cp-receipts-archive-list');
            if (!tbody) return;
            var comp = (db.companies || []).find(function(c) { return c.id === currentViewingCompanyId; });
            if (!comp) { tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;">چ کۆمپانی دیارنەکرینە.</td></tr>'; return; }
            var q = ((document.getElementById('cp-receipts-archive-search') || {}).value || '').trim().toLowerCase();
            var rows = (db.print_log || []).filter(function(p) {
                var txt = ((p.note || '') + ' ' + (p.details || '') + ' ' + (p.doc_id || '') + ' ' + (p.doc_type || '')).toLowerCase();
                var byCompanyName = txt.indexOf((comp.name || '').toLowerCase()) >= 0;
                var byDocType = (p.doc_type === 'company_ledger' || p.doc_type === 'purchase_invoice' || p.doc_type === 'purchase_return');
                return byDocType && (byCompanyName || txt.indexOf(String(comp.id)) >= 0);
            }).sort(function(a, b) { return new Date((b.created_at || '').replace(' ', 'T')) - new Date((a.created_at || '').replace(' ', 'T')); });
            if (q) {
                rows = rows.filter(function(r) {
                    var txt = ((r.doc_type || '') + ' ' + (r.doc_id || '') + ' ' + (r.user || '') + ' ' + (r.note || '') + ' ' + (r.details || '')).toLowerCase();
                    return txt.indexOf(q) >= 0;
                });
            }
            if (!rows.length) { tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; color:var(--text-muted);">چ ئەرشیف بۆ ڤێ کۆمپانیێ نینن.</td></tr>'; return; }
            tbody.innerHTML = rows.slice(0, 400).map(function(r) {
                var createdAt = r.created_at ? new Date(r.created_at.replace(' ', 'T')).toLocaleString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ') : '-';
                return '<tr>' +
                    '<td>' + escapeHtml(createdAt) + '</td>' +
                    '<td><span class="badge badge-doc">' + escapeHtml(r.doc_type || '-') + '</span></td>' +
                    '<td>' + escapeHtml(String(r.doc_id || '-')) + '</td>' +
                    '<td>' + escapeHtml(r.user || '-') + '</td>' +
                    '<td style="font-size:0.9rem;">' + escapeHtml(r.note || '-') + '</td>' +
                    '<td style="font-size:0.85rem; color:var(--text-muted);">' + escapeHtml(r.details || '-') + '</td>' +
                '</tr>';
            }).join('');
        }

        function printCompanyReceiptFromRow(ref) {
            var comp = (db.companies || []).find(function(c) { return c.id === currentViewingCompanyId; });
            if (!comp || !ref) return;
            var tx = String(ref);
            var lines = (db.supplies || []).filter(function(s) { return String(s.transaction_id || '') === tx && String(s.company || '') === String(comp.name || ''); });
            var ledgerLine = (db.ledger || []).find(function(l) { return String(l.transaction_id || '') === tx && Number(l.companyId) === Number(comp.id); });
            var amount = ledgerLine ? (parseFloat(ledgerLine.amount) || 0) : lines.reduce(function(sum, x) { return sum + (parseFloat(x.totalCost) || 0); }, 0);
            var details = lines.length ? lines.map(function(x) { return (x.itemName || '-') + ' x ' + (x.qtyAdded || 0); }).join(' | ') : (ledgerLine && ledgerLine.note ? ledgerLine.note : '-');
            var html = (typeof buildReportHtml === 'function')
                ? buildReportHtml('پسوولەیا کۆمپانیێ', new Date().toLocaleString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ'), '', '<table class="print-table"><tr><th>کۆمپانیا</th><td>' + escapeHtml(comp.name || '') + '</td></tr><tr><th>ناسناما</th><td>' + escapeHtml(tx) + '</td></tr><tr><th>کوژم</th><td>' + formatCurrency(amount) + '</td></tr><tr><th>هویرکاری</th><td>' + escapeHtml(details) + '</td></tr></table>')
                : '';
            if (html && typeof routePrint === 'function') routePrint('company_ledger', html, { docId: tx, details: 'company_profile_receipt' });
            else if (html && typeof printContent === 'function') printContent(html);
        }

        function toggleSupplyForm(isReturn = false) {
            const form = document.getElementById('new-supply-form');
            const isHidden = form.style.display === 'none' || form.style.display === '';
            form.style.display = isHidden ? 'block' : 'none';
            
            isSupplyReturnMode = isReturn;
            const btn = document.getElementById('btn-save-supply');
            if(isReturn) {
                form.classList.add('supply-return-mode');
                btn.innerHTML = '<i class="fas fa-undo"></i> زڤڕاندن (Return)';
            } else {
                form.classList.remove('supply-return-mode');
                btn.innerHTML = '<i class="fas fa-check-circle"></i> تۆمارکرن';
            }

            if(isHidden) {
                const comp = db.companies.find(c => c.id === currentViewingCompanyId);
                document.getElementById('supply-comp-name').innerText = comp.name;
                const grid = document.getElementById('supply-item-grid'); grid.innerHTML = '';
                const prods = db.products.filter(p => p.supplier === comp.name);
                
                // Reset Info Box
                document.getElementById('supply-selected-info').innerHTML = '<i class="fas fa-box-open" style="font-size:3rem; opacity:0.3;"></i><p style="margin-top:10px; color:var(--text-muted)">هیچ ئایتمەک نەهاتیە هەڵبژارتن</p>';
                document.getElementById('supply-selected-info').classList.remove('active');

                if(prods.length === 0) { grid.innerHTML = '<div style="grid-column:span 3; text-align:center; padding:40px; color:var(--text-muted);"><i class="fas fa-box-open" style="font-size:3rem; margin-bottom:10px;"></i><br>چ ئایتم نەهاتینە پێناسەکرن بۆ ڤێ کۆمپانیێ.</div>'; return; }
                prods.forEach(p => {
                    let icon = 'fa-box';
                    if(p.cat === 'Drinks') icon = 'fa-wine-bottle';
                    if(p.cat === 'Food') icon = 'fa-utensils';
                    
                    grid.innerHTML += `
                    <div class="supply-item-card" id="sel-card-${p.id}" onclick="selectSupplyItem(${p.id})">
                        <i class="fas ${icon}"></i>
                        <b>${escapeHtml(p.name || 'ئایتم')}</b>
                        <small style="color:var(--info)">${formatCurrency(p.cost)}</small>
                        ${p.trackStock ? `<span style="font-size:0.7rem; color:var(--text-muted); margin-top:5px;">Stock: ${p.qty}</span>` : ''}
                    </div>`;
                });
                selectedSupplyProdId = null; document.getElementById('supply-selected-prod-id').value = "";
                document.getElementById('supply-unit-cost').value = '';
                document.getElementById('supply-carton-cost').value = '';
                const barInput = document.getElementById('supply-barcode'); 
                if(barInput) { 
                    barInput.value = ''; 
                    // Only focus if desktop (No Touch)
                    if(window.innerWidth > 1290 && navigator.maxTouchPoints === 0) setTimeout(() => barInput.focus(), 100); 
                }
            }
        }

        function selectSupplyItem(id) {
            document.querySelectorAll('.supply-item-card').forEach(el => el.classList.remove('selected'));
            const card = document.getElementById('sel-card-'+id);
            if(card) card.classList.add('selected');
            
            selectedSupplyProdId = id; 
            document.getElementById('supply-selected-prod-id').value = id;
            
            // Update Info Box
            const p = db.products.find(x => x.id === id);
            const infoBox = document.getElementById('supply-selected-info');
            if(p) {
                infoBox.innerHTML = `<h3 style="margin:0; color:var(--brand)">${escapeHtml(p.name || 'ئایتم')}</h3><p style="margin:5px 0; color:#666">Cost: ${formatCurrency(p.cost)}</p>`;
                infoBox.classList.add('active');
                document.getElementById('supply-unit-cost').value = p.cost;
                document.getElementById('supply-carton-cost').value = p.cost * (p.itemsPerCarton || 1);
                
                // Update Entry Unit Dropdown based on product capabilities (Zero Loss System)
                updateSupplyEntryUnitOptions(p);
            }
            
            autoCalcSupply('qty');
        }

        // Zero Loss System: Update Entry Unit dropdown based on product capabilities
        function updateSupplyEntryUnitOptions(product) {
            let entryUnitSelect = document.getElementById('supply-entry-unit');
            if (!entryUnitSelect) return;
            
            // Morph SELECT into HIDDEN input + BUTTONS if not already done
            if (entryUnitSelect.tagName === 'SELECT') {
                const hidden = document.createElement('input');
                hidden.type = 'hidden';
                hidden.id = 'supply-entry-unit';
                hidden.value = entryUnitSelect.value || 'carton';
                
                const btnGroup = document.createElement('div');
                btnGroup.id = 'supply-entry-unit-btns';
                btnGroup.className = 'pos-unit-toggles supply-entry-unit-toggles';
                btnGroup.style.marginBottom = '10px';
                
                entryUnitSelect.parentNode.insertBefore(hidden, entryUnitSelect);
                entryUnitSelect.parentNode.insertBefore(btnGroup, entryUnitSelect);
                entryUnitSelect.remove();
                
                entryUnitSelect = hidden;
            }
            
            const packLevelOn = product.unit_show_pack == null || Number(product.unit_show_pack) !== 0;
            const cartonLevelOn = product.unit_show_carton == null || Number(product.unit_show_carton) !== 0;
            const hasPacks = packLevelOn && (product.pieces_per_pack != null && product.pieces_per_pack > 1) &&
                             ((product.barcode_pack && product.barcode_pack.trim() !== '') ||
                              (product.price_pack != null && product.price_pack > 0) ||
                              (product.cost_pack != null && product.cost_pack > 0));
            const hasCartons = cartonLevelOn && product.itemsPerCarton != null && product.itemsPerCarton > 1;
            
            // Store current selection
            let currentUnit = entryUnitSelect.value || 'carton';
            
            // Restore selection if it's still valid, otherwise default to best available option
            if (currentUnit === 'carton' && !hasCartons) currentUnit = hasPacks ? 'pack' : 'piece';
            if (currentUnit === 'pack' && !hasPacks) currentUnit = hasCartons ? 'carton' : 'piece';
            
            entryUnitSelect.value = currentUnit;
            
            const btnGroup = document.getElementById('supply-entry-unit-btns');
            if (btnGroup) {
                var cartonLabel = getProductUnitLabel(product, 'carton');
                var packLabel = getProductUnitLabel(product, 'pack');
                var pieceLabel = getProductUnitLabel(product, 'piece');
                var availableUnits = ['piece'];
                if (hasPacks) availableUnits.push('pack');
                if (hasCartons) availableUnits.push('carton');
                btnGroup.innerHTML = (typeof window.buildPosUnitToggleHtml === 'function')
                    ? window.buildPosUnitToggleHtml({
                        available: availableUnits,
                        current: currentUnit,
                        onSet: 'setSupplyUnit',
                        labels: { piece: pieceLabel, pack: packLabel, carton: cartonLabel }
                    })
                    : '';
            }
            
            // Show Zero Loss System info
            showZeroLossInfo(product, hasPacks, hasCartons);
            
            // Update quantity input labels based on available units
            updateSupplyQuantityLabels(product);
        }

        function setSupplyUnit(unit) {
            const entryUnitSelect = document.getElementById('supply-entry-unit');
            if (entryUnitSelect) entryUnitSelect.value = unit;
            
            const btnGroup = document.getElementById('supply-entry-unit-btns');
            if (btnGroup) {
                btnGroup.querySelectorAll('.pos-unit-btn').forEach(btn => btn.classList.remove('active'));
                const activeBtn = btnGroup.querySelector('button[data-unit="' + unit + '"]') || btnGroup.querySelector('button[onclick="setSupplyUnit(\'' + unit + '\')"]');
                if (activeBtn) activeBtn.classList.add('active');
            }
            
            if (selectedSupplyProdId) {
                const p = db.products.find(x => x.id === selectedSupplyProdId);
                if (p) {
                    updateSupplyQuantityLabels(p);
                    autoCalcSupply('qty');
                }
            }
        }

        // Show Zero Loss System information
        function showZeroLossInfo(product, hasPacks, hasCartons) {
            const infoBox = document.getElementById('supply-selected-info');
            if (!infoBox || !infoBox.classList.contains('active')) return;
            var cartonLabel = getProductUnitLabel(product, 'carton');
            var packLabel = getProductUnitLabel(product, 'pack');
            var pieceLabel = getProductUnitLabel(product, 'piece');
            
            let conversionInfo = '';
            if (hasPacks && hasCartons) {
                conversionInfo = `<div style="font-size:0.8rem; color:var(--text-muted); margin-top:5px;">
                    📦 1 ${cartonLabel} = ${product.packs_per_carton || 1} ${packLabel} = ${product.pieces_per_pack * (product.packs_per_carton || 1)} ${pieceLabel}
                </div>`;
            } else if (hasPacks) {
                conversionInfo = `<div style="font-size:0.8rem; color:var(--text-muted); margin-top:5px;">
                    📦 1 ${packLabel} = ${product.pieces_per_pack} ${pieceLabel}
                </div>`;
            } else if (hasCartons) {
                conversionInfo = `<div style="font-size:0.8rem; color:var(--text-muted); margin-top:5px;">
                    📦 1 ${cartonLabel} = ${product.itemsPerCarton} ${pieceLabel}
                </div>`;
            }
            
            // Update existing info
            const currentHTML = infoBox.innerHTML;
            if (currentHTML.includes('Cost:')) {
                infoBox.innerHTML = currentHTML.replace(/<p style="margin:5px 0; color:#666">Cost: .*?<\/p>/, 
                    `<p style="margin:5px 0; color:#666">Cost: ${formatCurrency(product.cost)}</p>${conversionInfo}`);
            }
        }

        // Update quantity input labels based on available units
        function updateSupplyQuantityLabels(product) {
            const entryUnit = document.getElementById('supply-entry-unit').value;
            const mainQtyLabel = document.getElementById('supply-main-qty-label');
            
            if (!mainQtyLabel) return;
            
            if (entryUnit === 'carton') {
                mainQtyLabel.textContent = '📦 ' + getProductUnitLabel(product, 'carton');
            } else if (entryUnit === 'pack') {
                mainQtyLabel.textContent = '📦 ' + getProductUnitLabel(product, 'pack');
            } else {
                mainQtyLabel.textContent = '🧩 ' + getProductUnitLabel(product, 'piece');
            }
        }

        function handleSupplyBarcode(input) {
            const val = input.value.trim();
            if(!val) return;
            const comp = db.companies.find(c => c.id === currentViewingCompanyId);
            if(!comp) return;
            
            const p = db.products.find(x => {
                const codes = (x.barcode || '').split(',').map(c => c.trim());
                return codes.includes(val) && x.supplier === comp.name;
            });
            if(p) {
                selectSupplyItem(p.id);
                input.value = ''; 
            }
        }

        // Add event listener for entry unit change
        document.addEventListener('DOMContentLoaded', function() {
            const entryUnitSelect = document.getElementById('supply-entry-unit');
            if (entryUnitSelect) {
                entryUnitSelect.addEventListener('change', function() {
                    if (selectedSupplyProdId) {
                        const p = db.products.find(x => x.id === selectedSupplyProdId);
                        if (p) {
                            updateSupplyQuantityLabels(p);
                            autoCalcSupply('qty');
                        }
                    }
                });
            }
        });

        function autoCalcSupply(mode) {
            if(!selectedSupplyProdId) return;
            const p = db.products.find(x => x.id == selectedSupplyProdId);
            if(!p) return;

            const entryUnit = document.getElementById('supply-entry-unit').value;
            const mainQty = parseInt(document.getElementById('supply-qty-carton').value) || 0;
            const units = parseInt(document.getElementById('supply-qty-unit').value) || 0;
            
            // Zero Loss System: Calculate conversion factors
            const ppp = (p.pieces_per_pack != null && p.pieces_per_pack >= 1) ? p.pieces_per_pack : 1;
            const ppc = (p.packs_per_carton != null && p.packs_per_carton >= 1) ? p.packs_per_carton : 1;
            const piecesPerCarton = ppp * ppc;
            
            let totalUnits = 0;
            let multiplier = 1;
            
            if (entryUnit === 'carton') {
                multiplier = piecesPerCarton;
                totalUnits = (mainQty * multiplier) + units;
            } else if (entryUnit === 'pack') {
                multiplier = ppp;
                totalUnits = (mainQty * multiplier) + units;
            } else {
                totalUnits = mainQty + units;
            }
            
            let unitCost = parseFloat(document.getElementById('supply-unit-cost').value) || 0;
            let cartonCost = parseFloat(document.getElementById('supply-carton-cost').value) || 0;
            let totalCost = parseFloat(document.getElementById('supply-cost').value) || 0;

            if (mode === 'qty' || mode === 'unit') {
                // Calculate Total based on Qty * UnitCost
                if(mode === 'unit') {
                    cartonCost = unitCost * piecesPerCarton;
                    document.getElementById('supply-carton-cost').value = cartonCost;
                }
                totalCost = totalUnits * unitCost;
                document.getElementById('supply-cost').value = totalCost > 0 ? totalCost : '';
            } 
            else if (mode === 'carton_price') {
                // Calculate UnitCost from CartonPrice
                unitCost = cartonCost / piecesPerCarton;
                document.getElementById('supply-unit-cost').value = unitCost; // Keep decimals
                totalCost = totalUnits * unitCost;
                document.getElementById('supply-cost').value = totalCost > 0 ? totalCost : '';
            }
            else if (mode === 'total') {
                // Calculate UnitCost based on Total / Qty (Zero Loss System)
                if (totalUnits > 0) {
                    unitCost = totalCost / totalUnits;
                    document.getElementById('supply-unit-cost').value = Math.round(unitCost * 100) / 100; // Keep 2 decimal precision
                    document.getElementById('supply-carton-cost').value = Math.round((unitCost * piecesPerCarton) * 100) / 100;
                }
            }
        }

        function saveSupplyTransaction() {
            const comp = db.companies.find(c => c.id === currentViewingCompanyId);
            const prodId = selectedSupplyProdId;
            const cartonsInput = parseInt(document.getElementById('supply-qty-carton').value) || 0;
            const unitsInput = parseInt(document.getElementById('supply-qty-unit').value) || 0;
            const cost = parseFloat(document.getElementById('supply-cost').value) || 0;
            const type = document.querySelector('input[name="supply-type"]:checked').value; 

            if(!prodId) return alert("هیڤییە ئایتمی هەلبژێرە!");
            if(cartonsInput === 0 && unitsInput === 0) return alert("هیڤیە ژمارێ بنڤیسە!");

            const product = db.products.find(p => p.id == prodId);
            const entryUnit = (document.getElementById('supply-entry-unit') && document.getElementById('supply-entry-unit').value) || 'carton';
            const mainQty = cartonsInput; // Main quantity (cartons/packs)
            
            // Zero Loss System: Calculate conversion factors
            const ppp = (product.pieces_per_pack != null && product.pieces_per_pack >= 1) ? product.pieces_per_pack : 1;
            const ppc = (product.packs_per_carton != null && product.packs_per_carton >= 1) ? product.packs_per_carton : 1;
            const piecesPerCarton = ppp * ppc;
            const multiplier = (entryUnit === 'carton') ? piecesPerCarton : (entryUnit === 'pack') ? ppp : 1;
            const totalItemsToAdd = (mainQty * multiplier) + unitsInput;

            // HANDLE RETURN MODE
            if(isSupplyReturnMode) {
                if(confirm(`دڵنیای ژ زڤڕاندنا ${totalItemsToAdd} دانەیان بۆ کۆمپانیێ؟
ئەڤە دێ ژ مەخزەنی و قەرزی کێم کەت.`)) {
                    const formData = new FormData();
                    formData.append('action', 'return_supply_to_company');
                    formData.append('company', comp.name);
                    formData.append('prodId', product.id);
                    formData.append('itemName', product.name);
                    formData.append('qtyAdded', totalItemsToAdd);
                    formData.append('totalCost', cost);
                    
                    fetch('?action=return_supply_to_company', { method: 'POST', body: formData })
                    .then(res => res.json())
                    .then(data => {
                        if(data.status === 'success') {
                            if(product.trackStock) product.qty -= totalItemsToAdd;
                            comp.balance = (typeof roundMoney === 'function' ? roundMoney : function(x){ return Math.round(Number(x)); })((parseFloat(comp.balance)||0) - (parseFloat(cost)||0));
                            db.supplies.push({ id: Date.now(), company: comp.name, prodId: product.id, itemName: product.name, qtyAdded: -totalItemsToAdd, totalCost: cost, date: new Date(), type: 'return' });
                            db.ledger.push({ id: Date.now(), companyId: comp.id, type: 'return_to_supplier', amount: cost, date: new Date(), note: `زڤڕاندن: ${product.name}` });
                            
                            refreshCompanyUI(comp);
                            alert("✅ ئایتم هاتنە زڤڕاندن.");
                        } else { alert("Error: " + data.message); }
                    });
                }
                return;
            }

            if(product.trackStock) { product.qty += totalItemsToAdd; }

            let expenseMsg = "";
            
            // SAVE TO SQL
            const formData = new FormData();
            formData.append('action', 'save_supply');
            formData.append('company', comp.name);
            formData.append('prodId', product.id);
            formData.append('itemName', product.name);
            formData.append('qtyAdded', totalItemsToAdd);
            formData.append('totalCost', cost);
            formData.append('type', type);
            formData.append('user', currentUser ? currentUser.name : 'System'); // FIX: Send User
            
            // Zero Loss System: Log entry unit for audit trail
            formData.append('entryUnit', entryUnit);
            formData.append('mainQty', mainQty);
            formData.append('conversionFactor', multiplier);

            fetch('?action=save_supply', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                if(data.status === 'success') {
                    // Update Local UI
                    if(type === 'credit') {
                        if(!comp.balance) comp.balance = 0;
                        comp.balance = (typeof roundMoney === 'function' ? roundMoney : function(x){ return Math.round(Number(x)); })((parseFloat(comp.balance)||0) + (parseFloat(cost)||0));
                        if(!db.ledger) db.ledger = [];
                        db.ledger.push({ id: Date.now(), companyId: comp.id, type: 'credit_purchase', amount: cost, date: new Date(), note: `کڕین: ${product.name} (قەرز)` });
                    } else {
                        const note = `کڕین: ${product.name} ژ ${comp.name}`;
                        const user = currentUser ? currentUser.name : 'System';
                        const txnLocal = data.transaction_id || ('TXS_LOCAL_' + Date.now());

                        if(!db.expenses) db.expenses = [];
                        db.expenses.push({ id: data.expense_id || Date.now(), note, amount: cost, date: new Date(), user, type: 'purchase', transaction_id: txnLocal });

                        if(!db.ledger) db.ledger = [];
                        db.ledger.push({ id: Date.now() + 1, companyId: comp.id, type: 'purchase', amount: cost, date: new Date(), note: note + ' (کاش)', transaction_id: txnLocal });

                        if (db.treasury !== undefined) {
                            db.treasury = (typeof roundMoney === 'function' ? roundMoney : function(x){ return Math.round(Number(x)); })((parseFloat(db.treasury) || 0) - (parseFloat(cost)||0));
                        }
                        expenseMsg = `
💰 ${formatCurrency(cost)} لە قاسە کەم بوو.`;
                    }

                    db.supplies.push({ id: data.id, company: comp.name, prodId: product.id, itemName: product.name, qtyAdded: totalItemsToAdd, totalCost: cost, date: new Date(), type: type });
                    
                    refreshCompanyUI(comp);
                    if (typeof updateStats === 'function') updateStats();
                    alert(`✅ ${product.name} هاتە کڕین.${expenseMsg}`);
                }
            });
        }

        function refreshCompanyUI(comp) {
            document.getElementById('supply-qty-carton').value = ''; 
            document.getElementById('supply-qty-unit').value = ''; 
            document.getElementById('supply-cost').value = '';
            document.getElementById('supply-unit-cost').value = '';
            document.getElementById('supply-carton-cost').value = '';
            
            // Reset entry unit dropdown to default (Zero Loss System)
            const entryUnitSelect = document.getElementById('supply-entry-unit');
            if (entryUnitSelect) {
                if (entryUnitSelect.tagName === 'SELECT') {
                    entryUnitSelect.innerHTML = '<option value="carton">📦 ' + getDefaultUnitLabel('carton') + '</option><option value="pack">📦 ' + getDefaultUnitLabel('pack') + '</option><option value="piece">🧩 ' + getDefaultUnitLabel('piece') + '</option>';
                }
                entryUnitSelect.value = 'carton';
            }
            
            const btnGroup = document.getElementById('supply-entry-unit-btns');
            if (btnGroup) {
                btnGroup.innerHTML = (typeof window.buildPosUnitToggleHtml === 'function')
                    ? window.buildPosUnitToggleHtml({ available: ['piece', 'pack', 'carton'], current: 'carton', onSet: 'setSupplyUnit' })
                    : '';
            }
            
            // Reset quantity label
            const mainQtyLabel = document.getElementById('supply-main-qty-label');
            if (mainQtyLabel) {
                mainQtyLabel.textContent = '📦 ' + getDefaultUnitLabel('carton');
            }
            
            toggleSupplyForm(); 
            renderCompanyInventory(comp.name); 
            renderCompanyHistory(comp.name);
            renderLedgerHistory(comp.id);
            var compBalFx2 = (typeof fxUsdRateFormatOptsForEntityBalance === 'function')
                ? fxUsdRateFormatOptsForEntityBalance(comp.id, 'company', comp.balance)
                : undefined;
            if (typeof fillElWithCurrencyAndDuhokPaper === 'function') fillElWithCurrencyAndDuhokPaper(document.getElementById('cp-balance'), comp.balance || 0, compBalFx2);
            else document.getElementById('cp-balance').innerText = formatCurrency(comp.balance || 0, compBalFx2) + " " + getCurrencySymbol();
            renderExpenses();
            updateStats();
        }

