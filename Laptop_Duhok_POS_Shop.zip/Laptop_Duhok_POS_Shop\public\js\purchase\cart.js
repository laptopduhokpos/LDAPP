// purchase/cart.js — purchase cart, product grid
        // --- PURCHASE SCREEN (POS-like) ---
        var purchaseCart = [];
        var purchaseSelectedUnit = 'piece';
        var purchaseActiveCategory = 'all';
        var purchaseGridTimeout = null;
        var _purchaseCartRenderRaf = null;
        var _purchaseReturnCartRenderRaf = null;

        var _purchaseCartRenderTimer = null;
        var _purchaseReturnCartRenderTimer = null;

        function schedulePurchaseCartRender() {
            var _deb = (typeof posTxnCartRenderDebounceMs === 'function') ? posTxnCartRenderDebounceMs() : 0;
            if (_deb > 0) {
                if (_purchaseCartRenderTimer) clearTimeout(_purchaseCartRenderTimer);
                _purchaseCartRenderTimer = setTimeout(function () {
                    _purchaseCartRenderTimer = null;
                    renderPurchaseCart();
                }, _deb);
                return;
            }
            if (_purchaseCartRenderRaf) return;
            _purchaseCartRenderRaf = requestAnimationFrame(function () {
                _purchaseCartRenderRaf = null;
                renderPurchaseCart();
            });
        }

        function schedulePurchaseReturnCartRender() {
            var _deb = (typeof posTxnCartRenderDebounceMs === 'function') ? posTxnCartRenderDebounceMs() : 0;
            if (_deb > 0) {
                if (_purchaseReturnCartRenderTimer) clearTimeout(_purchaseReturnCartRenderTimer);
                _purchaseReturnCartRenderTimer = setTimeout(function () {
                    _purchaseReturnCartRenderTimer = null;
                    renderPurchaseReturnCart();
                }, _deb);
                return;
            }
            if (_purchaseReturnCartRenderRaf) return;
            _purchaseReturnCartRenderRaf = requestAnimationFrame(function () {
                _purchaseReturnCartRenderRaf = null;
                renderPurchaseReturnCart();
            });
        }

        /** One listener for purchase grids — reliable taps on weak laptops. */
        function bindPurchaseCardEditButton(btn, pid) {
            if (!btn || btn._purEditBound) return;
            btn._purEditBound = true;
            var fire = function (ev) {
                if (ev) {
                    if (ev.preventDefault) ev.preventDefault();
                    if (ev.stopPropagation) ev.stopPropagation();
                    if (ev.stopImmediatePropagation) ev.stopImmediatePropagation();
                }
                window._purchaseEditClickAt = Date.now();
                var id = parseInt(pid, 10);
                if (isNaN(id) && btn.getAttribute) id = parseInt(btn.getAttribute('data-product-id'), 10);
                if (!isNaN(id) && typeof window.editProdFromPurchase === 'function') {
                    window.editProdFromPurchase(id);
                }
            };
            btn.addEventListener('pointerdown', fire, true);
            btn.addEventListener('click', fire, true);
        }
        window.bindPurchaseCardEditButton = bindPurchaseCardEditButton;

        (function bindTxnProductGridClicks() {
            if (window.__txnProductGridClickDelegate) return;
            window.__txnProductGridClickDelegate = true;
            document.addEventListener('pointerdown', function (e) {
                var t = e.target;
                if (!t || !t.closest) return;
                var editBtn = t.closest('#purchase-product-grid .txn-card-edit-btn');
                if (!editBtn) return;
                e.preventDefault();
                e.stopPropagation();
                if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
                window._purchaseEditClickAt = Date.now();
                var card = editBtn.closest('.txn-product-card--purchase');
                var editId = card ? parseInt(card.getAttribute('data-product-id'), 10) : NaN;
                if (isNaN(editId)) editId = parseInt(editBtn.getAttribute('data-product-id'), 10);
                if (!isNaN(editId) && typeof window.editProdFromPurchase === 'function') {
                    window.editProdFromPurchase(editId);
                }
            }, true);
            document.addEventListener('click', function (e) {
                var t = e.target;
                if (!t || !t.closest) return;
                var editBtn = t.closest('#purchase-product-grid .txn-card-edit-btn');
                if (editBtn) {
                    e.preventDefault();
                    e.stopPropagation();
                    if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
                    return;
                }
            }, true);
            document.addEventListener('click', function (e) {
                var t = e.target;
                if (!t || !t.closest) return;
                if (window._purchaseEditClickAt && (Date.now() - window._purchaseEditClickAt) < 600) return;
                if (t.closest('#purchase-product-grid .txn-card-edit-btn')) return;
                var purAddCard = t.closest('#purchase-product-grid .txn-product-card--purchase-add');
                if (purAddCard) {
                    if (typeof isWorkspaceViewActive === 'function' && !isWorkspaceViewActive('purchase')) return;
                    e.preventDefault();
                    e.stopPropagation();
                    if (typeof promptPurchaseDefineMissingItem === 'function') {
                        promptPurchaseDefineMissingItem('');
                    } else if (typeof window.openQuickDefineModal === 'function') {
                        window.openQuickDefineModal('');
                    }
                    return;
                }
                var purCard = t.closest('#purchase-product-grid .txn-product-card--purchase');
                if (purCard) {
                    if (typeof isWorkspaceViewActive === 'function' && !isWorkspaceViewActive('purchase')) return;
                    if (t.closest('.txn-card-edit-btn')) {
                        e.preventDefault();
                        e.stopPropagation();
                        var editId = parseInt(purCard.getAttribute('data-product-id'), 10);
                        if (!isNaN(editId) && typeof window.editProdFromPurchase === 'function') {
                            window.editProdFromPurchase(editId);
                        }
                        return;
                    }
                    var pid = parseInt(purCard.getAttribute('data-product-id'), 10);
                    var unit = purCard.getAttribute('data-sale-unit');
                    if (!isNaN(pid) && typeof addToPurchaseCart === 'function') {
                        e.preventDefault();
                        e.stopPropagation();
                        addToPurchaseCart(pid, unit || undefined);
                    }
                    return;
                }
                var retCard = t.closest('#purchase-returns-product-grid .txn-product-card--purchase-return');
                if (retCard && typeof handlePurchaseReturnProductCardTap === 'function') {
                    handlePurchaseReturnProductCardTap(retCard, e);
                    return;
                }
                var salesRetCard = t.closest('#returns-products .txn-product-card--sales-return');
                if (salesRetCard && typeof window.handleReturnsProductCardClick === 'function') {
                    e.preventDefault();
                    e.stopPropagation();
                    window.handleReturnsProductCardClick(salesRetCard);
                    return;
                }
                var wasteCard = t.closest('#waste-products .txn-product-card--waste');
                if (wasteCard && typeof window.addToWasteCart === 'function') {
                    if (typeof isWorkspaceViewActive === 'function' && !isWorkspaceViewActive('waste')) return;
                    var wPid = parseInt(wasteCard.getAttribute('data-product-id'), 10);
                    var wUnit = wasteCard.getAttribute('data-sale-unit');
                    if (!isNaN(wPid)) {
                        e.preventDefault();
                        e.stopPropagation();
                        window.addToWasteCart(wPid, wUnit || undefined);
                    }
                }
            }, false);
            document.addEventListener('touchend', function (e) {
                var t = e.target;
                if (!t || !t.closest) return;
                var retCard = t.closest('#purchase-returns-product-grid .txn-product-card--purchase-return');
                if (retCard && typeof handlePurchaseReturnProductCardTap === 'function') {
                    handlePurchaseReturnProductCardTap(retCard, e);
                }
            }, { passive: false, capture: true });
        })();

        var _purchaseReturnCardTapAt = 0;
        function handlePurchaseReturnProductCardTap(retCard, e) {
            if (typeof isWorkspaceViewActive === 'function' && !isWorkspaceViewActive('purchase-returns')) return;
            var now = Date.now();
            if (now - _purchaseReturnCardTapAt < 350) return;
            _purchaseReturnCardTapAt = now;
            if (e) {
                e.preventDefault();
                e.stopPropagation();
            }
            var pid2 = parseInt(retCard.getAttribute('data-product-id'), 10);
            var cost = parseFloat(retCard.getAttribute('data-return-cost') || '0');
            var unit2 = retCard.getAttribute('data-sale-unit');
            if (!isNaN(pid2) && typeof addToPurchaseReturnCart === 'function') {
                addToPurchaseReturnCart(pid2, unit2 || undefined, isNaN(cost) ? undefined : cost);
            }
        }

        function setPurchaseUnit(unit) {
            purchaseSelectedUnit = unit || 'piece';
            ['carton', 'pack', 'piece'].forEach(function(u) {
                var btn = document.getElementById('btn-purchase-unit-' + u);
                if (btn) { btn.classList.toggle('active', u === purchaseSelectedUnit); btn.setAttribute('aria-pressed', u === purchaseSelectedUnit ? 'true' : 'false'); }
            });
            debouncedRenderPurchaseProductGrid();
        }

        function purchaseProductCat(p) {
            return String((p && (p.cat || p.category)) || '').trim();
        }

        function renderPurchaseCategories() {
            var container = document.getElementById('purchase-category-tabs');
            if (!container || !db) return;
            var used = {};
            (db.products || []).forEach(function(p) {
                var c = purchaseProductCat(p);
                if (c) used[c] = true;
            });
            var sourceCats = (db.categories && db.categories.length)
                ? db.categories.slice()
                : Object.keys(used);
            var cats = sourceCats.filter(function(c) { return !!used[c]; }).sort();
            var allLbl = (typeof t === 'function') ? t('pos_category_all') : 'هەمی';
            var html = '<button type="button" class="cat-btn ' + (purchaseActiveCategory === 'all' ? 'active' : '') + '" onclick="setPurchaseCategory(\'all\')"><i class="fas fa-border-all" aria-hidden="true"></i> ' + escapeHtml(allLbl) + '</button>';
            cats.forEach(function(c) {
                var safe = String(c).replace(/\\/g, '\\\\').replace(/'/g, "\\'");
                html += '<button type="button" class="cat-btn ' + (purchaseActiveCategory === c ? 'active' : '') + '" onclick="setPurchaseCategory(\'' + safe + '\')"><i class="fas fa-folder-open" aria-hidden="true"></i> ' + escapeHtml(c) + '</button>';
            });
            container.innerHTML = html;
            if (typeof refreshTxnCategoryTabsScrollUi === 'function') {
                requestAnimationFrame(function() { refreshTxnCategoryTabsScrollUi('purchase-category-tabs'); });
            } else if (typeof refreshPOSCategoryTabsScrollUi === 'function') {
                requestAnimationFrame(function() { refreshPOSCategoryTabsScrollUi(); });
            }
        }
        window.renderPurchaseCategories = renderPurchaseCategories;

        window.setPurchaseCategory = function setPurchaseCategory(cat) {
            purchaseActiveCategory = cat || 'all';
            renderPurchaseCategories();
            debouncedRenderPurchaseProductGrid();
        };
        function getPurchaseCostForUnit(p, unit) {
            if (!p) return 0;
            // Jewelry: live cost from today's buy rate × saved grams
            if ((typeof isJewelryByWeightProduct === 'function') && isJewelryByWeightProduct(p)
                && (typeof computeProductJewelryBuyCost === 'function')) {
                var uJew = (unit == null || unit === '') ? 'piece' : String(unit);
                var w = Number(p.weight_grams) || 0;
                if (w > 0) {
                    if (uJew === 'pack') {
                        var fJ = typeof getProductUnitFactors === 'function' ? getProductUnitFactors(p) : { piecesPerPack: 1 };
                        w = w * (fJ.piecesPerPack || 1);
                    } else if (uJew === 'carton') {
                        var fJc = typeof getProductUnitFactors === 'function' ? getProductUnitFactors(p) : { piecesPerCarton: 1 };
                        w = w * (fJc.piecesPerCarton || 1);
                    }
                    var liveBuy = computeProductJewelryBuyCost(p, w);
                    if (liveBuy > 0) return Math.floor(liveBuy);
                }
            }
            var fromUsd = (typeof catalogIqdFromUsdField === 'function') ? catalogIqdFromUsdField : null;
            var u = (unit == null || unit === '') ? 'piece' : String(unit);
            var f = (typeof getProductUnitFactors === 'function') ? getProductUnitFactors(p) : { piecesPerPack: 1, piecesPerCarton: 1 };
            var pieceCost = fromUsd ? fromUsd(p, 'cost_usd', 'cost') : (p.cost != null && p.cost !== '' ? parseFloat(p.cost) : 0);
            if (isNaN(pieceCost)) pieceCost = 0;

            if (u === 'carton') {
                if (fromUsd) {
                    var cc = fromUsd(p, 'cost_carton_usd', 'cost_carton');
                    if (!isNaN(cc) && cc > 0) return Math.round(cc);
                }
                if (p.cost_carton != null && p.cost_carton !== '' && parseFloat(p.cost_carton) > 0) return Math.round(parseFloat(p.cost_carton) || 0);
                return Math.round(pieceCost * (f.piecesPerCarton || 1));
            }
            if (u === 'pack') {
                if (fromUsd) {
                    var cp = fromUsd(p, 'cost_pack_usd', 'cost_pack');
                    if (!isNaN(cp) && cp > 0) return Math.round(cp);
                }
                if (p.cost_pack != null && p.cost_pack !== '' && parseFloat(p.cost_pack) > 0) return Math.round(parseFloat(p.cost_pack) || 0);
                return Math.round(pieceCost * (f.piecesPerPack || 1));
            }
            return Math.round(pieceCost);
        }

        function refreshPurchaseJewelryCostsFromRates() {
            if (!purchaseCart || !purchaseCart.length) return;
            if (typeof isJewelryMode === 'function' && !isJewelryMode()) return;
            purchaseCart.forEach(function (row) {
                if (!row || row.isGift) return;
                var p = row.productRef || ((typeof db !== 'undefined' && db.products) || []).find(function (x) {
                    return String(x.id) === String(row.productId);
                });
                if (!p) return;
                if (typeof isJewelryByWeightProduct !== 'function' || !isJewelryByWeightProduct(p)) return;
                var unit = row.unit || 'piece';
                var live = getPurchaseCostForUnit(p, unit);
                if (live > 0) {
                    row.costPerUnit = live;
                    row.productRef = p;
                }
                if (typeof getPurchaseSellForUnit === 'function') {
                    var sell = getPurchaseSellForUnit(p, unit);
                    if (sell > 0) row.sellPerUnit = sell;
                }
            });
            schedulePurchaseCartRender();
        }

        function getPurchaseSellForUnit(p, unit) {
            if (!p) return 0;
            if (typeof getPriceForUnit === 'function') return getPriceForUnit(p, unit || 'piece', null);
            var u = (unit == null || unit === '') ? 'piece' : String(unit);
            var f = (typeof getProductUnitFactors === 'function') ? getProductUnitFactors(p) : { piecesPerPack: 1, piecesPerCarton: 1 };
            var piecePrice = (typeof getCatalogPieceSellIqd === 'function') ? getCatalogPieceSellIqd(p) : (parseFloat(p.price) || 0);
            if (u === 'carton') {
                var pc = Number(p.price_carton);
                if (!isNaN(pc) && pc > 0) return pc;
                return piecePrice * (f.piecesPerCarton || 1);
            } else if (u === 'pack') {
                var pp = Number(p.price_pack);
                if (!isNaN(pp) && pp > 0) return pp;
                return piecePrice * (f.piecesPerPack || 1);
            }
            return piecePrice;
        }
        function applyPurchaseSellToProduct(p, unit, sellIqd) {
            if (!p) return;
            var iq = Math.max(0, parseFloat(sellIqd) || 0);
            var u = unit || 'piece';
            var rate = (typeof getPosFrozenFxRatePerOne === 'function') ? getPosFrozenFxRatePerOne(null) : ((typeof getUsdRatePerOne === 'function') ? getUsdRatePerOne() : 0);
            var isUsd = (typeof getActiveCurrency === 'function') && getActiveCurrency() === 'USD';
            var usdVal = (isUsd && rate > 0)
                ? ((typeof storedIqdToUsdAmount === 'function') ? storedIqdToUsdAmount(iq, rate) : parseFloat((iq / rate).toFixed(6)))
                : null;
            if (u === 'carton') {
                p.price_carton = iq;
                if (usdVal != null) p.price_carton_usd = usdVal;
            } else if (u === 'pack') {
                p.price_pack = iq;
                if (usdVal != null) p.price_pack_usd = usdVal;
            } else {
                p.price = iq;
                if (usdVal != null) p.price_usd = usdVal;
            }
        }
        function applyPurchaseCostToProduct(p, unit, costIqd, allowZero) {
            if (!p) return;
            var roundMCost = typeof roundMoney === 'function' ? roundMoney : function(x) { return Math.round(Number(x)); };
            var iq = Math.max(0, parseFloat(costIqd) || 0);
            if (iq <= 0 && !allowZero) return;
            var u = unit || 'piece';
            var rate = (typeof getPosFrozenFxRatePerOne === 'function') ? getPosFrozenFxRatePerOne(null) : ((typeof getUsdRatePerOne === 'function') ? getUsdRatePerOne() : 0);
            var isUsd = (typeof getActiveCurrency === 'function') && getActiveCurrency() === 'USD';
            var usdOf = function(iqd) {
                if (!(isUsd && rate > 0)) return null;
                return (typeof storedIqdToUsdAmount === 'function') ? storedIqdToUsdAmount(iqd, rate) : parseFloat((iqd / rate).toFixed(6));
            };
            if (iq <= 0) {
                p.cost = 0;
                p.cost_pack = 0;
                p.cost_carton = 0;
                if (usdOf(0) != null) {
                    p.cost_usd = 0;
                    p.cost_pack_usd = 0;
                    p.cost_carton_usd = 0;
                }
                return;
            }
            var f = (typeof getProductUnitFactors === 'function')
                ? getProductUnitFactors(p)
                : { piecesPerPack: 1, piecesPerCarton: 1 };
            var ppp = Math.max(1, parseFloat(f.piecesPerPack) || 1);
            var pCarton = Math.max(1, parseFloat(f.piecesPerCarton) || ppp);

            var pieceCost;
            var packCost;
            var cartonCost;
            if (u === 'carton') {
                cartonCost = roundMCost(iq);
                pieceCost = roundMCost(iq / Math.max(1, pCarton));
                packCost = roundMCost(pieceCost * ppp);
                cartonCost = roundMCost(iq);
            } else if (u === 'pack') {
                packCost = roundMCost(iq);
                pieceCost = roundMCost(iq / Math.max(1, ppp));
                cartonCost = roundMCost(pieceCost * pCarton);
                packCost = roundMCost(iq);
            } else {
                pieceCost = roundMCost(iq);
                packCost = roundMCost(pieceCost * ppp);
                cartonCost = roundMCost(pieceCost * pCarton);
            }
            if (!(pieceCost > 0)) pieceCost = roundMCost(iq);
            if (!(packCost > 0)) packCost = pieceCost;
            if (!(cartonCost > 0)) cartonCost = roundMCost(pieceCost * pCarton);

            p.cost = pieceCost;
            p.cost_pack = packCost;
            p.cost_carton = cartonCost;
            var pu = usdOf(pieceCost);
            var pku = usdOf(packCost);
            var cku = usdOf(cartonCost);
            if (pu != null) p.cost_usd = pu;
            if (pku != null) p.cost_pack_usd = pku;
            if (cku != null) p.cost_carton_usd = cku;
        }
        function applyPurchaseWacAfterStockIn(p, addPieces, addTotalCost) {
            if (!p) return;
            var qtyAfter = parseFloat(p.qty) || 0;
            var add = parseFloat(addPieces) || 0;
            if (!(add > 0)) return;
            var qtyBefore = Math.max(0, qtyAfter - add);
            var oldCost = parseFloat(p.cost) || 0;
            var addTot = Math.max(0, parseFloat(addTotalCost) || 0);
            var wac = qtyAfter > 0.000001 ? ((qtyBefore * oldCost + addTot) / qtyAfter) : 0;
            applyPurchaseCostToProduct(p, 'piece', wac, true);
        }
        function getPiecesMultiplierForUnit(p, unit) {
            if (!p || unit === 'piece') return 1;
            var f = typeof getProductUnitFactors === 'function' ? getProductUnitFactors(p) : { piecesPerPack: 1, piecesPerCarton: 1 };
            if (unit === 'carton') return f.piecesPerCarton || 1;
            if (unit === 'pack') return f.piecesPerPack || 1;
            return 1;
        }

        function purchaseLineTotal(row) {
            if (!row || row.isGift) return 0;
            var roundM3 = typeof roundMoney === 'function' ? roundMoney : function (x) { return Math.round(Number(x)); };
            return roundM3(Math.max(0, (row.qty || 0) * (row.costPerUnit || 0) - (row.discount || 0)));
        }

        function findPurchaseCartMergeIndex(productId, unit, whId, isGift) {
            return purchaseCart.findIndex(function (r) {
                if (!r || r.productId !== productId || (r.unit || 'piece') !== unit) return false;
                if (!!r.isGift !== !!isGift) return false;
                if (typeof shouldShowPurchaseWarehouseUi === 'function' && shouldShowPurchaseWarehouseUi()) {
                    return Number(typeof getPurchaseRowWarehouseId === 'function' ? getPurchaseRowWarehouseId(r) : r.warehouseId) === Number(whId);
                }
                return true;
            });
        }

        function clonePurchaseCartRow(row, overrides) {
            var nr = Object.assign({}, row, overrides || {});
            if (row.productRef) nr.productRef = row.productRef;
            return nr;
        }

        function purchaseGiftUnitDelta(row) {
            var p = row.productRef || (db.products || []).find(function (x) { return x.id === row.productId; });
            return (p && typeof isWeightProduct === 'function' && isWeightProduct(p)) ? 0.25 : 1;
        }

        /** Like sales: one 🎁 click = one unit gift, not the whole line. */
        function splitPurchaseCartGiftUnit(idx) {
            var row = purchaseCart[idx];
            if (!row) return;
            var p = row.productRef || (db.products || []).find(function (x) { return x.id === row.productId; });
            var whId = typeof getPurchaseRowWarehouseId === 'function' ? getPurchaseRowWarehouseId(row) : (row.warehouseId || 0);
            var unit = row.unit || 'piece';
            var qty = typeof normalizeQtyForProduct === 'function' ? normalizeQtyForProduct(p, row.qty || 0) : (parseFloat(row.qty) || 0);
            if (qty <= 0) return;
            var delta = purchaseGiftUnitDelta(row);
            var norm = function (n) {
                return typeof normalizeQtyForProduct === 'function' ? normalizeQtyForProduct(p, n) : n;
            };

            if (!row.isGift) {
                if (qty > delta) {
                    row.qty = norm(qty - delta);
                    var giftIdx = findPurchaseCartMergeIndex(row.productId, unit, whId, true);
                    if (giftIdx >= 0) {
                        purchaseCart[giftIdx].qty = norm((purchaseCart[giftIdx].qty || 0) + delta);
                    } else {
                        purchaseCart.splice(idx + 1, 0, clonePurchaseCartRow(row, { qty: delta, isGift: true, discount: 0 }));
                    }
                } else {
                    row.isGift = true;
                    row.discount = 0;
                }
                return;
            }

            if (qty > delta) {
                row.qty = norm(qty - delta);
                var paidIdx = findPurchaseCartMergeIndex(row.productId, unit, whId, false);
                if (paidIdx >= 0) {
                    purchaseCart[paidIdx].qty = norm((purchaseCart[paidIdx].qty || 0) + delta);
                } else {
                    purchaseCart.splice(idx + 1, 0, clonePurchaseCartRow(row, { qty: delta, isGift: false, discount: 0 }));
                }
            } else {
                var paidIdx2 = findPurchaseCartMergeIndex(row.productId, unit, whId, false);
                if (paidIdx2 >= 0) {
                    purchaseCart[paidIdx2].qty = norm((purchaseCart[paidIdx2].qty || 0) + qty);
                    purchaseCart.splice(idx, 1);
                } else {
                    row.isGift = false;
                    row.discount = 0;
                }
            }
        }

        function getPurchaseGiftSummary() {
            var lines = 0;
            var totalQty = 0;
            var items = [];
            purchaseCart.forEach(function (row) {
                if (!row || !row.isGift) return;
                var q = parseFloat(row.qty) || 0;
                if (q <= 0) return;
                lines += 1;
                totalQty += q;
                items.push({
                    name: row.productName || '',
                    qty: q,
                    unit: row.unit || 'piece'
                });
            });
            return { lines: lines, totalQty: totalQty, items: items };
        }

        function updatePurchaseGiftSummaryUi() {
            var box = document.getElementById('purchase-gift-summary');
            var textEl = document.getElementById('purchase-gift-summary-text');
            var detailEl = document.getElementById('purchase-gift-summary-detail');
            if (!box || !textEl) return;
            var sum = getPurchaseGiftSummary();
            if (!sum.lines) {
                box.classList.add('is-hidden');
                textEl.textContent = '';
                if (detailEl) detailEl.textContent = '';
                return;
            }
            box.classList.remove('is-hidden');
            var qtyStr = (typeof formatQtyForInput === 'function')
                ? formatQtyForInput(sum.totalQty, null)
                : String(sum.totalQty);
            textEl.textContent = sum.lines + ' جۆر · ' + qtyStr + ' دانە';
            if (detailEl) {
                detailEl.textContent = sum.items.map(function (it) {
                    var q = (typeof formatQtyForInput === 'function') ? formatQtyForInput(it.qty, null) : String(it.qty);
                    var ul = (typeof getProductUnitLabel === 'function') ? getProductUnitLabel(it, it.unit) : it.unit;
                    return escapeHtml(it.name || '') + ' × ' + q + ' ' + escapeHtml(ul);
                }).join(' · ');
            }
        }

        window.togglePurchaseCartGift = function (idx) {
            splitPurchaseCartGiftUnit(idx);
            schedulePurchaseCartRender();
            var sum = getPurchaseGiftSummary();
            if (typeof showToast === 'function' && sum.totalQty > 0) {
                var qtyStr = (typeof formatQtyForInput === 'function') ? formatQtyForInput(sum.totalQty, null) : String(sum.totalQty);
                showToast('دیاری: ' + sum.lines + ' جۆر · ' + qtyStr + ' دانە', 'info');
            }
        };

        function initSalesReturnScreen() {
            var view = document.getElementById('view-returns-new');
            if (!view) return;

            var legacyTopRow = document.getElementById('returns-new-top-row');
            if (legacyTopRow) legacyTopRow.remove();

            var hasTxnMeta = !!view.querySelector('.txn-meta-sticky[data-txn-meta="returns-new"]');
            if (!hasTxnMeta) {
                var topBar = view.querySelector('.pos-top-bar') || view.querySelector('.returns-top-bar');
                if (!topBar) return;
                var topRow = document.getElementById('returns-new-top-row');
                if (!topRow) {
                    topRow = document.createElement('div');
                    topRow.id = 'returns-new-top-row';
                    topRow.className = 'purchase-top-supplier-row txn-legacy-meta-row';
                    var debtWrap = document.createElement('div');
                    debtWrap.className = 'purchase-top-field txn-meta-field';
                    debtWrap.innerHTML = '<label class="purchase-label">' + escapeHtml(t('returns_debt_on_label')) + '</label>';
                    var existingDebtSelect = document.getElementById('returns-debt-select') || view.querySelector('.returns-debt-select');
                    if (existingDebtSelect) {
                        debtWrap.appendChild(existingDebtSelect);
                    } else {
                        existingDebtSelect = document.createElement('select');
                        existingDebtSelect.id = 'returns-debt-select';
                        existingDebtSelect.className = 'input-std returns-debt-select purchase-supplier-select';
                        existingDebtSelect.innerHTML = '<option value="">' + escapeHtml(t('returns_select_cash_short')) + '</option>';
                        debtWrap.appendChild(existingDebtSelect);
                    }
                    var invWrap = document.createElement('div');
                    invWrap.className = 'purchase-top-field txn-meta-field';
                    var existingInvInput = document.getElementById('returns-new-invoice-ref');
                    if (!existingInvInput) {
                        invWrap.innerHTML = '<label class="purchase-label">' + escapeHtml(t('returns_sale_invoice_label')) + '</label>' +
                            '<input type="text" id="returns-new-invoice-ref" class="input-std" maxlength="20" dir="ltr">';
                        existingInvInput = invWrap.querySelector('input');
                    } else {
                        invWrap.innerHTML = '<label class="purchase-label">' + escapeHtml(t('returns_sale_invoice_label')) + '</label>';
                        invWrap.appendChild(existingInvInput);
                    }
                    if (existingInvInput) existingInvInput.placeholder = t('returns_invoice_ref_placeholder');
                    topRow.appendChild(debtWrap);
                    topRow.appendChild(invWrap);
                    var searchBar = view.querySelector('.pos-search-unit-bar');
                    if (searchBar && searchBar.parentNode) {
                        searchBar.parentNode.insertBefore(topRow, searchBar);
                    } else {
                        topBar.insertBefore(topRow, topBar.firstChild);
                    }
                }
            }

            var debtSel = document.getElementById('returns-debt-select') || view.querySelector('.returns-debt-select');
            if (debtSel && debtSel.options.length <= 1) {
                debtSel.innerHTML = '<option value="">' + escapeHtml(t('returns_select_cash_short')) + '</option>';
                if (db && db.customers) {
                    var sorted = db.customers.slice().sort((a,b) => (a.name||'').localeCompare(b.name||''));
                    sorted.forEach(c => {
                        debtSel.innerHTML += `<option value="customer_${c.id}">${escapeHtml(c.name)} ${escapeHtml(t('returns_tag_customer'))}</option>`;
                    });
                }
                if (db && db.users) {
                    db.users.forEach(u => {
                        debtSel.innerHTML += `<option value="user_${u.id}">${escapeHtml(u.name)} ${escapeHtml(t('returns_tag_staff'))}</option>`;
                    });
                }
            }
            
            if (window.pendingReturnFromSale) {
                if (typeof applyPendingReturnFromSale === 'function') {
                    applyPendingReturnFromSale();
                } else {
                    var s = window.pendingReturnFromSale;
                    var invEl = document.getElementById('returns-new-invoice-ref');
                    if (invEl) invEl.value = s.id;
                    if (debtSel) {
                        if (s.customer_id && s.customer_type) {
                            debtSel.value = s.customer_type + '_' + s.customer_id;
                        } else {
                            debtSel.value = '';
                        }
                    }
                    window.pendingReturnFromSale = null;
                }
                if (typeof renderReturnsMenu === 'function') renderReturnsMenu();
                if (typeof window.maybeCollapseTxnMetaAfterValid === 'function') {
                    window.maybeCollapseTxnMetaAfterValid('returns-new', ['returns-new-invoice-ref']);
                }
            }
            
            var searchEl = view.querySelector('.pos-search-input');
            if (searchEl && window.innerWidth > 768) setTimeout(function() { searchEl.focus(); }, 150);

            if (typeof renderReturnsCategories === 'function') renderReturnsCategories();
            if (typeof renderReturnsMenu === 'function') renderReturnsMenu((document.getElementById('returns-barcode-input') || {}).value || '');

            if (typeof window.applyI18nSubtree === 'function') window.applyI18nSubtree(view);
        }

        function isTxnMobileUi() {
            return typeof window.isTxnMobileViewport === 'function' && window.isTxnMobileViewport();
        }

        function stampTxnMobileCartLabels(root) {
            if (!isTxnMobileUi() || !root) return;
            root.querySelectorAll('.returns-row-disc').forEach(function (el) {
                el.setAttribute('data-txn-label', 'داشکاندن');
            });
            root.querySelectorAll('.purchase-price-step-wrap').forEach(function (el) {
                if (!el.getAttribute('data-txn-label')) {
                    el.setAttribute('data-txn-label', el.classList.contains('purchase-sell-step-wrap') ? 'فرۆشتن' : 'کڕین');
                }
            });
            root.querySelectorAll('.returns-row-price').forEach(function (el) {
                if (el.closest && el.closest('.purchase-price-step-wrap')) return;
                el.setAttribute('data-txn-label', el.classList.contains('returns-row-sell') ? 'فرۆشتن' : 'کڕین');
            });
            root.querySelectorAll('.returns-row-qty-wrap input[type="number"]').forEach(function (el) {
                el.setAttribute('data-txn-label', 'ژمارە');
            });
            root.querySelectorAll('.purchase-expiry-input').forEach(function (el) {
                el.setAttribute('data-txn-label', 'بەروار');
            });
        }

        /** Parse numeric purchase invoice id (ignores TXPI_LOCAL_* / uniqid hex). */
        function parsePurchaseTransactionNumber(tid) {
            if (tid == null || tid === '') return 0;
            var s = String(tid).trim();
            if (/^\d{1,12}$/.test(s)) return parseInt(s, 10);
            return 0;
        }

        /** Next sequential «ژمارا مە» for purchase (e.g. 000045). */
        function allocateNextPurchaseTransactionId() {
            var maxNum = 0;
            function scanTxnId(tid) {
                var n = parsePurchaseTransactionNumber(tid);
                if (n > maxNum) maxNum = n;
            }
            (db.supplies || []).forEach(function(s) { if (s && s.transaction_id) scanTxnId(s.transaction_id); });
            (db.ledger || []).forEach(function(l) { if (l && l.transaction_id) scanTxnId(l.transaction_id); });
            (db.expenses || []).forEach(function(e) {
                if (e && e.transaction_id && (e.type === 'purchase' || String(e.note || '').indexOf('کڕین') >= 0 || String(e.note || '').indexOf('شراء') >= 0)) {
                    scanTxnId(e.transaction_id);
                }
            });
            var next = maxNum + 1;
            return String(next).padStart(6, '0');
        }

        function formatPurchaseTransactionIdForDisplay(tid) {
            if (tid == null || tid === '') return '---';
            var n = parsePurchaseTransactionNumber(tid);
            if (n > 0) return String(n).padStart(6, '0');
            var s = String(tid).trim();
            if (/^TXPI/i.test(s) || /_LOCAL_/i.test(s)) return '---';
            return s;
        }

        function formatWhTransferReceiptNo(tr) {
            if (!tr) return '---';
            var tid = tr.transaction_id != null ? String(tr.transaction_id).trim() : '';
            if (/^\d+$/.test(tid)) return tid.padStart(6, '0');
            if (/^TXF/i.test(tid) || !tid) {
                var id = parseInt(tr.id, 10);
                if (id > 0) return String(id).padStart(6, '0');
            }
            return tid || '---';
        }

        /** Supplier invoice # for print/list; never use txnId.substring (breaks 000045 → 45). */
        function resolveCompanyInvoiceDisplayNumber(supplierInv, txnId) {
            var sup = supplierInv != null ? String(supplierInv).trim() : '';
            if (sup && sup !== '---') return sup;
            if (typeof formatPurchaseTransactionIdForDisplay === 'function') {
                var fmt = formatPurchaseTransactionIdForDisplay(txnId);
                if (fmt && fmt !== '---') return fmt;
            }
            return txnId != null && String(txnId).trim() ? String(txnId).trim() : '---';
        }

        window.allocateNextPurchaseTransactionId = allocateNextPurchaseTransactionId;
        window.formatWhTransferReceiptNo = formatWhTransferReceiptNo;
        window.formatPurchaseTransactionIdForDisplay = formatPurchaseTransactionIdForDisplay;
        window.resolveCompanyInvoiceDisplayNumber = resolveCompanyInvoiceDisplayNumber;

        function purchaseInvoiceRefVariants(ref) {
            var raw = ref != null ? String(ref).trim() : '';
            var out = [];
            if (!raw) return out;
            out.push(raw.toLowerCase());
            if (/^\d{1,12}$/.test(raw)) {
                var n = parseInt(raw, 10);
                if (Number.isFinite(n) && n > 0) {
                    out.push(String(n));
                    out.push(String(n).padStart(6, '0'));
                }
            }
            return out.filter(function (v, i, a) { return v && a.indexOf(v) === i; });
        }

        function supplyInvoiceRefVariants(s) {
            if (!s) return [];
            var out = [];
            var sup = String(s.supplier_invoice_number || '').trim();
            if (sup) out.push(sup.toLowerCase());
            var tid = String(s.transaction_id || '').trim();
            if (tid) {
                out.push(tid.toLowerCase());
                if (typeof formatPurchaseTransactionIdForDisplay === 'function') {
                    var fmt = formatPurchaseTransactionIdForDisplay(tid);
                    if (fmt && fmt !== '---') out.push(String(fmt).toLowerCase());
                }
                if (typeof parsePurchaseTransactionNumber === 'function') {
                    var n = parsePurchaseTransactionNumber(tid);
                    if (n > 0) {
                        out.push(String(n));
                        out.push(String(n).padStart(6, '0'));
                    }
                }
            }
            return out.filter(function (v, i, a) { return v && a.indexOf(v) === i; });
        }

        function supplyMatchesPurchaseReturnCompany(s, supplierName) {
            if (!s || !supplierName) return false;
            return String(s.company || '').trim().toLowerCase() === String(supplierName).trim().toLowerCase();
        }

        function supplyMatchesPurchaseReturnInvoiceRef(s, invRefRaw) {
            var invRef = invRefRaw != null ? String(invRefRaw).trim() : '';
            if (!invRef) return true;
            var userVars = purchaseInvoiceRefVariants(invRef);
            var rowVars = supplyInvoiceRefVariants(s);
            for (var i = 0; i < userVars.length; i++) {
                if (rowVars.indexOf(userVars[i]) >= 0) return true;
            }
            return false;
        }

        function resolvePurchaseReturnInvoiceContext(supplierName, invRefRaw) {
            var invRef = invRefRaw != null ? String(invRefRaw).trim() : '';
            if (!supplierName || !invRef) return null;
            var byTxn = {};
            getPurchaseReturnSuppliesList().forEach(function (s) {
                if (!supplyMatchesPurchaseReturnCompany(s, supplierName)) return;
                if (s.type === 'opening') return;
                if (!supplyMatchesPurchaseReturnInvoiceRef(s, invRef)) return;
                var txn = String(s.transaction_id || '').trim();
                var sup = String(s.supplier_invoice_number || '').trim();
                if (!txn && !sup) return;
                var key = txn || ('sup:' + sup);
                byTxn[key] = { supplier_invoice_number: sup, transaction_id: txn };
            });
            var keys = Object.keys(byTxn);
            if (!keys.length) return null;
            var pick = byTxn[keys[0]];
            var canonical = pick.supplier_invoice_number || pick.transaction_id;
            if (!canonical) return null;
            return {
                supplier_invoice_number: pick.supplier_invoice_number,
                transaction_id: pick.transaction_id,
                canonical: canonical
            };
        }

        function listPurchaseReturnInvoiceHints(companyName) {
            var seen = {};
            var out = [];
            getPurchaseReturnSuppliesList().forEach(function (s) {
                if (!supplyMatchesPurchaseReturnCompany(s, companyName)) return;
                if (s.type === 'return' || s.type === 'opening') return;
                if ((parseFloat(s.qtyAdded) || 0) <= 0) return;
                var label = resolveCompanyInvoiceDisplayNumber(s.supplier_invoice_number, s.transaction_id);
                if (!label || label === '---' || seen[label]) return;
                seen[label] = 1;
                out.push(label);
            });
            return out.slice(0, 8);
        }

        window.resolvePurchaseReturnInvoiceContext = resolvePurchaseReturnInvoiceContext;

        function requirePurchaseSupplierInvoiceNumber(focus) {
            var invNumEl = document.getElementById('purchase-supplier-invoice-number');
            var supplierInvoiceNumber = (invNumEl && invNumEl.value) ? String(invNumEl.value).trim() : '';
            if (!supplierInvoiceNumber) {
                if (typeof window.highlightTxnMetaFields === 'function') {
                    window.highlightTxnMetaFields('purchase', ['purchase-supplier-invoice-number']);
                }
                var msg = (typeof t === 'function') ? t('purchase_invoice_ref_required') : 'پێدڤیە ژمارا پسوولێ بنڤیسی!';
                if (typeof showToast === 'function') showToast(msg, 'error');
                else alert(msg);
                if (invNumEl && focus !== false) { invNumEl.focus(); invNumEl.classList.add('input-error'); }
                return false;
            }
            if (invNumEl) invNumEl.classList.remove('input-error');
            return true;
        }

        function requirePurchaseBatchNumber(focus) {
            if (typeof canUsePurchaseBatch === 'function' && !canUsePurchaseBatch()) return true;
            var batchEl = document.getElementById('purchase-batch-number');
            var batchNumber = (batchEl && batchEl.value) ? String(batchEl.value).trim() : '';
            if (!batchNumber) {
                if (typeof window.highlightTxnMetaFields === 'function') {
                    window.highlightTxnMetaFields('purchase', ['purchase-batch-number']);
                }
                var msg = (typeof t === 'function') ? t('purchase_batch_number_required') : 'پێدڤیە ژمارا وەجبێ بنڤیسی!';
                if (typeof showToast === 'function') showToast(msg, 'error');
                else alert(msg);
                if (batchEl && focus !== false) { batchEl.focus(); batchEl.classList.add('input-error'); }
                return false;
            }
            if (batchEl) batchEl.classList.remove('input-error');
            return true;
        }

        window.requirePurchaseBatchNumber = requirePurchaseBatchNumber;

        function applyPurchaseBatchPremiumUi() {
            var view = document.getElementById('view-purchase');
            var batchEl = document.getElementById('purchase-batch-number');
            var lockBtn = document.getElementById('purchase-batch-pro-lock');
            var unlocked = (typeof canUsePurchaseBatch === 'function') ? canUsePurchaseBatch() : true;
            if (view) view.classList.toggle('purchase-batch-locked', !unlocked);
            if (batchEl) {
                batchEl.required = unlocked;
                if (!unlocked) batchEl.value = '';
            }
            if (lockBtn) {
                lockBtn.style.display = unlocked ? 'none' : '';
                if (!unlocked && typeof applyPosPremiumPricingLabels === 'function') {
                    applyPosPremiumPricingLabels(lockBtn.parentElement || lockBtn);
                }
            }
        }
        window.applyPurchaseBatchPremiumUi = applyPurchaseBatchPremiumUi;

        function requirePurchaseReturnSupplierInvoiceRef(focus) {
            var refInput = document.getElementById('purchase-return-supplier-invoice-ref');
            var supplierInvoiceRef = (refInput && refInput.value) ? String(refInput.value).trim() : '';
            if (!supplierInvoiceRef) {
                if (typeof window.highlightTxnMetaFields === 'function') {
                    window.highlightTxnMetaFields('purchase-returns', ['purchase-return-supplier-invoice-ref']);
                }
                var msg = (typeof t === 'function') ? t('purchase_invoice_ref_required') : 'پێدڤیە ژمارا پسوولێ بنڤیسی!';
                if (typeof showToast === 'function') showToast(msg, 'error');
                else alert(msg);
                if (refInput && focus !== false) { refInput.focus(); refInput.classList.add('input-error'); }
                return false;
            }
            if (refInput) refInput.classList.remove('input-error');
            return true;
        }

        function initPurchaseScreen() {
            if (typeof fillWarehouseSelects === 'function') fillWarehouseSelects();
            if (typeof applyMultiWarehouseVisibility === 'function') applyMultiWarehouseVisibility();
            var sel = document.getElementById('purchase-supplier-select');
            if (!sel) return;
            var keepSupplierId = '';
            var keepSupplierName = '';
            if (window._posEditingPurchase && window._posEditingPurchase.txnId) {
                keepSupplierId = window._posEditingPurchase.company_id ? String(window._posEditingPurchase.company_id) : '';
                keepSupplierName = String(window._posEditingPurchase.company || '');
            } else if (sel.value) {
                keepSupplierId = String(sel.value);
            }
            sel.innerHTML = '<option value="">-- هەلبژێرە --</option>';
            (db.companies || []).slice().sort(function(a,b){ return (a.name||'').localeCompare(b.name||''); }).forEach(function(c) {
                sel.innerHTML += '<option value="' + c.id + '">' + escapeHtml(c.name || '') + '</option>';
            });
            if (keepSupplierId) sel.value = keepSupplierId;
            if (typeof window.ensurePurchaseSupplierDatalist === 'function') window.ensurePurchaseSupplierDatalist();
            else if (typeof window.syncPurchaseSupplierSearchFromSelect === 'function') window.syncPurchaseSupplierSearchFromSelect();
            if (keepSupplierName) {
                var searchKeep = document.getElementById('purchase-supplier-search');
                if (searchKeep && (!searchKeep.value || !sel.value)) searchKeep.value = keepSupplierName;
            }
            var invNumInput = document.getElementById('purchase-supplier-invoice-number');
            if (typeof setPurchaseUnit === 'function') setPurchaseUnit(typeof purchaseSelectedUnit !== 'undefined' ? purchaseSelectedUnit : 'piece');
            if (typeof renderPurchaseCategories === 'function') renderPurchaseCategories();
            debouncedRenderPurchaseProductGrid();
            renderPurchaseCart();
            if (typeof updatePurchaseDebtSummary === 'function') updatePurchaseDebtSummary(0);
            if (typeof initCartAppearanceFromStorage === 'function') initCartAppearanceFromStorage();
            if (window.innerWidth > 768) {
                var purchaseSticky = document.querySelector('#view-purchase .txn-meta-sticky[data-txn-meta="purchase"]');
                if (purchaseSticky) purchaseSticky.classList.remove('is-collapsed');
            }
            if (typeof window.refreshTxnScreen === 'function') window.refreshTxnScreen('purchase');
            if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('purchase');
            if (typeof applyPurchaseBatchPremiumUi === 'function') applyPurchaseBatchPremiumUi();
        }

        function onPurchaseSupplierChange() {
            var sel = document.getElementById('purchase-supplier-select');
            var paidField = document.querySelector('#view-purchase .purchase-paid-field');
            var paidInput = document.getElementById('purchase-supplier-paid');
            var hasSupplier = !!(sel && sel.value);

            if (paidField) paidField.classList.toggle('is-hidden-until-supplier', !hasSupplier);
            if (!hasSupplier && paidInput) paidInput.value = '';

            debouncedRenderPurchaseProductGrid();
            renderPurchaseCart();
            if (hasSupplier && typeof window.maybeCollapseTxnMetaAfterValid === 'function') {
                // Keep meta open while editing an existing purchase invoice
                if (!(window._posEditingPurchase && window._posEditingPurchase.txnId)) {
                    var purchaseMetaFields = ['purchase-supplier-select', 'purchase-supplier-invoice-number'];
                    if (typeof canUsePurchaseBatch === 'function' && canUsePurchaseBatch()) {
                        purchaseMetaFields.push('purchase-batch-number');
                    }
                    window.maybeCollapseTxnMetaAfterValid('purchase', purchaseMetaFields);
                }
            }
            if (typeof window.updateTxnPeekBar === 'function') window.updateTxnPeekBar('purchase');
            if (typeof calculatePurchaseDebtRemaining === 'function') calculatePurchaseDebtRemaining();
            if (hasSupplier && sel && sel.value) {
                var compId = parseInt(sel.value, 10);
                var compPick = (db && db.companies) ? db.companies.find(function(c) { return c && c.id === compId; }) : null;
                if (compPick) {
                    var compKey = 'co:' + String(compPick.id);
                    if (window._purchasePaymentDuePrefillKey !== compKey) {
                        window._purchasePaymentDuePrefillKey = compKey;
                        if (typeof applyEntityPaymentTermToTxn === 'function') applyEntityPaymentTermToTxn('purchase', compPick);
                    }
                    if (typeof maybeToastPaymentDueOverdue === 'function') maybeToastPaymentDueOverdue('company', compPick);
                }
            } else {
                window._purchasePaymentDuePrefillKey = null;
            }
            if (typeof window.syncPurchaseSupplierSearchFromSelect === 'function') {
                var _supSearch = document.getElementById('purchase-supplier-search');
                if (!(_supSearch && document.activeElement === _supSearch)) {
                    window.syncPurchaseSupplierSearchFromSelect();
                }
            }
            if (typeof connectToDB === 'function' && !(typeof isPosCpuSaveMode === 'function' && isPosCpuSaveMode())) {
                connectToDB(true, { skipRenderOnRefresh: true }).then(function() {
                    renderPurchaseCart();
                }).catch(function() {});
            }
        }

        function debouncedRenderPurchaseProductGrid() {
            if (purchaseGridTimeout) clearTimeout(purchaseGridTimeout);
            var _gMs = (typeof posTxnGridDebounceMs === 'function') ? posTxnGridDebounceMs() : 120;
            purchaseGridTimeout = setTimeout(renderPurchaseProductGrid, _gMs);
        }

        function renderPurchaseProductGrid() {
            var grid = document.getElementById('purchase-product-grid');
            var sel = document.getElementById('purchase-supplier-select');
            var q = (document.getElementById('purchase-search') && document.getElementById('purchase-search').value) || '';
            if (!grid) return;
            var supplierId = sel && sel.value ? parseInt(sel.value, 10) : null;
            var comp = supplierId ? (db.companies || []).find(function(c) { return c.id === supplierId; }) : null;
            var supplierName = comp ? comp.name : null;
            var activeUnit = typeof purchaseSelectedUnit !== 'undefined' ? purchaseSelectedUnit : 'piece';
            var list = (db.products || []).filter(function(p) {
                if (!productMatchesUnitFilter(p, activeUnit, true)) return false;
                if (purchaseActiveCategory && purchaseActiveCategory !== 'all' && purchaseProductCat(p) !== purchaseActiveCategory) return false;
                if (q.trim() && typeof window.productMatchesBarcodeOrNameSearch === 'function' && !window.productMatchesBarcodeOrNameSearch(p, q)) return false;
                return true;
            });
            var _gridMax = (typeof posTxnGridProductLimit === 'function') ? posTxnGridProductLimit(q) : 50;
            if (list.length > _gridMax) {
                list = list.slice().sort(function (a, b) {
                    if (a.isPinned && !b.isPinned) return -1;
                    if (!a.isPinned && b.isPinned) return 1;
                    return (b.id || 0) - (a.id || 0);
                }).slice(0, _gridMax);
            }
            var countBadge = document.getElementById('purchase-products-count');
            if (countBadge) countBadge.textContent = String(list.length);

            grid.innerHTML = '';
            if (list.length === 0) {
                grid.innerHTML = '<div class="txn-grid-empty-state pos-empty-products"><i class="fas fa-box-open"></i><span>' +
                    escapeHtml((typeof t === 'function') ? t('purchase_no_products_hint') : 'چ ئایتم نەدۆزرایەوە — خۆت زێدەکە / داخلکە') +
                    '</span></div>';
            }
            var activeUnit = typeof purchaseSelectedUnit !== 'undefined' ? purchaseSelectedUnit : 'piece';
            var cardIcon = activeUnit === 'carton' ? 'fa-box' : (activeUnit === 'pack' ? 'fa-boxes' : 'fa-cube');
            list.forEach(function(p) {
                var costActive = 0;
                if (activeUnit === 'carton' && typeof getCatalogCartonCostActive === 'function') {
                    costActive = getCatalogCartonCostActive(p);
                } else if (activeUnit === 'pack' && typeof getCatalogPackCostActive === 'function') {
                    costActive = getCatalogPackCostActive(p);
                } else if (typeof getCatalogPieceCostActive === 'function') {
                    costActive = getCatalogPieceCostActive(p);
                } else {
                    costActive = typeof getPurchaseCostForUnit === 'function' ? getPurchaseCostForUnit(p, activeUnit) : (parseFloat(p.cost) || 0);
                }
                var unitLabel = getProductUnitLabel(p, activeUnit);
                var costDisplay = (costActive > 0)
                    ? ((typeof formatActiveCurrencyAmount === 'function') ? formatActiveCurrencyAmount(costActive) : formatCurrency(costActive))
                    : '-';
                var priceLine = unitLabel + ': ' + costDisplay;
                if ((typeof isJewelryByWeightProduct === 'function') && isJewelryByWeightProduct(p)
                    && (typeof jewelryMetaLabel === 'function')) {
                    var jewMeta = jewelryMetaLabel(p);
                    if (jewMeta) priceLine = jewMeta + ' · ' + priceLine;
                }
                var card = document.createElement('div');
                card.className = 'unified-product-card p-card txn-product-card txn-product-card--purchase';
                var pid = p.id;
                card.setAttribute('data-product-id', String(pid));
                card.setAttribute('data-sale-unit', activeUnit);
                var ctaShort = (typeof t === 'function') ? t('unified_card_cta_add') : 'زیادکرن';
                var canEditProd = typeof hasPermission === 'function' && hasPermission('products_manage');
                var editTitle = (typeof t === 'function') ? t('purchase_card_edit_title') : 'دەستکاری ئایتم';
                var editBtn = canEditProd
                    ? '<button type="button" class="txn-card-edit-btn" data-product-id="' + pid + '" title="' + escapeHtml(editTitle) + '" aria-label="' + escapeHtml(editTitle) + '"><i class="fas fa-pen" aria-hidden="true"></i></button>'
                    : '';
                card.innerHTML = editBtn + '<div class="unified-card-header"><div class="unified-card-icon"><i class="fas ' + cardIcon + '"></i></div><div class="unified-card-barcode">' + escapeHtml((p.barcode || '').substring(0, 12) || '---') + '</div></div>' +
                    '<div class="unified-card-name">' + escapeHtml(p.name || 'ئایتم') + '</div>' +
                    '<div class="unified-card-price">' + escapeHtml(priceLine) + '</div>' +
                    '<div class="unified-card-cta"><i class="fas fa-cart-plus"></i> ' + escapeHtml(ctaShort) + '</div>';
                if (canEditProd) {
                    var editEl = card.querySelector('.txn-card-edit-btn');
                    if (editEl && typeof bindPurchaseCardEditButton === 'function') bindPurchaseCardEditButton(editEl, pid);
                }
                grid.appendChild(card);
            });
            appendPurchaseDefineYourselfCard(grid);
        }

        function purchaseDefineYourselfMsg() {
            return (typeof t === 'function') ? t('purchase_define_yourself') : 'ئایتم نەهاتە داخلکرن — خۆت چێکە، زێدەکە، داخلکە';
        }

        function promptPurchaseDefineMissingItem(barcode) {
            var msg = purchaseDefineYourselfMsg();
            if (typeof hasPermission === 'function' && !hasPermission('products_manage')) {
                if (typeof showToast === 'function') {
                    showToast(msg + ' — ' + ((typeof t === 'function') ? t('purchase_define_no_perm') : 'تۆ دەستوورا زێدەکرنێ نینە'), 'error');
                }
                return;
            }
            if (typeof showToast === 'function') showToast(msg, 'info');
            if (typeof window.openQuickDefineModal === 'function') {
                window.openQuickDefineModal(barcode || '', { fromPurchaseAdd: true });
            }
        }

        function appendPurchaseDefineYourselfCard(grid) {
            if (!grid) return;
            if (typeof hasPermission === 'function' && !hasPermission('products_manage')) return;
            var title = (typeof t === 'function') ? t('purchase_add_yourself_title') : 'زێدەکە بخو';
            var sub = (typeof t === 'function') ? t('purchase_add_yourself_sub') : 'چێکە بخو · داخلکە بخو';
            var cta = (typeof t === 'function') ? t('purchase_add_yourself_cta') : 'بکە — پێناسەکرن';
            var card = document.createElement('div');
            card.className = 'unified-product-card p-card txn-product-card txn-product-card--purchase-add';
            card.setAttribute('role', 'button');
            card.setAttribute('tabindex', '0');
            card.setAttribute('title', title);
            card.innerHTML =
                '<div class="unified-card-header">' +
                    '<div class="unified-card-icon"><i class="fas fa-plus"></i></div>' +
                    '<div class="unified-card-barcode">—</div>' +
                '</div>' +
                '<div class="unified-card-name">' + escapeHtml(title) + '</div>' +
                '<div class="unified-card-price">' + escapeHtml(sub) + '</div>' +
                '<div class="unified-card-cta"><i class="fas fa-magic"></i> ' + escapeHtml(cta) + '</div>';
            grid.appendChild(card);
        }

        function addToPurchaseCart(pid, unitOverride) {
            if (typeof isWorkspaceViewActive === 'function' && !isWorkspaceViewActive('purchase')) return;
            var p = (db.products || []).find(function(x) { return String(x.id) === String(pid); });
            if (!p) return;
            var unit = (unitOverride === 'carton' || unitOverride === 'pack' || unitOverride === 'piece') ? unitOverride : (typeof purchaseSelectedUnit !== 'undefined' ? purchaseSelectedUnit : 'piece');
            if (typeof resolveSmartUnitForProduct === 'function') {
                var smartPur = resolveSmartUnitForProduct(p, unit, true);
                unit = smartPur.unit;
            }
            var costPerUnit = typeof getPurchaseCostForUnit === 'function' ? getPurchaseCostForUnit(p, unit) : ((p.cost != null && p.cost !== '') ? parseFloat(p.cost) : 0);
            var whId = (typeof shouldShowPurchaseWarehouseUi === 'function' && shouldShowPurchaseWarehouseUi()) ? getPurchaseTargetWarehouseId() : 0;
            var existing = purchaseCart.find(function(row) {
                return row.productId === pid && (row.unit || 'piece') === unit &&
                    !!row.isGift === false &&
                    (!(typeof shouldShowPurchaseWarehouseUi === 'function' && shouldShowPurchaseWarehouseUi()) ||
                        Number(getPurchaseRowWarehouseId(row)) === Number(whId));
            });
            if (existing) {
                existing.qty = normalizeQtyForProduct(p, (existing.qty || 0) + 1);
            } else {
                purchaseCart.push({
                    productId: p.id,
                    productName: p.name || '',
                    qty: 1,
                    unit: unit,
                    costPerUnit: costPerUnit,
                    sellPerUnit: typeof getPurchaseSellForUnit === 'function' ? getPurchaseSellForUnit(p, unit) : 0,
                    discount: 0,
                    isGift: false,
                    expiry_date: '',
                    expiry_visible: false,
                    productRef: p,
                    warehouseId: whId || (typeof getDefaultWarehouseId === 'function' ? getDefaultWarehouseId() : 0)
                });
            }
            if (typeof notifyPurchaseWarehouseAdded === 'function') notifyPurchaseWarehouseAdded(p, whId);
            schedulePurchaseCartRender();
            if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('purchase', { clear: true, delay: 0 });
        }

        function formatAutoDate(val) {
            if (!val) return '';
            var v = String(val).replace(/\D/g, '');
            if (v.length > 0 && !v.startsWith('20')) {
                if (v.length >= 2 || (v.length === 1 && v !== '2')) {
                    v = '20' + v;
                }
            }
            if (v.length > 8) v = v.substring(0, 8);
            var res = '';
            if (v.length > 0) res += v.substring(0, 4);
            if (v.length > 4) {
                var month = v.substring(4, 6);
                if (month.length === 2) {
                    var m = parseInt(month, 10);
                    if (m < 1) month = '01';
                    if (m > 12) month = '12';
                } else if (month.length === 1) {
                    var m = parseInt(month, 10);
                    if (m > 1) month = '0' + m;
                }
                res += '-' + month;
            }
            if (v.length > 6) {
                var day = v.substring(6, 8);
                if (day.length === 2) {
                    var d = parseInt(day, 10);
                    if (d < 1) day = '01';
                    if (d > 31) day = '31';
                } else if (day.length === 1) {
                    var d = parseInt(day, 10);
                    if (d > 3) day = '0' + d;
                }
                res += '-' + day;
            }
            return res;
        }

        /** True only when this product already has expiry batches (not item_type / clothing). */
        function productUsesExpiryTracking(productOrId) {
            var p = (productOrId && typeof productOrId === 'object')
                ? productOrId
                : (db.products || []).find(function(x) { return String(x.id) === String(productOrId); });
            if (!p) return false;
            if (p.batch_qty_sum != null && p.batch_qty_sum !== '' && (parseFloat(p.batch_qty_sum) || 0) > 0) return true;
            if (p.batch_min_expiry && String(p.batch_min_expiry).trim()) return true;
            var pid = p.id;
            var supplies = db.supplies || [];
            for (var si = 0; si < supplies.length; si++) {
                var s = supplies[si];
                if (String(s.prodId) !== String(pid) || s.type === 'return') continue;
                if (String(s.expiry_date || '').trim()) return true;
            }
            return false;
        }

        /** Purchase save: expiry only when checkbox is on AND date is full YYYY-MM-DD; otherwise skip. */
        function normalizePurchaseExpiryRows(rowsToSend) {
            var ymdRx = /^\d{4}-\d{2}-\d{2}$/;
            for (var vi = 0; vi < rowsToSend.length; vi++) {
                var row = rowsToSend[vi];
                if (!row.expiry_visible) {
                    row.expiry_visible = false;
                    row.expiry_date = '';
                    continue;
                }
                var exp = String(row.expiry_date || '').trim();
                if (!ymdRx.test(exp)) {
                    row.expiry_visible = false;
                    row.expiry_date = '';
                } else {
                    row.expiry_date = exp;
                }
            }
            return { ok: true };
        }
        window.productUsesExpiryTracking = productUsesExpiryTracking;

        function setPurchaseRowExpiryEnabled(idx, enabled) {
            var row = purchaseCart[idx];
            if (!row) return;
            row.expiry_visible = !!enabled;
            if (!row.expiry_visible) row.expiry_date = '';
            renderPurchaseCart();
        }
        window.setPurchaseRowExpiryEnabled = setPurchaseRowExpiryEnabled;

        function getPurchaseCartCurrency() {
            var el = document.getElementById('purchase-currency');
            var v = el ? String(el.value || '').toUpperCase() : '';
            if (v === 'USD' || v === 'IQD') return v;
            return (typeof getDefaultCurrency === 'function') ? getDefaultCurrency() : 'IQD';
        }
        function ensurePurchaseCartCurrencyDefault() {
            var el = document.getElementById('purchase-currency');
            if (!el) return;
            if (el.getAttribute('data-user-set') === '1') return;
            var def = (typeof getDefaultCurrency === 'function') ? getDefaultCurrency() : 'IQD';
            if (el.value !== def) el.value = def;
        }
        function onPurchaseCurrencyChange() {
            var el = document.getElementById('purchase-currency');
            if (el) el.setAttribute('data-user-set', '1');
            if (typeof schedulePurchaseCartRender === 'function') schedulePurchaseCartRender();
            else if (typeof renderPurchaseCart === 'function') renderPurchaseCart();
        }
        window.getPurchaseCartCurrency = getPurchaseCartCurrency;
        window.onPurchaseCurrencyChange = onPurchaseCurrencyChange;
        function isPurchaseUsdMode() {
            return getPurchaseCartCurrency() === 'USD';
        }
        function isPurchasePaymentUsdMode() {
            return (typeof getPurchaseCartCurrency === 'function')
                ? (getPurchaseCartCurrency() === 'USD')
                : isPurchaseUsdMode();
        }
        function getPurchasePaymentInputKind() {
            return isPurchasePaymentUsdMode() ? 'usd' : 'int';
        }
        function purchasePaymentDisplayToIqd(val) {
            var parsed = (typeof parseAmountInput === 'function')
                ? parseAmountInput(String(val || ''))
                : parseFloat(String(val || '').replace(/,/g, ''));
            var n = Number.isFinite(parsed) ? parsed : 0;
            if (!isPurchasePaymentUsdMode()) return n;
            var rate = (typeof getPosFrozenFxRatePerOne === 'function') ? getPosFrozenFxRatePerOne(null) : ((typeof getUsdRatePerOne === 'function') ? getUsdRatePerOne() : 0);
            var iqd = (typeof convertCurrency === 'function')
                ? convertCurrency(n, 'USD', 'IQD', rate)
                : ((typeof usdAmountToStoredIqd === 'function')
                    ? usdAmountToStoredIqd(n, rate)
                    : (rate > 0 ? n * rate : 0));
            return (typeof roundMoney === 'function' && typeof usdAmountToStoredIqd !== 'function') ? roundMoney(iqd) : iqd;
        }
        function purchasePaymentIqdToDisplay(iqdVal) {
            var n = Number(iqdVal) || 0;
            if (!isPurchasePaymentUsdMode()) return n;
            var rate = (typeof getPosFrozenFxRatePerOne === 'function') ? getPosFrozenFxRatePerOne(null) : ((typeof getUsdRatePerOne === 'function') ? getUsdRatePerOne() : 0);
            if (!(rate > 0)) return 0;
            return (typeof convertCurrency === 'function')
                ? convertCurrency(n, 'IQD', 'USD', rate)
                : ((typeof storedIqdToUsdAmount === 'function') ? storedIqdToUsdAmount(n, rate) : (n / rate));
        }
        /** Parse «پارێ دای» on purchase screen: USD entry → IQD storage; IQD entry → IQD as typed. */
        function parsePurchaseSupplierPaidToIqd(raw) {
            return (typeof purchasePaymentDisplayToIqd === 'function')
                ? purchasePaymentDisplayToIqd(raw)
                : (function(v) {
                    var p = (typeof parseAmountInput === 'function')
                        ? parseAmountInput(String(v || ''))
                        : parseFloat(String(v || '').replace(/,/g, ''));
                    return Number.isFinite(p) ? p : 0;
                })(raw);
        }
        function onPurchaseSupplierPaidInput(el) {
            if (!el) el = document.getElementById('purchase-supplier-paid');
            if (!el) return;
            var kind = (typeof getPurchasePaymentInputKind === 'function') ? getPurchasePaymentInputKind() : 'int';
            if (typeof formatPaymentInputElement === 'function') formatPaymentInputElement(el, kind);
            if (typeof calculatePurchaseDebtRemaining === 'function') calculatePurchaseDebtRemaining();
        }
        window.onPurchaseSupplierPaidInput = onPurchaseSupplierPaidInput;
        function purchaseDisplayToIqd(val) {
            var parsed = (typeof parseAmountInput === 'function')
                ? parseAmountInput(String(val || ''))
                : parseFloat(String(val || '').replace(/,/g, ''));
            var n = Number.isFinite(parsed) ? Math.max(0, parsed) : 0;
            if (!isPurchaseUsdMode()) return n;
            var r = (typeof getPosFrozenFxRatePerOne === 'function') ? getPosFrozenFxRatePerOne(null) : ((typeof getUsdRatePerOne === 'function') ? getUsdRatePerOne() : 0);
            if (!(r > 0)) return n;
            return (typeof convertCurrency === 'function')
                ? convertCurrency(n, 'USD', 'IQD', r)
                : ((typeof usdAmountToStoredIqd === 'function')
                    ? usdAmountToStoredIqd(n, r)
                    : ((typeof roundMoney === 'function') ? roundMoney(n * r) : (n * r)));
        }
        function purchaseIqdToDisplay(val) {
            var n = Math.max(0, parseFloat(val) || 0);
            if (!isPurchaseUsdMode()) return n;
            var r = (typeof getPosFrozenFxRatePerOne === 'function') ? getPosFrozenFxRatePerOne(null) : ((typeof getUsdRatePerOne === 'function') ? getUsdRatePerOne() : 0);
            if (!(r > 0)) return n;
            return (typeof convertCurrency === 'function')
                ? convertCurrency(n, 'IQD', 'USD', r)
                : ((typeof storedIqdToUsdAmount === 'function') ? storedIqdToUsdAmount(n, r) : (n / r));
        }
        function getPurchaseCartPriceInputKind() {
            return isPurchaseUsdMode() ? 'usd' : 'int';
        }
        function formatPurchaseCartPriceDisplay(iqdStoredVal) {
            var n = purchaseIqdToDisplay(iqdStoredVal);
            var kind = getPurchaseCartPriceInputKind();
            if (typeof formatPaymentAmountNumber === 'function') {
                return formatPaymentAmountNumber(n, kind);
            }
            return String(n);
        }
        function onPurchaseCartPriceInput(el, rerender) {
            if (!el) return;
            var kind = getPurchaseCartPriceInputKind();
            if (typeof formatPaymentInputElement === 'function') formatPaymentInputElement(el, kind);
            var m = /^(pur_cart|pur_ret_cart)_(\d+)_(cost|sell|price)$/.exec(el.id || '');
            if (!m) return;
            var idx = parseInt(m[2], 10);
            var field = (m[3] === 'sell') ? 'sellPerUnit' : 'costPerUnit';
            if (m[1] === 'pur_ret_cart') {
                if (typeof updatePurchaseReturnCartLine === 'function') {
                    updatePurchaseReturnCartLine(idx, field, el.value, !!rerender);
                }
            } else {
                updatePurchaseCartLine(idx, field, el.value, !!rerender);
            }
        }
        window.onPurchaseCartPriceInput = onPurchaseCartPriceInput;
        window.isPurchaseUsdMode = isPurchaseUsdMode;
        window.purchaseIqdToDisplay = purchaseIqdToDisplay;
        window.purchaseDisplayToIqd = purchaseDisplayToIqd;

        function getPurchaseCartFxBundle() {
            if (window._posEditingPurchase && window._posEditingPurchase.fx_usd_rate != null && window._posEditingPurchase.fx_usd_rate !== '') {
                return (typeof normalizeUsdBundleRate === 'function')
                    ? normalizeUsdBundleRate(window._posEditingPurchase.fx_usd_rate)
                    : Number(window._posEditingPurchase.fx_usd_rate);
            }
            if (window._pendingPurchaseReturnFromHistory && window._pendingPurchaseReturnFromHistory.fx_usd_rate != null && window._pendingPurchaseReturnFromHistory.fx_usd_rate !== '') {
                return (typeof normalizeUsdBundleRate === 'function')
                    ? normalizeUsdBundleRate(window._pendingPurchaseReturnFromHistory.fx_usd_rate)
                    : Number(window._pendingPurchaseReturnFromHistory.fx_usd_rate);
            }
            return (typeof getExchangeRate === 'function') ? getExchangeRate() : 150000;
        }
        window.getPurchaseCartFxBundle = getPurchaseCartFxBundle;

        function purchaseFormatMoneyWithSymbol(iqdVal) {
            var iqd = Number(iqdVal) || 0;
            var r = (typeof getPosFrozenFxRatePerOne === 'function') ? getPosFrozenFxRatePerOne(null) : ((typeof getUsdRatePerOne === 'function') ? getUsdRatePerOne() : 0);
            var usd = (typeof convertCurrency === 'function')
                ? convertCurrency(iqd, 'IQD', 'USD', r)
                : (r > 0 ? iqd / r : 0);
            if (typeof formatDualCurrencyLines === 'function') {
                var dual = formatDualCurrencyLines(iqd, usd, r);
                return isPurchaseUsdMode() ? dual.usd : dual.iqd;
            }
            if (isPurchaseUsdMode()) {
                return (typeof formatUsdAmount === 'function') ? formatUsdAmount(usd) : ('$' + Number(usd).toFixed(2));
            }
            var n = Math.round(iqd);
            if (n < 0) n = 0;
            var body = n.toLocaleString('en-US', { maximumFractionDigits: 0 });
            return body + ' ' + (typeof getCurrencySymbol === 'function' ? getCurrencySymbol() : 'IQD');
        }
        function paintPurchaseCartGrandTotal(grandTotal) {
            ensurePurchaseCartCurrencyDefault();
            var totalEl = document.getElementById('purchase-cart-total');
            var secEl = document.getElementById('purchase-cart-total-secondary');
            var iqd = Number(grandTotal) || 0;
            if (totalEl) totalEl.innerText = iqd > 0 || (purchaseCart && purchaseCart.length) ? purchaseFormatMoneyWithSymbol(iqd) : '0';
            if (secEl) {
                if (iqd > 0 && typeof formatDualCurrencyLines === 'function') {
                    var r = (typeof getPosFrozenFxRatePerOne === 'function') ? getPosFrozenFxRatePerOne(null) : ((typeof getUsdRatePerOne === 'function') ? getUsdRatePerOne() : 0);
                    var usd = (typeof convertCurrency === 'function') ? convertCurrency(iqd, 'IQD', 'USD', r) : 0;
                    var dual = formatDualCurrencyLines(iqd, usd, r);
                    if (dual && dual.secondary) {
                        secEl.textContent = isPurchaseUsdMode() ? dual.iqd : dual.usd;
                        secEl.style.display = '';
                    } else {
                        secEl.textContent = '';
                        secEl.style.display = 'none';
                    }
                } else {
                    secEl.textContent = '';
                    secEl.style.display = 'none';
                }
            }
        }
        function updatePurchaseCartLine(idx, field, value, rerender) {
            var row = purchaseCart[idx];
            if (!row) return;
            if (typeof rerender === 'undefined') rerender = true;
            if (field === 'costPerUnit' && row.isGift) return;
            if (field === 'discount' && row.isGift) return;
            if (field === 'qty') row.qty = normalizeQtyForProduct(row.productRef || null, value);
            if (field === 'costPerUnit') row.costPerUnit = purchaseDisplayToIqd(value);
            if (field === 'sellPerUnit') row.sellPerUnit = purchaseDisplayToIqd(value);
            if (field === 'discount') row.discount = Math.max(0, parseFloat(value) || 0);
            if (field === 'expiry_date') row.expiry_date = String(value || '').trim();
            if (field === 'expiry_visible') row.expiry_visible = !!value;
            if (rerender) {
                schedulePurchaseCartRender();
                return;
            }
            // Fast path for typing: keep focus stable, update totals only.
            var roundM3 = typeof roundMoney === 'function' ? roundMoney : function(x){ return Math.round(Number(x)); };
            var grandTotal = 0;
            purchaseCart.forEach(function(r) {
                grandTotal = roundM3(grandTotal + purchaseLineTotal(r));
            });
            var totalEl = document.getElementById('purchase-cart-total');
            if (totalEl) paintPurchaseCartGrandTotal(grandTotal);
            updatePurchaseDebtSummary(grandTotal);
            var rowTotalEl = document.querySelector('[data-purchase-row-total="' + idx + '"]');
            if (rowTotalEl) {
                rowTotalEl.textContent = purchaseFormatMoneyWithSymbol(purchaseLineTotal(row));
            }
        }

        function getPurchasePriceNudgeStepIqd() {
            if (isPurchaseUsdMode()) {
                return purchaseDisplayToIqd(0.25);
            }
            return 250;
        }
        function nudgePurchaseCartPrice(idx, field, dir) {
            var row = purchaseCart[idx];
            if (!row) return;
            if (field !== 'costPerUnit' && field !== 'sellPerUnit') return;
            if (field === 'costPerUnit' && row.isGift) return;
            var step = getPurchasePriceNudgeStepIqd();
            if (!(step > 0)) step = isPurchaseUsdMode() ? 1 : 250;
            var cur = Number(row[field]) || 0;
            var next = cur + ((dir < 0) ? -step : step);
            if (next < 0) next = 0;
            if (typeof roundMoney === 'function') next = roundMoney(next);
            row[field] = next;
            schedulePurchaseCartRender();
        }
        window.nudgePurchaseCartPrice = nudgePurchaseCartPrice;
        function renderPurchasePriceStepperHtml(idx, field, inputHtml, label, wrapClass, disabled) {
            var inner;
            if (disabled) {
                inner = inputHtml;
            } else {
                inner =
                    '<button type="button" class="purchase-price-nudge" onclick="nudgePurchaseCartPrice(' + idx + ',\'' + field + '\',-1)" title="کێم"><i class="fas fa-minus"></i></button>' +
                    inputHtml +
                    '<button type="button" class="purchase-price-nudge" onclick="nudgePurchaseCartPrice(' + idx + ',\'' + field + '\',1)" title="زێدە"><i class="fas fa-plus"></i></button>';
            }
            return '<div class="purchase-price-step-wrap ' + (wrapClass || '') + (disabled ? ' is-disabled' : '') + '" data-txn-label="' + escapeHtml(label) + '">' +
                '<div class="purchase-price-step-inner">' + inner + '</div></div>';
        }

        function removeFromPurchaseCart(idx) {
            purchaseCart.splice(idx, 1);
            schedulePurchaseCartRender();
        }

        function clearPurchaseCart() {
            purchaseCart = [];
            window._posEditingPurchase = null;
            var invNumInput = document.getElementById('purchase-supplier-invoice-number');
            var batchInput = document.getElementById('purchase-batch-number');
            if (invNumInput) invNumInput.value = '';
            if (batchInput) batchInput.value = '';
            if (typeof updatePurchaseEditModeUI === 'function') updatePurchaseEditModeUI();
            schedulePurchaseCartRender();
        }

        function updatePurchaseEditModeUI() {
            var editing = !!(window._posEditingPurchase && window._posEditingPurchase.txnId);
            var btn = document.getElementById('btn-save-purchase-invoice');
            var titleEl = document.querySelector('#view-purchase .txn-sheet-title, #view-purchase [data-i18n="view_purchase_title"], #view-purchase h2, #view-purchase .page-title');
            var editLbl = (typeof t === 'function') ? t('purchase_edit_save') : 'پاراستنا تەعدیلێ';
            var newLbl = (typeof t === 'function') ? t('purchase_save_invoice') : 'پاراستنا وەسڵێ (Save)';
            if (typeof window.resetPurchaseSaveBusy === 'function') window.resetPurchaseSaveBusy();
            if (btn) {
                btn.disabled = false;
                btn.removeAttribute('aria-busy');
                if (editing) {
                    btn.innerHTML = '<i class="fas fa-save"></i> ' + editLbl + ' #' + escapeHtml(String(window._posEditingPurchase.txnId));
                    btn.classList.add('btn-warning');
                    btn.title = editLbl;
                } else {
                    btn.innerHTML = '<i class="fas fa-save"></i> ' + newLbl;
                    btn.classList.remove('btn-warning');
                    btn.title = '';
                }
            }
            document.querySelectorAll('.cart-pay-method-toggle[data-cart-pay="purchase"]').forEach(function (el) {
                el.style.display = editing ? 'none' : '';
            });
            var banner = document.getElementById('purchase-edit-mode-banner');
            if (editing) {
                if (!banner) {
                    var view = document.getElementById('view-purchase');
                    var host = view && (view.querySelector('.txn-meta-sticky') || view.querySelector('.pos-bill-header') || view);
                    if (host) {
                        banner = document.createElement('div');
                        banner.id = 'purchase-edit-mode-banner';
                        banner.style.cssText = 'margin:8px 0;padding:10px 12px;border-radius:10px;background:rgba(245,158,11,0.15);border:1px solid rgba(245,158,11,0.45);color:#f59e0b;font-weight:800;display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;';
                        host.insertBefore(banner, host.firstChild);
                    }
                }
                if (banner) {
                    banner.innerHTML = '<span><i class="fas fa-pen-to-square" style="margin-left:8px;"></i> ' +
                        escapeHtml((typeof t === 'function') ? t('purchase_edit_mode_title') : 'تەعدیلی فاتورەی کڕین') +
                        ' <span style="opacity:.85">#' + escapeHtml(String(window._posEditingPurchase.txnId)) + '</span></span>' +
                        '<button type="button" class="btn btn-sm btn-danger" onclick="clearPosEditPurchaseMode()"><i class="fas fa-times"></i> هەڵوەشاندن</button>';
                    banner.style.display = 'flex';
                }
            } else if (banner) {
                banner.style.display = 'none';
            }
            if (titleEl && editing) {
                // keep original title; banner is enough
            }
        }
        window.updatePurchaseEditModeUI = updatePurchaseEditModeUI;

        window.clearPosEditPurchaseMode = function () {
            window._posEditingPurchase = null;
            purchaseCart = [];
            var invNumInput = document.getElementById('purchase-supplier-invoice-number');
            var batchInput = document.getElementById('purchase-batch-number');
            var paidEl = document.getElementById('purchase-supplier-paid');
            if (invNumInput) invNumInput.value = '';
            if (batchInput) batchInput.value = '';
            if (paidEl) paidEl.value = '';
            updatePurchaseEditModeUI();
            schedulePurchaseCartRender();
            if (typeof showToast === 'function') {
                showToast((typeof t === 'function') ? t('purchase_edit_cancelled') : 'تەعدیل هەڵوەشا', 'info');
            }
        };

        /**
         * Load existing purchase invoice into purchase cart (same idea as startEditSaleInPos).
         */
        window.startEditPurchaseInCart = function (txnId) {
            txnId = String(txnId || '').trim();
            if (!txnId) return;
            var canEdit = (typeof currentUser !== 'undefined' && currentUser && (currentUser.role === 'admin' || currentUser.role === 'manager'))
                || (typeof checkPermission === 'function' && checkPermission('companies_manage'));
            if (!canEdit) {
                if (typeof showToast === 'function') {
                    showToast((typeof t === 'function') ? t('purchase_edit_denied') : 'دەستکاری قەدەغەیە', 'error');
                }
                return;
            }
            var pool = [];
            if (typeof purchaseLinePool === 'function') {
                try { pool = purchaseLinePool() || []; } catch (_e) { pool = []; }
            }
            if (!pool.length) {
                pool = (window._fullPurchaseHistory || (window.db && window.db.supplies) || []);
            }
            var items = (pool || []).filter(function (s) {
                return String(s.transaction_id || '') === txnId;
            });
            if (!items.length) {
                if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('purchase_edit_not_found') : 'وەسڵ نەهاتە دیتن', 'error');
                return;
            }
            if (String(items[0].type || '').toLowerCase() === 'return') {
                if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('purchase_edit_is_return') : 'وەسڵێ زڤڕاندنێ ناکرێت تەعدیل بکرێت', 'error');
                return;
            }

            var det = document.getElementById('purchase-invoice-detail-modal');
            if (det) {
                try { det.style.display = 'none'; } catch (_e2) {}
            }
            var histModal = document.getElementById('purchase-history-company-modal');
            if (histModal) {
                try { histModal.style.display = 'none'; } catch (_eHist) {}
            }
            var pop1 = document.getElementById('purchase-options-popover');
            if (pop1) pop1.style.display = 'none';

            if (typeof closeCompanyProfile === 'function') closeCompanyProfile();
            else {
                var cpm = document.getElementById('company-profile-modal');
                if (cpm) cpm.style.display = 'none';
            }
            if (typeof closeCustomerProfile === 'function') closeCustomerProfile();
            else {
                var custpm = document.getElementById('customer-profile-modal');
                if (custpm) custpm.style.display = 'none';
            }

            if (typeof closeDailySummaryDetailSheet === 'function') closeDailySummaryDetailSheet();
            if (typeof closeDailyHistoryModal === 'function') closeDailyHistoryModal();
            else {
                var dhm = document.getElementById('daily-history-modal');
                if (dhm) dhm.style.display = 'none';
            }

            purchaseCart = [];
            items.forEach(function (it) {
                var pid = it.prodId;
                var prod = (window.db && window.db.products || []).find(function (p) { return String(p.id) === String(pid); });
                var pieces = parseFloat(it.qtyAdded) || 0;
                var total = parseFloat(it.totalCost) || 0;
                var isGift = (typeof window.isSupplyItemGift === 'function')
                    ? window.isSupplyItemGift(it)
                    : !!(it && (it.isGift === true || it.is_gift === 1 || it.is_gift === '1' || it.is_gift === true));
                var displayUnit = (typeof window.inferPurchaseDisplayUnit === 'function')
                    ? window.inferPurchaseDisplayUnit(pieces, prod)
                    : 'piece';
                var unitQty = (typeof window.purchasePiecesToUnitQty === 'function')
                    ? window.purchasePiecesToUnitQty(pieces, displayUnit, prod)
                    : pieces;
                if (!(unitQty > 0)) unitQty = pieces || 1;
                var costPerUnit = isGift ? 0 : (unitQty ? (total / unitQty) : 0);
                var exp = String(it.expiry_date || '').trim();
                purchaseCart.push({
                    productId: pid,
                    productName: it.itemName || (prod && prod.name) || '',
                    qty: unitQty,
                    unit: displayUnit || 'piece',
                    costPerUnit: costPerUnit,
                    sellPerUnit: (typeof getPurchaseSellForUnit === 'function' && prod) ? getPurchaseSellForUnit(prod, displayUnit || 'piece') : 0,
                    discount: 0,
                    isGift: isGift,
                    expiry_date: exp,
                    expiry_visible: !!exp,
                    productRef: prod || null,
                    warehouseId: parseInt(it.warehouse_id, 10) || (typeof getDefaultWarehouseId === 'function' ? getDefaultWarehouseId() : 0)
                });
            });

            var compName = items[0].company || '';
            var payType = String(items[0].type || 'cash').toLowerCase();
            var invNum = items[0].supplier_invoice_number || '';
            var batchNum = String(items[0].batch_number || '').trim();
            if (!batchNum) {
                var sib = items.find(function (s) { return String(s.batch_number || '').trim(); });
                if (sib) batchNum = String(sib.batch_number).trim();
            }
            var grandTotal = 0;
            items.forEach(function (it) {
                grandTotal += parseFloat(it.totalCost) || 0;
            });
            if (typeof roundMoney === 'function') grandTotal = roundMoney(grandTotal);

            var paidIqd = 0;
            if (payType === 'cash') {
                paidIqd = grandTotal;
            } else if (payType === 'credit') {
                paidIqd = 0;
            } else {
                // split: cash/payment part from ledger
                (window.db && window.db.ledger || []).forEach(function (l) {
                    if (String(l.transaction_id || '') !== String(txnId)) return;
                    var lt = String(l.type || '').toLowerCase();
                    if (lt === 'payment' || lt === 'pay') {
                        paidIqd += Math.abs(parseFloat(l.amount) || 0);
                    }
                });
                if (typeof roundMoney === 'function') paidIqd = roundMoney(paidIqd);
                if (paidIqd > grandTotal) paidIqd = grandTotal;
            }

            var editCompanyObj = null;
            if (compName && window.db && Array.isArray(window.db.companies)) {
                var cnEarly = String(compName).trim().toLowerCase();
                editCompanyObj = window.db.companies.find(function (x) {
                    return String(x.name || '').trim().toLowerCase() === cnEarly;
                }) || null;
            }

            window._posEditingPurchase = {
                txnId: txnId,
                type: payType,
                company: compName,
                company_id: editCompanyObj ? editCompanyObj.id : 0,
                date: items[0].date || '',
                supplier_invoice_number: invNum,
                batch_number: batchNum,
                paid_iqd: paidIqd,
                total: grandTotal,
                fx_usd_rate: items[0].fx_usd_rate != null ? items[0].fx_usd_rate : null
            };

            if (typeof nav === 'function') nav('purchase');
            if (typeof initPurchaseScreen === 'function') {
                try { initPurchaseScreen(); } catch (_e3) {}
            }

            var applyPurchaseEditMeta = function () {
                var sel = document.getElementById('purchase-supplier-select');
                var c = editCompanyObj;
                if (!c && compName && window.db && Array.isArray(window.db.companies)) {
                    var cn = String(compName).trim().toLowerCase();
                    c = window.db.companies.find(function (x) {
                        return String(x.name || '').trim().toLowerCase() === cn;
                    }) || null;
                }
                if (sel && c) {
                    sel.value = String(c.id);
                } else if (sel && compName) {
                    // keep name visible even if company row missing
                    sel.value = '';
                }
                if (typeof window.ensurePurchaseSupplierDatalist === 'function') {
                    window.ensurePurchaseSupplierDatalist();
                }
                var searchEl = document.getElementById('purchase-supplier-search');
                if (searchEl) {
                    searchEl.value = c ? (c.name || compName) : compName;
                }
                if (typeof window.syncPurchaseSupplierSearchFromSelect === 'function' && c) {
                    window.syncPurchaseSupplierSearchFromSelect();
                }

                var payTypeHid = document.getElementById('purchase-payment-type-value');
                if (payTypeHid) payTypeHid.value = payType;
                var invNumEl = document.getElementById('purchase-supplier-invoice-number');
                if (invNumEl) invNumEl.value = invNum;
                var batchEl = document.getElementById('purchase-batch-number');
                if (batchEl) batchEl.value = batchNum;

                var paidField = document.querySelector('#view-purchase .purchase-paid-field');
                if (paidField) paidField.classList.remove('is-hidden-until-supplier');
                var paidEl = document.getElementById('purchase-supplier-paid');
                if (paidEl) {
                    var displayPaid = (typeof purchasePaymentIqdToDisplay === 'function')
                        ? purchasePaymentIqdToDisplay(paidIqd)
                        : paidIqd;
                    var kind = (typeof getPurchasePaymentInputKind === 'function') ? getPurchasePaymentInputKind() : 'int';
                    if (typeof formatPaymentAmountNumber === 'function') {
                        paidEl.value = formatPaymentAmountNumber(displayPaid, kind);
                    } else {
                        paidEl.value = (kind === 'usd') ? (Number(displayPaid) || 0).toFixed(2) : String(Math.round(Number(displayPaid) || 0));
                    }
                }

                if (typeof onPurchaseSupplierChange === 'function') {
                    // Re-fill paid after supplier change (it may toggle paid field visibility)
                    var keepPaid = paidEl ? paidEl.value : '';
                    onPurchaseSupplierChange();
                    if (paidEl && keepPaid) paidEl.value = keepPaid;
                    if (paidField && (sel && sel.value || compName)) paidField.classList.remove('is-hidden-until-supplier');
                }
                if (typeof calculatePurchaseDebtRemaining === 'function') calculatePurchaseDebtRemaining();

                var purchaseSticky = document.querySelector('#view-purchase .txn-meta-sticky[data-txn-meta="purchase"]');
                if (purchaseSticky) purchaseSticky.classList.remove('is-collapsed');
                if (typeof window.updateTxnPeekBar === 'function') window.updateTxnPeekBar('purchase');

                if (typeof renderPurchaseCart === 'function') renderPurchaseCart();
                updatePurchaseEditModeUI();
            };

            setTimeout(function () {
                applyPurchaseEditMeta();
                if (typeof showToast === 'function') {
                    showToast(((typeof t === 'function') ? t('purchase_edit_loaded') : 'وەسڵ هاتە بارکرن بۆ تەعدیل') + ' #' + txnId, 'success');
                }
                // Second pass: nav/init can race and wipe search field
                setTimeout(applyPurchaseEditMeta, 120);
            }, 50);
        };

        function updatePurchaseReturnFromHistoryBanner(payload) {
            var panel = document.getElementById('purchase-returns-cart-panel');
            var existing = document.getElementById('purchase-return-history-banner');
            var titleEl = document.querySelector('#view-purchase-returns .txn-screen-head-title');
            if (!payload) {
                if (existing) existing.remove();
                if (titleEl) titleEl.textContent = (typeof t === 'function') ? (t('nav_purchase_returns') || titleEl.textContent) : titleEl.textContent;
                return;
            }
            if (titleEl) {
                titleEl.textContent = ((typeof t === 'function') ? t('nav_purchase_returns') : 'زڤڕاندنا کڕینێ') + ' #' + (payload.invoiceRef || payload.txnId || '');
            }
            if (!panel) return;
            if (!existing) {
                existing = document.createElement('div');
                existing.id = 'purchase-return-history-banner';
                existing.style.cssText = 'background:#f97316; color:white; text-align:center; padding:6px 8px; font-weight:bold; font-size:0.9rem;';
                panel.insertBefore(existing, panel.firstChild);
            }
            existing.innerHTML = '↩️ ' + escapeHtml((typeof t === 'function') ? t('purchase_return_banner') : 'وەسڵ هاتە بارکرن — ژمارە کەم بکە یان ئایتم ژێبە، پاشان پەسەندکرن') +
                ' <span style="opacity:.9">#' + escapeHtml(String(payload.invoiceRef || payload.txnId || '')) + '</span>' +
                ' <button type="button" class="btn btn-sm" style="margin-right:8px;background:rgba(255,255,255,0.2);color:#fff;border:1px solid rgba(255,255,255,0.4);padding:2px 8px;" onclick="typeof clearPurchaseReturnFromHistory===\'function\'&&clearPurchaseReturnFromHistory(true)">' +
                escapeHtml((typeof t === 'function') ? t('purchase_return_cancel') : 'هەلوەشاندن') + '</button>';
        }

        window.clearPurchaseReturnFromHistory = function (clearCart) {
            window._pendingPurchaseReturnFromHistory = null;
            var refInput = document.getElementById('purchase-return-supplier-invoice-ref');
            if (refInput) refInput.value = '';
            var sel = document.getElementById('purchase-returns-supplier-select');
            if (sel) sel.value = '';
            if (clearCart) {
                purchaseReturnCart = [];
                if (typeof renderPurchaseReturnCart === 'function') renderPurchaseReturnCart();
            }
            updatePurchaseReturnFromHistoryBanner(null);
            if (typeof renderPurchaseReturnsProductGrid === 'function') renderPurchaseReturnsProductGrid();
        };

        function applyPendingPurchaseReturnFromHistory() {
            var pending = window._pendingPurchaseReturnFromHistory;
            if (!pending || !pending.cart || !pending.cart.length) return false;
            var sel = document.getElementById('purchase-returns-supplier-select');
            if (sel && pending.company && window.db && Array.isArray(window.db.companies)) {
                var cn = String(pending.company).trim().toLowerCase();
                var c = window.db.companies.find(function (x) {
                    return String(x.name || '').trim().toLowerCase() === cn;
                }) || null;
                if (c) sel.value = String(c.id);
            }
            var refInput = document.getElementById('purchase-return-supplier-invoice-ref');
            if (refInput && pending.invoiceRef) {
                refInput.value = String(pending.invoiceRef);
                refInput.classList.remove('input-error');
            }
            purchaseReturnCart = pending.cart.map(function (row) {
                return Object.assign({}, row);
            });
            if (typeof getPurchaseReturnAvailablePieces === 'function') {
                var ctx = typeof getPurchaseReturnSupplierContext === 'function' ? getPurchaseReturnSupplierContext() : { supplierName: pending.company };
                var inv = pending.invoiceRef;
                var used = {};
                purchaseReturnCart.forEach(function (row) {
                    var pid = String(row.productId);
                    var avail = getPurchaseReturnAvailablePieces(pid, ctx.supplierName, inv);
                    var usedBefore = used[pid] || 0;
                    var left = Math.max(0, avail - usedBefore);
                    var mult = typeof getPiecesMultiplierForUnit === 'function'
                        ? getPiecesMultiplierForUnit(row.productRef || row, row.unit || 'piece')
                        : 1;
                    if (!(mult > 0)) mult = 1;
                    var maxUnit = left / mult;
                    if (row.qty > maxUnit) row.qty = maxUnit;
                    used[pid] = usedBefore + ((row.qty || 0) * mult);
                });
                purchaseReturnCart = purchaseReturnCart.filter(function (r) { return (parseFloat(r.qty) || 0) > 0.0001; });
            }
            if (purchaseReturnCart.length) {
                updatePurchaseReturnFromHistoryBanner(pending);
            } else {
                updatePurchaseReturnFromHistoryBanner(null);
            }
            if (typeof renderPurchaseReturnsProductGrid === 'function') renderPurchaseReturnsProductGrid();
            if (typeof renderPurchaseReturnCart === 'function') renderPurchaseReturnCart();
            if (typeof window.expandTxnSheet === 'function') window.expandTxnSheet('purchase-returns');
            if (typeof window.maybeCollapseTxnMetaAfterValid === 'function') {
                window.maybeCollapseTxnMetaAfterValid('purchase-returns', ['purchase-returns-supplier-select', 'purchase-return-supplier-invoice-ref']);
            }
            return purchaseReturnCart.length > 0;
        }
        window.applyPendingPurchaseReturnFromHistory = applyPendingPurchaseReturnFromHistory;

        /**
         * Load a purchase invoice into the purchase-return cart (same idea as startEditPurchaseInCart / sales return).
         */
        window.startPurchaseReturnFromHistory = function (txnId) {
            txnId = String(txnId || '').trim();
            if (!txnId) return;
            var canRet = (typeof currentUser !== 'undefined' && currentUser && (currentUser.role === 'admin' || currentUser.role === 'manager'))
                || (typeof checkPermission === 'function' && checkPermission('companies_manage'));
            if (!canRet) {
                if (typeof showToast === 'function') {
                    showToast((typeof t === 'function') ? t('purchase_return_denied') : 'زڤڕاندن قەدەغەیە', 'error');
                }
                return;
            }
            var pool = [];
            if (typeof purchaseLinePool === 'function') {
                try { pool = purchaseLinePool() || []; } catch (_e) { pool = []; }
            }
            if (!pool.length) {
                pool = (window._fullPurchaseHistory || (window.db && window.db.supplies) || []);
            }
            var items = (pool || []).filter(function (s) {
                return String(s.transaction_id || '') === txnId;
            });
            if (!items.length && Array.isArray(window._dailySummaryPurchaseLines)) {
                items = window._dailySummaryPurchaseLines.filter(function (s) {
                    return String(s.transaction_id || '') === txnId;
                });
            }
            if (!items.length) {
                if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('purchase_edit_not_found') : 'وەسڵ نەهاتە دیتن', 'error');
                return;
            }
            if (String(items[0].type || '').toLowerCase() === 'return') {
                if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('purchase_return_is_return') : 'ئەڤە وەسڵێ زڤڕاندنێ یە', 'error');
                return;
            }
            var purchaseLines = items.filter(function (it) {
                var ty = String(it.type || '').toLowerCase();
                return ty !== 'return' && (parseFloat(it.qtyAdded) || 0) > 0;
            });
            if (!purchaseLines.length) {
                if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('purchase_return_no_items') : 'ئایتم نەما بۆ زڤڕاندن', 'error');
                return;
            }
            var cartRows = [];
            purchaseLines.forEach(function (it) {
                var pid = it.prodId;
                var prod = (window.db && window.db.products || []).find(function (p) { return String(p.id) === String(pid); });
                var pieces = parseFloat(it.qtyAdded) || 0;
                var total = parseFloat(it.totalCost) || 0;
                var isGift = (typeof window.isSupplyItemGift === 'function')
                    ? window.isSupplyItemGift(it)
                    : !!(it && (it.isGift === true || it.is_gift === 1 || it.is_gift === '1' || it.is_gift === true));
                var displayUnit = (typeof window.inferPurchaseDisplayUnit === 'function')
                    ? window.inferPurchaseDisplayUnit(pieces, prod)
                    : 'piece';
                var unitQty = (typeof window.purchasePiecesToUnitQty === 'function')
                    ? window.purchasePiecesToUnitQty(pieces, displayUnit, prod)
                    : pieces;
                if (!(unitQty > 0)) unitQty = pieces || 1;
                var costPerUnit = isGift ? 0 : (unitQty ? (total / unitQty) : 0);
                cartRows.push({
                    productId: pid,
                    productName: it.itemName || (prod && prod.name) || '',
                    qty: unitQty,
                    unit: displayUnit || 'piece',
                    costPerUnit: costPerUnit,
                    discount: 0,
                    productRef: prod || null
                });
            });
            var compName = items[0].company || '';
            var invNum = String(items[0].supplier_invoice_number || '').trim();
            if (!invNum) {
                var sib = items.find(function (s) { return String(s.supplier_invoice_number || '').trim(); });
                if (sib) invNum = String(sib.supplier_invoice_number).trim();
            }
            window._pendingPurchaseReturnFromHistory = {
                txnId: txnId,
                company: compName,
                invoiceRef: invNum || txnId,
                cart: cartRows,
                fx_usd_rate: items[0].fx_usd_rate != null ? items[0].fx_usd_rate : null
            };

            var det = document.getElementById('purchase-invoice-detail-modal');
            if (det) {
                try { det.style.display = 'none'; } catch (_e2) {}
            }
            var histModal = document.getElementById('purchase-history-company-modal');
            if (histModal) {
                try { histModal.style.display = 'none'; } catch (_eHist) {}
            }
            var pop1 = document.getElementById('purchase-options-popover');
            if (pop1) pop1.style.display = 'none';
            var pop2 = document.getElementById('purchase-returns-options-popover');
            if (pop2) pop2.style.display = 'none';
            if (typeof closeCompanyProfile === 'function') closeCompanyProfile();
            else {
                var cpm = document.getElementById('company-profile-modal');
                if (cpm) cpm.style.display = 'none';
            }
            if (typeof closeDailySummaryDetailSheet === 'function') closeDailySummaryDetailSheet();
            if (typeof closeDailyHistoryModal === 'function') closeDailyHistoryModal();
            else {
                var dhm = document.getElementById('daily-history-modal');
                if (dhm) dhm.style.display = 'none';
            }

            if (typeof nav === 'function') nav('purchase-returns');
            var applyOnce = function () {
                var ok = applyPendingPurchaseReturnFromHistory();
                if (ok && typeof showToast === 'function' && !window._purchaseReturnFromHistoryToasted) {
                    window._purchaseReturnFromHistoryToasted = true;
                    showToast(((typeof t === 'function') ? t('purchase_return_loaded') : 'وەسڵ هاتە بارکرن بۆ زڤڕاندن') + ' #' + (invNum || txnId), 'success');
                    setTimeout(function () { window._purchaseReturnFromHistoryToasted = false; }, 1500);
                }
            };
            setTimeout(applyOnce, 50);
            setTimeout(applyOnce, 180);
        };

        function renderPurchaseCart() {
            var tbody = document.getElementById('purchase-cart-rows');
            var totalEl = document.getElementById('purchase-cart-total');
            if (!tbody) return;
            var grandTotal = 0;
            var roundM3 = typeof roundMoney === 'function' ? roundMoney : function(x){ return Math.round(Number(x)); };
            let activeFocusId = null;
            let activeFocusStart = null;
            let activeFocusEnd = null;
            if (document.activeElement && document.activeElement.classList.contains('pur-cart-input')) {
                activeFocusId = document.activeElement.id;
                try { activeFocusStart = document.activeElement.selectionStart; activeFocusEnd = document.activeElement.selectionEnd; } catch(e) {}
            }
        var unitIconFor = function(u) {
            return (typeof window.getPosUnitIconHtml === 'function') ? window.getPosUnitIconHtml(u, true) : '';
        };
        
        if (purchaseCart.length === 0) {
            tbody.innerHTML = '<div class="returns-empty-state" style="padding:40px 10px;"><i class="fas fa-shopping-basket"></i><span>سەبەتە یا ڤالایە</span></div>';
            paintPurchaseCartGrandTotal(0);
            updatePurchaseDebtSummary(0);
            updatePurchaseGiftSummaryUi();
            if (typeof window.updateTxnPeekBar === 'function') window.updateTxnPeekBar('purchase');
            return;
        }
        tbody.innerHTML = '';
            purchaseCart.forEach(function(row, idx) {
                var lineTotal = purchaseLineTotal(row);
                grandTotal = roundM3(grandTotal + lineTotal);
            var unitIcon = unitIconFor(row.unit || 'piece');
            var unitLabel = (typeof getProductUnitLabel === 'function') ? getProductUnitLabel(row.productRef || row, row.unit || 'piece') : (row.unit || 'piece');
            var isGiftRow = !!row.isGift;
            var giftBadge = isGiftRow
                ? ' <span class="purchase-gift-badge" title="هدیە / فری بێ بەرامبەر">(هدیە × ' + escapeHtml((typeof formatQtyForInput === 'function' ? formatQtyForInput(row.qty || 0, row.productRef || row) : String(row.qty || 0))) + ')</span>'
                : '';
            var isWeightQty = isWeightProduct(row.productRef || null);
            var qtyStep = '0.001';
            var qtyDelta = isWeightQty ? 0.25 : 1;
            var kiloQtyChips = renderKiloQtyPresetChips(row.productRef || row, function(v) {
                return "updatePurchaseCartLine(" + idx + ",'qty'," + v + ",true)";
            });
            var expOn = !!row.expiry_visible;
            if (typeof ensurePurchaseRowWarehouseId === 'function') ensurePurchaseRowWarehouseId(row);
            var whSelectHtml = (typeof buildPurchaseCartWarehouseSelectHtml === 'function') ? buildPurchaseCartWarehouseSelectHtml(idx, row) : '';
            var sellIqd = row.sellPerUnit != null ? row.sellPerUnit : getPurchaseSellForUnit(row.productRef || null, row.unit || 'piece');
            if (row.sellPerUnit == null) row.sellPerUnit = sellIqd;
            var div = document.createElement('div');
            div.className = 'returns-cart-row returns-cart-row-slim purchase-cart-row' + (whSelectHtml ? ' purchase-cart-row--has-wh' : '') + (isGiftRow ? ' purchase-cart-row--gift' : '');
            var costDisplay = isGiftRow ? '0' : formatPurchaseCartPriceDisplay(row.costPerUnit || 0);
            var giftBtn = '<button type="button" class="purchase-gift-toggle' + (isGiftRow ? ' is-active' : '') + '" onclick="togglePurchaseCartGift(' + idx + ')" title="' + (isGiftRow ? 'لابردنا ١ دیاری' : 'کرنە دیاری (١ دانە)') + '"><i class="fas fa-gift"></i></button>';
            var costInputHtml = '<input type="text" inputmode="decimal" dir="ltr" id="pur_cart_' + idx + '_cost" class="pur-cart-input returns-row-price returns-row-cost"' + (isGiftRow ? ' disabled' : '') + ' value="' + costDisplay + '" onkeydown="if(event.key===\'Enter\') this.blur();" oninput="onPurchaseCartPriceInput(this,false)" onchange="onPurchaseCartPriceInput(this,true)" onfocus="this.select()" title="' + (isGiftRow ? 'فری — بێ بەرامبەر' : (isPurchaseUsdMode() ? '$ کڕین (USD)' : 'نرخێ کڕینێ')) + '">';
            var sellInputHtml = '<input type="text" inputmode="decimal" dir="ltr" id="pur_cart_' + idx + '_sell" class="pur-cart-input returns-row-price returns-row-sell" value="' + formatPurchaseCartPriceDisplay(sellIqd) + '" onkeydown="if(event.key===\'Enter\') this.blur();" oninput="onPurchaseCartPriceInput(this,false)" onchange="onPurchaseCartPriceInput(this,true)" onfocus="this.select()" title="' + (isPurchaseUsdMode() ? '$ فرۆشتن (USD)' : 'نرخێ فرۆشتنێ') + '">';
            div.innerHTML =
                '<label class="purchase-expiry-chk-wrap" title="بەسەرچوون — تیک = بەروار، بێ تیک = ئایتم بێ بەسەرچوون">' +
                    '<input type="checkbox" class="purchase-expiry-chk" aria-label="بەسەرچوون"' + (expOn ? ' checked' : '') + ' onchange="setPurchaseRowExpiryEnabled(' + idx + ', this.checked)">' +
                '</label>' +
                '<span class="returns-row-name purchase-row-name purchase-row-name-block" title="' + escapeHtml(row.productName || 'ئایتم') + '">' +
                    '<span class="purchase-row-name-text">' + unitIcon + escapeHtml(row.productName || 'ئایتم') + giftBadge + ' <small style="color:var(--text-muted); font-weight:600;">(' + escapeHtml(unitLabel) + ')</small></span>' +
                    whSelectHtml +
                '</span>' +
                '<div class="purchase-expiry-wrap' + (expOn ? ' is-open' : '') + '">' +
                    '<input type="text" placeholder="YYYY-MM-DD" dir="ltr" id="pur_cart_' + idx + '_exp" class="pur-cart-input purchase-expiry-input" value="' + escapeHtml(String(row.expiry_date || '')) + '" onchange="updatePurchaseCartLine(' + idx + ',\'expiry_date\',this.value,true)" oninput="this.value=formatAutoDate(this.value); updatePurchaseCartLine(' + idx + ',\'expiry_date\',this.value,false)" onkeydown="if(event.key===\'Enter\') this.blur();" title="تاریخا بەسەرچوونێ">' +
                '</div>' +
                    '<input type="number" id="pur_cart_' + idx + '_disc" class="pur-cart-input returns-row-disc"' + (isGiftRow ? ' disabled' : '') + ' min="0" step="0.01" value="' + (isGiftRow ? 0 : (row.discount || 0)) + '" onkeydown="if(event.key===\'Enter\') this.blur();" onchange="updatePurchaseCartLine(' + idx + ',\'discount\',this.value,true)" oninput="updatePurchaseCartLine(' + idx + ',\'discount\',this.value,false)" onfocus="this.select()" title="داشکاندن">' +
                    renderPurchasePriceStepperHtml(idx, 'costPerUnit', costInputHtml, 'کڕین', 'purchase-cost-step-wrap', isGiftRow) +
                    renderPurchasePriceStepperHtml(idx, 'sellPerUnit', sellInputHtml, 'فرۆشتن', 'purchase-sell-step-wrap', false) +
                '<div class="returns-row-qty-wrap">' +
                    '<button type="button" onclick="updatePurchaseCartLine(' + idx + ',\'qty\',' + ((row.qty || 0) - qtyDelta) + ')"><i class="fas fa-minus"></i></button>' +
                        '<input type="number" id="pur_cart_' + idx + '_qty" class="pur-cart-input" min="0" step="' + qtyStep + '" inputmode="decimal" readonly value="' + formatQtyForInput((row.qty || 0), row.productRef || row) + '" onclick="openPurchaseCartQtyPrompt(' + idx + ',' + (row.qty || 0) + '); return false;" onkeydown="if(event.key===\'Enter\') this.blur();" onchange="updatePurchaseCartLine(' + idx + ',\'qty\',this.value,true)" oninput="updatePurchaseCartLine(' + idx + ',\'qty\',this.value,false)" onfocus="this.select()">' +
                    '<button type="button" onclick="updatePurchaseCartLine(' + idx + ',\'qty\',' + ((row.qty || 0) + qtyDelta) + ')"><i class="fas fa-plus"></i></button>' +
                    kiloQtyChips +
                '</div>' +
                '<span class="returns-row-total" data-purchase-row-total="' + idx + '">' + (isGiftRow ? '<span style="color:#ec4899; font-weight:800;">فری</span>' : purchaseFormatMoneyWithSymbol(lineTotal)) + '</span>' +
                giftBtn +
                '<button type="button" class="returns-row-del" onclick="removeFromPurchaseCart(' + idx + ')" title="سڕینەوە"><i class="fas fa-times"></i></button>';
            tbody.appendChild(div);
            stampTxnMobileCartLabels(div);
            });
            paintPurchaseCartGrandTotal(grandTotal);
            updatePurchaseDebtSummary(grandTotal);
            updatePurchaseGiftSummaryUi();
            if (activeFocusId) {
                setTimeout(() => {
                    const el = document.getElementById(activeFocusId);
                    if (el) { el.focus(); try { el.setSelectionRange(activeFocusStart, activeFocusEnd); } catch(e){} }
                }, 10);
            }
            if (typeof window.updateTxnPeekBar === 'function') window.updateTxnPeekBar('purchase');
            if (!(typeof isPosTxnLiteMode === 'function' && isPosTxnLiteMode()) && typeof window.bounceTxnSheet === 'function' && purchaseCart.length) window.bounceTxnSheet('purchase');
        }
        function getSupplierPreviousDebt() {
            var sel = document.getElementById('purchase-supplier-select');
            var supplierId = sel && sel.value ? parseInt(sel.value, 10) : null;
            var comp = supplierId && db && db.companies ? (db.companies.find(function(c) { return c.id === supplierId; })) : null;
            return comp ? (parseFloat(comp.balance) || 0) : 0;
        }
        function updatePurchaseDebtSummary(currentInvoiceTotal) {
            var prevEl = document.getElementById('purchase-previous-debt');
            var invEl = document.getElementById('purchase-invoice-total');
            var cashEl = document.getElementById('purchase-cash-paid');
            var debtAddEl = document.getElementById('purchase-debt-added');
            var debtAddRow = document.getElementById('purchase-debt-added-row');
            var balEl = document.getElementById('purchase-new-balance');
            var paidInput = document.getElementById('purchase-supplier-paid');
            var summaryEl = document.getElementById('purchase-debt-summary');
            var sel = document.getElementById('purchase-supplier-select');
            var hasSupplier = !!(sel && sel.value);
            if (summaryEl) summaryEl.classList.toggle('is-hidden', !hasSupplier);
            var roundM = typeof roundMoney === 'function' ? roundMoney : function(x){ return Math.round(Number(x)); };
            var prevDebt = hasSupplier ? getSupplierPreviousDebt() : 0;
            var invTotal = typeof currentInvoiceTotal === 'number' ? currentInvoiceTotal : 0;
            var paidIqd = parsePurchaseSupplierPaidToIqd(paidInput ? paidInput.value : '0');
            if (paidIqd < 0) paidIqd = 0;
            var debtFromInvoice = roundM(Math.max(0, invTotal - paidIqd));
            var newBalance = roundM(prevDebt + debtFromInvoice);
            var fmt = purchaseFormatMoneyWithSymbol;
            var compBalFx = (hasSupplier && sel && sel.value && typeof fxUsdRateFormatOptsForEntityBalance === 'function')
                ? fxUsdRateFormatOptsForEntityBalance(sel.value, 'company', prevDebt)
                : undefined;
            if (prevEl) prevEl.textContent = isPurchaseUsdMode() ? ('$' + formatCurrency(prevDebt, compBalFx)) : fmt(prevDebt);
            if (invEl) invEl.textContent = fmt(invTotal);
            if (cashEl) cashEl.textContent = fmt(paidIqd);
            if (debtAddEl) debtAddEl.textContent = fmt(debtFromInvoice);
            if (debtAddRow) debtAddRow.style.display = debtFromInvoice > 0 ? '' : 'none';
            if (balEl) {
                if (isPurchaseUsdMode() && typeof storedIqdToUsdDisplayAmount === 'function') {
                    var prevUsd = storedIqdToUsdDisplayAmount(prevDebt, compBalFx);
                    var curPurFx = { fxUsdRate: getPurchaseCartFxBundle() };
                    var debtUsd = storedIqdToUsdDisplayAmount(debtFromInvoice, curPurFx);
                    var newBalUsd = Math.round((prevUsd + debtUsd) * 100) / 100;
                    balEl.textContent = '$' + formatCurrency(0, { directUsd: newBalUsd });
                } else {
                    balEl.textContent = fmt(newBalance);
                }
                var compactBal = document.getElementById('purchase-new-balance-compact');
                if (compactBal) compactBal.textContent = balEl.textContent;
            }
            if (typeof togglePaymentDueRow === 'function') {
                togglePaymentDueRow('purchase', hasSupplier && (debtFromInvoice > 0 || paidIqd > 0 || prevDebt > 0));
            }
        }

        window.togglePurchaseDebtDetails = function(forceOpen) {
            var body = document.getElementById('purchase-debt-expanded-rows');
            var btn = document.getElementById('btn-toggle-purchase-debt');
            if (!body) return;
            var isCollapsed = body.classList.contains('is-collapsed');
            var shouldOpen = typeof forceOpen === 'boolean' ? forceOpen : isCollapsed;
            body.classList.toggle('is-collapsed', !shouldOpen);
            if (btn) {
                btn.setAttribute('aria-expanded', shouldOpen ? 'true' : 'false');
                var icon = btn.querySelector('.txn-details-chevron');
                if (icon) {
                    icon.className = shouldOpen ? 'fas fa-chevron-up txn-details-chevron' : 'fas fa-chevron-down txn-details-chevron';
                }
            }
        };

        window.calculatePurchaseDebtRemaining = function() {
            var total = getPurchaseCartSubtotal();
            updatePurchaseDebtSummary(total);
        };

        function handlePurchaseBarcode(event) {
            if (event.key !== 'Enter') return;
            if (typeof isWorkspaceViewActive === 'function' && !isWorkspaceViewActive('purchase')) return;
            var input = document.getElementById('purchase-search');
            var val = (input && input.value) ? input.value.trim() : '';
            if (!val) return;
            if (typeof window.sanitizeScannerBarcodeInput === 'function') {
                val = window.sanitizeScannerBarcodeInput(val);
            }
            if (!val) return;
            event.preventDefault();

            function applyPurchaseResolved(resolved) {
                if (resolved && resolved.ambiguous) {
                    if (typeof showToast === 'function') showToast('پتر ژ ئێک ئایتم هاتە دیتن! ئێکێ هەلبژێرە.', 'info');
                    return;
                }
                if (resolved && resolved.p) {
                    var unit = resolved.unit;
                    if (typeof productMatchesUnitFilter === 'function' && !productMatchesUnitFilter(resolved.p, unit, true)) {
                        if (typeof showToast === 'function') showToast('ئەم یەکەیە بۆ ئەم ئایتمە پێناسە نەکراوە.', 'warning');
                        return;
                    }
                    addToPurchaseCart(resolved.p.id, unit);
                    if (input) input.value = '';
                    if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('purchase', { clear: false, delay: 0 });
                    return;
                }
                var looksLikeBarcode = /^\d{4,}$/.test(val) || (val.length >= 3 && !/\s/.test(val));
                if (typeof promptPurchaseDefineMissingItem === 'function') {
                    promptPurchaseDefineMissingItem(looksLikeBarcode ? val : '');
                    if (input) input.value = '';
                    return;
                }
                if (looksLikeBarcode && typeof window.openQuickDefineModal === 'function') {
                    if (!hasPermission('products_manage')) {
                        if (typeof showToast === 'function') showToast('⚠️ ئایتم نەهاتە دیتن! (تۆ دەستوورا زێدەکرنێ نینە)', 'error');
                    } else {
                        window.openQuickDefineModal(val);
                    }
                    if (input) input.value = '';
                    return;
                }
                if (typeof showToast === 'function') {
                    showToast((typeof t === 'function') ? t('purchase_define_yourself') : 'ئایتم نەهاتە داخلکرن — خۆت چێکە، زێدەکە، داخلکە', 'warning');
                }
            }

            var activeUnit = typeof purchaseSelectedUnit !== 'undefined' ? purchaseSelectedUnit : 'piece';
            var resolved = typeof window.resolveBarcodeForTxnAdd === 'function'
                ? window.resolveBarcodeForTxnAdd(val, activeUnit, { isPurchase: true })
                : null;
            if (resolved && (resolved.p || resolved.ambiguous)) {
                applyPurchaseResolved(resolved);
                return;
            }
            if (typeof posBarcodeNeedsServerLookup === 'function' && posBarcodeNeedsServerLookup(val)
                && typeof posEnsureProductByBarcode === 'function') {
                posEnsureProductByBarcode(val).then(function () {
                    var resolved2 = typeof window.resolveBarcodeForTxnAdd === 'function'
                        ? window.resolveBarcodeForTxnAdd(val, activeUnit, { isPurchase: true })
                        : null;
                    applyPurchaseResolved(resolved2);
                });
                return;
            }
            applyPurchaseResolved(resolved);
        }

        window.addToPurchaseCart = addToPurchaseCart;
        window.renderPurchaseProductGrid = renderPurchaseProductGrid;
        window.renderPurchaseCart = renderPurchaseCart;
        window.getPurchaseCostForUnit = getPurchaseCostForUnit;
        window.refreshPurchaseJewelryCostsFromRates = refreshPurchaseJewelryCostsFromRates;
        window.promptPurchaseDefineMissingItem = promptPurchaseDefineMissingItem;
