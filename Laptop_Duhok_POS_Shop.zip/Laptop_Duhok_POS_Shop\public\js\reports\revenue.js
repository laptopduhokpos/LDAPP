// POS reports - revenue comparison & detailed A4
        // --- REVENUE COMPARISON DASHBOARD (Multi-Series A,B,C,D,E,F) ---
        var REV_COMP_PERIOD_LETTERS = ['A', 'B', 'C', 'D', 'E', 'F'];
        var REV_COMP_COLORS = ['#3b82f6', '#f97316', '#10b981', '#8b5cf6', '#ec4899', '#06b6d4'];
        var revCompChart = null;
        function revCompPeriodLabel(idxOrLetter) {
            var letter = (typeof idxOrLetter === 'number')
                ? (REV_COMP_PERIOD_LETTERS[idxOrLetter] || ('P' + (idxOrLetter + 1)))
                : String(idxOrLetter || '');
            var raw = (typeof t === 'function') ? t('rev_comp_period_label') : 'Period {letter}';
            return raw.split('{letter}').join(letter);
        }
        function revCompRemoveButtonTitle() {
            return (typeof t === 'function') ? t('btn_delete') : 'حذف';
        }
        function revCompMsg(key, fallback) {
            if (typeof t !== 'function') return fallback;
            var v = t(key);
            return (v && v !== key) ? v : fallback;
        }
        function _drT(key, fallback) {
            return revCompMsg(key, fallback);
        }
        function revCompGetPeriods() {
            var wrap = document.getElementById('rev-comp-periods-wrap');
            if (!wrap) return [];
            var out = [];
            wrap.querySelectorAll('.rev-comp-period-row').forEach(function(row) {
                var idx = row.getAttribute('data-idx');
                var startEl = document.getElementById('rev-comp-start-' + idx);
                var endEl = document.getElementById('rev-comp-end-' + idx);
                if (startEl && endEl && startEl.value && endEl.value) out.push({ start: startEl.value, end: endEl.value });
            });
            return out;
        }
        function revCompSetPeriods(ranges) {
            var wrap = document.getElementById('rev-comp-periods-wrap');
            if (!wrap) return;
            wrap.innerHTML = '';
            ranges.forEach(function(r, i) {
                revCompAppendPeriodRow(i, r.start, r.end);
            });
            revCompUpdateAddButton();
        }
        function revCompAppendPeriodRow(idx, startVal, endVal) {
            var wrap = document.getElementById('rev-comp-periods-wrap');
            if (!wrap) return;
            var row = document.createElement('div');
            row.className = 'rev-comp-period-row';
            row.setAttribute('data-idx', idx);
            var rmTitle = revCompRemoveButtonTitle().replace(/"/g, '&quot;');
            var removeBtn = idx >= 2 ? '<button type="button" class="rev-comp-remove" onclick="revCompRemovePeriod(' + idx + ')" title="' + rmTitle + '">×</button>' : '';
            row.innerHTML = '<label>' + revCompPeriodLabel(idx) + '</label><input type="date" id="rev-comp-start-' + idx + '" class="input-std rev-comp-date" value="' + (startVal || '') + '"><input type="date" id="rev-comp-end-' + idx + '" class="input-std rev-comp-date" value="' + (endVal || '') + '">' + removeBtn;
            wrap.appendChild(row);
            revCompUpdateAddButton();
        }
        function revCompAddPeriod() {
            var wrap = document.getElementById('rev-comp-periods-wrap');
            if (!wrap || wrap.querySelectorAll('.rev-comp-period-row').length >= 6) return;
            var idx = wrap.querySelectorAll('.rev-comp-period-row').length;
            revCompAppendPeriodRow(idx, '', '');
        }
        function revCompRemovePeriod(idx) {
            var wrap = document.getElementById('rev-comp-periods-wrap');
            if (!wrap) return;
            var rows = wrap.querySelectorAll('.rev-comp-period-row');
            if (rows.length <= 2) return;
            var row = wrap.querySelector('.rev-comp-period-row[data-idx="' + idx + '"]');
            if (row) row.remove();
            var i = 0;
            wrap.querySelectorAll('.rev-comp-period-row').forEach(function(r) {
                r.setAttribute('data-idx', i);
                var startEl = r.querySelector('input[type="date"]');
                var endEl = r.querySelectorAll('input[type="date"]')[1];
                if (startEl) startEl.id = 'rev-comp-start-' + i;
                if (endEl) endEl.id = 'rev-comp-end-' + i;
                var lbl = r.querySelector('label');
                if (lbl) lbl.textContent = revCompPeriodLabel(i);
                var btn = r.querySelector('.rev-comp-remove');
                if (btn) btn.setAttribute('onclick', 'revCompRemovePeriod(' + i + ')');
                i++;
            });
            revCompUpdateAddButton();
        }
        function revCompUpdateAddButton() {
            var wrap = document.getElementById('rev-comp-periods-wrap');
            var btn = document.getElementById('rev-comp-add-period-btn');
            if (btn && wrap) btn.style.display = wrap.querySelectorAll('.rev-comp-period-row').length >= 6 ? 'none' : 'inline-flex';
        }
        function revCompRefreshStaticLabels() {
            var wrap = document.getElementById('rev-comp-periods-wrap');
            if (!wrap) return;
            var i = 0;
            wrap.querySelectorAll('.rev-comp-period-row').forEach(function(r) {
                var lbl = r.querySelector('label');
                if (lbl) lbl.textContent = revCompPeriodLabel(i);
                var b = r.querySelector('.rev-comp-remove');
                if (b) b.setAttribute('title', revCompRemoveButtonTitle());
                i++;
            });
        }
        function renderRevCompPeriodRowsInitial() {
            var wrap = document.getElementById('rev-comp-periods-wrap');
            if (!wrap || wrap.querySelectorAll('.rev-comp-period-row').length > 0) return;
            var today = new Date();
            var y = today.getFullYear(), m = today.getMonth();
            function toYMD(d) { return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
            var lastStart = new Date(y, m - 1, 1);
            var lastEnd = new Date(y, m, 0);
            var thisStart = new Date(y, m, 1);
            var thisEnd = new Date(y, m + 1, 0);
            revCompSetPeriods([{ start: toYMD(lastStart), end: toYMD(lastEnd) }, { start: toYMD(thisStart), end: toYMD(thisEnd) }]);
        }
        function applyRevenuePreset(preset) {
            var today = new Date();
            var y = today.getFullYear(), m = today.getMonth(), d = today.getDate();
            function toYMD(dt) { return dt.getFullYear() + '-' + String(dt.getMonth() + 1).padStart(2, '0') + '-' + String(dt.getDate()).padStart(2, '0'); }
            var ranges = [];
            if (preset === 'month_vs_month') {
                ranges = [
                    { start: toYMD(new Date(y, m - 1, 1)), end: toYMD(new Date(y, m, 0)) },
                    { start: toYMD(new Date(y, m, 1)), end: toYMD(new Date(y, m + 1, 0)) }
                ];
            } else if (preset === 'year_vs_year') {
                ranges = [
                    { start: (y - 1) + '-01-01', end: (y - 1) + '-12-31' },
                    { start: y + '-01-01', end: toYMD(today) }
                ];
            } else if (preset === '10d_vs_10d') {
                var endB = new Date(today);
                var startB = new Date(today); startB.setDate(startB.getDate() - 9);
                var endA = new Date(today); endA.setDate(endA.getDate() - 10);
                var startA = new Date(today); startA.setDate(startA.getDate() - 19);
                ranges = [{ start: toYMD(startA), end: toYMD(endA) }, { start: toYMD(startB), end: toYMD(endB) }];
            } else if (preset === 'last_4_weeks') {
                for (var w = 3; w >= 0; w--) {
                    var endW = new Date(today); endW.setDate(endW.getDate() - w * 7);
                    var startW = new Date(endW); startW.setDate(startW.getDate() - 6);
                    ranges.push({ start: toYMD(startW), end: toYMD(endW) });
                }
            } else if (preset === 'last_5_years') {
                for (var yr = 4; yr >= 0; yr--) {
                    ranges.push({ start: (y - yr) + '-01-01', end: (y - yr) + '-12-31' });
                }
            } else if (preset === 'last_4_blocks_10d') {
                for (var b = 3; b >= 0; b--) {
                    var endB = new Date(today); endB.setDate(endB.getDate() - b * 10);
                    var startB = new Date(endB); startB.setDate(startB.getDate() - 9);
                    ranges.push({ start: toYMD(startB), end: toYMD(endB) });
                }
            } else if (preset === '5y_vs_5y') {
                ranges = [
                    { start: (y - 10) + '-01-01', end: (y - 6) + '-12-31' },
                    { start: (y - 5) + '-01-01', end: (y - 1) + '-12-31' }
                ];
            }
            if (ranges.length) revCompSetPeriods(ranges);
            loadRevenueComparison(preset);
        }
        function loadRevenueComparison(presetOrOpts, silentArg) {
            var silent = false;
            var presetForBlock = null;
            if (presetOrOpts && typeof presetOrOpts === 'object' && !Array.isArray(presetOrOpts)) {
                silent = !!presetOrOpts.silent;
                presetForBlock = presetOrOpts.preset || null;
            } else {
                presetForBlock = presetOrOpts;
                silent = !!silentArg;
            }
            var periods = revCompGetPeriods();
            if (periods.length < 1) { renderRevCompPeriodRowsInitial(); periods = revCompGetPeriods(); }
            if (periods.length < 1) return;
            var granularity = 'day';
            var blockDays = 0;
            if (presetForBlock === 'last_4_blocks_10d') blockDays = 10;
            var maxDays = 0;
            periods.forEach(function(p) {
                var days = (new Date(p.end) - new Date(p.start)) / (24 * 60 * 60 * 1000) + 1;
                if (days > maxDays) maxDays = days;
            });
            if (maxDays > 400) granularity = 'month';
            var url = '?action=get_revenue_comparison&granularity=' + encodeURIComponent(granularity);
            if (blockDays) url += '&block_days=' + blockDays;
            periods.forEach(function(p, i) {
                url += '&period' + i + '_start=' + encodeURIComponent(p.start) + '&period' + i + '_end=' + encodeURIComponent(p.end);
            });
            fetch(url, { credentials: 'same-origin' })
                .then(function(r) {
                    return r.text().then(function(text) {
                        try { return JSON.parse(text); }
                        catch (e) { throw new Error('invalid_json'); }
                    });
                })
                .then(function(data) {
                    if (!data || data.status !== 'ok') {
                        var msg = (data && data.message) || revCompMsg('rev_comp_load_error', 'هەڵە د وەرگرتنا داتایێ دا');
                        if (!silent && typeof showToast === 'function') showToast(msg, true);
                        else revCompShowInlineHint(msg);
                        return;
                    }
                    var labels = data.labels || [];
                    var totals = data.totals || [];
                    var datasets = [];
                    for (var i = 0; i < totals.length; i++) {
                        var arr = data['data' + i];
                        if (!arr) continue;
                        var color = REV_COMP_COLORS[i % REV_COMP_COLORS.length];
                        var h = color.replace('#', '');
                        var r = parseInt(h.substr(0, 2), 16), g = parseInt(h.substr(2, 2), 16), b = parseInt(h.substr(4, 2), 16);
                        var bg = 'rgba(' + r + ',' + g + ',' + b + ',0.12)';
                        datasets.push({
                            label: revCompPeriodLabel(i),
                            data: arr,
                            borderColor: color,
                            backgroundColor: bg,
                            borderWidth: 2,
                            fill: true,
                            tension: 0.3,
                            pointRadius: labels.length > 60 ? 0 : 3,
                            pointHoverRadius: 6
                        });
                    }
                    var summaryEl = document.getElementById('rev-comp-summary-cards');
                    if (summaryEl) {
                        summaryEl.innerHTML = totals.map(function(total, i) {
                            var prev = i > 0 ? totals[i - 1] : 0;
                            var pct = prev > 0 ? (((total - prev) / prev) * 100) : (total > 0 ? 100 : 0);
                            var pctStr = i === 0 ? '—' : (pct >= 0 ? '+' : '') + pct.toFixed(1) + '%';
                            var color = REV_COMP_COLORS[i % REV_COMP_COLORS.length];
                            return '<div class="rev-comp-summary-card" style="border-right:4px solid ' + color + '"><h4>' + revCompPeriodLabel(i) + '</h4><div class="rev-comp-total" style="color:' + color + '">' + formatCurrency(total) + ' ' + getCurrencySymbol() + '</div><div class="rev-comp-pct" style="color:' + (pct >= 0 ? 'var(--success)' : 'var(--danger)') + '">' + pctStr + '</div></div>';
                        }).join('');
                    }
                    var canvas = document.getElementById('rev-comp-chart');
                    if (!canvas) return;
                    if (typeof Chart === 'undefined') {
                        var noChartMsg = revCompMsg('rev_comp_chart_unavailable', 'چارت بەردەست نییە — دوگمەی هەڤبەرکرن دووبارە تاقی بکە');
                        if (!silent && typeof showToast === 'function') showToast(noChartMsg, true);
                        else revCompShowInlineHint(noChartMsg);
                        return;
                    }
                    try {
                    if (revCompChart) revCompChart.destroy();
                    var displayLabels = labels.length > 31 && labels[0] !== 'Day 1' ? labels.map(function(_, i) { return (i + 1); }) : labels;
                    var xAxisTitle;
                    if (labels[0] === 'Day 1') {
                        xAxisTitle = revCompMsg('rev_comp_axis_day_range', 'Day {from} – Day {to}')
                            .split('{from}').join('1').split('{to}').join(String(labels.length));
                    } else {
                        xAxisTitle = revCompMsg('rev_comp_x_axis_time', 'ڕۆژ / مانگ');
                    }
                    var yAxisTitle = revCompMsg('rev_comp_y_axis_revenue', 'کۆی داهات');
                    var _revChartAnim = (typeof window !== 'undefined' && window.POS_CHART_ANIMATIONS === false);
                    revCompChart = new Chart(canvas, {
                        type: 'line',
                        data: { labels: displayLabels, datasets: datasets },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            animation: _revChartAnim ? false : undefined,
                            interaction: { intersect: false, mode: 'index' },
                            onClick: function(ev, items) {},
                            plugins: {
                                legend: {
                                    position: 'top',
                                    onClick: function(e, legendItem, legend) {
                                        var idx = legendItem.datasetIndex;
                                        var ci = legend.chart;
                                        var meta = ci.getDatasetMeta(idx);
                                        meta.hidden = meta.hidden === null ? !ci.data.datasets[idx].hidden : null;
                                        ci.data.datasets[idx].hidden = meta.hidden;
                                        ci.update();
                                    }
                                },
                                tooltip: {
                                    backgroundColor: 'rgba(15,23,42,0.95)',
                                    titleColor: '#e2e8f0',
                                    bodyColor: '#cbd5e1',
                                    borderColor: 'rgba(255,255,255,0.1)',
                                    borderWidth: 1,
                                    callbacks: {
                                        label: function(ctx) {
                                            var v = ctx.raw;
                                            return ctx.dataset.label + ': ' + formatCurrency(v) + ' ' + getCurrencySymbol();
                                        },
                                        afterBody: function(tooltipItems) {
                                            return '';
                                        }
                                    }
                                }
                            },
                            scales: {
                                x: { title: { display: true, text: xAxisTitle }, grid: { color: 'rgba(255,255,255,0.06)' }, ticks: { color: '#94a3b8', maxTicksLimit: 15 } },
                                y: { beginAtZero: true, title: { display: true, text: yAxisTitle }, grid: { color: 'rgba(255,255,255,0.06)' }, ticks: { color: '#94a3b8', callback: function(v) { return formatCurrency(v); } } }
                            }
                        }
                    });
                    } catch (chartErr) {
                        var chartMsg = revCompMsg('rev_comp_load_error', 'هەڵە د وەرگرتنا داتایێ دا');
                        if (!silent && typeof showToast === 'function') showToast(chartMsg, true);
                        else revCompShowInlineHint(chartMsg);
                    }
                })
                .catch(function() {
                    var failMsg = revCompMsg('rev_comp_load_error', 'هەڵە د وەرگرتنا داتایێ دا');
                    if (!silent && typeof showToast === 'function') showToast(failMsg, true);
                    else revCompShowInlineHint(failMsg);
                });
        }

        function revCompShowInlineHint(msg) {
            var summaryEl = document.getElementById('rev-comp-summary-cards');
            if (!summaryEl) return;
            var safe = (typeof escapeHtml === 'function') ? escapeHtml(String(msg || '')) : String(msg || '');
            summaryEl.innerHTML = '<div style="padding:12px;color:#94a3b8;font-size:0.85rem;text-align:center;">' + safe + '</div>';
        }

        // --- DETAILED REPORT (A4 DESIGN) - ENHANCED ---
        function printDetailedReport(type) {
            const today = getBusinessDate(new Date());
            const thisMonth = getBusinessMonth(new Date());
            const allSales = getReportSales(); // Use filtered sales
            const loc = typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ';
            const L = {
                dateLabel: _drT('print_date', 'بەروار'),
                titleDaily: _drT('dr_report_daily', 'ڕاپۆرتا ڕۆژانە'),
                titleMonthly: _drT('dr_report_monthly', 'ڕاپۆرتا هەیڤانە'),
                totalSales: _drT('dr_total_sales', 'کۆیێ فرۆتنێ'),
                totalExpenses: _drT('dr_total_expenses', 'کۆیێ مەزاختنێ'),
                netProfit: _drT('dr_net_profit', 'مفایێ سافی'),
                sectionItems: _drT('dr_section_sales_by_item', '١. فرۆتن ل دویڤ ئایتمی'),
                colItem: _drT('dr_col_item', 'ئایتم'),
                colQty: _drT('dr_col_qty', 'ژمارە'),
                colLineTotal: _drT('dr_col_line_total', 'کۆیا بهای'),
                sectionStaff: _drT('dr_section_staff', '٢. چالاکیێن کارمەندان'),
                colStaff: _drT('dr_col_staff', 'کارمەند'),
                colReceiptCount: _drT('dr_col_receipt_count', 'ژمارا وەسڵان'),
                sectionExpenses: _drT('dr_section_expenses', '٣. مەزاختن'),
                colNote: _drT('dr_col_note', 'تێبینی'),
                colAmount: _drT('dr_col_amount_iqd', 'بڕ (IQD)'),
                noExpenses: _drT('dr_no_expenses', 'چ مەزاختن نینن'),
                sectionReceipts: _drT('dr_section_receipts', '٤. وەسڵ'),
                colReceiptNo: _drT('dr_col_receipt_no', 'ژمارا وەسڵێ'),
                colTable: _drT('dr_col_table', (typeof getTablesLabelShort === 'function' ? getTablesLabelShort() : 'مێز')),
                colTime: _drT('dr_col_time', 'دەم'),
                giftLabel: _drT('dr_gift_label', 'دیاری'),
                footerGenerated: _drT('dr_footer_generated', 'Generated at')
            };
            
            let filteredSales = [];
            let filteredExpenses = []; 
            let title = "";

            if(type === 'daily') {
                filteredSales = allSales.filter(s => getBusinessDate(parseSQLDate(s.date || s.created_at)) === today);
                filteredExpenses = (typeof filterOperationalExpenses === 'function' ? filterOperationalExpenses(db.expenses) : db.expenses).filter(e => getBusinessDate(parseSQLDate(e.date)) === today);
                title = L.titleDaily + ': ' + today;
            } else {
                filteredSales = allSales.filter(s => getBusinessMonth(parseSQLDate(s.date || s.created_at)) === thisMonth);
                filteredExpenses = (typeof filterOperationalExpenses === 'function' ? filterOperationalExpenses(db.expenses) : db.expenses).filter(e => getBusinessMonth(parseSQLDate(e.date)) === thisMonth);
                title = L.titleMonthly + ': ' + thisMonth;
            }

            const itemCounts = {};
            const staffStats = {};
            let totalRevenue = 0;
            
            filteredSales.forEach(s => {
                totalRevenue += s.total;
                s.items.forEach(i => {
                    if (i.isGift) {
                        const giftName = '🎁 ' + escapeHtml(i.name) + ' (' + L.giftLabel + ')';
                        if(!itemCounts[giftName]) itemCounts[giftName] = { qty: 0, total: 0 };
                        var lineQ = typeof getItemQty === 'function' ? getItemQty(i) : 1;
                        itemCounts[giftName].qty += lineQ;
                        itemCounts[giftName].total += (parseFloat(i.price) || 0) * lineQ;
                    } else {
                        const safeName = escapeHtml(i.name);
                        if(!itemCounts[safeName]) itemCounts[safeName] = { qty: 0, total: 0 };
                        var lineQ = typeof getItemQty === 'function' ? getItemQty(i) : 1;
                        itemCounts[safeName].qty += lineQ;
                        itemCounts[safeName].total += (parseFloat(i.price) || 0) * lineQ;
                    }
                });
                
                // Track Staff Performance
                const cName = s.cashier || 'Unknown';
                if(!staffStats[cName]) staffStats[cName] = { count: 0, total: 0 };
                staffStats[cName].count++;
                staffStats[cName].total += s.total;
            });

            const totalExp = filteredExpenses.reduce(function(a, e) {
                return a + ((typeof expenseAmountIqd === 'function') ? expenseAmountIqd(e) : (parseFloat(e.amount) || 0));
            }, 0);
            const net = totalRevenue - totalExp;

            const logoHtml = (typeof getReceiptLogoHtml === 'function')
                ? getReceiptLogoHtml({ mode: 'a4' })
                : ((typeof getPosShopLogoUrl === 'function' && getPosShopLogoUrl()) ? `<img src="${getPosShopLogoUrl()}" style="max-height: 80px; max-width: 150px;" alt="">` : ''); 

            // A4 HTML GENERATION - ENHANCED
            let html = `
            <div class="print-a4-container" data-skip-print-localize="1" style="font-family:'Rudaw', sans-serif;">
                    <div class="print-header">
                        <div style="text-align:right">
                            <h1 style="color: #000; margin: 0; font-size: 24px;">${db.settings.cafeName}</h1>
                            <p style="color:#444; margin: 5px 0; font-size: 14px;">${db.settings.cafeInfo}</p>
                        </div>
                        <div style="text-align:center;">${logoHtml}</div>
                        <div style="text-align:left">
                            <h2 style="color: #000; margin: 0; font-size: 20px;">${title}</h2>
                            <p style="color:#444; margin: 5px 0;">${L.dateLabel}: ${new Date().toLocaleDateString(loc)}</p>
                        </div>
                    </div>
                    
                    <div class="print-summary-box">
                        <div class="p-box" style="border-color: #10b981;">
                            <h3>${L.totalSales}</h3>
                            <h2 style="color: #10b981;">${formatCurrency(totalRevenue)} ${getCurrencySymbol()}</h2>
                        </div>
                        ${((typeof canViewExpenses === 'function') ? canViewExpenses() : true) ? `<div class="p-box" style="border-color: #ef4444;">
                            <h3>${L.totalExpenses}</h3>
                            <h2 style="color: #ef4444;">${formatCurrency(totalExp)} ${getCurrencySymbol()}</h2>
                        </div>` : ''}
                        ${((typeof canViewProfit === 'function') ? canViewProfit() : true) ? `<div class="p-box" style="background:#f0f9ff; border-color: #3b82f6;">
                            <h3>${L.netProfit}</h3>
                            <h2 style="color: #1f2937;">${formatCurrency(net)} ${getCurrencySymbol()}</h2>
                        </div>` : ''}
                    </div>

                    <div class="section-title">${L.sectionItems}</div>
                    <table class="print-table">
                        <thead><tr><th>${L.colItem}</th><th>${L.colQty}</th><th>${L.colLineTotal}</th></tr></thead>
                        <tbody>
                            ${Object.keys(itemCounts).map(k => `
                                <tr>
                                    <td><b>${k}</b></td>
                                    <td style="text-align:center; font-weight:bold;">${itemCounts[k].qty}</td>
                                    <td style="text-align:right; font-weight:bold;">${formatCurrency(itemCounts[k].total)} ${getCurrencySymbol()}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                    
                    <div class="section-title">${L.sectionStaff}</div>
                    <table class="print-table">
                        <thead><tr><th>${L.colStaff}</th><th>${L.colReceiptCount}</th><th>${L.totalSales}</th></tr></thead>
                        <tbody>
                            ${Object.keys(staffStats).map(k => `
                                <tr>
                                    <td><b>${k}</b></td>
                                    <td style="text-align:center;">${staffStats[k].count}</td>
                                    <td style="text-align:right; font-weight:bold;">${formatCurrency(staffStats[k].total)} ${getCurrencySymbol()}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>

                    <div class="section-title">${L.sectionExpenses}</div>
                     <table class="print-table">
                        <thead><tr><th>${L.colNote}</th><th>${L.colAmount}</th></tr></thead>
                        <tbody>
                            ${filteredExpenses.map(e => `<tr><td>${escapeHtml(typeof translateExpenseNoteForUi === 'function' ? translateExpenseNoteForUi(e.note) : e.note)}</td><td style="text-align:right; color:#ef4444;">${(typeof formatExpenseAmountDisplay === 'function') ? formatExpenseAmountDisplay(e) : formatCurrency((typeof expenseAmountIqd === 'function') ? expenseAmountIqd(e) : e.amount)}</td></tr>`).join('')}
                            ${filteredExpenses.length === 0 ? '<tr><td colspan="2" style="text-align:center; color:#999;">' + L.noExpenses + '</td></tr>' : ''}
                        </tbody>
                    </table>

                    <div class="section-title">${L.sectionReceipts}</div>
                    <table class="print-table">
                        <thead><tr><th>${L.colReceiptNo}</th><th>${L.colTable}</th><th>${L.colLineTotal}</th><th>${L.colTime}</th></tr></thead>
                        <tbody>
                            ${filteredSales.slice().reverse().map(s => `
                                <tr>
                                    <td>#${s.id.toString().slice(-4)}</td>
                                    <td>${escapeHtml(s.table)}</td>
                                    <td style="text-align:right;">${formatCurrency(s.total, typeof fxUsdRateFormatOpts === 'function' ? fxUsdRateFormatOpts(s) : undefined)} ${getCurrencySymbol()}</td>
                                    <td>${parseSQLDate(s.date || s.created_at).toLocaleTimeString(loc, {hour: '2-digit', minute:'2-digit'})}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>

                    <div class="report-footer">
                        ${window.posBrandWithVersion()} | ${L.footerGenerated}: ${new Date().toLocaleString(loc)}
                    </div>
                </div>
            `;

            var reportDocId = type === 'monthly' ? 'monthly' : 'daily';
            if (typeof routePrint === 'function') {
                routePrint('daily_monthly_report', html, { docId: reportDocId, details: 'type=' + reportDocId });
            } else {
                printContent(html);
            }
        }
        
        function printEntityListReport(opts) {
            opts = opts || {};
            var list = opts.list || [];
            var loc = typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ';
            var T = function(k, fb) {
                if (typeof t !== 'function') return fb;
                var v = t(k);
                return (v && v !== k) ? v : fb;
            };
            var roundM = (typeof roundMoney === 'function') ? roundMoney : function(x) { return Math.round(Number(x) || 0); };
            var totalDebt = roundM(list.reduce(function(sum, item) { return sum + (parseFloat(item.balance) || 0); }, 0));
            var debtorCount = list.filter(function(item) { return (parseFloat(item.balance) || 0) > 0; }).length;
            var clearCount = list.length - debtorCount;
            var showProfit = (typeof canViewProfit === 'function') ? canViewProfit() : true;
            var sorted = list.slice().sort(function(a, b) { return (parseFloat(b.balance) || 0) - (parseFloat(a.balance) || 0); });
            var colCount = 6 + (showProfit ? 1 : 0);
            var profitTh = showProfit ? '<th>' + T('debt_card_profit', 'فایدە') + '</th>' : '';
            var rows = sorted.map(function(item) {
                var stats = (opts.statsMap && opts.statsMap[String(item.id)]) || {};
                var extraAmt = parseFloat(stats.extra) || 0;
                var profitAmt = parseFloat(stats.profit) || 0;
                var profitTd = showProfit ? '<td>' + formatCurrency(profitAmt) + '</td>' : '';
                var bal = parseFloat(item.balance) || 0;
                var balColor = bal > 0 ? '#dc2626' : (bal < 0 ? '#2563eb' : '#059669');
                return '<tr>'
                    + '<td><b>' + escapeHtml(item.name || '') + '</b> <small style="color:#64748b;">#' + escapeHtml(String(item.id != null ? item.id : '')) + '</small></td>'
                    + '<td>' + escapeHtml(item.phone || '—') + '</td>'
                    + '<td>' + formatCurrency(item.opening_balance || 0) + '</td>'
                    + '<td style="text-align:right;color:' + balColor + ';font-weight:bold;">' + formatCurrency(bal) + '</td>'
                    + '<td>' + formatCurrency(extraAmt) + '</td>'
                    + profitTd
                    + '<td>' + escapeHtml(item.address || '—') + '</td>'
                    + '</tr>';
            }).join('');
            if (!sorted.length) {
                rows = '<tr><td colspan="' + colCount + '" style="text-align:center;color:#999;padding:30px;">' + escapeHtml(opts.emptyText || '—') + '</td></tr>';
            }
            var summaryHtml = '<div class="p-box" style="border-color:#dc2626;background:#fef2f2;"><h3>' + escapeHtml(opts.sumDebtLabel) + '</h3><h2 style="color:#dc2626;">' + formatCurrency(totalDebt) + '</h2></div>'
                + '<div class="p-box" style="border-color:#d97706;background:#fffbeb;"><h3>' + escapeHtml(opts.sumDebtorsLabel) + '</h3><h2 style="color:#d97706;">' + debtorCount + '</h2></div>'
                + '<div class="p-box" style="border-color:#059669;background:#ecfdf5;"><h3>' + escapeHtml(opts.sumClearLabel) + '</h3><h2 style="color:#059669;">' + clearCount + '</h2></div>';
            var tableHtml = '<div class="section-title">' + escapeHtml(opts.tableTitle) + '</div>'
                + '<table class="print-table"><thead><tr>'
                + '<th>' + escapeHtml(opts.colName) + '</th>'
                + '<th>' + T('debt_new_phone_ph', 'ژمارا تەلەفۆنێ') + '</th>'
                + '<th>' + T('debt_card_old_opening', 'دەینی کەڤن') + '</th>'
                + '<th>' + escapeHtml(opts.colBalance) + '</th>'
                + '<th>' + escapeHtml(opts.colExtra) + '</th>'
                + profitTh
                + '<th>' + T('debt_new_address_ph', 'ناڤنیشان') + '</th>'
                + '</tr></thead><tbody>' + rows + '</tbody></table>';
            var html = (typeof buildFlexibleReportPrintHtml === 'function')
                ? buildFlexibleReportPrintHtml(opts.docType, opts.title, T('print_date', 'بەروار') + ': ' + new Date().toLocaleDateString(loc), summaryHtml, tableHtml)
                : tableHtml;
            if (typeof routePrint === 'function') routePrint(opts.docType, html, { details: opts.docType + '_rows=' + sorted.length });
            else if (typeof printContent === 'function') printContent(html);
        }

        function printCustomersReport() {
            if (!db) return;
            var list = (db.customers || []).slice();
            var statsMap = Object.create(null);
            if (typeof buildDebtEntitySalesStatsMap === 'function') {
                var raw = buildDebtEntitySalesStatsMap('customers') || {};
                Object.keys(raw).forEach(function(id) {
                    statsMap[id] = { extra: raw[id].sales || 0, profit: raw[id].profit || 0 };
                });
            }
            printEntityListReport({
                list: list,
                statsMap: statsMap,
                docType: 'debt_list',
                title: (typeof t === 'function' ? t('view_debt_title') : '') || 'کریار',
                tableTitle: 'لیستا کریاران',
                sumDebtLabel: 'کۆیێ قەرزێ کریاران',
                sumDebtorsLabel: 'ژمارا کریارێن قەرزدار',
                sumClearLabel: 'کریارێن بێ قەرز',
                colName: 'کریار',
                colBalance: 'قەرزێ مای',
                colExtra: (typeof t === 'function' ? t('debt_card_sales') : '') || 'فرۆتن',
                emptyText: 'هیچ کریارەک تۆمار نەبوویە'
            });
        }

        function printCompaniesReport() {
            if (!db) return;
            var list = (db.companies || []).slice();
            var statsMap = Object.create(null);
            if (typeof buildCompanyPurchaseStatsMap === 'function') {
                var raw = buildCompanyPurchaseStatsMap() || {};
                Object.keys(raw).forEach(function(id) {
                    statsMap[id] = { extra: raw[id].purchase || 0, profit: raw[id].profit || 0 };
                });
            }
            printEntityListReport({
                list: list,
                statsMap: statsMap,
                docType: 'company_ledger',
                title: (typeof t === 'function' ? t('view_companies_title') : '') || 'کۆمپانیا',
                tableTitle: 'لیستا کۆمپانیان',
                sumDebtLabel: 'کۆمێ قەرزێ گشتی',
                sumDebtorsLabel: 'ژمارا کۆمپانیێن قەرزدار',
                sumClearLabel: 'کۆمپانیێن بێ قەرز',
                colName: 'کۆمپانیا',
                colBalance: 'بڕێ قەرزی',
                colExtra: (typeof t === 'function' ? t('comp_card_purchases') : '') || 'کڕین',
                emptyText: 'هیچ کۆمپانیایەک تۆمار نەبوویە'
            });
        }

        function printDebtReport() {
            printCustomersReport();
        }
        window.printCustomersReport = printCustomersReport;
        window.printCompaniesReport = printCompaniesReport;
        window.printDebtReport = printDebtReport;
        window.printEntityListReport = printEntityListReport;


        function openRevenueComparisonModal() {
            var modal = document.getElementById('revenue-comparison-modal');
            if (modal) {
                modal.style.display = 'flex';
                if (typeof renderRevCompPeriodRowsInitial === 'function') renderRevCompPeriodRowsInitial();
                loadRevenueComparison();
            }
        }
        function closeRevenueComparisonModal() {
            var modal = document.getElementById('revenue-comparison-modal');
            if (modal) modal.style.display = 'none';
        }
        window.openRevenueComparisonModal = openRevenueComparisonModal;
        window.closeRevenueComparisonModal = closeRevenueComparisonModal;

