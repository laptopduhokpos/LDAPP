    <!-- تایبەتمەندیە قفڵکراوەکان: قفڵ لە مێنوی نهێنی؛ چالاک/ناچالاک لە ڕێکخستن دوای کردنەوەی قفڵ -->
    <div id="secret-only-feature-toggles" hidden aria-hidden="true">
        <label class="setting-toggle-card" for="set-show-note-icon">
            <div class="stc-content"><div class="stc-icon"><i class="fas fa-comment-dots"></i></div><div class="stc-info"><h4 data-i18n="settings_t_item_note">تێبینی بۆ ئایتمان</h4></div></div>
            <div class="toggle-switch"><input type="checkbox" id="set-show-note-icon" onchange="updateToggleCards()"><span class="slider"></span></div>
        </label>
        <label class="setting-toggle-card setting-toggle-card--jumla-system" for="set-enable-takeaway">
            <div class="stc-content"><div class="stc-icon"><i class="fas fa-box"></i></div><div class="stc-info"><h4 data-i18n="settings_t_takeaway">سیستەمێ جوملە</h4><p data-i18n="settings_t_takeaway_hint">فرۆشتن ب نرخێ جوملە — دوگمەی جوملە ل POS</p><div id="jumla-system-mode-wrap" class="jumla-system-mode-wrap is-hidden" aria-hidden="true" onclick="event.preventDefault(); event.stopPropagation();"><span class="jumla-system-mode-label" data-i18n="settings_jumla_mode_label">جۆر:</span><div class="jumla-system-mode-segment" role="group" aria-label="سەفەری یان جوملە"><button type="button" class="jumla-system-mode-btn" data-jumla-mode="sefari" onclick="event.preventDefault(); event.stopPropagation(); if(typeof setJumlaSystemMode==='function')setJumlaSystemMode('sefari');"><i class="fas fa-shopping-bag"></i> <span data-i18n="settings_jumla_mode_sefari">سەفەری</span></button><button type="button" class="jumla-system-mode-btn" data-jumla-mode="jumla" onclick="event.preventDefault(); event.stopPropagation(); if(typeof setJumlaSystemMode==='function')setJumlaSystemMode('jumla');"><i class="fas fa-box"></i> <span data-i18n="settings_jumla_mode_jumla">جوملە</span></button></div></div></div></div>
            <div class="toggle-switch"><input type="checkbox" id="set-enable-takeaway" onchange="toggleTakeawaySettings(); updateToggleCards()"><span class="slider"></span></div>
        </label>
        <input type="checkbox" id="set-takeaway-as-wholesale" hidden aria-hidden="true" tabindex="-1">
        <label class="setting-toggle-card" for="set-enable-wholesale">
            <div class="stc-content"><div class="stc-icon"><i class="fas fa-boxes"></i></div><div class="stc-info"><h4 data-i18n="settings_t_wholesale">فرۆتنا ب کۆم</h4></div></div>
            <div class="toggle-switch"><input type="checkbox" id="set-enable-wholesale" onchange="toggleWholesaleSettings(); updateToggleCards()"><span class="slider"></span></div>
        </label>
        <label class="setting-toggle-card" for="set-show-tables">
            <div class="stc-content"><div class="stc-icon"><i class="fas fa-th"></i></div><div class="stc-info"><h4 data-i18n="settings_t_tables">نیشاندانا مێزان</h4></div></div>
            <div class="toggle-switch"><input type="checkbox" id="set-show-tables" onchange="toggleTablesUI(); updateToggleCards()"><span class="slider"></span></div>
        </label>
        <label class="setting-toggle-card" for="set-enable-gift">
            <div class="stc-content"><div class="stc-icon"><i class="fas fa-gift"></i></div><div class="stc-info"><h4 data-i18n="settings_t_gift">دیاریکرنا دیاریێ</h4></div></div>
            <div class="toggle-switch"><input type="checkbox" id="set-enable-gift" onchange="updateToggleCards()"><span class="slider"></span></div>
        </label>
        <label class="setting-toggle-card" for="set-enable-manual-sale">
            <div class="stc-content"><div class="stc-icon"><i class="fas fa-keyboard"></i></div><div class="stc-info"><h4 data-i18n="settings_enable_manual_sale">فرۆتنا دەستی</h4><p data-i18n="settings_enable_manual_sale_hint">ئەگەر کوژێیت، دوگمە و فرۆتنا بێ بارکۆد دەشارێتەوە.</p></div></div>
            <div class="toggle-switch"><input type="checkbox" id="set-enable-manual-sale" onchange="if(typeof applyManualSaleVisibility==='function')applyManualSaleVisibility(); updateToggleCards()"><span class="slider"></span></div>
        </label>
        <label class="setting-toggle-card" for="set-enable-manual-sale">
            <div class="stc-content"><div class="stc-icon"><i class="fas fa-users"></i></div><div class="stc-info"><h4 data-i18n="settings_locked_staff_cap_title">زیاتر لە ٣ کارمەند</h4><p data-i18n="settings_locked_staff_cap_hint">زیادکردنا کارمەندێن زیاتر</p></div></div>
            <div class="toggle-switch"><input type="checkbox" id="set-unlock-staff-beyond-five" onchange="updateToggleCards()"><span class="slider"></span></div>
        </label>
        <label class="setting-toggle-card" for="set-show-fab">
            <div class="stc-content"><div class="stc-icon"><i class="fas fa-bars"></i></div><div class="stc-info"><h4 data-i18n="settings_t_fab_menu">بشکوکێ لیستا سەرەکی</h4></div></div>
            <div class="toggle-switch"><input type="checkbox" id="set-show-fab" onchange="toggleFabVisibility(); updateToggleCards()"><span class="slider"></span></div>
        </label>
        <label class="setting-toggle-card" for="set-enable-delivery">
            <div class="stc-content"><div class="stc-icon"><i class="fas fa-truck"></i></div><div class="stc-info"><h4 data-i18n="settings_t_delivery">گەهاندن</h4></div></div>
            <div class="toggle-switch"><input type="checkbox" id="set-enable-delivery" onchange="applyFeatureVisibility(); updateToggleCards()"><span class="slider"></span></div>
        </label>
        <label class="setting-toggle-card" for="set-require-opening-balance-prompt">
            <div class="stc-content"><div class="stc-icon"><i class="fas fa-cash-register"></i></div><div class="stc-info"><h4 data-i18n="settings_t_opening_balance">داخوازکرنا پارەیێ دەستپێکێ</h4><p data-i18n="settings_t_opening_balance_hint">ل دەمێ ڤەکرنا سیستەمی</p></div></div>
            <div class="toggle-switch"><input type="checkbox" id="set-require-opening-balance-prompt" onchange="if(window.saveOpeningBalancePromptSetting) saveOpeningBalancePromptSetting(); updateToggleCards()"><span class="slider"></span></div>
        </label>
        <label class="setting-toggle-card" for="set-require-end-shift-reconcile-prompt">
            <div class="stc-content"><div class="stc-icon"><i class="fas fa-clipboard-check"></i></div><div class="stc-info"><h4 data-i18n="settings_t_end_shift">داخوازکرنا قاسەی ل داویێ</h4><p data-i18n="settings_t_end_shift_hint">ل دەمێ گرتنا شیفتی</p></div></div>
            <div class="toggle-switch"><input type="checkbox" id="set-require-end-shift-reconcile-prompt" onchange="if(window.saveEndShiftReconcilePromptSetting) saveEndShiftReconcilePromptSetting(); updateToggleCards()"><span class="slider"></span></div>
        </label>
        <label class="setting-toggle-card" for="set-allow-negative-stock">
            <div class="stc-content"><div class="stc-icon"><i class="fas fa-box-open"></i></div><div class="stc-info"><h4 data-i18n="settings_t_neg_stock">فرۆتنا بێ کۆگەه (سالب)</h4><p data-i18n="settings_t_neg_stock_hint">فرۆتن ئەگەر ئایتم ژی نەمابیت</p></div></div>
            <div class="toggle-switch"><input type="checkbox" id="set-allow-negative-stock" onchange="updateToggleCards()"><span class="slider"></span></div>
        </label>
        <label class="setting-toggle-card" for="set-enable-money-rounding">
            <div class="stc-content"><div class="stc-icon"><i class="fas fa-coins"></i></div><div class="stc-info"><h4 data-i18n="settings_t_money_round">خڕکرنا پارەیێ دیناری</h4><p data-i18n="settings_t_money_round_hint">کۆژم بێ باقی دەرکەڤیت</p></div></div>
            <div class="toggle-switch"><input type="checkbox" id="set-enable-money-rounding" onchange="updateToggleCards()"><span class="slider"></span></div>
        </label>
        <label class="setting-toggle-card" for="set-show-payment-modal">
            <div class="stc-content"><div class="stc-icon"><i class="fas fa-window-maximize"></i></div><div class="stc-info"><h4 data-i18n="settings_t_payment_modal">شاشا پارەدانێ</h4><p data-i18n="settings_t_payment_modal_hint">ئەگەر نەبیت، ڕاستەوخۆ وەسلێ دەردێخیت</p></div></div>
            <div class="toggle-switch"><input type="checkbox" id="set-show-payment-modal" onchange="updateToggleCards()"><span class="slider"></span></div>
        </label>
        <label class="setting-toggle-card" for="set-enable-multi-warehouse">
            <div class="stc-content"><div class="stc-icon"><i class="fas fa-store-alt"></i></div><div class="stc-info"><h4 data-i18n="settings_t_multi_warehouse">کۆگای فرە (Pro)</h4><p data-i18n="settings_t_multi_warehouse_hint">زیاتر لە یەک کۆگە، گواستنەوە، هەڵبژاردن ل کڕین و ئایتم</p></div></div>
            <div class="toggle-switch"><input type="checkbox" id="set-enable-multi-warehouse" onchange="if(typeof onEnableMultiWarehouseChange==='function')onEnableMultiWarehouseChange(this); else { if(typeof applyMultiWarehouseVisibility==='function')applyMultiWarehouseVisibility(); updateToggleCards(); }"><span class="slider"></span></div>
        </label>
        <label class="setting-toggle-card" for="premium-purchase-batch">
            <div class="stc-content"><div class="stc-icon"><i class="fas fa-layer-group"></i></div><div class="stc-info"><h4 data-i18n="settings_t_purchase_batch">ژمارا وەجبێ (کڕین)</h4><p data-i18n="settings_t_purchase_batch_hint">گەڕاندن و مێژووی کڕین بە ژمارەی وەجبە</p></div></div>
            <div class="toggle-switch"><input type="checkbox" id="premium-purchase-batch" onchange="if(window.db&&window.db.settings){db.settings.enablePurchaseBatch=this.checked;} if(typeof applyPurchaseBatchPremiumUi==='function')applyPurchaseBatchPremiumUi(); if(typeof syncSettingsLockedPreviewCards==='function')syncSettingsLockedPreviewCards(); updateToggleCards(); if(typeof saveSettings==='function')saveSettings().catch(function(){});"><span class="slider"></span></div>
        </label>
        <label class="setting-toggle-card" for="premium-mfr-slot">
            <div class="stc-content"><div class="stc-icon"><i class="fas fa-industry"></i></div><div class="stc-info"><h4 data-i18n="settings_t_manufacturer">کۆمپانیا دروستکەر</h4><p data-i18n="settings_t_manufacturer_hint">فلتەر و هەڵبژاردن ل ئایتم، کۆگە و کڕین</p></div></div>
            <div class="toggle-switch"><input type="checkbox" id="premium-mfr-slot" onchange="if(window.db&&window.db.settings){db.settings.manufacturerSlot=this.checked;} if(typeof applyProductFormPremiumFeatureFields==='function')applyProductFormPremiumFeatureFields(); if(typeof renderManufacturers==='function'&&window.companiesActiveTab==='manufacturers')renderManufacturers(); if(typeof syncSettingsLockedPreviewCards==='function')syncSettingsLockedPreviewCards(); updateToggleCards();"><span class="slider"></span></div>
        </label>
        <label class="setting-toggle-card" for="premium-tech-specs">
            <div class="stc-content"><div class="stc-icon"><i class="fas fa-microchip"></i></div><div class="stc-info"><h4 data-i18n="settings_t_tech_specs">مواسفات لاپتۆب / مۆبایل</h4><p data-i18n="settings_t_tech_specs_hint">CPU، RAM، GPU ل فۆرمێ ئایتم و لزگە</p></div></div>
            <div class="toggle-switch"><input type="checkbox" id="premium-tech-specs" onchange="if(typeof onPremiumTechSpecsToggle==='function')onPremiumTechSpecsToggle(this);"><span class="slider"></span></div>
        </label>
        <div class="setting-toggle-card setting-followup-card" data-premium-vault="premium-sale-followup">
            <label class="stc-followup-head" for="premium-sale-followup">
                <div class="stc-content">
                    <div class="stc-icon" style="background: rgba(37, 211, 102, 0.15); color: #128c7e;"><i class="fab fa-whatsapp"></i></div>
                    <div class="stc-info">
                        <h4 data-i18n="settings_t_sale_followup">پەیوەندیا پشتی فرۆتنێ</h4>
                        <p data-i18n="settings_t_sale_followup_hint_on">سووچ ڤەکە — وەختێ وەخت گەهشت، ل ئاگەهداریان ناڤێ کریاری دێت</p>
                    </div>
                </div>
                <div class="toggle-switch"><input type="checkbox" id="premium-sale-followup" onchange="if(typeof persistSaleFollowupSettings==='function')persistSaleFollowupSettings();"><span class="slider"></span></div>
            </label>
            <div class="followup-settings-fields">
                <label class="followup-settings-label" data-i18n="settings_sale_followup_times">وەختێ نامێ (تۆ دەست نیشان دکەی)</label>
                <small class="followup-settings-note" data-i18n="settings_sale_followup_times_hint">نموونە: جارا ئێکێ ١ دەمژمێر، جارا دووێ ٥ ڕۆژ. دێکاری خولەک ژی.</small>
                <div id="sale-followup-schedule-list" class="followup-sched-list"></div>
                <button type="button" class="btn btn-sm btn-dark" onclick="if(typeof addSaleFollowupScheduleRow==='function')addSaleFollowupScheduleRow();" data-i18n="settings_sale_followup_add_time">+ وەختەکێ دی</button>
                <label class="followup-settings-label" for="set-sale-followup-warranty-val" data-i18n="settings_sale_followup_warranty">زەمانێ گەرەنتییێ</label>
                <small class="followup-settings-note" data-i18n="settings_sale_followup_warranty_hint">ئەگەر خلاس بوو، د نامێ دا دێ هێتە گوتن. نموونە: ١٢ هەیڤ.</small>
                <div class="followup-sched-row followup-warranty-row">
                    <input type="number" id="set-sale-followup-warranty-val" class="input-std followup-sched-val" min="1" max="999" value="12" onchange="if(typeof persistSaleFollowupSettings==='function')persistSaleFollowupSettings();">
                    <select id="set-sale-followup-warranty-unit" class="input-std followup-sched-unit" onchange="if(typeof persistSaleFollowupSettings==='function')persistSaleFollowupSettings();">
                        <option value="day" data-i18n="followup_unit_day">ڕۆژ</option>
                        <option value="month" selected data-i18n="followup_unit_month">هەیڤ</option>
                        <option value="year" data-i18n="followup_unit_year">سال</option>
                    </select>
                </div>
                <label class="followup-settings-label" for="set-sale-followup-message" data-i18n="settings_sale_followup_msg">تێکستێ نامێ</label>
                <textarea id="set-sale-followup-message" class="input-std" rows="8" dir="auto" data-i18n-placeholder="settings_sale_followup_msg_ph" placeholder="{name} {item} {shop} {warranty} {invoice} {date}" onblur="if(typeof persistSaleFollowupSettings==='function')persistSaleFollowupSettings();"></textarea>
                <small class="followup-settings-note" data-i18n="settings_sale_followup_msg_hint">{name} = ناڤێ کریاری، {item} = کەرستێن فاتوورێ، {shop} = ناڤێ دکانێ، {warranty} = زەمان، {invoice} = ژمارا فاتوورێ، {date} = مێژوو</small>
            </div>
        </div>
    </div>

    <div style="background:var(--bg); border:1px solid var(--border); border-radius:12px; padding:15px; margin-bottom:20px;">
        <h4 style="margin-top:0; color:var(--brand); border-bottom:1px solid var(--border); padding-bottom:8px; margin-bottom:15px;"><i class="fas fa-desktop"></i> <span data-i18n="settings_sec_ui">شێوەیێ ڕووکارێ سیستەمی</span></h4>
        <div class="settings-grid">
            <label class="setting-toggle-card" for="set-show-right-sidebar">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-list-ul"></i></div><div class="stc-info"><h4 data-i18n="settings_t_right_sidebar">لیستا کەناری</h4></div></div>
                <div class="toggle-switch"><input type="checkbox" id="set-show-right-sidebar" onchange="toggleRightSidebarVisibility()"><span class="slider"></span></div>
            </label>
            <div class="setting-toggle-card" style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:12px; padding:16px;">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-align-right"></i></div><div class="stc-info"><h4 data-i18n="settings_t_sidebar_align">جهێ لیستێ</h4></div></div>
                <div style="display:flex; gap:10px; align-items:center;">
                    <label style="display:flex; align-items:center; gap:6px; cursor:pointer; font-size:0.9rem;"><input type="radio" name="sidebar-position" id="set-sidebar-position-right" value="right" onchange="setSidebarPosition('right')"> <span data-i18n="settings_sidebar_right">ڕاست</span></label>
                    <label style="display:flex; align-items:center; gap:6px; cursor:pointer; font-size:0.9rem;"><input type="radio" name="sidebar-position" id="set-sidebar-position-left" value="left" onchange="setSidebarPosition('left')"> <span data-i18n="settings_sidebar_left">چەپ</span></label>
                </div>
            </div>
            <label class="setting-toggle-card" for="set-show-breadcrumb">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-route"></i></div><div class="stc-info"><h4 data-i18n="settings_t_breadcrumb">ڕێڕەو</h4></div></div>
                <div class="toggle-switch"><input type="checkbox" id="set-show-breadcrumb" onchange="toggleBreadcrumbVisibility()"><span class="slider"></span></div>
            </label>
            <label class="setting-toggle-card" for="set-show-stock-on-pos">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-boxes"></i></div><div class="stc-info"><h4 data-i18n="settings_t_stock_badge">نیشاندانا ژمارا مای</h4><p data-i18n="settings_t_stock_badge_hint">دانەیێن ماینە ل سەر وێنەیێ ئایتمی</p></div></div>
                <div class="toggle-switch"><input type="checkbox" id="set-show-stock-on-pos" checked onchange="if(window.db && window.db.settings) window.db.settings.showStockOnPos = this.checked; updateToggleCards(); if(typeof renderPOSMenu === 'function') renderPOSMenu((document.getElementById('pos-barcode-input')?document.getElementById('pos-barcode-input').value:''), true); if(typeof refreshAllStockDisplaysFromState === 'function') refreshAllStockDisplaysFromState(); if(typeof saveSettings === 'function') saveSettings().catch(function(){});"><span class="slider"></span></div>
            </label>
            <label class="setting-toggle-card" for="set-enable-notifications">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-bell"></i></div><div class="stc-info"><h4 data-i18n="settings_t_notifications_short">ئاگەهداری</h4></div></div>
                <div class="toggle-switch"><input type="checkbox" id="set-enable-notifications" onchange="applyFeatureVisibility(); updateToggleCards()"><span class="slider"></span></div>
            </label>
            <label class="setting-toggle-card" for="set-hide-warehouse-stock-warn">
                <div class="stc-content"><div class="stc-icon"><i class="fas fa-unlock"></i></div><div class="stc-info"><h4 data-i18n="settings_t_hide_wh_stock_warn">ریسالە نەهێت دەمێ دەستکاریا کۆگەهێ</h4><p data-i18n="settings_t_hide_wh_stock_warn_hint">ئەگەر ڤەکری، عەدەدێ کۆگەهێ بێ ئاگەهداری دەستکاری دکەی. بنەڕەت: ریسالە دێ هێت</p></div></div>
                <div class="toggle-switch"><input type="checkbox" id="set-hide-warehouse-stock-warn" onchange="if(typeof onHideWarehouseStockWarnChange==='function')onHideWarehouseStockWarnChange();"><span class="slider"></span></div>
            </label>
            <div class="setting-toggle-card" style="cursor: default;">
                <div class="stc-content">
                    <div class="stc-icon"><i class="fas fa-clock"></i></div>
                    <div class="stc-info">
                        <h4 data-i18n="settings_t_business_day">دەستپێکا ڕۆژێ (بۆ ڕاپۆرتان)</h4>
                        <div style="margin-top:8px;">
                            <select id="set-business-day-start-hour" class="input-std" style="margin:0; height:35px; padding:0 10px; font-size:0.9rem; width:100%;" onchange="if(typeof savePrintSettings==='function') savePrintSettings();">
                                <option value="0">12:00 AM (نیڤ شەڤ)</option>
                                <option value="1">01:00 AM</option><option value="2">02:00 AM</option><option value="3">03:00 AM</option>
                                <option value="4">04:00 AM</option><option value="5">05:00 AM</option><option value="6">06:00 AM</option>
                                <option value="7">07:00 AM</option><option value="8">08:00 AM</option>
                            </select>
                            <p id="set-business-day-start-hour-hint" style="display:none; font-size:0.82rem; color:var(--text-muted); margin:8px 0 0; line-height:1.35;"></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div style="background:var(--bg); border:1px solid var(--border); border-radius:12px; padding:15px;">
        <h4 style="margin-top:0; color:var(--brand); border-bottom:1px solid var(--border); padding-bottom:8px; margin-bottom:15px;"><i class="fas fa-tags"></i> <span data-i18n="settings_sec_stock_alerts">ئاگادارکرنا کۆگەهێ</span></h4>
        <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap:15px; margin-bottom: 15px;">
            <div style="grid-column: 1 / -1; display: flex; align-items: center; gap: 10px;">
                <label class="setting-toggle-card" for="set-use-global-min-stock" style="margin: 0; padding: 10px; flex: 1;">
                    <div class="stc-content">
                        <div class="stc-icon"><i class="fas fa-bell"></i></div>
                        <div class="stc-info">
                            <h4 data-settings-i18n="settings_global_min_stock_title">ئاگادارکرنا گشتی بۆ کەمبوونێ</h4>
                            <p data-settings-i18n="settings_global_min_stock_desc">ئەگەر چالاک بێت، هەمان ژمارە بۆ هەموو ئایتمەکان بەکاردێت (لە جیاتی ئەوەی بۆ هەر ئایتمێک جیاواز بێت).</p>
                        </div>
                    </div>
                    <div class="toggle-switch"><input type="checkbox" id="set-use-global-min-stock" onchange="updateToggleCards()"><span class="slider"></span></div>
                </label>
            </div>
            <div>
                <label for="set-global-min-stock-threshold" style="font-size:0.85rem; display:block; margin-bottom:4px; font-weight:bold;" data-settings-i18n="settings_global_min_stock_label">ژمارەی ئاگادارکرن (گشتی)</label>
                <input type="number" id="set-global-min-stock-threshold" class="input-std" min="0" data-settings-i18n-placeholder="settings_global_min_stock_ph" placeholder="بۆ نموونە: 3" style="width:100%;">
            </div>
        </div>
        <p style="font-size:0.85rem; color:var(--text-muted); margin:0 0 12px;" data-i18n="settings_stock_alerts_intro">ناڤێ ڤان خانەیان بگوهۆڕە یێن کو ل سەر فۆرمێ زێدەکرنا ئایتمی دەردکەڤن.</p>
        <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap:15px;">
            <div>
                <label for="set-label-min-stock-alert" style="font-size:0.85rem; display:block; margin-bottom:4px; font-weight:bold;" data-i18n="settings_l_min_stock">کەمبوونەوا ئایتمی ل کۆگەهێ</label>
                <input type="text" id="set-label-min-stock-alert" class="input-std" maxlength="160" autocomplete="off" data-settings-i18n-placeholder="settings_label_min_stock_ph" placeholder="بۆ نموونە: حد تنبيه الكمية" style="width:100%;">
            </div>
            <div>
                <label for="set-label-expiry-alert-days" style="font-size:0.85rem; display:block; margin-bottom:4px; font-weight:bold;" data-i18n="settings_l_expiry_days">ڕۆژێن مایی بۆ بەسەرچوونێ</label>
                <input type="text" id="set-label-expiry-alert-days" class="input-std" maxlength="160" autocomplete="off" data-settings-i18n-placeholder="settings_label_expiry_ph" placeholder="بۆ نموونە: تنبيه قبل الانتهاء (يوم)" style="width:100%;">
            </div>
        </div>
    </div>

    <div style="margin-top:20px;">
        <button class="btn btn-brand" style="width:100%; padding:15px; font-size:1.1rem;" onclick="savePrintSettings()"><i class="fas fa-save"></i> <span data-i18n="settings_save_layout_btn">پاراستنا گوهۆڕینان</span></button>
    </div>
</div>

            <!-- أيقونات لوحة التحكم الرئيسية -->
            <div class="card" style="border-top: 5px solid #10b981;">
                <h3><i class="fas fa-th-large"></i> <span data-settings-i18n="settings_home_icons_title">ئایکۆنێن داشبۆردێ سەرەکی</span></h3>
                <p style="color:var(--text-muted); margin:0 0 16px 0; font-size:0.95rem;" data-settings-i18n="settings_home_icons_desc">ئایکۆنێن ل داشبۆردێ سەرەکی (لاپەرێ ئێکێ) دەرکەڤن هەلبژێرە. هەلبژاردە ب شێوەیەکێ ئۆتۆماتیکی دێ هێنە پاراستن.</p>
                <div id="home-icons-settings" class="settings-grid"></div>
            </div>

            <!-- ئامرازێن پێشکەفتی -->
            <div class="card protected" style="border-top: 5px solid #6366f1;">
                <h3><i class="fas fa-toolbox"></i> <span data-i18n="settings_adv_section_title">ئامرازێن پێشکەفتی</span></h3>
                <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap:25px; margin-top:20px;">
                    
                    <!-- Database Management -->
                    <div onclick="openDbManageModal()" 
                         style="background:linear-gradient(135deg, #1e293b 0%, #0f172a 100%); padding:30px; border-radius:25px; text-align:center; cursor:pointer; transition:transform 0.2s; color:white; box-shadow:0 10px 25px rgba(15, 23, 42, 0.3); border:1px solid #334155;"
                         onmouseover="this.style.transform='translateY(-5px)'" onmouseout="this.style.transform='translateY(0)'">
                        <i class="fas fa-database" style="font-size:3.5rem; margin-bottom:15px; opacity:0.9;"></i>
                        <div style="font-weight:bold;" data-i18n="settings_tool_db_title">بەڕێوەبردنی داتابەیس</div>
                        <div style="font-size:0.85rem; opacity:0.7; margin-top:5px;" data-i18n="settings_tool_db_sub">داتا، هەناردن و باکئەپ</div>
                    </div>

                    <!-- Telegram -->
                    <div onclick="document.getElementById('modal-telegram').style.display='flex'" 
                         style="background:linear-gradient(135deg, #0284c7 0%, #0369a1 100%); padding:30px; border-radius:25px; text-align:center; cursor:pointer; transition:transform 0.2s; color:white; box-shadow:0 10px 25px rgba(2, 132, 199, 0.3); border:1px solid #38bdf8;"
                         onmouseover="this.style.transform='translateY(-5px)'" onmouseout="this.style.transform='translateY(0)'">
                        <i class="fab fa-telegram" style="font-size:3.5rem; margin-bottom:15px; opacity:0.9;"></i>
                        <div style="font-weight:bold;" data-i18n="settings_tool_telegram_title">تیلیگرام</div>
                        <div style="font-size:0.85rem; opacity:0.7; margin-top:5px;" data-i18n="settings_tool_telegram_sub">ڕاپۆرت و ڕێکخستن </div>
                    </div>

                </div>

            </div>

            <!-- SHOP OWNER GUIDE -->
            <div class="card settings-shop-guide-card" style="border-top: 5px solid #6366f1; margin-top: 20px; cursor: pointer;" onclick="if(typeof openShopGuideModal==='function')openShopGuideModal();">
                <div style="display:flex; justify-content:space-between; align-items:center; gap:16px; flex-wrap:wrap;">
                    <div>
                        <h3 style="margin:0; color:#a5b4fc;"><i class="fas fa-graduation-cap"></i> <span data-i18n="shop_guide_title">ڕێبەرێ تەمام یێ دوکانێ</span></h3>
                        <p style="margin:8px 0 0; color:var(--text-muted); font-size:0.88rem;" data-i18n="shop_guide_settings_desc">فێرکرنا سیستەمێ — هەمی بەش و داتا ب ڕوونی</p>
                    </div>
                    <span class="shop-guide-badge shop-guide-badge--inline" data-pos-app-version>v<?php echo htmlspecialchars(defined('POS_APP_VERSION') ? POS_APP_VERSION : '3.7.68', ENT_QUOTES, 'UTF-8'); ?></span>
                </div>
            </div>

            <!-- OTA SELF-UPDATE (Supabase) — no AnyDesk -->
            <div id="settings-ota-update-card" class="card" style="border-top: 5px solid #10b981; margin-top: 20px;">
                <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:16px; flex-wrap:wrap;">
                    <div style="flex:1; min-width:240px;">
                        <h3 style="margin:0; color:#6ee7b7;"><i class="fas fa-cloud-download-alt"></i> <span data-settings-i18n="settings_ota_title">نوێکردنەوەی سیستەم</span></h3>
                        <p style="margin:8px 0 0; color:var(--text-muted); font-size:0.88rem; line-height:1.55;" data-settings-i18n="settings_ota_desc">ل مالێ ب خو ئابدەیت بکە بێی کو پێدڤی ب چ کەسان بیت. پێدڤی ب ئینتەرنێتێ هەیە.</p>
                        <p id="settings-ota-status" style="margin:12px 0 0; font-size:0.92rem; color:var(--text);" dir="auto">…</p>
                        <p id="settings-ota-notes" style="margin:8px 0 0; font-size:0.82rem; color:var(--text-muted); white-space:pre-wrap; display:none;" dir="auto"></p>
                    </div>
                    <div style="display:flex; flex-direction:column; gap:10px; min-width:180px;">
                        <button type="button" class="btn btn-dark" id="settings-ota-check-btn" onclick="if(typeof posOtaCheckUpdate==='function')posOtaCheckUpdate(true);">
                            <i class="fas fa-sync-alt"></i> <span data-settings-i18n="settings_ota_check_btn">پشکنین</span>
                        </button>
                        <button type="button" class="btn btn-success" id="settings-ota-apply-btn" style="display:none;" onclick="if(typeof posOtaDownloadAndApply==='function')posOtaDownloadAndApply();">
                            <i class="fas fa-bolt"></i> <span data-settings-i18n="settings_ota_apply_btn">ئێستا نوێ بکە</span>
                        </button>
                    </div>
                </div>
                <div id="settings-ota-progress" style="display:none; margin-top:14px;">
                    <div style="height:8px; background:rgba(148,163,184,0.25); border-radius:999px; overflow:hidden;">
                        <div id="settings-ota-progress-bar" style="height:100%; width:0%; background:linear-gradient(90deg,#10b981,#059669); transition:width .25s;"></div>
                    </div>
                    <p id="settings-ota-progress-text" style="margin:8px 0 0; font-size:0.82rem; color:var(--text-muted);"></p>
                </div>
            </div>

            <!-- ABOUT ME SECTION (LAPTOP DUHOK STAFF) -->
            <div class="card" style="border-top: 5px solid #8b5cf6; background: linear-gradient(to right, var(--card), var(--input-bg)); margin-top: 20px;">
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:20px;">
                    <div style="flex:2; min-width: 300px; display: flex; flex-direction: column; justify-content: center;">
                        <div style="display:flex; align-items:center; gap:15px; margin-bottom: 10px;">
                            <img src="<?php echo htmlspecialchars($pos_default_logo_url, ENT_QUOTES, 'UTF-8'); ?>" alt="Laptop Duhok Logo" style="width: 70px; height: 70px; border-radius: 10px; object-fit: cover;">
                            <div>
                                <h2 style="margin:0; color:var(--brand); font-size:2rem;" data-settings-i18n="settings_about_brand">Laptop Duhok Staff</h2>
                                <h3 style="margin:5px 0; color:var(--text);" data-settings-i18n="settings_about_subtitle">ستافێ لاپتوب دهوک</h3>
                                <p style="margin:6px 0 0 0; font-size:0.95rem; color:var(--text-muted);"><span data-settings-i18n="settings_about_version">وەشان / الإصدار:</span> <strong id="pos-about-version" data-pos-app-version style="color:var(--brand);">v<?php echo htmlspecialchars(POS_APP_VERSION, ENT_QUOTES, 'UTF-8'); ?></strong></p>
                                <p style="margin:4px 0 0 0; font-size:0.82rem; color:var(--success); font-weight:600;"><?php echo htmlspecialchars(defined('POS_APP_RELEASE_LABEL') ? POS_APP_RELEASE_LABEL : ('Laptop Duhok POS v' . POS_APP_VERSION . ' - Production Certified'), ENT_QUOTES, 'UTF-8'); ?></p>
                            </div>
                        </div>
                        <p style="color:var(--text-muted); font-size:1.1rem; line-height:1.8; margin-top:15px; background:rgba(139, 92, 246, 0.1); padding:15px; border-radius:10px; border-right:4px solid #8b5cf6;">
                            <i class="fas fa-laptop-code"></i>
                            <span data-settings-i18n="settings_about_line1">ئەڤ سیستەمە ژلایێ ستافێ لاپتوب دهوک ڤە هاتیە دانان و دروستکرن.</span><br>
                            <span data-settings-i18n="settings_about_line2">ئەم یێ ئامادەینە بۆ دروستکرنا ئەپلیکەیشنان، وێبسایتان و سیستەمێن پێشکەفتی.</span><br>
                            <span data-settings-i18n="settings_about_line3">ئەگەر هەر ئاریشەک یان کێماسیەک د سیستەمی دا هەبیت، هیڤیە مە ئاگەهدار بکەن.</span>
                        </p>
                    </div>
                    <div style="flex:1; display:flex; flex-direction:column; gap:15px; min-width: 200px;">
                        <a href="https://wa.me/9647517959116" target="_blank" class="btn btn-success" style="text-decoration:none; font-size:1.2rem; padding:15px; justify-content:center; border-radius:15px; box-shadow:0 4px 15px rgba(16, 185, 129, 0.3);"><i class="fab fa-whatsapp"></i> <span data-i18n="settings_link_whatsapp">واتسئاپ</span></a>
                        <a href="https://t.me/+9647517959116" target="_blank" class="btn btn-info" style="text-decoration:none; font-size:1.2rem; padding:15px; justify-content:center; border-radius:15px; box-shadow:0 4px 15px rgba(14, 165, 233, 0.3);"><i class="fab fa-telegram"></i> <span data-i18n="settings_link_telegram_btn">تیلیگرام</span></a>
                        <a href="#" class="btn btn-dark" style="text-decoration:none; font-size:1.2rem; padding:15px; justify-content:center; border-radius:15px; display:none;"></a>
                    </div>
                </div>
            </div>
        </div>

        <!-- ڕێکخستنێن چاپی و دیزاینێ (Print & Design Settings) - Card-based UI -->
        <div id="view-print-design" class="workspace">
            <h2><i class="fas fa-print"></i> <span data-i18n="nav_print_design">ڕێکخستنێن چاپێ و دیزاینێ</span></h2>
            <p style="color:var(--text-muted); margin-bottom:24px; font-size:1.05rem;" data-i18n="print_design_intro">کلیک بکە سەر کارتەکە کە چاپی بۆ ڕێکدەخەیت، پاشان قەبارەی کاغەز و دیزاین هەڵبژێرە.</p>
            <!-- کارتا ناسنامێ و سەرێ وەسڵێ — <span data-i18n="invoice_settings">ڕێکخستنێن پسوولەیێ</span> -->
            <div class="card protected pds-identity-card" style="border-top: 5px solid var(--brand); margin-bottom:24px;">
                <h3 style="margin-top:0;"><i class="fas fa-id-card"></i> <span data-i18n="pds_identity_heading">ناسنامە و سەرێ وەسڵێ</span> <span style="font-size:0.85rem; color:var(--text-muted); font-weight:normal;">— <span data-i18n="invoice_settings">ڕێکخستنێن پسوولەیێ</span></span></h3>
                <p style="color:var(--text-muted); margin-bottom:20px; font-size:0.95rem;" data-i18n="pds_identity_intro">ئەم زانیاریانە لەسەر وەسڵ و پسوولەی چاپکراو دەرکەون.</p>
                <div style="display:grid; grid-template-columns: 1fr 1fr; gap:24px; align-items:start;">
                    <div style="display:flex; flex-direction:column; gap:16px;">
                        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:10px;">
                            <div class="pds-field-ico">
                                <i class="fas fa-store" aria-hidden="true"></i>
                                <div>
                                <label class="pds-label" for="set-cafe-name"><span data-i18n="pds_lbl_store_key">ناوی فرۆشگا / کلیل</span></label>
                                <input type="text" id="set-cafe-name" class="input-std" data-i18n-placeholder="pds_ph_store_name" placeholder="" oninput="updateReceiptPreview()">
                                </div>
                            </div>
                            <div class="pds-field-ico">
                                <i class="fas fa-phone" aria-hidden="true"></i>
                                <div>
                                <label class="pds-label" for="set-cafe-phone"><span data-i18n="pds_lbl_phone_num">ژمارەی تەلەفۆن</span></label>
                                <input type="text" id="set-cafe-phone" class="input-std" data-i18n-placeholder="pds_ph_phone" placeholder="" oninput="updateReceiptPreview()">
                                </div>
                            </div>
                        </div>
                        <div class="pds-field-ico">
                            <i class="fas fa-location-dot" aria-hidden="true"></i>
                            <div>
                            <label class="pds-label" for="set-cafe-address"><span data-i18n="pds_lbl_address">ناونیشان</span></label>
                            <input type="text" id="set-cafe-address" class="input-std" data-i18n-placeholder="pds_ph_address" placeholder="" oninput="updateReceiptPreview()">
                            </div>
                        </div>
                        <div class="pds-field-ico">
                            <i class="fas fa-circle-info" aria-hidden="true"></i>
                            <div>
                            <label class="pds-label" for="set-cafe-info"><span data-i18n="pds_lbl_about_short">زانیاری کورت (دەربارە)</span></label>
                            <input type="text" id="set-cafe-info" class="input-std" data-i18n-placeholder="pds_ph_about" placeholder="" oninput="updateReceiptPreview()">
                            </div>
                        </div>
                        <div class="pds-field-ico">
                            <i class="fas fa-comment-dots" aria-hidden="true"></i>
                            <div>
                            <label class="pds-label" for="set-cafe-footer"><span data-i18n="pds_lbl_receipt_footer">بنوسەی خوارەوەی وەسڵ</span></label>
                            <input type="text" id="set-cafe-footer" class="input-std" data-i18n-placeholder="pds_ph_footer" placeholder="" oninput="updateReceiptPreview()">
                            </div>
                        </div>
                        <details class="pds-identity-more" style="border:1px dashed var(--border); border-radius:10px; padding:10px 12px;">
                            <summary style="cursor:pointer; font-size:0.9rem; color:var(--text-muted); font-weight:600;" data-i18n="pds_identity_more_summary">زیاتر (ئیختیاری)</summary>
                            <div style="display:flex; flex-direction:column; gap:12px; margin-top:12px;">
                        <fieldset class="pds-preview-toggles" style="border:1px solid var(--border); border-radius:10px; padding:12px; margin:0;">
                            <legend style="font-size:0.85rem; color:var(--text-muted);"><span data-i18n="pds_legend_preview">دەرکەوتن لەسەر وەسڵ (پێشبینین)</span></legend>
                            <label class="pds-toggle-row"><input type="checkbox" id="pds-preview-show-logo" checked onchange="saveReceiptPreviewToggles(); updateReceiptPreview();"> <i class="fas fa-image"></i> <span data-i18n="pds_toggle_logo">نیشاندانی لۆگۆ</span></label>
                            <label class="pds-toggle-row"><input type="checkbox" id="pds-preview-show-date" checked onchange="saveReceiptPreviewToggles(); updateReceiptPreview();"> <i class="fas fa-calendar-days"></i> <span data-i18n="pds_toggle_date">نیشاندانی بەروار</span></label>
                            <label class="pds-toggle-row"><input type="checkbox" id="pds-preview-show-qr" onchange="saveReceiptPreviewToggles(); updateReceiptPreview();"> <i class="fas fa-qrcode"></i> <span data-i18n="pds_toggle_qr">نیشاندانی QR</span></label>
                        </fieldset>
                        <div class="pds-field-ico">
                            <i class="fas fa-sticky-note" aria-hidden="true"></i>
                            <div>
                            <label class="pds-label" for="set-invoice-note"><span data-i18n="pds_lbl_invoice_note_a4">تێبینیەکانی وەسڵ (لەسەر A4 دەرکەون)</span></label>
                            <input type="text" id="set-invoice-note" class="input-std" data-i18n-placeholder="pds_ph_invoice_note" placeholder="">
                            </div>
                        </div>
                        <div class="pds-field-ico">
                            <i class="fas fa-pen" aria-hidden="true"></i>
                            <div>
                            <label class="pds-label" for="set-custom-note"><span data-i18n="pds_lbl_custom_note">تێبینی تایبەت (لەسەر وەسڵ/ڕاپۆرت دەرکەوێت)</span></label>
                            <input type="text" id="set-custom-note" class="input-std" data-i18n-placeholder="pds_ph_custom_note" placeholder="">
                            </div>
                        </div>
                        <div class="pds-field-ico">
                            <i class="fas fa-list" aria-hidden="true"></i>
                            <div>
                            <label class="pds-label" for="set-static-note1"><span data-i18n="pds_lbl_static_notes">سێ تێبینیی جێگیر — خوارەوەی وەسڵی A4</span></label>
                            <input type="text" id="set-static-note1" class="input-std" data-i18n-placeholder="pds_ph_static_note1" placeholder="">
                            <input type="text" id="set-static-note2" class="input-std" data-i18n-placeholder="pds_ph_static_note2" placeholder="" style="margin-top:6px;">
                            <input type="text" id="set-static-note3" class="input-std" data-i18n-placeholder="pds_ph_static_note3" placeholder="" style="margin-top:6px;">
                            </div>
                        </div>
                        <div class="pds-field-ico">
                            <i class="fas fa-receipt" aria-hidden="true"></i>
                            <div>
                            <label class="pds-label" for="set-tax-number"><span data-i18n="pds_lbl_tax_number">ژمارەی باج</span></label>
                            <input type="text" id="set-tax-number" class="input-std" data-i18n-placeholder="pds_ph_tax_number" placeholder="">
                            </div>
                        </div>
                        <div class="pds-field-ico">
                            <i class="fas fa-globe" aria-hidden="true"></i>
                            <div>
                            <label class="pds-label" for="set-website"><span data-i18n="pds_lbl_website">ماڵپەر</span></label>
                            <input type="url" id="set-website" class="input-std" data-i18n-placeholder="pds_ph_website" placeholder="">
                            </div>
                        </div>
                        <div class="pds-field-ico">
                            <i class="fas fa-share-alt" aria-hidden="true"></i>
                            <div>
                            <label class="pds-label" for="set-social-links"><span data-i18n="pds_lbl_social_links">بەستەرەکانی تۆڕە کۆمەڵایەتییەکان (یەک لە هەر ڕیزێک)</span></label>
                            <textarea id="set-social-links" class="input-std" rows="3" data-i18n-placeholder="pds_ph_social_links" placeholder="" style="resize:vertical; min-height:70px;"></textarea>
                            </div>
                        </div>
                            </div>
                        </details>
                        <div class="pds-logo-upload-container" style="border: 1px solid var(--border); border-radius: 12px; padding: 16px; background: var(--input-bg); margin-top: 10px;">
                            <h4 style="margin: 0 0 16px 0; font-size: 1.05rem; color: var(--brand); border-bottom: 1px solid var(--border); padding-bottom: 8px;"><i class="fas fa-images"></i> <span data-i18n="pds_logo_section_title">ڕێکخستنی لۆگۆکان (بۆ پسوولەی بچووک و A4)</span></h4>
                            
                            <div style="margin-bottom: 20px;">
                                <label class="pds-label" style="font-weight: bold;"><span data-i18n="pds_logo_main_label">لۆگۆی سەرەکی (بۆ پسوولەی ٨٠ مم)</span></label>
                                <div style="display:flex; align-items:center; gap:12px; flex-wrap:wrap; background: var(--card); padding: 10px; border-radius: 8px; border: 1px dashed var(--border);">
                                    <input type="file" id="set-cafe-logo" class="input-std" accept="image/png, image/jpeg, image/jpg, image/webp" style="flex:1; min-width:180px; margin: 0;" onchange="handleLogoUploadWithResize(this)">
                                    <button type="button" class="btn btn-sm btn-danger" onclick="if(typeof clearReceiptLogo==='function')clearReceiptLogo();" data-i18n-title="pds_btn_remove_logo" title=""><i class="fas fa-trash-alt"></i> <span data-i18n="pds_btn_remove_logo">سڕینەوە</span></button>
                                    <span id="pds-logo-preview-wrap" style="display:none; background: #fff; padding: 4px; border-radius: 6px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);"><img id="pds-logo-preview" style="max-width:80px; max-height:50px; object-fit:contain; border-radius:4px;" alt=""></span>
                                </div>
                            </div>

                            <div style="border-top: 1px solid var(--border); padding-top: 16px;">
                                <details>
                                    <summary style="cursor:pointer; font-weight:bold; color:var(--info); margin-bottom:8px;" data-i18n="pds_a4_logos_title">ڕێکخستنی لۆگۆکانی سەرەوە بۆ پسوولەی A4</summary>
                                <p style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 12px;" data-i18n="pds_a4_logos_intro">دکاری تا سێ لۆگۆ ل سەرێ وەسڵا A4 دابنێی و شێوازێ نیشاندانا وان هەلبژێری.</p>
                                
                                <div style="margin-bottom: 16px; background: var(--card); padding: 12px; border-radius: 8px; border: 1px solid var(--border);">
                                    <label class="pds-label" style="font-size: 0.9rem;"><span data-i18n="pds_a4_layout_label">شێوازێ نیشاندانێ (Layout)</span></label>
                                    <select id="set-a4-design3-logo-layout" class="input-std" style="margin:0; font-weight: bold;" onchange="if(window.saveA4Design3LogoLayoutSetting) saveA4Design3LogoLayoutSetting();">
                                        <option value="center" data-i18n-opt="pds_a4_layout_center">لۆگۆی ناوەڕاست ب تنێ</option>
                                        <option value="left-right" data-i18n-opt="pds_a4_layout_lr">دوو لۆگۆ (چەپ + ڕاست)</option>
                                        <option value="left-center" data-i18n-opt="pds_a4_layout_lc">دوو لۆگۆ (چەپ + ناوەڕاست)</option>
                                        <option value="center-right" data-i18n-opt="pds_a4_layout_cr">دوو لۆگۆ (ناوەڕاست + ڕاست)</option>
                                        <option value="left-center-right" data-i18n-opt="pds_a4_layout_lcr">سێ لۆگۆ (چەپ + ناوەڕاست + ڕاست)</option>
                                        <option value="left" data-i18n-opt="pds_a4_layout_left">لۆگۆی چەپ ب تنێ</option>
                                        <option value="right" data-i18n-opt="pds_a4_layout_right">لۆگۆی ڕاست ب تنێ</option>
                                        <option value="none" data-i18n-opt="pds_a4_layout_none">چ لۆگۆ نیشان نەدە</option>
                                    </select>
                                </div>

                                <div style="margin-bottom: 16px; background: var(--card); padding: 12px; border-radius: 8px; border: 1px solid var(--border);">
                                    <label class="pds-label" style="font-size: 0.9rem;"><span data-i18n="pds_a4_accent_theme_label">ڕەنگی دیزاینی A4 (دیزاین ٣)</span></label>
                                    <select id="set-a4-accent-theme" class="input-std" style="margin:0; font-weight:bold;" onchange="if(window.saveA4AccentThemeSetting) saveA4AccentThemeSetting();">
                                        <option value="amber" data-i18n-opt="pds_a4_accent_amber">پرتەقاڵی / زەرد</option>
                                        <option value="navy" data-i18n-opt="pds_a4_accent_navy">شین / نیلی</option>
                                    </select>
                                </div>

                                <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap:16px;">
                                    <!-- Left Logo -->
                                    <div style="background: var(--card); padding: 12px; border-radius: 8px; border: 1px dashed var(--border); text-align: center;">
                                        <label class="pds-label" style="font-size:0.85rem; justify-content: center;"><i class="fas fa-align-left"></i> <span data-i18n="pds_logo_left">لۆگۆی چەپ</span></label>
                                        <input type="file" id="set-a4-design3-logo-left" class="input-std" accept="image/png, image/jpeg, image/jpg, image/webp" style="font-size: 0.75rem; padding: 4px; margin-bottom: 8px;" onchange="if(window.handleA4Design3SideLogoUpload) handleA4Design3SideLogoUpload(this,'left')">
                                        <div style="display:flex; flex-direction: column; align-items:center; gap:8px;">
                                            <span id="pds-a4-design3-logo-left-preview-wrap" style="display:none; background: #fff; padding: 4px; border-radius: 6px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); width: 100%; height: 60px; display: flex; align-items: center; justify-content: center;"><img id="pds-a4-design3-logo-left-preview" style="max-width:100%; max-height:100%; object-fit:contain;" alt=""></span>
                                            <button type="button" class="btn btn-sm btn-danger" style="width: 100%; padding: 4px;" onclick="if(window.clearA4Design3SideLogo) clearA4Design3SideLogo('left')"><i class="fas fa-trash-alt"></i> <span data-i18n="pds_btn_remove_logo">سڕینەوە</span></button>
                                        </div>
                                    </div>
                                    
                                    <!-- Center Logo -->
                                    <div style="background: var(--card); padding: 12px; border-radius: 8px; border: 1px dashed var(--border); text-align: center;">
                                        <label class="pds-label" style="font-size:0.85rem; justify-content: center;"><i class="fas fa-align-center"></i> <span data-i18n="pds_logo_center">لۆگۆی ناوەڕاست</span></label>
                                        <input type="file" id="set-a4-design3-logo-center" class="input-std" accept="image/png, image/jpeg, image/jpg, image/webp" style="font-size: 0.75rem; padding: 4px; margin-bottom: 8px;" onchange="if(window.handleA4Design3SideLogoUpload) handleA4Design3SideLogoUpload(this,'center')">
                                        <div style="display:flex; flex-direction: column; align-items:center; gap:8px;">
                                            <span id="pds-a4-design3-logo-center-preview-wrap" style="display:none; background: #fff; padding: 4px; border-radius: 6px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); width: 100%; height: 60px; display: flex; align-items: center; justify-content: center;"><img id="pds-a4-design3-logo-center-preview" style="max-width:100%; max-height:100%; object-fit:contain;" alt=""></span>
                                            <button type="button" class="btn btn-sm btn-danger" style="width: 100%; padding: 4px;" onclick="if(window.clearA4Design3SideLogo) clearA4Design3SideLogo('center')"><i class="fas fa-trash-alt"></i> <span data-i18n="pds_btn_remove_logo">سڕینەوە</span></button>
                                        </div>
                                    </div>
                                    
                                    <!-- Right Logo -->
                                    <div style="background: var(--card); padding: 12px; border-radius: 8px; border: 1px dashed var(--border); text-align: center;">
                                        <label class="pds-label" style="font-size:0.85rem; justify-content: center;"><i class="fas fa-align-right"></i> <span data-i18n="pds_logo_right">لۆگۆی ڕاست</span></label>
                                        <input type="file" id="set-a4-design3-logo-right" class="input-std" accept="image/png, image/jpeg, image/jpg, image/webp" style="font-size: 0.75rem; padding: 4px; margin-bottom: 8px;" onchange="if(window.handleA4Design3SideLogoUpload) handleA4Design3SideLogoUpload(this,'right')">
                                        <div style="display:flex; flex-direction: column; align-items:center; gap:8px;">
                                            <span id="pds-a4-design3-logo-right-preview-wrap" style="display:none; background: #fff; padding: 4px; border-radius: 6px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); width: 100%; height: 60px; display: flex; align-items: center; justify-content: center;"><img id="pds-a4-design3-logo-right-preview" style="max-width:100%; max-height:100%; object-fit:contain;" alt=""></span>
                                            <button type="button" class="btn btn-sm btn-danger" style="width: 100%; padding: 4px;" onclick="if(window.clearA4Design3SideLogo) clearA4Design3SideLogo('right')"><i class="fas fa-trash-alt"></i> <span data-i18n="pds_btn_remove_logo">سڕینەوە</span></button>
                                        </div>
                                    </div>
                                </div>
                                </details>
                            </div>
                        </div>
                    </div>
                    <div class="pds-receipt-preview-box pds-receipt-preview-paper">
                        <div class="pds-preview-header-row">
                            <span class="pds-preview-label" data-i18n="pds_preview_live_label">پێشبینین ڕاستەوخۆ — وەک وەسڵ لەسەر کاغەز</span>
                            <button type="button" class="btn btn-info btn-sm" onclick="if(typeof openPdsDesignPreview==='function')openPdsDesignPreview(typeof getOpenPdsDoc==='function'?getOpenPdsDoc():'pos_sale')" style="margin:0;"><i class="fas fa-expand"></i> <span data-i18n="pds_preview_full_btn">پێشبینینی تەواو</span></button>
                            <select id="pds-preview-doc" class="input-std" style="width:auto; margin:0; font-size:0.85rem;" onchange="updateReceiptPreview()">
                                <option value="pos_sale" data-i18n-opt="pds_preview_doc_sale">فرۆشتن</option>
                                <option value="proforma" data-i18n-opt="pds_preview_doc_proforma">لیست / دەمکی</option>
                            </select>
                            <select id="pds-preview-paper" class="input-std" style="width:auto; margin:0; font-size:0.85rem;" onchange="updateReceiptPreview()" data-i18n-title="pds_preview_paper_title" title="">
                                <option value="80mm" data-i18n-opt="pds_paper_sel_80">٨٠ مم (ترمەڵ)</option>
                                <option value="210mm" data-i18n-opt="pds_paper_sel_a4">A4</option>
                            </select>
                        </div>
                        <div id="pds-receipt-preview" class="pds-receipt-preview-inner preview-80mm">
                            <div id="pds-preview-logo" class="pds-preview-block"></div>
                            <div id="pds-preview-name" class="pds-preview-store-name">ناوی فرۆشگا</div>
                            <div id="pds-preview-info" class="pds-preview-info">—</div>
                            <div id="pds-preview-date" class="pds-preview-date" style="display:none;">—</div>
                            <div id="pds-preview-qr" class="pds-preview-qr" style="display:none;"></div>
                            <div id="pds-preview-footer" class="pds-preview-footer">سوپاس بۆ سەردانتان</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- نیشاندانی پۆپئەپێ ملاحظە پێش چاپ (Print Note Popup) — Pro -->
            <div id="pds-print-note-premium-card" class="card protected pds-print-note--locked" style="border-top: 5px solid var(--info); margin-bottom:24px;">
                <h3 style="margin-top:0;"><i class="fas fa-sticky-note"></i> <span data-i18n="pds_print_note_title">تێبینی پێش چاپ</span> <span class="subscription-badge subscription-badge--inline" style="font-size:0.7rem;vertical-align:middle;">PRO</span></h3>
                <p style="color:var(--text-muted); margin-bottom:8px; font-size:0.95rem;" data-i18n="pds_print_note_desc">پێش هەر چاپێک پەنجەرەیەکی پیشەیی دەکرێتەوە. تێبینی لەسەر وەسڵ بە شێوەی جوان دەردەکەوێت.</p>
                <p id="pds-print-note-pro-hint" style="color:var(--warning); margin:0 0 14px 0; font-size:0.88rem;" data-i18n="pds_print_note_pro_hint">تەنها لەگەڵ پلانی Pro ($224) — دوای چالاککردنی کۆد دەتوانیت لێرە یان پێش چاپ تێبینی بنووسیت.</p>
                <label style="display:flex; align-items:center; gap:10px; cursor:pointer; margin-bottom:12px;">
                    <input type="checkbox" id="setting-show-print-note-popup" onchange="if(window.savePrintNotePopupSetting) savePrintNotePopupSetting();">
                    <span data-i18n="pds_print_note_checkbox">نیشاندانی پەنجەرەی «تێبینی پێش چاپ» (پێشنیارکراو)</span>
                </label>
                <label style="display:flex; align-items:center; gap:10px; cursor:pointer; margin-bottom:12px;">
                    <input type="checkbox" id="set-print-invoice-barcode" checked onchange="if(window.db&&window.db.settings){window.db.settings.printInvoiceBarcode=this.checked;} if(typeof saveSettings==='function')saveSettings().catch(function(){});">
                    <span data-i18n="pds_show_invoice_barcode">نیشاندانی بارکۆدی ناسنامەی وەسڵ</span>
                </label>
                <label style="display:flex; align-items:center; gap:10px; cursor:pointer; margin-bottom:12px;">
                    <input type="checkbox" id="set-show-financial-summary-on-a4" checked onchange="if(window.db&&window.db.settings){window.db.settings.showFinancialSummaryOnA4=this.checked;} if(typeof saveSettings==='function')saveSettings().catch(function(){});">
                    <span data-i18n="pds_show_financial_summary_a4">نیشاندانی کورتەی دارایی و قەرز لە A4</span>
                </label>
                <label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
                    <input type="checkbox" id="set-show-both-currencies-on-a4" onchange="if(window.db&&window.db.settings){window.db.settings.showBothCurrenciesOnA4=this.checked;} if(typeof saveSettings==='function')saveSettings().catch(function(){});">
                    <span data-i18n="pds_show_both_currencies_a4">نیشاندانا هەردوو فەرزان د A4 دا (دینار + دۆلار)</span>
                </label>
            </div>

            
            <div class="pds-global-paper-bar card protected">
                <div class="pds-global-paper-bar__head">
                    <h3 style="margin:0;"><i class="fas fa-layer-group"></i> <span data-i18n="pds_global_paper_title">قەبارەی گشتی بۆ هەموو دیزاینەکان</span></h3>
                    <p data-i18n="pds_global_paper_desc">ب یەک کلیک هەموو وەسڵ و ڕاپۆرتەکان بگۆڕە بۆ 80mm یان A4 — دیزاینەکەش خۆکار دەگونجێت.</p>
                </div>
                <div class="pds-global-paper-bar__actions">
                    <button type="button" class="btn btn-brand" onclick="setAllPrintDesignPaper('80mm')">
                        <i class="fas fa-receipt"></i> <span data-i18n="pds_global_paper_all_80">هەموو → 80mm</span>
                    </button>
                    <button type="button" class="btn btn-info" onclick="setAllPrintDesignPaper('a4')">
                        <i class="fas fa-file-alt"></i> <span data-i18n="pds_global_paper_all_a4">هەموو → A4</span>
                    </button>
                </div>
            </div>

            <!-- Scale / product barcode label (کێش تابیعە) — size + font + printer name only here (not on product form) -->
            <div class="card protected" id="pds-label-print-card" style="border-top:5px solid #0d9488; margin-bottom:24px;">
                <h3 style="margin-top:0;"><i class="fas fa-tags"></i> دیزاینی لزگە (کێش / بارکۆد)</h3>
                <p style="color:var(--text-muted); margin:0 0 14px 0; font-size:0.92rem;">٤ دیزاین: <strong>عادی ١</strong>، <strong>عادی ٢</strong>، <strong>لۆگۆ ١</strong>، <strong>لۆگۆ ٢</strong>. ٤ قەبارێن ئامادە — یێن دی ب دوگمەی <strong>+</strong> زێدەکە.</p>
                <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(140px,1fr)); gap:12px; align-items:end;">
                    <div>
                        <label class="pds-label" for="pds-label-design">دیزاینی لزگە</label>
                        <select id="pds-label-design" class="input-std" style="margin:0;" onchange="if(typeof onLabelDesignChange==='function')onLabelDesignChange()">
                            <option value="normal">عادی ١</option>
                            <option value="normal2">عادی ٢</option>
                            <option value="logo">لۆگۆ ١</option>
                            <option value="logo2">لۆگۆ ٢</option>
                        </select>
                    </div>
                    <div>
                        <label class="pds-label" for="pds-label-width">پانی (مم)</label>
                        <input type="number" id="pds-label-width" class="input-std" min="20" max="120" step="1" value="40" dir="ltr" style="margin:0;" oninput="if(typeof persistLabelPrintSettings==='function')persistLabelPrintSettings(); if(typeof updateLabelPrintPreview==='function')updateLabelPrintPreview()">
                    </div>
                    <div>
                        <label class="pds-label" for="pds-label-height">درێژی (مم)</label>
                        <input type="number" id="pds-label-height" class="input-std" min="15" max="100" step="1" value="60" dir="ltr" style="margin:0;" oninput="if(typeof persistLabelPrintSettings==='function')persistLabelPrintSettings(); if(typeof updateLabelPrintPreview==='function')updateLabelPrintPreview()">
                    </div>
                    <div>
                        <label class="pds-label" for="pds-label-preset">قەبارەی ئامادە (٤ ئەساسی)</label>
                        <div style="display:flex; gap:6px; align-items:stretch;">
                            <select id="pds-label-preset" class="input-std" style="margin:0; flex:1;" onchange="if(typeof applyLabelSizePreset==='function')applyLabelSizePreset(this.value); if(typeof persistLabelPrintSettings==='function')persistLabelPrintSettings()">
                                <option value="40x60" selected>40 × 60 مم (درێژ)</option>
                                <option value="38x54">38 × 54 مم (درێژ)</option>
                                <option value="50x30">50 × 30 مم</option>
                                <option value="38x25">38 × 25 مم</option>
                            </select>
                            <button type="button" class="btn btn-sm btn-info" onclick="if(typeof addCurrentLabelSizePreset==='function')addCurrentLabelSizePreset()" title="قەبارێ یا نوکە زێدەکە">+</button>
                            <button type="button" class="btn btn-sm btn-dark" onclick="if(typeof removeSelectedLabelSizePreset==='function')removeSelectedLabelSizePreset()" title="قەبارێ یا من ڕابکە">−</button>
                        </div>
                    </div>
                    <div>
                        <label class="pds-label" for="pds-label-name-scale">فۆنتی ناڤ (١–٢٠)</label>
                        <input type="number" id="pds-label-name-scale" class="input-std" min="1" max="20" step="1" value="10" dir="ltr" style="margin:0;" oninput="if(typeof persistLabelPrintSettings==='function')persistLabelPrintSettings(); if(typeof updateLabelPrintPreview==='function')updateLabelPrintPreview()">
                    </div>
                    <div>
                        <label class="pds-label" for="pds-label-price-scale">فۆنتی نرخ (١–٢٠)</label>
                        <input type="number" id="pds-label-price-scale" class="input-std" min="1" max="20" step="1" value="10" dir="ltr" style="margin:0;" oninput="if(typeof persistLabelPrintSettings==='function')persistLabelPrintSettings(); if(typeof updateLabelPrintPreview==='function')updateLabelPrintPreview()">
                    </div>
                    <div>
                        <label class="pds-label" for="pds-label-font">فۆنتی گشتی</label>
                        <select id="pds-label-font" class="input-std" style="margin:0;" onchange="if(typeof persistLabelPrintSettings==='function')persistLabelPrintSettings(); if(typeof updateLabelPrintPreview==='function')updateLabelPrintPreview()">
                            <option value="small">بچووک</option>
                            <option value="medium" selected>ناوەند</option>
                            <option value="large">گەورە</option>
                            <option value="xlarge">زۆر گەورە</option>
                        </select>
                    </div>
                    <div style="grid-column:1 / -1;">
                        <label class="pds-label" for="pds-label-printer-select">ناوی پرینتەری لزگە</label>
                        <div style="display:flex; gap:8px; align-items:stretch;">
                            <select id="pds-label-printer-select" class="input-std" dir="ltr" style="margin:0; flex:1;" onchange="if(typeof onLabelPrinterSelectChange==='function')onLabelPrinterSelectChange(); if(typeof updateLabelPrintPreview==='function')updateLabelPrintPreview()">
                                <option value="">— هەڵبژێرە —</option>
                            </select>
                            <button type="button" class="btn btn-sm btn-dark" onclick="if(typeof refreshLabelPrinterList==='function')refreshLabelPrinterList()" title="نوێکرنا لیستا پرینتەرێن ویندۆز"><i class="fas fa-sync-alt"></i></button>
                        </div>
                        <small style="display:block; margin-top:6px; color:var(--text-muted); font-size:0.82rem;">حەجم: پانی و درێژی (مم). فۆنتی ناڤ و فۆنتی نرخ ژمارە مەزنتر = نڤیسین گەورەتر. پیشاندەر ل خوارێ ببینە.</small>
                    </div>
                    <div style="display:flex; flex-wrap:wrap; gap:14px; align-items:center; grid-column:1 / -1;">
                        <label style="display:flex; align-items:center; gap:6px; margin:0;"><input type="checkbox" id="pds-label-show-name" checked onchange="if(typeof persistLabelPrintSettings==='function')persistLabelPrintSettings(); if(typeof updateLabelPrintPreview==='function')updateLabelPrintPreview()"> ناڤێ ئایتم</label>
                        <label style="display:flex; align-items:center; gap:6px; margin:0;"><input type="checkbox" id="pds-label-show-price" checked onchange="if(typeof persistLabelPrintSettings==='function')persistLabelPrintSettings(); if(typeof updateLabelPrintPreview==='function')updateLabelPrintPreview()"> نرخ</label>
                        <label style="display:flex; align-items:center; gap:6px; margin:0;"><input type="checkbox" id="pds-label-show-barcode" checked onchange="if(typeof persistLabelPrintSettings==='function')persistLabelPrintSettings(); if(typeof updateLabelPrintPreview==='function')updateLabelPrintPreview()"> بارکۆد</label>
                        <label style="display:flex; align-items:center; gap:6px; margin:0;">ژمارا کۆپی: <input type="number" id="pds-label-copies" class="input-std" min="1" max="50" value="1" dir="ltr" style="width:70px; margin:0;" onchange="if(typeof persistLabelPrintSettings==='function')persistLabelPrintSettings()"></label>
                    </div>
                </div>
                <div style="margin-top:14px; display:flex; flex-wrap:wrap; gap:12px; align-items:flex-start;">
                    <div id="pds-label-preview" style="flex:0 0 auto; border:1px dashed #94a3b8; border-radius:8px; background:#fff; color:#0f172a; overflow:hidden; box-shadow:0 2px 8px rgba(0,0,0,0.08);"></div>
                    <div style="flex:1; min-width:180px;">
                        <button type="button" class="btn btn-info btn-sm" onclick="if(typeof testPrintProductLabel==='function')testPrintProductLabel()"><i class="fas fa-print"></i> تاقیکرنا چاپا لزگە</button>
                        <button type="button" class="btn btn-dark btn-sm" style="margin-right:6px;" onclick="if(typeof checkLabelPrintAgentStatus==='function')checkLabelPrintAgentStatus(true)"><i class="fas fa-plug"></i> دۆخی Agent</button>
                        <p id="pds-label-agent-status" style="margin:8px 0 0; font-size:0.85rem; color:var(--text-muted);">بۆ چاپا بێ شاشە: <code>Start_POS.bat</code> بکەرەوە (Agent دەستپێدکات).</p>
                    </div>
                </div>
            </div>

            <div id="pds-cards-grid" class="pds-cards-grid protected">
                <!-- فرۆتنێن POS - هەمان ئایکۆنێ شاشا سەرەکی (عەرەبانا کڕینێ) -->
                <div class="pds-card" data-doc="pos_sale" onclick="togglePdsCard('pos_sale')">
                    <div class="pds-card-inner">
                        <div class="pds-card-icon"><i class="fas fa-cart-plus"></i></div>
                        <div class="pds-card-title" data-i18n="pds_card_pos_sale_title">پسوولەی فرۆشتن</div>
                        <div class="pds-card-desc" data-i18n="pds_card_pos_sale_desc">پشتی پارەدان (خاڵی فرۆشتن)</div>
                        <div class="pds-card-options" id="pds-options-pos_sale" onclick="event.stopPropagation()">
                            <label><span data-i18n="pds_lbl_printer_route">پرێنتەر</span></label>
                            <select id="pds-pos_sale-printer" class="input-std pds-printer-select"><option value="" data-i18n-opt="pds_printer_routing_default">— بنەڕەتی سیستەم</option></select>
                            <label><span data-i18n="pds_lbl_paper_size">قەبارەی کاغەز</span></label>
                            <select id="pds-pos_sale-paper" class="input-std" onchange="pdsOnPaperChange('pos_sale')">
                                <option value="80mm" data-i18n-opt="pds_paper_sel_80">٨٠ مم (ترمەڵ)</option>
                                <option value="210mm" data-i18n-opt="pds_paper_sel_a4">A4</option>
                            </select>
                            <label><span data-i18n="pds_lbl_design">دیزاین</span></label>
                            <select id="pds-pos_sale-design" class="input-std" data-i18n-title="pds_lbl_design" title="" onchange="updateReceiptPreview()">
                                <option value="1" data-i18n-opt="pds_d_a4_1">A4: دیزاین ١</option>
                                <option value="2" data-i18n-opt="pds_d_a4_2">A4: دیزاین ٢</option>
                                <option value="8" data-i18n-opt="pds_d_a4_3">A4: دیزاین ٣</option>
                                <option value="7" data-i18n-opt="pds_paper_sel_80">٨٠ مم (ترمەڵ)</option>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- وەسڵا دەمکی -->
                <div class="pds-card" data-doc="proforma" onclick="togglePdsCard('proforma')">
                    <div class="pds-card-inner">
                        <div class="pds-card-icon"><i class="fas fa-receipt"></i></div>
                        <div class="pds-card-title" data-i18n="pds_card_proforma_title">وەسڵی دەمکی</div>
                        <div class="pds-card-desc" data-i18n="pds_card_proforma_desc">پێش پارەدان (ژمێریار)</div>
                        <div class="pds-card-options" id="pds-options-proforma" onclick="event.stopPropagation()">
                            <label><span data-i18n="pds_lbl_printer_route">پرێنتەر</span></label>
                            <select id="pds-proforma-printer" class="input-std pds-printer-select"><option value="" data-i18n-opt="pds_printer_routing_default">— بنەڕەتی سیستەم</option></select>
                            <label><span data-i18n="pds_lbl_paper_size">قەبارەی کاغەز</span></label>
                            <select id="pds-proforma-paper" class="input-std" onchange="pdsOnPaperChange('proforma')">
                                <option value="80mm" data-i18n-opt="pds_paper_sel_80">٨٠ مم (ترمەڵ)</option>
                                <option value="210mm" data-i18n-opt="pds_paper_sel_a4">A4</option>
                            </select>
                            <label><span data-i18n="pds_lbl_design">دیزاین</span></label>
                            <select id="pds-proforma-design" class="input-std" onchange="updateReceiptPreview()">
                                <option value="same_pos_sale" data-i18n-opt="pds_d_same_pos_sale">هەمان دیزاینی فرۆشتن</option>
                                <option value="1" data-i18n-opt="pds_d_a4_1">A4: دیزاین ١</option>
                                <option value="2" data-i18n-opt="pds_d_a4_2">A4: دیزاین ٢</option>
                                <option value="8" data-i18n-opt="pds_d_a4_3">A4: دیزاین ٣</option>
                                <option value="7" data-i18n-opt="pds_paper_sel_80">٨٠ مم (ترمەڵ)</option>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- چاپا چایخانێ - ئایکۆنێ چایخانێ -->
                <div class="pds-card" data-doc="kitchen_slip" onclick="togglePdsCard('kitchen_slip')">
                    <div class="pds-card-inner">
                        <div class="pds-card-icon"><i class="fas fa-utensils"></i></div>
                        <div class="pds-card-title" data-i18n="pds_card_kitchen_title">چاپی چایخانە</div>
                        <div class="pds-card-desc" data-i18n="pds_card_kitchen_desc">چایخانە</div>
                        <div class="pds-card-options" id="pds-options-kitchen_slip" onclick="event.stopPropagation()">
                            <label><span data-i18n="pds_lbl_printer_route">پرێنتەر</span></label>
                            <select id="pds-kitchen_slip-printer" class="input-std pds-printer-select"><option value="" data-i18n-opt="pds_printer_routing_default">— بنەڕەتی سیستەم</option></select>
                            <label><span data-i18n="pds_lbl_paper_size">قەبارەی کاغەز</span></label>
                            <select id="pds-kitchen_slip-paper" class="input-std">
                                <option value="80mm" data-i18n-opt="pds_paper_sel_80">٨٠ مم (ترمەڵ)</option>
                            </select>
                            <label><span data-i18n="pds_lbl_design">دیزاین</span></label>
                            <select id="pds-kitchen_slip-design" class="input-std">
                                <option value="1" data-i18n-opt="pds_d_a4_1">A4: دیزاین ١</option>
                                <option value="2" data-i18n-opt="pds_d_a4_2">A4: دیزاین ٢</option>
                                <option value="3" data-i18n-opt="pds_d_80_thermal">٨٠ مم: پسوولە (ترمەڵ)</option>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- پسولەیا زڤڕاندنێ -->
                <div class="pds-card" data-doc="return_receipt" onclick="togglePdsCard('return_receipt')">
                    <div class="pds-card-inner">
                        <div class="pds-card-icon"><i class="fas fa-undo"></i></div>
                        <div class="pds-card-title" data-i18n="pds_card_return_title">پسولەیا زڤڕاندنێ</div>
                        <div class="pds-card-desc" data-i18n="pds_card_return_desc">زڤڕاندنەوە</div>
                        <div class="pds-card-options" id="pds-options-return_receipt" onclick="event.stopPropagation()">
                            <label><span data-i18n="pds_lbl_printer_route">پرێنتەر</span></label>
                            <select id="pds-return_receipt-printer" class="input-std pds-printer-select"><option value="" data-i18n-opt="pds_printer_routing_default">— بنەڕەتی سیستەم</option></select>
                            <label><span data-i18n="pds_lbl_paper_size">قەبارەی کاغەز</span></label>
                            <select id="pds-return_receipt-paper" class="input-std">
                                <option value="80mm" data-i18n-opt="pds_paper_sel_80">٨٠ مم (ترمەڵ)</option>
                                <option value="210mm" data-i18n-opt="pds_paper_sel_a4">A4</option>
                            </select>
                            <label><span data-i18n="pds_lbl_design">دیزاین</span></label>
                            <select id="pds-return_receipt-design" class="input-std">
                                <option value="1" data-i18n-opt="pds_d_a4_1">A4: دیزاین ١</option>
                                <option value="2" data-i18n-opt="pds_d_a4_2">A4: دیزاین ٢</option>
                                <option value="3" data-i18n-opt="pds_d_80_thermal">٨٠ مم: پسوولە (ترمەڵ)</option>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- پسولەیا گەهاندنێ - ئایکۆنێ بارهەلگری -->
                <div class="pds-card" data-doc="delivery_slip" onclick="togglePdsCard('delivery_slip')">
                    <div class="pds-card-inner">
                        <div class="pds-card-icon"><i class="fas fa-truck"></i></div>
                        <div class="pds-card-title" data-i18n="pds_card_delivery_title">پسولەیا گەهاندنێ</div>
                        <div class="pds-card-desc" data-i18n="pds_card_delivery_desc">گەهاندن</div>
                        <div class="pds-card-options" id="pds-options-delivery_slip" onclick="event.stopPropagation()">
                            <label><span data-i18n="pds_lbl_printer_route">پرێنتەر</span></label>
                            <select id="pds-delivery_slip-printer" class="input-std pds-printer-select"><option value="" data-i18n-opt="pds_printer_routing_default">— بنەڕەتی سیستەم</option></select>
                            <label><span data-i18n="pds_lbl_paper_size">قەبارەی کاغەز</span></label>
                            <select id="pds-delivery_slip-paper" class="input-std">
                                <option value="80mm" data-i18n-opt="pds_paper_sel_80">٨٠ مم (ترمەڵ)</option>
                                <option value="210mm" data-i18n-opt="pds_paper_sel_a4">A4</option>
                            </select>
                            <label><span data-i18n="pds_lbl_design">دیزاین</span></label>
                            <select id="pds-delivery_slip-design" class="input-std">
                                <option value="1" data-i18n-opt="pds_d_a4_1">A4: دیزاین ١</option>
                                <option value="2" data-i18n-opt="pds_d_a4_2">A4: دیزاین ٢</option>
                                <option value="3" data-i18n-opt="pds_d_80_thermal">٨٠ مم: پسوولە (ترمەڵ)</option>
                            </select>
                        </div>
                    </div>
                </div>
                <details class="pds-cards-more card protected" style="margin-top:16px; border:1px dashed var(--border); border-radius:12px; padding:12px 16px;">
                    <summary style="cursor:pointer; font-weight:600; color:var(--text-muted); padding:4px 0;" data-i18n="pds_cards_more_summary">ڕاپۆرت و تر (ئیختیاری — ئەگەر پێویست بێت)</summary>
                    <div class="pds-cards-grid" style="margin-top:12px;">
                <!-- ڕاپۆرتێن پێداچوون/جەردی - ئایکۆنێ کۆگەهێ/سندوقێ -->
                <div class="pds-card" data-doc="inventory_report" onclick="togglePdsCard('inventory_report')">
                    <div class="pds-card-inner">
                        <div class="pds-card-icon"><i class="fas fa-warehouse"></i></div>
                        <div class="pds-card-title" data-i18n="pds_card_inventory_title">ڕاپۆرتی پێداچوونەوە/جەرد</div>
                        <div class="pds-card-desc" data-i18n="pds_card_inventory_desc">کۆگەه</div>
                        <div class="pds-card-options" id="pds-options-inventory_report" onclick="event.stopPropagation()">
                            <label><span data-i18n="pds_lbl_printer_route">پرێنتەر</span></label>
                            <select id="pds-inventory_report-printer" class="input-std pds-printer-select"><option value="" data-i18n-opt="pds_printer_routing_default">— بنەڕەتی سیستەم</option></select>
                            <label><span data-i18n="pds_lbl_paper_size">قەبارەی کاغەز</span></label>
                            <select id="pds-inventory_report-paper" class="input-std">
                                <option value="210mm" data-i18n-opt="pds_paper_sel_a4">A4</option>
                                <option value="80mm" data-i18n-opt="pds_paper_sel_80">٨٠ مم (ترمەڵ)</option>
                            </select>
                            <label><span data-i18n="pds_lbl_design">دیزاین</span></label>
                            <select id="pds-inventory_report-design" class="input-std">
                                <option value="same_proforma" data-i18n-opt="pds_d_same_proforma">هەمان دیزاینی لیستا فرۆشتن (لیست)</option>
                                <option value="1" data-i18n-opt="pds_d_a4_1">A4: دیزاین ١</option>
                                <option value="2" data-i18n-opt="pds_d_a4_2">A4: دیزاین ٢</option>
                                <option value="3" data-i18n-opt="pds_d_80_thermal">٨٠ مم: پسوولە (ترمەڵ)</option>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- تۆمارا لڤینێن کۆگەهێ (Stock Movement Log) -->
                <div class="pds-card" data-doc="stock_movement_log" onclick="togglePdsCard('stock_movement_log')">
                    <div class="pds-card-inner">
                        <div class="pds-card-icon"><i class="fas fa-exchange-alt"></i></div>
                        <div class="pds-card-title" data-i18n="pds_card_stock_movement_title">تۆماری جوڵەی کۆگەه</div>
                        <div class="pds-card-desc" data-i18n="pds_card_stock_movement_desc">هاتن / چوون / تێکچوون</div>
                        <div class="pds-card-options" id="pds-options-stock_movement_log" onclick="event.stopPropagation()">
                            <label><span data-i18n="pds_lbl_printer_route">پرێنتەر</span></label>
                            <select id="pds-stock_movement_log-printer" class="input-std pds-printer-select"><option value="" data-i18n-opt="pds_printer_routing_default">— بنەڕەتی سیستەم</option></select>
                            <label><span data-i18n="pds_lbl_paper_size">قەبارەی کاغەز</span></label>
                            <select id="pds-stock_movement_log-paper" class="input-std">
                                <option value="210mm" data-i18n-opt="pds_paper_sel_a4">A4</option>
                                <option value="80mm" data-i18n-opt="pds_paper_sel_80">٨٠ مم (ترمەڵ)</option>
                            </select>
                            <label><span data-i18n="pds_lbl_design">دیزاین</span></label>
                            <select id="pds-stock_movement_log-design" class="input-std">
                                <option value="1" data-i18n-opt="pds_d_a4_1">A4: دیزاین ١</option>
                                <option value="2" data-i18n-opt="pds_d_a4_2">A4: دیزاین ٢</option>
                                <option value="3" data-i18n-opt="pds_d_80_thermal">٨٠ مم: پسوولە (ترمەڵ)</option>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- گواستنەوەی کۆگە (Stock Transfer) -->
                <div class="pds-card" data-doc="stock_transfer_report" onclick="togglePdsCard('stock_transfer_report')">
                    <div class="pds-card-inner">
                        <div class="pds-card-icon"><i class="fas fa-dolly"></i></div>
                        <div class="pds-card-title" data-i18n="pds_card_stock_transfer_title">گواستنەوەی کۆگە</div>
                        <div class="pds-card-desc" data-i18n="pds_card_stock_transfer_desc">وەسڵا گواستنەوە — ٨٠مم / A4</div>
                        <div class="pds-card-options" id="pds-options-stock_transfer_report" onclick="event.stopPropagation()">
                            <label><span data-i18n="pds_lbl_printer_route">پرێنتەر</span></label>
                            <select id="pds-stock_transfer_report-printer" class="input-std pds-printer-select"><option value="" data-i18n-opt="pds_printer_routing_default">— بنەڕەتی سیستەم</option></select>
                            <label><span data-i18n="pds_lbl_paper_size">قەبارەی کاغەز</span></label>
                            <select id="pds-stock_transfer_report-paper" class="input-std">
                                <option value="80mm" data-i18n-opt="pds_paper_sel_80">٨٠ مم (ترمەڵ)</option>
                                <option value="210mm" data-i18n-opt="pds_paper_sel_a4">A4</option>
                            </select>
                            <label><span data-i18n="pds_lbl_design">دیزاین</span></label>
                            <select id="pds-stock_transfer_report-design" class="input-std">
                                <option value="1" data-i18n-opt="pds_d_a4_1">A4: دیزاین ١</option>
                                <option value="2" data-i18n-opt="pds_d_a4_2">A4: دیزاین ٢</option>
                                <option value="3" data-i18n-opt="pds_d_80_thermal">٨٠ مم: پسوولە (ترمەڵ)</option>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- لیستێن قەرزان - ئایکۆنێ دەفتەرێ -->
                <div class="pds-card" data-doc="debt_list" onclick="togglePdsCard('debt_list')">
                    <div class="pds-card-inner">
                        <div class="pds-card-icon"><i class="fas fa-book"></i></div>
                        <div class="pds-card-title" data-i18n="pds_card_debt_list_title">لیستی قەرز</div>
                        <div class="pds-card-desc" data-i18n="pds_card_debt_list_desc">دەفتەری قەرز</div>
                        <div class="pds-card-options" id="pds-options-debt_list" onclick="event.stopPropagation()">
                            <label><span data-i18n="pds_lbl_printer_route">پرێنتەر</span></label>
                            <select id="pds-debt_list-printer" class="input-std pds-printer-select"><option value="" data-i18n-opt="pds_printer_routing_default">— بنەڕەتی سیستەم</option></select>
                            <label><span data-i18n="pds_lbl_paper_size">قەبارەی کاغەز</span></label>
                            <select id="pds-debt_list-paper" class="input-std">
                                <option value="210mm" data-i18n-opt="pds_paper_sel_a4">A4</option>
                                <option value="80mm" data-i18n-opt="pds_paper_sel_80">٨٠ مم (ترمەڵ)</option>
                            </select>
                            <label><span data-i18n="pds_lbl_design">دیزاین</span></label>
                            <select id="pds-debt_list-design" class="input-std">
                                <option value="1" data-i18n-opt="pds_d_a4_1">A4: دیزاین ١</option>
                                <option value="2" data-i18n-opt="pds_d_a4_2">A4: دیزاین ٢</option>
                                <option value="3" data-i18n-opt="pds_d_80_thermal">٨٠ مم: پسوولە (ترمەڵ)</option>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- دەفتەرا حیساباتێن کۆمپانیان -->
                <div class="pds-card" data-doc="company_ledger" onclick="togglePdsCard('company_ledger')">
                    <div class="pds-card-inner">
                        <div class="pds-card-icon"><i class="fas fa-building"></i></div>
                        <div class="pds-card-title" data-i18n="pds_card_company_ledger_title">دەفتەری کۆمپانیا</div>
                        <div class="pds-card-desc" data-i18n="pds_card_company_ledger_desc">کۆمپانیا (حسابات)</div>
                        <div class="pds-card-options" id="pds-options-company_ledger" onclick="event.stopPropagation()">
                            <label><span data-i18n="pds_lbl_printer_route">پرێنتەر</span></label>
                            <select id="pds-company_ledger-printer" class="input-std pds-printer-select"><option value="" data-i18n-opt="pds_printer_routing_default">— بنەڕەتی سیستەم</option></select>
                            <label><span data-i18n="pds_lbl_paper_size">قەبارەی کاغەز</span></label>
                            <select id="pds-company_ledger-paper" class="input-std">
                                <option value="210mm" data-i18n-opt="pds_paper_sel_a4">A4</option>
                                <option value="80mm" data-i18n-opt="pds_paper_sel_80">٨٠ مم (ترمەڵ)</option>
                            </select>
                            <label><span data-i18n="pds_lbl_design">دیزاین</span></label>
                            <select id="pds-company_ledger-design" class="input-std">
                                <option value="1" data-i18n-opt="pds_d_a4_1">A4: دیزاین ١</option>
                                <option value="2" data-i18n-opt="pds_d_a4_2">A4: دیزاین ٢</option>
                                <option value="3" data-i18n-opt="pds_d_80_thermal">٨٠ مم: پسوولە (ترمەڵ)</option>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- پێداچوون/جەردێ کڕیاری -->
                <div class="pds-card" data-doc="customer_ledger" onclick="togglePdsCard('customer_ledger')">
                    <div class="pds-card-inner">
                        <div class="pds-card-icon"><i class="fas fa-user-tag"></i></div>
                        <div class="pds-card-title" data-i18n="pds_card_customer_ledger_title">جەردێ کڕیاری</div>
                        <div class="pds-card-desc" data-i18n="pds_card_customer_ledger_desc">پێداچوون/جەردێ پارەدان و قەرزان</div>
                        <div class="pds-card-options" id="pds-options-customer_ledger" onclick="event.stopPropagation()">
                            <label><span data-i18n="pds_lbl_printer_route">پرێنتەر</span></label>
                            <select id="pds-customer_ledger-printer" class="input-std pds-printer-select"><option value="" data-i18n-opt="pds_printer_routing_default">— بنەڕەتی سیستەم</option></select>
                            <label><span data-i18n="pds_lbl_paper_size">قەبارەی کاغەز</span></label>
                            <select id="pds-customer_ledger-paper" class="input-std">
                                <option value="80mm" data-i18n-opt="pds_paper_sel_80">٨٠ مم (ترمەڵ)</option>
                                <option value="210mm" data-i18n-opt="pds_paper_sel_a4">A4</option>
                            </select>
                            <label><span data-i18n="pds_lbl_design">دیزاین</span></label>
                            <select id="pds-customer_ledger-design" class="input-std">
                                <option value="1" data-i18n-opt="pds_d_a4_1">A4: دیزاین ١</option>
                                <option value="2" data-i18n-opt="pds_d_a4_2">A4: دیزاین ٢</option>
                                <option value="3" data-i18n-opt="pds_d_80_thermal">٨٠ مم: پسوولە (ترمەڵ)</option>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- ڕاپۆرتێن مەزاختنان - ئایکۆنێ جزدانی -->
                <div class="pds-card" data-doc="expenses_report" onclick="togglePdsCard('expenses_report')">
                    <div class="pds-card-inner">
                        <div class="pds-card-icon"><i class="fas fa-wallet"></i></div>
                        <div class="pds-card-title" data-i18n="pds_card_expenses_report_title">ڕاپۆرتی مەسروفات</div>
                        <div class="pds-card-desc" data-i18n="pds_card_expenses_report_desc">مەسروفات</div>
                        <div class="pds-card-options" id="pds-options-expenses_report" onclick="event.stopPropagation()">
                            <label><span data-i18n="pds_lbl_printer_route">پرێنتەر</span></label>
                            <select id="pds-expenses_report-printer" class="input-std pds-printer-select"><option value="" data-i18n-opt="pds_printer_routing_default">— بنەڕەتی سیستەم</option></select>
                            <label><span data-i18n="pds_lbl_paper_size">قەبارەی کاغەز</span></label>
                            <select id="pds-expenses_report-paper" class="input-std">
                                <option value="210mm" data-i18n-opt="pds_paper_sel_a4">A4</option>
                                <option value="80mm" data-i18n-opt="pds_paper_sel_80">٨٠ مم (ترمەڵ)</option>
                            </select>
                            <label><span data-i18n="pds_lbl_design">دیزاین</span></label>
                            <select id="pds-expenses_report-design" class="input-std">
                                <option value="1" data-i18n-opt="pds_d_a4_1">A4: دیزاین ١</option>
                                <option value="2" data-i18n-opt="pds_d_a4_2">A4: دیزاین ٢</option>
                                <option value="3" data-i18n-opt="pds_d_80_thermal">٨٠ مم: پسوولە (ترمەڵ)</option>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- ڕاپۆرتا ڕۆژانە/هەیڤانە - ئایکۆنێ ڕاپۆرتان -->
                <div class="pds-card" data-doc="daily_monthly_report" onclick="togglePdsCard('daily_monthly_report')">
                    <div class="pds-card-inner">
                        <div class="pds-card-icon"><i class="fas fa-file-invoice-dollar"></i></div>
                        <div class="pds-card-title" data-i18n="pds_card_daily_monthly_title">ڕاپۆرتی ڕۆژانە/مانگانە</div>
                        <div class="pds-card-desc" data-i18n="pds_card_daily_monthly_desc">ڕاپۆرت</div>
                        <div class="pds-card-options" id="pds-options-daily_monthly_report" onclick="event.stopPropagation()">
                            <label><span data-i18n="pds_lbl_printer_route">پرێنتەر</span></label>
                            <select id="pds-daily_monthly_report-printer" class="input-std pds-printer-select"><option value="" data-i18n-opt="pds_printer_routing_default">— بنەڕەتی سیستەم</option></select>
                            <label><span data-i18n="pds_lbl_paper_size">قەبارەی کاغەز</span></label>
                            <select id="pds-daily_monthly_report-paper" class="input-std">
                                <option value="210mm" data-i18n-opt="pds_paper_sel_a4">A4</option>
                                <option value="80mm" data-i18n-opt="pds_paper_sel_80">٨٠ مم (ترمەڵ)</option>
                            </select>
                            <label><span data-i18n="pds_lbl_design">دیزاین</span></label>
                            <select id="pds-daily_monthly_report-design" class="input-std">
                                <option value="1" data-i18n-opt="pds_d_a4_1">A4: دیزاین ١</option>
                                <option value="2" data-i18n-opt="pds_d_a4_2">A4: دیزاین ٢</option>
                                <option value="3" data-i18n-opt="pds_d_80_thermal">٨٠ مم: پسوولە (ترمەڵ)</option>
                            </select>
                        </div>
                    </div>
                </div>
                    </div>
                </details>
                <!-- وەسڵا کڕینێ (New) -->
                <div class="pds-card" data-doc="purchase_invoice" onclick="togglePdsCard('purchase_invoice')">
                    <div class="pds-card-inner">
                        <div class="pds-card-icon"><i class="fas fa-cart-shopping"></i></div>
                        <div class="pds-card-title" data-i18n="pds_card_purchase_invoice_title">وەسڵی کڕین</div>
                        <div class="pds-card-desc" data-i18n="pds_card_purchase_invoice_desc">کڕین لە کۆمپانیا</div>
                        <div class="pds-card-options" id="pds-options-purchase_invoice" onclick="event.stopPropagation()">
                            <label><span data-i18n="pds_lbl_printer_route">پرێنتەر</span></label>
                            <select id="pds-purchase_invoice-printer" class="input-std pds-printer-select"><option value="" data-i18n-opt="pds_printer_routing_default">— بنەڕەتی سیستەم</option></select>
                            <label><span data-i18n="pds_lbl_paper_size">قەبارەی کاغەز</span></label>
                            <select id="pds-purchase_invoice-paper" class="input-std">
                                <option value="80mm" data-i18n-opt="pds_paper_sel_80">٨٠ مم (ترمەڵ)</option>
                                <option value="210mm" data-i18n-opt="pds_paper_sel_a4">A4</option>
                            </select>
                            <label><span data-i18n="pds_lbl_design">دیزاین</span></label>
                            <select id="pds-purchase_invoice-design" class="input-std" data-i18n-title="pds_lbl_design" title="">
                                <option value="1" data-i18n-opt="pds_d_a4_1">A4: دیزاین ١ (کۆمپانیا)</option>
                                <option value="2" data-i18n-opt="pds_d_a4_2">A4: دیزاین ٢ (کۆمپانیا)</option>
                                <option value="8" data-i18n-opt="pds_d_a4_3">A4: دیزاین ٣ (کۆمپانیا)</option>
                                <option value="3" data-i18n-opt="pds_d_80_thermal">٨٠ مم: پسوولە (ترمەڵ)</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

            <div style="margin-top:28px; display:flex; flex-wrap:wrap; gap:12px; align-items:center;">
                <button type="button" class="btn btn-info" style="padding:14px 24px; font-size:1.05rem;" onclick="if(typeof openPdsDesignPreview==='function')openPdsDesignPreview(typeof getOpenPdsDoc==='function'?getOpenPdsDoc():'pos_sale')"><i class="fas fa-eye"></i> <span data-i18n="pds_preview_design_btn">پێشبینینی دیزاین</span></button>
                <button class="btn btn-success" style="padding:14px 28px; font-size:1.1rem;" onclick="savePrintDesignSettings()"><i class="fas fa-save"></i> <span data-i18n="pds_save_all_print">پاراستنی هەموو</span></button>
                <span style="color:var(--text-muted); font-size:0.95rem;" data-i18n="pds_save_hint">پێش پاشەکەوت «پێشبینین» بکە ← پاشان پاشەکەوت بکە</span>
            </div>

            <div id="pds-design-preview-modal" class="pds-design-preview-modal" style="display:none;" onclick="if(event.target===this&&typeof closePdsDesignPreview==='function')closePdsDesignPreview()">
                <div class="pds-design-preview-dialog" role="dialog" aria-modal="true" aria-labelledby="pds-design-preview-title">
                    <div class="pds-design-preview-dialog__head">
                        <div>
                            <h3 id="pds-design-preview-title"><i class="fas fa-eye"></i> <span data-i18n="pds_preview_modal_title">پێشبینینی دیزاین</span></h3>
                            <p id="pds-design-preview-meta" class="pds-design-preview-meta"></p>
                        </div>
                        <button type="button" class="btn btn-danger btn-sm" onclick="if(typeof closePdsDesignPreview==='function')closePdsDesignPreview()" data-i18n-title="pds_preview_close" title=""><i class="fas fa-times"></i></button>
                    </div>
                    <p class="pds-design-preview-dialog__note"><i class="fas fa-info-circle"></i> <span data-i18n="pds_preview_unsaved_note">ئەم پێشبینینە لە ڕێکخستنەکانی ئێستاتە — پێش پاشەکەوت. ئەگەر باشە «پاشەکەوت» بکە.</span></p>
                    <div id="pds-design-preview-variants" class="pds-design-preview-variants" style="display:none;"></div>
                    <div id="pds-design-preview-body" class="pds-design-preview-dialog__body"></div>
                    <div class="pds-design-preview-dialog__foot">
                        <button type="button" class="btn btn-info" onclick="if(typeof printPdsDesignPreview==='function')printPdsDesignPreview()"><i class="fas fa-print"></i> <span data-i18n="pds_preview_print_btn">چاپی تاقیکردنەوە</span></button>
                        <button type="button" class="btn btn-success" onclick="if(typeof closePdsDesignPreview==='function')closePdsDesignPreview(); if(typeof savePrintDesignSettings==='function')savePrintDesignSettings();"><i class="fas fa-save"></i> <span data-i18n="pds_preview_save_close">پاشەکەوت و داخستن</span></button>
                        <button type="button" class="btn btn-secondary" onclick="if(typeof closePdsDesignPreview==='function')closePdsDesignPreview()"><span data-i18n="pds_preview_close">داخستن</span></button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- لیستا لایێ ڕاستێ (ب وردەکاری - ئایکۆن + نڤیسین) -->
    <aside id="right-sidebar" class="right-sidebar">
        <div class="right-sidebar-user">
            <div class="user-avatar"><i class="fas fa-user"></i></div>
            <span id="right-sidebar-user-name" class="user-name">مدير (admin)</span>
            <a class="user-profile-link" href="javascript:void(0)" onclick="if(typeof openCurrentUserProfile==='function'){openCurrentUserProfile();}else{nav('staff')}" id="right-sidebar-profile-link"><span data-i18n="profile_view_link">View Profile</span></a>
        </div>
        <div id="right-sidebar-nav" class="right-sidebar-nav"></div>
        <div id="right-sidebar-premium-wrap" class="right-sidebar-premium-wrap">
            <button type="button" class="right-sidebar-premium-btn" onclick="if(typeof showPremiumLockedPurchasePopup==='function')showPremiumLockedPurchasePopup('');" title="Pro / Pro Plus">
                <span class="right-sidebar-premium-btn__icon" aria-hidden="true"><i class="fas fa-crown"></i></span>
                <span class="right-sidebar-premium-btn__text">
                    <span class="right-sidebar-premium-btn__title" data-i18n="sidebar_premium_title">وەشانا پارەدار (Pro)</span>
                    <span class="right-sidebar-premium-btn__sub" data-i18n="sidebar_premium_sub">Pro · Pro Plus</span>
                </span>
                <span class="right-sidebar-premium-btn__badge" id="sidebar-subscription-badge" aria-hidden="true" style="display:none;">PRO</span>
            </button>
        </div>
        <div id="right-sidebar-status" class="right-sidebar-status" title="حالة الاتصال بقاعدة البيانات">
            <span class="status-dot"></span>
            <span id="right-sidebar-status-text" data-i18n="sidebar_db_connected">گرێدایە (MySQL)</span>
            <span class="right-sidebar-status-sep" aria-hidden="true">·</span>
            <span id="right-sidebar-flash-status" class="right-sidebar-flash-status flash-off" role="button" tabindex="0" title="کلیک: هەڵبژاردن / چالاککردنەوەی فلاش" onclick="if(typeof posFlashSidebarBind==='function')posFlashSidebarBind();" onkeydown="if((event.key==='Enter'||event.key===' ')&&typeof posFlashSidebarBind==='function'){event.preventDefault();posFlashSidebarBind();}">
                <span class="status-dot"></span>
                <span id="right-sidebar-flash-status-text">فلاش</span>
            </span>
        </div>
    </aside>
    </div>
    <!-- تثبيت موقع <span data-i18n="sidebar_menu">لیستا کەناری</span> فوراً من localStorage (يمين/يسار) - يمنع القفز عند التحميل -->
    <script>
    (function(){
        try {
            var wrap = document.getElementById('app-content-wrap');
            if (wrap) {
                var pos = (typeof localStorage !== 'undefined' && localStorage.getItem('pos_sidebar_position')) || 'right';
                if (pos === 'left') wrap.classList.add('sidebar-on-left'); else wrap.classList.remove('sidebar-on-left');
            }
        } catch(e) {}
    })();
    </script>

    </div><!-- /#app-zoom-inner -->
    </div><!-- /#app-zoom-wrapper -->

    <!-- SALES HISTORY MODAL -->
    <div id="sales-history-modal" class="modal-overlay hist-modal" style="display:none;">
        <div class="modal-content hist-shell" data-accent="brand">
            <div class="hist-header">
                <h2 class="hist-title"><i class="fas fa-history"></i> <span data-i18n="sales_history_title">مێژوویا فرۆتنێ</span></h2>
                <button type="button" class="btn btn-sm btn-danger" onclick="document.getElementById('sales-history-modal').style.display='none'"><i class="fas fa-times"></i> <span data-i18n="btn_close">داخستن</span></button>
            </div>
            <div id="shift-summary-box" style="margin:0 0 8px 0; padding:10px 12px; border-radius:12px; background:linear-gradient(135deg, #020617, #0f172a); border:1px solid #1f2937; flex-shrink:0;">
                <div style="display:flex; flex-wrap:wrap; gap:12px; justify-content:space-between; align-items:center;">
                    <div>
                        <div style="font-size:0.75rem; color:#9ca3af;">شیفتێ نوکە</div>
                        <div id="shift-summary-user" style="font-weight:bold; color:#e5e7eb; font-size:0.95rem;">-</div>
                        <div id="shift-summary-time" style="font-size:0.72rem; color:#6b7280;">-</div>
                    </div>
                    <div style="display:flex; flex-wrap:wrap; gap:8px; text-align:center;">
                        <div style="min-width:100px; background:rgba(255,255,255,0.03); padding:6px 8px; border-radius:10px;">
                            <div style="font-size:0.68rem; color:#9ca3af;">پارێ دەستپێکێ</div>
                            <div id="shift-opening" style="font-weight:bold; color:#22c55e; font-size:0.95rem;">0</div>
                        </div>
                        <div style="min-width:100px; background:rgba(255,255,255,0.03); padding:6px 8px; border-radius:10px;">
                            <div style="font-size:0.68rem; color:#9ca3af;">فرۆتنا کاش</div>
                            <div id="shift-cash-sales" style="font-weight:bold; color:#38bdf8; font-size:0.95rem;">0</div>
                        </div>
                        <div style="min-width:100px; background:rgba(255,255,255,0.03); padding:6px 8px; border-radius:10px;">
                            <div style="font-size:0.68rem; color:#9ca3af;">مەزاختن</div>
                            <div id="shift-expenses" style="font-weight:bold; color:#f97316; font-size:0.95rem;">0</div>
                        </div>
                        <div style="min-width:110px; background:rgba(255,255,255,0.05); padding:6px 8px; border-radius:10px; border:1px solid rgba(250,204,21,0.2);">
                            <div style="font-size:0.68rem; color:#9ca3af;">پارێ د قاسێ دا</div>
                            <div id="shift-expected" style="font-weight:bold; color:#facc15; font-size:1rem;">0</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="hist-filters">
                <input type="date" id="date-start-sales" class="input-std" style="display:none;" onchange="renderSalesHistory()">
                <span style="color:var(--text-muted); white-space:nowrap; font-size:0.8rem; display:none;">تا</span>
                <input type="date" id="date-end-sales" class="input-std" style="display:none;" onchange="renderSalesHistory()">
                <button type="button" class="btn btn-sm btn-dark" onclick="resetSalesHistoryDateFilter()" title="پاککردنەوە"><i class="fas fa-times"></i></button>
                <div class="hist-presets">
                    <select id="sales-history-date-preset" class="input-std" style="width:160px; margin:0;" onchange="applySalesHistoryDatePreset(this.value)">
                        <option value="today" selected>☀️ ئەڤرۆ (Today)</option>
                        <option value="week">📅 حەفتییا بۆری (Last 7 Days)</option>
                        <option value="month">🌙 ئەڤ هەیڤە (This Month)</option>
                        <option value="90d">📅 ٩٠ ڕۆژ (Last 90 Days)</option>
                        <option value="1y">📅 ١ ساڵ (1 Year)</option>
                        <option value="8y">📅 ٨ ساڵ (8 Years)</option>
                        <option value="all">📅 هەمی دەم (All Time)</option>
                        <option value="custom">✍️ دیارکرنا دەمی (Custom)</option>
                    </select>
                </div>
                <div class="hist-search-wrap">
                    <i class="fas fa-search"></i>
                    <input type="text" id="sales-search-input" class="input-std" placeholder="لێگەریان: پسوول، مێز، ناڤ، بارکۆد، SKU..." onkeyup="filterHistory(this.value)" oninput="filterHistory(this.value)">
                </div>
            </div>
            <div id="sales-history-list" class="hist-body"></div>
            <div id="sales-history-more-bar" class="hist-footer">
                <span id="sales-history-more-status" style="font-size:0.85rem; color:var(--text-muted);">—</span>
                <div style="display:flex; gap:8px; flex-wrap:wrap;">
                    <button type="button" id="sales-history-extended-btn" class="btn btn-sm btn-dark" onclick="posLoadExtendedDataUi('supplies')" title="کڕین، مەسرەف، گەڕانەوە"><i class="fas fa-database"></i> زیاتر — کڕین/مەسرەف</button>
                    <button type="button" id="sales-history-more-btn" class="btn btn-sm btn-brand" onclick="loadMoreSalesHistory()" style="display:none;"><i class="fas fa-chevron-down"></i> زیاتر</button>
                </div>
            </div>
        </div>
    </div>

    <!-- RETURNS HISTORY MODAL -->
    <div id="returns-history-modal" class="modal-overlay hist-modal" style="display:none;">
        <div class="modal-content hist-shell" data-accent="warning">
            <div class="hist-header">
                <h2 class="hist-title"><i class="fas fa-undo-alt"></i> <span data-i18n="returns_history_title">مێژوویا زڤڕاندنێ</span></h2>
                <button type="button" class="btn btn-sm btn-danger" onclick="document.getElementById('returns-history-modal').style.display='none'"><i class="fas fa-times"></i> <span data-i18n="btn_close">داخستن</span></button>
            </div>
            <div class="hist-filters">
                <input type="date" id="date-start-returns" class="input-std" style="display:none;" onchange="renderReturnsReport()">
                <span style="color:var(--text-muted); white-space:nowrap; font-size:0.8rem; display:none;">تا</span>
                <input type="date" id="date-end-returns" class="input-std" style="display:none;" onchange="renderReturnsReport()">
                <button type="button" class="btn btn-sm btn-dark" onclick="resetDateFilter('returns', renderReturnsReport)" title="پاککردنەوە"><i class="fas fa-times"></i></button>
                <div class="hist-presets">
                    <select id="returns-history-date-preset" class="input-std" style="width:160px; margin:0;" onchange="applyReturnsHistoryDatePreset(this.value)">
                        <option value="today" selected>☀️ ئەڤرۆ (Today)</option>
                        <option value="week">📅 حەفتییا بۆری (Last 7 Days)</option>
                        <option value="month">🌙 ئەڤ هەیڤە (This Month)</option>
                        <option value="90d">📅 ٩٠ ڕۆژ (Last 90 Days)</option>
                        <option value="1y">📅 ١ ساڵ (1 Year)</option>
                        <option value="all">📅 هەمی دەم (All Time)</option>
                        <option value="custom">✍️ دیارکرنا دەمی (Custom)</option>
                    </select>
                </div>
            </div>
            <div id="returns-history-list" class="hist-body"></div>
            <div id="returns-history-more-bar" class="hist-footer">
                <span id="returns-history-more-status" style="font-size:0.85rem; color:var(--text-muted);">—</span>
                <button type="button" id="returns-history-more-btn" class="btn btn-sm btn-brand" onclick="loadMoreReturnsHistory()" style="display:none;"><i class="fas fa-chevron-down"></i> زیاتر</button>
            </div>
        </div>
    </div>

        <!-- SHOP AI — floating mini panel (not in menu) -->
        <button type="button" id="pos-shop-ai-fab" class="pos-shop-ai-fab" style="display:none;" onclick="if(typeof shopAiTogglePanel==='function')shopAiTogglePanel();" aria-label="هاریکارێ زیرەکێ دوکانێ" title="هاریکارێ زیرەکێ دوکانێ">
            <span class="pos-shop-ai-fab__ring" aria-hidden="true"></span>
            <i class="fas fa-robot" aria-hidden="true"></i>
        </button>
        <div id="pos-shop-ai-backdrop" class="pos-shop-ai-backdrop" style="display:none;" onclick="if(typeof shopAiClosePanel==='function')shopAiClosePanel();" aria-hidden="true"></div>
        <div id="pos-shop-ai-panel" class="pos-shop-ai-panel" style="display:none;" role="dialog" aria-modal="true" aria-labelledby="pos-shop-ai-panel-title">
            <header class="pos-shop-ai-panel__head">
                <div class="pos-shop-ai-panel__brand">
                    <span class="pos-shop-ai-panel__icon" aria-hidden="true"><i class="fas fa-robot"></i></span>
                    <div class="pos-shop-ai-panel__titles">
                        <h3 id="pos-shop-ai-panel-title" class="pos-shop-ai-panel__title" data-i18n="shop_ai_title">هاریکارێ زیرەکێ دوکانێ</h3>
                        <p class="pos-shop-ai-panel__sub" data-i18n="shop_ai_subtitle">پرسیار ل دور مفا، کۆگە... یان فێرکرنا سیستەمی (دێ چەوا ئایتەمەکی زێدە کەم؟)</p>
                    </div>
                </div>
                <div class="pos-shop-ai-panel__actions">
                    <button type="button" class="pos-shop-ai-panel__btn" onclick="if(typeof shopAiClearChat==='function')shopAiClearChat();" title="پاککردنەوە" aria-label="پاککردنەوە"><i class="fas fa-eraser"></i></button>
                    <button type="button" class="pos-shop-ai-panel__btn pos-shop-ai-panel__close" onclick="if(typeof shopAiClosePanel==='function')shopAiClosePanel();" aria-label="داخستن">&times;</button>
                </div>
            </header>
            <div id="shop-ai-status" class="shop-ai-status pos-shop-ai-panel__status" style="display:none;" aria-live="polite">
                <span id="shop-ai-status-icon" class="shop-ai-status__icon" aria-hidden="true"><i class="fas fa-circle"></i></span>
                <span id="shop-ai-status-text" class="shop-ai-status__text"></span>
            </div>
            <div id="shop-ai-usage" class="pos-shop-ai-panel__usage" aria-live="polite">
                <div class="shop-ai-usage-top">
                    <div class="shop-ai-usage-left">
                        <span id="shop-ai-plan-badge" class="shop-ai-plan-badge">Basic</span>
                        <span id="shop-ai-usage-label" class="pos-shop-ai-usage__label" data-i18n="shop_ai_usage_label">سنوورا ٣٠ ڕۆژانە</span>
                    </div>
                    <div class="shop-ai-usage-stats">
                        <span id="shop-ai-usage-text" class="pos-shop-ai-usage__text">0 / 150</span>
                        <span id="shop-ai-bonus-tag" class="shop-ai-bonus-tag" hidden></span>
                    </div>
                </div>
                <div class="pos-shop-ai-usage__track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0">
                    <div id="shop-ai-usage-fill" class="pos-shop-ai-usage__fill" style="width:0%;"></div>
                </div>
                <div class="shop-ai-usage-footer">
                    <span id="shop-ai-remaining-hint" class="shop-ai-remaining-hint"></span>
                    <span id="shop-ai-reset-hint" class="shop-ai-reset-hint"></span>
                </div>
            </div>
            <details id="shop-ai-commerce" class="shop-ai-commerce no-print">
                <summary class="shop-ai-commerce__toggle">
                    <span class="shop-ai-commerce__toggle-icon" aria-hidden="true"><i class="fas fa-chevron-down"></i></span>
                    <span data-i18n="shop_ai_packs_toggle">زیاتر خاڵ · کۆدی چالاککردن</span>
                </summary>
                <div class="shop-ai-commerce__body">
                    <p class="shop-ai-commerce__fair" data-i18n="shop_ai_packs_fair"><i class="fas fa-check-circle" aria-hidden="true"></i> خاڵەکان درست · نرخ بە $</p>
                    <div id="shop-ai-packs" class="shop-ai-packs"></div>
                    <div class="shop-ai-redeem">
                        <input type="text" id="shop-ai-limit-code" class="shop-ai-redeem__input" data-i18n-placeholder="shop_ai_code_placeholder" placeholder="کۆدی زیادکرن..." autocomplete="off" maxlength="32">
                        <button type="button" class="shop-ai-redeem__btn" onclick="if(typeof shopAiRedeemLimitCode==='function')shopAiRedeemLimitCode();" aria-label="چالاککردن">
                            <i class="fas fa-ticket-alt" aria-hidden="true"></i>
                        </button>
                    </div>
                    <p class="shop-ai-commerce__hint" data-i18n="shop_ai_packs_hint">پارە بە $ بدە بە پشتیوانی · کۆد وەربگرە</p>
                </div>
            </details>
            <div class="pos-shop-ai-panel__body" id="shop-ai-chat-panel">
                <div id="shop-ai-messages" class="shop-ai-messages pos-shop-ai-panel__messages" aria-live="polite"></div>
                <div class="pos-shop-ai-panel__footer">
                    <div class="pos-shop-ai-panel__quick">
                        <p class="shop-ai-quick__label" data-i18n="shop_ai_quick_label">پرسیارێن بەربڵاڤ:</p>
                        <div id="shop-ai-chips" class="shop-ai-chips pos-shop-ai-panel__chips"></div>
                    </div>
                    <div class="shop-ai-composer pos-shop-ai-panel__composer">
                        <textarea id="shop-ai-input" class="shop-ai-input input-std" rows="2" data-i18n-placeholder="shop_ai_input_placeholder" placeholder="ب سادەیی بنڤیسە..." maxlength="2000"></textarea>
                        <button type="button" id="shop-ai-send-btn" class="btn btn-brand shop-ai-send-btn" onclick="if(typeof shopAiSend==='function')shopAiSend();" aria-label="ناردن">
                            <i class="fas fa-paper-plane" aria-hidden="true"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>

    <div id="pos-ota-dock" class="pos-ota-dock" style="display:none;" role="status" aria-live="polite" hidden>
        <button type="button" id="pos-ota-dock-main" class="pos-ota-dock__main" onclick="if(typeof posOtaOpenFromDock==='function')posOtaOpenFromDock();">
            <i id="pos-ota-dock-icon" class="fas fa-cloud-download-alt" aria-hidden="true"></i>
            <span id="pos-ota-dock-count" class="pos-ota-dock__badge">0</span>
            <span class="pos-ota-dock__copy">
                <span id="pos-ota-dock-text" class="pos-ota-dock__text">ئابدەیت هاتیە — دەشێی کار بکەیت و پاشتر نوێ بکەیتەوە</span>
                <span id="pos-ota-dock-progress-wrap" class="pos-ota-dock__progress" style="display:none;" aria-hidden="true">
                    <span class="pos-ota-dock__progress-track"><span id="pos-ota-dock-progress-bar" class="pos-ota-dock__progress-bar"></span></span>
                    <span id="pos-ota-dock-progress-text" class="pos-ota-dock__progress-text"></span>
                </span>
            </span>
        </button>
        <button type="button" id="pos-ota-dock-apply" class="pos-ota-dock__apply" onclick="if(typeof posOtaOpenFromDock==='function')posOtaOpenFromDock();" data-i18n-title="ota_dock_apply" title="ئابدەیت">
            <i class="fas fa-bolt"></i> <span id="pos-ota-dock-apply-label">ئابدەیت</span>
        </button>
        <button type="button" id="pos-ota-dock-minimize" class="pos-ota-dock__min" onclick="if(typeof posOtaMinimizeDock==='function')posOtaMinimizeDock();" title="بچووک بکە — بەردەوامی کار">
            <i class="fas fa-chevron-down"></i>
        </button>
    </div>

    <button id="pos-notification-fab" title="Notifications">
        <i class="fas fa-bell"></i>
        <span id="pos-notification-count" class="count" style="display:none;">0</span>
    </button>
    <div id="pos-notification-panel">
        <div class="head">
            <strong>ئاگەهداری</strong>
            <button id="pos-notification-mark-read" class="btn btn-sm btn-dark" style="padding:4px 8px;">هەمیان بخوینە (Mark All Read)</button>
        </div>
        <div id="pos-notification-list">
            <div class="item">چ ئاگەهداری نینن.</div>
        </div>
    </div>
    <div id="pos-notification-toast" onclick="document.getElementById('pos-notification-fab').click(); this.style.display='none';">
        <div class="toast-card" id="pos-toast-card">
            <div class="toast-icon" id="pos-toast-icon"><i class="fas fa-bell"></i></div>
            <div class="toast-content">
                <div id="pos-toast-title" class="toast-title">ئاگەهداریەکا نوی</div>
                <div id="pos-toast-msg" class="toast-msg"></div>
            </div>
        </div>
    </div>

