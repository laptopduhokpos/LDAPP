// sales/print.js — printing, toast
        var _printStylesHtmlCache = null;
        var _printFrameReady = false;

        function posPrintRudawAlreadyReady() {
            try {
                return !!(document.fonts && document.fonts.check && (
                    document.fonts.check('16px Rudaw') || document.fonts.check('400 16px Rudaw')
                ));
            } catch (eR) {
                return false;
            }
        }

        function absAssetUrl(path) {
            try { return new URL(String(path || ''), window.location.href).href; }
            catch (eAbs) { return String(path || ''); }
        }
        if (typeof window !== 'undefined') window.absAssetUrl = absAssetUrl;

        /** Make relative <img src="public/..."> absolute for about:blank print iframe. */
        function absolutizePrintHtmlAssetUrls(html) {
            var s = String(html || '');
            if (!s) return s;
            return s.replace(/\bsrc=(["'])(?!data:|blob:|https?:|\/\/)([^"']+)\1/gi, function(_m, q, src) {
                var path = String(src || '').trim();
                if (!path || path.charAt(0) === '#') return _m;
                return 'src=' + q + absAssetUrl(path) + q;
            });
        }

        function getPrintStylesHtml() {
            if (_printStylesHtmlCache) return _printStylesHtmlCache;
            var parts = [];
            var rudawReg = absAssetUrl('public/fonts/rudaw/Rudaw-Regular.ttf');
            var rudawBold = absAssetUrl('public/fonts/rudaw/Rudaw-Bold.ttf');
            // Receipt CSS only. Dumping every POS sheet + Font Awesome made Chrome print preview hang.
            parts.push('<link rel="preload" href="' + rudawReg + '" as="font" type="font/ttf" crossorigin>');
            parts.push('<link rel="preload" href="' + rudawBold + '" as="font" type="font/ttf" crossorigin>');
            parts.push('<link rel="stylesheet" href="' + absAssetUrl('public/css/pos-01-base.css') + '" media="print">');
            parts.push(
                '<style>' +
                '@font-face{font-family:"Rudaw";src:url("' + rudawReg + '") format("truetype");font-weight:400;font-style:normal;font-display:swap;}' +
                '@font-face{font-family:"Rudaw";src:url("' + rudawReg + '") format("truetype");font-weight:500;font-style:normal;font-display:swap;}' +
                '@font-face{font-family:"Rudaw";src:url("' + rudawReg + '") format("truetype");font-weight:600;font-style:normal;font-display:swap;}' +
                '@font-face{font-family:"Rudaw";src:url("' + rudawBold + '") format("truetype");font-weight:700;font-style:normal;font-display:swap;}' +
                '@font-face{font-family:"Rudaw";src:url("' + rudawBold + '") format("truetype");font-weight:800;font-style:normal;font-display:swap;}' +
                '@font-face{font-family:"Rudaw";src:url("' + rudawBold + '") format("truetype");font-weight:900;font-style:normal;font-display:swap;}' +
                'html,body.print-mode{margin:0;padding:0;background:#fff!important;color:#0f172a!important;}' +
                '#printable-area{display:block!important;visibility:visible!important;position:static!important;width:100%!important;height:auto!important;}' +
                'html,body,.print-thermal-container,.print-thermal-container *,.print-a4-container,.print-a4-container *{font-family:"Rudaw",Tahoma,"Segoe UI",sans-serif !important;}' +
                '.print-a4-container,.print-thermal-container{color:#0f172a!important;-webkit-print-color-adjust:exact;print-color-adjust:exact;}' +
                '.print-a4-container .a4-items-table td,.print-a4-container .a4-items-table th,' +
                '.print-a4-container .a4-d1-meta,.print-a4-container .a4-d1-summary,' +
                '.print-a4-container .a4-d1-section-bar,' +
                '.print-thermal-container .thermal-table td,.print-thermal-container .thermal-totals-rtl,' +
                '.print-thermal-container table td{visibility:visible!important;opacity:1!important;}' +
                '@media print{@page{margin:0;}html,body{height:auto!important;overflow:visible!important;background:#fff!important;}' +
                '#printable-area{display:block!important;}img,svg,canvas{max-width:100%;height:auto;}}' +
                '</style>'
            );
            _printStylesHtmlCache = parts.join('');
            return _printStylesHtmlCache;
        }

        function ensurePrintFrame() {
            var printFrame = document.getElementById('hidden-print-frame');
            if (!printFrame) {
                printFrame = document.createElement('iframe');
                printFrame.id = 'hidden-print-frame';
                printFrame.setAttribute('aria-hidden', 'true');
                printFrame.style.cssText = 'position:fixed;width:210mm;height:297mm;border:0;opacity:0;pointer-events:none;left:-100vw;top:0;z-index:-1;';
                document.body.appendChild(printFrame);
            } else if (printFrame.style.width === '0px' || printFrame.style.width === '0') {
                printFrame.style.cssText = 'position:fixed;width:210mm;height:297mm;border:0;opacity:0;pointer-events:none;left:-100vw;top:0;z-index:-1;';
            }
            return printFrame;
        }

        function markPrintFrameReady(doc) {
            if (!doc || !doc.body) return;
            doc.body.setAttribute('data-warmed', '1');
            doc.body.setAttribute('data-print-ready', '1');
            _printFrameReady = true;
        }
        /** Wait until Rudaw TTF is loaded in doc (or timeout). Prevents blank Kurdish text on first print. */
        function whenRudawFontsInDoc(doc, cb, maxWaitMs) {
            if (typeof cb !== 'function') return;
            var maxMs = maxWaitMs != null ? maxWaitMs : (posPrintRudawAlreadyReady() ? 350 : 800);
            var finished = false;
            function done() {
                if (finished) return;
                finished = true;
                try { cb(); } catch (eCb) {}
            }
            var timer = setTimeout(done, maxMs);
            function rudawReady() {
                try {
                    return doc && doc.fonts && doc.fonts.check && (
                        doc.fonts.check('16px Rudaw') || doc.fonts.check('400 16px Rudaw')
                    );
                } catch (eCh) { return false; }
            }
            if (rudawReady()) {
                clearTimeout(timer);
                setTimeout(done, 30);
                return;
            }
            var waits = [];
            try {
                if (doc && doc.fonts) {
                    if (typeof doc.fonts.load === 'function') {
                        waits.push(doc.fonts.load('400 16px Rudaw'));
                        waits.push(doc.fonts.load('700 16px Rudaw'));
                    }
                }
            } catch (eLoad) {}
            if (waits.length && typeof Promise !== 'undefined') {
                Promise.all(waits.map(function (p) {
                    return Promise.resolve(p).catch(function () { return null; });
                })).then(function () {
                    var start = Date.now();
                    (function poll() {
                        if (rudawReady() || Date.now() - start >= maxMs) {
                            clearTimeout(timer);
                            setTimeout(done, 40);
                            return;
                        }
                        setTimeout(poll, 50);
                    })();
                }).catch(function () {
                    clearTimeout(timer);
                    done();
                });
                return;
            }
            clearTimeout(timer);
            setTimeout(done, Math.min(300, maxMs));
        }
        /** Run callback once print iframe CSS is loaded (fixes first receipt after login). */
        function whenPrintFrameReady(cb, maxWaitMs) {
            if (typeof cb !== 'function') return;
            if (_printFrameReady) { cb(); return; }
            var maxMs = maxWaitMs != null ? maxWaitMs : 3000;
            var start = Date.now();
            (function poll() {
                if (_printFrameReady) { cb(); return; }
                if (Date.now() - start >= maxMs) { cb(); return; }
                setTimeout(poll, 40);
            })();
        }
        function warmPrintFrame() {
            try {
                var printFrame = ensurePrintFrame();
                var doc = printFrame.contentDocument || (printFrame.contentWindow && printFrame.contentWindow.document);
                if (!doc) return;
                if (_printFrameReady && doc.body && doc.body.getAttribute('data-print-ready') === '1' && doc.getElementById('printable-area')) return;
                _printFrameReady = false;
                doc.open();
                doc.write('<html><head><title>Print</title>' + getPrintStylesHtml() + '</head><body class="print-mode"><div id="printable-area"></div></body></html>');
                doc.close();
                var links = doc.querySelectorAll('link[rel="stylesheet"]');
                var pending = links.length;
                var marked = false;
                function tryMark() {
                    if (marked) return;
                    marked = true;
                    whenRudawFontsInDoc(doc, function () { markPrintFrameReady(doc); }, posPrintRudawAlreadyReady() ? 250 : 500);
                }
                if (pending === 0) {
                    setTimeout(tryMark, 40);
                    return;
                }
                var done = 0;
                function linkDone() {
                    done++;
                    if (done >= pending) setTimeout(tryMark, 40);
                }
                for (var i = 0; i < links.length; i++) {
                    try {
                        if (links[i].sheet) { linkDone(); continue; }
                    } catch (eSheet) {}
                    links[i].addEventListener('load', linkDone, { once: true });
                    links[i].addEventListener('error', linkDone, { once: true });
                }
                setTimeout(tryMark, 450);
            } catch (e) {}
        }

        function triggerPrintFrame(printFrame, opts) {
            opts = opts || {};
            var maxImageWaitMs = opts.maxImageWaitMs != null ? opts.maxImageWaitMs : 1200;
            var win = printFrame.contentWindow;
            if (!win) return;
            var fired = false;
            
            function go() {
                if (fired) return;
                fired = true;

                try {
                    win.focus();
                    win.print();
                    if (typeof window.focusTxnScannerInput === 'function') {
                        setTimeout(function() { window.focusTxnScannerInput('pos', { clear: true, delay: 50 }); }, 400);
                    }
                } catch (e) {
                    console.error('Print error:', e);
                }
            }
            function whenImagesReady(cb) {
                var doc;
                try { doc = printFrame.contentDocument; } catch (eDoc) { doc = null; }
                if (!doc) { cb(); return; }
                var imgs = doc.querySelectorAll('img');
                var pending = 0;
                for (var i = 0; i < imgs.length; i++) {
                    if (imgs[i].complete) continue;
                    pending++;
                    imgs[i].addEventListener('load', done, { once: true });
                    imgs[i].addEventListener('error', done, { once: true });
                }
                function done() {
                    pending--;
                    if (pending <= 0) cb();
                }
                if (pending <= 0) cb();
                else setTimeout(cb, maxImageWaitMs);
            }
            function whenFontsReady(cb, maxWaitMs) {
                var maxMs = maxWaitMs != null ? maxWaitMs : 400;
                var finished = false;
                function done() {
                    if (finished) return;
                    finished = true;
                    try { cb(); } catch (eCb) {}
                }
                var timer = setTimeout(done, maxMs);
                try {
                    var docF = printFrame.contentDocument;
                    function iframeRudawOk() {
                        try {
                            return !!(docF && docF.fonts && docF.fonts.check && (
                                docF.fonts.check('16px Rudaw') || docF.fonts.check('400 16px Rudaw')
                            ));
                        } catch (eCh) { return false; }
                    }
                    if (iframeRudawOk() || posPrintRudawAlreadyReady()) {
                        clearTimeout(timer);
                        setTimeout(done, 16);
                        return;
                    }
                    var waits = [];
                    if (docF && docF.fonts) {
                        try {
                            if (typeof docF.fonts.load === 'function') {
                                waits.push(docF.fonts.load('400 16px Rudaw'));
                                waits.push(docF.fonts.load('700 16px Rudaw'));
                            }
                        } catch (eLoad) {}
                    }
                    if (waits.length && typeof Promise !== 'undefined') {
                        Promise.all(waits.map(function (p) {
                            return Promise.resolve(p).catch(function () { return null; });
                        })).then(function () {
                            clearTimeout(timer);
                            setTimeout(done, 16);
                        }).catch(function () {
                            clearTimeout(timer);
                            done();
                        });
                        return;
                    }
                } catch (eFonts) {}
                clearTimeout(timer);
                setTimeout(done, Math.min(50, maxMs));
            }
            function printFrameImagesReady() {
                try {
                    var docI = printFrame.contentDocument;
                    if (!docI) return true;
                    var imgs = docI.querySelectorAll('img');
                    for (var ii = 0; ii < imgs.length; ii++) {
                        if (!imgs[ii].complete) return false;
                    }
                    return true;
                } catch (eImg) {
                    return true;
                }
            }
            function schedulePrint() {
                var rudawOk = posPrintRudawAlreadyReady();
                var imgsOk = printFrameImagesReady();
                if (imgsOk) opts.immediate = true;
                var fontBudget = rudawOk
                    ? (opts.immediate ? 40 : 120)
                    : (opts.coldStart ? 400 : (opts.immediate ? 160 : 280));
                whenFontsReady(function () {
                    if (opts.immediate) {
                        go();
                        return;
                    }
                    whenImagesReady(go);
                }, fontBudget);
            }
            try {
                var doc = printFrame.contentDocument;
                if (doc && doc.readyState === 'complete') schedulePrint();
                else printFrame.onload = schedulePrint;
            } catch (e2) {
                schedulePrint();
            }
        }

        function printContent(htmlContent, opts) {
            opts = opts || {};
            if (opts.fast !== false) opts.fast = true;
            if (typeof ensurePosReceiptBrandInHtml === 'function') {
                htmlContent = ensurePosReceiptBrandInHtml(htmlContent);
            }
            const area = document.getElementById('printable-area');
            var localizedHtml = localizePrintHtml(htmlContent);
            // Dual-currency receipts keep intentional «د.ع» (e.g. "$ 240 · 366,000 د.ع").
            // Do not run USD UI sanitizer on finalized print HTML.
            var skipUsdIqdSanitize = localizedHtml.indexOf('data-skip-print-localize="1"') !== -1
                || localizedHtml.indexOf("data-skip-print-localize='1'") !== -1
                || localizedHtml.indexOf('data-allow-iqd="1"') !== -1
                || localizedHtml.indexOf('a4-iqd-hint') !== -1
                || localizedHtml.indexOf('a4-d1-total-iqd') !== -1
                || localizedHtml.indexOf('print-a4-container') !== -1
                || localizedHtml.indexOf('print-thermal-container') !== -1
                || localizedHtml.indexOf('receipt-grand-total') !== -1;
            if (!skipUsdIqdSanitize && typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD' && typeof sanitizeIqdTextForUsd === 'function') {
                localizedHtml = sanitizeIqdTextForUsd(localizedHtml);
            }
            localizedHtml = absolutizePrintHtmlAssetUrls(localizedHtml);
            
            // Check if auto-print is disabled in settings
            if (db && db.settings && db.settings.autoPrint === false) {
                if (area) area.innerHTML = localizedHtml;
                setTimeout(function() {
                    if (area) area.innerHTML = '';
                }, 5000); // Clear after 5 seconds if not printed
                showToast('پێشبینیکرنا وەسڵێ دەرکەفت (ئۆتۆ-پرێنت یێ گرتيیە)', 'info');
                return;
            }

            var printFrame = ensurePrintFrame();
            var doc = printFrame.contentDocument || printFrame.contentWindow.document;
            var printReady = _printFrameReady && doc.body && doc.body.getAttribute('data-print-ready') === '1';
            var areaInFrame = doc.getElementById('printable-area');
            if (printReady && areaInFrame) {
                areaInFrame.innerHTML = localizedHtml;
                triggerPrintFrame(printFrame, {
                    maxImageWaitMs: opts.fast ? 280 : 450,
                    docType: opts.docType
                });
                return;
            } else {
                _printFrameReady = false;
                doc.open();
                doc.write('<html><head><title>Print</title>' + getPrintStylesHtml() + '</head><body class="print-mode"><div id="printable-area">' + localizedHtml + '</div></body></html>');
                doc.close();
                var coldLinks = doc.querySelectorAll('link[rel="stylesheet"]');
                var coldPending = coldLinks.length;
                var coldMarked = false;
                function coldReadyThenPrint() {
                    if (coldMarked) return;
                    coldMarked = true;
                    whenRudawFontsInDoc(doc, function () {
                        markPrintFrameReady(doc);
                        triggerPrintFrame(printFrame, {
                            maxImageWaitMs: opts.fast ? 280 : 450,
                            coldStart: true,
                            docType: opts.docType
                        });
                    }, opts.fast ? 280 : 450);
                }
                if (coldPending === 0) {
                    printFrame.onload = coldReadyThenPrint;
                    setTimeout(coldReadyThenPrint, opts.fast ? 80 : 160);
                    return;
                }
                var coldDone = 0;
                function coldLinkDone() {
                    coldDone++;
                    if (coldDone >= coldPending) setTimeout(coldReadyThenPrint, 20);
                }
                for (var ci = 0; ci < coldLinks.length; ci++) {
                    try { if (coldLinks[ci].sheet) { coldLinkDone(); continue; } } catch (eCs) {}
                    coldLinks[ci].addEventListener('load', coldLinkDone, { once: true });
                    coldLinks[ci].addEventListener('error', coldLinkDone, { once: true });
                }
                setTimeout(coldReadyThenPrint, opts.fast ? 280 : 500);
                return;
            }
        }
        window.printContent = printContent;
        function logPrintAction(docType, docId, action, note, details) {
            const formData = new FormData();
            formData.append('action', 'log_print_action');
            formData.append('doc_type', docType || '');
            formData.append('doc_id', String(docId ?? ''));
            formData.append('log_action', action || 'print');
            formData.append('note', note || '');
            formData.append('details', details || '');
            formData.append('user', currentUser ? currentUser.name : 'System');
            formData.append('user_id', currentUser ? currentUser.id : 0);
            fetch('?action=log_print_action', { method: 'POST', body: formData }).then(function(r) { return r.json(); }).then(function(res) {
                if (res.status === 'success' && db) {
                    if (!db.print_log) db.print_log = [];
                    db.print_log.unshift({
                        id: res.id || ('tmp-' + Date.now()),
                        doc_type: docType,
                        doc_id: String(docId),
                        action: action || 'print',
                        user: currentUser ? currentUser.name : 'System',
                        note: note || '',
                        details: details || '',
                        created_at: new Date().toISOString().slice(0, 19).replace('T', ' ')
                    });
                    var ghView = document.getElementById('view-print-history');
                    if (ghView && ghView.classList.contains('active') && typeof renderGeneralHistory === 'function') renderGeneralHistory();
                }
            }).catch(function() {});
        }
        /** Show modal for optional note before print; on confirm call onConfirm(note), on cancel call onCancel(). */
        function showPrintNoteModal(options) {
            options = options || {};
            if (typeof canUsePrintNotes === 'function' && !canUsePrintNotes()) {
                if (typeof showPremiumLockedPurchasePopup === 'function') {
                    showPremiumLockedPurchasePopup((typeof t === 'function') ? t('print_note_pro_required') : 'تێبینی پێش چاپ تەنها لەگەڵ پلانی Pro ($224) — کۆدی چالاککردن بنووسە.');
                }
                if (typeof options.onCancel === 'function') options.onCancel();
                return;
            }
            var modal = document.getElementById('print-note-modal');
            var input = document.getElementById('print-note-input');
            var btnCancel = document.getElementById('print-note-cancel');
            var btnSkip = document.getElementById('print-note-skip');
            var btnConfirm = document.getElementById('print-note-confirm');
            var ctxEl = document.getElementById('print-note-context');
            if (!modal || !input) return;
            input.value = '';
            if (ctxEl) {
                var ctx = options.docLabel || options.docType || '';
                ctxEl.textContent = ctx ? (typeof t === 'function' ? (t('print_note_for_doc') || 'چاپ:') : 'چاپ:') + ' ' + ctx : '';
                ctxEl.style.display = ctx ? '' : 'none';
            }
            modal.style.zIndex = '50000';
            modal.style.display = 'flex';
            setTimeout(function() { input.focus(); }, 50);
            function closeModal() {
                modal.style.display = 'none';
                document.removeEventListener('keydown', onKey);
            }
            function onConfirmClick(noteText) {
                var note = noteText != null ? String(noteText).trim() : ((input && input.value) ? input.value.trim() : '');
                closeModal();
                if (typeof options.onConfirm === 'function') options.onConfirm(note);
            }
            function onCancelClick() {
                closeModal();
                if (typeof options.onCancel === 'function') options.onCancel();
            }
            function onKey(e) {
                if (e.key === 'Escape') { e.preventDefault(); onCancelClick(); }
                if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); onConfirmClick(); }
            }
            document.addEventListener('keydown', onKey);
            if (btnCancel) btnCancel.onclick = onCancelClick;
            if (btnSkip) btnSkip.onclick = function() { onConfirmClick(''); };
            if (btnConfirm) btnConfirm.onclick = function() { onConfirmClick(); };
            modal.onclick = function(e) { if (e.target === modal) onCancelClick(); };
            modal.querySelectorAll('.print-note-quick-chip').forEach(function(chip) {
                chip.onclick = function(ev) {
                    ev.stopPropagation();
                    var preset = chip.getAttribute('data-note') || chip.textContent || '';
                    input.value = preset;
                    input.focus();
                };
            });
        }
        /** Print with optional note: if showPrintNotePopup and !skipNotePopup, show modal then buildHtml(note), print, log. Else buildHtml(''), print, log. */
        function printWithOptionalNote(opts) {
            var docType = opts.docType || '';
            var docId = opts.docId !== undefined && opts.docId !== null ? String(opts.docId) : '';
            var skipNotePopup = opts.skipNotePopup === true;
            var notesAllowed = typeof canUsePrintNotes === 'function' && canUsePrintNotes();
            var showPopup = notesAllowed && (db.settings && db.settings.showPrintNotePopup !== false) && !skipNotePopup && typeof opts.buildHtml === 'function';
            function doPrint(note) {
                var noteText = notesAllowed ? (note || '') : '';
                var html = typeof opts.buildHtml === 'function' ? opts.buildHtml(noteText) : '';
                if (html) printContent(html, { fast: opts.fast !== false, docType: docType });
                setTimeout(function () {
                    logPrintAction(docType, docId, 'print', noteText || '', opts.details || '');
                }, 0);
            }
            if (showPopup) {
                var docLabel = opts.docLabel || '';
                if (!docLabel && docType && typeof t === 'function') {
                    var dk = 'pds_card_' + docType.replace(/_slip$/, '') + '_title';
                    if (docType === 'pos_sale') docLabel = t('pds_card_pos_sale_title');
                    else if (docType === 'proforma') docLabel = t('pds_card_proforma_title');
                    else if (docType === 'return_receipt') docLabel = t('pds_card_return_title');
                    else docLabel = docType;
                }
                showPrintNoteModal({ docType: docType, docLabel: docLabel, onConfirm: doPrint, onCancel: function() {} });
            } else {
                doPrint('');
            }
        }
        function buildUnifiedPrintHtml(docType, cfg, bodyHtml, note) {
            var body = String(bodyHtml || '');
            var isA4 = (cfg.paper === '210mm' || cfg.paper === 'A4');
            if (body.indexOf('print-a4-container') >= 0 || body.indexOf('a4-invoice-v2') >= 0) isA4 = true;
            if (body.indexOf('print-thermal-container') >= 0 && !isA4) {
                return typeof finalizePrintHtmlWithNote === 'function' ? finalizePrintHtmlWithNote(body, note || '') : body;
            }
            var wrapClass = isA4 ? 'print-a4-container' : 'print-thermal-container';
            var designCls = (!isA4 && cfg && cfg.design) ? (' design-' + cfg.design) : '';
            var baseStyle = isA4 ? '' : 'max-width:' + (cfg.paper || '80mm') + ';';
            var noteHtml = (typeof buildProfessionalPrintNoteHtml === 'function')
                ? buildProfessionalPrintNoteHtml(note, isA4 ? 'a4' : 'wrap')
                : '';
            if (body.indexOf('__NOTE_SLOT__') >= 0) {
                body = body.split('__NOTE_SLOT__').join(noteHtml);
                noteHtml = '';
            }
            return '<div class="print-unified ' + wrapClass + designCls + '" data-doc-type="' + escapeHtml(docType || '') + '" style="' + baseStyle + '">' + body + noteHtml + '</div>';
        }
        function printDocument(docType, bodyHtml, opts) {
            var cfg = typeof getPrintConfig === 'function' ? getPrintConfig(docType) : { paper: '80mm', design: '1' };
            var options = opts || {};
            if (options.cfg && typeof options.cfg === 'object') {
                cfg = Object.assign({}, cfg, options.cfg);
            }
            if (options.paper) {
                cfg.paper = /^(210mm|A4)$/i.test(String(options.paper)) ? '210mm' : '80mm';
            }
            if (typeof printWithOptionalNote === 'function') {
                printWithOptionalNote({
                    docType: docType || '',
                    docId: options.docId || '',
                    details: options.details || '',
                    docLabel: options.docLabel || '',
                    buildHtml: function(note) {
                        return buildUnifiedPrintHtml(docType || '', cfg, bodyHtml || '', note || '');
                    }
                });
                return;
            }
            var plain = buildUnifiedPrintHtml(docType || '', cfg, bodyHtml || '', '');
            printContent(plain, { docType: docType });
            if (typeof logPrintAction === 'function') {
                logPrintAction(docType || '', options.docId || '', 'print', '', options.details || '');
            }
        }

        /** Route print: build A4/thermal report and print using config for docType, integrating optional note + logging. */
        function routePrint(docType, htmlContent, opts) {
            printDocument(docType, htmlContent, opts || {});
        }
        window.routePrint = routePrint;

        function buildReceiptQrPayload(sale) {
            if (!sale) return '';
            var shop = (db && db.settings && db.settings.cafeName) ? String(db.settings.cafeName) : 'POS';
            var payload = {
                invoice_id: sale.id || '',
                date: sale.date || '',
                total: Number(sale.total || 0),
                shop: shop
            };
            return JSON.stringify(payload);
        }

        /** Matches preview toggle «Show QR» — when off, no QR block on printed thermal receipts. */
        function isReceiptQrPrintEnabled() {
            var t = db && db.settings && db.settings.receiptPreviewToggles;
            return !!(t && t.showQr === true);
        }

        /** Generate QR as data URL using local qrcode.min.js only (no internet). */
        function posOfflineQrDataUrl(text, size) {
            var qrPayload = String(text || '');
            if (!qrPayload || typeof window.QRCode === 'undefined') return '';
            var safeSize = Math.max(64, parseInt(size, 10) || 120);
            var holder = document.createElement('div');
            holder.style.cssText = 'position:fixed;left:-9999px;top:-9999px;width:0;height:0;overflow:hidden;';
            document.body.appendChild(holder);
            try {
                var level = (window.QRCode.CorrectLevel && window.QRCode.CorrectLevel.M) ? window.QRCode.CorrectLevel.M : 1;
                new window.QRCode(holder, { text: qrPayload, width: safeSize, height: safeSize, correctLevel: level });
                var canvas = holder.querySelector('canvas');
                if (canvas && typeof canvas.toDataURL === 'function') return canvas.toDataURL('image/png');
                var img = holder.querySelector('img');
                if (img && img.src) return img.src;
            } catch (_eQr) {}
            finally {
                if (holder.parentNode) holder.parentNode.removeChild(holder);
            }
            return '';
        }
        window.posOfflineQrDataUrl = posOfflineQrDataUrl;

        function getReceiptQrImageSrc(payload, size) {
            var qrPayload = String(payload || '');
            if (!qrPayload) return '';
            var safeSize = Math.max(80, parseInt(size, 10) || 120);
            try {
                if (window.QRious) {
                    var q = new window.QRious({ value: qrPayload, size: safeSize, level: 'M' });
                    if (q && typeof q.toDataURL === 'function') return q.toDataURL();
                }
            } catch (_e1) {}
            var local = posOfflineQrDataUrl(qrPayload, safeSize);
            if (local) return local;
            return '';
        }

        function printKitchen() { 
             const tableObj = db.tables.find(x => x.id === activeTableId);
             if (!tableObj || tableObj.items.length === 0) return; 
             const kc = getPrintConfig('kitchen_slip');

             const grouped = {};
             tableObj.items.forEach(i => {
                 const key = i.id + '_' + (i.note || '') + '_' + (i.saleUnit || 'piece');
                 if(!grouped[key]) grouped[key] = { ...i, count: 0 };
                 grouped[key].count += getItemQty(i);
             });
             var locale = typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ';
             let html = `
         <div class="print-thermal-container design-${kc.design || '1'}" style="max-width: ${kc.paper}; width: 100%; direction:rtl; font-family:'Rudaw', sans-serif;">
                <h2 style="margin:0; font-family:'Rudaw', sans-serif; font-size:1.5rem;">${typeof t === 'function' ? t('print_kitchen') : 'چێشتخانە'}</h2>
                <div class="thermal-divider"></div>
                <div class="thermal-info"><span>${typeof getTablesLabelShort === 'function' ? getTablesLabelShort() : (typeof t === 'function' ? t('bill_header_table') : 'مێز')}: ${tableObj.name}</span><span>${new Date().toLocaleTimeString(locale)}</span></div>
                <div class="thermal-divider"></div>
                <div class="kitchen-box">
                    ${Object.values(grouped).map(g => `
                       <div class="kitchen-row"><span class="kitchen-qty">${formatQtyForDisplay(g.count, g)}</span><span class="kitchen-item">${escapeHtml(g.name || 'ئایتم')}${getSaleItemUnitSuffix(g)}</span></div>
                        ${g.note ? `<span class="kitchen-note">* ${g.note}</span>` : ''}
                    `).join('')}
                </div>
             </div>`;
             routePrint('kitchen_slip', html, { docId: String(tableObj.id || ''), details: 'kitchen-slip' });
        }

        function printProforma() {
            const table = db.tables.find(t => t.id === activeTableId);
            if (!table || table.items.length === 0) return;

            let subTotal = (typeof roundMoney === 'function' ? roundMoney : function(x){ return (parseFloat(x) || 0); })(table.items.reduce(function(sum, item) {
                var u = typeof getBillLineUnitIqd === 'function' ? getBillLineUnitIqd(item) : (parseFloat(item.price) || 0);
                return sum + u * getItemQty(item);
            }, 0));
            let discount = 0;
            let discountPercent = 0;

            if (table.manualDiscount !== undefined && table.manualDiscount !== null) {
                discount = parseFloat(table.manualDiscount);
                discountPercent = subTotal > 0 ? (discount / subTotal) * 100 : 0;
            } else {
                const discountInputEl = document.getElementById('pos-discount');
                const discountInput = discountInputEl ? discountInputEl.value : '';
                if (discountInput && !isNaN(discountInput)) {
                    discountPercent = parseFloat(discountInput);
                    if (discountPercent >= 0 && discountPercent <= 100) {
                        discount = (typeof roundMoney === 'function' ? roundMoney : function(x){ return x; })(subTotal * (discountPercent / 100));
                    }
                }
            }
            const total = subTotal - discount;

            const grouped = {};
            table.items.forEach(i => {
                const key = i.id + '_' + (i.note || '') + '_' + (i.isGift ? 'gift' : 'normal');
                if (!grouped[key]) grouped[key] = { id: i.id, name: i.name, price: i.price, count: 0, sub: 0, note: i.note, saleUnit: i.saleUnit || 'piece', isGift: !!i.isGift, productRef: i.productRef || null };
                var lineQty = Math.max(1, Number(i.count || i.qty || 1));
                grouped[key].count += lineQty;
                var uPr = typeof getBillLineUnitIqd === 'function' ? getBillLineUnitIqd(i) : (Number(i.price) || 0);
                grouped[key].sub += (i.isGift ? 0 : uPr) * lineQty;
            });

            const calc = { subTotal: subTotal, discount: discount, discountPercent: discountPercent, total: total };
            const proformaCfg = getPrintConfig('proforma');
            const buildThermal = typeof buildProformaReceiptHtml === 'function' ? buildProformaReceiptHtml : null;
            const buildA4 = typeof buildProformaA4Html === 'function' ? buildProformaA4Html : null;
            const isA4 = typeof isA4PrintPaper === 'function' ? isA4PrintPaper(proformaCfg.paper) : (proformaCfg.paper === '210mm' || proformaCfg.paper === 'A4');

            const docId = String(table.id || '');
            const docLabel = typeof t === 'function' ? t('pds_card_proforma_title') : 'لیست';
            function printProformaHtml(note) {
                const base = (isA4 && buildA4) ? buildA4(table, grouped, calc) : (buildThermal ? buildThermal(table, grouped, calc) : '');
                if (!base) return '';
                return typeof finalizePrintHtmlWithNote === 'function' ? finalizePrintHtmlWithNote(base, note || '') : base;
            }
            if (typeof printWithOptionalNote === 'function') {
                printWithOptionalNote({
                    docType: 'proforma',
                    docId: docId,
                    details: isA4 ? 'proforma-a4' : 'proforma',
                    docLabel: docLabel,
                    buildHtml: printProformaHtml
                });
                return;
            }
            const fallback = printProformaHtml('');
            if (fallback) routePrint('proforma', fallback, { docId: docId, details: 'proforma' });
        }
        
        function isSpuriousConnectionFailedToast(msg) {
            var s = String(msg || '');
            if (!s) return false;
            if (s.indexOf('پەیوەندی سەرنەکەفت') !== -1) return true;
            if (s.indexOf('فشل الاتصال') !== -1) return true;
            if (/^connection failed$/i.test(s.replace(/^[❌⚠️]\s*/, '').trim())) return true;
            try {
                if (typeof t === 'function') {
                    var k = t('toast_connection_failed');
                    if (k && k !== 'toast_connection_failed' && s.indexOf(k) !== -1) return true;
                }
            } catch (_eI18n) {}
            return false;
        }
        function showToast(msg, type, opts) {
            if (type && typeof type === 'object' && opts == null) {
                opts = type;
                type = opts.type || 'success';
            }
            opts = opts || {};
            if (type === true) type = 'error';
            if (type !== 'error' && type !== 'warning' && type !== 'info') type = 'success';
            var loginEl = document.getElementById('login-screen');
            var loginOpen = loginEl && loginEl.style.display !== 'none';
            if (!loginOpen && isSpuriousConnectionFailedToast(msg)) {
                return;
            }
            const tEl = document.createElement('div');
            tEl.className = 'toast-msg ' + type;
            var icon = type === 'error' ? 'fa-exclamation-triangle' : (type === 'warning' ? 'fa-exclamation-circle' : 'fa-check-circle');
            var actionHtml = '';
            if (opts.actionLabel && typeof opts.onAction === 'function') {
                actionHtml = ' <button type="button" class="toast-msg__action">' + String(opts.actionLabel).replace(/</g, '&lt;') + '</button>';
            }
            tEl.innerHTML = '<i class="fas ' + icon + '"></i> <span class="toast-msg__text">' + (msg || '') + '</span>' + actionHtml;
            document.body.appendChild(tEl);
            var hideMs = Math.max(2500, parseInt(opts.durationMs, 10) || (actionHtml ? 10000 : 3000));
            var hideTimer = null;
            var removeToast = function () {
                tEl.classList.remove('show');
                setTimeout(function () { try { tEl.remove(); } catch (_e) {} }, 300);
            };
            if (actionHtml) {
                var btn = tEl.querySelector('.toast-msg__action');
                if (btn) {
                    btn.addEventListener('click', function (ev) {
                        ev.preventDefault();
                        ev.stopPropagation();
                        try { clearTimeout(hideTimer); } catch (_eT) {}
                        removeToast();
                        try { opts.onAction(); } catch (_eA) {}
                    });
                }
            }
            setTimeout(function () { tEl.classList.add('show'); }, 10);
            hideTimer = setTimeout(removeToast, hideMs);
        }
        if (typeof window !== 'undefined') window.showToast = showToast;

