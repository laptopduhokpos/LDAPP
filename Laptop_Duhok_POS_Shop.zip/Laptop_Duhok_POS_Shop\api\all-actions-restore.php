<?php
// POST: restore backup, archive
    // --- RESTORE BACKUP HANDLER (زڤڕاندنا داتایان) ---
    if($act == 'restore_backup') {
        pos_session_require_login_json();
        if (!pos_session_is_admin()) pos_json_perm_denied();
        ini_set('memory_limit', '2048M');
        ini_set('max_execution_time', '900');
        // Ensure only JSON is sent (no PHP notices/warnings as HTML)

        header('Content-Type: application/json; charset=utf-8');
        $sendJson = function($payload) { echo json_encode($payload, JSON_UNESCAPED_UNICODE); exit(); };

        $sources = function_exists('pos_collect_restore_upload_sources')
            ? pos_collect_restore_upload_sources()
            : [];
        if (!$sources) {
            $err = isset($_FILES['file']['error']) ? (int)$_FILES['file']['error'] : UPLOAD_ERR_NO_FILE;
            $hint = ($err === UPLOAD_ERR_INI_SIZE || $err === UPLOAD_ERR_FORM_SIZE)
                ? ' (پێویستە لە php.ini زیاد بکەیت: upload_max_filesize و post_max_size — Increase upload_max_filesize and post_max_size)'
                : '';
            $sendJson(["status"=>"error", "message"=>"هیچ فایلەک نەهاتیە هەڵبژاردن یان قەبارەک زۆر گەورەیە. (No file uploaded or too large)" . $hint]);
        }

        $loads = [];
        try {
            foreach ($sources as $src) {
                $loads[] = loadBackupPackageFromUpload($src[0], $src[1]);
            }
            $loaded = function_exists('pos_merge_restore_loads')
                ? pos_merge_restore_loads($loads)
                : $loads[0];
        } catch (\Throwable $e) {
            foreach ($loads as $L) {
                if (function_exists('pos_backup_close_loaded_package')) {
                    pos_backup_close_loaded_package($L);
                } elseif (isset($L['zip']) && $L['zip'] instanceof ZipArchive) {
                    @$L['zip']->close();
                }
            }
            $sendJson(["status"=>"error", "message"=>$e->getMessage()]);
        }

        try {
            if (isset($loaded['data']['table_data']) && is_array($loaded['data']['table_data'])) {
                pos_sanitize_backup_table_data($loaded['data']['table_data']);
            }
            if (function_exists('pos_assert_restore_payload_complete')) {
                pos_assert_restore_payload_complete($conn, $loaded);
            }
            pos_validate_full_restore_payload($conn, $loaded);
        } catch (\Throwable $e) {
            if (function_exists('pos_backup_close_loaded_package')) {
                pos_backup_close_loaded_package($loaded);
            } elseif (isset($loaded['zip']) && $loaded['zip'] instanceof ZipArchive) {
                @$loaded['zip']->close();
            }
            $sendJson(["status"=>"error", "message"=>$e->getMessage()]);
        }

        $conn->begin_transaction();
        $prev = set_error_handler(function($errNo, $errStr) { throw new \ErrorException($errStr, 0, $errNo); });
        try {
            $restoredFiles = 0;
            $restoredTables = [];
            $restoreMode = ($loaded['mode'] ?? 'legacy');

            if (($loaded['mode'] ?? '') === 'package') {
                $payload = $loaded['data'];
                restoreTableDataGeneric($conn, $payload['table_data']);
                $restoredTables = array_keys($payload['table_data']);
                if (isset($loaded['zip']) && $loaded['zip'] instanceof ZipArchive) {
                    $restoredFiles = restoreFilesystemFromPackageZip($loaded['zip'], __DIR__ . '/..');
                } elseif (!empty($loaded['extract_dir']) && function_exists('restoreFilesystemFromExtractDir')) {
                    $restoredFiles = restoreFilesystemFromExtractDir($loaded['extract_dir'], __DIR__ . '/..');
                }
                if (function_exists('pos_backup_close_loaded_package')) {
                    pos_backup_close_loaded_package($loaded);
                }
                $restoreMode = !empty($payload['_restored_from_parts']) ? 'package_merged' : 'package';
            } else {
                $raw = $loaded['data'];
                if (backupPayloadUsesSqlTableData($conn, $raw)) {
                    restoreTableDataGeneric($conn, $raw['table_data']);
                    $restoredTables = array_keys($raw['table_data']);
                    $restoreMode = 'sql_json';
                } else {
                    $normalized = normalizeBackupPayload($raw);
                    $asTableData = function_exists('pos_normalized_to_sql_table_data')
                        ? pos_normalized_to_sql_table_data($conn, $normalized)
                        : [];
                    if (!empty($asTableData)) {
                        pos_sanitize_backup_table_data($asTableData);
                        restoreTableDataGeneric($conn, $asTableData);
                        $restoredTables = array_keys($asTableData);
                        $restoreMode = 'legacy_generic';
                    } else {
                        performRestoreLogic($conn, $normalized);
                        $restoredTables = array_keys(array_filter($normalized, function($v){ return is_array($v); }));
                        $restoreMode = 'legacy';
                    }
                }
            }
            
            if (isset($_POST['force_currency']) && in_array($_POST['force_currency'], ['USD', 'IQD'])) {
                $forcedCurrency = $_POST['force_currency'];
                $newSettings = function_exists('pos_load_app_settings_array')
                    ? pos_load_app_settings_array($conn)
                    : [];
                if (!is_array($newSettings)) {
                    $newSettings = [];
                }
                $newSettings['currencyMode'] = $forcedCurrency;
                $newSettings['defaultCurrency'] = $forcedCurrency;
                $newSettings['default_currency'] = $forcedCurrency;
                if ($forcedCurrency === 'USD') {
                    $rateBundle = isset($newSettings['usdRate']) ? (int)round((float)$newSettings['usdRate']) : 0;
                    if ($rateBundle < 1000) {
                        $newSettings['usdRate'] = 150000;
                    }
                }
                $newSettingsJson = json_encode($newSettings, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
                if ($newSettingsJson !== false) {
                    if (function_exists('pos_db_set_setting_value')) {
                        pos_db_set_setting_value($conn, 'app_settings', $newSettingsJson);
                    } else {
                        $stmtUpdate = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('app_settings', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
                        $stmtUpdate->bind_param("ss", $newSettingsJson, $newSettingsJson);
                        $stmtUpdate->execute();
                    }
                }
            }

            $conn->commit();
            if (function_exists('pos_heal_currency_schema')) {
                try {
                    $healMode = isset($forcedCurrency) ? $forcedCurrency : null;
                    pos_heal_currency_schema($conn, $healMode);
                } catch (Throwable $eHeal) {
                    if (function_exists('pos_migrations_log')) {
                        pos_migrations_log('restore_fx_heal: ' . $eHeal->getMessage());
                    }
                }
            }
            touchLastUpdate($conn);
            logAction($conn, 'System', 'restore_backup', "System restored from backup (" . $restoreMode . ")");
            restore_error_handler();
            $counts = [];
            foreach ($restoredTables as $tbl) {
                $tblEsc = str_replace('`', '``', $tbl);
                $resCnt = @$conn->query("SELECT COUNT(*) c FROM `{$tblEsc}`");
                if ($resCnt && ($r = $resCnt->fetch_assoc())) $counts[$tbl] = (int)($r['c'] ?? 0);
            }
            $sendJson([
                "status"=>"success",
                "mode" => $restoreMode,
                "currencyMode" => isset($forcedCurrency) ? $forcedCurrency : null,
                "restored_files" => $restoredFiles,
                "restored_tables" => count($restoredTables),
                "table_counts" => $counts
            ]);
        } catch (\Throwable $e) {
            restore_error_handler();
            if (function_exists('pos_backup_close_loaded_package')) {
                pos_backup_close_loaded_package($loaded);
            } elseif (isset($loaded['zip']) && $loaded['zip'] instanceof ZipArchive) {
                @$loaded['zip']->close();
            }
            if ($conn) $conn->rollback();
            $sendJson(["status"=>"error", "message"=>$e->getMessage()]);
        }
    }

    /**
     * Apply flash continuous-sync deltas AFTER a full restore.
     * Does NOT truncate — UPSERT only (latest sales/stock from changes.jsonl).
     */
    if ($act == 'apply_flash_delta') {
        pos_session_require_login_json();
        if (!pos_session_is_admin()) pos_json_perm_denied();
        ini_set('memory_limit', '2048M');
        ini_set('max_execution_time', '900');
        header('Content-Type: application/json; charset=utf-8');
        $sendJson = function ($payload) {
            echo json_encode($payload, JSON_UNESCAPED_UNICODE);
            exit();
        };

        $raw = '';
        if (!empty($_FILES['file']['tmp_name']) && is_uploaded_file($_FILES['file']['tmp_name'])) {
            $raw = (string)@file_get_contents($_FILES['file']['tmp_name']);
        } elseif (!empty($_POST['delta_json'])) {
            $raw = (string)$_POST['delta_json'];
        } elseif (!empty($_POST['delta_jsonl'])) {
            $raw = (string)$_POST['delta_jsonl'];
        } else {
            $body = file_get_contents('php://input');
            if (is_string($body) && $body !== '') $raw = $body;
        }
        $raw = trim($raw);
        if ($raw === '') {
            $sendJson(['status' => 'success', 'applied_chunks' => 0, 'rows' => 0, 'message' => 'no_delta']);
        }

        $chunks = [];
        // Single JSON object
        if ($raw !== '' && ($raw[0] === '{' || $raw[0] === '[')) {
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                if (isset($decoded['table_data']) || (($decoded['_format'] ?? '') === 'flash_delta_v1')) {
                    $chunks[] = $decoded;
                } elseif (array_keys($decoded) === range(0, count($decoded) - 1)) {
                    foreach ($decoded as $item) {
                        if (is_array($item)) $chunks[] = $item;
                    }
                }
            }
        }
        // JSONL (one delta per line) — primary format on flash
        if (!$chunks) {
            $lines = preg_split("/\r\n|\n|\r/", $raw) ?: [];
            foreach ($lines as $line) {
                $line = trim($line);
                if ($line === '') continue;
                $obj = json_decode($line, true);
                if (!is_array($obj)) continue;
                if (isset($obj['table_data']) || (($obj['_format'] ?? '') === 'flash_delta_v1')) {
                    $chunks[] = $obj;
                }
            }
        }

        if (!$chunks) {
            $sendJson(['status' => 'success', 'applied_chunks' => 0, 'rows' => 0, 'message' => 'empty_delta']);
        }

        $totalRows = 0;
        $tablesTouched = [];
        $conn->begin_transaction();
        try {
            foreach ($chunks as $chunk) {
                $td = isset($chunk['table_data']) && is_array($chunk['table_data']) ? $chunk['table_data'] : [];
                if (!$td) continue;
                if (function_exists('pos_sanitize_backup_table_data')) {
                    pos_sanitize_backup_table_data($td);
                }
                foreach ($td as $t => $rows) {
                    if (!is_array($rows)) continue;
                    $totalRows += count($rows);
                    $tablesTouched[$t] = true;
                }
                // No truncate — merge latest rows onto restored snapshot
                restoreTableDataGeneric($conn, $td, ['truncate' => false]);
            }
            $conn->commit();
            if (function_exists('pos_heal_currency_schema')) {
                try {
                    pos_heal_currency_schema($conn);
                } catch (Throwable $eHealDelta) {}
            }
            if (function_exists('touchLastUpdate')) touchLastUpdate($conn);
            if (function_exists('logAction')) {
                logAction($conn, 'System', 'apply_flash_delta', 'Applied flash deltas chunks=' . count($chunks) . ' rows=' . $totalRows);
            }
            $sendJson([
                'status' => 'success',
                'applied_chunks' => count($chunks),
                'rows' => $totalRows,
                'tables' => array_keys($tablesTouched),
            ]);
        } catch (\Throwable $e) {
            if ($conn) $conn->rollback();
            $sendJson(['status' => 'error', 'message' => $e->getMessage()]);
        }
    }

    if ($act == 'regenerate_mobile_backup_pin') {
        pos_session_require_login_json();
        if (!pos_session_is_admin()) pos_json_perm_denied();
        header('Content-Type: application/json; charset=utf-8');
        try {
            $pin = function_exists('pos_regenerate_mobile_backup_pin')
                ? pos_regenerate_mobile_backup_pin($conn)
                : '';
            echo json_encode(['status' => 'success', 'pin' => $pin], JSON_UNESCAPED_UNICODE);
        } catch (\Throwable $e) {
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
        }
        exit();
    }

    // --- Restore raw XAMPP mysql/data ZIP (stop MySQL first) ---
    if ($act == 'restore_mysql_data_backup') {
        pos_session_require_login_json();
        if (!pos_session_is_admin()) pos_json_perm_denied();
        ini_set('memory_limit', '2048M');
        ini_set('max_execution_time', '900');
        header('Content-Type: application/json; charset=utf-8');

        $confirm = isset($_POST['confirm']) ? trim((string)$_POST['confirm']) : '';
        if ($confirm !== 'STOP_MYSQL') {
            echo json_encode([
                'status' => 'error',
                'message' => 'سەرەتا MySQL بوەستێنە لە XAMPP، پاشان بنووسە STOP_MYSQL بۆ دڵنیایی.',
            ], JSON_UNESCAPED_UNICODE);
            exit();
        }

        $tmpName = null;
        $fileName = '';
        if (!empty($_POST['backup_name']) && function_exists('pos_resolve_local_backup_path')) {
            try {
                $tmpName = pos_resolve_local_backup_path($_POST['backup_name']);
                $fileName = basename($tmpName);
            } catch (\Throwable $e) {
                echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
                exit();
            }
        } elseif (isset($_FILES['file']) && !empty($_FILES['file']['tmp_name'])) {
            $tmpName = $_FILES['file']['tmp_name'];
            $fileName = $_FILES['file']['name'] ?? 'mysql_data.zip';
        }
        if (!$tmpName || !is_file($tmpName)) {
            echo json_encode(['status' => 'error', 'message' => 'فایلی ZIP هەڵنەبژێردرا.'], JSON_UNESCAPED_UNICODE);
            exit();
        }

        try {
            $result = pos_restore_mysql_data_from_zip($tmpName, [
                'force' => !empty($_POST['force']) && (string)$_POST['force'] === '1',
            ]);
            if (function_exists('logAction')) {
                logAction($conn, 'System', 'restore_mysql_data', 'Restored XAMPP mysql/data from ' . $fileName);
            }
            echo json_encode([
                'status' => 'success',
                'message' => 'mysql/data گەڕایەوە — MySQL Start بکە لە XAMPP',
                'result' => $result,
            ], JSON_UNESCAPED_UNICODE);
        } catch (\Throwable $e) {
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
        }
        exit();
    }

    // --- NEW: UPDATE CUSTOMER DISPLAY STATE (POST) ---
    if($act == 'update_customer_display') {
        $data = $_POST['data'];
        $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('customer_display_state', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        $stmt->bind_param("ss", $data, $data);
        $stmt->execute();
        echo json_encode(["status"=>"success"]);
        exit();
    }

    // --- NEW: ARCHIVE OLD DATA ---
    if($act == 'archive_old_data') {
        $days = isset($_POST['days']) ? (int)$_POST['days'] : 365;
        
        $conn->begin_transaction();
        try {
            $result = function_exists('pos_archive_old_data')
                ? pos_archive_old_data($conn, $days)
                : ['archived_sales' => 0, 'archived_expenses' => 0];
            $archived_sales = (int)($result['archived_sales'] ?? 0);
            $archived_expenses = (int)($result['archived_expenses'] ?? 0);
            
            $conn->commit();
            touchLastUpdate($conn);
            logAction($conn, 'System', 'archive_data', "Archived $archived_sales sales and $archived_expenses expenses older than $days days");
            echo json_encode(["status"=>"success", "archived_sales" => $archived_sales, "archived_expenses" => $archived_expenses]);
            exit();
        } catch (\Throwable $e) {
            $conn->rollback();
            echo json_encode(["status"=>"error", "message"=>$e->getMessage()]);
            exit();
        }
    }

    if ($act == 'delete_archived_data') {
        $days = isset($_POST['days']) ? (int)$_POST['days'] : 365;
        $confirm = isset($_POST['confirm']) ? trim((string)$_POST['confirm']) : '';

        if ($days === 0 && $confirm !== 'DELETE') {
            echo json_encode([
                'status' => 'error',
                'message' => 'بۆ سڕینەوەی هەموو ئەرشیف بنووسە DELETE لە دڵنیایی دا.',
            ]);
            exit();
        }

        $conn->begin_transaction();
        try {
            $deleted_sales = 0;
            $deleted_expenses = 0;

            if ($days === 0) {
                $conn->query('DELETE FROM sales_archive');
                $deleted_sales = (int)$conn->affected_rows;
                $conn->query('DELETE FROM expenses_archive');
                $deleted_expenses = (int)$conn->affected_rows;
            } else {
                $date_limit = date('Y-m-d H:i:s', strtotime("-{$days} days"));

                $stmt = $conn->prepare('DELETE FROM sales_archive WHERE created_at < ?');
                $stmt->bind_param('s', $date_limit);
                $stmt->execute();
                $deleted_sales = (int)$stmt->affected_rows;
                $stmt->close();

                $stmt2 = $conn->prepare('DELETE FROM expenses_archive WHERE `date` < ?');
                $stmt2->bind_param('s', $date_limit);
                $stmt2->execute();
                $deleted_expenses = (int)$stmt2->affected_rows;
                $stmt2->close();
            }

            $conn->commit();
            touchLastUpdate($conn);
            logAction($conn, 'System', 'delete_archived_data', "Deleted $deleted_sales archived sales and $deleted_expenses archived expenses (days=$days)");
            echo json_encode([
                'status' => 'success',
                'deleted_sales' => $deleted_sales,
                'deleted_expenses' => $deleted_expenses,
            ]);
            exit();
        } catch (\Throwable $e) {
            $conn->rollback();
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
            exit();
        }
    }

    if ($act === 'run_ten_year_maintenance') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        if (!pos_session_is_admin()) pos_json_perm_denied();

        $movementYears = isset($_POST['movement_years']) ? (int)$_POST['movement_years'] : 0;
        if ($movementYears > 0 && (!isset($_POST['confirm_movements']) || $_POST['confirm_movements'] !== 'YES')) {
            echo json_encode([
                'status' => 'error',
                'message' => 'بۆ پاککردنی stock_movements کۆن بنووسە YES لە confirm_movements.',
            ], JSON_UNESCAPED_UNICODE);
            exit();
        }

        $conn->begin_transaction();
        try {
            $result = function_exists('pos_run_ten_year_maintenance')
                ? pos_run_ten_year_maintenance($conn, [
                    'archive_days' => (int)($_POST['archive_days'] ?? 365),
                    'audit_days' => (int)($_POST['audit_days'] ?? 365),
                    'print_days' => (int)($_POST['print_days'] ?? 365),
                    'movement_years' => $movementYears,
                    'snapshot_keep' => (int)($_POST['snapshot_keep'] ?? 10),
                ])
                : [];
            $conn->commit();
            touchLastUpdate($conn);
            logAction($conn, 'System', 'ten_year_maintenance', json_encode($result, JSON_UNESCAPED_UNICODE));
            echo json_encode(['status' => 'success', 'result' => $result], JSON_UNESCAPED_UNICODE);
            exit();
        } catch (\Throwable $e) {
            $conn->rollback();
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
            exit();
        }
    }

    if ($act === 'cleanup_operational_data') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        if (!pos_session_is_admin()) pos_json_perm_denied();

        $movementYears = isset($_POST['movement_years']) ? (int)$_POST['movement_years'] : 0;
        if ($movementYears > 0 && (!isset($_POST['confirm_movements']) || $_POST['confirm_movements'] !== 'YES')) {
            echo json_encode([
                'status' => 'error',
                'message' => 'بۆ پاککردنی stock_movements کۆن بنووسە YES لە confirm_movements.',
            ], JSON_UNESCAPED_UNICODE);
            exit();
        }

        $conn->begin_transaction();
        try {
            $deleted = function_exists('pos_cleanup_operational_data')
                ? pos_cleanup_operational_data($conn, [
                    'audit_days' => (int)($_POST['audit_days'] ?? 365),
                    'print_days' => (int)($_POST['print_days'] ?? 365),
                    'movement_years' => $movementYears,
                    'snapshot_keep' => (int)($_POST['snapshot_keep'] ?? 10),
                ])
                : [];
            $conn->commit();
            touchLastUpdate($conn);
            logAction($conn, 'System', 'cleanup_operational_data', json_encode($deleted, JSON_UNESCAPED_UNICODE));
            echo json_encode(['status' => 'success', 'deleted' => $deleted], JSON_UNESCAPED_UNICODE);
            exit();
        } catch (\Throwable $e) {
            $conn->rollback();
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
            exit();
        }
    }

    if ($act === 'repair_sale_cogs') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        if (!pos_session_is_admin()) pos_json_perm_denied();
        if (!isset($_POST['confirm']) || $_POST['confirm'] !== 'YES') {
            echo json_encode([
                'status' => 'error',
                'message' => 'بۆ دڵنیایی بنووسە YES.',
            ], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $conn->begin_transaction();
        try {
            $result = function_exists('pos_repair_historical_sale_cogs')
                ? pos_repair_historical_sale_cogs($conn)
                : [];
            $conn->commit();
            touchLastUpdate($conn);
            logAction($conn, 'System', 'repair_sale_cogs', json_encode($result, JSON_UNESCAPED_UNICODE));
            echo json_encode(['status' => 'success', 'result' => $result], JSON_UNESCAPED_UNICODE);
            exit();
        } catch (\Throwable $e) {
            $conn->rollback();
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
            exit();
        }
    }
