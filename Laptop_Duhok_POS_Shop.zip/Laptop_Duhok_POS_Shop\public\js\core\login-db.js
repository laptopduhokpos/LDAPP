// core/login-db.js — connect DB, login, confirm
        function connectToDB(isRefresh = false, options = {}) {
            options = options || {};
            var runConnect = function () {
            if (window.__posTerminalMacMissing && posIsFragiDeviceMode()) {
                posShowTerminalActivationScreen({
                    status: 'device_blocked',
                    device_detail: 'network_mac_required',
                    message: (typeof t === 'function') ? t('terminal_network_mac_required') : 'Wi‑Fi/LAN MAC پێویستە بۆ لاپتۆپی فرعی.',
                    terminal_activation_required: true
                });
                return Promise.resolve(null);
            }
            var useBootstrap = options.fullData !== true;
            var licenseRecheckQs = isRefresh ? '' : '&license_recheck=1';
            try {
                if (sessionStorage.getItem('pos_post_shift_reload') === '1') {
                    sessionStorage.removeItem('pos_post_shift_reload');
                    licenseRecheckQs = '';
                }
            } catch (_ePsrLic) {}
            if (!isRefresh && typeof isPosCpuSaveMode === 'function' && isPosCpuSaveMode()) {
                licenseRecheckQs = '';
            }
            // First open / login screen: skip forced live license recheck (was 8–32s hang → «پەیوەندی…»)
            try {
                if (!isRefresh && sessionStorage.getItem('pos_session_active') !== '1') {
                    licenseRecheckQs = '';
                }
            } catch (_eLicBoot) {}
            if (options.fromLogin) {
                licenseRecheckQs = '';
            }
            var _gfxQ = (typeof window.POS_GRAPHICS_QUALITY !== 'undefined') ? window.POS_GRAPHICS_QUALITY : '';
            var _largeCat = false;
            try { _largeCat = sessionStorage.getItem('pos_large_catalog') === '1'; } catch (eLc) {}
            try {
                if (sessionStorage.getItem('pos_large_shop') === '1') window.__posLargeShop = true;
            } catch (eLsBoot) {}
            var _useLiteProducts = (_gfxQ === 'low') || _largeCat || window.__posLargeCatalog === true || window.__posLargeShop === true;
            var _liteProd = _useLiteProducts ? '&lite_products=1' : '';
            if (_useLiteProducts) window.__posProductsLiteLoaded = true;
            else window.__posProductsLiteLoaded = false;
            var _catalogTierQs = (typeof posCatalogTierQueryString === 'function')
                ? posCatalogTierQueryString({ fullData: options.fullData === true })
                : '&catalog_tier=weak';
            var dataUrl = useBootstrap
                ? ('?action=get_data&bootstrap=1' + licenseRecheckQs + _liteProd + _catalogTierQs + '&t=' + Date.now())
                : ('?action=get_data' + licenseRecheckQs + _liteProd + _catalogTierQs + '&t=' + Date.now());
            if (options.autoResume) {
                if (typeof showAppBootLoader === 'function') showAppBootLoader();
                var st = document.getElementById('startup-screen');
                if (st) st.style.display = 'none';
            }
            // Device register is admin/security only — do not block POS data load on Supabase.
            if (typeof window.__posDeviceRegisterPromise !== 'undefined') {
                Promise.resolve(window.__posDeviceRegisterPromise).then(function (regResult) {
                    if (!regResult) return;
                    if (regResult && posIsTerminalProPlusBlock(regResult)) {
                        posShowTerminalProPlusRequiredScreen(regResult);
                    } else if (regResult && posIsTerminalSlotRegisterBlock(regResult)) {
                        posShowDeviceBlocked(regResult);
                    }
                }).catch(function () {});
            }
            var fetchData = function () {
                if (!isRefresh && !options.autoResume && window.__posBootstrapPrefetchPromise) {
                    var pref = window.__posBootstrapPrefetchPromise;
                    window.__posBootstrapPrefetchPromise = null;
                    return pref.then(function (cached) {
                        if (posBootstrapPrefetchUsable(cached)) return cached;
                        return apiJson(dataUrl);
                    }).catch(function () { return apiJson(dataUrl); });
                }
                // Login path: hard timeout so first-install / new laptop never hangs forever
                if (options.fromLogin && typeof AbortController !== 'undefined') {
                    var ac = new AbortController();
                    var _lanTerm = (typeof posIsRemoteLanPosClient === 'function' && posIsRemoteLanPosClient())
                        || (typeof posIsFragiDeviceMode === 'function' && posIsFragiDeviceMode());
                    var to = setTimeout(function () {
                        try { ac.abort(); } catch (_eAb2) {}
                    }, _lanTerm ? 28000 : 10000);
                    return apiJson(dataUrl, { signal: ac.signal }).finally(function () {
                        try { clearTimeout(to); } catch (_eClr) {}
                    }).catch(function (err) {
                        var aborted = err && (err.name === 'AbortError' || /abort/i.test(String(err && err.message || '')));
                        if (aborted) {
                            console.warn('[pos] get_data timeout on login — opening with partial data');
                            return null;
                        }
                        throw err;
                    });
                }
                return apiJson(dataUrl);
            };
            return fetchData().then(function (data) {
                return data;
            }).then(function(data) {
                if (!data) return;
                if (data.status === 'license_blocked') {
                    posShowLicenseBlocked(data);
                    return;
                }
                if (posIsTerminalProPlusBlock(data)) {
                    posShowTerminalProPlusRequiredScreen(data);
                    return;
                }
                if (data.status === 'device_blocked') {
                    if (posIsTerminalProPlusBlock(data)) {
                        posShowTerminalProPlusRequiredScreen(data);
                    } else if (posShouldShowTerminalActivationScreen(data)) {
                        posShowTerminalActivationScreen(data);
                    } else {
                        posShowDeviceBlocked(data);
                    }
                    return;
                }
                posHideDeviceBlockedScreen();
                posHideTerminalProPlusRequiredScreen();
                posHideTerminalActivationScreen();
                var _needLoginData = (data.status === 'auth_required')
                    || (data.status === 'error' && data.message && String(data.message).toLowerCase().indexOf('login required') >= 0);
                if (_needLoginData) {
                    window.__posBootstrapPrefetchPromise = null;
                    var loginFetch = window.__posLoginPrefetchPromise
                        ? window.__posLoginPrefetchPromise.catch(function () {
                            return apiJson('?action=get_login_data&t=' + Date.now());
                        })
                        : apiJson('?action=get_login_data&t=' + Date.now());
                    return loginFetch.then(function(loginData) {
                        if (loginData.status === 'license_blocked') {
                            posShowLicenseBlocked(loginData);
                            return;
                        }
                        if (posIsTerminalProPlusBlock(loginData)) {
                            posShowTerminalProPlusRequiredScreen(loginData);
                            return;
                        }
                        if (loginData.status === 'device_blocked') {
                            if (posIsTerminalProPlusBlock(loginData)) {
                                posShowTerminalProPlusRequiredScreen(loginData);
                            } else if (posShouldShowTerminalActivationScreen(loginData)) {
                                posShowTerminalActivationScreen(loginData);
                            } else {
                                posShowDeviceBlocked(loginData);
                            }
                            return;
                        }
                        posHideDeviceBlockedScreen();
                        posHideTerminalProPlusRequiredScreen();
                        posHideTerminalActivationScreen();
                        var defaultQuickItems = [{ name: 'طباعة A4', price: 500 }, { name: 'عمل CV', price: 10000 }, { name: 'نسخ', price: 250 }];
                        const defaults = { cafeName: "لپتۆپ دهۆک - لاب توب دهوك", cafeInfo: "", footer: "سوپاس بۆ سەردانتان - شكراً لزيارتكم", logo: "", paperWidth: "80mm", tgToken: "", tgChatId: "", autoPrint: true, enableTakeaway: false, systemMode: 'market', useBarcode: true, theme: 'light', enableDebt: true, showTables: false, showCustomerName: true, enableKitchen: true, showItemNoteIcon: false, enableWaste: true, enableRecipe: false, enableWholesale: false, enableWarehouse: true, enableCompanies: true, enablePurchase: true, enableReports: true, enableDelivery: false, enableMultiWarehouse: false, enableExpenses: true, enableCalendar: true, enableNotifications: true, hideWarehouseStockWarn: false, enableStaff: true, enableReturns: true, telegramReportInterval: 0, salesSinceLastReport: 0, settingsPin: "2026", usdRate: 150000, currencyMode: 'IQD', currencyBaseLocked: false, showPrintNotePopup: false, showPaymentModal: false, printInvoiceBarcode: true, language: 'badini', manualQuickItems: defaultQuickItems, enableMultiCartTabs: true, enableMoneyRounding: false, enableManualSale: false, enableGift: false, unlockStaffBeyondFive: false, takeawayAsWholesale: false, requireOpeningBalancePrompt: false, requireEndShiftReconcilePrompt: false, showStockOnPos: true, labelProductMinStockAlert: 'حد تنبيه الكمية', labelProductExpiryAlertDays: 'تنبيه قبل الانتهاء (یوم)', thermalReceiptOptions: THERMAL_RECEIPT_OPTIONS_DEFAULTS, tg_shift_start_report: true, tg_shift_end_report: true, tg_include_cash_in_drawer: true, tg_report_type: 'full', showFinancialSummaryOnA4: true };
                        db = { users: loginData.users || [], settings: { ...defaults, ...(loginData.settings || {}) }, tables: [], products: [], sales: [], expenses: [], companies: [], manufacturers: [], supplies: [], ledger: [], customers: [], customer_ledger: [], waste: [], recipes: [], returns: [], deliveries: [], drivers: [], logs: [], shifts: [], print_log: [] };
                        if (typeof localStorage !== 'undefined') {
                            var _lsL = (typeof normalizePosLanguageValue === 'function') ? normalizePosLanguageValue(localStorage.getItem('pos_language')) : null;
                            if (_lsL) db.settings.language = _lsL;
                        }
                        if(!db.users.length) db.users = [{ id: 1, name: 'Manager', role: 'admin' }];
                        if (typeof applyCurrencyFromLocalStorage === 'function') applyCurrencyFromLocalStorage();
                        revealLoginScreenFast(db.users);
                        deferPostLoginChromeWork(function () {
                            applyTheme();
                            if (typeof applyLanguage === 'function') applyLanguage({ deferNav: true, scopeLogin: true, skipNavPaint: true });
                        });
                    });
                }
                var defaultQuickItems = [{ name: 'طباعة A4', price: 500 }, { name: 'عمل CV', price: 10000 }, { name: 'نسخ', price: 250 }];
                const defaults = { cafeName: "لپتۆپ دهۆک - لاب توب دهوك", cafeInfo: "", footer: "سوپاس بۆ سەردانتان - شكراً لزيارتكم", logo: "", paperWidth: "80mm", tgToken: "", tgChatId: "", autoPrint: true, enableTakeaway: false, systemMode: 'market', useBarcode: true, theme: 'light', enableDebt: true, showTables: false, showCustomerName: true, enableKitchen: true, showItemNoteIcon: false, enableWaste: true, enableRecipe: false, enableWholesale: false, enableWarehouse: true, enableCompanies: true, enablePurchase: true, enableReports: true, enableDelivery: false, enableMultiWarehouse: false, enableExpenses: true, enableCalendar: true, enableNotifications: true, hideWarehouseStockWarn: false, enableStaff: true, enableReturns: true, telegramReportInterval: 0, salesSinceLastReport: 0, settingsPin: "2026", usdRate: 150000, currencyMode: 'IQD', currencyBaseLocked: false, zoomLevel: 100, graphicsQuality: 'normal', showPrintNotePopup: false, showPaymentModal: false, printInvoiceBarcode: true, language: 'badini', manualQuickItems: defaultQuickItems, enableMultiCartTabs: true, enableMoneyRounding: false, enableManualSale: false, enableGift: false, unlockStaffBeyondFive: false, takeawayAsWholesale: false, requireOpeningBalancePrompt: false, requireEndShiftReconcilePrompt: false, showStockOnPos: true, labelProductMinStockAlert: 'حد تنبيه الكمية', labelProductExpiryAlertDays: 'تنبيه قبل الانتهاء (يوم)', thermalReceiptOptions: THERMAL_RECEIPT_OPTIONS_DEFAULTS, tg_shift_start_report: true, tg_shift_end_report: true, tg_include_cash_in_drawer: true, tg_report_type: 'full', showFinancialSummaryOnA4: true };
                const serverSettings = data.settings || {};

                if (options.fromLogin) {
                    posInvalidateFinancialCaches(currentUser && currentUser.id);
                    if (db) posClearDbTransactionalData();
                }

                if(isRefresh && db) {
                    // Smart Merge: bootstrap refresh must not wipe sales/expenses (loaded via secondary fetch).
                    if (Array.isArray(data.products)) {
                        var incomingProducts = data.products;
                        var hasLocalCatalog = Array.isArray(db.products) && db.products.length > 0;
                        var partialIncoming = !!(data.catalog_partial || (typeof posIsCatalogPartial === 'function' && hasLocalCatalog && posIsCatalogPartial()));
                        if (partialIncoming && hasLocalCatalog && typeof posUpsertProducts === 'function') {
                            posUpsertProducts(incomingProducts);
                            if (typeof posMarkCatalogMeta === 'function') posMarkCatalogMeta(data);
                        } else if (incomingProducts.length > 0 || !hasLocalCatalog) {
                            db.products = incomingProducts;
                            if (typeof window.invalidateWmsWarehouseCache === 'function') window.invalidateWmsWarehouseCache();
                            if (typeof invalidatePosMenuListCache === 'function') invalidatePosMenuListCache();
                        }
                        if (typeof repairJewelryCatalogInMemory === 'function') repairJewelryCatalogInMemory();
                    }
                    if (Array.isArray(data.companies)) {
                        var hasLocalCompanies = Array.isArray(db.companies) && db.companies.length > 0;
                        var partialCompanies = !!(data.companies_partial || (hasLocalCompanies && typeof posIsCompaniesPartial === 'function' && posIsCompaniesPartial()));
                        if (partialCompanies && hasLocalCompanies && typeof posUpsertCompanies === 'function') {
                            posUpsertCompanies(data.companies);
                            if (typeof posMarkEntitiesMeta === 'function') posMarkEntitiesMeta(data);
                        } else {
                            db.companies = data.companies;
                        }
                    }
                    if (Array.isArray(data.manufacturers)) db.manufacturers = data.manufacturers;
                    if (Array.isArray(data.drivers)) db.drivers = data.drivers;
                    if (Array.isArray(data.deliveries) && data.deliveries.length) {
                        if (!Array.isArray(db.deliveries) || !db.deliveries.length) {
                            db.deliveries = data.deliveries;
                        } else if (typeof window.posMergeDeliveryRow === 'function') {
                            data.deliveries.forEach(function (srvD) {
                                window.posMergeDeliveryRow(db.deliveries, srvD);
                            });
                        }
                    }
                    if (typeof normalizePosManufacturerSlotSettings === 'function') normalizePosManufacturerSlotSettings();
                    if (Array.isArray(data.users)) db.users = data.users;
                    if (Array.isArray(data.customers)) {
                        var hasLocalCustomers = Array.isArray(db.customers) && db.customers.length > 0;
                        var partialCustomers = !!(data.customers_partial || (hasLocalCustomers && typeof posIsCustomersPartial === 'function' && posIsCustomersPartial()));
                        if (partialCustomers && hasLocalCustomers && typeof posUpsertCustomers === 'function') {
                            posUpsertCustomers(data.customers);
                            if (typeof posMarkEntitiesMeta === 'function') posMarkEntitiesMeta(data);
                        } else {
                            db.customers = data.customers;
                        }
                    }
                    if (Array.isArray(data.installment_plans)) db.installment_plans = data.installment_plans;
                    if (Array.isArray(data.installment_items)) db.installment_items = data.installment_items;
                    if (typeof window.refreshEntityDatalists === 'function') window.refreshEntityDatalists();
                    if (Array.isArray(data.shifts)) db.shifts = data.shifts;
                    if (Array.isArray(data.categories)) db.categories = data.categories;
                    if (Array.isArray(data.warehouses)) db.warehouses = data.warehouses;
                    if (Array.isArray(data.warehouse_stock)) db.warehouse_stock = data.warehouse_stock;
                    if (typeof window.applyOpenWarehouseFromPayload === 'function') window.applyOpenWarehouseFromPayload(data);
                    else if (data.open_warehouse_id != null) db.open_warehouse_id = Number(data.open_warehouse_id) || 0;
                    if (typeof window.syncPosSaleWarehouseBtn === 'function') window.syncPosSaleWarehouseBtn();
                    if (typeof updateCurrencyLockUI === 'function') updateCurrencyLockUI();
                    if (!useBootstrap) {
                        if (data.sales !== undefined) db.sales = data.sales;
                        if (data.expenses !== undefined) db.expenses = data.expenses;
                        if (data.expenses_deleted !== undefined) db.expenses_deleted = data.expenses_deleted;
                        if (data.customer_ledger !== undefined) db.customer_ledger = data.customer_ledger;
                        if (data.waste !== undefined) db.waste = data.waste;
                        if (data.recipes !== undefined) db.recipes = data.recipes;
                        if (data.returns !== undefined) db.returns = data.returns;
                        if (data.purchase_returns) db.purchase_returns = data.purchase_returns;
                        if (data.supplies !== undefined) db.supplies = data.supplies;
                        if (data.ledger !== undefined) db.ledger = data.ledger;
                    }

                    // Merge Today Stats if available (warm daily-detail on login so dashboard is not stuck at zero)
                    if (data.today_stats) {
                        db.today_stats = data.today_stats;
                        if (options.fromLogin) {
                            posWarmTodayDetailCache();
                        } else if (typeof updateStats === 'function') {
                            updateStats();
                        }
                    }

                    // Only update tables that are NOT active to prevent losing unsaved clicks
                    if(data.tables) {
                        data.tables = normalizePosTables(data.tables);
                        data.tables.forEach(serverTable => {
                            if(serverTable.id !== activeTableId) {
                                const localIdx = db.tables.findIndex(t => t.id === serverTable.id);
                                if(localIdx > -1) db.tables[localIdx] = serverTable;
                            }
                        });
                    }
                } else {
                    db = data; // Load SQL data into JS object
                    if (db && db.tables) db.tables = normalizePosTables(db.tables);
                }
                if (db && Array.isArray(data.drivers) && data.drivers.length) db.drivers = data.drivers;
                if (db && Array.isArray(data.deliveries) && data.deliveries.length) {
                    if (!Array.isArray(db.deliveries) || !db.deliveries.length) {
                        db.deliveries = data.deliveries.slice();
                    } else if (typeof window.posMergeDeliveryRow === 'function') {
                        data.deliveries.forEach(function (srvD) { window.posMergeDeliveryRow(db.deliveries, srvD); });
                    }
                }
                if (data.license_serial) db.license_serial = String(data.license_serial);
                if (data.db_health && typeof data.db_health === 'object') db._db_health = data.db_health;
                if (typeof posMarkCatalogMeta === 'function') posMarkCatalogMeta(data);
                if (typeof posMarkEntitiesMeta === 'function') posMarkEntitiesMeta(data);
                if (data.license_security_code) db.license_security_code = String(data.license_security_code);
                if (data.subscription_tier) {
                    db.subscription_tier = String(data.subscription_tier);
                    if (!db.settings) db.settings = {};
                    db.settings.subscription_tier = db.subscription_tier;
                }
                if (data.subscription_entitlements) db.subscription_entitlements = data.subscription_entitlements;
                
                // Merge server settings with defaults, server settings take priority
                db.settings = {...defaults, ...serverSettings};
                if (db.subscription_tier) db.settings.subscription_tier = db.subscription_tier;
                try { if (typeof syncHomeShopLogo === 'function') syncHomeShopLogo(); } catch (_eHomeLogoSync) {}
                // First install / empty shop: default business mode = Market (not general)
                try {
                    var _modeNow = String(db.settings.systemMode || '').trim();
                    var _freshShop = (!Array.isArray(db.products) || !db.products.length)
                        && (!Array.isArray(db.sales) || !db.sales.length);
                    if (_freshShop && (!_modeNow || _modeNow === 'general') && db.settings.businessSetupDone !== true) {
                        if (typeof applyBusinessModePreset === 'function') {
                            applyBusinessModePreset('market');
                        } else {
                            db.settings.systemMode = 'market';
                            db.settings.showTables = true;
                            db.settings.enableDelivery = true;
                            db.settings.enableKitchen = false;
                            db.settings.enableRecipe = false;
                            db.settings.businessSetupDone = true;
                        }
                    }
                } catch (_eModeDef) {}
                if (typeof syncPurchasedFeaturesFromEntitlements === 'function') syncPurchasedFeaturesFromEntitlements();
                if (typeof normalizePosMaxStaffSettings === 'function') normalizePosMaxStaffSettings();
                if (typeof normalizePosMaxCartTabsSettings === 'function') normalizePosMaxCartTabsSettings();
                if (typeof syncInstallmentTabProLock === 'function') syncInstallmentTabProLock();
                
                // Authoritative Sync: localStorage MUST win for the current browser session
                if (typeof localStorage !== 'undefined') {
                    var _lsWin = (typeof normalizePosLanguageValue === 'function') ? normalizePosLanguageValue(localStorage.getItem('pos_language')) : null;
                    if (_lsWin) {
                        db.settings.language = _lsWin;
                    }
                    // Label printer: restore from this browser if server settings lack it
                    try {
                        var _lpName = String(localStorage.getItem('pos_label_printer_name') || '').trim();
                        var _lpId = String(localStorage.getItem('pos_label_printer_id') || '').trim();
                        if (_lpName || _lpId) {
                            if (!db.settings.labelPrint || typeof db.settings.labelPrint !== 'object') {
                                db.settings.labelPrint = {};
                            }
                            if (_lpName) {
                                db.settings.labelPrint.printerName = _lpName.slice(0, 120);
                            }
                            if (_lpId) {
                                db.settings.labelPrint.printerId = _lpId;
                            }
                        }
                    } catch (eLpBoot) {}
                    
                    var storedZoom = parseInt(localStorage.getItem('pos_zoom'), 10);
                    if (storedZoom && storedZoom >= 70 && storedZoom <= 150) {
                        db.settings.zoomLevel = storedZoom;
                    }
                    var storedGfx = localStorage.getItem('pos_graphics_quality');
                    if (storedGfx === 'low' || storedGfx === 'ultra' || storedGfx === 'normal') {
                        db.settings.graphicsQuality = storedGfx;
                    }
                    if (typeof autoConfigureGraphicsQualityIfNeeded === 'function') {
                        var _autoGfxTier = autoConfigureGraphicsQualityIfNeeded();
                        if (_autoGfxTier) {
                            db.settings.graphicsQuality = _autoGfxTier;
                            try { localStorage.setItem('pos_graphics_quality', _autoGfxTier); } catch (eGfxDb) {}
                        }
                    }
                    
                    try { localStorage.setItem('pos_startup_logo', (db.settings && db.settings.startupLogo) ? db.settings.startupLogo : ((db.settings && db.settings.logo) ? db.settings.logo : '')); } catch(e) {}
                }

                if(data.today_stats) db.today_stats = data.today_stats;
                if (data.db_health && (parseInt(data.db_health.products_count, 10) || 0) >= 1000) {
                    window.__posLargeCatalog = true;
                    try { sessionStorage.setItem('pos_large_catalog', '1'); } catch (eCat) {}
                    window.__posBootRenderLight = true;
                    if (typeof invalidatePosMenuListCache === 'function') invalidatePosMenuListCache();
                }
                if (data.db_health && typeof isPosLargeShopMode === 'function' && isPosLargeShopMode()) {
                    window.__posLargeShop = true;
                    window.__posBootRenderLight = true;
                    try { sessionStorage.setItem('pos_large_shop', '1'); } catch (eLs) {}
                } else if (data.large_shop) {
                    window.__posLargeShop = true;
                    window.__posBootRenderLight = true;
                    try { sessionStorage.setItem('pos_large_shop', '1'); } catch (eLs2) {}
                }
                if (typeof applyCurrencyFromLocalStorage === 'function') applyCurrencyFromLocalStorage();
                if (typeof persistSystemFeaturesToStorage === 'function') persistSystemFeaturesToStorage();

                var _loginVisible = document.getElementById('login-screen') && document.getElementById('login-screen').style.display !== 'none';
                var _weakBoot = (typeof isPosCpuSaveMode === 'function' && isPosCpuSaveMode());
                var _needsLogin = !isRefresh && !data.session_user;
                var deferChrome = _weakBoot && (_loginVisible || _needsLogin);
                var zoomVal = db.settings.zoomLevel || 100;

                if (_needsLogin && !window.__posLoginRevealed) {
                    revealLoginScreenFast(db.users);
                }

                var applyBootChrome = function () {
                    applyTheme();
                    applyZoomLevel(zoomVal);
                    if (typeof initGraphicsQualityFromStorage === 'function') initGraphicsQualityFromStorage();
                    if (!deferChrome && typeof initCartAppearanceFromStorage === 'function') initCartAppearanceFromStorage();
                    if (typeof applyLanguage === 'function') {
                        applyLanguage({
                            deferNav: _weakBoot || _loginVisible,
                            scopeLogin: _loginVisible || _needsLogin,
                            skipNavPaint: !!(_weakBoot && (_loginVisible || _needsLogin))
                        });
                    }
                    if (typeof window.syncPaymentToggles === 'function') window.syncPaymentToggles();
                };
                if (deferChrome && (_needsLogin || _loginVisible)) {
                    deferPostLoginChromeWork(applyBootChrome);
                } else {
                    applyBootChrome();
                }

                // Ensure defaults
                if (db && db.tables) db.tables = normalizePosTables(db.tables);
                if(!db.tables || !db.tables.length) db.tables = [{id: 1, name: 'T1', items:[]}, {id:2, name:'T2', items:[]}];
                if(!db.users || db.users.length === 0) db.users = [{ id: 1, name: 'Manager', pin: '2026', role: 'admin' }];
                if(!Array.isArray(db.settings.manualQuickItems)) db.settings.manualQuickItems = [{ name: 'طباعة A4', price: 500 }, { name: 'عمل CV', price: 10000 }, { name: 'نسخ', price: 250 }];
                if (db.settings.enableManualSale === undefined) db.settings.enableManualSale = false;
                if (db.settings.enableGift === undefined) db.settings.enableGift = false;
                if (db.settings.unlockStaffBeyondFive === undefined) db.settings.unlockStaffBeyondFive = false;
                if (typeof normalizePosMaxStaffSettings === 'function') normalizePosMaxStaffSettings();
                if (typeof normalizePosMaxCartTabsSettings === 'function') normalizePosMaxCartTabsSettings();
                if(!db.companies) db.companies = [];
                if(!db.manufacturers) db.manufacturers = [];
                if (typeof normalizePosManufacturerSlotSettings === 'function') normalizePosManufacturerSlotSettings();
                if(!db.supplies) db.supplies = [];
                if(!db.ledger) db.ledger = [];
                if(!db.customers) db.customers = [];
                if(!db.drivers) db.drivers = [];
                if(!db.customer_ledger) db.customer_ledger = [];
                if (typeof updateAutoPrintQuickButtonState === 'function') updateAutoPrintQuickButtonState();
                if (typeof updatePrintNotePopupQuickButtonState === 'function') updatePrintNotePopupQuickButtonState();
                if (typeof updateTelegramQuickButtonState === 'function') updateTelegramQuickButtonState();
                if (typeof window.posNotifyMobileDebtSync === 'function') {
                    window.posNotifyMobileDebtSync('bootstrap_data');
                }
                if (typeof window.posFirebasePushAfterDbReady === 'function') {
                    window.posFirebasePushAfterDbReady();
                }
                if(!db.waste) db.waste = [];
                if(!db.recipes) db.recipes = [];
                if (db.settings && db.settings.enableRecipe === undefined) {
                    db.settings.enableRecipe = !!(db.recipes && db.recipes.length > 0);
                }
                if(!db.returns) db.returns = [];
                if(!db.purchase_returns) db.purchase_returns = [];
                if(!db.logs) db.logs = [];
                if(!db.print_log) db.print_log = [];
                if (!Array.isArray(db.categories)) db.categories = [];
                if (typeof window.posAfterWarehouseDataLoaded === 'function') {
                    window.posAfterWarehouseDataLoaded(isRefresh ? 'db_refresh' : 'bootstrap_data');
                } else if (typeof window.healWarehouseStockMemory === 'function') {
                    window.healWarehouseStockMemory();
                }

                if(!isRefresh) {
                    var stHide = document.getElementById('startup-screen');
                    if (stHide) stHide.style.display = 'none';
                    if (data.session_user) {
                        try { sessionStorage.setItem('pos_session_active', '1'); } catch (_eSess) {}
                        document.documentElement.classList.remove('pos-pre-auth');
                        currentUser = data.session_user;
                        if (typeof posHideStartupScreens === 'function') posHideStartupScreens();
                        document.getElementById('user-display').innerText = typeof getUserDisplayLabel === 'function' ? getUserDisplayLabel(currentUser) : (currentUser.name + " (" + currentUser.role + ")");
                        var _su = document.getElementById('right-sidebar-user-name'); if(_su) _su.innerText = typeof getUserDisplayLabel === 'function' ? getUserDisplayLabel(currentUser) : (currentUser.name + " (" + currentUser.role + ")");
                        applySessionShellAfterData({ deferHeavyRender: !!options.autoResume });
                        if (useBootstrap) scheduleDataSecondaryFetch();
                        deferPosBackgroundTasks();
                        
                        if (db.settings.showTables !== true) {
                            showPosInitOverlay();
                            openDirectPOS({ markReady: true });
                        } else {
                            nav('calendar');
                            hidePosInitOverlay();
                        }
                        if (typeof posMarkShellReadyAndPaint === 'function') posMarkShellReadyAndPaint();
                        setTimeout(function () {
                            var hg = document.getElementById('home-grid-container');
                            if (!hg || !hg.querySelector('.home-card--skeleton')) return;
                            if (typeof posMarkShellReadyAndPaint === 'function') posMarkShellReadyAndPaint();
                        }, (typeof posStartupDeferMs === 'function') ? posStartupDeferMs(500) : 500);
                    } else {
                        try { sessionStorage.removeItem('pos_session_active'); } catch (_eSess0) {}
                        if (!window.__posLoginRevealed) {
                            revealLoginScreenFast(db.users);
                        }
                        if (typeof applySystemMode === 'function') {
                            applySystemMode({ deferNav: !!(typeof isPosCpuSaveMode === 'function' && isPosCpuSaveMode()) });
                        }
                    }
                } else {
                    var stayWs = document.querySelector('.workspace.active');
                    var stayPut = !!(stayWs && stayWs.id && currentUser);
                    if (!options.skipRenderOnRefresh && !stayPut) {
                        if (typeof window.isPosCpuSaveMode === 'function' && window.isPosCpuSaveMode()) {
                            window.__posBootRenderLight = true;
                        }
                        renderAll();
                    } else if (typeof posRefreshActiveWorkspaceData === 'function') {
                        try { posRefreshActiveWorkspaceData(); } catch (_eStay) {}
                    }
                    if(activeTableId) {
                        const t = db.tables.find(x => x.id === activeTableId);
                        if(t) renderBill(); else { activeTableId = null; nav('tables'); }
                    }
                }
                var _mustLoadSecondary = useBootstrap && (options.fromLogin || (options.autoResume && data.session_user));
                if (useBootstrap && isRefresh && !_mustLoadSecondary) {
                    scheduleDataSecondaryFetch();
                }
                var runDeferredChrome = function () {
                    if (typeof initCartAppearanceFromStorage === 'function') initCartAppearanceFromStorage();
                    schedulePosScanIndexBuild();
                    scheduleWarmPrintFrameDeferred();
                    if (typeof applyPremiumStartup === 'function') applyPremiumStartup();
                };
                if (deferChrome) {
                    deferPostLoginChromeWork(runDeferredChrome);
                } else {
                    if (typeof initCartAppearanceFromStorage === 'function') initCartAppearanceFromStorage();
                    schedulePosScanIndexBuild();
                    scheduleWarmPrintFrameDeferred();
                    if (typeof applyPremiumStartup === 'function') applyPremiumStartup();
                }
                if (typeof scheduleCatalogBackgroundLoad === 'function') scheduleCatalogBackgroundLoad();
                if (typeof scheduleEntitiesBackgroundLoad === 'function') scheduleEntitiesBackgroundLoad();
                if (typeof refreshBusinessDayStartHourControlState === 'function') refreshBusinessDayStartHourControlState();
                if (typeof refreshInstallationCodesInSettings === 'function') refreshInstallationCodesInSettings(data);
                if (typeof normalizePosMaxDailySalesSettings === 'function') normalizePosMaxDailySalesSettings();
                if (typeof posStartLicenseRecheckPoll === 'function') posStartLicenseRecheckPoll();
                updateSaveStatus(true);
                var _shouldPaint = !options.skipPaintAfterLoad && currentUser && (options.fromLogin || !isRefresh);
                // Login: open POS immediately — secondary books load in background (was the big delay).
                if (_mustLoadSecondary && options.fromLogin && options.skipPaintAfterLoad) {
                    scheduleDataSecondaryFetch({ immediate: true });
                    if (typeof checkInstallmentDueReminders === 'function') {
                        setTimeout(function () { checkInstallmentDueReminders(); }, 1200);
                    }
                    return;
                }
                if (_mustLoadSecondary) {
                    return posFetchSecondaryDataNow().then(function () {
                        if (_shouldPaint) {
                            return posAfterDataLoadPaint({ full: !!options.fromLogin, defer: !options.fromLogin }).then(function () {
                                if (typeof checkInstallmentDueReminders === 'function') checkInstallmentDueReminders();
                            });
                        }
                        if (typeof checkInstallmentDueReminders === 'function') checkInstallmentDueReminders();
                    });
                }
                if (_shouldPaint) {
                    return posAfterDataLoadPaint({ full: !!options.fromLogin, defer: !options.fromLogin }).then(function () {
                        if (typeof checkInstallmentDueReminders === 'function') checkInstallmentDueReminders();
                    });
                }
                if (typeof checkInstallmentDueReminders === 'function') checkInstallmentDueReminders();
            })
            .catch(function(err) {
                if (typeof hideAppBootLoader === 'function') hideAppBootLoader();
                // Background refresh / silent sync must never toast «پەیوەندی سەرنەکەفت»
                // (Firebase/Supabase/network blips while MySQL and the POS still work).
                if (isRefresh || options.silentFail || options.skipRenderOnRefresh) {
                    return;
                }
                var loginVisible = document.getElementById('login-screen') && document.getElementById('login-screen').style.display !== 'none';
                var startupVisible = document.getElementById('startup-screen') && document.getElementById('startup-screen').style.display !== 'none';
                if (loginVisible || startupVisible) {
                    var msg = (typeof t === 'function' ? t('toast_connection_failed') : 'Connection Failed');
                    var errEl = document.getElementById('login-error');
                    if (errEl) errEl.innerText = msg;
                    else alert(msg + ': ' + err);
                }
            })
            .finally(function () {
                var loginVisible = document.getElementById('login-screen') && document.getElementById('login-screen').style.display !== 'none';
                var startupVisible = document.getElementById('startup-screen') && document.getElementById('startup-screen').style.display !== 'none';
                if ((loginVisible || startupVisible) && typeof hideAppBootLoader === 'function') {
                    hideAppBootLoader();
                }
            });
            };
            function posWaitDeviceBootstrap() {
                // Login must not wait for device/Supabase bootstrap (new laptop hang → «پەیوەندی…»)
                if (options.fromLogin) return Promise.resolve();
                var p = window.__posDeviceBootstrapPromise || Promise.resolve();
                var ms = (typeof posDeviceBootstrapWaitMs === 'function') ? posDeviceBootstrapWaitMs() : 0;
                if (!ms) {
                    // Still cap wait on cold start (first install) — never block forever
                    return Promise.race([
                        p,
                        new Promise(function (resolve) { setTimeout(resolve, 800); })
                    ]);
                }
                return Promise.race([
                    p,
                    new Promise(function (resolve) { setTimeout(resolve, ms); })
                ]);
            }
            return posWaitDeviceBootstrap().then(runConnect);
        }
        window.connectToDB = connectToDB;

        /** Tiny staff list — warms login dropdown on weak laptops. */
        function prefetchLoginStaffData() {
            if (window.__posLoginPrefetchPromise) return window.__posLoginPrefetchPromise;
            if (typeof apiJson !== 'function') return null;
            try {
                if (sessionStorage.getItem('pos_session_active') === '1') return null;
            } catch (_eLf) { return null; }
            window.__posLoginPrefetchPromise = apiJson('?action=get_login_data&t=' + Date.now());
            return window.__posLoginPrefetchPromise;
        }
        window.prefetchLoginStaffData = prefetchLoginStaffData;

        /** Warm bootstrap JSON while user is on startup screen (weak laptops). */
        function prefetchBootstrapData() {
            if (window.__posBootstrapPrefetchPromise) return window.__posBootstrapPrefetchPromise;
            if (typeof apiJson !== 'function') return null;
            try {
                if (sessionStorage.getItem('pos_session_active') === '1') return null;
            } catch (_ePf) { return null; }
            var st = document.getElementById('startup-screen');
            if (!st || st.style.display === 'none') return null;
            var _gfxQ = (typeof window.POS_GRAPHICS_QUALITY !== 'undefined') ? window.POS_GRAPHICS_QUALITY : 'low';
            var _lite = (_gfxQ !== 'normal') ? '&lite_products=1' : '';
            var _tierQs = (typeof posCatalogTierQueryString === 'function') ? posCatalogTierQueryString() : '&catalog_tier=weak';
            var url = '?action=get_data&bootstrap=1' + _lite + _tierQs + '&t=' + Date.now();
            var startFetch = function () { return apiJson(url); };
            window.__posBootstrapPrefetchPromise = (window.__posDeviceBootstrapPromise || Promise.resolve()).then(startFetch);
            return window.__posBootstrapPrefetchPromise;
        }
        window.prefetchBootstrapData = prefetchBootstrapData;

        (function posWarmBootstrapOnStartupScreen() {
            function kick() {
                if (window.__posBootstrapPrefetchStarted) return;
                window.__posBootstrapPrefetchStarted = true;
                try {
                    if (sessionStorage.getItem('pos_session_active') === '1') return;
                } catch (_eKick) { return; }
                prefetchBootstrapData();
                prefetchLoginStaffData();
            }
            var delay = 80;
            try {
                if (document.documentElement.classList.contains('pos-cpu-save')) delay = 0;
            } catch (_eDly) {}
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', function () { setTimeout(kick, delay); });
            } else {
                setTimeout(kick, delay);
            }
        })();

        /** After F5/Ctrl+R: skip startup button when PHP session still active. */
        (function posAutoResumeSessionIfActive() {
            function tryAutoStart() {
                if (window.__posAutoStartDone) return;
                if (!window.__posLegacyScriptsReady) {
                    window.addEventListener('pos-legacy-scripts-ready', tryAutoStart, { once: true });
                    return;
                }
                if (typeof connectToDB !== 'function') return;
                try {
                    if (sessionStorage.getItem('pos_session_active') !== '1') return;
                } catch (_eAuto) { return; }
                window.__posAutoStartDone = true;
                document.documentElement.classList.add('app-booting', 'pos-pre-auth');
                var st = document.getElementById('startup-screen');
                if (st) st.style.display = 'none';
                if (typeof showAppBootLoader === 'function') showAppBootLoader();
                connectToDB(false, { autoResume: true });
            }
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', tryAutoStart);
            } else {
                setTimeout(tryAutoStart, 0);
            }
        })();

        /** Once dated operations exist, changing report day-boundary would break consistency. */
        function hasReportingHistoryLockingBusinessDayStart() {
            if (!db) return false;
            if ((db.sales && db.sales.length > 0) || (db.archive && db.archive.length > 0)) return true;
            if (db.expenses && db.expenses.length > 0) return true;
            if (db.returns && db.returns.length > 0) return true;
            if (db.supplies && db.supplies.length > 0) return true;
            if (db.waste && db.waste.length > 0) return true;
            if (db.ledger && db.ledger.length > 0) return true;
            if (db.customer_ledger && db.customer_ledger.length > 0) return true;
            if (db.purchase_returns && db.purchase_returns.length > 0) return true;
            return false;
        }

        function refreshBusinessDayStartHourControlState() {
            var sel = document.getElementById('set-business-day-start-hour');
            var hint = document.getElementById('set-business-day-start-hour-hint');
            if (!sel) return;
            var locked = hasReportingHistoryLockingBusinessDayStart();
            sel.disabled = locked;
            sel.setAttribute('aria-disabled', locked ? 'true' : 'false');
            sel.style.opacity = locked ? '0.72' : '';
            sel.style.cursor = locked ? 'not-allowed' : '';
            var tip = locked
                ? (typeof t === 'function' ? t('business_day_start_locked_tooltip') : 'قفڵکراو دوای دەستپێکرنا کاروبار.')
                : '';
            sel.title = tip;
            if (hint) {
                if (locked) {
                    hint.textContent = typeof t === 'function' ? t('business_day_start_locked_hint') : 'دوای فرۆشتن یان دەخلکردن، دەستپێکی ڕۆژ بۆ ڕاپۆرت ناگۆڕدرێت.';
                    hint.style.display = 'block';
                } else {
                    hint.textContent = '';
                    hint.style.display = 'none';
                }
            }
        }
        window.refreshBusinessDayStartHourControlState = refreshBusinessDayStartHourControlState;

        /** Canonical unit toggles: icons, order, labels (POS / purchase / returns / supply). */
        window.POS_UNIT_ORDER = ['piece', 'pack', 'carton'];
        window.POS_UNIT_ICONS = { piece: 'fa-cube', pack: 'fa-boxes', carton: 'fa-box' };

        function normalizePosUnitCode(unitCode) {
            return (unitCode === 'carton' || unitCode === 'pack') ? unitCode : 'piece';
        }
        window.normalizePosUnitCode = normalizePosUnitCode;

        window.getPosUnitIconClass = function(unitCode) {
            var u = normalizePosUnitCode(unitCode);
            return 'fas ' + (window.POS_UNIT_ICONS[u] || window.POS_UNIT_ICONS.piece);
        };

        window.getDefaultUnitLabel = function(unitCode) {
            var u = normalizePosUnitCode(unitCode);
            var jewelry = (typeof isJewelryMode === 'function' && isJewelryMode());
            if (u === 'carton') return jewelry ? 'کۆمەڵ' : (typeof t === 'function' ? t('pos_unit_carton') : 'کارتۆن');
            if (u === 'pack') return jewelry ? 'سێت' : (typeof t === 'function' ? t('pos_unit_pack') : 'پاکێت');
            return jewelry ? 'دانە' : (typeof t === 'function' ? t('pos_unit_piece') : 'تاک');
        };

        window.getProductUnitLabel = function(prod, unitCode) {
            var u = normalizePosUnitCode(unitCode);
            if (prod && typeof prod === 'object') {
                var key = 'unit_name_' + u;
                var custom = (prod[key] != null) ? String(prod[key]).trim() : '';
                if (custom) return custom;
            }
            return window.getDefaultUnitLabel(u);
        };

        /**
         * Wholesale-style packaging text for A4 invoices, e.g. "100*10" or "20*100 عدد".
         * Uses pieces_per_pack × packs_per_carton (or itemsPerCarton fallback).
         */
        window.formatProductPackagingLabel = function(prod) {
            if (!prod || typeof prod !== 'object') return '—';
            var f = (typeof getProductUnitFactors === 'function')
                ? getProductUnitFactors(prod)
                : { piecesPerPack: 1, piecesPerCarton: 1, ppp: 1, ppc: 1 };
            var ppp = Math.max(1, parseInt(f.piecesPerPack != null ? f.piecesPerPack : f.ppp, 10) || 1);
            var ppc = Math.max(1, parseInt(prod.packs_per_carton != null ? prod.packs_per_carton : (f.ppc != null ? f.ppc : 1), 10) || 1);
            if ((ppp <= 1 && ppc <= 1) && prod.itemsPerCarton != null && Number(prod.itemsPerCarton) > 1) {
                ppp = Math.max(1, parseInt(prod.itemsPerCarton, 10) || 1);
                ppc = 1;
            }
            var pieceName = (prod.unit_name_piece != null) ? String(prod.unit_name_piece).trim() : '';
            if (ppp <= 1 && ppc <= 1) {
                return pieceName || '1';
            }
            var base = String(ppp) + '*' + String(ppc);
            return pieceName ? (base + ' ' + pieceName) : base;
        };

        window.resolveSaleLineProduct = function(item) {
            if (!item) return null;
            if (item.productRef && typeof item.productRef === 'object') return item.productRef;
            var id = item.id != null ? item.id : item.prodId;
            if (typeof getProductByIdSafe === 'function') {
                try { return getProductByIdSafe(id); } catch (_e) {}
            }
            if (typeof db !== 'undefined' && db && Array.isArray(db.products)) {
                return db.products.find(function(p) { return String(p.id) === String(id); }) || null;
            }
            return null;
        };

        window.getPosUnitIconHtml = function(unitCode, inline) {
            var u = normalizePosUnitCode(unitCode);
            var cls = window.getPosUnitIconClass(u);
            if (inline) {
                return '<i class="' + cls + ' pos-unit-icon-inline" data-unit="' + u + '" aria-hidden="true"></i>';
            }
            return '<i class="' + cls + '" aria-hidden="true"></i>';
        };

        /**
         * Build icon-only unit toggle buttons (piece → pack → carton).
         * @param {{ available?: string[], current?: string, onSet?: string, labels?: object }} options
         */
        window.buildPosUnitToggleHtml = function(options) {
            options = options || {};
            var available = options.available || window.POS_UNIT_ORDER.slice();
            var current = normalizePosUnitCode(options.current || 'piece');
            var onSet = options.onSet || 'setSupplyUnit';
            var labels = options.labels || {};
            var esc = (typeof escapeHtml === 'function') ? escapeHtml : function(s) { return String(s == null ? '' : s); };
            var html = '';
            window.POS_UNIT_ORDER.forEach(function(unit) {
                if (available.indexOf(unit) === -1) return;
                var label = labels[unit] || window.getDefaultUnitLabel(unit);
                var active = current === unit ? ' active' : '';
                html += '<button type="button" class="pos-unit-btn' + active + '" data-unit="' + unit + '" onclick="' + onSet + '(\'' + unit + '\')" title="' + esc(label) + '" aria-label="' + esc(label) + '"><i class="' + window.getPosUnitIconClass(unit) + '"></i></button>';
            });
            return html;
        };

        /** Break pieces into carton / pack / remainder piece counts for display. */
        window.piecesToUnitBreakdown = function (pieces, prod) {
            var f = (typeof getProductUnitFactors === 'function') ? getProductUnitFactors(prod) : { piecesPerPack: 1, piecesPerCarton: 1 };
            var absPieces = Math.max(0, parseFloat(pieces) || 0);
            var carton = 0;
            var pack = 0;
            var piece = absPieces;
            var ppc = Math.max(1, parseInt(f.piecesPerCarton, 10) || 1);
            var ppp = Math.max(1, parseInt(f.piecesPerPack, 10) || 1);
            if (ppc > 1) {
                carton = Math.floor(piece / ppc + 1e-9);
                piece = piece - (carton * ppc);
            }
            if (ppp > 1) {
                pack = Math.floor(piece / ppp + 1e-9);
                piece = piece - (pack * ppp);
            }
            if (piece < 0.0001) piece = 0;
            return { carton: carton, pack: pack, piece: piece, piecesTotal: absPieces };
        };

        /** Best unit to show qty (carton if whole cartons, else pack, else piece). */
        window.inferPurchaseDisplayUnit = function (pieces, prod) {
            var p = Math.max(0, parseFloat(pieces) || 0);
            if (!p) return 'piece';
            var f = (typeof getProductUnitFactors === 'function') ? getProductUnitFactors(prod) : { piecesPerPack: 1, piecesPerCarton: 1 };
            var ppc = Math.max(1, parseInt(f.piecesPerCarton, 10) || 1);
            var ppp = Math.max(1, parseInt(f.piecesPerPack, 10) || 1);
            if (ppc > 1 && Math.abs(p % ppc) < 0.0001 && p >= ppc) {
                if (typeof productMatchesUnitFilter === 'function' && !productMatchesUnitFilter(prod, 'carton', true)) { /* fall through */ }
                else return 'carton';
            }
            if (ppp > 1 && Math.abs(p % ppp) < 0.0001 && p >= ppp) {
                if (typeof productMatchesUnitFilter === 'function' && !productMatchesUnitFilter(prod, 'pack', true)) { /* fall through */ }
                else return 'pack';
            }
            return 'piece';
        };

        window.purchasePiecesToUnitQty = function (pieces, unit, prod) {
            var mult = 1;
            if (typeof getPiecesMultiplierForUnit === 'function') mult = getPiecesMultiplierForUnit(prod, unit || 'piece');
            else {
                var f = (typeof getProductUnitFactors === 'function') ? getProductUnitFactors(prod) : { piecesPerPack: 1, piecesPerCarton: 1 };
                if (unit === 'carton') mult = f.piecesPerCarton || 1;
                else if (unit === 'pack') mult = f.piecesPerPack || 1;
            }
            if (!mult || mult <= 0) mult = 1;
            var q = (parseFloat(pieces) || 0) / mult;
            if (typeof formatQtyForInput === 'function') return parseFloat(formatQtyForInput(q, prod));
            return q;
        };

        window.purchaseUnitQtyToPieces = function (qty, unit, prod) {
            var mult = 1;
            if (typeof getPiecesMultiplierForUnit === 'function') mult = getPiecesMultiplierForUnit(prod, unit || 'piece');
            else {
                var f = (typeof getProductUnitFactors === 'function') ? getProductUnitFactors(prod) : { piecesPerPack: 1, piecesPerCarton: 1 };
                if (unit === 'carton') mult = f.piecesPerCarton || 1;
                else if (unit === 'pack') mult = f.piecesPerPack || 1;
            }
            return (parseFloat(qty) || 0) * (mult || 1);
        };

        /** Human-readable multi-unit summary, e.g. "2 کارتۆن · 1 تاک". */
        window.formatPiecesUnitSummary = function (pieces, prod, opts) {
            opts = opts || {};
            var esc = (typeof escapeHtml === 'function') ? escapeHtml : function (s) { return String(s == null ? '' : s); };
            var bd = window.piecesToUnitBreakdown(pieces, prod);
            var parts = [];
            if (bd.carton > 0) parts.push(esc(String(bd.carton)) + ' ' + esc(window.getProductUnitLabel(prod, 'carton')));
            if (bd.pack > 0) parts.push(esc(String(bd.pack)) + ' ' + esc(window.getProductUnitLabel(prod, 'pack')));
            if (bd.piece > 0 || !parts.length) {
                var pq = (typeof formatQtyForInput === 'function') ? formatQtyForInput(bd.piece, prod) : bd.piece;
                parts.push(esc(String(pq)) + ' ' + esc(window.getProductUnitLabel(prod, 'piece')));
            }
            var main = parts.join(' · ');
            if (opts.showPiecesHint && bd.piecesTotal > 0 && (bd.carton > 0 || bd.pack > 0)) {
                var hint = (typeof formatQtyForInput === 'function') ? formatQtyForInput(bd.piecesTotal, prod) : bd.piecesTotal;
                main += ' <small style="opacity:.75;font-weight:500;">(' + esc(String(hint)) + ' ' + esc(window.getProductUnitLabel(prod, 'piece')) + ')</small>';
            }
            return main;
        };

        window.availablePurchaseUnitsForProduct = function (prod) {
            var out = ['piece'];
            if (typeof productMatchesUnitFilter === 'function') {
                if (productMatchesUnitFilter(prod, 'pack', true)) out.push('pack');
                if (productMatchesUnitFilter(prod, 'carton', true)) out.push('carton');
            } else {
                var f = (typeof getProductUnitFactors === 'function') ? getProductUnitFactors(prod) : { piecesPerPack: 1, piecesPerCarton: 1 };
                if ((f.piecesPerPack || 1) > 1) out.push('pack');
                if ((f.piecesPerCarton || 1) > 1) out.push('carton');
            }
            return out;
        };

        window.availableSaleUnitsForProduct = function (prod) {
            var out = ['piece'];
            if (typeof productMatchesUnitFilter === 'function') {
                if (productMatchesUnitFilter(prod, 'pack', false)) out.push('pack');
                if (productMatchesUnitFilter(prod, 'carton', false)) out.push('carton');
            } else {
                var f = (typeof getProductUnitFactors === 'function') ? getProductUnitFactors(prod) : { piecesPerPack: 1, piecesPerCarton: 1 };
                if ((f.piecesPerPack || 1) > 1) out.push('pack');
                if ((f.piecesPerCarton || 1) > 1) out.push('carton');
            }
            return out;
        };

        window.inferSaleLineDisplayUnit = function (item, prod) {
            var u = (item && (item.saleUnit === 'carton' || item.saleUnit === 'pack')) ? item.saleUnit : 'piece';
            if (typeof productMatchesUnitFilter === 'function' && !productMatchesUnitFilter(prod, u, false)) return 'piece';
            return u;
        };

        /** True when sale id is a client timestamp (instant print before server id). */
        function isProvisionalTimestampSaleId(id) {
            var n = parseInt(String(id == null ? '' : id).trim(), 10);
            return isFinite(n) && n >= 1e12;
        }

        /** Next sequential receipt # for display (e.g. 000046). Skips timestamp ids. */
        function allocateNextSaleIdForDisplay() {
            var maxNum = 0;
            function scan(sid) {
                var n = parseInt(String(sid == null ? '' : sid).trim(), 10);
                if (!isFinite(n) || n <= 0 || n >= 1e12) return;
                if (n > maxNum) maxNum = n;
            }
            (window.db && db.sales || []).forEach(function(s) { if (s && s.id != null) scan(s.id); });
            (window.db && db.archive || []).forEach(function(s) { if (s && s.id != null) scan(s.id); });
            return String(maxNum + 1).padStart(getSaleIdDisplayPad(), '0');
        }

        /** Human receipt number for thermal / A4 (never full Date.now()). */
        function getSaleIdDisplayPad() {
            var pad = 6;
            try {
                if (window.db && db.settings && db.settings.saleIdDisplayPad != null) {
                    pad = parseInt(db.settings.saleIdDisplayPad, 10) || 6;
                }
            } catch (_ePad) {}
            if (pad < 1) pad = 1;
            if (pad > 10) pad = 10;
            return pad;
        }
        function formatSaleIdForDisplay(id) {
            if (id == null || id === '') return '---';
            var n = parseInt(String(id).trim(), 10);
            if (!isFinite(n) || n <= 0) return '---';
            if (n >= 1e12) return allocateNextSaleIdForDisplay();
            return String(n).padStart(getSaleIdDisplayPad(), '0');
        }

        window.isProvisionalTimestampSaleId = isProvisionalTimestampSaleId;
        window.allocateNextSaleIdForDisplay = allocateNextSaleIdForDisplay;
        window.formatSaleIdForDisplay = formatSaleIdForDisplay;
        window.getSaleIdDisplayPad = getSaleIdDisplayPad;

        /** Catalog expiry on products.expiry — ignore 0, empty, invalid (clothing has no date). */
        function isValidProductCatalogExpiry(val) {
            if (val == null || val === undefined) return false;
            var s = String(val).trim();
            if (!s || s === '0' || s === '-' || s === 'null' || s === 'undefined') return false;
            if (/^0000-00-00/.test(s)) return false;
            if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
            var d = new Date(s + 'T12:00:00');
            return !isNaN(d.getTime());
        }
        function getProductCatalogExpiryDisplay(valOrProduct) {
            var val = (valOrProduct && typeof valOrProduct === 'object') ? valOrProduct.expiry : valOrProduct;
            return isValidProductCatalogExpiry(val) ? String(val).trim() : '-';
        }
        function productCatalogExpiryDaysLeft(valOrProduct) {
            var val = (valOrProduct && typeof valOrProduct === 'object') ? valOrProduct.expiry : valOrProduct;
            if (valOrProduct && typeof valOrProduct === 'object' && isValidProductCatalogExpiry(valOrProduct.batch_min_expiry)) {
                val = valOrProduct.batch_min_expiry;
            }
            if (!isValidProductCatalogExpiry(val)) return null;
            var today = new Date();
            today.setHours(0, 0, 0, 0);
            var exp = new Date(String(val).trim() + 'T12:00:00');
            exp.setHours(0, 0, 0, 0);
            return Math.ceil((exp.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
        }
        function isProductCatalogExpired(valOrProduct) {
            var days = productCatalogExpiryDaysLeft(valOrProduct);
            return days != null && days < 0;
        }
        window.isValidProductCatalogExpiry = isValidProductCatalogExpiry;
        window.getProductCatalogExpiryDisplay = getProductCatalogExpiryDisplay;
        window.productCatalogExpiryDaysLeft = productCatalogExpiryDaysLeft;
        window.isProductCatalogExpired = isProductCatalogExpired;

        var _posConfirmResolve = null;
        var _posConfirmDelayTimer = null;
        function posNormalizeConfirmPhrase(s) {
            return String(s || '')
                .replace(/[\u200c\u200b\u200d\ufeff]/g, '')
                .replace(/\s+/g, ' ')
                .trim();
        }
        function posCopyTextFallback(text) {
            try {
                var ta = document.createElement('textarea');
                ta.value = String(text || '');
                ta.setAttribute('readonly', '');
                ta.style.position = 'fixed';
                ta.style.left = '-9999px';
                document.body.appendChild(ta);
                ta.select();
                var ok = document.execCommand('copy');
                document.body.removeChild(ta);
                return !!ok;
            } catch (_eC) {
                return false;
            }
        }
        function _posConfirmClose(result) {
            if (_posConfirmDelayTimer) {
                try { clearTimeout(_posConfirmDelayTimer); } catch (_eClr) {}
                _posConfirmDelayTimer = null;
            }
            var modal = document.getElementById('pos-confirm-modal');
            if (modal) modal.style.display = 'none';
            var phraseInput = document.getElementById('pos-confirm-phrase-input');
            if (phraseInput) {
                phraseInput.value = '';
                phraseInput.oninput = null;
                phraseInput.onkeydown = null;
                phraseInput.classList.remove('pos-confirm-phrase-input--long');
                phraseInput.rows = 1;
            }
            var phraseWrap = document.getElementById('pos-confirm-phrase-wrap');
            if (phraseWrap) phraseWrap.style.display = 'none';
            var phraseSource = document.getElementById('pos-confirm-phrase-source');
            if (phraseSource) phraseSource.style.display = 'none';
            var copyBtn = document.getElementById('pos-confirm-phrase-copy');
            if (copyBtn) copyBtn.onclick = null;
            var choicesReset = document.getElementById('pos-confirm-choices');
            if (choicesReset) {
                choicesReset.innerHTML = '';
                choicesReset.style.display = 'none';
            }
            var cardReset = modal && modal.querySelector('.pos-confirm-card');
            if (cardReset) cardReset.classList.remove('pos-confirm-card--wide');
            var okBtn = document.getElementById('pos-confirm-ok');
            if (okBtn) {
                okBtn.disabled = false;
                okBtn.removeAttribute('aria-disabled');
                okBtn.style.display = '';
            }
            var actionsReset = modal && modal.querySelector('.pos-confirm-actions');
            if (actionsReset) actionsReset.classList.remove('pos-confirm-actions--choices');
            var fn = _posConfirmResolve;
            _posConfirmResolve = null;
            if (typeof fn === 'function') fn(result);
        }
        window.posConfirm = function posConfirm(opts) {
            opts = opts || {};
            return new Promise(function (resolve) {
                var modal = document.getElementById('pos-confirm-modal');
                if (!modal) {
                    resolve(window.confirm(String(opts.message || opts.title || '')));
                    return;
                }
                if (_posConfirmResolve) _posConfirmClose(false);
                _posConfirmResolve = resolve;
                var titleEl = document.getElementById('pos-confirm-title');
                var msgEl = document.getElementById('pos-confirm-message');
                var okBtn = document.getElementById('pos-confirm-ok');
                var cancelBtn = document.getElementById('pos-confirm-cancel');
                var iconWrap = document.getElementById('pos-confirm-icon-wrap');
                var actions = modal.querySelector('.pos-confirm-actions');
                var card = modal.querySelector('.pos-confirm-card');
                var phraseWrap = document.getElementById('pos-confirm-phrase-wrap');
                var phraseLabel = document.getElementById('pos-confirm-phrase-label');
                var phraseInput = document.getElementById('pos-confirm-phrase-input');
                var choicesEl = document.getElementById('pos-confirm-choices');
                var choiceList = Array.isArray(opts.choices) ? opts.choices.filter(function (c) { return c && c.id; }) : [];
                var hasChoices = choiceList.length > 0;
                var tone = opts.tone || (opts.danger ? 'danger' : (opts.success ? 'success' : 'warn'));
                var alertOnly = !!opts.alertOnly || !!opts.hideCancel || tone === 'success';
                var requirePhrase = String(opts.requirePhrase || opts.typeToConfirm || '').trim();
                var confirmDelayMs = Math.max(0, parseInt(opts.confirmDelayMs != null ? opts.confirmDelayMs : (requirePhrase ? 1200 : 0), 10) || 0);
                var delayReady = confirmDelayMs <= 0;
                var phraseReady = !requirePhrase;
                var iconClass = opts.icon || (
                    tone === 'danger' ? 'fa-trash-alt'
                    : tone === 'info' ? 'fa-info-circle'
                    : tone === 'success' ? 'fa-check-circle'
                    : 'fa-exclamation-triangle'
                );
                if (card) {
                    card.classList.toggle('pos-confirm-card--success', tone === 'success');
                    card.classList.toggle('pos-confirm-card--danger', tone === 'danger');
                }
                if (iconWrap) {
                    var iconTone = '';
                    if (tone === 'info') iconTone = ' pos-confirm-icon--info';
                    else if (tone === 'warn') iconTone = ' pos-confirm-icon--warn';
                    else if (tone === 'success') iconTone = ' pos-confirm-icon--success';
                    else if (tone === 'danger') iconTone = ' pos-confirm-icon--danger';
                    iconWrap.className = 'pos-confirm-icon' + iconTone;
                    iconWrap.innerHTML = '<i class="fas ' + iconClass + '" aria-hidden="true"></i>';
                }
                if (titleEl) {
                    titleEl.textContent = opts.title || (typeof t === 'function' ? t('confirm_title') : 'دڵنیایت؟');
                }
                if (msgEl) msgEl.textContent = opts.message || '';

                var syncOkEnabled = function () {
                    if (!okBtn) return;
                    var enabled = alertOnly ? true : (delayReady && phraseReady);
                    okBtn.disabled = !enabled;
                    okBtn.setAttribute('aria-disabled', enabled ? 'false' : 'true');
                };

                var phraseSource = document.getElementById('pos-confirm-phrase-source');
                var phraseSourceText = document.getElementById('pos-confirm-phrase-source-text');
                var phraseCopyBtn = document.getElementById('pos-confirm-phrase-copy');
                var phraseCopyLabel = document.getElementById('pos-confirm-phrase-copy-label');
                var copyPastePhrase = !!opts.phraseCopyPaste && !!requirePhrase && !alertOnly;
                if (card) card.classList.toggle('pos-confirm-card--wide', copyPastePhrase);
                if (phraseWrap && phraseInput) {
                    if (requirePhrase && !alertOnly) {
                        phraseWrap.style.display = '';
                        if (phraseLabel) {
                            var hintTpl = opts.phraseHint
                                || (copyPastePhrase && typeof t === 'function' ? t('confirm_data_restore_paste_hint') : '')
                                || ((typeof t === 'function') ? t('confirm_type_code_hint') : '')
                                || ((typeof t === 'function') ? t('confirm_type_phrase_hint') : '')
                                || 'بۆ پشتڕاستکرن، بنڤیسە کودێ: {phrase}';
                            if (!hintTpl || hintTpl === 'confirm_type_code_hint' || hintTpl === 'confirm_type_phrase_hint' || hintTpl === 'confirm_data_restore_paste_hint') {
                                hintTpl = copyPastePhrase
                                    ? 'ڤێ نڤیسینێ کۆپی بکە، پاشان ل خوارێ پەیست بکە — بێ ڤێ، گەڕاندنەوە ناچێت.'
                                    : 'بۆ پشتڕاستکرن، بنڤیسە کودێ: {phrase}';
                            }
                            phraseLabel.textContent = String(hintTpl).split('{phrase}').join(requirePhrase);
                        }
                        phraseInput.value = '';
                        var isNumericPhrase = !copyPastePhrase && (!!opts.phraseNumeric || /^\d+$/.test(requirePhrase));
                        if (copyPastePhrase) {
                            phraseInput.placeholder = (typeof t === 'function' ? t('confirm_data_restore_paste_ph') : '') || 'ل ڤێرێ پەیست بکە…';
                            if (phraseInput.placeholder === 'confirm_data_restore_paste_ph') phraseInput.placeholder = 'ل ڤێرێ پەیست بکە…';
                            phraseInput.setAttribute('inputmode', 'text');
                            phraseInput.removeAttribute('pattern');
                            phraseInput.setAttribute('autocomplete', 'off');
                            phraseInput.style.letterSpacing = '';
                            phraseInput.style.fontSize = '';
                            phraseInput.rows = 3;
                            phraseInput.classList.add('pos-confirm-phrase-input--long');
                            if (phraseSource) phraseSource.style.display = '';
                            if (phraseSourceText) phraseSourceText.textContent = requirePhrase;
                            if (phraseCopyLabel) {
                                var copyLbl = (typeof t === 'function' ? t('confirm_data_restore_copy_btn') : '') || 'کۆپی';
                                if (copyLbl === 'confirm_data_restore_copy_btn') copyLbl = 'کۆپی';
                                phraseCopyLabel.textContent = copyLbl;
                            }
                            if (phraseCopyBtn) {
                                phraseCopyBtn.onclick = function (ev) {
                                    if (ev) ev.preventDefault();
                                    var copiedMsg = (typeof t === 'function' ? t('confirm_data_restore_copied') : '') || 'هاتە کۆپیکرن — ئێستا پەیست بکە';
                                    if (copiedMsg === 'confirm_data_restore_copied') copiedMsg = 'هاتە کۆپیکرن — ئێستا پەیست بکە';
                                    var done = function (ok) {
                                        if (phraseCopyLabel) phraseCopyLabel.textContent = ok ? copiedMsg : ((typeof t === 'function' ? t('confirm_data_restore_copy_btn') : '') || 'کۆپی');
                                        if (ok && phraseInput) {
                                            try { phraseInput.focus(); } catch (_eF2) {}
                                        }
                                    };
                                    if (navigator.clipboard && navigator.clipboard.writeText) {
                                        navigator.clipboard.writeText(requirePhrase).then(function () { done(true); }).catch(function () {
                                            done(posCopyTextFallback(requirePhrase));
                                        });
                                    } else {
                                        done(posCopyTextFallback(requirePhrase));
                                    }
                                };
                            }
                        } else {
                            phraseInput.placeholder = requirePhrase;
                            phraseInput.rows = 1;
                            phraseInput.classList.remove('pos-confirm-phrase-input--long');
                            if (phraseSource) phraseSource.style.display = 'none';
                            if (phraseCopyBtn) phraseCopyBtn.onclick = null;
                            if (isNumericPhrase) {
                                phraseInput.setAttribute('inputmode', 'numeric');
                                phraseInput.setAttribute('pattern', '[0-9]*');
                                phraseInput.setAttribute('autocomplete', 'one-time-code');
                                phraseInput.style.letterSpacing = '0.35em';
                                phraseInput.style.fontSize = '1.25rem';
                            } else {
                                phraseInput.setAttribute('inputmode', 'text');
                                phraseInput.removeAttribute('pattern');
                                phraseInput.setAttribute('autocomplete', 'off');
                                phraseInput.style.letterSpacing = '';
                                phraseInput.style.fontSize = '';
                            }
                        }
                        phraseInput.oninput = function () {
                            var typed = String(phraseInput.value || '');
                            if (isNumericPhrase) {
                                typed = typed.replace(/\D+/g, '');
                                if (phraseInput.value !== typed) phraseInput.value = typed;
                                phraseReady = typed === requirePhrase;
                            } else if (copyPastePhrase) {
                                phraseReady = posNormalizeConfirmPhrase(typed) === posNormalizeConfirmPhrase(requirePhrase);
                            } else {
                                phraseReady = typed.trim() === requirePhrase;
                            }
                            syncOkEnabled();
                        };
                        phraseInput.onkeydown = function (ev) {
                            if (ev.key === 'Enter') {
                                if (copyPastePhrase) return;
                                ev.preventDefault();
                                if (!okBtn || okBtn.disabled) return;
                                _posConfirmClose(true);
                            }
                        };
                    } else {
                        phraseWrap.style.display = 'none';
                        phraseInput.value = '';
                        phraseInput.oninput = null;
                        phraseInput.onkeydown = null;
                        phraseInput.classList.remove('pos-confirm-phrase-input--long');
                        if (phraseSource) phraseSource.style.display = 'none';
                        if (phraseCopyBtn) phraseCopyBtn.onclick = null;
                        phraseReady = true;
                    }
                } else {
                    phraseReady = !requirePhrase;
                }

                if (okBtn) {
                    var okLabel = opts.confirmText || (tone === 'success'
                        ? ((typeof t === 'function') ? (t('btn_ok') || t('btn_confirm')) : 'باشە')
                        : (typeof t === 'function' ? t('btn_confirm') : 'بەڵێ'));
                    okBtn.innerHTML = '<span>' + okLabel + '</span>';
                    okBtn.className = 'btn pos-confirm-btn ' + (
                        tone === 'danger' ? 'btn-danger'
                        : tone === 'info' ? 'btn-brand'
                        : tone === 'success' ? 'btn-success'
                        : tone === 'warn' ? 'btn-dark'
                        : 'btn-dark'
                    );
                    okBtn.disabled = false;
                }
                if (cancelBtn) {
                    var cancelLabel = opts.cancelText || (typeof t === 'function' ? t('btn_cancel') : 'پاشگەزبوون');
                    cancelBtn.innerHTML = '<span>' + cancelLabel + '</span>';
                    cancelBtn.className = 'btn pos-confirm-btn pos-confirm-btn--cancel';
                    cancelBtn.style.display = alertOnly ? 'none' : '';
                }
                if (choicesEl) {
                    choicesEl.innerHTML = '';
                    if (hasChoices && !alertOnly) {
                        choicesEl.style.display = 'flex';
                        choiceList.forEach(function (ch) {
                            var b = document.createElement('button');
                            b.type = 'button';
                            b.className = 'btn pos-confirm-btn ' + (ch.className || 'btn-brand');
                            b.setAttribute('data-choice-id', String(ch.id));
                            b.innerHTML = '<span>' + String(ch.label || ch.id) + '</span>';
                            b.onclick = function () { _posConfirmClose(String(ch.id)); };
                            choicesEl.appendChild(b);
                        });
                    } else {
                        choicesEl.style.display = 'none';
                    }
                }
                if (okBtn) {
                    okBtn.style.display = (hasChoices && !alertOnly) ? 'none' : '';
                }
                if (actions) {
                    actions.classList.toggle('pos-confirm-actions--single', alertOnly);
                    actions.classList.toggle('pos-confirm-actions--choices', hasChoices && !alertOnly);
                }

                if (_posConfirmDelayTimer) {
                    try { clearTimeout(_posConfirmDelayTimer); } catch (_eT) {}
                    _posConfirmDelayTimer = null;
                }
                delayReady = confirmDelayMs <= 0 || alertOnly;
                syncOkEnabled();
                if (!delayReady) {
                    _posConfirmDelayTimer = setTimeout(function () {
                        delayReady = true;
                        syncOkEnabled();
                        _posConfirmDelayTimer = null;
                    }, confirmDelayMs);
                }

                modal.style.display = 'flex';
                if (typeof window.bringOverlayToFront === 'function') {
                    window.bringOverlayToFront(modal);
                }
                modal.onclick = function (e) {
                    if (e.target === modal) {
                        if (alertOnly) _posConfirmClose(true);
                        else _posConfirmClose(false);
                    }
                };
                if (okBtn) {
                    okBtn.onclick = function () {
                        if (okBtn.disabled) return;
                        if (requirePhrase && phraseInput) {
                            var typedOk = String(phraseInput.value || '').trim();
                            if (copyPastePhrase) {
                                if (posNormalizeConfirmPhrase(typedOk) !== posNormalizeConfirmPhrase(requirePhrase)) return;
                            } else if (typedOk !== requirePhrase) {
                                return;
                            }
                        }
                        _posConfirmClose(true);
                    };
                }
                if (cancelBtn) {
                    cancelBtn.onclick = function () { _posConfirmClose(false); };
                }
                setTimeout(function () {
                    try {
                        if (copyPastePhrase && phraseCopyBtn) {
                            phraseCopyBtn.focus();
                        } else if (requirePhrase && phraseInput && phraseWrap && phraseWrap.style.display !== 'none') {
                            phraseInput.focus();
                        } else if (tone === 'danger' && cancelBtn && !alertOnly) {
                            cancelBtn.focus();
                        } else {
                            (okBtn || cancelBtn).focus();
                        }
                    } catch (_eF) {}
                }, 30);
            });
        };

        /** Dangerous void/delete: type a fresh random 4-digit code + short delay. */
        window.posConfirmDangerous = function posConfirmDangerous(opts) {
            opts = opts || {};
            var phrase = String(opts.requirePhrase || opts.typeToConfirm || '').trim();
            if (!phrase) {
                phrase = String(1000 + Math.floor(Math.random() * 9000));
            }
            var hintTpl = opts.phraseHint
                || ((typeof t === 'function') ? t('confirm_type_code_hint') : '')
                || 'بۆ پشتڕاستکرن، بنڤیسە کودێ: {phrase}';
            if (!hintTpl || hintTpl === 'confirm_type_code_hint') {
                hintTpl = 'بۆ پشتڕاستکرن، بنڤیسە کودێ: {phrase}';
            }
            return window.posConfirm({
                title: opts.title || ((typeof t === 'function') ? t('confirm_void_title') : 'ئاگاداری — ژێبرن'),
                message: opts.message || '',
                tone: 'danger',
                confirmText: opts.confirmText || ((typeof t === 'function') ? t('confirm_void_btn') : 'بەڵێ، ژێ ببە'),
                cancelText: opts.cancelText,
                icon: opts.icon || 'fa-exclamation-triangle',
                requirePhrase: phrase,
                phraseHint: String(hintTpl).split('{phrase}').join(phrase),
                confirmDelayMs: opts.confirmDelayMs != null ? opts.confirmDelayMs : 1500,
                phraseNumeric: /^\d+$/.test(phrase)
            });
        };

        /** Restore / flash / rollback: copy-paste a long sentence before replacing all data. */
        window.posConfirmDataRestore = function posConfirmDataRestore(opts) {
            opts = opts || {};
            var tr = (typeof t === 'function') ? t : function () { return ''; };
            var body = String(opts.message || tr('confirm_data_restore_body') || '').trim();
            if (!body || body === 'confirm_data_restore_body') {
                body = '⚠️ ئاگەهداربە!\n\nهەموو داتای ئێستا دەسڕدرێتەوە و داتای پاراستوو/نوێ دێتە جێی.\nئەم کارە ناگەڕێتەوە!';
            }
            var parts = [body];
            if (opts.source) parts.push('\n\n📍 ' + String(opts.source));
            if (opts.detail) parts.push('\n' + String(opts.detail));
            if (opts.currencyLabel) parts.push('\n\n' + (tr('modal_restore_currency_label') || 'دراو') + ' ' + String(opts.currencyLabel));
            var phrase = String(opts.requirePhrase || tr('confirm_data_restore_phrase') || '').trim();
            if (!phrase || phrase === 'confirm_data_restore_phrase') {
                phrase = 'ئەز یێ رازیمە داتایێن من یێن کەڤن ژێببن و یێن نوی بێنە زڤراندن';
            }
            var pasteHint = String(tr('confirm_data_restore_paste_hint') || '').trim();
            if (!pasteHint || pasteHint === 'confirm_data_restore_paste_hint') {
                pasteHint = 'ڤێ نڤیسینێ کۆپی بکە، پاشان ل خوارێ پەیست بکە — بێ ڤێ، گەڕاندنەوە ناچێت.';
            }
            if (typeof window.posConfirm === 'function') {
                return window.posConfirm({
                    title: opts.title || tr('confirm_data_restore_title') || 'ئاگاداری — گەڕاندنەوەی داتا',
                    message: parts.join(''),
                    tone: 'danger',
                    confirmText: opts.confirmText || tr('confirm_data_restore_btn') || 'بەڵێ، گەڕاندنەوە',
                    cancelText: opts.cancelText,
                    icon: opts.icon || 'fa-database',
                    requirePhrase: phrase,
                    phraseHint: pasteHint,
                    phraseCopyPaste: true,
                    phraseNumeric: false,
                    confirmDelayMs: opts.confirmDelayMs != null ? opts.confirmDelayMs : 2000
                });
            }
            return Promise.resolve(window.confirm(parts.join('')));
        };
        window.posAlert = function posAlert(opts) {
            opts = opts || {};
            opts.alertOnly = true;
            if (!opts.tone) opts.tone = opts.success === false ? 'info' : 'success';
            if (!opts.confirmText && typeof t === 'function') {
                opts.confirmText = t('btn_ok') || t('btn_confirm') || 'باشە';
            }
            if (typeof window.posConfirm === 'function') return window.posConfirm(opts);
            window.alert(String((opts.title ? opts.title + '\n' : '') + (opts.message || '')));
            return Promise.resolve(true);
        };

        /**
         * Modal stacking: every time an overlay opens, put it on top.
         * Fixes nested screens appearing underneath parent history/daily modals.
         */
        window._posOverlayZ = 25000;
        window._posOverlayRaising = false;
        window.isPosStackableOverlay = function isPosStackableOverlay(el) {
            if (!el || el.nodeType !== 1) return false;
            var id = el.id || '';
            if (id === 'app-boot-loader' || id === 'mobile-connect-info' || id === 'secret-menu-modal') return false;
            if (el.classList) {
                if (el.classList.contains('pos-auth-screen') || el.classList.contains('pos-spotlight-tutorial') || el.classList.contains('pos-spotlight-dim')) return false;
                if (el.classList.contains('startup-mobile-overlay')) return false;
                if (el.classList.contains('modal-overlay') || el.classList.contains('pos-confirm-overlay')) return true;
            }
            return false;
        };
        window.bringOverlayToFront = function bringOverlayToFront(el) {
            if (!el || !el.style || window._posOverlayRaising) return 0;
            if (typeof window.isPosStackableOverlay === 'function' && !window.isPosStackableOverlay(el)) return 0;
            var alreadyZ = parseInt(el.getAttribute('data-pos-stack-z') || '0', 10) || 0;
            if (alreadyZ === (parseInt(window._posOverlayZ, 10) || 0) && document.body && document.body.lastElementChild === el) {
                return alreadyZ;
            }
            window._posOverlayRaising = true;
            try {
                var cs = null;
                try { cs = window.getComputedStyle(el); } catch (_eCs) {}
                var disp = (el.style && el.style.display) || (cs && cs.display) || '';
                if (disp === 'none') return 0;
                if (document.body && el.parentNode) {
                    try {
                        if (el.parentNode !== document.body || document.body.lastElementChild !== el) {
                            document.body.appendChild(el);
                        }
                    } catch (_eMove) {}
                }
                var next = Math.max(25000, (parseInt(window._posOverlayZ, 10) || 25000) + 1);
                if (next > 500000) next = 25001;
                window._posOverlayZ = next;
                el.style.zIndex = String(next);
                el.setAttribute('data-pos-stack-z', String(next));
                return next;
            } finally {
                window._posOverlayRaising = false;
            }
        };
        window.showOverlay = function showOverlay(el, displayMode) {
            if (!el) return;
            el.style.display = displayMode || 'flex';
            if (typeof window.bringOverlayToFront === 'function') window.bringOverlayToFront(el);
        };
        (function installPosOverlayStackWatcher() {
            var watchOverlay = null;
            var boot = function () {
                if (window._posOverlayStackInstalled || typeof MutationObserver === 'undefined' || !document.body) return;
                window._posOverlayStackInstalled = true;
                var raiseIfVisible = function (el) {
                    if (!el || !window.isPosStackableOverlay(el)) return;
                    var disp = '';
                    try {
                        disp = el.style.display || window.getComputedStyle(el).display || '';
                    } catch (_e) { return; }
                    if (disp === 'flex' || disp === 'block' || disp === 'grid') {
                        window.bringOverlayToFront(el);
                    }
                };
                var overlayObs = new MutationObserver(function (records) {
                    if (window._posOverlayRaising) return;
                    for (var i = 0; i < records.length; i++) {
                        var rec = records[i];
                        if (rec.type === 'attributes') raiseIfVisible(rec.target);
                    }
                });
                watchOverlay = function (el) {
                    if (!el || el.nodeType !== 1 || el._posStackWatched) return;
                    if (!window.isPosStackableOverlay(el)) return;
                    el._posStackWatched = true;
                    try {
                        overlayObs.observe(el, { attributes: true, attributeFilter: ['style', 'class'] });
                    } catch (_eW) {}
                };
                document.querySelectorAll('.modal-overlay, .pos-confirm-overlay').forEach(watchOverlay);
                var bodyObs = new MutationObserver(function (records) {
                    for (var i = 0; i < records.length; i++) {
                        var rec = records[i];
                        if (!rec.addedNodes) continue;
                        for (var j = 0; j < rec.addedNodes.length; j++) {
                            var n = rec.addedNodes[j];
                            if (!n || n.nodeType !== 1) continue;
                            watchOverlay(n);
                            if (n.querySelectorAll) {
                                n.querySelectorAll('.modal-overlay, .pos-confirm-overlay').forEach(watchOverlay);
                            }
                            raiseIfVisible(n);
                        }
                    }
                });
                try {
                    bodyObs.observe(document.body, { childList: true, subtree: true });
                } catch (_eObs) {}
                window._posWatchOverlay = watchOverlay;
            };
            if (document.body) boot();
            else document.addEventListener('DOMContentLoaded', boot);
        })();

