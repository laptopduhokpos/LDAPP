// sales/payment-modal.js — payment modal, credit
        // --- PAYMENT INTERFACE FUNCTIONS ---
        let currentPayMethod = 'cash';

        function _setPayInputFormatted(id, value, kind) {
            var el = document.getElementById(id);
            if (!el) return;
            if (value === '' || value == null) { el.value = ''; return; }
            if (typeof formatPaymentAmountNumber === 'function') {
                var n = Number(value);
                if (!Number.isFinite(n)) { el.value = ''; return; }
                if (kind === 'int') el.value = formatPaymentAmountNumber(Math.round(n), 'int');
                else el.value = formatPaymentAmountNumber(n, kind);
            } else {
                el.value = String(value);
            }
        }

        function onPayReceivedInput(el) {
            if (typeof formatPaymentInputElement === 'function') formatPaymentInputElement(el, 'int');
            setActivePayInput('pay-received');
            if (typeof updateUSDFromIQD === 'function') updateUSDFromIQD(el.value);
        }
        function onPosCustomerPaidInput(el) {
            if (!el) el = document.getElementById('pos-customer-paid');
            if (!el) return;
            var kind = (typeof getSalesPaymentInputKind === 'function') ? getSalesPaymentInputKind() : 'int';
            if (typeof formatPaymentInputElement === 'function') formatPaymentInputElement(el, kind);
            if (typeof calculateDebtRemaining === 'function') calculateDebtRemaining();
        }
        window.onPosCustomerPaidInput = onPosCustomerPaidInput;
        function onPayUsdInput(el) {
            if (typeof formatPaymentInputElement === 'function') formatPaymentInputElement(el, 'usd');
            setActivePayInput('pay-usd-input');
            convertUSDPayment(el.value);
            updatePayReceivedVisualIqdFromUsd(el.value);
        }
        function onPayDebtAmountInput(el) {
            if (typeof formatPaymentInputElement === 'function') formatPaymentInputElement(el, getSalesPaymentInputKind());
            setActivePayInput('pay-debt-amount');
            calcPayModalTotals();
            var v = salesPaymentDisplayToIqd(el.value || '0');
            if (v > 0) { var s = document.getElementById('pay-debt-search'); if (s) s.focus(); }
        }
        function onPayBankCardAmountInput(el) {
            if (typeof formatPaymentInputElement === 'function') formatPaymentInputElement(el, getSalesPaymentInputKind());
            setActivePayInput('pay-bank-card-amount');
            calcPayModalTotals();
        }
        function onPPayReceivedInput(el) {
            if (typeof formatPaymentInputElement === 'function') formatPaymentInputElement(el, getPurchasePaymentInputKind());
            setActivePurchasePayInput('ppay-received');
            calcPurchasePayModalTotals();
            if (!isPurchasePaymentUsdMode() && typeof updateUSDFromIQD_Purchase === 'function') updateUSDFromIQD_Purchase(el.value);
        }
        function onPPayUsdInput(el) {
            if (typeof formatPaymentInputElement === 'function') formatPaymentInputElement(el, 'usd');
            setActivePurchasePayInput('ppay-usd-input');
            convertUSDPurchasePayment(el.value);
        }
        function onPPayDebtAmountInput(el) {
            if (typeof formatPaymentInputElement === 'function') formatPaymentInputElement(el, getPurchasePaymentInputKind());
            setActivePurchasePayInput('ppay-debt-amount');
            calcPurchasePayModalTotals();
            var v = purchasePaymentDisplayToIqd(el.value || '0');
            if (v > 0) { var s = document.getElementById('ppay-debt-search'); if (s) s.focus(); }
        }
        function onPPayBankCardAmountInput(el) {
            if (typeof formatPaymentInputElement === 'function') formatPaymentInputElement(el, getPurchasePaymentInputKind());
            setActivePurchasePayInput('ppay-bank-card-amount');
            calcPurchasePayModalTotals();
        }
        window.onPayReceivedInput = onPayReceivedInput;
        window.onPayUsdInput = onPayUsdInput;
        window.onPayDebtAmountInput = onPayDebtAmountInput;
        window.onPayBankCardAmountInput = onPayBankCardAmountInput;
        window.onPPayReceivedInput = onPPayReceivedInput;
        window.onPPayUsdInput = onPPayUsdInput;
        window.onPPayDebtAmountInput = onPPayDebtAmountInput;
        window.onPPayBankCardAmountInput = onPPayBankCardAmountInput;

        function openPaymentModal() {
            const table = db.tables.find(t => t.id === activeTableId);
            if (!table || table.items.length === 0) return alert("سەبەت یا ڤالایە!");

            if (!isAutoPaymentModalEnabled()) return;

            var payBlock = typeof assertPosPaymentModalAllowed === 'function' ? assertPosPaymentModalAllowed() : null;
            if (payBlock) {
                if (typeof showPosSaleGatePopup === 'function') showPosSaleGatePopup(payBlock);
                return;
            }
            
            const rawSubtotalIqd = (typeof roundMoney === 'function' ? roundMoney : function(x){return x;})(table.items.reduce(function(a, b) {
                var u = typeof getBillLineUnitIqd === 'function' ? getBillLineUnitIqd(b) : (parseFloat(b.price) || 0);
                return a + u * getItemQty(b);
            }, 0));
            var ratePerOneOpen = typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0;
            var lineUsdSumFOpen = (typeof sumCartItemsSubtotalUsd === 'function')
                ? sumCartItemsSubtotalUsd(table.items)
                : (ratePerOneOpen > 0 ? table.items.reduce(function(s, item) {
                    if (typeof isPosCartLineGift === 'function' ? isPosCartLineGift(item) : !!item.isGift) return s;
                    var q = getItemQty(item);
                    if (typeof resolveCartLineMoney === 'function') {
                        var pm = resolveCartLineMoney(item);
                        return s + (Number(pm.usd) || 0) * q;
                    }
                    if (item.bill_unit_usd != null && item.bill_unit_usd !== '' && !isNaN(parseFloat(item.bill_unit_usd)))
                        return s + parseFloat(item.bill_unit_usd) * q;
                    return s + ((Number(item.price) || 0) * q) / ratePerOneOpen;
                }, 0) : 0);
            
            let subTotal = rawSubtotalIqd;
            let fixedDiscount = 0;
            if (table.manualDiscount !== undefined && table.manualDiscount !== null) {
                fixedDiscount = parseFloat(table.manualDiscount) || 0;
                subTotal = (typeof roundMoney === 'function' ? roundMoney : function(x){return x;})(subTotal - fixedDiscount);
                if (subTotal < 0) subTotal = 0;
            }
            
            // Reset Modal State
            var payTotEl = document.getElementById('pay-modal-total');
            payTotEl.dataset.subtotal = String(subTotal);
            try {
                payTotEl.dataset.rawSubtotalIqd = String(rawSubtotalIqd);
                payTotEl.dataset.lineUsdSumF = String(lineUsdSumFOpen);
            } catch (ePay) {}
            document.getElementById('pay-discount-pct').value = '';
            document.getElementById('pay-received').value = '';
            document.getElementById('pay-usd-input').value = ''; // Reset USD input
            const payDebtAmountEl = document.getElementById('pay-debt-amount');
            const payBankAmountEl = document.getElementById('pay-bank-card-amount');
            if (payDebtAmountEl) {
                _setPayInputFormatted('pay-debt-amount', 0, getSalesPaymentInputKind());
                payDebtAmountEl.removeAttribute('maxlength');
                payDebtAmountEl.removeAttribute('max');
                payDebtAmountEl.setAttribute('oninput', "setActivePayInput(this.id); onPayDebtAmountInput(this);");
            }
            if (payBankAmountEl) {
                _setPayInputFormatted('pay-bank-card-amount', 0, getSalesPaymentInputKind());
                payBankAmountEl.removeAttribute('maxlength');
                payBankAmountEl.removeAttribute('max');
                payBankAmountEl.setAttribute('oninput', "setActivePayInput(this.id); onPayBankCardAmountInput(this);");
            }
            const paySelectedDebtIdEl = document.getElementById('pay-selected-debt-id');
            const paySelectedDebtTypeEl = document.getElementById('pay-selected-debt-type');
            if (paySelectedDebtIdEl) paySelectedDebtIdEl.value = '';
            if (paySelectedDebtTypeEl) paySelectedDebtTypeEl.value = '';
            
            // Check existing discount first (needed for USD prefill)
            const posDiscountEl = document.getElementById('pos-discount');
            const existingDisc = posDiscountEl ? posDiscountEl.value : '';
            if(existingDisc && document.getElementById('pay-discount-pct')) document.getElementById('pay-discount-pct').value = existingDisc;
            const discPct = parseFloat(existingDisc) || 0;
            const discount = (discPct > 0 && discPct <= 100) ? roundMoney(subTotal * (discPct / 100)) : 0;
            const totalAfterDiscount = subTotal - discount;
            
            const totalElForFinal = document.getElementById('pay-modal-total');
            if (totalElForFinal) totalElForFinal.dataset.final = String(totalAfterDiscount);

            // Payment screen follows system default currency (Global Currency Sync)
            const sysCurrency = (typeof getActiveCurrency === 'function')
                ? getActiveCurrency()
                : ((db && db.settings && String(db.settings.currencyMode || 'IQD').toUpperCase() === 'USD') ? 'USD' : 'IQD');
            if (sysCurrency === 'USD') {
                activePayInputId = 'pay-usd-input';
                var rate = getUsdRatePerOneForPaymentScreen();
                var dueUsdOpen = 0;
                if (rawSubtotalIqd > 0 && lineUsdSumFOpen > 0) {
                    dueUsdOpen = lineUsdSumFOpen * (totalAfterDiscount / rawSubtotalIqd);
                } else if (rate > 0) {
                    dueUsdOpen = totalAfterDiscount / rate;
                }
                if (rate > 0) {
                    _setPayInputFormatted('pay-usd-input', dueUsdOpen, 'usd');
                    _setPayInputFormatted('pay-received', roundMoney(dueUsdOpen * rate), 'iqd');
                }
            } else {
                activePayInputId = 'pay-received';
                _setPayInputFormatted('pay-received', roundMoney(totalAfterDiscount), 'iqd');
                // Keep USD input preview in sync (even if user prefers IQD).
                updateUSDFromIQD(document.getElementById('pay-received').value);
            }
            
            const ratePerOne = getUsdRatePerOneForPaymentScreen();
            var payRateDisplay = document.getElementById('pay-usd-rate-display');
            if (payRateDisplay) {
                if (typeof formatFxRateDisplay === 'function') {
                    payRateDisplay.innerText = formatFxRateDisplay(ratePerOne);
                } else {
                    var _rn = Math.round(ratePerOne).toLocaleString();
                    payRateDisplay.innerText = (typeof t === 'function') ? String(t('payment_fx_line')).replace(/\{n\}/g, _rn) : ('1$ = ' + _rn + ' IQD');
                }
            }
            updatePayReceivedVisualIqdFromUsd((document.getElementById('pay-usd-input') && document.getElementById('pay-usd-input').value) || '');
            try {
                var _payGlass = document.querySelector('#payment-modal .pay-modal-glass');
                if (_payGlass && typeof applyI18nSubtree === 'function') applyI18nSubtree(_payGlass);
            } catch (ePayI18n) {}
            if (typeof applyCurrencyModeUiText === 'function') applyCurrencyModeUiText();
            if ((typeof getActiveCurrency === 'function' ? getActiveCurrency() : 'IQD') === 'USD') {
                fetchBasketVisualRateFromSqlLatest(true);
            }

            togglePayMethod('cash'); // Default to cash
            calcPayModalTotals();
            if (sysCurrency === 'USD') {
                var shownUsdAtOpen = getDisplayedPayTotalUsd();
                if (shownUsdAtOpen > 0) {
                    _setPayInputFormatted('pay-usd-input', shownUsdAtOpen, 'usd');
                    convertUSDPayment(shownUsdAtOpen);
                }
            }
            
            document.getElementById('payment-modal').style.display = 'flex';
            // Focus the primary input based on system currency
            setTimeout(function() {
                if (sysCurrency === 'USD') {
                    document.getElementById('pay-usd-input').focus();
                    if (document.getElementById('pay-usd-input').select) document.getElementById('pay-usd-input').select();
                } else {
                    document.getElementById('pay-received').focus();
                    if (document.getElementById('pay-received').select) document.getElementById('pay-received').select();
                }
            }, 100);
        }

        function convertUSDPayment(usdVal) {
            var usd = typeof parseAmountInput === 'function' ? parseAmountInput(String(usdVal)) : parseFloat(String(usdVal).replace(/,/g, ''));
            var rate = getUsdRatePerOneForPaymentScreen();
            if (!isNaN(usd) && usd > 0 && rate > 0) {
                var rm = typeof roundMoney === 'function' ? roundMoney : function(x){ return Math.round(Number(x)); };
                _setPayInputFormatted('pay-received', rm(usd * rate), 'iqd');
            } else {
                document.getElementById('pay-received').value = '';
            }
            updatePayReceivedVisualIqdFromUsd(usdVal);
            calcPayModalTotals();
        }

        function updateUSDFromIQD(iqdVal) {
            var iqd = typeof parseAmountInput === 'function' ? parseAmountInput(String(iqdVal)) : parseFloat(String(iqdVal).replace(/,/g, ''));
            var rate = getUsdRatePerOneForPaymentScreen();
            if (!isNaN(iqd) && iqd >= 0) {
                if (rate > 0) _setPayInputFormatted('pay-usd-input', iqd / rate, 'usd');
                else _setPayInputFormatted('pay-usd-input', 0, 'usd');
            } else {
                document.getElementById('pay-usd-input').value = '';
            }
            updatePayReceivedVisualIqdFromUsd(document.getElementById('pay-usd-input').value || '');
            calcPayModalTotals();
        }

        function getUsdRatePerOneForPaymentScreen() {
            // Never use basket "visual" FX here — that rate is cart/display-only. Payment math follows
            // catalog pricing (effective line rate) or system settings (getUsdRatePerOne).
            try {
                var payTot = document.getElementById('pay-modal-total');
                if (payTot) {
                    var rawSubIqdEff = parseFloat(payTot.dataset.rawSubtotalIqd || '');
                    var lineUsdEff = parseFloat(payTot.dataset.lineUsdSumF || '');
                    if (isFinite(rawSubIqdEff) && rawSubIqdEff > 0 && isFinite(lineUsdEff) && lineUsdEff > 0) {
                        var eff = rawSubIqdEff / lineUsdEff;
                        if (isFinite(eff) && eff > 0) return eff;
                    }
                }
            } catch (e) {}
            var base = (typeof getUsdRatePerOne === 'function') ? getUsdRatePerOne() : 0;
            return (isFinite(base) && base > 0) ? base : 0;
        }
        function isSalesPaymentUsdMode() {
            return (typeof getActiveCurrency === 'function')
                ? (getActiveCurrency() === 'USD')
                : !!(db && db.settings && db.settings.currencyMode === 'USD');
        }
        function getSalesPaymentInputKind() {
            return isSalesPaymentUsdMode() ? 'usd' : 'int';
        }
        function salesPaymentDisplayToIqd(val) {
            var parsed = (typeof parseAmountInput === 'function')
                ? parseAmountInput(String(val || ''))
                : parseFloat(String(val || '').replace(/,/g, ''));
            var n = Number.isFinite(parsed) ? parsed : 0;
            if (!isSalesPaymentUsdMode()) return n;
            var rate = getUsdRatePerOneForPaymentScreen();
            if (typeof usdAmountToStoredIqd === 'function') return usdAmountToStoredIqd(n, rate);
            var iqd = rate > 0 ? (n * rate) : 0;
            return (typeof roundMoney === 'function') ? roundMoney(iqd) : iqd;
        }
        function salesPaymentIqdToDisplay(iqdVal) {
            var n = Number(iqdVal) || 0;
            if (!isSalesPaymentUsdMode()) return n;
            var rate = getUsdRatePerOneForPaymentScreen();
            if (!(rate > 0)) return 0;
            return (typeof storedIqdToUsdAmount === 'function') ? storedIqdToUsdAmount(n, rate) : (n / rate);
        }

        function getDisplayedPayTotalUsd() {
            var payTot = document.getElementById('pay-modal-total');
            if (!payTot) return 0;
            var txt = String(payTot.innerText || '').replace(/[$,\s]/g, '');
            var v = parseFloat(txt);
            return (isFinite(v) && v >= 0) ? v : 0;
        }

        function updatePayReceivedVisualIqdFromUsd(usdVal) {
            var el = document.getElementById('pay-received-visual-iqd');
            if (!el) return;
            var isUsdMode = true;
            var usd = typeof parseAmountInput === 'function' ? parseAmountInput(String(usdVal || '')) : parseFloat(String(usdVal || '').replace(/,/g, ''));
            var convPerOne = (typeof getUsdRatePerOneForPaymentScreen === 'function') ? getUsdRatePerOneForPaymentScreen() : 0;
            if (!isFinite(usd) || usd < 0 || !isFinite(convPerOne) || convPerOne <= 0) {
                el.style.display = 'none';
                el.textContent = '';
                return;
            }
            var eqIqd = (typeof usdAmountToStoredIqd === 'function')
                ? usdAmountToStoredIqd(usd, convPerOne)
                : Math.round(usd * convPerOne);
            el.style.display = 'block';
            el.textContent = '≈ ' + Number(eqIqd).toLocaleString('en-US') + ' IQD';
        }

        function closePaymentModal() {
            var modal = document.getElementById('payment-modal');
            if (modal) modal.style.display = 'none';
            if (typeof window.focusTxnScannerInput === 'function') {
                window.focusTxnScannerInput('pos', { clear: true, delay: 50 });
            }
        }

        let activePayInputId = 'pay-received';
        let isAutoUpdatingSplitCash = false;
        function setActivePayInput(id) {
            activePayInputId = id;
        }

        function handlePayNumpad(key) {
            const input = document.getElementById(activePayInputId);
            if (!input) return;
            const kind = activePayInputId === 'pay-usd-input'
                ? 'usd'
                : (activePayInputId === 'pay-received' ? 'int' : getSalesPaymentInputKind());
            let raw = (input.value || '').replace(/,/g, '');
            if (key === 'C') {
                raw = '';
            } else if (key === '.') {
                if (kind === 'usd' && raw.indexOf('.') === -1) raw += '.';
            } else {
                raw += key;
            }
            input.value = raw;
            if (typeof formatPaymentInputElement === 'function') formatPaymentInputElement(input, kind);
            if (activePayInputId === 'pay-usd-input') {
                convertUSDPayment(input.value);
            } else {
                calcPayModalTotals();
                if (activePayInputId === 'pay-received' && typeof updateUSDFromIQD === 'function') updateUSDFromIQD(input.value);
            }
        }

        function posIsFibPayMethod(method) {
            var m = String(method || '').toLowerCase();
            return m === 'fib' || m === 'bankcard' || m === 'bank' || m === 'card';
        }

        function togglePayMethod(method) {
            if (posIsFibPayMethod(method)) method = 'fib';
            currentPayMethod = method;
            document.getElementById('pm-btn-cash').classList.toggle('active', method === 'cash');
            document.getElementById('pm-btn-debt').classList.toggle('active', method === 'debt');
            const bankBtn = document.getElementById('pm-btn-bankcard');
            if (bankBtn) bankBtn.classList.toggle('active', method === 'fib');

            const debtSec = document.getElementById('pay-debt-section');
            const bankSec = document.getElementById('pay-bank-section');
            if (method === 'debt') {
                if (debtSec) debtSec.style.display = 'block';
                if (bankSec) bankSec.style.display = 'none';
                const total = parseFloat(document.getElementById('pay-modal-total').dataset.final) || 0;
                const da = document.getElementById('pay-debt-amount');
                if (da) _setPayInputFormatted('pay-debt-amount', salesPaymentIqdToDisplay(total), getSalesPaymentInputKind());
                const cashEl = document.getElementById('pay-received');
                if (cashEl) { cashEl.value = ''; cashEl.focus(); }
                const usdEl = document.getElementById('pay-usd-input');
                if (usdEl) usdEl.value = '';
                const ba = document.getElementById('pay-bank-card-amount');
                if (ba) ba.value = '';
                renderPayDebtSearch('');
                setActivePayInput('pay-received');
            } else if (method === 'fib') {
                if (debtSec) debtSec.style.display = 'none';
                if (bankSec) bankSec.style.display = 'block';
                const total = parseFloat(document.getElementById('pay-modal-total').dataset.final) || 0;
                const cashEl = document.getElementById('pay-received');
                if (cashEl) cashEl.value = '';
                const debtEl = document.getElementById('pay-debt-amount');
                if (debtEl) _setPayInputFormatted('pay-debt-amount', 0, getSalesPaymentInputKind());
                const usdEl = document.getElementById('pay-usd-input');
                if (usdEl) usdEl.value = '';
                const el = document.getElementById('pay-bank-card-amount');
                if (el) {
                    _setPayInputFormatted('pay-bank-card-amount', salesPaymentIqdToDisplay(total), getSalesPaymentInputKind());
                    el.focus();
                    if (el.select) el.select();
                }
                setActivePayInput('pay-bank-card-amount');
            } else {
                if (debtSec) debtSec.style.display = 'none';
                if (bankSec) bankSec.style.display = 'none';
                const total = parseFloat(document.getElementById('pay-modal-total').dataset.final) || 0;
                const cashEl = document.getElementById('pay-received');
                var isUsdModeCash = (typeof getActiveCurrency === 'function') ? (getActiveCurrency() === 'USD') : false;
                if (isUsdModeCash) {
                    var shownUsd = getDisplayedPayTotalUsd();
                    if (shownUsd > 0) {
                        _setPayInputFormatted('pay-usd-input', shownUsd, 'usd');
                        convertUSDPayment(shownUsd);
                    } else {
                        if (cashEl) _setPayInputFormatted('pay-received', total, 'iqd');
                        updateUSDFromIQD(total);
                    }
                } else {
                    if (cashEl) _setPayInputFormatted('pay-received', total, 'iqd');
                    updateUSDFromIQD(total);
                }
                if (cashEl) cashEl.focus();
                const da = document.getElementById('pay-debt-amount');
                if (da) da.value = '';
                const ba = document.getElementById('pay-bank-card-amount');
                if (ba) ba.value = '';
            }
            calcPayModalTotals();
        }
        window.togglePayMethod = togglePayMethod;
        window.posIsFibPayMethod = posIsFibPayMethod;

        function renderPayDebtSearch(q) {
            const container = document.getElementById('pay-debt-list');
            const lowerQ = q.toLowerCase();
            // Combine customers and staff
            const all = [
                ...db.customers.map(c => ({...c, type:'customer'})),
                ...db.users.map(u => ({...u, type:'user'}))
            ];
            
            const filtered = all.filter(p => p.name.toLowerCase().includes(lowerQ)).slice(0, 20);
            
            container.innerHTML = filtered.map(function(p) {
                var _tc = (typeof t === 'function');
                var typeLab = (p.type === 'user')
                    ? (_tc ? t('payment_debt_type_staff') : 'کارمەند')
                    : (_tc ? t('payment_debt_type_customer') : 'کڕیار');
                return '<div class="pay-debt-item" onclick="selectPayDebtTarget(' + p.id + ', \'' + p.type + '\', this)">' +
                    '<b>' + escapeHtml(p.name || 'ئایتم') + '</b><br>' +
                    '<small>' + escapeHtml(typeLab) + '</small></div>';
            }).join('');
        }

        function selectPayDebtTarget(id, type, el) {
            document.querySelectorAll('.pay-debt-item').forEach(e => e.classList.remove('selected'));
            el.classList.add('selected');
            document.getElementById('pay-selected-debt-id').value = id;
            document.getElementById('pay-selected-debt-type').value = type;
        }

        function calcPayModalTotals() {
            const rm = typeof roundMoney === 'function' ? roundMoney : function(x) { return Math.round(Number(x) || 0); };
            const payTot = document.getElementById('pay-modal-total');
            const payVisualIqd = document.getElementById('pay-modal-iqd-visual');
            const subTotal = rm(parseFloat(payTot.dataset.subtotal) || 0);
            const discPctRaw = parseFloat(document.getElementById('pay-discount-pct').value);
            const discPct = (!isFinite(discPctRaw) || discPctRaw < 0) ? 0 : Math.min(100, discPctRaw);
            let discount = 0;
            if (discPct > 0 && discPct <= 100) discount = rm(subTotal * (discPct / 100));
            if (!isFinite(discount) || discount < 0) discount = 0;
            if (discount > subTotal) discount = subTotal;
            let total = rm(subTotal - discount);
            if (!isFinite(total) || total < 0) total = 0;
            const rawSubIqd = parseFloat(payTot.dataset.rawSubtotalIqd || '') || 0;
            const lineUsdF = parseFloat(payTot.dataset.lineUsdSumF || '') || 0;
            const isUsdPos = typeof getDefaultCurrency === 'function' ? (getDefaultCurrency() === 'USD') : (typeof getActiveCurrency === 'function' ? (getActiveCurrency() === 'USD') : !!(db.settings && db.settings.currencyMode === 'USD'));
            var dispUsd = 0;
            var ratePayHint = (typeof getUsdRatePerOneForPaymentScreen === 'function') ? getUsdRatePerOneForPaymentScreen() : ((typeof getUsdRatePerOne === 'function') ? getUsdRatePerOne() : 0);
            if (rawSubIqd > 0 && lineUsdF > 0 && isFinite(lineUsdF)) {
                dispUsd = lineUsdF * (total / rawSubIqd);
            } else if (ratePayHint > 0) {
                dispUsd = total / ratePayHint;
            }
            if (!isFinite(dispUsd) || dispUsd < 0) dispUsd = 0;
            var dualPay = (typeof formatDualCurrencyLines === 'function')
                ? formatDualCurrencyLines(total, dispUsd, ratePayHint)
                : null;
            if (dualPay) {
                payTot.innerHTML = dualPay.primary;
            } else if (isUsdPos) {
                payTot.innerText = (typeof formatUsdAmount === 'function') ? formatUsdAmount(dispUsd) : ('$' + (typeof formatUsdNumberPlain === 'function' ? formatUsdNumberPlain(dispUsd) : Number(dispUsd).toFixed(2)));
            } else {
                payTot.innerText = formatCurrency(total) + ' ' + getCurrencySymbol();
            }
            if (payVisualIqd) {
                if (dualPay && dualPay.secondary) {
                    payVisualIqd.style.display = 'block';
                    payVisualIqd.innerHTML = dualPay.secondary + (dualPay.rate ? (' · ' + dualPay.rate) : '');
                } else {
                    payVisualIqd.style.display = 'none';
                    payVisualIqd.textContent = '';
                }
            }
            payTot.dataset.final = String(total);

            const iqdRaw = (document.getElementById('pay-received').value || '').replace(/,/g, '');
            const usdRaw = (document.getElementById('pay-usd-input')?.value || '').replace(/,/g, '');
            const iqdReceived = (typeof parseAmountInput === 'function' ? parseAmountInput(iqdRaw) : parseFloat(iqdRaw)) || 0;
            const usdReceived = (typeof parseAmountInput === 'function' ? parseAmountInput(usdRaw) : parseFloat(usdRaw)) || 0;
            updatePayReceivedVisualIqdFromUsd(usdRaw);
            const exchangeRate = parseFloat(getUsdRatePerOne()) || 0;
            
            const sysCurrency = (typeof getActiveCurrency === 'function')
                ? getActiveCurrency()
                : ((db && db.settings && String(db.settings.currencyMode || 'IQD').toUpperCase() === 'USD') ? 'USD' : 'IQD');
            
            // The internal calculation for totals is ALWAYS in IQD (base currency).
            // Since convertUSDPayment updates pay-received, iqdReceived ALWAYS holds the cash total in IQD.
            var bankPaidModal = 0;
            if (posIsFibPayMethod(currentPayMethod)) {
                var bankRawModal = (document.getElementById('pay-bank-card-amount') && document.getElementById('pay-bank-card-amount').value) || '';
                bankPaidModal = (typeof salesPaymentDisplayToIqd === 'function')
                    ? salesPaymentDisplayToIqd(bankRawModal)
                    : ((typeof parseAmountInput === 'function' ? parseAmountInput(bankRawModal) : parseFloat(String(bankRawModal).replace(/,/g, ''))) || 0);
                bankPaidModal = rm(Math.max(0, bankPaidModal));
            }
            const totalPaidInBase = rm(iqdReceived + bankPaidModal);

            const finalBalance = rm(totalPaidInBase - total);
            const change = finalBalance > 0 ? finalBalance : 0;
            const debt = finalBalance < 0 ? Math.abs(finalBalance) : 0;

            const debtInputEl = document.getElementById('pay-debt-amount');
            if (debtInputEl) {
                var debtCur = salesPaymentDisplayToIqd(debtInputEl.value || '0');
                if (isNaN(debtCur)) debtCur = 0;
                if (debtCur !== debt) _setPayInputFormatted('pay-debt-amount', salesPaymentIqdToDisplay(debt), getSalesPaymentInputKind());
            }

            const changeEl = document.getElementById('pay-change');
            const debtEl = document.getElementById('pay-debt');
            const hintEl = document.getElementById('pay-change-hint');
            // Use the SAME effective rate as the displayed total/debt-input so the summary cannot diverge
            // from the modal's own math when the global usdRate differs from the cart's per-item USD rate
            // (e.g., items priced at 1530 but settings.usdRate=1500 → previously showed phantom debt of ~2%).
            var summaryFxOpts;
            if (isUsdPos && total > 0 && dispUsd > 0) {
                var effRate100 = Math.round((total / dispUsd) * 100);
                if (isFinite(effRate100) && effRate100 >= 1000) summaryFxOpts = { fxUsdRate: effRate100 };
            }
            var changeUsd = (ratePayHint > 0) ? (change / ratePayHint) : 0;
            var debtUsd = (ratePayHint > 0) ? (debt / ratePayHint) : 0;
            var dualChange = (typeof formatDualCurrencyLines === 'function')
                ? formatDualCurrencyLines(change, changeUsd, ratePayHint)
                : null;
            var dualDebt = (typeof formatDualCurrencyLines === 'function')
                ? formatDualCurrencyLines(debt, debtUsd, ratePayHint)
                : null;
            if (dualChange) {
                changeEl.innerHTML = dualChange.primary + (dualChange.secondary ? ('<div class="pay-change-secondary" data-allow-iqd="1">' + dualChange.secondary + '</div>') : '');
            } else {
                changeEl.innerText = formatCurrency(change, summaryFxOpts) + ' ' + getCurrencySymbol();
            }
            changeEl.style.color = change > 0 ? 'var(--success)' : 'var(--text)';
            if (debtEl) {
                if (dualDebt) {
                    debtEl.innerHTML = dualDebt.primary + (dualDebt.secondary ? ('<div class="pay-change-secondary" data-allow-iqd="1">' + dualDebt.secondary + '</div>') : '');
                } else {
                    debtEl.innerText = formatCurrency(debt, summaryFxOpts) + ' ' + getCurrencySymbol();
                }
                debtEl.style.color = debt > 0 ? 'var(--danger)' : 'var(--text)';
            }
            if (hintEl) {
                var _tPay = (typeof t === 'function');
                hintEl.textContent = debt > 0 ? (_tPay ? t('payment_hint_sales_debt') : 'قەرز ماوە') : (_tPay ? t('payment_hint_sales_ok') : 'تەواوکراوە');
                hintEl.style.color = debt > 0 ? 'var(--danger)' : 'var(--success)';
            }
        }

        function confirmAdvancedPayment() {
            if (window._confirmAdvancedPaymentPending) return;
            var payGate = typeof assertPosPaymentModalAllowed === 'function' ? assertPosPaymentModalAllowed() : null;
            if (payGate) {
                if (typeof showPosSaleGatePopup === 'function') showPosSaleGatePopup(payGate);
                return;
            }
            const total = parseFloat(document.getElementById('pay-modal-total').dataset.final) || 0;
            const iqdReceived = (typeof parseAmountInput === 'function' ? parseAmountInput(document.getElementById('pay-received').value || '') : parseFloat((document.getElementById('pay-received').value || '').replace(/,/g, ''))) || 0;
            const usdReceived = (typeof parseAmountInput === 'function' ? parseAmountInput(document.getElementById('pay-usd-input')?.value || '') : parseFloat((document.getElementById('pay-usd-input')?.value || '').replace(/,/g, ''))) || 0;
            const exchangeRate = parseFloat(getUsdRatePerOne()) || 0;
            
            const sysCurrency = (typeof getActiveCurrency === 'function')
                ? getActiveCurrency()
                : ((db && db.settings && String(db.settings.currencyMode || 'IQD').toUpperCase() === 'USD') ? 'USD' : 'IQD');
            var bankRaw = (document.getElementById('pay-bank-card-amount') && document.getElementById('pay-bank-card-amount').value) || '';
            var bank = (typeof salesPaymentDisplayToIqd === 'function') ? salesPaymentDisplayToIqd(bankRaw) : (parseFloat(String(bankRaw).replace(/,/g, '')) || 0);
            bank = roundMoney(Math.max(0, bank));
            var cashPaid = roundMoney(Math.max(0, iqdReceived));
            if (posIsFibPayMethod(currentPayMethod)) {
                if (bank <= 0) bank = roundMoney(Math.max(0, total - cashPaid));
                if (cashPaid > 0 && bank >= total - 1) cashPaid = 0;
            } else {
                bank = 0;
            }
            const totalPaidInBase = roundMoney(cashPaid + bank);
            const finalBalance = roundMoney(totalPaidInBase - total);
            const change = finalBalance > 0 ? finalBalance : 0;
            var debt = finalBalance < 0 ? roundMoney(Math.abs(finalBalance)) : 0;
            const discPct = document.getElementById('pay-discount-pct').value;

            // Apply Discount to Main UI
            if(discPct) {
                var posDiscApply = document.getElementById('pos-discount');
                if (posDiscApply) posDiscApply.value = discPct;
            }
            
            let targetId = 0, targetType = '';
            if (debt > 0) {
                targetId = document.getElementById('pay-selected-debt-id').value;
                targetType = document.getElementById('pay-selected-debt-type').value;
                if(!targetId) return alert("هیڤییە کەسەکێ هەلبژێرە بۆ قەرزی!");
            }

            var tolPay = 1;
            var methodSend = 'split';
            if (bank >= total - tolPay && cashPaid <= tolPay && debt <= tolPay) {
                methodSend = 'fib';
                bank = total;
                cashPaid = 0;
                debt = 0;
            } else if (debt <= tolPay && bank <= tolPay) {
                methodSend = 'cash';
            } else if (cashPaid <= tolPay && bank <= tolPay && debt >= total - tolPay) {
                methodSend = 'debt';
            }

            window._confirmAdvancedPaymentPending = true;
            window._saleFromPaymentModal = true;
            closePaymentModal();
            if (methodSend === 'cash') {
                processPayment('cash', targetId, targetType);
            } else if (methodSend === 'debt') {
                processPayment('debt', targetId, targetType);
            } else {
                processPayment(methodSend, targetId, targetType, {
                    cash: cashPaid,
                    debt: debt,
                    bank: bank,
                    change: change,
                    paid_cash: cashPaid,
                    paid_bank: bank,
                    remaining_debt: debt,
                    paid_amount: roundMoney(cashPaid + bank),
                    debt_amount: debt,
                    bank_amount: bank,
                    received_amount: cashPaid
                });
            }
        }
        window.confirmAdvancedPayment = confirmAdvancedPayment;

        /** Sale POST target — same router as get_data (?action= via index.php), not direct api/all.php. */
        function resolvePosApiAllUrl() {
            if (typeof window.posRouterUrl === 'function') {
                return window.posRouterUrl('');
            }
            return '?';
        }

        /** Block POS sale when a line price is 0 but catalog price for that unit is also 0 (not a discount-to-zero case). */
        function validatePosItemsNoIllegalZeroPrice(table) {
            if (!table || !table.items || !table.items.length) return { ok: true };
            var rm = typeof roundMoney === 'function' ? roundMoney : function(x) { return Math.round(Number(x)); };
            for (var i = 0; i < table.items.length; i++) {
                var item = table.items[i];
                if (item.isGift) continue;
                var linePrice = rm(typeof getBillLineUnitIqd === 'function' ? getBillLineUnitIqd(item) : (parseFloat(item.price) || 0));
                if (linePrice > 0) continue;
                if (item.isManualItem) return { ok: false };
                var prod = db.products.find(function(p) { return String(p.id) === String(item.id); });
                var listPrice = 0;
                if (prod) {
                    listPrice = typeof getPriceForUnit === 'function'
                        ? rm(getPriceForUnit(prod, item.saleUnit || 'piece', table))
                        : rm(parseFloat(prod.price) || 0);
                }
                if (listPrice <= 0) return { ok: false };
            }
            return { ok: true };
        }

        window.toggleCreditButton = function() {
            const name = typeof getPosCustomerNameValue === 'function' ? getPosCustomerNameValue() : '';
            const paidInput = document.getElementById('pos-customer-paid');
            const paidField = document.querySelector('#view-pos .pos-paid-field');
            const debtInfo = document.getElementById('pos-debt-remaining-info');
            const expandPaid = document.getElementById('pos-expand-customer-paid');

            if (expandPaid) expandPaid.classList.toggle('is-hidden-until-customer', !name);
            if (paidField) paidField.classList.toggle('is-hidden-until-customer', !name);
            if (!name && paidInput) paidInput.value = '';
            if (!name && expandPaid) expandPaid.value = '';
            if (!name && typeof window.setPosCustomerPhoneValue === 'function') window.setPosCustomerPhoneValue('');
            else if (typeof window.syncPosCustomerPhoneFromName === 'function') window.syncPosCustomerPhoneFromName();

            if (name && typeof calculateDebtRemaining === 'function') {
                calculateDebtRemaining();
            } else {
                if (debtInfo) {
                    debtInfo.classList.remove('is-visible');
                    debtInfo.style.display = 'none';
                }
                var compactPos = document.getElementById('pos-debt-remaining-compact');
                if (compactPos) compactPos.innerText = '0';
                var debtVal = document.getElementById('pos-debt-remaining-val');
                if (debtVal) debtVal.innerText = '0';
                var debtOldVal = document.getElementById('pos-debt-old-val');
                if (debtOldVal) debtOldVal.innerText = '0';
                var debtInvVal = document.getElementById('pos-debt-invoice-val');
                if (debtInvVal) debtInvVal.innerText = '0';
                var debtCashVal = document.getElementById('pos-debt-cash-val');
                if (debtCashVal) debtCashVal.innerText = '0';
                var debtAddedVal = document.getElementById('pos-debt-added-val');
                if (debtAddedVal) debtAddedVal.innerText = '0';
                var debtAddedRow = document.getElementById('pos-debt-added-row');
                if (debtAddedRow) debtAddedRow.style.display = 'none';
                if (typeof togglePaymentDueRow === 'function') togglePaymentDueRow('pos', false);
                window._posPaymentDuePrefillKey = null;
            }

            if (typeof window.updateTxnPeekBar === 'function') window.updateTxnPeekBar('pos');
            if (name && typeof window.maybeCollapseTxnMetaAfterValid === 'function') {
                window.maybeCollapseTxnMetaAfterValid('pos', ['pos-customer-name']);
            }
        };

        window.calculateDebtRemaining = function() {
            const table = db.tables.find(t => t.id === activeTableId);
            if (!table) return;

            const totals = computePosCartTotals(table);
            const total = totals.finalIqd;
            const paidInput = document.getElementById('pos-customer-paid');
            const debtInfo = document.getElementById('pos-debt-remaining-info');
            const debtVal = document.getElementById('pos-debt-remaining-val');
            const debtOldVal = document.getElementById('pos-debt-old-val');
            const debtInvVal = document.getElementById('pos-debt-invoice-val');
            const debtCashVal = document.getElementById('pos-debt-cash-val');
            const debtAddedVal = document.getElementById('pos-debt-added-val');
            const debtAddedRow = document.getElementById('pos-debt-added-row');
            
            if (paidInput && debtInfo && debtVal && debtOldVal) {
                const custName = typeof getPosCustomerNameValue === 'function' ? getPosCustomerNameValue() : (document.getElementById('pos-customer-name').value || '').trim();

                // If customer is empty or cleared, immediately hide debt strip and reset all values to 0
                if (!custName) {
                    debtInfo.classList.remove('is-visible');
                    debtInfo.style.display = 'none';
                    debtOldVal.innerText = '0';
                    if (debtInvVal) debtInvVal.innerText = '0';
                    if (debtCashVal) debtCashVal.innerText = '0';
                    if (debtAddedVal) debtAddedVal.innerText = '0';
                    if (debtAddedRow) debtAddedRow.style.display = 'none';
                    debtVal.innerText = '0';
                    var compactPosZero = document.getElementById('pos-debt-remaining-compact');
                    if (compactPosZero) compactPosZero.innerText = '0';
                    if (typeof togglePaymentDueRow === 'function') togglePaymentDueRow('pos', false);
                    window._posPaymentDuePrefillKey = null;
                    return;
                }

                let paid = (typeof getPosCustomerPaidValue === 'function')
                    ? getPosCustomerPaidValue()
                    : ((typeof parseAmountInput === 'function')
                        ? (parseAmountInput(paidInput.value || '') || 0)
                        : (parseFloat(String(paidInput.value || '').replace(/,/g, '')) || 0));
                const activeCur = typeof getActiveCurrency === 'function' ? getActiveCurrency() : 'IQD';
                if (activeCur === 'USD') {
                    const rate = typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0;
                    if (rate > 0) {
                        paid = paid * rate;
                    }
                }
                if (paid < 0) paid = 0;

                const roundM = typeof roundMoney === 'function' ? roundMoney : function(x) { return Math.round(Number(x)); };
                const creditFromInvoice = roundM(Math.max(0, total - paid));
                
                let previousDebt = 0;
                let cust = null;
                var activeCid = (typeof window.getPosActiveCustomerId === 'function') ? (window.getPosActiveCustomerId() || 0) : 0;
                if (activeCid > 0 && db.customers) {
                    cust = db.customers.find(function (c) { return c && parseInt(c.id, 10) === activeCid; }) || null;
                }
                if (!cust && custName && db.customers) {
                    var needleDebt = String(custName).trim().toLowerCase();
                    cust = db.customers.find(function (c) {
                        return c && String(c.name || '').trim().toLowerCase() === needleDebt;
                    }) || null;
                }
                if (cust) {
                    previousDebt = parseFloat(cust.balance) || 0;
                }
                
                if (custName && (creditFromInvoice > 0 || paid > 0 || previousDebt > 0)) {
                    const fmt = (typeof formatPosMoneyDisplay === 'function') ? formatPosMoneyDisplay : ((typeof formatCurrency === 'function') ? formatCurrency : String);
                    debtOldVal.innerText = fmt(previousDebt);
                    if (debtInvVal) debtInvVal.innerText = fmt(total);
                    if (debtCashVal) debtCashVal.innerText = fmt(paid);
                    if (debtAddedVal) debtAddedVal.innerText = fmt(creditFromInvoice);
                    if (debtAddedRow) debtAddedRow.style.display = creditFromInvoice > 0 ? '' : 'none';
                    debtVal.innerText = fmt(previousDebt + creditFromInvoice);
                    var compactPos = document.getElementById('pos-debt-remaining-compact');
                    if (compactPos) compactPos.innerText = debtVal.innerText;
                    debtInfo.style.display = '';
                    debtInfo.classList.add('is-visible');
                    if (typeof togglePaymentDueRow === 'function') togglePaymentDueRow('pos', true);
                    // Prefill term only when customer identity changes (do not reset cashier edits on every refresh).
                    var custKey = cust ? ('c:' + String(cust.id)) : ('n:' + String(custName).toLowerCase());
                    if (window._posPaymentDuePrefillKey !== custKey) {
                        window._posPaymentDuePrefillKey = custKey;
                        if (cust && typeof applyEntityPaymentTermToTxn === 'function') applyEntityPaymentTermToTxn('pos', cust);
                    }
                } else {
                    debtInfo.classList.remove('is-visible');
                    debtInfo.style.display = 'none';
                    debtOldVal.innerText = '0';
                    if (debtInvVal) debtInvVal.innerText = '0';
                    if (debtCashVal) debtCashVal.innerText = '0';
                    if (debtAddedVal) debtAddedVal.innerText = '0';
                    if (debtAddedRow) debtAddedRow.style.display = 'none';
                    debtVal.innerText = '0';
                    var compactPosElse = document.getElementById('pos-debt-remaining-compact');
                    if (compactPosElse) compactPosElse.innerText = '0';
                    if (typeof togglePaymentDueRow === 'function') togglePaymentDueRow('pos', false);
                    window._posPaymentDuePrefillKey = null;
                }
            }
        };

        window.togglePosDebtDetails = function(forceOpen) {
            var body = document.getElementById('pos-debt-expanded-rows');
            var btn = document.getElementById('btn-toggle-pos-debt');
            if (!body) return;
            var isCollapsed = body.classList.contains('is-collapsed');
            var shouldOpen = typeof forceOpen === 'boolean' ? forceOpen : isCollapsed;
            body.classList.toggle('is-collapsed', !shouldOpen);
            if (btn) {
                btn.setAttribute('aria-expanded', shouldOpen ? 'true' : 'false');
                var icon = btn.querySelector('.txn-details-chevron');
                if (icon) {
                    icon.className = shouldOpen ? 'fas fa-chevron-up txn-details-chevron' : 'fas fa-chevron-down txn-details-chevron';
                }
            }
        };

        function saveQuickCustomer(data) {
            const name = (typeof data === 'string') ? data.trim() : String(data && data.name || '').trim();
            const phone = (typeof data === 'object' && data) ? String(data.phone || '').trim() : '';
            const address = (typeof data === 'object' && data) ? String(data.address || '').trim() : '';
            const openingBalance = (typeof data === 'object' && data) ? (parseFloat(data.opening_balance) || 0) : 0;
            const debtLimit = (typeof data === 'object' && data) ? (parseFloat(data.debt_limit) || 0) : 0;
            const paymentTermValue = (typeof data === 'object' && data) ? (parseInt(data.payment_term_value, 10) || 0) : 0;
            const paymentTermUnit = (typeof data === 'object' && data && data.payment_term_unit) ? data.payment_term_unit : 'day';
            if (!name) return;
            const exists = db.customers.some(c => c.name === name);
            if (exists) {
                showToast("⚠️ ئەڤ کڕیارە پێشتر یێ هەی!", "error");
                var existingCust = db.customers.find(function (c) {
                    return c && String(c.name || '').trim().toLowerCase() === name.trim().toLowerCase();
                });
                if (existingCust && typeof window.setPosActiveCustomer === 'function') {
                    window.setPosActiveCustomer(existingCust.id, existingCust.name || name);
                } else {
                    document.getElementById('pos-customer-name').value = name;
                }
                toggleCreditButton();
                return;
            }

            const formData = new FormData();
            formData.append('action', 'save_customer');
            formData.append('name', name);
            formData.append('phone', phone);
            formData.append('address', address);
            formData.append('opening_balance', openingBalance);
            formData.append('debt_limit', debtLimit);
            formData.append('payment_term_value', paymentTermValue);
            formData.append('payment_term_unit', (typeof normalizePaymentTermUnit === 'function') ? normalizePaymentTermUnit(paymentTermUnit) : paymentTermUnit);

            fetch('?action=save_customer', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                if(data.status === 'success') {
                    const obSt = (typeof debtFormAmountToStoredIqd === 'function') ? debtFormAmountToStoredIqd(openingBalance) : openingBalance;
                    const dlSt = (typeof debtFormAmountToStoredIqd === 'function') ? debtFormAmountToStoredIqd(debtLimit) : debtLimit;
                    const bal = (typeof data.balance !== 'undefined') ? (parseFloat(data.balance) || 0) : obSt;
                    db.customers.push({ id: data.id, name: name, phone: phone, address: address, opening_balance: obSt, debt_limit: dlSt, balance: bal, payment_term_value: paymentTermValue, payment_term_unit: (typeof normalizePaymentTermUnit === 'function') ? normalizePaymentTermUnit(paymentTermUnit) : paymentTermUnit });
                    populateCustomerDatalist();
                    if (typeof window.setPosActiveCustomer === 'function') {
                        window.setPosActiveCustomer(data.id, name);
                    } else {
                        document.getElementById('pos-customer-name').value = name;
                    }
                    toggleCreditButton();
                    showToast("✅ کڕیار ب سەرکەفتیانە هاتە زێدەکرن!");
                } else {
                    showToast("❌ نەشیا کڕیار زێدە بکەت!", "error");
                }
            }).catch(err => showToast("❌ هەڵە: " + err, "error"));
        }

        window.quickAddCustomer = function() {
            const currentName = document.getElementById('pos-customer-name').value.trim();
            if (typeof openPosEntityNamePrompt === 'function') {
                openPosEntityNamePrompt({
                    entityType: 'customer',
                    defaultValue: currentName,
                    icon: 'fa-user-plus',
                    iconTone: 'customer',
                    onConfirm: saveQuickCustomer
                });
                return;
            }
            const customerName = prompt("ناڤێ کڕیارێ نوێ بنڤیسە:", currentName);
            if (!customerName || !customerName.trim()) return;
            saveQuickCustomer({ name: customerName.trim(), phone: '', address: '', opening_balance: 0, debt_limit: 0 });
        };

        function saveQuickCompany(data) {
            const name = (typeof data === 'string') ? data.trim() : String(data && data.name || '').trim();
            const phone = (typeof data === 'object' && data) ? String(data.phone || '').trim() : '';
            const address = (typeof data === 'object' && data) ? String(data.address || '').trim() : '';
            const openingBalance = (typeof data === 'object' && data) ? (parseFloat(data.opening_balance) || 0) : 0;
            const debtLimit = (typeof data === 'object' && data) ? (parseFloat(data.debt_limit) || 0) : 0;
            const paymentTermValue = (typeof data === 'object' && data) ? (parseInt(data.payment_term_value, 10) || 0) : 0;
            const paymentTermUnit = (typeof data === 'object' && data && data.payment_term_unit) ? data.payment_term_unit : 'day';
            if (!name) return;
            const exists = db.companies.some(c => c.name === name);
            if (exists) {
                showToast("⚠️ ئەڤ کۆمپانیایە پێشتر یا هەی!", "error");
                return;
            }

            const formData = new FormData();
            formData.append('action', 'save_company');
            formData.append('name', name);
            formData.append('phone', phone);
            formData.append('address', address);
            formData.append('opening_balance', openingBalance);
            formData.append('debt_limit', debtLimit);
            formData.append('payment_term_value', paymentTermValue);
            formData.append('payment_term_unit', (typeof normalizePaymentTermUnit === 'function') ? normalizePaymentTermUnit(paymentTermUnit) : paymentTermUnit);

            fetch('?action=save_company', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                if(data.status === 'success') {
                    const obSt = (typeof debtFormAmountToStoredIqd === 'function') ? debtFormAmountToStoredIqd(openingBalance) : openingBalance;
                    const dlSt = (typeof debtFormAmountToStoredIqd === 'function') ? debtFormAmountToStoredIqd(debtLimit) : debtLimit;
                    const bal = (typeof data.balance !== 'undefined') ? (parseFloat(data.balance) || 0) : obSt;
                    db.companies.push({ id: data.id, name: name, phone: phone, address: address, opening_balance: obSt, debt_limit: dlSt, balance: bal, payment_term_value: paymentTermValue, payment_term_unit: (typeof normalizePaymentTermUnit === 'function') ? normalizePaymentTermUnit(paymentTermUnit) : paymentTermUnit });

                    var sel = document.getElementById('purchase-supplier-select');
                    if (sel) {
                        sel.innerHTML += '<option value="' + data.id + '">' + escapeHtml(name) + '</option>';
                        sel.value = data.id;
                        if (typeof onPurchaseSupplierChange === 'function') onPurchaseSupplierChange();
                    }
                    if (typeof window.refreshEntityDatalists === 'function') window.refreshEntityDatalists();
                    var qdSup = document.getElementById('qd-supplier');
                    if (qdSup && typeof populateQdSupplierSelect === 'function') populateQdSupplierSelect(name);
                    else if (qdSup) {
                        qdSup.innerHTML += '<option value="' + escapeHtml(name) + '">' + escapeHtml(name) + '</option>';
                        qdSup.value = name;
                    }
                    showToast("✅ دابینکەر ب سەرکەفتیانە هاتە زێدەکرن!");
                } else {
                    showToast("❌ نەشیا دابینکەر زێدە بکەت!", "error");
                }
            }).catch(err => showToast("❌ هەڵە: " + err, "error"));
        }

        window.quickAddCompany = function() {
            if (typeof openPosEntityNamePrompt === 'function') {
                openPosEntityNamePrompt({
                    entityType: 'supplier',
                    icon: 'fa-building',
                    iconTone: 'supplier',
                    onConfirm: saveQuickCompany
                });
                return;
            }
            const companyName = prompt("ناڤێ دابینکەر / کۆمپانیێ نوێ بنڤیسە:");
            if (!companyName || !companyName.trim()) return;
            saveQuickCompany({ name: companyName.trim(), phone: '', address: '', opening_balance: 0, debt_limit: 0 });
        };

        /** Named customer: paid field = cash/FIB; remainder = debt. Returns true if handled, false if no customer (use normal sell). */
        window.completePosSaleForNamedCustomer = function() {
            const table = db.tables.find(t => t.id === activeTableId);
            if (!table || table.items.length === 0) {
                showToast("⚠️ سەبەتە ڤالایە!", "error");
                return true;
            }

            if (typeof window.syncPosCustomerFieldsForCheckout === 'function') {
                window.syncPosCustomerFieldsForCheckout();
            } else if (typeof window.syncPosExpandCustomerFields === 'function') {
                var billPanel = document.getElementById('pos-bill-panel');
                window.syncPosExpandCustomerFields(billPanel && billPanel.classList.contains('expanded'));
            }
            const customerName = typeof getPosCustomerNameValue === 'function' ? getPosCustomerNameValue() : '';
            const activeCustomerId = (typeof window.getPosActiveCustomerId === 'function')
                ? (window.getPosActiveCustomerId() || 0)
                : (parseInt(window.__posActiveCustomerId, 10) || 0);
            if (!customerName && !(activeCustomerId > 0)) return false;

            const rm = typeof roundMoney === 'function' ? roundMoney : function (x) { return Math.round(Number(x) || 0); };
            var paidRaw = '';
            var billPaid = document.getElementById('pos-bill-panel');
            var expandPaid = document.getElementById('pos-expand-customer-paid');
            var mainPaid = document.getElementById('pos-customer-paid');
            if (billPaid && billPaid.classList.contains('expanded') && expandPaid) paidRaw = expandPaid.value || '';
            else paidRaw = mainPaid ? (mainPaid.value || '') : '';
            let paidAmount = 0;
            if (typeof salesPaymentDisplayToIqd === 'function') {
                paidAmount = salesPaymentDisplayToIqd(paidRaw);
            } else {
                paidAmount = typeof getPosCustomerPaidValue === 'function' ? getPosCustomerPaidValue() : 0;
                const activeCur = typeof getActiveCurrency === 'function' ? getActiveCurrency() : 'IQD';
                if (activeCur === 'USD') {
                    const rate = typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0;
                    if (rate > 0) paidAmount = paidAmount * rate;
                }
            }
            paidAmount = rm(Math.max(0, paidAmount));

            var totalAmount = 0;
            if (typeof computePosCartTotals === 'function') {
                var cartTot = computePosCartTotals(table);
                totalAmount = rm((cartTot && cartTot.finalIqd != null) ? cartTot.finalIqd : 0);
            } else {
                const subTotal = table.items.reduce(function(a, b) {
                    var u = typeof getBillLineUnitIqd === 'function' ? getBillLineUnitIqd(b) : (parseFloat(b.price) || 0);
                    return a + u * getItemQty(b);
                }, 0);
                let discount = 0;
                if (table.manualDiscount !== undefined && table.manualDiscount !== null) {
                    discount = parseFloat(table.manualDiscount);
                } else {
                    const discountInputEl = document.getElementById('pos-discount');
                    const discountInput = discountInputEl ? discountInputEl.value : '';
                    if (discountInput && !isNaN(discountInput)) {
                        const discountPercent = parseFloat(discountInput);
                        if (discountPercent >= 0 && discountPercent <= 100) {
                            discount = subTotal * (discountPercent / 100);
                        }
                    }
                }
                totalAmount = Math.max(0, subTotal - discount);
            }
            const debtAmount = rm(Math.max(0, totalAmount - paidAmount));
            const tol = 1;
            const isFib = typeof getCartPayMethod === 'function' && getCartPayMethod('pos') === 'fib';

            function finishSaleForCustomer(customerId) {
                if (typeof window.setPosActiveCustomer === 'function' && customerId) {
                    window.setPosActiveCustomer(customerId, customerName || '');
                }
                if (paidAmount >= totalAmount - tol) {
                    processPayment(isFib ? 'fib' : 'cash', customerId, 'customer');
                } else if (paidAmount > 0) {
                    processPayment('split', customerId, 'customer', {
                        cash: isFib ? 0 : paidAmount,
                        bank: isFib ? paidAmount : 0,
                        debt: debtAmount
                    });
                } else {
                    processPayment('debt', customerId, 'customer');
                }
            }

            function findCustomerByNameLoose(name) {
                var needle = String(name || '').trim().toLowerCase();
                if (!needle || !db || !Array.isArray(db.customers)) return null;
                return db.customers.find(function (c) {
                    return c && String(c.name || '').trim().toLowerCase() === needle;
                }) || null;
            }

            var customer = null;
            if (activeCustomerId > 0 && db && Array.isArray(db.customers)) {
                customer = db.customers.find(function (c) {
                    return c && parseInt(c.id, 10) === activeCustomerId;
                }) || null;
            }
            if (!customer && customerName) {
                customer = findCustomerByNameLoose(customerName);
            }
            if (!customer) {
                if (!customerName) {
                    var missMsg = (typeof t === 'function')
                        ? (t('pos_customer_id_missing') || 'کریار هەلبژێرە دووبارە — ناسنامە نەما.')
                        : 'کریار هەلبژێرە دووبارە — ناسنامە نەما.';
                    if (typeof showToast === 'function') showToast('⚠️ ' + missMsg, 'warning');
                    else alert(missMsg);
                    return true;
                }
                if (confirm('کریار ب ناڤێ "' + customerName + '" نەهاتە دیتن. دەتەوێت وەک کریارێکی نوێ زێدە بکەیت؟')) {
                    const formData = new FormData();
                    formData.append('action', 'save_customer');
                    formData.append('name', customerName);
                    formData.append('phone', (typeof window.getPosCustomerPhoneValue === 'function') ? window.getPosCustomerPhoneValue() : '');
                    formData.append('address', '');
                    formData.append('opening_balance', 0);
                    formData.append('debt_limit', 0);
                    fetch('?action=save_customer', { method: 'POST', body: formData })
                        .then(res => res.json())
                        .then(data => {
                            if (data.status === 'success') {
                                var newPhone = (typeof window.getPosCustomerPhoneValue === 'function') ? window.getPosCustomerPhoneValue() : '';
                                db.customers.push({ id: data.id, name: customerName, phone: newPhone, address: '', opening_balance: 0, debt_limit: 0, balance: 0 });
                                populateCustomerDatalist();
                                var newCust = db.customers[db.customers.length - 1];
                                if (typeof window.setPosActiveCustomer === 'function') {
                                    window.setPosActiveCustomer(data.id, customerName);
                                }
                                if (typeof window.ensureFollowupCustomerPhone === 'function') {
                                    window.ensureFollowupCustomerPhone(newCust, function () {
                                        finishSaleForCustomer(data.id);
                                    });
                                } else {
                                    finishSaleForCustomer(data.id);
                                }
                            } else {
                                showToast("❌ نەشیا کریار زێدە بکەت!", "error");
                            }
                        }).catch(err => showToast("❌ هەڵە: " + err, "error"));
                }
                return true;
            }

            if (typeof window.setPosActiveCustomer === 'function') {
                window.setPosActiveCustomer(customer.id, customer.name || customerName);
            }
            if (typeof window.ensureFollowupCustomerPhone === 'function') {
                window.ensureFollowupCustomerPhone(customer, function () {
                    finishSaleForCustomer(customer.id);
                });
            } else {
                finishSaleForCustomer(customer.id);
            }
            return true;
        };

        /** @deprecated Use sellFromPos — same logic (customer + پارێ دای on one button). */
        window.sellOnCredit = function() {
            if (typeof window.sellFromPos === 'function') window.sellFromPos();
        };

