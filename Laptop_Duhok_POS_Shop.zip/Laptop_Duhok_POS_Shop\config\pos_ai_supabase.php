<?php
/**
 * Shop AI quota — Supabase-backed limits for Pro (vendor pays Gemini).
 * Free tier: local limits only; vendor API key blocked in pos_ai.php.
 */
if (!function_exists('pos_ai_supabase_serial')) {
    function pos_ai_supabase_serial(mysqli $conn): string {
        if (!function_exists('pos_ensure_license_serial')) {
            return '';
        }
        return trim((string)pos_ensure_license_serial($conn));
    }
}

if (!function_exists('pos_ai_supabase_rpc')) {
    /** @return array<string,mixed> */
    function pos_ai_supabase_rpc(string $fn, array $payload): array {
        if (!defined('POS_SUPABASE_URL') || !defined('POS_SUPABASE_ANON_KEY')) {
            return ['ok' => false, 'reason' => 'config'];
        }
        $key = trim((string)POS_SUPABASE_ANON_KEY);
        if ($key === '') {
            return ['ok' => false, 'reason' => 'config'];
        }
        if (!function_exists('pos_supabase_http_post_json')) {
            return ['ok' => false, 'reason' => 'config'];
        }
        $url = rtrim(POS_SUPABASE_URL, '/') . '/rest/v1/rpc/' . rawurlencode($fn);
        $body = json_encode($payload, JSON_UNESCAPED_UNICODE);
        $headers = [
            'Content-Type: application/json',
            'apikey: ' . $key,
            'Authorization: Bearer ' . $key,
        ];
        list($code, $raw, $cerr, $insecure) = pos_supabase_http_post_json($url, $body, $headers);
        if ($code !== 200) {
            return ['ok' => false, 'reason' => 'http', 'http_code' => $code, 'detail' => substr((string)$raw, 0, 300)];
        }
        $j = json_decode((string)$raw, true);
        if (is_string($j)) {
            $j = json_decode($j, true);
        }
        return is_array($j) ? $j : ['ok' => false, 'reason' => 'parse'];
    }
}

if (!function_exists('pos_ai_supabase_quota_raw')) {
    /** @return array<string,mixed>|null */
    function pos_ai_supabase_quota_raw(mysqli $conn, bool $force = false): ?array {
        static $cache = [];
        $serial = pos_ai_supabase_serial($conn);
        if ($serial === '') {
            return null;
        }
        $ck = $serial . ($force ? ':f' : '');
        if (!$force && isset($cache[$ck])) {
            return $cache[$ck];
        }
        $settings = function_exists('pos_ai_load_settings_row') ? pos_ai_load_settings_row($conn) : [];
        $cachedJson = $settings['ai_supabase_quota_cache'] ?? null;
        $cachedAt = (int)($settings['ai_supabase_quota_cache_at'] ?? 0);
        $cfgDays = defined('POS_AI_PERIOD_DAYS') ? (int) POS_AI_PERIOD_DAYS : 30;
        $cachedDays = is_array($cachedJson) ? (int)($cachedJson['period_days'] ?? 0) : 0;
        if ($cachedDays > 0 && $cachedDays !== $cfgDays) {
            $force = true;
        }
        if (!$force && is_array($cachedJson) && (time() - $cachedAt) < 45) {
            $cache[$ck] = $cachedJson;
            return $cachedJson;
        }
        $res = pos_ai_supabase_rpc('pos_ai_get_quota', ['p_serial' => $serial]);
        if (empty($res['ok'])) {
            return null;
        }
        if (function_exists('pos_ai_apply_period_config')) {
            $res = pos_ai_apply_period_config($res);
        }
        if (function_exists('pos_ai_save_supabase_quota_cache')) {
            pos_ai_save_supabase_quota_cache($conn, $res);
        }
        $cache[$ck] = $res;
        return $res;
    }
}

if (!function_exists('pos_ai_save_supabase_quota_cache')) {
    function pos_ai_save_supabase_quota_cache(mysqli $conn, array $quota): void {
        if (!function_exists('pos_ai_load_settings_row')) {
            return;
        }
        $settings = pos_ai_load_settings_row($conn);
        $settings['ai_supabase_quota_cache'] = $quota;
        $settings['ai_supabase_quota_cache_at'] = time();
        $json = json_encode($settings, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
        if ($json === false) {
            return;
        }
        $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('app_settings', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        if ($stmt) {
            $stmt->bind_param('ss', $json, $json);
            $stmt->execute();
            $stmt->close();
        }
    }
}

if (!function_exists('pos_ai_supabase_vendor_gemini_allowed')) {
    function pos_ai_supabase_vendor_gemini_allowed(mysqli $conn): bool {
        $tier = function_exists('pos_ai_tier_from_conn') ? pos_ai_tier_from_conn($conn) : 'free';
        if ($tier !== 'pro' && $tier !== 'pro_plus') {
            return false;
        }
        $q = pos_ai_supabase_quota_raw($conn);
        if (is_array($q) && array_key_exists('vendor_gemini', $q)) {
            return !empty($q['vendor_gemini']);
        }
        return true;
    }
}

if (!function_exists('pos_ai_supabase_quota_snapshot')) {
    /** @return array<string,mixed>|null */
    function pos_ai_supabase_quota_snapshot(mysqli $conn): ?array {
        $q = pos_ai_supabase_quota_raw($conn);
        if (!is_array($q) || empty($q['ok'])) {
            return null;
        }
        $tier = (string)($q['tier'] ?? 'free');
        $limit = (int)($q['limit'] ?? 0);
        $used = (int)($q['used'] ?? 0);
        $remaining = (int)($q['remaining'] ?? max(0, $limit - $used));
        $baseLimit = (int)($q['base_limit'] ?? 0);
        $bonusLimit = (int)($q['bonus_limit'] ?? 0);
        if ($baseLimit <= 0) {
            $baseLimit = max(0, $limit - $bonusLimit);
        }
        $pct = $limit > 0 ? min(100.0, round(($used / $limit) * 100, 1)) : 100.0;
        $periodDays = max(1, (int) POS_AI_PERIOD_DAYS);
        $periodStart = (string)($q['period_start'] ?? '');
        $resetsOn = (string)($q['resets_on'] ?? '');
        if ((int)($q['period_days'] ?? 0) !== $periodDays && function_exists('pos_ai_current_period_start')) {
            $periodStart = pos_ai_current_period_start();
            $resetsOn = function_exists('pos_ai_next_period_start') ? pos_ai_next_period_start($periodStart) : $resetsOn;
        }
        return [
            'tier' => $tier,
            'base_limit' => $baseLimit,
            'bonus_limit' => $bonusLimit,
            'limit' => $limit,
            'used' => $used,
            'remaining' => $remaining,
            'exhausted' => !empty($q['exhausted']) || $remaining <= 0,
            'pct' => $pct,
            'resets_on' => $resetsOn !== '' ? $resetsOn : (string)($q['resets_on'] ?? ''),
            'period_start' => $periodStart !== '' ? $periodStart : (string)($q['period_start'] ?? ''),
            'period_days' => $periodDays,
            'period_label' => (string)($q['period_label'] ?? ($periodDays >= 28 ? 'month' : 'period')),
            'min_cost' => (int)($q['min_cost'] ?? pos_ai_min_turn_cost()),
            'max_cost' => (int)($q['max_cost'] ?? pos_ai_max_turn_cost()),
            'source' => 'supabase',
            'vendor_gemini' => !empty($q['vendor_gemini']),
            'packs' => is_array($q['packs'] ?? null) ? $q['packs'] : [],
        ];
    }
}

if (!function_exists('pos_ai_supabase_redeem_limit_code')) {
    /** @return array<string,mixed> */
    function pos_ai_supabase_redeem_limit_code(mysqli $conn, string $code): array {
        $serial = pos_ai_supabase_serial($conn);
        if ($serial === '') {
            return ['ok' => false, 'reason' => 'no_serial'];
        }
        $res = pos_ai_supabase_rpc('redeem_ai_limit_code', [
            'p_serial' => $serial,
            'p_code' => trim($code),
        ]);
        if (!empty($res['redeemed']) && function_exists('pos_ai_save_supabase_quota_cache')) {
            if (function_exists('pos_ai_apply_period_config') && !empty($res['ok'])) {
                $res = pos_ai_apply_period_config($res);
            }
            pos_ai_save_supabase_quota_cache($conn, $res);
        }
        return $res;
    }
}

if (!function_exists('pos_ai_supabase_consume')) {
    /** @return array{ok:bool,snapshot:?array,cost:int,requested_cost:int} */
    function pos_ai_supabase_consume(mysqli $conn, int $cost): array {
        $requested = max(pos_ai_min_turn_cost(), min(pos_ai_max_turn_cost(), $cost));
        $serial = pos_ai_supabase_serial($conn);
        if ($serial === '') {
            return ['ok' => false, 'snapshot' => null, 'cost' => 0, 'requested_cost' => $requested];
        }
        $res = pos_ai_supabase_rpc('pos_ai_consume_points', [
            'p_serial' => $serial,
            'p_cost' => $requested,
        ]);
        if (empty($res['ok']) || empty($res['consumed'])) {
            $snap = pos_ai_supabase_quota_snapshot($conn);
            if ($snap === null && function_exists('pos_ai_usage_snapshot')) {
                $local = pos_ai_usage_snapshot($conn);
                if (($local['source'] ?? '') === 'local') {
                    $snap = $local;
                }
            }
            return ['ok' => false, 'snapshot' => $snap, 'cost' => 0, 'requested_cost' => $requested];
        }
        if (function_exists('pos_ai_save_supabase_quota_cache')) {
            if (function_exists('pos_ai_apply_period_config') && !empty($res['ok'])) {
                $res = pos_ai_apply_period_config($res);
            }
            pos_ai_save_supabase_quota_cache($conn, $res);
        }
        $snap = function_exists('pos_ai_supabase_quota_snapshot')
            ? pos_ai_supabase_quota_snapshot($conn)
            : null;
        if ($snap === null && is_array($res)) {
            $snap = [
                'tier' => (string)($res['tier'] ?? 'pro'),
                'limit' => (int)($res['limit'] ?? 0),
                'used' => (int)($res['used'] ?? 0),
                'remaining' => (int)($res['remaining'] ?? 0),
                'exhausted' => !empty($res['exhausted']),
                'pct' => 0,
                'resets_on' => (string)($res['resets_on'] ?? ''),
                'period_days' => (int)($res['period_days'] ?? POS_AI_PERIOD_DAYS),
                'min_cost' => pos_ai_min_turn_cost(),
                'max_cost' => pos_ai_max_turn_cost(),
                'source' => 'supabase',
            ];
        }
        return [
            'ok' => true,
            'snapshot' => $snap,
            'cost' => (int)($res['cost'] ?? $requested),
            'requested_cost' => $requested,
        ];
    }
}
