using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;

internal static class PosLauncher
{
    private const string Title = "Laptop Duhok POS";
    private const string PosUrl = "http://127.0.0.1/pos/";

    [STAThread]
    private static int Main()
    {
        try
        {
            EnsureDesktopShortcut();
            string posDir = FindPosRoot(AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\', '/'));
            string xampp = FindXamppRoot(posDir);
            if (string.IsNullOrEmpty(xampp))
            {
                Fail("XAMPP نەهاتە دیتن.\nفولدر: C:\\xampp");
                return 1;
            }

            if (!PortOpen(80))
                StartHidden(Path.Combine(xampp, "apache\\bin\\httpd.exe"), "", xampp);

            if (!PortOpen(3306))
            {
                string ini = Path.Combine(xampp, "mysql\\bin\\my.ini");
                string mysqld = Path.Combine(xampp, "mysql\\bin\\mysqld.exe");
                string args = File.Exists(ini)
                    ? "--defaults-file=\"" + ini + "\" --standalone"
                    : "--standalone";
                StartHidden(mysqld, args, xampp);
            }

            string agent = Path.Combine(posDir, "api\\tools\\pos_label_print_agent.ps1");
            if (File.Exists(agent))
            {
                string ps = Path.Combine(Environment.SystemDirectory, "WindowsPowerShell\\v1.0\\powershell.exe");
                StartHidden(
                    ps,
                    "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File \"" + agent + "\"",
                    posDir);
            }

            if (!WaitForPos())
            {
                Fail("بەرنامە نەڤەبوو.\nApache / MySQL ل XAMPP ڤەکە، پاشان دوبارە ئایکۆنێ بکە.");
                return 1;
            }

            string browser = FindBrowser();
            if (string.IsNullOrEmpty(browser))
            {
                Process.Start(PosUrl);
                return 0;
            }

            string profile = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "LaptopDuhokPOS",
                "browser-profile");
            Directory.CreateDirectory(profile);

            ProcessStartInfo psi = new ProcessStartInfo();
            psi.FileName = browser;
            psi.Arguments = "--app=" + PosUrl + " --user-data-dir=\"" + profile + "\"";
            psi.UseShellExecute = false;
            Process.Start(psi);
            return 0;
        }
        catch (Exception ex)
        {
            Fail(ex.Message);
            return 1;
        }
    }

    private static void EnsureDesktopShortcut()
    {
        try
        {
            string exe = Process.GetCurrentProcess().MainModule.FileName;
            if (string.IsNullOrEmpty(exe) || !File.Exists(exe))
                return;
            string desk = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            if (string.IsNullOrEmpty(desk) || !Directory.Exists(desk))
                return;
            string lnk = Path.Combine(desk, "Laptop Duhok POS.lnk");
            Type t = Type.GetTypeFromProgID("WScript.Shell");
            if (t == null)
                return;
            object shell = Activator.CreateInstance(t);
            object sc = t.InvokeMember("CreateShortcut", BindingFlags.InvokeMethod, null, shell, new object[] { lnk });
            Type st = sc.GetType();
            string work = Path.GetDirectoryName(exe);
            string ico = Path.Combine(work, "LaptopDuhokPOS.ico");
            string iconLoc = File.Exists(ico) ? (ico + ",0") : (exe + ",0");
            st.InvokeMember("TargetPath", BindingFlags.SetProperty, null, sc, new object[] { exe });
            st.InvokeMember("WorkingDirectory", BindingFlags.SetProperty, null, sc, new object[] { work });
            st.InvokeMember("WindowStyle", BindingFlags.SetProperty, null, sc, new object[] { 1 });
            st.InvokeMember("Description", BindingFlags.SetProperty, null, sc, new object[] { Title });
            st.InvokeMember("IconLocation", BindingFlags.SetProperty, null, sc, new object[] { iconLoc });
            st.InvokeMember("Save", BindingFlags.InvokeMethod, null, sc, null);
        }
        catch
        {
        }
    }

    private static string FindPosRoot(string start)
    {
        string dir = start;
        for (int i = 0; i < 8; i++)
        {
            if (File.Exists(Path.Combine(dir, "index.php")) && Directory.Exists(Path.Combine(dir, "api")))
                return dir;
            string parent = Path.GetDirectoryName(dir);
            if (string.IsNullOrEmpty(parent) || parent == dir)
                break;
            dir = parent;
        }
        return start;
    }

    private static string FindXamppRoot(string posDir)
    {
        string[] candidates = new string[]
        {
            Path.GetFullPath(Path.Combine(posDir, "..", "..")),
            Path.GetFullPath(Path.Combine(posDir, "..", "..", "..")),
            @"C:\xampp",
            @"D:\xampp",
            @"E:\xampp"
        };
        for (int i = 0; i < candidates.Length; i++)
        {
            string httpd = Path.Combine(candidates[i], "apache\\bin\\httpd.exe");
            if (File.Exists(httpd))
                return candidates[i];
        }
        return null;
    }

    private static string FindBrowser()
    {
        string pf = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
        string pfx86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
        string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        string[] paths = new string[]
        {
            Path.Combine(pf, "Google\\Chrome\\Application\\chrome.exe"),
            Path.Combine(pfx86, "Google\\Chrome\\Application\\chrome.exe"),
            Path.Combine(local, "Google\\Chrome\\Application\\chrome.exe"),
            Path.Combine(pfx86, "Microsoft\\Edge\\Application\\msedge.exe"),
            Path.Combine(pf, "Microsoft\\Edge\\Application\\msedge.exe")
        };
        for (int i = 0; i < paths.Length; i++)
        {
            if (File.Exists(paths[i]))
                return paths[i];
        }
        return null;
    }

    private static void StartHidden(string fileName, string args, string workDir)
    {
        if (string.IsNullOrEmpty(fileName) || !File.Exists(fileName))
            return;
        ProcessStartInfo psi = new ProcessStartInfo();
        psi.FileName = fileName;
        psi.Arguments = args;
        if (!string.IsNullOrEmpty(workDir) && Directory.Exists(workDir))
            psi.WorkingDirectory = workDir;
        psi.UseShellExecute = false;
        psi.CreateNoWindow = true;
        psi.WindowStyle = ProcessWindowStyle.Hidden;
        Process.Start(psi);
    }

    private static bool PortOpen(int port)
    {
        try
        {
            using (TcpClient c = new TcpClient())
            {
                IAsyncResult ar = c.BeginConnect("127.0.0.1", port, null, null);
                bool ok = ar.AsyncWaitHandle.WaitOne(400, false);
                return ok && c.Connected;
            }
        }
        catch
        {
            return false;
        }
    }

    private static bool WaitForPos()
    {
        for (int i = 0; i < 40; i++)
        {
            try
            {
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(PosUrl);
                req.Timeout = 900;
                req.Method = "GET";
                req.AllowAutoRedirect = true;
                using (WebResponse resp = req.GetResponse())
                    return true;
            }
            catch
            {
                Thread.Sleep(500);
            }
        }
        return PortOpen(80);
    }

    private static void Fail(string msg)
    {
        MessageBox.Show(msg, Title, MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading | MessageBoxOptions.RightAlign);
    }
}
