// purchase/company-docs.js — company docs, debt
        // --- COMPANY DOCS ---
        function loadCompanyDocs() {
            const cid = currentViewingCompanyId;
            if(!cid) return;
            const grid = document.getElementById('company-docs-grid');
            grid.innerHTML = '<p style="text-align:center; width:100%;">Loading...</p>';
            
            const formData = new FormData();
            formData.append('action', 'get_company_docs');
            formData.append('company_id', cid);
            
            fetch('?action=get_company_docs', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                if(data.status === 'success') {
                    if(data.docs.length === 0) {
                        grid.innerHTML = '<p style="text-align:center; width:100%; color:var(--text-muted);">چ وێنە نینن.</p>';
                    } else {
                        grid.innerHTML = data.docs.map(d => `
                            <div class="doc-card">
                                <img src="${d.image_data}" class="doc-img" onclick="window.open(this.src)">
                                <button class="doc-del" onclick="deleteCompanyDoc(${d.id})"><i class="fas fa-trash"></i></button>
                                <div class="doc-info">
                                    <b>${new Date(d.created_at).toLocaleDateString()}</b><br>
                                    ${escapeHtml(d.note || '')}
                                </div>
                            </div>
                        `).join('');
                    }
                }
            });
        }

        function uploadCompanyDoc() {
            const input = document.getElementById('doc-upload-input');
            const note = document.getElementById('doc-upload-note').value;
            if(input.files.length === 0) return alert("هیڤییە وێنەیەکێ هەلبژێرە!");
            
            const file = input.files[0];
            const reader = new FileReader();
            reader.onload = function(e) {
                // RESIZE IMAGE TO AVOID POST LIMITS
                const img = new Image();
                img.src = e.target.result;
                img.onload = function() {
                    const canvas = document.createElement('canvas');
                    const ctx = canvas.getContext('2d');
                    
                    // Max dimensions
                    const MAX_WIDTH = 1024;
                    const MAX_HEIGHT = 1024;
                    let width = img.width;
                    let height = img.height;

                    if (width > height) {
                        if (width > MAX_WIDTH) { height *= MAX_WIDTH / width; width = MAX_WIDTH; }
                    } else {
                        if (height > MAX_HEIGHT) { width *= MAX_HEIGHT / height; height = MAX_HEIGHT; }
                    }

                    canvas.width = width;
                    canvas.height = height;
                    ctx.drawImage(img, 0, 0, width, height);
                    
                    const base64 = canvas.toDataURL('image/jpeg', 0.7); // Compress to 70% quality

                    const formData = new FormData();
                    formData.append('action', 'save_company_doc');
                    formData.append('company_id', currentViewingCompanyId);
                    formData.append('image', base64);
                    formData.append('note', note);
                    
                    const btn = document.querySelector('#tab-docs .btn-brand');
                    const originalText = btn.innerHTML;
                    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Uploading...';
                    btn.disabled = true;

                    fetch('?action=save_company_doc', { method: 'POST', body: formData })
                    .then(res => res.json())
                    .then(data => {
                        btn.innerHTML = originalText;
                        btn.disabled = false;
                        if(data.status === 'success') {
                        alert("✅ وێنە هاتە بارکرن!");
                            input.value = '';
                            document.getElementById('doc-upload-note').value = '';
                            loadCompanyDocs();
                        } else {
                            alert("Error: " + data.message);
                        }
                    });
                };
            };
            reader.readAsDataURL(file);
        }

        function deleteCompanyDoc(id) {
            if(confirm("دڵنیای ژ ژێبرنا ڤێ وێنەی؟")) {
                const formData = new FormData();
                formData.append('action', 'delete_company_doc');
                formData.append('id', id);
                fetch('?action=delete_company_doc', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if(data.status === 'success') loadCompanyDocs();
                });
            }
        }

        function getCompanyDebtExpenseLabel(e) {
            if (!e) return '';
            if (e.company_id && db && db.companies) {
                var c = db.companies.find(function(x) { return Number(x.id) === Number(e.company_id); });
                if (c && c.name) return String(c.name);
            }
            var note = String(e.note || '');
            var m = note.match(/دانەڤا قەرزی کۆمپانیا:\s*([^|]+)/);
            if (m && m[1]) return m[1].trim();
            m = note.match(/Company Payment[^:]*:\s*([^|]+)/i);
            if (m && m[1]) return m[1].trim();
            return (typeof translateExpenseNoteForUi === 'function') ? translateExpenseNoteForUi(note) : note;
        }
        if (typeof window !== 'undefined') window.getCompanyDebtExpenseLabel = getCompanyDebtExpenseLabel;

        function closePayCompanyDebtModal() {
            var m = document.getElementById('pay-company-debt-modal');
            if (m) m.style.display = 'none';
            window._pcdPayTransactionId = '';
            window._pcdPayInvoiceRemaining = 0;
        }
        if (typeof window !== 'undefined') window.closePayCompanyDebtModal = closePayCompanyDebtModal;

        function updatePayCompanyDebtSelectedUi(comp) {
            var box = document.getElementById('pcd-selected-box');
            var nameEl = document.getElementById('pcd-selected-name');
            var balEl = document.getElementById('pcd-selected-balance');
            var idEl = document.getElementById('pcd-selected-id');
            var amtEl = document.getElementById('pcd-amount');
            if (!box || !nameEl || !balEl || !idEl) return;
            if (!comp) {
                box.style.display = 'none';
                idEl.value = '';
                if (amtEl) amtEl.value = '';
                return;
            }
            idEl.value = String(comp.id);
            nameEl.textContent = comp.name || ('#' + comp.id);
            var bal = parseFloat(comp.balance) || 0;
            var compBalFx = (typeof fxUsdRateFormatOptsForEntityBalance === 'function')
                ? fxUsdRateFormatOptsForEntityBalance(comp.id, 'company', comp.balance)
                : undefined;
            balEl.textContent = formatCurrency(Math.abs(bal), compBalFx) + ' ' + getCurrencySymbol();
            box.style.display = 'block';
            if (amtEl && bal > 0) {
                var isUsd = (typeof getActiveCurrency === 'function') ? (getActiveCurrency() === 'USD') : false;
                var def = isUsd
                    ? ((typeof storedIqdToUsdDisplayAmount === 'function') ? storedIqdToUsdDisplayAmount(bal, compBalFx) : ((typeof getUsdRatePerOne === 'function' && getUsdRatePerOne() > 0) ? (bal / getUsdRatePerOne()) : bal))
                    : bal;
                amtEl.value = String(Math.round(def * 100) / 100);
            }
        }

        function selectPayCompanyDebtCompany(id, el) {
            if (!db || !db.companies) return;
            var comp = db.companies.find(function(c) { return Number(c.id) === Number(id); });
            if (!comp) return;
            document.querySelectorAll('#pcd-company-list .pay-debt-item').forEach(function(node) { node.classList.remove('selected'); });
            if (el) el.classList.add('selected');
            updatePayCompanyDebtSelectedUi(comp);
        }
        if (typeof window !== 'undefined') window.selectPayCompanyDebtCompany = selectPayCompanyDebtCompany;

        function renderPayCompanyDebtPicker(q) {
            var listEl = document.getElementById('pcd-company-list');
            if (!listEl || !db || !db.companies) return;
            var lowerQ = String(q || '').toLowerCase().trim();
            var withDebt = db.companies.filter(function(c) {
                if (!c || !c.name) return false;
                if ((parseFloat(c.balance) || 0) <= 0) return false;
                return !lowerQ || String(c.name).toLowerCase().indexOf(lowerQ) !== -1;
            }).sort(function(a, b) { return (parseFloat(b.balance) || 0) - (parseFloat(a.balance) || 0); });
            var emptyLbl = (typeof t === 'function') ? t('pcd_no_debt_companies') : 'چ کۆمپانیایەک قەرزی لەسەر نییە.';
            if (!withDebt.length) {
                listEl.innerHTML = '<div style="padding:12px;text-align:center;color:var(--text-muted);font-size:0.9rem;">' + escapeHtml(emptyLbl) + '</div>';
                updatePayCompanyDebtSelectedUi(null);
                return;
            }
            var debtLbl = (typeof t === 'function') ? t('pcd_debt_remaining') : 'قەرزی مای';
            listEl.innerHTML = withDebt.map(function(c) {
                var cFx = (typeof fxUsdRateFormatOptsForEntityBalance === 'function')
                    ? fxUsdRateFormatOptsForEntityBalance(c.id, 'company', c.balance)
                    : undefined;
                return '<div class="pay-debt-item" role="button" tabindex="0" data-company-id="' + c.id + '" onclick="selectPayCompanyDebtCompany(' + c.id + ', this)">' +
                    '<span class="pay-debt-item__name"><i class="fas fa-building pos-ic" aria-hidden="true"></i> ' + escapeHtml(c.name) + '</span>' +
                    '<span class="pay-debt-item__meta">' + escapeHtml(debtLbl) + ': ' + formatCurrency(c.balance, cFx) + '</span></div>';
            }).join('');
            var preId = document.getElementById('pcd-selected-id');
            if (preId && preId.value) {
                var match = listEl.querySelector('.pay-debt-item[data-company-id="' + preId.value + '"]');
                if (match) match.classList.add('selected');
            }
        }
        if (typeof window !== 'undefined') window.renderPayCompanyDebtPicker = renderPayCompanyDebtPicker;

        function openPayCompanyDebtModal(preselectCompanyId) {
            var m = document.getElementById('pay-company-debt-modal');
            if (!m) return;
            m.style.display = 'flex';
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(m);
            document.getElementById('pcd-selected-id').value = preselectCompanyId ? String(preselectCompanyId) : '';
            var searchEl = document.getElementById('pcd-search');
            if (searchEl) searchEl.value = '';
            renderPayCompanyDebtPicker('');
            if (typeof setCompanyDebtPayMethod === 'function') setCompanyDebtPayMethod('cash');
            if (preselectCompanyId) {
                var comp = db.companies.find(function(c) { return Number(c.id) === Number(preselectCompanyId); });
                if (comp) {
                    updatePayCompanyDebtSelectedUi(comp);
                    var match = document.querySelector('#pcd-company-list .pay-debt-item[data-company-id="' + preselectCompanyId + '"]');
                    if (match) match.classList.add('selected');
                }
            } else {
                updatePayCompanyDebtSelectedUi(null);
            }
            setTimeout(function() {
                var focusEl = preselectCompanyId ? document.getElementById('pcd-amount') : document.getElementById('pcd-search');
                if (focusEl) focusEl.focus();
            }, 80);
        }
        if (typeof window !== 'undefined') window.openPayCompanyDebtModal = openPayCompanyDebtModal;

        var _companyDebtPayMethod = 'cash';
        function setCompanyDebtPayMethod(method) {
            var m = String(method || '').toLowerCase() === 'fib' ? 'fib' : 'cash';
            _companyDebtPayMethod = m;
            var hid = document.getElementById('pcd-pay-method');
            if (hid) hid.value = m;
            document.querySelectorAll('.debt-pay-method-toggle[data-debt-pay="company"] .cart-pay-method-btn').forEach(function (btn) {
                var on = String(btn.getAttribute('data-pay') || '') === m;
                btn.classList.toggle('is-active', on);
                btn.setAttribute('aria-pressed', on ? 'true' : 'false');
            });
        }
        function getCompanyDebtPayMethod() {
            var hid = document.getElementById('pcd-pay-method');
            if (hid && (hid.value === 'fib' || hid.value === 'cash')) return hid.value;
            return _companyDebtPayMethod === 'fib' ? 'fib' : 'cash';
        }
        if (typeof window !== 'undefined') {
            window.setCompanyDebtPayMethod = setCompanyDebtPayMethod;
            window.getCompanyDebtPayMethod = getCompanyDebtPayMethod;
        }

        function submitCompanyDebtPayment(comp, val, actionType, payTransactionId) {
            if (!comp || val <= 0) return;
            var isPaying = actionType === 'payment';
            var beforeBalance = parseFloat(comp.balance) || 0;
            var invoiceTxn = payTransactionId ? String(payTransactionId) : '';
            comp.balance = (typeof roundMoney === 'function' ? roundMoney : function(x){ return Math.round(Number(x)); })((parseFloat(comp.balance)||0) + (isPaying ? -parseFloat(val) : parseFloat(val)));
            var afterBalance = parseFloat(comp.balance) || 0;
            var note = (isPaying ? 'دانەڤا قەرزی' : 'استلام دين') + ' | amount=' + formatCurrency(val) + ' | before=' + formatCurrency(beforeBalance) + ' | after=' + formatCurrency(afterBalance) + ' | by=' + (currentUser ? currentUser.name : 'System');
            if (invoiceTxn) note += ' | invoice_tx=' + invoiceTxn;
            var formData = new FormData();
            formData.append('action', 'save_ledger');
            formData.append('companyId', comp.id);
            formData.append('type', actionType);
            formData.append('amount', val);
            formData.append('note', note);
            formData.append('user', currentUser ? currentUser.name : 'System');
            if (invoiceTxn) formData.append('pay_transaction_id', invoiceTxn);
            var payChannel = (typeof getCompanyDebtPayMethod === 'function') ? getCompanyDebtPayMethod() : 'cash';
            formData.append('payment_method', payChannel);
            fetch('?action=save_ledger', { method: 'POST', body: formData })
            .then(function(res) { return res.json(); })
            .then(function(data) {
                if (data.status === 'error') { showToast('❌ ' + (data.message || 'هەڵە د پاراستنێ دا.'), 'error'); return; }
                if (data.status !== 'success') return;
                var paidAmt = parseFloat(data.amount != null ? data.amount : val) || 0;
                // Reconcile local balance if server capped amount
                if (isPaying && Math.abs(paidAmt - val) > 0.01) {
                    comp.balance = (typeof roundMoney === 'function' ? roundMoney : function(x){ return Math.round(Number(x)); })(beforeBalance - paidAmt);
                    afterBalance = parseFloat(comp.balance) || 0;
                }
                if (isPaying && typeof window.applyLocalCompanyInvoicePayment === 'function') {
                    window.applyLocalCompanyInvoicePayment(invoiceTxn || '', paidAmt, comp.name || '');
                }
                if (!db.ledger) db.ledger = [];
                var txId = data.transaction_id || ('TXL_LOCAL_' + Date.now());
                db.ledger.push({ id: data.id, companyId: comp.id, type: actionType, amount: paidAmt, date: new Date(), note: note, transaction_id: txId, related_id: data.expense_id || 0 });
                if (isPaying) {
                    var user = currentUser ? currentUser.name : 'System';
                    var paidCoChannel = String(data.payment_method || payChannel || 'cash').toLowerCase() === 'fib' ? 'fib' : 'cash';
                    var expNote = 'دانەڤا قەرزی کۆمپانیا: ' + (comp.name || ('#' + comp.id));
                    if (invoiceTxn) expNote += ' | فاتورە #' + invoiceTxn;
                    expNote += ' | کانال: ' + (paidCoChannel === 'fib' ? 'FIB' : 'نقد');
                    db.expenses.push({
                        id: data.expense_id || Date.now(),
                        note: expNote,
                        amount: paidAmt,
                        date: new Date(),
                        user: user,
                        type: paidCoChannel === 'fib' ? 'debt_payment_fib' : 'debt_payment',
                        transaction_id: txId,
                        company_id: comp.id
                    });
                }
                if (typeof posInvalidateDailyDetailCache === 'function' && typeof getBusinessDate === 'function') {
                    posInvalidateDailyDetailCache(getBusinessDate(new Date()));
                } else if (window._dailyDetailCache && typeof getBusinessDate === 'function') {
                    try { delete window._dailyDetailCache[getBusinessDate(new Date())]; } catch (_eDdc) {}
                }
                if (typeof connectToDB === 'function') connectToDB(true);
                if (db.today_stats && isPaying) {
                    var paidCoCh = String(data.payment_method || payChannel || 'cash').toLowerCase();
                    if (paidCoCh !== 'fib') {
                        db.today_stats.expenses = (typeof roundMoney === 'function' ? roundMoney : function(x){ return Math.round(Number(x)); })((parseFloat(db.today_stats.expenses) || 0) + paidAmt);
                    }
                }
                var cpBal = document.getElementById('cp-balance');
                if (typeof fillElWithCurrencyAndDuhokPaper === 'function') fillElWithCurrencyAndDuhokPaper(cpBal, comp.balance);
                else if (cpBal) cpBal.innerText = formatCurrency(comp.balance) + ' ' + getCurrencySymbol();
                if (typeof renderLedgerHistory === 'function') renderLedgerHistory(comp.id);
                if (isPaying && typeof renderExpenses === 'function') renderExpenses();
                if (typeof printCompanyDebtReceipt === 'function') {
                    printCompanyDebtReceipt(comp, { type: actionType, amount: paidAmt, before: beforeBalance, after: afterBalance, transaction_id: txId, note: note });
                }
                closePayCompanyDebtModal();
                if (currentViewingCompanyId === comp.id && typeof openCompanyProfile === 'function') openCompanyProfile(comp.id);
                if (typeof showToast === 'function') {
                    var toastCh = String(data.payment_method || payChannel || 'cash').toLowerCase();
                    if (!isPaying) showToast('✅ پارە وەرگیرا');
                    else if (toastCh === 'fib') showToast((typeof t === 'function' && t('pcd_paid_fib_toast') !== 'pcd_paid_fib_toast') ? t('pcd_paid_fib_toast') : '✅ قەرز هاتە دان — چووە هەژمارا FIB');
                    else showToast((typeof t === 'function' && t('pcd_paid_cash_toast') !== 'pcd_paid_cash_toast') ? t('pcd_paid_cash_toast') : '✅ قەرز هاتە دان — چووە قاسێ (نقد)');
                }
                if (typeof posRefreshOpenFinancialScreens === 'function') {
                    posRefreshOpenFinancialScreens();
                } else if (typeof openDailyHistoryModal === 'function' && document.getElementById('daily-history-modal') && document.getElementById('daily-history-modal').style.display === 'flex') {
                    openDailyHistoryModal(typeof getBusinessDate === 'function' ? getBusinessDate(new Date()) : null, { refresh: true });
                }
            })
            .catch(function(err) { showToast('❌ ' + (err.message || 'پەیوەندی'), 'error'); });
        }

        function confirmPayCompanyDebt() {
            var idRaw = document.getElementById('pcd-selected-id');
            var cid = idRaw && idRaw.value ? parseInt(idRaw.value, 10) : 0;
            if (!cid) {
                if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('pcd_pick_required') : 'تکایە سەرەتا کۆمپانیا هەڵبژێرە.', 'error');
                else if (typeof window.posAlert === 'function') window.posAlert({ message: (typeof t === 'function') ? t('pcd_pick_required') : 'تکایە سەرەتا کۆمپانیا هەڵبژێرە.', tone: 'danger' });
                else alert((typeof t === 'function') ? t('pcd_pick_required') : 'تکایە سەرەتا کۆمپانیا هەڵبژێرە.');
                return;
            }
            var comp = db.companies.find(function(c) { return Number(c.id) === cid; });
            if (!comp) return;
            var currentBal = parseFloat(comp.balance) || 0;
            if (currentBal <= 0) {
                if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('pcd_no_debt_on_company') : 'ئەڤ کۆمپانیە چ قەرز ل سەر نینن.', 'error');
                else if (typeof window.posAlert === 'function') window.posAlert({ message: (typeof t === 'function') ? t('pcd_no_debt_on_company') : 'ئەڤ کۆمپانیە چ قەرز ل سەر نینن.', tone: 'warning' });
                else alert((typeof t === 'function') ? t('pcd_no_debt_on_company') : 'ئەڤ کۆمپانیە چ قەرز ل سەر نینن.');
                return;
            }
            var rawAmt = (document.getElementById('pcd-amount') && document.getElementById('pcd-amount').value) || '';
            var valDisplay = (typeof parseAmountInput === 'function') ? parseAmountInput(String(rawAmt)) : parseFloat(String(rawAmt).replace(/,/g, ''));
            var isUsdDebtMode = (typeof getActiveCurrency === 'function') ? (getActiveCurrency() === 'USD') : false;
            var debtRate = 0;
            if (window._pcdPayTransactionId && typeof lookupFrozenFxBundleForTxn === 'function') {
                var bPay = lookupFrozenFxBundleForTxn(window._pcdPayTransactionId);
                if (bPay >= 1000) debtRate = bPay / 100;
            }
            if (!(debtRate > 0) && typeof fxUsdRateFormatOptsForEntityBalance === 'function') {
                var blendPay = fxUsdRateFormatOptsForEntityBalance(comp.id, 'company', currentBal);
                if (blendPay && blendPay.fxUsdRate) debtRate = blendPay.fxUsdRate / 100;
            }
            if (!(debtRate > 0) && typeof getUsdRatePerOne === 'function') debtRate = getUsdRatePerOne();
            var val = (isUsdDebtMode && debtRate > 0)
                ? ((typeof roundMoney === 'function' ? roundMoney : function(x){ return Number(x) || 0; })(valDisplay * debtRate))
                : valDisplay;
            if (val <= 0 || isNaN(val)) {
                if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('pcd_amount_required') : 'بڕی پارەدانێ بنووسە.', 'error');
                else if (typeof window.posAlert === 'function') window.posAlert({ message: (typeof t === 'function') ? t('pcd_amount_required') : 'بڕی پارەدانێ بنووسە.', tone: 'danger' });
                else alert((typeof t === 'function') ? t('pcd_amount_required') : 'بڕی پارەدانێ بنووسە.');
                return;
            }
            if (val > Math.round(currentBal) + 1) {
                if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('pcd_amount_too_high') : 'بڕەکە ژ قەرزی مەزنترە.', 'error');
                else if (typeof window.posAlert === 'function') window.posAlert({ message: (typeof t === 'function') ? t('pcd_amount_too_high') : 'بڕەکە ژ قەرزی مەزنترە.', tone: 'danger' });
                else alert((typeof t === 'function') ? t('pcd_amount_too_high') : 'بڕەکە ژ قەرزی مەزنترە.');
                return;
            }
            var invTxn = window._pcdPayTransactionId ? String(window._pcdPayTransactionId) : '';
            if (invTxn && typeof window.getCompanyInvoiceRemainingDebt === 'function') {
                var invRem = window.getCompanyInvoiceRemainingDebt(invTxn);
                if (invRem > 0 && val > invRem + 1) {
                    if (typeof showToast === 'function') showToast((typeof t === 'function' && t('pcd_amount_too_high') !== 'pcd_amount_too_high') ? t('pcd_amount_too_high') : 'بڕەکە ژ قەرزی فاتورێ مەزنترە.', 'error');
                    return;
                }
            }
            submitCompanyDebtPayment(comp, val, 'payment', invTxn);
        }
        if (typeof window !== 'undefined') window.confirmPayCompanyDebt = confirmPayCompanyDebt;

        window.getCompanyInvoiceRemainingDebt = function(txnId) {
            txnId = String(txnId || '');
            if (!txnId || !Array.isArray(db.supplies)) return 0;
            var rem = 0;
            var found = false;
            for (var i = 0; i < db.supplies.length; i++) {
                var s = db.supplies[i];
                if (!s || String(s.transaction_id || '') !== txnId) continue;
                var st = String(s.type || '').toLowerCase();
                if (st !== 'credit' && st !== 'split') continue;
                found = true;
                if (s.remaining_debt != null && s.remaining_debt !== '') {
                    rem += Math.max(0, parseFloat(s.remaining_debt) || 0);
                } else {
                    rem += Math.max(0, parseFloat(s.totalCost) || 0);
                }
            }
            return found ? rem : 0;
        };

        window.applyLocalCompanyInvoicePayment = function(txnId, amount, companyName) {
            amount = Math.max(0, parseFloat(amount) || 0);
            if (amount <= 0 || !Array.isArray(db.supplies)) return;
            var left = amount;
            var lines = (db.supplies || []).filter(function(s) {
                if (!s) return false;
                var st = String(s.type || '').toLowerCase();
                if (st !== 'credit' && st !== 'split') return false;
                if (txnId) return String(s.transaction_id || '') === String(txnId);
                return companyName ? (String(s.company || '').trim() === String(companyName).trim()) : false;
            }).sort(function(a, b) {
                return (new Date(a.date || 0)).getTime() - (new Date(b.date || 0)).getTime() || ((a.id || 0) - (b.id || 0));
            });
            lines.forEach(function(s) {
                if (left <= 0) return;
                var owed = (s.remaining_debt != null && s.remaining_debt !== '')
                    ? Math.max(0, parseFloat(s.remaining_debt) || 0)
                    : Math.max(0, parseFloat(s.totalCost) || 0);
                if (owed <= 0) return;
                var take = Math.min(left, owed);
                s.remaining_debt = Math.max(0, owed - take);
                if (s.remaining_debt <= 0.0001) s.payment_due_at = null;
                left -= take;
            });
        };

        window.payCompanyInvoiceDebt = function(txnId, invoiceRemaining) {
            txnId = String(txnId || '');
            invoiceRemaining = parseFloat(invoiceRemaining);
            if (!txnId) return;
            if (isNaN(invoiceRemaining)) {
                invoiceRemaining = (typeof window.getCompanyInvoiceRemainingDebt === 'function')
                    ? window.getCompanyInvoiceRemainingDebt(txnId) : 0;
            }
            if (invoiceRemaining <= 0) {
                if (typeof showToast === 'function') showToast((typeof t === 'function' && t('cdm_invoice_no_debt') !== 'cdm_invoice_no_debt') ? t('cdm_invoice_no_debt') : 'ئەڤ فاتورە چ قەرزێ مایی نینە', 'warning');
                return;
            }
            var cid = currentViewingCompanyId;
            if (!cid) return;
            window._pcdPayTransactionId = txnId;
            window._pcdPayInvoiceRemaining = invoiceRemaining;
            openPayCompanyDebtModal(cid);
            setTimeout(function() {
                var amtEl = document.getElementById('pcd-amount');
                if (!amtEl) return;
                var isUsdDebtMode = (typeof getActiveCurrency === 'function') ? (getActiveCurrency() === 'USD') : false;
                var debtRate = 0;
                if (txnId && typeof lookupFrozenFxBundleForTxn === 'function') {
                    var bInv = lookupFrozenFxBundleForTxn(txnId);
                    if (bInv >= 1000) debtRate = bInv / 100;
                }
                if (!(debtRate > 0) && typeof fxUsdRateFormatOpts === 'function') {
                    var invFx = fxUsdRateFormatOpts({ transaction_id: txnId });
                    if (invFx && invFx.fxUsdRate) debtRate = invFx.fxUsdRate / 100;
                }
                if (!(debtRate > 0) && typeof getUsdRatePerOne === 'function') debtRate = getUsdRatePerOne();
                var display = (isUsdDebtMode && debtRate > 0)
                    ? (Math.round((invoiceRemaining / debtRate) * 100) / 100)
                    : invoiceRemaining;
                amtEl.value = String(display);
                amtEl.focus();
                amtEl.select();
            }, 120);
        };

        function payDebt() {
            window._pcdPayTransactionId = '';
            window._pcdPayInvoiceRemaining = 0;
            if (!currentViewingCompanyId) return;
            openPayCompanyDebtModal(currentViewingCompanyId);
        }

        function printCompanyDebtReceipt(company, payload) {
            if (!company || !payload) return;
            var isPay = payload.type === 'payment';
            var title = isPay ? 'وەسڵا دانەڤا قەرزێ کۆمپانیێ' : 'وەسڵا وەرگرتنا قەرزێ کۆمپانیێ';
            var locale = typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ';
            var actor = (typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : 'System';
            var details =
                '<div class="section-title">' + title + '</div>' +
                '<table class="print-table" style="width:100%; border-collapse:collapse;">' +
                    '<tr><th>کۆمپانیا</th><td>' + escapeHtml(company.name || '') + '</td></tr>' +
                    '<tr><th>بەروار</th><td>' + new Date().toLocaleString(locale) + '</td></tr>' +
                    '<tr><th>پڕۆسە</th><td>' + (isPay ? 'دانەڤا قەرزی' : 'وەرگرتنا قەرزی') + '</td></tr>' +
                    '<tr><th>کوژم</th><td>' + formatCurrency(payload.amount || 0) + ' ' + (typeof getCurrencySymbol === 'function' ? getCurrencySymbol() : '') + '</td></tr>' +
                    '<tr><th>رەسیدێ بەرێ</th><td>' + formatCurrency(payload.before || 0) + '</td></tr>' +
                    '<tr><th>رەسیدێ پاشێ</th><td>' + formatCurrency(payload.after || 0) + '</td></tr>' +
                    '<tr><th>ژمارا لڤینێ</th><td>' + escapeHtml(payload.transaction_id || '-') + '</td></tr>' +
                    '<tr><th>بکارهێنەر</th><td>' + escapeHtml(actor) + '</td></tr>' +
                    '<tr><th>تێبینی</th><td>' + escapeHtml(payload.note || '-') + '</td></tr>' +
                '</table>';
            var html = (typeof buildReportHtml === 'function')
                ? buildReportHtml(title, new Date().toLocaleString(locale), '', details)
                : ('<div class="print-report-container">' + details + '</div>');
            if (typeof routePrint === 'function') routePrint('company_ledger', html, { details: 'debt_receipt=' + (isPay ? 'payment' : 'receive') });
            else if (typeof printContent === 'function') printContent(html);
        }

        function closeCompanyProfile() { document.getElementById('company-profile-modal').style.display = 'none'; renderCompanies(); }
