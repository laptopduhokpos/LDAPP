// POS reports - purchase/returns history modals

        /** Shared history-modal chrome helpers (pos-history-standard.css) */
        function histEsc(s) {
            return (typeof escapeHtml === 'function') ? escapeHtml(String(s == null ? '' : s)) : String(s == null ? '' : s);
        }
        function histListShellHtml(o) {
            o = o || {};
            var accent = o.accent || 'brand';
            var closeId = o.closeId || o.id || '';
            var titleInner = '<i class="' + histEsc(o.icon || 'fas fa-history') + '"></i> <span' +
                (o.titleI18n ? (' data-i18n="' + histEsc(o.titleI18n) + '"') : '') + '>' +
                histEsc(o.titleFb || '') + '</span>';
            return '<div class="glass-card hist-shell" data-accent="' + histEsc(accent) + '">' +
                '<div class="hist-header">' +
                '<h2 class="hist-title">' + titleInner + '</h2>' +
                '<button type="button" class="btn btn-danger btn-sm" onclick="document.getElementById(\'' + histEsc(closeId) + '\').style.display=\'none\'">' +
                '<i class="fas fa-times"></i> <span data-i18n="btn_close">داخستن</span></button></div>' +
                (o.filtersHtml || '') +
                (o.statsHtml || '') +
                '<div class="hist-body" id="' + histEsc(o.bodyId || '') + '">' + (o.bodyHtml || '') + '</div>' +
                (o.footerHtml || '') +
                '</div>';
        }
        function histFiltersWrap(innerHtml) {
            return '<div class="hist-filters">' + (innerHtml || '') + '</div>';
        }
        function histStatsHtml(cards) {
            cards = Array.isArray(cards) ? cards : [];
            if (!cards.length) return '';
            return '<div class="hist-stats">' + cards.map(function (c) {
                var tone = c.tone ? (' tone-' + c.tone) : '';
                return '<div class="hist-stat' + tone + '">' +
                    '<div class="hist-stat-label">' + histEsc(c.label || '') + '</div>' +
                    '<div class="hist-stat-value">' + (c.valueHtml != null ? c.valueHtml : histEsc(c.value || '')) + '</div></div>';
            }).join('') + '</div>';
        }
        function histTableWrap(theadHtml, tbodyId, tbodyHtml, colCount) {
            return '<table class="hist-table report-table"><thead><tr>' + (theadHtml || '') + '</tr></thead>' +
                '<tbody id="' + histEsc(tbodyId || '') + '">' +
                (tbodyHtml || ('<tr><td colspan="' + (colCount || 6) + '" style="text-align:center;padding:40px;"><i class="fas fa-spinner fa-spin fa-2x"></i></td></tr>')) +
                '</tbody></table>';
        }
        function histEmptyHtml(msg) {
            return '<div class="hist-empty"><i class="fas fa-inbox"></i><p style="margin:0;">' + histEsc(msg || '') + '</p></div>';
        }
        function histDetailShellHtml(o) {
            o = o || {};
            var accent = o.accent || 'brand';
            var closeId = o.closeId || o.id || '';
            return '<div class="glass-card hist-detail" data-accent="' + histEsc(accent) + '" onclick="event.stopPropagation();">' +
                '<div class="hist-header">' +
                '<h2 class="hist-title"><i class="' + histEsc(o.icon || 'fas fa-eye') + '"></i> ' + (o.titleHtml != null ? o.titleHtml : histEsc(o.title || '')) + '</h2>' +
                '<button type="button" class="btn btn-danger btn-sm" onclick="document.getElementById(\'' + histEsc(closeId) + '\').style.display=\'none\'"><i class="fas fa-times"></i></button></div>' +
                (o.bodyHtml || '') +
                '</div>';
        }
        function histDetailRow(lab, valHtml) {
            return '<div class="hist-detail-row"><span class="lab">' + histEsc(lab) + '</span><span class="val">' + valHtml + '</span></div>';
        }
        window.histListShellHtml = histListShellHtml;
        window.histFiltersWrap = histFiltersWrap;
        window.histStatsHtml = histStatsHtml;
        window.histTableWrap = histTableWrap;
        window.histEmptyHtml = histEmptyHtml;
        window.histDetailShellHtml = histDetailShellHtml;
        window.histDetailRow = histDetailRow;

        function purchaseHistFormatYmd(d) {
            var pad = function (n) { return String(n).padStart(2, '0'); };
            return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
        }

        function purchaseHistTodayYmd() {
            if (typeof getTodayDateInputValue === 'function') {
                var bd = getTodayDateInputValue(new Date());
                if (bd && /^\d{4}-\d{2}-\d{2}$/.test(String(bd))) return String(bd);
            }
            return purchaseHistFormatYmd(new Date());
        }

        function purchaseHistComputeFetchRange(prefix) {
            prefix = prefix || 'gph';
            var presetEl = document.getElementById(prefix + '-date-preset');
            var startEl = document.getElementById(prefix + '-start');
            var endEl = document.getElementById(prefix + '-end');
            if (!presetEl) return { all: '1' };
            
            var preset = presetEl.value;
            if (preset === 'all') return { all: '1' };
            
            // For all other presets, the helper updates the hidden/visible inputs
            var today = purchaseHistTodayYmd();
            var fromVal = (startEl && startEl.value) ? startEl.value : today;
            var toVal = (endEl && endEl.value) ? endEl.value : today;
            
            return { date_from: fromVal, date_to: toVal };
        }

        function purchaseHistDateKey(dateStr) {
            if (!dateStr) return '';
            try {
                if (typeof getBusinessDate === 'function') {
                    var bd = getBusinessDate(dateStr);
                    if (bd && /^\d{4}-\d{2}-\d{2}$/.test(String(bd))) return String(bd);
                }
            } catch (_e) {}
            var d = (typeof parseSQLDate === 'function') ? parseSQLDate(dateStr) : new Date(dateStr);
            if (!d || isNaN(d.getTime())) {
                var m = String(dateStr).match(/^(\d{4}-\d{2}-\d{2})/);
                return m ? m[1] : '';
            }
            return purchaseHistFormatYmd(d);
        }

        function purchaseHistDateInRange(dateStr, prefix) {
            var range = purchaseHistComputeFetchRange(prefix);
            if (range.all) return true;
            var key = purchaseHistDateKey(dateStr);
            if (!key) return false;
            if (range.date_from && key < range.date_from) return false;
            if (range.date_to && key > range.date_to) return false;
            return true;
        }

        function isPurchaseReturnSupplyLine(s) {
            if (!s) return false;
            var ty = String(s.type || '').toLowerCase().trim();
            var txn = String(s.transaction_id || '');
            if (txn.indexOf('TXPR') === 0) return true;
            if (ty === 'return') return true;
            return false;
        }

        window.loadGlobalPurchaseHistory = function (done, prefix) {
            prefix = prefix || 'gph';
            var tbody = document.getElementById(prefix === 'gprh' ? 'gprh-tbody' : 'gph-tbody');
            var colspan = prefix === 'gprh' ? 5 : 8;
            var hasCached = Array.isArray(window._fullPurchaseHistory) && window._fullPurchaseHistory.length > 0;
            if (tbody && !hasCached) {
                tbody.innerHTML = '<tr><td colspan="' + colspan + '" style="text-align:center;padding:40px;"><i class="fas fa-spinner fa-spin fa-2x"></i></td></tr>';
            }
            var range = purchaseHistComputeFetchRange(prefix);
            var params = new URLSearchParams();
            params.set('action', 'get_purchase_history');
            params.set('limit', '10000');
            if (range.all) {
                params.set('all', '1');
            } else {
                if (range.date_from) params.set('date_from', range.date_from);
                if (range.date_to) params.set('date_to', range.date_to);
            }
            var url = (typeof window.posRouterUrl === 'function') ? window.posRouterUrl(params.toString()) : ('?' + params.toString());
            return fetch(url)
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    if (data.status === 'success') {
                        window._fullPurchaseHistory = data.supplies || [];
                        window._gphAdjByTxn = (data.adjustments && data.adjustments.by_txn) ? data.adjustments.by_txn : {};
                        window._gphVoidedInvoices = (data.adjustments && Array.isArray(data.adjustments.voided)) ? data.adjustments.voided : [];
                        window._gphFetchMeta = {
                            truncated: !!data.truncated,
                            total: data.total || (data.supplies || []).length,
                            loaded: data.loaded || (data.supplies || []).length,
                            date_from: data.date_from,
                            date_to: data.date_to
                        };
                    }
                    if (typeof done === 'function') done();
                })
                .catch(function () {
                    window._fullPurchaseHistory = (window.db && window.db.supplies) || [];
                    window._gphAdjByTxn = window._gphAdjByTxn || {};
                    window._gphVoidedInvoices = window._gphVoidedInvoices || [];
                    window._gphFetchMeta = { truncated: true, fallback: true };
                    if (typeof done === 'function') done();
                });
        };

        function openPurchaseHistoryCompanyModal(e) {
            if (currentUser && currentUser.role !== 'admin' && typeof checkPermission === 'function' && !checkPermission('view_purchase_history')) {
                if (typeof logSecurityEvent === 'function') logSecurityEvent('access_denied', 'Attempted to open Purchase History without permission');
                nav('access-denied');
                return;
            }
            e = e || window.event;
            if (e) {
                e.preventDefault();
                e.stopPropagation();
            }

            let p1 = document.getElementById('purchase-options-popover'); if(p1) p1.style.display = 'none';
            let p2 = document.getElementById('purchase-returns-options-popover'); if(p2) p2.style.display = 'none';

            let modal = document.getElementById('purchase-history-company-modal');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'purchase-history-company-modal';
                modal.className = 'modal-overlay hist-modal';
                modal.style.zIndex = '10005';
                document.body.appendChild(modal);
                modal.onclick = function(evt) {
                    if (evt.target === modal) modal.style.display = 'none';
                };
            } else {
                modal.classList.add('hist-modal');
            }
            
            let compOptions = '<option value="">🏢 هەمی کۆمپانیا (All)</option>';
            if(window.db && window.db.companies) {
                let sorted = window.db.companies.slice().sort((a,b) => (a.name||'').localeCompare(b.name||''));
                compOptions += sorted.map(c => `<option value="${escapeHtml(c.name)}">${escapeHtml(c.name)}</option>`).join('');
            }

            var filtersHtml = histFiltersWrap(
                '<div style="flex:1; min-width:180px; position:relative;">' +
                '<i class="fas fa-search" style="position:absolute; right:12px; top:50%; transform:translateY(-50%); color:var(--text-muted); pointer-events:none;"></i>' +
                '<input type="text" id="gph-invoice-search" class="input-std" placeholder="🔍 گەڕان بە پسوولە یان کۆمپانیا..." style="width:100%; padding-right:38px;" oninput="if(typeof renderGlobalPurchaseHistory===\'function\') renderGlobalPurchaseHistory();">' +
                '</div>' +
                '<div style="flex:1; min-width:140px; position:relative;">' +
                '<i class="fas fa-layer-group" style="position:absolute; right:12px; top:50%; transform:translateY(-50%); color:#0E4AFF; pointer-events:none;"></i>' +
                '<input type="text" id="gph-batch-search" class="input-std" placeholder="ژمارا وەجبێ..." style="width:100%; padding-right:38px;" dir="ltr" maxlength="100" oninput="if(typeof renderGlobalPurchaseHistory===\'function\') renderGlobalPurchaseHistory();">' +
                '</div>' +
                '<select id="gph-company" class="input-std" style="flex:1; min-width:180px;" onchange="renderGlobalPurchaseHistory()">' + compOptions + '</select>' +
                '<select id="gph-date-preset" class="input-std" style="flex:1; min-width:150px;" onchange="if(typeof applyGlobalDatePreset===\'function\') applyGlobalDatePreset(this.value, \'gph\', function(){ loadGlobalPurchaseHistory(renderGlobalPurchaseHistory, \'gph\'); }); else { toggleGphCustomDates(); loadGlobalPurchaseHistory(renderGlobalPurchaseHistory, \'gph\'); }">' +
                '<option value="today" selected>☀️ ئەڤرۆ (Today)</option>' +
                '<option value="week">📅 حەفتییا بۆری (Last 7 Days)</option>' +
                '<option value="month">🌙 ئەڤ هەیڤە (This Month)</option>' +
                '<option value="90d">📅 ٩٠ ڕۆژ (Last 90 Days)</option>' +
                '<option value="1y">📅 ١ ساڵ (1 Year)</option>' +
                '<option value="all">📅 هەمی دەم (All Time)</option>' +
                '<option value="custom">✍️ دیارکرنا دەمی (Custom)</option></select>' +
                '<input type="date" id="gph-start" class="input-std" style="flex:1; min-width:130px; display:none;" onchange="loadGlobalPurchaseHistory(function(){ if(typeof renderGlobalPurchaseHistory===\'function\') renderGlobalPurchaseHistory(); }, \'gph\');">' +
                '<input type="date" id="gph-end" class="input-std" style="flex:1; min-width:130px; display:none;" onchange="loadGlobalPurchaseHistory(function(){ if(typeof renderGlobalPurchaseHistory===\'function\') renderGlobalPurchaseHistory(); }, \'gph\');">'
            );
            var th =
                '<th>بەروار</th><th>کۆمپانیا</th><th style="text-align:center;">ژمارا پسوولێ</th>' +
                '<th style="text-align:center;">ژمارا وەجبێ</th><th style="text-align:center;">ئایتم</th>' +
                '<th>جۆر</th><th style="text-align:left;">کۆم</th><th style="text-align:center;">کردار</th>';
            modal.innerHTML = histListShellHtml({
                id: 'purchase-history-company-modal',
                closeId: 'purchase-history-company-modal',
                titleFb: 'مێژوویا گشتی یا کڕینێ (Purchase History)',
                icon: 'fas fa-history',
                accent: 'warning',
                filtersHtml: filtersHtml,
                bodyId: 'gph-body-wrap',
                bodyHtml: histTableWrap(th, 'gph-tbody', null, 8)
            });

            modal.style.display = 'flex';

            loadGlobalPurchaseHistory(function () {
                if (typeof window.renderGlobalPurchaseHistory === 'function') {
                    window.renderGlobalPurchaseHistory();
                }
            }, 'gph');
        }

        function gphNormalizeSearchText(v) {
            var s = String(v == null ? '' : v);
            s = s.replace(/[\u0660-\u0669]/g, function (ch) { return String(ch.charCodeAt(0) - 0x0660); });
            s = s.replace(/[\u06F0-\u06F9]/g, function (ch) { return String(ch.charCodeAt(0) - 0x06F0); });
            return s.toLowerCase().replace(/\s+/g, ' ').trim();
        }

        function gphDigitsOnly(v) {
            return gphNormalizeSearchText(v).replace(/\D/g, '');
        }

        function gphTextMatches(hay, needle) {
            if (!needle) return true;
            var h = gphNormalizeSearchText(hay);
            if (!h) return false;
            if (h.indexOf(needle) >= 0) return true;
            var hD = gphDigitsOnly(h);
            var nD = gphDigitsOnly(needle);
            return nD.length > 0 && hD.indexOf(nD) >= 0;
        }

        function gphInvoiceDisplayNumber(inv) {
            var raw = String(inv.invNum != null ? inv.invNum : '').trim();
            if (raw) return raw;
            if (typeof resolveCompanyInvoiceDisplayNumber === 'function') {
                return String(resolveCompanyInvoiceDisplayNumber(inv.invNum, inv.txnId) || '').trim();
            }
            return String(inv.txnId || '').trim();
        }

        function gphSupplyMatchesSearch(s, searchQ) {
            if (!searchQ) return true;
            var parts = [
                s.supplier_invoice_number,
                s.batch_number,
                s.company,
                s.itemName,
                s.transaction_id
            ];
            if (typeof resolveCompanyInvoiceDisplayNumber === 'function') {
                parts.push(resolveCompanyInvoiceDisplayNumber(s.supplier_invoice_number, s.transaction_id));
            }
            for (var i = 0; i < parts.length; i++) {
                if (gphTextMatches(parts[i], searchQ)) return true;
            }
            return false;
        }

        function gphInvoiceMatchesSearch(inv, searchQ) {
            if (!searchQ) return true;
            var parts = [
                gphInvoiceDisplayNumber(inv),
                inv.invNum,
                inv.batchNum,
                inv.company,
                inv.txnId
            ];
            (inv.items || []).forEach(function (it) {
                parts.push(it.supplier_invoice_number);
                parts.push(it.batch_number);
                parts.push(it.itemName);
            });
            for (var i = 0; i < parts.length; i++) {
                if (gphTextMatches(parts[i], searchQ)) return true;
            }
            return false;
        }

        function gphBatchMatchesSearch(inv, batchQ) {
            if (!batchQ) return true;
            if (gphTextMatches(inv.batchNum, batchQ)) return true;
            return (inv.items || []).some(function (it) {
                return gphTextMatches(it.batch_number, batchQ);
            });
        }

        function gphRenderBatchCell(inv) {
            var batch = String(inv.batchNum || '').trim();
            if (batch) {
                return '<span style="display:inline-flex; align-items:center; gap:6px; background:rgba(14,74,255,0.1); border:2px solid #0E4AFF; padding:7px 14px; border-radius:10px; font-weight:900; font-size:1.1rem; color:#0E4AFF; font-family:Rudaw,sans-serif;" title="ژمارا وەجبێ"><i class="fas fa-layer-group" style="font-size:0.9rem;"></i> ' + escapeHtml(batch) + '</span>';
            }
            return '<span style="display:inline-flex; align-items:center; gap:6px; background:rgba(239,68,68,0.1); border:2px dashed #ef4444; padding:7px 12px; border-radius:10px; font-weight:bold; font-size:0.85rem; color:#ef4444;" title="بێ ژمارا وەجبێ"><i class="fas fa-exclamation-triangle"></i> بێ وەجبە</span>';
        }

        function computePurchaseInvoiceMargin(inv) {
            var items = (inv && Array.isArray(inv.items)) ? inv.items : [];
            var buyTotal = parseFloat(inv && inv.total) || 0;
            if (!buyTotal) {
                buyTotal = items.reduce(function (a, s) { return a + (parseFloat(s.totalCost) || 0); }, 0);
            }
            var map = window._gphProductById;
            if (!map || !(map instanceof Map)) {
                map = new Map();
                var prods = (window.db && Array.isArray(db.products)) ? db.products : [];
                for (var i = 0; i < prods.length; i++) {
                    if (prods[i] && prods[i].id != null) map.set(Number(prods[i].id), prods[i]);
                }
                window._gphProductById = map;
            }
            var sellTotal = 0;
            for (var j = 0; j < items.length; j++) {
                var it = items[j];
                var isGiftLine = (typeof window.isSupplyItemGift === 'function')
                    ? window.isSupplyItemGift(it)
                    : !!(it && (it.isGift === true || it.is_gift === 1 || it.is_gift === '1' || it.is_gift === true));
                if (!it || isGiftLine) continue;
                var pieces = parseFloat(it.qtyAdded);
                if (isNaN(pieces) || pieces <= 0) pieces = parseFloat(it.qty) || 0;
                if (!(pieces > 0)) continue;
                var prod = map.get(Number(it.prodId));
                var piecePrice = 0;
                if (prod && typeof getPriceForUnit === 'function') {
                    piecePrice = Number(getPriceForUnit(prod, 'piece')) || 0;
                } else if (prod) {
                    piecePrice = Number(prod.price) || 0;
                }
                sellTotal += piecePrice * pieces;
            }
            return {
                buy: buyTotal,
                sell: sellTotal,
                profit: sellTotal - buyTotal
            };
        }
        window.computePurchaseInvoiceMargin = computePurchaseInvoiceMargin;

        function showPurchaseProfitTip(btn, evt, opts) {
            opts = opts || {};
            try {
                if (evt && evt.stopPropagation) evt.stopPropagation();
                if (evt && evt.cancelable && (evt.type === 'pointerdown' || evt.type === 'click')) evt.preventDefault();
            } catch (e0) {}
            if (!btn) return;
            if (typeof canViewInvoiceProfit === 'function') {
                if (!canViewInvoiceProfit()) return;
            } else if (typeof canViewProfit === 'function' && !canViewProfit()) {
                return;
            }
            var sticky = !!opts.sticky;
            var txnId = btn.getAttribute('data-txn-id') || '';
            var list = window._gphInvoices || [];
            var inv = null;
            for (var i = 0; i < list.length; i++) {
                if (String(list[i].txnId) === String(txnId)) { inv = list[i]; break; }
            }
            var profitLabel = (typeof t === 'function') ? t('sale_hist_profit') : 'قازانج';
            var buyLabel = (typeof t === 'function') ? t('sale_hist_invoice_cost') : 'کرینا وەسڵێ';
            var sellLabel = (typeof t === 'function') ? t('purchase_hist_sell_value') : 'فرۆتن';
            var tip = (typeof ensurePosCostTipEl === 'function')
                ? ensurePosCostTipEl()
                : (function () {
                    var el = document.getElementById('pos-cost-hover-tip');
                    if (!el) {
                        el = document.createElement('div');
                        el.id = 'pos-cost-hover-tip';
                        el.className = 'pos-cost-hover-tip';
                        el.setAttribute('role', 'tooltip');
                        document.body.appendChild(el);
                    }
                    return el;
                })();
            if (!inv) {
                tip.textContent = profitLabel + ': —';
            } else {
                var calc = computePurchaseInvoiceMargin(inv);
                var fmt = function (n) {
                    return (typeof formatCurrency === 'function') ? formatCurrency(n) : String(Math.round(n));
                };
                tip.innerHTML =
                    '<div class="pos-tip-row"><span class="pos-tip-lab">' + profitLabel + '</span><span class="pos-tip-val">' + fmt(calc.profit) + '</span></div>' +
                    '<div class="pos-tip-row"><span class="pos-tip-lab">' + buyLabel + '</span><span class="pos-tip-val">' + fmt(calc.buy) + '</span></div>' +
                    '<div class="pos-tip-row"><span class="pos-tip-lab">' + sellLabel + '</span><span class="pos-tip-val">' + fmt(calc.sell) + '</span></div>';
            }
            if (sticky) tip.classList.add('is-sticky');
            else tip.classList.remove('is-sticky');
            window.__posCostTipSticky = sticky;
            window.__posCostTipActiveBtn = btn;
            if (typeof placePosCostTip === 'function') placePosCostTip(tip, btn);
            else {
                tip.style.zIndex = '600000';
                tip.style.display = 'block';
                tip.style.visibility = 'visible';
            }
            if (sticky && typeof bindPosCostTipOutside === 'function') bindPosCostTipOutside();
        }
        window.showPurchaseProfitTip = showPurchaseProfitTip;

        function togglePurchaseProfitTip(btn, evt) {
            try {
                if (evt && evt.stopPropagation) evt.stopPropagation();
                if (evt && evt.preventDefault) evt.preventDefault();
            } catch (e0) {}
            if (!btn) return;
            if (window.__posCostTipSticky && window.__posCostTipActiveBtn === btn && document.getElementById('pos-cost-hover-tip')) {
                if (typeof hidePosCostTip === 'function') hidePosCostTip();
                return;
            }
            showPurchaseProfitTip(btn, evt, { sticky: true });
        }
        window.togglePurchaseProfitTip = togglePurchaseProfitTip;

        function _gphT(k, fb) {
            if (typeof t !== 'function') return fb;
            var v = t(k);
            return (v && v !== k) ? v : fb;
        }
        function posPurchaseInvAdj(inv) {
            var txn = String((inv && inv.txnId) || '');
            var meta = (window._gphAdjByTxn && window._gphAdjByTxn[txn]) ? Object.assign({}, window._gphAdjByTxn[txn]) : {};
            if (inv && inv.is_voided) {
                meta.is_voided = 1;
            }
            if (!meta.has_return && inv && typeof db !== 'undefined' && db && Array.isArray(db.purchase_returns)) {
                var invn = String(inv.invNum || '').trim();
                var comp = String(inv.company || '').trim();
                if (invn && db.purchase_returns.some(function (r) {
                    return String(r.supplier_invoice_number || '') === invn &&
                        String(r.company_name || r.company || '') === comp;
                })) {
                    meta.has_return = 1;
                }
            }
            return meta;
        }
        function posPurchaseInvBadgesHtml(inv) {
            var meta = posPurchaseInvAdj(inv);
            var badges = '';
            if (inv && inv.is_voided) {
                badges += '<span class="hist-sale-badge hist-sale-badge--void">' + escapeHtml(_gphT('sale_hist_badge_void', 'ژێبرای')) + '</span>';
            }
            if (meta.has_return) {
                badges += '<span class="hist-sale-badge hist-sale-badge--return">' + escapeHtml(_gphT('sale_hist_badge_return', 'زڤڕاندن')) + '</span>';
            }
            if (meta.has_edits || Number(meta.edit_count) > 0) {
                badges += '<span class="hist-sale-badge hist-sale-badge--edit">' + escapeHtml(_gphT('sale_hist_badge_edit', 'تەعدیلکری')) + '</span>';
            }
            var extra = '';
            if (Number(meta.edit_count) > 0) {
                extra += '<div class="hist-sale-wh">' + escapeHtml(_gphT('sale_hist_badge_edit', 'تەعدیلکری')) + ': ' + Number(meta.edit_count) + '</div>';
            }
            if (inv && inv.void_user) {
                extra += '<div class="hist-sale-wh">' + escapeHtml(_gphT('sale_hist_badge_void', 'ژێبرای')) + ': ' + escapeHtml(inv.void_user) + '</div>';
            }
            if (!badges && !extra) return '';
            return (badges ? ('<div class="hist-sale-badges">' + badges + '</div>') : '') + extra;
        }
        window.posPurchaseInvAdj = posPurchaseInvAdj;
        window.posPurchaseInvBadgesHtml = posPurchaseInvBadgesHtml;

        window.renderGlobalPurchaseHistory = function() {
            const tbody = document.getElementById('gph-tbody');
            if (!tbody) return;
            
            const compEl = document.getElementById('gph-company');
            const compFilter = compEl ? compEl.value : '';
            const searchEl = document.getElementById('gph-invoice-search');
            const searchQ = searchEl ? gphNormalizeSearchText(searchEl.value) : '';
            const batchEl = document.getElementById('gph-batch-search');
            const batchQ = batchEl ? gphNormalizeSearchText(batchEl.value) : '';

            const baseList = window._fullPurchaseHistory || (window.db && window.db.supplies) || [];
            let history = baseList.filter(function (s) { return s.type !== 'return'; });
            
            if (compFilter) {
                history = history.filter(s => s.company === compFilter);
            }

            const grouped = {};
                history.forEach(s => {
                    const key = s.transaction_id || ('OLD_' + s.date + '_' + s.prodId);
                    if (!grouped[key]) grouped[key] = { txnId: s.transaction_id, date: s.date, type: s.type, total: 0, itemsCount: 0, items: [], invNum: '', batchNum: '', company: s.company };
                    var lineInv = String(s.supplier_invoice_number != null ? s.supplier_invoice_number : '').trim();
                    if (lineInv) grouped[key].invNum = lineInv;
                    var lineBatch = String(s.batch_number != null ? s.batch_number : '').trim();
                    if (lineBatch) grouped[key].batchNum = lineBatch;
                    grouped[key].total += (parseFloat(s.totalCost) || 0);
                    grouped[key].itemsCount++;
                    grouped[key].items.push(s);
                });
                
                let invoices = Object.values(grouped).sort((a, b) => new Date(b.date) - new Date(a.date));

                var seenTxn = {};
                invoices.forEach(function (inv) { seenTxn[String(inv.txnId || '')] = true; });
                (window._gphVoidedInvoices || []).forEach(function (v) {
                    if (!v || !v.txn_id) return;
                    var tid = String(v.txn_id);
                    if (seenTxn[tid]) return;
                    if (compFilter && String(v.company || '') !== String(compFilter)) return;
                    var vItems = Array.isArray(v.items) ? v.items.map(function (it) {
                        return {
                            company: v.company,
                            prodId: it.prodId,
                            itemName: it.itemName,
                            qtyAdded: it.qtyAdded,
                            totalCost: it.totalCost,
                            date: v.date,
                            type: v.type || 'cash',
                            transaction_id: tid,
                            supplier_invoice_number: v.supplier_invoice_number,
                            batch_number: it.batch_number || ''
                        };
                    }) : [];
                    invoices.push({
                        txnId: tid,
                        date: v.date,
                        type: v.type || 'cash',
                        total: v.total || 0,
                        itemsCount: v.items_count || vItems.length,
                        items: vItems,
                        invNum: v.supplier_invoice_number || '',
                        batchNum: '',
                        company: v.company || '',
                        is_voided: 1,
                        audit_id: v.audit_id || 0,
                        void_user: v.void_user || '',
                        void_at: v.void_at || ''
                    });
                    seenTxn[tid] = true;
                });
                invoices.sort(function (a, b) { return new Date(b.date) - new Date(a.date); });

                if (searchQ) {
                    invoices = invoices.filter(function (inv) { return gphInvoiceMatchesSearch(inv, searchQ); });
                }
                if (batchQ) {
                    invoices = invoices.filter(function (inv) { return gphBatchMatchesSearch(inv, batchQ); });
                }

                if (invoices.length === 0) {
                    var emptyParts = [];
                    if (searchQ && searchEl && searchEl.value.trim()) emptyParts.push('پسوولە: «' + escapeHtml(searchEl.value.trim()) + '»');
                    if (batchQ && batchEl && batchEl.value.trim()) emptyParts.push('وەجبە: «' + escapeHtml(batchEl.value.trim()) + '»');
                    var emptyMsg = emptyParts.length
                        ? 'چ وەسڵێک نەدۆزرایەوە بۆ ' + emptyParts.join(' · ')
                        : 'چ وەسڵێن کڕینێ نینن د ڤی دەمی دا.';
                    tbody.innerHTML = '<tr><td colspan="8" style="text-align:center; padding:40px; color:var(--text-muted);"><i class="fas fa-inbox" style="font-size:3rem; opacity:0.3; margin-bottom:15px; display:block;"></i>' + emptyMsg + '</td></tr>';
                    return;
                }

                var meta = window._gphFetchMeta || {};
                var metaRow = '';
                if (meta.truncated) {
                    metaRow = '<tr><td colspan="8" style="padding:10px 12px; background:rgba(245,158,11,0.12); color:var(--warning); font-size:0.82rem; text-align:center;">⚠️ ' + (meta.loaded || invoices.length) + ' / ' + (meta.total || '?') + ' — هەندێک تۆمار نەهاتن (سنوور). فیلتەری بەروار بەکاربهێنە.</td></tr>';
                }

                var canEditPurchaseLine = (typeof currentUser !== 'undefined' && currentUser && currentUser.role === 'admin') || (typeof checkPermission === 'function' && checkPermission('companies_manage'));
                var canSeeProfit = (typeof canViewInvoiceProfit === 'function')
                    ? canViewInvoiceProfit()
                    : ((typeof canViewProfit === 'function') ? canViewProfit() : (currentUser && currentUser.role === 'admin'));
                var profitTip = (typeof t === 'function') ? t('purchase_hist_profit_hold') : 'قازانج و کرینا وەسڵێ — کلیک بکە';
                window._gphInvoices = invoices;
                window._gphProductById = null;

                tbody.innerHTML = metaRow + invoices.map(inv => {
                    let typeBadge = inv.type === 'credit' ? '<span style="background:#fee2e2; color:#b91c1c; padding:4px 10px; border-radius:6px; font-size:0.8rem; font-weight:bold;">قەرز</span>' : (inv.type === 'return' ? '<span style="background:#000; color:white; padding:4px 10px; border-radius:6px; font-size:0.8rem; font-weight:bold;">زڤڕاندن</span>' : ((inv.type === 'fib' || inv.type === 'bank' || inv.type === 'bankcard') ? '<span style="background:#dbeafe; color:#1d4ed8; padding:4px 10px; border-radius:6px; font-size:0.8rem; font-weight:bold;">FIB</span>' : (inv.type === 'split' ? '<span style="background:#fef3c7; color:#b45309; padding:4px 10px; border-radius:6px; font-size:0.8rem; font-weight:bold;">قەرز + نەقد</span>' : '<span style="background:#d1fae5; color:#065f46; padding:4px 10px; border-radius:6px; font-size:0.8rem; font-weight:bold;">نەقد</span>')));
                    const displayInv = gphInvoiceDisplayNumber(inv);
                    const hasSupInv = String(inv.invNum || '').trim() !== '';
                    const invBadge = hasSupInv
                        ? '<span style="display:inline-flex; align-items:center; gap:6px; background:rgba(245,158,11,0.12); border:2px solid var(--warning); padding:7px 14px; border-radius:10px; font-weight:900; font-size:1.2rem; color:var(--warning); font-family:Rudaw,sans-serif; letter-spacing:0.5px;" title="ژمارا پسوولێ"><i class="fas fa-file-invoice" style="font-size:0.95rem;"></i> ' + escapeHtml(displayInv) + '</span>'
                        : '<span style="display:inline-flex; align-items:center; gap:6px; background:rgba(239,68,68,0.1); border:2px dashed #ef4444; padding:7px 12px; border-radius:10px; font-weight:bold; font-size:0.9rem; color:#ef4444;" title="پێدڤیە ژمارا پسوولێ بنڤیسی"><i class="fas fa-exclamation-triangle"></i> بێ ژمارا پسوولێ</span>';
                    const hasBatchNum = String(inv.batchNum || '').trim() !== '';
                    const batchBadge = gphRenderBatchCell(inv);
                    var editBtnHtml = (canEditPurchaseLine && inv.type !== 'return' && !inv.is_voided) ? `<button class="btn btn-sm btn-primary" onclick="startEditPurchaseInCart('${inv.txnId}')" title="تەعدیل لە سەبەتە"><i class="fas fa-edit"></i></button>` : '';
                    var returnBtnHtml = (canEditPurchaseLine && inv.type !== 'return' && !inv.is_voided) ? `<button class="btn btn-sm btn-return-invoice" onclick="startPurchaseReturnFromHistory('${inv.txnId}')" title="زڤڕاندنا کڕینێ"><i class="fas fa-undo"></i></button>` : '';
                    var adjMeta = posPurchaseInvAdj(inv);
                    var showAdjPrint = !!(inv.is_voided || adjMeta.has_return || adjMeta.has_edits || Number(adjMeta.edit_count) > 0);
                    var adjTitle = escapeHtml(_gphT('sale_hist_print_adjust', 'چاپا تەعدیل / ژێبرن'));
                    var adjPrintBtn = showAdjPrint
                        ? '<button class="btn btn-sm btn-warning" onclick="printPurchaseAdjustmentSlip(\'' + String(inv.txnId || '').replace(/'/g, "\\'") + '\')" title="' + adjTitle + '"><i class="fas fa-file-invoice"></i></button>'
                        : '';
                    var restoreBtn = inv.is_voided
                        ? '<button class="btn btn-sm btn-success" onclick="restoreVoidedPurchase(\'' + String(inv.txnId || '').replace(/'/g, "\\'") + '\',' + (parseInt(inv.audit_id, 10) || 0) + ')" title="گەڕاندنەوە"><i class="fas fa-trash-restore"></i></button>'
                        : '';
                    var delBtn = inv.is_voided ? '' : `<button class="btn btn-sm btn-danger" onclick="voidPurchaseInvoice('${inv.txnId}'); setTimeout(function(){ if(typeof loadGlobalPurchaseHistory==='function') loadGlobalPurchaseHistory(renderGlobalPurchaseHistory, 'gph'); else renderGlobalPurchaseHistory(); }, 500);" title="ژێبرن"><i class="fas fa-trash"></i></button>`;
                    var badgesHtml = posPurchaseInvBadgesHtml(inv);
                    var profitBtn = '';
                    if (canSeeProfit && inv.type !== 'return') {
                        var txnEsc = String(inv.txnId || '').replace(/"/g, '&quot;');
                        profitBtn = '<button type="button" class="btn btn-sm pos-sale-profit-btn" data-perm="view_profit" data-txn-id="' + txnEsc + '"' +
                            ' onpointerenter="showPurchaseProfitTip(this,event)"' +
                            ' onpointerleave="if(!window.__posCostTipSticky)hidePosCostTip()"' +
                            ' onclick="togglePurchaseProfitTip(this,event)"' +
                            ' title="' + escapeHtml(profitTip) + '" aria-label="' + escapeHtml(profitTip) + '">' +
                            '<i class="fas fa-coins" aria-hidden="true"></i></button>';
                    }
                    var companySub = '';
                    if (hasSupInv) companySub += '<div style="font-size:0.78rem; color:var(--text-muted); margin-top:4px;"><i class="fas fa-file-invoice" style="opacity:0.7;"></i> پسوول: <b style="color:var(--warning);">' + escapeHtml(displayInv) + '</b></div>';
                    if (hasBatchNum) companySub += '<div style="font-size:0.78rem; color:var(--text-muted); margin-top:4px;"><i class="fas fa-layer-group" style="opacity:0.7;"></i> وەجبە: <b style="color:#0E4AFF;">' + escapeHtml(inv.batchNum) + '</b></div>';
                    
                    return `<tr class="${inv.is_voided ? 'hist-sale-row--void' : ''}" style="border-bottom:1px solid var(--border); transition:0.2s;" onmouseover="this.style.background='var(--input-bg)'" onmouseout="this.style.background='transparent'">
                        <td style="padding:15px 12px; color:var(--text-muted); font-size:0.9rem;">${new Date(inv.date).toLocaleDateString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ')}${badgesHtml}</td>
                        <td style="padding:15px 12px; font-weight:bold; color:var(--info); cursor:pointer;" onclick="document.getElementById('purchase-history-company-modal').style.display='none'; window._companyProfileDefaultTab='history'; nav('companies'); setTimeout(()=>openCompanyProfile(${(db.companies.find(c=>c.name===inv.company)||{}).id}), 100);" title="چوون بۆ پڕۆفایلێ کۆمپانیێ"><div><i class="fas fa-building" style="margin-left:5px; opacity:0.7;"></i> ${escapeHtml(inv.company)}</div>${companySub}</td>
                        <td style="padding:15px 12px; text-align:center;">${invBadge}</td>
                        <td style="padding:15px 12px; text-align:center;">${batchBadge}</td>
                        <td style="padding:15px 12px; text-align:center;"><span style="background:var(--card); border:1px solid var(--border); padding:4px 10px; border-radius:8px; font-size:0.88rem; font-weight:bold;">${inv.itemsCount} ئایتم</span></td>
                        <td style="padding:15px 12px;">${typeBadge}</td>
                        <td style="padding:15px 12px; font-weight:900; color:#0E4AFF; font-size:1.1rem; text-align:left;">${(typeof formatTxnMoney === 'function') ? formatTxnMoney(inv.total, (inv.items && inv.items[0]) ? inv.items[0] : inv) : formatCurrency(inv.total, (typeof fxUsdRateFormatOpts === 'function') ? fxUsdRateFormatOpts((inv.items && inv.items[0]) ? inv.items[0] : inv) : undefined)}</td>
                        <td style="padding:15px 12px; text-align:center; white-space:nowrap; display:flex; gap:6px; justify-content:center; flex-wrap:wrap;">
                            ${profitBtn}
                            ${editBtnHtml}
                            ${returnBtnHtml}
                            ${adjPrintBtn}
                            ${restoreBtn}
                            <button class="btn btn-sm btn-dark" onclick="viewInvoiceHistoryDetails('${inv.txnId}')" title="بینین / چاپ"><i class="fas fa-eye"></i></button>
                            ${delBtn}
                        </td>
                    </tr>`;
                }).join('');
        };

        function openPosOptionsModal(e) {
            e = e || window.event;
            if (e) {
                e.preventDefault();
                e.stopPropagation();
            }

            // داخستنا مینیویا زڤڕاندنێ ئەگەر یا ڤەکری بیت
            let retModal = document.getElementById('returns-options-popover');
            if (retModal) retModal.style.display = 'none';
            let purchModal = document.getElementById('purchase-options-popover');
            if (purchModal) purchModal.style.display = 'none';
            let purchRetModal = document.getElementById('purchase-returns-options-popover');
            if (purchRetModal) purchRetModal.style.display = 'none';

            let modal = document.getElementById('pos-options-popover');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'pos-options-popover';
                modal.style.position = 'absolute';
                modal.style.zIndex = '10000';
                modal.style.background = 'var(--card)';
                modal.style.border = '1px solid var(--border)';
                modal.style.borderRadius = '12px';
                modal.style.boxShadow = '0 8px 30px rgba(0,0,0,0.15)';
                modal.style.padding = '15px';
                modal.style.minWidth = '320px';
                modal.style.display = 'flex';
                modal.style.flexDirection = 'column';
                modal.style.gap = '10px';
                modal.innerHTML = `
                    <div style="font-size:0.95rem; color:var(--text); padding-bottom:10px; border-bottom:1px solid var(--border); margin-bottom:5px; font-weight:bold; text-align:center;">
                        <i class="fas fa-th-large" style="margin-left:5px;"></i> <span data-i18n="popover_pos_menu_title">مینیویا فرۆتنێ</span>
                    </div>
                    <div style="display:grid; grid-template-columns: repeat(2, 1fr); gap:12px;">
                        <div data-shortcut-id="pos-sales-screen" draggable="true" style="cursor:pointer; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:20px 10px; background:var(--card); border:2px solid var(--border); border-radius:14px; transition:all 0.2s ease;" onmouseover="this.style.borderColor='var(--brand)'; this.style.transform='translateY(-3px)'; this.style.boxShadow='0 6px 15px rgba(14, 74, 255, 0.15)';" onmouseout="this.style.borderColor='var(--border)'; this.style.transform='none'; this.style.boxShadow='none';" onclick="document.getElementById('pos-options-popover').style.display='none'; if(db && db.settings && db.settings.showTables !== true) { openDirectPOS(); } else { nav('pos'); }">
                            <i class="fas fa-shopping-cart" style="font-size:2.2rem; margin-bottom:12px; color:var(--brand);"></i>
                            <span style="font-size:0.9rem; font-weight:bold; color:var(--text);" data-i18n="popover_screen_sales">شاشا فرۆتنێ</span>
                        </div>
                        <div data-perm="view_sales_history">
                            <div data-shortcut-id="sales-history" draggable="true" style="cursor:pointer; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:20px 10px; background:var(--card); border:2px solid var(--border); border-radius:14px; transition:all 0.2s ease;" onmouseover="this.style.borderColor='#8b5cf6'; this.style.transform='translateY(-3px)'; this.style.boxShadow='0 6px 15px rgba(139, 92, 246, 0.15)';" onmouseout="this.style.borderColor='var(--border)'; this.style.transform='none'; this.style.boxShadow='none';" onclick="document.getElementById('pos-options-popover').style.display='none'; openSalesHistoryFromReturnsPrompt();">
                                <i class="fas fa-file-invoice-dollar" style="font-size:2.2rem; margin-bottom:12px; color:#8b5cf6;"></i>
                                <span style="font-size:0.9rem; font-weight:bold; color:var(--text);" data-i18n="popover_history_sales">مێژوویا فرۆتنێ</span>
                            </div>
                        </div>
                            <div data-shortcut-id="debt" draggable="true" style="cursor:pointer; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:20px 10px; background:var(--card); border:2px solid var(--border); border-radius:14px; transition:all 0.2s ease;" onmouseover="this.style.borderColor='#10b981'; this.style.transform='translateY(-3px)'; this.style.boxShadow='0 6px 15px rgba(16, 185, 129, 0.15)';" onmouseout="this.style.borderColor='var(--border)'; this.style.transform='none'; this.style.boxShadow='none';" onclick="document.getElementById('pos-options-popover').style.display='none'; nav('debt');">
                                <i class="fas fa-users" style="font-size:2.2rem; margin-bottom:12px; color:#10b981;"></i>
                                <span style="font-size:0.9rem; font-weight:bold; color:var(--text);" data-i18n="view_debt_title">کریار</span>
                        </div>
                        <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; padding:20px 10px; background:var(--input-bg); border:2px dashed var(--border); border-radius:14px; opacity:0.5; cursor:not-allowed;">
                            <i class="fas fa-plus" style="font-size:1.5rem; margin-bottom:12px; color:var(--text-muted);"></i>
                            <span style="font-size:0.8rem; color:var(--text-muted); font-weight:bold;" data-i18n="popover_menu_empty">ڤالا</span>
                        </div>
                    </div>
                `;
                document.body.appendChild(modal);
                document.addEventListener('click', function(evt) {
                    if (modal.style.display === 'flex' && !modal.contains(evt.target)) {
                        modal.style.display = 'none';
                    }
                });
            }
            if (modal.style.display === 'flex') {
                modal.style.display = 'none';
                return;
            }
            modal.style.display = 'flex';
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
            if (e && e.currentTarget) {
                const rect = e.currentTarget.getBoundingClientRect();
                const isRightSidebar = e.currentTarget.closest('.right-sidebar');
                let top = rect.top;
                let left = rect.left;
                if (isRightSidebar) {
                    left = rect.left - 330; 
                } else {
                    top = rect.bottom + 5;
                    left = rect.left + (rect.width / 2) - 160;
                }
                if (top + 280 > window.innerHeight) top = window.innerHeight - 290;
                if (top < 10) top = 10;
                if (left + 330 > window.innerWidth) left = window.innerWidth - 340;
                if (left < 10) left = 10;
                modal.style.top = top + 'px';
                modal.style.left = left + 'px';
                modal.style.transform = 'none';
            } else {
                modal.style.top = '50%';
                modal.style.left = '50%';
                modal.style.transform = 'translate(-50%, -50%)';
            }
        }

        function isReturnsHistoryVoidRow(r) {
            if (!r) return false;
            if (r.type === 'void') return true;
            var note = String(r.note || '');
            return note.indexOf('Deleted Invoice') !== -1 || note.indexOf('ژێبرنا وەسڵ') !== -1;
        }

        function applyReturnsHistoryModeTitle(modal, mode) {
            if (!modal) return;
            var isVoid = mode === 'void';
            var titleText = isVoid
                ? ((typeof t === 'function') ? t('voided_history_title') : 'مێژوویا ژێبرنێ')
                : ((typeof t === 'function') ? t('returns_history_title') : 'مێژوویا زڤڕاندنێ');
            var h2 = modal.querySelector('h2');
            if (!h2) return;
            var span = h2.querySelector('[data-i18n], span');
            var icon = h2.querySelector('i');
            if (icon) {
                icon.className = isVoid ? 'fas fa-trash-alt' : 'fas fa-history';
                icon.style.marginLeft = '10px';
                icon.style.color = isVoid ? '#94a3b8' : '';
            }
            if (span) {
                span.setAttribute('data-i18n', isVoid ? 'voided_history_title' : 'returns_history_title');
                span.textContent = titleText;
            } else {
                h2.innerHTML = '<i class="fas ' + (isVoid ? 'fa-trash-alt' : 'fa-history') + '" style="margin-left:10px;"></i> ' + titleText;
            }
            h2.style.color = isVoid ? '#94a3b8' : 'var(--warning)';
            var shell = modal.querySelector('.hist-shell, .modal-content, .glass-card');
            if (shell) {
                shell.setAttribute('data-accent', isVoid ? 'slate' : 'warning');
                shell.classList.add('hist-shell');
            }
            modal.classList.add('hist-modal');
        }

        function applyReturnsHistoryDatePreset(preset) {
            if (typeof applyGlobalDatePreset === 'function') {
                applyGlobalDatePreset(preset, 'returns', function() {
                    if (typeof renderReturnsReport === 'function') renderReturnsReport();
                });
            } else {
                var end = new Date();
                var start = new Date();
                if (preset === '1d') {
                    /* today only */
                } else if (preset === '90d') {
                    start.setDate(start.getDate() - 90);
                } else if (preset === '1y') {
                    start.setFullYear(start.getFullYear() - 1);
                } else if (preset === 'all') {
                    start = new Date(2000, 0, 1);
                } else {
                    start.setDate(start.getDate() - 90);
                }
                var fmt = (typeof salesHistoryDateFmt === 'function')
                    ? salesHistoryDateFmt
                    : function (d) {
                        var pad = function (n) { return String(n).padStart(2, '0'); };
                        return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
                    };
                var sEl = document.getElementById('date-start-returns');
                var eEl = document.getElementById('date-end-returns');
                if (sEl) sEl.value = fmt(start);
                if (eEl) eEl.value = fmt(end);
                if (typeof renderReturnsReport === 'function') renderReturnsReport();
            }
        }
        window.applyReturnsHistoryDatePreset = applyReturnsHistoryDatePreset;

        function openReturnsHistoryOption(mode) {
            window._returnsHistoryMode = (mode === 'void') ? 'void' : 'returns';
            let modal = document.getElementById('returns-history-modal');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'returns-history-modal';
                modal.className = 'modal-overlay hist-modal';
                modal.style.zIndex = '10000';
                var filtersHtml = histFiltersWrap(
                    '<input type="date" id="date-start-returns" class="input-std" onchange="renderReturnsReport()">' +
                    '<span style="color:var(--text-muted); white-space:nowrap; font-size:0.8rem;">تا</span>' +
                    '<input type="date" id="date-end-returns" class="input-std" onchange="renderReturnsReport()">' +
                    '<button type="button" class="btn btn-sm btn-dark" onclick="resetDateFilter(\'returns\', renderReturnsReport)" title="پاککردنەوە"><i class="fas fa-times"></i></button>' +
                    '<div class="hist-presets">' +
                    '<span>مەودا:</span>' +
                    '<button type="button" class="btn btn-sm btn-dark" onclick="applyReturnsHistoryDatePreset(\'1d\')">١ ڕۆژ</button>' +
                    '<button type="button" class="btn btn-sm btn-dark" onclick="applyReturnsHistoryDatePreset(\'90d\')">٩٠ ڕۆژ</button>' +
                    '<button type="button" class="btn btn-sm btn-dark" onclick="applyReturnsHistoryDatePreset(\'1y\')">١ ساڵ</button>' +
                    '<button type="button" class="btn btn-sm btn-dark" onclick="applyReturnsHistoryDatePreset(\'all\')">هەموو</button>' +
                    '</div>'
                );
                modal.innerHTML = histListShellHtml({
                    id: 'returns-history-modal',
                    closeId: 'returns-history-modal',
                    titleI18n: 'returns_history_title',
                    titleFb: 'مێژوویا زڤڕاندنێ',
                    icon: 'fas fa-history',
                    accent: 'warning',
                    filtersHtml: filtersHtml,
                    bodyId: 'returns-history-modal-content',
                    bodyHtml: '<div style="text-align:center; padding:40px;"><i class="fas fa-spinner fa-spin fa-2x" style="color:var(--warning);"></i><p style="margin-top:15px; color:var(--text-muted);" data-i18n="msg_data_loading">داتا باردەکرێت…</p></div>'
                });
                document.body.appendChild(modal);
                if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
                modal.addEventListener('click', function(e) {
                    if (e.target === modal) modal.style.display = 'none';
                });
            } else {
                modal.classList.add('hist-modal');
                var shell = modal.querySelector('.modal-content, .glass-card');
                if (shell) shell.classList.add('hist-shell');
            }
            applyReturnsHistoryModeTitle(modal, window._returnsHistoryMode);

            // Always start on today — wide leftover ranges make the modal feel "stuck"
            var sEl = document.getElementById('date-start-returns');
            var eEl = document.getElementById('date-end-returns');
            var todayStr = (typeof getTodayDateInputValue === 'function')
                ? getTodayDateInputValue()
                : ((typeof salesHistoryDateFmt === 'function')
                    ? salesHistoryDateFmt(new Date())
                    : new Date().toISOString().slice(0, 10));
            if (sEl) sEl.value = todayStr;
            if (eEl) eEl.value = todayStr;

            modal.style.display = 'flex';
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);

            if (window._returnsHistoryMode === 'void') {
                if (typeof loadVoidedSalesHistoryForUi === 'function') {
                    loadVoidedSalesHistoryForUi({});
                } else {
                    renderReturnsHistoryModalContent();
                }
                return;
            }

            // Date-scoped returns only — do NOT pull full sales history (was freezing UI)
            if (typeof renderReturnsReport === 'function') {
                renderReturnsReport();
            } else if (typeof fetchReturnsHistoryForUi === 'function') {
                fetchReturnsHistoryForUi({});
            } else {
                renderReturnsHistoryModalContent();
            }
        }

        function openVoidedSalesHistoryOption() {
            openReturnsHistoryOption('void');
        }

        function openSaleEditsHistoryOption() {
            var modal = document.getElementById('sale-edits-history-modal');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'sale-edits-history-modal';
                modal.className = 'modal-overlay hist-modal';
                modal.style.zIndex = '10020';
                document.body.appendChild(modal);
                modal.addEventListener('click', function (e) { if (e.target === modal) modal.style.display = 'none'; });
            } else {
                modal.classList.add('hist-modal');
            }
            var filtersHtml = histFiltersWrap(
                '<label style="font-size:0.85rem;font-weight:700;">ژ <input type="date" id="sale-edits-date-from" class="input-std" style="margin-right:4px;"></label>' +
                '<label style="font-size:0.85rem;font-weight:700;">تا <input type="date" id="sale-edits-date-to" class="input-std" style="margin-right:4px;"></label>' +
                '<button type="button" class="btn btn-sm btn-primary" onclick="if(typeof loadSaleEditsHistory==\'function\')loadSaleEditsHistory();"><i class="fas fa-sync"></i></button>'
            );
            modal.innerHTML = histListShellHtml({
                id: 'sale-edits-history-modal',
                closeId: 'sale-edits-history-modal',
                titleI18n: 'sale_edits_history_title',
                titleFb: 'مێژوویا تەعدیلی فاتورەی فرۆتنێ',
                icon: 'fas fa-pen-to-square',
                accent: 'sky',
                filtersHtml: filtersHtml,
                bodyId: 'sale-edits-history-body',
                bodyHtml: '<div style="text-align:center;padding:36px;color:var(--text-muted);"><i class="fas fa-spinner fa-spin fa-2x"></i></div>'
            });
            var todayStr = (typeof getTodayDateInputValue === 'function')
                ? getTodayDateInputValue()
                : (function () {
                    var d = new Date();
                    var pad = function (n) { return String(n).padStart(2, '0'); };
                    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
                })();
            var fromEl = document.getElementById('sale-edits-date-from');
            var toEl = document.getElementById('sale-edits-date-to');
            if (fromEl && !fromEl.value) fromEl.value = todayStr;
            if (toEl && !toEl.value) toEl.value = todayStr;
            modal.style.display = 'flex';
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
            loadSaleEditsHistory();
        }

        function loadSaleEditsHistory() {
            var body = document.getElementById('sale-edits-history-body');
            if (!body) return;
            body.innerHTML = '<div style="text-align:center;padding:36px;color:var(--text-muted);"><i class="fas fa-spinner fa-spin fa-2x"></i></div>';
            var fromEl = document.getElementById('sale-edits-date-from');
            var toEl = document.getElementById('sale-edits-date-to');
            var q = 'action=get_sale_edits_history&limit=400';
            if (fromEl && fromEl.value) q += '&date_from=' + encodeURIComponent(fromEl.value);
            if (toEl && toEl.value) q += '&date_to=' + encodeURIComponent(toEl.value);
            var url = (typeof window.posRouterUrl === 'function') ? window.posRouterUrl(q) : ('?' + q);
            var actionLbl = function (at) {
                var map = {
                    sale_cart_replace: (typeof t === 'function') ? t('sale_edit_action_cart') : 'تەعدیل ژ سەبەتێ',
                    sale_line_edit: (typeof t === 'function') ? t('sale_edit_action_line') : 'دەستکاری ئایتم',
                    sale_line_add: (typeof t === 'function') ? t('sale_edit_action_add') : 'زیادکرنا ئایتم',
                    sale_line_delete: (typeof t === 'function') ? t('sale_edit_action_del') : 'سڕینەوەی ئایتم'
                };
                return map[at] || at;
            };
            fetch(url, { credentials: 'same-origin' })
                .then(function (r) { return r.json().catch(function () { return {}; }); })
                .then(function (data) {
                    if (!data || data.status !== 'success') {
                        body.innerHTML = '<p style="text-align:center;color:var(--danger);padding:24px;">' +
                            escapeHtml((data && data.message) || ((typeof t === 'function') ? t('sale_edits_history_err') : 'نەهاتە بارکرن')) + '</p>';
                        return;
                    }
                    var edits = Array.isArray(data.edits) ? data.edits : [];
                    window._saleEditsHistoryCache = edits;
                    if (!edits.length) {
                        body.innerHTML = histEmptyHtml((typeof t === 'function') ? t('sale_edits_history_empty') : 'هێشتا تەعدیلێن تۆمارکرى نینن.');
                        return;
                    }
                    var fmtMoney = function (n) {
                        if (n == null || n === '') return '—';
                        return (typeof formatCurrency === 'function') ? formatCurrency(n) : String(n);
                    };
                    var viewTitle = (typeof t === 'function') ? t('sale_edit_view') : 'بینینی تەعدیل';
                    var fmtChangesCell = function (ed) {
                        var ch = Array.isArray(ed.changes) ? ed.changes.filter(Boolean) : [];
                        if (!ch.length) {
                            return '<span style="color:var(--text-muted);">' +
                                escapeHtml((typeof t === 'function') ? t('sale_edit_changes_legacy') : 'تەنها گۆڕانی کۆ (پێش تۆمارکرنا وردەکاریێ)') +
                                '</span>';
                        }
                        var show = ch.slice(0, 3).map(function (line) {
                            return '<div style="margin:2px 0;line-height:1.45;">• ' + escapeHtml(String(line)) + '</div>';
                        }).join('');
                        if (ch.length > 3) {
                            show += '<div style="opacity:.7;font-size:0.8rem;">+' + (ch.length - 3) + '…</div>';
                        }
                        return show;
                    };
                    var rows = edits.map(function (ed, idx) {
                        var sid = parseInt(ed.sale_id, 10) || 0;
                        var openBtn = '<button type="button" class="btn btn-sm btn-info" onclick="viewSaleEditDetail(' + idx + ')" title="' +
                            escapeHtml(viewTitle) + '"><i class="fas fa-eye"></i>' +
                            (sid > 0 ? (' #' + sid) : '') + '</button>';
                        return '<tr>' +
                            '<td style="white-space:nowrap;">' + escapeHtml(String(ed.created_at || '')) + '</td>' +
                            '<td style="font-weight:800;color:#0ea5e9;">' + escapeHtml(actionLbl(ed.action_type)) + '</td>' +
                            '<td>' + openBtn + '</td>' +
                            '<td>' + escapeHtml(String(ed.user || '')) + '</td>' +
                            '<td style="direction:ltr;text-align:left;">' + fmtMoney(ed.old_total) + ' → <b>' + fmtMoney(ed.new_total) + '</b></td>' +
                            '<td style="font-size:0.84rem;max-width:320px;">' + fmtChangesCell(ed) + '</td>' +
                            '</tr>';
                    }).join('');
                    var th = '<th>' + escapeHtml((typeof t === 'function') ? t('sale_edit_at') : 'کات') + '</th>' +
                        '<th>' + escapeHtml((typeof t === 'function') ? t('sale_edit_type') : 'جۆر') + '</th>' +
                        '<th>' + escapeHtml((typeof t === 'function') ? t('sale_edit_invoice') : 'وەسڵ') + '</th>' +
                        '<th>' + escapeHtml((typeof t === 'function') ? t('sale_edit_by') : 'ژ لایێ') + '</th>' +
                        '<th>' + escapeHtml((typeof t === 'function') ? t('sale_edit_total_change') : 'کۆ') + '</th>' +
                        '<th>' + escapeHtml((typeof t === 'function') ? t('sale_edit_details') : 'وردەکاری') + '</th>';
                    body.innerHTML = histTableWrap(th, '', rows, 6);
                })
                .catch(function () {
                    body.innerHTML = '<p style="text-align:center;color:var(--danger);padding:24px;">' +
                        escapeHtml((typeof t === 'function') ? t('sale_edits_history_err') : 'نەهاتە بارکرن') + '</p>';
                });
        }

        function viewSaleEditDetail(idx) {
            idx = parseInt(idx, 10);
            var edits = window._saleEditsHistoryCache || [];
            var ed = edits[idx];
            if (!ed) return;
            var actionLbl = function (at) {
                var map = {
                    sale_cart_replace: (typeof t === 'function') ? t('sale_edit_action_cart') : 'تەعدیل ژ سەبەتێ',
                    sale_line_edit: (typeof t === 'function') ? t('sale_edit_action_line') : 'دەستکاری ئایتم',
                    sale_line_add: (typeof t === 'function') ? t('sale_edit_action_add') : 'زیادکرنا ئایتم',
                    sale_line_delete: (typeof t === 'function') ? t('sale_edit_action_del') : 'سڕینەوەی ئایتم'
                };
                return map[at] || at;
            };
            var fmtMoney = function (n) {
                if (n == null || n === '') return '—';
                return (typeof formatCurrency === 'function') ? formatCurrency(n) : String(n);
            };
            var sid = parseInt(ed.sale_id, 10) || 0;
            var modal = document.getElementById('sale-edit-view-modal');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'sale-edit-view-modal';
                modal.className = 'modal-overlay';
                modal.style.zIndex = '10030';
                document.body.appendChild(modal);
                modal.addEventListener('click', function (e) { if (e.target === modal) modal.style.display = 'none'; });
            }
            var previewBtn = sid > 0
                ? ('<button type="button" class="btn btn-sm btn-dark" onclick="if(typeof previewSaleInvoice===\'function\')previewSaleInvoice(' + sid + ');' +
                    'else if(typeof reprintBill===\'function\')reprintBill(' + sid + ');"><i class="fas fa-print"></i> ' +
                    escapeHtml((typeof t === 'function') ? t('sale_edit_preview_invoice') : 'پێشبینینی وەسڵ') + '</button>')
                : '';
            var adjPrintBtn = sid > 0
                ? ('<button type="button" class="btn btn-sm btn-warning" onclick="if(typeof printSaleAdjustmentSlip===\'function\')printSaleAdjustmentSlip(' + sid + ',[window._saleEditsHistoryCache[' + idx + ']]);"><i class="fas fa-file-invoice"></i> ' +
                    escapeHtml((typeof t === 'function') ? t('sale_hist_print_adjust') : 'چاپا تەعدیلێ') + '</button>')
                : '';
            var ch = Array.isArray(ed.changes) ? ed.changes.filter(Boolean) : [];
            var changesHtml;
            if (ch.length) {
                changesHtml = '<ul style="margin:0;padding:0 18px 0 0;list-style:disc;">' +
                    ch.map(function (line) {
                        return '<li style="margin:6px 0;line-height:1.5;">' + escapeHtml(String(line)) + '</li>';
                    }).join('') + '</ul>';
            } else {
                changesHtml = '<span style="font-size:0.92rem;color:var(--text-muted);">' +
                    escapeHtml((typeof t === 'function') ? t('sale_edit_changes_legacy') : 'تەنها گۆڕانی کۆ تۆمارکراوە (پێش نوێکرنا وردەکاریێ)') +
                    (ed.details ? ('<br><br>' + escapeHtml(String(ed.details))) : '') +
                    '</span>';
            }
            var titleHtml = escapeHtml((typeof t === 'function') ? t('sale_edit_view') : 'بینینی تەعدیل') +
                (sid > 0 ? (' <span style="opacity:.75;">#' + sid + '</span>') : '');
            modal.classList.add('hist-detail-modal');
            modal.innerHTML = histDetailShellHtml({
                id: 'sale-edit-view-modal',
                closeId: 'sale-edit-view-modal',
                accent: 'sky',
                icon: 'fas fa-eye',
                titleHtml: titleHtml,
                bodyHtml:
                    histDetailRow((typeof t === 'function') ? t('sale_edit_at') : 'کات', escapeHtml(String(ed.created_at || '—'))) +
                    histDetailRow((typeof t === 'function') ? t('sale_edit_type') : 'جۆر', '<b style="color:#0ea5e9;">' + escapeHtml(actionLbl(ed.action_type)) + '</b>') +
                    histDetailRow((typeof t === 'function') ? t('sale_edit_by') : 'ژ لایێ', escapeHtml(String(ed.user || '—'))) +
                    histDetailRow((typeof t === 'function') ? t('sale_edit_total_change') : 'کۆ',
                        '<span dir="ltr">' + escapeHtml(fmtMoney(ed.old_total)) + ' → <b>' + escapeHtml(fmtMoney(ed.new_total)) + '</b></span>') +
                    '<div style="padding:12px 0 4px;border-bottom:1px solid var(--border);">' +
                    '<div style="font-weight:800;color:var(--text-muted);margin-bottom:8px;">' +
                    escapeHtml((typeof t === 'function') ? t('sale_edit_item_changes') : 'گۆڕانێن ئایتم') + '</div>' +
                    changesHtml + '</div>' +
                    '<div style="display:flex;gap:8px;justify-content:flex-start;margin-top:16px;flex-wrap:wrap;">' + previewBtn + adjPrintBtn +
                    '<button type="button" class="btn btn-sm btn-secondary" onclick="document.getElementById(\'sale-edit-view-modal\').style.display=\'none\'">' +
                    escapeHtml((typeof t === 'function') ? t('btn_close') : 'داخستن') + '</button></div>'
            });
            modal.style.display = 'flex';
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
        }

        window.openSaleEditsHistoryOption = openSaleEditsHistoryOption;
        window.loadSaleEditsHistory = loadSaleEditsHistory;
        window.viewSaleEditDetail = viewSaleEditDetail;

        function openPurchaseEditsHistoryOption() {
            var modal = document.getElementById('purchase-edits-history-modal');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'purchase-edits-history-modal';
                modal.className = 'modal-overlay hist-modal';
                modal.style.zIndex = '10020';
                document.body.appendChild(modal);
                modal.addEventListener('click', function (e) { if (e.target === modal) modal.style.display = 'none'; });
            } else {
                modal.classList.add('hist-modal');
            }
            var filtersHtml = histFiltersWrap(
                '<label style="font-size:0.85rem;font-weight:700;">ژ <input type="date" id="purchase-edits-date-from" class="input-std" style="margin-right:4px;"></label>' +
                '<label style="font-size:0.85rem;font-weight:700;">تا <input type="date" id="purchase-edits-date-to" class="input-std" style="margin-right:4px;"></label>' +
                '<button type="button" class="btn btn-sm btn-primary" onclick="if(typeof loadPurchaseEditsHistory==\'function\')loadPurchaseEditsHistory();"><i class="fas fa-sync"></i></button>'
            );
            modal.innerHTML = histListShellHtml({
                id: 'purchase-edits-history-modal',
                closeId: 'purchase-edits-history-modal',
                titleI18n: 'purchase_edits_history_title',
                titleFb: 'مێژوویا تەعدیلی فاتورەی کڕینێ',
                icon: 'fas fa-pen-to-square',
                accent: 'amber',
                filtersHtml: filtersHtml,
                bodyId: 'purchase-edits-history-body',
                bodyHtml: '<div style="text-align:center;padding:36px;color:var(--text-muted);"><i class="fas fa-spinner fa-spin fa-2x"></i></div>'
            });
            var todayStr = (typeof getTodayDateInputValue === 'function')
                ? getTodayDateInputValue()
                : (function () {
                    var d = new Date();
                    var pad = function (n) { return String(n).padStart(2, '0'); };
                    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
                })();
            var fromEl = document.getElementById('purchase-edits-date-from');
            var toEl = document.getElementById('purchase-edits-date-to');
            if (fromEl && !fromEl.value) fromEl.value = todayStr;
            if (toEl && !toEl.value) toEl.value = todayStr;
            modal.style.display = 'flex';
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
            loadPurchaseEditsHistory();
        }

        function loadPurchaseEditsHistory() {
            var body = document.getElementById('purchase-edits-history-body');
            if (!body) return;
            body.innerHTML = '<div style="text-align:center;padding:36px;color:var(--text-muted);"><i class="fas fa-spinner fa-spin fa-2x"></i></div>';
            var fromEl = document.getElementById('purchase-edits-date-from');
            var toEl = document.getElementById('purchase-edits-date-to');
            var q = 'action=get_purchase_edits_history&limit=400';
            if (fromEl && fromEl.value) q += '&date_from=' + encodeURIComponent(fromEl.value);
            if (toEl && toEl.value) q += '&date_to=' + encodeURIComponent(toEl.value);
            var url = (typeof window.posRouterUrl === 'function') ? window.posRouterUrl(q) : ('?' + q);
            var actionLbl = function (at) {
                var map = {
                    purchase_cart_replace: (typeof t === 'function') ? t('purchase_edit_action_cart') : 'تەعدیل ژ سەبەتێ',
                    purchase_line_edit: (typeof t === 'function') ? t('purchase_edit_action_line') : 'دەستکاری ئایتم',
                    purchase_line_add: (typeof t === 'function') ? t('purchase_edit_action_add') : 'زیادکرنا ئایتم',
                    purchase_line_delete: (typeof t === 'function') ? t('purchase_edit_action_del') : 'سڕینەوەی ئایتم'
                };
                return map[at] || at;
            };
            fetch(url, { credentials: 'same-origin' })
                .then(function (r) { return r.json().catch(function () { return {}; }); })
                .then(function (data) {
                    if (!data || data.status !== 'success') {
                        body.innerHTML = '<p style="text-align:center;color:var(--danger);padding:24px;">' +
                            escapeHtml((data && data.message) || ((typeof t === 'function') ? t('purchase_edits_history_err') : 'نەهاتە بارکرن')) + '</p>';
                        return;
                    }
                    var edits = Array.isArray(data.edits) ? data.edits : [];
                    window._purchaseEditsHistoryCache = edits;
                    if (!edits.length) {
                        body.innerHTML = histEmptyHtml((typeof t === 'function') ? t('purchase_edits_history_empty') : 'هێشتا تەعدیلێن تۆمارکرى نینن.');
                        return;
                    }
                    var fmtMoney = function (n) {
                        if (n == null || n === '') return '—';
                        return (typeof formatCurrency === 'function') ? formatCurrency(n) : String(n);
                    };
                    var viewTitle = (typeof t === 'function') ? t('purchase_edit_view') : 'بینینی تەعدیل';
                    var fmtChangesCell = function (ed) {
                        var ch = Array.isArray(ed.changes) ? ed.changes.filter(Boolean) : [];
                        if (!ch.length) {
                            return '<span style="color:var(--text-muted);">' +
                                escapeHtml((typeof t === 'function') ? t('purchase_edit_changes_legacy') : 'تەنها گۆڕانی کۆ (پێش تۆمارکرنا وردەکاریێ)') +
                                '</span>';
                        }
                        var show = ch.slice(0, 3).map(function (line) {
                            return '<div style="margin:2px 0;line-height:1.45;">• ' + escapeHtml(String(line)) + '</div>';
                        }).join('');
                        if (ch.length > 3) {
                            show += '<div style="opacity:.7;font-size:0.8rem;">+' + (ch.length - 3) + '…</div>';
                        }
                        return show;
                    };
                    var rows = edits.map(function (ed, idx) {
                        var tid = String(ed.txn_id || '').trim();
                        var openBtn = '<button type="button" class="btn btn-sm btn-info" onclick="viewPurchaseEditDetail(' + idx + ')" title="' +
                            escapeHtml(viewTitle) + '"><i class="fas fa-eye"></i>' +
                            (tid ? (' #' + escapeHtml(tid)) : '') + '</button>';
                        return '<tr>' +
                            '<td style="white-space:nowrap;">' + escapeHtml(String(ed.created_at || '')) + '</td>' +
                            '<td style="font-weight:800;color:#f59e0b;">' + escapeHtml(actionLbl(ed.action_type)) + '</td>' +
                            '<td>' + openBtn + '</td>' +
                            '<td>' + escapeHtml(String(ed.user || '')) + '</td>' +
                            '<td style="direction:ltr;text-align:left;">' + fmtMoney(ed.old_total) + ' → <b>' + fmtMoney(ed.new_total) + '</b></td>' +
                            '<td style="font-size:0.84rem;max-width:320px;">' + fmtChangesCell(ed) + '</td>' +
                            '</tr>';
                    }).join('');
                    var th = '<th>' + escapeHtml((typeof t === 'function') ? t('sale_edit_at') : 'کات') + '</th>' +
                        '<th>' + escapeHtml((typeof t === 'function') ? t('sale_edit_type') : 'جۆر') + '</th>' +
                        '<th>' + escapeHtml((typeof t === 'function') ? t('sale_edit_invoice') : 'وەسڵ') + '</th>' +
                        '<th>' + escapeHtml((typeof t === 'function') ? t('sale_edit_by') : 'ژ لایێ') + '</th>' +
                        '<th>' + escapeHtml((typeof t === 'function') ? t('sale_edit_total_change') : 'کۆ') + '</th>' +
                        '<th>' + escapeHtml((typeof t === 'function') ? t('sale_edit_details') : 'وردەکاری') + '</th>';
                    body.innerHTML = histTableWrap(th, '', rows, 6);
                })
                .catch(function () {
                    body.innerHTML = '<p style="text-align:center;color:var(--danger);padding:24px;">' +
                        escapeHtml((typeof t === 'function') ? t('purchase_edits_history_err') : 'نەهاتە بارکرن') + '</p>';
                });
        }

        function viewPurchaseEditDetail(idx) {
            idx = parseInt(idx, 10);
            var edits = window._purchaseEditsHistoryCache || [];
            var ed = edits[idx];
            if (!ed) return;
            var actionLbl = function (at) {
                var map = {
                    purchase_cart_replace: (typeof t === 'function') ? t('purchase_edit_action_cart') : 'تەعدیل ژ سەبەتێ',
                    purchase_line_edit: (typeof t === 'function') ? t('purchase_edit_action_line') : 'دەستکاری ئایتم',
                    purchase_line_add: (typeof t === 'function') ? t('purchase_edit_action_add') : 'زیادکرنا ئایتم',
                    purchase_line_delete: (typeof t === 'function') ? t('purchase_edit_action_del') : 'سڕینەوەی ئایتم'
                };
                return map[at] || at;
            };
            var fmtMoney = function (n) {
                if (n == null || n === '') return '—';
                return (typeof formatCurrency === 'function') ? formatCurrency(n) : String(n);
            };
            var tid = String(ed.txn_id || '').trim();
            var modal = document.getElementById('purchase-edit-view-modal');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'purchase-edit-view-modal';
                modal.className = 'modal-overlay';
                modal.style.zIndex = '10030';
                document.body.appendChild(modal);
                modal.addEventListener('click', function (e) { if (e.target === modal) modal.style.display = 'none'; });
            }
            var previewBtn = tid
                ? ('<button type="button" class="btn btn-sm btn-dark" onclick="if(typeof viewInvoiceHistoryDetails===\'function\')viewInvoiceHistoryDetails(\'' +
                    String(tid).replace(/'/g, "\\'") + '\');"><i class="fas fa-print"></i> ' +
                    escapeHtml((typeof t === 'function') ? t('purchase_edit_preview_invoice') : 'پێشبینینی وەسڵ') + '</button>')
                : '';
            var ch = Array.isArray(ed.changes) ? ed.changes.filter(Boolean) : [];
            var changesHtml;
            if (ch.length) {
                changesHtml = '<ul style="margin:0;padding:0 18px 0 0;list-style:disc;">' +
                    ch.map(function (line) {
                        return '<li style="margin:6px 0;line-height:1.5;">' + escapeHtml(String(line)) + '</li>';
                    }).join('') + '</ul>';
            } else {
                changesHtml = '<span style="font-size:0.92rem;color:var(--text-muted);">' +
                    escapeHtml((typeof t === 'function') ? t('purchase_edit_changes_legacy') : 'تەنها گۆڕانی کۆ تۆمارکراوە (پێش نوێکرنا وردەکاریێ)') +
                    (ed.details ? ('<br><br>' + escapeHtml(String(ed.details))) : '') +
                    '</span>';
            }
            var titleHtml = escapeHtml((typeof t === 'function') ? t('purchase_edit_view') : 'بینینی تەعدیل') +
                (tid ? (' <span style="opacity:.75;">#' + escapeHtml(tid) + '</span>') : '');
            modal.classList.add('hist-detail-modal');
            modal.innerHTML = histDetailShellHtml({
                id: 'purchase-edit-view-modal',
                closeId: 'purchase-edit-view-modal',
                accent: 'amber',
                icon: 'fas fa-eye',
                titleHtml: titleHtml,
                bodyHtml:
                    histDetailRow((typeof t === 'function') ? t('sale_edit_at') : 'کات', escapeHtml(String(ed.created_at || '—'))) +
                    histDetailRow((typeof t === 'function') ? t('sale_edit_type') : 'جۆر', '<b style="color:#f59e0b;">' + escapeHtml(actionLbl(ed.action_type)) + '</b>') +
                    histDetailRow((typeof t === 'function') ? t('sale_edit_by') : 'ژ لایێ', escapeHtml(String(ed.user || '—'))) +
                    histDetailRow((typeof t === 'function') ? t('sale_edit_total_change') : 'کۆ',
                        '<span dir="ltr">' + escapeHtml(fmtMoney(ed.old_total)) + ' → <b>' + escapeHtml(fmtMoney(ed.new_total)) + '</b></span>') +
                    '<div style="padding:12px 0 4px;border-bottom:1px solid var(--border);">' +
                    '<div style="font-weight:800;color:var(--text-muted);margin-bottom:8px;">' +
                    escapeHtml((typeof t === 'function') ? t('sale_edit_item_changes') : 'گۆڕانێن ئایتم') + '</div>' +
                    changesHtml + '</div>' +
                    '<div style="display:flex;gap:8px;justify-content:flex-start;margin-top:16px;flex-wrap:wrap;">' + previewBtn +
                    '<button type="button" class="btn btn-sm btn-secondary" onclick="document.getElementById(\'purchase-edit-view-modal\').style.display=\'none\'">' +
                    escapeHtml((typeof t === 'function') ? t('btn_close') : 'داخستن') + '</button></div>'
            });
            modal.style.display = 'flex';
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
        }

        window.openPurchaseEditsHistoryOption = openPurchaseEditsHistoryOption;
        window.loadPurchaseEditsHistory = loadPurchaseEditsHistory;
        window.viewPurchaseEditDetail = viewPurchaseEditDetail;

        function openVoidedPurchaseReturnsHistoryOption() {
            var modal = document.getElementById('voided-purchase-returns-history-modal');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'voided-purchase-returns-history-modal';
                modal.className = 'modal-overlay hist-modal';
                modal.style.zIndex = '10020';
                document.body.appendChild(modal);
                modal.addEventListener('click', function (e) { if (e.target === modal) modal.style.display = 'none'; });
            } else {
                modal.classList.add('hist-modal');
            }
            var filtersHtml = histFiltersWrap(
                '<label style="font-size:0.85rem;font-weight:700;">ژ <input type="date" id="vprh-date-from" class="input-std" style="margin-right:4px;"></label>' +
                '<label style="font-size:0.85rem;font-weight:700;">تا <input type="date" id="vprh-date-to" class="input-std" style="margin-right:4px;"></label>' +
                '<button type="button" class="btn btn-sm btn-primary" onclick="if(typeof loadVoidedPurchaseReturnsHistory==\'function\')loadVoidedPurchaseReturnsHistory();"><i class="fas fa-sync"></i></button>'
            );
            modal.innerHTML = histListShellHtml({
                id: 'voided-purchase-returns-history-modal',
                closeId: 'voided-purchase-returns-history-modal',
                titleI18n: 'voided_purchase_returns_history_title',
                titleFb: 'مێژوویا ژێبرنا پسولێ',
                icon: 'fas fa-trash-alt',
                accent: 'slate',
                filtersHtml: filtersHtml,
                bodyId: 'voided-purchase-returns-history-body',
                bodyHtml: '<div style="text-align:center;padding:36px;color:var(--text-muted);"><i class="fas fa-spinner fa-spin fa-2x"></i></div>'
            });
            var todayStr = (typeof getTodayDateInputValue === 'function')
                ? getTodayDateInputValue()
                : (function () {
                    var d = new Date();
                    var pad = function (n) { return String(n).padStart(2, '0'); };
                    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
                })();
            var fromEl = document.getElementById('vprh-date-from');
            var toEl = document.getElementById('vprh-date-to');
            if (fromEl && !fromEl.value) fromEl.value = todayStr;
            if (toEl && !toEl.value) toEl.value = todayStr;
            modal.style.display = 'flex';
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
            loadVoidedPurchaseReturnsHistory();
        }

        function loadVoidedPurchaseReturnsHistory() {
            var body = document.getElementById('voided-purchase-returns-history-body');
            if (!body) return;
            body.innerHTML = '<div style="text-align:center;padding:36px;color:var(--text-muted);"><i class="fas fa-spinner fa-spin fa-2x"></i></div>';
            var fromEl = document.getElementById('vprh-date-from');
            var toEl = document.getElementById('vprh-date-to');
            var q = 'action=get_voided_purchase_invoices&scope=return&limit=400';
            if (fromEl && fromEl.value) q += '&date_from=' + encodeURIComponent(fromEl.value);
            if (toEl && toEl.value) q += '&date_to=' + encodeURIComponent(toEl.value);
            var url = (typeof window.posRouterUrl === 'function') ? window.posRouterUrl(q) : ('?' + q);
            fetch(url, { credentials: 'same-origin' })
                .then(function (r) { return r.json().catch(function () { return {}; }); })
                .then(function (data) {
                    if (!data || data.status !== 'success') {
                        body.innerHTML = '<p style="text-align:center;color:var(--danger);padding:24px;">' +
                            escapeHtml((data && data.message) || ((typeof t === 'function') ? t('voided_purchase_returns_history_err') : 'نەهاتە بارکرن')) + '</p>';
                        return;
                    }
                    var voids = Array.isArray(data.voids) ? data.voids : [];
                    window._voidedPurchaseReturnsCache = voids;
                    if (!voids.length) {
                        body.innerHTML = histEmptyHtml((typeof t === 'function') ? t('voided_purchase_returns_history_empty') : 'چ پسولێن ژێبری نینن.');
                        return;
                    }
                    var fmtMoney = function (n) {
                        if (n == null || n === '') return '—';
                        return (typeof formatCurrency === 'function') ? formatCurrency(n) : String(n);
                    };
                    var viewTitle = (typeof t === 'function') ? t('voided_purchase_return_view') : 'بینینی پسولێ ژێبری';
                    var sumTotal = 0;
                    voids.forEach(function (v) { sumTotal += parseFloat(v.total) || 0; });
                    var statsHtml = histStatsHtml([
                        { label: (typeof t === 'function') ? t('voided_purchase_returns_count') : 'ژمارا پسولێن ژێبری', value: voids.length, tone: 'slate' },
                        { label: (typeof t === 'function') ? t('voided_purchase_returns_amount') : 'کۆی پسولێن ژێبری', value: fmtMoney(sumTotal), tone: 'danger' }
                    ]);
                    var rows = voids.map(function (v, idx) {
                        var invLabel = v.supplier_invoice_number
                            ? escapeHtml(String(v.supplier_invoice_number))
                            : ('#' + escapeHtml(String(v.txn_id || '—')));
                        var openBtn = '<button type="button" class="btn btn-sm btn-info" onclick="viewVoidedPurchaseReturnDetail(' + idx + ')" title="' +
                            escapeHtml(viewTitle) + '"><i class="fas fa-eye"></i></button>';
                        return '<tr>' +
                            '<td style="white-space:nowrap;">' + escapeHtml(String(v.created_at || v.date || '')) + '</td>' +
                            '<td style="font-weight:700;color:var(--info);">' + escapeHtml(String(v.company || '—')) + '</td>' +
                            '<td>' + invLabel +
                            ' <span style="opacity:.7;font-size:0.8rem;">(' + (parseInt(v.items_count, 10) || (v.items || []).length || 0) + ')</span></td>' +
                            '<td style="font-weight:800;color:#ef4444;">' + escapeHtml(fmtMoney(v.total)) + '</td>' +
                            '<td>' + escapeHtml(String(v.user || '')) + '</td>' +
                            '<td style="text-align:center;">' + openBtn + '</td>' +
                            '</tr>';
                    }).join('');
                    var th = '<th>' + escapeHtml((typeof t === 'function') ? t('sale_edit_at') : 'کات') + '</th>' +
                        '<th>' + escapeHtml((typeof t === 'function') ? t('voided_purchase_return_company') : 'کۆمپانیا') + '</th>' +
                        '<th>' + escapeHtml((typeof t === 'function') ? t('sale_edit_invoice') : 'وەسڵ') + '</th>' +
                        '<th>' + escapeHtml((typeof t === 'function') ? t('voided_purchase_returns_amount') : 'کۆ') + '</th>' +
                        '<th>' + escapeHtml((typeof t === 'function') ? t('sale_edit_by') : 'ژ لایێ') + '</th>' +
                        '<th style="text-align:center;">' + escapeHtml((typeof t === 'function') ? t('voided_purchase_return_view') : 'بینین') + '</th>';
                    body.innerHTML = statsHtml + histTableWrap(th, '', rows, 6);
                })
                .catch(function () {
                    body.innerHTML = '<p style="text-align:center;color:var(--danger);padding:24px;">' +
                        escapeHtml((typeof t === 'function') ? t('voided_purchase_returns_history_err') : 'نەهاتە بارکرن') + '</p>';
                });
        }

        function viewVoidedPurchaseReturnDetail(idx) {
            idx = parseInt(idx, 10);
            var voids = window._voidedPurchaseReturnsCache || [];
            var v = voids[idx];
            if (!v) return;
            var fmtMoney = function (n) {
                if (n == null || n === '') return '—';
                return (typeof formatCurrency === 'function') ? formatCurrency(n) : String(n);
            };
            var modal = document.getElementById('voided-purchase-return-view-modal');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'voided-purchase-return-view-modal';
                modal.className = 'modal-overlay';
                modal.style.zIndex = '10030';
                document.body.appendChild(modal);
                modal.addEventListener('click', function (e) { if (e.target === modal) modal.style.display = 'none'; });
            }
            var items = Array.isArray(v.items) ? v.items : [];
            var itemsHtml;
            if (items.length) {
                itemsHtml = '<table class="hist-table" style="margin-top:6px;">' +
                    '<thead><tr><th>ئایتم</th><th>ژمارە</th><th>کۆ</th></tr></thead><tbody>' +
                    items.map(function (it) {
                        var qtyAbs = Math.abs(parseFloat(it.qty) || 0);
                        return '<tr>' +
                            '<td>' + escapeHtml(String(it.name || ('#' + (it.prodId || '')))) + '</td>' +
                            '<td>' + escapeHtml(String(qtyAbs)) + '</td>' +
                            '<td>' + escapeHtml(fmtMoney(it.totalCost)) + '</td></tr>';
                    }).join('') + '</tbody></table>';
            } else {
                itemsHtml = '<span style="color:var(--text-muted);">' +
                    escapeHtml((typeof t === 'function') ? t('voided_purchase_return_no_items') : 'وردەکاری ئایتمان نەهاتە پاراستن') + '</span>';
            }
            var invDisp = v.supplier_invoice_number
                ? escapeHtml(String(v.supplier_invoice_number))
                : ('#' + escapeHtml(String(v.txn_id || '—')));
            modal.classList.add('hist-detail-modal');
            modal.innerHTML = histDetailShellHtml({
                id: 'voided-purchase-return-view-modal',
                closeId: 'voided-purchase-return-view-modal',
                accent: 'slate',
                icon: 'fas fa-eye',
                title: (typeof t === 'function') ? t('voided_purchase_return_view') : 'بینینی پسولێ ژێبری',
                bodyHtml:
                    '<p class="hist-detail-hint">' + escapeHtml((typeof t === 'function') ? t('voided_purchase_return_hint') : 'ئەڤە ژێبرنا پسولێ یە — نە زڤڕاندن.') + '</p>' +
                    histDetailRow((typeof t === 'function') ? t('sale_edit_at') : 'کات', escapeHtml(String(v.created_at || '—'))) +
                    histDetailRow((typeof t === 'function') ? t('voided_purchase_return_company') : 'کۆمپانیا', escapeHtml(String(v.company || '—'))) +
                    histDetailRow((typeof t === 'function') ? t('sale_edit_invoice') : 'وەسڵ', invDisp) +
                    histDetailRow((typeof t === 'function') ? t('sale_edit_by') : 'ژ لایێ', escapeHtml(String(v.user || '—'))) +
                    histDetailRow((typeof t === 'function') ? t('voided_purchase_returns_amount') : 'کۆ', '<b style="color:#ef4444;">' + escapeHtml(fmtMoney(v.total)) + '</b>') +
                    '<div style="padding:12px 0 4px;">' +
                    '<div style="font-weight:800;color:var(--text-muted);margin-bottom:8px;">' +
                    escapeHtml((typeof t === 'function') ? t('voided_purchase_return_items') : 'ئایتمێن پسولێ ژێبری') + '</div>' +
                    itemsHtml + '</div>' +
                    '<div style="display:flex;gap:8px;justify-content:flex-start;margin-top:16px;">' +
                    '<button type="button" class="btn btn-sm btn-secondary" onclick="document.getElementById(\'voided-purchase-return-view-modal\').style.display=\'none\'">' +
                    escapeHtml((typeof t === 'function') ? t('btn_close') : 'داخستن') + '</button></div>'
            });
            modal.style.display = 'flex';
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
        }

        window.openVoidedPurchaseReturnsHistoryOption = openVoidedPurchaseReturnsHistoryOption;
        window.loadVoidedPurchaseReturnsHistory = loadVoidedPurchaseReturnsHistory;
        window.viewVoidedPurchaseReturnDetail = viewVoidedPurchaseReturnDetail;

        function openVoidedPurchasesHistoryOption() {
            openVoidedPurchaseInvoicesHistoryOption('purchase');
        }

        function openVoidedPurchaseInvoicesHistoryOption(scope) {
            scope = (scope === 'return') ? 'return' : 'purchase';
            if (scope === 'return') {
                openVoidedPurchaseReturnsHistoryOption();
                return;
            }
            var modalId = 'voided-purchases-history-modal';
            var modal = document.getElementById(modalId);
            if (!modal) {
                modal = document.createElement('div');
                modal.id = modalId;
                modal.className = 'modal-overlay hist-modal';
                modal.style.zIndex = '10020';
                document.body.appendChild(modal);
                modal.addEventListener('click', function (e) { if (e.target === modal) modal.style.display = 'none'; });
            } else {
                modal.classList.add('hist-modal');
            }
            var filtersHtml = histFiltersWrap(
                '<label style="font-size:0.85rem;font-weight:700;">ژ <input type="date" id="vph-date-from" class="input-std" style="margin-right:4px;"></label>' +
                '<label style="font-size:0.85rem;font-weight:700;">تا <input type="date" id="vph-date-to" class="input-std" style="margin-right:4px;"></label>' +
                '<button type="button" class="btn btn-sm btn-primary" onclick="if(typeof loadVoidedPurchasesHistory==\'function\')loadVoidedPurchasesHistory();"><i class="fas fa-sync"></i></button>'
            );
            modal.innerHTML = histListShellHtml({
                id: modalId,
                closeId: modalId,
                titleI18n: 'voided_purchases_history_title',
                titleFb: 'مێژوویا ژێبرنا پسولێ کڕینێ',
                icon: 'fas fa-trash-alt',
                accent: 'teal',
                filtersHtml: filtersHtml,
                bodyId: 'voided-purchases-history-body',
                bodyHtml: '<div style="text-align:center;padding:36px;color:var(--text-muted);"><i class="fas fa-spinner fa-spin fa-2x"></i></div>'
            });
            var todayStr = (typeof getTodayDateInputValue === 'function')
                ? getTodayDateInputValue()
                : (function () {
                    var d = new Date();
                    var pad = function (n) { return String(n).padStart(2, '0'); };
                    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
                })();
            var fromEl = document.getElementById('vph-date-from');
            var toEl = document.getElementById('vph-date-to');
            if (fromEl && !fromEl.value) fromEl.value = todayStr;
            if (toEl && !toEl.value) toEl.value = todayStr;
            modal.style.display = 'flex';
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
            loadVoidedPurchasesHistory();
        }

        function loadVoidedPurchasesHistory() {
            var body = document.getElementById('voided-purchases-history-body');
            if (!body) return;
            body.innerHTML = '<div style="text-align:center;padding:36px;color:var(--text-muted);"><i class="fas fa-spinner fa-spin fa-2x"></i></div>';
            var fromEl = document.getElementById('vph-date-from');
            var toEl = document.getElementById('vph-date-to');
            var q = 'action=get_voided_purchase_invoices&scope=purchase&limit=400';
            if (fromEl && fromEl.value) q += '&date_from=' + encodeURIComponent(fromEl.value);
            if (toEl && toEl.value) q += '&date_to=' + encodeURIComponent(toEl.value);
            var url = (typeof window.posRouterUrl === 'function') ? window.posRouterUrl(q) : ('?' + q);
            fetch(url, { credentials: 'same-origin' })
                .then(function (r) { return r.json().catch(function () { return {}; }); })
                .then(function (data) {
                    if (!data || data.status !== 'success') {
                        body.innerHTML = '<p style="text-align:center;color:var(--danger);padding:24px;">' +
                            escapeHtml((data && data.message) || ((typeof t === 'function') ? t('voided_purchases_history_err') : 'نەهاتە بارکرن')) + '</p>';
                        return;
                    }
                    var voids = Array.isArray(data.voids) ? data.voids : [];
                    window._voidedPurchasesCache = voids;
                    if (!voids.length) {
                        body.innerHTML = histEmptyHtml((typeof t === 'function') ? t('voided_purchases_history_empty') : 'چ پسولێن کڕینێ یێن ژێبری نینن.');
                        return;
                    }
                    var fmtMoney = function (n) {
                        if (n == null || n === '') return '—';
                        return (typeof formatCurrency === 'function') ? formatCurrency(n) : String(n);
                    };
                    var viewTitle = (typeof t === 'function') ? t('voided_purchase_view') : 'بینینی پسولێ ژێبری';
                    var sumTotal = 0;
                    voids.forEach(function (v) { sumTotal += parseFloat(v.total) || 0; });
                    var statsHtml = histStatsHtml([
                        { label: (typeof t === 'function') ? t('voided_purchases_count') : 'ژمارا پسولێن ژێبری', value: voids.length, tone: 'teal' },
                        { label: (typeof t === 'function') ? t('voided_purchases_amount') : 'کۆی پسولێن ژێبری', value: fmtMoney(sumTotal), tone: 'teal' }
                    ]);
                    var rows = voids.map(function (v, idx) {
                        var invLabel = v.supplier_invoice_number
                            ? escapeHtml(String(v.supplier_invoice_number))
                            : ('#' + escapeHtml(String(v.txn_id || '—')));
                        var undoLbl = (typeof t === 'function') ? t('btn_undo_void') : 'پەشێمان بم';
                        var txnEsc = String(v.txn_id || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'");
                        var auditId = parseInt(v.audit_id || v.id, 10) || 0;
                        var undoBtn = '<button type="button" class="btn btn-sm btn-success" onclick="event.stopPropagation();if(typeof restoreVoidedPurchase===\'function\')restoreVoidedPurchase(\'' + txnEsc + '\',' + auditId + ')" title="' + escapeHtml(undoLbl) + '"><i class="fas fa-undo"></i> ' + escapeHtml(undoLbl) + '</button>';
                        var openBtn = '<button type="button" class="btn btn-sm btn-info" onclick="viewVoidedPurchaseDetail(' + idx + ')" title="' +
                            escapeHtml(viewTitle) + '"><i class="fas fa-eye"></i></button>';
                        return '<tr>' +
                            '<td style="white-space:nowrap;">' + escapeHtml(String(v.created_at || v.date || '')) + '</td>' +
                            '<td style="font-weight:700;color:var(--info);">' + escapeHtml(String(v.company || '—')) + '</td>' +
                            '<td>' + invLabel +
                            ' <span style="opacity:.7;font-size:0.8rem;">(' + (parseInt(v.items_count, 10) || (v.items || []).length || 0) + ')</span></td>' +
                            '<td style="font-weight:800;color:#14b8a6;">' + escapeHtml(fmtMoney(v.total)) + '</td>' +
                            '<td>' + escapeHtml(String(v.user || '')) + '</td>' +
                            '<td style="text-align:center;"><div style="display:flex;gap:6px;justify-content:center;flex-wrap:wrap;">' + undoBtn + openBtn + '</div></td>' +
                            '</tr>';
                    }).join('');
                    var th = '<th>' + escapeHtml((typeof t === 'function') ? t('sale_edit_at') : 'کات') + '</th>' +
                        '<th>' + escapeHtml((typeof t === 'function') ? t('voided_purchase_company') : 'کۆمپانیا') + '</th>' +
                        '<th>' + escapeHtml((typeof t === 'function') ? t('sale_edit_invoice') : 'وەسڵ') + '</th>' +
                        '<th>' + escapeHtml((typeof t === 'function') ? t('voided_purchases_amount') : 'کۆ') + '</th>' +
                        '<th>' + escapeHtml((typeof t === 'function') ? t('sale_edit_by') : 'ژ لایێ') + '</th>' +
                        '<th style="text-align:center;">' + escapeHtml(viewTitle) + '</th>';
                    body.innerHTML = statsHtml + histTableWrap(th, '', rows, 6);
                })
                .catch(function () {
                    body.innerHTML = '<p style="text-align:center;color:var(--danger);padding:24px;">' +
                        escapeHtml((typeof t === 'function') ? t('voided_purchases_history_err') : 'نەهاتە بارکرن') + '</p>';
                });
        }

        function viewVoidedPurchaseDetail(idx) {
            idx = parseInt(idx, 10);
            var voids = window._voidedPurchasesCache || [];
            var v = voids[idx];
            if (!v) return;
            var fmtMoney = function (n) {
                if (n == null || n === '') return '—';
                return (typeof formatCurrency === 'function') ? formatCurrency(n) : String(n);
            };
            var modal = document.getElementById('voided-purchase-view-modal');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'voided-purchase-view-modal';
                modal.className = 'modal-overlay';
                modal.style.zIndex = '10030';
                document.body.appendChild(modal);
                modal.addEventListener('click', function (e) { if (e.target === modal) modal.style.display = 'none'; });
            }
            var items = Array.isArray(v.items) ? v.items : [];
            var itemsHtml;
            if (items.length) {
                itemsHtml = '<table class="hist-table" style="margin-top:6px;">' +
                    '<thead><tr><th>ئایتم</th><th>ژمارە</th><th>کۆ</th></tr></thead><tbody>' +
                    items.map(function (it) {
                        var qtyAbs = Math.abs(parseFloat(it.qty) || 0);
                        return '<tr>' +
                            '<td>' + escapeHtml(String(it.name || ('#' + (it.prodId || '')))) + '</td>' +
                            '<td>' + escapeHtml(String(qtyAbs)) + '</td>' +
                            '<td>' + escapeHtml(fmtMoney(it.totalCost)) + '</td></tr>';
                    }).join('') + '</tbody></table>';
            } else {
                itemsHtml = '<span style="color:var(--text-muted);">' +
                    escapeHtml((typeof t === 'function') ? t('voided_purchase_no_items') : 'وردەکاری ئایتمان نەهاتە پاراستن') + '</span>';
            }
            var invDisp = v.supplier_invoice_number
                ? escapeHtml(String(v.supplier_invoice_number))
                : ('#' + escapeHtml(String(v.txn_id || '—')));
            modal.classList.add('hist-detail-modal');
            modal.innerHTML = histDetailShellHtml({
                id: 'voided-purchase-view-modal',
                closeId: 'voided-purchase-view-modal',
                accent: 'teal',
                icon: 'fas fa-eye',
                title: (typeof t === 'function') ? t('voided_purchase_view') : 'بینینی پسولێ ژێبری',
                bodyHtml:
                    '<p class="hist-detail-hint" style="background:rgba(20,184,166,0.12);">' +
                    escapeHtml((typeof t === 'function') ? t('voided_purchase_hint') : 'ئەڤە ژێبرنا پسولێ کڕینێ یە.') + '</p>' +
                    histDetailRow((typeof t === 'function') ? t('sale_edit_at') : 'کات', escapeHtml(String(v.created_at || '—'))) +
                    histDetailRow((typeof t === 'function') ? t('voided_purchase_company') : 'کۆمپانیا', escapeHtml(String(v.company || '—'))) +
                    histDetailRow((typeof t === 'function') ? t('sale_edit_invoice') : 'وەسڵ', invDisp) +
                    histDetailRow((typeof t === 'function') ? t('sale_edit_by') : 'ژ لایێ', escapeHtml(String(v.user || '—'))) +
                    histDetailRow((typeof t === 'function') ? t('voided_purchases_amount') : 'کۆ', '<b style="color:#14b8a6;">' + escapeHtml(fmtMoney(v.total)) + '</b>') +
                    '<div style="padding:12px 0 4px;">' +
                    '<div style="font-weight:800;color:var(--text-muted);margin-bottom:8px;">' +
                    escapeHtml((typeof t === 'function') ? t('voided_purchase_items') : 'ئایتمێن پسولێ ژێبری') + '</div>' +
                    itemsHtml + '</div>' +
                    '<div style="display:flex;gap:8px;justify-content:flex-start;margin-top:16px;flex-wrap:wrap;">' +
                    '<button type="button" class="btn btn-sm btn-success" onclick="document.getElementById(\'voided-purchase-view-modal\').style.display=\'none\';if(typeof restoreVoidedPurchase===\'function\')restoreVoidedPurchase(\'' +
                    String(v.txn_id || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'") + '\',' + (parseInt(v.audit_id || v.id, 10) || 0) + ')">' +
                    '<i class="fas fa-undo"></i> ' + escapeHtml((typeof t === 'function') ? t('btn_undo_void') : 'پەشێمان بم') + '</button>' +
                    '<button type="button" class="btn btn-sm btn-secondary" onclick="document.getElementById(\'voided-purchase-view-modal\').style.display=\'none\'">' +
                    escapeHtml((typeof t === 'function') ? t('btn_close') : 'داخستن') + '</button></div>'
            });
            modal.style.display = 'flex';
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
        }

        window.openVoidedPurchasesHistoryOption = openVoidedPurchasesHistoryOption;
        window.loadVoidedPurchasesHistory = loadVoidedPurchasesHistory;
        window.viewVoidedPurchaseDetail = viewVoidedPurchaseDetail;

        /**
         * Light local void scan — never walk full sales+archive (freezes large shops).
         * Optional dateFrom/dateTo (YYYY-MM-DD) keep the scan tiny.
         */
        function collectLocalVoidedSalesRows(dateFrom, dateTo) {
            var map = {};
            var from = dateFrom ? String(dateFrom).slice(0, 10) : '';
            var to = dateTo ? String(dateTo).slice(0, 10) : '';
            function inRange(s) {
                if (!from && !to) return true;
                var d = String(s.date || s.created_at || '').slice(0, 10);
                if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) return true;
                if (from && d < from) return false;
                if (to && d > to) return false;
                return true;
            }
            function add(s) {
                if (!s) return;
                if (!(s.is_returned == 1 || s.is_returned === true || s.is_returned === '1')) return;
                if (!inRange(s)) return;
                var id = s.id;
                if (id == null || id === '') return;
                map[String(id)] = {
                    id: id,
                    date: s.date || s.created_at,
                    created_at: s.created_at || s.date,
                    items: s.items,
                    total: s.total,
                    note: 'ژێبرنا وەسڵێ (Void)',
                    cashier: s.cashier,
                    type: 'void',
                    sale_id: id,
                    payment_method: s.payment_method || 'cash',
                    is_returned: 1
                };
            }
            // Prefer already-loaded history pages / recent db.sales only — not archive
            (window._voidedSalesHistoryPage || []).forEach(add);
            (window._salesHistoryPage || []).forEach(add);
            if (typeof db !== 'undefined' && db && Array.isArray(db.sales)) {
                var sales = db.sales;
                var maxScan = 800;
                var start = Math.max(0, sales.length - maxScan);
                for (var i = start; i < sales.length; i++) add(sales[i]);
            }
            return Object.keys(map).map(function(k) { return map[k]; });
        }

        function openPurchaseOptionsModal(e) {
            e = e || window.event;
            if (e) {
                e.preventDefault();
                e.stopPropagation();
            }

            let posModal = document.getElementById('pos-options-popover');
            if (posModal) posModal.style.display = 'none';
            let retModal = document.getElementById('returns-options-popover');
            if (retModal) retModal.style.display = 'none';
            let purchRetModal = document.getElementById('purchase-returns-options-popover');
            if (purchRetModal) purchRetModal.style.display = 'none';

            let modal = document.getElementById('purchase-options-popover');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'purchase-options-popover';
                modal.style.position = 'absolute';
                modal.style.zIndex = '10000';
                modal.style.background = 'var(--card)';
                modal.style.border = '1px solid var(--border)';
                modal.style.borderRadius = '12px';
                modal.style.boxShadow = '0 8px 30px rgba(0,0,0,0.15)';
                modal.style.padding = '15px';
                modal.style.minWidth = '320px';
                modal.style.display = 'flex';
                modal.style.flexDirection = 'column';
                modal.style.gap = '10px';
                modal.innerHTML = `
                    <div style="font-size:0.95rem; color:var(--text); padding-bottom:10px; border-bottom:1px solid var(--border); margin-bottom:5px; font-weight:bold; text-align:center;">
                        <i class="fas fa-shopping-basket" style="margin-left:5px;"></i> <span data-i18n="popover_purchase_menu_title">مینیویا کڕینێ</span>
                    </div>
                    <div style="display:grid; grid-template-columns: repeat(2, 1fr); gap:12px;">
                        <div data-shortcut-id="purchase" draggable="true" style="cursor:pointer; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:20px 10px; background:var(--card); border:2px solid var(--border); border-radius:14px; transition:all 0.2s ease;" onmouseover="this.style.borderColor='var(--success)'; this.style.transform='translateY(-3px)'; this.style.boxShadow='0 6px 15px rgba(16, 185, 129, 0.15)';" onmouseout="this.style.borderColor='var(--border)'; this.style.transform='none'; this.style.boxShadow='none';" onclick="document.getElementById('purchase-options-popover').style.display='none'; nav('purchase');">
                            <i class="fas fa-shopping-basket" style="font-size:2.2rem; margin-bottom:12px; color:var(--success);"></i>
                            <span style="font-size:0.9rem; font-weight:bold; color:var(--text);" data-i18n="popover_screen_purchase">شاشا کڕینێ</span>
                        </div>
                        <div data-perm="view_purchase_history">
                            <div data-shortcut-id="purchase-history" draggable="true" style="cursor:pointer; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:20px 10px; background:var(--card); border:2px solid var(--border); border-radius:14px; transition:all 0.2s ease;" onmouseover="this.style.borderColor='var(--warning)'; this.style.transform='translateY(-3px)'; this.style.boxShadow='0 6px 15px rgba(245, 158, 11, 0.15)';" onmouseout="this.style.borderColor='var(--border)'; this.style.transform='none'; this.style.boxShadow='none';" onclick="document.getElementById('purchase-options-popover').style.display='none'; openPurchaseHistoryCompanyModal(event);">
                                <i class="fas fa-history" style="font-size:2.2rem; margin-bottom:12px; color:var(--warning);"></i>
                                <span style="font-size:0.9rem; font-weight:bold; color:var(--text);" data-i18n="popover_history_purchase">مێژوویا کڕینێ</span>
                            </div>
                        </div>
                        <div data-shortcut-id="companies-inventory" draggable="true" style="cursor:pointer; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:20px 10px; background:var(--card); border:2px solid var(--border); border-radius:14px; transition:all 0.2s ease;" onmouseover="this.style.borderColor='var(--info)'; this.style.transform='translateY(-3px)'; this.style.boxShadow='0 6px 15px rgba(14, 74, 255, 0.15)';" onmouseout="this.style.borderColor='var(--border)'; this.style.transform='none'; this.style.boxShadow='none';" onclick="document.getElementById('purchase-options-popover').style.display='none'; window._companyProfileDefaultTab='inventory'; nav('companies');">
                            <i class="fas fa-building" style="font-size:2.2rem; margin-bottom:12px; color:var(--info);"></i>
                            <span style="font-size:0.9rem; font-weight:bold; color:var(--text);" data-i18n="popover_suppliers">کۆمپانیا</span>
                        </div>
                        <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; padding:20px 10px; background:var(--input-bg); border:2px dashed var(--border); border-radius:14px; opacity:0.5; cursor:not-allowed;">
                            <i class="fas fa-plus" style="font-size:1.5rem; margin-bottom:12px; color:var(--text-muted);"></i>
                            <span style="font-size:0.8rem; color:var(--text-muted); font-weight:bold;" data-i18n="popover_menu_empty">ڤالا</span>
                        </div>
                    </div>
                `;
                document.body.appendChild(modal);
                document.addEventListener('click', function(evt) {
                    if (modal.style.display === 'flex' && !modal.contains(evt.target)) {
                        modal.style.display = 'none';
                    }
                });
            }
            if (modal.style.display === 'flex') {
                modal.style.display = 'none';
                return;
            }
            modal.style.display = 'flex';
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
            if (e && e.currentTarget) {
                const rect = e.currentTarget.getBoundingClientRect();
                const isRightSidebar = e.currentTarget.closest('.right-sidebar');
                let top = rect.top;
                let left = rect.left;
                if (isRightSidebar) {
                    left = rect.left - 330; 
                } else {
                    top = rect.bottom + 5;
                    left = rect.left + (rect.width / 2) - 160;
                }
                if (top + 280 > window.innerHeight) top = window.innerHeight - 290;
                if (top < 10) top = 10;
                if (left + 330 > window.innerWidth) left = window.innerWidth - 340;
                if (left < 10) left = 10;
                modal.style.top = top + 'px';
                modal.style.left = left + 'px';
                modal.style.transform = 'none';
            } else {
                modal.style.top = '50%';
                modal.style.left = '50%';
                modal.style.transform = 'translate(-50%, -50%)';
            }
        }

        function openPurchaseReturnsOptionsModal(e) {
            e = e || window.event;
            if (e) {
                e.preventDefault();
                e.stopPropagation();
            }

            let posModal = document.getElementById('pos-options-popover');
            if (posModal) posModal.style.display = 'none';
            let retModal = document.getElementById('returns-options-popover');
            if (retModal) retModal.style.display = 'none';
            let purchModal = document.getElementById('purchase-options-popover');
            if (purchModal) purchModal.style.display = 'none';

            let modal = document.getElementById('purchase-returns-options-popover');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'purchase-returns-options-popover';
                modal.style.position = 'absolute';
                modal.style.zIndex = '10000';
                modal.style.background = 'var(--card)';
                modal.style.border = '1px solid var(--border)';
                modal.style.borderRadius = '12px';
                modal.style.boxShadow = '0 8px 30px rgba(0,0,0,0.15)';
                modal.style.padding = '15px';
                modal.style.minWidth = '320px';
                modal.style.display = 'flex';
                modal.style.flexDirection = 'column';
                modal.style.gap = '10px';
                modal.innerHTML = `
                    <div style="font-size:0.95rem; color:var(--text); padding-bottom:10px; border-bottom:1px solid var(--border); margin-bottom:5px; font-weight:bold; text-align:center;">
                        <i class="fas fa-undo" style="margin-left:5px;"></i> <span data-i18n="popover_purchase_returns_menu_title">مینیویا زڤڕاندنا کڕینێ</span>
                    </div>
                    <div style="display:grid; grid-template-columns: repeat(2, 1fr); gap:12px;">
                        <div data-shortcut-id="purchase-returns" draggable="true" style="cursor:pointer; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:20px 10px; background:var(--card); border:2px solid var(--border); border-radius:14px; transition:all 0.2s ease;" onmouseover="this.style.borderColor='var(--danger)'; this.style.transform='translateY(-3px)'; this.style.boxShadow='0 6px 15px rgba(220, 38, 38, 0.15)';" onmouseout="this.style.borderColor='var(--border)'; this.style.transform='none'; this.style.boxShadow='none';" onclick="document.getElementById('purchase-returns-options-popover').style.display='none'; nav('purchase-returns');">
                            <i class="fas fa-undo" style="font-size:2.2rem; margin-bottom:12px; color:var(--danger);"></i>
                            <span style="font-size:0.9rem; font-weight:bold; color:var(--text);" data-i18n="popover_screen_purchase_returns">زڤڕاندنا کڕینێ</span>
                        </div>
                        <div data-shortcut-id="companies-inventory" draggable="true" style="cursor:pointer; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:20px 10px; background:var(--card); border:2px solid var(--border); border-radius:14px; transition:all 0.2s ease;" onmouseover="this.style.borderColor='var(--info)'; this.style.transform='translateY(-3px)'; this.style.boxShadow='0 6px 15px rgba(14, 74, 255, 0.15)';" onmouseout="this.style.borderColor='var(--border)'; this.style.transform='none'; this.style.boxShadow='none';" onclick="document.getElementById('purchase-returns-options-popover').style.display='none'; window._companyProfileDefaultTab='inventory'; nav('companies');">
                            <i class="fas fa-building" style="font-size:2.2rem; margin-bottom:12px; color:var(--info);"></i>
                            <span style="font-size:0.9rem; font-weight:bold; color:var(--text);" data-i18n="popover_suppliers">کۆمپانیا</span>
                        </div>
                        <div data-perm="view_purchase_history">
                            <div data-shortcut-id="purchase-returns-history" draggable="true" style="cursor:pointer; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:20px 10px; background:var(--card); border:2px solid var(--border); border-radius:14px; transition:all 0.2s ease;" onmouseover="this.style.borderColor='var(--purple)'; this.style.transform='translateY(-3px)'; this.style.boxShadow='0 6px 15px rgba(168, 85, 247, 0.15)';" onmouseout="this.style.borderColor='var(--border)'; this.style.transform='none'; this.style.boxShadow='none';" onclick="document.getElementById('purchase-returns-options-popover').style.display='none'; openPurchaseReturnsHistoryCompanyModal(event);">
                                <i class="fas fa-receipt" style="font-size:2.2rem; margin-bottom:12px; color:var(--purple);"></i>
                                <span style="font-size:0.9rem; font-weight:bold; color:var(--text);" data-i18n="popover_history_purchase_returns">مێژوویا زڤڕاندنا کڕینێ</span>
                            </div>
                        </div>
                    </div>
                `;
                document.body.appendChild(modal);
                document.addEventListener('click', function(evt) {
                    if (modal.style.display === 'flex' && !modal.contains(evt.target)) {
                        modal.style.display = 'none';
                    }
                });
            }
            if (modal.style.display === 'flex') {
                modal.style.display = 'none';
                return;
            }
            modal.style.display = 'flex';
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
            if (e && e.currentTarget) {
                const rect = e.currentTarget.getBoundingClientRect();
                const isRightSidebar = e.currentTarget.closest('.right-sidebar');
                let top = rect.top;
                let left = rect.left;
                if (isRightSidebar) {
                    left = rect.left - 330; 
                } else {
                    top = rect.bottom + 5;
                    left = rect.left + (rect.width / 2) - 160;
                }
                if (top + 280 > window.innerHeight) top = window.innerHeight - 290;
                if (top < 10) top = 10;
                if (left + 330 > window.innerWidth) left = window.innerWidth - 340;
                if (left < 10) left = 10;
                modal.style.top = top + 'px';
                modal.style.left = left + 'px';
                modal.style.transform = 'none';
            } else {
                modal.style.top = '50%';
                modal.style.left = '50%';
                modal.style.transform = 'translate(-50%, -50%)';
            }
        }

        function renderReturnsHistoryModalContent() {
            const container = document.getElementById('returns-history-modal-content')
                || document.getElementById('returns-history-list');
            if(!container) return;
            
            const mode = window._returnsHistoryMode || 'returns';
            const returnsBase = window._fullReturnsHistory || (typeof db !== 'undefined' && db && db.returns) || [];
            let sorted;
            if (mode === 'void') {
                if (Array.isArray(window._voidedSalesHistoryPage)) {
                    sorted = window._voidedSalesHistoryPage.slice();
                } else {
                    var vp = (typeof getVoidedHistoryDateParams === 'function') ? getVoidedHistoryDateParams() : {};
                    sorted = (typeof collectLocalVoidedSalesRows === 'function')
                        ? collectLocalVoidedSalesRows(vp.date_from, vp.date_to)
                        : [];
                }
                sorted.sort((a, b) => new Date(b.date || b.created_at) - new Date(a.date || a.created_at));
            } else {
                sorted = (returnsBase || []).filter(r => !isReturnsHistoryVoidRow(r)).sort((a, b) => new Date(b.date) - new Date(a.date));
            }

            const emptyMsg = mode === 'void'
                ? ((typeof t === 'function') ? t('voided_history_empty') : 'چ وەسڵێن ژێبری نینن.')
                : ((typeof t === 'function') ? t('returns_history_empty') : 'چ زڤڕاندن نینن.');
            const countLabel = mode === 'void'
                ? ((typeof t === 'function') ? t('voided_history_count') : 'ژمارا وەسڵێن ژێبری')
                : ((typeof t === 'function') ? t('returns_history_count') : 'ژمارا زڤڕاندنان');
            const amountLabel = mode === 'void'
                ? ((typeof t === 'function') ? t('voided_history_amount') : 'کۆی وەسڵێن ژێبری')
                : ((typeof t === 'function') ? t('returns_history_amount') : 'کۆی پارە زڤڕاندی');

            if (sorted.length === 0) {
                container.innerHTML = histEmptyHtml(emptyMsg);
                return;
            }

            const totalCount = sorted.length;
            const totalAmount = sorted.reduce((s, r) => s + (parseFloat(r.total) || 0), 0);
            const statsHtml = histStatsHtml([
                { label: countLabel, value: totalCount, tone: mode === 'void' ? 'slate' : 'accent' },
                { label: amountLabel, valueHtml: escapeHtml(formatCurrency(totalAmount)) + ' ' + (typeof getCurrencySymbol === 'function' ? getCurrencySymbol() : ''), tone: 'danger' }
            ]);

            let html = statsHtml + `
            <table class="hist-table report-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>بەروار</th>
                        <th>وەسڵ</th>
                        <th>ئایتم</th>
                        <th>تێبینی</th>
                        <th style="text-align:left;">کۆم</th>
                        <th style="text-align:center;">کردار</th>
                    </tr>
                </thead>
                <tbody>`;

            html += sorted.slice(0, 100).map(r => {
                const itemCount = r.items ? (Array.isArray(r.items) ? r.items.length : 0) : 0;
                const itemNames = (r.items && Array.isArray(r.items)) ? r.items.map(i => i.name).slice(0, 2).join(', ') + (itemCount > 2 ? '...' : '') : '-';
                const isVoid = isReturnsHistoryVoidRow(r);
                const badge = isVoid ? '<span style="background:#ef4444; color:white; padding:4px 10px; border-radius:8px; font-size:0.75rem;">ژێبراو</span>' : '<span style="background:#10b981; color:white; padding:4px 10px; border-radius:8px; font-size:0.75rem;">زڤڕاندن</span>';
                const saleLink = (r.sale_id != null && r.sale_id !== '' && parseInt(r.sale_id, 10) > 0) ? '<span style="background:var(--input-bg); border:1px solid var(--border); padding:4px 10px; border-radius:8px; font-size:0.85rem; font-family:Rudaw,sans-serif;" title="وەسڵا سەرەتایی">#'+ parseInt(r.sale_id, 10) +'</span>' : (isVoid ? '<span style="background:var(--input-bg); border:1px solid var(--border); padding:4px 10px; border-radius:8px; font-size:0.85rem;">#'+ r.id +'</span>' : '<span style="color:var(--text-muted);">—</span>');
                return `
                <tr style="${isVoid ? 'background:rgba(239,68,68,0.04);' : ''}" onmouseover="this.style.background='var(--input-bg)'" onmouseout="this.style.background='${isVoid ? 'rgba(239,68,68,0.04)' : 'transparent'}'">
                    <td><b>#${r.id}</b></td>
                    <td style="font-size:0.85rem; color:var(--text-muted);">${new Date(r.date).toLocaleString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ')}</td>
                    <td>${saleLink}</td>
                    <td title="${r.items ? escapeHtml((Array.isArray(r.items) ? r.items : []).map(i=>i.name).join(', ')) : ''}">${escapeHtml(itemNames)} <span style="background:var(--input-bg); padding:2px 6px; border-radius:6px; font-size:0.8rem; margin-right:5px; border:1px solid var(--border);">${itemCount}</span></td>
                    <td style="max-width:180px; overflow:hidden; text-overflow:ellipsis; font-size:0.85rem;">${escapeHtml((isVoid ? 'ژێبرنا وەسڵێ (Void)' : (r.note || '')).slice(0, 50))}${(!isVoid && r.note && r.note.length > 50) ? '...' : ''}</td>
                    <td style="color:#ef4444; font-weight:900; font-size:1.05rem; text-align: left;">${formatCurrency(r.total)}</td>
                    <td style="text-align: center;">
                        <div style="display:flex; gap:6px; justify-content:center; align-items:center; flex-wrap:wrap;">
                        ${badge}
                        ${isVoid ? `<button type="button" class="btn btn-sm btn-success" onclick="event.stopPropagation();if(typeof restoreVoidedSale==='function')restoreVoidedSale(${parseInt(r.id, 10)})" title="${escapeHtml((typeof t === 'function') ? t('btn_undo_void') : 'پەشێمان بم')}"><i class="fas fa-undo"></i> ${escapeHtml((typeof t === 'function') ? t('btn_undo_void') : 'پەشێمان بم')}</button>` : ''}
                        <button class="btn btn-sm btn-info" onclick="showReturnDetails(${r.id})" title="وردەکاری"><i class="fas fa-eye"></i></button>
                        <button class="btn btn-sm btn-dark" onclick="printReturnReceipt(${r.id})" title="چاپ"><i class="fas fa-print"></i></button>
                        </div>
                    </td>
                </tr>`;
            }).join('');

            html += '</tbody></table>';
            container.innerHTML = html;
            // Keep list in sync for showReturnDetails / print
            if (mode === 'void') {
                window._returnsHistoryPage = sorted.slice();
                window._voidedSalesHistoryPage = sorted.slice();
            }
            var statusEl = document.getElementById('returns-history-more-status');
            if (statusEl) {
                statusEl.textContent = totalCount
                    ? ('پیشاندراو: ' + Math.min(totalCount, 100) + (totalCount > 100 ? ' / ' + totalCount : '') + ' — کۆتایی')
                    : '—';
            }
        }

        function getVoidedHistoryDateParams() {
            var sEl = document.getElementById('date-start-returns');
            var eEl = document.getElementById('date-end-returns');
            var today = (typeof getTodayDateInputValue === 'function')
                ? getTodayDateInputValue()
                : ((typeof salesHistoryDateFmt === 'function')
                    ? salesHistoryDateFmt(new Date())
                    : new Date().toISOString().slice(0, 10));
            return {
                date_from: sEl && sEl.value ? sEl.value : today,
                date_to: eEl && eEl.value ? eEl.value : today
            };
        }

        function loadVoidedSalesHistoryForUi(opts) {
            opts = opts || {};
            var container = document.getElementById('returns-history-modal-content')
                || document.getElementById('returns-history-list');
            if (container && !opts.append) {
                container.innerHTML = '<div style="text-align:center; padding:40px;"><i class="fas fa-spinner fa-spin fa-2x" style="color:#94a3b8;"></i>' +
                    '<p style="margin-top:12px;color:var(--text-muted);font-size:0.85rem;">١ ڕۆژ — باردەکرێت…</p></div>';
            }
            var dates = getVoidedHistoryDateParams();
            var seq = (window._voidedSalesHistoryFetchSeq = (window._voidedSalesHistoryFetchSeq || 0) + 1);
            var params = new URLSearchParams();
            params.set('action', 'get_voided_sales_history');
            params.set('date_from', dates.date_from);
            params.set('date_to', dates.date_to);
            params.set('limit', '200');
            params.set('offset', '0');
            var q = params.toString();
            var url = (typeof window.posRouterUrl === 'function') ? window.posRouterUrl(q) : ('?' + q);

            function finishWithRows(rows, hasMore) {
                if (seq !== window._voidedSalesHistoryFetchSeq) return;
                rows = Array.isArray(rows) ? rows.slice() : [];
                rows.sort(function(a, b) {
                    return new Date(b.date || b.created_at) - new Date(a.date || a.created_at);
                });
                window._voidedSalesHistoryPage = rows;
                window._returnsHistoryPage = rows;
                window._returnsHistoryHasMore = !!hasMore;
                renderReturnsHistoryModalContent();
            }

            // Paint light local voids immediately so spinner is not stuck waiting on server
            try {
                var localQuick = collectLocalVoidedSalesRows(dates.date_from, dates.date_to);
                if (localQuick && localQuick.length) {
                    finishWithRows(localQuick, false);
                }
            } catch (_eLoc) {}

            var ctrl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
            var timedOut = false;
            var toId = setTimeout(function () {
                timedOut = true;
                if (ctrl) try { ctrl.abort(); } catch (_eAb) {}
            }, 4000);
            var fetchOpts = { credentials: 'same-origin', cache: 'no-store' };
            if (ctrl) fetchOpts.signal = ctrl.signal;

            fetch(url, fetchOpts)
                .then(function(r) { return r.json().catch(function() { return { status: 'error' }; }); })
                .then(function(data) {
                    clearTimeout(toId);
                    if (seq !== window._voidedSalesHistoryFetchSeq) return;
                    if (data && data.status === 'success' && Array.isArray(data.voids)) {
                        // Trust server for the selected day — no full local merge
                        finishWithRows(data.voids, !!data.has_more);
                        return;
                    }
                    if (!(window._voidedSalesHistoryPage && window._voidedSalesHistoryPage.length)) {
                        finishWithRows(collectLocalVoidedSalesRows(dates.date_from, dates.date_to), false);
                    }
                })
                .catch(function() {
                    clearTimeout(toId);
                    if (seq !== window._voidedSalesHistoryFetchSeq) return;
                    if (window._voidedSalesHistoryPage && window._voidedSalesHistoryPage.length) return;
                    finishWithRows(collectLocalVoidedSalesRows(dates.date_from, dates.date_to), false);
                    if (timedOut && typeof showToast === 'function') {
                        showToast('سێرڤەر خاو بوو — داتای ناوخۆیی.', 'warning');
                    }
                });
        }

        window.openPosOptionsModal = openPosOptionsModal;
        window.openReturnsHistoryOption = openReturnsHistoryOption;
        window.openVoidedSalesHistoryOption = openVoidedSalesHistoryOption;
        window.loadVoidedSalesHistoryForUi = loadVoidedSalesHistoryForUi;
        window.collectLocalVoidedSalesRows = collectLocalVoidedSalesRows;
        window.renderReturnsHistoryModalContent = renderReturnsHistoryModalContent;
        window.openPurchaseOptionsModal = openPurchaseOptionsModal;
        window.openPurchaseReturnsOptionsModal = openPurchaseReturnsOptionsModal;
        window.openPurchaseHistoryCompanyModal = openPurchaseHistoryCompanyModal;

        function openPurchaseReturnsHistoryCompanyModal(e) {
            if (currentUser && currentUser.role !== 'admin' && typeof checkPermission === 'function' && !checkPermission('view_purchase_history')) {
                if (typeof logSecurityEvent === 'function') logSecurityEvent('access_denied', 'Attempted to open Purchase Returns History without permission');
                nav('access-denied');
                return;
            }
            e = e || window.event;
            if (e) {
                e.preventDefault();
                e.stopPropagation();
            }

            let p1 = document.getElementById('purchase-options-popover'); if(p1) p1.style.display = 'none';
            let p2 = document.getElementById('purchase-returns-options-popover'); if(p2) p2.style.display = 'none';

            let modal = document.getElementById('purchase-returns-history-company-modal');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'purchase-returns-history-company-modal';
                modal.className = 'modal-overlay hist-modal';
                modal.style.zIndex = '10005';
                document.body.appendChild(modal);
                modal.onclick = function(evt) {
                    if (evt.target === modal) modal.style.display = 'none';
                };
            } else {
                modal.classList.add('hist-modal');
            }
            
            let compOptions = '<option value="">🏢 هەمی کۆمپانیا (All)</option>';
            if(window.db && window.db.companies) {
                let sorted = window.db.companies.slice().sort((a,b) => (a.name||'').localeCompare(b.name||''));
                compOptions += sorted.map(c => `<option value="${escapeHtml(c.name)}">${escapeHtml(c.name)}</option>`).join('');
            }

            var filtersHtml = histFiltersWrap(
                '<select id="gprh-company" class="input-std" style="flex:1; min-width:180px;" onchange="renderGlobalPurchaseReturnsHistory()">' + compOptions + '</select>' +
                '<select id="gprh-date-preset" class="input-std" style="flex:1; min-width:150px;" onchange="if(typeof applyGlobalDatePreset===\'function\') applyGlobalDatePreset(this.value, \'gprh\', function(){ loadGlobalPurchaseReturnsHistory(renderGlobalPurchaseReturnsHistory); }); else { toggleGprhCustomDates(); loadGlobalPurchaseReturnsHistory(renderGlobalPurchaseReturnsHistory); }">' +
                '<option value="today" selected>☀️ ئەڤرۆ (Today)</option>' +
                '<option value="week">📅 حەفتییا بۆری (Last 7 Days)</option>' +
                '<option value="month">🌙 ئەڤ هەیڤە (This Month)</option>' +
                '<option value="90d">📅 ٩٠ ڕۆژ (Last 90 Days)</option>' +
                '<option value="1y">📅 ١ ساڵ (1 Year)</option>' +
                '<option value="all">📅 هەمی دەم (All Time)</option>' +
                '<option value="custom">✍️ دیارکرنا دەمی (Custom)</option></select>' +
                '<input type="date" id="gprh-start" class="input-std" style="flex:1; min-width:130px; display:none;" onchange="if(typeof renderGlobalPurchaseReturnsHistory===\'function\') renderGlobalPurchaseReturnsHistory();">' +
                '<input type="date" id="gprh-end" class="input-std" style="flex:1; min-width:130px; display:none;" onchange="if(typeof renderGlobalPurchaseReturnsHistory===\'function\') renderGlobalPurchaseReturnsHistory();">'
            );
            var th = '<th>بەروار</th><th>کۆمپانیا</th><th>وەسڵ / ئایتم</th><th style="text-align:left;">کۆم</th><th style="text-align:center;">کردار</th>';
            modal.innerHTML = histListShellHtml({
                id: 'purchase-returns-history-company-modal',
                closeId: 'purchase-returns-history-company-modal',
                titleFb: 'مێژوویا زڤڕاندنا کڕینێ (Purchase Returns History)',
                icon: 'fas fa-receipt',
                accent: 'purple',
                filtersHtml: filtersHtml,
                bodyId: 'gprh-body-wrap',
                bodyHtml: histTableWrap(th, 'gprh-tbody', null, 5)
            });

            modal.style.display = 'flex';

            var startLoad = function () {
                if (typeof window.loadGlobalPurchaseReturnsHistory === 'function') {
                    window.loadGlobalPurchaseReturnsHistory(function () {
                        if (typeof window.renderGlobalPurchaseReturnsHistory === 'function') {
                            window.renderGlobalPurchaseReturnsHistory();
                        }
                    });
                }
            };
            if (typeof applyGlobalDatePreset === 'function') {
                applyGlobalDatePreset('today', 'gprh', startLoad);
            } else {
                startLoad();
            }
        }

        window.loadGlobalPurchaseReturnsHistory = function (done) {
            var tbody = document.getElementById('gprh-tbody');
            if (tbody) {
                tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;padding:40px;"><i class="fas fa-spinner fa-spin fa-2x"></i></td></tr>';
            }
            var params = new URLSearchParams();
            params.set('action', 'get_purchase_returns_history');
            var url = (typeof window.posRouterUrl === 'function') ? window.posRouterUrl(params.toString()) : ('?' + params.toString());
            return fetch(url)
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    var rows = (data && data.status === 'success' && Array.isArray(data.purchase_returns))
                        ? data.purchase_returns
                        : ((window.db && window.db.purchase_returns) || []);
                    window._fullPurchaseReturnsHistory = rows;
                    if (window.db) window.db.purchase_returns = rows;
                    if (typeof done === 'function') done();
                })
                .catch(function () {
                    window._fullPurchaseReturnsHistory = (window.db && window.db.purchase_returns) || [];
                    if (typeof done === 'function') done();
                });
        };

        window.renderGlobalPurchaseReturnsHistory = function() {
            const tbody = document.getElementById('gprh-tbody');
            if (!tbody) return;
            
            const compEl = document.getElementById('gprh-company');
            const compFilter = compEl ? compEl.value : '';

            const receipts = window._fullPurchaseReturnsHistory
                || (window.db && window.db.purchase_returns)
                || [];
            const grouped = {};

            receipts.forEach(function (pr) {
                if (!pr) return;
                if (!purchaseHistDateInRange(pr.date, 'gprh')) return;
                var company = String(pr.company_name || pr.company || '');
                if (compFilter && company !== compFilter) return;
                var txnId = String(pr.transaction_id || ('PR_' + (pr.id || '')));
                var items = Array.isArray(pr.items) ? pr.items : [];
                grouped[txnId] = {
                    txnId: pr.transaction_id || txnId,
                    date: pr.date,
                    type: 'return',
                    total: parseFloat(pr.total) || 0,
                    itemsCount: items.length || (parseInt(pr.items_count, 10) || 1),
                    items: items,
                    invNum: pr.supplier_invoice_number || '',
                    company: company,
                    fromReceipt: true
                };
            });

            const baseList = window._fullPurchaseHistory
                || (typeof window.posGetSuppliesPool === 'function' ? window.posGetSuppliesPool() : null)
                || (window.db && window.db.supplies)
                || [];
            baseList.forEach(function (s) {
                if (!isPurchaseReturnSupplyLine(s)) return;
                if (!purchaseHistDateInRange(s.date, 'gprh')) return;
                if (compFilter && s.company !== compFilter) return;
                const key = s.transaction_id || ('OLD_' + s.date + '_' + s.prodId);
                if (grouped[key] && grouped[key].fromReceipt) return;
                if (!grouped[key]) grouped[key] = { txnId: s.transaction_id, date: s.date, type: 'return', total: 0, itemsCount: 0, items: [], invNum: s.supplier_invoice_number, company: s.company };
                if (!grouped[key].invNum && s.supplier_invoice_number) grouped[key].invNum = s.supplier_invoice_number;
                grouped[key].total += (parseFloat(s.totalCost) || 0);
                grouped[key].itemsCount++;
                grouped[key].items.push(s);
            });
            
            const invoices = Object.values(grouped).sort((a, b) => new Date(b.date) - new Date(a.date));

            if (invoices.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; padding:40px; color:var(--text-muted);"><i class="fas fa-inbox" style="font-size:3rem; opacity:0.3; margin-bottom:15px; display:block;"></i>چ وەسڵێن زڤڕاندنێ نینن د ڤی دەمی دا.</td></tr>';
                return;
            }

            tbody.innerHTML = invoices.map(inv => {
                const invFallback = (typeof resolveCompanyInvoiceDisplayNumber === 'function') ? resolveCompanyInvoiceDisplayNumber(inv.invNum, inv.txnId) : (inv.txnId || '---');
                const invDisplay = inv.invNum ? `<b style="font-size:1.05rem;">${escapeHtml(String(inv.invNum))}</b>` : `<small style="background:var(--input-bg); border:1px solid var(--border); padding:2px 6px; border-radius:6px; font-family:Rudaw,sans-serif;">#${escapeHtml(String(invFallback))}</small>`;
                var txnEsc = String(inv.txnId || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'");
                var compId = ((window.db && window.db.companies || []).find(function (c) { return c.name === inv.company; }) || {}).id || 0;
                
                return `<tr style="border-bottom:1px solid var(--border); transition:0.2s;" onmouseover="this.style.background='var(--input-bg)'" onmouseout="this.style.background='transparent'">
                    <td style="padding:15px 12px; color:var(--text-muted); font-size:0.9rem;">${new Date(inv.date).toLocaleDateString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ')}</td>
                    <td style="padding:15px 12px; font-weight:bold; color:var(--info); cursor:pointer;" onclick="document.getElementById('purchase-returns-history-company-modal').style.display='none'; window._companyProfileDefaultTab='history'; nav('companies'); setTimeout(()=>openCompanyProfile(${compId}), 100);" title="چوون بۆ پڕۆفایلێ کۆمپانیێ"><i class="fas fa-building" style="margin-left:5px; opacity:0.7;"></i> ${escapeHtml(inv.company)}</td>
                    <td style="padding:15px 12px;">${invDisplay} <span style="background:var(--card); border:1px solid var(--border); padding:2px 8px; border-radius:6px; font-size:0.8rem; margin-right:8px;">${inv.itemsCount} ئایتم</span></td>
                    <td style="padding:15px 12px; font-weight:900; color:#0E4AFF; font-size:1.1rem; text-align:left;">${(typeof formatTxnMoney === 'function') ? formatTxnMoney(inv.total, (inv.items && inv.items[0]) ? inv.items[0] : inv) : formatCurrency(inv.total, (typeof fxUsdRateFormatOpts === 'function') ? fxUsdRateFormatOpts((inv.items && inv.items[0]) ? inv.items[0] : inv) : undefined)}</td>
                    <td style="padding:15px 12px; text-align:center; white-space:nowrap; display:flex; gap:6px; justify-content:center;">
                        <button class="btn btn-sm btn-dark" onclick="viewInvoiceHistoryDetails('${txnEsc}')" title="بینین"><i class="fas fa-eye"></i></button>
                        <button class="btn btn-sm btn-danger" onclick="voidPurchaseInvoice('${txnEsc}'); setTimeout(function(){ if(typeof loadGlobalPurchaseReturnsHistory==='function') loadGlobalPurchaseReturnsHistory(renderGlobalPurchaseReturnsHistory); else renderGlobalPurchaseReturnsHistory(); }, 500);" title="ژێبرن"><i class="fas fa-trash"></i></button>
                    </td>
                </tr>`;
            }).join('');
        };
        window.openPurchaseReturnsHistoryCompanyModal = openPurchaseReturnsHistoryCompanyModal;

        // Inject CSS to beautify the payment toggle and hide the ugly checkbox
        (function() {
            if (document.getElementById('payment-toggle-styles')) return;
            var style = document.createElement('style');
            style.id = 'payment-toggle-styles';
            style.innerHTML = `
                .search-inline-toggle {
                    display: inline-flex !important;
                    align-items: center;
                    justify-content: center;
                    background: var(--input-bg);
                    border: 1px solid var(--border);
                    border-radius: 8px;
                    padding: 0 12px;
                    min-height: 42px;
                    cursor: pointer;
                    transition: all 0.2s ease;
                    color: var(--text-muted);
                    font-weight: bold;
                    gap: 8px;
                    user-select: none;
                }
                .search-inline-toggle input[type="checkbox"] {
                    display: none !important;
                }
                .search-inline-toggle.active-toggle {
                    background: rgba(16, 185, 129, 0.15) !important;
                    border-color: #10b981 !important;
                    color: #10b981 !important;
                }
                .search-inline-toggle i {
                    font-size: 1.2rem;
                }
            `;
            document.head.appendChild(style);
        })();

        window.syncPaymentToggles = function() {
            if (!db || !db.settings) return;
            var isChecked = (typeof isAutoPaymentModalEnabled === 'function')
                ? !!isAutoPaymentModalEnabled()
                : (db.settings.showPaymentModal === true);
            document.querySelectorAll('.search-inline-toggle input[type="checkbox"]').forEach(function(el) {
                if (el.checked !== isChecked) el.checked = isChecked;
                var parent = el.closest('.pos-payment-wallet-btn') || el.closest('.search-inline-toggle');
                if (parent) {
                    parent.style.display = isChecked ? '' : 'none';
                    if (isChecked) parent.classList.add('active-toggle');
                    else parent.classList.remove('active-toggle');
                    parent.title = isChecked
                        ? ((typeof t === 'function') ? t('payment_modal_toggle_on_hint') : 'شاشا پارەدانێ چالاکە')
                        : ((typeof t === 'function') ? t('payment_modal_toggle_off') : 'شاشا پارەدانێ نەچالاکە');
                }
            });
            document.querySelectorAll('.pos-payment-wallet-btn').forEach(function(btn) {
                btn.style.display = isChecked ? '' : 'none';
                if (isChecked) btn.classList.add('active-toggle');
                else btn.classList.remove('active-toggle');
                btn.title = (typeof t === 'function') ? t('settings_t_payment_modal') : 'شاشة الدفع';
            });
            var mainSet = document.getElementById('set-show-payment-modal');
            if (mainSet && mainSet.checked !== isChecked) mainSet.checked = isChecked;
        };

        document.addEventListener('change', function(e) {
            if (e.target && e.target.closest && e.target.closest('.search-inline-toggle')) {
                if (!db) return;
                if (!db.settings) db.settings = {};
                db.settings.showPaymentModal = e.target.checked;
                window.syncPaymentToggles();
                if (typeof saveSettings === 'function') saveSettings().catch(function(){});
            }
        });

