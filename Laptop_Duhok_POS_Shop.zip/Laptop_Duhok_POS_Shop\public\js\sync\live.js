// sync/live.js — live data, login, shift
        // --- NEW: SMART SYNC FUNCTION ---
        let isPolling = false;

        /** Apply server stock qty patches and refresh visible inventory UI. */
        function applyServerStockUpdates(stockArray, options) {
            options = options || {};
            if (!stockArray || !Array.isArray(stockArray) || !db) return;
            if (!options.force && (window._isCartSaving || window._posCartOperationLock || window._posScanQueueBusy)) return;
            if (!Array.isArray(db.warehouse_stock)) db.warehouse_stock = [];
            stockArray.forEach(function(s) {
                var reservedHere = (typeof getReservedPiecesForProduct === 'function')
                    ? (getReservedPiecesForProduct(s.id) || 0)
                    : 0;
                var p = db.products.find(function(x) { return String(x.id) === String(s.id); });
                if (p) {
                    var syncedQty = typeof normalizeQtyForProduct === 'function'
                        ? normalizeQtyForProduct(p, s.qty, db.settings.allowNegativeStock)
                        : s.qty;
                    syncedQty = (parseFloat(syncedQty) || 0) + reservedHere;
                    p.qty = db.settings.allowNegativeStock ? (syncedQty || 0) : Math.max(0, syncedQty || 0);
                }
                var pid = Number(s.id);
                var whId = Number(s.warehouse_id) || 0;
                if (!whId && typeof getSaleWarehouseId === 'function') whId = Number(getSaleWarehouseId()) || 0;
                if (!whId && typeof getDefaultWarehouseId === 'function') whId = Number(getDefaultWarehouseId()) || 0;
                if (whId && pid) {
                    var nextWhQty = (s.warehouse_qty != null && s.warehouse_qty !== '')
                        ? parseFloat(s.warehouse_qty)
                        : parseFloat(s.qty);
                    if (!isFinite(nextWhQty)) nextWhQty = 0;
                    nextWhQty += reservedHere;
                    if (!(db.settings && (db.settings.allowNegativeStock == true || db.settings.allowNegativeStock == 'true' || db.settings.allowNegativeStock == 1))) {
                        nextWhQty = Math.max(0, nextWhQty);
                    }
                    var foundWh = false;
                    for (var wi = 0; wi < db.warehouse_stock.length; wi++) {
                        var row = db.warehouse_stock[wi];
                        if (Number(row.product_id) === pid && Number(row.warehouse_id) === whId) {
                            row.qty = nextWhQty;
                            foundWh = true;
                            break;
                        }
                    }
                    if (!foundWh) {
                        db.warehouse_stock.push({ warehouse_id: whId, product_id: pid, qty: nextWhQty, min_stock: 5 });
                    }
                    if (typeof isMultiWarehouseProEnabled === 'function' && !isMultiWarehouseProEnabled()) {
                        db.warehouse_stock.forEach(function(r) {
                            if (Number(r.product_id) === pid && Number(r.warehouse_id) !== whId) r.qty = 0;
                        });
                    }
                }
            });
            var viewPos = document.getElementById('view-pos');
            if (viewPos && viewPos.classList.contains('active') && typeof updateProductCardQty === 'function') {
                stockArray.forEach(function(s) {
                    var p = db.products.find(function(x) { return String(x.id) === String(s.id); });
                    if (p) updateProductCardQty(s.id, typeof getDisplayQty === 'function' ? getDisplayQty(p) : p.qty, p.trackStock);
                });
            }
            var viewProducts = document.getElementById('view-products');
            if (viewProducts && viewProducts.classList.contains('active') && typeof renderProducts === 'function') {
                var prodInput = document.getElementById('products-search-input');
                renderProducts(prodInput ? prodInput.value : '');
            }
            var viewWarehouse = document.getElementById('view-warehouse');
            if (viewWarehouse && viewWarehouse.classList.contains('active') && typeof renderWarehouse === 'function') {
                renderWarehouse();
            }
            var viewReturns = document.getElementById('view-returns-new');
            if (viewReturns && viewReturns.classList.contains('active') && typeof renderReturnsMenu === 'function') {
                renderReturnsMenu();
            }
            if (typeof refreshAllStockDisplaysFromState === 'function') refreshAllStockDisplaysFromState();
        }

        function syncLiveData(longPoll = false) {
            if(!db) return;
            if (window._posScanQueueBusy) {
                if (longPoll) {
                    var _scanWait = (typeof isPosFastLanSync === 'function' && isPosFastLanSync()) ? 200 : 2000;
                    setTimeout(function () { syncLiveData(true); }, _scanWait);
                }
                return;
            }
            if (typeof shouldPosUseLongPoll === 'function' && !shouldPosUseLongPoll()) longPoll = false;
            if (longPoll) {
                var _settingsView = document.getElementById('view-settings');
                if (_settingsView && _settingsView.classList.contains('active')) {
                    var _deferMs = (typeof posPollIntervalMs === 'function') ? posPollIntervalMs(15000) : 30000;
                    setTimeout(function () { syncLiveData(true); }, _deferMs);
                    return;
                }
            }
            if(longPoll && isPolling) return;
            if(longPoll) isPolling = true;

            var _delViewWait = document.getElementById('view-delivery');
            var _skipLongWait = !!((_delViewWait && _delViewWait.classList.contains('active')) || window._posDeliveryFetchBusy);
            var _fastLan = (typeof isPosFastLanSync === 'function' && isPosFastLanSync());
            if (!longPoll && _fastLan && window.__posLanDataSyncBusy) return;
            if (!longPoll && _fastLan) window.__posLanDataSyncBusy = true;
            var _waitMax = (typeof posLiveSyncWaitMax === 'function') ? posLiveSyncWaitMax() : 25;
            var _syncQs = '?action=get_sync_data&last_sync=' + lastSyncTime;
            if (longPoll && !_skipLongWait) {
                _syncQs += '&wait=1&wait_max=' + encodeURIComponent(String(_waitMax));
            }
            const url = (typeof window.posRouterUrl === 'function') ? window.posRouterUrl(_syncQs.replace(/^\?/, '')) : _syncQs;
            fetch(url, { credentials: 'same-origin' })
            .then(res => res.json())
            .then(data => {
                if(longPoll) isPolling = false;
                if (!longPoll) window.__posLanDataSyncBusy = false;
                if(data.status === 'auth_required') { currentUser = null; document.getElementById('login-screen').style.display = 'flex'; return; }
                if(data.status === 'no_change') {
                    if (data.server_time) lastSyncTime = data.server_time;
                    if (typeof updateSaveStatus === 'function') updateSaveStatus(true);
                    if (longPoll) {
                        var _again = function () { syncLiveData(true); };
                        var _delOpen = document.getElementById('view-delivery');
                        if (_fastLan) {
                            setTimeout(_again, 50);
                        } else if ((_delOpen && _delOpen.classList.contains('active')) || (typeof isPosCpuSaveMode === 'function' && isPosCpuSaveMode())) {
                            setTimeout(_again, (typeof posPollIntervalMs === 'function') ? posPollIntervalMs(4000) : 4000);
                        } else {
                            _again();
                        }
                    }
                    return;
                }
                if(data.server_time) lastSyncTime = data.server_time;

                try {
                if(data.tables) {
                    data.tables.forEach(srvTbl => {
                        const localTbl = db.tables.find(t => t && String(t.id) === String(srvTbl.id));
                        if(localTbl) {
                            // Only update if changed to prevent UI glitches
                            // FIX: Do not sync items for the ACTIVE table to prevent "shaklin" (glitching) when working fast
                            if(String(activeTableId) !== String(srvTbl.id)) {
                                var _itemsChanged = false;
                                if (typeof isPosCpuSaveMode === 'function' && isPosCpuSaveMode()) {
                                    _itemsChanged = (localTbl.items || []).length !== (srvTbl.items || []).length;
                                } else {
                                    _itemsChanged = JSON.stringify(localTbl.items) !== JSON.stringify(srvTbl.items);
                                }
                                if (_itemsChanged) {
                                    localTbl.items = srvTbl.items;
                                    localTbl.has_new_items = srvTbl.has_new_items;
                                }
                            }
                            localTbl.name = srvTbl.name;
                        } else {
                            db.tables.push(srvTbl);
                        }
                    });
                    var _tablesView = document.getElementById('view-tables');
                    if (!_tablesView || _tablesView.classList.contains('active')) renderTables();
                }

                if (Array.isArray(data.drivers)) {
                    db.drivers = data.drivers;
                    if (typeof window.syncCartDeliveryUI === 'function') window.syncCartDeliveryUI();
                }
                if(data.deliveries) {
                    if (!Array.isArray(db.deliveries)) db.deliveries = [];
                    data.deliveries.forEach(srvD => {
                        if (typeof window.posMergeDeliveryRow === 'function') window.posMergeDeliveryRow(db.deliveries, srvD);
                        else {
                            if (!srvD || srvD.id == null) return;
                            const sid = Number(srvD.id);
                            const idx = db.deliveries.findIndex(d => d && Number(d.id) === sid);
                            if(idx > -1) db.deliveries[idx] = Object.assign({}, db.deliveries[idx], srvD);
                            else db.deliveries.push(srvD);
                        }
                    });
                    if (Array.isArray(data.drivers)) db.drivers = data.drivers;
                    var _delView = document.getElementById('view-delivery');
                    if (!_delView || _delView.classList.contains('active')) {
                        try {
                            if (typeof renderDeliveries === 'function') renderDeliveries();
                        } catch (_eDel) {}
                    }
                    if (typeof window.syncCartDeliveryUI === 'function') window.syncCartDeliveryUI();
                }

                // 3. Sync Stock (server qty is already net of cart reservations — real-time deduction at add-to-cart)
                if (data.warehouses) db.warehouses = data.warehouses;
                if (data.warehouse_stock) db.warehouse_stock = data.warehouse_stock;
                if (data.stock) {
                    applyServerStockUpdates(data.stock);
                }
                if (Array.isArray(data.products) && data.products.length) {
                    if (!Array.isArray(db.products)) db.products = [];
                    var _prodAdded = 0;
                    data.products.forEach(function (srvP) {
                        if (!srvP || srvP.id == null) return;
                        var idx = db.products.findIndex(function (p) { return p && String(p.id) === String(srvP.id); });
                        if (idx > -1) {
                            db.products[idx] = Object.assign({}, db.products[idx], srvP);
                        } else {
                            db.products.unshift(srvP);
                            _prodAdded++;
                        }
                    });
                    var _prodView = document.getElementById('view-products');
                    if (_prodView && _prodView.classList.contains('active') && typeof renderProducts === 'function') {
                        var _ps = document.getElementById('products-search-input');
                        renderProducts(_ps ? _ps.value : '');
                    }
                    var _posView = document.getElementById('view-pos');
                    if (_posView && _posView.classList.contains('active') && _prodAdded && typeof debouncedRenderPOSMenu === 'function') {
                        var _bar = document.getElementById('pos-barcode-input');
                        debouncedRenderPOSMenu(_bar ? _bar.value : '');
                    }
                    if (typeof window.schedulePosScanIndexBuild === 'function') window.schedulePosScanIndexBuild();
                }
                if (typeof window.applyOpenWarehouseFromPayload === 'function') window.applyOpenWarehouseFromPayload(data);
                else if (data.open_warehouse_id != null) db.open_warehouse_id = Number(data.open_warehouse_id) || 0;
                if (typeof window.syncPosSaleWarehouseBtn === 'function') window.syncPosSaleWarehouseBtn();
                if (typeof window.posAfterWarehouseDataLoaded === 'function') {
                    window.posAfterWarehouseDataLoaded('smart_sync');
                } else if (typeof window.healWarehouseStockMemory === 'function') {
                    window.healWarehouseStockMemory();
                }
                if (data.warehouses && document.getElementById('view-warehouse') && document.getElementById('view-warehouse').classList.contains('active') && typeof renderWmsWarehouseHub === 'function') {
                    renderWmsWarehouseHub();
                }

                // 4. Sync Users & Permissions
                if(data.users) {
                    db.users = data.users;
                    // Update Current User if changed
                    if(currentUser) {
                        const updatedUser = db.users.find(u => u.id === currentUser.id);
                        if(updatedUser) {
                            // Check if role or permissions changed
                            if(JSON.stringify(updatedUser.permissions) !== JSON.stringify(currentUser.permissions) || updatedUser.role !== currentUser.role) {
                                currentUser = updatedUser;
                                document.getElementById('user-display').innerText = typeof getUserDisplayLabel === 'function' ? getUserDisplayLabel(currentUser) : (currentUser.name + " (" + currentUser.role + ")");
                                var _su = document.getElementById('right-sidebar-user-name'); if(_su) _su.innerText = typeof getUserDisplayLabel === 'function' ? getUserDisplayLabel(currentUser) : (currentUser.name + " (" + currentUser.role + ")");
                                applyUserPermissions(); // Re-apply permissions
                            }
                        }
                    }
                    var _staffView = document.getElementById('view-staff');
                    if (!_staffView || _staffView.classList.contains('active')) renderUsers();
                }

                // 5. Sync Customers Balance (+ name / opening so many-customer shops stay complete)
                if(data.customers) {
                    if (!Array.isArray(db.customers)) db.customers = [];
                    if (typeof posUpsertCustomers === 'function') {
                        posUpsertCustomers(data.customers);
                        if (typeof posDedupeCustomersInPlace === 'function') posDedupeCustomersInPlace();
                    } else {
                        data.customers.forEach(srvC => {
                            const localC = db.customers.find(c => c && String(c.id) === String(srvC.id));
                            if(localC) {
                                localC.balance = srvC.balance;
                                if (srvC.name) localC.name = srvC.name;
                                if (typeof srvC.phone !== 'undefined') localC.phone = srvC.phone;
                                if (typeof srvC.address !== 'undefined') localC.address = srvC.address;
                                if (typeof srvC.opening_balance !== 'undefined') localC.opening_balance = srvC.opening_balance;
                                if (typeof srvC.debt_limit !== 'undefined') localC.debt_limit = srvC.debt_limit;
                                if (typeof srvC.payment_term_value !== 'undefined') {
                                    localC.payment_term_value = parseInt(srvC.payment_term_value, 10) || 0;
                                }
                                if (typeof srvC.payment_term_unit !== 'undefined' && srvC.payment_term_unit) {
                                    localC.payment_term_unit = srvC.payment_term_unit;
                                }
                            } else if (srvC && srvC.id) {
                                db.customers.push(srvC);
                            }
                        });
                    }
                }
                // 6. Sync Companies Balance (+ name / opening)
                if(data.companies) {
                    if (!Array.isArray(db.companies)) db.companies = [];
                    if (typeof posUpsertCompanies === 'function') {
                        posUpsertCompanies(data.companies);
                    } else {
                        data.companies.forEach(srvC => {
                            const localC = db.companies.find(c => c && c.id === srvC.id);
                            if(localC) {
                                localC.balance = srvC.balance;
                                if (srvC.name) localC.name = srvC.name;
                                if (typeof srvC.phone !== 'undefined') localC.phone = srvC.phone;
                                if (typeof srvC.address !== 'undefined') localC.address = srvC.address;
                                if (typeof srvC.opening_balance !== 'undefined') localC.opening_balance = srvC.opening_balance;
                                if (typeof srvC.debt_limit !== 'undefined') localC.debt_limit = srvC.debt_limit;
                                if (typeof srvC.payment_term_value !== 'undefined') {
                                    localC.payment_term_value = parseInt(srvC.payment_term_value, 10) || 0;
                                }
                                if (typeof srvC.payment_term_unit !== 'undefined' && srvC.payment_term_unit) {
                                    localC.payment_term_unit = srvC.payment_term_unit;
                                }
                            } else if (srvC && srvC.id) {
                                db.companies.push(srvC);
                            }
                        });
                    }
                }

                var finOk = ((typeof posIsFinancialDataReady === 'function') && posIsFinancialDataReady()) || _fastLan;

                // 8–9. Sales / expenses — only after login secondary load (avoids wrong totals + merge flicker)
                if (finOk) {
                    if (data.sales) {
                        if (!Array.isArray(db.sales)) db.sales = [];
                        data.sales.forEach(s => {
                            var local = db.sales.find(function(x) { return x && x.id == s.id; });
                            if (!local) {
                                db.sales.push(s);
                            } else if (s.payment_due_at && !local.payment_due_at) {
                                local.payment_due_at = s.payment_due_at;
                            } else if (s.payment_due_at) {
                                local.payment_due_at = s.payment_due_at;
                            }
                            if (local && typeof s.remaining_debt !== 'undefined') {
                                local.remaining_debt = s.remaining_debt;
                            }
                        });
                        db.sales.sort((a, b) => b.id - a.id);
                    }
                    if (data.expenses) {
                        if (!Array.isArray(db.expenses)) db.expenses = [];
                        data.expenses.forEach(e => {
                            if (!db.expenses.some(local => local.id == e.id)) { db.expenses.push(e); }
                        });
                        db.expenses.sort((a, b) => b.id - a.id);
                    }
                    if (data.today_stats) db.today_stats = data.today_stats;
                    if (data.sales || data.expenses || data.today_stats) {
                        if (typeof updateStats === 'function') updateStats();
                        var _repView = document.getElementById('view-reports');
                        if (_repView && _repView.classList.contains('active')) {
                            if (typeof renderSalesHistory === 'function') renderSalesHistory();
                            if (typeof renderShiftSummary === 'function') renderShiftSummary();
                        }
                        var _expView = document.getElementById('view-expenses');
                        if (_expView && _expView.classList.contains('active') && typeof renderExpenses === 'function') renderExpenses();
                    }
                }

                if (typeof refreshBusinessDayStartHourControlState === 'function') refreshBusinessDayStartHourControlState();
                } catch (_eSyncApply) {}
                if (typeof updateSaveStatus === 'function') updateSaveStatus(true);
                if (longPoll) {
                    var _delOpen2 = document.getElementById('view-delivery');
                    if (_fastLan) {
                        setTimeout(function () { syncLiveData(true); }, 50);
                    } else if ((_delOpen2 && _delOpen2.classList.contains('active')) || (typeof isPosCpuSaveMode === 'function' && isPosCpuSaveMode())) {
                        setTimeout(function () { syncLiveData(true); }, (typeof posPollIntervalMs === 'function') ? posPollIntervalMs(4000) : 4000);
                    } else {
                        syncLiveData(true);
                    }
                }
            }).catch(err => {
                if(longPoll) isPolling = false;
                if (!longPoll) window.__posLanDataSyncBusy = false;
                var msg = (err && (err.name || err.message)) ? String(err.name || err.message) : '';
                if (!/AbortError|TypeError/i.test(msg) || /Failed to fetch|NetworkError|JSON/i.test(msg)) {
                    if (typeof updateSaveStatus === 'function') updateSaveStatus(false);
                }
                if(longPoll) {
                    var _retryMs = _fastLan
                        ? 400
                        : ((typeof isPosCpuSaveMode === 'function' && isPosCpuSaveMode() && typeof posPollIntervalMs === 'function')
                            ? posPollIntervalMs(10000) : 2000);
                    setTimeout(function () { syncLiveData(true); }, _retryMs);
                }
            });
        }

        // --- POS PARTIAL REFRESH (for the sync/refresh icon in POS top bar) ---
        function posPartialRefresh(btnEl) {
            const icon = btnEl ? btnEl.querySelector('i') : null;
            if (icon) { icon.classList.add('fa-spin'); }
            if (btnEl) { btnEl.disabled = true; btnEl.style.opacity = '0.7'; }

            fetch('?action=get_data&t=' + Date.now(), { credentials: 'same-origin' })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'auth_required') {
                    currentUser = null;
                    document.getElementById('login-screen').style.display = 'flex';
                    return;
                }
                if (data.products) {
                    db.products = data.products;
                    if (typeof repairJewelryCatalogInMemory === 'function') repairJewelryCatalogInMemory();
                }
                if (typeof updateCurrencyLockUI === 'function') updateCurrencyLockUI();
                if (data.sales) { db.sales = data.sales; updateStats(); }
                if (data.customers) {
                    if (typeof posUpsertCustomers === 'function') posUpsertCustomers(data.customers);
                    else db.customers = data.customers;
                    if (typeof posDedupeCustomersInPlace === 'function') posDedupeCustomersInPlace();
                }
                if (data.customer_ledger) db.customer_ledger = data.customer_ledger;
                if (data.returns) db.returns = data.returns;
                if (data.purchase_returns) db.purchase_returns = data.purchase_returns;
                if (data.companies) {
                    if (typeof posUpsertCompanies === 'function') posUpsertCompanies(data.companies);
                    else db.companies = data.companies;
                }
                if (Array.isArray(data.manufacturers)) db.manufacturers = data.manufacturers;
                if (data.supplies) db.supplies = data.supplies;
                if (data.expenses) db.expenses = data.expenses;
                if (data.expenses_deleted) db.expenses_deleted = data.expenses_deleted;

                if (document.getElementById('view-expenses') && document.getElementById('view-expenses').classList.contains('active') && typeof renderExpenses === 'function') {
                    renderExpenses();
                }
                if (typeof renderPOSMenu === 'function') renderPOSMenu();
                if (typeof renderBill === 'function') renderBill();
                if (typeof showToast === 'function') showToast(typeof t === 'function' ? t('toast_refreshed') : '✅ تازەکرانەوە');
                updateSaveStatus(true);
                if (typeof window.posNotifyMobileDebtSync === 'function') {
                    window.posNotifyMobileDebtSync('partial_refresh');
                }
            })
            .catch(() => {
                if (typeof showToast === 'function') showToast('❌ سەرنەکەفت', 'error');
                updateSaveStatus(false);
            })
            .finally(() => {
                if (icon) { icon.classList.remove('fa-spin'); }
                if (btnEl) { btnEl.disabled = false; btnEl.style.opacity = ''; }
                if (typeof refreshBusinessDayStartHourControlState === 'function') refreshBusinessDayStartHourControlState();
            });
        }
        window.posPartialRefresh = posPartialRefresh;

        function openCustomerDisplay() {
            // Open Customer Screen in a new window
            // Fix for iPad/Mobile Popup Blockers
            if (/iPhone|iPad|iPod|Android/i.test(navigator.userAgent)) {
                window.open('?view=customer', '_blank');
            } else {
                window.open('?view=customer', 'CustomerDisplay', 'width=1000,height=800,menubar=no,toolbar=no,location=no,status=no');
            }
        }

        // --- SHIFT OPENING BALANCE HELPERS ---
        let pendingShiftUser = null;

        function posOpeningBalanceRequired(user) {
            if (!user || !user.id) return false;
            var promptEl = document.getElementById('set-require-opening-balance-prompt');
            var shouldAsk = (typeof isPremiumSettingsFeatureEnabled === 'function')
                ? isPremiumSettingsFeatureEnabled('set-require-opening-balance-prompt')
                : (promptEl ? !!promptEl.checked : false);
            if (!shouldAsk) return false;
            var todayKey = new Date().toISOString().slice(0, 10);
            try {
                if (sessionStorage.getItem('opening_' + user.id) === todayKey) return false;
            } catch (e) {}
            return true;
        }

        function posShiftGateRelease(ok) {
            var gate = window._posShiftGateLogin;
            window._posShiftGateLogin = null;
            if (typeof gate !== 'function') return;
            if (ok) {
                gate();
                return;
            }
            window.__posLoginInFlight = false;
            var loginBtn = document.querySelector('.login-btn-main');
            if (loginBtn) { loginBtn.disabled = false; loginBtn.removeAttribute('aria-busy'); }
            var errEl = document.getElementById('login-error');
            if (errEl) errEl.innerText = (typeof t === 'function') ? t('toast_connection_failed') : 'شفت نەهاتە دەستپێکرن';
        }

        function posAfterShiftStarted(user, ok) {
            if (ok) scheduleVerifyShiftAfterStart(user);
            if (window._posShiftGateLogin) posShiftGateRelease(ok);
        }

        /** هەمان لۆژیکی get_shift_expected لەسەر db ـی ناوخۆیی — خێراتر بۆ مۆدالی گرتنا شفتێ */
        function posComputeShiftExpectedFromLocal(shift) {
            if (!shift || !shift.startTime || !db) return null;
            var startDt = (typeof parseSQLDate === 'function') ? parseSQLDate(shift.startTime) : new Date(shift.startTime);
            if (!startDt || isNaN(startDt.getTime())) return null;
            var startMs = startDt.getTime();
            var endMs = Date.now();
            var net = 0;
            (db.ledger || []).forEach(function (l) {
                if (!l) return;
                var ld = (typeof parseSQLDate === 'function') ? parseSQLDate(l.date || l.created_at) : new Date(l.date || l.created_at);
                if (!ld || isNaN(ld.getTime())) return;
                var tms = ld.getTime();
                if (tms < startMs || tms > endMs) return;
                var amt = parseFloat(l.amount) || 0;
                var typ = l.type;
                if (typ === 'sale' || typ === 'debt_payment_in') net += amt;
                else if (typ === 'expense' || typ === 'purchase' || typ === 'debt_payment' || typ === 'refund') net -= amt;
            });
            var bank = 0;
            var salesPool = (typeof getAllSales === 'function') ? getAllSales() : (db.sales || []);
            salesPool.forEach(function (s) {
                if (!s) return;
                var sd = (typeof parseSQLDate === 'function') ? parseSQLDate(s.created_at || s.date) : new Date(s.created_at || s.date);
                if (!sd || isNaN(sd.getTime())) return;
                var st = sd.getTime();
                if (st < startMs || st > endMs) return;
                bank += parseFloat(s.paid_bank != null ? s.paid_bank : (s.bank_amount || 0)) || 0;
            });
            net -= bank;
            var opening = parseFloat(shift.opening_balance) || 0;
            return {
                status: 'ok',
                opening_balance: opening,
                expected: opening + net,
                startTime: shift.startTime,
                _localEstimate: true
            };
        }
        window.posComputeShiftExpectedFromLocal = posComputeShiftExpectedFromLocal;

        /** پاش دەستپێکرنا شفتێ لە سێرڤەر، دڵنیابە ڕاستی هەیە؛ ئەگەر نەبوو دووبارە start_shift */
        function verifyServerShiftOrRepair(user) {
            if (!user || !user.id) return;
            if (typeof getCurrentShift === 'function' && !getCurrentShift()) return;
            var fd = new FormData();
            fd.append('action', 'get_shift_expected');
            fd.append('userId', user.id);
            fetch('?action=get_shift_expected', { method: 'POST', body: fd, credentials: 'same-origin' })
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    if (data && data.status === 'ok') return;
                    if (window._posShiftRepairAttempted) {
                        alert('چ شیفتێن ڤەکری نینن لە سێرڤەر.\nلا توجد وردية مفتوحة في الخادم.\nتکایە پەڕە نوێ بکەرەوە و دووبارە بچۆ ژوورەوە.');
                        return;
                    }
                    window._posShiftRepairAttempted = true;
                    console.warn('POS: repairing missing open shift on server');
                    completeShiftStart(user, null).then(function(ok) {
                        if (ok && typeof showToast === 'function') {
                            showToast('وردية هاتە ھەڵکرنەوە لە سێرڤەر.', false);
                        }
                    });
                })
                .catch(function(e) { console.error('verifyServerShiftOrRepair', e); });
        }

        function scheduleVerifyShiftAfterStart(user) {
            if (!user) return;
            setTimeout(function() { verifyServerShiftOrRepair(user); }, 2200);
        }

        function startShiftFlow(user, options) {
            options = options || {};
            window._posShiftRepairAttempted = false;
            pendingShiftUser = user;
            var gateLogin = !!options.gateLogin;
            var shouldAskOpeningBalance = posOpeningBalanceRequired(user);
            if (!shouldAskOpeningBalance) {
                completeShiftStart(user, null).then(function(ok) {
                    posAfterShiftStarted(user, ok);
                });
                return;
            }
            const modal = document.getElementById('opening-balance-modal');
            const input = document.getElementById('opening-balance-input');
            if (!modal || !input) {
                completeShiftStart(user, null).then(function(ok) {
                    posAfterShiftStarted(user, ok);
                });
                return;
            }
            input.value = '';
            var obCard = modal.querySelector('.glass-card');
            if (obCard && typeof applyI18nSubtree === 'function') applyI18nSubtree(obCard);
            if (gateLogin) modal.classList.add('opening-balance-modal--login-gate');
            modal.style.display = 'flex';
            if (gateLogin) {
                var errEl = document.getElementById('login-error');
                if (errEl) errEl.innerText = '';
            }
            setTimeout(function() { input.focus(); }, 50);
        }

        function posCloseOpeningBalanceModal() {
            const modal = document.getElementById('opening-balance-modal');
            if (modal) {
                modal.style.display = 'none';
                modal.classList.remove('opening-balance-modal--login-gate');
            }
        }

        function cancelOpeningBalance() {
            posCloseOpeningBalanceModal();
            if (pendingShiftUser) {
                completeShiftStart(pendingShiftUser, null).then(function(ok) {
                    posAfterShiftStarted(pendingShiftUser, ok);
                });
            }
        }

        function confirmOpeningBalance() {
            const input = document.getElementById('opening-balance-input');
            if (!pendingShiftUser || !input) {
                posCloseOpeningBalanceModal();
                return;
            }
            let rawVal = input.value || '';
            rawVal = rawVal.replace(/[٠-٩]/g, function(ch) { return String(ch.charCodeAt(0) - 1632); });
            rawVal = rawVal.replace(/[۰-۹]/g, function(ch) { return String(ch.charCodeAt(0) - 1776); });
            var parsedOb = (typeof parseAmountInput === 'function')
                ? parseAmountInput(rawVal)
                : parseFloat(String(rawVal).replace(/,/g, ''));
            var val = (parsedOb != null && isFinite(parsedOb) && !isNaN(parsedOb)) ? Math.max(0, parsedOb) : 0;
            const todayKey = new Date().toISOString().slice(0, 10);
            const storageKey = 'opening_' + pendingShiftUser.id;
            try { sessionStorage.setItem(storageKey, todayKey); } catch(e) {}
            posCloseOpeningBalanceModal();
            completeShiftStart(pendingShiftUser, val).then(function(ok) {
                posAfterShiftStarted(pendingShiftUser, ok);
            });
        }

        /** دەستپێکرنا شفتێ لە DB ـی سێرڤەر؛ دەگەڕێتەوە true ئەگەر سەرکەوتوو بوو */
        function completeShiftStart(user, opening) {
            if (!user) return Promise.resolve(false);
            const shiftData = new FormData();
            shiftData.append('action', 'start_shift');
            shiftData.append('userId', user.id);
            shiftData.append('name', user.name);
            shiftData.append('rate', user.hourlyRate || 0);
            if (typeof opening === 'number' && !isNaN(opening)) {
                shiftData.append('opening_balance', opening);
            }

            return fetch('?action=start_shift', { method: 'POST', body: shiftData, credentials: 'same-origin' })
                .then(function(res) {
                    return res.text().then(function(t) {
                        try {
                            return JSON.parse(t);
                        } catch (parseErr) {
                            throw new Error((t && t.slice ? t.slice(0, 240) : '') || 'Invalid server response');
                        }
                    });
                })
                .then(function(sData) {
                    if (sData.status === 'success') {
                        if (!db.shifts) db.shifts = [];
                        db.shifts.push({
                            id: sData.id,
                            userId: user.id,
                            userName: user.name,
                            startTime: sData.startTime,
                            endTime: null,
                            hourlyRate: user.hourlyRate || 0,
                            opening_balance: (sData.opening_balance != null && sData.opening_balance !== '') ? (parseFloat(sData.opening_balance) || 0) : ((typeof opening === 'number' && !isNaN(opening)) ? opening : 0)
                        });
                        var _paintShifts = function () { if (typeof renderShifts === 'function') renderShifts(); };
                        if (typeof isPosCpuSaveMode === 'function' && isPosCpuSaveMode()) {
                            setTimeout(_paintShifts, (typeof posLoginDeferMs === 'function') ? posLoginDeferMs(2500) : 2500);
                        } else {
                            _paintShifts();
                        }

                        if (typeof posTelegramConfigured === 'function' ? posTelegramConfigured() : (db && db.settings && db.settings.tgToken && db.settings.tgChatId)) {
                            if (db.settings.tg_shift_start_report !== false) {
                            const sym = typeof getCurrencySymbol === 'function' ? getCurrencySymbol() : 'IQD';
                            const obStored = (sData.opening_balance != null && sData.opening_balance !== '') ? (parseFloat(sData.opening_balance) || 0) : 0;
                            const esc = typeof telegramEscapeHtml === 'function' ? telegramEscapeHtml : function(x) { return String(x == null ? '' : x).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); };
                            let customMsg = '<b>🟢 دەستپێکرنا شفتەکا نوو</b>\n\n<b>کارمەند:</b> ' + esc(user.name) + '\n<b>دەستپێک:</b> ' + esc(new Date().toLocaleString('ku-IQ')) + '\n';
                            if (db.settings.tg_include_cash_in_drawer !== false) {
                                customMsg += '<b>پارێ سندوقێ د دەستپێکێ دا:</b> ' + esc(formatCurrency(obStored)) + ' ' + esc(sym) + '\n';
                            }
                            customMsg += '\n📌 ئاگەهداری: سیستەم ب سەرکەفتیانە دەست ب کار بوو.';
                            sendFilesToTelegram(db.settings.tgToken, db.settings.tgChatId, true, customMsg, true).catch(function(e) { console.error('Telegram backup failed', e); });
                            }
                        }
                        return true;
                    }
                    alert(sData.message || 'هەڵە د دەستپێکرنا شفتێ — شفت لە سێرڤەر دا نەهاتە تۆمارکرن');
                    return false;
                })
                .catch(function(err) {
                    var msg = (err && err.message) ? err.message : 'هەڵە د پەیوەندیێ دا';
                    alert(msg + '\n\nشفت نەهاتە ھەڵکرن — تکایە پەیوەندی ئینتەرنێت و دووبارە هەوڵ بدەرەوە.');
                    console.error('start_shift', err);
                    return false;
                });
        }

        function attemptLogin() {
            const pin = document.getElementById('pin-code').value;
            const uid = document.getElementById('login-user-select').value;
            var loginBtn = document.querySelector('.login-btn-main');
            
            if(!uid) { document.getElementById('login-error').innerText = (typeof t === 'function') ? t('login_err_select_user') : 'هیڤییە ناڤێ خۆ هەلبژێرە!'; return; }
            if(!pin) { document.getElementById('login-error').innerText = (typeof t === 'function') ? t('login_err_enter_pin') : 'هیڤیە پین کۆدی بنڤیسە!'; return; }
            if (window.__posLoginInFlight) return;
            window.__posLoginInFlight = true;
            if (loginBtn) { loginBtn.disabled = true; loginBtn.setAttribute('aria-busy', 'true'); }
            document.getElementById('login-error').innerText = (typeof t === 'function' && t('login_connecting') !== 'login_connecting') ? t('login_connecting') : 'پەیوەندی…';
            if (loginBtn) {
                try {
                    loginBtn.dataset._loginHtml = loginBtn.innerHTML;
                    loginBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ' + ((typeof t === 'function' && t('login_connecting') !== 'login_connecting') ? t('login_connecting') : 'پەیوەندی…');
                } catch (_eBtn) {}
            }
            
            const formData = new FormData();
            formData.append('action', 'login');
            formData.append('pin', pin);
            formData.append('userId', uid);

            var loginAbort = null;
            var loginTimer = null;
            var loginFetchOpts = { method: 'POST', body: formData, credentials: 'same-origin' };
            try {
                if (typeof AbortController !== 'undefined') {
                    loginAbort = new AbortController();
                    loginFetchOpts.signal = loginAbort.signal;
                    loginTimer = setTimeout(function () {
                        try { loginAbort.abort(); } catch (_eAb) {}
                    }, 15000);
                }
            } catch (_eAc) {}

            fetch('?action=login', loginFetchOpts)
            .then(res => res.json())
            .then(data => {
                if (loginTimer) { try { clearTimeout(loginTimer); } catch (_eT) {} }
                var restoreLoginBtn = function () {
                    window.__posLoginInFlight = false;
                    if (!loginBtn) return;
                    loginBtn.disabled = false;
                    loginBtn.removeAttribute('aria-busy');
                    if (loginBtn.dataset._loginHtml) {
                        loginBtn.innerHTML = loginBtn.dataset._loginHtml;
                        delete loginBtn.dataset._loginHtml;
                    }
                };
                if (data.status === 'license_blocked') {
                    restoreLoginBtn();
                    posShowLicenseBlocked(data);
                    return;
                }
                if (posIsTerminalProPlusBlock(data)) {
                    restoreLoginBtn();
                    posShowTerminalProPlusRequiredScreen(data);
                    return;
                }
                if (data.status === 'device_blocked') {
                    restoreLoginBtn();
                    if (posIsTerminalProPlusBlock(data)) {
                        posShowTerminalProPlusRequiredScreen(data);
                    } else if (posShouldShowTerminalActivationScreen(data)) {
                        posShowTerminalActivationScreen(data);
                    } else {
                        posShowDeviceBlocked(data);
                    }
                    return;
                }
                if(data.status === 'success') {
                    const user = data.user;
                    currentUser = user;
                    if (typeof posInvalidateFinancialCaches === 'function') posInvalidateFinancialCaches(user.id);
                    document.getElementById('login-error').innerText = '';
                    window._posScannerReady = false;
                    _cartRestoreNotified = false;

                    var loginUiOpened = false;
                    var openPosAfterLogin = function () {
                        if (loginUiOpened) return;
                        loginUiOpened = true;
                        restoreLoginBtn();

                        var finishLogin = function () {
                            if (!db || !db.settings) {
                                finishLoginAndOpenPOS(user);
                                return;
                            }
                            ensureValidCurrencyMode();
                            finishLoginAndOpenPOS(user);
                        };

                        if (typeof posMigrateBusinessSetupFlag === 'function') posMigrateBusinessSetupFlag();
                        var proceedAfterBusinessSetup = function () {
                            if (posOpeningBalanceRequired(user)) {
                                window._posShiftGateLogin = function () {
                                    finishLogin();
                                };
                                startShiftFlow(user, { gateLogin: true });
                                return;
                            }
                            startShiftFlow(user, { gateLogin: false });
                            finishLogin();
                        };
                        if (typeof posNeedsFirstRunBusinessSetup === 'function' && posNeedsFirstRunBusinessSetup(user)) {
                            showFirstRunBusinessModal(proceedAfterBusinessSetup);
                            return;
                        }
                        proceedAfterBusinessSetup();
                    };

                    // Fast path: open POS with cached db — do not wait for bootstrap (was 30s+ with Supabase/Telegram).
                    var hasCachedDb = !!(db && db.settings && Array.isArray(db.users) && db.users.length);
                    if (hasCachedDb) {
                        openPosAfterLogin();
                    } else {
                        // First install / new laptop: never leave user stuck on «پەیوەندی…»
                        try {
                            document.getElementById('login-error').innerText =
                                (typeof t === 'function' && t('login_loading_data') !== 'login_loading_data')
                                    ? t('login_loading_data')
                                    : 'داتا باردەبێت… چرکەیەک چاوەڕێ بکە';
                        } catch (_eMsg) {}
                    }

                    // Hard cap: open UI even if get_data is slow (MySQL cold / first migrations)
                    var loginOpenCap = setTimeout(function () {
                        if (loginUiOpened) return;
                        try {
                            if (!db || !db.settings) {
                                if (typeof createDefaultDB === 'function') createDefaultDB();
                            }
                            if (db) {
                                if (!Array.isArray(db.users) || !db.users.length) db.users = [user];
                                if (!db.settings) db.settings = {};
                            }
                        } catch (_eDef) {}
                        openPosAfterLogin();
                    }, hasCachedDb ? 12000 : 3500);

                    connectToDB(true, { skipRenderOnRefresh: true, fromLogin: true, skipPaintAfterLoad: true }).then(function () {
                        try { clearTimeout(loginOpenCap); } catch (_eC1) {}
                        openPosAfterLogin();
                    }).catch(function() {
                        try { clearTimeout(loginOpenCap); } catch (_eC2) {}
                        if (!loginUiOpened) {
                            openPosAfterLogin();
                        }
                    });
                } else {
                    restoreLoginBtn();
                    document.getElementById('login-error').innerText = (typeof t === 'function') ? t('login_err_wrong_pin') : 'پین کۆد یێ خەلەتە!';
                }
            })
            .catch(err => {
                if (loginTimer) { try { clearTimeout(loginTimer); } catch (_eT2) {} }
                window.__posLoginInFlight = false;
                if (loginBtn) {
                    loginBtn.disabled = false;
                    loginBtn.removeAttribute('aria-busy');
                    if (loginBtn.dataset._loginHtml) {
                        loginBtn.innerHTML = loginBtn.dataset._loginHtml;
                        delete loginBtn.dataset._loginHtml;
                    }
                }
                var aborted = err && (err.name === 'AbortError' || /abort/i.test(String(err.message || '')));
                document.getElementById('login-error').innerText = aborted
                    ? ((typeof t === 'function' && t('login_timeout') !== 'login_timeout') ? t('login_timeout') : 'پەیوەندی درێژ بوو — MySQL/Apache بپشکنە و دووبارە هەوڵ بدە')
                    : ((typeof t === 'function') ? t('toast_connection_failed') : 'Connection Error');
            });
        }

        function verifySecretPin(actionName) {
            const pin = prompt(`🔒 بۆ ئەنجامدانا (${actionName})، هیڤیە ژمارا نهێنی (Secret PIN) بنڤیسە:`);
            const actualPin = (db.settings && db.settings.settingsPin) ? db.settings.settingsPin : "2026";
            if (pin === actualPin) return true;
            alert("❌ ژمارا نهێنی خەلەتە!");
            return false;
        }

        var FIRST_RUN_BUSINESS_MODES = [
            { id: 'market', icon: 'fa-store', accent: '#2563eb' },
            { id: 'pharmacy', icon: 'fa-pills', accent: '#0d9488' },
            { id: 'stationery', icon: 'fa-pen-ruler', accent: '#f97316' },
            { id: 'mobile', icon: 'fa-mobile-screen-button', accent: '#5b7a9a' },
            { id: 'company', icon: 'fa-building', accent: '#4b5563' },
            { id: 'restaurant', icon: 'fa-utensils', accent: '#ef4444' },
            { id: 'cafe', icon: 'fa-mug-saucer', accent: '#a855f7' },
            { id: 'clinic', icon: 'fa-stethoscope', accent: '#0ea5e9' },
            { id: 'hotel', icon: 'fa-hotel', accent: '#eab308' },
            { id: 'school', icon: 'fa-school', accent: '#6366f1' },
            { id: 'factory', icon: 'fa-industry', accent: '#0891b2' },
            { id: 'jewelry', icon: 'fa-gem', accent: '#c9a227' },
            { id: 'general', icon: 'fa-layer-group', accent: '#64748b' }
        ];
        var _firstRunBusinessSelected = '';
        var _firstRunBusinessCallback = null;

        function posMigrateBusinessSetupFlag() {
            if (!db || !db.settings || db.settings.businessSetupDone === true) return;
            var mode = String(db.settings.systemMode || 'general');
            var hasProducts = Array.isArray(db.products) && db.products.length > 0;
            var hasSales = Array.isArray(db.sales) && db.sales.length > 0;
            if (mode !== 'general' || hasProducts || hasSales) {
                db.settings.businessSetupDone = true;
            }
        }
        window.posMigrateBusinessSetupFlag = posMigrateBusinessSetupFlag;

        function posNeedsFirstRunBusinessSetup(user) {
            if (!user || !db || !db.settings) return false;
            if (db.settings.businessSetupDone === true) return false;
            var role = String(user.role || '').toLowerCase();
            return role === 'admin' || role === 'manager';
        }
        window.posNeedsFirstRunBusinessSetup = posNeedsFirstRunBusinessSetup;

        function getFirstRunBusinessModeTitle(modeId) {
            var map = {
                market: 'مارکێت',
                pharmacy: 'سەیدەلی',
                stationery: 'قرطاسیە',
                mobile: 'مۆبایل',
                company: 'کۆمپانیا',
                restaurant: 'مەتعەم',
                cafe: 'کوفی شۆپ',
                clinic: 'عیادة',
                hotel: 'فندق',
                school: 'قوتابخانە',
                factory: 'کارگە',
                jewelry: 'زیڤ و زێر',
                general: 'گشتی'
            };
            return map[modeId] || modeId;
        }

        function getFirstRunBusinessModeSubtitle(modeId) {
            if (typeof getBusinessProfile !== 'function') return '';
            var profile = getBusinessProfile(modeId);
            if (!profile) return '';
            var lang = (db && db.settings && db.settings.language === 'ar') ? 'ar' : 'badini';
            if (lang === 'ar' && profile.homeSubtitleAr) return profile.homeSubtitleAr;
            return profile.homeSubtitle || '';
        }

        function getFirstRunBusinessFeatureLabels(modeId) {
            var profile = (typeof getBusinessProfile === 'function') ? getBusinessProfile(modeId) : null;
            if (!profile || !profile.visibleSections) return [];
            var skip = { settings: true, 'print-design': true, 'print-history': true };
            return profile.visibleSections.filter(function (id) {
                return id && !skip[id];
            }).map(function (id) {
                return (typeof getBreadcrumbLabel === 'function') ? getBreadcrumbLabel(id) : id;
            });
        }

        function applyBusinessModePreset(mode) {
            if (!db.settings) db.settings = {};
            var shared = {
                enableReports: true,
                enableExpenses: true,
                enableCalendar: true,
                enableNotifications: true,
                enableStaff: true,
                enableReturns: true,
                showCustomerName: true,
                useBarcode: true,
                enableCompanies: true,
                enablePurchase: true,
                enableWarehouse: true,
                enableDebt: true,
                enableWaste: true
            };
            var perMode = {
                market: { showTables: true, enableDelivery: true, enableRecipe: false, enableKitchen: false },
                pharmacy: { showTables: true, enableRecipe: true, enableKitchen: false, enableDelivery: false },
                stationery: { showTables: true, enableDelivery: true, enableRecipe: false, enableKitchen: false },
                mobile: { showTables: true, enableDelivery: true, enableRecipe: false, enableKitchen: false },
                company: { showTables: true, enableDelivery: true, enableWarehouse: false, enableRecipe: false, enableKitchen: false },
                restaurant: { showTables: true, enableKitchen: true, enableRecipe: true, enableDelivery: true },
                cafe: { showTables: true, enableKitchen: true, enableRecipe: true, enableDelivery: false, enableWarehouse: false },
                clinic: { showTables: true, enableRecipe: false, enableKitchen: false, enableWarehouse: false },
                hotel: { showTables: true, enableKitchen: true, enableRecipe: true, enableDelivery: false },
                school: { showTables: true, enableDebt: true, enableRecipe: false },
                factory: { showTables: true, enableRecipe: true, enableKitchen: false, enableWaste: true },
                jewelry: { showTables: true, enableDelivery: false, enableRecipe: false, enableKitchen: false, enableWaste: true },
                general: { showTables: false, enableRecipe: false, enableKitchen: false, enableDelivery: false }
            };
            var preset = perMode[mode] || perMode.general;
            Object.keys(shared).forEach(function (k) { db.settings[k] = shared[k]; });
            Object.keys(preset).forEach(function (k) { db.settings[k] = preset[k]; });
            db.settings.systemMode = mode;
            db.settings.businessSetupDone = true;
            try { localStorage.removeItem('main_nav_order'); } catch (e) {}
        }
        window.applyBusinessModePreset = applyBusinessModePreset;

        function renderFirstRunBusinessGrid() {
            var grid = document.getElementById('first-run-business-grid');
            if (!grid) return;
            grid.innerHTML = FIRST_RUN_BUSINESS_MODES.map(function (m) {
                var title = escapeHtml(getFirstRunBusinessModeTitle(m.id));
                var sub = escapeHtml(getFirstRunBusinessModeSubtitle(m.id));
                var sel = _firstRunBusinessSelected === m.id ? ' is-selected' : '';
                return '<button type="button" class="first-run-business-option' + sel + '" data-mode="' + escapeHtml(m.id) + '" onclick="selectFirstRunBusinessMode(\'' + m.id.replace(/'/g, '') + '\')" role="option" aria-selected="' + (_firstRunBusinessSelected === m.id ? 'true' : 'false') + '">' +
                    '<div class="first-run-business-option__icon"><i class="fas ' + escapeHtml(m.icon) + '" style="color:' + escapeHtml(m.accent) + '"></i></div>' +
                    '<div class="first-run-business-option__title">' + title + '</div>' +
                    (sub ? '<div class="first-run-business-option__sub">' + sub + '</div>' : '') +
                    '</button>';
            }).join('');
        }

        function selectFirstRunBusinessMode(mode) {
            _firstRunBusinessSelected = mode;
            renderFirstRunBusinessGrid();
            var preview = document.getElementById('first-run-business-preview');
            var chips = document.getElementById('first-run-business-features');
            var confirmBtn = document.getElementById('first-run-business-confirm');
            if (confirmBtn) confirmBtn.disabled = !mode;
            if (!preview || !chips) return;
            if (!mode) {
                preview.style.display = 'none';
                chips.innerHTML = '';
                return;
            }
            preview.style.display = 'block';
            var labels = getFirstRunBusinessFeatureLabels(mode);
            chips.innerHTML = labels.map(function (lbl) {
                return '<span class="first-run-business-feature-chip">' + escapeHtml(lbl) + '</span>';
            }).join('');
        }
        window.selectFirstRunBusinessMode = selectFirstRunBusinessMode;

        function showFirstRunBusinessModal(onDone) {
            _firstRunBusinessCallback = (typeof onDone === 'function') ? onDone : null;
            _firstRunBusinessSelected = 'market';
            var modal = document.getElementById('first-run-business-modal');
            var err = document.getElementById('first-run-business-error');
            var confirmBtn = document.getElementById('first-run-business-confirm');
            if (err) { err.style.display = 'none'; err.textContent = ''; }
            if (confirmBtn) confirmBtn.disabled = false;
            renderFirstRunBusinessGrid();
            selectFirstRunBusinessMode('market');
            var preview = document.getElementById('first-run-business-preview');
            if (preview) preview.style.display = 'block';
            if (modal) {
                modal.style.display = 'flex';
                if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
            }
        }
        window.showFirstRunBusinessModal = showFirstRunBusinessModal;

        function hideFirstRunBusinessModal() {
            var modal = document.getElementById('first-run-business-modal');
            if (modal) modal.style.display = 'none';
        }
        window.hideFirstRunBusinessModal = hideFirstRunBusinessModal;

        function confirmFirstRunBusinessSetup() {
            if (!_firstRunBusinessSelected) {
                var err = document.getElementById('first-run-business-error');
                if (err) {
                    err.textContent = (typeof t === 'function') ? t('first_run_business_pick_required') : 'هیڤییە جۆرێ کاروبارێ هەلبژێرە.';
                    err.style.display = 'block';
                }
                return;
            }
            var btn = document.getElementById('first-run-business-confirm');
            if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>'; }
            applyBusinessModePreset(_firstRunBusinessSelected);
            var newIcon = (typeof getSystemIcon === 'function') ? getSystemIcon() : '';
            if (window.customerChannel) {
                window.customerChannel.postMessage({ type: 'clear', items: [], total: 0, table: '', timestamp: Date.now(), icon: newIcon });
            }
            var finish = function () {
                if (typeof applySystemMode === 'function') applySystemMode();
                if (typeof applyFeatureVisibility === 'function') applyFeatureVisibility();
                if (typeof persistSystemFeaturesToStorage === 'function') persistSystemFeaturesToStorage();
                hideFirstRunBusinessModal();
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-check"></i> <span data-i18n="first_run_business_confirm">دەستپێکرن</span>';
                    if (typeof applyI18nSubtree === 'function') applyI18nSubtree(btn.parentElement);
                }
                if (typeof showToast === 'function') {
                    showToast('✅ ' + getFirstRunBusinessModeTitle(_firstRunBusinessSelected) + ' — ' + ((typeof t === 'function') ? t('first_run_business_saved') : 'ڕێکخرا!'));
                }
                var cb = _firstRunBusinessCallback;
                _firstRunBusinessCallback = null;
                if (cb) cb();
            };
            if (typeof saveSettings === 'function') {
                saveSettings().then(finish).catch(function (e) {
                    if (btn) {
                        btn.disabled = false;
                        btn.innerHTML = '<i class="fas fa-check"></i> <span data-i18n="first_run_business_confirm">دەستپێکرن</span>';
                    }
                    var errEl = document.getElementById('first-run-business-error');
                    if (errEl) {
                        errEl.textContent = (typeof t === 'function') ? t('first_run_business_error') : 'هەڵە د پاراستنێ دا.';
                        errEl.style.display = 'block';
                    }
                    console.error('first_run_business', e);
                });
            } else {
                finish();
            }
        }
        window.confirmFirstRunBusinessSetup = confirmFirstRunBusinessSetup;

        function setSystemMode(mode) {
            if (!db.settings) db.settings = {};
            if (db.settings.systemMode === mode) return; // No change

            let modeName = "";
            if (mode === 'market') modeName = "١. مارکێت (Market)";
            else if (mode === 'pharmacy') modeName = "٢. دەرمانخانە (Pharmacy)";
            else if (mode === 'stationery') modeName = "٣. قرطاسیە (Stationery)";
            else if (mode === 'mobile') modeName = "٤. مۆبایل (Mobile shop)";
            else if (mode === 'company') modeName = "٥. کۆمپانیا (Company)";
            else if (mode === 'cafe') modeName = "٦. کوفی شۆپ (Coffee Shop)";
            else if (mode === 'restaurant') modeName = "٧. مەتعەم (Restaurant)";
            else if (mode === 'clinic') modeName = "٨. عیادة / دکتور (Clinic)";
            else if (mode === 'hotel') modeName = "٩. فندق (Hotel)";
            else if (mode === 'school') modeName = "١٠. قوتابخانە / مەدرەسە (School)";
            else if (mode === 'factory') modeName = "١١. کارگە (Factory)";
            else if (mode === 'jewelry') modeName = "١٢. زیڤ و زێر (Jewelry)";
            else modeName = "٠. گشتی (General)";

            if (confirm(`دێ سیستەم هێتە گوهۆڕین بۆ '${modeName}'. دڵنیای؟

(ئەڤ گوهۆڕینە دێ ناڤ، ئایکۆن و بەشێن سیستەمی گوهۆڕیت لدیڤ جۆرێ کارێ تە.)`)) {
                db.settings.systemMode = mode;
                
                // Clear custom nav order when switching modes so the new mode's default order takes effect
                localStorage.removeItem('main_nav_order');

                // BROADCAST NEW ICON TO CUSTOMER DISPLAY IMMEDIATELY
                const newIcon = getSystemIcon();
                const displayData = {
                    type: 'clear',
                    items: [], total: 0, table: "", timestamp: Date.now(),
                    icon: newIcon
                };
                if(window.customerChannel) window.customerChannel.postMessage(displayData);
                const fd = new FormData();
                fd.append('action', 'update_customer_display');
                fd.append('data', JSON.stringify(displayData));
                fetch('?action=update_customer_display', { method: 'POST', body: fd });

                const indicator = document.getElementById('save-indicator');
                indicator.style.display = 'block'; 
                indicator.innerHTML = '<i class="fas fa-sync fa-spin"></i> گوهۆڕینا سیستەمی...';
                
                // Apply new business profile immediately (no hard refresh needed)
                saveSettings().then(function () {
                    if (typeof applySystemMode === 'function') applySystemMode();
                    if (typeof applyFeatureVisibility === 'function') applyFeatureVisibility();
                    if (typeof renderAll === 'function') renderAll();
                    if (typeof showToast === 'function') showToast('✅ گوهۆڕین هاتە پاراستن و نوێکرنەوە.');
                }).catch(function (e) {
                    if (typeof showToast === 'function') {
                        showToast('❌ هەڵە د پاراستنێ دا: ' + (e && e.message ? e.message : ''), 'error');
                    }
                }).finally(function () {
                    if (indicator) indicator.style.display = 'none';
                });
            }
        }

        window.updateAutoPrintQuickButtonState = function() {
            if (!db || !db.settings) return;
            var isOn = !!db.settings.autoPrint;
            
            var btnSlim = document.getElementById('btn-quick-autoprint-toggle');
            var btnExpand = document.getElementById('btn-quick-autoprint-toggle-expand');
            
            if (isOn) {
                if (btnSlim) { btnSlim.style.color = 'var(--text-muted)'; btnSlim.innerHTML = '<i class="fas fa-print"></i>'; btnSlim.title = 'چاپکرنا ئۆتۆماتیکی: کارایە'; btnSlim.style.textDecoration = 'none'; }
                if (btnExpand) { btnExpand.style.color = 'var(--text-muted)'; btnExpand.innerHTML = '<i class="fas fa-print"></i>'; btnExpand.title = 'چاپکرنا ئۆتۆماتیکی: کارایە'; btnExpand.style.textDecoration = 'none'; }
            } else {
                if (btnSlim) { btnSlim.style.color = 'var(--danger)'; btnSlim.innerHTML = '<i class="fas fa-print"></i>'; btnSlim.title = 'چاپکرنا ئۆتۆماتیکی: ناچالاکە'; btnSlim.style.textDecoration = 'line-through'; }
                if (btnExpand) { btnExpand.style.color = 'var(--danger)'; btnExpand.innerHTML = '<i class="fas fa-print"></i>'; btnExpand.title = 'چاپکرنا ئۆتۆماتیکی: ناچالاکە'; btnExpand.style.textDecoration = 'line-through'; }
            }
            if (typeof window.updateTelegramQuickButtonState === 'function') window.updateTelegramQuickButtonState();
        };

        window.updateTelegramQuickButtonState = function() {
            var btnSlim = document.getElementById('btn-quick-telegram-toggle');
            if (!btnSlim) return;
            
            if (!db || !db.settings || !db.settings.tgToken || !db.settings.tgChatId) {
                btnSlim.style.display = 'none';
                return;
            }
            
            btnSlim.style.display = '';
            var isPaused = db.settings.tgPaused === true;
            
            if (isPaused) {
                btnSlim.style.color = 'var(--danger)';
                btnSlim.title = 'تێلیگرام: ڕاگیراوە';
                btnSlim.style.textDecoration = 'line-through';
            } else {
                btnSlim.style.color = '#0088cc'; // Telegram blue
                btnSlim.title = 'تێلیگرام: کارایە';
                btnSlim.style.textDecoration = 'none';
            }
        };

        window.toggleTelegramQuick = function() {
            if (!db || !db.settings) return;
            var newStatus = !db.settings.tgPaused;
            db.settings.tgPaused = newStatus;
            
            if (typeof window.updateTelegramQuickButtonState === 'function') {
                window.updateTelegramQuickButtonState();
            }
            
            if (typeof saveSettings === 'function') saveSettings(true);
            
            if (typeof showToast === 'function') {
                showToast(newStatus ? 'ناردن بۆ تێلیگرام ڕاگیرا' : 'ناردن بۆ تێلیگرام کارا کرا', newStatus ? 'warning' : 'success');
            }
        };

        window.toggleAutoPrintQuick = function() {
            if (!db || !db.settings) return;
            var newStatus = !db.settings.autoPrint;
            db.settings.autoPrint = newStatus;
            
            // visually update the buttons
            var btnSlim = document.getElementById('btn-quick-autoprint-toggle');
            var btnExpand = document.getElementById('btn-quick-autoprint-toggle-expand');
            
            if (newStatus) {
                if (btnSlim) { btnSlim.style.color = 'var(--text-muted)'; btnSlim.innerHTML = '<i class="fas fa-print"></i>'; btnSlim.title = 'چاپکرنا ئۆتۆماتیکی: کارایە'; btnSlim.style.textDecoration = 'none'; }
                if (btnExpand) { btnExpand.style.color = 'var(--text-muted)'; btnExpand.innerHTML = '<i class="fas fa-print"></i>'; btnExpand.title = 'چاپکرنا ئۆتۆماتیکی: کارایە'; btnExpand.style.textDecoration = 'none'; }
            } else {
                if (btnSlim) { btnSlim.style.color = 'var(--danger)'; btnSlim.innerHTML = '<i class="fas fa-print"></i>'; btnSlim.title = 'چاپکرنا ئۆتۆماتیکی: ناچالاکە'; btnSlim.style.textDecoration = 'line-through'; }
                if (btnExpand) { btnExpand.style.color = 'var(--danger)'; btnExpand.innerHTML = '<i class="fas fa-print"></i>'; btnExpand.title = 'چاپکرنا ئۆتۆماتیکی: ناچالاکە'; btnExpand.style.textDecoration = 'line-through'; }
            }
            
            // Sync with settings UI if it's currently open
            var cb = document.getElementById('set-auto-print');
            if (cb) {
                cb.checked = newStatus;
                if (typeof updateToggleCards === 'function') updateToggleCards();
            }
            
            // Save settings via API
            if (typeof saveSettings === 'function') saveSettings(true); // pass true to indicate a silent/background save if supported, otherwise just normal save.
            
            // feedback
            if (typeof showToast === 'function') {
                showToast(newStatus ? 'چاپکرنا ئۆتۆماتیکی کارا کرا' : 'چاپکرنا ئۆتۆماتیکی ڕاگیرا', newStatus ? 'success' : 'warning');
            }
        };

        window.updatePrintNotePopupQuickButtonState = function() {
            var btns = [
                document.getElementById('btn-quick-printnote-toggle'),
                document.getElementById('btn-quick-printnote-toggle-expand'),
                document.getElementById('btn-quick-printnote-toggle-footer')
            ];
            var can = typeof canUsePrintNotes === 'function' && canUsePrintNotes();
            var isOn = can && db && db.settings && db.settings.showPrintNotePopup !== false;
            var titleOn = (typeof t === 'function') ? t('pos_print_note_quick_on') : 'تێبینی پێش چاپ: کارایە';
            var titleOff = (typeof t === 'function') ? t('pos_print_note_quick_off') : 'تێبینی پێش چاپ: ناچالاکە';
            var titleLock = (typeof t === 'function') ? t('print_note_pro_required') : 'تێبینی پێش چاپ — Pro';
            if (titleOn === 'pos_print_note_quick_on') titleOn = 'تێبینی پێش چاپ: کارایە';
            if (titleOff === 'pos_print_note_quick_off') titleOff = 'تێبینی پێش چاپ: ناچالاکە';
            btns.forEach(function(btn) {
                if (!btn) return;
                if (!can) {
                    btn.style.color = 'var(--text-muted)';
                    btn.style.opacity = '0.4';
                    btn.style.textDecoration = 'none';
                    btn.title = titleLock;
                    btn.setAttribute('aria-pressed', 'false');
                    return;
                }
                btn.style.opacity = '';
                if (isOn) {
                    btn.style.color = 'var(--text-muted)';
                    btn.style.textDecoration = 'none';
                    btn.title = titleOn;
                    btn.setAttribute('aria-pressed', 'true');
                } else {
                    btn.style.color = 'var(--danger)';
                    btn.style.textDecoration = 'line-through';
                    btn.title = titleOff;
                    btn.setAttribute('aria-pressed', 'false');
                }
            });
        };

        window.togglePrintNotePopupQuick = function() {
            if (!db || !db.settings) return;
            if (typeof canUsePrintNotes === 'function' && !canUsePrintNotes()) {
                if (typeof showPremiumLockedPurchasePopup === 'function') {
                    var noteTitle = (typeof t === 'function') ? t('pds_print_note_title') : 'تێبینی پێش چاپ';
                    showPremiumLockedPurchasePopup(noteTitle, 'setting-show-print-note-popup');
                }
                if (typeof updatePrintNotePopupQuickButtonState === 'function') updatePrintNotePopupQuickButtonState();
                return;
            }
            var next = !(db.settings.showPrintNotePopup !== false);
            db.settings.showPrintNotePopup = next;
            var el = document.getElementById('setting-show-print-note-popup');
            if (el) el.checked = next;
            if (typeof updatePrintNotePopupQuickButtonState === 'function') updatePrintNotePopupQuickButtonState();
            if (typeof saveSettings === 'function') saveSettings(true);
            if (typeof showToast === 'function') {
                var msgOn = (typeof t === 'function') ? t('pos_print_note_quick_toast_on') : 'پەنجەرا تێبینی پێش چاپ کارا بوو';
                var msgOff = (typeof t === 'function') ? t('pos_print_note_quick_toast_off') : 'پەنجەرا تێبینی پێش چاپ هاتە داخستن';
                if (msgOn === 'pos_print_note_quick_toast_on') msgOn = 'پەنجەرا تێبینی پێش چاپ کارا بوو';
                if (msgOff === 'pos_print_note_quick_toast_off') msgOff = 'پەنجەرا تێبینی پێش چاپ هاتە داخستن';
                showToast(next ? msgOn : msgOff, next ? 'success' : 'warning');
            }
        };

        function updateToggleCards() {
            document.querySelectorAll('.setting-toggle-card input[type="checkbox"]').forEach(cb => {
                const card = cb.closest('.setting-toggle-card');
                if(card) {
                    if(cb.checked) card.classList.add('active'); else card.classList.remove('active');
                }
            });
            if (typeof updateAutoPrintQuickButtonState === 'function') updateAutoPrintQuickButtonState();
            if (typeof updatePrintNotePopupQuickButtonState === 'function') updatePrintNotePopupQuickButtonState();
            if (typeof window.syncPaymentToggles === 'function') window.syncPaymentToggles();
        }

        /** Premium sections: secret menu unlocks; settings page toggles on/off after unlock. */
        var POS_PREMIUM_VAULT_FEATURES = [
            { id: 'set-show-note-icon', key: 'showItemNoteIcon', featureKey: 'showItemNoteIcon' },
            { id: 'set-enable-takeaway', key: 'enableTakeaway', featureKey: 'enableTakeaway' },
            { id: 'set-takeaway-as-wholesale', key: 'takeawayAsWholesale', featureKey: 'takeawayAsWholesale' },
            { id: 'set-enable-wholesale', key: 'enableWholesale', featureKey: 'enableWholesale' },
            { id: 'set-show-tables', key: 'showTables', featureKey: 'showTables' },
            { id: 'set-enable-gift', key: 'enableGift', featureKey: 'enableGift' },
            { id: 'set-enable-manual-sale', key: 'enableManualSale', featureKey: 'enableManualSale' },
            { id: 'set-unlock-staff-beyond-five', key: 'unlockStaffBeyondFive', featureKey: 'unlockStaffBeyondFive' },
            { id: 'set-show-fab', key: 'fabMenu', featureKey: 'fabMenu' },
            { id: 'set-enable-delivery', key: 'enableDelivery', featureKey: 'enableDelivery', noAutoUnlock: true },
            { id: 'set-require-opening-balance-prompt', key: 'requireOpeningBalancePrompt', featureKey: 'requireOpeningBalancePrompt', noAutoUnlock: true },
            { id: 'set-require-end-shift-reconcile-prompt', key: 'requireEndShiftReconcilePrompt', featureKey: 'requireEndShiftReconcilePrompt', noAutoUnlock: true },
            { id: 'set-allow-negative-stock', key: 'allowNegativeStock', featureKey: 'allowNegativeStock' },
            { id: 'set-enable-money-rounding', key: 'enableMoneyRounding', featureKey: 'enableMoneyRounding', noAutoUnlock: true },
            { id: 'set-show-payment-modal', key: 'showPaymentModal', featureKey: 'showPaymentModal' },
            { id: 'set-enable-multi-warehouse', key: 'enableMultiWarehouse', featureKey: 'enableMultiWarehouse' },
            { id: 'setting-show-print-note-popup', key: 'showPrintNotePopup', featureKey: 'showPrintNotePopup' },
            { id: 'set-enable-customer-installments', key: 'enableCustomerInstallments', featureKey: 'enableCustomerInstallments' },
            { id: 'premium-mfr-slot', key: 'manufacturerSlot', featureKey: 'manufacturerSlot', noAutoUnlock: true },
            { id: 'premium-purchase-batch', key: 'enablePurchaseBatch', featureKey: 'enablePurchaseBatch', noAutoUnlock: true },
            { id: 'premium-tech-specs', key: 'enableTechSpecs', featureKey: 'enableTechSpecs', noAutoUnlock: true },
            { id: 'premium-sale-followup', key: 'enableSaleFollowup', featureKey: 'enableSaleFollowup', noAutoUnlock: true }
        ];
        if (typeof window !== 'undefined') window.POS_PREMIUM_VAULT_FEATURES = POS_PREMIUM_VAULT_FEATURES;

        function posPremiumVaultFeatureByFeatureKey(featureKey) {
            if (!featureKey) return null;
            var fk = String(featureKey).toLowerCase();
            for (var i = 0; i < POS_PREMIUM_VAULT_FEATURES.length; i++) {
                if (String(POS_PREMIUM_VAULT_FEATURES[i].featureKey || '').toLowerCase() === fk) {
                    return POS_PREMIUM_VAULT_FEATURES[i];
                }
            }
            return null;
        }

        function posPremiumVaultFeatureById(checkboxId) {
            for (var i = 0; i < POS_PREMIUM_VAULT_FEATURES.length; i++) {
                if (POS_PREMIUM_VAULT_FEATURES[i].id === checkboxId) return POS_PREMIUM_VAULT_FEATURES[i];
            }
            return null;
        }

        function posPremiumFeatureWasEnabledForMigration(meta) {
            if (!db || !db.settings) return false;
            if (meta.noAutoUnlock) return false;
            var k = meta.key;
            if (k === 'fabMenu') {
                try { return localStorage.getItem('pos_fab_visible') !== 'false'; } catch (eFab) { return true; }
            }
            if (k === 'showPaymentModal') {
                return false;
            }
            if (k === 'enableMoneyRounding' || k === 'requireOpeningBalancePrompt' || k === 'requireEndShiftReconcilePrompt') {
                return db.settings[k] !== false;
            }
            return db.settings[k] === true;
        }

        /** True on brand-new install (no sales/supplies yet) — all Pro sections stay locked. */
        function isPosFreshPremiumInstall() {
            if (!db) return false;
            try {
                if (localStorage.getItem('pos_premium_vault_seeded') === '1') return false;
            } catch (eLs) {}
            if (db.settings && db.settings.premiumFeatureUnlocks && typeof db.settings.premiumFeatureUnlocks === 'object') {
                try { localStorage.setItem('pos_premium_vault_seeded', '1'); } catch (eLs2) {}
                return false;
            }
            var hasSales = db.sales && db.sales.length > 0;
            var hasSupplies = db.supplies && db.supplies.length > 0;
            var hasShifts = db.shifts && db.shifts.length > 0;
            if (hasSales || hasSupplies || hasShifts) {
                try { localStorage.setItem('pos_premium_vault_seeded', '1'); } catch (eLs3) {}
                return false;
            }
            return true;
        }

        function ensurePremiumFeatureUnlocks() {
            if (!db.settings) db.settings = {};
            if (db.settings.premiumFeatureUnlocks && typeof db.settings.premiumFeatureUnlocks === 'object') {
                if (!db.settings.premiumFeatureForceLocked || typeof db.settings.premiumFeatureForceLocked !== 'object') {
                    db.settings.premiumFeatureForceLocked = {};
                }
                return;
            }
            var fresh = isPosFreshPremiumInstall();
            var unlocks = {};
            var forceLocked = {};
            POS_PREMIUM_VAULT_FEATURES.forEach(function(meta) {
                unlocks[meta.key] = fresh ? false : posPremiumFeatureWasEnabledForMigration(meta);
                forceLocked[meta.key] = false;
            });
            db.settings.premiumFeatureUnlocks = unlocks;
            db.settings.premiumFeatureForceLocked = forceLocked;
            if (fresh) {
                try { localStorage.setItem('pos_premium_vault_seeded', '1'); } catch (eFresh) {}
            }
            migratePremiumVaultNoAutoUnlockKeys();
        }

        /** Re-lock delivery / shift prompts / rounding — never auto-unlock from old installs. */
        function migratePremiumVaultNoAutoUnlockKeys() {
            try {
                if (localStorage.getItem('pos_premium_vault_nau_v1') === '1') return;
            } catch (eLs) {}
            if (!db || !db.settings) return;
            ensurePremiumFeatureUnlocks();
            var changed = false;
            POS_PREMIUM_VAULT_FEATURES.forEach(function(meta) {
                if (!meta.noAutoUnlock) return;
                if (typeof hasPurchasedFeature === 'function' && hasPurchasedFeature(meta.featureKey)) return;
                if (db.settings.premiumFeatureUnlocks[meta.key]) {
                    db.settings.premiumFeatureUnlocks[meta.key] = false;
                    changed = true;
                }
                if (!hasPremiumEntitlement()) {
                    db.settings[meta.key] = false;
                    changed = true;
                }
            });
            try { localStorage.setItem('pos_premium_vault_nau_v1', '1'); } catch (eLs2) {}
            if (changed && typeof saveSettings === 'function') {
                try { saveSettings().catch(function() {}); } catch (eSave) {}
            }
        }

        function posCanonicalVaultSettingsKey(featureKey) {
            var meta = typeof posPremiumVaultFeatureByFeatureKey === 'function'
                ? posPremiumVaultFeatureByFeatureKey(featureKey) : null;
            return meta ? meta.key : String(featureKey || '');
        }

        function posCanonicalFeatureKey(featureKey) {
            var meta = typeof posPremiumVaultFeatureByFeatureKey === 'function'
                ? posPremiumVaultFeatureByFeatureKey(featureKey) : null;
            return meta ? meta.featureKey : String(featureKey || '');
        }

        /** Sync Supabase feature entitlements into persisted purchasedFeatures (survives bootstrap reload). */
        function syncPurchasedFeaturesFromEntitlements() {
            if (!db || !db.settings) return;
            var ent = db.subscription_entitlements;
            if (!ent || !ent.features || typeof ent.features !== 'object') return;
            if (!db.settings.purchasedFeatures || typeof db.settings.purchasedFeatures !== 'object') {
                db.settings.purchasedFeatures = {};
            }
            ensurePremiumFeatureUnlocks();
            Object.keys(ent.features).forEach(function(fkey) {
                if (!ent.features[fkey]) return;
                var canon = posCanonicalFeatureKey(fkey);
                var vaultKey = posCanonicalVaultSettingsKey(fkey);
                db.settings.purchasedFeatures[canon] = true;
                db.settings.premiumFeatureUnlocks[vaultKey] = true;
                if (!db.settings.premiumFeatureForceLocked || typeof db.settings.premiumFeatureForceLocked !== 'object') {
                    db.settings.premiumFeatureForceLocked = {};
                }
                db.settings.premiumFeatureForceLocked[vaultKey] = false;
            });
        }

        /** Pull $50 purchases from Supabase (e.g. redeemed in owner-admin, not in POS). */
        function repairPremiumFeatureEntitlementsFromServer() {
            if (window.__posEntitlementsRepairPromise) return window.__posEntitlementsRepairPromise;
            if (!db || !db.license_serial) return Promise.resolve(false);
            var url = (typeof window.posRouterUrl === 'function')
                ? window.posRouterUrl('action=repair_feature_entitlements')
                : '?action=repair_feature_entitlements';
            window.__posEntitlementsRepairPromise = fetch(url, { credentials: 'same-origin' })
                .then(function(r) { return r.json(); })
                .then(function(d) {
                    if (!d || d.status !== 'success' || !db) return false;
                    if (d.subscription_entitlements) db.subscription_entitlements = d.subscription_entitlements;
                    if (d.settings && typeof d.settings === 'object') {
                        if (!db.settings) db.settings = {};
                        if (d.settings.purchasedFeatures) db.settings.purchasedFeatures = d.settings.purchasedFeatures;
                        if (d.settings.premiumFeatureUnlocks) db.settings.premiumFeatureUnlocks = d.settings.premiumFeatureUnlocks;
                        if (d.settings.premiumFeatureForceLocked) db.settings.premiumFeatureForceLocked = d.settings.premiumFeatureForceLocked;
                    }
                    syncPurchasedFeaturesFromEntitlements();
                    enforcePremiumGatedSettingsRuntime();
                    if (typeof applyPremiumSettingsUI === 'function') applyPremiumSettingsUI();
                    if (typeof applyPrintSettings === 'function') applyPrintSettings();
                    return true;
                })
                .catch(function() { return false; });
            return window.__posEntitlementsRepairPromise;
        }

        function posMarkFeaturePurchased(featureKey) {
            if (!featureKey || !db || !db.settings) return;
            if (!db.settings.purchasedFeatures || typeof db.settings.purchasedFeatures !== 'object') {
                db.settings.purchasedFeatures = {};
            }
            db.settings.purchasedFeatures[String(featureKey)] = true;
        }

        /**
         * Stock qty badge is Basic (free) — was wrongly Pro-gated and forced OFF on free shops.
         * One-time: restore ON when the vault had never unlocked/purchased this feature.
         */
        function migrateShowStockOnPosToBasic() {
            try {
                if (localStorage.getItem('pos_stock_on_pos_basic_v1') === '1') return;
            } catch (eLs) {}
            if (!db || !db.settings) return;
            var unlocks = db.settings.premiumFeatureUnlocks;
            var wasVaultLocked = !(unlocks && typeof unlocks === 'object' && unlocks.showStockOnPos);
            var purchased = typeof hasPurchasedFeature === 'function' && hasPurchasedFeature('showStockOnPos');
            if (!purchased && wasVaultLocked) {
                db.settings.showStockOnPos = true;
            } else if (db.settings.showStockOnPos === undefined || db.settings.showStockOnPos === null || db.settings.showStockOnPos === '') {
                db.settings.showStockOnPos = true;
            }
            if (unlocks && typeof unlocks === 'object') delete unlocks.showStockOnPos;
            if (db.settings.premiumFeatureForceLocked && typeof db.settings.premiumFeatureForceLocked === 'object') {
                delete db.settings.premiumFeatureForceLocked.showStockOnPos;
            }
            try { localStorage.setItem('pos_stock_on_pos_basic_v1', '1'); } catch (eLs2) {}
            if (typeof saveSettings === 'function') {
                try { saveSettings().catch(function() {}); } catch (eSave) {}
            }
        }

        /** Keep premium-gated toggles OFF until Pro/Pro Plus activation (server tier). */
        function enforcePremiumGatedSettingsRuntime() {
            if (!db || !db.settings) return;
            if (hasPremiumEntitlement()) return;
            ensurePremiumFeatureUnlocks();
            if (typeof canUsePrintNotes === 'function' && !canUsePrintNotes()) {
                db.settings.showPrintNotePopup = false;
            }
            POS_PREMIUM_VAULT_FEATURES.forEach(function(meta) {
                if (meta.featureKey && typeof hasPurchasedFeature === 'function' && hasPurchasedFeature(meta.featureKey)) return;
                if (isPremiumFeatureUnlocked(meta.id)) return;
                if (meta.key === 'fabMenu') {
                    try { localStorage.setItem('pos_fab_visible', 'false'); } catch (eFab) {}
                    return;
                }
                db.settings[meta.key] = false;
            });
        }

        function applyPremiumStartup() {
            if (!db || !db.settings) return;
            syncPurchasedFeaturesFromEntitlements();
            migrateShowStockOnPosToBasic();
            enforcePremiumGatedSettingsRuntime();
            if (!hasPremiumEntitlement()) {
                var shiftKeys = ['requireOpeningBalancePrompt', 'requireEndShiftReconcilePrompt'];
                var missingPurchase = shiftKeys.some(function(k) {
                    return typeof hasPurchasedFeature === 'function' && !hasPurchasedFeature(k);
                });
                if (missingPurchase && db.license_serial && typeof repairPremiumFeatureEntitlementsFromServer === 'function') {
                    repairPremiumFeatureEntitlementsFromServer();
                }
            }
            if (typeof applySubscriptionBadge === 'function') applySubscriptionBadge();
            if (typeof applyMultiDeviceSettingsUI === 'function') applyMultiDeviceSettingsUI();
            if (typeof applyPremiumSettingsUI === 'function') applyPremiumSettingsUI();
            if (typeof normalizePosManufacturerSlotSettings === 'function') normalizePosManufacturerSlotSettings();
            if (typeof applyProductFormPremiumFeatureFields === 'function') applyProductFormPremiumFeatureFields();
            if (typeof applyFabVisibility === 'function') applyFabVisibility();
            if (typeof applyManualSaleVisibility === 'function') applyManualSaleVisibility();
            if (typeof applyFeatureVisibility === 'function') applyFeatureVisibility();
            if (typeof applyPrintNotePremiumUI === 'function') applyPrintNotePremiumUI();
            if (typeof applyMultiWarehouseVisibility === 'function') applyMultiWarehouseVisibility();
            if (typeof applyJumlaSystemGlobally === 'function') applyJumlaSystemGlobally();
            if (typeof renderManufacturers === 'function' && window.companiesActiveTab === 'manufacturers') renderManufacturers();
            if (typeof applyPurchaseBatchPremiumUi === 'function') applyPurchaseBatchPremiumUi();
            if (typeof bindTechSpecsSplitGesture === 'function') bindTechSpecsSplitGesture();
        }

        function isPremiumFeatureUnlocked(checkboxId) {
            if (hasPremiumEntitlement()) return true;
            var meta = posPremiumVaultFeatureById(checkboxId);
            if (!meta || !meta.featureKey) return false;
            ensurePremiumFeatureUnlocks();
            var forcedLocked = !!(db && db.settings && db.settings.premiumFeatureForceLocked && db.settings.premiumFeatureForceLocked[meta.key] === true);
            if (forcedLocked) return false;
            var purchased = typeof hasPurchasedFeature === 'function' && hasPurchasedFeature(meta.featureKey);
            if (purchased) return true;
            var unlocks = db && db.settings && db.settings.premiumFeatureUnlocks;
            if (!unlocks) return false;
            if (unlocks[meta.key]) return true;
            var lk = String(meta.key || '').toLowerCase();
            return !!unlocks[lk];
        }

        function setPremiumFeatureUnlocked(checkboxId, unlocked) {
            if (hasPremiumEntitlement()) return;
            ensurePremiumFeatureUnlocks();
            var meta = posPremiumVaultFeatureById(checkboxId);
            if (!meta) return;
            if (!db.settings.premiumFeatureForceLocked || typeof db.settings.premiumFeatureForceLocked !== 'object') {
                db.settings.premiumFeatureForceLocked = {};
            }
            var isPurchased = typeof hasPurchasedFeature === 'function' && hasPurchasedFeature(meta.featureKey);
            db.settings.premiumFeatureUnlocks[meta.key] = !!unlocked;
            if (isPurchased) {
                db.settings.premiumFeatureForceLocked[meta.key] = !unlocked;
            } else {
                db.settings.premiumFeatureForceLocked[meta.key] = false;
            }
        }

        function applySubscriptionBadge() {
            var tier = getSubscriptionTier();
            var isPro = tier === 'pro';
            var isPlus = tier === 'pro_plus';
            var hasPaid = isPro || isPlus;
            var label = '';
            if (isPlus) label = (typeof t === 'function') ? t('subscription_badge_pro_plus') : 'PRO PLUS';
            else if (isPro) label = (typeof t === 'function') ? t('subscription_badge_pro') : 'PRO';

            if (document.body) {
                if (hasPaid) document.body.setAttribute('data-sub-tier', tier);
                else document.body.removeAttribute('data-sub-tier');
            }

            var badge = document.querySelector('.right-sidebar-premium-btn__badge');
            var wrap = document.getElementById('right-sidebar-premium-wrap');
            var titleEl = document.querySelector('.right-sidebar-premium-btn__title');
            var subEl = document.querySelector('.right-sidebar-premium-btn__sub');
            var iconEl = document.querySelector('.right-sidebar-premium-btn__icon i');
            var leftLink = document.querySelector('.sidebar-premium-link');
            var leftLinkIcon = leftLink ? leftLink.querySelector('i') : null;
            var leftLinkText = leftLink ? leftLink.querySelector('span[data-i18n], span:not(.fas)') : null;

            if (badge) {
                badge.textContent = label;
                badge.style.display = label ? '' : 'none';
            }
            if (wrap) {
                wrap.classList.toggle('has-tier-pro', isPro);
                wrap.classList.toggle('has-tier-pro-plus', isPlus);
                wrap.classList.toggle('is-tier-owned', hasPaid);
            }
            if (titleEl) {
                if (isPlus) titleEl.textContent = (typeof t === 'function') ? t('sidebar_premium_owned_plus_title') : 'Pro Plus ✓';
                else if (isPro) titleEl.textContent = (typeof t === 'function') ? t('sidebar_premium_owned_pro_title') : 'Pro چالاکە ✓';
                else titleEl.textContent = (typeof t === 'function') ? t('sidebar_premium_title') : 'وەشانا پارەدار';
            }
            if (subEl) {
                if (isPlus) subEl.textContent = (typeof t === 'function') ? t('sidebar_premium_owned_plus_sub') : 'باشترین پلان — هەموو تایبەتمەندی';
                else if (isPro) subEl.textContent = (typeof t === 'function') ? t('sidebar_premium_owned_pro_sub') : 'بەرز بکە بۆ Pro Plus';
                else subEl.textContent = (typeof t === 'function') ? t('sidebar_premium_sub') : 'Pro · Pro Plus';
            }
            if (iconEl) iconEl.className = isPlus ? 'fas fa-gem' : 'fas fa-crown';
            if (leftLink) {
                leftLink.classList.toggle('is-tier-pro', isPro);
                leftLink.classList.toggle('is-tier-pro-plus', isPlus);
                leftLink.classList.toggle('is-tier-owned', hasPaid);
            }
            if (leftLinkIcon) leftLinkIcon.className = isPlus ? 'fas fa-gem' : 'fas fa-crown';
            if (leftLinkText && hasPaid) {
                leftLinkText.textContent = isPlus
                    ? ((typeof t === 'function') ? t('sidebar_premium_owned_plus_title') : 'Pro Plus ✓')
                    : ((typeof t === 'function') ? t('sidebar_premium_owned_pro_title') : 'Pro چالاکە ✓');
            } else if (leftLinkText && typeof t === 'function') {
                leftLinkText.textContent = t('sidebar_premium_title');
            }

            var headerBadge = document.getElementById('top-header-tier-badge');
            var headerLabel = document.getElementById('top-header-tier-label');
            var headerIcon = headerBadge ? headerBadge.querySelector('i') : null;
            if (headerBadge) {
                headerBadge.style.display = hasPaid ? 'inline-flex' : 'none';
                headerBadge.classList.toggle('is-pro', isPro);
                headerBadge.classList.toggle('is-pro-plus', isPlus);
                headerBadge.setAttribute('aria-hidden', hasPaid ? 'false' : 'true');
            }
            if (headerLabel && label) headerLabel.textContent = label;
            if (headerIcon) headerIcon.className = isPlus ? 'fas fa-gem' : 'fas fa-crown';

            var homeBanner = document.getElementById('home-tier-banner');
            var homeTitle = document.getElementById('home-tier-banner-title');
            var homeDesc = document.getElementById('home-tier-banner-desc');
            var homeBadgeEl = document.getElementById('home-tier-banner-badge');
            var homeIcon = homeBanner ? homeBanner.querySelector('.home-tier-banner__icon i') : null;
            if (homeBanner) {
                homeBanner.style.display = hasPaid ? 'flex' : 'none';
                homeBanner.classList.toggle('is-pro', isPro);
                homeBanner.classList.toggle('is-pro-plus', isPlus);
                homeBanner.setAttribute('aria-hidden', hasPaid ? 'false' : 'true');
            }
            if (homeTitle) {
                if (isPlus) homeTitle.textContent = (typeof t === 'function') ? t('tier_pro_plus_hero_title') : 'Pro Plus — باشترین وەشان';
                else if (isPro) homeTitle.textContent = (typeof t === 'function') ? t('tier_pro_hero_title') : 'Pro — وەشانا پارەدار چالاکە';
                else homeTitle.textContent = '';
            }
            if (homeDesc) {
                if (isPlus) homeDesc.textContent = (typeof t === 'function') ? t('tier_pro_plus_hero_desc') : 'کارمەند بێ سنوور · چەند ئامێر · خانەی لاوەکی · VIP';
                else if (isPro) homeDesc.textContent = (typeof t === 'function') ? t('tier_pro_hero_desc') : '٥ کارمەند · POS تەواو · خانەی لاوەکی · هەموو تایبەتمەندی Pro';
                else homeDesc.textContent = '';
            }
            if (homeBadgeEl && label) homeBadgeEl.textContent = label;
            if (homeIcon) homeIcon.className = isPlus ? 'fas fa-gem' : 'fas fa-crown';

            if (typeof syncPremiumLockPlanOptions === 'function') syncPremiumLockPlanOptions();
        }

        /** Hide plan/code options the customer already owns. */
        function syncPremiumLockPlanOptions() {
            var tier = getSubscriptionTier();
            var showPro = tier === 'free';
            var showPlus = tier === 'free' || tier === 'pro';
            var proBtn = document.querySelector('.premium-lock-popup__plan[data-tier="pro"]');
            var plusBtn = document.querySelector('.premium-lock-popup__plan[data-tier="pro_plus"]');
            var intro = document.querySelector('#premium-lock-popup .premium-lock-popup__intro');
            var plansWrap = document.querySelector('.premium-lock-popup__plans');
            var footer = document.querySelector('#premium-lock-popup .premium-lock-popup__footer');
            if (proBtn) proBtn.style.display = showPro ? '' : 'none';
            if (plusBtn) plusBtn.style.display = showPlus ? '' : 'none';
            if (plansWrap) plansWrap.style.display = (showPro || showPlus) ? '' : 'none';
            if (intro) {
                if (tier === 'pro_plus') {
                    intro.style.display = 'none';
                } else {
                    intro.style.display = '';
                    intro.textContent = tier === 'pro'
                        ? ((typeof t === 'function') ? t('premium_lock_intro_plus_only') : 'Pro چالاکە — تەنها کۆدی Pro Plus بنووسە بۆ بەرزکردنەوە:')
                        : ((typeof t === 'function') ? t('premium_lock_popup_intro') : 'پلانێ هەڵبژێرە و کۆدی چالاککردن بنووسە:');
                }
            }
            if (footer) footer.style.display = tier === 'pro_plus' ? 'none' : '';
        }
        window.syncPremiumLockPlanOptions = syncPremiumLockPlanOptions;

        function applyMultiDeviceSettingsUI() {
            var card = document.getElementById('settings-sub-device-mgmt-card');
            var legacyCard = document.getElementById('settings-multi-device-card');
            var fbCard = document.getElementById('settings-firebase-sync-card');
            var tier = getSubscriptionTier();
            var canBranch = tier === 'pro' || tier === 'pro_plus';
            var chk = document.getElementById('set-enable-multi-device');
            var gate = document.getElementById('subdev-tier-gate');
            var body = document.getElementById('subdev-mgmt-body');
            if (card) card.style.display = '';
            if (legacyCard) legacyCard.style.display = 'none';
            if (gate) gate.style.display = canBranch ? 'none' : 'block';
            if (body) body.style.display = canBranch ? 'block' : 'none';
            if (chk) {
                if (db && db.settings && db.settings.enableMultiDeviceTerminal) chk.checked = true;
                chk.disabled = !canBranch;
                if (!canBranch && chk.checked) {
                    chk.checked = false;
                    if (db && db.settings) db.settings.enableMultiDeviceTerminal = false;
                }
            }
            var lockHint = document.getElementById('settings-multi-device-lock-hint');
            if (lockHint) lockHint.style.display = (tier === 'pro') ? 'block' : 'none';
            if (fbCard) fbCard.style.opacity = (tier === 'free' || (tier === 'pro' && chk && !chk.checked)) ? '0.55' : '1';
            if (canBranch && typeof loadSubDeviceNetworkPanel === 'function') {
                loadSubDeviceNetworkPanel(false);
            }
            if (typeof applyTerminalSecuritySettingsUI === 'function') applyTerminalSecuritySettingsUI();
        }

        function openSubDeviceNetworkModal() {
            var modal = document.getElementById('sub-device-network-modal');
            if (modal) modal.style.display = 'flex';
            if (typeof applyMultiDeviceSettingsUI === 'function') applyMultiDeviceSettingsUI();
        }
        function closeSubDeviceNetworkModal() {
            var modal = document.getElementById('sub-device-network-modal');
            if (modal) modal.style.display = 'none';
        }
        window.openSubDeviceNetworkModal = openSubDeviceNetworkModal;
        window.closeSubDeviceNetworkModal = closeSubDeviceNetworkModal;

        var _subdevPollTimer = null;
        var _subdevLastPayload = null;
        var _subdevSlotRedeemOpen = null;

        function subdevEscapeHtml(s) {
            return String(s || '')
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;');
        }

        function subdevSlotKindFromStatus(status) {
            var st = String(status || 'empty').toLowerCase();
            if (st === 'active') return 'verified';
            if (st === 'pending') return 'pending';
            if (st === 'empty') return 'available';
            return 'locked';
        }

        function subdevReleaseTerminalSlot(slotId, slotNumber) {
            if (!slotId) return;
            var msg = (typeof t === 'function')
                ? t('subdev_slot_release_confirm')
                : 'Remove the assigned device from this slot? The seat stays yours — connect a new terminal later.';
            if (!window.confirm(msg)) return;
            var fd = new FormData();
            fd.append('action', 'release_terminal_license_slot');
            fd.append('slot_id', slotId);
            var url = (typeof window.posRouterUrl === 'function') ? window.posRouterUrl('') : '?';
            var headers = {};
            try {
                if (typeof window.__posDeviceKey === 'string' && window.__posDeviceKey) {
                    headers['X-POS-Device-Key'] = window.__posDeviceKey;
                }
            } catch (_eH) {}
            fetch(url, { method: 'POST', body: fd, credentials: 'same-origin', headers: headers })
                .then(function (r) { return r.json(); })
                .then(function (d) {
                    if (d && d.status === 'success') {
                        if (typeof loadSubDeviceNetworkPanel === 'function') loadSubDeviceNetworkPanel(true);
                        return;
                    }
                    window.alert((d && d.message) ? d.message : 'Could not release slot.');
                })
                .catch(function () {
                    window.alert((typeof t === 'function') ? t('activation_code_network_error') : 'Network error');
                });
        }

        function subdevToggleSlotRedeem(slotNumber) {
            _subdevSlotRedeemOpen = (_subdevSlotRedeemOpen === slotNumber) ? null : slotNumber;
            if (_subdevLastPayload && typeof renderSubDeviceLicenseSlots === 'function') {
                renderSubDeviceLicenseSlots(_subdevLastPayload);
            }
        }

        function subdevSubmitSlotPurchaseCode(slotNumber) {
            var inp = document.getElementById('subdev-slot-code-' + slotNumber);
            var msgEl = document.getElementById('subdev-slot-msg-' + slotNumber);
            var code = inp ? String(inp.value || '').trim() : '';
            if (!code) {
                if (msgEl) {
                    msgEl.style.display = 'block';
                    msgEl.style.color = '#fca5a5';
                    msgEl.textContent = (typeof t === 'function') ? t('terminal_activation_code_empty') : 'Enter activation code.';
                }
                return;
            }
            var fd = new FormData();
            fd.append('action', 'redeem_terminal_slot_purchase_code');
            fd.append('code', code);
            fd.append('slot_number', String(slotNumber));
            var url = (typeof window.posRouterUrl === 'function') ? window.posRouterUrl('') : '?';
            var headers = {};
            try {
                if (typeof window.__posDeviceKey === 'string' && window.__posDeviceKey) {
                    headers['X-POS-Device-Key'] = window.__posDeviceKey;
                }
            } catch (_eH) {}
            if (msgEl) {
                msgEl.style.display = 'block';
                msgEl.style.color = '#94a3b8';
                msgEl.textContent = '…';
            }
            fetch(url, { method: 'POST', body: fd, credentials: 'same-origin', headers: headers })
                .then(function (r) { return r.json(); })
                .then(function (d) {
                    if (d && d.status === 'success') {
                        _subdevSlotRedeemOpen = null;
                        if (d.security_code && msgEl) {
                            msgEl.style.display = 'block';
                            msgEl.style.color = '#86efac';
                            msgEl.innerHTML = ((typeof t === 'function') ? t('subdev_slot_gen_code_hint') : 'Enter on sub-device') +
                                ': <strong dir="ltr">' + subdevEscapeHtml(String(d.security_code)) + '</strong>';
                        }
                        if (typeof loadSubDeviceNetworkPanel === 'function') loadSubDeviceNetworkPanel(true);
                        return;
                    }
                    if (msgEl) {
                        msgEl.style.display = 'block';
                        msgEl.style.color = '#fca5a5';
                        msgEl.textContent = (d && d.message) ? d.message : 'Invalid code.';
                    }
                })
                .catch(function () {
                    if (msgEl) {
                        msgEl.style.display = 'block';
                        msgEl.style.color = '#fca5a5';
                        msgEl.textContent = (typeof t === 'function') ? t('activation_code_network_error') : 'Network error';
                    }
                });
        }

        function subdevCopySlotSecurityCode(code) {
            var c = String(code || '').trim();
            if (!c) return;
            try {
                if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(c);
                    return;
                }
            } catch (_eCp) {}
            try {
                var ta = document.createElement('textarea');
                ta.value = c;
                document.body.appendChild(ta);
                ta.select();
                document.execCommand('copy');
                document.body.removeChild(ta);
            } catch (_eCp2) {}
        }

        function subdevGenerateSlotSecurityCode(slotId, slotNumber) {
            if (!slotId) return;
            var msgEl = document.getElementById('subdev-slot-active-msg-' + slotNumber);
            var fd = new FormData();
            fd.append('action', 'generate_slot_terminal_security_code');
            fd.append('slot_id', slotId);
            var url = (typeof window.posRouterUrl === 'function') ? window.posRouterUrl('') : '?';
            var headers = {};
            try {
                if (typeof window.__posDeviceKey === 'string' && window.__posDeviceKey) {
                    headers['X-POS-Device-Key'] = window.__posDeviceKey;
                }
            } catch (_eGh) {}
            if (msgEl) {
                msgEl.style.display = 'block';
                msgEl.style.color = '#94a3b8';
                msgEl.textContent = '…';
            }
            fetch(url, { method: 'POST', body: fd, credentials: 'same-origin', headers: headers })
                .then(function (r) { return r.json(); })
                .then(function (d) {
                    if (d && d.status === 'success') {
                        if (d.security_code && typeof showToast === 'function') {
                            showToast('✅ کۆد: ' + String(d.security_code) + ' — لە لاپتۆپێ فرعی بنووسە', false);
                        }
                        if (typeof loadSubDeviceNetworkPanel === 'function') loadSubDeviceNetworkPanel(true);
                        return;
                    }
                    if (msgEl) {
                        msgEl.style.display = 'block';
                        msgEl.style.color = '#fca5a5';
                        msgEl.textContent = (d && d.message) ? d.message : 'Could not generate code.';
                    }
                })
                .catch(function () {
                    if (msgEl) {
                        msgEl.style.display = 'block';
                        msgEl.style.color = '#fca5a5';
                        msgEl.textContent = (typeof t === 'function') ? t('activation_code_network_error') : 'Network error';
                    }
                });
        }

        window.subdevToggleSlotRedeem = subdevToggleSlotRedeem;
        window.subdevSubmitSlotPurchaseCode = subdevSubmitSlotPurchaseCode;
        window.subdevReleaseTerminalSlot = subdevReleaseTerminalSlot;
        window.subdevGenerateSlotSecurityCode = subdevGenerateSlotSecurityCode;
        window.subdevCopySlotSecurityCode = subdevCopySlotSecurityCode;

        function renderSubDeviceLicenseSlots(data) {
            var el = document.getElementById('subdev-license-slots');
            if (!el || !data) return;
            var purchased = parseInt(data.terminal_slots_purchased, 10) || 0;
            var dbSlots = Array.isArray(data.license_slots) ? data.license_slots.slice() : [];
            var slots = [];
            var i;

            if (dbSlots.length) {
                dbSlots.forEach(function (row) {
                    slots.push({
                        kind: subdevSlotKindFromStatus(row.status),
                        index: parseInt(row.slot_number, 10) || slots.length + 1,
                        slot_id: row.id || '',
                        device_key: row.device_key || '',
                        network_mac: row.network_mac || '',
                        network_type: row.network_type || '',
                        device_status: row.device_status || row.status || '',
                        security_code: row.security_code || ''
                    });
                });
            } else {
                var terminals = Array.isArray(data.terminals) ? data.terminals.slice() : [];
                var approved = terminals.filter(function (d) { return d.status === 'approved'; });
                var pending = terminals.filter(function (d) { return d.status === 'pending'; });
                for (i = 0; i < Math.max(purchased, approved.length + pending.length); i++) {
                    if (i < approved.length) {
                        slots.push({ kind: 'verified', device: approved[i], index: i + 1, slot_id: approved[i].terminal_slot_id || '' });
                    } else if (i - approved.length < pending.length) {
                        slots.push({ kind: 'pending', device: pending[i - approved.length], index: i + 1, slot_id: pending[i - approved.length].terminal_slot_id || '' });
                    } else if (i < purchased) {
                        slots.push({ kind: 'available', index: i + 1 });
                    }
                }
            }

            var upsell = 2;
            var maxNum = slots.length ? Math.max.apply(null, slots.map(function (s) { return s.index || 0; })) : purchased;
            for (i = 1; i <= upsell; i++) {
                var lockNum = maxNum + i;
                if (!slots.some(function (s) { return s.index === lockNum; })) {
                    slots.push({ kind: 'locked', index: lockNum });
                }
            }

            if (!slots.length) {
                slots.push({ kind: 'locked', index: 1 });
                slots.push({ kind: 'locked', index: 2 });
            }

            el.innerHTML = slots.map(function (slot) {
                var cls = 'subdev-slot subdev-slot--' + slot.kind;
                var num = slot.index;
                var redeemOpen = _subdevSlotRedeemOpen === num;

                if (slot.kind === 'verified' || slot.kind === 'pending') {
                    var devKey = slot.device_key || (slot.device && slot.device.device_key) || '';
                    var mac = slot.network_mac || (slot.device && slot.device.network_mac) || '';
                    var title = slot.kind === 'verified'
                        ? ((typeof t === 'function') ? t('subdev_slot_verified') : 'Verified')
                        : ((typeof t === 'function') ? t('subdev_slot_pending') : 'Pending');
                    return (
                        '<div class="' + cls + ' subdev-slot--managed" data-slot-id="' + subdevEscapeHtml(slot.slot_id || '') + '">' +
                        '<div class="subdev-slot__icon"><i class="fas fa-' + (slot.kind === 'verified' ? 'circle-check' : 'hourglass-half') + '"></i></div>' +
                        '<div class="subdev-slot__title">' + title + ' #' + num + '</div>' +
                        '<div class="subdev-slot__sub">' + subdevEscapeHtml(subdevDeviceKeyHint(devKey)) + '</div>' +
                        (mac ? ('<div class="subdev-slot__mac" dir="ltr">' + subdevEscapeHtml(mac) + '</div>') : '') +
                        '<div class="subdev-slot__actions">' +
                        '<button type="button" class="btn btn-dark btn-xs subdev-slot-action" onclick="subdevReleaseTerminalSlot(\'' + subdevEscapeHtml(slot.slot_id || '') + '\',' + num + ')">' +
                        '<i class="fas fa-right-left"></i> ' + ((typeof t === 'function') ? t('subdev_slot_transfer') : 'Transfer') +
                        '</button></div></div>'
                    );
                }

                if (slot.kind === 'available') {
                    var secCode = slot.security_code ? String(slot.security_code) : '';
                    var codeBlock = secCode
                        ? ('<div class="subdev-slot__code" dir="ltr">' + subdevEscapeHtml(secCode) + '</div>' +
                            '<button type="button" class="btn btn-dark btn-xs subdev-slot-action" onclick="subdevCopySlotSecurityCode(\'' + subdevEscapeHtml(secCode) + '\')">' +
                            '<i class="fas fa-copy"></i> ' + ((typeof t === 'function') ? t('subdev_slot_copy_code') : 'Copy') + '</button>')
                        : ('<button type="button" class="btn btn-brand btn-xs subdev-slot-action" onclick="subdevGenerateSlotSecurityCode(\'' + subdevEscapeHtml(slot.slot_id || '') + '\',' + num + ')">' +
                            '<i class="fas fa-key"></i> ' + ((typeof t === 'function') ? t('subdev_slot_gen_code') : 'Generate code') + '</button>');
                    return (
                        '<div class="' + cls + '" data-slot-id="' + subdevEscapeHtml(slot.slot_id || '') + '">' +
                        '<div class="subdev-slot__icon"><i class="fas fa-unlock"></i></div>' +
                        '<div class="subdev-slot__title">' + ((typeof t === 'function') ? t('subdev_slot_unlocked') : 'Unlocked') + ' #' + num + '</div>' +
                        '<div class="subdev-slot__sub">' + ((typeof t === 'function') ? t('subdev_slot_security_code_label') : 'Security code') + '</div>' +
                        codeBlock +
                        '<p class="subdev-slot__hint">' + ((typeof t === 'function') ? t('subdev_slot_gen_code_hint') : 'Enter on sub-device in Settings') + '</p>' +
                        '<p id="subdev-slot-active-msg-' + num + '" class="subdev-slot-redeem__msg" style="display:none;"></p>' +
                        (secCode ? ('<button type="button" class="btn btn-dark btn-xs subdev-slot-action" style="margin-top:6px;" onclick="subdevGenerateSlotSecurityCode(\'' + subdevEscapeHtml(slot.slot_id || '') + '\',' + num + ')">' +
                            '<i class="fas fa-rotate"></i> ' + ((typeof t === 'function') ? t('subdev_slot_gen_code') : 'New code') + '</button>') : '') +
                        '</div>'
                    );
                }

                return (
                    '<div class="' + cls + ' subdev-slot--locked-click' + (redeemOpen ? ' is-redeem-open' : '') + '" role="button" tabindex="0" onclick="if(!event.target.closest(\'.subdev-slot-redeem\'))subdevToggleSlotRedeem(' + num + ')">' +
                    '<div class="subdev-slot__icon"><i class="fas fa-lock"></i></div>' +
                    '<div class="subdev-slot__title">' + ((typeof t === 'function') ? t('subdev_slot_locked') : 'Premium') + ' #' + num + '</div>' +
                    '<div class="subdev-slot__price"><i class="fas fa-shield-halved"></i> ' + ((typeof t === 'function') ? t('subdev_slot_security_label') : 'Sub-laptop security') + '</div>' +
                    (redeemOpen ? '' : ('<div class="subdev-slot__tap">' + ((typeof t === 'function') ? t('subdev_slot_click_unlock') : 'Click to enter code') + '</div>')) +
                    '<div class="subdev-slot-redeem" style="' + (redeemOpen ? '' : 'display:none;') + '" onclick="event.stopPropagation()">' +
                    '<input type="text" id="subdev-slot-code-' + num + '" dir="ltr" placeholder="TERM-XXXX-XXXX" autocomplete="off" class="subdev-slot-redeem__input" />' +
                    '<button type="button" class="btn btn-brand btn-xs subdev-slot-redeem__btn" onclick="subdevSubmitSlotPurchaseCode(' + num + ')">' +
                    '<i class="fas fa-key"></i> ' + ((typeof t === 'function') ? t('subdev_slot_unlock_btn') : 'Unlock') +
                    '</button>' +
                    '<p id="subdev-slot-msg-' + num + '" class="subdev-slot-redeem__msg" style="display:none;"></p>' +
                    '</div></div>'
                );
            }).join('');
        }

        function subdevDeviceKeyHint(key) {
            var k = String(key || '');
            if (k.length <= 16) return k || '—';
            return k.slice(0, 8) + '…' + k.slice(-4);
        }

        function subdevNetworkLabel(ip) {
            var s = String(ip || '').trim();
            if (!s) return (typeof t === 'function') ? t('subdev_network_unknown') : 'Network';
            if (/^(10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[0-1])\.|127\.|::1|fe80:)/i.test(s)) {
                return (typeof t === 'function') ? t('subdev_network_lan') : 'LAN / Wi‑Fi';
            }
            return (typeof t === 'function') ? t('subdev_network_remote') : 'Network';
        }

        function subdevStatusLabel(status) {
            var s = String(status || 'pending').toLowerCase();
            if (s === 'approved') return (typeof t === 'function') ? t('subdev_status_authorized') : 'Authorized';
            if (s === 'blocked') return (typeof t === 'function') ? t('subdev_status_blocked') : 'Blocked';
            return (typeof t === 'function') ? t('subdev_status_pending') : 'Pending';
        }

        function renderSubDevicePurchaseHistory(data) {
            var el = document.getElementById('subdev-purchase-history');
            if (!el || !data) return;
            var rows = Array.isArray(data.purchase_history) ? data.purchase_history : [];
            if (!rows.length) {
                el.innerHTML = '<p class="subdev-empty">' + ((typeof t === 'function') ? t('subdev_no_history') : 'No purchase history yet.') + '</p>';
                return;
            }
            el.innerHTML = rows.map(function (row) {
                var when = String(row.created_at || '').slice(0, 16).replace('T', ' ');
                var dev = row.device_key ? subdevDeviceKeyHint(row.device_key) : '—';
                var note = row.note ? String(row.note) : '';
                var delta = parseInt(row.slots_delta, 10) || 0;
                var label = row.event_type === 'assign'
                    ? ((typeof t === 'function') ? t('subdev_hist_assign') : 'Assigned')
                    : ((typeof t === 'function') ? t('subdev_hist_purchase') : 'Purchase');
                return (
                    '<div class="subdev-history-item">' +
                    '<strong>' + label + '</strong>' +
                    (delta > 0 ? (' · +' + delta + ' ' + ((typeof t === 'function') ? t('subdev_hist_slots') : 'slots')) : '') +
                    ' · ' + when +
                    (dev !== '—' ? (' · ' + dev) : '') +
                    (note ? (' · ' + note) : '') +
                    '</div>'
                );
            }).join('');
        }

        function renderSubDeviceConnectionList(data) {
            var el = document.getElementById('subdev-device-list');
            if (!el || !data) return;
            var terminals = Array.isArray(data.terminals) ? data.terminals : [];
            if (!terminals.length) {
                el.innerHTML = '<p class="subdev-empty">' + ((typeof t === 'function') ? t('subdev_no_connections') : 'No sub-devices connected yet.') + '</p>';
                return;
            }
            el.innerHTML = terminals.map(function (dev, idx) {
                var st = String(dev.status || 'pending').toLowerCase();
                var stCls = st === 'approved' ? 'approved' : (st === 'blocked' ? 'blocked' : 'pending');
                var plat = dev.platform ? String(dev.platform) : '';
                var ip = dev.registration_ip ? String(dev.registration_ip) : '';
                var net = subdevNetworkLabel(ip);
                var mac = dev.network_mac ? String(dev.network_mac) : '';
                return (
                    '<div class="subdev-device-row">' +
                    '<div class="subdev-device-row__main">' +
                    '<div class="subdev-device-row__title">' +
                    '<i class="fas fa-tablet-screen-button"></i> ' +
                    ((typeof t === 'function') ? t('subdev_terminal_label') : 'Terminal') + ' ' + (idx + 1) +
                    '</div>' +
                    '<div class="subdev-device-row__meta">' +
                    subdevDeviceKeyHint(dev.device_key) +
                    ' · ' + net +
                    (mac ? (' · ' + mac) : '') +
                    (ip ? (' · ' + ip) : '') +
                    (plat ? (' · ' + plat) : '') +
                    '</div>' +
                    '</div>' +
                    '<span class="subdev-status subdev-status--' + stCls + '">' + subdevStatusLabel(st) + '</span>' +
                    (st !== 'approved' ? ('<span class="subdev-price-tag" style="font-size:0.72rem;"><i class="fas fa-shield-halved"></i> ' + ((typeof t === 'function') ? t('subdev_slot_security_label') : 'Security') + '</span>') : '') +
                    '</div>'
                );
            }).join('');
        }

        function renderSubDeviceNetworkPanel(data) {
            if (!data || !data.ok) return;
            _subdevLastPayload = data;
            var purchased = parseInt(data.terminal_slots_purchased, 10) || 0;
            var serialEl = document.getElementById('subdev-primary-serial');
            var metaEl = document.getElementById('subdev-primary-meta');
            var capEl = document.getElementById('subdev-purchased-summary');
            var serial = data.installation_serial || (typeof window.__POS_PUBLIC_INSTALL_SERIAL__ !== 'undefined' ? window.__POS_PUBLIC_INSTALL_SERIAL__ : '');
            if (serialEl) serialEl.textContent = serial || '—';
            if (metaEl) {
                var pk = data.primary_device && data.primary_device.device_key ? subdevDeviceKeyHint(data.primary_device.device_key) : '—';
                var pst = data.primary_device && data.primary_device.status ? subdevStatusLabel(data.primary_device.status) : '—';
                metaEl.textContent = ((typeof t === 'function') ? t('subdev_primary_device') : 'Primary device') + ': ' + pk + ' · ' + pst;
            }
            if (capEl) {
                capEl.textContent = purchased + ' ' + ((typeof t === 'function') ? t('subdev_terminals_purchased') : 'security slots');
            }
            var setStat = function (id, val) {
                var n = document.getElementById(id);
                if (n) n.textContent = String(val != null ? val : 0);
            };
            setStat('subdev-stat-connected', data.terminals_connected);
            setStat('subdev-stat-approved', data.terminals_approved);
            setStat('subdev-stat-pending', data.terminals_pending);
            setStat('subdev-stat-purchased', purchased);
            renderSubDeviceLicenseSlots(data);
            renderSubDevicePurchaseHistory(data);
            renderSubDeviceConnectionList(data);
            var errEl = document.getElementById('subdev-load-error');
            if (errEl) errEl.style.display = 'none';
        }

        function loadSubDeviceNetworkPanel(force) {
            if (!hasPremiumEntitlement()) {
                if (typeof applyMultiDeviceSettingsUI === 'function') applyMultiDeviceSettingsUI();
                return Promise.resolve();
            }
            var errEl = document.getElementById('subdev-load-error');
            var url = (typeof window.posRouterUrl === 'function')
                ? window.posRouterUrl('action=get_sub_device_network_status&t=' + Date.now())
                : ('?action=get_sub_device_network_status&t=' + Date.now());
            return (typeof apiJson === 'function' ? apiJson(url) : fetch(url, { credentials: 'same-origin' }).then(function (r) { return r.json(); }))
                .then(function (resp) {
                    if (resp && resp.status === 'success' && resp.data) {
                        renderSubDeviceNetworkPanel(resp.data);
                    } else if (errEl) {
                        errEl.style.display = 'block';
                        errEl.textContent = (resp && resp.message) ? resp.message : ((typeof t === 'function') ? t('subdev_load_error') : 'Could not load sub-device status.');
                    }
                })
                .catch(function () {
                    if (errEl) {
                        errEl.style.display = 'block';
                        errEl.textContent = (typeof t === 'function') ? t('activation_code_network_error') : 'Network error';
                    }
                });
        }
        window.loadSubDeviceNetworkPanel = loadSubDeviceNetworkPanel;

        function startSubDeviceNetworkPoll() {
            if (_subdevPollTimer) return;
            try {
                if (localStorage.getItem('pos_graphics_quality') === 'ultra') return;
            } catch (eGfxPoll) {}
            if (typeof window !== 'undefined' && window.POS_DEFER_SUBDEV_PANEL === true) return;
            var _subPollMs = (typeof posPollIntervalMs === 'function') ? posPollIntervalMs(30000) : 30000;
            _subdevPollTimer = setInterval(function () {
                var view = document.getElementById('view-settings');
                if (!view || !view.classList.contains('active')) return;
                if (!hasPremiumEntitlement()) return;
                loadSubDeviceNetworkPanel(false);
            }, _subPollMs);
        }
        startSubDeviceNetworkPoll();

        function redeemActivationCode(opts) {
            opts = opts || {};
            var inp = opts.inputEl || document.getElementById('settings-activation-code-input');
            var msgEl = opts.msgEl || document.getElementById('settings-activation-code-msg');
            var expectedTier = opts.expectedTier || null;
            var code = inp ? String(inp.value || '').trim() : '';
            if (!code) {
                if (msgEl) {
                    msgEl.className = (opts.msgClassPrefix || 'activation-msg') + ' err';
                    msgEl.textContent = (typeof t === 'function') ? t('activation_code_empty') : 'Enter activation code';
                }
                return Promise.resolve({ status: 'error' });
            }
            var fd = new FormData();
            fd.append('action', 'redeem_activation_code');
            fd.append('code', code);
            var url = (typeof window.posRouterUrl === 'function') ? window.posRouterUrl('') : '?';
            var msgPrefix = opts.msgClassPrefix || 'activation-msg';
            var btn = opts.submitBtn || null;
            if (btn) btn.disabled = true;
            return fetch(url, { method: 'POST', body: fd, credentials: 'same-origin' })
                .then(function(r) { return r.json(); })
                .then(function(d) {
                    var msg = d.message || (d.status === 'success' ? 'OK' : 'Error');
                    if (d.status === 'success' && expectedTier && d.product_type !== 'feature' && d.tier && d.tier !== expectedTier && typeof t === 'function') {
                        var actualLabel = d.tier === 'pro_plus' ? 'Pro Plus' : 'Pro';
                        var expectedLabel = expectedTier === 'pro_plus' ? 'Pro Plus' : 'Pro';
                        msg += ' ' + t('premium_lock_tier_mismatch')
                            .replace('{actual}', actualLabel)
                            .replace('{expected}', expectedLabel);
                    }
                    if (msgEl) {
                        msgEl.className = msgPrefix + (d.status === 'success' ? ' ok' : ' err');
                        msgEl.textContent = msg;
                    }
                    if (d.status === 'success') {
                        if (db) {
                            if (!db.settings) db.settings = {};
                            if (d.product_type === 'feature') {
                                if (d.entitlements) db.subscription_entitlements = d.entitlements;
                                if (d.feature_key && typeof posMarkFeaturePurchased === 'function') {
                                    posMarkFeaturePurchased(d.feature_key);
                                }
                                var fmeta = d.feature_key ? posPremiumVaultFeatureByFeatureKey(d.feature_key) : null;
                                if (fmeta) {
                                    ensurePremiumFeatureUnlocks();
                                    if (typeof posMarkFeaturePurchased === 'function') posMarkFeaturePurchased(fmeta.featureKey);
                                    db.settings.premiumFeatureUnlocks[fmeta.key] = true;
                                    if (!db.settings.premiumFeatureForceLocked || typeof db.settings.premiumFeatureForceLocked !== 'object') {
                                        db.settings.premiumFeatureForceLocked = {};
                                    }
                                    db.settings.premiumFeatureForceLocked[fmeta.key] = false;
                                    if (fmeta.key === 'fabMenu') {
                                        try { localStorage.setItem('pos_fab_visible', 'true'); } catch (eFabOn) {}
                                    } else if (fmeta.key === 'enableMoneyRounding' ||
                                        fmeta.key === 'requireOpeningBalancePrompt' || fmeta.key === 'requireEndShiftReconcilePrompt') {
                                        db.settings[fmeta.key] = true;
                                    } else if (fmeta.key === 'showPaymentModal' || fmeta.key === 'showPrintNotePopup') {
                                        db.settings[fmeta.key] = true;
                                    } else if (fmeta.key === 'enableCustomerInstallments') {
                                        db.settings.enableCustomerInstallments = true;
                                    } else if (fmeta.key === 'manufacturerSlot') {
                                        if (typeof normalizePosManufacturerSlotSettings === 'function') normalizePosManufacturerSlotSettings();
                                        var packMax = (typeof POS_MFR_PACK_MAX !== 'undefined') ? POS_MFR_PACK_MAX : 100;
                                        if (d.manufacturer_slots_purchased != null) {
                                            db.settings.manufacturerSlotsPurchased = Math.max(parseInt(d.manufacturer_slots_purchased, 10) || 0, packMax);
                                        } else {
                                            db.settings.manufacturerSlotsPurchased = packMax;
                                        }
                                    } else {
                                        db.settings[fmeta.key] = true;
                                    }
                                }
                            } else {
                                db.subscription_tier = d.tier || 'pro';
                                db.settings.subscription_tier = db.subscription_tier;
                                if (d.entitlements) db.subscription_entitlements = d.entitlements;
                            }
                        }
                        if (typeof saveSettings === 'function') saveSettings();
                        if (typeof applyPremiumStartup === 'function') applyPremiumStartup();
                        if (typeof showToast === 'function') showToast(d.message || 'OK');
                        if (inp) inp.value = '';
                        if (opts.closePopupOnSuccess && typeof closePremiumLockedPurchasePopup === 'function') {
                            closePremiumLockedPurchasePopup();
                        }
                        if (typeof opts.onSuccess === 'function') opts.onSuccess(d);
                    }
                    return d;
                })
                .catch(function() {
                    if (msgEl) {
                        msgEl.className = msgPrefix + ' err';
                        msgEl.textContent = (typeof t === 'function') ? t('activation_code_network_error') : 'Network error';
                    }
                    return { status: 'error' };
                })
                .finally(function() {
                    if (btn) btn.disabled = false;
                });
        }
        window.redeemActivationCode = redeemActivationCode;

        var _premiumLockSelectedTier = null;
        var _premiumLockFeatureCheckboxId = null;

        function resetPremiumLockRedeemPanel() {
            _premiumLockSelectedTier = null;
            _premiumLockFeatureCheckboxId = null;
            var featurePanel = document.getElementById('premium-lock-feature-only-panel');
            var featureInp = document.getElementById('premium-lock-feature-code-input');
            var featureMsg = document.getElementById('premium-lock-feature-code-msg');
            var divider = document.getElementById('premium-lock-or-pro-divider');
            var plans = document.getElementById('premium-lock-pro-plans');
            var intro = document.querySelector('.premium-lock-popup__intro');
            if (featurePanel) featurePanel.style.display = 'none';
            if (featureInp) featureInp.value = '';
            if (featureMsg) {
                featureMsg.textContent = '';
                featureMsg.className = 'activation-msg premium-lock-popup__code-msg';
            }
            if (divider) divider.style.display = 'none';
            if (plans) plans.style.display = '';
            if (intro) intro.style.display = '';
            var panel = document.getElementById('premium-lock-redeem-panel');
            if (panel) panel.style.display = 'none';
            document.querySelectorAll('.premium-lock-popup__plan[data-tier]').forEach(function(el) {
                el.classList.remove('is-selected');
            });
            var inp = document.getElementById('premium-lock-code-input');
            if (inp) inp.value = '';
            var msg = document.getElementById('premium-lock-code-msg');
            if (msg) {
                msg.textContent = '';
                msg.className = 'activation-msg premium-lock-popup__code-msg';
            }
        }

        function selectPremiumLockPlan(tier) {
            var current = getSubscriptionTier();
            if (tier === 'pro' && (current === 'pro' || current === 'pro_plus')) return;
            if (tier === 'pro_plus' && current === 'pro_plus') return;
            _premiumLockSelectedTier = tier === 'pro_plus' ? 'pro_plus' : 'pro';
            var panel = document.getElementById('premium-lock-redeem-panel');
            if (panel) panel.style.display = 'block';
            document.querySelectorAll('.premium-lock-popup__plan[data-tier]').forEach(function(el) {
                el.classList.toggle('is-selected', el.getAttribute('data-tier') === _premiumLockSelectedTier);
            });
            var hint = document.getElementById('premium-lock-redeem-hint');
            if (hint) {
                hint.textContent = (typeof t === 'function')
                    ? t(_premiumLockSelectedTier === 'pro_plus' ? 'premium_lock_redeem_hint_plus' : 'premium_lock_redeem_hint_pro')
                    : (_premiumLockSelectedTier === 'pro_plus' ? 'Enter Pro Plus code:' : 'Enter Pro code:');
            }
            var inp = document.getElementById('premium-lock-code-input');
            if (inp) {
                try { inp.focus(); } catch (_ePf) {}
            }
        }
        window.selectPremiumLockPlan = selectPremiumLockPlan;

        function redeemActivationCodeFromPopup() {
            if (!_premiumLockSelectedTier) {
                var msgEl = document.getElementById('premium-lock-code-msg');
                if (msgEl) {
                    msgEl.className = 'activation-msg premium-lock-popup__code-msg err';
                    msgEl.textContent = (typeof t === 'function') ? t('premium_lock_select_plan_first') : 'Select a plan first.';
                }
                return;
            }
            redeemActivationCode({
                inputEl: document.getElementById('premium-lock-code-input'),
                msgEl: document.getElementById('premium-lock-code-msg'),
                msgClassPrefix: 'activation-msg premium-lock-popup__code-msg',
                submitBtn: document.getElementById('premium-lock-redeem-btn'),
                expectedTier: _premiumLockSelectedTier,
                closePopupOnSuccess: true
            });
        }
        window.redeemActivationCodeFromPopup = redeemActivationCodeFromPopup;
        window.applySubscriptionBadge = applySubscriptionBadge;
        window.applyMultiDeviceSettingsUI = applyMultiDeviceSettingsUI;

        /** «سیستەمێ جوملە»: toggle ON/OFF + mode سەفەری vs جوملە (takeawayAsWholesale). */
        function getJumlaSystemMode() {
            if (!db || !db.settings) return 'off';
            if (db.settings.enableTakeaway !== true && db.settings.takeawayAsWholesale !== true) return 'off';
            return db.settings.takeawayAsWholesale === true ? 'jumla' : 'sefari';
        }
        function normalizeJumlaSystemSettings() {
            if (!db || !db.settings) return;
            var on = db.settings.enableTakeaway === true || db.settings.takeawayAsWholesale === true;
            if (!on) {
                db.settings.enableTakeaway = false;
                db.settings.takeawayAsWholesale = false;
                return;
            }
            // If they have it on, ensure enableTakeaway is explicitly true
            db.settings.enableTakeaway = true;
            if (db.settings.takeawayAsWholesale !== true && db.settings.takeawayAsWholesale !== false) {
                db.settings.takeawayAsWholesale = true;
            }
        }
        function syncJumlaSystemSettings(checked) {
            if (!db || !db.settings) return;
            var on = !!checked;
            if (on) {
                db.settings.enableTakeaway = true;
                if (db.settings.takeawayAsWholesale !== true && db.settings.takeawayAsWholesale !== false) {
                    db.settings.takeawayAsWholesale = true;
                }
            } else {
                db.settings.enableTakeaway = false;
                db.settings.takeawayAsWholesale = false;
            }
            var el = document.getElementById('set-enable-takeaway');
            if (el) el.checked = on;
            var tws = document.getElementById('set-takeaway-as-wholesale');
            if (tws) tws.checked = false;
            updateJumlaModeSelectorUI();
            if (typeof applyJumlaSystemGlobally === 'function') applyJumlaSystemGlobally();
            if (typeof saveSettings === 'function') saveSettings().catch(function() {});
        }
        function setJumlaSystemMode(mode) {
            if (!db || !db.settings) return;
            var m = (mode === 'sefari') ? 'sefari' : 'jumla';
            db.settings.enableTakeaway = true;
            db.settings.takeawayAsWholesale = (m === 'jumla');
            var el = document.getElementById('set-enable-takeaway');
            if (el) el.checked = true;
            var tws = document.getElementById('set-takeaway-as-wholesale');
            if (tws) tws.checked = (m === 'jumla');
            updateJumlaModeSelectorUI();
            if (typeof applyJumlaSystemGlobally === 'function') applyJumlaSystemGlobally();
            if (typeof updateToggleCards === 'function') updateToggleCards();
            if (typeof saveSettings === 'function') saveSettings().catch(function() {});
        }
        /** Propagate سەفەری/جوملە mode across POS, product form, tables, and pricing. */
        function applyJumlaSystemGlobally() {
            if (!db || !db.settings) return;
            var active = typeof isJumlaSystemFeatureEnabled === 'function' && isJumlaSystemFeatureEnabled();
            var mode = typeof getJumlaSystemMode === 'function' ? getJumlaSystemMode() : 'off';
            if (document.body) {
                document.body.setAttribute('data-jumla-system', active ? mode : 'off');
            }
            if (typeof applyProductFormPremiumFeatureFields === 'function') applyProductFormPremiumFeatureFields();
            if (typeof window.updateTakeawayToggleUI === 'function') window.updateTakeawayToggleUI();
            lastTableState = '';
            if (typeof renderTables === 'function') renderTables();
            if (typeof renderPOSMenu === 'function') {
                var q = document.getElementById('pos-barcode-input') ? document.getElementById('pos-barcode-input').value : '';
                renderPOSMenu(q, true);
            }
            if (typeof recalcBulkPrices === 'function') recalcBulkPrices();
            if (typeof renderBill === 'function') renderBill();
        }
        function updateJumlaModeSelectorUI() {
            var wrap = document.getElementById('jumla-system-mode-wrap');
            if (!wrap) return;
            var el = document.getElementById('set-enable-takeaway');
            var on = !!(el && el.checked);
            if (!on && db && db.settings) {
                on = db.settings.enableTakeaway === true || db.settings.takeawayAsWholesale === true;
            }
            wrap.classList.toggle('is-hidden', !on);
            wrap.setAttribute('aria-hidden', on ? 'false' : 'true');
            var mode = getJumlaSystemMode();
            wrap.querySelectorAll('.jumla-system-mode-btn').forEach(function(btn) {
                var bm = btn.getAttribute('data-jumla-mode');
                var active = bm === mode;
                btn.classList.toggle('active', active);
                btn.setAttribute('aria-pressed', active ? 'true' : 'false');
            });
        }
        function isJumlaSystemFeatureEnabled() {
            if (typeof isPremiumSettingsFeatureEnabled === 'function') {
                if (isPremiumSettingsFeatureEnabled('set-enable-takeaway')) return true;
                if (isPremiumSettingsFeatureEnabled('set-takeaway-as-wholesale')) return true;
            }
            return !!(db && db.settings && (db.settings.enableTakeaway === true || db.settings.takeawayAsWholesale === true));
        }
        if (typeof window !== 'undefined') {
            window.normalizeJumlaSystemSettings = normalizeJumlaSystemSettings;
            window.syncJumlaSystemSettings = syncJumlaSystemSettings;
            window.getJumlaSystemMode = getJumlaSystemMode;
            window.setJumlaSystemMode = setJumlaSystemMode;
            window.updateJumlaModeSelectorUI = updateJumlaModeSelectorUI;
            window.isJumlaSystemFeatureEnabled = isJumlaSystemFeatureEnabled;
            window.applyJumlaSystemGlobally = applyJumlaSystemGlobally;
        }

        /** Pro / purchased / secret-vault unlock + settings toggle ON (delivery, rounding, stock badge, shift prompts, …). */
        function isPremiumSettingsFeatureEnabled(checkboxId) {
            if (checkboxId === 'set-takeaway-as-wholesale') {
                return isPremiumSettingsFeatureEnabled('set-enable-takeaway');
            }
            var meta = posPremiumVaultFeatureById(checkboxId);
            if (!isPremiumFeatureUnlocked(checkboxId)) return false;
            if (!db || !db.settings) return false;
            if (!meta) return false;
            var k = meta.key;
            if (k === 'fabMenu') {
                try { return localStorage.getItem('pos_fab_visible') !== 'false'; } catch (eFab) { return true; }
            }
            if (k === 'enableMoneyRounding' || k === 'requireOpeningBalancePrompt' || k === 'requireEndShiftReconcilePrompt') {
                return !(db.settings[k] === false || db.settings[k] === 'false' || db.settings[k] === 0);
            }
            if (k === 'showPaymentModal') {
                return db.settings[k] === true;
            }
            return db.settings[k] === true;
        }

        function isShowStockOnPosEnabled() {
            // Core POS need: always show remaining qty unless user turns the setting OFF.
            // Do not gate behind premium unlock — shops must see stock on sales.
            if (!db || !db.settings) return true;
            if (db.settings.showStockOnPos === undefined || db.settings.showStockOnPos === null || db.settings.showStockOnPos === '') {
                db.settings.showStockOnPos = true;
                return true;
            }
            return !(db.settings.showStockOnPos === false || db.settings.showStockOnPos === 'false' || db.settings.showStockOnPos === 0 || db.settings.showStockOnPos === '0');
        }

        /**
         * زێدەکرنا ئایتمان: hide/disable takeaway & wholesale fields when setting is off or section still locked.
         * Runs after applyProductFormLayout so layout prefs cannot re-show locked fields.
         */
        function jumlaAltPriceHeaderLabel(mode) {
            var m = (mode === 'sefari') ? 'sefari' : 'jumla';
            if (mode === 'off') m = 'jumla'; // Default label even if off
            var key = m === 'sefari' ? 'product_form_sefari_header' : 'product_form_takeaway_header';
            var fallback = m === 'sefari' ? 'سەفەری' : 'جوملە';
            if (typeof t === 'function') {
                var v = t(key);
                if (v && v !== key) return v;
            }
            return fallback;
        }
        function updateProductFormAlternatePriceHeader() {
            var mode = typeof getJumlaSystemMode === 'function' ? getJumlaSystemMode() : 'jumla';
            var label = jumlaAltPriceHeaderLabel(mode);
            var key = mode === 'sefari' ? 'product_form_sefari_header' : 'product_form_takeaway_header';
            var span = document.getElementById('product-form-alt-price-header');
            var icon = document.getElementById('product-form-alt-price-icon');
            if (span) {
                span.setAttribute('data-i18n', key);
                span.textContent = label;
            }
            if (icon) {
                icon.className = mode === 'jumla' ? 'fas fa-box' : 'fas fa-shopping-bag';
            }
        }
        function applyProductFormPremiumFeatureFields() {
            var takeawayOn = isPremiumSettingsFeatureEnabled('set-enable-takeaway');
            var wholesaleOn = isPremiumSettingsFeatureEnabled('set-enable-wholesale');
            var jumlaMode = typeof getJumlaSystemMode === 'function' ? getJumlaSystemMode() : 'off';
            
            // Strictly hide if the feature is not active
            if (jumlaMode === 'off') takeawayOn = false;

            var layoutVis = null;
            try {
                if (typeof getProductFormLayoutConfig === 'function') {
                    var cfg = getProductFormLayoutConfig();
                    layoutVis = (cfg && cfg.visibility) ? cfg.visibility : cfg;
                }
            } catch (eLayout) { layoutVis = null; }

            function layoutWantsShow(layoutId) {
                if (!layoutVis) return true;
                return layoutVis[layoutId] !== false;
            }

            document.querySelectorAll('[data-layout-id="layout-optional-takeaway"]').forEach(function(el) {
                el.style.display = (takeawayOn && layoutWantsShow('layout-optional-takeaway')) ? '' : 'none';
                el.querySelectorAll('input, select, textarea, button').forEach(function(inp) {
                    inp.disabled = !takeawayOn;
                });
            });
            updateProductFormAlternatePriceHeader();
            var wholesaleWrap = document.getElementById('p-wholesale-wrapper');
            var showWholesale = wholesaleOn || (takeawayOn && jumlaMode === 'jumla');
            if (wholesaleWrap) {
                wholesaleWrap.style.display = (showWholesale && layoutWantsShow('layout-optional-wholesale')) ? '' : 'none';
                wholesaleWrap.querySelectorAll('input, select, textarea, button').forEach(function(inp) {
                    inp.disabled = !showWholesale;
                });
            }
            if (!takeawayOn && db && db.settings) {
                db.settings.takeawayAsWholesale = false;
                var twsOff = document.getElementById('set-takeaway-as-wholesale');
                if (twsOff) twsOff.checked = false;
            }
            var mfrRow = document.querySelector('[data-layout-id="layout-optional-companies"]');
            var canMfr = typeof canUseManufacturerCompanies === 'function' && canUseManufacturerCompanies();
            if (mfrRow) {
                mfrRow.style.display = (canMfr && layoutWantsShow('layout-optional-companies')) ? '' : 'none';
                mfrRow.querySelectorAll('input, select, textarea, button').forEach(function(inp) {
                    inp.disabled = !canMfr;
                });
            }
            var currencyRow = document.getElementById('p-base-currency-row');
            var canItemCur = typeof canUseProductItemCurrencyPicker === 'function' && canUseProductItemCurrencyPicker();
            if (currencyRow) {
                currencyRow.style.display = (canItemCur && layoutWantsShow('layout-optional-item-currency')) ? '' : 'none';
            }
            var specBox = document.getElementById('p-tech-specs-box');
            var canSpecs = typeof canUseTechSpecs === 'function' && canUseTechSpecs();
            if (specBox) {
                specBox.style.display = canSpecs ? '' : 'none';
                specBox.querySelectorAll('input, select, textarea, button').forEach(function(inp) {
                    inp.disabled = !canSpecs;
                });
                if (!canSpecs) specBox.open = false;
            }
            if (typeof applyWarehouseManufacturerUi === 'function') applyWarehouseManufacturerUi();
        }
        if (typeof window !== 'undefined') {
            window.isPremiumSettingsFeatureEnabled = isPremiumSettingsFeatureEnabled;
            window.isShowStockOnPosEnabled = isShowStockOnPosEnabled;
            window.applyProductFormPremiumFeatureFields = applyProductFormPremiumFeatureFields;
            window.updateProductFormAlternatePriceHeader = updateProductFormAlternatePriceHeader;
        }

        /** کارتەکانی ڕێکخستنی «قفڵ» — تەنها پیشاندان؛ دۆخی چالاک/ناچالاک لە چێکبۆکس */
        function syncSettingsLockedPreviewCards() {
            if (typeof syncRightSidebarCheckboxFromStorage === 'function') syncRightSidebarCheckboxFromStorage();
            var onLabel = (typeof t === 'function') ? t('settings_locked_state_on') : 'چالاك';
            var offLabel = (typeof t === 'function') ? t('settings_locked_state_off') : 'قفڵ';
            document.querySelectorAll('.setting-locked-card[data-locked-sync]').forEach(function(card) {
                var id = card.getAttribute('data-locked-sync');
                var input = id ? document.getElementById(id) : null;
                var on = false;
                if (id === 'premium-purchase-batch' && typeof canUsePurchaseBatch === 'function') {
                    on = canUsePurchaseBatch();
                } else if (id === 'premium-mfr-slot' && typeof canUseManufacturerCompanies === 'function') {
                    on = canUseManufacturerCompanies();
                } else if (id === 'premium-tech-specs' && typeof canUseTechSpecs === 'function') {
                    on = canUseTechSpecs();
                } else if (id === 'premium-sale-followup' && typeof canUseSaleFollowup === 'function') {
                    on = canUseSaleFollowup();
                } else {
                    on = !!(input && input.checked);
                }
                card.classList.toggle('setting-locked-card--on', on);
                var badge = card.querySelector('.setting-locked-card-badge');
                if (!badge) return;
                var ic = badge.querySelector('i');
                if (ic) ic.className = on ? 'fas fa-check-circle' : 'fas fa-times-circle';
                var lab = badge.querySelector('.setting-locked-card-label');
                if (lab) lab.textContent = on ? onLabel : offLabel;
            });
        }

        /** دوای کردنەوەی قفڵ لە مێنوی نهێنی: سووچەکانی ڕێکخستن دەردەکەون؛ پێش ئەوە تەنها کارتێ قفڵ */
        function applyPremiumSettingsUI() {
            ensurePremiumFeatureUnlocks();
            var wrap = document.querySelector('.settings-premium-locked-wrap');
            var grid = wrap ? wrap.querySelector('.settings-grid') : null;
            var vault = document.getElementById('secret-only-feature-toggles');
            if (!grid || !vault) {
                syncSettingsLockedPreviewCards();
                return;
            }
            POS_PREMIUM_VAULT_FEATURES.forEach(function(meta) {
                var card = document.querySelector('.setting-locked-card[data-locked-sync="' + meta.id + '"]');
                var block = document.querySelector('[data-premium-vault="' + meta.id + '"]');
                var toggleLabel = vault.querySelector('label[for="' + meta.id + '"]') || (grid ? grid.querySelector('label[for="' + meta.id + '"]') : null);
                var moveEl = block || toggleLabel;
                var unlocked = isPremiumFeatureUnlocked(meta.id);
                if (card) card.style.display = unlocked ? 'none' : '';
                if (!moveEl) return;
                if (unlocked) {
                    if (moveEl.parentElement !== grid) grid.appendChild(moveEl);
                    moveEl.style.display = '';
                } else {
                    if (moveEl.parentElement !== vault) vault.appendChild(moveEl);
                    moveEl.style.display = 'none';
                }
            });
            syncSettingsLockedPreviewCards();
            bindPremiumLockedCardClicks();
            if (typeof applyPosPremiumPricingLabels === 'function' && wrap) applyPosPremiumPricingLabels(wrap);
            if (typeof updateToggleCards === 'function') updateToggleCards();
            if (typeof applyProductFormPremiumFeatureFields === 'function') applyProductFormPremiumFeatureFields();
            if (typeof applyMultiWarehouseVisibility === 'function') applyMultiWarehouseVisibility();
            if (typeof bindTechSpecsSplitGesture === 'function') bindTechSpecsSplitGesture();
        }

        function redeemFeatureActivationCodeFromPopup() {
            redeemActivationCode({
                inputEl: document.getElementById('premium-lock-feature-code-input'),
                msgEl: document.getElementById('premium-lock-feature-code-msg'),
                msgClassPrefix: 'activation-msg premium-lock-popup__code-msg',
                submitBtn: document.getElementById('premium-lock-feature-redeem-btn'),
                expectedTier: null,
                closePopupOnSuccess: true
            });
        }
        window.redeemFeatureActivationCodeFromPopup = redeemFeatureActivationCodeFromPopup;

        function showPremiumLockedPurchasePopup(featureName, checkboxId) {
            var tier = getSubscriptionTier();
            if (tier === 'pro_plus') {
                var msgPlus = (typeof t === 'function') ? t('premium_already_pro_plus') : 'Pro Plus چالاکە — پێویست بە کۆد نییە.';
                if (typeof showToast === 'function') showToast(msgPlus, 'info');
                else alert(msgPlus);
                return;
            }
            var popup = document.getElementById('premium-lock-popup');
            if (!popup) return;
            resetPremiumLockRedeemPanel();
            _premiumLockFeatureCheckboxId = checkboxId || null;
            var titleEl = document.getElementById('premium-lock-popup-title');
            var featEl = document.getElementById('premium-lock-popup-feature');
            var hasFeature = !!(featureName && String(featureName).trim() !== '');
            var featurePanel = document.getElementById('premium-lock-feature-only-panel');
            var divider = document.getElementById('premium-lock-or-pro-divider');
            var plans = document.getElementById('premium-lock-pro-plans');
            var intro = document.querySelector('.premium-lock-popup__intro');
            var vaultMeta = checkboxId && typeof posPremiumVaultFeatureById === 'function' ? posPremiumVaultFeatureById(checkboxId) : null;
            var showFeatureOnly = hasFeature && !hasPremiumEntitlement() && tier === 'free' && !!(vaultMeta && vaultMeta.featureKey);
            if (featurePanel) featurePanel.style.display = showFeatureOnly ? 'block' : 'none';
            if (divider) divider.style.display = showFeatureOnly ? 'block' : 'none';
            if (plans) plans.style.display = showFeatureOnly ? '' : '';
            if (intro) intro.style.display = showFeatureOnly ? 'none' : '';
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(popup);
            if (typeof applyPosPremiumPricingLabels === 'function') applyPosPremiumPricingLabels(popup);
            if (showFeatureOnly && vaultMeta && vaultMeta.featureKey) {
                var featOnlyTitle = featurePanel ? featurePanel.querySelector('.premium-lock-popup__feature-only-title') : null;
                var featRedeemBtn = document.getElementById('premium-lock-feature-redeem-btn');
                var pUsd = (typeof getPosFeaturePriceUsd === 'function') ? getPosFeaturePriceUsd(vaultMeta.featureKey) : null;
                if (pUsd != null && typeof formatPosPremiumUsd === 'function') {
                    var priceLbl = formatPosPremiumUsd(pUsd);
                    if (featOnlyTitle) featOnlyTitle.textContent = 'تەنها ئەم تایبەتمەندیە · ' + priceLbl;
                    if (featRedeemBtn) {
                        var redeemSpan = featRedeemBtn.querySelector('span');
                        if (redeemSpan) redeemSpan.textContent = 'چالاککردن (' + priceLbl + ')';
                    }
                }
            }
            syncPremiumLockPlanOptions();
            if (tier === 'pro') {
                selectPremiumLockPlan('pro_plus');
            }
            if (titleEl) {
                titleEl.textContent = (typeof t === 'function')
                    ? t(hasFeature ? 'premium_lock_popup_title' : 'sidebar_premium_popup_title')
                    : (hasFeature ? 'ئەم بەشە قفڵە' : 'وەشانێن پارەدار');
            }
            if (featEl) {
                var label = (typeof t === 'function') ? t('premium_lock_popup_feature_label') : 'بەش:';
                if (hasFeature) {
                    featEl.textContent = label + ' ' + String(featureName).trim();
                    featEl.style.display = 'block';
                } else {
                    featEl.style.display = 'none';
                    featEl.textContent = '';
                }
            }
            popup.style.display = 'flex';
            document.body.style.overflow = 'hidden';
            if (!popup.getAttribute('data-esc-bound')) {
                popup.setAttribute('data-esc-bound', '1');
                document.addEventListener('keydown', function premiumLockEsc(ev) {
                    if (ev.key === 'Escape' && popup.style.display === 'flex') closePremiumLockedPurchasePopup();
                });
            }
            var codeInp = document.getElementById('premium-lock-code-input');
            if (codeInp && !codeInp.getAttribute('data-enter-bound')) {
                codeInp.setAttribute('data-enter-bound', '1');
                codeInp.addEventListener('keydown', function (ev) {
                    if (ev.key === 'Enter') {
                        ev.preventDefault();
                        redeemActivationCodeFromPopup();
                    }
                });
            }
        }

        function closePremiumLockedPurchasePopup() {
            var popup = document.getElementById('premium-lock-popup');
            if (popup) popup.style.display = 'none';
            document.body.style.overflow = '';
            resetPremiumLockRedeemPanel();
        }

        function bindPremiumLockedCardClicks() {
            var wrap = document.querySelector('.settings-premium-locked-wrap');
            if (!wrap) return;
            document.querySelectorAll('.setting-locked-card[data-locked-sync]').forEach(function(card) {
                var id = card.getAttribute('data-locked-sync');
                var locked = !(typeof isPremiumFeatureUnlocked === 'function' && isPremiumFeatureUnlocked(id));
                var visible = card.style.display !== 'none';
                if (locked && visible) {
                    card.classList.add('setting-locked-card--clickable');
                    card.setAttribute('role', 'button');
                    card.setAttribute('tabindex', '0');
                    card.setAttribute('aria-label', (typeof t === 'function') ? t('premium_lock_popup_title') : 'قفڵ');
                } else {
                    card.classList.remove('setting-locked-card--clickable');
                    card.removeAttribute('role');
                    card.removeAttribute('tabindex');
                    card.removeAttribute('aria-label');
                }
            });
            if (wrap.getAttribute('data-lock-popup-bound') === '1') return;
            wrap.setAttribute('data-lock-popup-bound', '1');
            wrap.addEventListener('click', function(ev) {
                var card = ev.target.closest('.setting-locked-card[data-locked-sync]');
                if (!card || card.style.display === 'none') return;
                var syncId = card.getAttribute('data-locked-sync');
                if (typeof isPremiumFeatureUnlocked === 'function' && isPremiumFeatureUnlocked(syncId)) return;
                var titleEl = card.querySelector('.stc-info h4');
                var featureName = titleEl ? titleEl.textContent.trim() : '';
                showPremiumLockedPurchasePopup(featureName, syncId);
            });
            wrap.addEventListener('keydown', function(ev) {
                if (ev.key !== 'Enter' && ev.key !== ' ') return;
                var card = ev.target.closest('.setting-locked-card[data-locked-sync]');
                if (!card || !card.classList.contains('setting-locked-card--clickable')) return;
                ev.preventDefault();
                var titleEl = card.querySelector('.stc-info h4');
                var syncId = card.getAttribute('data-locked-sync');
                showPremiumLockedPurchasePopup(titleEl ? titleEl.textContent.trim() : '', syncId);
            });
        }

        if (typeof window !== 'undefined') {
            window.syncSettingsLockedPreviewCards = syncSettingsLockedPreviewCards;
            window.applyPremiumSettingsUI = applyPremiumSettingsUI;
            window.applyPremiumStartup = applyPremiumStartup;
            window.syncPurchasedFeaturesFromEntitlements = syncPurchasedFeaturesFromEntitlements;
            window.repairPremiumFeatureEntitlementsFromServer = repairPremiumFeatureEntitlementsFromServer;
            window.enforcePremiumGatedSettingsRuntime = enforcePremiumGatedSettingsRuntime;
            window.isPremiumFeatureUnlocked = isPremiumFeatureUnlocked;
            window.hasPremiumEntitlement = hasPremiumEntitlement;
            window.getSubscriptionTier = getSubscriptionTier;
            window.showPremiumLockedPurchasePopup = showPremiumLockedPurchasePopup;
            window.closePremiumLockedPurchasePopup = closePremiumLockedPurchasePopup;
        }
