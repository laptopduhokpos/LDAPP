// sales/complete-sale.js — complete sale
        function processPayment(method = 'cash', targetId = 0, targetType = '', splitAllocations = null) {
            if(isProcessingPayment) return;
            // Edit mode must update the same invoice — never create a new sale row.
            if (window._posEditingSale && window._posEditingSale.id && typeof window.savePosEditedSale === 'function') {
                window.savePosEditedSale();
                return;
            }
            // All amounts (subTotal, discount, total) are in base currency (IQD) for DB integrity; display conversion is UI-only.
            const table = db.tables.find(t => t.id === activeTableId); 
            if (!table || table.items.length === 0) {
                window._confirmAdvancedPaymentPending = false;
                window._saleFromPaymentModal = false;
                return;
            }
            
            if(isReturnMode) {
                window._confirmAdvancedPaymentPending = false;
                window._saleFromPaymentModal = false;
                processReturnTransaction();
                return;
            }

            if (!validatePosItemsNoIllegalZeroPrice(table).ok) {
                var zmsg = typeof t === 'function' ? t('pos_zero_price_blocked') : 'لا يمكنك البيع بهذا السعر';
                if (typeof showToast === 'function') showToast(zmsg, 'error');
                else alert(zmsg);
                window._confirmAdvancedPaymentPending = false;
                window._saleFromPaymentModal = false;
                return;
            }

            if (typeof window.posEnsureSaleWarehouseOpen === 'function' && !window.posEnsureSaleWarehouseOpen()) {
                window._confirmAdvancedPaymentPending = false;
                window._saleFromPaymentModal = false;
                return;
            }
            
            isProcessingPayment = true; // FIX: Lock function
            if (saveTimeout) { clearTimeout(saveTimeout); saveTimeout = null; }
            cartSaveQueue = [];
            window._isCartSaving = true;
            var _sellBtnLabel = (typeof t === 'function') ? (t('pos_btn_sell') || t('btn_pos_sell')) : 'فروشتن';
            if (_sellBtnLabel === 'pos_btn_sell' || _sellBtnLabel === 'btn_pos_sell') _sellBtnLabel = 'فروشتن';
            
            const subTotal = (typeof roundMoney === 'function' ? roundMoney : function(x){ return (parseFloat(x) || 0); })(table.items.reduce(function(a, b) {
                var u = typeof getBillLineUnitIqd === 'function' ? getBillLineUnitIqd(b) : (parseFloat(b.price) || 0);
                return a + u * getItemQty(b);
            }, 0)); 
            const customerName = document.getElementById('pos-customer-name').value;
            let discount = 0;
            const discountInputEl = document.getElementById('pos-discount');
            let discountPercent = 0;
            
            if (table.manualDiscount !== undefined && table.manualDiscount !== null) {
                discount = parseFloat(table.manualDiscount);
                if (discount > subTotal) discount = subTotal;
                if (discount < 0 && Math.abs(discount) > 0) { /* allow markup */ }
                discountPercent = subTotal > 0 ? (discount / subTotal) * 100 : 0;
            } else {
                const discountInput = discountInputEl ? discountInputEl.value : '';
                if(discountInput && !isNaN(discountInput)) {
                    discountPercent = parseFloat(discountInput);
                    if(discountPercent >= 0 && discountPercent <= 100) {
                        discount = (typeof roundMoney === 'function' ? roundMoney : function(x){return x;})(subTotal * (discountPercent / 100));
                    }
                }
            }
            
            const total = Math.max(0, subTotal - discount);
            
            // Capture current items to sell (include stock metadata for server deduction)
            const itemsToSell = table.items.map(function(it) {
                var qty = getItemQty(it);
                var isGiftLine = typeof isPosCartLineGift === 'function' ? isPosCartLineGift(it) : !!it.isGift;
                // Keep catalog/unit price for gift-value reports; charging is skipped via isGift + getBillLineUnitIqd
                var lineIqd = isGiftLine
                    ? (Number(it.price) || 0)
                    : (typeof getBillLineUnitIqd === 'function' ? getBillLineUnitIqd(it) : (parseFloat(it.price) || 0));
                    var prod = (db && db.products) ? db.products.find(function(p) { return String(p.id) === String(it.id); }) : null;
                    var fxBundle = (db && db.settings && db.settings.usdRate != null) ? Math.round(Number(db.settings.usdRate)) : 0;
                    var saleCur = (typeof getActiveCurrency === 'function') ? getActiveCurrency() : ((db && db.settings && db.settings.currencyMode) || 'IQD');
                    return {
                    id: it.id,
                    name: it.name,
                    qty: qty,
                    count: qty,
                    price: lineIqd,
                    cost: it.cost,
                    saleUnit: it.saleUnit || 'piece',
                    bill_unit_usd: it.bill_unit_usd,
                    fx_rate_per_one: it.fx_rate_per_one,
                    sale_price: lineIqd,
                    sale_price_usd: it.bill_unit_usd,
                    sale_currency: saleCur,
                    sale_exchange_rate: fxBundle >= 1000 ? fxBundle : null,
                    isManualItem: it.isManualItem,
                    isGift: !!isGiftLine,
                    note: it.note,
                    trackStock: it.trackStock != null ? it.trackStock : (prod ? prod.trackStock : false),
                    barcode: it.barcode != null ? it.barcode : (prod ? prod.barcode : ''),
                    sku: it.sku != null ? it.sku : (prod ? prod.sku : ''),
                    pieces_per_pack: it.pieces_per_pack != null ? it.pieces_per_pack : (prod ? prod.pieces_per_pack : 1),
                    packs_per_carton: it.packs_per_carton != null ? it.packs_per_carton : (prod ? prod.packs_per_carton : 1),
                    itemsPerCarton: it.itemsPerCarton != null ? it.itemsPerCarton : (prod ? prod.itemsPerCarton : 1)
                };
            });

            // OPTIMISTIC UI: sale completes instantly for cashier; server sync runs in background
            const originalItems = [...table.items];
            const originalDiscount = table.manualDiscount;
            const originalCustomerName = document.getElementById('pos-customer-name').value;
            
            table.items = [];
            delete table.manualDiscount;
            lastTableState = "";
            if (discountInputEl) discountInputEl.value = '';
            if (typeof window.clearPosCustomerCheckoutState === 'function') {
                window.clearPosCustomerCheckoutState({ skipToggle: false });
            } else {
                document.getElementById('pos-customer-name').value = '';
                const paidInput = document.getElementById('pos-customer-paid');
                if (paidInput) paidInput.value = '';
                var _expN = document.getElementById('pos-expand-customer-name');
                if (_expN) _expN.value = '';
                var _expP = document.getElementById('pos-expand-customer-paid');
                if (_expP) _expP.value = '';
                var _ph = document.getElementById('pos-customer-phone');
                if (_ph) _ph.value = '';
                var _expPh = document.getElementById('pos-expand-customer-phone');
                if (_expPh) _expPh.value = '';
                window.__posActiveCustomerId = null;
                if (typeof toggleCreditButton === 'function') toggleCreditButton();
            }
            if (typeof cancelPendingPosTabSnapshot === 'function') cancelPendingPosTabSnapshot();
            if (typeof clearActivePosTabAfterSale === 'function') clearActivePosTabAfterSale();
            else if (typeof saveActivePosTabSnapshot === 'function') saveActivePosTabSnapshot();
            if (typeof renderPosTabsUI === 'function') renderPosTabsUI();
            if (typeof scheduleRenderBill === 'function') scheduleRenderBill();
            else if (typeof renderBill === 'function') renderBill();
            if (typeof window.collapseTxnSheet === 'function') window.collapseTxnSheet('pos');
            if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('pos');
            closePaymentModal();
            isProcessingPayment = false;
            window._confirmAdvancedPaymentPending = false;
            if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('toast_sale_ok') : 'وەسڵ ب سەرکەفتیانە هاتە لێدان', 'success');

            window._cartSaveGen = (window._cartSaveGen || 0) + 1;

            const requestKey = 'sale_' + Date.now() + '_' + Math.random().toString(36).slice(2, 10);
            var groupedForPrint = buildSaleReceiptGrouped(itemsToSell);
            window._salePrintIssued = null;
            if (db && db.settings && db.settings.autoPrint !== false) {
                try {
                    if (typeof warmPrintFrame === 'function') warmPrintFrame();
                    else if (typeof ensurePrintFrame === 'function') ensurePrintFrame();
                } catch (ePf) {}
                var _instantPrintPayload = {
                    itemsToSell: itemsToSell,
                    total: total,
                    subTotal: subTotal,
                    discount: discount,
                    discountPercent: discountPercent,
                    method: method,
                    tableName: table.name,
                    customerName: customerName,
                    targetId: targetId,
                    targetType: targetType,
                    splitAllocations: splitAllocations
                };
                var _issueInstantPrint = function () {
                    if (typeof triggerInstantSalePrint === 'function' && triggerInstantSalePrint(_instantPrintPayload)) {
                        window._salePrintIssued = requestKey;
                    }
                };
                if (typeof whenPrintFrameReady === 'function') {
                    whenPrintFrameReady(_issueInstantPrint, 2500);
                } else {
                    _issueInstantPrint();
                }
            }

            const formData = new FormData();
            // Unique key per submit so backend idempotency protects retries
            // without blocking intentionally repeated same-item sales.
            formData.append('action', 'process_payment');
            formData.append('request_key', requestKey);
            formData.append('total', total);
            formData.append('discount', discount);
            formData.append('items', JSON.stringify(itemsToSell)); // Send captured items
            formData.append('cashier', currentUser ? currentUser.name : 'System');
            formData.append('method', method);
            var saleWhId = typeof getSaleWarehouseId === 'function' ? getSaleWarehouseId() : 0;
            if (saleWhId) formData.append('warehouse_id', String(saleWhId));
            formData.append('targetId', targetId);
            formData.append('targetType', targetType);
            if(method === 'split' && splitAllocations) {
                formData.append('split_allocations', JSON.stringify(splitAllocations));
                formData.append('paid_cash', String(parseFloat(splitAllocations.paid_cash != null ? splitAllocations.paid_cash : (splitAllocations.cash || 0)) || 0));
                formData.append('paid_bank', String(parseFloat(splitAllocations.paid_bank != null ? splitAllocations.paid_bank : (splitAllocations.bank || 0)) || 0));
                formData.append('remaining_debt', String(parseFloat(splitAllocations.remaining_debt != null ? splitAllocations.remaining_debt : (splitAllocations.debt || 0)) || 0));
                formData.append('paid_amount', String(parseFloat(splitAllocations.paid_amount != null ? splitAllocations.paid_amount : ((splitAllocations.cash || 0) + (splitAllocations.bank || 0))) || 0));
                formData.append('debt_amount', String(parseFloat(splitAllocations.debt_amount != null ? splitAllocations.debt_amount : (splitAllocations.debt || 0)) || 0));
                formData.append('bank_amount', String(parseFloat(splitAllocations.bank_amount != null ? splitAllocations.bank_amount : (splitAllocations.bank || 0)) || 0));
                formData.append('received_amount', String(parseFloat(splitAllocations.received_amount != null ? splitAllocations.received_amount : (splitAllocations.cash || 0)) || 0));
            }
            if (method === 'fib') {
                var fibAmt = splitAllocations
                    ? (parseFloat(splitAllocations.paid_bank != null ? splitAllocations.paid_bank : (splitAllocations.bank || 0)) || 0)
                    : total;
                if (splitAllocations) formData.append('split_allocations', JSON.stringify(splitAllocations));
                formData.append('paid_cash', '0');
                formData.append('paid_bank', String(fibAmt));
                formData.append('bank_amount', String(fibAmt));
                formData.append('paid_amount', String(fibAmt));
                formData.append('received_amount', '0');
            }
            if (activeTableId) formData.append('table_id', activeTableId);
            if (typeof appendPaymentTermToFormData === 'function') appendPaymentTermToFormData(formData, 'pos');
            var fxSave = (db && db.settings && db.settings.usdRate != null) ? Math.round(Number(db.settings.usdRate)) : 0;
            if (fxSave >= 1000) formData.append('fx_usd_rate', String(fxSave));
            var fxModeSave = (typeof getActiveCurrency === 'function') ? getActiveCurrency() : ((db && db.settings && db.settings.currencyMode) || 'IQD');
            if (fxModeSave === 'USD' || fxModeSave === 'IQD') formData.append('fx_currency_mode', fxModeSave);
            const _apiUrl = resolvePosApiAllUrl();
            try { window.__POS_DEBUG_API_URL = _apiUrl; } catch (e) {}

            fetch(_apiUrl, { method: 'POST', body: formData, credentials: 'same-origin' })
            .then(async res => {
                let t = '';
                try { t = await res.text(); } catch (e) { t = ''; }
                if (!res.ok) {
                    throw new Error(`Server error: ${res.status} ${res.statusText}${t ? ' - ' + t.slice(0, 200) : ''}`);
                }
                var raw = String(t || '').replace(/^\uFEFF/, '').trim();
                // Prefer real API JSON ({"status":...}) — do not slice on random "[" inside PHP warnings
                var statusMatch = raw.match(/\{\s*"status"\s*:/);
                if (statusMatch && statusMatch.index > 0) raw = raw.slice(statusMatch.index);
                try {
                    return JSON.parse(raw);
                } catch (e) {
                    var preview = raw.slice(0, 120).replace(/\s+/g, ' ');
                    throw new Error(preview.indexOf('<') === 0
                        ? 'سێرڤەر وەڵامێ HTML گەڕاندەوە — پەڕە نوو بکە.'
                        : ('وەڵامێ سێرڤەر نادروستە' + (preview ? (': ' + preview) : '')));
                }
            })
            .then(data => {
                window._isCartSaving = false;
                if (activeTableId) {
                    cartSaveQueue.push({ id: activeTableId, items: '[]' });
                    if (typeof processCartSaveQueue === 'function') processCartSaveQueue();
                }
                if(data.status === 'success') {
                    if (data.stock && typeof applyServerStockUpdates === 'function') {
                        applyServerStockUpdates(data.stock, { force: true });
                    }
                    if (typeof window.scheduleFirebaseMobilePush === 'function') {
                        window.scheduleFirebaseMobilePush('sale', false);
                    }
                    // Defer heavy sync while cashier is selling — stock already applied above
                    if (typeof syncLiveData === 'function') {
                        var onPosNow = (typeof isPosTxnViewActive === 'function') ? isPosTxnViewActive() : true;
                        if (onPosNow) {
                            if (window._posPostSaleSyncTimer) {
                                try { clearTimeout(window._posPostSaleSyncTimer); } catch (_eT) {}
                            }
                            window._posPostSaleSyncTimer = setTimeout(function () {
                                window._posPostSaleSyncTimer = null;
                                try { syncLiveData(false); } catch (_eS) {}
                            }, (typeof isPosFastLanSync === 'function' && isPosFastLanSync()) ? 50 : 3500);
                        } else {
                            syncLiveData(false);
                        }
                    }
                    var fromPaymentModal = !!window._saleFromPaymentModal;
                    window._saleFromPaymentModal = false;
                    // Update Local Balance Immediately (Fix for Debt Display)
                    const responsePaidAmount = parseFloat(data.paid_amount != null ? data.paid_amount : NaN);
                    const responseDebtAmount = parseFloat(data.debt_amount != null ? data.debt_amount : NaN);
                    const responseBankAmount = parseFloat(data.bank_amount != null ? data.bank_amount : NaN);
                    const paidAmountFinal = isNaN(responsePaidAmount) ? ((method === 'cash') ? total : ((method === 'debt') ? 0 : ((method === 'fib') ? total : ((splitAllocations ? ((parseFloat(splitAllocations.cash) || 0) + (parseFloat(splitAllocations.bank) || 0)) : 0))))) : responsePaidAmount;
                    const debtAmountFinal = isNaN(responseDebtAmount) ? ((method === 'debt') ? total : (splitAllocations ? (parseFloat(splitAllocations.debt) || 0) : 0)) : responseDebtAmount;
                    const bankAmountFinal = isNaN(responseBankAmount) ? ((method === 'fib') ? total : (splitAllocations ? (parseFloat(splitAllocations.bank) || 0) : 0)) : responseBankAmount;

                    // Receipt/debt breakdown (used by thermal + A4 invoice templates)
                    const receiptDebtAdded = Math.max(0, debtAmountFinal);
                    const receiptCashPaid = method === 'fib' ? 0 : Math.max(0, paidAmountFinal - Math.max(0, bankAmountFinal));

                    // Local balance is still pre-sale here (we bump it after print). Total = previous + this invoice.
                    let receiptPreviousDebt = 0;
                    if(targetId > 0) {
                        if(targetType === 'user') {
                            const u = db.users.find(x => x.id == targetId);
                            receiptPreviousDebt = parseFloat(u?.balance || 0) || 0;
                        } else {
                            const c = db.customers.find(x => x.id == targetId);
                            receiptPreviousDebt = parseFloat(c?.balance || 0) || 0;
                        }
                    }
                    if (receiptPreviousDebt < 0) receiptPreviousDebt = 0;
                    const receiptOutstandingDebt = receiptPreviousDebt + receiptDebtAdded;

                    var saleIdResolved = data.id;
                    if (saleIdResolved == null || saleIdResolved === '') {
                        saleIdResolved = (typeof allocateNextSaleIdForDisplay === 'function')
                            ? parseInt(allocateNextSaleIdForDisplay(), 10)
                            : Date.now();
                    }
                    const sale = {
                        id: saleIdResolved, date: data.date || new Date(), table: table.name, total: total,
                        items: itemsToSell, discount: discount, discountPercent: discountPercent, customer: customerName,
                        cashier: currentUser ? currentUser.name : 'System',
                        payment_method: method,
                        customer_id: targetId,
                        customer_type: targetType,
                        remaining_debt: receiptDebtAdded,
                        payment_due_at: (function() {
                            if (data.payment_due_at) return data.payment_due_at;
                            if (receiptDebtAdded <= 0 || !targetId) return null;
                            var ent = null;
                            if (targetType === 'customer' || targetType === 'customers') {
                                ent = (db.customers || []).find(function(x) { return x && String(x.id) === String(targetId); });
                            }
                            var pt = (typeof resolveTxnPaymentTerm === 'function') ? resolveTxnPaymentTerm('pos', ent) : { value: 0, unit: 'day' };
                            return (typeof computePaymentDueAtIso === 'function') ? computePaymentDueAtIso(pt.value, pt.unit, data.date || new Date()) : null;
                        })(),
                        cash_paid: receiptCashPaid,
                        debt_added: receiptDebtAdded,
                        bank_amount: Math.max(0, bankAmountFinal),
                        paid_bank: Math.max(0, bankAmountFinal),
                        paid_amount: Math.max(0, receiptCashPaid + Math.max(0, bankAmountFinal)),
                        debt_amount: receiptDebtAdded,
                        previous_debt: receiptPreviousDebt,
                        total_outstanding_debt: receiptOutstandingDebt,
                        fx_usd_rate: (db.settings && db.settings.usdRate != null) ? Math.round(Number(db.settings.usdRate)) : null,
                        fx_currency_mode: (typeof getActiveCurrency === 'function') ? getActiveCurrency() : ((db.settings && db.settings.currencyMode) || 'IQD')
                    };
                    if (typeof attachSaleBasketPrintFields === 'function') attachSaleBasketPrintFields(sale, itemsToSell);
                    var printSaleFx = (typeof fxUsdRateFormatOpts === 'function') ? fxUsdRateFormatOpts(sale) : undefined;
                    if (!data.duplicate && db.settings && db.settings.autoPrint !== false && window._salePrintIssued !== requestKey) {
                        runPostSalePrintJob({
                            sale: sale,
                            grouped: groupedForPrint,
                            printSaleFx: printSaleFx,
                            subTotal: subTotal,
                            discount: discount,
                            discountPercent: discountPercent,
                            skipNotePopup: true,
                            fastTiming: true
                        });
                    }
                    if (window._salePrintIssued === requestKey) window._salePrintIssued = null;
                    if (fromPaymentModal && !data.duplicate && !isPosPaymentModalSalesUnlimited() && typeof incrementPosDailyPaymentModalUses === 'function') {
                        incrementPosDailyPaymentModalUses();
                    }
                    if(method === 'debt' && targetId > 0) {
                        if(targetType === 'customer' || targetType === 'customers') {
                            const c = db.customers.find(x => x.id == targetId);
                            if(c) {
                                c.balance = (parseFloat(c.balance) || 0) + total;
                                if ((parseInt(data.payment_term_value, 10) || 0) > 0) {
                                    if (!(parseInt(c.payment_term_value, 10) > 0)) {
                                        c.payment_term_value = parseInt(data.payment_term_value, 10) || 0;
                                        c.payment_term_unit = data.payment_term_unit || 'day';
                                    }
                                }
                            }
                        } else if(targetType === 'user') {
                            const u = db.users.find(x => x.id == targetId);
                            if(u) u.balance = (parseFloat(u.balance) || 0) + total;
                        }
                    }
                    if(method === 'split' && targetId > 0) {
                        const debtAmount = debtAmountFinal;
                        if(debtAmount > 0) {
                            if(targetType === 'customer' || targetType === 'customers') {
                                const c = db.customers.find(x => x.id == targetId);
                                if(c) {
                                    c.balance = (parseFloat(c.balance) || 0) + debtAmount;
                                    if ((parseInt(data.payment_term_value, 10) || 0) > 0) {
                                        if (!(parseInt(c.payment_term_value, 10) > 0)) {
                                            c.payment_term_value = parseInt(data.payment_term_value, 10) || 0;
                                            c.payment_term_unit = data.payment_term_unit || 'day';
                                        }
                                    }
                                }
                            } else if(targetType === 'user') {
                                const u = db.users.find(x => x.id == targetId);
                                if(u) u.balance = (parseFloat(u.balance) || 0) + debtAmount;
                            }
                        }
                    }
                    if(data.debt_warning && data.debt_warning.message) {
                        showToast('⚠️ ' + data.debt_warning.message, 'warning');
                    }
                    if(data.payment_due_warning && data.payment_due_warning.message) {
                        showToast('⚠️ ' + data.payment_due_warning.message, 'warning');
                    }
                    var _afterSalePayload = {
                        sale: sale, itemsToSell: itemsToSell, total: total, discount: discount,
                        subTotal: subTotal, discountPercent: discountPercent, method: method,
                        targetId: targetId, targetType: targetType, tableName: table.name,
                        printSaleFx: printSaleFx,
                        dataDuplicate: !!data.duplicate, dataId: data.id,
                        skipPrint: true,
                        booksCommitted: true
                    };
                    // Commit books immediately — setTimeout(0) was racing UI on weak laptops.
                    if (typeof commitSaleToLocalBooks === 'function') commitSaleToLocalBooks(_afterSalePayload);
                    setTimeout(function () { runPostSaleBackgroundTasks(_afterSalePayload); }, 0);
                } else {
                    throw new Error(data.message || 'Unknown server error');
                }
            }).catch(err => {
                window._confirmAdvancedPaymentPending = false;
                window._saleFromPaymentModal = false;
                window._isCartSaving = false;
                if (window._salePrintIssued === requestKey) {
                    window._salePrintIssued = null;
                    var voidMsg = (typeof t === 'function') ? (t('toast_sale_failed_receipt_void') || 'هەڵە: وەسڵ چاپبووە — پێویستە دەستی ب ژێبەرێ') : 'هەڵە: وەسڵ چاپبووە — پێویستە دەستی ب ژێبەرێ';
                    if (typeof showToast === 'function') showToast(voidMsg, 'warning');
                }
                if (table && originalItems && originalItems.length && (!table.items || table.items.length === 0)) {
                    table.items = originalItems;
                    if (originalDiscount !== undefined && originalDiscount !== null) table.manualDiscount = originalDiscount;
                    else delete table.manualDiscount;
                    var custEl = document.getElementById('pos-customer-name');
                    if (custEl) custEl.value = originalCustomerName || '';
                    if (discountInputEl && originalDiscount == null) discountInputEl.value = '';
                    lastTableState = '';
                    if (typeof saveActivePosTabSnapshot === 'function') saveActivePosTabSnapshot();
                    if (typeof renderPosTabsUI === 'function') renderPosTabsUI();
                    if (typeof renderBill === 'function') renderBill();
                    if (typeof refreshAllStockDisplaysFromState === 'function') refreshAllStockDisplaysFromState();
                    if (activeTableId) {
                        cartSaveQueue.push({ id: activeTableId, items: JSON.stringify(table.items) });
                        if (typeof processCartSaveQueue === 'function') processCartSaveQueue();
                    }
                }
                const rawMsg = String(err && err.message ? err.message : '');
                let uiMsg = "❌ هەڵە: " + rawMsg;
                let toastType = 'error';
                if (/over allocated/i.test(rawMsg)) {
                    uiMsg = "❌ کۆی پارەی دابەشکراو پترە ژ کۆیا پسوولێ.";
                } else if (/remaining balance|not covered/i.test(rawMsg)) {
                    uiMsg = "❌ بڕی پارە نەتەواوە؛ باقی هەیە.";
                } else                 if (/duplicate/i.test(rawMsg)) {
                    uiMsg = "⚠️ ئەم مامەڵەیە پێشتر تۆمار بووە (duplicate).";
                    toastType = 'warning';
                } else if (/daily_sales_cap_exceeded/i.test(rawMsg)) {
                    if (typeof showPaymentDailyCapPurchasePopup === 'function') showPaymentDailyCapPurchasePopup();
                    return;
                } else if (/stock_not_enough_batches/i.test(rawMsg)) {
                    var reqM = rawMsg.match(/pieces required:\s*([\d.]+)/i);
                    var missM = rawMsg.match(/missing in stock_batches:\s*([\d.]+)/i);
                    var nameM = rawMsg.match(/stock_not_enough_batches:\s*(.+?)\s*\[product_id=/i);
                    var reqN = reqM ? parseFloat(reqM[1]) : 0;
                    var missN = missM ? parseFloat(missM[1]) : 0;
                    var availN = Math.max(0, reqN - missN);
                    var availStr = (Math.abs(availN - Math.round(availN)) < 0.0001) ? String(Math.round(availN)) : String(availN);
                    var nameStr = nameM ? String(nameM[1]).trim() : '';
                    uiMsg = '⚠️ کۆگە'
                        + (nameStr ? ' یا «' + nameStr + '»' : '')
                        + ' تەنها ' + availStr + ' دانەیە — ژمارە د سەبەتێ کێم بکە.';
                    toastType = 'warning';
                    if (typeof connectToDB === 'function') {
                        connectToDB(true, { skipRenderOnRefresh: true }).then(function () {
                            if (typeof refreshAllStockDisplaysFromState === 'function') refreshAllStockDisplaysFromState();
                        });
                    }
                } else if (/stock_not_enough/i.test(rawMsg)) {
                    var snM = rawMsg.match(/stock_not_enough:?\s*([^(]+)?\s*\(available:\s*([\d.]+),\s*required:\s*([\d.]+)\)/i);
                    var sName = snM && snM[1] ? String(snM[1]).trim() : '';
                    var sAvail = snM ? parseFloat(snM[2]) : 0;
                    var sReq = snM ? parseFloat(snM[3]) : 0;
                    var sAvailStr = (Math.abs(sAvail - Math.round(sAvail)) < 0.0001) ? String(Math.round(sAvail)) : String(sAvail);
                    var sReqStr = (Math.abs(sReq - Math.round(sReq)) < 0.0001) ? String(Math.round(sReq)) : String(sReq);
                    uiMsg = '⚠️ کۆگە تێر نینە'
                        + (sName ? ' — ' + sName : '')
                        + ' (بەردەست: ' + sAvailStr + '، پێویست: ' + sReqStr + '). ژمارە د سەبەتێ کێم بکە.';
                    toastType = 'warning';
                    if (typeof connectToDB === 'function') {
                        connectToDB(true, { skipRenderOnRefresh: true }).then(function () {
                            if (typeof refreshAllStockDisplaysFromState === 'function') refreshAllStockDisplaysFromState();
                        });
                    }
                }
                if (typeof showToast === 'function') showToast(uiMsg, toastType);
                else alert(uiMsg);
            });
        }

        function buildSaleReceiptGrouped(items) {
            var grouped = {};
            (items || []).forEach(function (i) {
                var key = i.id + '_' + (i.note || '') + '_' + i.price + '_' + (i.saleUnit || 'piece') + '_' + (i.isGift ? 'gift' : 'normal');
                if (!grouped[key]) grouped[key] = { name: i.name, price: i.price, count: 0, sub: 0, note: i.note, saleUnit: i.saleUnit || 'piece', isGift: !!i.isGift };
                var lineQty = getItemQty(i);
                grouped[key].count += lineQty;
                var uPr = (typeof isPosCartLineGift === 'function' ? isPosCartLineGift(i) : !!i.isGift)
                    ? 0
                    : (typeof getBillLineUnitIqd === 'function' ? getBillLineUnitIqd(i) : (Number(i.price) || 0));
                grouped[key].sub += uPr * lineQty;
            });
            return grouped;
        }

        function buildProvisionalSaleForPrint(opts) {
            var total = opts.total;
            var method = opts.method || 'cash';
            var targetId = opts.targetId || 0;
            var targetType = opts.targetType || '';
            var splitAllocations = opts.splitAllocations;
            var debtAdded = method === 'debt' ? total : (method === 'split' && splitAllocations ? (parseFloat(splitAllocations.debt) || 0) : 0);
            var bankAmtPrint = method === 'fib' ? total : (method === 'split' && splitAllocations ? (parseFloat(splitAllocations.bank) || 0) : 0);
            var cashPaid = method === 'cash' ? total : (method === 'split' && splitAllocations ? (parseFloat(splitAllocations.cash) || 0) : 0);
            var previousDebt = 0;
            if (targetId > 0) {
                if (targetType === 'user') {
                    var u = db.users && db.users.find(function (x) { return x.id == targetId; });
                    previousDebt = parseFloat(u && u.balance) || 0;
                } else {
                    var c = db.customers && db.customers.find(function (x) { return x.id == targetId; });
                    previousDebt = parseFloat(c && c.balance) || 0;
                }
            }
            if (previousDebt < 0) previousDebt = 0;
            var provisionalNumericId = (typeof allocateNextSaleIdForDisplay === 'function')
                ? parseInt(allocateNextSaleIdForDisplay(), 10)
                : Date.now();
            var sale = {
                id: opts.provisionalId || provisionalNumericId,
                date: new Date(),
                table: opts.tableName || '',
                total: total,
                items: opts.itemsToSell,
                discount: opts.discount,
                discountPercent: opts.discountPercent,
                customer: opts.customerName || '',
                cashier: currentUser ? currentUser.name : 'System',
                payment_method: method,
                customer_id: targetId,
                customer_type: targetType,
                cash_paid: cashPaid,
                debt_added: debtAdded,
                bank_amount: bankAmtPrint,
                paid_bank: bankAmtPrint,
                paid_amount: cashPaid + bankAmtPrint,
                debt_amount: debtAdded,
                previous_debt: previousDebt,
                total_outstanding_debt: previousDebt + debtAdded,
                fx_usd_rate: (db.settings && db.settings.usdRate != null) ? Math.round(Number(db.settings.usdRate)) : null,
                fx_currency_mode: (typeof getActiveCurrency === 'function') ? getActiveCurrency() : ((db.settings && db.settings.currencyMode) || 'IQD')
            };
            if (typeof attachSaleBasketPrintFields === 'function') attachSaleBasketPrintFields(sale, opts.itemsToSell);
            return sale;
        }

        function triggerInstantSalePrint(opts) {
            if (!db || !db.settings || db.settings.autoPrint === false) return false;
            var sale = buildProvisionalSaleForPrint(opts);
            var grouped = buildSaleReceiptGrouped(opts.itemsToSell);
            var printSaleFx = (typeof fxUsdRateFormatOpts === 'function') ? fxUsdRateFormatOpts(sale) : undefined;
            executePosSalePrint(sale, grouped, {
                printSaleFx: printSaleFx,
                subTotal: opts.subTotal,
                discount: opts.discount,
                discountPercent: opts.discountPercent,
                skipNotePopup: true,
                fastTiming: true
            });
            return true;
        }

        function commitSaleToLocalBooks(payload) {
            if (!payload || !payload.sale || !db) return;
            if (!Array.isArray(db.sales)) db.sales = [];
            var sale = payload.sale;
            var total = payload.total;
            var dataDuplicate = !!payload.dataDuplicate;
            var saleIdKey = sale.id != null && sale.id !== '' ? String(sale.id) : '';
            var alreadyInSales = saleIdKey
                ? db.sales.some(function (s) { return s && String(s.id) === saleIdKey; })
                : false;
            if (!alreadyInSales) {
                db.sales.unshift(sale);
                if (db.today_stats && !dataDuplicate) {
                    db.today_stats.sales = (parseFloat(db.today_stats.sales) || 0) + total;
                    db.today_stats.count = (parseInt(db.today_stats.count) || 0) + 1;
                }
                if (typeof window._cachedTopSellingCounts !== 'undefined') window._cachedTopSellingCounts = -1;
            }
            if (typeof window.invalidateSalesPoolCache === 'function') window.invalidateSalesPoolCache();
            if (!dataDuplicate && typeof getBusinessDate === 'function') {
                if (typeof posInvalidateDailyDetailCache === 'function') {
                    posInvalidateDailyDetailCache(getBusinessDate(new Date()));
                } else if (window._dailyDetailCache) {
                    try { delete window._dailyDetailCache[getBusinessDate(new Date())]; } catch (_eDdc) {}
                }
            }
            if (typeof updateStats === 'function') updateStats();
            // Don't wipe all month stats on every sale — mark stale; calendar refreshes when opened
            if (typeof invalidateCalendarMonthCache === 'function') {
                var calView = document.getElementById('view-calendar');
                if (calView && calView.classList.contains('active')) {
                    invalidateCalendarMonthCache();
                } else {
                    window._calMonthCacheStale = true;
                }
            }
            if (typeof scheduleSave === 'function') scheduleSave();
            if (typeof posRefreshOpenFinancialScreens === 'function') posRefreshOpenFinancialScreens();
        }

        function runPostSaleBackgroundTasks(payload) {
            if (!payload || !payload.sale) return;
            var sale = payload.sale;
            var itemsToSell = payload.itemsToSell;
            var total = payload.total;
            var discount = payload.discount;
            var subTotal = payload.subTotal;
            var discountPercent = payload.discountPercent;
            var method = payload.method;
            var targetId = payload.targetId;
            var targetType = payload.targetType;
            var printSaleFx = payload.printSaleFx;
            var data = { duplicate: payload.dataDuplicate, id: payload.dataId };

            // Books already committed synchronously; keep this path idempotent for older call sites.
            if (!payload.booksCommitted) {
                commitSaleToLocalBooks(payload);
            }

            if (db.settings && db.settings.tgToken && db.settings.tgChatId) {
                var emoji = method === 'cash' ? '💵' : (method === 'debt' ? '📕' : '💳');
                var msg = '🧾 **فرۆتنەکا نوو**\n' +
                    '📅 ' + new Date().toLocaleTimeString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ') + '\n' +
                    '👤 ' + (currentUser ? currentUser.name : 'System') + '\n' +
                    '💰 **' + formatCurrency(total, printSaleFx) + ' ' + getCurrencySymbol() + '** (' + emoji + ')\n' +
                    '📦 ژمارا ئایتمان: ' + itemsToSell.length + '\n' +
                    (payload.tableName ? '🍽️ ' + payload.tableName : '');
                // Do not send individual sales to telegram, only send the daily report
                // sendTelegramNotification(msg);
            }

            var grouped = buildSaleReceiptGrouped(sale.items);
            var successMsg = { type: 'success', total: total, timestamp: Date.now() };
            if (window.customerChannel) window.customerChannel.postMessage(successMsg);
            try { localStorage.setItem('LAPTOP_DUHOK_POS_display_sync', JSON.stringify(successMsg)); } catch (eLs) {}
            var fdSuccess = new FormData();
            fdSuccess.append('action', 'update_customer_display');
            fdSuccess.append('data', JSON.stringify(successMsg));
            fetch('?action=update_customer_display', { method: 'POST', body: fdSuccess }).catch(function () {});

            if (!payload.skipPrint) {
                runPostSalePrintJob({ sale: sale, grouped: grouped, printSaleFx: printSaleFx, subTotal: subTotal, discount: discount, discountPercent: discountPercent, skipNotePopup: true });
            }

            // Continuous flash: XAMPP stays live; ZIP + mysql/data snapshot → USB (debounced)
            try {
                if (typeof posFlashScheduleSync === 'function') posFlashScheduleSync('sale');
            } catch (_eFlashSale) {}
        }

        function runPostSalePrintJob(payload) {
            if (!payload || !payload.sale) return;
            try {
                var fastTiming = payload.fastTiming === true || payload.fastPrint === true;
                executePosSalePrint(payload.sale, payload.grouped || {}, {
                    printSaleFx: payload.printSaleFx,
                    subTotal: payload.subTotal,
                    discount: payload.discount,
                    discountPercent: payload.discountPercent,
                    skipNotePopup: payload.skipNotePopup === true,
                    fastTiming: fastTiming
                });
            } catch (e) {
                console.warn('[runPostSalePrintJob]', e);
            }
        }
