using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;

internal static class BuildPosIco
{
    private static void Main(string[] args)
    {
        string pngPath = args[0];
        string icoPath = args[1];
        int[] sizes = new int[] { 256, 64, 48, 32, 16 };

        using (Bitmap src = (Bitmap)Image.FromFile(pngPath))
        {
            using (MemoryStream ico = new MemoryStream())
            using (BinaryWriter bw = new BinaryWriter(ico))
            {
                byte[][] images = new byte[sizes.Length][];
                for (int i = 0; i < sizes.Length; i++)
                    images[i] = EncodePng(ResizeHigh(src, sizes[i]));

                bw.Write((ushort)0);
                bw.Write((ushort)1);
                bw.Write((ushort)sizes.Length);

                int offset = 6 + (16 * sizes.Length);
                for (int i = 0; i < sizes.Length; i++)
                {
                    int s = sizes[i];
                    bw.Write((byte)(s >= 256 ? 0 : s));
                    bw.Write((byte)(s >= 256 ? 0 : s));
                    bw.Write((byte)0);
                    bw.Write((byte)0);
                    bw.Write((ushort)1);
                    bw.Write((ushort)32);
                    bw.Write(images[i].Length);
                    bw.Write(offset);
                    offset += images[i].Length;
                }
                for (int i = 0; i < images.Length; i++)
                    bw.Write(images[i]);

                File.WriteAllBytes(icoPath, ico.ToArray());
            }
        }
        Console.WriteLine("ICO " + new FileInfo(icoPath).Length);
    }

    private static Bitmap ResizeHigh(Bitmap src, int size)
    {
        Bitmap dest = new Bitmap(size, size, PixelFormat.Format32bppArgb);
        using (Graphics g = Graphics.FromImage(dest))
        {
            g.CompositingMode = CompositingMode.SourceCopy;
            g.Clear(Color.Transparent);
            g.CompositingMode = CompositingMode.SourceOver;
            g.CompositingQuality = CompositingQuality.HighQuality;
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.SmoothingMode = SmoothingMode.HighQuality;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            g.DrawImage(src, 0, 0, size, size);
        }
        return dest;
    }

    private static byte[] EncodePng(Bitmap bmp)
    {
        using (bmp)
        using (MemoryStream ms = new MemoryStream())
        {
            bmp.Save(ms, ImageFormat.Png);
            return ms.ToArray();
        }
    }
}
