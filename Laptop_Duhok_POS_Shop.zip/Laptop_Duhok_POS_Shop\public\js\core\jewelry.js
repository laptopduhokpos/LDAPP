/**
 * Gold/silver jewelry helpers: rates, karat, weight pricing.
 */
(function (global) {
    'use strict';

    var KARAT_OPTIONS = [18, 21, 22, 24];

    function isJewelryMode() {
        try {
            return !!(global.db && global.db.settings && global.db.settings.systemMode === 'jewelry');
        } catch (e) {
            return false;
        }
    }

    function normalizeMetalType(v) {
        v = String(v || '').toLowerCase().trim();
        if (v === 'gold' || v === 'زێر' || v === 'ذهب') return 'gold';
        if (v === 'silver' || v === 'زیڤ' || v === 'زیف' || v === 'فضة') return 'silver';
        return '';
    }

    function normalizeKarat(v) {
        var n = parseFloat(v);
        if (!isFinite(n) || n <= 0) return null;
        n = Math.round(n * 100) / 100;
        if (KARAT_OPTIONS.indexOf(Math.round(n)) >= 0) return Math.round(n);
        return n;
    }

    function normalizeJewelryPriceMode(v) {
        v = String(v || '').toLowerCase().trim();
        return v === 'by_weight' ? 'by_weight' : 'fixed';
    }

    function isJewelryByWeightProduct(prod) {
        // Never affect market / restaurant / other modes
        if (!isJewelryMode() || !prod) return false;
        var metal = normalizeMetalType(prod.metal_type);
        var w = Number(prod.weight_grams) || 0;
        // Jewelry shop: grams saved → price follows daily metal rate
        if (w > 0) {
            return true;
        }
        if (!metal) return false;
        if (normalizeJewelryPriceMode(prod.jewelry_price_mode) === 'by_weight') return true;
        return false;
    }

    /** Effective metal for pricing (jewelry mode defaults empty → silver when grams exist). */
    function effectiveJewelryMetal(prod) {
        if (!prod || !isJewelryMode()) return '';
        var metal = normalizeMetalType(prod.metal_type);
        if (metal) return metal;
        if ((Number(prod.weight_grams) || 0) > 0) return 'silver';
        return '';
    }

    var DEFAULT_SILVER_GRADES = [
        { code: '925', name: '925', sell: 0, buy: 0 },
        { code: '999', name: '999', sell: 0, buy: 0 }
    ];

    function normalizeSilverGradeCode(v) {
        var s = String(v == null ? '' : v).trim();
        if (!s) return '';
        // Keep digits (925, 999, 800…) — also allow decimal as string key
        var n = parseFloat(s.replace(/,/g, ''));
        if (isFinite(n) && n > 0) {
            // Prefer integer codes for purity
            if (Math.abs(n - Math.round(n)) < 0.0001) return String(Math.round(n));
            return String(Math.round(n * 1000) / 1000);
        }
        return s.slice(0, 32);
    }

    function getSilverGrades() {
        var s = (global.db && global.db.settings) ? global.db.settings : {};
        var list = Array.isArray(s.silverGrades) ? s.silverGrades : [];
        var out = [];
        var seen = {};
        list.forEach(function (g) {
            if (!g) return;
            var code = normalizeSilverGradeCode(g.code != null ? g.code : g.karat);
            if (!code || seen[code]) return;
            seen[code] = true;
            out.push({
                code: code,
                name: String(g.name || code || 'ئایتم').trim().slice(0, 60) || code,
                sell: Math.max(0, Math.round(Number(g.sell != null ? g.sell : g.rate) || 0)),
                buy: Math.max(0, Math.round(Number(g.buy != null ? g.buy : g.buyRate) || 0))
            });
        });
        // Migrate legacy single silver rate into 925 if no grades yet
        if (!out.length) {
            var legacySell = Math.max(0, Math.round(Number(s.silverRate) || 0));
            var legacyBuy = Math.max(0, Math.round(Number(s.silverBuyRate) || 0));
            out = DEFAULT_SILVER_GRADES.map(function (d) {
                return {
                    code: d.code,
                    name: d.name,
                    sell: d.code === '925' ? legacySell : 0,
                    buy: d.code === '925' ? legacyBuy : 0
                };
            });
        }
        return out;
    }

    function setSilverGrades(grades) {
        if (!global.db) return;
        if (!global.db.settings) global.db.settings = {};
        var clean = [];
        var seen = {};
        (grades || []).forEach(function (g) {
            if (!g) return;
            var code = normalizeSilverGradeCode(g.code);
            if (!code || seen[code]) return;
            seen[code] = true;
            clean.push({
                code: code,
                name: String(g.name || code || 'ئایتم').trim().slice(0, 60) || code,
                sell: Math.max(0, Math.round(Number(g.sell) || 0)),
                buy: Math.max(0, Math.round(Number(g.buy) || 0))
            });
        });
        if (!clean.length) clean = DEFAULT_SILVER_GRADES.map(function (d) {
            return { code: d.code, name: d.name, sell: 0, buy: 0 };
        });
        global.db.settings.silverGrades = clean;
        // Keep legacy fields in sync (first grade / 925) for old code paths
        var primary = clean.find(function (g) { return g.code === '925'; }) || clean[0];
        if (primary) {
            global.db.settings.silverRate = primary.sell || 0;
            global.db.settings.silverBuyRate = primary.buy || 0;
        }
    }

    function findSilverGrade(codeOrKarat) {
        var code = normalizeSilverGradeCode(codeOrKarat);
        var grades = getSilverGrades();
        if (!code) return grades[0] || null;
        for (var i = 0; i < grades.length; i++) {
            if (grades[i].code === code) return grades[i];
        }
        // Numeric fuzzy match
        var n = parseFloat(code);
        if (isFinite(n)) {
            for (var j = 0; j < grades.length; j++) {
                if (Math.abs(parseFloat(grades[j].code) - n) < 0.0001) return grades[j];
            }
        }
        return null;
    }

    function getJewelryRates() {
        var s = (global.db && global.db.settings) ? global.db.settings : {};
        var grades = getSilverGrades();
        var primary = grades.find(function (g) { return g.code === '925'; }) || grades[0] || { sell: 0, buy: 0 };
        return {
            gold18: Math.max(0, Number(s.goldRate18) || 0),
            gold21: Math.max(0, Number(s.goldRate21) || 0),
            gold22: Math.max(0, Number(s.goldRate22) || 0),
            gold24: Math.max(0, Number(s.goldRate24) || 0),
            silver: Math.max(0, Number(primary.sell) || Number(s.silverRate) || 0),
            buyGold18: Math.max(0, Number(s.goldBuyRate18) || 0),
            buyGold21: Math.max(0, Number(s.goldBuyRate21) || 0),
            buyGold22: Math.max(0, Number(s.goldBuyRate22) || 0),
            buyGold24: Math.max(0, Number(s.goldBuyRate24) || 0),
            buySilver: Math.max(0, Number(primary.buy) || Number(s.silverBuyRate) || 0),
            silverGrades: grades
        };
    }

    function getRatePerGram(metalType, karat) {
        var rates = getJewelryRates();
        var metal = normalizeMetalType(metalType);
        if (metal === 'silver') {
            var sg = findSilverGrade(karat);
            if (sg && sg.sell > 0) return sg.sell;
            return rates.silver;
        }
        if (metal !== 'gold') return 0;
        var k = normalizeKarat(karat);
        if (k === 18) return rates.gold18;
        if (k === 21) return rates.gold21;
        if (k === 22) return rates.gold22;
        if (k === 24) return rates.gold24;
        if (rates.gold21 > 0 && k > 0) {
            return Math.round(rates.gold21 * (k / 21));
        }
        return 0;
    }

    function getBuyRatePerGram(metalType, karat) {
        var rates = getJewelryRates();
        var metal = normalizeMetalType(metalType);
        if (metal === 'silver') {
            var sg = findSilverGrade(karat);
            if (sg && sg.buy > 0) return sg.buy;
            return rates.buySilver;
        }
        if (metal !== 'gold') return 0;
        var k = normalizeKarat(karat);
        if (k === 18) return rates.buyGold18;
        if (k === 21) return rates.buyGold21;
        if (k === 22) return rates.buyGold22;
        if (k === 24) return rates.buyGold24;
        if (rates.buyGold21 > 0 && k > 0) {
            return Math.round(rates.buyGold21 * (k / 21));
        }
        return 0;
    }

    function formatJewelryRateChip() {
        var rates = getJewelryRates();
        var fmt = function (n) {
            n = Math.round(Number(n) || 0);
            if (!(n > 0)) return '—';
            try {
                return n.toLocaleString('en-US');
            } catch (e) {
                return String(n);
            }
        };
        var parts = [];
        var grades = rates.silverGrades || getSilverGrades();
        var withRate = grades.filter(function (g) { return (g.buy > 0 || g.sell > 0); });
        if (withRate.length) {
            var g0 = withRate[0];
            var more = withRate.length > 1 ? (' +' + (withRate.length - 1)) : '';
            parts.push('زیڤ ' + (g0.name || g0.code) + more + ' کڕین ' + fmt(g0.buy) + ' · فرۆشتن ' + fmt(g0.sell));
        } else if (rates.buyGold21 > 0 || rates.gold21 > 0) {
            parts.push('زێر21 کڕین ' + fmt(rates.buyGold21) + ' · فرۆشتن ' + fmt(rates.gold21));
        }
        return parts.join(' | ');
    }

    function updateJewelryRatesChip() {
        var chip = document.getElementById('pos-jewelry-rates-chip');
        if (!chip) return;
        if (!isJewelryMode()) {
            chip.style.display = 'none';
            chip.textContent = '';
            return;
        }
        var text = formatJewelryRateChip();
        chip.textContent = text || 'نرخی ڕۆژانە دابنێ';
        chip.title = text || 'نرخی ڕۆژانەی کڕین و فرۆشتن';
        chip.style.display = '';
    }

    function computeJewelryUnitPrice(opts) {
        opts = opts || {};
        var metal = normalizeMetalType(opts.metal_type || opts.metalType);
        var karat = normalizeKarat(opts.karat);
        var weight = parseFloat(opts.weight_grams != null ? opts.weight_grams : opts.weightGrams);
        if (!isFinite(weight) || weight < 0) weight = 0;
        var making = parseFloat(opts.making_charge != null ? opts.making_charge : opts.makingCharge);
        if (!isFinite(making) || making < 0) making = 0;
        var rate = getRatePerGram(metal, karat);
        var metalPart = weight * rate;
        var total = metalPart + making;
        if (typeof global.roundMoney === 'function') return global.roundMoney(total);
        return Math.round(total);
    }

    /** Buy/cost by gram: weight × daily buy rate (no making — making is sell-side). */
    function computeJewelryBuyUnitPrice(opts) {
        opts = opts || {};
        var metal = normalizeMetalType(opts.metal_type || opts.metalType);
        var karat = normalizeKarat(opts.karat);
        var weight = parseFloat(opts.weight_grams != null ? opts.weight_grams : opts.weightGrams);
        if (!isFinite(weight) || weight < 0) weight = 0;
        var rate = getBuyRatePerGram(metal, karat);
        if (!(rate > 0) || !(weight > 0)) return 0;
        var total = weight * rate;
        if (typeof global.roundMoney === 'function') return global.roundMoney(total);
        return Math.round(total);
    }

    function computeProductJewelryPrice(prod, weightOverride) {
        if (!prod) return 0;
        var w = weightOverride != null ? weightOverride : prod.weight_grams;
        return computeJewelryUnitPrice({
            metal_type: effectiveJewelryMetal(prod) || prod.metal_type,
            karat: prod.karat,
            weight_grams: w,
            making_charge: prod.making_charge
        });
    }

    function computeProductJewelryBuyCost(prod, weightOverride) {
        if (!prod) return 0;
        var w = weightOverride != null ? weightOverride : prod.weight_grams;
        return computeJewelryBuyUnitPrice({
            metal_type: effectiveJewelryMetal(prod) || prod.metal_type,
            karat: prod.karat,
            weight_grams: w
        });
    }

    function jewelryMetaLabel(prodOrLine) {
        if (!prodOrLine || !isJewelryMode()) return '';
        var metal = normalizeMetalType(prodOrLine.metal_type || prodOrLine.jewelry_metal);
        if (!metal && (Number(prodOrLine.weight_grams != null ? prodOrLine.weight_grams : prodOrLine.jewelry_weight) || 0) > 0) {
            metal = 'silver';
        }
        var karatRaw = prodOrLine.karat != null ? prodOrLine.karat : prodOrLine.jewelry_karat;
        var karat = normalizeKarat(karatRaw);
        var weight = parseFloat(prodOrLine.weight_grams != null ? prodOrLine.weight_grams : prodOrLine.jewelry_weight);
        var parts = [];
        if (metal === 'gold') {
            parts.push(karat ? ('زێر ' + karat + 'K') : 'زێر');
        } else if (metal === 'silver') {
            var sg = findSilverGrade(karatRaw);
            parts.push(sg ? ('زیڤ ' + (sg.name || sg.code || '')) : (karat ? ('زیڤ ' + karat) : 'زیڤ'));
        }
        if (isFinite(weight) && weight > 0) {
            parts.push((Math.round(weight * 1000) / 1000) + 'g');
        }
        return parts.join(' · ');
    }

    function fillKaratSelectOptions(metal, preferredValue) {
        var karatEl = document.getElementById('p-karat');
        if (!karatEl) return;
        metal = normalizeMetalType(metal);
        var want = preferredValue != null && preferredValue !== ''
            ? String(preferredValue)
            : String(karatEl.value || '');
        karatEl.innerHTML = '';
        if (metal === 'gold') {
            KARAT_OPTIONS.forEach(function (k) {
                var opt = document.createElement('option');
                opt.value = String(k);
                opt.textContent = String(k);
                karatEl.appendChild(opt);
            });
            if (!want || KARAT_OPTIONS.indexOf(Math.round(parseFloat(want))) < 0) want = '21';
            karatEl.value = String(Math.round(parseFloat(want)) || 21);
            return;
        }
        if (metal === 'silver') {
            var grades = getSilverGrades();
            if (!grades.length) {
                grades = DEFAULT_SILVER_GRADES.map(function (d) {
                    return { code: d.code, name: d.name, sell: 0, buy: 0 };
                });
            }
            grades.forEach(function (g) {
                var opt = document.createElement('option');
                opt.value = g.code;
                opt.textContent = g.name || g.code || 'ئایتم';
                karatEl.appendChild(opt);
            });
            var wantCode = normalizeSilverGradeCode(want);
            var match = grades.find(function (g) { return g.code === wantCode; });
            karatEl.value = match ? match.code : grades[0].code;
        }
    }

    function escAttr(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }

    function renderSilverGradesList(containerId, opts) {
        opts = opts || {};
        var el = document.getElementById(containerId);
        if (!el) return;
        var grades = getSilverGrades();
        var canRemove = opts.allowRemove !== false;
        var onChange = opts.onChange || '';
        el.innerHTML = grades.map(function (g) {
            var buyVal = g.buy > 0 ? String(Math.round(g.buy)) : '';
            var sellVal = g.sell > 0 ? String(Math.round(g.sell)) : '';
            var rm = canRemove
                ? ('<button type="button" class="btn btn-sm btn-dark" title="سڕینەوە" onclick="if(typeof removeSilverGrade===\'function\')removeSilverGrade(\'' + escAttr(g.code) + '\')"><i class="fas fa-trash"></i></button>')
                : '<span></span>';
            return '<div data-sg-row data-sg-code="' + escAttr(g.code) + '" style="display:grid; grid-template-columns:1.2fr 1fr 1fr auto; gap:6px; margin-bottom:6px; align-items:center;">'
                + '<input type="text" class="input-std" data-sg-name dir="ltr" value="' + escAttr(g.name || g.code || '') + '" placeholder="ناڤ" style="margin:0;"' + (onChange ? (' onchange="' + onChange + '"') : '') + '>'
                + '<input type="number" class="input-std" data-sg-buy min="0" step="1" placeholder="کڕین" dir="ltr" value="' + escAttr(buyVal) + '" style="margin:0;"' + (onChange ? (' onchange="' + onChange + '"') : '') + '>'
                + '<input type="number" class="input-std" data-sg-sell min="0" step="1" placeholder="فرۆشتن" dir="ltr" value="' + escAttr(sellVal) + '" style="margin:0;"' + (onChange ? (' onchange="' + onChange + '"') : '') + '>'
                + rm
                + '</div>';
        }).join('');
    }

    function renderAllSilverGradeLists() {
        renderSilverGradesList('pos-jew-silver-grades-list', { allowRemove: true });
        renderSilverGradesList('set-silver-grades-list', {
            allowRemove: true,
            onChange: "if(typeof applyJewelryRateSettings==='function')applyJewelryRateSettings(false)"
        });
    }

    function readSilverGradesFromContainer(containerId) {
        var el = document.getElementById(containerId);
        if (!el) return null;
        var rows = el.querySelectorAll('[data-sg-row]');
        if (!rows.length) return null;
        var out = [];
        var seen = {};
        Array.prototype.forEach.call(rows, function (row) {
            var code = normalizeSilverGradeCode(row.getAttribute('data-sg-code'));
            var nameEl = row.querySelector('[data-sg-name]');
            var buyEl = row.querySelector('[data-sg-buy]');
            var sellEl = row.querySelector('[data-sg-sell]');
            var name = nameEl ? String(nameEl.value || '').trim() : code;
            var buy = buyEl ? parseFloat(String(buyEl.value || '').replace(/,/g, '')) : 0;
            var sell = sellEl ? parseFloat(String(sellEl.value || '').replace(/,/g, '')) : 0;
            if (!code || seen[code]) return;
            seen[code] = true;
            out.push({
                code: code,
                name: name || code,
                buy: (isFinite(buy) && buy > 0) ? Math.round(buy) : 0,
                sell: (isFinite(sell) && sell > 0) ? Math.round(sell) : 0
            });
        });
        return out;
    }

    function promptAddSilverGrade(fromRatesUi) {
        if (!isJewelryMode()) return;
        var raw = window.prompt('ناڤ / ژمارەی دەرجەی زیڤ بنڤیسە (وەک 925، 999، 800…)', '');
        if (raw == null) return;
        var code = normalizeSilverGradeCode(raw);
        if (!code) {
            if (typeof global.showToast === 'function') global.showToast('⚠️ دەرجەێک دروست بنڤیسە');
            return;
        }
        // Persist any typed rates before mutating list
        if (fromRatesUi) {
            var fromModal = readSilverGradesFromContainer('pos-jew-silver-grades-list');
            var fromSet = readSilverGradesFromContainer('set-silver-grades-list');
            if (fromModal && fromModal.length) setSilverGrades(fromModal);
            else if (fromSet && fromSet.length) setSilverGrades(fromSet);
        }
        var grades = getSilverGrades();
        if (grades.some(function (g) { return g.code === code; })) {
            if (typeof global.showToast === 'function') global.showToast('ℹ️ ئەڤ دەرجە هەیە');
            fillKaratSelectOptions('silver', code);
            var metalEl = document.getElementById('p-metal-type');
            if (metalEl && normalizeMetalType(metalEl.value) === 'silver') {
                var karatEl = document.getElementById('p-karat');
                if (karatEl) karatEl.value = code;
            }
            renderAllSilverGradeLists();
            return;
        }
        grades.push({ code: code, name: code, sell: 0, buy: 0 });
        setSilverGrades(grades);
        renderAllSilverGradeLists();
        fillKaratSelectOptions('silver', code);
        var metalEl2 = document.getElementById('p-metal-type');
        if (metalEl2 && normalizeMetalType(metalEl2.value) !== 'silver') {
            metalEl2.value = 'silver';
            syncJewelryFormMetalUi();
        } else {
            var karatEl2 = document.getElementById('p-karat');
            if (karatEl2) karatEl2.value = code;
            syncJewelryFormPreview();
            syncJewelrySetPricingFromGrams();
        }
        if (typeof global.saveSettings === 'function') {
            global.saveSettings().catch(function () {});
        }
        if (typeof global.showToast === 'function') global.showToast('✅ دەرجەی زیڤ ' + code + ' هاتە زێدەکرن');
    }

    function removeSilverGrade(code) {
        code = normalizeSilverGradeCode(code);
        if (!code) return;
        var fromModal = readSilverGradesFromContainer('pos-jew-silver-grades-list');
        var fromSet = readSilverGradesFromContainer('set-silver-grades-list');
        var grades = (fromModal && fromModal.length) ? fromModal
            : ((fromSet && fromSet.length) ? fromSet : getSilverGrades());
        if (grades.length <= 1) {
            if (typeof global.showToast === 'function') global.showToast('⚠️ دەبێت لانی کەم ئێک دەرجە بمێنیت');
            return;
        }
        grades = grades.filter(function (g) { return g.code !== code; });
        setSilverGrades(grades);
        renderAllSilverGradeLists();
        var metalEl = document.getElementById('p-metal-type');
        if (metalEl && normalizeMetalType(metalEl.value) === 'silver') {
            fillKaratSelectOptions('silver');
            syncJewelryFormPreview();
        }
        if (typeof global.saveSettings === 'function') {
            global.saveSettings().catch(function () {});
        }
    }

    function syncJewelryFormPreview() {
        if (!isJewelryMode()) return;
        var preview = document.getElementById('p-jewelry-price-preview');
        var modeEl = document.getElementById('p-jewelry-price-mode');
        var mode = modeEl ? modeEl.value : 'fixed';
        if (!preview) return;
        if (mode !== 'by_weight') {
            preview.textContent = '';
            preview.style.display = 'none';
            return;
        }
        var metalEl = document.getElementById('p-metal-type');
        var karatEl = document.getElementById('p-karat');
        var weightEl = document.getElementById('p-weight-grams');
        var makingEl = document.getElementById('p-making-charge');
        var price = computeJewelryUnitPrice({
            metal_type: metalEl ? metalEl.value : '',
            karat: karatEl ? karatEl.value : '',
            weight_grams: weightEl ? weightEl.value : 0,
            making_charge: makingEl ? makingEl.value : 0
        });
        var rate = getRatePerGram(metalEl ? metalEl.value : '', karatEl ? karatEl.value : '');
        var fmt = (typeof global.formatCurrency === 'function') ? global.formatCurrency(price) : String(price);
        var rateFmt = (typeof global.formatCurrency === 'function') ? global.formatCurrency(rate) : String(rate);
        preview.style.display = 'block';
        preview.innerHTML = '<i class="fas fa-calculator"></i> نرخێ حیسابکڕی: <strong>' + fmt + '</strong>'
            + ' <span style="opacity:0.75;">(گرام: ' + rateFmt + ')</span>';
        var priceEl = document.getElementById('p-price');
        if (priceEl && price > 0) {
            priceEl.value = (typeof productFormFormatDerivedField === 'function')
                ? productFormFormatDerivedField(price)
                : String(Math.round(price));
        }
        var jPrice = document.getElementById('p-jewelry-price');
        if (jPrice && price > 0) {
            jPrice.value = (typeof productFormFormatDerivedField === 'function')
                ? productFormFormatDerivedField(price)
                : String(Math.round(price));
        }
        syncJewelrySimpleMoneyUi();
    }

    function syncJewelryFormMetalUi() {
        var metalEl = document.getElementById('p-metal-type');
        var karatWrap = document.getElementById('p-karat-wrap');
        var modeEl = document.getElementById('p-jewelry-price-mode');
        var metal = metalEl ? normalizeMetalType(metalEl.value) : '';
        var labelText = document.getElementById('p-karat-label-text');
        var addBtn = document.getElementById('p-silver-grade-add-btn');
        if (karatWrap) karatWrap.style.display = (metal === 'gold' || metal === 'silver') ? '' : 'none';
        if (labelText) labelText.textContent = (metal === 'silver') ? 'دەرجە' : 'عیار';
        if (addBtn) addBtn.style.display = (metal === 'silver') ? '' : 'none';
        if (metal === 'gold' || metal === 'silver') {
            fillKaratSelectOptions(metal);
        }
        // Silver/gold pieces: default to daily gram pricing
        if (metal && modeEl && !modeEl.dataset.userPicked) {
            modeEl.value = 'by_weight';
        }
        syncJewelryFormPreview();
        syncJewelrySimpleMoneyUi();
        syncJewelrySetPricingFromGrams();
    }

    function applyJewelryUnitLabels() {
        var pieceTitle = (typeof global.getDefaultUnitLabel === 'function') ? global.getDefaultUnitLabel('piece') : 'تاک';
        var packTitle = (typeof global.getDefaultUnitLabel === 'function') ? global.getDefaultUnitLabel('pack') : 'پاکێت';
        var cartonIds = ['btn-pos-unit-carton', 'btn-pos-expand-unit-carton', 'btn-returns-unit-carton', 'btn-purchase-unit-carton', 'btn-purchase-returns-unit-carton'];
        var packBtnIds = ['btn-pos-unit-pack', 'btn-pos-expand-unit-pack', 'btn-returns-unit-pack', 'btn-purchase-unit-pack', 'btn-purchase-returns-unit-pack'];
        var pieceBtnIds = ['btn-pos-unit-piece', 'btn-pos-expand-unit-piece'];

        if (!isJewelryMode()) {
            // Restore market / mobile / other modes — do not leave jewelry UI behind
            cartonIds.forEach(function (id) {
                var el = document.getElementById(id);
                if (el) el.style.display = '';
            });
            pieceBtnIds.forEach(function (id) {
                var el = document.getElementById(id);
                if (!el) return;
                el.setAttribute('title', pieceTitle);
                el.setAttribute('aria-label', pieceTitle);
            });
            packBtnIds.forEach(function (id) {
                var el = document.getElementById(id);
                if (!el) return;
                el.setAttribute('title', packTitle);
                el.setAttribute('aria-label', packTitle);
                var icon = el.querySelector('i.fas');
                if (icon) icon.className = 'fas fa-boxes';
            });
            var packToggleLabel = document.querySelector('.p-unit-toggle-pack');
            if (packToggleLabel) {
                var span = packToggleLabel.querySelector('span');
                if (span) span.textContent = (typeof global.t === 'function') ? global.t('product_form_pack_label') : 'پاکێت';
                var ic = packToggleLabel.querySelector('i.fas');
                if (ic) ic.className = 'fas fa-boxes';
            }
            var rowPackSpan = document.querySelector('#p-ml-row-pack td span[data-i18n="product_form_pack_label"]');
            if (rowPackSpan) rowPackSpan.textContent = (typeof global.t === 'function') ? global.t('product_form_pack_label') : 'پاکێت';
            var convPpp = document.querySelector('#label-pieces-per-pack span[data-i18n="product_form_conv_ppp"]');
            if (convPpp) convPpp.textContent = (typeof global.t === 'function') ? global.t('product_form_conv_ppp') : 'دانە ل پاکێتی دا';
            var namePiece = document.getElementById('p-unit-name-piece');
            var namePack = document.getElementById('p-unit-name-pack');
            if (namePiece) namePiece.placeholder = (typeof global.t === 'function') ? global.t('product_form_unit_placeholder_piece') : 'ناڤێ یەکە';
            if (namePack) namePack.placeholder = (typeof global.t === 'function') ? global.t('product_form_unit_placeholder_pack') : 'ناڤێ یەکە';
            return;
        }

        var map = [
            { sel: '.p-unit-toggle-pack span[data-i18n="product_form_pack_label"]', text: 'سێت' },
            { sel: '#p-ml-row-pack td span[data-i18n="product_form_pack_label"]', text: 'سێت' },
            { sel: '#label-pieces-per-pack span[data-i18n="product_form_conv_ppp"]', text: 'دانە ل سێتی دا' }
        ];
        map.forEach(function (m) {
            try {
                document.querySelectorAll(m.sel).forEach(function (el) {
                    if (m.text) el.textContent = m.text;
                });
            } catch (e) {}
        });
        var titleMap = {
            'btn-pos-unit-piece': 'دانە',
            'btn-pos-expand-unit-piece': 'دانە',
            'btn-pos-unit-pack': 'سێت',
            'btn-pos-expand-unit-pack': 'سێت',
            'btn-returns-unit-pack': 'سێت',
            'btn-purchase-unit-pack': 'سێت',
            'btn-purchase-returns-unit-pack': 'سێت'
        };
        Object.keys(titleMap).forEach(function (id) {
            var el = document.getElementById(id);
            if (!el) return;
            el.setAttribute('title', titleMap[id]);
            el.setAttribute('aria-label', titleMap[id]);
            if (id.indexOf('pack') >= 0) {
                var icon = el.querySelector('i.fas');
                if (icon) icon.className = 'fas fa-layer-group';
            }
        });
        cartonIds.forEach(function (id) {
            var el = document.getElementById(id);
            if (el) el.style.display = 'none';
        });
        var namePieceJ = document.getElementById('p-unit-name-piece');
        var namePackJ = document.getElementById('p-unit-name-pack');
        if (namePieceJ && !String(namePieceJ.value || '').trim()) namePieceJ.placeholder = 'دانە';
        if (namePackJ && !String(namePackJ.value || '').trim()) namePackJ.placeholder = 'سێت';
        var packToggleLabelJ = document.querySelector('.p-unit-toggle-pack');
        if (packToggleLabelJ) {
            var spanJ = packToggleLabelJ.querySelector('span');
            if (spanJ) spanJ.textContent = 'سێت';
            var icJ = packToggleLabelJ.querySelector('i.fas');
            if (icJ) icJ.className = 'fas fa-layer-group';
        }
    }

    function escapeJewelryHtml(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function isJewelrySetProduct(prod) {
        if (!prod) return false;
        if (prod.is_jewelry_set === true || prod.is_jewelry_set === 1 || prod.is_jewelry_set === '1') return true;
        return Array.isArray(prod.jewelry_set_items) && prod.jewelry_set_items.length > 0;
    }

    function getJewelrySetMembers(prod) {
        if (!prod) return [];
        return Array.isArray(prod.jewelry_set_items) ? prod.jewelry_set_items : [];
    }

    function jewelrySetAvailableCompleteSets(prod) {
        var members = getJewelrySetMembers(prod);
        if (!members.length || !global.db || !Array.isArray(global.db.products)) return 0;
        var minSets = Infinity;
        var trackedAny = false;
        members.forEach(function (m) {
            var mid = m.product_id != null ? m.product_id : m.id;
            var need = Math.max(0.001, parseFloat(m.qty) || 1);
            var mp = global.db.products.find(function (p) { return String(p.id) === String(mid); });
            if (!mp) {
                minSets = 0;
                return;
            }
            // Jewelry set members must count toward stock (even if trackStock was left off)
            trackedAny = true;
            var have = typeof global.getPosAvailablePieces === 'function'
                ? global.getPosAvailablePieces(mp)
                : (parseFloat(mp.qty) || 0);
            if (!(have >= 0) || isNaN(have)) have = 0;
            var can = Math.floor((Number(have) + 0.000001) / need);
            if (can < minSets) minSets = can;
        });
        if (!trackedAny) return 0;
        return minSets === Infinity ? 0 : Math.max(0, minSets);
    }

    /** Jewelry shop: always enforce warehouse qty (no unlimited ∞ sales). */
    function jewelryEnforcesStock(prod) {
        if (!isJewelryMode() || !prod) return false;
        return true;
    }

    function addJewelrySetMemberRow(data) {
        data = data || {};
        var body = document.getElementById('p-jewelry-set-members-body');
        if (!body) return;
        var label = data.label || 'پارچە';
        var name = data.name || '';
        var barcode = data.barcode || '';
        // Earrings (گووهار) default as a pair in one row
        var defaultQty = /گووه?ار|earring/i.test(String(label)) ? 2 : 1;
        var qty = (data.qty != null && Number(data.qty) > 0) ? Number(data.qty) : defaultQty;
        var weight = (data.weight_grams != null && Number(data.weight_grams) > 0) ? Number(data.weight_grams) : '';
        var price = (data.price != null && Number(data.price) > 0) ? Math.round(Number(data.price)) : '';
        var cost = (data.cost != null && Number(data.cost) > 0) ? Math.round(Number(data.cost)) : '';
        var pid = data.product_id != null ? data.product_id : (data.id != null ? data.id : '');
        if (!name && label) name = label;

        var tr = document.createElement('tr');
        tr.className = 'jewelry-set-member-row';
        if (pid) tr.setAttribute('data-product-id', String(pid));
        tr.innerHTML =
            '<td><input type="text" class="input-std jem-label" value="' + escapeJewelryHtml(label) + '" style="min-width:70px;"></td>' +
            '<td><input type="text" class="input-std jem-name" value="' + escapeJewelryHtml(name) + '" style="min-width:110px;" placeholder="ناڤ"></td>' +
            '<td><input type="text" class="input-std jem-barcode" value="' + escapeJewelryHtml(barcode) + '" style="min-width:110px;" dir="ltr" placeholder="بارکۆد"></td>' +
            '<td><input type="number" class="input-std jem-qty" value="' + escapeJewelryHtml(String(qty)) + '" min="0.001" step="1" style="width:64px;" dir="ltr" title="چەند دانە لە سێتدا (گووهار=٢)"></td>' +
            '<td><input type="number" class="input-std jem-weight" value="' + escapeJewelryHtml(weight === '' ? '' : String(weight)) + '" min="0" step="0.001" style="width:80px;" dir="ltr" placeholder="g" title="کێشی ئەم ڕیزە (جووت پێکەوە)"></td>' +
            '<td><input type="number" class="input-std jem-price" value="' + escapeJewelryHtml(price === '' ? '' : String(price)) + '" min="0" step="1" style="width:90px;" dir="ltr" placeholder="نرخ" title="نرخی فرۆشتنی تاک"></td>' +
            '<td><button type="button" class="btn btn-sm btn-danger" title="سڕینەوە" onclick="this.closest(\'tr\').remove(); if(typeof syncJewelrySetPricingFromGrams===\'function\')syncJewelrySetPricingFromGrams();"><i class="fas fa-trash"></i></button></td>';
        if (cost !== '') tr.setAttribute('data-unit-cost', String(cost));
        body.appendChild(tr);
        var wEl = tr.querySelector('.jem-weight');
        var qEl = tr.querySelector('.jem-qty');
        var pEl = tr.querySelector('.jem-price');
        if (pEl && price !== '') pEl.dataset.userPicked = '1';
        function onMemChange() {
            if (typeof syncJewelrySetPricingFromGrams === 'function') syncJewelrySetPricingFromGrams();
        }
        if (wEl) wEl.addEventListener('input', onMemChange);
        if (qEl) qEl.addEventListener('input', onMemChange);
        if (pEl) {
            pEl.addEventListener('input', function () {
                pEl.dataset.userPicked = '1';
            });
        }
        syncJewelrySetPricingFromGrams();
    }

    /**
     * When set is on:
     * - Buy cost = grams × daily buy rate
     * - Set sell + unit sell auto from grams × daily sell rate + making
     * Parent weight synced from table (top weight field stays hidden).
     */
    function syncJewelrySetPricingFromGrams(opts) {
        opts = opts || {};
        if (!isJewelryMode()) return;
        var chk = document.getElementById('p-jewelry-sell-set');
        if (!chk || !chk.checked) return;
        var body = document.getElementById('p-jewelry-set-members-body');
        if (!body) return;
        var metalEl = document.getElementById('p-metal-type');
        var karatEl = document.getElementById('p-karat');
        var makingEl = document.getElementById('p-making-charge');
        var metal = normalizeMetalType(metalEl ? metalEl.value : '') || 'silver';
        var karat = karatEl ? karatEl.value : null;
        var buyRate = Number(getBuyRatePerGram(metal, karat)) || 0;
        var sellRate = Number(getRatePerGram(metal, karat)) || 0;
        var making = makingEl ? parseFloat(String(makingEl.value || '').replace(/,/g, '')) : 0;
        if (!isFinite(making) || making < 0) making = 0;

        var setPriceEl = document.getElementById('p-jewelry-set-price');
        var rows = [];
        var totalLineGrams = 0;
        body.querySelectorAll('tr.jewelry-set-member-row').forEach(function (tr) {
            var qty = Number(parseFloat((tr.querySelector('.jem-qty') || {}).value || '1'));
            var weight = Number(parseFloat((tr.querySelector('.jem-weight') || {}).value || '0'));
            if (!isFinite(qty) || qty <= 0) qty = 1;
            if (!isFinite(weight) || weight < 0) weight = 0;
            totalLineGrams = Number(totalLineGrams) + weight;
            rows.push({ tr: tr, qty: qty, weight: weight });
        });
        totalLineGrams = Math.round(Number(totalLineGrams) * 1000) / 1000;

        // Auto set sell = total grams × sell rate + making
        var setSellAuto = 0;
        if (totalLineGrams > 0 && sellRate > 0) {
            setSellAuto = totalLineGrams * sellRate + making;
            if (typeof global.roundMoney === 'function') setSellAuto = global.roundMoney(setSellAuto);
            else setSellAuto = Math.round(setSellAuto);
        }
        var setPrice = 0;
        if (setPriceEl) {
            if (opts.keepSetPrice || setPriceEl.dataset.userPicked === '1') {
                setPrice = parseFloat(String(setPriceEl.value || '').replace(/,/g, ''));
                if (!isFinite(setPrice) || setPrice < 0) setPrice = 0;
            } else if (setSellAuto > 0) {
                setPriceEl.value = String(Math.round(setSellAuto));
                setPrice = Math.round(setSellAuto);
            }
        }
        if (!(setPrice > 0) && setSellAuto > 0) setPrice = Math.round(setSellAuto);

        var totalBuy = 0;
        rows.forEach(function (r) {
            var lineBuy = (buyRate > 0 && r.weight > 0) ? (r.weight * buyRate) : 0;
            if (typeof global.roundMoney === 'function') lineBuy = global.roundMoney(lineBuy);
            else lineBuy = Math.round(lineBuy);
            totalBuy = Number(totalBuy) + Number(lineBuy);
            var unitCost = r.qty > 0 ? Math.round(lineBuy / r.qty) : Math.round(lineBuy);
            r.tr.setAttribute('data-unit-cost', String(unitCost));
            r.tr.setAttribute('data-line-cost', String(lineBuy));

            var priceEl = r.tr.querySelector('.jem-price');
            if (priceEl && priceEl.dataset.userPicked !== '1' && r.weight > 0 && totalLineGrams > 0) {
                var lineSell = 0;
                if (sellRate > 0) {
                    lineSell = r.weight * sellRate + making * (r.weight / totalLineGrams);
                } else if (setPrice > 0) {
                    lineSell = setPrice * (r.weight / totalLineGrams);
                }
                var unitSell = r.qty > 0 ? (lineSell / r.qty) : lineSell;
                priceEl.value = String(Math.max(0, Math.round(unitSell)));
            }
        });

        // Keep hidden parent weight in sync for save (field itself hidden in set mode)
        var weightEl = document.getElementById('p-weight-grams');
        if (weightEl) {
            weightEl.value = totalLineGrams > 0 ? String(totalLineGrams) : '';
        }
        var costStr = String(Math.max(0, Math.round(Number(totalBuy) || 0)));
        var pCost = document.getElementById('p-cost');
        var jCost = document.getElementById('p-jewelry-cost');
        if (pCost) pCost.value = costStr;
        if (jCost) jCost.value = costStr;
        var pPrice = document.getElementById('p-price');
        if (pPrice && setPrice > 0) pPrice.value = String(Math.round(setPrice));

        var hint = document.getElementById('p-jewelry-set-cost-hint');
        if (hint) {
            if (totalLineGrams > 0) {
                var parts = ['کێشی سێت: <strong>' + totalLineGrams + 'g</strong>'];
                if (buyRate > 0) parts.push('نرخی کڕین: <strong>' + costStr + '</strong>');
                if (sellRate > 0 && setPrice > 0) parts.push('نرخی سێت: <strong>' + Math.round(setPrice) + '</strong>');
                else if (!(buyRate > 0) && !(sellRate > 0)) {
                    parts.push('<span style="color:#f87171;">نرخی ڕۆژانە دابنێ (ئایکۆنی زیڤ/زێر)</span>');
                }
                hint.innerHTML = '<i class="fas fa-info-circle"></i> ' + parts.join(' · ');
            } else {
                hint.textContent = '';
            }
        }
        if (typeof global.syncCostFromLevel === 'function') {
            try { global.syncCostFromLevel(); } catch (e) {}
        }
    }

    function collectJewelrySetMembersFromForm() {
        var body = document.getElementById('p-jewelry-set-members-body');
        if (!body) return [];
        syncJewelrySetPricingFromGrams();
        var out = [];
        body.querySelectorAll('tr.jewelry-set-member-row').forEach(function (tr) {
            var label = (tr.querySelector('.jem-label') || {}).value || '';
            var name = (tr.querySelector('.jem-name') || {}).value || '';
            var barcode = (tr.querySelector('.jem-barcode') || {}).value || '';
            var qty = Number(parseFloat((tr.querySelector('.jem-qty') || {}).value || '1'));
            var weight = Number(parseFloat((tr.querySelector('.jem-weight') || {}).value || '0'));
            var price = Number(parseFloat((tr.querySelector('.jem-price') || {}).value || '0'));
            var unitCost = Number(parseFloat(tr.getAttribute('data-unit-cost') || '0'));
            var pidAttr = tr.getAttribute('data-product-id');
            var productId = pidAttr ? parseInt(pidAttr, 10) : 0;
            label = String(label).trim();
            name = String(name).trim();
            barcode = String(barcode).trim();
            if (!isFinite(qty) || qty <= 0) qty = 1;
            if (!isFinite(weight) || weight < 0) weight = 0;
            if (!isFinite(price) || price < 0) price = 0;
            if (!isFinite(unitCost) || unitCost < 0) unitCost = 0;
            if (!name && !barcode && !(productId > 0)) return;
            if (!name) name = label || 'پارچە';
            var unitWeight = qty > 0 ? (Math.round((weight / qty) * 1000) / 1000) : weight;
            out.push({
                product_id: productId > 0 ? productId : 0,
                label: label || 'پارچە',
                name: name,
                barcode: barcode,
                qty: qty,
                weight_grams: unitWeight,
                line_weight_grams: Math.round(weight * 1000) / 1000,
                price: Math.round(price),
                cost: Math.round(unitCost)
            });
        });
        return out;
    }

    function clearJewelrySetMemberRows() {
        var body = document.getElementById('p-jewelry-set-members-body');
        if (body) body.innerHTML = '';
    }

    function syncJewelrySetFormUi() {
        if (!isJewelryMode()) return;
        var chk = document.getElementById('p-jewelry-sell-set');
        var fields = document.getElementById('p-jewelry-set-fields');
        var on = !!(chk && chk.checked);
        if (fields) fields.style.display = on ? 'block' : 'none';

        // Set mode: grams only in the table — hide top weight field
        var weightWrap = document.getElementById('p-weight-grams-wrap');
        if (weightWrap) weightWrap.style.display = on ? 'none' : '';
        var modeWrap = document.getElementById('p-jewelry-price-mode');
        if (modeWrap && modeWrap.parentElement) {
            modeWrap.parentElement.style.display = on ? 'none' : '';
        }

        if (on) {
            var body = document.getElementById('p-jewelry-set-members-body');
            if (body && !body.querySelector('tr.jewelry-set-member-row')) {
                addJewelrySetMemberRow({ label: 'گووهار', name: 'گووهار', qty: 2 });
                addJewelrySetMemberRow({ label: 'رستە', name: 'رستە', qty: 1 });
            }
            var trackEl = document.getElementById('p-track');
            if (trackEl) trackEl.checked = false;
            if (typeof global.syncProductTrackStockToggleUI === 'function') {
                try { global.syncProductTrackStockToggleUI(); } catch (e) {}
            }
            syncJewelrySetPricingFromGrams();
        }
        syncJewelrySimpleMoneyUi();
        applyJewelryUnitLabels();
    }

    function fillJewelrySetFromProduct(p) {
        if (!isJewelryMode()) return;
        p = p || {};
        var chk = document.getElementById('p-jewelry-sell-set');
        var setPriceEl = document.getElementById('p-jewelry-set-price');
        var isSet = isJewelrySetProduct(p);
        if (chk) chk.checked = isSet;
        clearJewelrySetMemberRows();
        if (isSet) {
            var members = getJewelrySetMembers(p);
            if (members.length) {
                members.forEach(function (m) {
                    var qty = (m.qty != null && Number(m.qty) > 0) ? Number(m.qty) : 1;
                    var unitW = Number(m.weight_grams) || 0;
                    // Form shows line total grams (pair together)
                    var lineW = unitW > 0 ? Math.round(unitW * qty * 1000) / 1000 : 0;
                    addJewelrySetMemberRow({
                        product_id: m.product_id != null ? m.product_id : m.id,
                        label: m.label,
                        name: m.name,
                        barcode: m.barcode,
                        qty: qty,
                        weight_grams: lineW > 0 ? lineW : undefined,
                        price: m.price,
                        cost: m.cost
                    });
                });
            }
            if (setPriceEl) {
                setPriceEl.value = (p.price != null && Number(p.price) > 0) ? String(Math.round(Number(p.price))) : '';
                if (setPriceEl.value) setPriceEl.dataset.userPicked = '1';
                else delete setPriceEl.dataset.userPicked;
            }
        } else if (setPriceEl) {
            setPriceEl.value = '';
            delete setPriceEl.dataset.userPicked;
        }
        syncJewelrySetFormUi();
        syncJewelrySetPricingFromGrams();
    }

    function ensureJewelryTrackStockOn() {
        if (!isJewelryMode()) return;
        var setChk = document.getElementById('p-jewelry-sell-set');
        if (setChk && setChk.checked) return; // set SKU: stock on members
        var trackEl = document.getElementById('p-track');
        if (trackEl && !trackEl.checked) {
            trackEl.checked = true;
            if (typeof global.syncProductTrackStockToggleUI === 'function') {
                try { global.syncProductTrackStockToggleUI(); } catch (e) {}
            }
            if (typeof global.toggleStockInputs === 'function') {
                try { global.toggleStockInputs(); } catch (e) {}
            }
        }
    }

    function syncJewelryMoneyFromSimple(which) {
        if (!isJewelryMode()) return;
        var jCost = document.getElementById('p-jewelry-cost');
        var jPrice = document.getElementById('p-jewelry-price');
        var jStock = document.getElementById('p-jewelry-stock');
        var pCost = document.getElementById('p-cost');
        var pPrice = document.getElementById('p-price');
        var pStock = document.getElementById('p-stock-piece');
        if (which === 'cost' || !which) {
            if (jCost && pCost) pCost.value = jCost.value;
            if (typeof global.syncCostFromLevel === 'function') {
                try { global.syncCostFromLevel(); } catch (e) {}
            }
        }
        if (which === 'price' || !which) {
            if (jPrice && pPrice) pPrice.value = jPrice.value;
        }
        if (which === 'stock' || !which) {
            ensureJewelryTrackStockOn();
            if (jStock && pStock) pStock.value = jStock.value;
            if (typeof global.calcTotalStockFromTable === 'function') {
                try { global.calcTotalStockFromTable(); } catch (e) {}
            }
        }
    }

    /** Fill hidden p-cost from daily buy rate × grams (or 0) so save validation passes without a cost field. */
    function ensureJewelryCostBeforeSave() {
        if (!isJewelryMode()) return;
        // Piece table (watches): cost/price already on the unit table — do not overwrite
        if (isJewelryPieceEntryMode()) return;
        var setChk = document.getElementById('p-jewelry-sell-set');
        if (setChk && setChk.checked) {
            syncJewelrySetPricingFromGrams();
            return;
        }
        syncJewelryMoneyFromSimple();
        var fields = readJewelryFieldsFromForm();
        var buy = 0;
        if (fields.metal_type && fields.weight_grams > 0) {
            buy = computeJewelryBuyUnitPrice({
                metal_type: fields.metal_type,
                karat: fields.karat,
                weight_grams: fields.weight_grams
            });
        }
        var costStr = String(Math.max(0, Math.round(Number(buy) || 0)));
        var pCost = document.getElementById('p-cost');
        var jCost = document.getElementById('p-jewelry-cost');
        if (pCost) {
            var cur = String(pCost.value || '').replace(/,/g, '').trim();
            if (cur === '' || isNaN(parseFloat(cur)) || parseFloat(cur) < 0) {
                pCost.value = costStr;
            }
        }
        if (jCost) jCost.value = (pCost && pCost.value) ? pCost.value : costStr;
        // Ensure sell price is on hidden p-price (by_weight preview / simple field)
        var pPrice = document.getElementById('p-price');
        var jPrice = document.getElementById('p-jewelry-price');
        if (pPrice) {
            var pv = String(pPrice.value || '').replace(/,/g, '').trim();
            if (!(parseFloat(pv) > 0) && jPrice && parseFloat(String(jPrice.value || '').replace(/,/g, '')) > 0) {
                pPrice.value = jPrice.value;
            }
            if (!(parseFloat(String(pPrice.value || '').replace(/,/g, '')) > 0)
                && fields.jewelry_price_mode === 'by_weight' && fields.metal_type && fields.weight_grams > 0) {
                var sell = computeJewelryUnitPrice(fields);
                if (sell > 0) {
                    var sellStr = (typeof productFormFormatDerivedField === 'function')
                        ? productFormFormatDerivedField(sell)
                        : String(Math.round(sell));
                    pPrice.value = sellStr;
                    if (jPrice) jPrice.value = sellStr;
                }
            }
        }
        if (typeof global.syncCostFromLevel === 'function') {
            try { global.syncCostFromLevel(); } catch (e2) {}
        }
    }

    function syncJewelryMoneyToSimple() {
        if (!isJewelryMode()) return;
        var jCost = document.getElementById('p-jewelry-cost');
        var jPrice = document.getElementById('p-jewelry-price');
        var jStock = document.getElementById('p-jewelry-stock');
        var pCost = document.getElementById('p-cost');
        var pPrice = document.getElementById('p-price');
        var pStock = document.getElementById('p-stock-piece');
        if (jCost && pCost) jCost.value = pCost.value || '';
        if (jPrice && pPrice) jPrice.value = pPrice.value || '';
        if (jStock && pStock) jStock.value = pStock.value || '';
        syncJewelrySimpleMoneyUi();
    }

    function syncJewelrySimpleMoneyUi() {
        if (!isJewelryMode()) return;
        var modeEl = document.getElementById('p-jewelry-price-mode');
        var mode = modeEl ? modeEl.value : 'fixed';
        var sellWrap = document.getElementById('p-jewelry-sell-field-wrap');
        var hint = document.getElementById('p-jewelry-sell-hint');
        var jPrice = document.getElementById('p-jewelry-price');
        var setChk = document.getElementById('p-jewelry-sell-set');
        var isSet = !!(setChk && setChk.checked);
        var byWeight = mode === 'by_weight';

        if (sellWrap) sellWrap.style.opacity = (byWeight && !isSet) ? '0.7' : '1';
        if (hint) hint.style.display = (byWeight && !isSet) ? 'block' : 'none';
        if (jPrice) {
            jPrice.readOnly = !!(byWeight && !isSet);
            jPrice.placeholder = (byWeight && !isSet) ? 'خۆکار ژ گرام' : 'بهای فرۆشتن';
        }
        var money = document.getElementById('p-jewelry-simple-money');
        if (money) money.style.display = isSet ? 'none' : '';
    }

    function getJewelryEntryKind() {
        var el = document.getElementById('p-jewelry-entry-kind');
        var v = el ? String(el.value || '').toLowerCase() : 'metal';
        return v === 'piece' ? 'piece' : 'metal';
    }

    function isJewelryPieceEntryMode() {
        return isJewelryMode() && getJewelryEntryKind() === 'piece';
    }

    function setJewelryEntryKind(kind) {
        var el = document.getElementById('p-jewelry-entry-kind');
        if (!el) return;
        el.value = (kind === 'piece') ? 'piece' : 'metal';
    }

    function syncJewelryEntryKindUi() {
        if (!isJewelryMode()) return;
        var piece = isJewelryPieceEntryMode();
        var metalBox = document.getElementById('p-jewelry-metal-fields');
        if (metalBox) metalBox.style.display = piece ? 'none' : '';
        // Piece mode uses the unit/cost/sell/stock table
        applyJewelryProductFormSteps();
        if (typeof global.toggleStockInputs === 'function') {
            try { global.toggleStockInputs(); } catch (e) {}
        }
        if (piece) {
            ensureJewelryTrackStockOn();
            var stockSection = document.getElementById('stock-cost-section');
            if (stockSection) {
                stockSection.style.display = '';
                stockSection.classList.remove('no-stock-track');
            }
            // Hide pack/carton rows & takeaway for simple watches
            document.querySelectorAll('.p-unit-level-item--pack, .p-unit-level-item--carton').forEach(function (el) {
                el.style.display = 'none';
            });
            var showPack = document.getElementById('p-unit-show-pack');
            var showCarton = document.getElementById('p-unit-show-carton');
            if (showPack) showPack.value = '0';
            if (showCarton) showCarton.value = '0';
            if (typeof global.applyProductUnitLevelUI === 'function') {
                try { global.applyProductUnitLevelUI(); } catch (e2) {}
            }
            document.querySelectorAll('#stock-cost-section [data-layout-id="layout-optional-takeaway"]').forEach(function (el) {
                el.style.display = 'none';
            });
            var stockPreview = document.getElementById('p-total-stock-preview');
            if (stockPreview) stockPreview.style.display = '';
            var unitLevels = document.getElementById('layout-step1-unit-levels');
            if (unitLevels) unitLevels.style.display = 'none';
            var expiryBlock = document.getElementById('layout-optional-expiry');
            if (expiryBlock) expiryBlock.style.display = 'none';
        } else {
            syncJewelryFormMetalUi();
            syncJewelrySimpleMoneyUi();
        }
    }

    function applyJewelryProductFormSteps() {
        var slot = document.getElementById('jewelry-step2-deferred-slot');
        var moveMap = [
            { homeId: 'jewelry-step1-home-unit-levels', blockId: 'layout-step1-unit-levels' },
            { homeId: 'jewelry-step1-home-stock', blockId: 'stock-cost-section' },
            { homeId: 'jewelry-step1-home-expiry', blockId: 'layout-optional-expiry' }
        ];
        // Market-only blocks: pack/carton toggles — always hide in jewelry
        var alwaysHideInJewelry = [
            'layout-step1-unit-levels',
            'layout-optional-expiry',
            'p-requires-recipe-stock',
            'p-wholesale-wrapper',
            'jewelry-qty-mode-wrap',
            'btn-recipe'
        ];

        if (isJewelryMode()) {
            var pieceMode = isJewelryPieceEntryMode();
            moveMap.forEach(function (p) {
                var home = document.getElementById(p.homeId);
                var block = document.getElementById(p.blockId);
                if (home && block && block.parentElement !== home) home.appendChild(block);
            });
            if (slot) slot.style.display = 'none';

            alwaysHideInJewelry.forEach(function (id) {
                var el = document.getElementById(id);
                if (!el) return;
                if (id === 'p-requires-recipe-stock' && el.parentElement) {
                    el.parentElement.style.display = 'none';
                } else {
                    el.style.display = 'none';
                }
            });
            document.querySelectorAll('.p-unit-level-item--pack, .p-unit-level-item--carton').forEach(function (el) {
                el.style.display = 'none';
            });
            var showPack = document.getElementById('p-unit-show-pack');
            var showCarton = document.getElementById('p-unit-show-carton');
            if (showPack) showPack.value = '0';
            if (showCarton) showCarton.value = '0';
            if (typeof global.applyProductUnitLevelUI === 'function') {
                try { global.applyProductUnitLevelUI(); } catch (e) {}
            }

            var stockSection = document.getElementById('stock-cost-section');
            if (stockSection) {
                if (pieceMode) {
                    stockSection.style.display = '';
                    stockSection.classList.remove('no-stock-track');
                    document.querySelectorAll('#stock-cost-section [data-layout-id="layout-optional-takeaway"]').forEach(function (el) {
                        el.style.display = 'none';
                    });
                } else {
                    stockSection.style.display = 'none';
                }
            }
            alwaysHideInJewelry.forEach(function (id) {
                var el = document.getElementById(id);
                if (!el) return;
                if (id === 'p-requires-recipe-stock' && el.parentElement) {
                    el.parentElement.style.display = 'none';
                } else {
                    el.style.display = 'none';
                }
            });
            ensureJewelryTrackStockOn();
            if (!pieceMode) {
                syncJewelryMoneyToSimple();
                syncJewelrySimpleMoneyUi();
            }
            var metalBox = document.getElementById('p-jewelry-metal-fields');
            if (metalBox) metalBox.style.display = pieceMode ? 'none' : '';
        } else {
            moveMap.forEach(function (p) {
                var home = document.getElementById(p.homeId);
                var block = document.getElementById(p.blockId);
                if (home && block && block.parentElement !== home) home.appendChild(block);
                if (block) block.style.display = '';
            });
            if (slot) slot.style.display = 'none';
            alwaysHideInJewelry.forEach(function (id) {
                var el = document.getElementById(id);
                if (!el) return;
                if (id === 'p-requires-recipe-stock' && el.parentElement) {
                    el.parentElement.style.display = '';
                } else if (id === 'btn-recipe') {
                    // visibility controlled elsewhere by recipe feature
                } else {
                    el.style.display = '';
                }
            });
            document.querySelectorAll('.p-unit-level-item--pack, .p-unit-level-item--carton').forEach(function (el) {
                el.style.display = '';
            });
            document.querySelectorAll('#stock-cost-section [data-layout-id="layout-optional-takeaway"]').forEach(function (el) {
                el.style.display = '';
            });
            var qtyMode2 = document.getElementById('jewelry-qty-mode-wrap');
            if (qtyMode2) qtyMode2.style.display = '';
            var stockSection2 = document.getElementById('stock-cost-section');
            if (stockSection2) stockSection2.style.display = '';
            // Restore market/restaurant unit table behavior
            if (typeof global.toggleStockInputs === 'function') {
                try { global.toggleStockInputs(); } catch (eRest) {}
            }
            if (typeof global.applyProductUnitLevelUI === 'function') {
                try { global.applyProductUnitLevelUI(); } catch (eUi) {}
            }
        }
    }

    function repairJewelryCatalogInMemory() {
        if (!isJewelryMode() || !global.db || !Array.isArray(global.db.products)) return false;
        var changed = false;
        global.db.products.forEach(function (p) {
            if (!p) return;
            var w = Number(p.weight_grams) || 0;
            if (!(w > 0)) return;
            if (!normalizeMetalType(p.metal_type)) {
                p.metal_type = 'silver';
                changed = true;
            }
            if (normalizeJewelryPriceMode(p.jewelry_price_mode) !== 'by_weight') {
                p.jewelry_price_mode = 'by_weight';
                changed = true;
            }
            // Non-set jewelry must track stock — ∞ was allowing sales without warehouse qty
            if (!isJewelrySetProduct(p)) {
                if (!(p.trackStock === true || p.trackStock === 1 || p.trackStock === '1')) {
                    p.trackStock = true;
                    changed = true;
                }
            }
        });
        return changed;
    }

    function syncJewelryUiVisibility() {
        var show = isJewelryMode();
        document.querySelectorAll('.jewelry-only').forEach(function (el) {
            // deferred slot / modal visibility controlled separately
            if (el.id === 'jewelry-step2-deferred-slot') return;
            if (el.id === 'modal-jewelry-daily-rates') {
                if (!show) el.style.display = 'none';
                return;
            }
            el.style.display = show ? '' : 'none';
        });
        applyJewelryProductFormSteps();
        applyJewelryUnitLabels();
        if (show) {
            repairJewelryCatalogInMemory();
            syncJewelryFormMetalUi();
            fillJewelryRateInputs();
            syncJewelrySetFormUi();
            ensureJewelryTrackStockOn();
            syncJewelryMoneyToSimple();
            syncJewelryEntryKindUi();
            updateJewelryRatesChip();
            if (typeof global.renderPOSMenu === 'function') {
                try {
                    var qEl = document.getElementById('pos-barcode-input');
                    global.renderPOSMenu(qEl ? qEl.value : '', true);
                } catch (e) {}
            }
            if (typeof global.renderPurchaseProductGrid === 'function') {
                try { global.renderPurchaseProductGrid(); } catch (eP) {}
            }
        } else {
            updateJewelryRatesChip();
        }
    }

    function fillJewelryRateInputs() {
        var rates = getJewelryRates();
        var map = {
            'set-gold-rate-18': rates.gold18,
            'set-gold-rate-21': rates.gold21,
            'set-gold-rate-22': rates.gold22,
            'set-gold-rate-24': rates.gold24,
            'set-gold-buy-rate-18': rates.buyGold18,
            'set-gold-buy-rate-21': rates.buyGold21,
            'set-gold-buy-rate-22': rates.buyGold22,
            'set-gold-buy-rate-24': rates.buyGold24
        };
        Object.keys(map).forEach(function (id) {
            var el = document.getElementById(id);
            if (el) el.value = map[id] > 0 ? String(Math.round(map[id])) : '';
        });
        renderAllSilverGradeLists();
        updateJewelryRatesChip();
    }

    function readJewelryRatesFromForm() {
        function num(id) {
            var el = document.getElementById(id);
            var n = el ? parseFloat(String(el.value || '').replace(/,/g, '')) : 0;
            return (isFinite(n) && n > 0) ? Math.round(n) : 0;
        }
        var grades = readSilverGradesFromContainer('set-silver-grades-list');
        if (!grades || !grades.length) grades = getSilverGrades();
        var primary = grades.find(function (g) { return g.code === '925'; }) || grades[0] || { sell: 0, buy: 0 };
        return {
            goldRate18: num('set-gold-rate-18'),
            goldRate21: num('set-gold-rate-21'),
            goldRate22: num('set-gold-rate-22'),
            goldRate24: num('set-gold-rate-24'),
            silverRate: primary.sell || 0,
            goldBuyRate18: num('set-gold-buy-rate-18'),
            goldBuyRate21: num('set-gold-buy-rate-21'),
            goldBuyRate22: num('set-gold-buy-rate-22'),
            goldBuyRate24: num('set-gold-buy-rate-24'),
            silverBuyRate: primary.buy || 0,
            silverGrades: grades
        };
    }

    function openJewelryDailyRatesModal() {
        if (!isJewelryMode()) return;
        var rates = getJewelryRates();
        var map = {
            'pos-jew-rate-18': rates.gold18,
            'pos-jew-rate-21': rates.gold21,
            'pos-jew-rate-22': rates.gold22,
            'pos-jew-rate-24': rates.gold24,
            'pos-jew-buy-18': rates.buyGold18,
            'pos-jew-buy-21': rates.buyGold21,
            'pos-jew-buy-22': rates.buyGold22,
            'pos-jew-buy-24': rates.buyGold24
        };
        Object.keys(map).forEach(function (id) {
            var el = document.getElementById(id);
            if (el) el.value = map[id] > 0 ? String(Math.round(map[id])) : '';
        });
        renderAllSilverGradeLists();
        var modal = document.getElementById('modal-jewelry-daily-rates');
        if (modal) modal.style.display = 'flex';
        setTimeout(function () {
            var list = document.getElementById('pos-jew-silver-grades-list');
            var focusEl = list ? list.querySelector('[data-sg-buy]') : null;
            if (!focusEl) focusEl = document.getElementById('pos-jew-buy-21');
            if (focusEl) focusEl.focus();
        }, 50);
    }

    function closeJewelryDailyRatesModal() {
        var modal = document.getElementById('modal-jewelry-daily-rates');
        if (modal) modal.style.display = 'none';
    }

    function saveJewelryDailyRatesFromModal() {
        if (!isJewelryMode()) return;
        function num(id) {
            var el = document.getElementById(id);
            var n = el ? parseFloat(String(el.value || '').replace(/,/g, '')) : 0;
            return (isFinite(n) && n > 0) ? Math.round(n) : 0;
        }
        if (!global.db) return;
        if (!global.db.settings) global.db.settings = {};
        global.db.settings.goldRate18 = num('pos-jew-rate-18');
        global.db.settings.goldRate21 = num('pos-jew-rate-21');
        global.db.settings.goldRate22 = num('pos-jew-rate-22');
        global.db.settings.goldRate24 = num('pos-jew-rate-24');
        global.db.settings.goldBuyRate18 = num('pos-jew-buy-18');
        global.db.settings.goldBuyRate21 = num('pos-jew-buy-21');
        global.db.settings.goldBuyRate22 = num('pos-jew-buy-22');
        global.db.settings.goldBuyRate24 = num('pos-jew-buy-24');
        var grades = readSilverGradesFromContainer('pos-jew-silver-grades-list');
        if (grades && grades.length) setSilverGrades(grades);
        else setSilverGrades(getSilverGrades());
        fillJewelryRateInputs();
        syncJewelryFormPreview();
        refreshJewelryLivePricesFromRates();
        closeJewelryDailyRatesModal();
        if (typeof global.saveSettings === 'function') {
            global.saveSettings().then(function () {
                if (typeof global.showToast === 'function') {
                    global.showToast('✅ نرخی کڕین و فرۆشتن هاتە پاراستن');
                }
            }).catch(function () {});
        } else if (typeof global.showToast === 'function') {
            global.showToast('✅ نرخی ڕۆژانە هاتە نوێکرن');
        }
    }

    /** After daily rates change: refresh POS sell prices + purchase costs that use grams. */
    function refreshJewelryLivePricesFromRates() {
        if (!isJewelryMode()) return;
        repairJewelryCatalogInMemory();
        updateJewelryRatesChip();

        // POS basket: reprice by-weight lines from sell rate
        try {
            var table = (typeof global.findActivePosTable === 'function') ? global.findActivePosTable() : null;
            if (table && Array.isArray(table.items) && global.db && Array.isArray(global.db.products)) {
                table.items.forEach(function (item) {
                    if (!item) return;
                    var mode = normalizeJewelryPriceMode(item.jewelry_price_mode);
                    var metal = normalizeMetalType(item.metal_type || item.jewelry_metal);
                    var w = Number(item.jewelry_weight != null ? item.jewelry_weight : item.weight_grams) || 0;
                    if (mode !== 'by_weight' && !(metal && w > 0)) return;
                    if (!(w > 0)) return;
                    var prod = global.db.products.find(function (p) { return String(p.id) === String(item.id); });
                    if (!prod && !metal) return;
                    var src = prod || item;
                    if (prod && !isJewelryByWeightProduct(prod) && mode !== 'by_weight') return;
                    var price = computeProductJewelryPrice({
                        metal_type: metal || src.metal_type,
                        karat: item.karat != null ? item.karat : (item.jewelry_karat != null ? item.jewelry_karat : src.karat),
                        weight_grams: w,
                        making_charge: item.making_charge != null ? item.making_charge : (item.jewelry_making != null ? item.jewelry_making : src.making_charge)
                    }, w);
                    if (price > 0) {
                        item.price = price;
                        item.jewelry_rate = getRatePerGram(metal || src.metal_type, item.karat != null ? item.karat : src.karat);
                        item.jewelry_price_mode = 'by_weight';
                    }
                });
                if (typeof global.saveActivePosTabSnapshot === 'function') {
                    try { global.saveActivePosTabSnapshot(); } catch (eSnap) {}
                }
            }
        } catch (eCart) {}

        // Purchase basket: reprice jewelry lines from buy rate
        if (typeof global.refreshPurchaseJewelryCostsFromRates === 'function') {
            try { global.refreshPurchaseJewelryCostsFromRates(); } catch (ePur) {}
        }

        if (typeof global.renderPOSMenu === 'function') {
            try {
                var qEl = document.getElementById('pos-barcode-input');
                global.renderPOSMenu(qEl ? qEl.value : '', true);
            } catch (e) {}
        }
        if (typeof global.renderPurchaseProductGrid === 'function') {
            try { global.renderPurchaseProductGrid(); } catch (eP) {}
        }
        if (typeof global.renderBill === 'function') {
            try { global.renderBill(); } catch (e2) {}
        }
        if (typeof global.renderBillTotal === 'function') {
            try { global.renderBillTotal(); } catch (e2b) {}
        }
        if (typeof global.renderPurchaseCart === 'function') {
            try { global.renderPurchaseCart(); } catch (e3) {}
        }
    }

    function applyJewelryRateSettings(save) {
        if (!global.db) return;
        if (!global.db.settings) global.db.settings = {};
        var rates = readJewelryRatesFromForm();
        Object.keys(rates).forEach(function (k) {
            if (k === 'silverGrades') return;
            global.db.settings[k] = rates[k];
        });
        if (rates.silverGrades) setSilverGrades(rates.silverGrades);
        syncJewelryFormPreview();
        refreshJewelryLivePricesFromRates();
        if (save !== false && typeof global.saveSettings === 'function') {
            global.saveSettings().then(function () {
                if (typeof global.showToast === 'function') {
                    global.showToast('✅ نرخێن زێر و زیڤ هاتنە پاراستن');
                }
            }).catch(function () {});
        }
    }

    function readJewelryFieldsFromForm() {
        var metalEl = document.getElementById('p-metal-type');
        var karatEl = document.getElementById('p-karat');
        var weightEl = document.getElementById('p-weight-grams');
        var makingEl = document.getElementById('p-making-charge');
        var modeEl = document.getElementById('p-jewelry-price-mode');
        var metal = normalizeMetalType(metalEl ? metalEl.value : '');
        var mode = normalizeJewelryPriceMode(modeEl ? modeEl.value : 'fixed');
        if (!metal) mode = 'fixed';
        var karat = null;
        if (metal === 'gold') {
            karat = normalizeKarat(karatEl ? karatEl.value : '');
        } else if (metal === 'silver') {
            var code = normalizeSilverGradeCode(karatEl ? karatEl.value : '');
            var n = parseFloat(code);
            karat = (isFinite(n) && n > 0) ? n : null;
        }
        var weight = parseFloat(weightEl ? String(weightEl.value || '').replace(/,/g, '') : '');
        if (!isFinite(weight) || weight < 0) weight = 0;
        weight = Math.round(weight * 1000) / 1000;
        var making = parseFloat(makingEl ? String(makingEl.value || '').replace(/,/g, '') : '');
        if (!isFinite(making) || making < 0) making = 0;
        making = Math.round(making);
        return {
            metal_type: metal,
            karat: karat,
            weight_grams: weight,
            making_charge: making,
            jewelry_price_mode: mode
        };
    }

    function fillJewelryFieldsToForm(p) {
        p = p || {};
        if (!isJewelryMode()) {
            // Keep jewelry fields empty for market/mobile/etc. — do not touch pack/carton
            return;
        }
        var hasMetal = !!normalizeMetalType(p.metal_type);
        var hasWeight = (Number(p.weight_grams) || 0) > 0;
        setJewelryEntryKind((!hasMetal && !hasWeight) ? 'piece' : 'metal');
        var metalEl = document.getElementById('p-metal-type');
        var karatEl = document.getElementById('p-karat');
        var weightEl = document.getElementById('p-weight-grams');
        var makingEl = document.getElementById('p-making-charge');
        var modeEl = document.getElementById('p-jewelry-price-mode');
        var metal = hasMetal ? normalizeMetalType(p.metal_type) : 'silver';
        if (metalEl) metalEl.value = metal;
        fillKaratSelectOptions(metal, p.karat);
        if (weightEl) weightEl.value = hasWeight ? String(p.weight_grams) : '';
        if (makingEl) makingEl.value = (p.making_charge != null && Number(p.making_charge) > 0) ? String(Math.round(Number(p.making_charge))) : '';
        if (modeEl) {
            var loadedMode = normalizeJewelryPriceMode(p.jewelry_price_mode);
            if (hasMetal && hasWeight && loadedMode === 'fixed') {
                loadedMode = 'by_weight';
            }
            if (!hasMetal && !hasWeight) loadedMode = 'fixed';
            modeEl.value = loadedMode;
            modeEl.dataset.userPicked = '1';
        }
        syncJewelryEntryKindUi();
        syncJewelryFormMetalUi();
        // Re-apply preferred karat after sync rebuilds options
        if (karatEl && p.karat != null && p.karat !== '') {
            fillKaratSelectOptions(metal, p.karat);
        }
        fillJewelrySetFromProduct(p);
        setTimeout(function () { syncJewelryMoneyToSimple(); }, 0);
    }

    function clearJewelryFieldsForm() {
        if (!isJewelryMode()) return;
        setJewelryEntryKind('metal');
        var metalEl = document.getElementById('p-metal-type');
        var weightEl = document.getElementById('p-weight-grams');
        var makingEl = document.getElementById('p-making-charge');
        var modeEl = document.getElementById('p-jewelry-price-mode');
        if (metalEl) metalEl.value = 'silver';
        if (weightEl) weightEl.value = '';
        if (makingEl) makingEl.value = '';
        if (modeEl) {
            modeEl.value = 'by_weight';
            delete modeEl.dataset.userPicked;
        }
        fillKaratSelectOptions('silver');
        var chk = document.getElementById('p-jewelry-sell-set');
        if (chk) chk.checked = false;
        var setPriceEl = document.getElementById('p-jewelry-set-price');
        if (setPriceEl) {
            setPriceEl.value = '';
            delete setPriceEl.dataset.userPicked;
        }
        clearJewelrySetMemberRows();
        var jCost = document.getElementById('p-jewelry-cost');
        var jPrice = document.getElementById('p-jewelry-price');
        var jStock = document.getElementById('p-jewelry-stock');
        if (jCost) jCost.value = '';
        if (jPrice) jPrice.value = '';
        if (jStock) jStock.value = '';
        syncJewelryEntryKindUi();
        syncJewelrySetFormUi();
        syncJewelryFormPreview();
        syncJewelrySimpleMoneyUi();
    }

    function appendJewelryToFormData(formData) {
        // Other business modes: do not alter pack/carton/set; only clear jewelry attrs
        if (!isJewelryMode()) {
            formData.append('metal_type', '');
            formData.append('karat', '');
            formData.append('weight_grams', '0');
            formData.append('making_charge', '0');
            formData.append('jewelry_price_mode', 'fixed');
            formData.append('is_jewelry_set', '0');
            formData.append('jewelry_set_members', '[]');
            return null;
        }
        // Piece table mode (watches etc.): fixed sell price — no metal/grams
        if (isJewelryPieceEntryMode()) {
            formData.append('metal_type', '');
            formData.append('karat', '');
            formData.append('weight_grams', '0');
            formData.append('making_charge', '0');
            formData.append('jewelry_price_mode', 'fixed');
            formData.append('is_jewelry_set', '0');
            formData.append('jewelry_set_members', '[]');
            ensureJewelryTrackStockOn();
            formData.set('trackStock', '1');
            formData.set('unit_show_pack', '0');
            formData.set('unit_show_carton', '0');
            formData.set('pieces_per_pack', '1');
            formData.set('packs_per_carton', '1');
            return {
                metal_type: '',
                karat: null,
                weight_grams: 0,
                making_charge: 0,
                jewelry_price_mode: 'fixed',
                entry_kind: 'piece'
            };
        }
        var j = readJewelryFieldsFromForm();
        j.entry_kind = 'metal';
        // Grams without metal → default silver (jewelry shops)
        if (!j.metal_type && j.weight_grams > 0) {
            j.metal_type = 'silver';
            var metalElFix = document.getElementById('p-metal-type');
            if (metalElFix) metalElFix.value = 'silver';
        }
        // Metal + grams: default sell by today's rate (unless user explicitly chose fixed)
        if (j.metal_type && j.weight_grams > 0) {
            var modeElSave = document.getElementById('p-jewelry-price-mode');
            if (modeElSave && modeElSave.dataset.userPicked === '1' && modeElSave.value === 'fixed') {
                j.jewelry_price_mode = 'fixed';
            } else {
                j.jewelry_price_mode = 'by_weight';
            }
        }
        formData.append('metal_type', j.metal_type);
        formData.append('karat', j.karat != null ? String(j.karat) : '');
        formData.append('weight_grams', String(j.weight_grams || 0));
        formData.append('making_charge', String(j.making_charge || 0));
        formData.append('jewelry_price_mode', j.jewelry_price_mode);
        syncJewelryMoneyFromSimple();
        if (j.jewelry_price_mode === 'by_weight' && j.metal_type) {
            var computed = computeJewelryUnitPrice(j);
            if (computed > 0) formData.set('price', String(computed));
            var buyCost = computeJewelryBuyUnitPrice(j);
            if (buyCost > 0) formData.set('cost', String(buyCost));
        }
        var chk = document.getElementById('p-jewelry-sell-set');
        var isSet = !!(chk && chk.checked);
        formData.append('is_jewelry_set', isSet ? '1' : '0');
        if (isSet) {
            syncJewelrySetPricingFromGrams();
            var members = collectJewelrySetMembersFromForm();
            formData.append('jewelry_set_members', JSON.stringify(members));
            var setPriceEl = document.getElementById('p-jewelry-set-price');
            var setPriceRaw = setPriceEl ? String(setPriceEl.value || '').trim() : '';
            if (setPriceRaw !== '') {
                var setPrice = parseFloat(setPriceRaw.replace(/,/g, ''));
                if (isFinite(setPrice) && setPrice > 0) {
                    formData.set('price', String(Math.round(setPrice)));
                    formData.append('jewelry_set_price', String(Math.round(setPrice)));
                }
            }
            // Set buy cost + total grams from member lines
            var setCostEl = document.getElementById('p-cost');
            var setCost = setCostEl ? parseFloat(String(setCostEl.value || '').replace(/,/g, '')) : 0;
            if (isFinite(setCost) && setCost >= 0) {
                formData.set('cost', String(Math.round(setCost)));
            }
            var totalLineW = 0;
            members.forEach(function (m) {
                var lw = Number(m.line_weight_grams);
                if (!(lw > 0)) lw = (Number(m.weight_grams) || 0) * (Number(m.qty) || 1);
                totalLineW += lw;
            });
            if (totalLineW > 0) {
                formData.set('weight_grams', String(Math.round(totalLineW * 1000) / 1000));
            }
            formData.set('trackStock', '0');
            formData.set('unit_show_pack', '0');
            formData.set('unit_show_carton', '0');
            formData.set('pieces_per_pack', '1');
            formData.set('packs_per_carton', '1');
        } else {
            formData.append('jewelry_set_members', '[]');
            ensureJewelryTrackStockOn();
            formData.set('trackStock', '1');
            formData.set('unit_show_pack', '0');
            formData.set('unit_show_carton', '0');
            formData.set('pieces_per_pack', '1');
            formData.set('packs_per_carton', '1');
        }
        return j;
    }

    var _jewelryWeightModalCb = null;

    function openJewelryWeightModal(opts) {
        opts = opts || {};
        _jewelryWeightModalCb = (typeof opts.onDone === 'function') ? opts.onDone : null;
        var modal = document.getElementById('modal-jewelry-weight');
        var input = document.getElementById('jewelry-weight-modal-input');
        var metaEl = document.getElementById('jewelry-weight-modal-meta');
        var titleEl = document.getElementById('jewelry-weight-modal-title');
        if (titleEl) titleEl.innerHTML = '<i class="fas fa-weight-hanging"></i> ' + (opts.title || 'کێش (گرام)');
        if (metaEl) metaEl.textContent = opts.meta || '';
        if (input) {
            var def = opts.defaultWeight != null && opts.defaultWeight !== '' ? String(opts.defaultWeight) : '';
            input.value = def;
        }
        if (modal) modal.style.display = 'flex';
        setTimeout(function () {
            if (!input) return;
            input.focus();
            if (input.select) input.select();
        }, 40);
    }

    function closeJewelryWeightModal(ok) {
        var modal = document.getElementById('modal-jewelry-weight');
        var input = document.getElementById('jewelry-weight-modal-input');
        var cb = _jewelryWeightModalCb;
        _jewelryWeightModalCb = null;
        if (modal) modal.style.display = 'none';
        if (!ok) {
            if (typeof cb === 'function') cb(null);
            return;
        }
        var raw = input ? String(input.value || '').trim() : '';
        var w = parseFloat(raw.replace(/,/g, ''));
        if (!isFinite(w) || w <= 0) {
            if (typeof global.showToast === 'function') global.showToast('کێشێ نادروست', 'error');
            if (typeof cb === 'function') cb(null);
            return;
        }
        w = Math.round(w * 1000) / 1000;
        if (typeof cb === 'function') cb(w);
    }

    function promptJewelryWeight(prod, done) {
        var def = (prod && prod.weight_grams != null && Number(prod.weight_grams) > 0)
            ? String(prod.weight_grams)
            : '';
        var meta = jewelryMetaLabel(prod);
        openJewelryWeightModal({
            title: 'کێش (گرام)',
            meta: meta || (prod && prod.name ? String(prod.name) : ''),
            defaultWeight: def,
            onDone: done
        });
    }

    function editCartJewelryWeight(id, note, currentPrice, saleUnit, currentWeight) {
        openJewelryWeightModal({
            title: 'گوهۆڕینا کێشێ',
            meta: 'کێشا نوێ بنڤیسە (گرام)',
            defaultWeight: currentWeight != null ? String(currentWeight) : '',
            onDone: function (w) {
                if (w == null) return;
                commitCartJewelryWeight(id, note, currentPrice, saleUnit, w);
            }
        });
    }

    function commitCartJewelryWeight(id, note, currentPrice, saleUnit, newWeight) {
        if (!global.db || !global.db.products) return;
        var table = (typeof global.findActivePosTable === 'function') ? global.findActivePosTable() : null;
        if (!table || !Array.isArray(table.items)) return;
        var w = parseFloat(newWeight);
        if (!isFinite(w) || w <= 0) return;
        w = Math.round(w * 1000) / 1000;
        var prod = global.db.products.find(function (p) { return String(p.id) === String(id); });
        if (!prod) return;
        var making = Number(prod.making_charge) || 0;
        var price = computeProductJewelryPrice(prod, w);
        note = note || '';
        saleUnit = saleUnit || 'piece';
        table.items.forEach(function (item) {
            if (String(item.id) !== String(id)) return;
            if ((item.note || '') !== note) return;
            if ((item.saleUnit || 'piece') !== saleUnit) return;
            if (Number(item.price) !== Number(currentPrice)) return;
            item.jewelry_weight = w;
            item.weight_grams = w;
            item.jewelry_making = making;
            item.making_charge = making;
            item.jewelry_metal = normalizeMetalType(prod.metal_type);
            item.metal_type = item.jewelry_metal;
            item.jewelry_karat = normalizeKarat(prod.karat);
            item.karat = item.jewelry_karat;
            item.jewelry_rate = getRatePerGram(prod.metal_type, prod.karat);
            item.price = price;
            item.jewelry_price_mode = 'by_weight';
        });
        if (typeof global.saveActivePosTabSnapshot === 'function') global.saveActivePosTabSnapshot();
        if (typeof global.renderBill === 'function') global.renderBill();
        if (typeof global.renderBillTotal === 'function') global.renderBillTotal();
    }

    global.KARAT_OPTIONS = KARAT_OPTIONS;
    global.isJewelryMode = isJewelryMode;
    global.normalizeMetalType = normalizeMetalType;
    global.normalizeKarat = normalizeKarat;
    global.normalizeJewelryPriceMode = normalizeJewelryPriceMode;
    global.isJewelryByWeightProduct = isJewelryByWeightProduct;
    global.effectiveJewelryMetal = effectiveJewelryMetal;
    global.repairJewelryCatalogInMemory = repairJewelryCatalogInMemory;
    global.getJewelryEntryKind = getJewelryEntryKind;
    global.isJewelryPieceEntryMode = isJewelryPieceEntryMode;
    global.setJewelryEntryKind = setJewelryEntryKind;
    global.syncJewelryEntryKindUi = syncJewelryEntryKindUi;
    global.getJewelryRates = getJewelryRates;
    global.getSilverGrades = getSilverGrades;
    global.setSilverGrades = setSilverGrades;
    global.promptAddSilverGrade = promptAddSilverGrade;
    global.removeSilverGrade = removeSilverGrade;
    global.getRatePerGram = getRatePerGram;
    global.getBuyRatePerGram = getBuyRatePerGram;
    global.updateJewelryRatesChip = updateJewelryRatesChip;
    global.refreshJewelryLivePricesFromRates = refreshJewelryLivePricesFromRates;
    global.computeJewelryUnitPrice = computeJewelryUnitPrice;
    global.computeProductJewelryPrice = computeProductJewelryPrice;
    global.computeProductJewelryBuyCost = computeProductJewelryBuyCost;
    global.computeJewelryBuyUnitPrice = computeJewelryBuyUnitPrice;
    global.jewelryMetaLabel = jewelryMetaLabel;
    global.syncJewelryFormPreview = syncJewelryFormPreview;
    global.syncJewelryFormMetalUi = syncJewelryFormMetalUi;
    global.syncJewelryUiVisibility = syncJewelryUiVisibility;
    global.applyJewelryProductFormSteps = applyJewelryProductFormSteps;
    global.syncJewelrySetFormUi = syncJewelrySetFormUi;
    global.applyJewelryUnitLabels = applyJewelryUnitLabels;
    global.fillJewelrySetFromProduct = fillJewelrySetFromProduct;
    global.addJewelrySetMemberRow = addJewelrySetMemberRow;
    global.collectJewelrySetMembersFromForm = collectJewelrySetMembersFromForm;
    global.clearJewelrySetMemberRows = clearJewelrySetMemberRows;
    global.syncJewelrySetPricingFromGrams = syncJewelrySetPricingFromGrams;
    global.isJewelrySetProduct = isJewelrySetProduct;
    global.getJewelrySetMembers = getJewelrySetMembers;
    global.jewelrySetAvailableCompleteSets = jewelrySetAvailableCompleteSets;
    global.jewelryEnforcesStock = jewelryEnforcesStock;
    global.syncJewelryMoneyFromSimple = syncJewelryMoneyFromSimple;
    global.syncJewelryMoneyToSimple = syncJewelryMoneyToSimple;
    global.syncJewelrySimpleMoneyUi = syncJewelrySimpleMoneyUi;
    global.ensureJewelryCostBeforeSave = ensureJewelryCostBeforeSave;
    global.ensureJewelryTrackStockOn = ensureJewelryTrackStockOn;
    global.fillJewelryRateInputs = fillJewelryRateInputs;
    global.applyJewelryRateSettings = applyJewelryRateSettings;
    global.openJewelryDailyRatesModal = openJewelryDailyRatesModal;
    global.closeJewelryDailyRatesModal = closeJewelryDailyRatesModal;
    global.saveJewelryDailyRatesFromModal = saveJewelryDailyRatesFromModal;
    global.readJewelryFieldsFromForm = readJewelryFieldsFromForm;
    global.fillJewelryFieldsToForm = fillJewelryFieldsToForm;
    global.clearJewelryFieldsForm = clearJewelryFieldsForm;
    global.appendJewelryToFormData = appendJewelryToFormData;
    global.promptJewelryWeight = promptJewelryWeight;
    global.openJewelryWeightModal = openJewelryWeightModal;
    global.closeJewelryWeightModal = closeJewelryWeightModal;
    global.editCartJewelryWeight = editCartJewelryWeight;
    global.commitCartJewelryWeight = commitCartJewelryWeight;
})(typeof window !== 'undefined' ? window : this);
