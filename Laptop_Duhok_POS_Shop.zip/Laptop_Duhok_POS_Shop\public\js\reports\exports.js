// POS reports - window exports, auto Telegram backup
        window.syncLiveData = syncLiveData;
        window.setPOSUnit = setPOSUnit;
        window.renderSalesHistory = renderSalesHistory;
        window.resetSalesHistoryDateFilter = resetSalesHistoryDateFilter;
        window.loadMoreSalesHistory = loadMoreSalesHistory;
        window.buildSalesHistoryQueryParams = buildSalesHistoryQueryParams;
        window.renderReturnsReport = renderReturnsReport;
        window.filterHistory = filterHistory;
        window.isDateInScope = isDateInScope;
        window.resetDateFilter = resetDateFilter;
        window.renderExpenses = renderExpenses;
        window.saveExpense = saveExpense;
        window.deleteExpense = deleteExpense;
        window.editExpense = editExpense;
        window.cancelExpenseEdit = cancelExpenseEdit;
        window.printExpenses = printExpenses;

        // --- Auto Telegram Backup every 3 hours ---
        setInterval(async () => {
            if (typeof db !== 'undefined' && db && db.settings && db.settings.tgToken && db.settings.tgChatId) {
                try {
                    const customMsg = '<b>📊 ڕاپۆرتا ئوتۆماتیکی (٣ دەمژمێر)</b>\n\n📌 ئاگەهداری: ئەڤە ڕاپۆرتا کورت یا ڕەوشا دکانێ یە بۆ ڤی دەمی.\n\n—\n\n' + generateBadiniReportText();
                    await sendFilesToTelegram(db.settings.tgToken, db.settings.tgChatId, true, customMsg, false);
                } catch(e) {
                    console.error('Failed to send auto backup to Telegram:', e);
                }
            }
        }, 3 * 60 * 60 * 1000); // 3 hours

        // --- نەهێلانا پرسیارا چاپکرنێ ل دەمێ زڤڕاندنا فرۆتنێ ---
        const originalConfirmPopup = window.confirm;
        window.confirm = function(msg) {
            if (typeof msg === 'string' && msg.indexOf('پسوولەیا زڤڕاندنێ چاپ کەی') !== -1) {
                return (typeof db !== 'undefined' && db && db.settings && db.settings.autoPrint) ? true : false;
            }
            return originalConfirmPopup(msg);
        };
