// inventory/stocktake.js — stocktake, overview, waste
        var stocktakeData = {};
        var stocktakeBoundWarehouseId = null;
        var stocktakeViewFilter = 'all';
        var stocktakeHistoryCache = [];
        function stocktakePeriodLabel(p) {
            if (p === 'monthly') return 'هەیڤانە';
            if (p === 'yearly') return 'ساڵانە';
            return 'جەردا ئێستا';
        }
        function stocktakeUnitCost(p) {
            if (!p) return 0;
            if (typeof getCatalogPieceCostIqd === 'function') return parseFloat(getCatalogPieceCostIqd(p)) || 0;
            return parseFloat(p.cost) || 0;
        }
        function stocktakeMoney(n) {
            return (typeof formatCurrency === 'function') ? formatCurrency(n || 0) : String(n || 0);
        }
        function computeStocktakeTotals() {
            var shortQty = 0, surplusQty = 0, shortVal = 0, surplusVal = 0, nShort = 0, nSurp = 0, nOk = 0;
            for (var pid in stocktakeData) {
                var d = stocktakeData[pid];
                if (!d) continue;
                var sys = parseFloat(d.system) || 0;
                var act = (d.actual !== undefined) ? (parseFloat(d.actual) || 0) : sys;
                var v = act - sys;
                var money = stocktakeUnitCost(d.productRef) * Math.abs(v);
                if (v < -0.0001) { shortQty += -v; shortVal += money; nShort++; }
                else if (v > 0.0001) { surplusQty += v; surplusVal += money; nSurp++; }
                else nOk++;
            }
            return { shortQty: shortQty, surplusQty: surplusQty, shortVal: shortVal, surplusVal: surplusVal, net: surplusVal - shortVal, nShort: nShort, nSurp: nSurp, nOk: nOk };
        }
        function paintStocktakeKpis() {
            var t = computeStocktakeTotals();
            var elS = document.getElementById('st-kpi-short-money');
            var elSm = document.getElementById('st-kpi-short-meta');
            var elU = document.getElementById('st-kpi-surplus-money');
            var elUm = document.getElementById('st-kpi-surplus-meta');
            var elN = document.getElementById('st-kpi-net-money');
            var elOk = document.getElementById('st-kpi-ok-meta');
            if (elS) elS.textContent = stocktakeMoney(t.shortVal);
            if (elSm) elSm.textContent = t.nShort + ' ئایتم کێم';
            if (elU) elU.textContent = stocktakeMoney(t.surplusVal);
            if (elUm) elUm.textContent = t.nSurp + ' ئایتم زێدە';
            if (elN) {
                elN.textContent = (t.net < 0 ? '−' : (t.net > 0 ? '+' : '')) + stocktakeMoney(Math.abs(t.net));
                elN.style.color = t.net < 0 ? 'var(--danger)' : (t.net > 0 ? 'var(--success)' : 'var(--brand)');
            }
            if (elOk) elOk.textContent = t.nOk + ' ئایتم ڕاست';
        }
        function setStocktakeViewFilter(f) {
            stocktakeViewFilter = f || 'all';
            ['all', 'short', 'surplus', 'diff'].forEach(function(k){
                var b = document.getElementById('st-view-' + k);
                if (b) b.classList.toggle('active', k === stocktakeViewFilter);
            });
            renderWarehouseStocktake();
        }
        function flushStocktakeVisibleInputs() {
            var tbody = document.getElementById('stocktake-tbody');
            if (!tbody) return;
            tbody.querySelectorAll('input[data-pid]').forEach(function(inp){
                var pid = parseInt(inp.getAttribute('data-pid'), 10);
                var r = stocktakeData[pid] || null;
                var v = normalizeQtyForProduct(r ? r.productRef : null, inp.value);
                if (!isNaN(v) && stocktakeData[pid]) {
                    stocktakeData[pid].actual = v;
                    stocktakeData[pid].variance = v - (stocktakeData[pid].system || 0);
                }
            });
        }
        function fillStocktakeCategoryFilter() {
            var sel = document.getElementById('stocktake-cat-filter');
            if (!sel || !db) return;
            var products = db.products || [];
            var cats = [...new Set((db.categories || []).concat(products.map(function(p){ return p.cat || p.category || ''; }).filter(Boolean)))].filter(Boolean).sort();
            var prev = sel.value;
            var allLab = (typeof t === 'function') ? t('wh_filter_all') : 'هەمی';
            sel.innerHTML = '<option value="">' + escapeHtml(allLab) + '</option>' + cats.map(function(c){
                return '<option value="' + escapeHtml(c) + '">' + escapeHtml(c) + '</option>';
            }).join('');
            if (prev) {
                for (var i = 0; i < sel.options.length; i++) {
                    if (sel.options[i].value === prev) { sel.value = prev; break; }
                }
            }
        }
        function getStocktakeTrackItems(whId) {
            return (db.products || []).filter(function(p){ return p.trackStock; }).map(function(p) {
                var q = getProductQtyForWarehouse(p, whId);
                return Object.assign({}, p, { qty: q, _warehouse_id: whId });
            });
        }
        function getStocktakeFilteredItems(items) {
            var catVal = (document.getElementById('stocktake-cat-filter') || {}).value || '';
            var searchEl = document.getElementById('stocktake-search');
            var qRaw = (searchEl && searchEl.value) ? String(searchEl.value).trim() : '';
            var list = items;
            if (catVal) {
                list = list.filter(function(p){ return (p.cat || p.category || '') === catVal; });
            }
            if (qRaw) {
                list = list.filter(function(p){
                    if (typeof window.productMatchesBarcodeOrNameSearch === 'function') {
                        return window.productMatchesBarcodeOrNameSearch(p, qRaw);
                    }
                    var q = qRaw.toLowerCase();
                    return (p.name && String(p.name).toLowerCase().indexOf(q) !== -1)
                        || (p.barcode && String(p.barcode).toLowerCase().indexOf(q) !== -1)
                        || (String(p.id).indexOf(q) !== -1);
                });
            }
            if (stocktakeViewFilter && stocktakeViewFilter !== 'all') {
                list = list.filter(function(p){
                    var d = stocktakeData[p.id];
                    var sys = d ? (parseFloat(d.system) || 0) : (parseFloat(p.qty) || 0);
                    var act = d && d.actual !== undefined ? (parseFloat(d.actual) || 0) : sys;
                    var v = act - sys;
                    if (stocktakeViewFilter === 'short') return v < -0.0001;
                    if (stocktakeViewFilter === 'surplus') return v > 0.0001;
                    if (stocktakeViewFilter === 'diff') return Math.abs(v) > 0.0001;
                    return true;
                });
            }
            return list;
        }
        function renderWarehouseStocktake(opts) {
            if(!db || !db.products) return;
            opts = opts || {};
            var tbody = document.getElementById('stocktake-tbody');
            if(!tbody) return;
            var needFill = opts.reset === true || stocktakeBoundWarehouseId === null;
            if (needFill && typeof fillWarehouseSelects === 'function') fillWarehouseSelects();
            var whId = parseInt((document.getElementById('stocktake-warehouse-select') || {}).value, 10) || getDefaultWarehouseId();
            var reset = opts.reset === true || stocktakeBoundWarehouseId !== whId;
            if (!reset) flushStocktakeVisibleInputs();
            if (reset) {
                stocktakeData = {};
                stocktakeBoundWarehouseId = whId;
                fillStocktakeCategoryFilter();
            }
            var items = getStocktakeTrackItems(whId);
            items.forEach(function(p){
                var prev = stocktakeData[p.id];
                var actual = (!reset && prev && prev.actual !== undefined) ? prev.actual : p.qty;
                stocktakeData[p.id] = { system: p.qty, actual: actual, name: p.name, productRef: p };
            });
            paintStocktakeKpis();
            if (opts.reset === true || !stocktakeHistoryCache.length) loadStocktakeHistory();
            var visible = getStocktakeFilteredItems(items);
            var countEl = document.getElementById('stocktake-visible-count');
            if (countEl) countEl.textContent = visible.length + ' / ' + items.length;
            if (!visible.length) {
                var emptyMsg = (typeof t === 'function') ? t('wh_table_empty') : 'هیچ ئایتمێک نەدۆزرایەوە';
                tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; color:var(--text-muted); padding:18px;">' + escapeHtml(emptyMsg) + '</td></tr>';
                return;
            }
            tbody.innerHTML = visible.map(function(p){
                var d = stocktakeData[p.id];
                var actual = (d && d.actual !== undefined) ? d.actual : (p.qty || 0);
                var variance = actual - (p.qty || 0);
                var qtyStep = isWeightProduct(p) ? '0.01' : '1';
                var varTxt = variance !== 0 ? ((variance > 0 ? '+' : '') + formatQtyForDisplay(variance, p)) : '0';
                var money = stocktakeUnitCost(p) * Math.abs(variance);
                var moneyTxt = variance === 0 ? '—' : ((variance < 0 ? '−' : '+') + stocktakeMoney(money));
                var varColor = variance < 0 ? 'var(--danger)' : (variance > 0 ? 'var(--success)' : 'var(--text-muted)');
                return '<tr><td>' + escapeHtml(p.name || 'ئایتم') + '</td><td><b>' + formatQtyForDisplay((p.qty || 0), p) + '</b></td><td><input type="number" min="0" step="' + qtyStep + '" class="input-std" style="width:80px; margin:0; padding:6px;" value="' + formatQtyForDisplay(actual, p) + '" data-pid="' + p.id + '" onchange="updateStocktakeActual(' + p.id + ', this.value)" oninput="updateStocktakeActual(' + p.id + ', this.value)"></td><td id="st-var-' + p.id + '" style="font-weight:800; color:' + varColor + ';">' + varTxt + '</td><td id="st-val-' + p.id + '" style="font-weight:700; color:' + varColor + ';">' + moneyTxt + '</td></tr>';
            }).join('');
        }
        function updateStocktakeActual(pid, val) {
            var row = stocktakeData[pid] || null;
            var v = normalizeQtyForProduct(row ? row.productRef : null, val);
            if(isNaN(v)) v = 0;
            if(stocktakeData[pid]) { stocktakeData[pid].actual = v; stocktakeData[pid].variance = v - (stocktakeData[pid].system || 0); }
            var varEl = document.getElementById('st-var-' + pid);
            var valEl = document.getElementById('st-val-' + pid);
            var variance = stocktakeData[pid] ? stocktakeData[pid].variance : 0;
            var varColor = variance < 0 ? 'var(--danger)' : (variance > 0 ? 'var(--success)' : 'var(--text-muted)');
            if(varEl && stocktakeData[pid]) {
                varEl.style.color = varColor;
                varEl.innerText = stocktakeData[pid].variance !== 0 ? (stocktakeData[pid].variance > 0 ? '+' : '') + formatQtyForDisplay(stocktakeData[pid].variance, row ? row.productRef : null) : '0';
            }
            if (valEl && stocktakeData[pid]) {
                var money = stocktakeUnitCost(row ? row.productRef : null) * Math.abs(variance);
                valEl.style.color = varColor;
                valEl.textContent = variance === 0 ? '—' : ((variance < 0 ? '−' : '+') + stocktakeMoney(money));
            }
            paintStocktakeKpis();
        }
        function loadStocktakeHistory() {
            var tbody = document.getElementById('stocktake-history-tbody');
            fetch('?action=get_stocktake_history&t=' + Date.now(), { credentials: 'same-origin' }).then(function(r){ return r.json(); }).then(function(data){
                if (!data || data.status !== 'ok') return;
                stocktakeHistoryCache = data.sessions || [];
                paintStocktakeHistory();
            }).catch(function(){});
        }
        function paintStocktakeHistory() {
            var tbody = document.getElementById('stocktake-history-tbody');
            var banner = document.getElementById('stocktake-last-banner');
            var loc = (typeof getDateLocale === 'function') ? getDateLocale() : 'ar-IQ';
            var list = stocktakeHistoryCache || [];
            if (banner) {
                if (list.length) {
                    var last = list[0];
                    var dStr = last.date ? (function(){ try { return new Date(last.date).toLocaleString(loc); } catch(e){ return String(last.date); } })() : '';
                    banner.style.display = 'block';
                    banner.innerHTML = '<strong>دوماهی جەرد:</strong> ' + escapeHtml(stocktakePeriodLabel(last.period))
                        + ' · ' + escapeHtml(dStr)
                        + ' · خسار <span style="color:var(--danger); font-weight:800;">' + escapeHtml(stocktakeMoney(last.short_value)) + '</span>'
                        + ' · زێدە <span style="color:var(--success); font-weight:800;">' + escapeHtml(stocktakeMoney(last.surplus_value)) + '</span>'
                        + ' · خالص <strong>' + escapeHtml(stocktakeMoney(last.net_value)) + '</strong>'
                        + (last.user ? (' · ' + escapeHtml(last.user)) : '');
                } else banner.style.display = 'none';
            }
            if (!tbody) return;
            if (!list.length) {
                tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; color:var(--text-muted);">هێشتا جەرد تۆمار نەبوویە</td></tr>';
                return;
            }
            tbody.innerHTML = list.map(function(s){
                var dStr = s.date ? (function(){ try { return new Date(s.date).toLocaleString(loc); } catch(e){ return String(s.date); } })() : '-';
                return '<tr style="cursor:pointer;" onclick="viewStocktakeSession(' + s.id + ')">'
                    + '<td>' + escapeHtml(dStr) + '</td>'
                    + '<td>' + escapeHtml(stocktakePeriodLabel(s.period)) + '</td>'
                    + '<td style="color:var(--danger); font-weight:700;">' + escapeHtml(stocktakeMoney(s.short_value)) + '</td>'
                    + '<td style="color:var(--success); font-weight:700;">' + escapeHtml(stocktakeMoney(s.surplus_value)) + '</td>'
                    + '<td style="font-weight:800;">' + escapeHtml(stocktakeMoney(s.net_value)) + '</td>'
                    + '<td>' + escapeHtml(s.user || '') + '</td></tr>';
            }).join('');
        }
        function viewStocktakeSession(id) {
            var box = document.getElementById('stocktake-history-detail');
            if (!box) return;
            box.style.display = 'block';
            box.innerHTML = '<p style="color:var(--text-muted);"><i class="fas fa-spinner fa-spin"></i> بارکردن...</p>';
            fetch('?action=get_stocktake_session&id=' + encodeURIComponent(id) + '&t=' + Date.now(), { credentials: 'same-origin' }).then(function(r){ return r.json(); }).then(function(data){
                if (!data || data.status !== 'ok' || !data.session) {
                    box.innerHTML = '<p style="color:var(--danger);">جەرد نەهاتیە دیتن</p>';
                    return;
                }
                var s = data.session;
                var lines = data.lines || [];
                var loc = (typeof getDateLocale === 'function') ? getDateLocale() : 'ar-IQ';
                var dStr = s.date ? (function(){ try { return new Date(s.date).toLocaleString(loc); } catch(e){ return String(s.date); } })() : '';
                var rows = lines.map(function(ln){
                    var v = parseFloat(ln.variance) || 0;
                    var col = v < 0 ? 'var(--danger)' : 'var(--success)';
                    var vTxt = (v > 0 ? '+' : '') + v;
                    return '<tr><td>' + escapeHtml(ln.product_name || '') + '</td><td>' + ln.system_qty + '</td><td>' + ln.actual_qty + '</td><td style="color:' + col + '; font-weight:800;">' + vTxt + '</td><td style="color:' + col + ';">' + (v < 0 ? '−' : '+') + stocktakeMoney(ln.value) + '</td></tr>';
                }).join('');
                box.innerHTML = '<div style="padding:12px; border-radius:10px; background:var(--bg-muted, rgba(0,0,0,0.04));">'
                    + '<div style="display:flex; justify-content:space-between; gap:8px;"><strong>' + escapeHtml(stocktakePeriodLabel(s.period)) + ' · ' + escapeHtml(dStr) + '</strong>'
                    + '<button type="button" class="btn btn-sm btn-outline" onclick="document.getElementById(\'stocktake-history-detail\').style.display=\'none\'">داخستن</button></div>'
                    + '<p style="margin:8px 0;">خسار ' + escapeHtml(stocktakeMoney(s.short_value)) + ' · زێدە ' + escapeHtml(stocktakeMoney(s.surplus_value)) + ' · خالص ' + escapeHtml(stocktakeMoney(s.net_value)) + '</p>'
                    + '<div style="max-height:240px; overflow:auto;"><table class="report-table"><thead><tr><th>ئایتم</th><th>سیستەم</th><th>دروست</th><th>جوداهی</th><th>پارە</th></tr></thead><tbody>'
                    + (rows || '<tr><td colspan="5">هیچ جوداهی</td></tr>') + '</tbody></table></div></div>';
            }).catch(function(){ box.innerHTML = '<p style="color:var(--danger);">هەڵە د بارکرنێ دا</p>'; });
        }
        function applyStocktake() {
            if(!db || !db.products) return;
            flushStocktakeVisibleInputs();
            var totals = computeStocktakeTotals();
            var items = [];
            for(var pid in stocktakeData) {
                var d = stocktakeData[pid];
                if(d.actual !== undefined && d.system !== d.actual) {
                    var p = db.products.find(function(x){ return x.id == pid; });
                    if(p && p.trackStock) items.push({ product_id: parseInt(pid, 10), actual_qty: Math.max(0, d.actual), system_qty: d.system || 0 });
                }
            }
            if(items.length === 0) { alert('چ گوهۆڕین نینن.'); return; }
            var periodEl = document.getElementById('stocktake-period');
            var period = periodEl ? periodEl.value : 'spot';
            var noteEl = document.getElementById('stocktake-note');
            var note = noteEl ? String(noteEl.value || '').trim() : '';
            var msg = 'ئەڤ جەردێ (' + stocktakePeriodLabel(period) + '):\n'
                + 'خسار: ' + stocktakeMoney(totals.shortVal) + ' (' + totals.nShort + ' ئایتم کێم)\n'
                + 'زێدە: ' + stocktakeMoney(totals.surplusVal) + ' (' + totals.nSurp + ' ئایتم زێدە)\n'
                + 'خالص: ' + stocktakeMoney(totals.net) + '\n\n'
                + 'دێ مەخزەنێ نویکەی؟';
            if (!confirm(msg)) return;
            var formData = new FormData();
            formData.append('action', 'apply_stocktake');
            formData.append('items', JSON.stringify(items));
            formData.append('user', (typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : 'System');
            formData.append('period', period);
            formData.append('note', note);
            formData.append('items_ok', String(totals.nOk));
            var stWh = document.getElementById('stocktake-warehouse-select');
            if (stWh && stWh.value) {
                formData.append('warehouse_id', stWh.value);
                if (typeof saveActiveWarehouseChoice === 'function') saveActiveWarehouseChoice('stocktake', stWh.value);
            }
            fetch('?action=apply_stocktake', { method: 'POST', credentials: 'same-origin', body: formData, headers: { 'X-Requested-With': 'XMLHttpRequest' } }).then(function(r){ return r.json(); }).then(function(data){
                if(data.status === 'ok' && data.updated > 0) {
                    items.forEach(function(it){
                        var p = db.products.find(function(x){ return x.id == it.product_id; });
                        if(p && p.trackStock) p.qty = it.actual_qty;
                    });
                    if(typeof syncLiveData === 'function') syncLiveData();
                    function done() {
                        renderWarehouseStocktake({ reset: true });
                        renderWarehouse('all');
                        if(typeof renderWmsMovements === 'function') renderWmsMovements();
                        if(typeof renderWmsReports === 'function') renderWmsReports();
                        try {
                            if (typeof window.scheduleFirebaseMobilePush === 'function') {
                                window.scheduleFirebaseMobilePush('stocktake', true);
                            }
                        } catch (e) {}
                        var doneMsg = 'مەخزەن هاتە نویکرن بۆ ' + data.updated + ' ئایتمان.\n'
                            + 'خسار: ' + stocktakeMoney(data.short_value) + '\n'
                            + 'زێدە: ' + stocktakeMoney(data.surplus_value) + '\n'
                            + 'خالص: ' + stocktakeMoney(data.net_value);
                        alert(doneMsg);
                    }
                    if(typeof connectToDB === 'function') connectToDB(true).then(done).catch(done);
                    else done();
                } else {
                    alert(data.message || 'هەڵە د نویکرنێ دا.');
                }
            }).catch(function(){ alert('هەڵە د پەیوەندیێ دا؛ دووبارە هەول بدە.'); });
        }
        function printStocktakeReport() {
            flushStocktakeVisibleInputs();
            var whId = parseInt((document.getElementById('stocktake-warehouse-select') || {}).value, 10) || getDefaultWarehouseId();
            var printItems = getStocktakeFilteredItems(getStocktakeTrackItems(whId));
            var totals = computeStocktakeTotals();
            var periodEl = document.getElementById('stocktake-period');
            var period = periodEl ? periodEl.value : 'spot';
            var rows = printItems.map(function(p){
                var d = stocktakeData[p.id] || { system: p.qty, actual: p.qty, name: p.name, productRef: p };
                var v = (d.actual !== undefined ? d.actual : d.system) - (d.system || 0);
                var refProd = d.productRef || p;
                var sysTxt = formatQtyForDisplay((d.system || 0), refProd);
                var actualTxt = formatQtyForDisplay((d.actual !== undefined ? d.actual : d.system), refProd);
                var varTxt = (v !== 0 ? (v > 0 ? '+' : '') + formatQtyForDisplay(v, refProd) : '0');
                var money = stocktakeUnitCost(refProd) * Math.abs(v);
                var moneyTxt = v === 0 ? '—' : ((v < 0 ? '−' : '+') + stocktakeMoney(money));
                return '<tr><td>' + escapeHtml(d.name || p.name || '') + '</td><td>' + sysTxt + '</td><td>' + actualTxt + '</td><td>' + varTxt + '</td><td>' + moneyTxt + '</td></tr>';
            });
            var summaryHtml = '<p><strong>' + escapeHtml(stocktakePeriodLabel(period)) + '</strong> · خسار: ' + escapeHtml(stocktakeMoney(totals.shortVal)) + ' · زێدە: ' + escapeHtml(stocktakeMoney(totals.surplusVal)) + ' · خالص: ' + escapeHtml(stocktakeMoney(totals.net)) + '</p>';
            var tableHtml = '<div class="section-title">ڕاپۆرتی جەرد (لیستا جەرد)</div>' + summaryHtml + '<table class="print-table" style="width:100%; border-collapse:collapse;"><thead><tr><th style="border:1px solid #ddd; padding:8px;">ئایتم</th><th>مەخزەنا سیستەم</th><th>ژمارا ڕاستەقینە</th><th>جیاوازی</th><th>پارە</th></tr></thead><tbody>' + rows.join('') + '</tbody></table>';
            var html = (typeof buildFlexibleReportPrintHtml === 'function')
                ? buildFlexibleReportPrintHtml('stocktake_report', 'ڕاپۆرتی جەردا مەخزەنێ (Inventory Audit)', new Date().toLocaleString('ar-IQ'), '', tableHtml)
                : (typeof buildReportHtml === 'function' ? buildReportHtml('ڕاپۆرتی جەردا مەخزەنێ (Inventory Audit)', new Date().toLocaleString('ar-IQ'), '', tableHtml) : tableHtml);
            try { routePrint('stocktake_report', html, { details: 'rows=' + rows.length }); } catch(e) { alert('هەڵە د چاپکرنێ دا. هیڤییە ڕێگە ب پۆپئەپ بدە یان پرێنتەری بپشکنە.'); }
        }
        window.setStocktakeViewFilter = setStocktakeViewFilter;
        window.viewStocktakeSession = viewStocktakeSession;
        window.updateStocktakeActual = updateStocktakeActual;
        window.applyStocktake = applyStocktake;
        window.renderWarehouseStocktake = renderWarehouseStocktake;

        function printStockMovementLog() {
            var movs = (wmsMovementsCache && wmsMovementsCache.length)
                ? wmsMovementsCache.slice()
                : ((db && db.warehouse_movements) ? db.warehouse_movements.slice(0, 500) : []);
            var typeLabels = wmsMovementTypeLabels || { purchase: 'کڕین', customer_return: 'زڤڕاندن کریار', sale: 'فرۆتن', supplier_return: 'زڤڕاندن دابینکەر', waste: 'تەلەف', stocktake: 'جەرد', adjustment: 'دەستکاری' };
            var rows = movs.map(function(m){
                var typ = typeLabels[m.movement_type] || m.movement_type;
                var qStr = (typeof formatWmsMovQty === 'function') ? formatWmsMovQty(m) : String(m.quantity || 0);
                return '<tr><td>' + (m.date ? new Date(m.date).toLocaleString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ') : '-') + '</td><td>' + escapeHtml(m.product_name || '') + '</td><td>' + typ + '</td><td>' + escapeHtml(m.company || '—') + '</td><td>' + qStr + '</td><td>' + escapeHtml((m.note || '') + ' ' + (m.user || '')) + '</td></tr>';
            }).join('');
            var tableHtml = '<table class="print-table" style="width:100%; border-collapse:collapse;"><thead><tr><th>بەروار</th><th>ئایتم</th><th>جۆرێ کردارێ</th><th>کۆمپانی</th><th>ژمارە</th><th>تێبینی</th></tr></thead><tbody>' + (rows || '<tr><td colspan="6" style="text-align:center;">هیچ لڤینێک نییە</td></tr>') + '</tbody></table>';
            var html = (typeof buildFlexibleReportPrintHtml === 'function')
                ? buildFlexibleReportPrintHtml('stock_movement_log', 'تۆمارا لڤینێن کۆگەهێ (سجل الحركات)', '', '', tableHtml)
                : tableHtml;
            try { routePrint('stock_movement_log', html, { details: 'rows=' + movs.length }); } catch(e) { alert('هەڵە د چاپکرنێ دا: ' + (e && e.message ? e.message : 'هیڤییە ڕێگە بە پۆپئەپ بدە.')); }
        }

        var WMS_PRINT_ZERO_KEY = 'pos_wms_print_zero_items';
        function isWmsPrintZeroItemsOn() {
            try {
                var v = localStorage.getItem(WMS_PRINT_ZERO_KEY);
                if (v === '0' || v === 'off' || v === 'false') return false;
            } catch (e) {}
            return true;
        }
        function setWmsPrintZeroItemsOn(on) {
            try { localStorage.setItem(WMS_PRINT_ZERO_KEY, on ? '1' : '0'); } catch (e) {}
        }
        function syncWmsPrintZeroToggleUi() {
            var btn = document.getElementById('wms-print-zero-toggle');
            if (!btn) return;
            var on = isWmsPrintZeroItemsOn();
            btn.classList.toggle('is-on', on);
            btn.setAttribute('aria-checked', on ? 'true' : 'false');
        }
        function toggleWmsPrintZeroItems() {
            setWmsPrintZeroItemsOn(!isWmsPrintZeroItemsOn());
            syncWmsPrintZeroToggleUi();
        }
        window.isWmsPrintZeroItemsOn = isWmsPrintZeroItemsOn;
        window.syncWmsPrintZeroToggleUi = syncWmsPrintZeroToggleUi;
        window.toggleWmsPrintZeroItems = toggleWmsPrintZeroItems;

        function printInventoryList() {
            // Print whatever the warehouse table currently shows (all / low / out / expired / in-stock + filters).
            var filter = (typeof currentWhFilter !== 'undefined' && currentWhFilter) ? String(currentWhFilter) : 'all';
            var list = Array.isArray(window._wmsSortedList)
                ? window._wmsSortedList.slice()
                : null;
            if (!list) {
                list = (db.products || []).filter(function(p){ return p.trackStock; });
                var catFilter = document.getElementById('wms-filter-cat');
                var mfrFilter = document.getElementById('wms-filter-manufacturer');
                var searchQ = document.getElementById('wh-search');
                if (catFilter && catFilter.value) list = list.filter(function(p){ return (p.cat || p.category || '') === catFilter.value; });
                if (mfrFilter && mfrFilter.value === '__none__') list = list.filter(function(p){ return !String(p.manufacturer || '').trim(); });
                else if (mfrFilter && mfrFilter.value) list = list.filter(function(p){ return String(p.manufacturer || '').trim() === mfrFilter.value; });
                if (searchQ && searchQ.value.trim()) {
                    var q = searchQ.value.trim().toLowerCase();
                    list = list.filter(function(p){
                        return (p.name && p.name.toLowerCase().indexOf(q) !== -1)
                            || (p.barcode && String(p.barcode).toLowerCase().indexOf(q) !== -1)
                            || (String(p.id).indexOf(q) !== -1);
                    });
                }
                if (filter === 'low') list = list.filter(function(p){ return (parseFloat(p.qty) || 0) > 0 && isLowStockByMin(p); });
                else if (filter === 'out') list = list.filter(function(p){ return typeof isWarehouseTrueStockout === 'function' ? isWarehouseTrueStockout(p) : ((parseFloat(p.qty) || 0) <= 0); });
                else if (filter === 'instock') list = list.filter(function(p){ return (parseFloat(p.qty) || 0) > 0; });
                else if (filter === 'expired') {
                    list = list.filter(function(p){
                        if (typeof productCatalogExpiryDaysLeft !== 'function') return false;
                        var days = productCatalogExpiryDaysLeft(p);
                        return days != null && days <= 60;
                    });
                }
            }
            var includeZero = isWmsPrintZeroItemsOn();
            var hidZero = false;
            if (!includeZero && filter !== 'out') {
                list = list.filter(function(p) {
                    if (!p || p.trackStock === false) return true;
                    var qty = (typeof getWarehouseProductQty === 'function') ? getWarehouseProductQty(p) : (parseFloat(p.qty) || 0);
                    return qty !== null && qty > 0;
                });
                hidZero = true;
            }
            var titleRaw = (window._wmsListTitle && String(window._wmsListTitle).trim())
                ? String(window._wmsListTitle).trim()
                : ((typeof t === 'function') ? t('wh_list_heading') : 'لیستا مەخزەن');
            var title = titleRaw.replace(/^[^\w\u0600-\u06FF#]+/, '').trim() || 'لیستا مەخزەن';
            var showAlertCols = (filter === 'low' || filter === 'out' || filter === 'expired');
            var showMfr = typeof isWarehouseManufacturerUiOn === 'function' ? isWarehouseManufacturerUiOn() : true;
            var mfrTh = (typeof t === 'function') ? t('wh_col_manufacturer') : 'کۆمپانیا دروستکەر';
            var catTh = (typeof t === 'function') ? (t('products_tbl_category') || t('product_form_label_category') || 'پۆل') : 'پۆل';
            if (catTh === 'products_tbl_category' || catTh === 'product_form_label_category') catTh = 'پۆل';
            var minTh = (typeof t === 'function') ? t('wh_col_min') : 'کەمترین';
            var statusTh = (typeof t === 'function') ? (t('wh_col_status') || t('th_status') || 'دۆخ') : 'دۆخ';
            var lbl = function(key, fb) { return (typeof t === 'function') ? t(key) : fb; };
            function printStatusText(p) {
                if (!p.trackStock) return lbl('wh_status_service', 'خزمەتگوزاری');
                if ((parseFloat(p.qty) || 0) <= 0) return lbl('wh_status_stockout', 'نەما');
                if (typeof isLowStockByMin === 'function' && isLowStockByMin(p)) return lbl('wh_status_low', 'کێمبووی');
                return lbl('wh_status_ok', 'باشە');
            }
            var colCount = (showAlertCols ? 10 : 8) + (showMfr ? 0 : -1);
            var rows = list.map(function(p){
                var _si = typeof getCatalogPieceSellIqd === 'function' ? getCatalogPieceSellIqd(p) : (p.price || 0);
                var _ci = typeof getCatalogPieceCostIqd === 'function' ? getCatalogPieceCostIqd(p) : (p.cost || 0);
                var _mfr = (p.manufacturer != null && String(p.manufacturer).trim()) ? String(p.manufacturer).trim() : '—';
                var _cat = String(p.cat || p.category || '').trim() || '—';
                var qtyCell = formatQtyForDisplay((p.qty || 0), p);
                var extra = showAlertCols
                    ? ('<td>' + getMinStock(p) + '</td><td>' + escapeHtml(printStatusText(p)) + '</td>')
                    : '';
                var mfrTd = showMfr ? ('<td>' + escapeHtml(_mfr) + '</td>') : '';
                return '<tr><td>' + (p.id || '') + '</td><td>' + escapeHtml(p.name || '') + '</td><td>' + escapeHtml(_cat) + '</td><td>' + escapeHtml(String(p.barcode || '—')) + '</td>' + mfrTd + '<td>' + qtyCell + '</td>' + extra + '<td>' + formatCurrency(_ci) + '</td><td>' + formatCurrency(_si) + '</td></tr>';
            }).join('');
            var headExtra = showAlertCols ? ('<th>' + escapeHtml(minTh) + '</th><th>' + escapeHtml(statusTh) + '</th>') : '';
            var mfrHead = showMfr ? ('<th>' + escapeHtml(mfrTh) + '</th>') : '';
            var tableHtml = '<table class="print-table" style="width:100%; border-collapse:collapse;"><thead><tr><th>SKU</th><th>ناڤ</th><th>' + escapeHtml(catTh) + '</th><th>بارکۆد</th>' + mfrHead + '<th>ژمارە</th>' + headExtra + '<th>کرین</th><th>نرخ</th></tr></thead><tbody>' + (rows || '<tr><td colspan="' + colCount + '" style="text-align:center;">هیچ ئایتمێک نییە</td></tr>') + '</tbody></table>';
            var subtitle = (typeof t === 'function' ? t('print_date') : 'بەروار') + ': ' + new Date().toLocaleDateString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ')
                + ' · ' + list.length + ' ' + ((typeof t === 'function') ? (t('comp_items_unit') || 'ئایتم') : 'ئایتم');
            if (hidZero) subtitle += ' · ' + lbl('wh_print_zero_hidden', 'بێ ئایتمێن سفر');
            var html = (typeof buildFlexibleReportPrintHtml === 'function')
                ? buildFlexibleReportPrintHtml('inventory_report', title, subtitle, '', tableHtml)
                : tableHtml;
            routePrint('inventory_report', html, { details: 'filter=' + filter + ';rows=' + list.length + ';zero=' + (includeZero ? 'on' : 'off') });
        }
        window.printInventoryList = printInventoryList;

        function printSuppliersList() {
            if(!db) return;
            var list = db.companies || [];
            var supplies = db.supplies || [];
            var rows = list.map(function(c){ var purchaseCount = supplies.filter(function(s){ return s.company === c.name; }).length; return '<tr><td>' + escapeHtml(c.name) + '</td><td>' + escapeHtml(c.phone || '-') + '</td><td>' + formatCurrency(c.balance || 0) + '</td><td>' + purchaseCount + '</td></tr>'; }).join('');
            var tableHtml = '<table class="print-table" style="width:100%; border-collapse:collapse;"><thead><tr><th>ناڤ</th><th>تەلەفۆن</th><th>قەرز</th><th>ژمارا کڕین</th></tr></thead><tbody>' + (rows || '<tr><td colspan="4" style="text-align:center;">هیچ دابینکەرێک نییە</td></tr>') + '</tbody></table>';
            var html = (typeof buildFlexibleReportPrintHtml === 'function')
                ? buildFlexibleReportPrintHtml('company_ledger', 'لیستا دابینکەران (Suppliers)', '', '', tableHtml)
                : tableHtml;
            routePrint('company_ledger', html, { details: 'rows=' + list.length });
        }

        window.printDeliveryList = function() {
            var list = (db.deliveries || []).slice().sort(function(a,b){ return new Date(b.date) - new Date(a.date); });
            var startEl = document.getElementById('date-start-delivery');
            var endEl = document.getElementById('date-end-delivery');
            if (startEl && startEl.value) list = list.filter(function(d){ return new Date(d.date) >= new Date(startEl.value); });
            if (endEl && endEl.value) list = list.filter(function(d){ return new Date(d.date) <= new Date(endEl.value + 'T23:59:59'); });
            var loc = typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ';
            var stOk = typeof t === 'function' ? t('del_print_status_delivered') : 'گەهێندراو';
            var stWait = typeof t === 'function' ? t('del_print_status_pending') : 'چاوەڕوان';
            var stRef = typeof t === 'function' ? t('del_status_refused') : 'رەفس';
            var stCan = typeof t === 'function' ? t('del_status_cancelled') : 'هەلوەشاندی';
            var thD = typeof t === 'function' ? t('del_th_date') : 'بەروار';
            var thC = typeof t === 'function' ? t('del_th_customer') : 'کڕیار';
            var thS = typeof t === 'function' ? t('del_th_status') : 'دۆخ';
            var thI = typeof t === 'function' ? t('del_th_items') : 'ژمارا ئایتم';
            var thT = typeof t === 'function' ? t('del_th_total') : 'کۆم';
            var title = typeof t === 'function' ? t('del_print_list_title') : 'لیستا گەهاندن';
            var empty = typeof t === 'function' ? t('del_print_empty') : 'هیچ گەهاندنێک نییە';
            var prDate = typeof t === 'function' ? t('print_date') : 'بەروار';
            var rows = list.slice(0, 300).map(function(d){
                var itemCount = (d.items && d.items.length) || 0;
                var dFx = (typeof fxUsdRateFormatOpts === 'function') ? fxUsdRateFormatOpts(d) : undefined;
                var st = d.status === 'delivered' ? stOk : (d.status === 'refused' ? stRef : (d.status === 'cancelled' ? stCan : stWait));
                return '<tr><td>' + new Date(d.date).toLocaleDateString(loc) + '</td><td>' + escapeHtml((typeof deliveryCustomerLabel === 'function' ? deliveryCustomerLabel(d) : (d.customer_name || 'بێ ناڤ'))) + '</td><td>' + escapeHtml(st) + '</td><td>' + itemCount + '</td><td>' + formatCurrency(d.total || 0, dFx) + '</td></tr>';
            }).join('');
            var tableHtml = '<table class="print-table" style="width:100%; border-collapse:collapse;"><thead><tr><th>' + escapeHtml(thD) + '</th><th>' + escapeHtml(thC) + '</th><th>' + escapeHtml(thS) + '</th><th>' + escapeHtml(thI) + '</th><th>' + escapeHtml(thT) + '</th></tr></thead><tbody>' + (rows || '<tr><td colspan="5" style="text-align:center;">' + escapeHtml(empty) + '</td></tr>') + '</tbody></table>';
            var html = (typeof buildFlexibleReportPrintHtml === 'function')
                ? buildFlexibleReportPrintHtml('delivery_slip', title, prDate + ': ' + new Date().toLocaleDateString(loc), '', tableHtml)
                : tableHtml;
            routePrint('delivery_slip', html, { details: 'rows=' + list.length });
        }

        /** Build standard report wrapper (header + body + footer) for consistent admin reports. */
        function buildReportHtml(title, subtitle, summaryBoxesHtml, tableHtml) {
            var logoHtml = (typeof getReceiptLogoHtml === 'function')
                ? getReceiptLogoHtml({ mode: 'a4' })
                : ((typeof getPosShopLogoUrl === 'function' && getPosShopLogoUrl()) ? '<img src="' + getPosShopLogoUrl() + '" style="max-height:80px; max-width:150px;" alt="">' : '');
            return '<div class="print-report-container">' +
                '<div class="print-header"><div><h2 style="margin:0;">' + (db.settings && db.settings.cafeName ? escapeHtml(db.settings.cafeName) : '') + '</h2><p style="margin:4px 0 0 0; color:#666;">' + (db.settings && db.settings.cafeInfo ? escapeHtml(db.settings.cafeInfo) : '') + '</p></div><div style="text-align:center;">' + logoHtml + '</div><div><h2 style="margin:0;">' + (title || '') + '</h2><p style="margin:4px 0 0 0;">' + (subtitle || new Date().toLocaleDateString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ')) + '</p></div></div>' +
                (summaryBoxesHtml ? '<div class="print-summary-box">' + summaryBoxesHtml + '</div>' : '') +
                (tableHtml || '') +
                '<div class="report-footer">' + window.posBrandWithVersion() + ' | ' + (title || 'Report') + '</div></div>';
        }


        function printWasteReport() {
            if (!db || !db.waste) return;
            var loc = typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ';
            var T = function(k, fb) { return (typeof t === 'function') ? t(k) : fb; };
            var startEl = document.getElementById('date-start-waste');
            var endEl = document.getElementById('date-end-waste');
            var list = db.waste.slice();
            if (startEl && startEl.value) list = list.filter(function(w){ return new Date(w.date) >= new Date(startEl.value); });
            if (endEl && endEl.value) list = list.filter(function(w){ return new Date(w.date) <= new Date(endEl.value + 'T23:59:59'); });
            var rows = list.slice(0, 500).map(function(w){ var prod = getProductByIdSafe(w.prodId); return '<tr><td>#' + escapeHtml(w.id != null ? w.id : '-') + '</td><td>' + escapeHtml(w.prodName || '-') + '</td><td>' + formatQtyForDisplay(w.qty || 0, prod) + ' ' + getProductUnitLabel(prod, 'piece') + '</td><td>' + ((typeof formatFrozenIqdAmount === 'function') ? formatFrozenIqdAmount(w, w.cost || 0) : formatCurrency(w.cost || 0)) + '</td><td>' + escapeHtml(w.reason || '-') + '</td><td>' + escapeHtml(w.user || '-') + '</td><td>' + new Date(w.date).toLocaleDateString(loc) + '</td></tr>'; }).join('');
            var totalCost = list.reduce(function(s, w){ return s + (parseFloat(w.cost) || 0); }, 0);
            var totalCostTxt = (typeof formatFrozenIqdRowsSum === 'function') ? formatFrozenIqdRowsSum(list, function(w) { return parseFloat(w.cost) || 0; }) : formatCurrency(totalCost);
            var summary = '<div class="p-box" style="border-color:#7f1d1d; background:#fef2f2;"><h3>' + escapeHtml(T('waste_print_sum_total', 'کۆیێ تەلەف')) + '</h3><h2 style="color:#7f1d1d;">' + totalCostTxt + '</h2></div><div class="p-box"><h3>' + escapeHtml(T('waste_print_sum_count', 'ژمارا تۆمار')) + '</h3><h2>' + list.length + '</h2></div>';
            var thId = T('waste_th_id', 'ID');
            var thI = T('waste_th_item', 'ئایتم');
            var thQ = T('waste_th_qty', 'ژمارە');
            var thC = T('waste_th_cost', 'کرین');
            var thR = T('waste_th_reason', 'ئەگەر');
            var thS = T('waste_th_staff', 'کارمەند');
            var thD = T('waste_th_date', 'بەروار');
            var sec = T('waste_print_table_heading', 'مێژوویا تەلەف');
            var emptyR = T('waste_print_empty', 'هیچ تەلەفێک نییە');
            var tableHtml = '<div class="section-title">' + escapeHtml(sec) + '</div><table class="print-table"><thead><tr><th>' + escapeHtml(thId) + '</th><th>' + escapeHtml(thI) + '</th><th>' + escapeHtml(thQ) + '</th><th>' + escapeHtml(thC) + '</th><th>' + escapeHtml(thR) + '</th><th>' + escapeHtml(thS) + '</th><th>' + escapeHtml(thD) + '</th></tr></thead><tbody>' + (rows || '<tr><td colspan="7" style="text-align:center;">' + escapeHtml(emptyR) + '</td></tr>') + '</tbody></table>';
            var prTitle = T('waste_print_title', 'ڕاپۆرتا تەلەف');
            var prDate = T('print_date', 'بەروار');
            var html = buildReportHtml(prTitle, prDate + ': ' + new Date().toLocaleDateString(loc), summary, tableHtml);
            routePrint('waste_report', html, { details: 'rows=' + list.length });
        }

        function printStockCardReport() {
            var tbody = document.getElementById('stock-card-tbody');
            var productName = document.getElementById('stock-card-product-name');
            if (!tbody || !productName || !productName.innerText) { showToast('ئایتمەکێ هەلبژێرە بۆ چاپکرنا کارتا ئایتمی', 'warning'); return; }
            var rows = [];
            tbody.querySelectorAll('tr').forEach(function(tr){
                var cells = tr.querySelectorAll('td');
                if (cells.length >= 4) rows.push('<tr><td>' + (cells[0] ? cells[0].innerText : '') + '</td><td>' + (cells[1] ? cells[1].innerText : '') + '</td><td>' + (cells[2] ? cells[2].innerText : '') + '</td><td>' + (cells[3] ? cells[3].innerText : '') + '</td><td>' + (cells[4] ? cells[4].innerText : '') + '</td><td>' + (cells[5] ? cells[5].innerText : '') + '</td></tr>');
            });
            var tableHtml = '<div class="section-title">مێژوویا لڤینان</div><table class="print-table"><thead><tr><th>بەروار</th><th>جۆر</th><th>ژمارە</th><th>کرین</th><th>پەیوەند</th><th>بەکارهێنەر</th></tr></thead><tbody>' + rows.join('') + '</tbody></table>';
            var html = buildReportHtml('کارتێ ئایتمی: ' + productName.innerText, 'Stock Card', '', tableHtml);
            routePrint('stock_card', html, { details: 'rows=' + rows.length });
        }

        function printCategoryReport() {
            var catFilter = document.getElementById('wh-cat-filter');
            var catValue = catFilter ? catFilter.value : '';
            var list = (db.products || []).filter(function(p){ return p.trackStock !== false; });
            if (catValue) list = list.filter(function(p){ return (p.cat || p.category || '') === catValue; });
            var rows = list.slice(0, 500).map(function(p){ return '<tr><td>' + escapeHtml(p.name || '') + '</td><td>' + escapeHtml(p.cat || p.category || '-') + '</td><td>' + formatQtyForDisplay(p.qty || 0, p) + ' ' + getProductUnitLabel(p, 'piece') + '</td><td>' + (p.minStock ? (p.qty <= p.minStock ? 'کەم' : 'نورمال') : '-') + '</td></tr>'; }).join('');
            var tableHtml = '<div class="section-title">لیستا کەرەستەیان ب پۆلی</div><table class="print-table"><thead><tr><th>کەرەستە</th><th>پۆل</th><th>ژمارە</th><th>دۆخ</th></tr></thead><tbody>' + (rows || '<tr><td colspan="4" style="text-align:center;">هیچ ئایتمێک نییە</td></tr>') + '</tbody></table>';
            var subtitle = catValue ? 'پۆل: ' + escapeHtml(catValue) + ' | بەروار: ' + new Date().toLocaleDateString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ') : 'بەروار: ' + new Date().toLocaleDateString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ');
            var html = buildReportHtml('ڕاپۆرتا پۆلێنکرن (Categories)', subtitle, '', tableHtml);
            routePrint('category_report', html, { details: 'rows=' + list.length });
        }

        function showItemReport(productId) {
            const p = db.products.find(x => String(x.id) === String(productId));
            if (!p) return;
            const pid = p.id;
            window._itemReportPid = pid;
            const contentDiv = document.getElementById('item-report-content');
            const modalEl = document.getElementById('item-report-modal');
            var wasClosed = !modalEl || modalEl.style.display !== 'flex';
            if (wasClosed) window._itemReportAllTime = false;
            var fromEl = document.getElementById('item-report-date-from');
            var toEl = document.getElementById('item-report-date-to');
            if (!window._itemReportAllTime) {
                if (typeof ensureDateInputsToday === 'function') {
                    ensureDateInputsToday('item-report-date-from', 'item-report-date-to');
                } else {
                    var todayIso = (typeof getBusinessDate === 'function') ? getBusinessDate(new Date()) : new Date().toISOString().slice(0, 10);
                    if (fromEl && !fromEl.value) fromEl.value = todayIso;
                    if (toEl && !toEl.value) toEl.value = todayIso;
                }
            }
            var rangeFrom = (fromEl && fromEl.value) ? fromEl.value : '';
            var rangeTo = (toEl && toEl.value) ? toEl.value : '';
            var rangeAll = !!window._itemReportAllTime || (!rangeFrom && !rangeTo);
            if (contentDiv) {
                contentDiv.innerHTML = '<div style="text-align:center;padding:28px;color:var(--text-muted);"><i class="fas fa-spinner fa-spin"></i> د بارکرنا مێژوویا کرینێ دایە...</div>';
            }
            if (modalEl) modalEl.style.display = 'flex';
            try {
                if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modalEl);
            } catch (_eI18n) {}

            function paintItemReport(supplyRows, salesRows, extraRows) {
            extraRows = extraRows || {};
            // --- Data Calculation ---
            const history = [];
            function itemReportDate(raw) {
                if (!raw) return new Date(NaN);
                if (raw instanceof Date) return raw;
                if (typeof parseSQLDate === 'function') return parseSQLDate(raw);
                return new Date(raw);
            }
            function itemReportIso(raw) {
                if (!raw) return '';
                try {
                    if (typeof getBusinessDate === 'function') {
                        var bd = getBusinessDate(raw);
                        if (bd && /^\d{4}-\d{2}-\d{2}$/.test(String(bd))) return String(bd);
                    }
                    var d = itemReportDate(raw);
                    if (isNaN(d.getTime())) {
                        var m = String(raw).match(/^(\d{4}-\d{2}-\d{2})/);
                        return m ? m[1] : '';
                    }
                    var pad = function (n) { return String(n).padStart(2, '0'); };
                    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
                } catch (_eIso) {
                    var m2 = String(raw).match(/^(\d{4}-\d{2}-\d{2})/);
                    return m2 ? m2[1] : String(raw).slice(0, 10);
                }
            }
            function inReportRange(raw) {
                if (rangeAll) return true;
                var iso = itemReportIso(raw);
                if (!iso) return false;
                if (rangeFrom && iso < rangeFrom) return false;
                if (rangeTo && iso > rangeTo) return false;
                return true;
            }
            function afterReportRange(raw) {
                if (rangeAll || !rangeTo) return false;
                var iso = itemReportIso(raw);
                return iso && iso > rangeTo;
            }
            var rangeToTs = 0;
            if (!rangeAll && rangeTo) {
                rangeToTs = new Date(rangeTo + 'T23:59:59').getTime() || 0;
            }
            const unitFactors = (typeof getProductUnitFactors === 'function') ? getProductUnitFactors(p) : { piecesPerPack: 1, piecesPerCarton: 1 };
            function piecesToUnitCounts(pieces) {
                const absPieces = Math.max(0, Math.floor(parseFloat(pieces) || 0));
                let carton = 0;
                let pack = 0;
                let piece = absPieces;
                if (unitFactors.piecesPerCarton && unitFactors.piecesPerCarton > 1) {
                    carton = Math.floor(piece / unitFactors.piecesPerCarton);
                    piece = piece - (carton * unitFactors.piecesPerCarton);
                }
                if (unitFactors.piecesPerPack && unitFactors.piecesPerPack > 1) {
                    pack = Math.floor(piece / unitFactors.piecesPerPack);
                    piece = piece - (pack * unitFactors.piecesPerPack);
                }
                return { carton, pack, piece };
            }

            function normalizeReportSaleItems(raw) {
                var items = raw;
                if (typeof items === 'string') {
                    try { items = JSON.parse(items); } catch (_e) { return []; }
                }
                if (!items) return [];
                if (Array.isArray(items)) return items;
                if (typeof items === 'object') {
                    return Object.keys(items).map(function(k) { return items[k]; }).filter(function(x) { return x && typeof x === 'object'; });
                }
                return [];
            }
            function saleLineMatchesProduct(item) {
                if (!item || typeof item !== 'object') return false;
                if (item.id != null && String(item.id) === String(pid)) return true;
                if (item.prodId != null && String(item.prodId) === String(pid)) return true;
                if (item.product_id != null && String(item.product_id) === String(pid)) return true;
                if (item.productId != null && String(item.productId) === String(pid)) return true;
                var pb = String(p.barcode || '').trim();
                var ib = String(item.barcode || '').trim();
                if (pb && ib && pb === ib) return true;
                return false;
            }
            function isSaleVoided(sale) {
                if (!sale) return true;
                if (Number(sale.is_returned) === 1) return true;
                if (sale.voided || sale.is_voided) return true;
                return false;
            }

            // Purchase batches for FIFO COGS (new buys must NOT rewrite past sales profit).
            var fifoBatches = [];
            let purchaseCostSum = 0;
            let purchaseQtySum = 0;
            (supplyRows || []).forEach(function (s) {
                if (!s || String(s.prodId) !== String(pid)) return;
                var typ = String(s.type || '').toLowerCase();
                if (typ === 'return' || typ === 'opening') return;
                var q = parseFloat(s.qtyAdded) || 0;
                if (q <= 0) return;
                var tc = parseFloat(s.totalCost) || 0;
                purchaseCostSum += tc;
                purchaseQtySum += q;
                fifoBatches.push({
                    rem: q,
                    unitCost: q > 0 ? (tc / q) : 0,
                    t: itemReportDate(s.date).getTime() || 0
                });
            });
            fifoBatches.sort(function (a, b) { return a.t - b.t; });
            var avgPurchasePieceCost = purchaseQtySum > 0 ? (purchaseCostSum / purchaseQtySum) : 0;
            var catalogPieceCost = (typeof getCatalogPieceCostIqd === 'function') ? getCatalogPieceCostIqd(p) : (parseFloat(p.cost) || 0);

            function consumeFifoPieces(pieces) {
                var left = Math.max(0, parseFloat(pieces) || 0);
                var cost = 0;
                var fromFifo = 0;
                while (left > 0.000001 && fifoBatches.length) {
                    var b = fifoBatches[0];
                    if (!b || b.rem <= 0.000001) {
                        fifoBatches.shift();
                        continue;
                    }
                    var take = Math.min(left, b.rem);
                    cost += take * (b.unitCost || 0);
                    b.rem -= take;
                    left -= take;
                    fromFifo += take;
                    if (b.rem <= 0.000001) fifoBatches.shift();
                }
                return { cost: cost, fromFifo: fromFifo, leftover: left };
            }

            // Timeline: purchases already queued; waste/sales consume in date order.
            var wasteRows = (Array.isArray(extraRows.waste) && extraRows.waste.length)
                ? extraRows.waste
                : ((db && db.waste) || []);
            var timeline = [];
            wasteRows.forEach(function (w) {
                if (String(w.prodId) !== String(pid)) return;
                var wq = Math.abs(parseFloat(w.qty) || 0);
                if (wq <= 0) return;
                timeline.push({
                    kind: 'waste',
                    t: itemReportDate(w.date).getTime() || 0,
                    pieces: wq,
                    inRange: inReportRange(w.date),
                    after: afterReportRange(w.date)
                });
            });
            
            let salesCount = 0;
            let giftSalesCount = 0;
            // Count sold quantity by unit type for this item (carton/pack/piece).
            // Each POS cart line corresponds to exactly 1 unit in `saleUnit`.
            let salesByUnit = { carton: 0, pack: 0, piece: 0 };
            let giftByUnit = { carton: 0, pack: 0, piece: 0 };
            let totalRevenue = 0;
            let totalGiftValue = 0;
            let totalCogs = 0;
            let soldPiecesForCogs = 0;
            var reconSaleRange = 0;
            var reconSaleAfter = 0;
            var localSales = (typeof getAllSales === 'function') ? getAllSales(true) : ((db && db.sales) || []);
            var allSales = (Array.isArray(salesRows) && salesRows.length) ? salesRows : localSales;
            // Merge local + server by id so newest local drafts are not lost
            if (Array.isArray(salesRows) && salesRows.length && Array.isArray(localSales) && localSales.length) {
                var byId = {};
                localSales.forEach(function(s) { if (s && s.id != null) byId[String(s.id)] = s; });
                salesRows.forEach(function(s) {
                    if (!s || s.id == null) return;
                    var k = String(s.id);
                    if (!byId[k]) byId[k] = s;
                    else {
                        var locItems = normalizeReportSaleItems(byId[k].items);
                        var srvItems = normalizeReportSaleItems(s.items);
                        if (srvItems.length && !locItems.length) byId[k] = s;
                        else if (srvItems.length >= locItems.length) byId[k] = s;
                    }
                });
                allSales = Object.keys(byId).map(function(k) { return byId[k]; });
            }
            allSales.forEach(function(sale) {
                if (isSaleVoided(sale)) return;
                var saleItems = normalizeReportSaleItems(sale.items);
                if (!saleItems.length) return;
                let itemInSaleCount = 0;
                let giftInSale = 0;
                var saleT = itemReportDate(sale.date || sale.created_at).getTime() || 0;
                var saleDateRaw = sale.date || sale.created_at;
                var saleInRange = inReportRange(saleDateRaw);
                var saleAfter = afterReportRange(saleDateRaw);
                saleItems.forEach(function(item) {
                    if (!saleLineMatchesProduct(item)) return;
                    var u = item.saleUnit || 'piece';
                    var lineQ = (typeof getItemQty === 'function')
                        ? getItemQty(item)
                        : (typeof getSaleLineQty === 'function' ? getSaleLineQty(item) : (parseFloat(item.qty != null ? item.qty : item.count) || 1));
                    var lineVal = (item.price || 0) * lineQ;
                    var pieceMult = (typeof getPiecesMultiplierForUnit === 'function')
                        ? (getPiecesMultiplierForUnit(p, u) || 1)
                        : 1;
                    var linePieces = lineQ * pieceMult;
                    var stamped = Number(item.cost);
                    if (saleAfter) reconSaleAfter += linePieces;
                    else if (saleInRange) reconSaleRange += linePieces;
                    if (saleInRange) {
                        salesCount++;
                        itemInSaleCount++;
                        if (u === 'carton') salesByUnit.carton += lineQ;
                        else if (u === 'pack') salesByUnit.pack += lineQ;
                        else salesByUnit.piece += lineQ;
                        if (item.isGift) {
                            giftSalesCount++;
                            giftInSale++;
                            totalGiftValue += lineVal;
                            if (u === 'carton') giftByUnit.carton += lineQ;
                            else if (u === 'pack') giftByUnit.pack += lineQ;
                            else giftByUnit.piece += lineQ;
                        } else {
                            totalRevenue += lineVal;
                        }
                    }
                    timeline.push({
                        kind: 'sale',
                        t: saleT,
                        pieces: linePieces,
                        lineQ: lineQ,
                        stamped: (Number.isFinite(stamped) && stamped > 0) ? stamped : 0,
                        saleId: sale.id,
                        giftBits: item.isGift ? 1 : 0,
                        inRange: saleInRange,
                        after: saleAfter
                    });
                });
                if(saleInRange && itemInSaleCount > 0) {
                    history.push({
                        type: giftInSale === itemInSaleCount ? 'sale_gift' : (giftInSale > 0 ? 'sale_gift_mixed' : 'sale'),
                        date: itemReportDate(sale.date || sale.created_at),
                        qty: itemInSaleCount,
                        info: `وەسڵ #${sale.id.toString().slice(-4)}` + (giftInSale > 0 ? ' · دیاری' : '')
                    });
                }
            });
            timeline.sort(function (a, b) {
                if (a.t !== b.t) return a.t - b.t;
                if (a.kind === b.kind) return 0;
                if (a.kind === 'waste') return -1;
                if (b.kind === 'waste') return 1;
                return 0;
            });
            // Re-seed FIFO in chronological lockstep with waste/sales:
            // purchases are already sorted; only batches with t <= event.t are available.
            var allBatches = fifoBatches.slice();
            fifoBatches = [];
            var batchCursor = 0;
            function releasePurchasesUntil(t) {
                while (batchCursor < allBatches.length && allBatches[batchCursor].t <= t) {
                    fifoBatches.push({
                        rem: allBatches[batchCursor].rem,
                        unitCost: allBatches[batchCursor].unitCost,
                        t: allBatches[batchCursor].t
                    });
                    batchCursor++;
                }
            }
            timeline.forEach(function (ev) {
                if (ev.after) return;
                releasePurchasesUntil(ev.t);
                if (ev.kind === 'waste') {
                    consumeFifoPieces(ev.pieces);
                    return;
                }
                if (ev.kind !== 'sale') return;
                // Prefer frozen sale-line cost (catalog at sale time).
                // New cheaper purchases must NOT rewrite old sales; new sales after a cheaper buy
                // stamp the new cost and must use it (FIFO-old-batch would wrongly keep 15k).
                if (ev.stamped > 0 && ev.lineQ > 0) {
                    if (ev.inRange) {
                        totalCogs += ev.stamped * ev.lineQ;
                        soldPiecesForCogs += ev.pieces;
                    }
                    consumeFifoPieces(ev.pieces);
                    return;
                }
                var got = consumeFifoPieces(ev.pieces);
                if (ev.inRange) {
                    totalCogs += got.cost;
                    soldPiecesForCogs += got.fromFifo;
                    if (got.leftover > 0.000001 && ev.pieces > 0 && catalogPieceCost > 0) {
                        totalCogs += catalogPieceCost * got.leftover;
                        soldPiecesForCogs += got.leftover;
                    }
                }
            });
            const totalProfit = totalRevenue - totalCogs;
            var fifoUnitCost = soldPiecesForCogs > 0 ? (totalCogs / soldPiecesForCogs) : 0;
            
            // NEW: Calculate Delivered Quantity
            let deliveredQty = 0;
            (db.deliveries || []).forEach(d => {
                if(d.status === 'delivered' && d.items && inReportRange(d.date)) {
                    const count = d.items.filter(i => String(i.id) === String(pid)).length;
                    deliveredQty += count;
                }
            });

            // Add Pending Deliveries to History
            (db.deliveries || []).forEach(d => {
                if(d.status === 'pending' && d.items && inReportRange(d.date)) {
                    const countInDelivery = d.items.filter(i => String(i.id) === String(pid)).length;
                    if(countInDelivery > 0) {
                        history.push({
                            type: 'delivery_pending',
                            date: new Date(d.date),
                            qty: countInDelivery,
                            info: `بەریدان (ل ڕێکێ): ${typeof deliveryCustomerLabel === 'function' ? deliveryCustomerLabel(d) : (d.customer_name || 'بێ ناڤ')}`
                        });
                    }
                }
            });

            function isSupplierReturnLine(supply) {
                var typ = String(supply.type || '').toLowerCase().trim();
                var txn = String(supply.transaction_id || '');
                if (typ === 'return' || txn.indexOf('TXPR') === 0) return true;
                return (parseFloat(supply.qtyAdded) || 0) < 0 && typ !== 'opening';
            }
            function returnLinePieces(item) {
                const u = item.saleUnit || item.unit || 'piece';
                var lineCount = (typeof getItemQty === 'function')
                    ? getItemQty(item)
                    : (parseFloat(item.qty != null ? item.qty : item.count) || 0);
                if (item.pieces != null && !isNaN(parseFloat(item.pieces))) {
                    return { u: u, lineCount: lineCount, pieces: Math.abs(parseFloat(item.pieces) || 0) };
                }
                var pieceMult = (typeof getPiecesMultiplierForUnit === 'function')
                    ? (getPiecesMultiplierForUnit(p, u) || 1)
                    : 1;
                return { u: u, lineCount: lineCount, pieces: Math.abs(lineCount * pieceMult) };
            }

            let supplyCount = 0;
            let totalPurchaseCost = 0;
            let totalSuppliedQty = 0;
            let purchasesByUnit = { carton: 0, pack: 0, piece: 0 };
            let openingQtySum = 0;
            let openingCostSum = 0;
            var reconBuyRange = 0;
            var reconBuyAfter = 0;
            var reconSuppRange = 0;
            var reconSuppAfter = 0;
            var supplierReturnTxnSeen = {};
            (supplyRows || []).forEach(supply => {
                if (String(supply.prodId) !== String(pid)) return;
                var typ = String(supply.type || '').toLowerCase();
                const qtyPieces = Math.abs(parseFloat(supply.qtyAdded) || 0);
                if (qtyPieces <= 0) return;
                if (isSupplierReturnLine(supply)) {
                    return;
                }
                if (afterReportRange(supply.date)) {
                    reconBuyAfter += qtyPieces;
                    return;
                }
                if (!inReportRange(supply.date)) return;
                if (typ === 'opening') {
                    openingQtySum += qtyPieces;
                    openingCostSum += (parseFloat(supply.totalCost) || 0);
                    history.push({
                        type: 'opening',
                        date: itemReportDate(supply.date),
                        qty: supply.qtyAdded,
                        info: 'کۆگەها دەستپێکێ'
                    });
                    return;
                }
                reconBuyRange += qtyPieces;
                supplyCount++;
                totalPurchaseCost += (parseFloat(supply.totalCost) || 0);
                totalSuppliedQty += qtyPieces;
                const bc = piecesToUnitCounts(qtyPieces);
                purchasesByUnit.carton += bc.carton;
                purchasesByUnit.pack += bc.pack;
                purchasesByUnit.piece += bc.piece;
                history.push({
                    type: 'supply',
                    date: itemReportDate(supply.date),
                    qty: supply.qtyAdded,
                    info: supply.company
                });
            });

            let customerReturnCount = 0;
            let customerReturnsByUnit = { carton: 0, pack: 0, piece: 0 };
            var reconCustRange = 0;
            var reconCustAfter = 0;
            var customerReturnRows = (Array.isArray(extraRows.returns) && extraRows.returns.length)
                ? extraRows.returns
                : ((db && db.returns) || []);
            if (Array.isArray(extraRows.returns) && extraRows.returns.length && db && Array.isArray(db.returns) && db.returns.length) {
                var retById = {};
                extraRows.returns.forEach(function (r) { if (r && r.id != null) retById[String(r.id)] = r; });
                db.returns.forEach(function (r) { if (r && r.id != null && !retById[String(r.id)]) retById[String(r.id)] = r; });
                customerReturnRows = Object.keys(retById).map(function (k) { return retById[k]; });
            }
            customerReturnRows.forEach(function (ret) {
                (normalizeReportSaleItems(ret.items) || []).forEach(function (item) {
                    if (!saleLineMatchesProduct(item)) return;
                    var line = returnLinePieces(item);
                    if (line.pieces <= 0) return;
                    if (afterReportRange(ret.date)) {
                        reconCustAfter += line.pieces;
                        return;
                    }
                    if (!inReportRange(ret.date)) return;
                    reconCustRange += line.pieces;
                    customerReturnCount++;
                    if (line.u === 'carton') customerReturnsByUnit.carton += line.lineCount;
                    else if (line.u === 'pack') customerReturnsByUnit.pack += line.lineCount;
                    else customerReturnsByUnit.piece += line.lineCount;
                    history.push({
                        type: 'return_customer',
                        date: itemReportDate(ret.date),
                        qty: line.pieces,
                        info: 'زڤڕاندنا کریاری'
                    });
                });
            });
            
            let supplierReturnsByUnit = { carton: 0, pack: 0, piece: 0 };
            let supplierReturnCount = 0;
            var purchaseReturnRows = Array.isArray(extraRows.purchase_returns) ? extraRows.purchase_returns : ((db && db.purchase_returns) || []);
            purchaseReturnRows.forEach(function (pr) {
                var items = normalizeReportSaleItems(pr.items);
                var matched = 0;
                var pcs = 0;
                items.forEach(function (item) {
                    if (!saleLineMatchesProduct(item) && String(item.productId || item.prodId || '') !== String(pid)) return;
                    var line = returnLinePieces(item);
                    if (line.pieces <= 0) return;
                    matched++;
                    pcs += line.pieces;
                    if (afterReportRange(pr.date)) {
                        reconSuppAfter += line.pieces;
                        return;
                    }
                    if (!inReportRange(pr.date)) return;
                    reconSuppRange += line.pieces;
                    var bc = piecesToUnitCounts(line.pieces);
                    supplierReturnsByUnit.carton += bc.carton;
                    supplierReturnsByUnit.pack += bc.pack;
                    supplierReturnsByUnit.piece += bc.piece;
                });
                if (matched) {
                    var txn = String(pr.transaction_id || ('PR_' + pr.id));
                    supplierReturnTxnSeen[txn] = 1;
                    if (inReportRange(pr.date)) {
                        supplierReturnCount++;
                        history.push({
                            type: 'return_supply',
                            date: itemReportDate(pr.date),
                            qty: pcs,
                            info: 'زڤڕاندن بۆ ' + (pr.company_name || pr.company || '')
                        });
                    }
                }
            });
            (supplyRows || []).forEach(function (s) {
                if (String(s.prodId) !== String(pid) || !isSupplierReturnLine(s)) return;
                var txn = String(s.transaction_id || '');
                if (txn && supplierReturnTxnSeen[txn]) return;
                const qtyPieces = Math.abs(parseFloat(s.qtyAdded) || 0);
                if (qtyPieces <= 0) return;
                if (txn) supplierReturnTxnSeen[txn] = 1;
                if (afterReportRange(s.date)) {
                    reconSuppAfter += qtyPieces;
                    return;
                }
                if (!inReportRange(s.date)) return;
                reconSuppRange += qtyPieces;
                const bc = piecesToUnitCounts(qtyPieces);
                supplierReturnsByUnit.carton += bc.carton;
                supplierReturnsByUnit.pack += bc.pack;
                supplierReturnsByUnit.piece += bc.piece;
                supplierReturnCount++;
                history.push({
                    type: 'return_supply',
                    date: itemReportDate(s.date),
                    qty: qtyPieces,
                    info: 'زڤڕاندن بۆ ' + (s.company || '')
                });
            });

            let wasteCount = 0;
            let wasteCost = 0;
            let wasteByUnit = { carton: 0, pack: 0, piece: 0 };
            var reconWasteRange = 0;
            var reconWasteAfter = 0;
            wasteRows.forEach(function (w) {
                if (String(w.prodId) !== String(pid)) return;
                const qtyPieces = Math.abs(parseFloat(w.qty) || 0);
                if (afterReportRange(w.date)) {
                    reconWasteAfter += qtyPieces;
                    return;
                }
                if (!inReportRange(w.date)) return;
                reconWasteRange += qtyPieces;
                wasteCount += (w.qty || 0);
                wasteCost += (w.cost || 0);
                const bc = piecesToUnitCounts(qtyPieces);
                wasteByUnit.carton += bc.carton;
                wasteByUnit.pack += bc.pack;
                wasteByUnit.piece += bc.piece;
                history.push({
                    type: 'waste',
                    date: itemReportDate(w.date),
                    qty: w.qty,
                    info: w.reason
                });
            });
            
            function countsToPieces(c) {
                var pc = (unitFactors.piecesPerCarton > 1) ? unitFactors.piecesPerCarton : 1;
                var pp = (unitFactors.piecesPerPack > 1) ? unitFactors.piecesPerPack : 1;
                return (Number(c.carton) || 0) * pc + (Number(c.pack) || 0) * pp + (Number(c.piece) || 0);
            }
            var soldPcs = reconSaleRange;
            var buyPcs = reconBuyRange;
            var custPcs = reconCustRange;
            var suppPcs = reconSuppRange;
            var wastePcs = reconWasteRange;
            var onHandPcs = Math.max(0, parseFloat(extraRows.qty != null ? extraRows.qty : p.qty) || 0);
            if (extraRows.qty != null && !isNaN(parseFloat(extraRows.qty))) {
                p.qty = parseFloat(extraRows.qty);
            }
            var qAtTo = onHandPcs - reconBuyAfter + reconSaleAfter - reconCustAfter + reconSuppAfter + reconWasteAfter;
            var qAtFrom = qAtTo - reconBuyRange + reconSaleRange - reconCustRange + reconSuppRange + reconWasteRange;
            if (qAtTo < 0 && qAtTo > -0.02) qAtTo = 0;
            if (qAtFrom < 0 && qAtFrom > -0.02) qAtFrom = 0;
            var openingDisplayPcs = qAtFrom;
            var expectedOnHand = qAtFrom + buyPcs - soldPcs + custPcs - suppPcs - wastePcs;
            var reconDrift = Math.round((expectedOnHand - qAtTo) * 1000) / 1000;
            var reconOk = Math.abs(reconDrift) < 0.02;
            var fmtPcs = function (n) {
                return (typeof formatQtyForDisplay === 'function') ? formatQtyForDisplay(n, p) : String(Math.round(n));
            };
            var pieceLbl = (typeof getProductUnitLabel === 'function') ? getProductUnitLabel(p, 'piece') : 'تاک';
            var todayIso = (typeof getBusinessDate === 'function') ? getBusinessDate(new Date()) : new Date().toISOString().slice(0, 10);
            var endIsNow = rangeAll || !rangeTo || rangeTo >= todayIso;
            var endLbl = endIsNow
                ? 'کۆگەها نوکە'
                : ((typeof t === 'function') ? t('item_report_stock_end') : 'کۆگەها دوماهیێ');
            var rangeHint = '';
            if (!rangeAll && rangeFrom && rangeTo) {
                rangeHint = '<div style="font-size:0.8rem;color:var(--text-muted);margin-bottom:4px;">' +
                    (rangeFrom === rangeTo ? rangeFrom : (rangeFrom + ' → ' + rangeTo)) + '</div>';
            }
            var reconHtml =
                '<div class="card" style="margin:0 0 12px 0;padding:12px 14px;border-right:4px solid ' + (reconOk ? 'var(--info)' : 'var(--warning)') + ';">' +
                    rangeHint +
                    '<div style="font-weight:800;margin-bottom:6px;"><i class="fas fa-balance-scale"></i> هاوکێشا کۆگەهێ</div>' +
                    '<div style="font-size:0.88rem;line-height:1.7;color:var(--text);">' +
                        'دەستپێک <b>' + fmtPcs(openingDisplayPcs) + '</b>' +
                        ' + کرین <b>' + fmtPcs(buyPcs) + '</b>' +
                        ' − فرۆتن <b>' + fmtPcs(soldPcs) + '</b>' +
                        (custPcs ? (' + زڤڕاندنا کریاری <b>' + fmtPcs(custPcs) + '</b>') : '') +
                        (suppPcs ? (' − زڤڕاندنا کۆمپانیێ <b>' + fmtPcs(suppPcs) + '</b>') : '') +
                        (wastePcs ? (' − تەلەف <b>' + fmtPcs(wastePcs) + '</b>') : '') +
                        ' = ' + escapeHtml(endLbl) + ' <b>' + fmtPcs(qAtTo) + '</b> ' + escapeHtml(pieceLbl) +
                    '</div>' +
                    (!rangeAll
                        ? '<p style="margin:8px 0 0;font-size:0.8rem;color:var(--text-muted);">' + ((typeof t === 'function') ? t('item_report_opening_period') : 'کۆگەه بەری ڤی قۆناغی') + '</p>'
                        : (openingDisplayPcs > 0.0001 && openingQtySum < 0.0001
                            ? '<p style="margin:8px 0 0;font-size:0.8rem;color:#b45309;">' + fmtPcs(openingDisplayPcs) + ' دانە ژ کۆگەها دەستپێکێ / بێ پسوولا کرینێ — ل کارتێ کرینێ ناهێنە ژمێرتن.</p>'
                            : '')) +
                    (!reconOk
                        ? '<p style="margin:8px 0 0;font-size:0.8rem;color:var(--danger);">ژمارە نەگونجان: جیاوازی ' + fmtPcs(Math.abs(reconDrift)) + ' — مێژوویا کرینێ یان فرۆتنێ کێمە.</p>'
                        : '') +
                '</div>';

            // Sort History
            history.sort((a, b) => b.date - a.date);

            var reportCostPiece = fifoUnitCost > 0 ? fifoUnitCost : (avgPurchasePieceCost > 0 ? avgPurchasePieceCost : null);
            var sellPiece = (typeof getCatalogPieceSellIqd === 'function') ? getCatalogPieceSellIqd(p) : (p.price || 0);
            var costBasisNote = (purchaseQtySum > 0)
                ? '<p style="margin:6px 0 0;font-size:0.78rem;color:var(--text-muted);">تێچووی دانێن فرۆتی (FIFO / نرخێ وەسڵێ) — کرینێن نوو قازانجا کۆن ناگۆڕن</p>'
                : '<p style="margin:6px 0 0;font-size:0.78rem;color:#b45309;">بێ مێژوویا کرینێ — تێچوو ژ نرخێ دەستپێکێ (کاتالۆگ)</p>';
            if (Math.abs((totalCogs || 0) - (totalPurchaseCost || 0)) > 1) {
                costBasisNote += '<p style="margin:4px 0 0;font-size:0.75rem;color:var(--text-muted);">ئەڤە نە کۆی پسوولێن کرینێ یە (' + formatCurrency(totalPurchaseCost) + ')</p>';
            }

            // --- HTML Generation ---
            if (!contentDiv) return;
            contentDiv.innerHTML = `
                <div class="card" style="text-align:center; background: var(--input-bg);">
                    <h3 style="margin:0; color:var(--brand);">${escapeHtml(p.name || 'ئایتم')}</h3>
                    <p style="color:var(--text-muted); margin:5px 0;">${escapeHtml(p.cat)}</p>
                </div>
                ${reconHtml}

                <div class="stat-grid" style="grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));">
                    <div class="stat-card" style="padding:15px; background:var(--card);">
                        <h3>فرۆتن (Sales)</h3>
                        <h1>${salesCount} <small>جار</small></h1>
                        <div style="margin-top:10px; display:flex; flex-direction:column; gap:6px; text-align:right;">
                            <div><span style="color:var(--text-muted);">Sales by ${getProductUnitLabel(p, 'carton')}:</span> <b>${salesByUnit.carton}</b></div>
                            <div><span style="color:var(--text-muted);">Sales by ${getProductUnitLabel(p, 'pack')}:</span> <b>${salesByUnit.pack}</b></div>
                            <div><span style="color:var(--text-muted);">Sales by ${getProductUnitLabel(p, 'piece')}:</span> <b>${salesByUnit.piece}</b></div>
                        </div>
                        <p>کۆی داهات: ${formatCurrency(totalRevenue)}</p>
                    </div>
                    <div class="stat-card" style="padding:15px; background:var(--card); border-right-color:#ec4899;">
                        <h3 style="color:#ec4899;"><i class="fas fa-gift"></i> دیاری (بەلاش)</h3>
                        <h1 style="color:#ec4899;">${giftSalesCount} <small>جار</small></h1>
                        <div style="margin-top:10px; display:flex; flex-direction:column; gap:6px; text-align:right;">
                            <div><span style="color:var(--text-muted);">دیاری ${getProductUnitLabel(p, 'carton')}:</span> <b>${giftByUnit.carton}</b></div>
                            <div><span style="color:var(--text-muted);">دیاری ${getProductUnitLabel(p, 'pack')}:</span> <b>${giftByUnit.pack}</b></div>
                            <div><span style="color:var(--text-muted);">دیاری ${getProductUnitLabel(p, 'piece')}:</span> <b>${giftByUnit.piece}</b></div>
                        </div>
                        <p style="color:#ec4899;">بهایێ دیاری: ${formatCurrency(totalGiftValue)}</p>
                    </div>
                    ${((typeof canViewProfit === 'function') ? canViewProfit() : true) ? `<div class="stat-card" data-needs="profit" style="padding:15px; background:var(--card); border-right-color: var(--success);">
                        <h3>قازانج (Profit)</h3>
                        <h1 style="color:var(--success);">${formatCurrency(totalProfit)}</h1>
                        <p>تێچووی فرۆتنێ: ${formatCurrency(totalCogs)}</p>
                        ${costBasisNote}
                    </div>` : ''}
                    <div class="stat-card" style="padding:15px; background:var(--card); border-right-color: var(--info);">
                        <h3>کڕین (Purchases)</h3>
                        <h1>${supplyCount} <small>جار</small></h1>
                        <div style="margin-top:10px; display:flex; flex-direction:column; gap:6px; text-align:right;">
                            <div><span style="color:var(--text-muted);">Purchases by ${getProductUnitLabel(p, 'carton')}:</span> <b>${purchasesByUnit.carton}</b></div>
                            <div><span style="color:var(--text-muted);">Purchases by ${getProductUnitLabel(p, 'pack')}:</span> <b>${purchasesByUnit.pack}</b></div>
                            <div><span style="color:var(--text-muted);">Purchases by ${getProductUnitLabel(p, 'piece')}:</span> <b>${purchasesByUnit.piece}</b></div>
                        </div>
                        <p>کۆی مەزاختن: ${formatCurrency(totalPurchaseCost)}</p>
                        <p style="margin-top:6px;font-size:0.82rem;color:var(--text-muted);">کۆ: ${fmtPcs(buyPcs)} ${escapeHtml(pieceLbl)} · ${supplyCount} پسوولە</p>
                        ${openingDisplayPcs > 0.0001 ? '<p style="margin-top:6px;font-size:0.82rem;color:#b45309;">+ ' + fmtPcs(openingDisplayPcs) + (rangeAll ? ' دەستپێک (بێ پسوولە)' : ' دەستپێکا قۆناغێ') + '</p>' : ''}
                    </div>
                    <div class="stat-card" style="padding:15px; background:var(--card); border-right-color: var(--warning);">
                        <h3>زڤڕاندن (Returns)</h3>
                        <h1>${customerReturnCount} <small>کریار</small></h1>
                        <div style="margin-top:10px; display:flex; flex-direction:column; gap:6px; text-align:right;">
                            <div><span style="color:var(--text-muted);">Return by ${getProductUnitLabel(p, 'carton')}:</span> <b>${customerReturnsByUnit.carton}</b></div>
                            <div><span style="color:var(--text-muted);">Return by ${getProductUnitLabel(p, 'pack')}:</span> <b>${customerReturnsByUnit.pack}</b></div>
                            <div><span style="color:var(--text-muted);">Return by ${getProductUnitLabel(p, 'piece')}:</span> <b>${customerReturnsByUnit.piece}</b></div>
                        </div>
                        <div style="margin-top:10px; display:flex; flex-direction:column; gap:6px; text-align:right;">
                            <div><span style="color:var(--text-muted);">Supplier Return by ${getProductUnitLabel(p, 'carton')}:</span> <b>${supplierReturnsByUnit.carton}</b></div>
                            <div><span style="color:var(--text-muted);">Supplier Return by ${getProductUnitLabel(p, 'pack')}:</span> <b>${supplierReturnsByUnit.pack}</b></div>
                            <div><span style="color:var(--text-muted);">Supplier Return by ${getProductUnitLabel(p, 'piece')}:</span> <b>${supplierReturnsByUnit.piece}</b></div>
                        </div>
                        <p style="margin-top:10px;">${supplierReturnCount} <small>بۆ کۆمپانیێ</small></p>
                    </div>
                    <div class="stat-card" style="padding:15px; background:var(--card); border-right-color: var(--danger);">
                        <h3>تەلەف (Waste)</h3>
                        <h1>${wasteCount} <small>دانە</small></h1>
                        <div style="margin-top:10px; display:flex; flex-direction:column; gap:6px; text-align:right;">
                            <div><span style="color:var(--text-muted);">Waste by ${getProductUnitLabel(p, 'carton')}:</span> <b>${wasteByUnit.carton}</b></div>
                            <div><span style="color:var(--text-muted);">Waste by ${getProductUnitLabel(p, 'pack')}:</span> <b>${wasteByUnit.pack}</b></div>
                            <div><span style="color:var(--text-muted);">Waste by ${getProductUnitLabel(p, 'piece')}:</span> <b>${wasteByUnit.piece}</b></div>
                        </div>
                        <p>بهای: ${formatCurrency(wasteCost)}</p>
                    </div>
                    <div class="stat-card" style="padding:15px; background:var(--card); border-right-color: #8b5cf6;">
                        <h3>بەریدان (Delivered)</h3>
                        <h1>${deliveredQty} <small>دانە</small></h1>
                        <p>ب ڕێکا دلیڤەری</p>
                    </div>
                </div>

                <div class="card">
                    <h4><i class="fas fa-info-circle"></i> زانیاریێن گشتی</h4>
                    <table class="report-table">
                        <tr><td>مەخزەنا نوکە</td><td><b>${formatQtyForDisplay((p.qty || 0), p)}</b> <small>${getProductUnitLabel(p, 'piece')}</small></td></tr>
                        <tr><td>نرخێ فرۆتنێ</td><td>${formatCurrency(sellPiece)}</td></tr>
                        ${((typeof canViewProfit === 'function') ? canViewProfit() : true) ? `<tr data-needs="profit"><td>نرخێ کڕینێ ${fifoUnitCost > 0 ? '(FIFO)' : (avgPurchasePieceCost > 0 ? '(ناوەند)' : '')}</td><td>${reportCostPiece != null ? formatCurrency(reportCostPiece) : '—'}</td></tr>
                        ${reportCostPiece != null && Math.abs(reportCostPiece - catalogPieceCost) > 0.009 ? `<tr data-needs="profit"><td>نرخێ دەستپێکێ (کاتالۆگ)</td><td style="color:var(--text-muted);">${formatCurrency(catalogPieceCost)}</td></tr>` : ''}
                        <tr data-needs="profit"><td>قازانجێ تاک</td><td style="color:var(--success); font-weight:bold;">${reportCostPiece != null ? formatCurrency(sellPiece - reportCostPiece) : '—'}</td></tr>
                        <tr data-needs="profit"><td>ڕێژا قازانجی</td><td>${reportCostPiece != null && sellPiece > 0 ? (((sellPiece - reportCostPiece) / sellPiece) * 100).toFixed(1) + '%' : '—'}</td></tr>` : ''}
                        <tr><td>بارکۆد</td><td>${p.barcode || '-'}</td></tr>
                        <tr><td>بەسەرچوون</td><td>${(typeof getProductCatalogExpiryDisplay === 'function') ? getProductCatalogExpiryDisplay(p) : '-'}</td></tr>
                    </table>
                </div>
                
                <div class="card" style="margin-top:20px;">
                    <h4><i class="fas fa-history"></i> مێژوویا لڤینان (Transaction History)</h4>
                    <div style="max-height:300px; overflow-y:auto;">
                        <table class="report-table">
                            <thead><tr><th>جۆر</th><th>بەروار</th><th>ژمارە</th><th>وردەکاری</th></tr></thead>
                            <tbody>
                                ${history.length > 0 ? history.map(h => {
                                    let color = 'black'; let icon = ''; let label = '';
                                    if(h.type === 'sale') { color='green'; icon='fa-shopping-cart'; label='فرۆتن'; }
                                    else if(h.type === 'sale_gift' || h.type === 'sale_gift_mixed') { color='#ec4899'; icon='fa-gift'; label='فرۆتن · دیاری'; }
                                    else if(h.type === 'supply') { color='blue'; icon='fa-truck'; label='کڕین'; }
                                    else if(h.type === 'opening') { color='#0ea5e9'; icon='fa-warehouse'; label='کۆگەها دەستپێکێ'; }
                                    else if(h.type === 'waste') { color='red'; icon='fa-trash'; label='تەلەف'; }
                                    else if(h.type === 'delivery_pending') { color='#f59e0b'; icon='fa-motorcycle'; label='بەریدان (Pending)'; }
                                    else if(h.type === 'return_supply') { color='orange'; icon='fa-undo'; label='زڤڕاندن (کۆمپانیا)'; }
                                    else if(h.type === 'return_customer') { color='#f97316'; icon='fa-undo'; label='زڤڕاندن (کریار)'; }
                                    
                                    return `<tr>
                                        <td style="color:${color}; font-weight:bold;"><i class="fas ${icon}"></i> ${label}</td>
                                        <td>${h.date.toLocaleDateString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ')}</td>
                                        <td>${h.qty}</td>
                                        <td>${escapeHtml(h.info)}</td>
                                    </tr>`;
                                }).join('') : '<tr><td colspan="4" style="text-align:center; color:#999;">چ مێژوو نینە</td></tr>'}
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
            }

            var fallbackSupplies = function () {
                var base = (typeof window.posGetSuppliesPool === 'function')
                    ? window.posGetSuppliesPool()
                    : ((db && db.supplies) || []);
                return (base || []).filter(function (s) {
                    return s && String(s.prodId) === String(pid);
                });
            };
            var mergePurchaseRows = function (primary, secondary) {
                var seen = {};
                var out = [];
                function ingest(list) {
                    (list || []).forEach(function (s) {
                        if (!s) return;
                        var fp = (typeof window.posSupplyFingerprint === 'function')
                            ? window.posSupplyFingerprint(s)
                            : String(s.id || '') + '|' + String(s.prodId || '') + '|' + String(s.date || '') + '|' + String(s.type || '') + '|' + String(s.qtyAdded || '');
                        if (!fp || seen[fp]) return;
                        seen[fp] = 1;
                        out.push(s);
                    });
                }
                ingest(primary);
                ingest(secondary);
                return out;
            };
            var finishWithRows = function (rows, salesRows, extra) {
                paintItemReport(mergePurchaseRows(rows, fallbackSupplies()), salesRows || [], extra || {});
            };
            var fetchProductItemReport = function () {
                try {
                    var params = new URLSearchParams();
                    params.set('action', 'get_product_item_report');
                    params.set('product_id', String(pid));
                    params.set('_', String(Date.now()));
                    var url = (typeof window.posRouterUrl === 'function')
                        ? window.posRouterUrl(params.toString())
                        : ('?' + params.toString());
                    return fetch(url, { credentials: 'same-origin' })
                        .then(function (res) { return res.json(); })
                        .then(function (data) {
                            if (!data || data.status !== 'success') return null;
                            return data;
                        })
                        .catch(function () { return null; });
                } catch (_e) {
                    return Promise.resolve(null);
                }
            };
            fetchProductItemReport().then(function (pack) {
                if (pack) {
                    finishWithRows(pack.supplies || [], pack.sales || [], {
                        returns: pack.returns || [],
                        purchase_returns: pack.purchase_returns || [],
                        waste: pack.waste || [],
                        qty: pack.qty
                    });
                    return;
                }
                var salesPromise = (function () {
                    try {
                        var params = new URLSearchParams();
                        params.set('action', 'get_product_item_report_sales');
                        params.set('product_id', String(pid));
                        var url = (typeof window.posRouterUrl === 'function')
                            ? window.posRouterUrl(params.toString())
                            : ('?' + params.toString());
                        return fetch(url, { credentials: 'same-origin' })
                            .then(function (res) { return res.json(); })
                            .then(function (data) {
                                return (data && data.status === 'success' && Array.isArray(data.sales)) ? data.sales : [];
                            })
                            .catch(function () { return []; });
                    } catch (_e2) {
                        return Promise.resolve([]);
                    }
                })();
                if (typeof window.posEnsureProductFifoSupplies === 'function') {
                    Promise.all([
                        window.posEnsureProductFifoSupplies(pid, { force: true, includeOpening: true }).catch(function () { return []; }),
                        salesPromise
                    ]).then(function (pair) {
                        finishWithRows(pair[0] || [], pair[1] || [], {
                            returns: (db && db.returns) || [],
                            purchase_returns: (db && db.purchase_returns) || [],
                            waste: (db && db.waste) || []
                        });
                    }).catch(function () {
                        salesPromise.then(function (salesRows) {
                            finishWithRows([], salesRows, {
                                returns: (db && db.returns) || [],
                                purchase_returns: (db && db.purchase_returns) || [],
                                waste: (db && db.waste) || []
                            });
                        });
                    });
                } else {
                    salesPromise.then(function (salesRows) {
                        finishWithRows([], salesRows, {
                            returns: (db && db.returns) || [],
                            purchase_returns: (db && db.purchase_returns) || [],
                            waste: (db && db.waste) || []
                        });
                    });
                }
            });
        }
        window.showItemReport = showItemReport;
        window.applyItemReportDateRange = function () {
            window._itemReportAllTime = false;
            if (window._itemReportPid != null && typeof showItemReport === 'function') showItemReport(window._itemReportPid);
        };
        window.setItemReportRangeToday = function () {
            window._itemReportAllTime = false;
            var todayIso = (typeof getBusinessDate === 'function') ? getBusinessDate(new Date()) : new Date().toISOString().slice(0, 10);
            var f = document.getElementById('item-report-date-from');
            var tEl = document.getElementById('item-report-date-to');
            if (f) f.value = todayIso;
            if (tEl) tEl.value = todayIso;
            if (window._itemReportPid != null) showItemReport(window._itemReportPid);
        };
        window.setItemReportRangeAll = function () {
            window._itemReportAllTime = true;
            var f = document.getElementById('item-report-date-from');
            var tEl = document.getElementById('item-report-date-to');
            if (f) f.value = '';
            if (tEl) tEl.value = '';
            if (window._itemReportPid != null) showItemReport(window._itemReportPid);
        };

        // --- NEW: SHOP OVERVIEW FUNCTION (ADVANCED MASTER VIEW) ---
        function renderShopOverview() {
            const container = document.getElementById('shop-overview-content');
            if(!container) return;
            const _t = (typeof t === 'function') ? t : function(k) { return k; };
            const _e = (typeof escapeHtml === 'function') ? escapeHtml : function(s) { return String(s == null ? '' : s); };
            const roundM = typeof roundMoney === 'function' ? roundMoney : function(x){ return Math.round(Number(x)); };
            const todayStr = getBusinessDate(new Date());
            const isAdmin = currentUser && currentUser.role === 'admin';
            const metrics = (typeof getFinancialMetrics === 'function')
                ? getFinancialMetrics(null, isAdmin ? {} : { salesScope: 'report' })
                : null;

            // --- INVENTORY (tracked stock only for health %) ---
            let totalItems = 0;
            let trackedItems = 0;
            let stockCost = 0;
            let lowStockCount = 0;
            let expiredCount = 0;
            let outOfStockCount = 0;

            db.products.forEach(p => {
                totalItems++;
                if (!p.trackStock) return;
                trackedItems++;
                const q = p.qty > 0 ? p.qty : 0;
                let val = 0;
                if (window.getProductFifoBatches) {
                    const batches = window.getProductFifoBatches(p.id, q);
                    batches.forEach(b => { val += b.qty * b.unitCost; });
                } else {
                    var _unitCost = (typeof productStockValueIqd === 'function')
                        ? (productStockValueIqd(p, 1))
                        : (typeof getCatalogPieceCostIqd === 'function' ? getCatalogPieceCostIqd(p) : (p.cost || 0));
                    val = _unitCost * q;
                }
                if (val < 100000000) {
                    stockCost = roundM(stockCost + val);
                }
                if (isWarehouseTrueStockout(p)) outOfStockCount++;
                else if (p.qty > 0 && p.qty <= getMinStock(p)) lowStockCount++;
                if (q > 0 && typeof productCatalogExpiryDaysLeft === 'function') {
                    const days = productCatalogExpiryDaysLeft(p);
                    if (days != null && days <= 60) expiredCount++;
                }
            });
            const stockHealth = trackedItems > 0
                ? Math.round(((trackedItems - outOfStockCount - lowStockCount) / trackedItems) * 100)
                : 100;

            const capReport = db.capital_report;
            const stockValueDisplay = (capReport && capReport.stock_value != null)
                ? roundM(capReport.stock_value)
                : stockCost;

            // --- TODAY (same engine as daily summary / dashboard) ---
            let netSales = 0;
            let todayCashSales = 0;
            let todayDebtSales = 0;
            let todayExpenses = 0;
            let todayNetProfit = 0;
            let todayCashMovement = 0;
            let todayGifts = 0;
            let todayDebtPaymentsIn = 0;
            let todayPurchaseReturnsIn = 0;
            let margin = 0;
            if (metrics) {
                netSales = roundM(metrics.totalSales - metrics.totalReturns);
                todayCashSales = metrics.cashSales;
                todayDebtSales = metrics.debtSales;
                todayExpenses = metrics.opExpenses;
                todayNetProfit = metrics.netProfit;
                todayCashMovement = metrics.cashMovement;
                todayGifts = metrics.totalGiftsValue || 0;
                todayDebtPaymentsIn = metrics.debtPaymentsIn || 0;
                todayPurchaseReturnsIn = metrics.purchaseReturnsIn || 0;
                margin = netSales > 0 ? Math.round((todayNetProfit / netSales) * 100) : 0;
            }

            const todaySales = (typeof getReportSales === 'function' ? getReportSales() : getAllSales())
                .filter(s => s && getBusinessDate(parseSQLDate(s.date || s.created_at)) === todayStr);
            const itemSalesMap = {};
            const hourMap = {};
            todaySales.forEach(s => {
                if (s.items) s.items.forEach(i => {
                    const lineQ = typeof getItemQty === 'function' ? getItemQty(i) : 1;
                    itemSalesMap[i.name] = (itemSalesMap[i.name] || 0) + lineQ;
                });
                const h = parseSQLDate(s.date || s.created_at).getHours();
                hourMap[h] = (hourMap[h] || 0) + 1;
            });
            let topItemName = _t('shop_ov_na');
            let maxQty = 0;
            for (const [name, qty] of Object.entries(itemSalesMap)) {
                if (qty > maxQty) { maxQty = qty; topItemName = name; }
            }
            let busyHour = _t('shop_ov_na');
            let maxTx = 0;
            for (const [h, count] of Object.entries(hourMap)) {
                if (count > maxTx) { maxTx = count; busyHour = `${h}:00`; }
            }

            const supplierDebt = roundM(db.companies.reduce((a,c) => a + (parseFloat(c.balance) || 0), 0));
            const customerDebt = roundM(db.customers.reduce((a,c) => a + (parseFloat(c.balance) || 0), 0));
            const staffDebt = roundM(db.users.reduce((a,u) => a + (parseFloat(u.balance) || 0), 0));
            const totalReceivable = roundM(customerDebt + staffDebt);
            const treasuryVal = capReport ? capReport.treasury : ((db.treasury !== undefined) ? parseFloat(db.treasury) : 0);
            const capital = capReport ? capReport.capital : roundM(stockValueDisplay + treasuryVal + totalReceivable - supplierDebt);
            const stockValue = stockValueDisplay;
            const payablesVal = capReport ? capReport.payables : supplierDebt;
            const receivablesVal = capReport ? capReport.receivables : totalReceivable;

            let topDebtor = {name: _t('shop_ov_na'), amount: 0};
            db.customers.forEach(c => { if(c.balance > topDebtor.amount) topDebtor = {name: c.name, amount: c.balance}; });

            const activeTables = (db.tables || []).filter(t => t && Array.isArray(t.items) && t.items.length > 0).length;
            const pendingDel = (db.deliveries || []).filter(d => d.status === 'pending').length;
            const activeStaff = (db.shifts || []).filter(s => !s.endTime).length;

            const showProfit = (typeof canViewProfit === 'function') ? canViewProfit() : true;
            const showExpenses = (typeof canViewExpenses === 'function') ? canViewExpenses() : true;
            const tblShort = (typeof getTablesLabelShort === 'function') ? getTablesLabelShort() : _t('nav_tables');
            const openTablesLabel = _e(tblShort) + _t('shop_ov_tables_open_suffix');
            const openDaily = (typeof openDailyHistoryModal === 'function') ? 'openDailyHistoryModal()' : '';
            const cashMoveParts = [];
            if (todayCashSales > 0) cashMoveParts.push(_e(_t('shop_ov_cash_sales')) + ': ' + formatCurrency(todayCashSales));
            if (todayDebtPaymentsIn > 0) cashMoveParts.push(_e(_t('shop_ov_debt_collected')) + ': ' + formatCurrency(todayDebtPaymentsIn));
            if (todayPurchaseReturnsIn > 0) cashMoveParts.push(_e(_t('shop_ov_purchase_return_in')) + ': ' + formatCurrency(todayPurchaseReturnsIn));
            const cashMoveBreakdown = cashMoveParts.length ? cashMoveParts.join(' · ') : '';

            container.innerHTML = `
                <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap:20px; margin-bottom:25px;">

                    <div class="stat-card shop-ov-stat shop-ov-stat--treasury protected">
                        <div class="shop-ov-stat__head">
                            <h4 class="shop-ov-stat__label"><i class="fas fa-cash-register"></i> ${_e(_t('shop_ov_treasury_title'))}</h4>
                            <span class="shop-ov-stat__badge">${_e(_t('shop_ov_live_badge'))}</span>
                        </div>
                        <h1 class="shop-ov-stat__value shop-ov-stat__value--ltr">${formatCurrency(treasuryVal)} <small>${getCurrencySymbol()}</small></h1>
                        <p class="shop-ov-stat__hint">${_e(_t('shop_ov_treasury_hint'))}</p>
                        <details class="shop-ov-stat__details">
                            <summary>${_e(_t('shop_ov_capital_detail'))}</summary>
                            <p class="shop-ov-stat__hint" style="margin:8px 0;">${_e(_t('shop_ov_capital_formula'))}</p>
                            <div class="shop-ov-stat__grid2">
                                <div class="shop-ov-stat__meta shop-ov-stat__meta--ok"><i class="fas fa-landmark"></i> ${_e(_t('shop_ov_capital'))}: <strong>${formatCurrency(capital)}</strong></div>
                                <div class="shop-ov-stat__meta shop-ov-stat__meta--warn"><i class="fas fa-arrow-down"></i> ${_e(_t('shop_ov_payables'))}: <strong>${formatCurrency(payablesVal)}</strong></div>
                                <div class="shop-ov-stat__meta shop-ov-stat__meta--info"><i class="fas fa-box"></i> ${_e(_t('shop_ov_stock_value'))}: <strong>${(typeof formatCanonicalMoney === 'function') ? formatCanonicalMoney(stockValue, capReport && capReport.stock_value_usd) : formatCurrency(stockValue)}</strong></div>
                                <div class="shop-ov-stat__meta shop-ov-stat__meta--gold"><i class="fas fa-hand-holding-usd"></i> ${_e(_t('shop_ov_receivables'))}: <strong>${formatCurrency(receivablesVal)}</strong></div>
                            </div>
                        </details>
                    </div>

                    <div class="stat-card shop-ov-stat shop-ov-stat--today" style="cursor:pointer;" onclick="${openDaily}" title="${_e(_t('shop_ov_tap_daily'))}">
                        <h4 class="shop-ov-stat__label shop-ov-stat__label--today"><i class="fas fa-shopping-cart"></i> ${_e(_t('shop_ov_today_sales_title'))}</h4>
                        <h1 class="shop-ov-stat__value">${formatCurrency(netSales)} <small>${getCurrencySymbol()}</small></h1>
                        <p class="shop-ov-stat__hint">${_e(_t('shop_ov_tap_daily'))}</p>
                        <div class="shop-ov-stat__today-row">
                            <div class="shop-ov-stat__today-cell">
                                <div class="shop-ov-stat__today-k">${_e(_t('shop_ov_cash_sales'))}</div>
                                <div class="shop-ov-stat__today-v">${formatCurrency(todayCashSales)}</div>
                            </div>
                            <div class="shop-ov-stat__today-cell">
                                <div class="shop-ov-stat__today-k">${_e(_t('shop_ov_debt_sales'))}</div>
                                <div class="shop-ov-stat__today-v">${formatCurrency(todayDebtSales)}</div>
                            </div>
                            ${showExpenses ? `<div class="shop-ov-stat__today-cell">
                                <div class="shop-ov-stat__today-k">${_e(_t('shop_ov_expenses'))}</div>
                                <div class="shop-ov-stat__today-v">${formatCurrency(todayExpenses)}</div>
                            </div>` : ''}
                            ${showProfit ? `<div class="shop-ov-stat__today-cell">
                                <div class="shop-ov-stat__today-k">${_e(_t('shop_ov_net_profit'))}</div>
                                <div class="shop-ov-stat__today-v" style="color:var(--success);">${formatCurrency(todayNetProfit)}</div>
                            </div>` : ''}
                        </div>
                        <div class="shop-ov-stat__today-foot">
                            <span>${_e(_t('shop_ov_cash_movement_today'))}: <strong>${formatCurrency(todayCashMovement)}</strong></span>
                            ${showProfit && netSales > 0 ? `<span>${_e(_t('shop_ov_margin'))}: <strong>${margin}%</strong></span>` : ''}
                            ${todayGifts > 0 ? `<span>${_e(_t('shop_ov_gifts'))}: <strong>${formatCurrency(todayGifts)}</strong></span>` : ''}
                        </div>
                        ${cashMoveBreakdown ? `<p class="shop-ov-stat__hint" style="margin-top:8px;">${_e(_t('shop_ov_cash_movement_hint'))}<br>${cashMoveBreakdown}</p>` : ''}
                    </div>

                    <div class="stat-card shop-ov-stat shop-ov-stat--inventory protected" onclick="nav('warehouse')">
                        <h4 class="shop-ov-stat__label shop-ov-stat__label--muted"><i class="fas fa-boxes"></i> ${_e(_t('shop_ov_inv_health'))}</h4>
                        <p class="shop-ov-stat__hint">${_e(_t('shop_ov_inv_health_hint'))}</p>
                        <div class="shop-ov-stat__inv-row">
                            <div class="shop-ov-stat__ring shop-ov-stat__ring--${stockHealth > 80 ? 'ok' : (stockHealth > 50 ? 'mid' : 'low')}" data-pct="${stockHealth}">
                                <span class="shop-ov-stat__ring-pct">${stockHealth}%</span>
                            </div>
                            <div style="flex:1;">
                                <div style="display:flex; justify-content:space-between; margin-bottom:5px; font-size:0.9rem;">
                                    <span>${_e(_t('shop_ov_inv_tracked'))}</span> <b>${trackedItems}</b>
                                </div>
                                <div style="display:flex; justify-content:space-between; margin-bottom:5px; font-size:0.9rem; color:#ef4444;">
                                    <span>${_e(_t('shop_ov_out_stock'))}</span> <b>${outOfStockCount}</b>
                                </div>
                                <div style="display:flex; justify-content:space-between; font-size:0.9rem; color:#f59e0b;">
                                    <span>${_e(_t('shop_ov_low_stock'))}</span> <b>${lowStockCount}</b>
                                </div>
                            </div>
                        </div>
                        <div style="margin-top:15px; font-size:0.8rem; color:var(--text-muted); text-align:center; background:var(--input-bg); padding:5px; border-radius:5px;">
                            ${_e(_t('shop_ov_value_cost_before'))}<span style="color:var(--brand); font-weight:bold;">${(typeof formatCanonicalMoney === 'function') ? formatCanonicalMoney(stockValueDisplay, capReport && capReport.stock_value_usd) : formatCurrency(stockValueDisplay)}</span>${_e(_t('shop_ov_value_cost_after'))}
                            · ${_e(_t('shop_ov_total_items'))}: ${totalItems}
                        </div>
                    </div>
                </div>

                <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap:20px; margin-bottom:25px;">
                    <div class="card" style="padding:15px; border-left:4px solid var(--info); background:var(--input-bg);">
                        <h4 style="margin:0 0 10px 0; color:var(--info);"><i class="fas fa-cogs"></i> ${_e(_t('shop_ov_operations'))}</h4>
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; cursor:pointer;" onclick="nav('tables')">
                            <span>${openTablesLabel}</span>
                            <span style="background:var(--info); color:white; padding:2px 8px; border-radius:10px; font-weight:bold;">${activeTables}</span>
                        </div>
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; cursor:pointer;" onclick="nav('delivery')">
                            <span>🛵 ${_e(_t('shop_ov_delivery_pending'))}</span>
                            <span style="background:var(--warning); color:white; padding:2px 8px; border-radius:10px; font-weight:bold;">${pendingDel}</span>
                        </div>
                        <div style="display:flex; justify-content:space-between; align-items:center;">
                            <span>👨‍🍳 ${_e(_t('shop_ov_staff_on_shift'))}</span>
                            <span style="background:var(--success); color:white; padding:2px 8px; border-radius:10px; font-weight:bold;">${activeStaff}</span>
                        </div>
                    </div>

                    <div class="card" style="padding:15px; border-left:4px solid var(--brand); background:var(--input-bg);">
                        <h4 style="margin:0 0 10px 0; color:var(--brand);"><i class="fas fa-trophy"></i> ${_e(_t('shop_ov_highlights'))}</h4>
                        <div style="margin-bottom:10px;">
                            <div style="font-size:0.8rem; color:var(--text-muted);">${_e(_t('shop_ov_top_seller_today'))}</div>
                            <div style="font-weight:bold; color:var(--text); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${_e(topItemName)} <span style="color:var(--brand);">(${maxQty})</span></div>
                        </div>
                        <div>
                            <div style="font-size:0.8rem; color:var(--text-muted);">${_e(_t('shop_ov_peak_hour'))}</div>
                            <div style="font-weight:bold; color:var(--text);">${_e(busyHour)} <span style="color:var(--brand);">(${maxTx} ${_e(_t('shop_ov_orders_word'))})</span></div>
                        </div>
                    </div>

                    <div class="card protected" style="padding:15px; border-left:4px solid var(--danger); background:var(--input-bg); cursor:pointer;" onclick="nav('debt')">
                        <h4 style="margin:0 0 10px 0; color:var(--danger);"><i class="fas fa-exclamation-circle"></i> ${_e(_t('shop_ov_debt_watch'))}</h4>
                        <div style="margin-bottom:10px;">
                            <div style="font-size:0.8rem; color:var(--text-muted);">${_e(_t('shop_ov_total_receivable'))}</div>
                            <div style="font-weight:bold; color:var(--text);">${formatCurrency(totalReceivable)}</div>
                        </div>
                        <div>
                            <div style="font-size:0.8rem; color:var(--text-muted);">${_e(_t('shop_ov_top_debtor'))}</div>
                            <div style="font-weight:bold; color:var(--danger);">${_e(topDebtor.name)} (${formatCurrency(topDebtor.amount)})</div>
                        </div>
                    </div>
                </div>

                <div class="card protected" style="border-top:4px solid var(--warning);">
                    <h4 style="margin:0 0 15px 0;"><i class="fas fa-bell"></i> ${_e(_t('shop_ov_system_alerts'))}</h4>
                    <div style="display:flex; flex-wrap:wrap; gap:10px;">
                        ${lowStockCount > 0 ? `<div style="background:rgba(245, 158, 11, 0.1); color:#f59e0b; padding:8px 12px; border-radius:8px; cursor:pointer; border:1px solid rgba(245, 158, 11, 0.3);" onclick="nav('warehouse'); renderWarehouse('low')"><i class="fas fa-cubes"></i> ${_e(_t('shop_ov_alert_low').split('{count}').join(String(lowStockCount)))}</div>` : ''}
                        ${expiredCount > 0 ? `<div style="background:rgba(239, 68, 68, 0.1); color:#ef4444; padding:8px 12px; border-radius:8px; cursor:pointer; border:1px solid rgba(239, 68, 68, 0.3);" onclick="nav('warehouse'); renderWarehouse('expired')"><i class="fas fa-calendar-times"></i> ${_e(_t('shop_ov_alert_expiring').split('{count}').join(String(expiredCount)))}</div>` : ''}
                        ${supplierDebt > 0 ? `<div style="background:rgba(239, 68, 68, 0.1); color:#ef4444; padding:8px 12px; border-radius:8px; cursor:pointer; border:1px solid rgba(239, 68, 68, 0.3);" onclick="nav('companies')"><i class="fas fa-hand-holding-usd"></i> ${_e(_t('shop_ov_alert_supplier').split('{amount}').join(formatCurrency(supplierDebt)))}</div>` : ''}
                        ${(lowStockCount === 0 && expiredCount === 0 && supplierDebt === 0) ? `<div style="width:100%; text-align:center; color:var(--success);"><i class="fas fa-check-circle"></i> ${_e(_t('shop_ov_all_ok'))}</div>` : ''}
                    </div>
                </div>
            `;
        }

        // --- WASTE MANAGEMENT (POS-like cart) ---
        var wasteCart = [];
        var wasteSelectedUnit = 'piece';
        var wasteActiveCategory = 'all';
        var wasteMenuTimeout = null;
        var _wasteSubmitting = false;

        function wasteMsg(key, fallback, vars) {
            var tpl = (typeof t === 'function') ? t(key) : '';
            if (!tpl || tpl === key) tpl = fallback;
            if (vars && typeof tpl === 'string') {
                Object.keys(vars).forEach(function(k) {
                    tpl = tpl.replace(new RegExp('\\{' + k + '\\}', 'g'), String(vars[k]));
                });
            }
            return tpl;
        }
        function canUndoWaste() {
            if (!currentUser) return false;
            if (currentUser.role === 'admin') return true;
            return (typeof hasPermission === 'function') && hasPermission('waste_manage');
        }
        function wasteSavedToast(id) {
            var wid = parseInt(id, 10);
            if (wid > 0) {
                return wasteMsg('waste_toast_saved_id', '✅ تەلەف #' + wid + ' هاتە تۆمارکرن.', { id: wid });
            }
            return wasteMsg('waste_toast_saved', '✅ تەلەف هاتە تۆمارکرن.');
        }
        function wasteSaveErrorToast(data) {
            var wid = data && data.id != null ? parseInt(data.id, 10) : 0;
            var base = (data && data.message) ? data.message : wasteMsg('waste_err_save', 'هەڵە د تۆمارکرنا تەلەفێ دا.');
            if (wid > 0) {
                return wasteMsg('waste_err_save_id', base + ' (ID: #' + wid + ')', { id: wid });
            }
            return base;
        }
        function undoWaste(id) {
            if (!canUndoWaste()) return;
            var wid = parseInt(id, 10);
            if (!wid) return;
            var row = (db.waste || []).find(function(w) { return Number(w.id) === wid; });
            if (!row) {
                // Daily summary may have the row from server pools before local db.waste is synced
                row = { id: wid, prodName: '#' + wid, qty: 0, prodId: 0 };
            }
            var msg = wasteMsg('waste_undo_confirm', 'دڵنیایت لە گەڕاندنەوەی تەلەف #' + wid + '؟', {
                id: wid,
                product: row.prodName || '-',
                qty: row.qty || 0
            });
            if (!confirm(msg)) return;
            var formData = new FormData();
            formData.append('action', 'undo_waste');
            formData.append('id', String(wid));
            formData.append('user', currentUser ? currentUser.name : 'System');
            fetch('?action=undo_waste', { method: 'POST', body: formData, credentials: 'same-origin' })
                .then(function(res) {
                    return res.text().then(function(t) {
                        var raw = String(t || '').replace(/^\uFEFF/, '').trim();
                        var statusMatch = raw.match(/\{\s*"status"\s*:/);
                        if (statusMatch && statusMatch.index > 0) raw = raw.slice(statusMatch.index);
                        try {
                            return JSON.parse(raw);
                        } catch (_e) {
                            return { status: 'error', message: wasteMsg('waste_undo_failed', 'گەڕاندنەوە سەرکەوتوو نەبوو.') };
                        }
                    });
                })
                .then(function(data) {
                    if (!data || data.status !== 'success') {
                        var err = wasteSaveErrorToast(data || {});
                        if (typeof showToast === 'function') showToast('❌ ' + err, 'error');
                        else alert('❌ ' + err);
                        return;
                    }
                    db.waste = (db.waste || []).filter(function(w) { return Number(w.id) !== wid; });
                    if (db.ledger && Array.isArray(db.ledger)) {
                        db.ledger = db.ledger.filter(function(l) {
                            return !(l && l.type === 'waste' && Number(l.related_id) === wid);
                        });
                    }
                    var p = (db.products || []).find(function(x) { return Number(x.id) === Number(data.prodId || row.prodId); });
                    if (p && p.trackStock !== false) {
                        p.qty = (parseFloat(p.qty) || 0) + (parseFloat(data.qty || row.qty) || 0);
                    }
                    if (typeof renderWasteList === 'function') renderWasteList();
                    if (typeof renderWasteCandidates === 'function') renderWasteCandidates();
                    if (typeof updateStats === 'function') updateStats();
                    if (typeof invalidateCalendarMonthCache === 'function') {
                        try { invalidateCalendarMonthCache(); } catch (_eInv) {}
                    }
                    try {
                        if (window._dailyDetailCache) {
                            Object.keys(window._dailyDetailCache).forEach(function(k) {
                                try { delete window._dailyDetailCache[k]; } catch (_e) {}
                            });
                        }
                    } catch (_eC) {}
                    var dailyModal = document.getElementById('daily-history-modal');
                    if (dailyModal && dailyModal.style.display === 'flex' && typeof openDailyHistoryModal === 'function') {
                        var dayIso = (row.date && typeof getBusinessDate === 'function')
                            ? getBusinessDate(typeof parseSQLDate === 'function' ? parseSQLDate(row.date) : new Date(row.date))
                            : undefined;
                        var keepDetailOnly = !!window._dailySummaryDetailOnly;
                        try {
                            openDailyHistoryModal(dayIso, {
                                force: true,
                                refresh: true,
                                keepDetail: true,
                                detailSection: keepDetailOnly ? 'daily-sec-waste' : null,
                                detailOnly: keepDetailOnly
                            });
                        } catch (_eDh) {
                            try { openDailyHistoryModal(dayIso, { force: true, refresh: true }); } catch (_e2) {}
                        }
                    }
                    var cal = document.getElementById('view-calendar');
                    if (cal && cal.classList.contains('active') && typeof renderWorkCalendar === 'function') {
                        try { renderWorkCalendar(); } catch (_eCal) {}
                    }
                    var ok = data.message || wasteMsg('waste_undo_ok', 'تەلەف #' + wid + ' گەڕایەوە.', { id: wid });
                    if (typeof showToast === 'function') showToast(ok, 'success');
                    else alert(ok);
                })
                .catch(function(err) {
                    var em = (err && err.message) ? err.message : wasteMsg('waste_undo_failed', 'گەڕاندنەوە سەرکەوتوو نەبوو.');
                    if (typeof showToast === 'function') showToast('❌ ' + em, 'error');
                    else alert('❌ ' + em);
                });
        }
        window.undoWaste = undoWaste;
        window.canUndoWaste = canUndoWaste;

        var _wasteModalProduct = null;

        function wasteFindProductByBarcode(raw) {
            var code = String(raw || '').trim();
            if (!code || !db.products) return null;
            if (typeof window.productMatchesPosScanCode === 'function') {
                for (var i = 0; i < db.products.length; i++) {
                    if (window.productMatchesPosScanCode(db.products[i], code)) return db.products[i];
                }
            }
            for (var j = 0; j < db.products.length; j++) {
                var p = db.products[j];
                if (String(p.barcode || '').trim() === code) return p;
                var packs = String(p.barcode_pack || '').split(',');
                for (var k = 0; k < packs.length; k++) {
                    if (packs[k].trim() === code) return p;
                }
                var cartons = String(p.barcode_carton || '').split(',');
                for (var m = 0; m < cartons.length; m++) {
                    if (cartons[m].trim() === code) return p;
                }
            }
            return null;
        }

        function wasteUnitToPieces(p, unit, qty) {
            var q = parseFloat(qty) || 0;
            if (q <= 0) return 0;
            var u = unit || 'piece';
            if (u === 'piece') return q;
            var factors = (typeof getProductUnitFactors === 'function') ? getProductUnitFactors(p) : { piecesPerPack: 1, piecesPerCarton: 1 };
            if (u === 'pack') return q * (factors.piecesPerPack || 1);
            if (u === 'carton') return q * (factors.piecesPerCarton || 1);
            return q;
        }

        function wasteCartCommittedPieces(pid, excludeIdx) {
            var sum = 0;
            (wasteCart || []).forEach(function(row, idx) {
                if (excludeIdx != null && idx === excludeIdx) return;
                if (Number(row.productId) !== Number(pid)) return;
                sum += parseFloat(row.qtyPieces) || 0;
            });
            return sum;
        }

        function wasteAvailableStock(p, excludeIdx) {
            if (!p) return 0;
            if (p.trackStock === false) return Number.MAX_SAFE_INTEGER;
            var stock = parseFloat(p.qty) || 0;
            return Math.max(0, stock - wasteCartCommittedPieces(p.id, excludeIdx));
        }

        window.setWasteUnit = function setWasteUnit(unit) {
            wasteSelectedUnit = unit || 'piece';
            ['carton', 'pack', 'piece'].forEach(function(u) {
                var btn = document.getElementById('btn-waste-unit-' + u);
                if (btn) {
                    btn.classList.toggle('active', u === wasteSelectedUnit);
                    btn.setAttribute('aria-pressed', u === wasteSelectedUnit ? 'true' : 'false');
                }
            });
            renderWasteMenu((document.getElementById('waste-barcode-input-main') || {}).value || '');
        };

        window.setWasteCategory = function setWasteCategory(cat) {
            wasteActiveCategory = cat || 'all';
            renderWasteCategories();
            renderWasteMenu((document.getElementById('waste-barcode-input-main') || {}).value || '');
        };

        function renderWasteCategories() {
            var container = document.getElementById('waste-category-tabs');
            if (!container || !db) return;
            var cats = [];
            (db.products || []).forEach(function(p) {
                var c = String((p.cat || p.category) || '').trim();
                if (c && cats.indexOf(c) === -1) cats.push(c);
            });
            cats.sort();
            var allLbl = (typeof t === 'function') ? t('pos_category_all') : 'هەمی';
            var html = '<button type="button" class="cat-btn ' + (wasteActiveCategory === 'all' ? 'active' : '') + '" onclick="setWasteCategory(\'all\')"><i class="fas fa-border-all" aria-hidden="true"></i> ' + escapeHtml(allLbl) + '</button>';
            cats.forEach(function(c) {
                html += '<button type="button" class="cat-btn ' + (wasteActiveCategory === c ? 'active' : '') + '" onclick="setWasteCategory(\'' + String(c).replace(/'/g, "\\'") + '\')"><i class="fas fa-folder-open" aria-hidden="true"></i> ' + escapeHtml(c) + '</button>';
            });
            container.innerHTML = html;
        }

        function renderWasteMenu(searchQ) {
            var grid = document.getElementById('waste-products');
            if (!grid || !db || !db.products) return;
            var q = String(searchQ || '').trim();
            var unit = wasteSelectedUnit || 'piece';
            var list = (db.products || []).filter(function(p) {
                if (!p || p.forSale === false) return false;
                if (p.trackStock !== false && (parseFloat(p.qty) || 0) <= 0) return false;
                if (typeof productMatchesUnitFilter === 'function' && !productMatchesUnitFilter(p, unit, true)) return false;
                if (wasteActiveCategory && wasteActiveCategory !== 'all') {
                    if (String((p.cat || p.category) || '').trim() !== String(wasteActiveCategory)) return false;
                }
                if (q && typeof window.productMatchesBarcodeOrNameSearch === 'function' && !window.productMatchesBarcodeOrNameSearch(p, q)) return false;
                return true;
            });
            var _gridMax = (typeof posTxnGridProductLimit === 'function') ? posTxnGridProductLimit(q) : 50;
            if (list.length > _gridMax) {
                list = list.slice().sort(function(a, b) {
                    if (a.isPinned && !b.isPinned) return -1;
                    if (!a.isPinned && b.isPinned) return 1;
                    return (b.id || 0) - (a.id || 0);
                }).slice(0, _gridMax);
            }
            var countBadge = document.getElementById('waste-products-count');
            if (countBadge) countBadge.textContent = String(list.length);
            if (!list.length) {
                grid.innerHTML = '<div class="txn-grid-empty-state pos-empty-products"><i class="fas fa-box-open"></i><span>' + escapeHtml(wasteMsg('waste_empty_products', 'چ کاڵا نەدۆزرایەوە')) + '</span></div>';
                return;
            }
            var cardIcon = unit === 'carton' ? 'fa-box' : (unit === 'pack' ? 'fa-boxes' : 'fa-cube');
            var ctaShort = wasteMsg('waste_card_cta', 'تەلەف');
            var frag = document.createDocumentFragment();
            list.forEach(function(p) {
                var cost = parseFloat(p.cost) || 0;
                var stock = p.trackStock === false ? '∞' : String(p.qty != null ? p.qty : 0);
                var card = document.createElement('div');
                card.className = 'unified-product-card p-card txn-product-card txn-product-card--waste';
                card.setAttribute('data-product-id', String(p.id));
                card.setAttribute('data-sale-unit', unit);
                card.innerHTML =
                    '<div class="unified-card-header"><div class="unified-card-icon"><i class="fas ' + cardIcon + '"></i></div><div class="unified-card-barcode">' + escapeHtml((p.barcode || '').substring(0, 12) || '---') + '</div></div>' +
                    '<div class="unified-card-name">' + escapeHtml(p.name || 'ئایتم') + '</div>' +
                    '<div class="unified-card-price">' + escapeHtml(wasteMsg('waste_th_stock', 'کۆگەه') + ': ' + stock) + (cost ? (' · ' + formatCurrency(cost)) : '') + '</div>' +
                    '<div class="unified-card-cta"><i class="fas fa-trash-alt"></i> ' + escapeHtml(ctaShort) + '</div>';
                frag.appendChild(card);
            });
            grid.innerHTML = '';
            grid.appendChild(frag);
        }
        window.renderWasteMenu = renderWasteMenu;

        window.debouncedRenderWasteMenu = function debouncedRenderWasteMenu(q) {
            if (wasteMenuTimeout) clearTimeout(wasteMenuTimeout);
            var ms = (typeof posTxnMenuDebounceMs === 'function') ? posTxnMenuDebounceMs() : 80;
            var s = String(q || '').trim();
            if (/^\d{4,}$/.test(s)) ms = 220;
            wasteMenuTimeout = setTimeout(function() {
                if (/^\d{6,}$/.test(String(q || '').trim())) return;
                renderWasteMenu(q);
            }, ms);
        };

        window.handleWasteBarcode = function handleWasteBarcode(e) {
            if (!e || e.key !== 'Enter') return;
            e.preventDefault();
            if (wasteMenuTimeout) clearTimeout(wasteMenuTimeout);
            var inp = e.target || document.getElementById('waste-barcode-input-main');
            var code = inp ? String(inp.value || '').trim() : '';
            if (!code) return;
            var p = wasteFindProductByBarcode(code);
            if (!p && typeof window.productMatchesBarcodeOrNameSearch === 'function') {
                var hits = (db.products || []).filter(function(x) { return window.productMatchesBarcodeOrNameSearch(x, code); });
                if (hits.length === 1) p = hits[0];
            }
            if (!p) {
                var msg = wasteMsg('waste_alert_not_found', 'ئایتم نەهاتە دیتن!');
                if (typeof showToast === 'function') showToast('⚠️ ' + msg, 'error');
                if (inp) inp.select();
                return;
            }
            addToWasteCart(p.id, wasteSelectedUnit);
            if (inp) inp.value = '';
            renderWasteMenu('');
            if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('waste', { clear: true, delay: 0 });
        };

        window.addToWasteCart = function addToWasteCart(pid, unitOverride) {
            if (typeof isWorkspaceViewActive === 'function' && !isWorkspaceViewActive('waste')) return;
            var p = (db.products || []).find(function(x) { return String(x.id) === String(pid); });
            if (!p) return;
            var unit = (unitOverride === 'carton' || unitOverride === 'pack' || unitOverride === 'piece') ? unitOverride : (wasteSelectedUnit || 'piece');
            if (typeof resolveSmartUnitForProduct === 'function') {
                var smart = resolveSmartUnitForProduct(p, unit, true);
                unit = smart.unit || unit;
            }
            var addPieces = wasteUnitToPieces(p, unit, 1);
            if (addPieces <= 0) addPieces = 1;
            var avail = wasteAvailableStock(p);
            if (p.trackStock !== false && avail + 0.0001 < addPieces) {
                var msgQty = wasteMsg('waste_alert_qty_too_high', 'ژمارە ژ مەخزەنی مەزنترە!');
                if (typeof showToast === 'function') showToast('⚠️ ' + msgQty, 'error');
                return;
            }
            var existing = wasteCart.find(function(row) {
                return Number(row.productId) === Number(p.id) && (row.unit || 'piece') === unit;
            });
            if (existing) {
                var next = (parseFloat(existing.qtyPieces) || 0) + addPieces;
                if (p.trackStock !== false && next > (parseFloat(p.qty) || 0) + 0.0001) {
                    var msg2 = wasteMsg('waste_alert_qty_too_high', 'ژمارە ژ مەخزەنی مەزنترە!');
                    if (typeof showToast === 'function') showToast('⚠️ ' + msg2, 'error');
                    return;
                }
                existing.qtyPieces = next;
                existing.qtyUnits = (parseFloat(existing.qtyUnits) || 0) + 1;
            } else {
                wasteCart.push({
                    productId: p.id,
                    productName: p.name || '',
                    barcode: p.barcode || '',
                    unit: unit,
                    qtyUnits: 1,
                    qtyPieces: addPieces,
                    costPerPiece: parseFloat(p.cost) || 0,
                    productRef: p
                });
            }
            renderWasteCart();
            if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('waste', { clear: true, delay: 0 });
            if (typeof window.updateTxnPeekBar === 'function') window.updateTxnPeekBar('waste');
        };

        window.clearWasteCart = function clearWasteCart() {
            wasteCart = [];
            renderWasteCart();
            if (typeof window.updateTxnPeekBar === 'function') window.updateTxnPeekBar('waste');
        };

        window.wasteCartPickReason = function wasteCartPickReason(btn) {
            if (!btn) return;
            document.querySelectorAll('#waste-cart-reason-chips .pos-waste-reason-chip').forEach(function(c) { c.classList.remove('is-active'); });
            btn.classList.add('is-active');
            var inp = document.getElementById('waste-cart-reason-input');
            if (!inp) return;
            var reason = btn.getAttribute('data-reason') || '';
            var isOther = reason === '__other__' || reason === 'دی';
            if (isOther) {
                inp.classList.remove('is-hidden');
                inp.setAttribute('aria-hidden', 'false');
                if (!inp.value || inp.value === 'بەسەرچوون' || inp.value === 'شکان' || inp.value === 'خراپی' || inp.value === 'دی' || inp.value === '__other__') {
                    inp.value = '';
                }
                try { inp.focus(); } catch (_eF) {}
            } else {
                inp.classList.add('is-hidden');
                inp.setAttribute('aria-hidden', 'true');
                inp.value = reason || (btn.textContent || '').trim();
            }
        };

        window.updateWasteCartQty = function updateWasteCartQty(idx, delta) {
            idx = parseInt(idx, 10);
            if (!wasteCart[idx]) return;
            var row = wasteCart[idx];
            var p = row.productRef || (db.products || []).find(function(x) { return Number(x.id) === Number(row.productId); });
            var step = wasteUnitToPieces(p || {}, row.unit || 'piece', 1) || 1;
            var next = (parseFloat(row.qtyPieces) || 0) + (delta * step);
            if (next <= 0) {
                wasteCart.splice(idx, 1);
                renderWasteCart();
                return;
            }
            if (p && p.trackStock !== false) {
                var max = parseFloat(p.qty) || 0;
                var others = wasteCartCommittedPieces(row.productId, idx);
                if (next + others > max + 0.0001) {
                    var msg = wasteMsg('waste_alert_qty_too_high', 'ژمارە ژ مەخزەنی مەزنترە!');
                    if (typeof showToast === 'function') showToast('⚠️ ' + msg, 'error');
                    return;
                }
            }
            row.qtyPieces = next;
            row.qtyUnits = (parseFloat(row.qtyUnits) || 0) + delta;
            if (row.qtyUnits < 1) row.qtyUnits = 1;
            renderWasteCart();
        };

        window.removeWasteCartRow = function removeWasteCartRow(idx) {
            idx = parseInt(idx, 10);
            if (!wasteCart[idx]) return;
            wasteCart.splice(idx, 1);
            renderWasteCart();
        };

        function renderWasteCart() {
            var wrap = document.getElementById('waste-bill-rows');
            var totalEl = document.getElementById('waste-bill-total');
            if (!wrap) return;
            var total = 0;
            if (!wasteCart.length) {
                wrap.innerHTML = '<div class="txn-cart-empty" style="padding:24px; text-align:center; color:var(--text-muted);">' +
                    '<i class="fas fa-trash-alt" style="font-size:2rem; opacity:0.45; display:block; margin-bottom:8px;"></i>' +
                    escapeHtml(wasteMsg('waste_cart_empty', 'سەبەتە بەتاڵە — سکان بکە یان کاڵایێ هەلبژێرە')) + '</div>';
                if (totalEl) totalEl.textContent = formatCurrency(0);
                if (typeof window.updateTxnPeekBar === 'function') window.updateTxnPeekBar('waste');
                return;
            }
            wrap.innerHTML = wasteCart.map(function(row, idx) {
                var line = (parseFloat(row.qtyPieces) || 0) * (parseFloat(row.costPerPiece) || 0);
                total += line;
                var u = row.unit || 'piece';
                var unitIcon = u === 'carton'
                    ? '<i class="fas fa-box returns-unit-icon returns-unit-karton" aria-hidden="true"></i>'
                    : (u === 'pack'
                        ? '<i class="fas fa-boxes returns-unit-icon returns-unit-pakit" aria-hidden="true"></i>'
                        : '<i class="fas fa-cube returns-unit-icon returns-unit-tak" aria-hidden="true"></i>');
                var unitLbl = (typeof getProductUnitLabel === 'function')
                    ? getProductUnitLabel(row.productRef || { name: row.productName }, u)
                    : u;
                var qtyShow = (parseFloat(row.qtyUnits) > 0 && u !== 'piece')
                    ? (String(row.qtyUnits) + ' ' + unitLbl)
                    : String(row.qtyPieces);
                return '<div class="returns-cart-row returns-cart-row-slim waste-cart-row">' +
                    '<span class="returns-row-name" title="' + escapeHtml(row.productName || '') + '">' + unitIcon +
                    '<span class="returns-row-name-txt">' + escapeHtml(row.productName || '') + '</span></span>' +
                    '<span class="returns-row-price waste-cart-cost">' + formatCurrency(row.costPerPiece || 0) + '</span>' +
                    '<div class="returns-row-qty-wrap">' +
                    '<button type="button" onclick="updateWasteCartQty(' + idx + ',-1)" aria-label="-"><i class="fas fa-minus"></i></button>' +
                    '<span class="waste-cart-qty-val" title="' + escapeHtml(String(row.qtyPieces) + ' دانە') + '">' + escapeHtml(qtyShow) + '</span>' +
                    '<button type="button" onclick="updateWasteCartQty(' + idx + ',1)" aria-label="+"><i class="fas fa-plus"></i></button>' +
                    '</div>' +
                    '<span class="returns-row-total">' + formatCurrency(line) + '</span>' +
                    '<button type="button" class="returns-row-del" onclick="removeWasteCartRow(' + idx + ')" title="سڕینەوە"><i class="fas fa-times"></i></button>' +
                    '</div>';
            }).join('');
            if (totalEl) totalEl.textContent = formatCurrency(total);
            if (typeof window.updateTxnPeekBar === 'function') window.updateTxnPeekBar('waste');
        }
        window.renderWasteCart = renderWasteCart;

        function getWasteCartReason() {
            var active = document.querySelector('#waste-cart-reason-chips .pos-waste-reason-chip.is-active');
            var dataReason = active ? (active.getAttribute('data-reason') || '') : '';
            var inp = document.getElementById('waste-cart-reason-input');
            if (dataReason === '__other__' || dataReason === 'دی') {
                var custom = inp ? String(inp.value || '').trim() : '';
                return custom || wasteMsg('waste_reason_other', 'هۆکارێ تر');
            }
            if (dataReason) return dataReason;
            var reason = inp ? String(inp.value || '').trim() : '';
            return reason || wasteModalDefaultReason();
        }

        window.processWasteCart = async function processWasteCart() {
            if (_wasteSubmitting) return;
            if (!wasteCart.length) {
                var emptyMsg = wasteMsg('waste_cart_empty', 'سەبەتە بەتاڵە');
                if (typeof showToast === 'function') showToast('⚠️ ' + emptyMsg, 'error');
                return;
            }
            var reason = getWasteCartReason();
            var btn = document.getElementById('waste-confirm-btn');
            _wasteSubmitting = true;
            if (btn) btn.disabled = true;
            var okCount = 0;
            var lastId = 0;
            var errMsg = '';
            try {
                for (var i = 0; i < wasteCart.length; i++) {
                    var row = wasteCart[i];
                    var p = row.productRef || (db.products || []).find(function(x) { return Number(x.id) === Number(row.productId); });
                    if (!p) continue;
                    var qty = parseFloat(row.qtyPieces) || 0;
                    if (qty <= 0) continue;
                    var formData = new FormData();
                    formData.append('action', 'save_waste');
                    formData.append('prodId', p.id);
                    formData.append('qty', qty);
                    formData.append('reason', reason);
                    formData.append('user', currentUser ? currentUser.name : 'System');
                    var res = await fetch('?action=save_waste', { method: 'POST', body: formData, credentials: 'same-origin' });
                    var data = await res.json();
                    if (!data || data.status !== 'success') {
                        errMsg = wasteSaveErrorToast(data || {});
                        break;
                    }
                    var wasteId = parseInt(data.id, 10) || 0;
                    lastId = wasteId || lastId;
                    if (p.trackStock !== false) p.qty = (parseFloat(p.qty) || 0) - qty;
                    db.waste = db.waste || [];
                    db.waste.push({
                        id: wasteId || data.id,
                        prodId: p.id,
                        prodName: p.name,
                        qty: qty,
                        cost: (parseFloat(p.cost) || 0) * qty,
                        reason: reason,
                        date: new Date(),
                        user: currentUser ? currentUser.name : 'System',
                        fx_usd_rate: data.fx_usd_rate != null ? data.fx_usd_rate : (db.settings && db.settings.usdRate),
                        fx_currency_mode: data.fx_currency_mode || (db.settings && db.settings.currencyMode) || null,
                        transaction_id: data.transaction_id || null
                    });
                    okCount++;
                }
            } catch (err) {
                errMsg = (err && err.message) ? err.message : wasteMsg('waste_err_save', 'هەڵە');
            }
            _wasteSubmitting = false;
            if (btn) btn.disabled = false;
            if (okCount > 0) {
                wasteCart = [];
                renderWasteCart();
                renderWasteMenu((document.getElementById('waste-barcode-input-main') || {}).value || '');
                renderWasteList();
                renderWasteCandidates();
                if (typeof updateStats === 'function') updateStats();
                var ok = okCount === 1
                    ? wasteSavedToast(lastId)
                    : wasteMsg('waste_toast_saved_multi', '✅ {n} تەلەف هاتنە تۆمارکرن.', { n: okCount });
                if (typeof showToast === 'function') showToast(ok, 'success');
                if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('waste', { clear: true, delay: 40 });
            }
            if (errMsg) {
                if (typeof showToast === 'function') showToast('❌ ' + errMsg, 'error');
            }
        };

        window.openWasteHistoryPanel = function openWasteHistoryPanel(mode) {
            var panel = document.getElementById('waste-history-panel');
            if (!panel) return;
            var hist = document.getElementById('waste-history-section');
            var exp = document.getElementById('waste-expiry-section');
            var title = document.getElementById('waste-history-panel-title');
            var showExpiry = mode === 'expiry';
            if (hist) hist.classList.toggle('is-hidden', showExpiry);
            if (exp) exp.classList.toggle('is-hidden', !showExpiry);
            if (title) {
                title.innerHTML = showExpiry
                    ? '<i class="fas fa-exclamation-triangle"></i> ' + escapeHtml(wasteMsg('waste_expiry_section_title', 'ئایتمێن بەسەرچووی'))
                    : '<i class="fas fa-history"></i> ' + escapeHtml(wasteMsg('waste_log_title', 'مێژوویا تەلەف بوونێ'));
            }
            panel.classList.remove('is-hidden');
            panel.setAttribute('aria-hidden', 'false');
            if (showExpiry) renderWasteCandidates();
            else renderWasteList();
        };

        window.closeWasteHistoryPanel = function closeWasteHistoryPanel() {
            var panel = document.getElementById('waste-history-panel');
            if (!panel) return;
            panel.classList.add('is-hidden');
            panel.setAttribute('aria-hidden', 'true');
        };

        window.initWasteScreen = function initWasteScreen() {
            if (!db) return;
            renderWasteCategories();
            renderWasteMenu((document.getElementById('waste-barcode-input-main') || {}).value || '');
            renderWasteCart();
            renderWasteList();
            renderWasteCandidates();
            if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('waste', { clear: false, delay: 60 });
            if (typeof applyI18nSubtree === 'function') {
                var root = document.getElementById('view-waste');
                if (root) applyI18nSubtree(root);
            }
        };

        function applyWasteModalLanguage() {
            var modal = document.getElementById('waste-report-modal');
            if (!modal || typeof t !== 'function') return;
            modal.querySelectorAll('[data-i18n]').forEach(function(el) {
                var key = el.getAttribute('data-i18n');
                if (!key) return;
                var v = t(key);
                if (v && v !== key) el.textContent = v;
            });
            modal.querySelectorAll('.pos-waste-reason-chip[data-i18n]').forEach(function(chip) {
                var key = chip.getAttribute('data-i18n');
                var v = t(key);
                if (v && v !== key) chip.setAttribute('data-reason', v);
            });
        }

        function wasteModalDefaultReason() {
            return wasteMsg('waste_prompt_reason_default', 'بەسەرچوون');
        }

        function wasteModalResetReasonChips(reason) {
            var def = reason || wasteModalDefaultReason();
            var chips = document.querySelectorAll('.pos-waste-reason-chip');
            chips.forEach(function(chip) {
                var r = chip.getAttribute('data-reason') || '';
                chip.classList.toggle('is-active', r === def);
            });
            var inp = document.getElementById('waste-reason-input');
            if (inp) inp.value = def;
        }

        window.closeWasteReportModal = function closeWasteReportModal() {
            var modal = document.getElementById('waste-report-modal');
            if (modal) modal.style.display = 'none';
            _wasteModalProduct = null;
        };

        function wasteModalShowForm(show) {
            var form = document.getElementById('waste-form-step');
            var saveBtn = document.getElementById('waste-save-btn');
            if (form) form.classList.toggle('is-hidden', !show);
            if (saveBtn) saveBtn.classList.toggle('is-hidden', !show);
        }

        function wasteModalSelectProduct(p) {
            if (!p) return;
            _wasteModalProduct = p;
            var idEl = document.getElementById('waste-selected-prod-id');
            if (idEl) idEl.value = String(p.id);
            var nameEl = document.getElementById('waste-product-name');
            var bcEl = document.getElementById('waste-product-barcode');
            var stockEl = document.getElementById('waste-product-stock');
            if (nameEl) nameEl.textContent = p.name || '—';
            if (bcEl) bcEl.textContent = p.barcode || '—';
            if (stockEl) stockEl.textContent = String(p.qty != null ? p.qty : 0);
            var qtyEl = document.getElementById('waste-qty-input');
            if (qtyEl) {
                qtyEl.value = '1';
                qtyEl.max = String(Math.max(1, parseInt(p.qty, 10) || 1));
            }
            wasteModalResetReasonChips(wasteModalDefaultReason());
            wasteModalValidateQty();
            wasteModalShowForm(true);
            var hint = document.getElementById('waste-modal-hint');
            if (hint) hint.textContent = wasteMsg('waste_modal_product_hint', 'ژمارە و هۆکار بنووسە، پاشان تۆمار بکە.');
        }

        window.openWasteReportModal = function openWasteReportModal(opts) {
            opts = opts || {};
            var modal = document.getElementById('waste-report-modal');
            if (!modal) return;
            _wasteModalProduct = null;
            var barcodeStep = document.getElementById('waste-barcode-step');
            var bcInput = document.getElementById('waste-barcode-input');
            var hint = document.getElementById('waste-modal-hint');
            if (bcInput) bcInput.value = '';
            wasteModalShowForm(false);
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
            applyWasteModalLanguage();
            if (opts.prodId) {
                var p = db.products.find(function(x) { return Number(x.id) === Number(opts.prodId); });
                if (!p) return;
                if (barcodeStep) barcodeStep.classList.add('is-hidden');
                if (hint) hint.textContent = wasteMsg('waste_modal_product_hint', 'ژمارە و هۆکار بنووسە، پاشان تۆمار بکە.');
                wasteModalSelectProduct(p);
                modal.style.display = 'flex';
                setTimeout(function() {
                    var qtyEl = document.getElementById('waste-qty-input');
                    if (qtyEl) { qtyEl.focus(); qtyEl.select(); }
                }, 80);
                return;
            }
            if (barcodeStep) barcodeStep.classList.remove('is-hidden');
            if (hint) hint.textContent = wasteMsg('waste_prompt_barcode', 'بارکۆدێ ئایتمی سکان بکە یان بنڤیسە:');
            modal.style.display = 'flex';
            setTimeout(function() {
                if (bcInput) { bcInput.focus(); bcInput.select(); }
            }, 80);
        };

        window.wasteModalLookupBarcode = function wasteModalLookupBarcode() {
            var bcInput = document.getElementById('waste-barcode-input');
            var code = bcInput ? bcInput.value : '';
            var p = wasteFindProductByBarcode(code);
            if (!p) {
                var msg = wasteMsg('waste_alert_not_found', 'ئایتم نەهاتە دیتن!');
                if (typeof showToast === 'function') showToast('⚠️ ' + msg, 'error');
                else alert(msg);
                if (bcInput) bcInput.select();
                return;
            }
            wasteModalSelectProduct(p);
            setTimeout(function() {
                var qtyEl = document.getElementById('waste-qty-input');
                if (qtyEl) { qtyEl.focus(); qtyEl.select(); }
            }, 60);
        };

        window.wasteModalAdjustQty = function wasteModalAdjustQty(delta) {
            var qtyEl = document.getElementById('waste-qty-input');
            if (!qtyEl) return;
            var n = parseInt(qtyEl.value, 10) || 0;
            n += delta;
            if (n < 1) n = 1;
            qtyEl.value = String(n);
            wasteModalValidateQty();
        };

        window.wasteModalValidateQty = function wasteModalValidateQty() {
            var qtyEl = document.getElementById('waste-qty-input');
            var errEl = document.getElementById('waste-qty-error');
            var saveBtn = document.getElementById('waste-save-btn');
            if (!qtyEl || !_wasteModalProduct) return true;
            var qty = parseInt(qtyEl.value, 10);
            var max = parseInt(_wasteModalProduct.qty, 10) || 0;
            var bad = !isFinite(qty) || qty <= 0 || qty > max;
            if (errEl) {
                errEl.textContent = bad ? wasteMsg('waste_alert_qty_too_high', 'ژمارە ژ مەخزەنی مەزنترە!') : '';
                errEl.classList.toggle('is-hidden', !bad);
            }
            if (saveBtn) saveBtn.disabled = bad;
            return !bad;
        };

        window.wasteModalPickReason = function wasteModalPickReason(btn) {
            if (!btn) return;
            document.querySelectorAll('.pos-waste-reason-chip').forEach(function(c) { c.classList.remove('is-active'); });
            btn.classList.add('is-active');
            var inp = document.getElementById('waste-reason-input');
            if (inp) inp.value = btn.getAttribute('data-reason') || btn.textContent.trim();
        };

        function submitWasteRecord(p, qty, reason) {
            if (!p || qty <= 0) return;
            var formData = new FormData();
            formData.append('action', 'save_waste');
            formData.append('prodId', p.id);
            formData.append('qty', qty);
            formData.append('reason', reason);
            formData.append('user', currentUser ? currentUser.name : 'System');
            fetch('?action=save_waste', { method: 'POST', body: formData })
            .then(function(res) { return res.json(); })
            .then(function(data) {
                if (data.status === 'success') {
                    var wasteId = parseInt(data.id, 10) || 0;
                    if (p.trackStock) p.qty -= qty;
                    db.waste.push({
                        id: wasteId || data.id,
                        prodId: p.id,
                        prodName: p.name,
                        qty: qty,
                        cost: p.cost * qty,
                        reason: reason,
                        date: new Date(),
                        user: currentUser ? currentUser.name : 'System',
                        fx_usd_rate: data.fx_usd_rate != null ? data.fx_usd_rate : (db.settings && db.settings.usdRate),
                        fx_currency_mode: data.fx_currency_mode || (db.settings && db.settings.currencyMode) || null,
                        transaction_id: data.transaction_id || null
                    });
                    var ok = wasteSavedToast(wasteId || data.id);
                    if (typeof showToast === 'function') showToast(ok, 'success');
                    else alert(ok);
                    closeWasteReportModal();
                    renderWasteList();
                    renderWasteCandidates();
                    if (typeof updateStats === 'function') updateStats();
                } else {
                    var err = wasteSaveErrorToast(data);
                    if (typeof showToast === 'function') showToast('❌ ' + err, 'error');
                    else alert('❌ ' + err);
                }
            })
            .catch(function(err) {
                if (typeof showToast === 'function') showToast('❌ ' + (err.message || wasteMsg('waste_err_save', 'هەڵە')), 'error');
            });
        }

        window.saveWasteFromModal = function saveWasteFromModal() {
            if (!_wasteModalProduct) return;
            var qtyEl = document.getElementById('waste-qty-input');
            var reasonEl = document.getElementById('waste-reason-input');
            if (!wasteModalValidateQty()) return;
            var qty = parseInt(qtyEl && qtyEl.value, 10);
            var reason = (reasonEl && reasonEl.value) ? reasonEl.value.trim() : wasteModalDefaultReason();
            if (!reason) reason = wasteModalDefaultReason();
            submitWasteRecord(_wasteModalProduct, qty, reason);
        };

        function promptReportWaste() {
            if (typeof nav === 'function') {
                var view = document.getElementById('view-waste');
                if (!view || !view.classList.contains('active')) nav('waste');
            }
            if (typeof initWasteScreen === 'function') initWasteScreen();
            else if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('waste', { clear: true, delay: 80 });
        }
        window.promptReportWaste = promptReportWaste;

        function renderWasteList() {
            if (typeof ensureDateFilterToday === 'function') ensureDateFilterToday('waste');
            const tbody = document.getElementById('waste-list-body');
            if (!tbody) return;
            if(!db.waste) db.waste = [];

            const totalAll = db.waste.length;
            const sorted = db.waste.filter(w => isDateInScope(w.date, 'waste')).sort((a,b) => new Date(b.date) - new Date(a.date));
            var emptyMsg = (typeof t === 'function') ? t('waste_empty_log') : 'چ تەلەف نینن.';
            var startEl = document.getElementById('date-start-waste');
            var endEl = document.getElementById('date-end-waste');
            var hasFilter = !!(startEl && startEl.value) || !!(endEl && endEl.value);
            if (sorted.length === 0) {
                if (hasFilter && totalAll > 0) {
                    emptyMsg = wasteMsg('waste_empty_filter', 'لەم بەروارەدا تەلەف نییە — {total} تۆمار لە گشتی هەن. فلتەر پاک بکە (✕).', { total: totalAll });
                } else if (totalAll === 0 && typeof posIsFinancialDataReady === 'function' && !posIsFinancialDataReady()) {
                    emptyMsg = wasteMsg('waste_loading', 'بارکردن... تکایە چاوەڕێ بکە.');
                }
            }
            var dl = typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ';

            if(sorted.length === 0) {
                tbody.innerHTML = '<tr><td colspan="8" style="text-align:center; padding:20px; color:var(--text-muted);">' + escapeHtml(emptyMsg) + '</td></tr>';
                var hintEl = document.getElementById('waste-filter-hint');
                if (hintEl) {
                    if (hasFilter && totalAll > 0) {
                        hintEl.textContent = wasteMsg('waste_filter_active', 'فلتەر چالاکە — ✕ بگرە بۆ بینینی هەموو');
                        hintEl.classList.remove('is-hidden');
                    } else {
                        hintEl.textContent = '';
                        hintEl.classList.add('is-hidden');
                    }
                }
                return;
            }

            var hintElShow = document.getElementById('waste-filter-hint');
            if (hintElShow) {
                if (hasFilter && totalAll > sorted.length) {
                    hintElShow.textContent = wasteMsg('waste_filter_showing', '{shown} لە {total} تۆمار', { shown: sorted.length, total: totalAll });
                    hintElShow.classList.remove('is-hidden');
                } else {
                    hintElShow.textContent = '';
                    hintElShow.classList.add('is-hidden');
                }
            }

            var undoLbl = wasteMsg('waste_undo_btn', 'گەڕاندنەوە');
            var canUndo = canUndoWaste();

            tbody.innerHTML = sorted.slice(0, 100).map(w => `
                <tr>
                    <td><b>#${escapeHtml(w.id != null ? w.id : '—')}</b></td>
                    <td><b>${escapeHtml(w.prodName)}</b></td>
                    <td style="color:red; font-weight:bold; direction:ltr;">-${w.qty}</td>
                    <td>${(typeof formatFrozenIqdAmount === 'function') ? formatFrozenIqdAmount(w, w.cost) : formatCurrency(w.cost)}</td>
                    <td>${escapeHtml(w.reason)}</td>
                    <td>${escapeHtml(w.user || '-')}</td>
                    <td style="font-size:0.85rem;">${new Date(w.date).toLocaleString(dl)}</td>
                    <td>${canUndo && w.id ? '<button type="button" class="btn btn-sm btn-dark" onclick="undoWaste(' + parseInt(w.id, 10) + ')" title="' + escapeHtml(undoLbl) + '"><i class="fas fa-undo"></i></button>' : '<span style="color:var(--text-muted);">—</span>'}</td>
                </tr>
            `).join('');
        }

        function renderWasteCandidates() {
            const container = document.getElementById('waste-candidates-body');
            if (!container) return;
            const today = new Date();
            
            // Filter items expiring in < 60 days or already expired
            const candidates = db.products.filter(p => {
                if (!p.trackStock || p.qty <= 0) return false;
                if (typeof productCatalogExpiryDaysLeft !== 'function') return false;
                const days = productCatalogExpiryDaysLeft(p);
                return days != null && days <= 60;
            }).sort((a, b) => {
                var da = productCatalogExpiryDaysLeft(a);
                var dbd = productCatalogExpiryDaysLeft(b);
                return (da == null ? 99999 : da) - (dbd == null ? 99999 : dbd);
            });

            var emptyCand = (typeof t === 'function') ? t('waste_empty_candidates') : 'چ ئایتمێن بەسەرچووی نینن.';
            var btnW = (typeof t === 'function') ? t('waste_btn_row_waste') : 'تەلەف';
            var tplExp = function(n) {
                var s = (typeof t === 'function') ? String(t('waste_tpl_expired') || '') : 'بەسەرچوویە ({n} ڕۆژ)';
                return s.replace(/\{n\}/g, String(n));
            };
            var tplLeft = function(n) {
                var s = (typeof t === 'function') ? String(t('waste_tpl_days_left') || '') : '{n} ڕۆژ ماینە';
                return s.replace(/\{n\}/g, String(n));
            };

            if(candidates.length === 0) {
                container.innerHTML = '<tr><td colspan="5" style="text-align:center; color:var(--text-muted);">' + escapeHtml(emptyCand) + '</td></tr>';
                return;
            }

            container.innerHTML = candidates.map(p => {
                let days = (typeof productCatalogExpiryDaysLeft === 'function') ? productCatalogExpiryDaysLeft(p) : null;
                
                let status;
                if (days === null || Math.abs(days) > 20000) {
                    status = '<span style="color:var(--text-muted);">—</span>';
                } else if (days < 0) {
                    status = `<span style="color:red; font-weight:bold;">${escapeHtml(tplExp(Math.abs(days)))}</span>`;
                } else {
                    status = `<span style="color:orange;">${escapeHtml(tplLeft(days))}</span>`;
                }
                
                return `
                <tr>
                    <td><b>${escapeHtml(p.name || 'ئایتم')}</b><br><small>${escapeHtml(p.barcode || '')}</small></td>
                    <td>${p.qty}</td>
                    <td>${(typeof getProductCatalogExpiryDisplay === 'function') ? getProductCatalogExpiryDisplay(p) : '-'}</td>
                    <td>${status}</td>
                    <td>
                        <button class="btn btn-sm btn-danger" onclick="quickReportWaste(${p.id})"><i class="fas fa-trash-alt"></i> ${escapeHtml(btnW)}</button>
                    </td>
                </tr>`;
            }).join('');
        }

        function quickReportWaste(id) {
            closeWasteHistoryPanel();
            if (typeof addToWasteCart === 'function') addToWasteCart(id, 'piece');
            else openWasteReportModal({ prodId: id });
        }
        window.quickReportWaste = quickReportWaste;

        window.toggleWasteSettings = function toggleWasteSettings() {
            const enabled = document.getElementById('set-enable-waste').checked;
            const navItem = document.getElementById('nav-waste');
            if(navItem) navItem.style.display = enabled ? 'flex' : 'none';
        };

        function updateNavAlerts() {
            const allItems = db.products.filter(p => p.trackStock);
            const outItems = allItems.filter(p => isWarehouseTrueStockout(p));
            const today = new Date();
            const expItems = allItems.filter(p => {
                if (parseFloat(p.qty) <= 0) return false;
                if (typeof productCatalogExpiryDaysLeft !== 'function') return false;
                const days = productCatalogExpiryDaysLeft(p);
                return days != null && days <= 60;
            });
            
            const totalAlerts = outItems.length + expItems.length;
            const navItem = document.querySelector('.nav-item[onclick="nav(\'warehouse\')"]');
            if(navItem) {
                let badge = navItem.querySelector('.nav-badge');
                if(totalAlerts > 0) {
                    if(!badge) { badge = document.createElement('span'); badge.className = 'nav-badge'; badge.style.cssText = 'background:red; color:white; padding:2px 6px; border-radius:10px; font-size:0.7rem; margin-right:auto; float:left;'; navItem.appendChild(badge); }
                    badge.innerText = totalAlerts;
                } else if(badge) { badge.remove(); }
            }
        }

        function checkExpiryPopup() {
            if (sessionStorage.getItem('expiryChecked')) return;
            const today = new Date();
            const expItems = db.products.filter(p => {
                if (!p.trackStock || parseFloat(p.qty) <= 0) return false;
                if (typeof productCatalogExpiryDaysLeft !== 'function') return false;
                const days = productCatalogExpiryDaysLeft(p);
                return days != null && days <= 60;
            });

            if(expItems.length > 0) {
                if (typeof showToast === 'function') {
                    showToast(`⚠️ ئاگەهداربە! ${expItems.length} ئایتم بەرەڤ بەسەرچوونێ دچن، هیڤییە ئاگەهداریێ بپشکنە`, 'warning');
                }
                sessionStorage.setItem('expiryChecked', 'true');
            }
        }

        function checkLowStockPopup() {
            if (sessionStorage.getItem('lowStockChecked')) return;
            const lowItems = db.products.filter(p => p.trackStock && p.qty <= getMinStock(p));

            if(lowItems.length > 0) {
                if (typeof showToast === 'function') {
                    showToast(`⚠️ ئاگەهداریا کێمبوونا مەوادی: ${lowItems.length} ئایتم ل مەخزەنی کێم بووینە`, 'warning');
                }
                sessionStorage.setItem('lowStockChecked', 'true');
            }
        }

