@echo off
chcp 65001 >nul
set HERE=%~dp0
if "%HERE:~-1%"=="\" set HERE=%HERE:~0,-1%
set EXE=%HERE%\LaptopDuhokPOS.exe
set POSDIR=%HERE%\..
if not exist "%EXE%" (
  echo LaptopDuhokPOS.exe نەهاتە دیتن.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%POSDIR%\tools\launcher\Install-DesktopIcon.ps1" -ExePath "%EXE%"
exit /b %ERRORLEVEL%
