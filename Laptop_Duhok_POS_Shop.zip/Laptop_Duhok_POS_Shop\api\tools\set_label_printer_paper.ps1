param(
    [Parameter(Mandatory = $false)][string]$PrinterName = '',
    [Parameter(Mandatory = $false)][double]$WidthMm = 40,
    [Parameter(Mandatory = $false)][double]$HeightMm = 60
)

$ErrorActionPreference = 'Stop'

if ($WidthMm -lt 15) { $WidthMm = 15 }
if ($WidthMm -gt 120) { $WidthMm = 120 }
if ($HeightMm -lt 10) { $HeightMm = 10 }
if ($HeightMm -gt 100) { $HeightMm = 100 }

function Resolve-XprinterName([string]$requested) {
    $all = @(Get-Printer -ErrorAction Stop | ForEach-Object { [string]$_.Name })
    if ([string]::IsNullOrWhiteSpace($requested)) {
        $xp = $all | Where-Object { $_ -match '(?i)xprinter|xp-365' }
        if ($xp) { return @($xp)[-1] }
        return $null
    }
    $requested = $requested.Trim()
    foreach ($n in $all) {
        if ($n -eq $requested) { return $n }
    }
    $base = $requested -replace '\s+#\d+\s*$', ''
    $family = @($all | Where-Object {
        $nl = $_.ToLowerInvariant()
        $bl = $base.ToLowerInvariant()
        ($nl -eq $bl) -or $nl.StartsWith($bl + ' #')
    })
    if ($family.Count -ge 1) {
        return ($family | Sort-Object)[-1]
    }
    $xp = @($all | Where-Object { $_ -match '(?i)xprinter|xp-365' })
    if ($xp.Count -ge 1) { return ($xp | Sort-Object)[-1] }
    throw ("Printer not found in Windows: " + $requested + " / have: " + ($all -join ', '))
}

$printer = Resolve-XprinterName $PrinterName
if ([string]::IsNullOrWhiteSpace($printer)) {
    throw 'Xprinter not found'
}

# Print Schema sizes are microns (1/1000 mm)
$wMicron = [int][Math]::Round($WidthMm * 1000)
$hMicron = [int][Math]::Round($HeightMm * 1000)

$cfg = Get-PrintConfiguration -PrinterName $printer
$ticket = [string]$cfg.PrintTicketXML
if ([string]::IsNullOrWhiteSpace($ticket)) {
    throw 'PrintTicket empty for ' + $printer
}

$xml = New-Object System.Xml.XmlDocument
$xml.PreserveWhitespace = $true
$xml.LoadXml($ticket)

foreach ($n in $xml.SelectNodes("//*[local-name()='ScoredProperty']")) {
    $nm = [string]$n.GetAttribute('name')
    $valNode = $n.SelectSingleNode("*[local-name()='Value']")
    if ($null -eq $valNode) { continue }
    if ($nm -match 'MediaSizeWidth$') { $valNode.InnerText = [string]$wMicron }
    elseif ($nm -match 'MediaSizeHeight$') { $valNode.InnerText = [string]$hMicron }
}

# Use Windows stock size instead of the printer's internal SIZE
$useCur = $xml.SelectNodes("//*[local-name()='Feature' and contains(@name,'JobUseCurrentPrinterSettings')]/*[local-name()='Option']")
if ($useCur -and $useCur.Count -gt 0) {
    $opt = $useCur[0]
    $n = [string]$opt.GetAttribute('name')
    if ($n -match 'OptYes') {
        $opt.SetAttribute('name', ($n -replace 'OptYes', 'OptNo'))
    }
}

$newTicket = $xml.OuterXml
Set-PrintConfiguration -PrinterName $printer -PrintTicketXml $newTicket

$check = Get-PrintConfiguration -PrinterName $printer
Write-Output ("OK printer=" + $printer + " size=" + $WidthMm + "x" + $HeightMm + "mm")
# Echo applied microns for verification
$cx = New-Object System.Xml.XmlDocument
$cx.LoadXml([string]$check.PrintTicketXML)
$wNow = $cx.SelectSingleNode("//*[local-name()='ScoredProperty' and contains(@name,'MediaSizeWidth')]/*[local-name()='Value']")
$hNow = $cx.SelectSingleNode("//*[local-name()='ScoredProperty' and contains(@name,'MediaSizeHeight')]/*[local-name()='Value']")
$useNow = $cx.SelectSingleNode("//*[local-name()='Feature' and contains(@name,'JobUseCurrentPrinterSettings')]/*[local-name()='Option']")
Write-Output ("applied_width_micron=" + $(if ($wNow) { $wNow.InnerText } else { '?' }))
Write-Output ("applied_height_micron=" + $(if ($hNow) { $hNow.InnerText } else { '?' }))
Write-Output ("use_printer_internal=" + $(if ($useNow) { $useNow.GetAttribute('name') } else { '?' }))
