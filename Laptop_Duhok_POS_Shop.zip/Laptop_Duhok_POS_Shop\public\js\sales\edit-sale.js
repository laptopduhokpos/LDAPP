// sales/edit-sale.js — edit sale, POS return mode
        function toggleReturnMode() {
            isReturnMode = !isReturnMode;
            updatePOSModeUI();
            renderBill(); 
        }

        function updatePOSModeUI() {
            const panel = document.getElementById('pos-bill-panel');
            const btn = document.querySelector('#view-pos .btn-sell-large') || document.querySelector('.btn-sell-large');
            const titleEl = document.querySelector('#view-pos .txn-screen-head-title');
            const editing = !!(window._posEditingSale && window._posEditingSale.id);
            
            if(isReturnMode) {
                panel.classList.add('return-mode-active');
                panel.classList.remove('edit-sale-mode-active');
                if(btn) { btn.innerHTML = '<i class="fas fa-undo"></i> Refund (زڤڕاندن)'; btn.style.background = '#ef4444'; }
                if (titleEl) titleEl.textContent = (typeof t === 'function') ? t('returns_screen_title') : 'زڤڕاندن';
                let ind = document.getElementById('return-mode-indicator');
                if(!ind) {
                    ind = document.createElement('div'); ind.id = 'return-mode-indicator';
                    ind.style.cssText = 'background:#ef4444; color:white; text-align:center; padding:5px; font-weight:bold; animation:pulse 2s infinite;';
                    ind.innerText = "⚠️ مۆدێ زڤڕاندنێ (RETURN MODE)";
                    panel.insertBefore(ind, panel.firstChild);
                }
                var editIndRm = document.getElementById('edit-sale-mode-indicator');
                if (editIndRm) editIndRm.remove();
            } else if (editing) {
                panel.classList.remove('return-mode-active');
                panel.classList.add('edit-sale-mode-active');
                var editLbl = (typeof t === 'function') ? t('pos_btn_edit_sale') : 'تەعدیل';
                if (editLbl === 'pos_btn_edit_sale') editLbl = 'تەعدیل';
                if (btn) {
                    btn.innerHTML = '<i class="fas fa-save" aria-hidden="true"></i> <span>' + editLbl + '</span>';
                    btn.style.background = '#0ea5e9';
                    btn.title = editLbl + ' #' + window._posEditingSale.id;
                }
                if (titleEl) {
                    var editTitle = (typeof t === 'function') ? t('pos_edit_sale_title') : 'تەعدیل';
                    if (editTitle === 'pos_edit_sale_title') editTitle = 'تەعدیل';
                    titleEl.textContent = editTitle + ' #' + window._posEditingSale.id;
                }
                const retInd = document.getElementById('return-mode-indicator');
                if (retInd) retInd.remove();
                let eind = document.getElementById('edit-sale-mode-indicator');
                if (!eind && panel) {
                    eind = document.createElement('div');
                    eind.id = 'edit-sale-mode-indicator';
                    eind.style.cssText = 'background:#0ea5e9; color:white; text-align:center; padding:6px 8px; font-weight:bold; font-size:0.9rem;';
                    var dateHint = window._posEditingSale.created_at || window._posEditingSale.date || '';
                    eind.innerHTML = '✏️ ' + escapeHtml((typeof t === 'function') ? t('pos_edit_sale_banner') : 'مۆدێ تەعدیلێ — وەسڵێ کەڤن دێتە نوێکرن، فرۆتنا نوێ نابیت') +
                        ' <span style="opacity:.9">#' + escapeHtml(String(window._posEditingSale.id)) + (dateHint ? ' · ' + escapeHtml(String(dateHint)) : '') + '</span>' +
                        ' <button type="button" class="btn btn-sm" style="margin-right:8px;background:rgba(255,255,255,0.2);color:#fff;border:1px solid rgba(255,255,255,0.4);padding:2px 8px;" onclick="typeof clearPosEditSaleMode===\'function\'&&clearPosEditSaleMode(true)">' +
                        escapeHtml((typeof t === 'function') ? t('pos_edit_sale_cancel') : 'هەلوەشاندن') + '</button>';
                    panel.insertBefore(eind, panel.firstChild);
                } else if (eind) {
                    // refresh text if already present
                }
            } else {
                panel.classList.remove('return-mode-active');
                panel.classList.remove('edit-sale-mode-active');
                if (btn) {
                    var sellLbl = (typeof t === 'function') ? (t('pos_btn_sell') || t('btn_pos_sell')) : 'فروشتن';
                    if (sellLbl === 'pos_btn_sell' || sellLbl === 'btn_pos_sell') sellLbl = 'فروشتن';
                    btn.innerHTML = '<i class="fas fa-cash-register" aria-hidden="true"></i> <span>' + sellLbl + '</span>';
                    btn.style.background = '';
                    btn.title = sellLbl;
                }
                if (titleEl) {
                    var posTitle = (typeof t === 'function') ? t('view_pos_title') : 'فرۆشتن';
                    if (posTitle === 'view_pos_title') posTitle = 'فرۆشتن';
                    titleEl.textContent = posTitle;
                }
                if (typeof window.applyCartDeliverySellLabel === 'function') window.applyCartDeliverySellLabel();
                const ind = document.getElementById('return-mode-indicator');
                if(ind) ind.remove();
                const eind2 = document.getElementById('edit-sale-mode-indicator');
                if (eind2) eind2.remove();
            }
        }

        window.clearPosEditSaleMode = function (clearCart) {
            window._posEditingSale = null;
            if (clearCart) {
                var table = db && db.tables ? db.tables.find(function (t) { return t.id === activeTableId; }) : null;
                if (table) {
                    table.items = [];
                    if (typeof clearPosCartDiscount === 'function') clearPosCartDiscount(table);
                    else delete table.manualDiscount;
                }
                var custEl = document.getElementById('pos-customer-name');
                if (custEl) custEl.value = '';
                var discEl = document.getElementById('pos-discount');
                if (discEl) discEl.value = '';
                lastTableState = '';
                if (typeof onCartChanged === 'function') onCartChanged();
                if (typeof renderBill === 'function') renderBill();
            }
            if (typeof updatePOSModeUI === 'function') updatePOSModeUI();
        };

        /** Map a saved sale line into a POS cart line (same fields as add-to-cart). */
        function saleLineToCartItem(it) {
            var qty = (typeof getItemQty === 'function') ? getItemQty(it) : (parseFloat(it && (it.qty != null ? it.qty : it.count)) || 0);
            var prod = null;
            if (it && it.id != null && db && db.products) {
                prod = db.products.find(function (p) { return String(p.id) === String(it.id); });
            }
            var line = {
                id: it.id,
                name: it.name || (prod ? prod.name : 'ئایتم'),
                price: parseFloat(it.price) || 0,
                cost: it.cost != null ? it.cost : (prod ? prod.cost : 0),
                qty: qty,
                count: qty,
                saleUnit: it.saleUnit || it.sale_unit || 'piece',
                barcode: it.barcode != null ? it.barcode : (prod ? prod.barcode : ''),
                trackStock: it.trackStock != null ? it.trackStock : (prod ? !!prod.trackStock : false),
                pieces_per_pack: it.pieces_per_pack != null ? it.pieces_per_pack : (prod ? prod.pieces_per_pack : 1),
                packs_per_carton: it.packs_per_carton != null ? it.packs_per_carton : (prod ? prod.packs_per_carton : 1),
                itemsPerCarton: it.itemsPerCarton != null ? it.itemsPerCarton : (prod ? prod.itemsPerCarton : 1),
                isManualPrice: true
            };
            if (it.isGift) line.isGift = true;
            if (it.isManualItem) {
                line.isManualItem = true;
                line.trackStock = false;
            }
            if (it.bill_unit_usd != null) line.bill_unit_usd = it.bill_unit_usd;
            if (it.fx_rate_per_one != null && Number(it.fx_rate_per_one) > 0) line.fx_rate_per_one = Number(it.fx_rate_per_one);
            if (it.note) line.note = it.note;
            return line;
        }

        /**
         * Load an existing invoice into the POS basket for editing.
         * Saving will update the same sale id/date — not create a new sale.
         */
        window.startEditSaleInPos = function (saleId) {
            saleId = parseInt(saleId, 10);
            if (!saleId) return;
            var canEdit = (typeof currentUser !== 'undefined' && currentUser && (currentUser.role === 'admin' || currentUser.role === 'manager'))
                || (typeof checkPermission === 'function' && checkPermission('returns_manage'));
            if (!canEdit) {
                if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('pos_edit_sale_denied') : 'دەستکاری قەدەغەیە', 'error');
                return;
            }

            var applySale = function (sale) {
                if (!sale || sale.is_returned) {
                    if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('pos_edit_sale_voided') : 'وەسڵێ ژێبری / زڤڕاندی ناکرێت تەعدیل بکرێت', 'error');
                    return;
                }
                var items = sale.items;
                if (typeof items === 'string') {
                    try { items = JSON.parse(items); } catch (_e) { items = []; }
                }
                if (!Array.isArray(items) || !items.length) {
                    if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('pos_edit_sale_no_items') : 'ئایتم نەهاتنە دیتن', 'error');
                    return;
                }
                if (typeof isReturnMode !== 'undefined' && isReturnMode) {
                    isReturnMode = false;
                }
                if (typeof ensureDefaultCart === 'function') ensureDefaultCart();
                var table = db && db.tables ? db.tables.find(function (t) { return t.id === activeTableId; }) : null;
                if (!table) {
                    if (typeof showToast === 'function') showToast('سەبەتە نەهاتە دیتن', 'error');
                    return;
                }
                if (table.items && table.items.length > 0) {
                    // Replace current cart with the invoice being edited
                    table.items = [];
                }
                table.items = items.map(saleLineToCartItem);
                var frozenSalePerOne = (typeof fxBundleToRatePerOne === 'function')
                    ? fxBundleToRatePerOne(sale.fx_usd_rate)
                    : 0;
                if (!(frozenSalePerOne > 0) && typeof getUsdRatePerOne === 'function') frozenSalePerOne = getUsdRatePerOne();
                if (frozenSalePerOne > 0) {
                    table.items.forEach(function (line) {
                        if (!(Number(line.fx_rate_per_one) > 0)) line.fx_rate_per_one = frozenSalePerOne;
                    });
                }
                var origPiecesByPid = {};
                items.forEach(function (it) {
                    if (!it || it.id == null) return;
                    var prodRef = (db && db.products) ? db.products.find(function (p) { return String(p.id) === String(it.id); }) : null;
                    var pcs = (typeof getPosCartLinePieceCount === 'function')
                        ? getPosCartLinePieceCount(it, prodRef)
                        : (parseFloat(it.qty || it.count) || 0);
                    if (!(pcs > 0)) return;
                    var pk = String(it.id);
                    origPiecesByPid[pk] = (origPiecesByPid[pk] || 0) + pcs;
                });
                var disc = parseFloat(sale.discount) || 0;
                if (disc > 0) {
                    table.manualDiscount = disc;
                } else {
                    delete table.manualDiscount;
                }
                var discEl = document.getElementById('pos-discount');
                if (discEl) discEl.value = '';
                var custEl = document.getElementById('pos-customer-name');
                if (custEl) {
                    var cname = sale.customer || '';
                    if (!cname && sale.customer_id && db && db.customers) {
                        var c = db.customers.find(function (x) { return parseInt(x.id, 10) === parseInt(sale.customer_id, 10); });
                        if (c) cname = c.name;
                    }
                    if (cname && String(cname).toLowerCase() !== 'general') custEl.value = cname;
                    else custEl.value = '';
                }
                window._posEditingSale = {
                    id: parseInt(sale.id, 10),
                    created_at: sale.created_at || sale.date || '',
                    date: sale.date || sale.created_at || '',
                    payment_method: sale.payment_method || 'cash',
                    customer_id: sale.customer_id || 0,
                    customer_type: sale.customer_type || 'customer',
                    discount: disc,
                    total: sale.total,
                    fx_usd_rate: sale.fx_usd_rate != null ? sale.fx_usd_rate : null,
                    originalPiecesByPid: origPiecesByPid
                };
                lastTableState = '';
                var det = document.getElementById('sale-invoice-detail-modal');
                if (det) det.style.display = 'none';
                var shm = document.getElementById('sales-history-modal');
                if (shm) shm.style.display = 'none';
                if (typeof closeCustomerProfile === 'function') closeCustomerProfile();
                else {
                    var cpm = document.getElementById('customer-profile-modal');
                    if (cpm) cpm.style.display = 'none';
                }
                if (typeof closeCompanyProfile === 'function') closeCompanyProfile();
                else {
                    var compProf = document.getElementById('company-profile-modal');
                    if (compProf) compProf.style.display = 'none';
                }
                if (typeof closeCollectDebtModal === 'function') closeCollectDebtModal();
                if (typeof closeDailySummaryDetailSheet === 'function') closeDailySummaryDetailSheet();
                if (typeof closeDailyHistoryModal === 'function') closeDailyHistoryModal();
                else {
                    var dhm = document.getElementById('daily-history-modal');
                    if (dhm) dhm.style.display = 'none';
                }
                if (typeof nav === 'function') nav('pos');
                if (typeof onCartChanged === 'function') onCartChanged();
                if (typeof renderBill === 'function') renderBill();
                if (typeof renderPosTabsUI === 'function') renderPosTabsUI();
                if (typeof updatePOSModeUI === 'function') updatePOSModeUI();
                if (typeof showToast === 'function') {
                    showToast(((typeof t === 'function') ? t('pos_edit_sale_loaded') : 'وەسڵ هاتە بارکرن بۆ تەعدیل') + ' #' + saleId, 'success');
                }
            };

            var local = (typeof findSaleInHistoryPools === 'function') ? findSaleInHistoryPools(saleId) : null;
            if (local && local.items && local.items.length) {
                applySale(local);
                return;
            }
            if (typeof withSaleRecord === 'function') {
                withSaleRecord(saleId, applySale);
            } else if (typeof fetchSaleRecordById === 'function') {
                fetchSaleRecordById(saleId, applySale);
            } else {
                fetch('?action=get_sale_record&id=' + encodeURIComponent(saleId), { credentials: 'same-origin' })
                    .then(function (r) { return r.json(); })
                    .then(function (d) {
                        if (d && (d.sale || d.status === 'ok' || d.id)) applySale(d.sale || d);
                        else if (typeof showToast === 'function') showToast('وەسڵ نەهاتە دیتن', 'error');
                    })
                    .catch(function () {
                        if (typeof showToast === 'function') showToast('وەسڵ نەهاتە دیتن', 'error');
                    });
            }
        };

        window.savePosEditedSale = function () {
            var meta = window._posEditingSale;
            if (!meta || !meta.id) return false;
            if (isProcessingPayment) return true;
            var table = db && db.tables ? db.tables.find(function (t) { return t.id === activeTableId; }) : null;
            if (!table || !table.items || table.items.length === 0) {
                var emptyMsg = (typeof t === 'function') ? t('pos_empty_cart') : 'سەبەتە بەتاڵە!';
                if (typeof showToast === 'function') showToast(emptyMsg, 'error');
                return true;
            }
            if (typeof validatePosItemsNoIllegalZeroPrice === 'function' && !validatePosItemsNoIllegalZeroPrice(table).ok) {
                var zmsg = typeof t === 'function' ? t('pos_zero_price_blocked') : 'لا يمكنك البيع بهذا السعر';
                if (typeof showToast === 'function') showToast(zmsg, 'error');
                return true;
            }

            isProcessingPayment = true;
            var roundM = (typeof roundMoney === 'function') ? roundMoney : function (x) { return Math.round(Number(x) || 0); };
            var subTotal = roundM(table.items.reduce(function (a, b) {
                var u = typeof getBillLineUnitIqd === 'function' ? getBillLineUnitIqd(b) : (parseFloat(b.price) || 0);
                return a + u * ((typeof getItemQty === 'function') ? getItemQty(b) : (parseFloat(b.qty) || 1));
            }, 0));
            var discount = 0;
            if (table.manualDiscount !== undefined && table.manualDiscount !== null) {
                discount = parseFloat(table.manualDiscount) || 0;
            } else {
                var discountInputEl = document.getElementById('pos-discount');
                var discountInput = discountInputEl ? discountInputEl.value : '';
                if (discountInput && !isNaN(discountInput)) {
                    var discountPercent = parseFloat(discountInput);
                    if (discountPercent >= 0 && discountPercent <= 100) {
                        discount = roundM(subTotal * (discountPercent / 100));
                    }
                }
            }
            var itemsToSave = table.items.map(function (it) {
                var qty = (typeof getItemQty === 'function') ? getItemQty(it) : (parseFloat(it.qty) || 0);
                var isGiftLine = typeof isPosCartLineGift === 'function' ? isPosCartLineGift(it) : !!it.isGift;
                var lineIqd = isGiftLine
                    ? (Number(it.price) || 0)
                    : (typeof getBillLineUnitIqd === 'function' ? getBillLineUnitIqd(it) : (parseFloat(it.price) || 0));
                var prod = (db && db.products) ? db.products.find(function (p) { return String(p.id) === String(it.id); }) : null;
                return {
                    id: it.id,
                    name: it.name,
                    qty: qty,
                    count: qty,
                    price: lineIqd,
                    cost: it.cost,
                    saleUnit: it.saleUnit || 'piece',
                    bill_unit_usd: it.bill_unit_usd,
                    fx_rate_per_one: it.fx_rate_per_one,
                    isManualItem: it.isManualItem,
                    isGift: isGiftLine,
                    note: it.note,
                    trackStock: it.trackStock != null ? it.trackStock : (prod ? prod.trackStock : false),
                    barcode: it.barcode != null ? it.barcode : (prod ? prod.barcode : ''),
                    pieces_per_pack: it.pieces_per_pack != null ? it.pieces_per_pack : (prod ? prod.pieces_per_pack : 1),
                    packs_per_carton: it.packs_per_carton != null ? it.packs_per_carton : (prod ? prod.packs_per_carton : 1),
                    itemsPerCarton: it.itemsPerCarton != null ? it.itemsPerCarton : (prod ? prod.itemsPerCarton : 1)
                };
            });

            var formData = new FormData();
            formData.append('action', 'replace_sale_cart');
            formData.append('sale_id', String(meta.id));
            formData.append('items', JSON.stringify(itemsToSave));
            formData.append('discount', String(discount));
            formData.append('user', (typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : 'System');

            var saleIdKeep = meta.id;
            var apiUrl = (typeof window.posRouterUrl === 'function')
                ? window.posRouterUrl('action=replace_sale_cart')
                : '?action=replace_sale_cart';
            fetch(apiUrl, {
                method: 'POST',
                body: formData,
                credentials: 'same-origin'
            })
                .then(function (r) {
                    return r.text().then(function (txt) {
                        var data = null;
                        try { data = JSON.parse(txt); } catch (_e) { data = null; }
                        if (!data) {
                            return { status: 'error', message: (txt && String(txt).slice(0, 180)) || ('HTTP ' + r.status) };
                        }
                        return data;
                    });
                })
                .then(function (data) {
                    isProcessingPayment = false;
                    if (!data || data.status !== 'success') {
                        var errMsg = (data && data.message) ? String(data.message) : 'تەعدیل سەرنەکەوت';
                        if (errMsg.indexOf('stock_not_enough') !== -1) {
                            errMsg = (typeof t === 'function') ? t('pos_edit_sale_stock_err') : 'کۆگا تێر نینە بۆ تەعدیل — ژمارە کەمتر بکە یان کۆگا پڕ بکە';
                        }
                        if (typeof showToast === 'function') showToast(errMsg, 'error');
                        else alert(errMsg);
                        return;
                    }
                    if (typeof applySaleLineEditLocally === 'function' && data.sale) {
                        applySaleLineEditLocally({ sale: data.sale, customer_id: data.customer_id, customer_type: data.customer_type, customer_balance: data.customer_balance });
                    } else if (typeof patchSaleInHistoryPools === 'function' && data.sale) {
                        patchSaleInHistoryPools(saleIdKeep, function (row) {
                            row.total = data.sale.total;
                            row.items = data.sale.items;
                            row.discount = data.sale.discount;
                        });
                    }
                    if (typeof getAllSales === 'function') {
                        try {
                            var pool = getAllSales(true);
                            if (Array.isArray(pool) && data.sale) {
                                var ix = pool.findIndex(function (s) { return parseInt(s.id, 10) === parseInt(saleIdKeep, 10); });
                                if (ix >= 0) {
                                    pool[ix].total = data.sale.total;
                                    pool[ix].items = data.sale.items;
                                    pool[ix].discount = data.sale.discount;
                                }
                            }
                        } catch (_ePool) {}
                    }
                    table.items = [];
                    delete table.manualDiscount;
                    var custEl2 = document.getElementById('pos-customer-name');
                    if (custEl2) custEl2.value = '';
                    var discEl2 = document.getElementById('pos-discount');
                    if (discEl2) discEl2.value = '';
                    window._posEditingSale = null;
                    lastTableState = '';
                    if (typeof onCartChanged === 'function') onCartChanged();
                    if (typeof renderBill === 'function') renderBill();
                    if (typeof updatePOSModeUI === 'function') updatePOSModeUI();
                    if (typeof posInvalidateDailyDetailCache === 'function') posInvalidateDailyDetailCache();
                    if (typeof syncLiveData === 'function') {
                        try { syncLiveData(false); } catch (_eSync) {}
                    }
                    if (typeof posRefreshOpenFinancialScreens === 'function') {
                        try { posRefreshOpenFinancialScreens(); } catch (_e) {}
                    }
                    if (typeof renderSalesHistory === 'function') {
                        try { renderSalesHistory(); } catch (_e2) {}
                    }
                    var okMsg = ((typeof t === 'function') ? t('pos_edit_sale_saved') : 'وەسڵ هاتە تەعدیلکرن') + ' #' + saleIdKeep;
                    if (data.stock_skipped) {
                        okMsg += ' — ' + ((typeof t === 'function') ? t('pos_edit_sale_stock_warn') : 'کۆگا هەموو نەگۆڕا');
                    }
                    if (typeof showToast === 'function') {
                        showToast(okMsg, data.stock_skipped ? 'warning' : 'success');
                    }
                })
                .catch(function (err) {
                    isProcessingPayment = false;
                    var msg = (err && err.message) ? err.message : 'تەعدیل سەرنەکەوت';
                    if (typeof showToast === 'function') showToast(msg, 'error');
                    else alert(msg);
                });
            return true;
        };

        function recalcBulkPrices() {
            const table = db.tables.find(t => t.id === activeTableId);
            if(!table) return;
            
            // Count quantities per product ID and collect unique IDs
            const counts = {};
            const uniqueIds = new Set();
            table.items.forEach(i => {
                if(!counts[i.id]) counts[i.id] = 0;
                counts[i.id]++;
                uniqueIds.add(i.id);
            });
            
            // Build a fast lookup map for products in the cart
            const productMap = new Map();
            uniqueIds.forEach(function (uid) {
                var p = (typeof posGetProductById === 'function') ? posGetProductById(uid) : null;
                if (!p && db.products) p = db.products.find(function (x) { return x.id === uid; });
                if (p) productMap.set(uid, p);
            });
            
            // Update prices based on wholesale rules; respect saleUnit (carton/pack/piece) for unit price
            var rRec = typeof getPosFrozenFxRatePerOne === 'function' ? getPosFrozenFxRatePerOne(null) : (typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0);
            var usdRec = typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD';
            var iqdFromUsdRec = function (usd) {
                if (typeof usdAmountToStoredIqd === 'function') return usdAmountToStoredIqd(usd, rRec);
                return Math.round(usd * rRec);
            };
            table.items.forEach(i => {
                if(i.isManualPrice) return; // Skip manual overrides
                const p = productMap.get(i.id);
                var unitPrice = (p && typeof getPriceForUnit === 'function') ? getPriceForUnit(p, i.saleUnit || 'piece', table) : (p ? (p.price || 0) : 0);
                
                // Only apply wholesale price if the unit is 'piece'
                var wholesaleFeatOn = false;
                if (typeof getJumlaSystemMode === 'function' && getJumlaSystemMode() === 'jumla' &&
                    typeof isJumlaSystemFeatureEnabled === 'function' && isJumlaSystemFeatureEnabled() &&
                    typeof isAlternatePricingActive === 'function' && isAlternatePricingActive(table)) {
                    wholesaleFeatOn = true;
                } else if (typeof isPremiumSettingsFeatureEnabled === 'function') {
                    wholesaleFeatOn = isPremiumSettingsFeatureEnabled('set-enable-wholesale');
                } else {
                    wholesaleFeatOn = (db.settings.enableWholesale === true);
                }
                if(wholesaleFeatOn && p && p.wholesaleQty > 0 && p.wholesalePrice > 0 && (i.saleUnit || 'piece') === 'piece') {
                    if(counts[i.id] >= p.wholesaleQty) {
                        if (usdRec && rRec > 0 && !i.isManualItem) {
                            var wUsd = typeof getCatalogWholesaleBillUnitUsd === 'function' ? getCatalogWholesaleBillUnitUsd(p) : (p.wholesalePrice / rRec);
                            if (wUsd > 0) {
                                i.bill_unit_usd = wUsd;
                                i.price = iqdFromUsdRec(wUsd);
                            } else {
                                i.price = p.wholesalePrice;
                            }
                        } else {
                            i.price = p.wholesalePrice;
                        }
                        i.isWholesale = true;
                    } else {
                        if (usdRec && typeof getCatalogBillUnitUsdAtAdd === 'function' && p && !i.isManualItem) {
                            var bu = getCatalogBillUnitUsdAtAdd(p, i.saleUnit || 'piece', table);
                            if (bu > 0 && rRec > 0) {
                                i.bill_unit_usd = bu;
                                i.price = iqdFromUsdRec(bu);
                            } else {
                                i.price = unitPrice;
                            }
                        } else {
                            i.price = unitPrice;
                        }
                        i.isWholesale = false;
                    }
                } else {
                    // For cartons and packs, always use the unit price
                    if (usdRec && typeof getCatalogBillUnitUsdAtAdd === 'function' && p && !i.isManualItem) {
                        var bu2 = getCatalogBillUnitUsdAtAdd(p, i.saleUnit || 'piece', table);
                        if (bu2 > 0 && rRec > 0) {
                            i.bill_unit_usd = bu2;
                            i.price = iqdFromUsdRec(bu2);
                        } else {
                            i.price = unitPrice;
                        }
                    } else {
                        i.price = unitPrice;
                    }
                    i.isWholesale = false;
                }
            });
        }

        var _recalcBulkTimer = null;
        function scheduleRecalcBulkPrices() {
            if (_recalcBulkTimer) clearTimeout(_recalcBulkTimer);
            _recalcBulkTimer = setTimeout(function () {
                _recalcBulkTimer = null;
                recalcBulkPrices();
                if (typeof renderBillTotal === 'function') renderBillTotal();
            }, 0);
        }
