/**
 * Pure helpers and formatters. Currency helpers use state.db when available.
 */
import { state } from './state.js';

/** YYYY-MM-DD for date inputs — prefer business day when available. */
export function getTodayDateInputValue(d) {
    const base = d instanceof Date ? d : new Date();
    try {
        if (typeof getBusinessDate === 'function') {
            const bd = getBusinessDate(base);
            if (bd && /^\d{4}-\d{2}-\d{2}$/.test(String(bd))) return String(bd);
        }
    } catch (_e) {}
    const pad = (n) => String(n).padStart(2, '0');
    return base.getFullYear() + '-' + pad(base.getMonth() + 1) + '-' + pad(base.getDate());
}

/**
 * If arbitrary from/to date inputs are empty, set both to today.
 * Does not override a range the user already chose.
 */
export function ensureDateInputsToday(fromId, toId) {
    const s = document.getElementById(fromId);
    const e = document.getElementById(toId);
    if (!s || !e) return false;
    if (s.value && e.value) return false;
    const today = getTodayDateInputValue();
    if (!s.value) s.value = today;
    if (!e.value) e.value = today;
    return true;
}

/**
 * If date filter inputs are empty, set both to today so lists stay fast.
 * Does not override a range the user already chose.
 */
export function ensureDateFilterToday(id) {
    return ensureDateInputsToday('date-start-' + id, 'date-end-' + id);
}

export function resetDateFilter(id, callback) {
    const s = document.getElementById('date-start-' + id) || document.getElementById('mega-date-from') || document.getElementById('gph-start');
    const e = document.getElementById('date-end-' + id) || document.getElementById('mega-date-to') || document.getElementById('gph-end');
    
    // Find any associated preset dropdown
    const presets = [
        id + '-history-date-preset',
        id + '-date-preset',
        'sales-history-date-preset',
        'returns-history-date-preset',
        'expenses-history-date-preset',
        'mega-period',
        'gph-date-preset',
        'gprh-date-preset'
    ];
    
    let presetEl = null;
    for (const p of presets) {
        const found = document.getElementById(p);
        if (found) { presetEl = found; break; }
    }

    const today = getTodayDateInputValue();
    if (s) s.value = today;
    if (e) e.value = today;

    if (presetEl) {
        presetEl.value = presetEl.id === 'mega-period' ? 'today' : (presetEl.id.indexOf('date-preset') >= 0 ? 'today' : 'today');
        // Standardize value if needed
        if (presetEl.querySelector('option[value="today"]')) presetEl.value = 'today';
        else if (presetEl.querySelector('option[value="1d"]')) presetEl.value = '1d';
        
        applyGlobalDatePreset(presetEl.value, id, callback);
    } else {
        if (typeof callback === 'function') callback();
    }
}

/** Standardized date preset applier for all history/report screens */
export function applyGlobalDatePreset(preset, prefix, callback) {
    let fromId = 'date-start-' + prefix;
    let toId = 'date-end-' + prefix;
    
    // Special handling for legacy/custom IDs
    if (prefix === 'mega') {
        const check1 = document.getElementById('mega-date-from');
        if (check1) { fromId = 'mega-date-from'; toId = 'mega-date-to'; }
    } else if (prefix === 'gph') {
        const check2 = document.getElementById('gph-start');
        if (check2) { fromId = 'gph-start'; toId = 'gph-end'; }
    } else if (prefix === 'gprh') {
        const check3 = document.getElementById('gprh-start');
        if (check3) { fromId = 'gprh-start'; toId = 'gprh-end'; }
    }

    const s = document.getElementById(fromId);
    const e = document.getElementById(toId);
    if (!s || !e) return;

    const now = new Date();
    const today = getTodayDateInputValue(now);
    let start = today;
    let end = today;

    if (preset === 'today' || preset === '1d') {
        start = today;
        end = today;
    } else if (preset === 'week' || preset === '7d') {
        const d = new Date(now);
        d.setDate(now.getDate() - 7);
        start = getTodayDateInputValue(d);
    } else if (preset === 'month') {
        start = getTodayDateInputValue(new Date(now.getFullYear(), now.getMonth(), 1));
    } else if (preset === '90d') {
        const d = new Date(now);
        d.setDate(now.getDate() - 90);
        start = getTodayDateInputValue(d);
    } else if (preset === '1y') {
        const d = new Date(now);
        d.setFullYear(now.getFullYear() - 1);
        start = getTodayDateInputValue(d);
    } else if (preset === '8y') {
        const d = new Date(now);
        d.setFullYear(now.getFullYear() - 8);
        start = getTodayDateInputValue(d);
    } else if (preset === 'all') {
        start = '2000-01-01';
    }

    if (preset !== 'custom') {
        s.value = start;
        e.value = end;
        s.style.display = 'none';
        e.style.display = 'none';
        
        if (s.parentElement && s.parentElement.classList.contains('mega-stats-filter-label')) s.parentElement.style.display = 'none';
        if (e.parentElement && e.parentElement.classList.contains('mega-stats-filter-label')) e.parentElement.style.display = 'none';

        const labels = s.parentElement.parentElement.querySelectorAll('span, label');
        labels.forEach(l => {
            if (l.id && (l.id.indexOf('lbl-from') >= 0 || l.id.indexOf('lbl-to') >= 0)) l.style.display = 'none';
            if (l.textContent.trim() === 'تا' || l.getAttribute('data-i18n') === 'exp_date_to' || l.getAttribute('data-i18n') === 'waste_date_to') {
                l.style.display = 'none';
            }
        });
    } else {
        s.style.display = 'inline-block';
        e.style.display = 'inline-block';
        
        if (s.parentElement && s.parentElement.classList.contains('mega-stats-filter-label')) s.parentElement.style.display = 'inline-block';
        if (e.parentElement && e.parentElement.classList.contains('mega-stats-filter-label')) e.parentElement.style.display = 'inline-block';

        const labels = s.parentElement.parentElement.querySelectorAll('span, label');
        labels.forEach(l => {
            if (l.id && (l.id.indexOf('lbl-from') >= 0 || l.id.indexOf('lbl-to') >= 0)) l.style.display = 'inline-block';
            if (l.textContent.trim() === 'تا' || l.getAttribute('data-i18n') === 'exp_date_to' || l.getAttribute('data-i18n') === 'waste_date_to') {
                l.style.display = 'inline-block';
            }
        });
    }

    if (typeof callback === 'function') callback();
}

export function isDateInScope(dateStr, id) {
    const sEl = document.getElementById('date-start-' + id);
    const eEl = document.getElementById('date-end-' + id);
    if (!sEl || !eEl) return true;
    let s = sEl.value;
    let e = eEl.value;
    // Empty filter → today only (fast default). User must pick a wider range explicitly.
    if (!s && !e) {
        const today = getTodayDateInputValue();
        s = today;
        e = today;
    } else if (!s && e) {
        s = e;
    } else if (s && !e) {
        e = s;
    }
    const d = parseSQLDate(dateStr);
    if (!d || isNaN(d.getTime())) return true;
    if (s) {
        const sd = parseSQLDate(s + ' 00:00:00');
        if (sd && !isNaN(sd.getTime())) {
            if (d < sd) return false;
        }
    }
    if (e) {
        const ed = parseSQLDate(e + ' 23:59:59');
        if (ed && !isNaN(ed.getTime())) {
            if (d > ed) return false;
        }
    }
    return true;
}

export function normalizeForSearch(str) {
    if (!str) return '';
    return str.toLowerCase().trim()
        .replace(/[\u0627\u0622\u0623\u0625\u0671]/g, 'a')
        .replace(/[\u0626]/g, 'a') /* ئ */
        .replace(/[\u0628]/g, 'b')
        .replace(/[\u067E]/g, 'p')
        .replace(/[\u062A\u0629\u0637]/g, 't')
        .replace(/[\u062C]/g, 'j')
        .replace(/[\u0686]/g, 'ch')
        .replace(/[\u062D\u0647]/g, 'h')
        .replace(/[\u062E]/g, 'x')
        .replace(/[\u062F]/g, 'd')
        .replace(/[\u0631\u0695]/g, 'r')
        .replace(/[\u0632\u0630\u0638\u0636]/g, 'z')
        .replace(/[\u0698]/g, 'zh')
        .replace(/[\u0633\u0635\u062B]/g, 's')
        .replace(/[\u0634]/g, 'sh')
        .replace(/[\u0639]/g, 'a')
        .replace(/[\u063A]/g, 'gh')
        .replace(/[\u0641]/g, 'f')
        .replace(/[\u06A4]/g, 'v')
        .replace(/[\u0642]/g, 'q')
        .replace(/[\u0643\u06A9]/g, 'k')
        .replace(/[\u06AF]/g, 'g')
        .replace(/[\u0644\u06AD]/g, 'l')
        .replace(/[\u0645]/g, 'm')
        .replace(/[\u0646]/g, 'n')
        .replace(/[\u0648\u06C5]/g, 'w')
        .replace(/[\u06C6\u06CA]/g, 'o') /* ۆ ۊ */
        .replace(/[\u064A\u06CC\u0649\u06CE]/g, 'i') /* ی ي ى ێ */
        .replace(/[\u06D0\u06D5]/g, 'e')
        .replace(/u/g, 'w')
        .replace(/y/g, 'i')
        .replace(/ee/g, 'i')
        .replace(/oo/g, 'w');
}

/** IQD per 1 USD from settings (always available for mixed IQD/USD carts). */
export function getFxRatePerOne() {
    if (state.db && state.db.settings) {
        const er = Number(state.db.settings.exchange_rate);
        if (Number.isFinite(er) && er > 0 && er < 10000) return er;
        const n = Number(state.db.settings.usdRate);
        if (Number.isFinite(n) && n > 0) return n >= 100 ? n / 100 : n;
    }
    try {
        const r = localStorage.getItem('pos_usd_rate');
        if (r) {
            const n = parseInt(r, 10);
            if (!isNaN(n) && n > 0) return n >= 100 ? n / 100 : n;
        }
    } catch (e) {}
    return 1500;
}

export function getUsdRatePerOne() {
    return getFxRatePerOne();
}

export function getDefaultCurrency() {
    if (state.db && state.db.settings) {
        const d = String(state.db.settings.defaultCurrency || state.db.settings.default_currency || '').toUpperCase();
        if (d === 'USD' || d === 'IQD') return d;
        const m = String(state.db.settings.currencyMode || '').toUpperCase();
        if (m === 'USD') return 'USD';
        return 'IQD';
    }
    try {
        const ls = localStorage.getItem('pos_default_currency') || localStorage.getItem('pos_currency_mode');
        if (ls === 'USD') return 'USD';
    } catch (e) {}
    return 'IQD';
}

export function getActiveCurrency() {
    return getDefaultCurrency();
}

export function roundIqd(n) {
    const x = Number(n);
    if (!Number.isFinite(x)) return 0;
    return Math.round(x);
}

export function roundUsd(n) {
    const x = Number(n);
    if (!Number.isFinite(x)) return 0;
    return Math.round(x * 100) / 100;
}

/**
 * Single source of truth for IQD <-> USD.
 * Same currency -> exact amount (IQD integer, USD 2 decimals).
 * USD -> IQD -> Math.round(amount * rate) (no decimals).
 * IQD -> USD -> (amount / rate).toFixed(2) (2 decimals).
 */
export function convertCurrency(amount, fromCurrency, toCurrency, rate) {
    const from = String(fromCurrency || 'IQD').toUpperCase() === 'USD' ? 'USD' : 'IQD';
    const to = String(toCurrency || 'IQD').toUpperCase() === 'USD' ? 'USD' : 'IQD';
    const n = Number(amount);
    const a = Number.isFinite(n) ? n : 0;
    let r = Number(rate);
    if (!(r > 0)) {
        try {
            const s = state.db && state.db.settings;
            if (s) {
                const er = Number(s.exchange_rate);
                if (Number.isFinite(er) && er > 0 && er < 10000) r = er;
                else {
                    const usdN = Number(s.usdRate);
                    if (Number.isFinite(usdN) && usdN > 0) r = usdN >= 100 ? usdN / 100 : usdN;
                }
            }
        } catch (_e) {}
    }
    if (from === to) {
        return from === 'USD' ? roundUsd(a) : roundIqd(a);
    }
    if (!(r > 0)) return 0;
    if (from === 'USD' && to === 'IQD') return Math.round(a * r);
    return parseFloat((a / r).toFixed(2));
}

export function usdToIqd(usd, ratePerOne) {
    return convertCurrency(usd, 'USD', 'IQD', ratePerOne);
}

export function iqdToUsd(iqd, ratePerOne) {
    return convertCurrency(iqd, 'IQD', 'USD', ratePerOne);
}

export function formatIqdAmount(n) {
    return roundIqd(n).toLocaleString('en-US', { maximumFractionDigits: 0, minimumFractionDigits: 0 }) + ' IQD';
}

/** USD number with grouping. Whole dollars omit .00; cents always two digits ($12.50). */
export function formatUsdNumberPlain(n) {
    const x = roundUsd(n);
    const neg = x < 0;
    const abs = Math.abs(x);
    const cents = Math.round(abs * 100) % 100;
    const formatted = cents === 0
        ? Math.round(abs).toLocaleString('en-US', { maximumFractionDigits: 0, minimumFractionDigits: 0 })
        : abs.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    return neg && formatted !== '0' ? '-' + formatted : formatted;
}

export function formatUsdAmount(n) {
    return '$' + formatUsdNumberPlain(n);
}

export function formatFxRateDisplay(ratePerOne) {
    const r = Number(ratePerOne) > 0 ? Number(ratePerOne) : getFxRatePerOne();
    const bundle = Math.round(r * 100);
    return '100$ = ' + bundle.toLocaleString('en-US') + ' IQD';
}

/** Screen dual-currency (IQD + USD). Default on; Settings can turn it off. */
export function isShowBothCurrenciesEnabled() {
    try {
        if (state.db && state.db.settings && state.db.settings.showBothCurrencies === false) return false;
    } catch (e) {}
    return true;
}

/** Primary = shop default_currency; secondary = the other currency (blank when dual display is off). */
export function formatDualCurrencyLines(iqd, usd, ratePerOne) {
    const primary = getDefaultCurrency();
    const iqdTxt = formatIqdAmount(iqd);
    const usdTxt = formatUsdAmount(usd);
    const both = isShowBothCurrenciesEnabled();
    const primaryTxt = primary === 'USD' ? usdTxt : iqdTxt;
    const secondaryTxt = primary === 'USD' ? iqdTxt : usdTxt;
    return {
        primary: primaryTxt,
        secondary: both ? secondaryTxt : '',
        rate: both ? formatFxRateDisplay(ratePerOne) : '',
        primaryCurrency: primary,
        iqd: iqdTxt,
        usd: usdTxt,
        showBoth: both
    };
}

export function joinDualCurrencyText(dual) {
    if (!dual) return '';
    if (!dual.secondary) return dual.primary || '';
    return dual.primary + ' · ' + dual.secondary;
}

/**
 * Unified shop display: main amount in default_currency, equivalent in the other.
 * IQD main has no decimals. USD main has 2 decimals.
 * Does not write to the database.
 */
export function formatCanonicalMoney(iqdAmount, usdAmount, ratePerOne) {
    const rate = Number(ratePerOne) > 0 ? Number(ratePerOne) : getUsdRatePerOne();
    const iqd = Number(iqdAmount) || 0;
    let usd = (usdAmount != null && usdAmount !== '' && Number.isFinite(Number(usdAmount)))
        ? Number(usdAmount)
        : convertCurrency(iqd, 'IQD', 'USD', rate);
    const dual = formatDualCurrencyLines(iqd, usd, rate);
    return joinDualCurrencyText(dual);
}

/** Historical IQD amount + frozen row rate (sales, supplies, debts). Prefer stored USD when stamped. */
export function formatTxnMoney(iqdAmount, row) {
    const iqd = Number(iqdAmount) || 0;
    const rate = getPosFrozenFxRatePerOne(row);
    let usd = null;
    if (row && row.total_usd != null && row.total_usd !== '' && Number.isFinite(Number(row.total_usd))) {
        usd = Number(row.total_usd);
    } else {
        usd = storedIqdToUsdDisplayAmount(iqd, row);
    }
    return formatCanonicalMoney(iqd, usd, rate);
}

function inventoryPositiveQty(prod, qtyOverride) {
    const q = Number(qtyOverride != null ? qtyOverride : (prod && prod.qty));
    return Number.isFinite(q) && q > 0 ? q : 0;
}

function inventoryNativeField(prod, keys) {
    if (!prod || !keys || !keys.length) return 0;
    for (let i = 0; i < keys.length; i++) {
        const n = Number(prod[keys[i]]);
        if (Number.isFinite(n) && n > 0) return n;
    }
    for (let i = 0; i < keys.length; i++) {
        const n = Number(prod[keys[i]]);
        if (Number.isFinite(n)) return n;
    }
    return 0;
}

/**
 * Item native currency for warehouse valuation.
 * Explicit `currency` wins; empty falls back to shop default_currency (not base_currency).
 */
export function inventoryItemNativeCurrency(prod) {
    const c = String((prod && prod.currency) || '').toUpperCase();
    if (c === 'USD' || c === 'IQD') return c;
    return getDefaultCurrency() === 'USD' ? 'USD' : 'IQD';
}

export function inventoryNativeUnitIqd(prod, kind) {
    if (kind === 'sell') return inventoryNativeField(prod, ['price', 'base_price']);
    return inventoryNativeField(prod, ['cost_price', 'cost', 'base_cost']);
}

export function inventoryNativeUnitUsd(prod, kind) {
    if (kind === 'sell') return inventoryNativeField(prod, ['price_usd', 'base_price']);
    return inventoryNativeField(prod, ['cost_usd', 'base_cost']);
}

/**
 * Combine native IQD + USD buckets into shop-currency totals.
 * IQD shop: IQD items stay raw; USD items convert once as (sumUsd * rate).
 * USD shop: USD items stay raw; IQD items convert once as (sumIqd / rate).
 */
export function finalizeInventoryValuationBuckets(costIqd, saleIqd, costUsd, saleUsd) {
    const rate = getUsdRatePerOne();
    const shopUsd = getDefaultCurrency() === 'USD';
    const ci = Number(costIqd) || 0;
    const si = Number(saleIqd) || 0;
    const cu = Number(costUsd) || 0;
    const su = Number(saleUsd) || 0;
    const costIqdTotal = roundIqd(ci + (rate > 0 ? cu * rate : 0));
    const saleIqdTotal = roundIqd(si + (rate > 0 ? su * rate : 0));
    const costUsdTotal = roundUsd(cu + (rate > 0 ? ci / rate : 0));
    const saleUsdTotal = roundUsd(su + (rate > 0 ? si / rate : 0));
    return {
        cost: shopUsd ? costUsdTotal : costIqdTotal,
        sale: shopUsd ? saleUsdTotal : saleIqdTotal,
        costIqd: costIqdTotal,
        saleIqd: saleIqdTotal,
        costUsd: costUsdTotal,
        saleUsd: saleUsdTotal,
        costIqdNative: ci,
        saleIqdNative: si,
        costUsdNative: cu,
        saleUsdNative: su
    };
}

/**
 * Warehouse / dashboard valuation: sum each item in its native currency.
 * 100% IQD catalog => changing the FX rate changes 0 IQD.
 * 100% USD catalog => changing the FX rate changes $0.
 */
export function sumInventoryValuationNative(list) {
    let costIqd = 0;
    let saleIqd = 0;
    let costUsd = 0;
    let saleUsd = 0;
    const items = Array.isArray(list) ? list : [];
    for (let i = 0; i < items.length; i++) {
        const p = items[i];
        if (!p || !p.trackStock) continue;
        const q = inventoryPositiveQty(p);
        if (!q) continue;
        if (inventoryItemNativeCurrency(p) === 'USD') {
            costUsd += inventoryNativeUnitUsd(p, 'cost') * q;
            saleUsd += inventoryNativeUnitUsd(p, 'sell') * q;
        } else {
            costIqd += inventoryNativeUnitIqd(p, 'cost') * q;
            saleIqd += inventoryNativeUnitIqd(p, 'sell') * q;
        }
    }
    return finalizeInventoryValuationBuckets(costIqd, saleIqd, costUsd, saleUsd);
}

export function renderInventoryStats(list) {
    const src = Array.isArray(list) ? list : ((state.db && state.db.products) || []);
    return sumInventoryValuationNative(src);
}

export function productStockValueIqd(prod, qtyOverride) {
    if (!prod) return 0;
    const qty = inventoryPositiveQty(prod, qtyOverride);
    if (!qty) return 0;
    if (inventoryItemNativeCurrency(prod) === 'USD') {
        const rate = getUsdRatePerOne();
        return roundIqd(rate > 0 ? inventoryNativeUnitUsd(prod, 'cost') * qty * rate : 0);
    }
    return roundIqd(inventoryNativeUnitIqd(prod, 'cost') * qty);
}

export function productStockValueUsd(prod, qtyOverride) {
    if (!prod) return 0;
    const qty = inventoryPositiveQty(prod, qtyOverride);
    if (!qty) return 0;
    if (inventoryItemNativeCurrency(prod) === 'USD') {
        return roundUsd(inventoryNativeUnitUsd(prod, 'cost') * qty);
    }
    const rate = getUsdRatePerOne();
    return roundUsd(rate > 0 ? (inventoryNativeUnitIqd(prod, 'cost') * qty) / rate : 0);
}

/** Dollar shops only. Dinar shops must never enter FX / *_usd paths. */
export function isUsdMoneySystem() {
    return getActiveCurrency() === 'USD';
}

/** Dinar shops: prices, cost, debt, profit stay IQD. No rate, no *_usd. */
export function isIqdMoneySystem() {
    return getActiveCurrency() === 'IQD';
}

export function isMoneyRoundingEnabled() {
    if (typeof window.isPremiumSettingsFeatureEnabled === 'function') {
        return window.isPremiumSettingsFeatureEnabled('set-enable-money-rounding');
    }
    if (state.db && state.db.settings) return state.db.settings.enableMoneyRounding !== false;
    return false;
}

export function getExchangeRate() {
    return getUsdRatePerOne();
}

/** For historical rows: use stored fx_usd_rate (settings encoding: IQD per 100 USD). */
export function fxUsdRateFormatOpts(row) {
    if (!row || row.fx_usd_rate == null || row.fx_usd_rate === '') return undefined;
    const r = Math.round(Number(row.fx_usd_rate));
    if (!Number.isFinite(r) || r < 1000) return undefined;
    return { fxUsdRate: r };
}

/** Transaction currency stamp (USD/IQD). Falls back to shop mode for unstamped rows. */
export function txnFxCurrencyMode(row) {
    const m = String((row && (row.fx_currency_mode || row.sale_currency || row.currency)) || '').toUpperCase();
    if (m === 'USD' || m === 'IQD') return m;
    return getActiveCurrency() === 'USD' ? 'USD' : 'IQD';
}

/**
 * IQD → USD for reports without re-ratioing USD-origin money through today's rate.
 * Prefer stored USD; proportional total_usd for partial amounts; else frozen row rate.
 * NEVER returns the full invoice total_usd for a partial IQD slice (that exploded debts).
 * NEVER falls back to live shop rate when a row/context is provided.
 */
export function storedIqdToUsdDisplayAmount(iqd, fxOptsOrRow, usdHint) {
    if (usdHint != null && usdHint !== '' && Number.isFinite(Number(usdHint))) {
        return roundUsd(Number(usdHint));
    }
    if (fxOptsOrRow && typeof fxOptsOrRow === 'object') {
        if (fxOptsOrRow.directUsd != null && fxOptsOrRow.directUsd !== '' && Number.isFinite(Number(fxOptsOrRow.directUsd))) {
            return roundUsd(Number(fxOptsOrRow.directUsd));
        }
    }
    const n = Number(iqd) || 0;
    if (fxOptsOrRow && typeof fxOptsOrRow === 'object') {
        const totalUsd = (fxOptsOrRow.total_usd != null && fxOptsOrRow.total_usd !== '')
            ? Number(fxOptsOrRow.total_usd)
            : NaN;
        const rowTotal = Number(
            fxOptsOrRow.total != null && fxOptsOrRow.total !== ''
                ? fxOptsOrRow.total
                : (fxOptsOrRow.total_iqd != null ? fxOptsOrRow.total_iqd : NaN)
        );
        if (Number.isFinite(totalUsd) && Number.isFinite(rowTotal) && rowTotal > 0.0000001) {
            // Full row → stamped USD; partial → proportional share of stamped USD (raw contract).
            return roundUsd(n * (totalUsd / rowTotal));
        }
        let rate = 0;
        if (fxOptsOrRow.fxUsdRate != null && fxOptsOrRow.fxUsdRate !== '') {
            const bundle = Math.round(Number(fxOptsOrRow.fxUsdRate));
            if (Number.isFinite(bundle) && bundle >= 1000) rate = bundle / 100;
        }
        if (!(rate > 0)) {
            // Strict frozen only — do not call getPosFrozenFxRatePerOne (it falls back to live).
            if (fxOptsOrRow.exchange_rate != null && fxOptsOrRow.exchange_rate !== '') {
                const er = Number(fxOptsOrRow.exchange_rate);
                if (Number.isFinite(er) && er >= 10000) rate = er / 100;
                else if (Number.isFinite(er) && er > 0) rate = er;
            }
            if (!(rate > 0) && fxOptsOrRow.fx_rate_per_one != null && Number(fxOptsOrRow.fx_rate_per_one) > 0) {
                rate = Number(fxOptsOrRow.fx_rate_per_one);
            }
            if (!(rate > 0) && fxOptsOrRow.fx_usd_rate != null && fxOptsOrRow.fx_usd_rate !== '') {
                const b = Math.round(Number(fxOptsOrRow.fx_usd_rate));
                if (Number.isFinite(b) && b >= 1000) rate = b / 100;
            }
        }
        if (rate > 0) return roundUsd(n / rate);
        // Row context without frozen FX / USD stamp: refuse live re-ratio (locks debts/COGS).
        return 0;
    }
    // No row context (e.g. today's opening float): live shop rate OK.
    const live = getUsdRatePerOne();
    return live > 0 ? roundUsd(n / live) : 0;
}

/**
 * Convert stored IQD (+ optional USD) to the active shop display currency.
 * Rule: same currency → exact raw; cross-currency → frozen exchange_rate only.
 */
export function storedAmountToActiveCurrency(iqdAmount, row, usdAmount) {
    const display = getActiveCurrency() === 'USD' ? 'USD' : 'IQD';
    const txn = txnFxCurrencyMode(row);
    const rate = getPosFrozenFxRatePerOne(row);
    const iqd = Number(iqdAmount) || 0;
    let usd = (usdAmount != null && usdAmount !== '' && Number.isFinite(Number(usdAmount)))
        ? Number(usdAmount)
        : null;
    if (usd == null && row && row.total_usd != null && row.total_usd !== '' && Number.isFinite(Number(row.total_usd))) {
        usd = Number(row.total_usd);
    }
    if (display === 'USD') {
        if (txn === 'USD') {
            if (usd != null) return roundUsd(usd);
            return rate > 0 ? roundUsd(iqd / rate) : 0;
        }
        return rate > 0 ? roundUsd(iqd / rate) : 0;
    }
    if (txn === 'IQD') return roundMoney(iqd, 'IQD');
    if (usd != null && rate > 0) return roundMoney(usd * rate, 'IQD');
    return roundMoney(iqd, 'IQD');
}

/** Format report totals: pass precomputed USD so USD mode never re-divides by live rate. */
export function formatReportAmount(iqdAmount, usdAmount) {
    if (getActiveCurrency() === 'USD') {
        if (usdAmount != null && usdAmount !== '' && Number.isFinite(Number(usdAmount))) {
            return formatUsdNumberPlain(usdAmount);
        }
        return formatCurrency(iqdAmount);
    }
    return formatCurrency(iqdAmount);
}

/**
 * Entity (customer/company) balance → formatCurrency opts with directUsd in USD shops.
 * Uses locked raw USD from remaining unpaid principals — never live FX re-ratio.
 */
export function fxUsdRateFormatOptsForEntityBalance(entityId, entityType, balanceIqd) {
    if (getActiveCurrency() !== 'USD') return undefined;
    const usd = reconstructEntityBalanceUsd(entityId, entityType, balanceIqd);
    if (usd == null || !Number.isFinite(usd)) return undefined;
    return { directUsd: usd };
}

function ledgerRowFxSource(row) {
    if (!row || typeof row !== 'object') return row;
    if (row.fx_usd_rate != null || row.exchange_rate != null || row.currency || row.total_usd != null) return row;
    const rid = row.receipt_id != null ? row.receipt_id : row.transaction_id;
    if (rid == null || rid === '' || !state.db || !Array.isArray(state.db.sales)) return row;
    const key = String(rid);
    const sale = state.db.sales.find(function (s) {
        return s && (String(s.id) === key || String(s.transaction_id || '') === key);
    });
    return sale || row;
}

/** Frozen IQD/USD rate from a row only — never today's live shop rate. */
function strictFrozenRatePerOne(row) {
    if (!row || typeof row !== 'object') return 0;
    if (row.exchange_rate != null && row.exchange_rate !== '') {
        const er = Number(row.exchange_rate);
        if (Number.isFinite(er) && er >= 10000) return er / 100;
        if (Number.isFinite(er) && er > 0) return er;
    }
    if (row.fx_rate_per_one != null && Number(row.fx_rate_per_one) > 0) return Number(row.fx_rate_per_one);
    if (row.fx_usd_rate != null && row.fx_usd_rate !== '') {
        const b = Math.round(Number(row.fx_usd_rate));
        if (Number.isFinite(b) && b >= 1000) return b / 100;
    }
    return 0;
}

/**
 * Convert an IQD debt slice to the invoice's locked raw USD (contractual).
 * Uses total_usd proportion or frozen exchange_rate — never live FX.
 */
function iqdDebtSliceToRawUsd(iqdAmt, row) {
    const n = Math.abs(Number(iqdAmt) || 0);
    if (!(n > 0) || !row || typeof row !== 'object') return 0;
    const totalUsd = (row.total_usd != null && row.total_usd !== '') ? Number(row.total_usd) : NaN;
    const rowTotal = Number(row.total != null && row.total !== '' ? row.total : (row.total_iqd != null ? row.total_iqd : (row.totalCost != null ? row.totalCost : NaN)));
    if (Number.isFinite(totalUsd) && Number.isFinite(rowTotal) && rowTotal > 0.0000001) {
        return roundUsd(n * (totalUsd / rowTotal));
    }
    if (row.paid_usd != null && row.paid_amount != null && Number(row.paid_amount) > 0) {
        const paidUsd = Number(row.paid_usd);
        const paidIqd = Number(row.paid_amount);
        if (Number.isFinite(paidUsd) && paidIqd > 0.0000001) {
            return roundUsd(n * (paidUsd / paidIqd));
        }
    }
    const rate = strictFrozenRatePerOne(row);
    if (rate > 0) return roundUsd(n / rate);
    return 0;
}

function supplyFrozenRatePerOne(supply) {
    let rate = strictFrozenRatePerOne(supply);
    if (rate > 0) return rate;
    if (!supply || !state.db) return 0;
    const pid = Number(supply.prodId != null ? supply.prodId : supply.product_id);
    const qty = Number(supply.qtyAdded) || 0;
    const costIqd = Number(supply.totalCost) || 0;
    if (!(pid > 0) || !(qty > 0) || !(costIqd > 0) || !Array.isArray(state.db.products)) return 0;
    const p = state.db.products.find(function (x) { return x && Number(x.id) === pid; });
    if (!p) return 0;
    const unitUsd = (p.cost_usd != null && p.cost_usd !== '')
        ? Number(p.cost_usd)
        : ((String(p.base_currency || '').toUpperCase() === 'USD' && p.base_cost != null) ? Number(p.base_cost) : NaN);
    if (!(Number.isFinite(unitUsd) && unitUsd > 0)) return 0;
    const usd = unitUsd * qty;
    if (!(usd > 0)) return 0;
    return costIqd / usd;
}

/**
 * Locked raw USD debt — NEVER multiply/divide by today's exchange rate.
 * Customer: SUM(sale.remaining_debt → raw USD via total_usd/frozen rate).
 *   = (total_usd − paid_usd) − later debt payments already reflected in remaining_debt.
 * Company: SUM(credit/split supplies.remaining_debt → raw USD). Cash purchases (rem=0) excluded.
 */
function reconstructEntityBalanceUsd(entityId, entityType, balanceIqd) {
    const id = String(entityId == null ? '' : entityId);
    if (!id || !state.db) return null;
    const typ = String(entityType || 'customer').toLowerCase();
    let usd = 0;
    let saw = false;

    if (typ === 'customer' || typ === 'customers') {
        const sales = (state.db.sales || []).concat(state.db.archive || []);
        sales.forEach(function (s) {
            if (!s || String(s.customer_id) !== id) return;
            const ct = String(s.customer_type || 'customer').toLowerCase();
            if (ct && ct !== 'customer' && ct !== 'customers') return;
            if (Number(s.is_returned) === 1) return;
            const rem = (s.remaining_debt != null && s.remaining_debt !== '')
                ? Math.max(0, Number(s.remaining_debt) || 0)
                : Math.max(0, (Number(s.total) || 0) - (Number(s.paid_amount) || 0));
            if (!(rem > 0.0001)) return;
            saw = true;
            usd += iqdDebtSliceToRawUsd(rem, s);
        });
        // Opening balance (IQD) only if stamped path exists — never live FX.
        const cust = (state.db.customers || []).find(function (c) { return c && String(c.id) === id; });
        if (cust) {
            const opening = Number(cust.opening_balance) || 0;
            if (opening > 0.0001) {
                saw = true;
                // No opening_usd column: leave IQD opening out of USD lock (0) rather than live-divide.
            }
        }
        if (saw) return roundUsd(usd);

        // Fallback: debt ledger lines only (ignore sale_cash), convert via linked sale stamps.
        ((state.db.customer_ledger) || []).forEach(function (l) {
            if (!l || String(l.target_id) !== id) return;
            const tt = String(l.target_type || 'customer').toLowerCase();
            if (tt && tt !== 'customer' && tt !== 'customers') return;
            const ty = String(l.type || '').toLowerCase();
            if (ty === 'sale_cash' || ty === 'return_cash') return;
            const src = ledgerRowFxSource(l);
            const amt = Math.abs(Number(l.amount) || 0);
            const u = iqdDebtSliceToRawUsd(amt, src);
            if (!(u > 0) && !(amt > 0)) return;
            saw = true;
            if (ty === 'sale' || ty === 'restore' || ty === 'debt') usd += u;
            else if (ty === 'payment' || ty === 'pay' || ty === 'return' || ty === 'void') usd -= u;
        });
        if (saw) return roundUsd(usd);
    } else {
        const comp = (state.db.companies || []).find(function (c) {
            return c && String(c.id) === id;
        });
        const companyName = comp ? String(comp.name || '').trim() : '';
        ((state.db.supplies) || []).forEach(function (s) {
            if (!s) return;
            const st = String(s.type || '').toLowerCase();
            // Cash purchases are not debt.
            if (st !== 'credit' && st !== 'split') return;
            if (companyName && String(s.company || '').trim() !== companyName) return;
            if (!companyName) return;
            const rem = (s.remaining_debt != null && s.remaining_debt !== '')
                ? Math.max(0, Number(s.remaining_debt) || 0)
                : Math.max(0, Number(s.totalCost) || 0);
            if (!(rem > 0.0001)) return;
            saw = true;
            let rate = supplyFrozenRatePerOne(s);
            if (!(rate > 0)) {
                // Same invoice: inherit rate from sibling supply lines.
                const txn = String(s.transaction_id || '');
                if (txn) {
                    ((state.db.supplies) || []).some(function (sib) {
                        if (!sib || String(sib.transaction_id || '') !== txn) return false;
                        rate = supplyFrozenRatePerOne(sib);
                        return rate > 0;
                    });
                }
            }
            if (rate > 0) usd += roundUsd(rem / rate);
        });
        if (saw) return roundUsd(usd);

        // Fallback ledger: credit_purchase − payments (ignore cash purchase), frozen rate only.
        ((state.db.ledger) || []).forEach(function (l) {
            if (!l || String(l.companyId != null ? l.companyId : l.company_id) !== id) return;
            const ty = String(l.type || '').toLowerCase();
            if (ty === 'purchase' || ty === 'purchase_fib' || ty === 'purchase_cash') return;
            const txn = String(l.transaction_id || '');
            let rate = strictFrozenRatePerOne(l);
            if (!(rate > 0) && txn) {
                ((state.db.supplies) || []).some(function (s) {
                    if (!s || String(s.transaction_id || '') !== txn) return false;
                    rate = supplyFrozenRatePerOne(s);
                    return rate > 0;
                });
            }
            if (!(rate > 0)) return;
            saw = true;
            const u = roundUsd(Math.abs(Number(l.amount) || 0) / rate);
            if (ty === 'credit_purchase' || ty === 'receive' || ty === 'debt') usd += u;
            else if (ty === 'payment' || ty === 'pay' || ty === 'debt_payment' || ty === 'return' || ty === 'return_to_supplier' || ty === 'purchase_return') usd -= u;
        });
        if (saw) return roundUsd(usd);
    }
    const iqd = Number(balanceIqd) || 0;
    if (!(iqd > 0)) return 0;
    // Refuse live conversion of unstamped entity balances.
    return null;
}

// --- Payment modal amount display (en-US: comma thousands, dot decimals) ---

export function stripAmountThousands(str) {
    return String(str ?? '').replace(/,/g, '');
}

function normalizeEasternDigitsInString(s) {
    return String(s)
        .replace(/[\u0660-\u0669]/g, (d) => String(d.charCodeAt(0) - 0x0660))
        .replace(/[\u06F0-\u06F9]/g, (d) => String(d.charCodeAt(0) - 0x06F0))
        .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));
}

/**
 * Parse display amount: commas ignored, '.' is decimal separator only.
 * @returns {number} NaN for empty or incomplete '.' only
 */
export function parseAmountInput(str) {
    let s = normalizeEasternDigitsInString(String(str ?? '')).trim();
    if (s === '') return NaN;
    // Normalize Arabic separators to common forms first.
    s = s.replace(/\u066B/g, '.').replace(/\u066C/g, ',');
    // Remove spaces that may appear from mobile/laptop keyboards.
    s = s.replace(/\s+/g, '');
    // If there is only one comma and no dot, decide whether comma is decimal or thousands.
    if (s.indexOf('.') === -1 && (s.match(/,/g) || []).length === 1) {
        const parts = s.split(',');
        const frac = parts[1] || '';
        // 1-2 decimal digits => decimal comma (e.g. 12,5 or 12,50)
        // 3 digits => likely thousands separator (e.g. 72,000)
        if (frac.length > 0 && frac.length <= 2) s = parts[0] + '.' + frac;
        else s = parts[0] + frac;
    } else {
        // Default project format uses comma as thousands separator.
        s = s.replace(/,/g, '');
    }
    // Keep only digits and first decimal dot.
    s = s.replace(/[^0-9.]/g, '');
    const firstDot = s.indexOf('.');
    if (firstDot !== -1) s = s.slice(0, firstDot + 1) + s.slice(firstDot + 1).replace(/\./g, '');
    if (s === '' || s === '.') return NaN;
    const n = parseFloat(s);
    return Number.isFinite(n) ? n : NaN;
}

/**
 * @param {string} raw - digits / optional dot; commas stripped first
 * @param {number} maxFracDigits 2 USD, 3 IQD, 0 integer
 * @param {boolean} allowDecimal
 */
export function normalizePaymentTypingRaw(raw, maxFracDigits, allowDecimal) {
    let s = normalizeEasternDigitsInString(stripAmountThousands(raw));
    if (!allowDecimal) {
        return s.replace(/[^\d]/g, '');
    }
    let out = '';
    let dotSeen = false;
    for (let i = 0; i < s.length; i++) {
        const c = s[i];
        if (c >= '0' && c <= '9') {
            if (dotSeen) {
                const dotIdx = out.indexOf('.');
                const fracLen = out.length - dotIdx - 1;
                if (fracLen < maxFracDigits) out += c;
            } else {
                out += c;
            }
        } else if (c === '.' && !dotSeen) {
            out += '.';
            dotSeen = true;
        }
    }
    if (out.startsWith('.')) out = `0${out}`;
    const di = out.indexOf('.');
    if (di === -1) {
        const intOnly = out.replace(/^0+(?=\d)/, '') || (out.includes('0') ? '0' : '');
        return intOnly;
    }
    let intPart = out.slice(0, di);
    const frac = out.slice(di + 1);
    const trailDot = frac === '';
    intPart = intPart.replace(/^0+(?=\d)/, '') || '0';
    if (trailDot) return `${intPart}.`;
    return `${intPart}.${frac}`;
}

function caretIndexForNormalizedPrefix(display, normPrefix) {
    if (normPrefix === '') return 0;
    let acc = '';
    for (let i = 0; i < display.length; i++) {
        const c = display[i];
        if (c !== ',') acc += c;
        if (acc === normPrefix) return i + 1;
    }
    return display.length;
}

export function formatNormalizedPaymentDisplay(norm, maxFracDigits) {
    if (norm === '' || norm == null) return '';
    if (maxFracDigits === 0) {
        const only = String(norm).replace(/[^\d]/g, '');
        if (only === '') return '';
        const intNum = parseInt(only, 10);
        if (!Number.isFinite(intNum)) return '';
        return intNum.toLocaleString('en-US', { useGrouping: true, maximumFractionDigits: 0 });
    }
    const endsWithDot = String(norm).endsWith('.');
    const core = endsWithDot ? String(norm).slice(0, -1) : String(norm);
    const parts = core.split('.');
    let intRaw = parts[0] || '0';
    intRaw = intRaw.replace(/^0+(?=\d)/, '') || '0';
    const intNum = parseInt(intRaw, 10);
    const intStr = Number.isFinite(intNum)
        ? intNum.toLocaleString('en-US', { useGrouping: true, maximumFractionDigits: 0 })
        : intRaw;
    let frac = parts.length > 1 ? parts[1] : '';
    if (frac.length > maxFracDigits) frac = frac.slice(0, maxFracDigits);
    if (parts.length > 1) return `${intStr}.${frac}`;
    if (endsWithDot) return `${intStr}.`;
    return intStr;
}

/**
 * @param {'usd'|'iqd'|'int'} kind
 */
export function formatPaymentAmountNumber(num, kind) {
    const n = Number(num);
    if (!Number.isFinite(n)) return '';
    if (kind === 'usd') {
        return formatUsdNumberPlain(n);
    }
    if (kind === 'iqd') {
        return Math.floor(n).toLocaleString('en-US', { useGrouping: true, minimumFractionDigits: 0, maximumFractionDigits: 0 });
    }
    return Math.floor(n).toLocaleString('en-US', { useGrouping: true, maximumFractionDigits: 0 });
}

/**
 * Reformat a payment amount input in-place; preserves caret using normalized prefix length.
 * @param {HTMLInputElement} el
 * @param {'usd'|'iqd'|'int'} kind
 */
export function formatPaymentInputElement(el, kind) {
    if (!el || el.tagName !== 'INPUT') return;
    const maxFrac = kind === 'usd' ? 2 : 0;
    const allowDec = maxFrac > 0;
    const val = el.value || '';
    let sel = typeof el.selectionStart === 'number' ? el.selectionStart : val.length;
    if (sel == null || sel < 0) sel = val.length;
    sel = Math.min(sel, val.length);
    const logicalPrefix = val.slice(0, sel).replace(/,/g, '');
    const rawFull = val.replace(/,/g, '');
    const normFull = normalizePaymentTypingRaw(rawFull, maxFrac, allowDec);
    const normPrefix = normalizePaymentTypingRaw(logicalPrefix, maxFrac, allowDec);
    const dispFull = formatNormalizedPaymentDisplay(normFull, maxFrac);
    const newCaret = logicalPrefix === '' && sel === 0 ? 0 : caretIndexForNormalizedPrefix(dispFull, normPrefix);
    el.value = dispFull;
    if (typeof el.setSelectionRange === 'function') {
        try {
            const c = Math.min(newCaret, dispFull.length);
            el.setSelectionRange(c, c);
        } catch (e) { /* ignore */ }
    }
}

/**
 * Integer-math money helpers (BigInt-based):
 * - IQD internal scale: 3 decimals (1 IQD = 1000 minor units)
 * - USD internal scale: 2 decimals (1 USD = 100 cents)
 * These helpers avoid floating-point accumulation errors in financial sums.
 */
function getMoneyScale(currency = null) {
    const c = (currency || getActiveCurrency()).toUpperCase();
    return c === 'USD' ? 2 : 3;
}

function pow10BigInt(exp) {
    let out = 1n;
    for (let i = 0; i < exp; i++) out *= 10n;
    return out;
}

function normalizeNumericString(input) {
    if (input === null || input === undefined) return '0';
    let s = String(input).trim();
    if (!s) return '0';
    s = s.replace(/,/g, '');
    s = s.replace(/[٠-٩]/g, d => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));
    s = s.replace(/[^\d.\-]/g, '');
    if (!s || s === '-' || s === '.' || s === '-.') return '0';
    const neg = s.startsWith('-');
    s = s.replace(/-/g, '');
    const parts = s.split('.');
    const intPart = (parts[0] || '0').replace(/^0+(?=\d)/, '') || '0';
    const fracPart = (parts[1] || '').replace(/[^\d]/g, '');
    return (neg ? '-' : '') + intPart + (fracPart ? ('.' + fracPart) : '');
}

export function moneyToMinor(value, currency = null) {
    try {
        const scale = getMoneyScale(currency);
        const base = pow10BigInt(scale);
        const normalized = normalizeNumericString(value);
        const negative = normalized.startsWith('-');
        const abs = negative ? normalized.slice(1) : normalized;
        const parts = abs.split('.');
        const intPart = (parts[0] || '0').replace(/\D/g, '') || '0';
        const fracRaw = parts[1] || '';
        const frac = (fracRaw + '0'.repeat(scale)).slice(0, scale).replace(/\D/g, '') || '0';
        const major = BigInt(intPart);
        const minor = BigInt(frac);
        const total = (major * base) + minor;
        return negative ? -total : total;
    } catch (_eMoney) {
        return 0n;
    }
}

export function moneyFromMinor(minorValue, currency = null) {
    const scale = getMoneyScale(currency);
    const base = pow10BigInt(scale);
    let v = typeof minorValue === 'bigint' ? minorValue : BigInt(String(minorValue || 0));
    const negative = v < 0n;
    if (negative) v = -v;
    const major = v / base;
    const minor = v % base;
    const frac = minor.toString().padStart(scale, '0');
    const out = scale > 0 ? `${major.toString()}.${frac}` : major.toString();
    return negative ? `-${out}` : out;
}

export function roundMoney(val, currency = null) {
    const asMinor = moneyToMinor(val, currency);
    const normalized = moneyFromMinor(asMinor, currency);
    let n = Number(normalized);
    if (!Number.isFinite(n)) return 0;
    return n;
}

/**
 * Debt form amounts (opening balance, debt limit): UI units → canonical IQD for DB/API storage.
 * Matches api/all.php pos_debt_form_amounts_to_stored_iqd when currencyMode is USD (multiply by rate).
 */
export function debtFormAmountToStoredIqd(n) {
    const v = Math.max(0, Number(n));
    if (!Number.isFinite(v)) return 0;
    if (getActiveCurrency() !== 'USD') {
        return roundMoney(v, 'IQD');
    }
    const r = getUsdRatePerOne();
    if (!(r > 0)) return roundMoney(v, 'IQD');
    return roundMoney(v * r, 'IQD');
}

/** Inverse of debtFormAmountToStoredIqd for filling edit form fields from db.customers / db.companies. */
export function storedIqdToDebtFormAmount(iqd) {
    const v = Math.max(0, Number(iqd));
    if (!Number.isFinite(v)) return 0;
    if (getActiveCurrency() !== 'USD') {
        return roundMoney(v, 'IQD');
    }
    const r = getUsdRatePerOne();
    if (!(r > 0)) return roundMoney(v, 'IQD');
    return roundMoney(v / r, 'USD');
}

/**
 * Cash/bill rounding for display only (customer-facing views/receipts).
 * Never use this for stock, product pricing, or accounting storage.
 */
export function roundMoneyForDisplay(val, currency = null) {
    let n = roundMoney(val, currency);
    const curr = (currency || getActiveCurrency()).toUpperCase();
    if (curr === 'IQD' && isMoneyRoundingEnabled()) {
        n = Math.round(n / 250) * 250;
    }
    return n;
}

/** Stored IQD amounts from DB: minor-unit normalize only (no 250 IQD bill rounding). */
function normalizeStoredIqdValue(val) {
    const asMinor = moneyToMinor(val, 'IQD');
    const normalized = moneyFromMinor(asMinor, 'IQD');
    const n = Number(normalized);
    return Number.isFinite(n) ? n : 0;
}

/**
 * @param {number|string} val - Amount stored in IQD
 * @param {{ fxUsdRate?: number|string }} [options] - Optional per-row snapshot (same encoding as settings.usdRate; per-one = fxUsdRate/100)
 * @see docs/currency_model.md — IQD canonical storage; USD is display conversion (today’s rate unless options.fxUsdRate).
 */
export function formatCurrency(val, options) {
    // DB/API store IQD. Do not apply 250 IQD rounding before USD conversion — it shifts catalog prices (e.g. $30 → wrong USD after save).
    if (options && options.directUsd != null && options.directUsd !== '') {
        if (getActiveCurrency() === 'USD') {
            return formatUsdNumberPlain(options.directUsd);
        }
    }
    const baseIqd = normalizeStoredIqdValue(val);
    let fxRaw = 0;
    if (options && options.fxUsdRate != null && options.fxUsdRate !== '') {
        fxRaw = Math.round(Number(options.fxUsdRate));
        if (!Number.isFinite(fxRaw) || fxRaw < 1000) fxRaw = 0;
    }
    if (getActiveCurrency() === 'USD') {
        const ratePerOne = fxRaw > 0 ? (fxRaw / 100) : getUsdRatePerOne();
        const displayNum = ratePerOne > 0 ? (baseIqd / ratePerOne) : baseIqd;
        return formatUsdNumberPlain(displayNum);
    }
    const n = roundMoneyForDisplay(baseIqd, 'IQD');
    return Number(Math.floor(n)).toLocaleString('en-US', { maximumFractionDigits: 0, minimumFractionDigits: 0 });
}

export function getCurrencySymbol() {
    return getActiveCurrency() === 'IQD' ? 'IQD' : '$';
}

/** Formatted USD amount from IQD. */
export function formatApproxUsdFromIqd(iqdVal) {
    const baseIqd = normalizeStoredIqdValue(iqdVal);
    const ratePerOne = getUsdRatePerOne();
    if (!(ratePerOne > 0) || !(baseIqd > 0)) return '—';
    const usd = baseIqd / ratePerOne;
    return formatUsdNumberPlain(usd);
}

export function usdAmountToStoredIqd(usd, ratePerOne) {
    return convertCurrency(usd, 'USD', 'IQD', ratePerOne);
}

export function getPosFrozenFxRatePerOne(item) {
    if (item && item.exchange_rate != null && item.exchange_rate !== '') {
        const er = Number(item.exchange_rate);
        if (Number.isFinite(er) && er >= 10000) return er / 100;
        if (Number.isFinite(er) && er > 0) return er;
    }
    if (item && item.fx_rate_per_one != null && Number(item.fx_rate_per_one) > 0) {
        return Number(item.fx_rate_per_one);
    }
    if (item && item.fx_usd_rate != null && item.fx_usd_rate !== '') {
        const b = Math.round(Number(item.fx_usd_rate));
        if (Number.isFinite(b) && b >= 1000) return b / 100;
    }
    if (item && item.sale_exchange_rate != null && item.sale_exchange_rate !== '') {
        const b2 = Math.round(Number(item.sale_exchange_rate));
        if (Number.isFinite(b2) && b2 >= 1000) return b2 / 100;
    }
    return getUsdRatePerOne();
}

/** Per-product stored currency. Missing/empty defaults to shop default_currency, then IQD. */
export function getProductBaseCurrency(prod) {
    const c = String((prod && (prod.base_currency || prod.currency)) || '').toUpperCase();
    if (c === 'USD' || c === 'IQD') return c;
    try {
        if (typeof getDefaultCurrency === 'function') {
            const d = String(getDefaultCurrency() || '').toUpperCase();
            if (d === 'USD' || d === 'IQD') return d;
        }
    } catch (e) {}
    return 'IQD';
}

function catalogBaseKeyForField(usdKey, iqdKey) {
    if (iqdKey === 'price' || usdKey === 'price_usd') return 'base_price';
    if (iqdKey === 'cost' || usdKey === 'cost_usd') return 'base_cost';
    return '';
}

/** True when a value labeled USD is actually the IQD snapshot (same number, or IQD already converted once). */
export function usdValueLooksLikeIqdSnapshot(usdVal, iqdVal, ratePerOne) {
    const u = Number(usdVal);
    const i = Number(iqdVal);
    const r = Number(ratePerOne);
    if (!(u > 0) || !(r > 0)) return false;
    if (i > 0 && Math.abs(u - i) / Math.max(Math.abs(i), 1) < 0.02) return true;
    // Double-converted: labeled USD is already IQD (e.g. 180000) and IQD column is that × rate (270M).
    if (i > 0 && u >= (r * 10) && Math.abs((u * r) - i) / Math.max(Math.abs(i), 1) < 0.05) return true;
    return false;
}

export function catalogFieldBaseAmount(prod, usdKey, iqdKey) {
    if (!prod) return 0;
    const cur = getProductBaseCurrency(prod);
    const r = getUsdRatePerOne();
    const iqdCol = Number(prod[iqdKey]) || 0;
    const baseKey = catalogBaseKeyForField(usdKey, iqdKey);
    let raw = null;
    if (baseKey && prod[baseKey] != null && prod[baseKey] !== '') {
        const n = Number(prod[baseKey]);
        // 0 is the ALTER DEFAULT — treat as missing and fall back to price/cost.
        if (Number.isFinite(n) && n > 0) raw = n;
    }
    if (raw == null && cur === 'USD') {
        const u = prod[usdKey];
        if (u != null && u !== '' && !isNaN(parseFloat(u))) raw = parseFloat(u);
    }
    if (cur === 'USD') {
        if (raw != null && Number.isFinite(raw) && raw > 0) {
            if (usdValueLooksLikeIqdSnapshot(raw, iqdCol, r) && r > 0) {
                return parseFloat((raw / r).toFixed(6));
            }
            return raw;
        }
        if (r > 0 && iqdCol > 0) return parseFloat((iqdCol / r).toFixed(6));
        return 0;
    }
    if (raw != null && Number.isFinite(raw)) return raw;
    return iqdCol;
}

/**
 * Catalog field in IQD — runtime only.
 * IQD base: exact base_price. USD base: base_price * exchange_rate.
 */
export function catalogIqdFromUsdField(prod, usdKey, iqdKey) {
    if (!prod) return 0;
    const base = catalogFieldBaseAmount(prod, usdKey, iqdKey);
    const cur = getProductBaseCurrency(prod);
    const r = getUsdRatePerOne();
    if (cur === 'IQD') return convertCurrency(base, 'IQD', 'IQD', r);
    if (!r || r <= 0) return Number(prod[iqdKey]) || 0;
    return convertCurrency(base, 'USD', 'IQD', r);
}

/**
 * Catalog field in USD — runtime only.
 * USD base: exact base_price. IQD base: base_price / exchange_rate.
 */
export function catalogUsdFromBaseField(prod, usdKey, iqdKey) {
    if (!prod) return 0;
    const base = catalogFieldBaseAmount(prod, usdKey, iqdKey);
    const cur = getProductBaseCurrency(prod);
    const r = getUsdRatePerOne();
    if (cur === 'USD') return convertCurrency(base, 'USD', 'USD', r);
    if (!r || r <= 0) return 0;
    return convertCurrency(base, 'IQD', 'USD', r);
}

export function getCatalogPieceSellIqd(p) {
    if (!p) return 0;
    return catalogIqdFromUsdField(p, 'price_usd', 'price');
}

export function getCatalogPieceCostIqd(p) {
    if (!p) return 0;
    return catalogIqdFromUsdField(p, 'cost_usd', 'cost');
}

export function getCatalogPieceSellUsd(p) {
    if (!p) return 0;
    return catalogUsdFromBaseField(p, 'price_usd', 'price');
}

export function getCatalogPieceCostUsd(p) {
    if (!p) return 0;
    return catalogUsdFromBaseField(p, 'cost_usd', 'cost');
}

export function getCatalogPieceSellActive(p) {
    return isUsdMoneySystem() ? getCatalogPieceSellUsd(p) : getCatalogPieceSellIqd(p);
}

export function getCatalogPieceCostActive(p) {
    return isUsdMoneySystem() ? getCatalogPieceCostUsd(p) : getCatalogPieceCostIqd(p);
}

/** Format an amount already in the shop display currency. */
export function formatActiveCurrencyAmount(val) {
    const n = Number(val);
    if (!Number.isFinite(n)) return '0';
    if (getActiveCurrency() === 'USD') {
        return formatUsdNumberPlain(n);
    }
    return formatCurrency(n);
}

export function convertArabicNumerals(input) {
    const val = input.value;
    if (/[٠-٩]/.test(val)) {
        const converted = val.replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
        input.value = converted;
    }
}

export function escapeHtml(unsafe) {
    if (typeof unsafe !== 'string') return unsafe;
    return unsafe.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}

/** Server/MySQL datetimes are stored in Asia/Baghdad (see config/core.php). */
export const POS_TIMEZONE = 'Asia/Baghdad';
const POS_TZ_OFFSET_MIN = 180;

function shiftPosDateKey(ymd, deltaDays) {
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(ymd || ''));
    if (!m) return ymd;
    const y = parseInt(m[1], 10);
    const mo = parseInt(m[2], 10);
    const da = parseInt(m[3], 10);
    const utcMs = Date.UTC(y, mo - 1, da, 12, 0, 0) - (POS_TZ_OFFSET_MIN * 60 * 1000) + (deltaDays * 86400000);
    return new Date(utcMs).toLocaleDateString('en-CA', { timeZone: POS_TIMEZONE });
}

export function getPosTimezoneHour(d) {
    if (!(d instanceof Date) || isNaN(d.getTime())) return 0;
    return parseInt(d.toLocaleString('en-GB', { timeZone: POS_TIMEZONE, hour: 'numeric', hour12: false }), 10) || 0;
}

export function getPosDateKey(d) {
    if (!(d instanceof Date) || isNaN(d.getTime())) return '';
    return d.toLocaleDateString('en-CA', { timeZone: POS_TIMEZONE });
}

/** Format stored/server timestamps in Baghdad wall time (24h). */
export function formatPosDateTime(dateInput, locale) {
    const d = dateInput instanceof Date ? dateInput : parseSQLDate(dateInput);
    if (!d || isNaN(d.getTime())) return '';
    const loc = locale || 'ar-IQ';
    try {
        return d.toLocaleString(loc, {
            timeZone: POS_TIMEZONE,
            year: 'numeric',
            month: 'numeric',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false
        });
    } catch (e) {
        const parts = getPosTimezoneParts(d);
        return `${parts.day}/${parts.month}/${parts.year.slice(-2)} ${parts.hour}:${parts.minute}:${parts.second}`;
    }
}

export function getPosTimezoneParts(d) {
    const map = { year: '0000', month: '01', day: '01', hour: '00', minute: '00', second: '00' };
    if (!(d instanceof Date) || isNaN(d.getTime())) return map;
    try {
        new Intl.DateTimeFormat('en-GB', {
            timeZone: POS_TIMEZONE,
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false
        }).formatToParts(d).forEach((p) => {
            if (p.type !== 'literal') map[p.type] = p.value;
        });
    } catch (e) { /* keep defaults */ }
    return map;
}

export function getBusinessDate(dateObj = new Date()) {
    const d = dateObj instanceof Date ? dateObj : parseSQLDate(dateObj);
    if (isNaN(d.getTime())) return '';
    const startHour = (state.db && state.db.settings && state.db.settings.businessDayStartHour !== undefined)
        ? parseInt(state.db.settings.businessDayStartHour, 10)
        : 0;
    const sh = Number.isFinite(startHour) && startHour >= 0 && startHour <= 23 ? startHour : 0;
    let dateKey = getPosDateKey(d);
    if (getPosTimezoneHour(d) < sh) dateKey = shiftPosDateKey(dateKey, -1);
    return dateKey;
}

export function parseSQLDate(sqlDate) {
    if (!sqlDate) return new Date();
    if (sqlDate instanceof Date) return sqlDate;
    const raw = sqlDate.toString().trim();
    if (!raw) return new Date();
    if (raw.indexOf('T') !== -1 || raw.indexOf('Z') !== -1 || /[+-]\d{2}:?\d{2}$/.test(raw)) {
        return new Date(sqlDate);
    }
    const t = raw.split(/[- :]/);
    const yi = parseInt(t[0], 10);
    const mi = parseInt(t[1], 10) || 1;
    const di = parseInt(t[2], 10) || 1;
    const hi = t[3] !== undefined && t[3] !== '' ? parseInt(t[3], 10) : NaN;
    /** Date-only strings (YYYY-MM-DD): noon Baghdad avoids day-boundary splits. */
    const hh = Number.isFinite(hi) ? hi : 12;
    const min = Number.isFinite(parseInt(t[4], 10)) ? parseInt(t[4], 10) : 0;
    const sec = Number.isFinite(parseInt(t[5], 10)) ? parseInt(t[5], 10) : 0;
    if (!Number.isFinite(yi)) return new Date();
    /** Naive SQL DATETIME from PHP/MySQL = Asia/Baghdad wall clock, not browser local. */
    return new Date(Date.UTC(yi, mi - 1, di, hh, min, sec) - (POS_TZ_OFFSET_MIN * 60 * 1000));
}

export function getBusinessMonth(dateObj = new Date()) {
    const dayKey = getBusinessDate(dateObj);
    const m = /^(\d{4})-(\d{2})-\d{2}$/.exec(dayKey);
    if (!m) return '';
    return `${m[1]}-${parseInt(m[2], 10)}`;
}

let _allSalesCache = null;
let _allSalesCacheKey = '';

function buildAllSalesCacheKey(includeVoid) {
    const db = state.db;
    if (!db) return '';
    const sales = db.sales || [];
    const archive = db.archive || [];
    const head = sales.length ? sales[0].id : 0;
    return (includeVoid ? '1' : '0') + ':' + sales.length + ':' + archive.length + ':' + head;
}

export function invalidateSalesPoolCache() {
    _allSalesCache = null;
    _allSalesCacheKey = '';
}

export function getAllSales(includeVoid = false) {
    if (!state.db) return [];
    const cacheKey = buildAllSalesCacheKey(includeVoid);
    if (_allSalesCache && _allSalesCacheKey === cacheKey) {
        return _allSalesCache;
    }
    const all = [...(state.db.sales || []), ...(state.db.archive || [])];
    const result = includeVoid ? all : all.filter(s => s.is_returned != 1);
    _allSalesCache = result;
    _allSalesCacheKey = cacheKey;
    return result;
}

/** Quantity on one sale line (matches server: count ?? qty ?? 1). */
export function getSaleLineQty(item) {
    if (!item || typeof item !== 'object') return 1;
    const raw = item.qty !== undefined && item.qty !== null ? item.qty : item.count;
    const q = Number(raw);
    return !Number.isNaN(q) && q > 0 ? q : 1;
}

/** Sale/return lines: `items` or `items_json`. Never leave COGS empty. */
export function saleOrReturnItems(row) {
    if (!row || typeof row !== 'object') return [];
    let raw = row.items;
    if (raw == null || raw === '') raw = row.items_json;
    if (typeof raw === 'string') {
        try { raw = JSON.parse(raw); } catch (_e) { return []; }
    }
    if (Array.isArray(raw)) return raw;
    if (raw && typeof raw === 'object') return Object.keys(raw).map((k) => raw[k]);
    return [];
}

function buildProductCostById(products) {
    const map = new Map();
    (products || []).forEach(p => {
        if (!p || p.id == null) return;
        map.set(Number(p.id), p);
    });
    return map;
}

/** Pieces inside a sale unit (pack / carton). */
export function piecesInSaleUnit(p, saleUnit) {
    if (!p || saleUnit === 'piece' || !saleUnit) return 1;
    const ppp = Math.max(1, parseInt(p.pieces_per_pack, 10) || 1);
    const ppc = Math.max(1, parseInt(p.packs_per_carton, 10) || 1);
    if (saleUnit === 'carton') {
        if (p.itemsPerCarton) return Math.max(1, parseFloat(p.itemsPerCarton) || (ppp * ppc));
        return ppp * ppc;
    }
    if (saleUnit === 'pack') return ppp;
    return 1;
}

/**
 * Catalog cost for a sale unit (IQD columns only).
 * After a cheaper purchase, piece cost is source of truth — unless pack/carton
 * only differs by floor() leftover (paid carton 310,000 vs piece×12 = 309,996).
 * Dollar shops keep the same IQD storage; display converts later. Never × rate here.
 */
export function catalogCostForSaleUnit(p, saleUnit) {
    if (!p) return 0;
    const pieceCost = catalogIqdFromUsdField(p, 'cost_usd', 'cost');
    if (saleUnit === 'piece' || !saleUnit) return pieceCost;
    // Free / gift remaining stock must stay 0 — do not use a stale pack/carton catalog cost.
    if (Number.isFinite(pieceCost) && pieceCost <= 0) return 0;
    const mult = piecesInSaleUnit(p, saleUnit);
    const unitField = saleUnit === 'carton'
        ? catalogIqdFromUsdField(p, 'cost_carton_usd', 'cost_carton')
        : catalogIqdFromUsdField(p, 'cost_pack_usd', 'cost_pack');
    const fromPiece = pieceCost > 0 ? pieceCost * mult : 0;
    if (fromPiece > 0 && unitField > 0) {
        const diff = unitField - fromPiece;
        if (diff >= 0 && diff < Math.max(1, mult)) return unitField;
        return fromPiece;
    }
    return fromPiece || unitField || 0;
}

/**
 * Typed pack/carton buy price. Floor when FIFO cannot cover a full unit (oversell).
 * Gift remaining stock (piece cost 0) stays 0.
 */
export function enteredCatalogCostForSaleUnit(p, saleUnit) {
    if (!p) return 0;
    const pieceCost = catalogIqdFromUsdField(p, 'cost_usd', 'cost');
    if (Number.isFinite(pieceCost) && pieceCost <= 0) return 0;
    if (saleUnit === 'carton') {
        const c = catalogIqdFromUsdField(p, 'cost_carton_usd', 'cost_carton');
        if (c > 0) return c;
    } else if (saleUnit === 'pack') {
        const c = catalogIqdFromUsdField(p, 'cost_pack_usd', 'cost_pack');
        if (c > 0) return c;
    }
    return catalogCostForSaleUnit(p, saleUnit);
}

/** True when the line stored a numeric cost, including explicit 0 (free gift lot). */
export function saleLineHasExplicitCost(item) {
    if (!item || typeof item !== 'object') return false;
    if (!Object.prototype.hasOwnProperty.call(item, 'cost')) return false;
    if (item.cost === null || item.cost === undefined || item.cost === '') return false;
    return Number.isFinite(Number(item.cost));
}

function saleLinePiecesForFifo(item, prod) {
    const q = getSaleLineQty(item);
    const su = (item && item.saleUnit) || 'piece';
    const mult = piecesInSaleUnit(prod || item, su);
    return q * (Number(mult) > 0 ? Number(mult) : 1);
}

function fifoSupplyIsPurchaseLayer(s) {
    if (!s) return false;
    const typ = String(s.type || '').toLowerCase();
    if (typ === 'return' || typ === 'supplier_return') return false;
    return (parseFloat(s.qtyAdded) || 0) > 0;
}

function fifoSuppliesPool() {
    if (typeof window !== 'undefined' && typeof window.posGetSuppliesPool === 'function') {
        try {
            const pool = window.posGetSuppliesPool();
            if (Array.isArray(pool) && pool.length) return pool;
        } catch (_e) {}
    }
    if (state.db && Array.isArray(state.db.supplies)) return state.db.supplies;
    if (typeof window !== 'undefined' && window.db && Array.isArray(window.db.supplies)) return window.db.supplies;
    return [];
}

function fifoParseTs(raw) {
    if (raw == null || raw === '') return 0;
    const t = Date.parse(raw);
    return Number.isFinite(t) ? t : 0;
}

/**
 * Newest-first purchase lots covering remainingQty. Gift lines keep unitCost = 0.
 */
export function remainingInventoryFifoLayers(pid, remainingQty, opts) {
    opts = opts || {};
    const left0 = Math.max(0, Number(remainingQty) || 0);
    if (!(left0 > 0) || pid == null) return [];
    const asOfTs = opts.asOfTs != null ? Number(opts.asOfTs) : null;
    const catalogPiece = Number(opts.catalogPieceCost) || 0;
    const purchases = fifoSuppliesPool().filter((s) => {
        if (!s || String(s.prodId) !== String(pid)) return false;
        if (!fifoSupplyIsPurchaseLayer(s)) return false;
        if (asOfTs != null && fifoParseTs(s.date) > asOfTs) return false;
        return true;
    });
    purchases.sort((a, b) => {
        const dt = fifoParseTs(b.date) - fifoParseTs(a.date);
        if (dt !== 0) return dt;
        return (Number(b.id) || 0) - (Number(a.id) || 0);
    });
    let left = left0;
    const taken = [];
    for (let i = 0; i < purchases.length && left > 0.000001; i++) {
        const s = purchases[i];
        const qAdded = parseFloat(s.qtyAdded) || 0;
        const tCost = parseFloat(s.totalCost) || 0;
        const take = Math.min(qAdded, left);
        if (take <= 0) continue;
        taken.push({
            rem: take,
            unitCost: qAdded > 0 ? (tCost / qAdded) : 0
        });
        left -= take;
    }
    if (left > 0.000001) {
        taken.push({ rem: left, unitCost: catalogPiece > 0 ? catalogPiece : 0 });
    }
    taken.reverse();
    return taken;
}

function consumeFifoLayersResult(layers, pieces) {
    let left = Math.max(0, Number(pieces) || 0);
    let cost = 0;
    if (!Array.isArray(layers) || left <= 0) return { cost: 0, left };
    for (let i = 0; i < layers.length && left > 0.000001; i++) {
        const b = layers[i];
        const rem = Number(b && b.rem) || 0;
        if (rem <= 0.000001) continue;
        const take = Math.min(left, rem);
        cost += take * (Number(b.unitCost) || 0);
        b.rem = rem - take;
        left -= take;
    }
    return { cost, left };
}

function consumeFifoLayerCost(layers, pieces) {
    return consumeFifoLayersResult(layers, pieces).cost;
}

function remainingQtyForFifoSale(prod, sale) {
    let q = Number(prod && prod.qty) || 0;
    if (!sale) return Math.max(0, q);
    const pid = Number(prod.id);
    const saleT = fifoParseTs(sale.created_at || sale.date);
    const saleId = sale.id != null ? String(sale.id) : '';
    const dbObj = (typeof window !== 'undefined' && window.db) ? window.db : (state.db || {});
    const sales = (typeof getAllSales === 'function')
        ? getAllSales(true)
        : ((dbObj && dbObj.sales) || []);
    let thisCounted = false;
    for (let i = 0; i < sales.length; i++) {
        const s = sales[i];
        if (!s) continue;
        if (s.is_returned == 1 || s.is_returned === true || s.is_returned === '1') continue;
        const t = fifoParseTs(s.created_at || s.date);
        if (t < saleT) continue;
        if (saleId && t === saleT && s.id != null && Number(s.id) < Number(saleId)) continue;
        const items = saleOrReturnItems(s);
        for (let j = 0; j < items.length; j++) {
            const it = items[j];
            if (!it || Number(it.id) !== pid) continue;
            q += saleLinePiecesForFifo(it, prod);
        }
        if (saleId && String(s.id) === saleId) thisCounted = true;
    }
    if (!thisCounted) {
        const items = saleOrReturnItems(sale);
        for (let j = 0; j < items.length; j++) {
            const it = items[j];
            if (!it || Number(it.id) !== pid) continue;
            q += saleLinePiecesForFifo(it, prod);
        }
    }
    const pool = fifoSuppliesPool();
    for (let i = 0; i < pool.length; i++) {
        const s = pool[i];
        if (!s || String(s.prodId) !== String(pid)) continue;
        if (!fifoSupplyIsPurchaseLayer(s)) continue;
        if (fifoParseTs(s.date) > saleT) q -= parseFloat(s.qtyAdded) || 0;
    }
    return Math.max(0, q);
}

/**
 * Actual remaining batch/WAC cost for a sale unit, including gift lots at 0.
 * @returns {number|null} cost per sale unit, or null if unknown
 */
export function inventoryFifoSaleUnitCost(prod, item, opts) {
    opts = opts || {};
    if (!prod || !item) return null;
    const lineQty = getSaleLineQty(item);
    if (!(lineQty > 0)) return null;
    const needPieces = saleLinePiecesForFifo(item, prod);
    if (!(needPieces > 0)) return null;
    const sale = opts.sale || null;
    const asOfTs = opts.asOfTs != null
        ? Number(opts.asOfTs)
        : (sale ? fifoParseTs(sale.created_at || sale.date) : Date.now());
    const remainingQty = (opts.remainingQty != null)
        ? Number(opts.remainingQty)
        : remainingQtyForFifoSale(prod, sale);
    const catalogPiece = catalogIqdFromUsdField(prod, 'cost_usd', 'cost');
    const layers = remainingInventoryFifoLayers(prod.id, remainingQty, {
        asOfTs,
        catalogPieceCost: catalogPiece
    });
    const roundEmpty = (typeof roundMoney === 'function') ? roundMoney : ((n) => Math.round(Number(n) || 0));
    if (!layers.length) {
        const enteredEmpty = enteredCatalogCostForSaleUnit(prod, item.saleUnit || 'piece');
        return enteredEmpty > 0 ? roundEmpty(enteredEmpty) : null;
    }
    const reserved = Math.max(0, Number(opts.reservedPieces) || 0);
    if (reserved > 0) consumeFifoLayerCost(layers, reserved);
    const got = consumeFifoLayersResult(layers, needPieces);
    const round = (typeof roundMoney === 'function') ? roundMoney : ((n) => Math.round(Number(n) || 0));
    let unit = round(got.cost / lineQty);
    // Oversell: leftover pieces are not a gift. Use typed pack/carton (or piece) buy price.
    if (got.left > 0.000001) {
        const entered = enteredCatalogCostForSaleUnit(prod, item.saleUnit || 'piece');
        if (entered > unit) unit = round(entered);
    }
    return unit;
}

/** Line COGS from stored IQD cost. Explicit 0 (gift lot) is valid. Optional FIFO via opts.sale. */
export function resolveSaleLineCost(item, productById, opts) {
    if (!item || typeof item !== 'object') return 0;
    const saleUnit = item.saleUnit || 'piece';
    const pid = Number(item.id);
    const p = productById && productById.get ? productById.get(pid) : null;
    const catalog = p ? catalogCostForSaleUnit(p, saleUnit) : 0;
    const useFifo = opts && (opts.sale || opts.useFifo);
    if (useFifo && p) {
        const fifo = inventoryFifoSaleUnitCost(p, item, opts);
        if (fifo != null && Number.isFinite(fifo)) return fifo;
    }
    if (saleLineHasExplicitCost(item)) return Number(item.cost);
    return catalog;
}

/**
 * @param {string|null} targetDateStr - YYYY-MM-DD business day key
 * @param {{ salesScope?: 'all'|'report', dayPools?: { sales?: any[], expenses?: any[], returns?: any[], ledger?: any[], customer_ledger?: any[] } }} opts
 *   `'report'` = same cashier filter as `getReportSales` when not using dayPools.
 *   `dayPools` = rows for that date from server (`get_daily_detail`) — skips local truncation.
 */
/** Ledger payment tied to purchase cash/split — already counted as expenses.type=purchase. */
export function isPurchaseLinkedDebtPayment(expense, allExpenses, ledgerEntry) {
    const list = Array.isArray(allExpenses) ? allExpenses : [];
    const exp = expense || ledgerEntry;
    if (!exp) return false;
    const txn = String(exp.transaction_id || '').trim();
    if (txn) {
        const hasPurchase = list.some(e => e && e.type === 'purchase' && String(e.transaction_id || '').trim() === txn);
        if (hasPurchase) return true;
    }
    const note = String(exp.note || '');
    if (/پێشەکی بۆ وەسڵ|split payment|کڕین \(نەقد\)|Bulk Invoice|وەسڵ #/i.test(note)) return true;
    return false;
}

/** Include company debt paid via ledger before expenses.debt_payment rows existed. */
export function mergeCompanyDebtExpensesFromLedger(expenses, ledgerEntries, companies) {
    const out = Array.isArray(expenses) ? expenses.slice() : [];
    const seenDebtTxn = new Set();
    const seenPurchaseTxn = new Set();
    out.forEach(e => {
        if (!e || !e.transaction_id) return;
        const txn = String(e.transaction_id);
        if (e.type === 'debt_payment') seenDebtTxn.add(txn);
        if (e.type === 'purchase') seenPurchaseTxn.add(txn);
    });
    const comps = Array.isArray(companies) ? companies : [];
    (ledgerEntries || []).forEach(l => {
        if (!l || l.type !== 'payment') return;
        if (isPurchaseLinkedDebtPayment(null, out, l)) return;
        const cid = Number(l.companyId || l.company_id || 0);
        if (!cid) return;
        const amt = parseFloat(l.amount) || 0;
        if (amt <= 0) return;
        const txn = l.transaction_id ? String(l.transaction_id) : '';
        if (txn && (seenDebtTxn.has(txn) || seenPurchaseTxn.has(txn))) return;
        const lDate = l.date || l.created_at;
        const dup = out.some(e => {
            if (!e || e.type !== 'debt_payment') return false;
            if (txn && e.transaction_id && String(e.transaction_id) === txn) return true;
            const eCid = Number(e.company_id || 0);
            const eAmt = parseFloat(e.amount) || 0;
            if (eCid === cid && Math.abs(eAmt - amt) < 0.02 && lDate && e.date) {
                return getBusinessDate(parseSQLDate(e.date)) === getBusinessDate(parseSQLDate(lDate));
            }
            return false;
        });
        if (dup) return;
        const comp = comps.find(c => Number(c.id) === cid);
        const name = comp && comp.name ? String(comp.name) : ('#' + cid);
        out.push({
            id: 'led_' + (l.id || txn || (cid + '_' + amt)),
            note: 'دانەڤا قەرزی کۆمپانیا: ' + name,
            amount: amt,
            date: lDate,
            user: l.user || 'System',
            type: 'debt_payment',
            transaction_id: txn,
            company_id: cid,
            _fromLedger: true
        });
        if (txn) seenDebtTxn.add(txn);
    });
    return out;
}

/** Cash portion of one purchase return — credit returns reduce supplier debt only, not قاسە. */
export function resolvePurchaseReturnCashAmount(pr, ledgerEntries, expenses, supplies) {
    if (!pr) return 0;
    const tot = parseFloat(pr.total) || 0;
    const txn = String(pr.transaction_id || '').trim();
    const expList = (expenses || []).filter(e => e && e.type === 'purchase_return');
    if (txn) {
        const exp = expList.find(e => String(e.transaction_id || '').trim() === txn);
        if (exp) return Math.abs(parseFloat(exp.amount) || 0);
    }
    if (pr.cash_refunded != null) return Math.max(0, parseFloat(pr.cash_refunded) || 0);
    if (pr.debt_adjusted != null) return Math.max(0, tot - (parseFloat(pr.debt_adjusted) || 0));

    const led = (ledgerEntries || []).find(l => l && l.type === 'return_to_supplier' && txn && String(l.transaction_id || '').trim() === txn);
    if (led) {
        const note = String(led.note || '');
        const cashM = note.match(/نەقد=([\d.]+)/);
        if (cashM) return parseFloat(cashM[1]) || 0;
        if (/نەقد\s*\(کاش\)/i.test(note) || (/\bنەقد\b|cash/i.test(note) && !/قەرز=/.test(note))) return tot;
        const debtM = note.match(/قەرز=([\d.]+)/);
        if (debtM) return Math.max(0, tot - (parseFloat(debtM[1]) || 0));
        if (/قەرز=/.test(note)) return 0;
    }

    const company = String(pr.company_name || '').trim();
    const invRef = String(pr.supplier_invoice_number || '').trim();
    const supplyPool = (supplies && supplies.length) ? supplies : ((state.db && state.db.supplies) || []);
    if (company && invRef && supplyPool.length) {
        const invRows = supplyPool.filter(s => s && String(s.company || '').trim() === company
            && String(s.supplier_invoice_number || '').trim() === invRef
            && s.type !== 'return' && s.type !== 'opening' && (parseFloat(s.qtyAdded) || 0) > 0);
        if (invRows.length) {
            const payType = String(invRows[0].type || 'cash').toLowerCase();
            if (payType === 'credit') return 0;
            if (payType === 'fib' || payType === 'bank' || payType === 'bankcard') return 0;
            if (payType === 'cash' || payType === '' || payType === 'purchase') return tot;
            if (payType === 'split') {
                const invTotal = invRows.reduce((s, r) => s + (parseFloat(r.totalCost) || 0), 0);
                const purchaseTxn = String(invRows[0].transaction_id || '').trim();
                if (invTotal > 0 && purchaseTxn) {
                    let cr = 0; let paid = 0;
                    const ledAll = (ledgerEntries && ledgerEntries.length) ? ledgerEntries : ((state.db && state.db.ledger) || []);
                    ledAll.forEach(l => {
                        if (!l || String(l.transaction_id || '').trim() !== purchaseTxn) return;
                        if (l.type === 'credit_purchase') cr += parseFloat(l.amount) || 0;
                        else if (l.type === 'payment' || l.type === 'pay') paid += parseFloat(l.amount) || 0;
                    });
                    const debtRatio = Math.min(1, Math.max(0, (cr - paid) / invTotal));
                    return Math.max(0, tot * (1 - debtRatio));
                }
            }
        }
    }
    return 0;
}

/** Cash in from purchase returns — only the cash refunded portion (credit returns reduce supplier debt, not قاسە). */
export function sumPurchaseReturnsCashInMinor(purchaseReturns, ledgerEntries, expenses, supplies) {
    const prList = purchaseReturns || [];
    let totalMinor = 0n;
    const seenTxn = new Set();
    prList.forEach(pr => {
        totalMinor += moneyToMinor(resolvePurchaseReturnCashAmount(pr, ledgerEntries, expenses, supplies), 'IQD');
        const txn = String(pr.transaction_id || '').trim();
        if (txn) seenTxn.add(txn);
    });
    (expenses || []).filter(e => e && e.type === 'purchase_return').forEach(e => {
        const txn = String(e.transaction_id || '').trim();
        if (txn && seenTxn.has(txn)) return;
        totalMinor += moneyToMinor(Math.abs(parseFloat(e.amount) || 0), 'IQD');
    });
    return totalMinor;
}

/** Display total of purchase return documents (may include debt portion not in قاسە). */
export function sumPurchaseReturnsDisplayMinor(purchaseReturns) {
    return (purchaseReturns || []).reduce((s, pr) => s + moneyToMinor(pr && pr.total != null ? pr.total : 0, 'IQD'), 0n);
}

/** Cash in from customer/staff debt repayments (customer_ledger + ledger debt_payment_in, de-duped). */
export function isCustomerDebtPaymentRow(cl) {
    if (!cl) return false;
    const ty = String(cl.type || '').toLowerCase();
    return ty === 'payment' || ty === 'pay';
}

/** Physical cash vs FIB/bank channel for customer debt collections (drawer accounting). */
export function customerDebtPaymentChannel(cl) {
    if (!cl) return 'cash';
    const pm = String(cl.payment_method || '').toLowerCase();
    if (pm === 'fib' || pm === 'bank' || pm === 'bank_transfer' || pm === 'banktransfer' || pm === 'bankcard' || pm === 'card') {
        return 'fib';
    }
    if (pm === 'cash') return 'cash';
    const ty = String(cl.type || '').toLowerCase();
    if (ty === 'debt_payment_in_fib' || ty === 'payment_fib') return 'fib';
    const note = String(cl.note || '');
    if (/کانال:\s*FIB|channel:\s*fib|\(FIB\)/i.test(note)) return 'fib';
    return 'cash';
}

export function sumCustomerDebtPaymentsInMinor(customerLedger, ledgerEntries) {
    const cashRows = (customerLedger || []).filter(cl => isCustomerDebtPaymentRow(cl) && customerDebtPaymentChannel(cl) === 'cash');
    const clPayMinor = cashRows.reduce((s, cl) => s + moneyToMinor(Math.abs(Number(cl.amount) || 0), 'IQD'), 0n);
    if (clPayMinor > 0n) return clPayMinor;
    return (ledgerEntries || []).filter(l => l && String(l.type || '').toLowerCase() === 'debt_payment_in')
        .reduce((s, l) => s + moneyToMinor(l.amount || 0, 'IQD'), 0n);
}

export function sumCustomerDebtPaymentsInFibMinor(customerLedger, ledgerEntries) {
    const fibRows = (customerLedger || []).filter(cl => isCustomerDebtPaymentRow(cl) && customerDebtPaymentChannel(cl) === 'fib');
    const clPayMinor = fibRows.reduce((s, cl) => s + moneyToMinor(Math.abs(Number(cl.amount) || 0), 'IQD'), 0n);
    if (clPayMinor > 0n) return clPayMinor;
    return (ledgerEntries || []).filter(l => l && String(l.type || '').toLowerCase() === 'debt_payment_in_fib')
        .reduce((s, l) => s + moneyToMinor(l.amount || 0, 'IQD'), 0n);
}

/** Cash that enters قاسە from a sale row (excludes debt + FIB). */
export function saleCashInAmount(s) {
    if (!s) return 0;
    const total = parseFloat(s.total) || 0;
    const pm = String(s.payment_method || '').toLowerCase();
    if (pm === 'debt') return 0;
    if (pm === 'fib' || pm === 'bank' || pm === 'bankcard' || pm === 'card') return 0;
    const bank = Math.max(0, parseFloat(s.bank_amount != null ? s.bank_amount : s.paid_bank) || 0);
    const debt = Math.max(0, parseFloat(s.debt_amount) || 0);
    // paid_cash=0 is common on legacy pure-cash rows — only trust 0 when split/debt/bank says cash was zero
    if (s.paid_cash != null && s.paid_cash !== '' && Number.isFinite(parseFloat(s.paid_cash))) {
        const pc = Math.max(0, parseFloat(s.paid_cash) || 0);
        if (pc > 0) return pc;
        if (pm === 'split' || debt > 0 || bank > 0) return 0;
    }
    if (s.paid_amount != null && s.paid_amount !== '' && Number.isFinite(parseFloat(s.paid_amount))) {
        const pa = Math.max(0, parseFloat(s.paid_amount) || 0);
        if (pa > 0) return Math.max(0, pa - bank);
        if (pm === 'split' || debt > 0 || bank > 0) return 0;
    }
    return Math.max(0, total - debt - bank);
}

export function saleFibAmount(s) {
    if (!s) return 0;
    const pm = String(s.payment_method || '').toLowerCase();
    if (pm === 'fib' || pm === 'bank' || pm === 'bankcard' || pm === 'card') return parseFloat(s.total) || 0;
    const bank = Math.max(0, parseFloat(s.bank_amount != null ? s.bank_amount : s.paid_bank) || 0);
    return bank;
}

export function saleDebtAmount(s) {
    if (!s) return 0;
    const pm = String(s.payment_method || '').toLowerCase();
    if (pm === 'debt') return parseFloat(s.total) || 0;
    const debt = parseFloat(s.debt_amount);
    if (Number.isFinite(debt) && debt > 0) return debt;
    return 0;
}

/** Operational expenses only — purchases (type=purchase) and debt payments are separate from مەزاختن. */
export function isOperationalExpenseRow(e) {
    if (!e) return false;
    const ty = e.type;
    if (ty === 'purchase' || ty === 'debt_payment' || ty === 'purchase_return') return false;
    if (ty != null && ty !== '' && ty !== 'operational') return false;
    const note = String(e.note || '');
    if (e.transaction_id && (note.indexOf('کڕین') >= 0 || note.indexOf('شراء') >= 0)) return false;
    return true;
}

export function filterOperationalExpenses(list) {
    return (Array.isArray(list) ? list : []).filter(isOperationalExpenseRow);
}

/** Cash staff pay stored on expense notes: Salary: Name / Advance: Name. */
export function staffPayExpenseKind(note) {
    const s = String(note || '');
    if (/Advance\s*:/i.test(s) || /نزبا\s*:/.test(s) || /سلفة\s*:/.test(s) || /سلفه\s*:/.test(s)) return 'advance';
    if (/Salary\s*:/i.test(s) || /مووچە\s*:/.test(s) || /راتب\s*:/.test(s)) return 'salary';
    return '';
}

function normStaffPayName(s) {
    return String(s || '').replace(/\s+/g, ' ').trim().toLowerCase();
}

export function staffPayExpenseStaffName(note) {
    const s = String(note || '');
    const m = s.match(/(?:Salary|Advance|مووچە|راتب|نزبا|سلفة|سلفه)\s*:\s*(.+)$/i);
    if (!m) return '';
    return String(m[1] || '').replace(/\s+[—\-–].*$/, '').replace(/\s+\([^)]*\)\s*$/, '').trim();
}

export function expenseTargetsStaff(e, staffName) {
    if (!e || !staffName) return false;
    const want = normStaffPayName(staffName);
    if (!want) return false;
    const named = normStaffPayName(staffPayExpenseStaffName(e.note));
    if (named && (named === want || named.indexOf(want) === 0 || want.indexOf(named) === 0)) return true;
    const note = normStaffPayName(e.note);
    return note.indexOf(want) !== -1 && staffPayExpenseKind(e.note) !== '';
}

export function listStaffPayExpenses(list, staffName) {
    return (Array.isArray(list) ? list : []).filter(function (e) {
        if (!e) return false;
        const ty = String(e.type || '');
        if (ty === 'purchase' || ty === 'debt_payment' || ty === 'purchase_return' || ty === 'debt_payment_fib') return false;
        if (staffPayExpenseKind(e.note) === '') return false;
        return !staffName || expenseTargetsStaff(e, staffName);
    }).sort(function (a, b) {
        return String(b.date || '').localeCompare(String(a.date || ''));
    });
}

export function sumStaffPayExpenses(list, kind, staffName, startDate, endDate) {
    const rows = listStaffPayExpenses(list, staffName);
    let sum = 0;
    const startMs = startDate ? startDate.getTime() : 0;
    const endMs = endDate ? endDate.getTime() : Number.POSITIVE_INFINITY;
    for (let i = 0; i < rows.length; i++) {
        const e = rows[i];
        if (kind && staffPayExpenseKind(e.note) !== kind) continue;
        if (startDate || endDate) {
            const raw = (typeof parseSQLDate === 'function') ? parseSQLDate(e.date) : new Date(e.date);
            const t = raw && !isNaN(raw.getTime()) ? raw.getTime() : 0;
            if (t < startMs || t > endMs) continue;
        }
        sum += (typeof expenseAmountIqd === 'function') ? expenseAmountIqd(e) : (parseFloat(e.amount) || 0);
    }
    return sum;
}

export function expenseRecordCurrency(row) {
    const c = String((row && row.currency) || '').toUpperCase();
    if (c === 'USD' || c === 'IQD') return c;
    return 'IQD';
}

export function expenseRecordRatePerOne(row) {
    const er = Number(row && row.exchange_rate);
    if (Number.isFinite(er) && er >= 10000) return er / 100;
    if (Number.isFinite(er) && er > 0) return er;
    if (row && row.fx_usd_rate != null && row.fx_usd_rate !== '') {
        const b = Math.round(Number(row.fx_usd_rate));
        if (Number.isFinite(b) && b >= 1000) return b / 100;
    }
    if (row && typeof fxUsdRateFormatOpts === 'function') {
        const o = fxUsdRateFormatOpts(row);
        if (o && o.fxUsdRate) {
            const r = Number(o.fxUsdRate) / 100;
            if (r > 0) return r;
        }
    }
    // No frozen stamp: return 0 (callers must not invent live FX for historical debts/expenses).
    return 0;
}

export function expenseAmountIqd(row) {
    if (!row) return 0;
    const amt = Number(row.amount) || 0;
    const cur = expenseRecordCurrency(row);
    if (cur === 'IQD') return roundMoney(amt, 'IQD');
    const r = expenseRecordRatePerOne(row);
    if (!(r > 0)) return roundMoney(amt, 'IQD');
    return convertCurrency(amt, cur, 'IQD', r);
}

export function expenseAmountUsd(row) {
    if (!row) return 0;
    const amt = Number(row.amount) || 0;
    const cur = expenseRecordCurrency(row);
    if (cur === 'USD') return roundUsd(amt);
    const r = expenseRecordRatePerOne(row);
    if (r > 0) return roundUsd(amt / r);
    // IQD row without frozen rate: refuse live re-ratio (locks monthly/daily debt displays).
    return storedIqdToUsdDisplayAmount(amt, row);
}

export function formatExpenseAmountDisplay(row) {
    const iqd = expenseAmountIqd(row);
    const usd = expenseAmountUsd(row);
    const rate = expenseRecordRatePerOne(row);
    if (typeof formatDualCurrencyLines === 'function') {
        const dual = formatDualCurrencyLines(iqd, usd, rate);
        return joinDualCurrencyText(dual);
    }
    return (getDefaultCurrency() === 'USD') ? formatUsdAmount(usd) : formatIqdAmount(iqd);
}

export function formatFrozenIqdAmount(row, iqdAmount) {
    if (row && (row.currency === 'USD' || row.currency === 'IQD' || row.exchange_rate != null)) {
        return formatExpenseAmountDisplay(row);
    }
    const iqd = Number(iqdAmount != null ? iqdAmount : (row && row.amount)) || 0;
    const opts = fxUsdRateFormatOpts(row);
    return formatCurrency(iqd, opts);
}

export function formatFrozenIqdRowsSum(rows, amountFn) {
    const list = Array.isArray(rows) ? rows : [];
    let iqd = 0;
    let usd = 0;
    list.forEach(function (e) {
        if (amountFn) {
            iqd += Number(amountFn(e)) || 0;
        } else {
            iqd += expenseAmountIqd(e);
            usd += expenseAmountUsd(e);
        }
    });
    if (amountFn) {
        usd = convertCurrency(iqd, 'IQD', 'USD', getUsdRatePerOne());
    }
    if (typeof formatDualCurrencyLines === 'function') {
        const dual = formatDualCurrencyLines(iqd, usd, getUsdRatePerOne());
        return joinDualCurrencyText(dual);
    }
    return (getDefaultCurrency() === 'USD') ? formatUsdAmount(usd) : formatIqdAmount(iqd);
}

/** Real supplier purchases — opening warehouse stock (Direct Store) is not a purchase. */
export function isReportablePurchaseSupply(s) {
    if (!s || s.type === 'return' || s.type === 'opening') return false;
    const comp = String(s.company || '').trim();
    if (comp === '' || /^direct\s*store$/i.test(comp)) return false;
    return true;
}

export function filterReportablePurchases(list) {
    return (Array.isArray(list) ? list : []).filter(isReportablePurchaseSupply);
}

export function getFinancialMetrics(targetDateStr = null, opts = {}) {
    if (!state.db) return null;
    const today = targetDateStr || getBusinessDate(new Date());
    const dayPools = opts && opts.dayPools && typeof opts.dayPools === 'object' ? opts.dayPools : null;
    let resolvedDayPools = dayPools;
    if (!resolvedDayPools && typeof window !== 'undefined' && window._dailyDetailCache) {
        const cached = window._dailyDetailCache[today]
            || window._dailyDetailCache[today + '_' + today + '_all'];
        const uid = state.currentUser && state.currentUser.id;
        const epochNow = window._dailyDetailEpoch || 0;
        const epochOk = cached && (cached.epoch == null || cached.epoch === epochNow);
        if (cached && cached.data && cached.data.pools && cached.userId === uid && epochOk
            && (Date.now() - (cached.ts || 0) < 30000)) {
            resolvedDayPools = cached.data.pools;
        }
    }
    let sales;
    let expenses;
    let returns;
    let purchaseReturns;
    let ledgerEntries;
    let customerLedger;
    if (resolvedDayPools) {
        sales = resolvedDayPools.sales || [];
        expenses = resolvedDayPools.expenses || [];
        returns = resolvedDayPools.returns || [];
        purchaseReturns = resolvedDayPools.purchase_returns || [];
        ledgerEntries = resolvedDayPools.ledger || [];
        customerLedger = resolvedDayPools.customer_ledger || [];
    } else {
        const useReportSales = opts && opts.salesScope === 'report';
        const salesPool = useReportSales ? getReportSales() : getAllSales();
        sales = salesPool.filter(s => getBusinessDate(parseSQLDate(s.date || s.created_at)) === today);
        expenses = (state.db.expenses || []).filter(e => getBusinessDate(parseSQLDate(e.date)) === today);
        returns = (state.db.returns || []).filter(r => getBusinessDate(parseSQLDate(r.date)) === today);
        purchaseReturns = (state.db.purchase_returns || []).filter(pr => getBusinessDate(parseSQLDate(pr.date)) === today);
        ledgerEntries = (state.db.ledger || []).filter(l => getBusinessDate(parseSQLDate(l.date || l.created_at)) === today);
        customerLedger = (state.db.customer_ledger || []).filter(cl => getBusinessDate(parseSQLDate(cl.date || cl.created_at)) === today);
    }
    expenses = mergeCompanyDebtExpensesFromLedger(expenses, ledgerEntries, state.db.companies || []);

    const seenSaleIds = new Set();
    sales = sales.filter(function (s) {
        if (!s) return false;
        const id = s.id != null && s.id !== '' ? String(s.id) : '';
        if (!id) return true;
        if (seenSaleIds.has(id)) return false;
        seenSaleIds.add(id);
        return true;
    });

    const productById = buildProductCostById(state.db.products);
    const storeCur = 'IQD';
    /** Always USD for *Usd fields — frozen row rate / stored USD; never live re-ratio. */
    const toUsd = function (iqd, row, usdHint) {
        return storedIqdToUsdDisplayAmount(iqd, row, usdHint);
    };
    let totalSalesMinor = 0n, cashSalesMinor = 0n, debtSalesMinor = 0n, fibSalesMinor = 0n, totalCogsMinor = 0n, totalGiftsValueMinor = 0n;
    let totalSalesUsd = 0, cashSalesUsd = 0, debtSalesUsd = 0, fibSalesUsd = 0, totalCogsUsd = 0, totalGiftsValueUsd = 0;
    let giftsCount = 0;
    sales.forEach(s => {
        if (!s) return;
        const saleIqd = Number(s.total) || 0;
        const totalM = moneyToMinor(saleIqd, storeCur);
        totalSalesMinor += totalM;
        totalSalesUsd += toUsd(saleIqd, s, s.total_usd);
        const debtIqd = saleDebtAmount(s);
        debtSalesMinor += moneyToMinor(debtIqd, storeCur);
        debtSalesUsd += toUsd(debtIqd, s, (s.debt_amount_usd != null ? s.debt_amount_usd : (saleIqd > 0 && s.total_usd != null ? (debtIqd / saleIqd) * Number(s.total_usd) : null)));
        const cashIqd = saleCashInAmount(s);
        cashSalesMinor += moneyToMinor(cashIqd, storeCur);
        cashSalesUsd += toUsd(cashIqd, s, (saleIqd > 0 && s.total_usd != null ? (cashIqd / saleIqd) * Number(s.total_usd) : null));
        const fibIqd = saleFibAmount(s);
        fibSalesMinor += moneyToMinor(fibIqd, storeCur);
        fibSalesUsd += toUsd(fibIqd, s, (saleIqd > 0 && s.total_usd != null ? (fibIqd / saleIqd) * Number(s.total_usd) : null));
        const saleItems = saleOrReturnItems(s);
        saleItems.forEach(i => {
            const q = getSaleLineQty(i);
            const lineCost = resolveSaleLineCost(i, productById) * q;
            totalCogsMinor += moneyToMinor(lineCost, storeCur);
            const costRow = (i && (i.fx_usd_rate != null || i.exchange_rate != null)) ? i : s;
            const costUsdHint = (i && i.cost_usd != null && i.cost_usd !== '')
                ? (Number(i.cost_usd) * q)
                : null;
            totalCogsUsd += toUsd(lineCost, costRow, costUsdHint);
            if (i.isGift) {
                const giftIqd = (Number(i.price) || 0) * q;
                totalGiftsValueMinor += moneyToMinor(giftIqd, storeCur);
                const giftUsdHint = (i && i.bill_unit_usd != null && i.bill_unit_usd !== '')
                    ? (Number(i.bill_unit_usd) * q)
                    : null;
                totalGiftsValueUsd += toUsd(giftIqd, (i && i.fx_usd_rate != null) ? i : s, giftUsdHint);
                giftsCount += q;
            }
        });
    });
    let totalReturnsMinor = 0n, totalReturnsCostMinor = 0n, cashRefundsMinor = 0n;
    const isCashReturn = (r) => {
        const pm = String((r && r.payment_method) || '').toLowerCase();
        if (pm === 'debt' || pm === 'fib' || pm === 'bank' || pm === 'bankcard' || pm === 'card') return false;
        return true;
    };
    let totalReturnsUsd = 0, totalReturnsCostUsd = 0, cashRefundsUsd = 0;
    returns.forEach(r => {
        if (!r) return;
        const retIqd = Number(r.total) || 0;
        totalReturnsMinor += moneyToMinor(retIqd, storeCur);
        totalReturnsUsd += toUsd(retIqd, r, r.total_usd);
        if (isCashReturn(r)) {
            cashRefundsMinor += moneyToMinor(retIqd, storeCur);
            cashRefundsUsd += toUsd(retIqd, r, r.total_usd);
        }
        const retItems = saleOrReturnItems(r);
        retItems.forEach(i => {
            const q = getSaleLineQty(i);
            const lineCost = resolveSaleLineCost(i, productById) * q;
            totalReturnsCostMinor += moneyToMinor(lineCost, storeCur);
            const costRow = (i && (i.fx_usd_rate != null || i.exchange_rate != null)) ? i : r;
            totalReturnsCostUsd += toUsd(lineCost, costRow, (i && i.cost_usd != null ? Number(i.cost_usd) * q : null));
        });
    });
    const opExpRows = expenses.filter(isOperationalExpenseRow);
    const opExpensesMinor = opExpRows.reduce((s, e) => s + moneyToMinor(expenseAmountIqd(e), storeCur), 0n);
    const opExpensesUsd = opExpRows.reduce((s, e) => s + expenseAmountUsd(e), 0);
    const cashPurchRows = expenses.filter(e => e.type === 'purchase');
    const cashPurchasesMinor = cashPurchRows.reduce((s, e) => s + moneyToMinor(expenseAmountIqd(e), storeCur), 0n);
    const cashPurchasesUsd = cashPurchRows.reduce((s, e) => s + expenseAmountUsd(e), 0);
    let fibPurchasesMinor = 0n;
    let fibPurchasesUsd = 0;
    let totalPurchasesMinor = 0n;
    let totalPurchasesUsd = 0;
    const suppliesPool = resolvedDayPools && resolvedDayPools.supplies
        ? resolvedDayPools.supplies
        : ((state.db && state.db.supplies) || []).filter(s => getBusinessDate(parseSQLDate(s.date)) === today);
    suppliesPool.forEach(function (s) {
        if (!isReportablePurchaseSupply(s)) return;
        const costIqd = Number(s.totalCost) || 0;
        totalPurchasesMinor += moneyToMinor(costIqd, storeCur);
        totalPurchasesUsd += toUsd(costIqd, s);
        const ty = String(s.type || '').toLowerCase();
        if (ty === 'fib' || ty === 'bank' || ty === 'bankcard') {
            fibPurchasesMinor += moneyToMinor(costIqd, storeCur);
            fibPurchasesUsd += toUsd(costIqd, s);
        }
    });
    const companyDebtPayRows = expenses.filter(e => e.type === 'debt_payment' && !isPurchaseLinkedDebtPayment(e, expenses));
    const companyDebtPaymentsMinor = companyDebtPayRows.reduce((s, e) => s + moneyToMinor(expenseAmountIqd(e), storeCur), 0n);
    const companyDebtPaymentsUsd = companyDebtPayRows.reduce((s, e) => s + expenseAmountUsd(e), 0);
    const companyDebtPayFibRows = expenses.filter(e => e.type === 'debt_payment_fib' && !isPurchaseLinkedDebtPayment(e, expenses));
    const companyDebtPaymentsFibMinor = companyDebtPayFibRows.reduce((s, e) => s + moneyToMinor(expenseAmountIqd(e), storeCur), 0n);
    const companyDebtPaymentsFibUsd = companyDebtPayFibRows.reduce((s, e) => s + expenseAmountUsd(e), 0);
    const debtPayRowsCash = (customerLedger || []).filter(cl => isCustomerDebtPaymentRow(cl) && customerDebtPaymentChannel(cl) === 'cash');
    const debtPayRowsFib = (customerLedger || []).filter(cl => isCustomerDebtPaymentRow(cl) && customerDebtPaymentChannel(cl) === 'fib');
    const debtPaymentsInMinor = sumCustomerDebtPaymentsInMinor(customerLedger, ledgerEntries);
    const debtPaymentsInFibMinor = sumCustomerDebtPaymentsInFibMinor(customerLedger, ledgerEntries);
    let debtPaymentsInUsd = 0;
    let debtPaymentsInFibUsd = 0;
    const addDebtUsd = function (rows, intoFib) {
        rows.forEach(function (cl) {
            const amt = Math.abs(Number(cl.amount) || 0);
            let u = toUsd(amt, ledgerRowFxSource(cl));
            if (!(u > 0) && amt > 0) {
                const tid = String(cl.target_id != null ? cl.target_id : '');
                const saleFx = (state.db.sales || []).find(function (s) {
                    return s && String(s.customer_id) === tid
                        && (s.total_usd != null || s.exchange_rate != null || s.fx_usd_rate != null);
                });
                if (saleFx) u = toUsd(amt, saleFx);
            }
            if (intoFib) debtPaymentsInFibUsd += u;
            else debtPaymentsInUsd += u;
        });
    };
    if (debtPayRowsCash.length || debtPayRowsFib.length) {
        addDebtUsd(debtPayRowsCash, false);
        addDebtUsd(debtPayRowsFib, true);
    } else {
        (ledgerEntries || []).filter(l => l && String(l.type || '').toLowerCase() === 'debt_payment_in').forEach(function (l) {
            debtPaymentsInUsd += toUsd(l.amount || 0, l);
        });
        (ledgerEntries || []).filter(l => l && String(l.type || '').toLowerCase() === 'debt_payment_in_fib').forEach(function (l) {
            debtPaymentsInFibUsd += toUsd(l.amount || 0, l);
        });
    }
    const purchaseReturnsInMinor = sumPurchaseReturnsCashInMinor(purchaseReturns, ledgerEntries, expenses, resolvedDayPools && resolvedDayPools.supplies ? resolvedDayPools.supplies : (state.db && state.db.supplies) || []);
    const purchaseReturnsDisplayMinor = sumPurchaseReturnsDisplayMinor(purchaseReturns);
    let purchaseReturnsInUsd = 0;
    let totalPurchaseReturnsUsd = 0;
    (purchaseReturns || []).forEach(function (pr) {
        if (!pr) return;
        const disp = pr.total != null ? Number(pr.total) || 0 : 0;
        totalPurchaseReturnsUsd += toUsd(disp, pr);
        const cashPart = (pr.cash_refunded != null && pr.cash_refunded !== '') ? Number(pr.cash_refunded) || 0 : disp;
        purchaseReturnsInUsd += toUsd(cashPart, pr);
    });
    const wasteLedgerRows = ledgerEntries.filter(l => l && l.type === 'waste');
    let wasteLossMinor = wasteLedgerRows.reduce((s, l) => s + moneyToMinor(l.amount || 0, storeCur), 0n);
    let wasteLossUsd = wasteLedgerRows.reduce((s, l) => s + toUsd(l.amount || 0, l), 0);
    let wasteCount = wasteLedgerRows.length;
    if (resolvedDayPools && Array.isArray(resolvedDayPools.waste) && resolvedDayPools.waste.length) {
        wasteCount = resolvedDayPools.waste.length;
        if (wasteLossMinor === 0n) {
            wasteLossMinor = resolvedDayPools.waste.reduce((s, w) => s + moneyToMinor(w && w.cost != null ? w.cost : 0, storeCur), 0n);
            wasteLossUsd = resolvedDayPools.waste.reduce((s, w) => s + toUsd(w && w.cost != null ? w.cost : 0, w), 0);
        }
    } else if (!resolvedDayPools && state.db && Array.isArray(state.db.waste)) {
        const wasteRowsToday = state.db.waste.filter(w => getBusinessDate(parseSQLDate(w.date)) === today);
        if (wasteRowsToday.length) {
            wasteCount = wasteRowsToday.length;
            if (wasteLossMinor === 0n) {
                wasteLossMinor = wasteRowsToday.reduce((s, w) => s + moneyToMinor(w && w.cost != null ? w.cost : 0, storeCur), 0n);
                wasteLossUsd = wasteRowsToday.reduce((s, w) => s + toUsd(w && w.cost != null ? w.cost : 0, w), 0);
            }
        }
    }
    const grossProfitMinor = (totalSalesMinor - totalReturnsMinor) - (totalCogsMinor - totalReturnsCostMinor);
    const netProfitMinor = grossProfitMinor - opExpensesMinor - wasteLossMinor;
    const cashInMinor = cashSalesMinor + debtPaymentsInMinor + purchaseReturnsInMinor;
    const cashOutMinor = opExpensesMinor + cashPurchasesMinor + companyDebtPaymentsMinor + cashRefundsMinor;
    const cashMovementMinor = cashInMinor - cashOutMinor;

    const totalSales = roundMoney(moneyFromMinor(totalSalesMinor, storeCur), storeCur);
    const cashSales = roundMoney(moneyFromMinor(cashSalesMinor, storeCur), storeCur);
    const debtSales = roundMoney(moneyFromMinor(debtSalesMinor, storeCur), storeCur);
    const fibSales = roundMoney(moneyFromMinor(fibSalesMinor, storeCur), storeCur);
    const totalReturns = roundMoney(moneyFromMinor(totalReturnsMinor, storeCur), storeCur);
    const totalReturnsCost = roundMoney(moneyFromMinor(totalReturnsCostMinor, storeCur), storeCur);
    const totalCogs = roundMoney(moneyFromMinor(totalCogsMinor, storeCur), storeCur);
    const opExpenses = roundMoney(moneyFromMinor(opExpensesMinor, storeCur), storeCur);
    const cashPurchases = roundMoney(moneyFromMinor(cashPurchasesMinor, storeCur), storeCur);
    const fibPurchases = roundMoney(moneyFromMinor(fibPurchasesMinor, storeCur), storeCur);
    const totalPurchases = roundMoney(moneyFromMinor(totalPurchasesMinor, storeCur), storeCur);
    const companyDebtPayments = roundMoney(moneyFromMinor(companyDebtPaymentsMinor, storeCur), storeCur);
    const debtPaymentsIn = roundMoney(moneyFromMinor(debtPaymentsInMinor, storeCur), storeCur);
    const debtPaymentsInFib = roundMoney(moneyFromMinor(debtPaymentsInFibMinor, storeCur), storeCur);
    const companyDebtPaymentsFib = roundMoney(moneyFromMinor(companyDebtPaymentsFibMinor, storeCur), storeCur);
    const purchaseReturnsIn = roundMoney(moneyFromMinor(purchaseReturnsInMinor, storeCur), storeCur);
    const totalPurchaseReturns = roundMoney(moneyFromMinor(purchaseReturnsDisplayMinor, storeCur), storeCur);
    const grossProfit = roundMoney(moneyFromMinor(grossProfitMinor, storeCur), storeCur);
    const netProfit = roundMoney(moneyFromMinor(netProfitMinor, storeCur), storeCur);
    const cashMovement = roundMoney(moneyFromMinor(cashMovementMinor, storeCur), storeCur);
    const wasteLoss = roundMoney(moneyFromMinor(wasteLossMinor, storeCur), storeCur);
    const cashRefunds = roundMoney(moneyFromMinor(cashRefundsMinor, storeCur), storeCur);
    const returnProfitImpact = roundMoney(moneyFromMinor(totalReturnsMinor - totalReturnsCostMinor, storeCur), storeCur);
    const totalGiftsValue = roundMoney(moneyFromMinor(totalGiftsValueMinor, storeCur), storeCur);
    const salesCount = sales.length;
    const grossProfitUsd = (totalSalesUsd - totalReturnsUsd) - (totalCogsUsd - totalReturnsCostUsd);
    const netProfitUsd = grossProfitUsd - opExpensesUsd - wasteLossUsd;
    const cashMovementUsd = (cashSalesUsd + debtPaymentsInUsd + purchaseReturnsInUsd)
        - (opExpensesUsd + cashPurchasesUsd + companyDebtPaymentsUsd + cashRefundsUsd);
    const returnProfitImpactUsd = totalReturnsUsd - totalReturnsCostUsd;
    return {
        totalSales, cashSales, debtSales, fibSales, totalReturns, totalReturnsCost, totalCogs,
        opExpenses, cashPurchases, fibPurchases, totalPurchases, companyDebtPayments, companyDebtPaymentsFib,
        debtPaymentsIn, debtPaymentsInFib, purchaseReturnsIn, totalPurchaseReturns, grossProfit, netProfit,
        cashMovement, wasteLoss, wasteCount, cashRefunds, returnProfitImpact,
        totalGiftsValue, giftsCount,
        salesCount, saleCount: salesCount,
        totalSalesUsd: roundUsd(totalSalesUsd),
        cashSalesUsd: roundUsd(cashSalesUsd),
        debtSalesUsd: roundUsd(debtSalesUsd),
        fibSalesUsd: roundUsd(fibSalesUsd),
        totalReturnsUsd: roundUsd(totalReturnsUsd),
        totalCogsUsd: roundUsd(totalCogsUsd),
        opExpensesUsd: roundUsd(opExpensesUsd),
        cashPurchasesUsd: roundUsd(cashPurchasesUsd),
        fibPurchasesUsd: roundUsd(fibPurchasesUsd),
        totalPurchasesUsd: roundUsd(totalPurchasesUsd),
        companyDebtPaymentsUsd: roundUsd(companyDebtPaymentsUsd),
        companyDebtPaymentsFibUsd: roundUsd(companyDebtPaymentsFibUsd),
        debtPaymentsInUsd: roundUsd(debtPaymentsInUsd),
        debtPaymentsInFibUsd: roundUsd(debtPaymentsInFibUsd),
        purchaseReturnsInUsd: roundUsd(purchaseReturnsInUsd),
        totalPurchaseReturnsUsd: roundUsd(totalPurchaseReturnsUsd),
        wasteLossUsd: roundUsd(wasteLossUsd),
        grossProfitUsd: roundUsd(grossProfitUsd),
        netProfitUsd: roundUsd(netProfitUsd),
        cashMovementUsd: roundUsd(cashMovementUsd),
        cashRefundsUsd: roundUsd(cashRefundsUsd),
        returnProfitImpactUsd: roundUsd(returnProfitImpactUsd),
        totalGiftsValueUsd: roundUsd(totalGiftsValueUsd)
    };
}

export function getReportSales(includeVoid = false) {
    const all = getAllSales(includeVoid);
    const role = state.currentUser && state.currentUser.role;
    /** Align with get_sync_data / server: admin & manager see full shop in reports & calendar */
    if (state.currentUser && (role === 'admin' || role === 'manager')) return all;
    if (state.currentUser) return all.filter(s => s.cashier === state.currentUser.name);
    return [];
}
