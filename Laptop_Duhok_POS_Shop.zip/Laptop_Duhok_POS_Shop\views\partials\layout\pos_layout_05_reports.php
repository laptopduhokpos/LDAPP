        <!-- WORK CALENDAR (تقويم العمل) -->
        <div id="view-calendar" class="workspace active txn-calendar-view">
            <h2 class="calendar-view-title"><i class="fas fa-chart-pie"></i> <span data-i18n="nav_calendar">شاشا سەرەکی</span></h2>

            <div class="card calendar-main-card" style="border-top: 5px solid #8b5cf6;">
                <div class="calendar-toolbar" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:15px; margin-bottom:20px;">
                    <div style="display:flex; gap:15px; align-items:center;">
                        <button class="btn btn-info" onclick="renderWorkCalendar(0)"><i class="fas fa-sync"></i> <span data-i18n="cal_btn_today">ئەڤرۆ</span></button>
                        <button class="btn btn-dark btn-sm btn-icon-only" onclick="typeof openRevenueComparisonModal==='function'&&openRevenueComparisonModal()" title="هەڤبەرکرنا داهاتی (Comparison)" style="width:36px; height:36px; border-radius:10px;"><i class="fas fa-chart-line"></i></button>
                        <select id="cal-staff-filter" class="input-std" style="min-width: 150px; margin:0; padding: 4px 10px;" onchange="renderWorkCalendar()">
                            <option value="all">هەمی کارمەند</option>
                        </select>
                    </div>
                    <div class="calendar-month-nav" style="display:flex; gap:10px; align-items:center; position:relative;">
                        <button type="button" class="btn btn-brand" onclick="renderWorkCalendar(-1)" aria-label="prev"><i class="fas fa-chevron-right"></i></button>
                        <button type="button" id="cal-month-title" class="cal-month-title-btn" onclick="typeof toggleCalMonthPicker==='function'&&toggleCalMonthPicker(event)" title="هەڵبژاردنا مانگ و سال" data-i18n-title="cal_pick_title">---</button>
                        <button type="button" class="btn btn-brand" onclick="renderWorkCalendar(1)" aria-label="next"><i class="fas fa-chevron-left"></i></button>
                        <div id="cal-month-picker" class="cal-month-picker" style="display:none;" role="dialog" aria-label="month year picker" onclick="event.stopPropagation();">
                            <div class="cal-month-picker__year">
                                <button type="button" class="btn btn-sm btn-brand" onclick="typeof shiftCalMonthPickerYear==='function'&&shiftCalMonthPickerYear(-1)"><i class="fas fa-chevron-right"></i></button>
                                <span id="cal-month-picker-year" class="cal-month-picker__year-num">2026</span>
                                <button type="button" class="btn btn-sm btn-brand" onclick="typeof shiftCalMonthPickerYear==='function'&&shiftCalMonthPickerYear(1)"><i class="fas fa-chevron-left"></i></button>
                            </div>
                            <div class="cal-month-picker__months">
                                <button type="button" class="cal-month-picker__btn" data-month="0">جانێوەری</button>
                                <button type="button" class="cal-month-picker__btn" data-month="1">فێبریوەری</button>
                                <button type="button" class="cal-month-picker__btn" data-month="2">مارچ</button>
                                <button type="button" class="cal-month-picker__btn" data-month="3">ئەپریل</button>
                                <button type="button" class="cal-month-picker__btn" data-month="4">مەی</button>
                                <button type="button" class="cal-month-picker__btn" data-month="5">جوونی</button>
                                <button type="button" class="cal-month-picker__btn" data-month="6">جوولای</button>
                                <button type="button" class="cal-month-picker__btn" data-month="7">ئۆگەست</button>
                                <button type="button" class="cal-month-picker__btn" data-month="8">سێپتێمبەر</button>
                                <button type="button" class="cal-month-picker__btn" data-month="9">ئۆکتۆبەر</button>
                                <button type="button" class="cal-month-picker__btn" data-month="10">نۆڤێمبەر</button>
                                <button type="button" class="cal-month-picker__btn" data-month="11">دیسێمبەر</button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Monthly Summary (same fields as daily summary) -->
                <div id="calendar-month-summary-panel" class="calendar-month-summary-panel"></div>

                <div id="work-calendar-grid" style="display:grid; grid-template-columns: repeat(7, minmax(0, 1fr)); gap:8px; background:var(--input-bg); padding:15px; border-radius:15px; border:1px solid var(--border);"></div>
            </div>
        </div>

        <!-- NOTIFICATIONS VIEW -->
        <div id="view-notifications" class="workspace notif-view" translate="no">
            <div class="notif-view-head">
                <h2><i class="fas fa-bell"></i> <span data-i18n="nav_notifications">ئاگەهدارکرن</span></h2>
                <div style="display:flex; gap:10px; align-items:center;">
                    <!-- SECURITY CENTER BUTTON (Moved from Reports) -->
                    <button type="button" data-perm="view_audit_logs" class="btn btn-sm btn-info" onclick="openSecurityModal()" title="سەنتەرێ ئاسایشێ (Security Center)">
                        <i class="fas fa-shield-alt"></i> <span data-i18n="reports_security_center">سەنتەرێ ئاسایشێ</span>
                    </button>
                    <button type="button" class="btn btn-sm btn-dark" onclick="renderNotifications()"><i class="fas fa-sync"></i> <span data-i18n="btn_refresh">نوێکردنەوە</span></button>
                </div>
            </div>
            <div id="notification-container" class="notif-container"></div>
        </div>

        <!-- ACCESS DENIED (redirect when user hits URL without permission) -->
        <div id="view-access-denied" class="workspace" style="display:none;">
            <div class="card" style="max-width:480px; margin:80px auto; text-align:center; padding:40px; border:2px solid var(--danger); background:linear-gradient(180deg, rgba(239,68,68,0.08) 0%, var(--card) 100%);">
                <div style="width:80px; height:80px; margin:0 auto 20px; background:rgba(239,68,68,0.2); border-radius:50%; display:flex; align-items:center; justify-content:center;"><i class="fas fa-lock" style="font-size:2.5rem; color:var(--danger);"></i></div>
                <h2 style="margin:0 0 12px; color:var(--danger);">دەستوور نینە (Access Denied)</h2>
                <p style="color:var(--text-muted); margin:0 0 24px;">تۆ دەستوورا چوونەژوورە بەشێک نینە. ئەگەر پێتڤیە، داوای لە ڕێڤەبەر بکە.</p>
                <button type="button" class="btn btn-primary" onclick="nav('calendar')"><i class="fas fa-home"></i> گەڕانەوە بۆ سەرەوە</button>
            </div>
        </div>

        <!-- STAFF CENTER (مركز <span data-i18n="staff">کارمەند</span>) -->
        <div id="view-staff" class="workspace staff-center-view" translate="no">
            <h2 class="staff-page-title"><i class="fas fa-user-tie"></i> <span data-i18n="nav_staff">کارمەند</span></h2>
            
            <div class="card protected staff-main-card">
                <div class="staff-center-header">
                    <h3 class="staff-center-title"><i class="fas fa-users-cog"></i> <span data-i18n="staff_center_title">ناڤەندێ کارمەندان</span></h3>
                    <span class="staff-team-badge"><span data-i18n="staff_team_badge">ڕێڤەبرنا تیمێ</span></span>
                </div>

                <div class="staff-layout-grid">
                    <!-- ADD USER FORM (hidden without edit_staff) -->
                    <div data-perm="edit_staff" class="staff-form-card">
                        <h4 class="staff-form-title">
                            <i class="fas fa-user-plus"></i> <span data-i18n="staff_form_add_title">زێدەکرنا ئەندامەکێ نوی</span>
                        </h4>
                        
                        <div class="staff-field-row">
                            <label class="staff-field-label"><span data-i18n="staff_label_name">ناڤێ کارمەندی</span></label>
                            <div class="staff-input-wrap">
                                <i class="fas fa-user staff-input-icon"></i>
                                <input type="text" id="new-u-name" class="input-std staff-input-control" data-i18n-placeholder="staff_placeholder_name" placeholder="ناڤ بنڤیسە...">
                            </div>
                        </div>

                        <div class="staff-field-row">
                            <label class="staff-field-label"><span data-i18n="staff_label_pin">کۆدێ نهێنی (PIN Code)</span></label>
                            <div class="staff-input-wrap">
                                <i class="fas fa-key staff-input-icon"></i>
                                <input type="text" inputmode="numeric" id="new-u-pin" class="input-std staff-input-control staff-pin-input" placeholder="****" maxlength="4" pattern="[0-9]*" autocomplete="off" oninput="this.value=this.value.replace(/\D/g,'').slice(0,4)">
                            </div>
                        </div>

                        <div class="staff-meta-row">
                            <div class="staff-meta-col">
                                <label class="staff-field-label"><span data-i18n="staff_label_role">ڕۆڵ</span></label>
                                <select id="new-u-role" class="input-std staff-input-control" onchange="toggleUserPermissions(true)">
                                    <option value="admin" data-i18n-opt="role_option_admin"></option>
                                    <option value="manager" data-i18n-opt="role_option_manager"></option>
                                    <option value="supervisor" data-i18n-opt="role_option_supervisor"></option>
                                    <option value="cashier" data-i18n-opt="role_option_cashier" selected></option>
                                    <option value="stock_manager" data-i18n-opt="role_option_stock_manager"></option>
                                    <option value="inventory_clerk" data-i18n-opt="role_option_inventory_clerk"></option>
                                    <option value="accountant" data-i18n-opt="role_option_accountant"></option>
                                    <option value="finance_viewer" data-i18n-opt="role_option_finance_viewer"></option>
                                    <option value="sales_rep" data-i18n-opt="role_option_sales_rep"></option>
                                    <option value="sales_viewer" data-i18n-opt="role_option_sales_viewer"></option>
                                    <option value="waiter" data-i18n-opt="role_option_waiter"></option>
                                </select>
                            </div>
                            <div class="staff-meta-col">
                                <label class="staff-field-label"><span data-i18n="staff_label_rate">مووچە (کاتژمێر)</span></label>
                                <input type="text" inputmode="numeric" id="new-u-rate" class="input-std staff-input-control" placeholder="0">
                            </div>
                        </div>

                        <!-- PERMISSIONS CHECKBOXES (Granular - every action) -->
                        <div id="user-permissions-box" class="staff-permissions-box">
                            <label class="staff-permissions-heading"><span data-i18n="staff_perm_heading">دەستوور:</span></label>

                            <!-- HIGHLIGHTED: PROFIT VISIBILITY (controls every profit display anywhere in the app) -->
                            <div class="staff-profit-highlight">
                                <label class="staff-profit-toggle">
                                    <input type="checkbox" class="perm-chk staff-profit-checkbox" value="view_profit">
                                    <span class="staff-profit-label" data-i18n="staff_perm_view_profit_title"></span>
                                </label>
                                <small class="staff-profit-hint" data-i18n="staff_perm_view_profit_hint"></small>
                            </div>
                            <div class="staff-profit-highlight" style="border-color:#d97706; background:linear-gradient(135deg, rgba(217,119,6,0.12), rgba(245,158,11,0.06));">
                                <label class="staff-profit-toggle">
                                    <input type="checkbox" class="perm-chk" value="view_cost" style="accent-color:#d97706;">
                                    <span class="staff-profit-label" style="color:#d97706;" data-i18n="staff_perm_view_cost_title"></span>
                                </label>
                                <small class="staff-profit-hint" data-i18n="staff_perm_view_cost_hint"></small>
                            </div>

                            <div class="staff-permissions-grid">
                                <div class="perm-group-title"><span data-i18n="staff_perm_grp_visible">📋 بەشێن دیار</span></div>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="pos_access"> <span data-i18n="perm_pos_access">تەختەی فرۆتن / مێز</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="warehouse_view"> <span data-i18n="perm_warehouse_view">کۆگە</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="products_manage"> <span data-i18n="perm_products_manage">بەرهەمەکان</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="companies_manage"> <span data-i18n="perm_companies_manage">کۆمپانیا و کڕین</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="debt_view"> <span data-i18n="perm_debt_view">قەرز</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="expenses_manage"> <span data-i18n="perm_expenses_manage">مەزاختن</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="waste_manage"> <span data-i18n="perm_waste_manage">تەلەف</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="recipes_manage"> <span data-i18n="perm_recipes_manage">ڕەسەپی</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="delivery_view"> <span data-i18n="perm_delivery_view">گەهاندن</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="reports_view"> <span data-i18n="perm_reports_view">ڕاپۆرت + ڕۆژمێر</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="view_daily_summary"> <span data-i18n="perm_view_daily_summary">مێژوویا ئەڤرۆ</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="send_telegram_report"> <span data-i18n="perm_send_telegram_report">ناردنی تیلیگرام</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="view_sales_history"> <span data-i18n="perm_view_sales_history">مێژوویا فرۆتنێ</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="view_purchase_history"> <span data-i18n="perm_view_purchase_history">مێژوویا کڕینێ</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="returns_manage"> <span data-i18n="perm_returns_manage">زڤڕاندن</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="edit_staff"> <span data-i18n="perm_edit_staff">کارمەند</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="access_settings"> <span data-i18n="perm_access_settings">ڕێکخستن</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="manage_printers"> <span data-i18n="perm_manage_printers">پرنتەر</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="view_audit_logs"> <span data-i18n="perm_view_audit_logs">تۆمارێ ئاسایش</span></label>

                                <div class="perm-group-title"><span data-i18n="staff_perm_grp_pos">🎯 کارەکانی تەختەی فرۆتن</span></div>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="pos_sell"> <span data-i18n="perm_pos_sell">فرۆتن</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="pos_discount"> <span data-i18n="perm_pos_discount">داشکاندن</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="pos_price"> <span data-i18n="perm_pos_price">گوهۆڕینا بهای</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="pos_delete_item"> <span data-i18n="perm_pos_delete_item">ژێبرنا ئایتمی</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="pos_void_invoice"> <span data-i18n="perm_pos_void_invoice">هەلوەشاندنا وەسڵێ</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="pos_open_drawer"> <span data-i18n="perm_pos_open_drawer">کرنتەوەی کەش</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="pos_kitchen"> <span data-i18n="perm_pos_kitchen">چاپا مەدبەخێ</span></label>

                                <div class="perm-group-title"><span data-i18n="staff_perm_grp_wh">📦 کارێن کۆگە</span></div>
                                <label class="staff-perm-item perm-multi-warehouse-wrap"><input type="checkbox" class="perm-chk" value="multi_warehouse"> <span data-i18n="perm_multi_warehouse">کۆگەهێن فرە</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="stock_view"> <span data-i18n="perm_stock_view">دیتنا کۆگە</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="stock_edit"> <span data-i18n="perm_stock_edit">دەستکاری کۆگە</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="stock_delete"> <span data-i18n="perm_stock_delete">ژێبرنا کۆگە</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="stock_audit"> <span data-i18n="perm_stock_audit">پێداچوون/جەرد</span></label>

                                <div class="perm-group-title"><span data-i18n="staff_perm_grp_fin">💰 دارایی</span></div>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="view_expenses"> <span data-i18n="perm_view_expenses">دیتنا مەزاختن</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="debt_manage"> <span data-i18n="perm_debt_manage">دەستکاریا قەرزان</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="manage_debts"> <span data-i18n="perm_manage_debts">ڕێڤەبرنا قەرزان</span></label>
                                <label class="staff-perm-item"><input type="checkbox" class="perm-chk" value="set_exchange_rate"> <span data-i18n="perm_set_exchange_rate">ڕێکخستنا نرخی دراو</span></label>
                            </div>
                        </div>

                        <button type="button" class="btn btn-dark staff-apply-role-btn" onclick="toggleUserPermissions(true)"><i class="fas fa-redo"></i> <span data-i18n="staff_apply_role_template">گەڕاندن بۆ بنەڕەتی ئەم ڕۆڵە</span></button>

                        <div class="staff-form-actions">
                            <button type="button" id="btn-u-save" class="btn btn-success staff-save-btn staff-register-btn" onclick="addUser()"><i class="fas fa-save"></i> <span data-i18n="staff_btn_register">تۆمارکرن</span></button>
                            <button type="button" id="btn-u-cancel" class="btn btn-dark" onclick="cancelUserEdit()"><i class="fas fa-times"></i> <span data-i18n="btn_cancel">پاشگەزبوون</span></button>
                        </div>
                    </div>

                    <!-- USERS LIST -->
                    <div class="staff-list-card">
                        <div class="staff-list-header">
                            <h4 class="staff-list-title"><i class="fas fa-list-ul"></i> <span data-i18n="staff_list_title">لیستا کارمەندان</span></h4>
                            <div class="staff-list-search">
                                <i class="fas fa-search"></i>
                                <input type="text" id="staff-search" class="input-std" data-i18n-placeholder="staff_search_ph" placeholder="لێگەریان..." oninput="renderUsers()">
                            </div>
                            <button type="button" class="btn btn-sm btn-danger" data-perm="edit_staff" onclick="deleteAllUsers()"><i class="fas fa-trash"></i> <span data-i18n="staff_btn_delete_all">ژێبرنا هەمیان</span></button>
                        </div>
                        <div id="users-list" class="staff-users-grid"></div>
                    </div>
                </div>
            </div>

            <div class="card protected staff-shift-card">
                <div class="staff-shift-header">
                    <h3 class="staff-shift-title"><i class="fas fa-business-time"></i> <span data-i18n="staff_shift_history_title">مێژوویا دەوامی و قاسێ</span></h3>
                    <div class="staff-shift-actions">
                        <input type="date" id="shift-date-start" class="input-std" onchange="renderShifts()">
                        <input type="date" id="shift-date-end" class="input-std" onchange="renderShifts()">
                        <button class="btn btn-dark btn-icon-only" onclick="resetShiftDateFilter()" title="پاکژکرن"><i class="fas fa-times"></i></button>
                        <button class="btn btn-brand" onclick="renderShifts()"><i class="fas fa-sync"></i> <span data-i18n="btn_refresh"></span></button>
                    </div>
                </div>
                <div style="overflow-x:auto;">
                    <table class="report-table staff-shift-table">
                        <thead>
                            <tr>
                                <th data-i18n="staff_shift_th_user">کارمەند</th>
                                <th data-i18n="staff_shift_th_start">دەسپێکا دەوامی</th>
                                <th data-i18n="staff_shift_th_end">دوماهییا دەوامی</th>
                                <th data-i18n="staff_shift_th_opening">قاسا دەسپێکێ</th>
                                <th data-i18n="staff_shift_th_closing">قاسا دوماهییێ</th>
                                <th data-i18n="staff_shift_th_diff">فەرقی (Diff)</th>
                                <th data-i18n="staff_shift_th_status">بارودۆخ</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody id="shifts-body"></tbody>
                    </table>
                </div>
            </div>
        </div>
