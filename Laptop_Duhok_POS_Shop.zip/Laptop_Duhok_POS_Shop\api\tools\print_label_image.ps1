param(
    [Parameter(Mandatory = $true)][string]$ImagePath,
    [Parameter(Mandatory = $true)][string]$PrinterName,
    [Parameter(Mandatory = $false)][double]$WidthMm = 40,
    [Parameter(Mandatory = $false)][double]$HeightMm = 60,
    [Parameter(Mandatory = $false)][int]$Copies = 1
)

$ErrorActionPreference = 'Stop'

if (-not (Test-Path -LiteralPath $ImagePath)) {
    throw "Image not found: $ImagePath"
}
if ([string]::IsNullOrWhiteSpace($PrinterName)) {
    throw "Printer name is empty"
}
if ($Copies -lt 1) { $Copies = 1 }
if ($Copies -gt 50) { $Copies = 50 }
if ($WidthMm -lt 10) { $WidthMm = 10 }
if ($HeightMm -lt 10) { $HeightMm = 10 }

$helperCs = Join-Path $PSScriptRoot 'PosLabelPrintHelper.cs'
if (-not (Test-Path -LiteralPath $helperCs)) {
    throw "PosLabelPrintHelper.cs missing"
}
if (-not ('PosLabelPrintHelper' -as [type])) {
    Add-Type -Path $helperCs -ReferencedAssemblies System.Drawing
}

$via = [PosLabelPrintHelper]::Print($PrinterName, $ImagePath, $WidthMm, $HeightMm, $Copies)
Write-Output ("OK " + $via)
