// POS reports - restore, archive, maintenance

        function posRestoreMysqlDataUpload(input) {
            var file = input && input.files && input.files[0];
            if (!file) return;
            posPostMysqlDataRestore(file, file.name || 'XAMPP_MySQL_Data.zip').finally(function () {
                input.value = '';
            });
        }

        async function posRestoreMysqlDataFromFlash(fileName) {
            if (!fileName) return;
            var handle = await posFlashLoadDirHandle();
            if (!handle) {
                alert('فلاش نەدۆزرایەوە — سەرەتا هەڵبژێرە.');
                return;
            }
            if (!(await posFlashEnsurePermission(handle, 'readwrite', true)) && !(await posFlashEnsurePermission(handle, 'read', true))) {
                alert('مۆڵەتی خوێندنەوە نییە — دووبارە فلاش هەڵبژێرە.');
                return;
            }
            var dir = await posFlashGetBackupsDir(handle, false);
            var fileHandle = await dir.getFileHandle(fileName);
            var file = await fileHandle.getFile();
            await posPostMysqlDataRestore(file, fileName);
        }

        window.posBackupMysqlDataToFlash = posBackupMysqlDataToFlash;
        window.posRestoreMysqlDataUpload = posRestoreMysqlDataUpload;
        window.posRestoreMysqlDataFromFlash = posRestoreMysqlDataFromFlash;

        async function posWriteBackupResponseToHandle(res, writable) {
            if (!res.ok) {
                var errText = await res.text();
                throw new Error(errText.slice(0, 280) || ('HTTP ' + res.status));
            }
            var ct = (res.headers && res.headers.get) ? (res.headers.get('Content-Type') || '') : '';
            var ctLow = ct.toLowerCase();
            if (ctLow.indexOf('text/html') !== -1) {
                var errHtml = await res.text();
                throw new Error(errHtml.slice(0, 180) || 'Server returned HTML');
            }
            if (res.body && typeof res.body.pipeTo === 'function') {
                await res.body.pipeTo(writable);
                return;
            }
            var zipBlob = await posAssertBackupZipResponse(res, await res.blob());
            await writable.write(zipBlob);
        }

        async function exportDB(extraParams) {
            const indicator = document.getElementById('save-indicator');
            indicator.style.display = 'block';
            indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ئامادەکردنی بک‌ئەپی تەواو (کۆمپانیا+کریار+فرۆشتن+هەموو)...';
            
            await posFlushBeforeBackup();

            const actionName = ['export', 'full', 'backup'].join('_');
            const dlParams = ['zip=1', 'download=1', 'save_local=1'].concat(extraParams || []).join('&');
            var ctrl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
            var timer = ctrl ? setTimeout(function () { try { ctrl.abort(); } catch (_e) {} }, 10 * 60 * 1000) : null;
            fetch('?action=' + actionName + '&' + dlParams, {
                credentials: 'same-origin',
                signal: ctrl ? ctrl.signal : undefined
            })
            .then(async res => {
                if (timer) clearTimeout(timer);
                if (!res.ok) {
                    let errText = await res.text();
                    throw new Error("Network response was not ok: " + errText);
                }
                var verified = res.headers.get('X-Backup-Verified');
                if (verified === '0') {
                    throw new Error('Backup incomplete — critical tables missing');
                }
                let filename = `Laptop_Duhok_POS_Backup_${new Date().toISOString().slice(0,10)}.posbak`;
                const disp = res.headers.get('Content-Disposition');
                if (disp && disp.includes('filename=')) {
                    filename = disp.split('filename=')[1].replace(/['"]/g, '');
                } else if (res.headers.get('Content-Type') && res.headers.get('Content-Type').includes('json')) {
                    filename = `Laptop_Duhok_POS_Backup_${new Date().toISOString().slice(0,10)}.json`;
                }
                const savedLocal = res.headers.get('X-Backup-Saved-Local') || '';
                const tableCount = res.headers.get('X-Backup-Tables') || '';
                const rowCount = res.headers.get('X-Backup-Rows') || '';
                return res.blob().then(async blob => ({blob: await posAssertBackupZipResponse(res, blob), filename, savedLocal, tableCount, rowCount}));
            })
            .then(async ({blob, filename, savedLocal, tableCount, rowCount}) => {
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a'); 
                a.href = url; 
                a.download = filename; 
                document.body.appendChild(a);
                a.click(); 
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
                
                indicator.innerHTML = '<i class="fas fa-check"></i> بک‌ئەپی تەواو داونلۆد بوو';
                if (typeof showToast === 'function') {
                    var meta = [];
                    if (tableCount) meta.push(tableCount + ' خشتە');
                    if (rowCount) meta.push(rowCount + ' ڕیز');
                    showToast('✅ پاشەکەوتی تەواو' + (meta.length ? ' · ' + meta.join(' · ') : ''), 'success');
                }
                if (savedLocal) {
                    var localHint = (typeof window.t === 'function') ? window.t('modal_db_saved_local_toast') : 'پاراستن لە backups/';
                    if (typeof showToast === 'function') showToast('💾 ' + localHint + ' ' + savedLocal);
                    if (typeof loadLocalBackupsList === 'function') loadLocalBackupsList();
                }
                if (typeof posCopyBackupBlobToFlash === 'function') {
                    try {
                        await posCopyBackupBlobToFlash(blob, filename, { silent: false, interactive: true, auto: true, kind: 'pos' });
                    } catch (_eFlash) {}
                }
                if (typeof window.pushFirebaseMobileBackup === 'function'
                    && typeof window.isFirebaseGmailLinked === 'function'
                    && window.isFirebaseGmailLinked()) {
                    window.pushFirebaseMobileBackup(blob, filename).then(function (r) {
                        if (r && r.ok && typeof showToast === 'function') {
                            var okMsg = (typeof window.t === 'function') ? window.t('firebase_backup_cloud_ok') : 'نێردرا بۆ Cloud — لە موبایل داونلۆد بکە';
                            showToast('☁️ ' + okMsg, 'success');
                        } else if (r && !r.ok && r.reason !== 'not_authed' && !r.skipped && typeof showToast === 'function') {
                            var failMsg = (typeof window.t === 'function') ? window.t('firebase_backup_cloud_fail') : 'Cloud backup سەرنەکەوت';
                            showToast('⚠️ ' + failMsg, 'error');
                        }
                    }).catch(function () {});
                }
                setTimeout(() => indicator.style.display = 'none', 2000);
            })
            .catch(err => {
                if (timer) clearTimeout(timer);
                console.error(err);
                indicator.innerHTML = '<i class="fas fa-times"></i> هەڵەیەک ڕوویدا!';
                setTimeout(() => indicator.style.display = 'none', 3000);
                alert("⚠️ کێشە لە پاشەکەوت: " + (err && err.message ? err.message : err));
            });
        }

        function posAfterBackupCloudUpload(force, quiet) {
            quiet = !!quiet;
            if (typeof window.isFirebaseGmailLinked === 'function' && !window.isFirebaseGmailLinked()) {
                if (quiet || (typeof window.shopHasFirebaseGmail === 'function' && !window.shopHasFirebaseGmail())) {
                    return Promise.resolve({ skipped: true, reason: 'not_authed' });
                }
                if (typeof openFirebaseSyncLogin === 'function') openFirebaseSyncLogin();
                return Promise.resolve({ skipped: true, reason: 'not_authed' });
            }
            if (typeof window.pushLatestLocalBackupToCloud !== 'function') {
                if (!quiet && typeof showToast === 'function') {
                    showToast('⚠️ POS نوێ بکەرەوە (Ctrl+F5)', 'error');
                }
                return Promise.resolve({ ok: false, reason: 'no_fn' });
            }
            return window.pushLatestLocalBackupToCloud(!!force).then(function (r) {
                if (r && r.ok && typeof showToast === 'function') {
                    var okMsg = (typeof window.t === 'function') ? window.t('firebase_backup_cloud_ok') : 'نێردرا بۆ Cloud — لە موبایل داونلۆد بکە';
                    showToast('☁️ ' + okMsg, 'success');
                } else if (r && r.reason === 'not_authed') {
                    if (!quiet && typeof openFirebaseSyncLogin === 'function') openFirebaseSyncLogin();
                } else if (r && r.reason === 'no_local') {
                    return posExportDbToCloud(true);
                } else if (!quiet && r && r.reason === 'already_uploaded') {
                    if (typeof showToast === 'function') {
                        showToast('☁️ پێشتر نێردراوە — لە موبایل refresh بکە', 'success');
                    }
                } else if (!quiet && r && !r.ok && !r.skipped && typeof showToast === 'function') {
                    var detail = (r && r.message) ? String(r.message) : '';
                    var failMsg = (typeof window.t === 'function') ? window.t('firebase_backup_cloud_fail') : 'Cloud backup سەرنەکەوت';
                    showToast('⚠️ ' + failMsg + (detail ? ' · ' + detail : ''), 'error');
                }
                return r;
            }).catch(function () {});
        }

        async function posExportDbToCloud(fromRetry) {
            if (typeof window.isFirebaseGmailLinked === 'function' && !window.isFirebaseGmailLinked()) {
                if (typeof openFirebaseSyncLogin === 'function') openFirebaseSyncLogin();
                return { ok: false, reason: 'not_authed' };
            }
            if (typeof getFirebaseSyncStatus === 'function') {
                var st = getFirebaseSyncStatus();
                if (!st || !st.connected) {
                    if (typeof openFirebaseSyncLogin === 'function') openFirebaseSyncLogin();
                    return { ok: false, reason: 'not_authed' };
                }
            }
            var indicator = document.getElementById('save-indicator');
            if (indicator) {
                indicator.style.display = 'block';
                indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Backup + Cloud…';
            }
            try {
                await posFlushBeforeBackup();
                var actionName = ['export', 'full', 'backup'].join('_');
                var dlParams = ['zip=1', 'download=1', 'save_local=1'].join('&');
                var res = await fetch('?action=' + actionName + '&' + dlParams, { credentials: 'same-origin' });
                if (!res.ok) {
                    var errText = await res.text();
                    throw new Error(errText.slice(0, 200) || ('HTTP ' + res.status));
                }
                var filename = 'Laptop_Duhok_POS_Backup_' + new Date().toISOString().slice(0, 10) + '.posbak';
                var disp = res.headers.get('Content-Disposition');
                if (disp && disp.indexOf('filename=') !== -1) {
                    filename = disp.split('filename=')[1].replace(/['"]/g, '');
                }
                var blob = await posAssertBackupZipResponse(res, await res.blob());
                if (typeof loadLocalBackupsList === 'function') loadLocalBackupsList();
                if (typeof posCopyBackupBlobToFlash === 'function') {
                    try { await posCopyBackupBlobToFlash(blob, filename, { silent: true, auto: true, kind: 'pos' }); } catch (_eFlash2) {}
                }
                if (typeof window.pushFirebaseMobileBackup !== 'function') {
                    throw new Error('Firebase sync بارنەبوو — Ctrl+F5');
                }
                var up = await window.pushFirebaseMobileBackup(blob, filename);
                if (up && up.ok) {
                    if (typeof showToast === 'function') {
                        var okMsg = (typeof window.t === 'function') ? window.t('firebase_backup_cloud_ok') : 'نێردرا بۆ Cloud';
                        showToast('☁️ ' + okMsg + '\n' + filename, 'success');
                    }
                    if (indicator) {
                        indicator.innerHTML = '<i class="fas fa-check"></i> Cloud OK';
                        setTimeout(function () { indicator.style.display = 'none'; }, 2500);
                    }
                    return up;
                }
                if (up && up.reason === 'not_authed') {
                    if (typeof openFirebaseSyncLogin === 'function') openFirebaseSyncLogin();
                    throw new Error('Firebase login نییە');
                }
                var msg = (up && up.message) ? up.message : 'Upload failed';
                throw new Error(msg);
            } catch (err) {
                if (indicator) {
                    indicator.innerHTML = '<i class="fas fa-times"></i> Cloud';
                    setTimeout(function () { indicator.style.display = 'none'; }, 3000);
                }
                alert('❌ Cloud backup سەرنەکەوت:\n\n' + String(err && err.message ? err.message : err) +
                    '\n\n① Firebase login (Settings)\n② Storage Rules → Publish\n③ دووبارە هەوڵ بدە');
                return { ok: false, error: err };
            }
        }

        function pushLocalBackupToCloudNow() {
            if (typeof getFirebaseSyncStatus === 'function') {
                var st = getFirebaseSyncStatus();
                if (!st || !st.connected) {
                    return posExportDbToCloud(false);
                }
            }
            var indicator = document.getElementById('save-indicator');
            if (indicator) {
                indicator.style.display = 'block';
                indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Cloud…';
            }
            posAfterBackupCloudUpload(true).finally(function () {
                if (indicator) {
                    indicator.innerHTML = '<i class="fas fa-check"></i> Cloud';
                    setTimeout(function () { indicator.style.display = 'none'; }, 2000);
                }
            });
        }

        function exportDBWithMaintenance() {
            if (!confirm('پێش backup:\n\n• فرۆشتنێن >١ ساڵ → ئەرشیف\n• log و snapshots پاک دەکرێن\n\nدواتر Full ZIP دادەگیرێت.')) return;
            exportDB(['maintain=1']);
        }

        function exportYearlyBackup() {
            var y = prompt('ساڵی backup (نموونە: ' + (new Date().getFullYear() - 1) + '):', String(new Date().getFullYear() - 1));
            if (y == null || y === '') return;
            y = parseInt(y, 10);
            if (!y || y < 2000 || y > 2100) {
                alert('ساڵ نادروستە');
                return;
            }
            var indicator = document.getElementById('save-indicator');
            if (indicator) {
                indicator.style.display = 'block';
                indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> بک‌ئەپێ ساڵانە…';
            }
            fetch('?action=export_yearly_backup&year=' + encodeURIComponent(y) + '&zip=1&download=1', { credentials: 'same-origin' })
                .then(function (res) {
                    if (!res.ok) return res.text().then(function (t) { throw new Error(t.slice(0, 200)); });
                    var fn = 'Laptop_Duhok_POS_Year_' + y + '.posbak';
                    var disp = res.headers.get('Content-Disposition');
                    if (disp && disp.indexOf('filename=') !== -1) fn = disp.split('filename=')[1].replace(/['"]/g, '');
                    return res.blob().then(function (blob) { return { blob: blob, filename: fn }; });
                })
                .then(function (o) {
                    var url = URL.createObjectURL(o.blob);
                    var a = document.createElement('a');
                    a.href = url;
                    a.download = o.filename;
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    URL.revokeObjectURL(url);
                    if (indicator) {
                        indicator.innerHTML = '<i class="fas fa-check"></i> بک‌ئەپێ ساڵانە';
                        setTimeout(function () { indicator.style.display = 'none'; }, 2000);
                    }
                })
                .catch(function (err) {
                    if (indicator) indicator.style.display = 'none';
                    alert('❌ ' + err);
                });
        }

        function runTenYearMaintenance() {
            var tr = (typeof window.t === 'function') ? window.t : function (k) { return k; };
            if (!confirm(tr('modal_db_10y_maintain_confirm'))) return;
            var movementYears = 0;
            if (confirm(tr('modal_db_10y_movements_confirm'))) {
                if (prompt('YES') !== 'YES') {
                    alert('هیچ شتێک نەسڕدرا.');
                    return;
                }
                movementYears = 3;
            }
            var fd = new FormData();
            fd.append('action', 'run_ten_year_maintenance');
            fd.append('archive_days', '365');
            fd.append('audit_days', '365');
            fd.append('print_days', '365');
            fd.append('snapshot_keep', '10');
            if (movementYears > 0) {
                fd.append('movement_years', String(movementYears));
                fd.append('confirm_movements', 'YES');
            }
            var indicator = document.getElementById('save-indicator');
            if (indicator) {
                indicator.style.display = 'block';
                indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> …';
            }
            fetch('?action=run_ten_year_maintenance', { method: 'POST', body: fd, credentials: 'same-origin' })
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    if (indicator) indicator.style.display = 'none';
                    if (data.status === 'success') {
                        var a = (data.result && data.result.archive) || {};
                        var c = (data.result && data.result.cleanup) || {};
                        alert('✅ پاککردنی ساڵانە تەواو:\n\nئەرشیف فرۆشتن: ' + (a.archived_sales || 0) + '\nlog: ' + ((c.audit_logs || 0) + (c.print_log || 0)) + '\nsnapshots: ' + (c.system_snapshots || 0));
                        loadDatabaseSizeReport();
                    } else {
                        alert('❌ ' + (data.message || 'error'));
                    }
                })
                .catch(function (err) {
                    if (indicator) indicator.style.display = 'none';
                    alert('❌ ' + err);
                });
        }

        window.exportDBWithMaintenance = exportDBWithMaintenance;
        window.exportYearlyBackup = exportYearlyBackup;
        window.runTenYearMaintenance = runTenYearMaintenance;
        window.posFlushBeforeBackup = posFlushBeforeBackup;
        
        async function exportItemsDB() {
            const indicator = document.getElementById('save-indicator');
            indicator.style.display = 'block';
            indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ئامادەکرنا باکئەپێ ئایتمان (هەمی)...';

            try {
                await posFlushBeforeBackup();
            } catch (e) { console.warn('Sync before items backup warning:', e); }
            
            const actionName = ['export', 'items', 'backup'].join('_');
            const dlParams = ['zip=1', 'download=1'].join('&');
            var qs = 'action=' + actionName + '&' + dlParams;
            var url = (typeof window.posRouterUrl === 'function') ? window.posRouterUrl(qs) : ('?' + qs);
            var ctrl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
            var timer = ctrl ? setTimeout(function () { try { ctrl.abort(); } catch (_e) {} }, 10 * 60 * 1000) : null;
            fetch(url, {
                credentials: 'same-origin',
                cache: 'no-store',
                signal: ctrl ? ctrl.signal : undefined
            })
            .then(async res => {
                if (timer) clearTimeout(timer);
                if(!res.ok) {
                    let errText = await res.text();
                    throw new Error("Network response was not ok: " + errText);
                }
                let filename = `Laptop_Duhok_POS_ItemsBackup_${new Date().toISOString().slice(0,10)}.posbak`;
                const disp = res.headers.get('Content-Disposition');
                if (disp && disp.includes('filename=')) {
                    filename = disp.split('filename=')[1].replace(/['"]/g, '');
                } else if (res.headers.get('Content-Type') && res.headers.get('Content-Type').includes('json')) {
                    filename = `Laptop_Duhok_POS_ItemsBackup_${new Date().toISOString().slice(0,10)}.json`;
                }
                const productCount = res.headers.get('X-Backup-Products') || '';
                const rowCount = res.headers.get('X-Backup-Rows') || '';
                const blob = await res.blob();
                if (!blob || blob.size < 32) {
                    throw new Error('Items backup file too small or empty');
                }
                // Reject HTML/login pages mistaken as ZIP
                var ct = (res.headers.get('Content-Type') || '').toLowerCase();
                if (ct.indexOf('text/html') !== -1) {
                    throw new Error('Server returned HTML instead of items backup');
                }
                return { blob: blob, filename: filename, productCount: productCount, rowCount: rowCount };
            })
            .then(({blob, filename, productCount, rowCount}) => {
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a'); 
                a.href = url; 
                a.download = filename; 
                document.body.appendChild(a);
                a.click(); 
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
                
                var meta = [];
                if (productCount) meta.push(productCount + ' ئایتم');
                if (rowCount) meta.push(rowCount + ' ڕیز');
                indicator.innerHTML = '<i class="fas fa-check"></i> هەمی ئایتم هاتنە داونلۆدکرن' + (meta.length ? (' · ' + meta.join(' · ')) : '');
                if (typeof showToast === 'function') {
                    showToast('✅ داونلۆدی ئایتمان: ' + (productCount || '?') + ' ئایتم', 'success');
                }
                setTimeout(() => indicator.style.display = 'none', 3500);
            })
            .catch(err => {
                if (timer) clearTimeout(timer);
                console.error(err);
                indicator.innerHTML = '<i class="fas fa-times"></i> هەڵەیەک ڕوویدا!';
                setTimeout(() => indicator.style.display = 'none', 3000);
                var msg = (err && err.name === 'AbortError')
                    ? 'کات تەواو بوو — دووبارە هەوڵ بدە'
                    : String((err && err.message) || err || '').slice(0, 220);
                alert("⚠️ کێشەیەک چێبوو د دەرهێنانا ئایتمان دا.\n" + msg);
            });
        }

        async function backupItemsToLocal() {
            const indicator = document.getElementById('save-indicator');
            if (window.showSaveFilePicker) {
                try {
                    const options = { 
                        suggestedName: `Laptop_Duhok_POS_ItemsBackup_${new Date().toISOString().slice(0,10)}.posbak`, 
                        types: [{ description: 'POS Items Backup', accept: { 'application/octet-stream': ['.posbak'] } }] 
                    };
                    const handle = await window.showSaveFilePicker(options);

                    try {
                        await posFlushBeforeBackup();
                    } catch (e) { console.warn('Sync before backup warning:', e); }
                    
                    indicator.style.display = 'block';
                    indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> هەمی ئایتم دهێنە داونلۆدکرن...';
                    
                    const actionName = ['export', 'items', 'backup'].join('_');
                    const dlParams = ['zip=1', 'download=1'].join('&');
                    var qs = 'action=' + actionName + '&' + dlParams;
                    var url = (typeof window.posRouterUrl === 'function') ? window.posRouterUrl(qs) : ('?' + qs);
                    var ctrl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
                    var timer = ctrl ? setTimeout(function () { try { ctrl.abort(); } catch (_e) {} }, 10 * 60 * 1000) : null;
                    const res = await fetch(url, {
                        credentials: 'same-origin',
                        cache: 'no-store',
                        signal: ctrl ? ctrl.signal : undefined
                    });
                    if (timer) clearTimeout(timer);
                    const productCount = res.headers.get('X-Backup-Products') || '';
                    const writable = await handle.createWritable();
                    await posWriteBackupResponseToHandle(res, writable);
                    await writable.close();
                    
                    indicator.innerHTML = '<i class="fas fa-check"></i> هەمی ئایتم هاتنە داونلۆدکرن' + (productCount ? (' · ' + productCount + ' ئایتم') : '');
                    if (typeof showToast === 'function') {
                        showToast('✅ داونلۆدی ئایتمان: ' + (productCount || '?') + ' ئایتم', 'success');
                    }
                    setTimeout(() => indicator.style.display = 'none', 3500);
                    return;
                } catch (err) {
                    if (err.name === 'AbortError') {
                        if (indicator) {
                            indicator.innerHTML = '<i class="fas fa-times"></i> هەڵوەشاندن';
                            setTimeout(() => indicator.style.display = 'none', 2000);
                        }
                        return;
                    }
                    console.error(err);
                    if (typeof showToast === 'function') {
                        showToast('⚠️ داونلۆدی ئاسایی...');
                    }
                }
            }
            exportItemsDB();
        }
        
        async function backupToLocal() {
            if (!window.showSaveFilePicker) {
                exportDB();
                return;
            }
            
            try {
                const options = { 
                    suggestedName: `Laptop_Duhok_POS_Backup_${new Date().toISOString().slice(0,10)}.posbak`, 
                    types: [{ description: 'POS Full Backup', accept: { 'application/octet-stream': ['.posbak'] } }] 
                };
                const handle = await window.showSaveFilePicker(options);

                await posFlushBeforeBackup();
                
                const indicator = document.getElementById('save-indicator');
                indicator.style.display = 'block';
                indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> داتایێن تە دهێنە پاراستن...';
                
                const actionName = ['export', 'full', 'backup'].join('_');
                const dlParams = ['zip=1', 'download=1', 'save_local=1'].join('&');
                const res = await fetch('?action=' + actionName + '&' + dlParams, { credentials: 'same-origin' });
                const writable = await handle.createWritable();
                await posWriteBackupResponseToHandle(res, writable);
                await writable.close();
                
                const savedLocal = res.headers.get('X-Backup-Saved-Local') || '';
                indicator.innerHTML = '<i class="fas fa-check"></i> فایلێ تە ب سەرکەفتیانە هاتە پاراستن!';
                if (savedLocal) {
                    var localHint = (typeof window.t === 'function') ? window.t('modal_db_saved_local_toast') : 'پاراستن لە backups/';
                    if (typeof showToast === 'function') showToast('💾 ' + localHint + ' ' + savedLocal);
                    if (typeof loadLocalBackupsList === 'function') loadLocalBackupsList();
                }
                try {
                    var savedFile = await handle.getFile();
                    if (savedFile && typeof posCopyBackupBlobToFlash === 'function') {
                        await posCopyBackupBlobToFlash(savedFile, handle.name || POS_FLASH_NAME_POS, { silent: false, auto: true, kind: 'pos' });
                    }
                } catch (_eFlash3) {}
                posAfterBackupCloudUpload(true, true);
                setTimeout(() => indicator.style.display = 'none', 3000);
                
            } catch (err) {
                if (err.name !== 'AbortError') {
                    console.error(err);
                    if (typeof showToast === 'function') {
                        showToast('⚠️ پاراستن لە فایل سەرنەکەوت — داونلۆدی ئاسایی...');
                    }
                    exportDB();
                }
            }
        }
        
        async function restoreBackup(input) {
            const files = input.files ? Array.prototype.slice.call(input.files) : [];
            if (!files.length) return;
            
            const currencyEl = document.getElementById('restore-currency-choice');
            let forceCurrency = (currencyEl && currencyEl.value === 'USD') ? 'USD' : 'IQD';
            const currLabel = forceCurrency === 'USD' ? 'دولار ($)' : 'دینار عێراقی (IQD)';
            const fileHint = files.length > 1
                ? ('\nفایل: ' + files.length + ' (part1+part2 یان چەند فایل)')
                : ('\nفایل: ' + (files[0].name || ''));

            if (window._posRestoreSkipConfirmOnce) {
                window._posRestoreSkipConfirmOnce = false;
            } else if (typeof posConfirmDataRestore === 'function') {
                var tr = (typeof t === 'function') ? t : function () { return ''; };
                var okRestore = await posConfirmDataRestore({
                    source: tr('confirm_data_restore_source_file') || 'گەڕاندنەوە لە فایل',
                    detail: fileHint.trim(),
                    currencyLabel: currLabel
                });
                if (!okRestore) {
                    input.value = '';
                    return;
                }
            } else if (!confirm(`⚠️ ئاگەهداربە!

ئەرێ دڵنیای تە دڤێت ڤی فایلی بزڤڕینی؟ هەمی داتایێن نوکە یێن د سیستەمی دا دێ هێنە ژێبرن و داتایێن ڤی فایلی دێ چنە جهێ وان.
دراڤێ سیستەمی دێ بیتە: ${currLabel}${fileHint}`)) {
                input.value = '';
                return;
            }

            const formData = new FormData();
            formData.append('action', 'restore_backup');
            if (files.length === 1) {
                formData.append('file', files[0]);
            } else {
                for (var fi = 0; fi < files.length; fi++) {
                    formData.append('file[]', files[fi]);
                }
            }
            formData.append('force_currency', forceCurrency);
            
            const indicator = document.getElementById('save-indicator');
            indicator.style.display = 'block';
            indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> هیڤییە چاڤەڕێبە، داتای تەواو دهێنە زڤڕاندن... (ڕەنگە چەند خولەکەک پێبچیت)';

            fetch('?action=restore_backup', { method: 'POST', body: formData, credentials: 'same-origin' })
            .then(res => res.text().then(function(text) {
                var t = (text || '').trim();
                if (!t) throw new Error('وەڵامی سێرڤەر بەتاڵە — ڕەنگە سنووری بارکردن (upload_max_filesize) یان کاتی جێبەجێکردن تەواو بووبێت.');
                try { return JSON.parse(t); } catch (e) { throw new Error(t.slice(0, 280)); }
            }))
            .then(data => {
                if(data.status === 'success') {
                    const modeLabel = data.mode === 'package_merged' ? 'part1+part2' : (data.mode === 'package' ? 'posbak' : (data.mode || 'Backup'));
                    var countHint = '';
                    if (data.table_counts && typeof data.table_counts === 'object') {
                        var parts = [];
                        ['products', 'companies', 'customers', 'sales', 'supplies', 'recipes', 'ledger'].forEach(function (k) {
                            if (data.table_counts[k] != null) parts.push(k + ': ' + data.table_counts[k]);
                        });
                        if (parts.length) countHint = ' · ' + parts.join(' · ');
                        else if (data.restored_tables) countHint = ' · ' + data.restored_tables + ' خشتە';
                    }
                    indicator.innerHTML = `<i class="fas fa-check"></i> داتای تەواو زڤڕا (${modeLabel}${countHint})! سیستەم دێ ڕیفرێش بیت...`;
                    Object.keys(localStorage).forEach(key => {
                        if (key.startsWith('pos_tabs_state_')) localStorage.removeItem(key);
                    });
                    setTimeout(() => location.reload(), 1500);
                } else {
                    indicator.style.display = 'none';
                    alert("❌ هەڵە د زڤڕاندنێ دا: " + data.message);
                }
            })
            .catch(err => {
                indicator.style.display = 'none';
                alert("❌ کێشەیەکا نەچاڤەڕێکری ڕوویدا: " + err);
            })
            .finally(() => {
                input.value = ''; // Reset input to allow selecting same file again
            });
        }

        function mergeItemsBackup(input) {
            var files = input && input.files ? Array.prototype.slice.call(input.files) : [];
            if (!files.length) return;
            window._posMergePendingFiles = files;
            if (input) input.value = '';
            var modal = document.getElementById('modal-merge-items-currency');
            var filesEl = document.getElementById('merge-items-currency-files');
            if (filesEl) {
                var names = files.map(function (f) { return f && f.name ? f.name : ''; }).filter(Boolean);
                filesEl.textContent = (files.length > 1)
                    ? ('فایل: ' + files.length + (names.length ? (' · ' + names.slice(0, 3).join('، ')) : ''))
                    : (names[0] || '');
            }
            if (modal) {
                if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
                modal.style.display = 'flex';
            } else {
                var usd = window.confirm('دراڤ دولار بیت؟\n\nOK = دولار ($)\nCancel = دینار عێراقی');
                confirmMergeItemsWithCurrency(usd ? 'USD' : 'IQD');
            }
        }

        function closeMergeItemsCurrencyModal() {
            var modal = document.getElementById('modal-merge-items-currency');
            if (modal) modal.style.display = 'none';
            window._posMergePendingFiles = [];
        }

        function confirmMergeItemsWithCurrency(code) {
            var files = window._posMergePendingFiles || [];
            window._posMergePendingFiles = [];
            var modal = document.getElementById('modal-merge-items-currency');
            if (modal) modal.style.display = 'none';
            if (!files.length) return;
            var forceCurrency = (String(code || '').toUpperCase() === 'USD') ? 'USD' : 'IQD';
            startMergeItemsBackup(files, forceCurrency);
        }

        function startMergeItemsBackup(files, forceCurrency) {
            const formData = new FormData();
            formData.append('action', 'restore_backup');
            formData.append('merge_items', '1');
            formData.append('force_currency', forceCurrency);
            if (files.length === 1) {
                formData.append('file', files[0]);
            } else {
                files.forEach(function (f) {
                    formData.append('file[]', f);
                });
            }

            const indicator = document.getElementById('save-indicator');
            indicator.style.display = 'block';
            var currLabel = forceCurrency === 'USD' ? 'دولار ($)' : 'دینار عێراقی';
            indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ئایتمەکان تێکەڵ دەکرێن · ' + currLabel + '…';

            var url = (typeof window.posRouterUrl === 'function')
                ? window.posRouterUrl('action=restore_backup')
                : '?action=restore_backup';
            fetch(url, { method: 'POST', body: formData, credentials: 'same-origin' })
            .then(res => res.text().then(function(text) {
                var t = (text || '').trim();
                if (!t) throw new Error('وەڵامی سێرڤەر بەتاڵە.');
                try { return JSON.parse(t); } catch (e) { throw new Error(t.slice(0, 280)); }
            }))
            .then(data => {
                if(data.status === 'success') {
                    try { localStorage.setItem('pos_currency_mode', forceCurrency); } catch (_eLs) {}
                    if (typeof db !== 'undefined' && db && db.settings) db.settings.currencyMode = forceCurrency;
                    var n = (data.table_counts && data.table_counts.products != null) ? data.table_counts.products : '';
                    indicator.innerHTML = '<i class="fas fa-check"></i> ئایتمەکان تێکەڵ کران'
                        + (n !== '' ? (' · کۆی ئایتم ل داتابەیس: ' + n) : '')
                        + ' · ' + currLabel
                        + '! سیستەم دێ ڕیفرێش بیت...';
                    setTimeout(() => location.reload(), 1500);
                } else {
                    indicator.style.display = 'none';
                    alert("❌ هەڵە د تێکەڵکردنێ دا: " + data.message);
                }
            })
            .catch(err => {
                indicator.style.display = 'none';
                alert("❌ کێشەیەکا نەچاڤەڕێکری ڕوویدا: " + err);
            });
        }

        function archiveOldData() {
            document.getElementById('modal-archive-selection').style.display='flex';
        }

        function confirmArchiveOldData() {
            const selectEl = document.getElementById('archive-time-selection');
            const daysMap = {
                '365': 365,
                '180': 180,
                '90': 90,
                '30': 30,
                'all': 0
            };
            const days = daysMap[selectEl.value];
            
            if(!confirm("⚠️ ئاگەهداربە!\n\nئەرێ تو دڵنیای دڤێت داتایێن کەڤن ئەرشیف بکەی؟\nداتا دێ ژ خشتەیێ سەرەکی چنە د خشتەیێ ئەرشیفێ دا بۆ سووککرنا سیستەمی.")) return;

            document.getElementById('modal-archive-selection').style.display = 'none';
            
            const formData = new FormData();
            formData.append('action', 'archive_old_data');
            formData.append('days', days);
            
            const indicator = document.getElementById('save-indicator');
            indicator.style.display = 'block';
            indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ئەرشیفکرن د کاریدایە، هیڤییە چاڤەڕێبە...';

            fetch('?action=archive_old_data', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                if(data.status === 'success') {
                    indicator.innerHTML = '<i class="fas fa-check"></i> ب سەرکەفتیانە هاتە ئەرشیفکرن!';
                    alert(`✅ ئەرشیفکرن ب دوماهی هات:

- ${data.archived_sales} وەسڵێن فرۆتنێ
- ${data.archived_expenses} مەزاختن`);
                    setTimeout(() => location.reload(), 1500);
                } else {
                    indicator.style.display = 'none';
                    alert("❌ هەڵە د ئەرشیفکرنێ دا: " + data.message);
                }
            })
            .catch(err => {
                indicator.style.display = 'none';
                alert("❌ کێشەیەک ڕوویدا: " + err);
            });
        }

        function deleteArchivedData() {
            document.getElementById('modal-delete-archive-selection').style.display = 'flex';
        }

        function confirmDeleteArchivedData() {
            const selectEl = document.getElementById('delete-archive-time-selection');
            const daysMap = {
                '365': 365,
                '180': 180,
                '90': 90,
                '30': 30,
                'all': 0
            };
            const days = daysMap[selectEl ? selectEl.value : '365'] ?? 365;
            let confirmToken = '';

            if (days === 0) {
                confirmToken = prompt(
                    '⚠️ سڕینەوەی هەموو ئەرشیف!\n\nفرۆشتن و مەزاختن لە خشتەی ئەرشیف بە تەواوی دەسڕێن — ناگەڕێتەوە.\n\nبۆ دەسپێکردن بنووسە: DELETE'
                );
                if (confirmToken !== 'DELETE') {
                    if (confirmToken != null) alert('هیچ شتێک نەسڕدرا — DELETE نەنووسراو.');
                    return;
                }
            } else if (!confirm('⚠️ دڵنیای؟\n\nداتای ئەرشیڤکراوی (فرۆشتن + مەزاختن) لە ماوەی هەڵبژاردە دەسڕێتەوە.\nئەم کارە ناگەڕێتەوە.')) {
                return;
            }

            document.getElementById('modal-delete-archive-selection').style.display = 'none';

            const formData = new FormData();
            formData.append('action', 'delete_archived_data');
            formData.append('days', days);
            if (confirmToken === 'DELETE') formData.append('confirm', 'DELETE');

            const indicator = document.getElementById('save-indicator');
            indicator.style.display = 'block';
            indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> سڕینەوە لە ئەرشیف…';

            fetch('?action=delete_archived_data', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    indicator.innerHTML = '<i class="fas fa-check"></i> ئەرشیف سڕدرایەوە!';
                    alert(
                        '✅ سڕینەوە تەواو بوو:\n\n- ' +
                        (data.deleted_sales || 0) +
                        ' فرۆشتنی ئەرشیف\n- ' +
                        (data.deleted_expenses || 0) +
                        ' مەزاختنی ئەرشیف'
                    );
                    setTimeout(() => location.reload(), 1500);
                } else {
                    indicator.style.display = 'none';
                    alert('❌ هەڵە: ' + (data.message || 'unknown'));
                }
            })
            .catch(err => {
                indicator.style.display = 'none';
                alert('❌ کێشە: ' + err);
            });
        }

        window.deleteArchivedData = deleteArchivedData;
        window.confirmDeleteArchivedData = confirmDeleteArchivedData;

        function loadDatabaseSizeReport() {
            var box = document.getElementById('db-size-report');
            if (!box) return;
            var tr = (typeof window.t === 'function') ? window.t : function (k) { return k; };
            box.style.display = 'block';
            box.innerHTML = '<i class="fas fa-spinner fa-spin"></i> …';
            fetch('?action=get_database_size_report', { credentials: 'same-origin' })
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    if (data.status !== 'success' || !data.report) {
                        box.innerHTML = '❌ ' + (data.message || 'error');
                        return;
                    }
                    var r = data.report;
                    var html = '<strong>~' + (r.total_mb || 0) + ' MB</strong> · ';
                    (r.tables || []).slice(0, 5).forEach(function (t, i) {
                        if (i) html += ' · ';
                        html += t.name + ' ' + t.mb + 'MB';
                    });
                    if (r.tips && r.tips.length) {
                        html += '<br><small>' + r.tips.slice(0, 2).join(' · ') + '</small>';
                    }
                    if (r.projection && r.projection.estimate_10y_no_archive_mb) {
                        html += '<br><small>١٠ ساڵ بەبێ ئەرشیف: ~' + r.projection.estimate_10y_no_archive_mb + 'MB · بە پلان: ~' + r.projection.estimate_10y_with_yearly_mb + 'MB</small>';
                    }
                    html += '<br><small>' + tr('modal_db_size_backup_note') + '</small>';
                    box.innerHTML = html;
                })
                .catch(function (err) {
                    box.innerHTML = '❌ ' + err;
                });
        }

        function cleanupOperationalLogs() {
            if (!confirm('⚠️ پاککردنی logـە کۆن (>١ ساڵ) و snapshots زیاد؟\n\naudit_logs · print_log · system_snapshots (١٠ دوایین)\n\nledger و sales ناگۆڕدرێن.')) return;
            var movementYears = 0;
            if (confirm('ئایا stock_movementsـێ >٣ ساڵیش بسڕیت؟ (ledger دەمێنێت)\n\nOK = بەڵێ · Cancel = نەخێر')) {
                var tok = prompt('بۆ دڵنیایی بنووسە: YES');
                if (tok !== 'YES') {
                    alert('هیچ شتێک نەسڕدرا.');
                    return;
                }
                movementYears = 3;
            }
            var fd = new FormData();
            fd.append('action', 'cleanup_operational_data');
            fd.append('audit_days', '365');
            fd.append('print_days', '365');
            fd.append('snapshot_keep', '10');
            if (movementYears > 0) {
                fd.append('movement_years', String(movementYears));
                fd.append('confirm_movements', 'YES');
            }
            var indicator = document.getElementById('save-indicator');
            if (indicator) {
                indicator.style.display = 'block';
                indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> پاککردن…';
            }
            fetch('?action=cleanup_operational_data', { method: 'POST', body: fd, credentials: 'same-origin' })
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    if (indicator) indicator.style.display = 'none';
                    if (data.status === 'success') {
                        var d = data.deleted || {};
                        alert('✅ پاککرا:\n\naudit: ' + (d.audit_logs || 0) + '\nprint: ' + (d.print_log || 0) + '\nmovements: ' + (d.stock_movements || 0) + '\nsnapshots: ' + (d.system_snapshots || 0));
                        loadDatabaseSizeReport();
                    } else {
                        alert('❌ ' + (data.message || 'error'));
                    }
                })
                .catch(function (err) {
                    if (indicator) indicator.style.display = 'none';
                    alert('❌ ' + err);
                });
        }

        window.loadDatabaseSizeReport = loadDatabaseSizeReport;

        function repairHistoricalSaleCogs() {
            var tr = (typeof window.t === 'function') ? window.t : function (k) { return k; };
            if (!confirm(tr('modal_db_repair_cogs_confirm'))) return;
            var tok = prompt('بۆ دڵنیایی بنووسە: YES');
            if (tok !== 'YES') {
                alert('هیچ شتێک نەگۆڕا.');
                return;
            }
            var fd = new FormData();
            fd.append('action', 'repair_sale_cogs');
            fd.append('confirm', 'YES');
            var indicator = document.getElementById('save-indicator');
            if (indicator) {
                indicator.style.display = 'block';
                indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ' + tr('modal_db_repair_cogs_working');
            }
            fetch('?action=repair_sale_cogs', { method: 'POST', body: fd, credentials: 'same-origin' })
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    if (indicator) indicator.style.display = 'none';
                    if (data.status === 'success') {
                        var r = data.result || {};
                        alert(
                            '✅ ' + tr('modal_db_repair_cogs_ok') + '\n\n' +
                            'وەسڵ: ' + (r.sales_scanned || 0) + '\n' +
                            'چاککرا: ' + (r.sales_updated || 0) + '\n' +
                            'هێڵ: ' + (r.lines_fixed || 0) + '\n' +
                            'ئایتم: ' + (r.products_synced || 0) + '\n' +
                            'ئەرشیف: ' + (r.archive_updated || 0)
                        );
                        try {
                            if (typeof window.invalidateFifoCaches === 'function') window.invalidateFifoCaches();
                            if (typeof window.invalidateFifoCache === 'function') window.invalidateFifoCache();
                            if (typeof window.clearFifoCache === 'function') window.clearFifoCache();
                            if (window.__posFifoCache) window.__posFifoCache = null;
                            if (window.__fifoLayersCache) window.__fifoLayersCache = null;
                            if (typeof window.loadSalesHistory === 'function') window.loadSalesHistory();
                            if (typeof window.refreshHomeFinance === 'function') window.refreshHomeFinance();
                            if (typeof window.paintTodayFinanceKpis === 'function') window.paintTodayFinanceKpis();
                        } catch (e) { /* ignore */ }
                    } else {
                        alert('❌ ' + (data.message || 'error'));
                    }
                })
                .catch(function (err) {
                    if (indicator) indicator.style.display = 'none';
                    alert('❌ ' + err);
                });
        }

        window.repairHistoricalSaleCogs = repairHistoricalSaleCogs;

        function posFormatBackupBytes(n) {
            n = Number(n) || 0;
            if (n < 1024) return n + ' B';
            if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
            return (n / 1048576).toFixed(1) + ' MB';
        }

        function loadLocalBackupsList() {
            var listEl = document.getElementById('local-backups-list');
            if (!listEl) return;
            var tr = (typeof window.t === 'function') ? window.t : function (k) { return k; };
            listEl.innerHTML = '<span class="pos-db-local-muted">' + tr('modal_db_local_loading') + '</span>';
            fetch('?action=list_local_backups', { credentials: 'same-origin' })
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    if (data.status !== 'success' || !data.backups || !data.backups.length) {
                        listEl.innerHTML = '<span class="pos-db-local-muted">' + tr('modal_db_local_empty') + '</span>';
                        return;
                    }
                    var html = '';
                    data.backups.forEach(function (b) {
                        var name = String(b.name || '').replace(/"/g, '&quot;');
                        var isMysqlData = name.indexOf('XAMPP_MySQL_Data') === 0;
                        html += '<div class="pos-db-local-row">';
                        html += '<div class="pos-db-local-meta"><span class="pos-db-local-name">' + (isMysqlData ? '🗄️ ' : '') + name + '</span>';
                        html += '<span class="pos-db-local-sub">' + (b.mtime_iso || '') + ' · ' + posFormatBackupBytes(b.bytes) + (isMysqlData ? ' · mysql/data' : '') + '</span></div>';
                        if (isMysqlData) {
                            html += '<button type="button" class="btn btn-sm btn-danger" onclick="posRestoreLocalMysqlDataBackup(\'' + name.replace(/'/g, "\\'") + '\')"><i class="fas fa-undo"></i> data→XAMPP</button>';
                        } else {
                            html += '<button type="button" class="btn btn-sm btn-danger" onclick="restoreLocalBackup(\'' + name.replace(/'/g, "\\'") + '\')"><i class="fas fa-undo"></i> ' + tr('modal_db_local_restore_btn') + '</button>';
                        }
                        html += '</div>';
                    });
                    listEl.innerHTML = html;
                })
                .catch(function () {
                    listEl.innerHTML = '<span class="pos-db-local-muted">' + tr('modal_db_local_error') + '</span>';
                });
        }

        async function restoreLocalBackup(backupName) {
            if (!backupName) return;
            if (String(backupName).indexOf('XAMPP_MySQL_Data') === 0) {
                posRestoreLocalMysqlDataBackup(backupName);
                return;
            }
            var currencyEl = document.getElementById('restore-currency-choice');
            var forceCurrency = (currencyEl && currencyEl.value === 'USD') ? 'USD' : 'IQD';
            var currLabel = forceCurrency === 'USD' ? 'دولار ($)' : 'دینار عێراقی (IQD)';
            var tr = (typeof t === 'function') ? t : function () { return ''; };
            if (typeof posConfirmDataRestore === 'function') {
                var okLocal = await posConfirmDataRestore({
                    source: tr('confirm_data_restore_source_local') || 'گەڕاندنەوە لە backups/',
                    detail: String(backupName),
                    currencyLabel: currLabel
                });
                if (!okLocal) return;
            } else if (!confirm('⚠️ ئاگەهداربە!\n\nگەڕاندنەوە لە backups/:\n' + backupName + '\n\nهەموو داتای ئێستا دەگۆڕدرێت.\nدراڤ: ' + currLabel)) return;

            var formData = new FormData();
            formData.append('action', 'restore_backup');
            formData.append('backup_name', backupName);
            formData.append('force_currency', forceCurrency);

            var indicator = document.getElementById('save-indicator');
            if (indicator) {
                indicator.style.display = 'block';
                indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> گەڕاندنەوە لە backups/…';
            }

            fetch('?action=restore_backup', { method: 'POST', body: formData, credentials: 'same-origin' })
                .then(function (res) { return res.text().then(function (text) {
                    var t = (text || '').trim();
                    if (!t) throw new Error('وەڵامی سێرڤەر بەتاڵە');
                    try { return JSON.parse(t); } catch (e) { throw new Error(t.slice(0, 280)); }
                }); })
                .then(function (data) {
                    if (data.status === 'success') {
                        if (indicator) indicator.innerHTML = '<i class="fas fa-check"></i> گەڕاندنەوە سەرکەوت — ڕیفرێش…';
                        Object.keys(localStorage).forEach(function (key) {
                            if (key.startsWith('pos_tabs_state_')) localStorage.removeItem(key);
                        });
                        setTimeout(function () { location.reload(); }, 1500);
                    } else {
                        if (indicator) indicator.style.display = 'none';
                        alert('❌ ' + (data.message || 'error'));
                    }
                })
                .catch(function (err) {
                    if (indicator) indicator.style.display = 'none';
                    alert('❌ ' + err);
                });
        }

        async function posRestoreLocalMysqlDataBackup(backupName) {
            if (!backupName) return;
            var tr = (typeof t === 'function') ? t : function () { return ''; };
            if (typeof posConfirmDataRestore === 'function') {
                var okMysqlLocal = await posConfirmDataRestore({
                    source: tr('confirm_data_restore_source_local') || 'گەڕاندنەوە لە backups/',
                    detail: 'mysql/data · ' + backupName + '\n١) XAMPP → Stop MySQL'
                });
                if (!okMysqlLocal) return;
            }
            var typed = prompt(
                '⚠️ گرنگ!\n\n١) XAMPP → Stop MySQL\n٢) بنووسە: STOP_MYSQL\n\nفایل: ' + backupName,
                ''
            );
            if (typed !== 'STOP_MYSQL') {
                alert('هەڵوەشایەوە.');
                return;
            }
            var force = confirm('ئەگەر MySQL وەستاوە OK بکە.') ? '1' : '0';
            var formData = new FormData();
            formData.append('action', 'restore_mysql_data_backup');
            formData.append('backup_name', backupName);
            formData.append('confirm', 'STOP_MYSQL');
            formData.append('force', force);
            var indicator = document.getElementById('save-indicator');
            if (indicator) {
                indicator.style.display = 'block';
                indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i> گەڕاندنەوەی mysql/data…';
            }
            try {
                var res = await fetch('?action=restore_mysql_data_backup', { method: 'POST', body: formData, credentials: 'same-origin' });
                var text = (await res.text() || '').trim();
                var data = JSON.parse(text);
                if (data.status !== 'success') throw new Error(data.message || 'error');
                alert('✅ mysql/data گەڕایەوە.\n\nئێستا XAMPP → Start MySQL');
                setTimeout(function () { location.reload(); }, 1200);
            } catch (err) {
                if (indicator) indicator.style.display = 'none';
                alert('❌ ' + (err && err.message ? err.message : err));
            }
        }

        window.posRestoreLocalMysqlDataBackup = posRestoreLocalMysqlDataBackup;

        window.loadLocalBackupsList = loadLocalBackupsList;
        window.restoreLocalBackup = restoreLocalBackup;
        window.pushLocalBackupToCloudNow = pushLocalBackupToCloudNow;
        window.posExportDbToCloud = posExportDbToCloud;
        window.exportItemsDB = exportItemsDB;
        window.backupItemsToLocal = backupItemsToLocal;
        window.mergeItemsBackup = mergeItemsBackup;
        window.closeMergeItemsCurrencyModal = closeMergeItemsCurrencyModal;
        window.confirmMergeItemsWithCurrency = confirmMergeItemsWithCurrency;
        window.cleanupOperationalLogs = cleanupOperationalLogs;

