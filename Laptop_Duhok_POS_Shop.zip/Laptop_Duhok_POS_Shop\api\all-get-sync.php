<?php
// GET: sync, calendar, expiry, sales history
// --- NEW: SMART SYNC HANDLER (LIGHTWEIGHT) ---
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] == 'get_sync_data') {

    error_reporting(0); ini_set('display_errors', 0);
    header('Content-Type: application/json; charset=utf-8');
    if(session_id()) session_write_close(); // Prevent session locking
    set_time_limit(120); // Allow script to run longer for Long Polling
    
    $clientTime = isset($_GET['last_sync']) ? (float)$_GET['last_sync'] : 0;
    $wait = isset($_GET['wait']) ? true : false;
    $startTime = time();
    
    $is_manager = isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], ['admin', 'manager']);

    // LONG POLLING LOOP
    while(true) {
        $serverTime = 0;
        $res = $conn->query("SELECT setting_value FROM settings WHERE setting_key = 'last_update'");
        if($res && $row=$res->fetch_assoc()) $serverTime = (float)$row['setting_value'];

        // If data changed, break loop and send data
        if($serverTime > $clientTime) break;

        // If not waiting or timeout (25s), return no_change
        if(!$wait || (time() - $startTime) > 25) {
            echo json_encode(['status'=>'no_change', 'server_time'=>$serverTime]); 
            exit();
        }
        usleep(200000); // Sleep 0.2s
    }
    
    $data = ['tables'=>[], 'deliveries'=>[], 'drivers'=>[], 'stock'=>[], 'warehouse_stock'=>[], 'warehouses'=>[], 'users'=>[], 'customers'=>[], 'companies'=>[], 'today_stats'=>[], 'sales'=>[], 'expenses'=>[], 'server_time'=>$serverTime];
    
    // 1. Active Tables Only
    $res = $conn->query("SELECT * FROM tables");
    if($res) while($r=$res->fetch_assoc()) { 
        $r['id']=(int)$r['id']; $r['items'] = json_decode($r['items_json'] ?? '[]'); 
        $r['isTakeaway']=(bool)($r['isTakeaway'] ?? 0);
        $r['has_new_items']=(bool)($r['has_new_items'] ?? 0);
        $data['tables'][]=$r; 
    }
    // 2. Deliveries (compact: skip bulky items_json except pending)
    if (function_exists('pos_fetch_deliveries_compact')) {
        $data['deliveries'] = $is_manager
            ? pos_fetch_deliveries_compact($conn, 200, 0)
            : [];
    }
    $pendingSql = "SELECT id, customer_name, phone, address, driver, driver_phone, delivery_cost, total, status, `date`, note, customer_id, driver_id, sale_id, settled_at, items_json FROM deliveries WHERE status = 'pending'";
    $resPend = $conn->query($pendingSql);
    $pendingById = [];
    if ($resPend) while ($r = $resPend->fetch_assoc()) {
        $decodedItems = json_decode($r['items_json'] ?? '[]', true);
        unset($r['items_json']);
        $r['items'] = is_array($decodedItems) ? $decodedItems : [];
        $r = function_exists('pos_map_delivery_row_compact') ? pos_map_delivery_row_compact($r) : $r;
        $pendingById[(int)$r['id']] = $r;
    }
    if ($pendingById) {
        foreach ($data['deliveries'] as $i => $row) {
            $pid = (int)($row['id'] ?? 0);
            if ($pid && isset($pendingById[$pid])) {
                $data['deliveries'][$i] = $pendingById[$pid];
                unset($pendingById[$pid]);
            }
        }
        foreach ($pendingById as $row) {
            $data['deliveries'][] = $row;
        }
    }
    try {
        $resDrv = $conn->query("SELECT id, name, phone, note FROM drivers WHERE (is_active IS NULL OR is_active = 1) ORDER BY name ASC");
        if ($resDrv) while ($rd = $resDrv->fetch_assoc()) {
            $data['drivers'][] = [
                'id' => (int)($rd['id'] ?? 0),
                'name' => trim((string)($rd['name'] ?? '')),
                'phone' => trim((string)($rd['phone'] ?? '')),
                'note' => trim((string)($rd['note'] ?? ''))
            ];
        }
    } catch (Throwable $eDrv) { /* ignore */ }
    // 3. Stock Levels (Only ID & Qty)
    $res = $conn->query("SELECT id, qty FROM products WHERE trackStock = 1");
    if($res) while($r=$res->fetch_assoc()) { $data['stock'][] = ['id'=>(int)$r['id'], 'qty'=>(float)$r['qty']]; }
    $data['warehouses'] = function_exists('pos_fetch_warehouses_public')
        ? pos_fetch_warehouses_public($conn)
        : [];
    $data['open_warehouse_id'] = function_exists('pos_session_open_warehouse_id')
        ? pos_session_open_warehouse_id()
        : 0;
    $resWs = $conn->query("SELECT warehouse_id, product_id, qty FROM warehouse_stock");
    if ($resWs) while ($r = $resWs->fetch_assoc()) {
        $data['warehouse_stock'][] = ['warehouse_id' => (int)$r['warehouse_id'], 'product_id' => (int)$r['product_id'], 'qty' => (float)$r['qty']];
    }
    // 4. Users (For Permission Sync - include is_active for staff cards)
    $res = $conn->query("SELECT id, name, role, permissions, hourlyRate, balance, COALESCE(is_active,1) AS is_active FROM users");
    if($res) while($r=$res->fetch_assoc()) { 
        $r['id']=(int)$r['id']; 
        $r['hourlyRate']=roundMoney($r['hourlyRate']??0); $r['balance']=roundMoney($r['balance']??0);
        $r['permissions'] = json_decode($r['permissions'] ?? '[]', true); 
        $r['is_active'] = (int)($r['is_active'] ?? 1);
        $data['users'][]=$r; 
    }
    // 5. Customers Balance Sync (New)
    $res = $conn->query("SELECT id, balance, payment_term_value, payment_term_unit FROM customers WHERE (is_active IS NULL OR is_active != 0)");
    if($res) while($r=$res->fetch_assoc()) {
        $data['customers'][] = [
            'id'=>(int)$r['id'],
            'balance'=>roundMoney($r['balance']??0),
            'payment_term_value'=> (isset($r['payment_term_value']) ? (int)$r['payment_term_value'] : 0),
            'payment_term_unit'=> (isset($r['payment_term_unit']) ? (string)$r['payment_term_unit'] : 'day'),
        ];
    }
    // 6. Companies Balance Sync (New)
    $res = $conn->query("SELECT id, balance, payment_term_value, payment_term_unit FROM companies WHERE (is_active IS NULL OR is_active != 0)");
    if($res) while($r=$res->fetch_assoc()) {
        $data['companies'][] = [
            'id'=>(int)$r['id'],
            'balance'=>roundMoney($r['balance']??0),
            'payment_term_value'=> (isset($r['payment_term_value']) ? (int)$r['payment_term_value'] : 0),
            'payment_term_unit'=> (isset($r['payment_term_unit']) ? (string)$r['payment_term_unit'] : 'day'),
        ];
    }

    // 8. Recent Sales (more for manager)
    $sales_limit = $is_manager ? 200 : 30;
    $res = $conn->query("SELECT * FROM sales ORDER BY id DESC LIMIT $sales_limit");
    if($res) while($r=$res->fetch_assoc()) {
        $r['id']=(int)$r['id']; $r['total']=roundMoney($r['total']??0); $r['discount']=roundMoney($r['discount']??0);
        $r['items'] = json_decode($r['items_json'] ?? '[]'); 
        $r['is_returned'] = (int)($r['is_returned'] ?? 0);
        if(isset($r['created_at']) && !isset($r['date'])) $r['date'] = $r['created_at'];
        pos_attach_sale_customer_field($conn, $r);
        $data['sales'][]=$r;
    }
    if (!empty($data['sales']) && function_exists('pos_attach_sales_warehouse')) {
        pos_attach_sales_warehouse($conn, $data['sales']);
    }

    // 9. Recent Expenses (more for manager)
    $expenses_limit = $is_manager ? 200 : 30;
    $res = $conn->query("SELECT * FROM expenses ORDER BY id DESC LIMIT $expenses_limit");
    if($res) while($r=$res->fetch_assoc()) { $r['id']=(int)$r['id']; $r['amount']=roundMoney($r['amount']??0); $data['expenses'][]=$r; }

    // 7. Today's Stats — derive exclusively from pos_get_financial_metrics_core (business-day window).
    $appSettingsSync = function_exists('pos_load_app_settings_array') ? pos_load_app_settings_array($conn) : [];
    $todayStart = function_exists('pos_business_day_start_datetime')
        ? pos_business_day_start_datetime($appSettingsSync)
        : (date('Y-m-d') . ' 00:00:00');
    try {
        $bd = new DateTime($todayStart);
        $bd->modify('+1 day');
        $tomorrowStart = $bd->format('Y-m-d H:i:s');
    } catch (Throwable $eBd) {
        $tomorrowStart = date('Y-m-d', strtotime(substr($todayStart, 0, 10) . ' +1 day')) . ' ' . substr($todayStart, 11);
    }
    $data['today_stats'] = [
        'sales' => 0,
        'count' => 0,
        'expenses' => 0,
        'returns' => 0,
        'purchases' => 0,
        'purchases_cash' => 0,
        'purchases_debt' => 0,
    ];
    if (function_exists('pos_enrich_today_stats_finance')) {
        $data['today_stats'] = pos_enrich_today_stats_finance($conn, $data['today_stats'], $todayStart, $tomorrowStart);
    }
    $data['session_user'] = pos_session_user_for_client();

    echo json_encode($data); exit();
}

/**
 * Unified financial metrics (PHP mirror of JS getFinancialMetrics).
 * GET ?action=get_financial_metrics&from=YYYY-MM-DD&to=YYYY-MM-DD
 * Optional: currency=USD|IQD, cashier=, see_shop_wide=1
 */
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_financial_metrics') {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    if (empty($_SESSION['user_id'])) {
        echo json_encode(['status' => 'auth_required', 'message' => 'Login required'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    if (!function_exists('pos_get_financial_metrics_core')) {
        echo json_encode(['status' => 'error', 'message' => 'engine_unavailable'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $from = function_exists('pos_parse_history_date_ymd')
        ? pos_parse_history_date_ymd($_GET['from'] ?? ($_GET['date'] ?? ''), '')
        : trim((string)($_GET['from'] ?? ($_GET['date'] ?? '')));
    $to = function_exists('pos_parse_history_date_ymd')
        ? pos_parse_history_date_ymd($_GET['to'] ?? '', '')
        : trim((string)($_GET['to'] ?? ''));
    if ($from === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid from date'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    if ($to === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) {
        $to = $from;
    }
    $appSettingsFm = function_exists('pos_load_app_settings_array') ? pos_load_app_settings_array($conn) : [];
    if (function_exists('pos_business_day_range_datetimes')) {
        list($startDt, $endDt) = pos_business_day_range_datetimes($from, $to, is_array($appSettingsFm) ? $appSettingsFm : []);
    } else {
        $startDt = $from . ' 00:00:00';
        $endDt = date('Y-m-d', strtotime($to . ' +1 day')) . ' 00:00:00';
    }
    $mode = strtoupper(trim((string)($_GET['currency'] ?? '')));
    if ($mode !== 'USD' && $mode !== 'IQD') {
        $mode = (function_exists('pos_is_usd_currency_system') && pos_is_usd_currency_system($conn)) ? 'USD' : 'IQD';
    }
    $seeShopWide = !empty($_GET['see_shop_wide']) || (
        !empty($_SESSION['role']) && in_array((string)$_SESSION['role'], ['admin', 'manager'], true)
    );
    $cashier = trim((string)($_GET['cashier'] ?? ''));
    if ($cashier === '' && !$seeShopWide) {
        $cashier = trim((string)($_SESSION['username'] ?? ($_SESSION['name'] ?? '')));
    }
    $core = pos_get_financial_metrics_core($conn, $startDt, $endDt, $mode, [
        'see_shop_wide' => $seeShopWide,
        'cashier' => $cashier,
        'user_name' => $cashier,
    ]);
    echo json_encode([
        'status' => 'ok',
        'metrics_engine' => 'pos_get_financial_metrics_core',
        'metrics' => $core,
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

/**
 * Calendar month rollup from full tables (SPA only had last ~200 recent sales/expenses — past months appeared empty).
 * GET ?action=get_calendar_month_stats&year=YYYY&month=1-12 — session required.
 */
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_calendar_month_stats') {

    error_reporting(0);
    ini_set('display_errors', 0);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: private, max-age=60');

    if (empty($_SESSION['user_id'])) {
        echo json_encode(['status' => 'auth_required', 'message' => 'Login required'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $role = isset($_SESSION['user_role']) ? (string)$_SESSION['user_role'] : '';
    $uname = isset($_SESSION['user_name']) ? (string)$_SESSION['user_name'] : '';
    $seeShopWide = ($role === 'admin' || $role === 'manager');
    $cashierEsc = $conn->real_escape_string($uname);
    $userEsc = $cashierEsc;

    $reqUser = isset($_GET['user']) ? trim($_GET['user']) : 'all';
    if ($reqUser !== 'all' && $seeShopWide) {
        $seeShopWide = false;
        $cashierEsc = $conn->real_escape_string($reqUser);
        $userEsc = $cashierEsc;
    }

    // Release session lock immediately so calendar stats calculation never stalls other requests
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }

    $year = isset($_GET['year']) ? (int)$_GET['year'] : (int)date('Y');
    $monthNum = isset($_GET['month']) ? (int)$_GET['month'] : (int)date('n');
    if ($year < 1970 || $year > 2100 || $monthNum < 1 || $monthNum > 12) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid year/month'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $start = sprintf('%04d-%02d-01', $year, $monthNum);
    $startEsc = $conn->real_escape_string($start);
    $endExclusive = date('Y-m-d', strtotime($start . ' +1 month'));
    $endEsc = $conn->real_escape_string($endExclusive);

    // Proactive fix: Respect businessDayStartHour for calendar bucketing.
    $startHour = 0;
    if (function_exists('pos_load_app_settings_array')) {
        $settings = pos_load_app_settings_array($conn);
        $startHour = isset($settings['businessDayStartHour']) ? (int)$settings['businessDayStartHour'] : 0;
    }
    if ($startHour < 0) $startHour = 0;
    if ($startHour > 23) $startHour = 23;
    $shStr = sprintf('%02d:00:00', $startHour);

    $startDt = $startEsc . ' ' . $shStr;
    $endDt = $endEsc . ' ' . $shStr;

    $intervalSql = $startHour > 0 ? "INTERVAL $startHour HOUR" : null;
    $dateExprSales = $intervalSql ? "DATE(DATE_SUB(created_at, $intervalSql))" : "DATE(created_at)";
    $dateExprExp = $intervalSql ? "DATE(DATE_SUB(`date`, $intervalSql))" : "DATE(`date`)";
    $dateExprReturns = $intervalSql ? "DATE(DATE_SUB(`date`, $intervalSql))" : "DATE(`date`)";
    $dateExprWaste = $intervalSql ? "DATE(DATE_SUB(`date`, $intervalSql))" : "DATE(`date`)";

    $days = [];
    $monthSales = 0.0;
    $monthCount = 0;
    $monthExp = 0.0;

    $ensureDay = static function (&$days, $d) {
        if (!isset($days[$d])) {
            $days[$d] = [
                'sales_total' => 0.0,
                'sale_count' => 0,
                'exp_total' => 0.0,
                'exp_usd' => 0.0,
                'cogs' => 0.0,
                'cogs_usd' => 0.0,
                'sales_usd' => 0.0,
                'gifts' => 0.0,
                'gifts_count' => 0,
                'wholesale' => 0.0,
                'returns_total' => 0.0,
                'returns_cogs' => 0.0,
                'returns_usd' => 0.0,
                'returns_cogs_usd' => 0.0,
                'waste_total' => 0.0,
                'waste_usd' => 0.0,
                'waste_count' => 0,
            ];
        }
    };

    $retScopeEarly = '';
    if (!$seeShopWide && $uname !== '') {
        $retScopeEarly = " AND cashier = '$cashierEsc' ";
    }

    /** Load only products sold/returned this month (not entire catalog — faster on large shops). */
    $neededPids = [];
    $collectPidsFromItemsJson = static function ($itemsJson) use (&$neededPids) {
        $items = json_decode($itemsJson ?? '[]', true);
        if (!is_array($items)) {
            return;
        }
        foreach ($items as $it) {
            if (!is_array($it)) {
                continue;
            }
            $pid = (int)($it['id'] ?? 0);
            if ($pid > 0) {
                $neededPids[$pid] = true;
            }
        }
    };
    $qPidSales = "SELECT items_json FROM sales WHERE created_at >= '$startDt' AND created_at < '$endDt' AND (is_returned IS NULL OR is_returned = 0)";
    if (!$seeShopWide && $uname !== '') {
        $qPidSales .= " AND cashier = '$cashierEsc' ";
    }
    $resPidSales = $conn->query($qPidSales);
    if ($resPidSales) {
        while ($row = $resPidSales->fetch_assoc()) {
            $collectPidsFromItemsJson($row['items_json'] ?? '[]');
        }
    }
    $resPidRet = $conn->query("SELECT items_json FROM `returns` WHERE `date` >= '$startDt' AND `date` < '$endDt' $retScopeEarly");
    if ($resPidRet) {
        while ($row = $resPidRet->fetch_assoc()) {
            $collectPidsFromItemsJson($row['items_json'] ?? '[]');
        }
    }

    $prodMap = [];
    $productsById = [];
    if (!empty($neededPids)) {
        $inList = implode(',', array_map('intval', array_keys($neededPids)));
            $prRes = $conn->query("SELECT id, cost, price, cost_pack, cost_carton, cost_usd, cost_pack_usd, cost_carton_usd, takeawayPrice, takeawayPrice_pack, takeawayPrice_carton FROM products WHERE id IN ($inList)");
            if (!$prRes) {
                $prRes = $conn->query("SELECT id, cost, price, cost_pack, cost_carton, takeawayPrice, takeawayPrice_pack, takeawayPrice_carton FROM products WHERE id IN ($inList)");
            }
        while ($prRes && ($pRow = $prRes->fetch_assoc())) {
            $pid = (int)$pRow['id'];
            $productsById[$pid] = $pRow;
            $tw = (float)($pRow['takeawayPrice'] ?? 0);
            $twPack = (float)($pRow['takeawayPrice_pack'] ?? 0);
            $twCarton = (float)($pRow['takeawayPrice_carton'] ?? 0);
            if ($tw != 0.0 || $twPack != 0.0 || $twCarton != 0.0) {
                $prodMap[$pid] = $pRow;
            }
        }
    }

    $resolveLineCost = static function ($it) use ($productsById) {
        return pos_resolve_sale_line_cost(is_array($it) ? $it : [], $productsById);
    };

    $lineQty = static function ($it) {
        if (!is_array($it)) {
            return 1.0;
        }
        $raw = $it['qty'] ?? ($it['count'] ?? null);
        $q = is_numeric($raw) ? (float)$raw : 0.0;
        return ($q > 0) ? $q : 1.0;
    };

    /** Single pass: daily totals + COGS / gifts / wholesale from items_json (avoids scanning sales twice). */
    $qSales = "SELECT $dateExprSales AS dd, total, total_usd, items_json, fx_usd_rate, fx_currency_mode, exchange_rate FROM sales
               WHERE created_at >= '$startDt' AND created_at < '$endDt'
               AND (is_returned IS NULL OR is_returned = 0)";
    if (!$seeShopWide && $uname !== '') {
        $qSales .= " AND cashier = '$cashierEsc' ";
    }
    $resSales = $conn->query($qSales);
    if (!$resSales) {
        $qSales = "SELECT $dateExprSales AS dd, total, items_json, fx_usd_rate, fx_currency_mode FROM sales
                   WHERE created_at >= '$startDt' AND created_at < '$endDt'
                   AND (is_returned IS NULL OR is_returned = 0)";
        if (!$seeShopWide && $uname !== '') {
            $qSales .= " AND cashier = '$cashierEsc' ";
        }
        $resSales = $conn->query($qSales);
    }
    if (!$resSales) {
        $qSales = "SELECT $dateExprSales AS dd, total, items_json FROM sales
                   WHERE created_at >= '$startDt' AND created_at < '$endDt'
                   AND (is_returned IS NULL OR is_returned = 0)";
        if (!$seeShopWide && $uname !== '') {
            $qSales .= " AND cashier = '$cashierEsc' ";
        }
        $resSales = $conn->query($qSales);
    }
    if ($resSales) {
        while ($row = $resSales->fetch_assoc()) {
            $d = isset($row['dd']) ? (string)$row['dd'] : '';
            if ($d === '') {
                continue;
            }
            $ensureDay($days, $d);

            $saleAmt = isset($row['total']) ? (float)$row['total'] : 0.0;
            $days[$d]['sales_total'] += $saleAmt;
            $days[$d]['sale_count']++;
            $monthSales += $saleAmt;
            $monthCount++;
            $usdHint = (isset($row['total_usd']) && $row['total_usd'] !== '' && $row['total_usd'] !== null && is_numeric($row['total_usd']))
                ? (float)$row['total_usd']
                : null;
            if (function_exists('pos_stored_iqd_to_usd')) {
                $days[$d]['sales_usd'] += pos_stored_iqd_to_usd($saleAmt, $row, $usdHint, $conn);
            }

            $items = json_decode($row['items_json'] ?? '[]', true);
            if (!is_array($items)) {
                continue;
            }
            foreach ($items as $i) {
                if (!is_array($i)) {
                    continue;
                }
                $q = $lineQty($i);
                $cost = $resolveLineCost($i);
                $price = isset($i['price']) ? (float)$i['price'] : 0.0;
                $lineCogs = $cost * $q;
                $days[$d]['cogs'] += $lineCogs;
                if (function_exists('pos_stored_iqd_to_usd')) {
                    $costUsdHint = (isset($i['cost_usd']) && $i['cost_usd'] !== '' && $i['cost_usd'] !== null && is_numeric($i['cost_usd']))
                        ? ((float)$i['cost_usd'] * $q)
                        : null;
                    $days[$d]['cogs_usd'] += pos_stored_iqd_to_usd($lineCogs, $row, $costUsdHint, $conn);
                }
                if (!empty($i['isGift'])) {
                    $days[$d]['gifts'] += $price * $q;
                    $days[$d]['gifts_count'] += $q;
                }

                $pid = isset($i['id']) ? (int)$i['id'] : 0;
                $saleUnit = isset($i['saleUnit']) ? (string)$i['saleUnit'] : 'piece';
                $tw = 0.0;
                if ($pid && isset($prodMap[$pid])) {
                    $pv = $prodMap[$pid];
                    if ($saleUnit === 'carton' && !empty($pv['takeawayPrice_carton'])) {
                        $tw = (float)$pv['takeawayPrice_carton'];
                    } elseif ($saleUnit === 'pack' && !empty($pv['takeawayPrice_pack'])) {
                        $tw = (float)$pv['takeawayPrice_pack'];
                    } elseif (!empty($pv['takeawayPrice'])) {
                        $tw = (float)$pv['takeawayPrice'];
                    }
                }
                if ($tw > 0 && (int)round($price) === (int)round($tw)) {
                    $days[$d]['wholesale'] += $price * $q;
                }
            }
        }
    }

    $expWhereExtra = '';
    if (!$seeShopWide && $uname !== '') {
        $expWhereExtra = " AND `user` = '$userEsc' ";
    }

    /** Expenses per calendar day — operational only; locked USD from row stamps (never live FX). */
    $expIqdSql = function_exists('pos_sql_expense_amount_iqd') ? pos_sql_expense_amount_iqd() : 'amount';
    $qERows = "SELECT $dateExprExp AS dd, amount, currency, exchange_rate, type
           FROM expenses
           WHERE `date` >= '$startDt' AND `date` < '$endDt'
           AND (type IS NULL OR type = '' OR type = 'operational')
           $expWhereExtra";
    $resERows = $conn->query($qERows);
    if ($resERows) {
        while ($row = $resERows->fetch_assoc()) {
            $d = isset($row['dd']) ? (string)$row['dd'] : '';
            if ($d === '') {
                continue;
            }
            $ensureDay($days, $d);
            $iqd = function_exists('pos_expense_amount_iqd') ? (float)pos_expense_amount_iqd($row) : (float)($row['amount'] ?? 0);
            $usd = function_exists('pos_expense_amount_usd') ? (float)pos_expense_amount_usd($row) : 0.0;
            $days[$d]['exp_total'] += $iqd;
            $days[$d]['exp_usd'] += $usd;
            $monthExp += $iqd;
        }
    } else {
        $qE = "SELECT $dateExprExp AS dd, COALESCE(SUM($expIqdSql),0) AS tt
           FROM expenses
           WHERE `date` >= '$startDt' AND `date` < '$endDt'
           AND (type IS NULL OR type = '' OR type = 'operational')
           $expWhereExtra
           GROUP BY $dateExprExp";
        $resE = $conn->query($qE);
        if ($resE) {
            while ($row = $resE->fetch_assoc()) {
                $d = isset($row['dd']) ? (string)$row['dd'] : '';
                if ($d === '') {
                    continue;
                }
                $ensureDay($days, $d);
                $amt = isset($row['tt']) ? (float)$row['tt'] : 0.0;
                $days[$d]['exp_total'] = roundMoney($amt);
                $monthExp += $amt;
            }
        }
    }

    /** Waste / spoilage per day — ledger type waste (parity with getFinancialMetrics). */
    $monthWaste = 0.0;
    $monthWasteCount = 0;
    try {
        $qWasteRows = "SELECT $dateExprWaste AS dd, amount, exchange_rate, currency, fx_usd_rate
                   FROM ledger
                   WHERE type = 'waste'
                   AND `date` >= '$startDt' AND `date` < '$endDt'";
        $resWasteRows = @$conn->query($qWasteRows);
        if (!$resWasteRows) {
            $qWasteRows = "SELECT $dateExprWaste AS dd, amount
                   FROM ledger
                   WHERE type = 'waste'
                   AND `date` >= '$startDt' AND `date` < '$endDt'";
            $resWasteRows = $conn->query($qWasteRows);
        }
        if ($resWasteRows) {
            while ($row = $resWasteRows->fetch_assoc()) {
                $d = isset($row['dd']) ? (string)$row['dd'] : '';
                if ($d === '') {
                    continue;
                }
                $ensureDay($days, $d);
                $amt = (float)($row['amount'] ?? 0);
                $days[$d]['waste_total'] += $amt;
                $days[$d]['waste_count']++;
                $monthWaste += $amt;
                $monthWasteCount++;
                if (function_exists('pos_stored_iqd_to_usd')) {
                    $days[$d]['waste_usd'] += pos_stored_iqd_to_usd($amt, $row, null, $conn);
                }
            }
        }
    } catch (Throwable $e) { /* ledger/waste may be unavailable */ }

    /** Sales returns per day — net profit parity with getFinancialMetrics (SPA). */
    $qRet = "SELECT $dateExprReturns AS dd, total, total_usd, items_json, fx_usd_rate, fx_currency_mode, exchange_rate FROM returns
             WHERE `date` >= '$startDt' AND `date` < '$endDt'";
    if (!$seeShopWide && $uname !== '') {
        $qRet .= " AND cashier = '$cashierEsc' ";
    }
    $resRet = @$conn->query($qRet);
    if (!$resRet) {
        $qRet = "SELECT $dateExprReturns AS dd, total, items_json, fx_usd_rate, fx_currency_mode FROM returns
             WHERE `date` >= '$startDt' AND `date` < '$endDt'";
        if (!$seeShopWide && $uname !== '') {
            $qRet .= " AND cashier = '$cashierEsc' ";
        }
        $resRet = @$conn->query($qRet);
    }
    if (!$resRet) {
        $qRet = "SELECT $dateExprReturns AS dd, total, items_json FROM returns
             WHERE `date` >= '$startDt' AND `date` < '$endDt'";
        if (!$seeShopWide && $uname !== '') {
            $qRet .= " AND cashier = '$cashierEsc' ";
        }
        $resRet = $conn->query($qRet);
    }
    if ($resRet) {
        while ($row = $resRet->fetch_assoc()) {
            $d = isset($row['dd']) ? (string)$row['dd'] : '';
            if ($d === '') {
                continue;
            }
            $ensureDay($days, $d);
            $retAmt = isset($row['total']) ? (float)$row['total'] : 0.0;
            $days[$d]['returns_total'] += $retAmt;
            $retUsdHint = (isset($row['total_usd']) && $row['total_usd'] !== '' && $row['total_usd'] !== null && is_numeric($row['total_usd']))
                ? (float)$row['total_usd']
                : null;
            if (function_exists('pos_stored_iqd_to_usd')) {
                $days[$d]['returns_usd'] += pos_stored_iqd_to_usd($retAmt, $row, $retUsdHint, $conn);
            }

            $items = json_decode($row['items_json'] ?? '[]', true);
            if (!is_array($items)) {
                continue;
            }
            foreach ($items as $i) {
                if (!is_array($i)) {
                    continue;
                }
                $q = $lineQty($i);
                $cost = $resolveLineCost($i);
                $lineCogs = $cost * $q;
                $days[$d]['returns_cogs'] += $lineCogs;
                if (function_exists('pos_stored_iqd_to_usd')) {
                    $costUsdHint = (isset($i['cost_usd']) && $i['cost_usd'] !== '' && $i['cost_usd'] !== null && is_numeric($i['cost_usd']))
                        ? ((float)$i['cost_usd'] * $q)
                        : null;
                    $days[$d]['returns_cogs_usd'] += pos_stored_iqd_to_usd($lineCogs, $row, $costUsdHint, $conn);
                }
            }
        }
    }

    $outDays = [];
    $sumDayProfit = 0.0;
    $sumCogsMonth = 0.0;
    $sumGiftsMonth = 0.0;
    $sumGiftsCountMonth = 0.0;
    $sumWholesaleMonth = 0.0;

    foreach ($days as $dn => $recRow) {
        $salePart = isset($recRow['sales_total']) ? (float)$recRow['sales_total'] : 0.0;
        $expPart = isset($recRow['exp_total']) ? (float)$recRow['exp_total'] : 0.0;
        $salePart = roundMoney($salePart);
        $expPart = roundMoney($expPart);
        $cogsRounded = roundMoney(isset($recRow['cogs']) ? (float)$recRow['cogs'] : 0.0);
        $returnsPart = roundMoney(isset($recRow['returns_total']) ? (float)$recRow['returns_total'] : 0.0);
        $returnsCogsRounded = roundMoney(isset($recRow['returns_cogs']) ? (float)$recRow['returns_cogs'] : 0.0);
        $giftsRounded = roundMoney(isset($recRow['gifts']) ? (float)$recRow['gifts'] : 0.0);
        $giftsCountDay = isset($recRow['gifts_count']) ? (float)$recRow['gifts_count'] : 0.0;
        $whRounded = roundMoney(isset($recRow['wholesale']) ? (float)$recRow['wholesale'] : 0.0);
        $wasteRounded = roundMoney(isset($recRow['waste_total']) ? (float)$recRow['waste_total'] : 0.0);
        $wasteCountDay = isset($recRow['waste_count']) ? (int)$recRow['waste_count'] : 0;

        /** Profit: (sales − returns) − (COGS − return COGS) − expenses − waste */
        $profitDay = roundMoney($salePart - $returnsPart - ($cogsRounded - $returnsCogsRounded) - $expPart - $wasteRounded);
        $salesUsdDay = round(isset($recRow['sales_usd']) ? (float)$recRow['sales_usd'] : 0.0, 2);
        $cogsUsdDay = round(isset($recRow['cogs_usd']) ? (float)$recRow['cogs_usd'] : 0.0, 2);
        $expUsdDay = round(isset($recRow['exp_usd']) ? (float)$recRow['exp_usd'] : 0.0, 2);
        $retUsdDay = round(isset($recRow['returns_usd']) ? (float)$recRow['returns_usd'] : 0.0, 2);
        $retCogsUsdDay = round(isset($recRow['returns_cogs_usd']) ? (float)$recRow['returns_cogs_usd'] : 0.0, 2);
        $wasteUsdDay = round(isset($recRow['waste_usd']) ? (float)$recRow['waste_usd'] : 0.0, 2);
        $profitUsdDay = round($salesUsdDay - $retUsdDay - ($cogsUsdDay - $retCogsUsdDay) - $expUsdDay - $wasteUsdDay, 2);

        $outDays[$dn] = [
            'sales_total' => $salePart,
            'sale_count' => isset($recRow['sale_count']) ? (int)$recRow['sale_count'] : 0,
            'exp_total' => $expPart,
            'cogs' => $cogsRounded,
            'returns_total' => $returnsPart,
            'returns_cogs' => $returnsCogsRounded,
            'gifts' => $giftsRounded,
            'gifts_count' => $giftsCountDay,
            'wholesale' => $whRounded,
            'waste_total' => $wasteRounded,
            'waste_count' => $wasteCountDay,
            'profit' => $profitDay,
            'sales_usd' => $salesUsdDay,
            'cogs_usd' => $cogsUsdDay,
            'exp_usd' => $expUsdDay,
            'returns_usd' => $retUsdDay,
            'returns_cogs_usd' => $retCogsUsdDay,
            'waste_usd' => $wasteUsdDay,
            'profit_usd' => $profitUsdDay,
        ];

        $sumDayProfit += (float)$profitDay;
        $sumCogsMonth += $cogsRounded;
        $sumGiftsMonth += $giftsRounded;
        $sumGiftsCountMonth += $giftsCountDay;
        $sumWholesaleMonth += $whRounded;
    }

    /** Month profit = Σ(day sales − COGS − day expenses) matches summing SPA daily cells when days are exhaustive */

    $installmentDays = [];
    try {
        if (pos_installments_pro_enabled($conn)) {
        pos_update_installment_overdue_status($conn);
        $qInst = "SELECT i.due_date, i.amount, i.paid_amount, i.installment_no, i.status,
                         p.customer_id, COALESCE(c.name, CONCAT('#', p.customer_id)) AS customer_name
                  FROM customer_installment_items i
                  INNER JOIN customer_installment_plans p ON p.id = i.plan_id AND p.status = 'active'
                  LEFT JOIN customers c ON c.id = p.customer_id
                  WHERE i.due_date >= '$startEsc' AND i.due_date < '$endEsc'
                  AND i.status IN ('pending','overdue','partial')
                  ORDER BY i.due_date ASC, i.installment_no ASC";
        $resInst = $conn->query($qInst);
        if ($resInst) {
            while ($ir = $resInst->fetch_assoc()) {
                $dInst = isset($ir['due_date']) ? (string)$ir['due_date'] : '';
                if ($dInst === '') continue;
                $amt = roundMoney($ir['amount'] ?? 0);
                $paid = roundMoney($ir['paid_amount'] ?? 0);
                $remaining = pos_installment_money_iqd(max(0, $amt - $paid));
                if ($remaining <= 0) continue;
                if (!isset($installmentDays[$dInst])) {
                    $installmentDays[$dInst] = ['count' => 0, 'total' => 0.0, 'items' => []];
                }
                $installmentDays[$dInst]['count']++;
                $installmentDays[$dInst]['total'] = roundMoney($installmentDays[$dInst]['total'] + $remaining);
                $installmentDays[$dInst]['items'][] = [
                    'customer_id' => (int)($ir['customer_id'] ?? 0),
                    'customer_name' => (string)($ir['customer_name'] ?? ''),
                    'installment_no' => (int)($ir['installment_no'] ?? 0),
                    'amount' => $amt,
                    'remaining' => $remaining,
                    'status' => (string)($ir['status'] ?? 'pending'),
                ];
            }
        }
        }
    } catch (Throwable $e) { /* tables may not exist yet */ }

    $monthInstallmentTotal = 0.0;
    $monthInstallmentCount = 0;
    foreach ($installmentDays as $idRec) {
        $monthInstallmentCount += (int)($idRec['count'] ?? 0);
        $monthInstallmentTotal = roundMoney($monthInstallmentTotal + (float)($idRec['total'] ?? 0));
    }

    $monthPurchases = 0.0;
    $monthPurchaseCount = 0;
    $qPur = "SELECT COALESCE(SUM(totalCost),0) AS tot,
                    COUNT(DISTINCT COALESCE(NULLIF(transaction_id,''), CONCAT('L', id))) AS inv_cnt
             FROM supplies
             WHERE `date` >= '$startDt' AND `date` < '$endDt'
             AND COALESCE(type,'') NOT IN ('return','opening')
             AND qtyAdded > 0
             AND company IS NOT NULL AND TRIM(company) != ''
             AND LOWER(TRIM(company)) NOT LIKE 'direct store'";
    $resPur = $conn->query($qPur);
    if ($resPur && ($rp = $resPur->fetch_assoc())) {
        $monthPurchases = roundMoney($rp['tot'] ?? 0);
        $monthPurchaseCount = (int)($rp['inv_cnt'] ?? 0);
    }
    $qOrphanPur = "SELECT COALESCE(SUM(e.amount),0) AS tot, COUNT(*) AS cnt
        FROM expenses e
        WHERE e.`date` >= '$startDt' AND e.`date` < '$endDt'
        AND e.type = 'purchase' $expWhereExtra
        AND (
            e.transaction_id IS NULL OR TRIM(e.transaction_id) = ''
            OR NOT EXISTS (
                SELECT 1 FROM supplies s
                WHERE s.transaction_id = e.transaction_id
                AND s.`date` >= '$startDt' AND s.`date` < '$endDt'
                AND COALESCE(s.type,'') NOT IN ('return','opening')
                AND s.qtyAdded > 0
            )
        )";
    $resOrphanPur = $conn->query($qOrphanPur);
    if ($resOrphanPur && ($orp = $resOrphanPur->fetch_assoc())) {
        $orphanPurTot = roundMoney($orp['tot'] ?? 0);
        $orphanPurCnt = (int)($orp['cnt'] ?? 0);
        if ($orphanPurTot > 0) {
            $monthPurchases = roundMoney($monthPurchases + $orphanPurTot);
            $monthPurchaseCount += $orphanPurCnt;
        }
    }

    $monthPurchaseReturns = 0.0;
    $monthPurchaseReturnCount = 0;
    $monthPurchaseReturnsCash = 0.0;
    try {
        $prScope = '';
        if (!$seeShopWide && $uname !== '') {
            $prScope = " AND `user` = '$userEsc' ";
        }
        $rprM = $conn->query("SELECT COUNT(*) AS cnt, COALESCE(SUM(total),0) AS tot FROM purchase_returns WHERE `date` >= '$startDt' AND `date` < '$endDt' $prScope");
        if ($rprM && ($prr = $rprM->fetch_assoc())) {
            $monthPurchaseReturnCount = (int)($prr['cnt'] ?? 0);
            $monthPurchaseReturns = roundMoney($prr['tot'] ?? 0);
        }
        $resPrCash = $conn->query("SELECT COALESCE(SUM(ABS(" . (function_exists('pos_sql_expense_amount_iqd') ? pos_sql_expense_amount_iqd() : 'amount') . ")),0) AS tot FROM expenses WHERE `date` >= '$startDt' AND `date` < '$endDt' AND type = 'purchase_return' $expWhereExtra");
        if ($resPrCash && ($prc = $resPrCash->fetch_assoc())) {
            $monthPurchaseReturnsCash = roundMoney($prc['tot'] ?? 0);
        }
        if ($monthPurchaseReturnsCash <= 0 && $monthPurchaseReturns > 0) {
            $monthPurchaseReturnsCash = $monthPurchaseReturns;
        }
    } catch (Throwable $e) { /* table may not exist */ }

    $retScopeM = '';
    if (!$seeShopWide && $uname !== '') {
        $retScopeM = " AND cashier = '$cashierEsc' ";
    }
    $monthReturnsTotal = 0.0;
    $monthReturnsCount = 0;
    $rretM = $conn->query("SELECT COUNT(*) AS cnt, COALESCE(SUM(total),0) AS tot FROM `returns` WHERE `date` >= '$startDt' AND `date` < '$endDt' $retScopeM");
    if ($rretM && ($rrm = $rretM->fetch_assoc())) {
        $monthReturnsCount = (int)($rrm['cnt'] ?? 0);
        $monthReturnsTotal = roundMoney($rrm['tot'] ?? 0);
    }

    $monthCustomerDebtIn = 0.0;
    $monthCustomerDebtCount = 0;
    try {
        $clTsM = pos_table_date_column_sql($conn, 'customer_ledger', 'cl');
        $dateExprClM = $intervalSql ? "DATE(DATE_SUB($clTsM, $intervalSql))" : "DATE($clTsM)";
        $rcdm = $conn->query("SELECT COUNT(*) AS cnt, COALESCE(SUM(amount),0) AS tot FROM customer_ledger cl WHERE cl.type = 'payment' AND $dateExprClM >= '$startEsc' AND $dateExprClM < '$endEsc'");
        if ($rcdm && ($cdr = $rcdm->fetch_assoc())) {
            $monthCustomerDebtCount = (int)($cdr['cnt'] ?? 0);
            $monthCustomerDebtIn = roundMoney($cdr['tot'] ?? 0);
        }
    } catch (Throwable $e) { /* ignore */ }

    $monthCompanyDebtPay = 0.0;
    $monthCompanyDebtCount = 0;
    $qCD = "SELECT COUNT(*) AS cnt, COALESCE(SUM(" . (function_exists('pos_sql_expense_amount_iqd') ? pos_sql_expense_amount_iqd() : 'amount') . "),0) AS tot FROM expenses
            WHERE `date` >= '$startDt' AND `date` < '$endDt'
            AND type = 'debt_payment' $expWhereExtra";
    $rcdExp = $conn->query($qCD);
    if ($rcdExp && ($cdrE = $rcdExp->fetch_assoc())) {
        $monthCompanyDebtCount = (int)($cdrE['cnt'] ?? 0);
        $monthCompanyDebtPay = roundMoney($cdrE['tot'] ?? 0);
    }

    $monthOpening = 0.0;
    $shiftScope = '';
    if (!$seeShopWide && !empty($_SESSION['user_id'])) {
        $uid = (int)$_SESSION['user_id'];
        $shiftScope = " AND userId = $uid ";
    }
    /** Month drawer opening = first shift of month only (not Σ all shifts — that inflated قاسە). */
    $ropFirst = $conn->query("SELECT opening_balance FROM shifts WHERE startTime >= '$startDt' AND startTime < '$endDt' $shiftScope ORDER BY startTime ASC LIMIT 1");
    if ($ropFirst && ($ropRow = $ropFirst->fetch_assoc())) {
        $monthOpening = roundMoney($ropRow['opening_balance'] ?? 0);
    }

    $saleScopeActive = "(s.is_returned IS NULL OR s.is_returned = 0)";
    if (!$seeShopWide && $uname !== '') {
        $saleScopeActive .= " AND s.cashier = '$cashierEsc' ";
    }
    $saleScopeDebt = $saleScopeActive . " AND (s.payment_method = 'debt' OR COALESCE(s.debt_amount,0) > 0)";
    $monthCashSales = 0.0;
    $monthDebtSales = 0.0;
    // Cash portion: paid_cash / paid_amount when >0; else total − debt − bank (legacy cash rows may have paid_cash=0)
    $resCashSales = $conn->query(
        "SELECT COALESCE(SUM("
        . " CASE"
        . "  WHEN s.payment_method = 'debt' THEN 0"
        . "  WHEN s.payment_method IN ('fib','bank','bankcard','card') THEN 0"
        . "  WHEN COALESCE(s.paid_cash, 0) > 0 THEN s.paid_cash"
        . "  WHEN COALESCE(s.bank_amount, 0) > 0 THEN GREATEST(0, COALESCE(s.paid_amount,0) - COALESCE(s.bank_amount,0))"
        . "  WHEN COALESCE(s.paid_amount, 0) > 0 THEN s.paid_amount"
        . "  ELSE GREATEST(0, s.total - COALESCE(s.debt_amount,0) - COALESCE(s.bank_amount,0))"
        . " END"
        . "),0) AS tot FROM sales s WHERE s.created_at >= '$startDt' AND s.created_at < '$endDt' AND $saleScopeActive"
    );
    if ($resCashSales && ($csr = $resCashSales->fetch_assoc())) {
        $monthCashSales = roundMoney($csr['tot'] ?? 0);
    }
    $resDebtSales = $conn->query(
        "SELECT COALESCE(SUM("
        . " CASE"
        . "  WHEN s.payment_method = 'debt' THEN s.total"
        . "  ELSE GREATEST(0, COALESCE(s.debt_amount,0))"
        . " END"
        . "),0) AS tot FROM sales s WHERE s.created_at >= '$startDt' AND s.created_at < '$endDt' AND $saleScopeDebt"
    );
    if ($resDebtSales && ($dsr = $resDebtSales->fetch_assoc())) {
        $monthDebtSales = roundMoney($dsr['tot'] ?? 0);
    }
    $monthFibSales = 0.0;
    $resFibSales = $conn->query(
        "SELECT COALESCE(SUM("
        . " CASE"
        . "  WHEN s.payment_method IN ('fib','bank','bankcard','card') THEN s.total"
        . "  ELSE GREATEST(0, COALESCE(s.bank_amount,0))"
        . " END"
        . "),0) AS tot FROM sales s WHERE s.created_at >= '$startDt' AND s.created_at < '$endDt' AND $saleScopeActive"
    );
    if ($resFibSales && ($fsr = $resFibSales->fetch_assoc())) {
        $monthFibSales = roundMoney($fsr['tot'] ?? 0);
    }

    $monthCashReturns = 0.0;
    $resCashRet = $conn->query("SELECT COALESCE(SUM(total),0) AS tot FROM `returns` WHERE `date` >= '$startDt' AND `date` < '$endDt' AND (payment_method IS NULL OR payment_method = '' OR payment_method <> 'debt') $retScopeM");
    if ($resCashRet && ($crr = $resCashRet->fetch_assoc())) {
        $monthCashReturns = roundMoney($crr['tot'] ?? 0);
    }

    /** Voided sales invoices (delete receipt) — sales.is_returned = 1; not customer returns */
    $monthVoidedSales = 0.0;
    $monthVoidedSalesCount = 0;
    $voidSaleScope = '';
    if (!$seeShopWide && $uname !== '') {
        $voidSaleScope = " AND cashier = '$cashierEsc' ";
    }
    $resVoidSales = $conn->query("SELECT COUNT(*) AS cnt, COALESCE(SUM(total),0) AS tot FROM sales WHERE created_at >= '$startDt' AND created_at < '$endDt' AND is_returned = 1 $voidSaleScope");
    if ($resVoidSales && ($vsr = $resVoidSales->fetch_assoc())) {
        $monthVoidedSalesCount = (int)($vsr['cnt'] ?? 0);
        $monthVoidedSales = roundMoney($vsr['tot'] ?? 0);
    }

    /** Voided purchase invoices — audit_logs void_purchase_invoice (exclude supplier-return voids) */
    $monthVoidedPurchases = 0.0;
    $monthVoidedPurchasesCount = 0;
    try {
        $voidPurUserScopeM = '';
        if (!$seeShopWide && $uname !== '') {
            $voidPurUserScopeM = " AND `user` = '$userEsc' ";
        }
        $qVoidPurM = "SELECT id, old_value, new_value FROM audit_logs
            WHERE action_type = 'void_purchase_invoice'
            AND created_at >= '$startDt' AND created_at < '$endDt'
            $voidPurUserScopeM";
        $resVoidPurM = $conn->query($qVoidPurM);
        if ($resVoidPurM) {
            while ($vpr = $resVoidPurM->fetch_assoc()) {
                $snap = null;
                if (!empty($vpr['old_value'])) {
                    $decoded = json_decode((string)$vpr['old_value'], true);
                    if (is_array($decoded)) {
                        $snap = $decoded;
                    }
                }
                if (function_exists('pos_void_purchase_audit_is_active') && !pos_void_purchase_audit_is_active($conn, $vpr, $snap)) {
                    continue;
                }
                $kind = '';
                if (is_array($snap) && !empty($snap['kind'])) {
                    $kind = strtolower(trim((string)$snap['kind']));
                } elseif (is_array($snap) && !empty($snap['type'])) {
                    $kind = (strtolower(trim((string)$snap['type'])) === 'return') ? 'return' : 'purchase';
                }
                if ($kind === 'return') {
                    continue;
                }
                $monthVoidedPurchasesCount++;
                $monthVoidedPurchases = roundMoney($monthVoidedPurchases + (is_array($snap) ? (float)($snap['total'] ?? 0) : 0));
            }
        }
    } catch (Throwable $e) { /* audit_logs may not exist */ }

    $monthCashPurchases = 0.0;
    $monthCashPurchaseCount = 0;
    $resCashPur = $conn->query("SELECT COUNT(*) AS cnt, COALESCE(SUM(" . (function_exists('pos_sql_expense_amount_iqd') ? pos_sql_expense_amount_iqd() : 'amount') . "),0) AS tot FROM expenses WHERE `date` >= '$startDt' AND `date` < '$endDt' AND type = 'purchase' $expWhereExtra");
    if ($resCashPur && ($cpr = $resCashPur->fetch_assoc())) {
        $monthCashPurchaseCount = (int)($cpr['cnt'] ?? 0);
        $monthCashPurchases = roundMoney($cpr['tot'] ?? 0);
    }
    $monthFibPurchases = 0.0;
    $resFibPur = $conn->query(
        "SELECT COALESCE(SUM(totalCost),0) AS tot FROM supplies
         WHERE `date` >= '$startDt' AND `date` < '$endDt'
         AND COALESCE(type,'') IN ('fib','bank','bankcard')
         AND qtyAdded > 0
         AND company IS NOT NULL AND TRIM(company) != ''
         AND LOWER(TRIM(company)) NOT LIKE 'direct store'"
    );
    if ($resFibPur && ($fpr = $resFibPur->fetch_assoc())) {
        $monthFibPurchases = roundMoney($fpr['tot'] ?? 0);
    }

    /** Cash box movement — parity with SPA getFinancialMetrics (cash sales/refunds, not debt). */
    $monthCashMovement = roundMoney(
        $monthCashSales + $monthCustomerDebtIn + $monthPurchaseReturnsCash
        - $monthExp - $monthCashPurchases - $monthCompanyDebtPay - $monthCashReturns
    );
    $monthCashDrawer = roundMoney($monthOpening + $monthCashMovement);

    $expiryDays = [];
    $monthExpiryCount = 0;
    try {
        $qExp = "SELECT b.expiry_date, b.product_id, COALESCE(p.name, CONCAT('#', b.product_id)) AS name, SUM(b.qty) AS qty
                 FROM stock_batches b
                 LEFT JOIN products p ON p.id = b.product_id
                 WHERE b.qty > 0.000001
                 AND b.expiry_date >= '$startEsc' AND b.expiry_date < '$endEsc'
                 GROUP BY b.expiry_date, b.product_id, p.name
                 ORDER BY b.expiry_date ASC, p.name ASC";
        $resExp = $conn->query($qExp);
        if ($resExp) {
            while ($er = $resExp->fetch_assoc()) {
                $dExp = isset($er['expiry_date']) ? (string)$er['expiry_date'] : '';
                if ($dExp === '' || strpos($dExp, '0000') === 0) {
                    continue;
                }
                $qtyExp = (float)($er['qty'] ?? 0);
                if ($qtyExp <= 0) {
                    continue;
                }
                if (!isset($expiryDays[$dExp])) {
                    $expiryDays[$dExp] = ['count' => 0, 'items' => []];
                }
                $expiryDays[$dExp]['count']++;
                $expiryDays[$dExp]['items'][] = [
                    'product_id' => (int)($er['product_id'] ?? 0),
                    'name' => (string)($er['name'] ?? ''),
                    'qty' => $qtyExp,
                ];
                $monthExpiryCount++;
            }
        }
    } catch (Throwable $e) { /* stock_batches may not exist yet */ }

    $monthDelTotal = 0.0;
    $monthDelCount = 0;
    $monthDelPending = 0.0;
    $monthDelPendingCount = 0;
    $monthDelDelivered = 0.0;
    $monthDelDeliveredCount = 0;
    $monthDelRefused = 0.0;
    $monthDelRefusedCount = 0;
    $monthDelCancelled = 0.0;
    $monthDelCancelledCount = 0;
    $monthDelHold = 0.0;
    $monthDelHoldCount = 0;
    try {
        $qDelAll = $conn->query("SELECT COUNT(*) AS cnt, COALESCE(SUM(total),0) AS tt FROM deliveries WHERE `date` >= '$startDt' AND `date` < '$endDt'");
        if ($qDelAll && ($rowDel = $qDelAll->fetch_assoc())) {
            $monthDelCount = (int)($rowDel['cnt'] ?? 0);
            $monthDelTotal = (float)($rowDel['tt'] ?? 0);
        }
        $qDelPend = $conn->query("SELECT COUNT(*) AS cnt, COALESCE(SUM(total),0) AS tt FROM deliveries WHERE `date` >= '$startDt' AND `date` < '$endDt' AND LOWER(status) = 'pending'");
        if ($qDelPend && ($rowDel = $qDelPend->fetch_assoc())) {
            $monthDelPendingCount = (int)($rowDel['cnt'] ?? 0);
            $monthDelPending = (float)($rowDel['tt'] ?? 0);
        }
        $qDelSet = $conn->query("SELECT LOWER(status) AS st, COUNT(*) AS cnt, COALESCE(SUM(total),0) AS tt FROM deliveries WHERE settled_at IS NOT NULL AND settled_at >= '$startDt' AND settled_at < '$endDt' GROUP BY LOWER(status)");
        if ($qDelSet) {
            while ($rowDel = $qDelSet->fetch_assoc()) {
                $stDel = strtolower(trim((string)($rowDel['st'] ?? '')));
                $cntDel = (int)($rowDel['cnt'] ?? 0);
                $ttDel = (float)($rowDel['tt'] ?? 0);
                if ($stDel === 'delivered') {
                    $monthDelDeliveredCount = $cntDel;
                    $monthDelDelivered = $ttDel;
                } elseif ($stDel === 'refused') {
                    $monthDelRefusedCount = $cntDel;
                    $monthDelRefused = $ttDel;
                } elseif ($stDel === 'cancelled') {
                    $monthDelCancelledCount = $cntDel;
                    $monthDelCancelled = $ttDel;
                }
            }
        }
        $qDelHold = $conn->query("SELECT COUNT(*) AS cnt, COALESCE(SUM(total),0) AS tt FROM deliveries WHERE LOWER(status) = 'pending'");
        if ($qDelHold && ($rowDel = $qDelHold->fetch_assoc())) {
            $monthDelHoldCount = (int)($rowDel['cnt'] ?? 0);
            $monthDelHold = (float)($rowDel['tt'] ?? 0);
        }
    } catch (Throwable $e) { /* deliveries table may not exist yet */ }

    // Unified financial engine — replaces duplicated SQL SUMs for sales/purchases/debts/drawer.
    $currencyModeMonth = (function_exists('pos_is_usd_currency_system') && pos_is_usd_currency_system($conn)) ? 'USD' : 'IQD';
    $monthCore = function_exists('pos_get_financial_metrics_core')
        ? pos_get_financial_metrics_core($conn, $startDt, $endDt, $currencyModeMonth, [
            'see_shop_wide' => $seeShopWide,
            'cashier' => $seeShopWide ? '' : $cashierEsc,
            'user_name' => $seeShopWide ? '' : $cashierEsc,
        ])
        : [];
    if ($monthCore) {
        $monthSales = (float)($monthCore['totalSales'] ?? $monthSales);
        $monthCount = (int)($monthCore['saleCount'] ?? $monthCount);
        $monthExp = (float)($monthCore['opExpenses'] ?? $monthExp);
        $monthCashSales = (float)($monthCore['cashSales'] ?? $monthCashSales);
        $monthDebtSales = (float)($monthCore['debtSales'] ?? $monthDebtSales);
        $monthFibSales = (float)($monthCore['fibSales'] ?? $monthFibSales);
        $monthCashReturns = (float)($monthCore['cashRefunds'] ?? $monthCashReturns);
        $monthReturnsTotal = (float)($monthCore['totalReturns'] ?? $monthReturnsTotal);
        $monthCashPurchases = (float)($monthCore['cashPurchases'] ?? $monthCashPurchases);
        $monthFibPurchases = (float)($monthCore['fibPurchases'] ?? $monthFibPurchases);
        $monthPurchases = (float)($monthCore['totalPurchases'] ?? $monthPurchases);
        $monthCustomerDebtIn = (float)($monthCore['debtPaymentsIn'] ?? $monthCustomerDebtIn);
        $monthCompanyDebtPay = (float)($monthCore['companyDebtPayments'] ?? $monthCompanyDebtPay);
        $monthPurchaseReturns = (float)($monthCore['totalPurchaseReturns'] ?? $monthPurchaseReturns);
        $monthPurchaseReturnsCash = (float)($monthCore['purchaseReturnsIn'] ?? $monthPurchaseReturnsCash);
        $monthWaste = (float)($monthCore['wasteLoss'] ?? $monthWaste);
        $monthWasteCount = (int)($monthCore['wasteCount'] ?? $monthWasteCount);
        $monthOpening = (float)($monthCore['opening'] ?? $monthOpening);
        $monthCashMovement = (float)($monthCore['cashMovement'] ?? $monthCashMovement);
        $monthCashDrawer = (float)($monthCore['cashDrawer'] ?? $monthCashDrawer);
        $sumDayProfit = (float)($monthCore['netProfit'] ?? $sumDayProfit);
        $sumCogsMonth = (float)($monthCore['totalCogs'] ?? $sumCogsMonth);
        $sumGiftsMonth = (float)($monthCore['totalGiftsValue'] ?? $sumGiftsMonth);
        $sumGiftsCountMonth = (float)($monthCore['giftsCount'] ?? $sumGiftsCountMonth);
    }

    echo json_encode([
        'status' => 'ok',
        'year' => $year,
        'month' => $monthNum,
        'start' => $start,
        'see_shop_wide' => $seeShopWide,
        'days' => $outDays,
        'installment_days' => $installmentDays,
        'expiry_days' => $expiryDays,
        'month_totals' => [
            'sales' => roundMoney($monthSales),
            'sale_count' => $monthCount,
            'expenses' => roundMoney($monthExp),
            'profit' => roundMoney($sumDayProfit),
            'cogs_sum' => roundMoney($sumCogsMonth),
            'gifts_sum' => roundMoney($sumGiftsMonth),
            'gifts_count' => $sumGiftsCountMonth,
            'wholesale_sum' => roundMoney($sumWholesaleMonth),
            'returns_total' => roundMoney($monthReturnsTotal),
            'returns_count' => $monthReturnsCount,
            'voided_sales_total' => roundMoney($monthVoidedSales),
            'voided_sales_count' => $monthVoidedSalesCount,
            'voided_purchases_total' => roundMoney($monthVoidedPurchases),
            'voided_purchases_count' => $monthVoidedPurchasesCount,
            'purchases_total' => roundMoney($monthPurchases),
            'purchase_count' => $monthPurchaseCount,
            'purchase_returns_total' => roundMoney($monthPurchaseReturns),
            'purchase_returns_cash' => roundMoney($monthPurchaseReturnsCash),
            'purchase_returns_count' => $monthPurchaseReturnCount,
            'purchases_cash' => roundMoney($monthCashPurchases),
            'debt_purchases' => roundMoney(max(0, $monthPurchases - $monthCashPurchases - $monthFibPurchases)),
            'purchases_fib' => roundMoney($monthFibPurchases),
            'cash_sales' => roundMoney($monthCashSales),
            'debt_sales' => roundMoney($monthDebtSales),
            'fib_sales' => roundMoney($monthFibSales),
            'cash_returns' => roundMoney($monthCashReturns),
            'customer_debt_in' => roundMoney($monthCustomerDebtIn),
            'customer_debt_count' => $monthCustomerDebtCount,
            'company_debt_payments' => roundMoney($monthCompanyDebtPay),
            'company_debt_count' => $monthCompanyDebtCount,
            'opening_balance' => roundMoney($monthOpening),
            'cash_movement' => roundMoney($monthCashMovement),
            'cash_drawer' => roundMoney($monthCashDrawer),
            // Locked USD from pos_get_financial_metrics_core (never live FX).
            'sales_usd' => round((float)($monthCore['totalSalesUsd'] ?? 0), 2),
            'cash_sales_usd' => round((float)($monthCore['cashSalesUsd'] ?? 0), 2),
            'debt_sales_usd' => round((float)($monthCore['debtSalesUsd'] ?? 0), 2),
            'fib_sales_usd' => round((float)($monthCore['fibSalesUsd'] ?? 0), 2),
            'expenses_usd' => round((float)($monthCore['opExpensesUsd'] ?? 0), 2),
            'profit_usd' => round((float)($monthCore['netProfitUsd'] ?? 0), 2),
            'purchases_total_usd' => round((float)($monthCore['totalPurchasesUsd'] ?? 0), 2),
            'purchases_cash_usd' => round((float)($monthCore['cashPurchasesUsd'] ?? 0), 2),
            'purchases_fib_usd' => round((float)($monthCore['fibPurchasesUsd'] ?? 0), 2),
            'debt_purchases_usd' => round((float)($monthCore['debtPurchasesUsd'] ?? 0), 2),
            'customer_debt_in_usd' => round((float)($monthCore['debtPaymentsInUsd'] ?? 0), 2),
            'company_debt_payments_usd' => round((float)($monthCore['companyDebtPaymentsUsd'] ?? 0), 2),
            'cash_movement_usd' => round((float)($monthCore['cashMovementUsd'] ?? 0), 2),
            'cash_drawer_usd' => round((float)($monthCore['cashDrawerUsd'] ?? ($monthCore['cashMovementUsd'] ?? 0)), 2),
            'returns_total_usd' => round((float)($monthCore['totalReturnsUsd'] ?? 0), 2),
            'cash_returns_usd' => round((float)($monthCore['cashRefundsUsd'] ?? 0), 2),
            'waste_total_usd' => round((float)($monthCore['wasteLossUsd'] ?? 0), 2),
            'purchase_returns_total_usd' => round((float)($monthCore['totalPurchaseReturnsUsd'] ?? 0), 2),
            'purchase_returns_cash_usd' => round((float)($monthCore['purchaseReturnsInUsd'] ?? 0), 2),
            'gifts_usd' => round((float)($monthCore['totalGiftsValueUsd'] ?? 0), 2),
            'metrics_engine' => 'pos_get_financial_metrics_core',
            'installment_count' => $monthInstallmentCount,
            'installment_total' => roundMoney($monthInstallmentTotal),
            'expiry_count' => $monthExpiryCount,
            'waste_total' => roundMoney($monthWaste),
            'waste_count' => $monthWasteCount,
            'delivery_total' => roundMoney($monthDelTotal),
            'delivery_count' => $monthDelCount,
            'delivery_pending' => roundMoney($monthDelPending),
            'delivery_pending_count' => $monthDelPendingCount,
            'delivery_delivered' => roundMoney($monthDelDelivered),
            'delivery_delivered_count' => $monthDelDeliveredCount,
            'delivery_refused' => roundMoney($monthDelRefused),
            'delivery_refused_count' => $monthDelRefusedCount,
            'delivery_cancelled' => roundMoney($monthDelCancelled),
            'delivery_cancelled_count' => $monthDelCancelledCount,
            'delivery_hold' => roundMoney($monthDelHold),
            'delivery_hold_count' => $monthDelHoldCount,
        ],
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_expiry_for_date') {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    if (empty($_SESSION['user_id'])) {
        echo json_encode(['status' => 'auth_required', 'message' => 'Login required'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $dateStr = function_exists('pos_parse_history_date_ymd')
        ? pos_parse_history_date_ymd($_GET['date'] ?? '', '')
        : trim((string)($_GET['date'] ?? ''));
    if ($dateStr === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateStr)) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid date'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $items = [];
    $count = 0;
    try {
        $stExp = $conn->prepare("SELECT b.product_id, COALESCE(p.name, CONCAT('#', b.product_id)) AS name, SUM(b.qty) AS qty
            FROM stock_batches b
            LEFT JOIN products p ON p.id = b.product_id
            WHERE b.qty > 0.000001 AND b.expiry_date = ?
            GROUP BY b.product_id, p.name
            ORDER BY p.name ASC");
        if ($stExp) {
            $stExp->bind_param('s', $dateStr);
            $stExp->execute();
            $resExpOne = $stExp->get_result();
            while ($resExpOne && ($er = $resExpOne->fetch_assoc())) {
                $qtyExp = (float)($er['qty'] ?? 0);
                if ($qtyExp <= 0) {
                    continue;
                }
                $count++;
                $items[] = [
                    'product_id' => (int)($er['product_id'] ?? 0),
                    'name' => (string)($er['name'] ?? ''),
                    'qty' => $qtyExp,
                ];
            }
        }
    } catch (Throwable $e) { /* ignore */ }
    echo json_encode([
        'status' => 'ok',
        'date' => $dateStr,
        'count' => $count,
        'items' => $items,
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

/** Cached DATE(...) filter column for ledger-style tables (avoids SHOW COLUMNS on every request). */
function pos_table_date_column_sql($conn, $table, $alias) {
    static $cache = [];
    $key = $table;
    if (!isset($cache[$key])) {
        $hasDate = false;
        $hasCreated = false;
        $rd = $conn->query("SHOW COLUMNS FROM `{$table}` LIKE 'date'");
        if ($rd && $rd->num_rows > 0) {
            $hasDate = true;
        }
        $rc = $conn->query("SHOW COLUMNS FROM `{$table}` LIKE 'created_at'");
        if ($rc && $rc->num_rows > 0) {
            $hasCreated = true;
        }
        $cache[$key] = ['date' => $hasDate, 'created' => $hasCreated];
    }
    $p = $alias !== '' ? ($alias . '.') : '';
    $flags = $cache[$key];
    if ($flags['date'] && $flags['created']) {
        return "COALESCE({$p}`date`, {$p}created_at)";
    }
    if ($flags['created']) {
        return "{$p}created_at";
    }
    return "{$p}`date`";
}

function pos_fetch_deliveries_for_range($conn, $rsEsc, $reEsc) {
    $rows = [];
    try {
        $q = "SELECT id, customer_name, phone, address, driver, driver_phone, delivery_cost, total, status, `date`, note, customer_id, driver_id, sale_id, settled_at
              FROM deliveries
              WHERE (`date` >= '{$rsEsc}' AND `date` < '{$reEsc}')
                 OR (settled_at IS NOT NULL AND settled_at >= '{$rsEsc}' AND settled_at < '{$reEsc}')
              ORDER BY id DESC
              LIMIT 400";
        $res = $conn->query($q);
        if ($res) {
            while ($r = $res->fetch_assoc()) {
                $r['id'] = (int)$r['id'];
                $r['total'] = roundMoney($r['total'] ?? 0);
                if (array_key_exists('delivery_cost', $r)) {
                    $r['delivery_cost'] = roundMoney($r['delivery_cost'] ?? 0);
                }
                $r['customer_id'] = (int)($r['customer_id'] ?? 0);
                $r['driver_id'] = (int)($r['driver_id'] ?? 0);
                $r['sale_id'] = (int)($r['sale_id'] ?? 0);
                $rows[] = $r;
            }
        }
    } catch (Throwable $e) { /* deliveries table may not exist */ }
    return $rows;
}

/**
 * Authoritative day card totals for daily summary (avoid client pools missing supplies/ledger).
 */
function pos_daily_detail_card_stats(array $salesRows, array $expensesRows, array $suppliesRows, array $ledgerRows = []) {
    $salesTotal = 0.0;
    $cashSales = 0.0;
    $debtSales = 0.0;
    $fibSales = 0.0;
    foreach ($salesRows as $s) {
        $total = roundMoney($s['total'] ?? 0);
        $salesTotal = roundMoney($salesTotal + $total);
        $pm = strtolower(trim((string)($s['payment_method'] ?? '')));
        $debtAmt = roundMoney($s['debt_amount'] ?? 0);
        $bankAmt = roundMoney($s['bank_amount'] ?? ($s['paid_bank'] ?? 0));
        $paidCash = isset($s['paid_cash']) ? roundMoney($s['paid_cash']) : null;
        $paidAmt = isset($s['paid_amount']) ? roundMoney($s['paid_amount']) : null;
        if ($pm === 'debt') {
            $debtSales = roundMoney($debtSales + $total);
            continue;
        }
        if ($pm === 'fib' || $pm === 'bank' || $pm === 'bankcard' || $pm === 'card') {
            $fibSales = roundMoney($fibSales + $total);
            continue;
        }
        $cashPart = 0.0;
        if ($paidCash !== null && $paidCash > 0) {
            $cashPart = $paidCash;
        } elseif ($paidCash !== null && $paidCash <= 0 && ($pm === 'split' || $debtAmt > 0 || $bankAmt > 0)) {
            $cashPart = 0.0;
        } elseif ($paidAmt !== null && $paidAmt > 0) {
            $cashPart = $paidAmt;
        } elseif ($paidAmt !== null && $paidAmt <= 0 && ($pm === 'split' || $debtAmt > 0 || $bankAmt > 0)) {
            $cashPart = 0.0;
        } else {
            $cashPart = max(0.0, roundMoney($total - $debtAmt - $bankAmt));
        }
        $cashSales = roundMoney($cashSales + $cashPart);
        if ($bankAmt > 0) {
            $fibSales = roundMoney($fibSales + $bankAmt);
        }
        if ($debtAmt > 0) {
            $debtSales = roundMoney($debtSales + $debtAmt);
        }
    }

    $purchasesTotal = 0.0;
    $purchasesFib = 0.0;
    $purchaseTxns = [];
    foreach ($suppliesRows as $row) {
        $purchasesTotal = roundMoney($purchasesTotal + roundMoney($row['totalCost'] ?? 0));
        $rowType = strtolower(trim((string)($row['type'] ?? '')));
        if ($rowType === 'fib' || $rowType === 'bank' || $rowType === 'bankcard') {
            $purchasesFib = roundMoney($purchasesFib + roundMoney($row['totalCost'] ?? 0));
        }
        $txn = trim((string)($row['transaction_id'] ?? ''));
        if ($txn !== '') {
            $purchaseTxns[$txn] = true;
        } else {
            $purchaseTxns['L' . (string)($row['id'] ?? uniqid('', true))] = true;
        }
    }

    $purchasesCash = 0.0;
    foreach ($expensesRows as $e) {
        if (($e['type'] ?? '') !== 'purchase') {
            continue;
        }
        $amt = function_exists('pos_expense_amount_iqd') ? pos_expense_amount_iqd($e) : roundMoney($e['amount'] ?? 0);
        if ($amt <= 0) {
            continue;
        }
        $purchasesCash = roundMoney($purchasesCash + $amt);
        $txn = trim((string)($e['transaction_id'] ?? ''));
        if ($txn !== '' && empty($purchaseTxns[$txn])) {
            $purchaseTxns[$txn] = true;
            $purchasesTotal = roundMoney($purchasesTotal + $amt);
        } elseif ($txn === '') {
            $purchaseTxns['E' . (string)($e['id'] ?? uniqid('', true))] = true;
            $purchasesTotal = roundMoney($purchasesTotal + $amt);
        }
    }

    foreach ($ledgerRows as $l) {
        $typ = strtolower(trim((string)($l['type'] ?? '')));
        if ($typ !== 'purchase' && $typ !== 'credit_purchase') {
            continue;
        }
        $txn = trim((string)($l['transaction_id'] ?? ''));
        if ($txn !== '' && !empty($purchaseTxns[$txn])) {
            continue;
        }
        $amt = roundMoney($l['amount'] ?? 0);
        if ($amt <= 0) {
            continue;
        }
        if ($txn !== '') {
            $purchaseTxns[$txn] = true;
        } else {
            $purchaseTxns['G' . (string)($l['id'] ?? uniqid('', true))] = true;
        }
        $purchasesTotal = roundMoney($purchasesTotal + $amt);
    }

    $purchasesDebt = roundMoney(max(0, $purchasesTotal - $purchasesCash - $purchasesFib));

    return [
        'sales_total' => roundMoney($salesTotal),
        'cash_sales' => roundMoney($cashSales),
        'debt_sales' => roundMoney($debtSales),
        'fib_sales' => roundMoney($fibSales),
        'sale_count' => count($salesRows),
        'purchases_total' => roundMoney($purchasesTotal),
        'purchases_cash' => roundMoney($purchasesCash),
        'purchases_debt' => roundMoney($purchasesDebt),
        'purchases_fib' => roundMoney($purchasesFib),
        'purchase_count' => count($purchaseTxns),
    ];
}

function pos_daily_items_as_arrays($items) {
    if ($items === null || $items === '') {
        return [];
    }
    if (is_string($items)) {
        $decoded = json_decode($items, true);
        $items = is_array($decoded) ? $decoded : [];
    }
    if (is_object($items)) {
        $items = json_decode(json_encode($items), true);
    }
    if (!is_array($items)) {
        return [];
    }
    $out = [];
    foreach ($items as $it) {
        if (is_object($it)) {
            $it = (array) $it;
        }
        if (is_array($it)) {
            $out[] = $it;
        }
    }
    return $out;
}

function pos_daily_rows_cogs(array $rows) {
    $cogs = 0.0;
    foreach ($rows as $row) {
        if (!is_array($row)) {
            continue;
        }
        foreach (pos_daily_items_as_arrays($row['items'] ?? []) as $it) {
            $cost = (float) ($it['cost'] ?? 0);
            $raw = $it['qty'] ?? ($it['count'] ?? 1);
            $q = is_numeric($raw) ? (float) $raw : 1.0;
            if ($q <= 0) {
                $q = 1.0;
            }
            $cogs += $cost * $q;
        }
    }
    return function_exists('roundMoney') ? roundMoney($cogs) : round($cogs);
}

function pos_daily_detail_json_flags() {
    $flags = JSON_UNESCAPED_UNICODE;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
        $flags |= JSON_INVALID_UTF8_SUBSTITUTE;
    }
    if (defined('JSON_PARTIAL_OUTPUT_ON_ERROR')) {
        $flags |= JSON_PARTIAL_OUTPUT_ON_ERROR;
    }
    return $flags;
}

function pos_daily_detail_empty_stats() {
    return [
        'sales_total' => 0,
        'cash_sales' => 0,
        'debt_sales' => 0,
        'fib_sales' => 0,
        'sale_count' => 0,
        'purchases_total' => 0,
        'purchases_cash' => 0,
        'purchases_debt' => 0,
        'purchases_fib' => 0,
        'purchase_count' => 0,
        'returns_total' => 0,
        'cash_refunds' => 0,
        'op_expenses' => 0,
        'net_profit' => 0,
        'cash_movement' => 0,
        'total_cogs' => 0,
    ];
}

function pos_daily_detail_fallback_payload($dateFrom, $dateTo, $isRange = false, $stats = null) {
    return [
        'status' => 'ok',
        'lite' => true,
        'date' => $dateFrom,
        'date_from' => $dateFrom,
        'date_to' => $dateTo,
        'is_range' => (bool)$isRange,
        'stats' => is_array($stats) ? $stats : pos_daily_detail_empty_stats(),
        'pools' => [
            'sales' => [],
            'expenses' => [],
        ],
        'metrics_fallback' => true,
    ];
}

function pos_daily_detail_flush_stray_output() {
    if (ob_get_level() <= 0) {
        return;
    }
    $buf = ob_get_contents();
    if (is_string($buf) && $buf !== '') {
        error_log('get_daily_detail stray output discarded (' . strlen($buf) . ' bytes)');
        ob_clean();
    }
}

/** Merge pos_get_financial_metrics_core into card stats; never throw out of get_daily_detail. */
function pos_daily_detail_apply_metrics_core($conn, $rsEsc, $reEsc, $seeShopWide, $metricsCashier, array $cardStats) {
    if (!function_exists('pos_get_financial_metrics_core') || !function_exists('pos_financial_metrics_to_daily_card_stats')) {
        return $cardStats;
    }
    try {
        $currencyModeDay = (function_exists('pos_is_usd_currency_system') && pos_is_usd_currency_system($conn)) ? 'USD' : 'IQD';
        $dayCore = pos_get_financial_metrics_core($conn, $rsEsc, $reEsc, $currencyModeDay, [
            'see_shop_wide' => $seeShopWide,
            'cashier' => $metricsCashier,
            'user_name' => $metricsCashier,
        ]);
        return pos_financial_metrics_to_daily_card_stats(is_array($dayCore) ? $dayCore : [], $cardStats);
    } catch (Throwable $e) {
        error_log('get_daily_detail metrics_core: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
        return $cardStats;
    }
}

/** Add COGS / profit / cash movement so the modal never treats sales−returns as profit. */
function pos_daily_detail_enrich_stats(array $cardStats, array $salesRows, array $expensesRows, array $returnsRows, array $clRows, array $wasteRows, array $purchaseReturnsRows = []) {
    $cogs = pos_daily_rows_cogs($salesRows);
    $retCogs = pos_daily_rows_cogs($returnsRows);
    $retTotal = 0.0;
    $cashRefunds = 0.0;
    foreach ($returnsRows as $r) {
        if (!is_array($r)) {
            continue;
        }
        $tot = (float) ($r['total'] ?? 0);
        $retTotal += $tot;
        $pm = strtolower((string) ($r['payment_method'] ?? ''));
        if ($pm !== 'debt' && $pm !== 'fib' && $pm !== 'bank' && $pm !== 'bankcard' && $pm !== 'card') {
            $cashRefunds += $tot;
        }
    }
    $opExp = 0.0;
    $companyDebt = 0.0;
    foreach ($expensesRows as $e) {
        if (!is_array($e)) {
            continue;
        }
        $ty = (string) ($e['type'] ?? '');
        $amt = function_exists('pos_expense_amount_iqd') ? pos_expense_amount_iqd($e) : (float) ($e['amount'] ?? 0);
        if ($ty === 'purchase' || $ty === 'purchase_return') {
            continue;
        }
        if ($ty === 'debt_payment') {
            $companyDebt += $amt;
            continue;
        }
        if ($ty !== '' && $ty !== 'operational') {
            continue;
        }
        $opExp += $amt;
    }
    $waste = 0.0;
    foreach ($wasteRows as $w) {
        if (is_array($w)) {
            $waste += (float) ($w['cost'] ?? 0);
        }
    }
    $debtIn = 0.0;
    foreach ($clRows as $cl) {
        if (!is_array($cl)) {
            continue;
        }
        $ty = strtolower((string) ($cl['type'] ?? ''));
        if ($ty === 'payment' || $ty === 'pay') {
            $debtIn += (float) ($cl['amount'] ?? 0);
        }
    }
    $prIn = 0.0;
    foreach ($purchaseReturnsRows as $pr) {
        if (!is_array($pr)) {
            continue;
        }
        if (isset($pr['cash_refunded']) && $pr['cash_refunded'] !== '' && $pr['cash_refunded'] !== null) {
            $prIn += (float) $pr['cash_refunded'];
        } else {
            $prIn += (float) ($pr['total'] ?? 0);
        }
    }
    $salesTotal = (float) ($cardStats['sales_total'] ?? 0);
    $cashSales = (float) ($cardStats['cash_sales'] ?? 0);
    $cashPurch = (float) ($cardStats['purchases_cash'] ?? 0);
    $netProfit = ($salesTotal - $retTotal) - ($cogs - $retCogs) - $opExp - $waste;
    $cashMovement = ($cashSales + $debtIn + $prIn) - ($opExp + $cashPurch + $companyDebt + $cashRefunds);
    $cardStats['total_cogs'] = function_exists('roundMoney') ? roundMoney($cogs) : $cogs;
    $cardStats['returns_cogs'] = function_exists('roundMoney') ? roundMoney($retCogs) : $retCogs;
    $cardStats['returns_total'] = function_exists('roundMoney') ? roundMoney($retTotal) : $retTotal;
    $cardStats['cash_refunds'] = function_exists('roundMoney') ? roundMoney($cashRefunds) : $cashRefunds;
    $cardStats['op_expenses'] = function_exists('roundMoney') ? roundMoney($opExp) : $opExp;
    $cardStats['waste_loss'] = function_exists('roundMoney') ? roundMoney($waste) : $waste;
    $cardStats['debt_payments_in'] = function_exists('roundMoney') ? roundMoney($debtIn) : $debtIn;
    $cardStats['net_profit'] = function_exists('roundMoney') ? roundMoney($netProfit) : $netProfit;
    $cardStats['cash_movement'] = function_exists('roundMoney') ? roundMoney($cashMovement) : $cashMovement;
    return $cardStats;
}

/**
 * Invoice-level purchase rows for daily summary list (company / invoice / total / type).
 */
function pos_daily_detail_purchase_invoices(array $suppliesRows, array $expensesRows, array $ledgerRows = [], array $companies = []) {
    $map = [];
    $companyById = [];
    foreach ($companies as $c) {
        if (!is_array($c) || !isset($c['id'])) {
            continue;
        }
        $companyById[(string)$c['id']] = (string)($c['name'] ?? '');
    }

    foreach ($suppliesRows as $row) {
        if (!is_array($row)) {
            continue;
        }
        $txn = trim((string)($row['transaction_id'] ?? ''));
        $inv = trim((string)($row['supplier_invoice_number'] ?? ''));
        if ($inv === '' && $txn !== '') {
            $inv = '#' . substr($txn, -8);
        }
        if ($inv === '') {
            $inv = '—';
        }
        $key = $txn !== '' ? ('txn:' . $txn) : ('fb:' . trim((string)($row['company'] ?? '')) . '|' . $inv);
        if (!isset($map[$key])) {
            $map[$key] = [
                'company' => (string)($row['company'] ?? ''),
                'invoice' => $inv,
                'total' => 0.0,
                'txnId' => $txn,
                'type' => (string)($row['type'] ?? 'cash'),
                'date' => (string)($row['date'] ?? ''),
                'fx_usd_rate' => isset($row['fx_usd_rate']) ? $row['fx_usd_rate'] : null,
                'fx_currency_mode' => isset($row['fx_currency_mode']) ? $row['fx_currency_mode'] : null,
                'items' => [],
            ];
        }
        $lineCost = roundMoney($row['totalCost'] ?? 0);
        $map[$key]['total'] = roundMoney($map[$key]['total'] + $lineCost);
        if (!empty($row['type'])) {
            $map[$key]['type'] = (string)$row['type'];
        }
        if ($txn !== '' && $map[$key]['txnId'] === '') {
            $map[$key]['txnId'] = $txn;
        }
        if (empty($map[$key]['fx_usd_rate']) && !empty($row['fx_usd_rate'])) {
            $map[$key]['fx_usd_rate'] = $row['fx_usd_rate'];
            $map[$key]['fx_currency_mode'] = $row['fx_currency_mode'] ?? null;
        }
        $map[$key]['items'][] = [
            'name' => (string)($row['itemName'] ?? $row['name'] ?? 'ئایتم'),
            'qty' => (float)($row['qtyAdded'] ?? 0),
            'totalCost' => $lineCost,
            'fx_usd_rate' => isset($row['fx_usd_rate']) ? $row['fx_usd_rate'] : null,
            'fx_currency_mode' => isset($row['fx_currency_mode']) ? $row['fx_currency_mode'] : null,
        ];
    }

    $seenTxn = [];
    foreach ($map as $row) {
        $t = trim((string)($row['txnId'] ?? ''));
        if ($t !== '') {
            $seenTxn[$t] = true;
        }
    }

    foreach ($expensesRows as $e) {
        if (!is_array($e) || ($e['type'] ?? '') !== 'purchase') {
            continue;
        }
        $txn = trim((string)($e['transaction_id'] ?? ''));
        if ($txn !== '' && !empty($seenTxn[$txn])) {
            continue;
        }
        $amt = roundMoney($e['amount'] ?? 0);
        if ($amt <= 0) {
            continue;
        }
        if ($txn !== '') {
            $seenTxn[$txn] = true;
        }
        $note = trim((string)($e['note'] ?? ''));
        $map['exp:' . ($txn !== '' ? $txn : ('e' . (string)($e['id'] ?? uniqid('', true))))] = [
            'company' => 'کڕینا نەقد',
            'invoice' => $note !== '' ? substr($note, 0, 56) : ($txn !== '' ? ('#' . substr($txn, -8)) : '—'),
            'total' => $amt,
            'txnId' => $txn,
            'type' => 'cash',
            'date' => (string)($e['date'] ?? ''),
            'items' => [],
            'expenseOnly' => true,
        ];
    }

    foreach ($ledgerRows as $l) {
        if (!is_array($l)) {
            continue;
        }
        $typ = strtolower(trim((string)($l['type'] ?? '')));
        if ($typ !== 'purchase' && $typ !== 'credit_purchase') {
            continue;
        }
        $txn = trim((string)($l['transaction_id'] ?? ''));
        if ($txn !== '' && !empty($seenTxn[$txn])) {
            continue;
        }
        $amt = roundMoney($l['amount'] ?? 0);
        if ($amt <= 0) {
            continue;
        }
        if ($txn !== '') {
            $seenTxn[$txn] = true;
        }
        $cid = isset($l['companyId']) ? (string)$l['companyId'] : '';
        $companyName = ($cid !== '' && isset($companyById[$cid])) ? $companyById[$cid] : '';
        $note = trim((string)($l['note'] ?? ''));
        $map['led:' . ($txn !== '' ? $txn : ('l' . (string)($l['id'] ?? uniqid('', true))))] = [
            'company' => $companyName !== '' ? $companyName : 'نەزانراو',
            'invoice' => $note !== '' ? substr($note, 0, 56) : ($txn !== '' ? ('#' . substr($txn, -8)) : '—'),
            'total' => $amt,
            'txnId' => $txn,
            'type' => ($typ === 'credit_purchase') ? 'credit' : 'cash',
            'date' => (string)($l['date'] ?? ($l['created_at'] ?? '')),
            'items' => [],
            'ledgerOnly' => true,
        ];
    }

    $out = [];
    foreach ($map as $row) {
        $row['total'] = roundMoney($row['total'] ?? 0);
        if ($row['total'] <= 0) {
            continue;
        }
        $out[] = $row;
    }
    return $out;
}

/**
 * Daily detail for calendar / modal (SPA local caches only ~200 rows).
 * GET ?action=get_daily_detail&date=YYYY-MM-DD
 * Optional range: &date_from=YYYY-MM-DD&date_to=YYYY-MM-DD (max 31 days).
 * Calendar DATE bucketing matches get_calendar_month_stats: DATE(created_at), DATE(expenses.date), etc.
 */
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_daily_detail') {

    error_reporting(0);
    ini_set('display_errors', 0);
    if (ob_get_level() === 0) {
        ob_start();
    }
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: private, max-age=15');

    // Do NOT run gift-COGS repair here — it can scan supplies/sales and stall the modal.
    // Calendar / admin maintenance already run pos_maybe_repair_gift_sale_cogs.

    if (empty($_SESSION['user_id'])) {
        echo json_encode(['status' => 'auth_required', 'message' => 'Login required'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }

    $dateFromRaw = isset($_GET['date_from']) ? trim((string)$_GET['date_from']) : '';
    $dateToRaw = isset($_GET['date_to']) ? trim((string)$_GET['date_to']) : '';
    $dateRaw = isset($_GET['date']) ? trim((string)$_GET['date']) : '';

    if ($dateFromRaw === '' && $dateToRaw === '' && $dateRaw !== '') {
        $dateFromRaw = $dateRaw;
        $dateToRaw = $dateRaw;
    }
    if ($dateFromRaw === '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateRaw)) {
        $dateFromRaw = $dateRaw;
    }
    if ($dateToRaw === '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateRaw)) {
        $dateToRaw = $dateRaw;
    }
    if ($dateFromRaw === '' && $dateToRaw !== '') {
        $dateFromRaw = $dateToRaw;
    }
    if ($dateToRaw === '' && $dateFromRaw !== '') {
        $dateToRaw = $dateFromRaw;
    }

    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateFromRaw) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateToRaw)) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid date'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    if ($dateFromRaw > $dateToRaw) {
        $tmp = $dateFromRaw;
        $dateFromRaw = $dateToRaw;
        $dateToRaw = $tmp;
    }

    try {
        $fromDt = new DateTimeImmutable($dateFromRaw . ' 00:00:00');
        $toDt = new DateTimeImmutable($dateToRaw . ' 00:00:00');
        $daySpan = (int)$fromDt->diff($toDt)->days;
    } catch (Throwable $e) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid date'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    if ($daySpan > 30) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Date range too long (max 31 days)',
            'max_days' => 31,
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    try {

    $dateFromEsc = $conn->real_escape_string($dateFromRaw);
    $dateToEsc = $conn->real_escape_string($dateToRaw);
    $isRange = ($dateFromRaw !== $dateToRaw);
    $lite = !empty($_GET['lite']) || !empty($_GET['fast']);

    // Proactive fix: Respect businessDayStartHour from settings for date bucketing.
    // Without this, sales made in early morning (e.g. 1 AM) are invisible in both 
    // "Today" and "Yesterday" summaries if business day starts at e.g. 4 AM.
    $startHour = 0;
    if (function_exists('pos_load_app_settings_array')) {
        $settings = pos_load_app_settings_array($conn);
        $startHour = isset($settings['businessDayStartHour']) ? (int)$settings['businessDayStartHour'] : 0;
    }
    if ($startHour < 0) $startHour = 0;
    if ($startHour > 23) $startHour = 23;
    $shStr = sprintf('%02d:00:00', $startHour);

    // Index-friendly bounds (avoid DATE(col) which forces full table scans)
    try {
        $rangeStart = $dateFromRaw . ' ' . $shStr;
        $rangeEndExclusive = (new DateTimeImmutable($dateToRaw))->modify('+1 day')->format('Y-m-d') . ' ' . $shStr;
        $shiftEndExclusive = (new DateTimeImmutable($dateFromRaw))->modify('+1 day')->format('Y-m-d') . ' ' . $shStr;
    } catch (Throwable $e) {
        $rangeStart = $dateFromRaw . ' ' . $shStr;
        $rangeEndExclusive = $dateToRaw . ' 23:59:59';
        $shiftEndExclusive = $dateFromRaw . ' 23:59:59';
    }
    $rsEsc = $conn->real_escape_string($rangeStart);
    $reEsc = $conn->real_escape_string($rangeEndExclusive);
    $shiftStartEsc = $conn->real_escape_string($dateFromRaw . ' 00:00:00');
    $shiftEndEsc = $conn->real_escape_string($shiftEndExclusive);

    $role = isset($_SESSION['user_role']) ? (string)$_SESSION['user_role'] : '';
    $uname = isset($_SESSION['user_name']) ? (string)$_SESSION['user_name'] : '';
    $seeShopWide = ($role === 'admin' || $role === 'manager');
    $cashierEsc = $conn->real_escape_string($uname);
    $userEsc = $cashierEsc;

    $reqUser = isset($_GET['user']) ? trim($_GET['user']) : 'all';
    if ($reqUser !== 'all' && $reqUser !== '' && $seeShopWide) {
        $seeShopWide = false;
        $cashierEsc = $conn->real_escape_string($reqUser);
        $userEsc = $cashierEsc;
    }
    // Same cashier as pool SQL — never session $uname when the calendar asked for Manager / all.
    $metricsCashier = '';
    if (!$seeShopWide) {
        if ($reqUser !== '' && strcasecmp($reqUser, 'all') !== 0) {
            $metricsCashier = $reqUser;
        } else {
            $metricsCashier = $uname;
        }
    }

    /**
     * FAST PATH (lite=1): cards-only payload — no items_json decode, no audit N+1, no JOIN customer names.
     * Used by daily modal so UI never waits on a heavy day dump.
     */
    if ($lite) {
        $saleScope = '(s.is_returned IS NULL OR s.is_returned = 0)';
        if (!$seeShopWide) {
            $saleScope .= " AND s.cashier = '$cashierEsc' ";
        }
        $salesRows = [];
        if (function_exists('pos_ensure_sales_warehouse_column')) {
            pos_ensure_sales_warehouse_column($conn);
        }
        // Include total_usd + fx_currency_mode so Daily USD cards match Monthly locked stamps (never live re-ratio).
        $qSf = "SELECT s.id, s.total, s.total_usd, s.discount, s.created_at, s.cashier, s.payment_method,
                       s.is_returned, s.customer_id, s.customer_type, s.paid_amount, s.paid_cash, s.debt_amount,
                       s.bank_amount, s.paid_bank, s.items_json, s.fx_usd_rate, s.fx_currency_mode, s.exchange_rate, s.warehouse_id
                FROM sales s
                WHERE s.created_at >= '{$rsEsc}' AND s.created_at < '{$reEsc}'
                AND {$saleScope}
                ORDER BY s.id DESC
                LIMIT 400";
        $resSf = $conn->query($qSf);
        if (!$resSf) {
            $qSf = "SELECT s.id, s.total, s.discount, s.created_at, s.cashier, s.payment_method,
                           s.is_returned, s.customer_id, s.customer_type, s.paid_amount, s.paid_cash, s.debt_amount,
                           s.bank_amount, s.items_json, s.fx_usd_rate, s.warehouse_id
                    FROM sales s
                    WHERE s.created_at >= '{$rsEsc}' AND s.created_at < '{$reEsc}'
                    AND {$saleScope}
                    ORDER BY s.id DESC
                    LIMIT 400";
            $resSf = $conn->query($qSf);
        }
        if ($resSf) {
            while ($r = $resSf->fetch_assoc()) {
                $r['id'] = (int)$r['id'];
                $r['total'] = roundMoney($r['total'] ?? 0);
                $r['discount'] = roundMoney($r['discount'] ?? 0);
                $decoded = json_decode($r['items_json'] ?? '[]');
                $r['items'] = $decoded !== null ? $decoded : [];
                unset($r['items_json']);
                $r['is_returned'] = (int)($r['is_returned'] ?? 0);
                $r['date'] = $r['created_at'] ?? '';
                $r['warehouse_id'] = (int)($r['warehouse_id'] ?? 0);
                $salesRows[] = $r;
            }
        }
        if ($salesRows && function_exists('pos_attach_sales_warehouse')) {
            pos_attach_sales_warehouse($conn, $salesRows);
        }
        $lastReceiptShop = null;
        if ($seeShopWide && !empty($salesRows)) {
            $lastReceiptShop = (int)$salesRows[0]['id'];
        } elseif ($seeShopWide) {
            $rq = $conn->query("SELECT MAX(s.id) AS mx FROM sales s WHERE s.created_at >= '{$rsEsc}' AND s.created_at < '{$reEsc}' AND (s.is_returned IS NULL OR s.is_returned = 0)");
            if ($rq && ($lr = $rq->fetch_assoc()) && isset($lr['mx']) && $lr['mx'] !== null) {
                $lastReceiptShop = (int)$lr['mx'];
            }
        }

        $expWhere = "`date` >= '{$rsEsc}' AND `date` < '{$reEsc}' ";
        if (!$seeShopWide) {
            $expWhere .= " AND `user` = '$userEsc' ";
        }
        $expensesRows = [];
        $rex = $conn->query("SELECT id, amount, currency, exchange_rate, `date`, `user`, note, type, company_id, transaction_id FROM expenses WHERE $expWhere ORDER BY id DESC LIMIT 300");
        if ($rex) {
            while ($r = $rex->fetch_assoc()) {
                $r['id'] = (int)$r['id'];
                $r['amount'] = roundMoney($r['amount'] ?? 0);
                if (!empty($r['company_id'])) {
                    $r['company_id'] = (int)$r['company_id'];
                }
                $expensesRows[] = $r;
            }
        }

        $retScope = !$seeShopWide ? " AND cashier = '$cashierEsc' " : '';
        $returnsRows = [];
        $rret = $conn->query("SELECT id, total, `date`, cashier, payment_method, items_json, fx_usd_rate, fx_currency_mode, sale_id FROM `returns` WHERE `date` >= '{$rsEsc}' AND `date` < '{$reEsc}' $retScope ORDER BY id DESC LIMIT 200");
        if (!$rret) {
            $rret = $conn->query("SELECT id, total, `date`, cashier, payment_method, items_json FROM `returns` WHERE `date` >= '{$rsEsc}' AND `date` < '{$reEsc}' $retScope ORDER BY id DESC LIMIT 200");
        }
        if ($rret) {
            while ($r = $rret->fetch_assoc()) {
                $r['id'] = (int)$r['id'];
                $r['total'] = roundMoney($r['total'] ?? 0);
                if (isset($r['fx_usd_rate'])) {
                    $r['fx_usd_rate'] = ($r['fx_usd_rate'] === null || $r['fx_usd_rate'] === '') ? null : (int)$r['fx_usd_rate'];
                }
                $dec = json_decode($r['items_json'] ?? '[]');
                $r['items'] = $dec !== null ? $dec : [];
                unset($r['items_json']);
                $returnsRows[] = $r;
            }
        }

        $voidScope = "s.is_returned = 1";
        if (!$seeShopWide) {
            $voidScope .= " AND s.cashier = '$cashierEsc' ";
        }
        $voidedSalesRows = [];
        $resVoid = $conn->query("SELECT s.id, s.total, s.created_at, s.cashier, s.payment_method FROM sales s WHERE s.created_at >= '{$rsEsc}' AND s.created_at < '{$reEsc}' AND {$voidScope} ORDER BY s.id DESC LIMIT 100");
        if ($resVoid) {
            while ($r = $resVoid->fetch_assoc()) {
                $r['id'] = (int)$r['id'];
                $r['total'] = roundMoney($r['total'] ?? 0);
                $r['items'] = [];
                $r['date'] = $r['created_at'] ?? '';
                $r['type'] = 'void';
                $r['sale_id'] = $r['id'];
                $r['note'] = 'ژێبرنا وەسڵێ (Void)';
                $voidedSalesRows[] = $r;
            }
        }

        $shiftsRows = [];
        $rsh = $conn->query("SELECT sh.id, sh.userId, sh.userName, sh.startTime, sh.endTime, sh.opening_balance, sh.hourlyRate FROM shifts sh WHERE sh.startTime >= '{$shiftStartEsc}' AND sh.startTime < '{$shiftEndEsc}' ORDER BY sh.startTime ASC LIMIT 50");
        if ($rsh) {
            while ($r = $rsh->fetch_assoc()) {
                $r['id'] = (int)$r['id'];
                $r['userId'] = (int)$r['userId'];
                $shiftsRows[] = $r;
            }
        }

        $suppliesRows = [];
        $rsup = $conn->query("SELECT id, company, prodId, itemName, qtyAdded, totalCost, `date`, type, transaction_id, supplier_invoice_number, fx_usd_rate, fx_currency_mode FROM supplies WHERE `date` >= '{$rsEsc}' AND `date` < '{$reEsc}' AND COALESCE(type, '') NOT IN ('return', 'opening') AND company IS NOT NULL AND TRIM(company) != '' AND LOWER(TRIM(company)) NOT LIKE 'direct store' ORDER BY id DESC LIMIT 300");
        if (!$rsup) {
            $rsup = $conn->query("SELECT id, company, prodId, itemName, qtyAdded, totalCost, `date`, type, transaction_id, supplier_invoice_number FROM supplies WHERE `date` >= '{$rsEsc}' AND `date` < '{$reEsc}' AND COALESCE(type, '') NOT IN ('return', 'opening') AND company IS NOT NULL AND TRIM(company) != '' AND LOWER(TRIM(company)) NOT LIKE 'direct store' ORDER BY id DESC LIMIT 300");
        }
        if ($rsup) {
            while ($r = $rsup->fetch_assoc()) {
                $r['id'] = (int)$r['id'];
                $r['prodId'] = (int)$r['prodId'];
                $r['qtyAdded'] = (float)($r['qtyAdded'] ?? 0);
                $r['totalCost'] = roundMoney($r['totalCost'] ?? 0);
                $suppliesRows[] = $r;
            }
        }

        // Some shop DBs have no ledger.created_at / customer_ledger.created_at — never hardcode it.
        $ledgerTsLite = pos_table_date_column_sql($conn, 'ledger', '');
        $clTsLite = pos_table_date_column_sql($conn, 'customer_ledger', '');

        $ledgerRows = [];
        $rled = $conn->query("SELECT id, type, amount, `date`, companyId, note, transaction_id FROM ledger WHERE ({$ledgerTsLite}) >= '{$rsEsc}' AND ({$ledgerTsLite}) < '{$reEsc}' ORDER BY id DESC LIMIT 300");
        if ($rled) {
            while ($r = $rled->fetch_assoc()) {
                $r['id'] = (int)$r['id'];
                $r['amount'] = roundMoney($r['amount'] ?? 0);
                $ledgerRows[] = $r;
            }
        }

        $clRows = [];
        // Payments only — avoid LIMIT starving debt_payment_in when many sale ledger rows exist the same day.
        $rcq = $conn->query("SELECT id, type, amount, currency, exchange_rate, `date`, target_id, target_type, note, receipt_id, transaction_id FROM customer_ledger WHERE ({$clTsLite}) >= '{$rsEsc}' AND ({$clTsLite}) < '{$reEsc}' AND type IN ('payment','pay') ORDER BY id DESC LIMIT 500");
        if (!$rcq) {
            $rcq = $conn->query("SELECT id, type, amount, `date`, target_id, target_type, note, receipt_id, transaction_id FROM customer_ledger WHERE ({$clTsLite}) >= '{$rsEsc}' AND ({$clTsLite}) < '{$reEsc}' AND type IN ('payment','pay') ORDER BY id DESC LIMIT 500");
        }
        if ($rcq) {
            while ($r = $rcq->fetch_assoc()) {
                $r['id'] = (int)$r['id'];
                $r['amount'] = roundMoney($r['amount'] ?? 0);
                $clRows[] = $r;
            }
        }

        $wasteRows = [];
        try {
            $rwaste = $conn->query("SELECT id, prodId, prodName, qty, cost, reason, `date`, `user` FROM waste WHERE `date` >= '{$rsEsc}' AND `date` < '{$reEsc}' ORDER BY id DESC LIMIT 100");
            if ($rwaste) {
                while ($r = $rwaste->fetch_assoc()) {
                    $r['id'] = (int)$r['id'];
                    $r['cost'] = roundMoney($r['cost'] ?? 0);
                    $wasteRows[] = $r;
                }
            }
        } catch (Throwable $e) {}

        $prScope = (!$seeShopWide && $uname !== '') ? " AND `user` = '$userEsc' " : '';
        $purchaseReturnsRows = [];
        $rpr = $conn->query("SELECT id, company_id, company_name, total, `date`, `user`, note, transaction_id, supplier_invoice_number, cash_refunded, debt_adjusted FROM purchase_returns WHERE `date` >= '{$rsEsc}' AND `date` < '{$reEsc}' $prScope ORDER BY id DESC LIMIT 100");
        if ($rpr) {
            while ($r = $rpr->fetch_assoc()) {
                $r['id'] = (int)$r['id'];
                $r['total'] = roundMoney($r['total'] ?? 0);
                $r['items'] = [];
                $purchaseReturnsRows[] = $r;
            }
        }

        $cardStats = pos_daily_detail_card_stats($salesRows, $expensesRows, $suppliesRows, $ledgerRows);
        $cardStats = pos_daily_detail_enrich_stats($cardStats, $salesRows, $expensesRows, $returnsRows, $clRows, $wasteRows, $purchaseReturnsRows);
        // Lite modal needs a fast JSON payload. Pool card stats are enough; core engine can stall the request.
        $purchaseInvoices = pos_daily_detail_purchase_invoices($suppliesRows, $expensesRows, $ledgerRows);

        $litePayload = [
            'status' => 'ok',
            'lite' => true,
            'date' => $dateFromRaw,
            'date_from' => $dateFromRaw,
            'date_to' => $dateToRaw,
            'is_range' => $isRange,
            'calendar_day_basis' => true,
            'see_shop_wide' => $seeShopWide,
            'last_receipt_id_shop' => $lastReceiptShop,
            'stats' => $cardStats,
            'purchase_invoices' => $purchaseInvoices,
            'pools' => [
                'sales' => $salesRows,
                'expenses' => $expensesRows,
                'returns' => $returnsRows,
                'voided_sales' => $voidedSalesRows,
                'voided_purchases' => [],
                'supplies' => $suppliesRows,
                'purchase_returns' => $purchaseReturnsRows,
                'ledger' => $ledgerRows,
                'customer_ledger' => $clRows,
                'shifts' => $shiftsRows,
                'waste' => $wasteRows,
                'deliveries' => function_exists('pos_fetch_deliveries_for_range') ? pos_fetch_deliveries_for_range($conn, $rsEsc, $reEsc) : [],
            ],
        ];
        $liteJson = json_encode($litePayload, pos_daily_detail_json_flags());
        pos_daily_detail_flush_stray_output();
        if ($liteJson === false) {
            echo json_encode(['status' => 'error', 'message' => 'encode_failed'], JSON_UNESCAPED_UNICODE);
        } else {
            echo $liteJson;
        }
        exit();
    }

    $ledgerTs = pos_table_date_column_sql($conn, 'ledger', 'l');
    $clTs = pos_table_date_column_sql($conn, 'customer_ledger', 'cl');

    $saleScope = '(s.is_returned IS NULL OR s.is_returned = 0)';
    if (!$seeShopWide) {
        $saleScope .= " AND s.cashier = '$cashierEsc' ";
    }

    $salesRows = [];
    if (function_exists('pos_ensure_sales_warehouse_column')) {
        pos_ensure_sales_warehouse_column($conn);
    }
    $qSf = "
        SELECT s.id, s.total, s.total_usd, s.discount, s.created_at, s.cashier, s.payment_method,
               s.is_returned, s.customer_id, s.customer_type, s.paid_amount, s.paid_cash, s.debt_amount,
               s.bank_amount, s.paid_bank, s.items_json, s.fx_usd_rate, s.fx_currency_mode, s.exchange_rate, s.warehouse_id
        FROM sales s
        WHERE s.created_at >= '{$rsEsc}' AND s.created_at < '{$reEsc}'
        AND {$saleScope}
        ORDER BY s.id ASC
        ";
    $resSf = $conn->query($qSf);
    if (!$resSf) {
        $qSf = "
            SELECT s.id, s.total, s.discount, s.created_at, s.cashier, s.payment_method,
                   s.is_returned, s.customer_id, s.customer_type, s.paid_amount, s.paid_cash, s.debt_amount,
                   s.bank_amount, s.items_json, s.fx_usd_rate, s.warehouse_id
            FROM sales s
            WHERE s.created_at >= '{$rsEsc}' AND s.created_at < '{$reEsc}'
            AND {$saleScope}
            ORDER BY s.id ASC
            ";
        $resSf = $conn->query($qSf);
    }
    if ($resSf) {
        while ($r = $resSf->fetch_assoc()) {
            $r['id'] = (int)$r['id'];
            $r['total'] = roundMoney($r['total'] ?? 0);
            $r['discount'] = roundMoney($r['discount'] ?? 0);
            $decoded = json_decode($r['items_json'] ?? '[]');
            $r['items'] = $decoded !== null ? $decoded : [];
            unset($r['items_json']);
            $r['is_returned'] = (int)($r['is_returned'] ?? 0);
            if (isset($r['created_at']) && !isset($r['date'])) {
                $r['date'] = $r['created_at'];
            }
            $r['warehouse_id'] = (int)($r['warehouse_id'] ?? 0);
            $salesRows[] = $r;
        }
    }
    if ($salesRows && function_exists('pos_attach_sales_warehouse')) {
        pos_attach_sales_warehouse($conn, $salesRows);
    }

    /** Shop-wide receipt id for admin/manager (numeric id ordering) — last in range */
    $lastReceiptShop = null;
    if ($seeShopWide) {
        $qLast = "
            SELECT MAX(s.id) AS mx FROM sales s
            WHERE s.created_at >= '{$rsEsc}' AND s.created_at < '{$reEsc}'
            AND (s.is_returned IS NULL OR s.is_returned = 0)
            ";
        $rq = $conn->query($qLast);
        if ($rq && ($lr = $rq->fetch_assoc()) && isset($lr['mx']) && $lr['mx'] !== null) {
            $lastReceiptShop = (int)$lr['mx'];
        }
    }

    $expWhere = "`date` >= '{$rsEsc}' AND `date` < '{$reEsc}' ";
    if (!$seeShopWide) {
        $expWhere .= " AND `user` = '$userEsc' ";
    }
    $expensesRows = [];
    $rex = $conn->query("SELECT id, amount, currency, exchange_rate, `date`, `user`, note, type, company_id, transaction_id FROM expenses WHERE $expWhere ORDER BY id ASC");
    if ($rex) {
        while ($r = $rex->fetch_assoc()) {
            $r['id'] = (int)$r['id'];
            $r['amount'] = roundMoney($r['amount'] ?? 0);
            if (!empty($r['company_id'])) {
                $r['company_id'] = (int)$r['company_id'];
            }
            $expensesRows[] = $r;
        }
    }

    $retScope = '';
    if (!$seeShopWide) {
        $retScope = " AND cashier = '$cashierEsc' ";
    }
    $returnsRows = [];
    $rret = $conn->query("SELECT id, total, `date`, cashier, payment_method, items_json FROM `returns` WHERE `date` >= '{$rsEsc}' AND `date` < '{$reEsc}' $retScope ORDER BY id ASC");
    if ($rret) {
        while ($r = $rret->fetch_assoc()) {
            $r['id'] = (int)$r['id'];
            $r['total'] = roundMoney($r['total'] ?? 0);
            $dec = json_decode($r['items_json'] ?? '[]');
            $r['items'] = $dec !== null ? $dec : [];
            unset($r['items_json']);
            $returnsRows[] = $r;
        }
    }

    /** Voided sales (invoice delete) — display separately from real returns; excluded from sales pool above */
    $voidedSalesRows = [];
    $voidScope = "s.is_returned = 1";
    if (!$seeShopWide) {
        $voidScope .= " AND s.cashier = '$cashierEsc' ";
    }
    $qVoid = "
        SELECT s.id, s.total, s.created_at, s.cashier, s.payment_method, s.items_json
        FROM sales s
        WHERE s.created_at >= '{$rsEsc}' AND s.created_at < '{$reEsc}'
        AND {$voidScope}
        ORDER BY s.id ASC
        ";
    $resVoid = $conn->query($qVoid);
    if ($resVoid) {
        while ($r = $resVoid->fetch_assoc()) {
            $r['id'] = (int)$r['id'];
            $r['total'] = roundMoney($r['total'] ?? 0);
            $decoded = json_decode($r['items_json'] ?? '[]');
            $r['items'] = $decoded !== null ? $decoded : [];
            unset($r['items_json']);
            if (isset($r['created_at']) && !isset($r['date'])) {
                $r['date'] = $r['created_at'];
            }
            $r['type'] = 'void';
            $r['sale_id'] = $r['id'];
            $r['note'] = 'ژێبرنا وەسڵێ (Void)';
            $voidedSalesRows[] = $r;
        }
    }

    /** Voided purchase invoices (intentional trash) — from audit_logs; not purchase returns */
    $voidedPurchasesRows = [];
    $voidPurUserScope = '';
    if (!$seeShopWide && $uname !== '') {
        $voidPurUserScope = " AND `user` = '$userEsc' ";
    }
    $qVoidPur = "
        SELECT id, user, details, created_at, old_value, new_value
        FROM audit_logs
        WHERE action_type = 'void_purchase_invoice'
          AND created_at >= '{$rsEsc}' AND created_at < '{$reEsc}'
          {$voidPurUserScope}
        ORDER BY id ASC
        ";
    $resVoidPur = $conn->query($qVoidPur);
    if ($resVoidPur) {
        while ($r = $resVoidPur->fetch_assoc()) {
            $snap = null;
            if (!empty($r['old_value'])) {
                $decoded = json_decode((string)$r['old_value'], true);
                if (is_array($decoded)) {
                    $snap = $decoded;
                }
            }
            // Fast path: skip DB lookup when new_value already marks restored
            if (!empty($r['new_value'])) {
                $nvFast = json_decode((string)$r['new_value'], true);
                if (is_array($nvFast) && !empty($nvFast['restored'])) {
                    continue;
                }
            }
            if (function_exists('pos_void_purchase_audit_is_active') && !pos_void_purchase_audit_is_active($conn, $r, $snap)) {
                continue;
            }
            $kind = '';
            if (is_array($snap) && !empty($snap['kind'])) {
                $kind = strtolower(trim((string)$snap['kind']));
            } elseif (is_array($snap) && !empty($snap['type'])) {
                $kind = (strtolower(trim((string)$snap['type'])) === 'return') ? 'return' : 'purchase';
            }
            // Daily summary: purchase invoice voids only (not supplier-return voids)
            if ($kind === 'return') {
                continue;
            }
            $items = [];
            if (is_array($snap) && !empty($snap['items']) && is_array($snap['items'])) {
                foreach ($snap['items'] as $it) {
                    if (!is_array($it)) {
                        continue;
                    }
                    $items[] = [
                        'id' => (int)($it['id'] ?? 0),
                        'prodId' => (int)($it['prodId'] ?? 0),
                        'name' => (string)($it['name'] ?? ''),
                        'qty' => (float)($it['qty'] ?? 0),
                        'totalCost' => roundMoney($it['totalCost'] ?? 0),
                        'price' => roundMoney($it['totalCost'] ?? 0),
                    ];
                }
            }
            $voidedPurchasesRows[] = [
                'id' => (int)$r['id'],
                'txn_id' => is_array($snap) ? (string)($snap['txn_id'] ?? '') : '',
                'company' => is_array($snap) ? (string)($snap['company'] ?? '') : '',
                'kind' => $kind !== '' ? $kind : 'purchase',
                'type' => is_array($snap) ? (string)($snap['type'] ?? '') : '',
                'total' => is_array($snap) ? roundMoney($snap['total'] ?? 0) : 0,
                'date' => (string)($r['created_at'] ?? ''),
                'created_at' => (string)($r['created_at'] ?? ''),
                'cashier' => (string)($r['user'] ?? ''),
                'user' => (string)($r['user'] ?? ''),
                'supplier_invoice_number' => is_array($snap) ? (string)($snap['supplier_invoice_number'] ?? '') : '',
                'items_count' => is_array($snap) ? (int)($snap['items_count'] ?? count($items)) : count($items),
                'items' => $items,
                'note' => 'ژێبرنا پسولێ کڕینێ',
                'details' => (string)($r['details'] ?? ''),
            ];
        }
    }

    /** Ledger rows (include shop-wide operational waste — same as local getFinancialMetrics) */
    $ledgerRows = [];
    $ledgerHasCreated = false;
    $rcLedCol = $conn->query("SHOW COLUMNS FROM `ledger` LIKE 'created_at'");
    if ($rcLedCol && $rcLedCol->num_rows > 0) {
        $ledgerHasCreated = true;
    }
    $ledgerSelectCols = $ledgerHasCreated
        ? 'l.id, l.type, l.amount, l.`date`, l.created_at, l.companyId, l.note, l.transaction_id'
        : 'l.id, l.type, l.amount, l.`date`, l.companyId, l.note, l.transaction_id';
    $lq = '
        SELECT ' . $ledgerSelectCols . '
        FROM ledger l
        WHERE (' . $ledgerTs . ") >= '{$rsEsc}' AND (" . $ledgerTs . ") < '{$reEsc}'
        ORDER BY l.id ASC
        ";
    $rled = $conn->query($lq);
    if ($rled) {
        while ($r = $rled->fetch_assoc()) {
            $r['id'] = (int)$r['id'];
            if (!empty($r['companyId'])) {
                $r['companyId'] = (int)$r['companyId'];
            }
            $r['amount'] = roundMoney($r['amount'] ?? 0);
            if (empty($r['date']) && !empty($r['created_at'])) {
                $r['date'] = $r['created_at'];
            }
            $ledgerRows[] = $r;
        }
    }

    /** Customer ledger — debt repayments for قاسە (payment/pay only). */
    $clRows = [];
    $cq = '
        SELECT cl.id, cl.type, cl.amount, cl.`date`, cl.target_id, cl.target_type, cl.note, cl.receipt_id, cl.transaction_id,
               CASE
                   WHEN cl.target_type = \'user\' THEN COALESCE(u.name, \'\')
                   ELSE COALESCE(c.name, \'\')
               END AS target_name
        FROM customer_ledger cl
        LEFT JOIN customers c ON cl.target_type = \'customer\' AND c.id = cl.target_id
        LEFT JOIN users u ON cl.target_type = \'user\' AND u.id = cl.target_id
        WHERE (' . $clTs . ") >= '{$rsEsc}' AND (" . $clTs . ") < '{$reEsc}'
          AND cl.type IN ('payment', 'pay')
        ORDER BY cl.id ASC
        ";
    $rcq = $conn->query($cq);
    if ($rcq) {
        while ($r = $rcq->fetch_assoc()) {
            $r['id'] = (int)$r['id'];
            if (!empty($r['target_id'])) {
                $r['target_id'] = (int)$r['target_id'];
            }
            $r['amount'] = roundMoney($r['amount'] ?? 0);
            $clRows[] = $r;
        }
    }

    /**
     * Shifts for opening balance: always date_from only (single day or range start).
     * Do not sum openings across every day in a multi-day range.
     */
    $shiftsRows = [];
    $qsh = "
        SELECT sh.id, sh.userId, sh.userName, sh.startTime, sh.endTime, sh.opening_balance, sh.hourlyRate
        FROM shifts sh
        WHERE sh.startTime >= '{$shiftStartEsc}' AND sh.startTime < '{$shiftEndEsc}'
        ORDER BY sh.startTime ASC, sh.id ASC
        ";
    $rsh = $conn->query($qsh);
    if ($rsh) {
        while ($r = $rsh->fetch_assoc()) {
            $r['id'] = (int)$r['id'];
            $r['userId'] = (int)$r['userId'];
            if (isset($r['hourlyRate'])) {
                $r['hourlyRate'] = roundMoney($r['hourlyRate'] ?? 0);
            }
            $shiftsRows[] = $r;
        }
    }

    /** Purchases (supplies) for the day — excludes returns, opening stock, Direct Store */
    $suppliesRows = [];
    $rsup = $conn->query("
        SELECT id, company, prodId, itemName, qtyAdded, totalCost, `date`, type, transaction_id, supplier_invoice_number
        FROM supplies
        WHERE `date` >= '{$rsEsc}' AND `date` < '{$reEsc}'
        AND COALESCE(type, '') NOT IN ('return', 'opening')
        AND company IS NOT NULL AND TRIM(company) != ''
        AND LOWER(TRIM(company)) NOT LIKE 'direct store'
        ORDER BY id ASC
        ");
    if ($rsup) {
        while ($r = $rsup->fetch_assoc()) {
            $r['id'] = (int)$r['id'];
            $r['prodId'] = (int)$r['prodId'];
            $r['qtyAdded'] = (float)($r['qtyAdded'] ?? 0);
            $r['totalCost'] = roundMoney($r['totalCost'] ?? 0);
            $suppliesRows[] = $r;
        }
    }

    /** Waste / spoilage rows for daily summary detail */
    $wasteRows = [];
    try {
        $rwaste = $conn->query("
            SELECT id, prodId, prodName, qty, cost, reason, `date`, `user`
            FROM waste
            WHERE `date` >= '{$rsEsc}' AND `date` < '{$reEsc}'
            ORDER BY id ASC
            ");
        if ($rwaste) {
            while ($r = $rwaste->fetch_assoc()) {
                $r['id'] = (int)$r['id'];
                $r['prodId'] = (int)($r['prodId'] ?? 0);
                $r['qty'] = (float)($r['qty'] ?? 0);
                $r['cost'] = roundMoney($r['cost'] ?? 0);
                $wasteRows[] = $r;
            }
        }
    } catch (Throwable $e) { /* waste table may not exist */ }

    /** Purchase returns to supplier (cash back into drawer) */
    $prScope = '';
    if (!$seeShopWide && $uname !== '') {
        $prScope = " AND `user` = '$userEsc' ";
    }
    $purchaseReturnsRows = [];
    $rpr = $conn->query("SELECT id, company_id, company_name, items_json, total, `date`, `user`, note, transaction_id, supplier_invoice_number, cash_refunded, debt_adjusted FROM purchase_returns WHERE `date` >= '{$rsEsc}' AND `date` < '{$reEsc}' $prScope ORDER BY id ASC");
    if ($rpr) {
        while ($r = $rpr->fetch_assoc()) {
            $r['id'] = (int)$r['id'];
            if (!empty($r['company_id'])) {
                $r['company_id'] = (int)$r['company_id'];
            }
            $r['total'] = roundMoney($r['total'] ?? 0);
            if (array_key_exists('cash_refunded', $r)) $r['cash_refunded'] = roundMoney($r['cash_refunded'] ?? 0);
            if (array_key_exists('debt_adjusted', $r)) $r['debt_adjusted'] = roundMoney($r['debt_adjusted'] ?? 0);
            $decPr = json_decode($r['items_json'] ?? '[]');
            $r['items'] = $decPr !== null ? $decPr : [];
            unset($r['items_json']);
            $purchaseReturnsRows[] = $r;
        }
    }

    $cardStatsFull = pos_daily_detail_card_stats($salesRows, $expensesRows, $suppliesRows, $ledgerRows);
    $cardStatsFull = pos_daily_detail_enrich_stats($cardStatsFull, $salesRows, $expensesRows, $returnsRows, $clRows, $wasteRows, $purchaseReturnsRows);
    $cardStatsFull = pos_daily_detail_apply_metrics_core($conn, $rsEsc, $reEsc, $seeShopWide, $metricsCashier, $cardStatsFull);
    $purchaseInvoicesFull = pos_daily_detail_purchase_invoices($suppliesRows, $expensesRows, $ledgerRows);

    $fullPayload = [
        'status' => 'ok',
        'date' => $dateFromRaw,
        'date_from' => $dateFromRaw,
        'date_to' => $dateToRaw,
        'is_range' => $isRange,
        'calendar_day_basis' => true,
        'see_shop_wide' => $seeShopWide,
        'last_receipt_id_shop' => $lastReceiptShop,
        'stats' => $cardStatsFull,
        'purchase_invoices' => $purchaseInvoicesFull,
        'pools' => [
            'sales' => $salesRows,
            'expenses' => $expensesRows,
            'returns' => $returnsRows,
            'voided_sales' => $voidedSalesRows,
            'voided_purchases' => $voidedPurchasesRows,
            'supplies' => $suppliesRows,
            'purchase_returns' => $purchaseReturnsRows,
            'ledger' => $ledgerRows,
            'customer_ledger' => $clRows,
            'shifts' => $shiftsRows,
            'waste' => $wasteRows,
            'deliveries' => function_exists('pos_fetch_deliveries_for_range') ? pos_fetch_deliveries_for_range($conn, $rsEsc, $reEsc) : [],
        ],
    ];
    $fullJson = json_encode($fullPayload, pos_daily_detail_json_flags());
    pos_daily_detail_flush_stray_output();
    if ($fullJson === false) {
        echo json_encode(['status' => 'error', 'message' => 'encode_failed'], JSON_UNESCAPED_UNICODE);
    } else {
        echo $fullJson;
    }

    exit();
    } catch (Throwable $eDaily) {
        error_log('get_daily_detail: ' . $eDaily->getMessage() . ' @ ' . $eDaily->getFile() . ':' . $eDaily->getLine());
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        if (!headers_sent()) {
            header('Content-Type: application/json; charset=utf-8');
        }
        $df = isset($dateFromRaw) ? $dateFromRaw : date('Y-m-d');
        $dt = isset($dateToRaw) ? $dateToRaw : $df;
        echo json_encode(
            pos_daily_detail_fallback_payload($df, $dt, $df !== $dt),
            JSON_UNESCAPED_UNICODE
        );
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_driver_deliveries') {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    if (empty($_SESSION['user_id'])) {
        echo json_encode(['status' => 'auth_required', 'message' => 'Login required'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }
    $driverId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if ($driverId <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid driver'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $rows = function_exists('pos_fetch_deliveries_for_driver')
        ? pos_fetch_deliveries_for_driver($conn, $driverId, 400)
        : (function_exists('pos_fetch_deliveries_compact') ? pos_fetch_deliveries_compact($conn, 400, $driverId) : []);
    echo json_encode(['status' => 'ok', 'driver_id' => $driverId, 'deliveries' => $rows, 'count' => count($rows)], JSON_UNESCAPED_UNICODE);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] == 'get_expiry_alerts') {

    header('Content-Type: application/json; charset=utf-8');
    $days = isset($_GET['days']) ? (int)$_GET['days'] : 30;
    if ($days <= 0) $days = 30;
    if ($days > 90) $days = 90;
    $expired = [];
    $expiringSoon = [];
    $res = $conn->query("SELECT b.product_id, p.name, p.barcode, b.expiry_date, b.qty, DATEDIFF(CURDATE(), b.expiry_date) AS days_over FROM stock_batches b LEFT JOIN products p ON p.id = b.product_id WHERE b.qty > 0 AND b.expiry_date < CURDATE() ORDER BY b.expiry_date ASC LIMIT 200");
    while ($res && ($r = $res->fetch_assoc())) $expired[] = $r;
    $res2 = $conn->query("SELECT b.product_id, p.name, p.barcode, b.expiry_date, b.qty, DATEDIFF(b.expiry_date, CURDATE()) AS days_left FROM stock_batches b LEFT JOIN products p ON p.id = b.product_id WHERE b.qty > 0 AND b.expiry_date >= CURDATE() AND b.expiry_date <= DATE_ADD(CURDATE(), INTERVAL COALESCE(NULLIF(p.expiry_alert_days, 0), $days) DAY) ORDER BY b.expiry_date ASC LIMIT 200");
    while ($res2 && ($r = $res2->fetch_assoc())) $expiringSoon[] = $r;
    echo json_encode([
        "status" => "success",
        "days" => $days,
        "expired_count" => count($expired),
        "expiring_soon_count" => count($expiringSoon),
        "expired" => $expired,
        "expiring_soon" => $expiringSoon
    ]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_sale_followups') {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    if (function_exists('pos_ensure_sale_followup_schema')) {
        pos_ensure_sale_followup_schema($conn);
    }
    if (function_exists('pos_can_use_sale_followup') && !pos_can_use_sale_followup($conn)) {
        echo json_encode(['status' => 'success', 'schedule' => [], 'count' => 0, 'rows' => [], 'locked' => true], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $settings = function_exists('pos_followup_load_app_settings') ? pos_followup_load_app_settings($conn) : [];
    $schedule = function_exists('pos_parse_followup_schedule') ? pos_parse_followup_schedule($settings) : [['value' => 10, 'unit' => 'day', 'key' => '10d']];
    if (empty($_SESSION['user_id'])) {
        echo json_encode(['status' => 'success', 'schedule' => $schedule, 'count' => 0, 'rows' => []], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $lookback = 14 * 86400;
    foreach ($schedule as $step) {
        $need = pos_followup_step_seconds($step['value'], $step['unit']) + pos_followup_grace_seconds($step['value'], $step['unit']);
        if ($need > $lookback) {
            $lookback = $need;
        }
    }
    if ($lookback > 400 * 86400) {
        $lookback = 400 * 86400;
    }
    $lookback = (int)$lookback;

    $sql = "SELECT s.id, s.created_at, s.total, s.items_json, s.customer_id,
                   c.name AS customer_name, c.phone AS customer_phone
            FROM sales s
            INNER JOIN customers c ON c.id = s.customer_id
            WHERE (s.is_returned IS NULL OR s.is_returned = 0)
              AND s.customer_id > 0
              AND (s.customer_type IS NULL OR s.customer_type = '' OR s.customer_type IN ('customer','customers'))
              AND s.followup_sent_at IS NULL
              AND s.created_at >= DATE_SUB(NOW(), INTERVAL {$lookback} SECOND)
              AND s.created_at <= NOW()
            ORDER BY s.created_at ASC
            LIMIT 400";
    $res = $conn->query($sql);
    $sales = [];
    $saleIds = [];
    while ($res && ($r = $res->fetch_assoc())) {
        $sid = (int)$r['id'];
        $saleIds[] = $sid;
        $extracted = function_exists('pos_followup_extract_sale_items')
            ? pos_followup_extract_sale_items($r['items_json'] ?? '[]')
            : ['list' => '', 'short' => ''];
        $sales[] = [
            'id' => $sid,
            'customer_id' => (int)$r['customer_id'],
            'customer_name' => (string)($r['customer_name'] ?? ''),
            'phone' => trim((string)($r['customer_phone'] ?? '')),
            'created_at' => (string)($r['created_at'] ?? ''),
            'item_names' => (string)($extracted['short'] ?? ''),
            'invoice_items' => (string)($extracted['list'] ?? ''),
            'invoice_no' => '#' . $sid,
            'age' => max(0, time() - (strtotime((string)$r['created_at']) ?: time())),
        ];
    }

    $sent = [];
    if ($saleIds) {
        $idList = implode(',', array_map('intval', $saleIds));
        $sentRes = $conn->query("SELECT sale_id, step_key FROM sale_followup_sends WHERE sale_id IN ({$idList})");
        while ($sentRes && ($sr = $sentRes->fetch_assoc())) {
            $sent[(int)$sr['sale_id'] . '|' . (string)$sr['step_key']] = true;
        }
    }

    $byKey = [];
    foreach ($sales as $sale) {
        foreach ($schedule as $stepIdx => $step) {
            $dueAt = pos_followup_step_seconds($step['value'], $step['unit']);
            if ($sale['age'] < $dueAt) {
                continue;
            }
            if (!empty($sent[$sale['id'] . '|' . $step['key']])) {
                continue;
            }
            $group = $sale['customer_id'] . '|' . $step['key'];
            if (!isset($byKey[$group])) {
                $byKey[$group] = [
                    'sale_id' => $sale['id'],
                    'customer_id' => $sale['customer_id'],
                    'customer_name' => $sale['customer_name'],
                    'phone' => $sale['phone'],
                    'created_at' => $sale['created_at'],
                    'item_names' => $sale['item_names'],
                    'invoice_items' => $sale['invoice_items'],
                    'invoice_no' => $sale['invoice_no'],
                    'sale_ids' => [$sale['id']],
                    'step_key' => $step['key'],
                    'step_index' => $stepIdx + 1,
                    'step_value' => $step['value'],
                    'step_unit' => $step['unit'],
                    'age_seconds' => $sale['age'],
                ];
            } else {
                $byKey[$group]['sale_ids'][] = $sale['id'];
                if ($sale['item_names'] !== '') {
                    $prev = (string)$byKey[$group]['item_names'];
                    $merged = $prev === '' ? $sale['item_names'] : ($prev . '، ' . $sale['item_names']);
                    $parts = array_values(array_unique(array_filter(array_map('trim', explode('،', $merged)))));
                    $byKey[$group]['item_names'] = implode('، ', array_slice($parts, 0, 6));
                }
                if ($sale['invoice_items'] !== '') {
                    $byKey[$group]['invoice_items'] = function_exists('pos_followup_merge_item_lists')
                        ? pos_followup_merge_item_lists((string)$byKey[$group]['invoice_items'], (string)$sale['invoice_items'])
                        : trim((string)$byKey[$group]['invoice_items'] . "\n" . $sale['invoice_items']);
                }
                if ($sale['invoice_no'] !== '' && strpos((string)$byKey[$group]['invoice_no'], (string)$sale['invoice_no']) === false) {
                    $byKey[$group]['invoice_no'] = trim((string)$byKey[$group]['invoice_no'] . '، ' . $sale['invoice_no'], '، ');
                }
                if ($byKey[$group]['phone'] === '' && $sale['phone'] !== '') {
                    $byKey[$group]['phone'] = $sale['phone'];
                }
            }
        }
    }
    $out = array_values($byKey);
    if (count($out) > 50) {
        $out = array_slice($out, 0, 50);
    }
    echo json_encode([
        'status' => 'success',
        'schedule' => $schedule,
        'count' => count($out),
        'rows' => $out,
    ], JSON_UNESCAPED_UNICODE);
    exit();
}
