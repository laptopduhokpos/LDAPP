# Speeds up this PC's XAMPP MySQL/PHP. Does not change shop sales/stock data.
# Safe: keeps innodb_flush_log_at_trx_commit=1 (full durability).
$ErrorActionPreference = 'Stop'
$xampp = 'C:\xampp'
if (-not (Test-Path (Join-Path $xampp 'mysql\bin\my.ini'))) {
    $here = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
    if (Test-Path (Join-Path $here 'mysql\bin\my.ini')) { $xampp = $here }
}
$myini = Join-Path $xampp 'mysql\bin\my.ini'
$phpini = Join-Path $xampp 'php\php.ini'

function Set-FirstUncommentedKey([string]$path, [string]$key, [string]$value) {
    $lines = [System.IO.File]::ReadAllLines($path)
    $changed = $false
    for ($i = 0; $i -lt $lines.Length; $i++) {
        if ($lines[$i] -match ('^\s*' + [regex]::Escape($key) + '\s*=')) {
            $new = "$key=$value"
            if ($lines[$i] -ne $new) {
                $lines[$i] = $new
                $changed = $true
            }
            break
        }
    }
    if ($changed) {
        [System.IO.File]::WriteAllLines($path, $lines)
    }
    return $changed
}

if (Test-Path $myini) {
    Set-FirstUncommentedKey $myini 'innodb_buffer_pool_size' '256M' | Out-Null
    Set-FirstUncommentedKey $myini 'max_allowed_packet' '64M' | Out-Null
    Write-Host "my.ini OK: $myini"
} else {
    Write-Host "my.ini not found"
}

if (Test-Path $phpini) {
    $p = [System.IO.File]::ReadAllText($phpini)
    $p2 = $p
    if ($p2 -match '(?m)^;zend_extension=opcache\s*$') {
        $p2 = [regex]::Replace($p2, '(?m)^;zend_extension=opcache\s*$', 'zend_extension=opcache', 1)
    }
    if ($p2 -match '(?m)^;opcache\.enable=1\s*$') {
        $p2 = [regex]::Replace($p2, '(?m)^;opcache\.enable=1\s*$', 'opcache.enable=1', 1)
    }
    if ($p2 -ne $p) {
        [System.IO.File]::WriteAllText($phpini, $p2)
    }
    Write-Host "php.ini OK: $phpini"
}

Write-Host 'Done. Restart Apache + MySQL (XAMPP) once.'
