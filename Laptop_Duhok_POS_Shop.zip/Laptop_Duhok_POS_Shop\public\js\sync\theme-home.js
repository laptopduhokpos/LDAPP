// sync/theme-home.js — theme, home, nav

        // applyTheme, applyZoomLevel from modules/ui.js (via window)
        function toggleTheme() {
            if (!db.settings) db.settings = {};
            if (db.settings.theme === 'dark' || !db.settings.theme) db.settings.theme = 'medical';
            db.settings.theme = (db.settings.theme === 'light') ? 'medical' : 'light';

            applyTheme();
            saveSettings();
        }

        function applyHomeZoneCssVars(mode) {
            var profile = typeof getBusinessProfile === 'function' ? getBusinessProfile(mode) : null;
            var keys = ['core', 'sales', 'catalog', 'stock', 'trade', 'kitchen', 'finance', 'insights', 'ops', 'system'];
            var hz = profile && profile.homeZoneColors;
            var fb = '#0E4AFF';
            try {
                var cs = getComputedStyle(document.documentElement);
                var b = cs.getPropertyValue('--brand').trim();
                if (b) fb = b;
            } catch (eBr) {}
            if (profile && profile.accent) fb = profile.accent;
            keys.forEach(function(k) {
                var v = hz && hz[k] ? hz[k] : fb;
                try {
                    document.documentElement.style.setProperty('--home-zone-' + k, v);
                } catch (eZ) {}
            });
        }

        function applyHomeSubtitle() {
            var el = document.getElementById('view-home-subtitle');
            if (!el) return;
            el.textContent = '';
            el.style.display = 'none';
        }
        if (typeof window !== 'undefined') {
            window.applyHomeZoneCssVars = applyHomeZoneCssVars;
            window.applyHomeSubtitle = applyHomeSubtitle;
        }

        function applySystemMode(options) {
            options = options || {};
            if (!db || !db.settings) return;
            const mode = db.settings.systemMode || 'general';
            try {
                document.body.setAttribute('data-business-mode', mode);
            } catch(e) {}
            if (typeof applyHomeZoneCssVars === 'function') applyHomeZoneCssVars(mode);
            if (typeof applyHomeSubtitle === 'function') applyHomeSubtitle();
            var customName = (db.settings.cafeName && db.settings.cafeName.trim() !== "") ? db.settings.cafeName : null;
            document.title = customName || 'شيرائ ز الباديني کرین';
            var paintNav = function () {
                if (typeof renderMainNav === 'function') renderMainNav();
                if (typeof renderRightSidebar === 'function') renderRightSidebar();
            };
            var workingWs = document.querySelector('.workspace.active');
            var userWorking = !!(workingWs && workingWs.id && workingWs.id.indexOf('view-') === 0
                && workingWs.id !== 'view-home' && typeof currentUser !== 'undefined' && currentUser);
            if (userWorking && !options.forceNav) {
                /* Stay on the screen the cashier is using — do not rebuild the menu under their click. */
            } else if (options.deferNav) {
                setTimeout(paintNav, (typeof posLoginDeferMs === 'function') ? posLoginDeferMs(600) : 600);
            } else {
                paintNav();
            }
            if (typeof applyTablesViewLabels === 'function') applyTablesViewLabels();
            if (typeof applyRecipeViewIcons === 'function') applyRecipeViewIcons();
            if (typeof syncJewelryUiVisibility === 'function') syncJewelryUiVisibility();
        }

        /** Recipe / bundle UI icons follow business profile (market = boxes, restaurant = utensils, …). */
        function applyRecipeViewIcons() {
            if (!db || !db.settings) return;
            var mode = db.settings.systemMode || 'general';
            var profile = (typeof getBusinessProfile === 'function') ? getBusinessProfile(mode) : null;
            var icon = (profile && profile.icons && profile.icons.recipes) ? profile.icons.recipes : 'fa-utensils';
            var selectors = [
                '#view-recipes h2 > i.fas',
                '#recipe-modal h2 > i.fas',
                '#btn-recipe > i.fas',
                'label[for="set-enable-recipe"] .stc-icon > i.fas',
                '.recipe-ui-icon'
            ];
            selectors.forEach(function (sel) {
                try {
                    document.querySelectorAll(sel).forEach(function (el) {
                        el.className = 'fas ' + icon + (el.classList.contains('recipe-ui-icon') ? ' recipe-ui-icon' : '');
                    });
                } catch (e) {}
            });
        }
        if (typeof window !== 'undefined') window.applyRecipeViewIcons = applyRecipeViewIcons;

        function posEndShiftRequiresReconcile() {
            var dbCheck = (typeof db !== 'undefined' && db && db.settings && db.settings.requireEndShiftReconcilePrompt === true);
            return dbCheck || ((typeof isPremiumSettingsFeatureEnabled === 'function')
                ? isPremiumSettingsFeatureEnabled('set-require-end-shift-reconcile-prompt')
                : (function () {
                    var endShiftPromptEl = document.getElementById('set-require-end-shift-reconcile-prompt');
                    return endShiftPromptEl ? !!endShiftPromptEl.checked : false;
                })());
        }

        function posApplyEndShiftExpectedToModal(data) {
            if (!data || data.status !== 'ok') return;
            var openEl = document.getElementById('reconcile-opening');
            var expEl = document.getElementById('reconcile-expected');
            var noteEl = document.getElementById('reconcile-expected-note');
            
            var rawExpected = (data.original_expected !== undefined) ? data.original_expected : data.expected;
            var isNegative = (rawExpected < 0);
            var safeExpected = (rawExpected > 0) ? rawExpected : 0;
            
            if (openEl) openEl.textContent = formatCurrency(data.opening_balance || 0);
            if (expEl) expEl.textContent = formatCurrency(safeExpected);
            
            if (noteEl) {
                if (isNegative) {
                    var inAmt = formatCurrency(data.pos_in || 0);
                    var outAmt = formatCurrency(data.pos_out || 0);
                    noteEl.innerHTML = '<i class="fas fa-info-circle"></i> پارەی پێشبینیکراو سالب بوو (ل خوار سفرێیە: <span style="direction:ltr; display:inline-block;">' + formatCurrency(rawExpected) + '</span>) بەهۆی کڕین یان مەزاختنەکان ('+outAmt+') کە زیاترن لە فرۆشتنەکان ('+inAmt+')، بۆیە وەکو ٠ (سفر) هەژمار دەکرێت.';
                    noteEl.style.display = 'block';
                } else {
                    noteEl.style.display = 'none';
                }
            }

            window._pendingEndShiftExpected = safeExpected;
            window._pendingEndShiftStart = data.startTime;
        }

        function posShowShiftCloseBusy() {
            var id = 'pos-shift-close-busy';
            var el = document.getElementById(id);
            if (!el) {
                el = document.createElement('div');
                el.id = id;
                el.setAttribute('aria-live', 'polite');
                el.style.cssText = 'position:fixed;inset:0;z-index:10060;display:flex;align-items:center;justify-content:center;background:rgba(15,23,42,0.5);backdrop-filter:blur(2px);-webkit-backdrop-filter:blur(2px);';
                var msg = (typeof t === 'function') ? (t('shift_closing') || 'گرتنا شیفتی…') : 'گرتنا شیفتی…';
                el.innerHTML = '<div style="background:var(--card,#fff);padding:22px 30px;border-radius:14px;text-align:center;font-weight:700;color:var(--text,#0f172a);box-shadow:0 12px 32px rgba(0,0,0,0.2);"><i class="fas fa-spinner fa-spin" style="display:block;font-size:1.4rem;margin-bottom:10px;color:var(--brand,#3b82f6);"></i><span>' + msg + '</span></div>';
                document.body.appendChild(el);
            } else {
                el.style.display = 'flex';
            }
        }
        function posHideShiftCloseBusy() {
            var el = document.getElementById('pos-shift-close-busy');
            if (el) el.style.display = 'none';
        }
        /** POST end_shift with hard timeout — blocked network must not hang shift close for 30s+. */
        function posFetchEndShift(formData, timeoutMs) {
            var ms = parseInt(timeoutMs, 10) || 12000;
            var opts = { method: 'POST', body: formData, credentials: 'same-origin' };
            if (typeof AbortSignal !== 'undefined' && typeof AbortSignal.timeout === 'function') {
                try { opts.signal = AbortSignal.timeout(ms); } catch (_eSig) {}
            }
            var req = fetch('?action=end_shift', opts);
            if (opts.signal) return req;
            return Promise.race([
                req,
                new Promise(function (_resolve, reject) {
                    setTimeout(function () { reject(new Error('shift_close_timeout')); }, ms);
                })
            ]);
        }
        function posFinishShiftCloseAndReload() {
            try { sessionStorage.removeItem('pos_session_active'); } catch (_eLo) {}
            try { sessionStorage.setItem('pos_post_shift_reload', '1'); } catch (_ePsr) {}
            posHideShiftCloseBusy();
            if (document.fullscreenElement) document.exitFullscreen().catch(function(){});
            try {
                var fd = new FormData();
                fd.append('action', 'logout');
                fetch('?action=logout', { method: 'POST', body: fd, credentials: 'same-origin', keepalive: true }).catch(function(){});
            } catch (_eLoFetch) {}
            location.reload();
        }

        function endShift() {
            if(!currentUser) {
                if (typeof window.posAlert === 'function') window.posAlert({ tone: 'info', title: 'چوونەژوور', message: 'پێدڤیە بچیە ژوور' });
                else alert('پێدڤیە بچیە ژوور');
                return;
            }
            var askEnd = (typeof t === 'function') ? (t('shift_end_confirm') || 'دڵنیای تە دڤێت شیفتی ب دوماهیک بینی؟') : 'دڵنیای تە دڤێت شیفتی ب دوماهیک بینی؟';
            var runEndShift = function () {
            function openReconcileModal(data) {
                posApplyEndShiftExpectedToModal(data);
                document.getElementById('reconcile-actual').value = '';
                document.getElementById('reconcile-result').style.display = 'none';
                var rmod = document.getElementById('end-shift-reconcile-modal');
                if (rmod) {
                    rmod.style.display = 'flex';
                    if (typeof applyI18nSubtree === 'function') applyI18nSubtree(rmod);
                }
                var act = document.getElementById('reconcile-actual');
                if (act) act.focus();
            }
            function closeShiftDirect(data, opts) {
                opts = opts || {};
                var formData = new FormData();
                formData.append('action', 'end_shift');
                formData.append('userId', currentUser.id);
                if (opts.fastClose) {
                    formData.append('fast_close', '1');
                } else {
                    var expected = (data && typeof data.expected === 'number') ? data.expected : (parseFloat((data && data.expected) || 0) || 0);
                    formData.append('closing_balance_actual', expected);
                    formData.append('reconciled_by', currentUser.name || '');
                }
                posShowShiftCloseBusy();
                if (typeof showToast === 'function') showToast((typeof t === 'function') ? (t('shift_closing') || 'گرتنا شیفتی…') : 'گرتنا شیفتی…', false);

                posFetchEndShift(formData, 12000)
                    .then(function(res) {
                        if (!res.ok) return res.text().then(function(t) { throw new Error(t || res.statusText); });
                        return res.json();
                    })
                    .then(function(data) {
                        if(data && data.status === 'success') {
                            posFinishShiftCloseAndReload();
                            return;
                        }
                        posHideShiftCloseBusy();
                        if (typeof window.posAlert === 'function') window.posAlert({ message: (data && data.message) ? data.message : 'Error', tone: 'danger' }); else alert((data && data.message) ? data.message : 'Error');
                    })
                    .catch(function(err) { 
                        posHideShiftCloseBusy();
                        var errMsg = (err && err.message === 'shift_close_timeout')
                            ? ((typeof t === 'function') ? (t('shift_close_timeout') || 'گرتنا شیفتی درێژ بوو — دووبارە هەوڵ بدە') : 'گرتنا شیفتی درێژ بوو')
                            : 'هەڵە د پەیوەندیێ دا یان سێرڤەر';
                        if (typeof window.posAlert === 'function') window.posAlert({ message: errMsg, tone: 'danger' }); else alert(errMsg); 
                        console.error('end_shift', err); 
                    });
            }
            function shiftMissingHelp(firstFailMsg) {
                return (firstFailMsg || 'چ شیفتێن ڤەکری نینن') + '<br><br>ئەگەر تازە چوویتە ژوورەوە: پەڕە نوێ بکەرەوە (F5) یان دووبارە بچۆ ژوورەوە بۆ ھەڵکرنا شفتێ.<br>إن كنت قد سجّلت الدخول للتو: حدّث الصفحة أو أعد تسجيل الدخول لفتح الوردية.';
            }
            function fetchExpectedOrRepair(tryRepair, onOk) {
                var fd = new FormData();
                fd.append('action', 'get_shift_expected');
                fd.append('userId', currentUser.id);
                apiJson('?action=get_shift_expected', { method: 'POST', body: fd, credentials: 'same-origin' })
                    .then(function(data) {
                        if (data.status === 'ok') {
                            if (typeof onOk === 'function') onOk(data);
                            return;
                        }
                        var errMsg = data.message || 'چ شیفتێن ڤەکری نینن';
                        
                        // If we're just trying to close and it's already missing/closed, bypass and go to login
                        if (!tryRepair) {
                            if (typeof closeShiftDirect === 'function') {
                                closeShiftDirect({ expected: 0 });
                            }
                            return;
                        }

                        if (tryRepair && typeof completeShiftStart === 'function') {
                            completeShiftStart(currentUser, null).then(function(ok) {
                                if (!ok) {
                                    if (typeof window.posAlert === 'function') window.posAlert({ message: shiftMissingHelp(errMsg), tone: 'info' }); else alert(shiftMissingHelp(errMsg).replace(/<br>/g, '\n'));
                                    return;
                                }
                                if (typeof showToast === 'function') {
                                    showToast('وردية هاتە ھەڵکرن لە سێرڤەر — دووبارە هەوڵ دەدرێت.', false);
                                }
                                fetchExpectedOrRepair(false, onOk);
                            });
                            return;
                        }
                        if (typeof window.posAlert === 'function') window.posAlert({ message: shiftMissingHelp(errMsg), tone: 'info' }); else alert(shiftMissingHelp(errMsg).replace(/<br>/g, '\n'));
                    }).catch(function(err) {
                        var msg = (err && err.message) ? err.message : 'خطأ في الاتصال';
                        if (typeof window.posAlert === 'function') window.posAlert({ message: msg, tone: 'danger' }); else alert(msg);
                    });
            }
            var shouldAskReconcile = posEndShiftRequiresReconcile();
            if (!shouldAskReconcile) {
                closeShiftDirect(null, { fastClose: true });
                return;
            }
            var localShift = (typeof getCurrentShift === 'function') ? getCurrentShift() : null;
            var localData = localShift ? posComputeShiftExpectedFromLocal(localShift) : null;
            if (localData) {
                openReconcileModal(localData);
                fetchExpectedOrRepair(true, function (serverData) {
                    posApplyEndShiftExpectedToModal(serverData);
                });
                return;
            }
            if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('login_connecting') : 'ژماردن…', false);
            fetchExpectedOrRepair(true, openReconcileModal);
            };
            var askTitle = (typeof t === 'function') ? (t('shift_end_title') || 'ب دوماهیک ئینانا شیفتی') : 'ب دوماهیک ئینانا شیفتی';
            var askOk = (typeof t === 'function') ? (t('shift_end_confirm_btn') || t('btn_confirm') || 'بەڵێ، بگرە') : 'بەڵێ، بگرە';
            var askCancel = (typeof t === 'function') ? (t('btn_cancel') || 'پاشگەزبوون') : 'پاشگەزبوون';
            var confirmFn = (typeof window.posConfirm === 'function') ? window.posConfirm : null;
            if (confirmFn) {
                confirmFn({
                    tone: 'warn',
                    icon: 'fa-power-off',
                    title: askTitle,
                    message: askEnd,
                    confirmText: askOk,
                    cancelText: askCancel
                }).then(function (ok) { if (ok) runEndShift(); });
            } else if (window.confirm(askEnd)) {
                runEndShift();
            }
        }
        if (typeof window !== 'undefined') { window.endShift = endShift; }
        function submitEndShiftReconcile() {
            if(!currentUser) { alert('پێدڤیە بچیە ژوور'); return; }
            var saveBtn = document.querySelector('#end-shift-reconcile-modal .btn-brand');
            if (saveBtn && saveBtn.disabled) return;
            if (saveBtn) { 
                saveBtn.disabled = true; 
                saveBtn.dataset.originalHtml = saveBtn.innerHTML;
                saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ' + ((typeof t === 'function') ? (t('login_connecting') || 'چاوەڕێ بکە...') : 'چاوەڕێ بکە...'); 
            }
            var actualInput = document.getElementById('reconcile-actual');
            var actualStr = (actualInput && actualInput.value) ? String(actualInput.value).trim() : '';
            if (!actualStr) {
                if (saveBtn) { saveBtn.disabled = false; saveBtn.innerHTML = saveBtn.dataset.originalHtml; }
                if (typeof window.posAlert === 'function') window.posAlert({ message: (typeof t === 'function') ? t('reconcile_enter_actual') : 'تکایە پارێ د قاسێ دا بنووسە', tone: 'warning' }); else alert((typeof t === 'function') ? t('reconcile_enter_actual') : 'تکایە پارێ د قاسێ دا بنووسە');
                return;
            }
            actualStr = actualStr.replace(/[٠-٩]/g, function(ch) { return String(ch.charCodeAt(0) - 1632); });
            actualStr = actualStr.replace(/[۰-۹]/g, function(ch) { return String(ch.charCodeAt(0) - 1776); });
            var parsedActual = (typeof parseAmountInput === 'function')
                ? parseAmountInput(actualStr)
                : parseFloat(String(actualStr).replace(/,/g, ''));
            if (parsedActual == null || !isFinite(parsedActual) || isNaN(parsedActual)) {
                if (saveBtn) { saveBtn.disabled = false; saveBtn.innerHTML = saveBtn.dataset.originalHtml; }
                if (typeof window.posAlert === 'function') window.posAlert({ message: (typeof t === 'function') ? t('reconcile_enter_actual') : 'تکایە پارێ د قاسێ دا بنووسە', tone: 'warning' }); else alert((typeof t === 'function') ? t('reconcile_enter_actual') : 'تکایە پارێ د قاسێ دا بنووسە');
                return;
            }
            var actualRaw = Math.max(0, parsedActual);
            var actualStored = (typeof debtFormAmountToStoredIqd === 'function') ? debtFormAmountToStoredIqd(actualRaw) : actualRaw;
            
            // Expected should never be treated as negative for calculations
            var expected = parseFloat(window._pendingEndShiftExpected) || 0;
            if (expected < 0) expected = 0;
            
            var shortage = expected > actualStored ? expected - actualStored : 0;
            var surplus = actualStored > expected ? actualStored - expected : 0;
            
            var resultEl = document.getElementById('reconcile-result');
            resultEl.style.display = 'block';
            if(shortage > 0) {
                var sLab = (typeof t === 'function') ? t('reconcile_shortage_label') : 'کێماسی';
                resultEl.innerHTML = '<span style="color:var(--danger);"><i class="fas fa-arrow-down"></i> ' + escapeHtml(sLab) + ': ' + formatCurrency(shortage) + '</span>';
            } else if(surplus > 0) {
                var uLab = (typeof t === 'function') ? t('reconcile_surplus_label') : 'زێدەهی';
                resultEl.innerHTML = '<span style="color:var(--success);"><i class="fas fa-arrow-up"></i> ' + escapeHtml(uLab) + ': ' + formatCurrency(surplus) + '</span>';
            } else {
                var mLab = (typeof t === 'function') ? t('reconcile_status_match') : 'وەک یەک';
                resultEl.innerHTML = '<span style="color:var(--success);">' + escapeHtml(mLab) + '</span>';
            }
            var formData = new FormData();
            formData.append('action', 'end_shift');
            formData.append('userId', currentUser.id);
            formData.append('closing_balance_actual', actualRaw);
            formData.append('reconciled_by', currentUser.name || '');
            posShowShiftCloseBusy();
            posFetchEndShift(formData, 12000)
            .then(function(res) {
                if (!res.ok) return res.text().then(function(t) { throw new Error(t || res.statusText); });
                return res.json();
            })
            .then(function(data) {
                // Remove loading spinner immediately
                if (saveBtn && saveBtn.dataset.originalHtml) {
                    saveBtn.disabled = false;
                    saveBtn.innerHTML = saveBtn.dataset.originalHtml;
                }
                if(data && data.status === 'success') {
                    if (typeof posTelegramConfigured === 'function' ? posTelegramConfigured() : (db && db.settings && db.settings.tgToken && db.settings.tgChatId)) {
                        if (db.settings.tg_shift_end_report !== false) {
                        const sym = typeof getCurrencySymbol === 'function' ? getCurrencySymbol() : 'IQD';
                        const esc = typeof telegramEscapeHtml === 'function' ? telegramEscapeHtml : function(x) { return String(x == null ? '' : x).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); };
                        let customMsg = '<b>🔴 ب دوماهی هاتنا شفتێ / إغلاق وردية</b>\n\n';
                        customMsg += '<b>کارمەند:</b> ' + esc(currentUser.name) + '\n';
                        customMsg += '<b>دەستپێک:</b> ' + esc(new Date(window._pendingEndShiftStart).toLocaleString('ku-IQ')) + '\n';
                        customMsg += '<b>دوماهیک:</b> ' + esc(new Date().toLocaleString('ku-IQ')) + '\n\n';
                        if (db.settings.tg_include_cash_in_drawer !== false) {
                            customMsg += '<b>💰 رصيد الصندوق / ڕێژا سندوقێ (کۆیێ نەقدی د سندوقێ دا — العدّ الفعلي):</b>\n';
                            customMsg += esc(formatCurrency(actualStored)) + ' ' + esc(sym) + '\n\n';
                            customMsg += '<b>پێشبینیکرنا سیستەمی (مُتوقَّع):</b> ' + esc(formatCurrency(expected)) + ' ' + esc(sym) + '\n';
                            if (shortage > 0) customMsg += '<b>کێماسی / عجز:</b> ' + esc(formatCurrency(shortage)) + ' ' + esc(sym) + '\n';
                            if (surplus > 0) customMsg += '<b>زێدەهی / فائض:</b> ' + esc(formatCurrency(surplus)) + ' ' + esc(sym) + '\n';
                            if (shortage === 0 && surplus === 0) customMsg += '✅ <b>وەک یەک (متطابق)</b>\n';
                        }
                        customMsg += '\n\n📌 ئاگەهداری: سیستەم هاتە داخستن.';
                        sendFilesToTelegram(db.settings.tgToken, db.settings.tgChatId, true, customMsg, true, null, actualStored).catch(function(e) { console.error('Telegram backup failed', e); });
                        }
                    }

                    var rmod = document.getElementById('end-shift-reconcile-modal');
                    if (rmod) rmod.style.display = 'none';
                    posFinishShiftCloseAndReload();
                } else {
                    posHideShiftCloseBusy();
                    if (saveBtn && saveBtn.dataset.originalHtml) { saveBtn.disabled = false; saveBtn.innerHTML = saveBtn.dataset.originalHtml; }
                    if (typeof window.posAlert === 'function') window.posAlert({ message: (data && data.message) ? data.message : 'Error', tone: 'danger' }); else alert((data && data.message) ? data.message : 'Error');
                }
            })
            .catch(function(err) {
                posHideShiftCloseBusy();
                if (saveBtn && saveBtn.dataset.originalHtml) { saveBtn.disabled = false; saveBtn.innerHTML = saveBtn.dataset.originalHtml; }
                var errMsg = (err && err.message === 'shift_close_timeout')
                    ? ((typeof t === 'function') ? (t('shift_close_timeout') || 'گرتنا شیفتی درێژ بوو') : 'گرتنا شیفتی درێژ بوو')
                    : 'هەڵە د پەیوەندیێ دا یان سێرڤەر';
                if (typeof window.posAlert === 'function') window.posAlert({ message: errMsg, tone: 'danger' }); else alert(errMsg);
                console.error('end_shift', err);
            });
        }
        if (typeof window !== 'undefined') { window.submitEndShiftReconcile = submitEndShiftReconcile; }

        function switchRole() {
            if (!currentUser) return;
            
            isSwitchedRole = !isSwitchedRole;
            
            const protectedItems = document.querySelectorAll('.protected');
            protectedItems.forEach(el => { 
                el.style.display = isSwitchedRole ? '' : (currentUser.role === 'admin' ? '' : 'none'); 
            });
            
            document.getElementById('role-switch-btn').innerHTML = isSwitchedRole ? 
                '🔄 زڤڕین بۆ ' + currentUser.role : '🔄 گوهۆڕینا ڕۆڵی';
            
            alert(isSwitchedRole ? 
                "نوکە دشێی هەمی بەشان ببینی." : 
                "زڤڕی بۆ ڕۆڵێ خۆ.");
        }

        var _posSecretAccessPollTimer = null;
        var _posSecretAccessExpiryTimer = null;
        var _posSecretAccessCountdownTimer = null;

        function posSecretAccessApplyUntil(data) {
            if (!data || !data.ok || !data.approved_until) {
                window.__posSecretAccessUntil = 0;
                return false;
            }
            var ts = Date.parse(String(data.approved_until));
            if (!isFinite(ts) || ts <= Date.now()) {
                window.__posSecretAccessUntil = 0;
                return false;
            }
            window.__posSecretAccessUntil = ts;
            return true;
        }

        function posSecretAccessIsActive() {
            return !!(window.__posSecretAccessUntil && window.__posSecretAccessUntil > Date.now());
        }

        function posSecretAccessStopTimers() {
            if (_posSecretAccessPollTimer) {
                clearInterval(_posSecretAccessPollTimer);
                _posSecretAccessPollTimer = null;
            }
            if (_posSecretAccessExpiryTimer) {
                clearTimeout(_posSecretAccessExpiryTimer);
                _posSecretAccessExpiryTimer = null;
            }
            if (_posSecretAccessCountdownTimer) {
                clearInterval(_posSecretAccessCountdownTimer);
                _posSecretAccessCountdownTimer = null;
            }
        }

        function posSecretAccessClosePendingModal() {
            posSecretAccessStopTimers();
            var ov = document.getElementById('secret-access-pending-modal');
            if (ov) ov.style.display = 'none';
        }

        function posSecretAccessUpdateCountdownUi() {
            var el = document.getElementById('secret-access-pending-countdown');
            if (!el) return;
            var left = Math.max(0, Math.ceil((window.__posSecretAccessUntil - Date.now()) / 1000));
            if (left <= 0) {
                el.style.display = 'none';
                return;
            }
            var mm = Math.floor(left / 60);
            var ss = left % 60;
            var pref = (typeof t === 'function') ? t('secret_access_countdown') : 'کاتێ ماوە:';
            el.style.display = 'block';
            el.textContent = pref + ' ' + mm + ':' + (ss < 10 ? '0' : '') + ss;
        }

        function posSecretAccessExpireSession(showAlert) {
            window.__posSecretAccessUntil = 0;
            posSecretAccessStopTimers();
            var menu = document.getElementById('secret-menu-modal');
            if (menu) menu.style.display = 'none';
            if (showAlert) {
                alert((typeof t === 'function') ? t('secret_access_expired') : 'کاتێ ٥ خولەکی تەواو بوو.');
            }
        }

        function posSecretAccessStartSessionWatch() {
            posSecretAccessStopTimers();
            if (!posSecretAccessIsActive()) return;
            var remain = window.__posSecretAccessUntil - Date.now();
            _posSecretAccessExpiryTimer = setTimeout(function () {
                posSecretAccessExpireSession(true);
            }, Math.max(500, remain));
            _posSecretAccessCountdownTimer = setInterval(function () {
                if (!posSecretAccessIsActive()) {
                    posSecretAccessExpireSession(false);
                    return;
                }
                posSecretAccessUpdateCountdownUi();
            }, 1000);
        }

        function posSecretAccessApiCheck() {
            return fetch('?action=check_secret_menu_access&t=' + Date.now(), { credentials: 'same-origin' })
                .then(function (r) { return r.json(); });
        }

        function posSecretAccessApiRequest() {
            var fd = new FormData();
            fd.append('action', 'request_secret_menu_access');
            if (navigator.platform) fd.append('platform', navigator.platform);
            return fetch('?action=request_secret_menu_access', { method: 'POST', body: fd, credentials: 'same-origin' })
                .then(function (r) { return r.json(); });
        }

        function posSecretAccessOnApproved(data) {
            posSecretAccessApplyUntil(data);
            posSecretAccessClosePendingModal();
            if (typeof showToast === 'function') {
                showToast((typeof t === 'function') ? t('secret_access_approved_opening') : 'ڕێگەپێدرا…', 'success');
            }
            openSecretMenu(true);
        }

        function posSecretAccessShowPendingModal(msg) {
            var ov = document.getElementById('secret-access-pending-modal');
            var mEl = document.getElementById('secret-access-pending-msg');
            var uEl = document.getElementById('secret-access-pending-user');
            if (mEl && msg) mEl.textContent = msg;
            if (uEl && typeof currentUser !== 'undefined' && currentUser) {
                uEl.textContent = (currentUser.name || currentUser.username || '') + (currentUser.role ? (' · ' + currentUser.role) : '');
            }
            if (ov) {
                ov.style.display = 'flex';
                if (typeof applyI18nSubtree === 'function') applyI18nSubtree(ov);
            }
        }

        function posSecretAccessBeginPoll() {
            posSecretAccessStopTimers();
            _posSecretAccessPollTimer = setInterval(function () {
                posSecretAccessApiCheck().then(function (data) {
                    if (!data) return;
                    if (data.status === 'auth_required') {
                        alert('پێویستە بچیتە ژوورەوە.');
                        posSecretAccessClosePendingModal();
                        return;
                    }
                    if (data.access_status === 'blocked') {
                        posSecretAccessClosePendingModal();
                        alert((typeof t === 'function') ? t('secret_access_blocked') : 'ڕێگری کراوە.');
                        return;
                    }
                    if (data.ok) {
                        posSecretAccessOnApproved(data);
                    }
                }).catch(function () {});
            }, 2500);
        }

        function posSecretAccessEnsureThenOpen() {
            posSecretAccessApiCheck().then(function (data) {
                if (data && data.ok) {
                    posSecretAccessOnApproved(data);
                    return;
                }
                if (data && data.access_status === 'blocked') {
                    alert((typeof t === 'function') ? t('secret_access_blocked') : 'ڕێگری کراوە.');
                    return;
                }
                var bodyMsg = (data && data.message) ? String(data.message) : ((typeof t === 'function') ? t('secret_access_pending_body') : '');
                posSecretAccessShowPendingModal(bodyMsg);
                return posSecretAccessApiRequest().then(function (reqData) {
                    if (reqData && reqData.ok) {
                        posSecretAccessOnApproved(reqData);
                        return;
                    }
                    if (reqData && reqData.access_status === 'blocked') {
                        posSecretAccessClosePendingModal();
                        alert((typeof t === 'function') ? t('secret_access_blocked') : 'ڕێگری کراوە.');
                        return;
                    }
                    posSecretAccessBeginPoll();
                });
            }).catch(function () {
                alert('تعذر الاتصال بالخادم.');
            });
        }

        function posSecretAccessRetryRequest() {
            posSecretAccessApiRequest().then(function (data) {
                if (data && data.ok) {
                    posSecretAccessOnApproved(data);
                } else if (data && data.message) {
                    posSecretAccessShowPendingModal(String(data.message));
                    posSecretAccessBeginPoll();
                }
            }).catch(function () {});
        }

        function posRequireSecretMenuAccessSync() {
            if (!posSecretAccessIsActive()) {
                posSecretAccessExpireSession(false);
                alert((typeof t === 'function') ? t('secret_access_expired') : 'کات تەواو بوو.');
                return false;
            }
            return true;
        }

        if (typeof window !== 'undefined') {
            window.posSecretAccessClosePendingModal = posSecretAccessClosePendingModal;
            window.posSecretAccessRetryRequest = posSecretAccessRetryRequest;
        }

        function handleSettingsNavClick() {
            if (settingsNavTimer) {
                clearTimeout(settingsNavTimer);
                settingsNavTimer = null;
            }

            settingsClickCount++;

            if (settingsClickCount < 10) {
                settingsNavTimer = setTimeout(() => {
                    nav('settings');
                    settingsClickCount = 0;
                }, 300);
            } else {
                settingsClickCount = 0;
                const currentPin = (db.settings && db.settings.settingsPin) ? db.settings.settingsPin : "2026";
                promptSecretPinModal().then(function (pass) {
                    if (pass == null) return;
                    if (pass === currentPin) {
                        posSecretAccessEnsureThenOpen();
                    } else {
                        alert("❌ ژمارا نهێنی یا خەلەتە.");
                    }
                });
            }
        }

        var POS_TG_INVITE_HIDE_KEY = 'pos_hide_telegram_group_invite';
        var _secretPinModalResolver = null;

        function posSecretPinInviteIsHidden() {
            try { return localStorage.getItem(POS_TG_INVITE_HIDE_KEY) === '1'; } catch (eH) { return false; }
        }

        function posSecretPinSyncInviteVisibility() {
            var el = document.getElementById('secret-pin-tg-invite');
            if (!el) return;
            el.style.display = posSecretPinInviteIsHidden() ? 'none' : 'block';
        }

        function posSecretPinHideTelegramInvite() {
            try { localStorage.setItem(POS_TG_INVITE_HIDE_KEY, '1'); } catch (eS) {}
            posSecretPinSyncInviteVisibility();
        }

        function posSecretPinModalClose(result) {
            var modal = document.getElementById('secret-pin-modal');
            if (modal) modal.style.display = 'none';
            var resolve = _secretPinModalResolver;
            _secretPinModalResolver = null;
            if (typeof resolve === 'function') resolve(result);
        }

        function posSecretPinModalCancel() {
            posSecretPinModalClose(null);
        }

        function posSecretPinModalSubmit() {
            var input = document.getElementById('secret-pin-input');
            var val = input ? String(input.value || '') : '';
            posSecretPinModalClose(val);
        }

        function promptSecretPinModal() {
            return new Promise(function (resolve) {
                var modal = document.getElementById('secret-pin-modal');
                var input = document.getElementById('secret-pin-input');
                if (!modal || !input) {
                    var fallback = prompt((typeof t === 'function') ? t('secret_pin_modal_label') : 'ژمارا نهێنی بنڤیسە');
                    resolve(fallback == null ? null : String(fallback));
                    return;
                }
                if (_secretPinModalResolver) {
                    _secretPinModalResolver(null);
                }
                _secretPinModalResolver = resolve;
                input.value = '';
                posSecretPinSyncInviteVisibility();
                modal.style.display = 'flex';
                if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
                setTimeout(function () {
                    try { input.focus(); input.select(); } catch (eF) {}
                }, 30);
            });
        }

        if (typeof window !== 'undefined') {
            window.posSecretPinModalCancel = posSecretPinModalCancel;
            window.posSecretPinModalSubmit = posSecretPinModalSubmit;
            window.posSecretPinHideTelegramInvite = posSecretPinHideTelegramInvite;
            window.promptSecretPinModal = promptSecretPinModal;
        }

        function injectSecretVaultVisualCss() {
            if (document.getElementById('secret-vault-visual-style')) return;
            var st = document.createElement('style');
            st.id = 'secret-vault-visual-style';
            st.textContent =
                '#secret-features-vault-wrap{position:relative;}' +
                '.secret-vault-tile{' +
                'position:relative;text-align:center;padding:20px 14px 16px;border-radius:18px;' +
                'border:1px solid rgba(129,140,248,0.35);' +
                'background:linear-gradient(165deg,rgba(17,24,39,0.98) 0%,rgba(30,27,75,0.55) 100%);' +
                'cursor:pointer;color:#e2e8f0;font-family:inherit;overflow:hidden;' +
                'transition:transform .22s ease,box-shadow .22s ease,border-color .2s;' +
                'box-shadow:inset 0 1px 0 rgba(255,255,255,0.06);}' +
                '.secret-vault-tile:focus{outline:2px solid rgba(250,204,21,0.45);outline-offset:2px;}' +
                '.secret-vault-tile::before{content:\"\";position:absolute;inset:0;' +
                'background:linear-gradient(115deg,transparent 35%,rgba(250,204,21,0.14) 50%,transparent 65%);' +
                'background-size:220% 100%;animation:posVaultSheen 5s linear infinite;opacity:.55;pointer-events:none;}' +
                '.secret-vault-tile.is-on{border-color:rgba(52,211,153,0.55);' +
                'box-shadow:0 0 32px rgba(52,211,153,0.12),inset 0 1px 0 rgba(255,255,255,0.08);}' +
                '.secret-vault-tile.is-on::before{opacity:.22;animation-duration:8s;}' +
                '.secret-vault-tile:hover{transform:translateY(-4px);box-shadow:0 14px 36px rgba(0,0,0,0.35);}' +
                '@keyframes posVaultSheen{0%{background-position:220% 0}100%{background-position:-220% 0}}' +
                '.secret-vault-tile .sv-lock{display:block;font-size:1.75rem;margin-bottom:10px;color:#fbbf24;' +
                'filter:drop-shadow(0 0 10px rgba(251,191,36,.45));line-height:1;}' +
                '.secret-vault-tile.is-on .sv-lock{color:#34d399;filter:drop-shadow(0 0 12px rgba(52,211,153,.35));}' +
                '.secret-vault-tile .sv-title{display:block;font-weight:700;font-size:.88rem;line-height:1.35;margin-bottom:5px;}' +
                '.secret-vault-tile .sv-sub{display:block;font-size:.68rem;opacity:.72;line-height:1.3;}' +
                '.secret-vault-tile .sv-state{display:block;margin-top:12px;font-size:.65rem;letter-spacing:.06em;' +
                'text-transform:uppercase;color:#94a3b8;font-weight:600;}' +
                '.secret-vault-tile.is-on .sv-state{color:#6ee7b7;}';
            document.head.appendChild(st);
        }

        function buildSecretVaultTilesOnce() {
            var grid = document.getElementById('secret-features-vault-grid');
            var vaultSection = document.getElementById('secret-features-vault-section');
            if (vaultSection) vaultSection.style.display = hasPremiumEntitlement() ? 'none' : '';
            if (!grid) return;
            if (hasPremiumEntitlement()) return;
            var bver = grid.getAttribute('data-vault-build') || '';
            if (bver === 'vault-172') return;
            grid.setAttribute('data-vault-build', 'vault-172');
            grid.removeAttribute('data-built');
            grid.innerHTML = '';
            var tiles = [
                { id: 'set-show-note-icon', title: '١· تێبینی بۆ ئایتمان', sub: 'Item notes', pin: '١· تێبینی بۆ ئایتمان' },
                { id: 'set-enable-takeaway', title: '٢· سیستەمێ جوملە', sub: 'Wholesale mode', pin: '٢· سیستەمێ جوملە' },
                { id: 'set-enable-wholesale', title: '٣· فرۆتنا ب کۆم', sub: 'Wholesale tiers', pin: '٣· فرۆتنا ب کۆم' },
                { id: 'set-show-tables', title: '٤· مێز و سەبەت', sub: 'Tables / carts UI', pin: '٤· نیشاندانا مێزان' },
                { id: 'set-enable-gift', title: '٥· دیاری', sub: 'Gift on bill', pin: '٥· دیاری' },
                { id: 'set-enable-manual-sale', title: '٦· فرۆتنا دەستی', sub: 'Manual line items', pin: '٦· فرۆتنا دەستی' },
                { id: 'set-unlock-staff-beyond-five', title: '٧· زیاتر لە ٣ کارمەند', sub: 'Staff beyond free limit', pin: '٧· زیاتر لە ٣ کارمەند' },
                { id: 'set-show-fab', title: '٨· مینیو یا پشکوکێ (FAB)', sub: 'Floating menu', pin: '٨· مینیو یا پشکوکێ' },
                { id: 'set-enable-delivery', title: '٩· گەهاندن', sub: 'Delivery module', pin: '٩· گەهاندن' },
                { id: 'set-require-opening-balance-prompt', title: '١٠· داخوازکرنا پارەی دەستپێکێ', sub: 'Opening drawer cash', pin: '١٠· پارەی دەستپێکی قاسە' },
                { id: 'set-require-end-shift-reconcile-prompt', title: '١٠ب· قاسەی کۆتایی شیفت', sub: 'End shift reconcile', pin: '١٠· قاسەی کۆتایی شیفت' },
                { id: 'set-allow-negative-stock', title: '١١· فرۆتنا بە سالبی', sub: 'Negative stock OK', pin: '١١· فرۆتنا ب سالبی' },
                { id: 'set-enable-money-rounding', title: '١٢· خڕکرنا پارەی دیناری', sub: 'Round IQD totals', pin: '١٢· خڕکرنا پارێ (تەقریبی)' },
                { id: 'set-show-payment-modal', title: '١٣· پەنجەرەی پارەدان', sub: 'Payment screen modal', pin: '١٣· شاشا پارەدانێ' }
            ];
            tiles.forEach(function(tile) {
                var btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'secret-vault-tile';
                btn.setAttribute('data-vault-cb', tile.id);
                btn.innerHTML = '<span class="sv-lock"><i class="fas fa-lock"></i></span>' +
                    '<span class="sv-title">' + tile.title + '</span>' +
                    '<span class="sv-sub">' + tile.sub + '</span>' +
                    '<span class="sv-state">—</span>';
                btn.addEventListener('click', function(ev) {
                    ev.preventDefault();
                    secretVaultToggleByCheckboxId(tile.id, tile.pin);
                });
                grid.appendChild(btn);
            });
        }

        function refreshSecretVaultTiles() {
            var openLbl = (typeof t === 'function') ? t('secret_vault_unlock_open') : 'قفڵ کراوە';
            var closedLbl = (typeof t === 'function') ? t('secret_vault_unlock_closed') : 'قفڵ';
            document.querySelectorAll('.secret-vault-tile[data-vault-cb]').forEach(function(btn) {
                var id = btn.getAttribute('data-vault-cb');
                var unlocked = typeof isPremiumFeatureUnlocked === 'function' && isPremiumFeatureUnlocked(id);
                btn.classList.toggle('is-on', unlocked);
                btn.classList.toggle('is-off', !unlocked);
                var ic = btn.querySelector('.sv-lock i');
                if (ic) ic.className = unlocked ? 'fas fa-lock-open' : 'fas fa-lock';
                var st = btn.querySelector('.sv-state');
                if (st) st.textContent = unlocked ? openLbl : closedLbl;
            });
        }

        /** تەنها کردنەوە/داخستنی قفڵی بەش — چالاک/ناچالاک لە ڕێکخستن */
        function secretVaultToggleByCheckboxId(checkboxId, pinActionLabel) {
            if (hasPremiumEntitlement()) return;
            if (!posRequireSecretMenuAccessSync()) return;
            if (typeof isPremiumFeatureUnlocked !== 'function') return;
            var currentlyUnlocked = isPremiumFeatureUnlocked(checkboxId);
            var willUnlock = !currentlyUnlocked;
            // Unlock needs PIN; re-lock can be done directly by admin in secret menu.
            if (willUnlock) {
                if (typeof verifySecretPin !== 'function' || !verifySecretPin(pinActionLabel)) return;
            }
            setPremiumFeatureUnlocked(checkboxId, willUnlock);
            refreshSecretVaultTiles();
            if (typeof applyPremiumSettingsUI === 'function') applyPremiumSettingsUI();
            if (typeof enforcePremiumGatedSettingsRuntime === 'function') enforcePremiumGatedSettingsRuntime();
            if (typeof applyFabVisibility === 'function') applyFabVisibility();
            if (typeof applyManualSaleVisibility === 'function') applyManualSaleVisibility();
            if (typeof applyFeatureVisibility === 'function') applyFeatureVisibility();
            if (typeof savePrintSettings === 'function') savePrintSettings();
            if (typeof showToast === 'function') {
                showToast(willUnlock ? '✅ بەشەکە هاتە کردنەوە.' : '🔒 بەشەکە دووبارە قفڵ کرایەوە.');
            }
        }

        function renderSecretTodaySalesStats() {
            var elCount = document.getElementById('secret-today-sales-count');
            var elItems = document.getElementById('secret-today-items-sold');
            var elTotal = document.getElementById('secret-today-sales-total');
            var elHint = document.getElementById('secret-today-sales-hint');
            if (!elCount || !elItems || !elTotal) return;
            try {
                var sales = (typeof getAllSales === 'function') ? getAllSales() : (db && Array.isArray(db.sales) ? db.sales : []);
                var today = (typeof getBusinessDate === 'function') ? getBusinessDate(new Date()) : new Date().toISOString().slice(0, 10);
                var daySales = sales.filter(function(s) {
                    var dt = (typeof parseSQLDate === 'function') ? parseSQLDate(s.date || s.created_at) : new Date(s.date || s.created_at || Date.now());
                    var d = (typeof getBusinessDate === 'function') ? getBusinessDate(dt) : dt.toISOString().slice(0, 10);
                    return d === today;
                });
                var invoices = daySales.length;
                var items = daySales.reduce(function(sum, s) {
                    var arr = Array.isArray(s.items) ? s.items : [];
                    return sum + arr.reduce(function(ss, it) { return ss + (parseFloat(it.qty) || 0); }, 0);
                }, 0);
                var total = daySales.reduce(function(sum, s) { return sum + (parseFloat(s.total) || 0); }, 0);
                elCount.textContent = String(invoices);
                elItems.textContent = String(Math.round(items * 100) / 100);
                elTotal.textContent = (typeof formatCurrency === 'function') ? formatCurrency(total) : String(total);
                if (elHint) {
                    elHint.textContent = 'Business date: ' + today;
                }
            } catch (e) {
                elCount.textContent = '0';
                elItems.textContent = '0';
                elTotal.textContent = '0';
                if (elHint) elHint.textContent = '—';
            }
        }

        function openSecretMenu(skipAccessCheck) {
            if (!skipAccessCheck && !posRequireSecretMenuAccessSync()) {
                posSecretAccessEnsureThenOpen();
                return;
            }
            posSecretAccessStartSessionWatch();
            if (typeof renderSecretTodaySalesStats === 'function') renderSecretTodaySalesStats();
            if (!document.getElementById('secret-menu-custom-style')) {
                var style = document.createElement('style');
                style.id = 'secret-menu-custom-style';
                style.innerHTML = `
                    #secret-menu-modal .glass-card, #secret-menu-modal > div:not(.modal-overlay) {
                        max-width: 900px !important;
                        width: 95% !important;
                        max-height: 85vh !important;
                        overflow-y: auto !important;
                        display: grid !important;
                        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)) !important;
                        gap: 20px !important;
                        align-items: start !important;
                    }
                    #secret-menu-modal .glass-card > :first-child,
                    #secret-menu-modal > div:not(.modal-overlay) > :first-child,
                    #secret-menu-modal .btn-danger {
                        grid-column: 1 / -1 !important;
                    }
                    #secret-startup-logo-wrap { margin-bottom: 0 !important; }
                `;
                document.head.appendChild(style);
            }

            document.getElementById('secret-menu-modal').style.display = 'flex';
            document.getElementById('secret-sys-name').value = db.settings.cafeName || '';
            document.getElementById('secret-manager-pin').value = "";
            var maxStaffInp = document.getElementById('secret-max-staff-allowed');
            if (maxStaffInp && typeof getPosMaxStaffAllowed === 'function') {
                maxStaffInp.value = String(getPosMaxStaffAllowed());
            }
            if (typeof refreshSecretMaxStaffHint === 'function') refreshSecretMaxStaffHint();
            var maxCartInp = document.getElementById('secret-max-cart-tabs-allowed');
            if (maxCartInp && typeof getPosMaxCartTabsAllowed === 'function') {
                maxCartInp.value = String(getPosMaxCartTabsAllowed());
            }
            if (typeof refreshSecretMaxCartTabsHint === 'function') refreshSecretMaxCartTabsHint();
            var maxDailySalesInp = document.getElementById('secret-max-daily-sales-allowed');
            if (maxDailySalesInp && typeof getPosMaxDailySalesAllowed === 'function') {
                maxDailySalesInp.value = String(getPosMaxDailySalesAllowed());
            }
            if (typeof refreshSecretMaxDailySalesHint === 'function') refreshSecretMaxDailySalesHint();
            var maxMfrInp = document.getElementById('secret-manufacturer-slots-purchased');
            if (maxMfrInp && typeof getPosManufacturerSlotsPurchased === 'function') {
                maxMfrInp.value = String(getPosManufacturerSlotsPurchased());
            }
            if (typeof refreshSecretManufacturerSlotsHint === 'function') refreshSecretManufacturerSlotsHint();
            if (typeof refreshSecretCurrencyUi === 'function') refreshSecretCurrencyUi();
            if (typeof refreshSecretSaleIdSequence === 'function') refreshSecretSaleIdSequence();

            // Add dynamic startup logo upload to secret menu
            var modalBody = document.querySelector('#secret-menu-modal .glass-card') || document.querySelector('#secret-menu-modal > div') || document.getElementById('secret-menu-modal');
            if (modalBody && !document.getElementById('secret-startup-logo-wrap')) {
                var logoWrap = document.createElement('div');
                logoWrap.id = 'secret-startup-logo-wrap';
                logoWrap.style.padding = '15px';
                logoWrap.style.background = 'rgba(0,0,0,0.2)';
                logoWrap.style.borderRadius = '10px';
                logoWrap.style.marginBottom = '15px';
                logoWrap.style.border = '1px dashed var(--border)';
                logoWrap.innerHTML = `
                    <h4 style="margin: 0 0 10px 0; color: #38bdf8;"><i class="fas fa-image"></i> لۆگۆیێ دەستپێکێ و سیستەمی (Startup Logo)</h4>
                    <p style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 10px;">ئەڤ لۆگۆیە دێ ل شاشا دەستپێکێ و وێبسایتی دەرکەڤیت، نە ل سەر وەسڵێ.</p>
                    <input type="file" id="secret-startup-logo" accept="image/png, image/jpeg, image/jpg, image/webp" class="input-std" onchange="handleSecretStartupLogoUpload(this)">
                    <div style="text-align: center;">
                        <img id="secret-startup-logo-preview" style="max-height: 100px; max-width: 100%; margin-top: 10px; display: none; border-radius: 8px; object-fit: contain;">
                    </div>
                    <button type="button" class="btn btn-info" style="margin-top: 10px; width: 100%;" onclick="saveSecretStartupLogo()"><i class="fas fa-save"></i> پاراستنا لۆگۆیێ سیستەمی</button>
                `;
                var resetBtn = modalBody.querySelector('.btn-danger');
                if (resetBtn && resetBtn.parentNode) {
                    resetBtn.parentNode.insertBefore(logoWrap, resetBtn);
                } else {
                    modalBody.appendChild(logoWrap);
                }
            }
            
            var prev = document.getElementById('secret-startup-logo-preview');
            var currentLogo = (db.settings && db.settings.startupLogo) ? db.settings.startupLogo : (typeof localStorage !== 'undefined' ? localStorage.getItem('pos_startup_logo') : '');
            if (prev) {
                if (currentLogo) {
                    prev.src = currentLogo;
                    prev.style.display = 'inline-block';
                } else {
                    prev.style.display = 'none';
                    prev.src = '';
                }
            }
            injectSecretVaultVisualCss();
            buildSecretVaultTilesOnce();
            refreshSecretVaultTiles();
        }

        function handleSecretStartupLogoUpload(input) {
            if (!input || !input.files.length) return;
            var file = input.files[0];
            var img = new Image();
            var objectUrl = URL.createObjectURL(file);
            img.onload = function() {
                var maxW = 400, maxH = 400, w = img.width, h = img.height;
                if (w > maxW || h > maxH) {
                    if (w / maxW > h / maxH) { w = maxW; h = Math.round(img.height * maxW / img.width); } 
                    else { h = maxH; w = Math.round(img.width * maxH / img.height); }
                }
                var canvas = document.createElement('canvas'); canvas.width = w; canvas.height = h;
                canvas.getContext('2d').drawImage(img, 0, 0, w, h);
                var dataUrl = canvas.toDataURL('image/jpeg', 0.8);
                
                var prev = document.getElementById('secret-startup-logo-preview');
                if (prev) {
                    prev.src = dataUrl;
                    prev.style.display = 'inline-block';
                }
                input.dataset.pendingBase64 = dataUrl;
                URL.revokeObjectURL(objectUrl);
            };
            img.onerror = function() {
                alert("هەڵە د خاندنا وێنەی دا.");
                URL.revokeObjectURL(objectUrl);
            };
            img.src = objectUrl;
        }

        function saveSecretStartupLogo() {
            var input = document.getElementById('secret-startup-logo');
            if (!input || !input.dataset.pendingBase64) {
                alert("هیڤییە لۆگۆیەکێ هەلبژێرە بەری پاراستنێ.");
                return;
            }
            var dataUrl = input.dataset.pendingBase64;
            if (!db.settings) db.settings = {};
            db.settings.startupLogo = dataUrl;
            try { localStorage.setItem('pos_startup_logo', dataUrl); } catch(e) {}
            
            var startupLogoEl = document.getElementById('startup-logo');
            if (startupLogoEl) startupLogoEl.src = dataUrl;
            
            var mobileSyncLogo = document.getElementById('startup-mobile-modal-logo');
            if (mobileSyncLogo) mobileSyncLogo.src = dataUrl;
            
            try {
                var appName = db.settings.cafeName || "Laptop Duhok POS";
                var link = document.querySelector("link[rel~='icon']");
                if (!link) { link = document.createElement('link'); link.rel = 'icon'; document.head.appendChild(link); }
                link.href = dataUrl;
                
                var appleLink = document.querySelector("link[rel='apple-touch-icon']");
                if (!appleLink) { appleLink = document.createElement('link'); appleLink.rel = 'apple-touch-icon'; document.head.appendChild(appleLink); }
                appleLink.href = dataUrl;
                
                var manifest = {
                    "name": appName,
                    "short_name": appName,
                    "start_url": ".",
                    "display": "standalone",
                    "background_color": "#000000",
                    "theme_color": "#000000",
                    "icons": [{
                        "src": dataUrl,
                        "sizes": "192x192 512x512",
                        "type": "image/png",
                        "purpose": "any maskable"
                    }]
                };
                var manifestBlob = new Blob([JSON.stringify(manifest)], {type: 'application/json'});
                var manifestLink = document.querySelector("link[rel='manifest']");
                if (!manifestLink) { manifestLink = document.createElement('link'); manifestLink.rel = 'manifest'; document.head.appendChild(manifestLink); }
                manifestLink.href = URL.createObjectURL(manifestBlob);
            } catch(e) {}
            
            saveSettings().then(function() {
                alert("✅ لۆگۆیێ سیستەمی ب سەرکەفتیانە هاتە پاراستن.");
            }).catch(function() {
                alert("❌ هەڵە د پاراستنێ دا.");
            });
        }

        function openSystemResetConfirm() {
            var msg = "ئەرێ دڵنیایت؟ ئەڤە هەمی داتا دەسڕێتەوە (ئایتم، فرۆتن، مەخزەن، مێژوو). ناگەڕێتەوە!\n\nدڵنیای بەردەوامبوون؟";
            if (!confirm(msg)) return;
            document.getElementById('secret-reset-modal').style.display = 'flex';
            document.getElementById('secret-reset-typed').value = '';
            document.getElementById('secret-reset-typed').focus();
            toggleSystemResetButton();
        }

        function closeSystemResetConfirm() {
            document.getElementById('secret-reset-modal').style.display = 'none';
            document.getElementById('secret-reset-typed').value = '';
        }

        function toggleSystemResetButton() {
            var typed = (document.getElementById('secret-reset-typed') && document.getElementById('secret-reset-typed').value) || '';
            var btn = document.getElementById('btn-do-system-reset');
            if (btn) btn.disabled = (typed.trim().toUpperCase() !== 'RESET');
        }

        function performSystemReset() {
            if (document.getElementById('secret-reset-typed').value.trim().toUpperCase() !== 'RESET') return;
            var btn = document.getElementById('btn-do-system-reset');
            if (btn) btn.disabled = true;
            fetch('?action=system_reset', { method: 'POST', credentials: 'same-origin' })
                .then(function(r) { return r.text().then(function(t) { try { return JSON.parse(t); } catch (e) { throw new Error(t.indexOf('<!DOCTYPE') !== -1 ? 'سێرڤەر وەڵامێ HTML گەڕاندەوە (هەڵەیە). هیڤییە پەڕەی نووی بکە و دووبارە هەوڵ بدە.' : t || r.statusText); } }); })
                .then(function(data) {
                    closeSystemResetConfirm();
                    document.getElementById('secret-menu-modal').style.display = 'none';
                    if (data && data.status === 'success') {
                        alert("✅ سیستەم هاتە ڕێکخستن. هەمی داتا ژێبرین.");
                        if (typeof connectToDB === 'function') connectToDB(true);
                    } else {
                        alert("❌ " + (data && data.message ? data.message : "هەڵە"));
                    }
                })
                .catch(function(err) {
                    if (btn) btn.disabled = false;
                    alert("❌ " + (err && err.message ? err.message : "پەیوەندی یان وەڵامێ سێرڤەر"));
                });
        }

        function saveSecretSystemName() {
            const name = document.getElementById('secret-sys-name').value;
            if(name) {
                db.settings.cafeName = name;
                saveSettings();
                applyPrintSettings();
                applySystemMode();
                alert("✅ ناڤێ سیستەمی هاتە گوهۆڕین.");
            }
        }

        function refreshSecretMaxStaffHint() {
            var hint = document.getElementById('secret-max-staff-current-hint');
            if (!hint) return;
            var cur = (db && Array.isArray(db.users)) ? db.users.length : 0;
            var max = (typeof getPosMaxStaffAllowed === 'function') ? getPosMaxStaffAllowed() : 3;
            var tpl = (typeof t === 'function') ? t('secret_max_staff_status') : 'Current: {current} / {max}';
            if (!tpl || tpl === 'secret_max_staff_status') tpl = '{current} / {max}';
            hint.textContent = tpl.replace(/\{current\}/g, String(cur)).replace(/\{max\}/g, String(max));
        }

        function saveSecretMaxStaffAllowed() {
            var inp = document.getElementById('secret-max-staff-allowed');
            if (!inp) return;
            var n = parseInt(inp.value, 10);
            if (isNaN(n) || n < 1) {
                alert((typeof t === 'function') ? t('toast_error') : 'Invalid number');
                return;
            }
            if (n > 999) n = 999;
            if (!db.settings) db.settings = {};
            db.settings.maxStaffAllowed = n;
            if (typeof saveSettings === 'function') {
                saveSettings().then(function () {
                    if (typeof refreshSecretMaxStaffHint === 'function') refreshSecretMaxStaffHint();
                    if (typeof showToast === 'function') {
                        showToast((typeof t === 'function') ? t('secret_max_staff_saved') : 'Saved');
                    }
                });
            }
        }
        window.saveSecretMaxStaffAllowed = saveSecretMaxStaffAllowed;

        function refreshSecretMaxCartTabsHint() {
            var hint = document.getElementById('secret-max-cart-tabs-current-hint');
            if (!hint) return;
            var max = (typeof getPosMaxCartTabsAllowed === 'function') ? getPosMaxCartTabsAllowed() : 2;
            var tpl = (typeof t === 'function') ? t('secret_max_cart_tabs_status') : 'Allowed: {max}';
            if (!tpl || tpl === 'secret_max_cart_tabs_status') tpl = '{max}';
            hint.textContent = tpl.replace(/\{max\}/g, String(max));
        }

        function saveSecretMaxCartTabsAllowed() {
            var inp = document.getElementById('secret-max-cart-tabs-allowed');
            if (!inp) return;
            var n = parseInt(inp.value, 10);
            if (isNaN(n) || n < 1) {
                alert((typeof t === 'function') ? t('toast_error') : 'Invalid number');
                return;
            }
            if (n > POS_CART_TABS_HARD_MAX) n = POS_CART_TABS_HARD_MAX;
            if (!db.settings) db.settings = {};
            db.settings.maxCartTabsAllowed = n;
            if (typeof saveSettings === 'function') {
                saveSettings().then(function () {
                    if (typeof refreshSecretMaxCartTabsHint === 'function') refreshSecretMaxCartTabsHint();
                    if (typeof activePosTabIndex === 'number' && activePosTabIndex >= n) {
                        if (typeof switchPosTab === 'function') switchPosTab(0);
                    }
                    if (typeof renderPosTabsUI === 'function') renderPosTabsUI();
                    if (typeof showToast === 'function') {
                        showToast((typeof t === 'function') ? t('secret_max_cart_tabs_saved') : 'Saved');
                    }
                });
            }
        }
        window.saveSecretMaxCartTabsAllowed = saveSecretMaxCartTabsAllowed;

        function refreshSecretMaxDailySalesHint() {
            var hint = document.getElementById('secret-max-daily-sales-current-hint');
            if (!hint) return;
            var used = (typeof getPosDailyPaymentModalUsesCount === 'function') ? getPosDailyPaymentModalUsesCount() : 0;
            var max = (typeof getPosMaxDailySalesAllowed === 'function') ? getPosMaxDailySalesAllowed() : 5;
            var tpl = (typeof t === 'function') ? t('secret_max_daily_sales_status') : 'Today: {used} / {max}';
            if (!tpl || tpl === 'secret_max_daily_sales_status') tpl = '{used} / {max}';
            hint.textContent = tpl.replace(/\{used\}/g, String(used)).replace(/\{max\}/g, String(max));
        }

        function saveSecretMaxDailySalesAllowed() {
            var inp = document.getElementById('secret-max-daily-sales-allowed');
            if (!inp) return;
            var n = parseInt(inp.value, 10);
            if (isNaN(n) || n < 1) {
                alert((typeof t === 'function') ? t('toast_error') : 'Invalid number');
                return;
            }
            if (n > 99999) n = 99999;
            if (!db.settings) db.settings = {};
            db.settings.maxDailySalesAllowed = n;
            if (typeof saveSettings === 'function') {
                saveSettings().then(function () {
                    if (typeof refreshSecretMaxDailySalesHint === 'function') refreshSecretMaxDailySalesHint();
                    if (typeof showToast === 'function') {
                        showToast((typeof t === 'function') ? t('secret_max_daily_sales_saved') : 'Saved');
                    }
                });
            }
        }
        window.saveSecretMaxDailySalesAllowed = saveSecretMaxDailySalesAllowed;
        window.refreshSecretMaxDailySalesHint = refreshSecretMaxDailySalesHint;

        function refreshSecretSaleIdSequence() {
            var elMax = document.getElementById('secret-sale-id-max');
            var elNext = document.getElementById('secret-sale-id-next-now');
            var elInp = document.getElementById('secret-next-sale-id');
            var elPad = document.getElementById('secret-sale-id-pad');
            var elHint = document.getElementById('secret-sale-id-hint');
            if (elHint) elHint.textContent = '…';
            var url = (typeof window.posRouterUrl === 'function')
                ? window.posRouterUrl('action=get_sale_id_sequence')
                : '?action=get_sale_id_sequence';
            fetch(url, { credentials: 'same-origin', cache: 'no-store' })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (!data || data.status !== 'success') {
                        if (elHint) elHint.textContent = (data && data.message) ? data.message : 'نەهاتە خواندن';
                        return;
                    }
                    if (elMax) elMax.textContent = '#' + String(data.max_id || 0);
                    if (elNext) elNext.textContent = '#' + String(data.next_id || 1);
                    if (elInp) {
                        elInp.min = String(data.min_allowed || 1);
                        elInp.value = String(data.next_id || data.min_allowed || 1);
                    }
                    if (elPad && data.display_pad) elPad.value = String(data.display_pad);
                    if (elHint) {
                        elHint.textContent = 'کێمترین داهاتوو: #' + String(data.min_allowed || 1)
                            + ' — وەک ١٠٠٠ بنڤیسە ئەگەر دڤێت ژ ١٠٠٠ دەستپێ بکەت.';
                    }
                })
                .catch(function() {
                    if (elHint) elHint.textContent = 'پەیوەندی سەرنەکەوت';
                });
        }
        window.refreshSecretSaleIdSequence = refreshSecretSaleIdSequence;

        function saveSecretNextSaleId() {
            var inp = document.getElementById('secret-next-sale-id');
            var padEl = document.getElementById('secret-sale-id-pad');
            if (!inp) return;
            var nextId = parseInt(inp.value, 10);
            var pad = padEl ? parseInt(padEl.value, 10) : 6;
            if (isNaN(nextId) || nextId < 1) {
                alert('ژمارا داهاتوو دڤێت ١ یان مەزنتر بیت.');
                return;
            }
            if (isNaN(pad) || pad < 1) pad = 6;
            if (pad > 10) pad = 10;
            if (!confirm('وەسڵێ داهاتوو دێ بیتە #' + nextId + '؟\n\nوەسڵێن کەڤن ناگوهۆڕن.')) return;
            var fd = new FormData();
            fd.append('action', 'secret_set_next_sale_id');
            fd.append('next_sale_id', String(nextId));
            fd.append('display_pad', String(pad));
            fetch('?action=secret_set_next_sale_id', { method: 'POST', body: fd, credentials: 'same-origin' })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (!data || data.status !== 'success') {
                        alert((data && data.message) ? data.message : 'پاراستن سەرنەکەوت');
                        return;
                    }
                    if (!db.settings) db.settings = {};
                    db.settings.saleIdDisplayPad = pad;
                    if (typeof saveSettings === 'function') {
                        try { saveSettings().catch(function() {}); } catch (_eS) {}
                    }
                    if (typeof showToast === 'function') {
                        showToast(data.message || ('وەسڵێ داهاتوو: #' + nextId), 'success');
                    } else {
                        alert(data.message || ('OK #' + nextId));
                    }
                    refreshSecretSaleIdSequence();
                })
                .catch(function() {
                    alert('پەیوەندی سەرنەکەوت');
                });
        }
        window.saveSecretNextSaleId = saveSecretNextSaleId;

        function refreshSecretManufacturerSlotsHint() {
            var hint = document.getElementById('secret-manufacturer-slots-current-hint');
            if (!hint) return;
            var used = (typeof getPosManufacturerSlotsUsed === 'function') ? getPosManufacturerSlotsUsed() : 0;
            var max = (typeof getPosMaxManufacturersAllowed === 'function') ? getPosMaxManufacturersAllowed() : 0;
            var tpl = (typeof t === 'function') ? t('secret_mfr_slots_status') : '{used} / {max}';
            if (!tpl || tpl === 'secret_mfr_slots_status') tpl = '{used} / {max}';
            hint.textContent = tpl.replace(/\{used\}/g, String(used)).replace(/\{max\}/g, String(max >= 9999 ? '∞' : max));
        }

        function saveSecretManufacturerSlotsPurchased() {
            var inp = document.getElementById('secret-manufacturer-slots-purchased');
            if (!inp) return;
            var n = parseInt(inp.value, 10);
            if (isNaN(n) || n < 0) {
                alert((typeof t === 'function') ? t('toast_error') : 'Invalid number');
                return;
            }
            if (n > 999) n = 999;
            if (!db.settings) db.settings = {};
            db.settings.manufacturerSlotsPurchased = n;
            if (typeof saveSettings === 'function') {
                saveSettings().then(function () {
                    if (typeof refreshSecretManufacturerSlotsHint === 'function') refreshSecretManufacturerSlotsHint();
                    if (typeof renderManufacturers === 'function') renderManufacturers();
                    if (typeof applyProductFormPremiumFeatureFields === 'function') applyProductFormPremiumFeatureFields();
                    if (typeof showToast === 'function') {
                        showToast((typeof t === 'function') ? t('secret_mfr_slots_saved') : 'Saved');
                    }
                });
            }
        }
        window.saveSecretManufacturerSlotsPurchased = saveSecretManufacturerSlotsPurchased;
        window.refreshSecretManufacturerSlotsHint = refreshSecretManufacturerSlotsHint;

        function refreshSecretCurrencyUi() {
            var hint = document.getElementById('secret-currency-current-hint');
            var rateInp = document.getElementById('secret-exchange-rate');
            var btnIqd = document.getElementById('secret-currency-btn-iqd');
            var btnUsd = document.getElementById('secret-currency-btn-usd');
            var mode = (db && db.settings && db.settings.currencyMode) ? String(db.settings.currencyMode).toUpperCase() : 'IQD';
            if (mode !== 'USD') mode = 'IQD';
            if (rateInp && db && db.settings) {
                rateInp.value = String(Math.round(db.settings.usdRate || 150000));
            }
            if (typeof syncExchangeRateLockUI === 'function') syncExchangeRateLockUI();
            if (btnIqd) {
                btnIqd.style.outline = mode === 'IQD' ? '2px solid #fbbf24' : '';
                btnIqd.style.fontWeight = mode === 'IQD' ? 'bold' : '';
            }
            if (btnUsd) {
                btnUsd.style.outline = mode === 'USD' ? '2px solid #4ade80' : '';
                btnUsd.style.fontWeight = mode === 'USD' ? 'bold' : '';
            }
            if (hint) {
                var rate = (db && db.settings) ? Math.round(db.settings.usdRate || 150000) : 150000;
                var tpl = (typeof t === 'function') ? t('secret_currency_status') : 'Active: {mode} · 100$ = {rate} IQD';
                if (!tpl || tpl === 'secret_currency_status') tpl = '{mode} · 100$ = {rate}';
                hint.textContent = tpl.replace(/\{mode\}/g, mode).replace(/\{rate\}/g, String(rate));
            }
        }
        window.refreshSecretCurrencyUi = refreshSecretCurrencyUi;

        function secretPostCurrencyMode(mode, rateBundle) {
            var fd = new FormData();
            fd.append('action', 'secret_set_currency_mode');
            fd.append('currencyMode', mode);
            if (rateBundle != null && rateBundle >= 10000) {
                fd.append('rate_bundle', String(rateBundle));
            }
            return fetch('?action=secret_set_currency_mode', { method: 'POST', body: fd, credentials: 'same-origin' })
                .then(function (res) { return res.json(); });
        }

        function setSecretCurrencyMode(mode) {
            if (!db || !db.settings) return;
            mode = (String(mode).toUpperCase() === 'USD') ? 'USD' : 'IQD';
            var rateInp = document.getElementById('secret-exchange-rate');
            var rawBundle = rateInp ? parseInt(rateInp.value, 10) : Math.round(db.settings.usdRate || 150000);
            var bundle = (typeof normalizeUsdBundleRateFromInput === 'function')
                ? normalizeUsdBundleRateFromInput(rawBundle)
                : ((typeof normalizeUsdBundleRate === 'function') ? normalizeUsdBundleRate(rawBundle) : rawBundle);
            if (!isFinite(bundle) || bundle < 10000) bundle = Math.round(db.settings.usdRate || 150000);
            if (mode === 'IQD') bundle = Math.round(db.settings.usdRate || 150000);
            secretPostCurrencyMode(mode, bundle).then(function (data) {
                if (!data || data.status !== 'success') {
                    alert('❌ ' + ((data && data.message) ? data.message : 'Error'));
                    return;
                }
                db.settings.currencyMode = data.currencyMode || mode;
                if (data.usdRate) db.settings.usdRate = data.usdRate;
                if (typeof refreshSecretCurrencyUi === 'function') refreshSecretCurrencyUi();
                if (typeof refreshAfterCurrencySettingsSave === 'function') refreshAfterCurrencySettingsSave();
                if (typeof showToast === 'function') {
                    showToast('✅ ' + ((typeof t === 'function') ? t('secret_currency_saved') : 'Currency saved'));
                } else {
                    alert('✅ ' + mode);
                }
            }).catch(function (err) {
                alert('❌ ' + (err && err.message ? err.message : err));
            });
        }
        window.setSecretCurrencyMode = setSecretCurrencyMode;

        function saveSecretExchangeRateOnly() {
            if (!db || !db.settings) return;
            if (typeof isIqdExchangeRateLocked === 'function' && isIqdExchangeRateLocked()) {
                if (typeof showToast === 'function') showToast((typeof t === 'function') ? t('exchange_rate_iqd_locked') : 'Locked', true);
                return;
            }
            var rateInp = document.getElementById('secret-exchange-rate');
            var rawBundle = rateInp ? parseInt(rateInp.value, 10) : 0;
            var bundle = (typeof normalizeUsdBundleRateFromInput === 'function')
                ? normalizeUsdBundleRateFromInput(rawBundle)
                : ((typeof normalizeUsdBundleRate === 'function') ? normalizeUsdBundleRate(rawBundle) : rawBundle);
            if (!isFinite(bundle) || bundle < 10000) {
                alert((typeof t === 'function') ? t('toast_error') : 'Invalid rate');
                return;
            }
            var mode = String(db.settings.currencyMode || 'IQD').toUpperCase();
            if (mode !== 'USD') mode = 'IQD';
            secretPostCurrencyMode(mode, bundle).then(function (data) {
                if (!data || data.status !== 'success') {
                    alert('❌ ' + ((data && data.message) ? data.message : 'Error'));
                    return;
                }
                if (data.usdRate) db.settings.usdRate = data.usdRate;
                if (typeof refreshSecretCurrencyUi === 'function') refreshSecretCurrencyUi();
                if (typeof refreshAfterCurrencySettingsSave === 'function') refreshAfterCurrencySettingsSave();
                if (typeof showToast === 'function') {
                    showToast('✅ ' + ((typeof t === 'function') ? t('secret_currency_rate_saved') : 'Rate saved'));
                }
            }).catch(function (err) {
                alert('❌ ' + (err && err.message ? err.message : err));
            });
        }
        window.saveSecretExchangeRateOnly = saveSecretExchangeRateOnly;

        function saveSecretManagerPin() {
            const newPin = document.getElementById('secret-manager-pin').value;
            if(newPin) {
                const admin = db.users.find(u => u.id === 1);
                if(admin) {
                    const formData = new FormData();
                    formData.append('action', 'update_user');
                    formData.append('id', admin.id);
                    formData.append('name', admin.name);
                    formData.append('pin', newPin);
                    formData.append('role', 'admin');
                    formData.append('rate', admin.hourlyRate);
                    formData.append('permissions', JSON.stringify(admin.permissions));

                    fetch('?action=update_user', { method: 'POST', body: formData })
                    .then(res => res.json())
                    .then(data => {
                        if(data.status === 'success') alert("✅ ژمارا نهێنی یا ڕێڤەبەری (Manager) هاتە گوهۆڕین.");
                        else alert('❌ ' + (data.message || 'هەڵە'));
                    })
                    .catch(err => alert('❌ هەڵە: ' + (err.message || 'پەیوەندی')));
                }
            }
        }

        function changeSecretPin() {
            const currentAttempt = document.getElementById('secret-current-pin').value;
            const newPin = document.getElementById('secret-new-pin').value;
            const actualPin = (db.settings && db.settings.settingsPin) ? db.settings.settingsPin : "2026";

            if (currentAttempt !== actualPin) {
                alert("❌ ژمارا نهێنی یا نوکە خەلەتە! (Current PIN is incorrect!)");
                return;
            }

            if(newPin && newPin.length >= 4) {
                db.settings.settingsPin = newPin;
                saveSettings();
                alert("✅ ژمارا نهێنی یا ستینگی (Secret PIN) هاتە گوهۆڕین.");
                document.getElementById('secret-current-pin').value = "";
                document.getElementById('secret-new-pin').value = "";
            } else {
                alert("❌ ژمارا نهێنی دڤێت کێمتر نەبیت ژ ٤ ژماران.");
            }
        }

        function toggleSidebar() {
            const sb = document.querySelector('.sidebar');
            const ov = document.getElementById('sidebar-overlay');
            sb.classList.toggle('open');
            // Overlay logic removed as sidebar is now full screen overlay itself
        }

        function openZakatModal() {
            const modal = document.getElementById('zakat-modal');
            if (!modal) return;
            updateZakatModal();
            modal.style.display = 'flex';
            document.querySelector('.sidebar').classList.remove('open');
        }

        function updateZakatModal() {
            let totalAssets = 0;
            if (db && db.products) {
                db.products.forEach(p => {
                    if (p.trackStock && p.qty > 0) {
                        const itemValue = (p.cost || 0) * (p.qty || 0);
                        if (itemValue <= 100000000) totalAssets += itemValue;
                    }
                });
            }
            let totalReceivables = 0;
            var roundM = typeof roundMoney === 'function' ? roundMoney : function(x){ return Math.round(Number(x)); };
            if (db && db.customers) db.customers.forEach(c => totalReceivables = roundM(totalReceivables + (parseFloat(c.balance) || 0)));
            if (db && db.users) db.users.forEach(u => totalReceivables = roundM(totalReceivables + (parseFloat(u.balance) || 0)));
            let totalLiabilities = 0;
            if (db && db.companies) db.companies.forEach(c => { if (c.balance > 0) totalLiabilities = roundM(totalLiabilities + (parseFloat(c.balance) || 0)); });
            const zakatNet = totalAssets + totalReceivables - totalLiabilities;
            const zakatAmount = Math.max(0, zakatNet) * 0.025;
            const set = (id, val) => { const el = document.getElementById(id); if (el) el.innerText = typeof val === 'number' ? formatCurrency(val) : val; };
            set('zakat-modal-inventory', totalAssets);
            set('zakat-modal-receivables', totalReceivables);
            set('zakat-modal-liabilities', totalLiabilities);
            set('zakat-modal-net', zakatNet);
            set('zakat-modal-amount', zakatAmount);
        }

        // --- PROFESSIONAL BEEP SOUND (Optimized) ---
        let globalAudioCtx = null;
        
        // Unlock Audio Context on first user interaction (Fixes silent first scan)
        document.addEventListener('click', () => {
            if (globalAudioCtx && globalAudioCtx.state === 'suspended') globalAudioCtx.resume();
        }, { once: true });

        function playBeep() {
            var viewPos = document.getElementById('view-pos');
            if (viewPos && viewPos.classList.contains('active')) return;
            setTimeout(function () {
                try {
                    if (!globalAudioCtx) globalAudioCtx = new (window.AudioContext || window.webkitAudioContext)();
                    if (globalAudioCtx.state === 'suspended') globalAudioCtx.resume();
                    const osc = globalAudioCtx.createOscillator();
                    const gain = globalAudioCtx.createGain();
                    osc.connect(gain); gain.connect(globalAudioCtx.destination);
                    osc.type = "sine"; osc.frequency.value = 1200;
                    gain.gain.value = 0.1;
                    osc.start(); setTimeout(function () { try { osc.stop(); } catch (_eStop) {} }, 100);
                } catch(e) {}
            }, 0);
        }

        // --- BREADCRUMB (شريط المسار الذكي) ---
        const BREADCRUMB_LABELS = {
            'menu': 'لیستا سەرەکی',
            'dash': 'داشبۆرد', 'tables': 'مێز (Carts)', 'pos': 'فرۆتن (POS)', 'returns': 'زڤڕاندن', 'returns-new': 'زڤڕاندن', 'debt': 'کریار',
            'companies': 'کۆمپانیا', 'purchase': 'کڕین', 'purchase-returns': 'زڤراندنا کڕینێ', 'warehouse': 'مەخزەن', 'warehouse-locations': 'کۆگاکان', 'warehouse-transfers': 'گواستنەوە', 'warehouse-categories': 'پۆلینکرن', 'warehouse-printers': 'تابیعە / پرینتەر', 'warehouse-stocktake': 'جەردا مەودایێ', 'warehouse-movements': 'لڤین و هویرکاری', 'warehouse-suppliers': 'دابینکەران', 'warehouse-reports': 'ڕاپۆرتی مەخزەن', 'stock-card': 'لڤین و هویرکاری', 'products': 'ئایتم', 'delivery': 'گەهاندن',
            'expenses': 'مەزاختن', 'waste': 'تەلەف', 'recipes': 'ڕەچەتە', 'shop-ai': 'یاریدەدەری AI',
            'calendar': 'شاشا سەرەکی', 'notifications': 'ئاگەهدارکرن', 'staff': 'ناڤەندێ کارمەندان', 'settings': 'ڕێکخستن', 'print-design': 'ڕێکخستنێن چاپی'
        };
        const BREADCRUMB_ICONS = {
            'home': 'fa-home',
            'menu': 'fa-bars',
            'dash': 'fa-chart-line', 'tables': 'fa-th-large', 'pos': 'fa-cash-register', 'returns': 'fa-undo-alt', 'returns-new': 'fa-exchange-alt', 'debt': 'fa-hand-holding-usd',
            'companies': 'fa-building', 'purchase': 'fa-shopping-basket', 'purchase-returns': 'fa-undo', 'warehouse': 'fa-warehouse', 'warehouse-locations': 'fa-store', 'warehouse-transfers': 'fa-dolly', 'warehouse-categories': 'fa-layer-group', 'warehouse-printers': 'fa-print', 'warehouse-stocktake': 'fa-clipboard-check', 'warehouse-movements': 'fa-arrows-alt-v', 'warehouse-suppliers': 'fa-truck-loading', 'warehouse-reports': 'fa-chart-bar', 'stock-card': 'fa-id-card', 'products': 'fa-tags', 'delivery': 'fa-shipping-fast',
            'expenses': 'fa-wallet', 'waste': 'fa-trash-alt', 'recipes': 'fa-utensils', 'shop-ai': 'fa-robot',
            'calendar': 'fa-chart-pie', 'notifications': 'fa-bell', 'zakat': 'fa-hand-holding-heart',
            'staff': 'fa-user-tie', 'settings': 'fa-cog', 'print-design': 'fa-palette', 'print-history': 'fa-history', 'access-denied': 'fa-lock'
        };
        /** i18n key for nav labels (breadcrumb, sidebar, main nav); matches LANGS entries (nav_* vs bc_*). */
        function getNavLabelI18nKey(id) {
            if (id === 'returns') id = 'returns-new';
            if (id === 'menu') return 'bc_menu';
            if (id === 'purchase' || id === 'purchase-returns' || id === 'warehouse-locations' || id === 'warehouse-transfers' || id === 'warehouse-categories' || id === 'warehouse-printers' || id === 'warehouse-stocktake' || id === 'warehouse-movements' || id === 'warehouse-suppliers' || id === 'warehouse-reports' || id === 'stock-card') {
                return 'bc_' + id.replace(/-/g, '_');
            }
            return 'nav_' + id.replace(/-/g, '_');
        }
        function getBreadcrumbLabel(id) {
            var key = getNavLabelI18nKey(id);
            return (typeof t === 'function' && window.LANGS && (window.LANGS.badini[key] || window.LANGS.ar[key])) ? t(key) : (BREADCRUMB_LABELS[id] || id);
        }
        /** Markup for a nav label: data-i18n only when both language maps define the key (avoids showing raw keys). */
        function navLabelSpanHtml(id, label) {
            var k = getNavLabelI18nKey(id);
            if (id === 'tables' && typeof getBreadcrumbLabel === 'function') {
                try {
                    if (String(label) !== String(getBreadcrumbLabel('tables'))) return '<span>' + escapeHtml(label) + '</span>';
                } catch (eTbl) {}
            }
            if (window.LANGS && (window.LANGS.badini[k] || window.LANGS.ar[k])) {
                return '<span data-i18n="' + escapeHtml(k) + '">' + escapeHtml(label) + '</span>';
            }
            return '<span>' + escapeHtml(label) + '</span>';
        }
        function getBreadcrumbIcon(id) {
            var mode = (db && db.settings && db.settings.systemMode) ? db.settings.systemMode : 'general';
            var profile = (typeof getBusinessProfile === 'function') ? getBusinessProfile(mode) : null;
            if (profile && profile.icons && profile.icons[id]) return profile.icons[id];
            return BREADCRUMB_ICONS[id] || 'fa-circle';
        }
        function isBreadcrumbVisible() { return localStorage.getItem('pos_breadcrumb_visible') !== 'false'; }
        function applyBreadcrumbVisibility() {
            const bar = document.getElementById('breadcrumb-bar');
            if (!bar) return;
            bar.style.display = isBreadcrumbVisible() ? 'flex' : 'none';
        }
        function toggleBreadcrumbVisibility() {
            try {
                const cb = document.getElementById('set-show-breadcrumb');
                if (cb) localStorage.setItem('pos_breadcrumb_visible', cb.checked ? 'true' : 'false');
                applyBreadcrumbVisibility();
            } catch(e) {}
        }
        function syncBreadcrumbCheckboxFromStorage() {
            try {
                const cb = document.getElementById('set-show-breadcrumb');
                if (cb) cb.checked = isBreadcrumbVisible();
            } catch(e) {}
        }
        function renderBreadcrumb() {
            const bar = document.getElementById('breadcrumb-bar');
            const topBar = document.getElementById('top-header-bar');
            if (!bar) return;
            if (typeof getBreadcrumbLabel === 'function') {
                breadcrumbStack.forEach(function(b) {
                    if (b && b.id) b.label = getBreadcrumbLabel(b.id);
                });
            }
            if (topBar) topBar.style.display = 'flex';
            if (!isBreadcrumbVisible()) { bar.style.display = 'none'; return; }
            bar.style.display = 'flex';
            if (breadcrumbStack.length === 0) { bar.innerHTML = ''; return; }
            var visible = breadcrumbStack.map(function(item, i) { return { item: item, i: i }; }).filter(function(x) { return x.item.id !== 'zakat'; });
            bar.innerHTML = visible.map(function(x, j) {
                var item = x.item, i = x.i;
                var isActive = i === currentBreadcrumbIndex;
                var sep = j < visible.length - 1 ? '<span class="breadcrumb-sep">›</span>' : '';
                var icon = item.icon || getBreadcrumbIcon(item.id);
                var removeBtn = i === 0 ? '' : '<span class="breadcrumb-remove" onclick="event.stopPropagation(); breadcrumbRemove(' + i + ')" title="ژێبرن ژ ڕێرەوی">×</span>';
                return '<span class="breadcrumb-item ' + (isActive ? 'active' : '') + '" data-index="' + i + '" onclick="breadcrumbGoTo(' + i + ')">' + removeBtn + '<i class="fas ' + icon + '" style="margin-left:6px; opacity:0.9;"></i>' + escapeHtml(item.label) + '</span>' + sep;
            }).join('');
        }
        function breadcrumbGoTo(index) {
            if (index < 0 || index >= breadcrumbStack.length) return;
            currentBreadcrumbIndex = index;
            nav(breadcrumbStack[index].id, true);
            renderBreadcrumb();
        }
        function getRightNavClickHandler(id) {
            if (id === 'settings') return 'handleSettingsNavClick()';
            if (id === 'returns-new') return 'openReturnsOptionsModal(event)';
            if (id === 'pos') return 'openPosOptionsModal(event)';
            if (id === 'purchase') return 'openPurchaseOptionsModal(event)';
            if (id === 'purchase-returns') return 'openPurchaseReturnsOptionsModal(event)';
            if (id === 'warehouse') return "if(typeof canUseMultiWarehouse==='function'&&canUseMultiWarehouse()&&typeof openWarehouseOptionsModal==='function'){openWarehouseOptionsModal(event);}else{nav('warehouse');}";
            if (id === 'companies') return "window._companyProfileDefaultTab='inventory'; nav('companies')";
            return "nav('" + id + "')";
        }
        function normalizeViewKey(id) {
            if (!id) return '';
            return (id && id.startsWith('warehouse-')) ? 'warehouse' : id;
        }
        function canAccessView(id) {
            var key = normalizeViewKey(id);
            if (!key || key === 'home' || key === 'menu' || key === 'dash' || key === 'access-denied') return true;
            if (!currentUser) return false;
            if (currentUser.role === 'admin') return true;
            var reqPerm = (typeof VIEW_TO_PERM !== 'undefined') ? VIEW_TO_PERM[key] : undefined;
            if (reqPerm === undefined || reqPerm === null || reqPerm === '') return false;
            return (typeof hasPermission === 'function') ? hasPermission(reqPerm) : false;
        }
        function getHomeHiddenIds() {
            try { return JSON.parse(localStorage.getItem('pos_home_hidden_ids') || '[]'); } catch(e) { return []; }
        }
        function setHomeHiddenIds(arr) { try { localStorage.setItem('pos_home_hidden_ids', JSON.stringify(arr)); } catch(e) {} }
        function getHomeExtraShortcutIds() {
            try { 
                var ids = JSON.parse(localStorage.getItem('pos_home_extra_shortcut_ids') || '[]'); 
                if (!Array.isArray(ids)) return [];
                var validExtras = ['pos-sales-screen', 'returns-history', 'sales-history', 'purchase-history', 'companies-inventory'];
                return ids.filter(function(id) { return validExtras.indexOf(id) >= 0; });
            } catch(e) { return []; }
        }
        function setHomeExtraShortcutIds(arr) { try { localStorage.setItem('pos_home_extra_shortcut_ids', JSON.stringify(arr)); } catch(e) {} }
        function getHomeShortcutOrder() {
            try { return JSON.parse(localStorage.getItem('pos_home_shortcut_order') || '[]'); } catch(e) { return []; }
        }
        function setHomeShortcutOrder(arr) { try { localStorage.setItem('pos_home_shortcut_order', JSON.stringify(arr)); } catch(e) {} }
        function getHomeMainOrderIds() {
            try { return getMainNavOrder(); } catch (e) { return []; }
        }
        function isMainShortcutId(id) {
            return getHomeMainOrderIds().indexOf(id) >= 0;
        }
        function getHomeShortcutClickHandler(id) {
            if (id === 'settings') return 'handleSettingsNavClick()';
            if (id === 'pos') return "if(db && db.settings && db.settings.showTables !== true) { openDirectPOS(); } else { nav('pos'); }";
            if (id === 'returns-new') return "nav('returns-new')";
            if (id === 'purchase') return "nav('purchase')";
            if (id === 'purchase-returns') return "nav('purchase-returns')";
            if (id === 'companies') return "window._companyProfileDefaultTab='inventory'; nav('companies')";
            return "nav('" + id + "')";
        }
        function reorderBySavedOrder(ids) {
            var order = getHomeShortcutOrder();
            if (!Array.isArray(order) || !order.length) return ids.slice();
            var setIds = new Set(ids);
            var out = [];
            order.forEach(function(id) {
                if (setIds.has(id) && out.indexOf(id) < 0) out.push(id);
            });
            ids.forEach(function(id) {
                if (out.indexOf(id) < 0) out.push(id);
            });
            setHomeShortcutOrder(out.slice());
            return out;
        }
        function moveIdBefore(list, sourceId, targetId) {
            if (!sourceId || !targetId || sourceId === targetId) return list.slice();
            var arr = list.slice();
            var sIdx = arr.indexOf(sourceId);
            var tIdx = arr.indexOf(targetId);
            if (sIdx < 0 || tIdx < 0) return arr;
            arr.splice(sIdx, 1);
            tIdx = arr.indexOf(targetId);
            arr.splice(tIdx, 0, sourceId);
            return arr;
        }
        function getShortcutDefinition(shortcutId) {
            var tf = (typeof t === 'function');
            var map = {
                'pos-sales-screen': { id: 'pos-sales-screen', label: tf ? t('home_shortcut_pos_screen') : 'شاشا فرۆتنێ', icon: 'fa-shopping-cart', onclick: "if(db && db.settings && db.settings.showTables !== true) { openDirectPOS(); } else { nav('pos'); }" },
                'returns-new': { id: 'returns-new', label: tf ? t('nav_returns_new') : 'زڤڕاندن', icon: 'fa-undo-alt', onclick: "nav('returns-new')" },
                'returns-history': { id: 'returns-history', label: tf ? t('returns_history_title') : 'مێژوویا زڤڕاندنێ', icon: 'fa-history', onclick: 'openReturnsHistoryOption()' },
                'sales-history': { id: 'sales-history', label: tf ? t('home_shortcut_sales_history') : 'مێژوویا فرۆتنێ', icon: 'fa-file-invoice-dollar', onclick: 'openSalesHistoryFromReturnsPrompt()' },
                'purchase-history': { id: 'purchase-history', label: tf ? t('popover_history_purchase') : 'مێژوویا کڕینێ', icon: 'fa-history', onclick: 'openPurchaseHistoryCompanyModal(event)' },
                'companies-inventory': { id: 'companies-inventory', label: tf ? t('nav_companies') : 'کۆمپانیا', icon: 'fa-building', onclick: "window._companyProfileDefaultTab='inventory'; nav('companies')" }
            };
            if (map[shortcutId]) return map[shortcutId];
            // Fallback: any regular nav section id (main or sub view ids).
            var label = typeof getBreadcrumbLabel === 'function' ? getBreadcrumbLabel(shortcutId) : shortcutId;
            var icon = typeof getBreadcrumbIcon === 'function' ? getBreadcrumbIcon(shortcutId) : 'fa-link';
            // Home shortcuts must be direct links (no popover/dropdown behavior).
            var onclick = getHomeShortcutClickHandler(shortcutId);
            return { id: shortcutId, label: label, icon: icon, onclick: onclick };
        }
        function getHomeCardZone(navId) {
            var mode = (db && db.settings && db.settings.systemMode) ? db.settings.systemMode : 'general';
            if (navId === 'recipes' && (mode === 'market' || mode === 'mobile' || mode === 'stationery' || mode === 'company' || mode === 'jewelry')) {
                return 'stock';
            }
            var map = {
                dash: 'core',
                tables: 'sales', pos: 'sales', debt: 'sales', 'returns-new': 'sales', 'pos-sales-screen': 'sales',
                products: 'catalog',
                warehouse: 'stock', purchase: 'stock', 'purchase-returns': 'stock', 'purchase-history': 'stock',
                companies: 'trade', delivery: 'trade', 'companies-inventory': 'trade',
                recipes: 'kitchen', waste: 'kitchen',
                expenses: 'finance',
                reports: 'insights', 'shop-ai': 'insights',
                calendar: 'ops', notifications: 'ops',
                settings: 'system', 'print-design': 'system', 'print-history': 'system',
                'returns-history': 'insights', 'sales-history': 'insights'
            };
            return map[navId] || 'ops';
        }

        function normalizeHomeNavId(navId) {
            if (navId === 'returns') return 'returns-new';
            return navId || 'default';
        }
        function renderHomeSimpleIcon(iconClass, navId) {
            var ic = String(iconClass || 'fa-circle').trim();
            ic = ic.replace(/^fa[sbrl]\s+/, '');
            if (ic.indexOf('fa-') !== 0) ic = 'fa-' + ic;
            var nid = typeof normalizeHomeNavId === 'function' ? normalizeHomeNavId(navId) : navId;
            var simpleMap = {
                pos: 'fa-cart-plus',
                'pos-sales-screen': 'fa-cart-plus',
                debt: 'fa-book-open',
                companies: 'fa-building',
                'companies-inventory': 'fa-building',
                purchase: 'fa-shopping-cart',
                'purchase-returns': 'fa-undo',
                delivery: 'fa-truck',
                calendar: 'fa-calendar-alt'
            };
            if (simpleMap[nid]) ic = simpleMap[nid];
            return '<span class="quick-access-drag-handle home-card__icon-slot" data-quick-access-drag-handle="true" data-quick-access-origin="home" data-i18n-title="qa_drag_home_title">' +
                '<span class="home-icon-simple" aria-hidden="true"><i class="fas ' + ic + '"></i></span></span>';
        }
        function wrapHomeCardLabel(html) {
            if (!html || html.indexOf('home-card__label') >= 0) return html;
            if (html.indexOf('<span') === 0) return html.replace('<span', '<span class="home-card__label"');
            return '<span class="home-card__label">' + html + '</span>';
        }
        function isAllowedQuickAccessNavId(navId) {
            if (!navId) return false;
            var validExtras = ['pos-sales-screen', 'returns-history', 'sales-history', 'purchase-history', 'companies-inventory'];
            if (validExtras.indexOf(navId) >= 0) return true;
            return (typeof isMainShortcutId === 'function') ? isMainShortcutId(navId) : false;
        }

        function moveShortcutToMainMenu(navId) {
            if (!isAllowedQuickAccessNavId(navId)) return;
            setHomeIconVisibility(navId, false);
            if (typeof setMainNavItemVisible === 'function') setMainNavItemVisible(navId, true);
            if (typeof showToast === 'function') {
                showToast((typeof t === 'function' ? t('qa_moved_to_menu') : 'چوو بۆ مێنیۆی سەرەوە'), 'success');
            }
        }
        window.moveShortcutToMainMenu = moveShortcutToMainMenu;

        function renderHomeShortcutCard(def, reqPerm) {
            var zone = typeof getHomeCardZone === 'function' ? getHomeCardZone(def.id) : 'ops';
            var labelHtml = wrapHomeCardLabel(typeof navLabelSpanHtml === 'function' ? navLabelSpanHtml(def.id, def.label) : ('<span class="home-card__label">' + escapeHtml(def.label) + '</span>'));
            var cardClick = 'if(window._posShortcutDragActive||window._posShortcutDidDrag)return; ' + def.onclick;
            return '<div class="home-card home-card--simple home-card--qa-draggable" draggable="true" data-quick-access-drag-handle="true" data-quick-access-origin="home" data-home-zone="' + escapeHtml(zone) + '" data-nav="' + escapeHtml(def.id) + '" data-perm="' + (reqPerm || '') + '" onclick="' + cardClick + '">' +
                renderHomeSimpleIcon(def.icon, def.id) +
                labelHtml + '</div>';
        }
        function toggleHomeIconVisibility(sectionId) {
            var hidden = getHomeHiddenIds();
            var idx = hidden.indexOf(sectionId);
            if (idx >= 0) hidden.splice(idx, 1); else hidden.push(sectionId);
            setHomeHiddenIds(hidden);
            var activeWs = document.querySelector('.workspace.active');
            if (activeWs && activeWs.id === 'view-home') renderHomeView();
        }

        // Drag & Drop: explicitly show/hide an item in the Home (Quick Access) grid.
        function setHomeIconVisibility(sectionId, visible) {
            var hidden = getHomeHiddenIds();
            var idx = hidden.indexOf(sectionId);
            var extras = getHomeExtraShortcutIds();
            var extraIdx = extras.indexOf(sectionId);
            var isMain = isMainShortcutId(sectionId);
            var order = getHomeShortcutOrder();
            var orderIdx = order.indexOf(sectionId);
            if (visible) {                
                if (isMain) {
                    if (idx >= 0) hidden.splice(idx, 1);
                } else {
                    // Sub-menu shortcut: store as explicit extra card.
                    if (extraIdx < 0) extras.push(sectionId);
                }
                if (orderIdx < 0) order.push(sectionId);
            } else {
                if (isMain) {
                    if (idx < 0) hidden.push(sectionId);
                } else {
                    if (extraIdx >= 0) extras.splice(extraIdx, 1);
                }
                if (orderIdx >= 0) order.splice(orderIdx, 1);
            }
            setHomeHiddenIds(hidden);
            setHomeExtraShortcutIds(extras);
            setHomeShortcutOrder(order);
            if (!visible && typeof setMainNavItemVisible === 'function') {
                setMainNavItemVisible(sectionId, true);
            }
            renderHomeView();
        }

        function clearQuickAccessDropHighlight() {
            ['home-grid-container', 'right-sidebar-nav', 'right-sidebar', 'main-nav'].forEach(function (id) {
                var el = document.getElementById(id);
                if (el) el.classList.remove('quick-access-drop-active');
            });
        }

        function getQuickAccessDropZone(target) {
            if (!target || !target.closest) return null;
            if (target.closest('#home-grid-container')) return 'home';
            if (target.closest('#main-nav, #right-sidebar-nav, #right-sidebar')) return 'menu';
            return null;
        }

        function highlightQuickAccessDropZone(zone, target) {
            clearQuickAccessDropHighlight();
            var el = null;
            if (zone === 'home') {
                el = document.getElementById('home-grid-container');
            } else if (target && target.closest) {
                if (target.closest('#main-nav')) el = document.getElementById('main-nav');
                else if (target.closest('#right-sidebar-nav')) el = document.getElementById('right-sidebar-nav');
                else if (target.closest('#right-sidebar')) el = document.getElementById('right-sidebar');
            }
            if (el) el.classList.add('quick-access-drop-active');
        }

        function applyShortcutDrop(zone, navId, origin, targetEl) {
            if (!isAllowedQuickAccessNavId(navId)) return;
            if (zone === 'home') {
                var targetCard = targetEl && targetEl.closest ? targetEl.closest('#home-grid-container .home-card[data-nav]') : null;
                var targetId = targetCard ? targetCard.getAttribute('data-nav') : '';
                if (origin === 'home' && targetId && targetId !== navId) {
                    var visibleIds = Array.from(document.querySelectorAll('#home-grid-container .home-card[data-nav]'))
                        .map(function (el) { return el.getAttribute('data-nav'); })
                        .filter(Boolean);
                    var nextOrder = moveIdBefore(reorderBySavedOrder(visibleIds), navId, targetId);
                    setHomeShortcutOrder(nextOrder);
                    renderHomeView();
                } else {
                    setHomeIconVisibility(navId, true);
                }
                return;
            }
            if (zone === 'menu') {
                setHomeIconVisibility(navId, false);
                if (typeof setMainNavItemVisible === 'function') setMainNavItemVisible(navId, true);
                refreshQuickAccessMenus();
                if (typeof showToast === 'function') {
                    showToast((typeof t === 'function' ? t('qa_moved_to_menu') : 'چوو بۆ مێنیۆ'), 'success');
                }
            }
        }

        function refreshQuickAccessMenus() {
            if (typeof applyMenuSectionsState === 'function') applyMenuSectionsState();
            else {
                if (typeof renderMainNav === 'function') renderMainNav();
                if (typeof renderRightSidebar === 'function') renderRightSidebar();
            }
        }

        function readQuickAccessDragNavId(e) {
            var navId = window._posShortcutDragNavId || '';
            if (!navId && e && e.dataTransfer) {
                try { navId = e.dataTransfer.getData('text/plain') || e.dataTransfer.getData('text') || ''; } catch (errGet) {}
            }
            return String(navId || '').trim();
        }

        function beginQuickAccessDrag(e, navId, origin) {
            window._posShortcutDragNavId = navId;
            window._posShortcutDragActive = true;
            window._posShortcutDidDrag = false;
            if (!e || !e.dataTransfer) return;
            try {
                e.dataTransfer.effectAllowed = 'move';
                e.dataTransfer.setData('text/plain', navId);
                e.dataTransfer.setData('text', navId);
                e.dataTransfer.setData('application/x-pos-origin', origin || '');
            } catch (errDnD) {}
        }

        function initQuickAccessDragDrop() {
            if (window.__posQuickAccessDnDInited) return;
            window.__posQuickAccessDnDInited = true;

            document.addEventListener('dragover', function (e) {
                if (!window._posShortcutDragNavId) return;
                e.preventDefault();
                if (e.dataTransfer) e.dataTransfer.dropEffect = 'move';
                var zone = getQuickAccessDropZone(e.target);
                if (zone) highlightQuickAccessDropZone(zone, e.target);
            }, true);

            document.addEventListener('dragenter', function (e) {
                if (!window._posShortcutDragNavId) return;
                e.preventDefault();
            }, true);

            document.addEventListener('dragleave', function (e) {
                if (!window._posShortcutDragNavId) return;
                if (!e.target || !e.target.closest) return;
                var left = e.target.closest('#home-grid-container, #main-nav, #right-sidebar-nav, #right-sidebar');
                if (left && e.relatedTarget && left.contains(e.relatedTarget)) return;
                clearQuickAccessDropHighlight();
            }, false);

            document.addEventListener('drop', function (e) {
                if (!window._posShortcutDragNavId && !(e.dataTransfer && e.dataTransfer.types && e.dataTransfer.types.length)) return;
                var zone = getQuickAccessDropZone(e.target);
                if (!zone) return;
                e.preventDefault();
                e.stopPropagation();
                clearQuickAccessDropHighlight();
                var navId = readQuickAccessDragNavId(e);
                if (!navId || !isAllowedQuickAccessNavId(navId)) return;
                var origin = '';
                try { origin = (e.dataTransfer && e.dataTransfer.getData('application/x-pos-origin')) || ''; } catch (errO) {}
                if (!origin && document.querySelector('#home-grid-container .home-card[data-nav="' + navId + '"]')) origin = 'home';
                applyShortcutDrop(zone, navId, origin, e.target);
                window._posShortcutDragNavId = null;
                window._posShortcutDidDrag = true;
                setTimeout(function () {
                    window._posShortcutDragActive = false;
                    window._posShortcutDidDrag = false;
                }, 280);
            }, true);

            document.addEventListener('dragstart', function (e) {
                var homeCard = e.target && e.target.closest ? e.target.closest('#home-grid-container .home-card[data-nav]') : null;
                if (homeCard) {
                    if (e.target.closest('.home-card__label')) {
                        e.preventDefault();
                        return;
                    }
                    var homeId = homeCard.getAttribute('data-nav');
                    if (!homeId || !isAllowedQuickAccessNavId(homeId)) return;
                    beginQuickAccessDrag(e, homeId, 'home');
                    return;
                }
                var sideHandle = e.target && e.target.closest ? e.target.closest('#right-sidebar-nav [data-quick-access-drag-handle="true"]') : null;
                if (sideHandle) {
                    var sideItem = sideHandle.closest('.right-nav-item[data-nav]');
                    var sideId = sideItem ? sideItem.getAttribute('data-nav') : '';
                    if (!sideId || !isAllowedQuickAccessNavId(sideId)) return;
                    beginQuickAccessDrag(e, sideId, 'menu');
                    return;
                }
                var handle = e.target && e.target.closest ? e.target.closest('[data-quick-access-drag-handle="true"]') : null;
                var sourceEl = handle || (e.target && e.target.closest ? e.target.closest('[data-shortcut-id][draggable="true"]') : null);
                if (!sourceEl) return;
                var itemEl = sourceEl.closest('[data-nav]');
                var navId = itemEl ? itemEl.getAttribute('data-nav') : sourceEl.getAttribute('data-shortcut-id');
                if (!navId || !isAllowedQuickAccessNavId(navId)) return;
                var origin = (itemEl && itemEl.closest && itemEl.closest('#home-grid-container')) ? 'home'
                    : ((itemEl && itemEl.closest && itemEl.closest('#right-sidebar-nav')) ? 'menu' : 'menu');
                beginQuickAccessDrag(e, navId, origin);
            }, false);

            document.addEventListener('dragend', function () {
                window._posShortcutDragNavId = null;
                window._posShortcutDidDrag = true;
                setTimeout(function () {
                    window._posShortcutDragActive = false;
                    window._posShortcutDidDrag = false;
                }, 280);
                clearQuickAccessDropHighlight();
            }, false);
        }

        if (typeof document !== 'undefined') {
            if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initQuickAccessDragDrop);
            else initQuickAccessDragDrop();
        }

        function getHomeGridLoadingHtml() {
            var cards = '';
            for (var i = 0; i < 9; i++) {
                cards += '<div class="home-card home-card--skeleton" aria-hidden="true">' +
                    '<span class="home-card--skeleton-icon" aria-hidden="true"></span>' +
                    '<span class="home-card--skeleton-label" aria-hidden="true"></span>' +
                    '</div>';
            }
            return cards;
        }

        function renderHomeView() {
            const container = document.getElementById('home-grid-container');
            if (!container) return;
            var preAuth = document.documentElement.classList.contains('pos-pre-auth');
            var stillBooting = document.documentElement.classList.contains('app-booting') || window.__posAppShellReady === false;
            if (stillBooting && db && currentUser) {
                if (typeof hideAppBootLoader === 'function') hideAppBootLoader();
                stillBooting = false;
            }
            if (preAuth || stillBooting) {
                container.innerHTML = getHomeGridLoadingHtml();
                var stripBoot = document.getElementById('home-finance-strip');
                if (stripBoot) stripBoot.style.display = 'none';
                try { if (typeof syncHomeShopLogo === 'function') syncHomeShopLogo(); } catch (_eLogoBoot) {}
                return;
            }
            var stripEl = document.getElementById('home-finance-strip');
            if (stripEl) stripEl.style.display = '';
            if (typeof applyHomeSubtitle === 'function') applyHomeSubtitle();
            const order = getMainNavOrder();
            const navHiddenIds = getMainNavHiddenIds();
            const homeHiddenIds = getHomeHiddenIds();
            const featureHiddenIds = getFeatureHiddenNavIds();
            const extraShortcutIds = getHomeExtraShortcutIds();
            const homeIds = [];
            let html = '';
            order.forEach(function(id) {
                if (navHiddenIds.indexOf(id) >= 0 || homeHiddenIds.indexOf(id) >= 0 || featureHiddenIds.indexOf(id) >= 0) return;
                // Keep staff/admin profile access out of the home dashboard cards.
                if (id === 'staff') return;
                if (!canAccessView(id)) return;
                homeIds.push(id);
            });
            extraShortcutIds.forEach(function(id) {
                if (!id || isMainShortcutId(id)) return;
                homeIds.push(id);
            });
            var orderedIds = reorderBySavedOrder(homeIds);
            orderedIds.forEach(function(id) {
                var reqPerm = '';
                if (isMainShortcutId(id)) {
                    reqPerm = typeof VIEW_TO_PERM !== 'undefined' ? (VIEW_TO_PERM[id] || '') : '';
                }
                var def = getShortcutDefinition(id);
                html += renderHomeShortcutCard(def, reqPerm);
            });
            container.innerHTML = html || ('<p style="color:var(--text-muted);">' + (typeof t === 'function' ? t('msg_no_sections') : '—') + '</p>');
            try {
                if (typeof syncHomeShopLogo === 'function') syncHomeShopLogo();
            } catch (_eHomeLogo) {}
            try {
                if (typeof updateStats === 'function') updateStats();
                else if (typeof paintTodayFinanceKpis === 'function' && typeof getFinancialMetrics === 'function') {
                    paintTodayFinanceKpis(getFinancialMetrics(null, {}));
                }
            } catch (_eHomeKpi) {}
        }

        window._expiryAlertsCache = window._expiryAlertsCache || null;
        window._expiryAlertsLoadedAt = 0;
        window._expiryAlertsPopupShown = false;
        function fetchExpiryAlerts(days) {
            var d = parseInt(days, 10);
            if (!d || d <= 0) d = parseInt((db && db.settings && db.settings.expiry_alert_days) || 30, 10) || 30;
            return fetch('?action=get_expiry_alerts&days=' + encodeURIComponent(d), { credentials: 'same-origin' })
                .then(function(r) { return r.json(); })
                .then(function(res) {
                    if (res && res.status === 'success') {
                        window._expiryAlertsCache = res;
                        window._expiryAlertsLoadedAt = Date.now();
                        return res;
                    }
                    return null;
                })
                .catch(function() { return null; });
        }
        function refreshExpiryAlertsWidget() {
            // Expiry alerts moved from Home widget to Notifications.
            fetchExpiryAlerts().then(function(res) {
                if (!res) return;
                var msg = 'Expired: ' + (res.expired_count || 0) + ' | <= ' + (res.days || 7) + ' days: ' + (res.expiring_soon_count || 0);
                if (!window._expiryAlertsPopupShown && ((res.expired_count || 0) > 0 || (res.expiring_soon_count || 0) > 0)) {
                    window._expiryAlertsPopupShown = true;
                    if (typeof showToast === 'function') showToast(msg, 'warning');
                }
            });
        }
        window.showExpiryAlertsPopup = function() {
            var res = window._expiryAlertsCache;
            if (!res) return;
            var lines = [];
            lines.push('Expired: ' + (res.expired_count || 0));
            lines.push('Expiring within ' + (res.days || 7) + ' days: ' + (res.expiring_soon_count || 0));
            var sample = [];
            (res.expired || []).slice(0, 5).forEach(function(r) {
                sample.push((r.name || ('#' + r.product_id)) + ' | ' + r.expiry_date + ' | qty=' + r.qty);
            });
            (res.expiring_soon || []).slice(0, 5).forEach(function(r) {
                sample.push((r.name || ('#' + r.product_id)) + ' | ' + r.expiry_date + ' | qty=' + r.qty);
            });
            if (sample.length) lines.push('\n' + sample.join('\n'));
            alert(lines.join('\n'));
        };
        function renderHomeIconsSettings() {
            const container = document.getElementById('home-icons-settings');
            if (!container) return;
            const order = getMainNavOrder();
            const homeHidden = getHomeHiddenIds();
            let html = '';
            order.forEach(function(id) {
                if (!canAccessView(id)) return;
                var label = typeof getNavItemLabel === 'function' ? getNavItemLabel(id) : getBreadcrumbLabel(id);
                var icon = getBreadcrumbIcon(id);
                var checked = homeHidden.indexOf(id) < 0;
                var titleHtml = typeof navLabelSpanHtml === 'function' ? navLabelSpanHtml(id, label) : escapeHtml(label);
                html += '<label class="setting-toggle-card" for="home-icon-' + escapeHtml(id) + '">' +
                    '<div class="stc-content"><div class="stc-icon"><i class="fas ' + icon + '"></i></div>' +
                    '<div class="stc-info"><h4>' + titleHtml + '</h4><p data-i18n="settings_show_home_card">' + (typeof t === 'function' ? t('settings_show_home_card') : '') + '</p></div></div>' +
                    '<div class="toggle-switch"><input type="checkbox" id="home-icon-' + escapeHtml(id) + '" ' + (checked ? 'checked' : '') + ' onchange="toggleHomeIconVisibility(\'' + id.replace(/'/g, "\\'") + '\')"><span class="slider"></span></div></label>';
            });
            container.innerHTML = html || ('<p style="color:var(--text-muted); padding:12px;">' + (typeof t === 'function' ? t('msg_no_sections') : '—') + '</p>');
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(container);
            if (typeof applySettingsStaticUi === 'function') applySettingsStaticUi();
        }
        function renderRightSidebar() {
            const container = document.getElementById('right-sidebar-nav');
            if (!container) return;
            const order = getMainNavOrder();
            const hiddenIds = getMainNavHiddenIds();
            const featureHiddenIds = getFeatureHiddenNavIds();
            let html = '';
            order.forEach(function(id) {
                if (hiddenIds.indexOf(id) >= 0 || featureHiddenIds.indexOf(id) >= 0) return;
                if (!canAccessView(id)) return;
                const label = getBreadcrumbLabel(id);
                const icon = getBreadcrumbIcon(id);
                const onclick = getRightNavClickHandler(id);
                var rightBadge = (id === 'notifications') ? ' <span id="right-notif-badge" style="display:none; background:#ef4444; color:white; padding:2px 6px; border-radius:10px; font-size:0.7rem; margin-right:auto;">0</span>' : '';
                var labelHtml = typeof navLabelSpanHtml === 'function' ? navLabelSpanHtml(id, label) : ('<span>' + escapeHtml(label) + '</span>');
                html += '<div class="right-nav-item" data-nav="' + escapeHtml(id) + '" onclick="' + onclick + '">' +
                    '<span class="quick-access-drag-handle" draggable="true" data-quick-access-drag-handle="true" data-quick-access-origin="right" data-i18n-title="qa_drag_sidebar_title">' +
                    '<i class="fas ' + icon + '"></i></span>' +
                    labelHtml + rightBadge + '</div>';
            });
            container.innerHTML = html || ('<div style="padding:12px; color:var(--text-muted); font-size:0.85rem;">' + (typeof t === 'function' ? t('msg_no_sections') : '—') + '</div>');
            updateRightSidebarActiveState();
        }
        function updateRightSidebarActiveState(activeViewId) {
            const viewId = activeViewId || (document.querySelector('.workspace.active') && document.querySelector('.workspace.active').id ? document.querySelector('.workspace.active').id.replace('view-', '') : 'dash');
            const sidebarKey = (viewId && viewId.startsWith('warehouse-')) ? 'warehouse' : viewId;
            document.querySelectorAll('.right-nav-item').forEach(function(r) { r.classList.remove('active'); });
            const re = document.querySelector('.right-nav-item[data-nav="' + sidebarKey + '"]');
            if (re) re.classList.add('active');
        }
        function isRightSidebarVisible() { return localStorage.getItem('pos_right_sidebar_visible') !== 'false'; }
        function isFabVisible() { return localStorage.getItem('pos_fab_visible') !== 'false'; }
        function applyFabVisibility() {
            var fab = document.querySelector('.menu-fab');
            if (!fab) return;
            var showFab = isFabVisible();
            fab.style.display = showFab ? '' : 'none';
        }
        function toggleFabVisibility() {
            var cbFab = document.getElementById('set-show-fab');
            var cbSb = document.getElementById('set-show-right-sidebar');
            if (!cbFab) return;
            
            // Prevent both from being disabled at the same time
            if (cbSb && !cbFab.checked && !cbSb.checked) {
                alert("نابن هەردوو (مێنیۆ و لیستا کەناری) ڤەشارتی بن د ئێک دەم دا! تکایە ئێک ژ وان هەلبژێرە.");
                cbFab.checked = true;
                return;
            }
            
            try {
                localStorage.setItem('pos_fab_visible', cbFab.checked ? 'true' : 'false');
                applyFabVisibility();
            } catch(e) {}
        }
        function toggleRightSidebarVisibility() {
            var cbFab = document.getElementById('set-show-fab');
            var cbSb = document.getElementById('set-show-right-sidebar');
            if (!cbSb) return;
            
            // Prevent both from being disabled at the same time
            if (cbFab && !cbSb.checked && !cbFab.checked) {
                alert("نابن هەردوو (مێنیۆ و لیستا کەناری) ڤەشارتی بن د ئێک دەم دا! تکایە ئێک ژ وان هەلبژێرە.");
                cbSb.checked = true;
                return;
            }
            
            try {
                localStorage.setItem('pos_right_sidebar_visible', cbSb.checked ? 'true' : 'false');
                applyRightSidebarVisibility();
                applyFabVisibility();
            } catch(e) {}
        }
        function getSidebarPosition() { try { var p = localStorage.getItem('pos_sidebar_position'); if (p !== 'left' && p !== 'right') return 'right'; return p; } catch(e) { return 'right'; } }
        function setSidebarPosition(pos) {
            try {
                var val = (pos === 'left') ? 'left' : 'right';
                localStorage.setItem('pos_sidebar_position', val);
                applySidebarPosition();
            } catch(e) {}
        }
        function normalizeWorkspaceActionButtons(workspaceId) {
            var ws = workspaceId ? document.getElementById('view-' + workspaceId) : document.querySelector('.workspace.active');
            if (!ws) return;

            // Clear only AUTO-tagged nodes inside this container, then re-tag.
            // (We keep any explicit markup that already uses these classes.)
            ws.querySelectorAll('.page-actions-auto.page-action-row').forEach(function(el) {
                el.classList.remove('page-action-row');
                el.classList.remove('page-actions-auto');
            });
            ws.querySelectorAll('.page-actions-auto.page-actions-standard').forEach(function(el) {
                el.classList.remove('page-actions-standard');
                el.classList.remove('page-actions-auto');
            });

            var candidates = ws.querySelectorAll('div');
            candidates.forEach(function(row) {
                // Header row heuristic: flex + space-between + has heading + has buttons.
                var cs = window.getComputedStyle(row);
                if (cs.display !== 'flex') return;
                // Be tolerant: different pages use slightly different flex justification/alignment.
                if (
                    cs.justifyContent !== 'space-between' &&
                    cs.justifyContent !== 'flex-end' &&
                    cs.justifyContent !== 'flex-start' &&
                    cs.justifyContent !== 'center' &&
                    cs.justifyContent !== 'space-around'
                ) return;
                if (cs.alignItems !== 'center' && cs.alignItems !== 'flex-end' && cs.alignItems !== 'flex-start') return;

                var heading = row.querySelector('h1, h2, h3');
                var buttons = row.querySelectorAll('.btn, button');
                if (!heading || !buttons.length) return;

                // Choose the direct child with most action buttons as action host.
                var actionHost = null;
                var maxBtns = 0;
                Array.from(row.children).forEach(function(child) {
                    var n = child.querySelectorAll ? child.querySelectorAll('.btn, button').length : 0;
                    if (n > maxBtns) {
                        maxBtns = n;
                        actionHost = child;
                    }
                });
                if (!actionHost || maxBtns === 0) return;

                var rowHadClass = row.classList.contains('page-action-row');
                var hostHadClass = actionHost.classList.contains('page-actions-standard');
                row.classList.add('page-action-row');
                actionHost.classList.add('page-actions-standard');
                if(!rowHadClass) row.classList.add('page-actions-auto');
                if(!hostHadClass) actionHost.classList.add('page-actions-auto');
            });
        }

        function normalizeVisibleModalActionButtons() {
            var overlays = document.querySelectorAll('.modal-overlay');
            overlays.forEach(function(ov) {
                // Only normalize visible modals
                if (!ov) return;
                var cs = window.getComputedStyle(ov);
                if (cs.display === 'none') return;
                var card = ov.querySelector('.glass-card');
                if (!card) return;
                // Payment modals use a custom grid layout; do not auto-normalize action rows inside them.
                if (ov.id === 'payment-modal' || ov.id === 'purchase-payment-modal' || card.querySelector('.pay-modal-layout')) return;

                // Clear only AUTO-tagged nodes inside the modal card
                card.querySelectorAll('.page-actions-auto.page-action-row').forEach(function(el) {
                    el.classList.remove('page-action-row');
                    el.classList.remove('page-actions-auto');
                });
                card.querySelectorAll('.page-actions-auto.page-actions-standard').forEach(function(el) {
                    el.classList.remove('page-actions-standard');
                    el.classList.remove('page-actions-auto');
                });

                var candidates = card.querySelectorAll('div');
                var bestRow = null;
                var bestBtns = 0;

                // For modals, pick the most "action-heavy" flex row (often Save/Confirm/Add/Cancel row).
                candidates.forEach(function(row) {
                    var rc = window.getComputedStyle(row);
                    if (rc.display !== 'flex') return;
                    var btns = row.querySelectorAll('.btn, button');
                    if (!btns || !btns.length) return;
                    if (btns.length > bestBtns) {
                        bestBtns = btns.length;
                        bestRow = row;
                    }
                });

                if (!bestRow) return;

                // Choose direct child with most buttons as action host
                var actionHost = null;
                var maxBtns = 0;
                Array.from(bestRow.children).forEach(function(child) {
                    var n = child.querySelectorAll ? child.querySelectorAll('.btn, button').length : 0;
                    if (n > maxBtns) { maxBtns = n; actionHost = child; }
                });
                if (!actionHost || maxBtns === 0) return;

                var rowHadClass = bestRow.classList.contains('page-action-row');
                var hostHadClass = actionHost.classList.contains('page-actions-standard');
                bestRow.classList.add('page-action-row');
                actionHost.classList.add('page-actions-standard');
                if(!rowHadClass) bestRow.classList.add('page-actions-auto');
                if(!hostHadClass) actionHost.classList.add('page-actions-auto');
            });
        }
        function applySidebarPosition() {
            var wrap = document.getElementById('app-content-wrap');
            if (!wrap) return;
            var pos = getSidebarPosition();
            if (pos === 'left') wrap.classList.add('sidebar-on-left');
            else { wrap.classList.remove('sidebar-on-left'); }
        }
        function applyRightSidebarVisibility() {
            const rs = document.getElementById('right-sidebar');
            if (!rs) return;
            if (isRightSidebarVisible()) { rs.classList.remove('hidden'); } else { rs.classList.add('hidden'); }
        }
        function syncRightSidebarCheckboxFromStorage() {
            try {
                var cb = document.getElementById('set-show-right-sidebar');
                if (cb) cb.checked = isRightSidebarVisible();
                var fabCb = document.getElementById('set-show-fab');
                if (fabCb) fabCb.checked = isFabVisible();
                var pos = getSidebarPosition();
                var r = document.getElementById('set-sidebar-position-right');
                var l = document.getElementById('set-sidebar-position-left');
                if (r) r.checked = (pos === 'right');
                if (l) l.checked = (pos === 'left');
            } catch(e) {}
        }

        function breadcrumbRemove(index) {
            if (index <= 0 || index >= breadcrumbStack.length) return; // ئاستێ ئێکێ (لیست) ناهێتە ژێبرن
            const hadCurrent = index === currentBreadcrumbIndex;
            breadcrumbStack.splice(index, 1);
            if (breadcrumbStack.length <= 1) {
                currentBreadcrumbIndex = 0;
                renderBreadcrumb();
                if (hadCurrent) nav('menu', true);
                return;
            }
            if (index < currentBreadcrumbIndex) currentBreadcrumbIndex--;
            else if (hadCurrent) currentBreadcrumbIndex = Math.max(0, index - 1);
            if (hadCurrent && breadcrumbStack[currentBreadcrumbIndex])
                nav(breadcrumbStack[currentBreadcrumbIndex].id, true);
            renderBreadcrumb();
        }

        function nav(id, fromBreadcrumb) {
            if (id === 'stock-card') id = 'warehouse-movements';
            var _navCpuSave = (typeof isPosCpuSaveMode === 'function' && isPosCpuSaveMode());
            if (typeof window.closePosEntityPickList === 'function') window.closePosEntityPickList();
            if (typeof window.syncPaymentToggles === 'function') window.syncPaymentToggles();
            applySidebarPosition();
            if (id === 'delivery' && typeof isPremiumSettingsFeatureEnabled === 'function' && !isPremiumSettingsFeatureEnabled('set-enable-delivery')) {
                var delCard = document.querySelector('.setting-locked-card[data-locked-sync="set-enable-delivery"] .stc-info h4');
                if (typeof showPremiumLockedPurchasePopup === 'function') {
                    showPremiumLockedPurchasePopup(delCard ? delCard.textContent.trim() : ((typeof t === 'function') ? t('nav_delivery') : 'گەهاندن'));
                }
                return;
            }
            if ((id === 'warehouse-locations' || id === 'warehouse-transfers')) {
                if (typeof isMultiWarehouseProEnabled === 'function' && !isMultiWarehouseProEnabled()) {
                    id = 'warehouse';
                } else if (typeof canUseMultiWarehouse === 'function' && !canUseMultiWarehouse()) {
                    if (typeof showToast === 'function') {
                        showToast((typeof t === 'function') ? t('toast_multi_wh_perm_denied') : 'مۆڵەت نییە بۆ کۆگای فرە', 'error');
                    }
                    return;
                }
            }
            const viewKey = normalizeViewKey(id);
            const requiredPerm = typeof VIEW_TO_PERM !== 'undefined' ? VIEW_TO_PERM[viewKey] : null;
            if (!canAccessView(id)) {
                if (typeof logSecurityEvent === 'function') logSecurityEvent('access_denied', 'Attempted access to ' + id + ' (required: ' + (requiredPerm || 'admin') + ') by User ID ' + (currentUser ? currentUser.id : 'none'));
                id = 'access-denied';
            }
            // Breadcrumb: سجل تصفح دائم — لا مسح تلقائي، الحذف يدوي فقط (X)
            if (!fromBreadcrumb) { 
                var menuItem = { id: 'menu', label: getBreadcrumbLabel('menu'), icon: getBreadcrumbIcon('menu') };
                if (breadcrumbStack.length === 0)
                    breadcrumbStack.push(menuItem);
                if (id === 'home' || id === 'menu') {
                    currentBreadcrumbIndex = 0;
                } else {
                    var existingIdx = breadcrumbStack.findIndex(function(b) { return b.id === id; });
                    if (existingIdx >= 0) {
                        currentBreadcrumbIndex = existingIdx;
                    } else {
                        breadcrumbStack.push({ id: id, label: getBreadcrumbLabel(id), icon: getBreadcrumbIcon(id) });
                        currentBreadcrumbIndex = breadcrumbStack.length - 1;
                    }
                }
            }

            const viewId = (id === 'dash') ? 'calendar' : ((id === 'menu') ? 'home' : id);
            document.querySelectorAll('.workspace').forEach(w => w.classList.remove('active'));
            document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
            const viewEl = document.getElementById('view-' + viewId);
            if(viewEl) viewEl.classList.add('active');
            var navBtn = document.querySelector('.nav-item[data-nav="' + viewId + '"]');
            if(navBtn) navBtn.classList.add('active');
            else if(id && (id.startsWith('warehouse-') && id !== 'warehouse')) {
                const whNav = document.querySelector('.nav-item[data-nav="warehouse"]');
                if(whNav) whNav.classList.add('active');
            }
            updateRightSidebarActiveState(viewId);
            
            // Auto-close sidebar when navigating
            document.querySelector('.sidebar').classList.remove('open');
            
            if(id === 'companies') {
                syncCompAddMoneyPlaceholders();
                if (typeof renderCompaniesView === 'function') renderCompaniesView();
                else if (typeof renderCompanies === 'function') renderCompanies();
            }
            if(id === 'pos') { 
                // Ensure an active cart exists before painting POS (tables hidden or direct nav)
                if (typeof ensureDefaultCart === 'function') ensureDefaultCart();
                if (typeof hidePosInitOverlay === 'function') hidePosInitOverlay();
                else window._posScannerReady = true;
                if (typeof updatePOSUnitButtons === 'function') updatePOSUnitButtons();
                var _paintPos = function () {
                    if (typeof renderPOSCategories === 'function') renderPOSCategories();
                    if (typeof renderPOSMenu === 'function') renderPOSMenu('', true);
                    if (typeof initPosTabs === 'function') initPosTabs();
                    if (typeof renderBill === 'function') renderBill();
                };
                var _runPosPaint = function () {
                    if (_navCpuSave) requestAnimationFrame(_paintPos);
                    else _paintPos();
                };
                if (typeof posEnsureCatalogLoaded === 'function') {
                    posEnsureCatalogLoaded().then(_runPosPaint);
                } else {
                    _runPosPaint();
                }
            }
            if(id === 'products') {
                var _paintProducts = function () {
                    if (typeof renderCategorySelect === 'function') renderCategorySelect();
                    if (typeof renderProducts === 'function') renderProducts();
                };
                if (typeof posEnsureCatalogLoaded === 'function') {
                    posEnsureCatalogLoaded().then(_paintProducts);
                } else if (window.__posProductsLiteLoaded && typeof connectToDB === 'function') {
                    window.__posProductsLiteLoaded = false;
                    connectToDB(true, { fullData: true, skipRenderOnRefresh: true }).then(_paintProducts);
                } else {
                    _paintProducts();
                }
                if (typeof applyProductFormLayout === 'function') applyProductFormLayout();
                else if (typeof applyProductFormPremiumFeatureFields === 'function') applyProductFormPremiumFeatureFields();
                if (typeof applyProductFormTrackStockPrefForNewItem === 'function') applyProductFormTrackStockPrefForNewItem();
                if (typeof applyProductFormCurrencyDefaultForNewItem === 'function') applyProductFormCurrencyDefaultForNewItem();
                if (typeof fillWarehouseSelects === 'function') fillWarehouseSelects();
                if (typeof applyMultiWarehouseVisibility === 'function') applyMultiWarehouseVisibility();
                var card = document.getElementById('product-form-card');
                if (card) card.querySelectorAll('input').forEach(function(i){ i.setAttribute('autocomplete','off'); });
                if (typeof window.applyI18nSubtree === 'function') {
                    var vpRoot = document.getElementById('view-products');
                    if (vpRoot) window.applyI18nSubtree(vpRoot);
                }
                if (typeof applyProductFormFieldLabels === 'function') applyProductFormFieldLabels();
            }
                if(id === 'settings') {
                    if (typeof applyZoomLevel === 'function' && db && db.settings) applyZoomLevel(db.settings.zoomLevel || parseInt(localStorage.getItem('pos_zoom'), 10) || 100);
                    if (typeof loadSubDeviceNetworkPanel === 'function' && !(typeof isPosUltraGraphicsMode === 'function' && isPosUltraGraphicsMode())) {
                        loadSubDeviceNetworkPanel(true);
                    }
                }
            if (id === 'warehouse') {
                if (typeof posPrioritizeCatalogLoadForWarehouse === 'function') posPrioritizeCatalogLoadForWarehouse();
                if (typeof posFetchWarehouseStats === 'function') posFetchWarehouseStats();
                var _paintWh = function () {
                    if (typeof isPosCpuSaveMode === 'function' && isPosCpuSaveMode()) {
                        requestAnimationFrame(function () { renderWarehouse('all'); });
                    } else {
                        renderWarehouse('all');
                    }
                };
                if (typeof posEnsureCatalogLoaded === 'function') {
                    posEnsureCatalogLoaded().then(_paintWh);
                } else {
                    _paintWh();
                }
            }
            if(id === 'warehouse-locations') { if (typeof renderWarehouseLocations === 'function') renderWarehouseLocations(); }
            if(id === 'warehouse-transfers') { if (typeof renderWarehouseTransfers === 'function') renderWarehouseTransfers(); }
            if(id === 'warehouse-categories') renderWarehouseCategories();
            if(id === 'warehouse-printers') renderWarehousePrinters();
            if(id === 'warehouse-stocktake') renderWarehouseStocktake();
            if(id === 'warehouse-movements') renderWmsMovements();
            if(id === 'warehouse-suppliers') renderWmsSuppliers();
            if(id === 'warehouse-reports') renderWmsReports();
            if(id === 'calendar') {
                try {
                    if (typeof window.renderWorkCalendar === 'function') window.renderWorkCalendar(0);
                    else if (typeof renderWorkCalendar === 'function') renderWorkCalendar(0);
                } catch (_eCalNav) {
                    try { if (typeof console !== 'undefined' && console.warn) console.warn('calendar nav', _eCalNav); } catch (_e) {}
                }
            }
            if (typeof shopAiUpdateFabVisibility === 'function') shopAiUpdateFabVisibility();
            if(id === 'tables') { lastTableState = ""; renderTables(); }
            if(id === 'expenses') {
                renderExpenses();
                if (typeof posIsFinancialDataReady === 'function' && !posIsFinancialDataReady() && typeof posFetchSecondaryDataNow === 'function') {
                    posFetchSecondaryDataNow(1);
                }
            }
            if(id === 'staff') {
                var _paintStaff = function () {
                    if (typeof renderUsers === 'function') renderUsers();
                    if (typeof renderShifts === 'function') renderShifts();
                };
                if (typeof requestAnimationFrame === 'function') requestAnimationFrame(_paintStaff);
                else setTimeout(_paintStaff, 0);
            }
            if(id === 'settings') {
                var _settingsLite = (typeof isPosUltraGraphicsMode === 'function' && isPosUltraGraphicsMode());
                if (typeof applySettingsStaticUi === 'function') applySettingsStaticUi();
                // Ensure System Mode card is visible (protected by PIN on click)
                const systemModeCard = document.getElementById('system-mode-card');
                if (systemModeCard) systemModeCard.style.display = 'block';
                syncBreadcrumbCheckboxFromStorage();
                syncRightSidebarCheckboxFromStorage();
                if (!_settingsLite && typeof applyPremiumSettingsUI === 'function') applyPremiumSettingsUI();
                var z = (db && db.settings && db.settings.zoomLevel) ? db.settings.zoomLevel : (parseInt(localStorage.getItem('pos_zoom'), 10) || 100);
                z = Math.min(150, Math.max(70, z));
                if (typeof applyZoomLevel === 'function') applyZoomLevel(z);
                if (typeof initGraphicsQualityFromStorage === 'function') initGraphicsQualityFromStorage();
                if (typeof initCartAppearanceFromStorage === 'function') initCartAppearanceFromStorage();
                if (!_settingsLite && typeof updateFirebaseSyncUI === 'function') updateFirebaseSyncUI();
                if (!_settingsLite && typeof applyProductFormFieldLabels === 'function') applyProductFormFieldLabels();
                if (typeof posOtaRefreshCard === 'function') {
                    try { posOtaRefreshCard(); } catch (_eOtaSet) {}
                }
                var _deferSettingsHeavy = function (fn) {
                    if (_settingsLite) setTimeout(fn, 1200);
                    else fn();
                };
                _deferSettingsHeavy(function () {
                    if (typeof renderHomeIconsSettings === 'function') renderHomeIconsSettings();
                    if (typeof renderSettingsQuickItems === 'function') renderSettingsQuickItems();
                });
                // Sync Business Day Start Hour
                var elBusinessDayStart = document.getElementById('set-business-day-start-hour');
                if (elBusinessDayStart && db.settings) {
                    elBusinessDayStart.value = db.settings.businessDayStartHour !== undefined ? db.settings.businessDayStartHour : 0;
                }
                if (typeof refreshBusinessDayStartHourControlState === 'function') refreshBusinessDayStartHourControlState();
                if (typeof refreshInstallationCodesInSettings === 'function') refreshInstallationCodesInSettings(db);
                if (!_settingsLite) {
                    var _sic = document.getElementById('settings-install-codes');
                    if (_sic && typeof applyI18nSubtree === 'function') applyI18nSubtree(_sic);
                }
            }
            if(id === 'print-design') { applyPrintDesignSettings(); if (typeof applyReceiptPreviewToggles === 'function') applyReceiptPreviewToggles(); if (typeof updateReceiptPreview === 'function') updateReceiptPreview(); if (typeof toggleNewPrinterIpField === 'function') toggleNewPrinterIpField(); if (typeof renderSalesHistory === 'function') renderSalesHistory(); if (typeof renderShiftSummary === 'function') renderShiftSummary(); if (typeof renderReturnsReport === 'function') renderReturnsReport(); try { var _vpd = document.getElementById('view-print-design'); if (_vpd && typeof applyI18nSubtree === 'function') applyI18nSubtree(_vpd); } catch(eVpdI18n) {} }
            if(id === 'waste') {
                if(db.settings.enableWaste !== false && hasPermission('waste_manage')) {
                    if (typeof initWasteScreen === 'function') initWasteScreen();
                    else {
                        renderWasteList();
                        renderWasteCandidates();
                    }
                    if (typeof posIsFinancialDataReady === 'function' && !posIsFinancialDataReady() && typeof posFetchSecondaryDataNow === 'function') {
                        posFetchSecondaryDataNow(1);
                    }
                } else nav('home');
            }
            if(id === 'recipes') { if(typeof isRecipeFeatureEnabled === 'function' ? isRecipeFeatureEnabled() : db.settings.enableRecipe === true) renderRecipeManager(); else nav('home'); }
            if(id === 'debt') { renderDebtView('customers'); }
            if(id === 'notifications') { renderNotifications(); }
            if(id === 'delivery') { renderDeliveries(); }
            if(id === 'print-history') { window._printLogLoaded = false; renderGeneralHistory(); }
            if(id === 'purchase') { initPurchaseScreen(); }
            if(id === 'purchase-returns') { initPurchaseReturnsScreen(); }
            if(id === 'returns-new') { initSalesReturnScreen(); }
            var _txnNav = (id === 'pos' || id === 'purchase' || id === 'purchase-returns' || id === 'returns-new' || id === 'waste');
            if (_txnNav && typeof window.refreshTxnScreen === 'function') {
                setTimeout(function() { window.refreshTxnScreen(id); }, 40);
            }
            if (_txnNav && typeof window.resetTxnSheet === 'function') {
                setTimeout(function () { window.resetTxnSheet(id); }, 30);
            }
            if (id === 'home' || id === 'menu') {
                if (typeof posMarkShellReadyAndPaint === 'function') posMarkShellReadyAndPaint();
                else renderHomeView();
            }
            if (_txnNav) {
                if (typeof initCartPanelResizers === 'function') initCartPanelResizers();
                if (typeof initCartPanelPinchDensity === 'function') initCartPanelPinchDensity();
            } else if (!_navCpuSave) {
                if (typeof initCartPanelResizers === 'function') initCartPanelResizers();
                if (typeof initCartPanelPinchDensity === 'function') initCartPanelPinchDensity();
            }
            // Force Auto-Focus on POS barcode input
            if(id === 'pos') {
                if (typeof window.syncPosSaleWarehouseBtn === 'function') window.syncPosSaleWarehouseBtn();
                if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('pos');
                try {
                    var storedPosW = parseInt(localStorage.getItem('cart_panel_width_pos'), 10);
                    if (typeof window.applyCartPanelWidthPos === 'function') {
                        window.applyCartPanelWidthPos(isFinite(storedPosW) && storedPosW > 0 ? storedPosW : 380, { toast: false });
                    }
                } catch (_ePosW) {}
                // Re-bind mouse resize handle after POS paints (clone clears old listeners)
                setTimeout(function() {
                    try {
                        var h = document.querySelector('#view-pos [data-resize-handle="pos"]');
                        if (h && h.parentNode) {
                            var clone = h.cloneNode(true);
                            delete clone.dataset.resizeBound;
                            h.parentNode.replaceChild(clone, h);
                        }
                    } catch (_eRb) {}
                    if (typeof window.initCartPanelResizers === 'function') window.initCartPanelResizers();
                }, 50);
            }
            if(id === 'waste') {
                if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('waste');
            }

            if (_txnNav) {
                setTimeout(function() {
                    var activeWs = document.querySelector('.workspace.active');
                    if (!activeWs || activeWs.id !== ('view-' + viewId)) return;
                    if (viewId === 'pos') {
                        // First paint already ran via posEnsureCatalogLoaded — only refresh bill if needed
                        if (typeof renderBill === 'function') renderBill();
                        if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('pos');
                        return;
                    }
                    if (viewId === 'purchase') { initPurchaseScreen(); return; }
                    if (viewId === 'purchase-returns') { initPurchaseReturnsScreen(); return; }
                    if (viewId === 'returns-new') { initSalesReturnScreen(); return; }
                    if (viewId === 'waste') {
                        if (typeof initWasteScreen === 'function') initWasteScreen();
                        if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('waste');
                        return;
                    }
                }, 50);
            } else if (!_navCpuSave) {
                setTimeout(function() {
                    var activeWs = document.querySelector('.workspace.active');
                    if (!activeWs || activeWs.id !== ('view-' + viewId)) return;
                    if (viewId === 'companies') { if (typeof renderCompaniesView === 'function') renderCompaniesView(); else if (typeof renderCompanies === 'function') renderCompanies(); return; }
                    if (viewId === 'debt') { renderDebtView('customers'); return; }
                    if (viewId === 'staff') { renderUsers(); renderShifts(); return; }
                    if (viewId === 'expenses') { renderExpenses(); return; }
                    if (viewId === 'delivery') { renderDeliveries(); return; }
                    /* Calendar already painted once on nav — skip redundant second renderWorkCalendar(0). */
                    if (viewId === 'calendar') { return; }
                    if (viewId === 'print-history') { renderGeneralHistory(); return; }
                    if (viewId === 'warehouse') { renderWarehouse('all'); return; }
                    if (viewId === 'warehouse-locations') { if (typeof renderWarehouseLocations === 'function') renderWarehouseLocations(); return; }
                    if (viewId === 'warehouse-transfers') { if (typeof renderWarehouseTransfers === 'function') renderWarehouseTransfers(); return; }
                    if (viewId === 'warehouse-categories') { renderWarehouseCategories(); return; }
                    if (viewId === 'warehouse-printers') { renderWarehousePrinters(); return; }
                    if (viewId === 'warehouse-stocktake') { renderWarehouseStocktake(); return; }
                    if (viewId === 'warehouse-movements' || viewId === 'stock-card') { renderWmsMovements(); return; }
                    if (viewId === 'warehouse-suppliers') { renderWmsSuppliers(); return; }
                    if (viewId === 'warehouse-reports') { renderWmsReports(); return; }
                    if (viewId === 'pos') {
                        // Avoid second full catalog paint — bill + scanner focus only
                        if (typeof renderBill === 'function') renderBill();
                        if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('pos');
                        return;
                    }
                    if (viewId === 'purchase') { initPurchaseScreen(); return; }
                    if (viewId === 'purchase-returns') { initPurchaseReturnsScreen(); return; }
                    if (viewId === 'returns-new') { initSalesReturnScreen(); return; }
                }, 120);
            }
            if (typeof updatePosTxnActiveClass === 'function') updatePosTxnActiveClass();
            renderBreadcrumb();
            if (!_navCpuSave) {
                setTimeout(function() { 
                    normalizeWorkspaceActionButtons(viewId); 
                    if (typeof normalizeVisibleModalActionButtons === 'function') normalizeVisibleModalActionButtons();
                    var L = (typeof getCurrentLanguage === 'function') ? getCurrentLanguage() : 'badini';
                    if (L === 'ar') {
                        if (typeof applyLanguage === 'function') applyLanguage();
                        else if (typeof localizeCriticalArabicSections === 'function') localizeCriticalArabicSections();
                    }
                }, 100);
            }
        }
        function updateFirebaseSyncUI() {
            if (typeof getFirebaseSyncStatus !== 'function') return;
            var status = getFirebaseSyncStatus();
            var emailEl = document.getElementById('firebase-sync-email');
            var kioskEl = document.getElementById('firebase-sync-kioskid');
            var lastEl = document.getElementById('firebase-sync-last');
            var text = document.getElementById('firebase-sync-status-text');
            var pill = document.getElementById('firebase-sync-status-pill');
            var sDot = document.getElementById('save-status-dot');
            var sideIcon = document.getElementById('firebase-sidebar-icon');
            var sideText = document.getElementById('firebase-sidebar-text');
            var errEl = document.getElementById('firebase-sync-last-err');

            if (emailEl) emailEl.textContent = status.email || '—';
            if (kioskEl) kioskEl.textContent = status.kioskId || '—';
            if (lastEl) {
                var ls = status.lastSync;
                if (!ls || ls === '—' || ls === 'Never') {
                    lastEl.textContent = (typeof t === 'function') ? t('firebase_sync_last_none') : '—';
                } else {
                    lastEl.textContent = ls;
                }
            }

            if (status.connected) {
                if (pill) {
                    pill.classList.add('firebase-sync-status-pill--connected');
                    pill.classList.remove('firebase-sync-status-pill--disconnected');
                }
                if (text) text.textContent = (typeof t === 'function' ? t('connected') : 'Connected');
                if (sDot) sDot.style.boxShadow = '0 0 8px #22c55e';
                if (sideIcon) sideIcon.style.color = '#22c55e';
                if (sideText) sideText.textContent = (typeof t === 'function' ? t('connected') : 'Connected');
            } else {
                var hasGmail = typeof window.shopHasFirebaseGmail === 'function' && window.shopHasFirebaseGmail();
                if (pill) {
                    pill.classList.add('firebase-sync-status-pill--disconnected');
                    pill.classList.remove('firebase-sync-status-pill--connected');
                }
                if (text) {
                    text.textContent = hasGmail
                        ? ((typeof t === 'function' ? t('disconnected') : 'Disconnected'))
                        : ((typeof t === 'function' ? t('firebase_sync_not_linked') : '—'));
                }
                if (sideIcon) sideIcon.style.color = hasGmail ? 'gray' : 'var(--text-muted, #64748b)';
                if (sideText) {
                    sideText.textContent = hasGmail
                        ? ((typeof t === 'function' ? t('disconnected') : 'Disconnected'))
                        : ((typeof t === 'function' ? t('firebase_sync_not_linked') : '—'));
                }
            }
            if (errEl) {
                var errMsg = '';
                var fbLinked = typeof window.isFirebaseGmailLinked === 'function' && window.isFirebaseGmailLinked();
                if (fbLinked) {
                    try { errMsg = String(localStorage.getItem('pos_firebase_last_err') || '').trim(); } catch (e) {}
                }
                if (errMsg) {
                    errEl.style.display = 'block';
                    errEl.textContent = 'هەڵەی دوایین هاوکات: ' + errMsg;
                } else {
                    errEl.style.display = 'none';
                    errEl.textContent = '';
                }
            }
            if (typeof refreshMobileManagerAppUi === 'function') refreshMobileManagerAppUi();
            var connectBtn = document.getElementById('firebase-sync-connect-btn');
            if (connectBtn) {
                var rec = typeof getShopFirebaseAccountRecord === 'function' ? getShopFirebaseAccountRecord() : null;
                var labelSpan = connectBtn.querySelector('[data-i18n]');
                var icon = connectBtn.querySelector('i');
                if (rec && rec.email) {
                    connectBtn.title = rec.email;
                    if (labelSpan) {
                        labelSpan.setAttribute('data-i18n', 'firebase_sync_login');
                        labelSpan.textContent = (typeof t === 'function') ? t('firebase_sync_login') : 'پەیوەست بکە';
                    }
                    if (icon) icon.className = 'fas fa-sign-in-alt';
                } else {
                    connectBtn.title = '';
                    if (labelSpan) {
                        labelSpan.setAttribute('data-i18n', 'firebase_sync_new');
                        labelSpan.textContent = (typeof t === 'function') ? t('firebase_sync_new') : 'دروستکردن / پەیوەست';
                    }
                    if (icon) icon.className = 'fas fa-user-plus';
                }
            }
        }
        window.updateFirebaseSyncUI = updateFirebaseSyncUI;
        function openFirebaseSyncModal() {
            var modal = document.getElementById('firebase-sync-modal');
            if (modal) modal.style.display = 'flex';
            if (typeof updateFirebaseSyncUI === 'function') updateFirebaseSyncUI();
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
        }
        function closeFirebaseSyncModal() {
            var modal = document.getElementById('firebase-sync-modal');
            if (modal) modal.style.display = 'none';
        }
        window.openFirebaseSyncModal = openFirebaseSyncModal;
        window.closeFirebaseSyncModal = closeFirebaseSyncModal;
        function renderAll(options) {
            options = options || {};
            if(!db) return;
            var bootLight = options.bootLight === true || window.__posBootRenderLight === true;
            if (bootLight) {
                window.__posBootRenderLight = false;
                if (typeof updateStats === 'function') updateStats();
                if (typeof updateNotificationBadge === 'function') updateNotificationBadge();
                if (typeof applyManualSaleVisibility === 'function') applyManualSaleVisibility();
                if (typeof applyPremiumStartup === 'function') applyPremiumStartup();
                var lightWs = document.querySelector('.workspace.active');
                var stayLight = !!(lightWs && lightWs.id && lightWs.id.indexOf('view-') === 0 && lightWs.id !== 'view-home');
                if (!stayLight) {
                    if (typeof renderMainNav === 'function') renderMainNav();
                    if (typeof renderHomeView === 'function') renderHomeView();
                }
                if (typeof posRefreshActiveWorkspaceData === 'function') posRefreshActiveWorkspaceData();
                return;
            }
            renderDashboard(); 
            renderTables(); 
            renderExpenses(); 
            updateStats(); 
            renderDeliveries(); 
            updateNotificationBadge(); 
            if(document.getElementById('view-products').classList.contains('active')) {
                if (typeof renderCategorySelect === 'function') renderCategorySelect();
                const prodSearch = document.getElementById('products-search-input');
                renderProducts(prodSearch ? prodSearch.value : '');
                if (typeof applyProductFormPremiumFeatureFields === 'function') applyProductFormPremiumFeatureFields();
                if (typeof applyProductFormTrackStockPrefForNewItem === 'function') applyProductFormTrackStockPrefForNewItem();
                if (typeof applyProductFormCurrencyDefaultForNewItem === 'function') applyProductFormCurrencyDefaultForNewItem();
            }
            if(document.getElementById('view-warehouse') && document.getElementById('view-warehouse').classList.contains('active')) {
                renderWarehouse();
            }
            setTimeout(function() { normalizeWorkspaceActionButtons(); }, 0);
            setTimeout(function() { if (typeof normalizeVisibleModalActionButtons === 'function') normalizeVisibleModalActionButtons(); }, 0);
            setTimeout(function() { if (typeof enforceUsdNoIqdText === 'function') enforceUsdNoIqdText(); }, 0);
            if (typeof applyManualSaleVisibility === 'function') applyManualSaleVisibility();
            if (typeof applyPremiumStartup === 'function') applyPremiumStartup();
        }

