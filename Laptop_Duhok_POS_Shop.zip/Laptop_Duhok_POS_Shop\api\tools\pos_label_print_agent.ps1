# POS Label Print Agent - user session (localhost only)
param([int]$Port = 9173)

$ErrorActionPreference = 'Stop'
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$printScript = Join-Path $scriptDir 'print_label_image.ps1'
$listenerPrefixes = @(
    "http://127.0.0.1:$Port/",
    "http://localhost:$Port/"
)

Add-Type -AssemblyName System.Drawing

$helperCs = Join-Path $scriptDir 'PosLabelPrintHelper.cs'
if ((Test-Path -LiteralPath $helperCs) -and -not ('PosLabelPrintHelper' -as [type])) {
    try {
        Add-Type -Path $helperCs -ReferencedAssemblies System.Drawing
    } catch {
        Write-Host ("PosLabelPrintHelper compile failed: " + $_)
    }
}

function Write-JsonResponse($response, $obj, $code = 200) {
    $json = ($obj | ConvertTo-Json -Compress -Depth 5)
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    $response.StatusCode = $code
    $response.ContentType = 'application/json; charset=utf-8'
    $response.ContentLength64 = $bytes.Length
    $response.Headers.Add('Access-Control-Allow-Origin', '*')
    $response.Headers.Add('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
    $response.Headers.Add('Access-Control-Allow-Headers', 'Content-Type')
    $response.OutputStream.Write($bytes, 0, $bytes.Length)
    $response.OutputStream.Close()
}

function Get-PrinterList {
    $out = @()
    try {
        foreach ($p in (Get-Printer -ErrorAction Stop)) {
            $out += [PSCustomObject]@{
                name = [string]$p.Name
                offline = $false
                default = [bool]$p.Default
            }
        }
    } catch {
        foreach ($p in (Get-CimInstance Win32_Printer)) {
            $out += [PSCustomObject]@{
                name = [string]$p.Name
                offline = [bool]$p.WorkOffline
                default = [bool]$p.Default
            }
        }
    }
    return $out
}

function Invoke-LabelPrint($printer, $widthMm, $heightMm, $copies, $imageBytes) {
    if ([string]::IsNullOrWhiteSpace($printer)) { throw 'printer empty' }
    if ($copies -lt 1) { $copies = 1 }
    if ($copies -gt 50) { $copies = 50 }
    $tmp = Join-Path $env:TEMP ("pos_agent_label_" + [guid]::NewGuid().ToString('N') + '.png')
    [System.IO.File]::WriteAllBytes($tmp, $imageBytes)
    try {
        if ('PosLabelPrintHelper' -as [type]) {
            [PosLabelPrintHelper]::Print($printer, $tmp, [double]$widthMm, [double]$heightMm, [int]$copies) | Out-Null
            return
        }
        if (Test-Path -LiteralPath $printScript) {
            $wStr = $widthMm.ToString([System.Globalization.CultureInfo]::InvariantCulture)
            $hStr = $heightMm.ToString([System.Globalization.CultureInfo]::InvariantCulture)
            $argsStr = "-NoProfile -ExecutionPolicy Bypass -File `"$printScript`" -ImagePath `"$tmp`" -PrinterName `"$printer`" -WidthMm $wStr -HeightMm $hStr -Copies $copies"
            
            $pinfo = New-Object System.Diagnostics.ProcessStartInfo
            $pinfo.FileName = "powershell.exe"
            $pinfo.Arguments = $argsStr
            $pinfo.UseShellExecute = $false
            $pinfo.CreateNoWindow = $true
            $pinfo.RedirectStandardError = $true
            $pinfo.RedirectStandardOutput = $true
            
            $proc = [System.Diagnostics.Process]::Start($pinfo)
            $proc.WaitForExit()
            
            if ($proc.ExitCode -ne 0) {
                $err = $proc.StandardError.ReadToEnd().Trim()
                if ([string]::IsNullOrWhiteSpace($err)) { $err = $proc.StandardOutput.ReadToEnd().Trim() }
                throw "print script exit $($proc.ExitCode): $err"
            }
            return
        }
        $img = [System.Drawing.Image]::FromFile($tmp)
        try {
            for ($i = 0; $i -lt $copies; $i++) {
                $pd = New-Object System.Drawing.Printing.PrintDocument
                try {
                    $pd.PrinterSettings.PrinterName = $printer
                    if (-not $pd.PrinterSettings.IsValid) { throw "invalid printer: $printer" }
                    $w = [Math]::Max(50, [int][Math]::Round($widthMm / 25.4 * 100))
                    $h = [Math]::Max(50, [int][Math]::Round($heightMm / 25.4 * 100))
                    try { $pd.DefaultPageSettings.PaperSize = New-Object System.Drawing.Printing.PaperSize('POSLabel', $w, $h) } catch {}
                    $pd.DefaultPageSettings.Margins = New-Object System.Drawing.Printing.Margins(0,0,0,0)
                    $script:__fbImg = $img
                    $script:__fbW = [single]$widthMm
                    $script:__fbH = [single]$heightMm
                    $handler = {
                        param($s,$e)
                        $g = $e.Graphics
                        $g.PageUnit = [System.Drawing.GraphicsUnit]::Millimeter
                        $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
                        $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
                        $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
                        $g.CompositingQuality = [System.Drawing.Drawing2D.CompositingQuality]::HighQuality
                        
                        $printableW = $e.PageSettings.PrintableArea.Width / 100.0 * 25.4
                        $printableH = $e.PageSettings.PrintableArea.Height / 100.0 * 25.4
                        
                        $drawW = $script:__fbW
                        $drawH = $script:__fbH
                        
                        if ($printableW -gt 10 -and $drawW -gt $printableW) {
                            $ratio = $printableW / $drawW
                            $drawW = $printableW
                            $drawH = $drawH * $ratio
                        }
                        
                        $x = 0
                        $y = 0
                        
                        if ($printableW -gt 0 -and $printableW -gt $drawW) {
                            $x = ($printableW - $drawW) / 2.0
                        }
                        if ($printableH -gt 0 -and $printableH -gt $drawH) {
                            $y = ($printableH - $drawH) / 2.0
                        }

                        $dest = New-Object System.Drawing.Rectangle([int]$x, [int]$y, [int]$drawW, [int]$drawH)
                        $imgAttr = New-Object System.Drawing.Imaging.ImageAttributes
                        try { $imgAttr.SetThreshold(0.5) } catch {}
                        $g.DrawImage($script:__fbImg, $dest, 0.0, 0.0, [single]$script:__fbImg.Width, [single]$script:__fbImg.Height, [System.Drawing.GraphicsUnit]::Pixel, $imgAttr)
                        $e.HasMorePages = $false
                    }
                    $pd.add_PrintPage($handler)
                    try {
                        $pd.Print()
                    } catch {
                        throw "Printer error: Printer might be offline or deleted ($printer). Details: $_"
                    }
                    $pd.remove_PrintPage($handler)
                } finally { $pd.Dispose() }
            }
        } finally { $img.Dispose() }
    } finally {
        Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
    }
}

foreach ($pfx in $listenerPrefixes) {
    try {
        netsh http add urlacl url=$pfx user=$env:USERNAME | Out-Null
    } catch {}
}

$listener = New-Object System.Net.HttpListener
foreach ($pfx in $listenerPrefixes) {
    $listener.Prefixes.Add($pfx)
}
try {
    $listener.Start()
} catch {
    Write-Host ("FAILED to bind " + ($listenerPrefixes -join ', ') + " - maybe already running. " + $_)
    # If another agent instance is already up, treat as OK for Start_POS.bat relaunch
    try {
        $probe = Invoke-WebRequest -Uri ("http://127.0.0.1:$Port/health") -UseBasicParsing -TimeoutSec 2
        if ($probe.Content -match '"status"\s*:\s*"ok"') {
            Write-Host "Print Agent already running — OK."
            exit 0
        }
    } catch {}
    exit 1
}

Write-Host ("POS Label Print Agent listening on " + ($listenerPrefixes -join ' + '))
Write-Host "Keep this window open while using POS label / silent receipt printing."

while ($listener.IsListening) {
    $ctx = $listener.GetContext()
    $req = $ctx.Request
    $res = $ctx.Response
    try {
        if ($req.HttpMethod -eq 'OPTIONS') {
            $res.StatusCode = 204
            $res.Headers.Add('Access-Control-Allow-Origin', '*')
            $res.Headers.Add('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
            $res.Headers.Add('Access-Control-Allow-Headers', 'Content-Type')
            $res.Close()
            continue
        }

        $path = $req.Url.AbsolutePath.TrimEnd('/').ToLowerInvariant()
        if ($path -eq '' -or $path -eq '/health') {
            Write-JsonResponse $res @{ status = 'ok'; agent = 'pos-label-print'; port = $Port }
            continue
        }
        if ($path -eq '/printers') {
            Write-JsonResponse $res @{ status = 'ok'; printers = @(Get-PrinterList) }
            continue
        }
        if ($path -eq '/print' -and $req.HttpMethod -eq 'POST') {
            $reader = New-Object System.IO.StreamReader($req.InputStream, $req.ContentEncoding)
            $body = $reader.ReadToEnd()
            $reader.Close()
            $data = $body | ConvertFrom-Json
            $printer = [string]$data.printer
            $widthMm = 50.0
            $heightMm = 30.0
            $copies = 1
            if ($null -ne $data.width_mm) { $widthMm = [double]$data.width_mm }
            if ($null -ne $data.height_mm) { $heightMm = [double]$data.height_mm }
            if ($null -ne $data.copies) { $copies = [int]$data.copies }
            $imgB64 = [string]$data.image
            $idx = $imgB64.IndexOf('base64,')
            if ($idx -ge 0) { $imgB64 = $imgB64.Substring($idx + 7) }
            $imgB64 = $imgB64 -replace '\s', ''
            $bytes = [Convert]::FromBase64String($imgB64)
            Invoke-LabelPrint $printer $widthMm $heightMm $copies $bytes
            Write-JsonResponse $res @{ status = 'success'; printer = $printer; message = 'printed' }
            continue
        }
        if ($path -eq '/apply-paper' -and $req.HttpMethod -eq 'POST') {
            $reader = New-Object System.IO.StreamReader($req.InputStream, $req.ContentEncoding)
            $body = $reader.ReadToEnd()
            $reader.Close()
            $data = $body | ConvertFrom-Json
            $printer = [string]$data.printer
            $widthMm = 40.0
            $heightMm = 60.0
            if ($null -ne $data.width_mm) { $widthMm = [double]$data.width_mm }
            if ($null -ne $data.height_mm) { $heightMm = [double]$data.height_mm }
            $paperScript = Join-Path $scriptDir 'set_label_printer_paper.ps1'
            if (-not (Test-Path -LiteralPath $paperScript)) {
                throw 'set_label_printer_paper.ps1 missing'
            }
            $wStr = $widthMm.ToString([System.Globalization.CultureInfo]::InvariantCulture)
            $hStr = $heightMm.ToString([System.Globalization.CultureInfo]::InvariantCulture)
            $pStr = $printer.Replace('"', '')
            $out = & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $paperScript -PrinterName $pStr -WidthMm $wStr -HeightMm $hStr 2>&1 | Out-String
            Write-JsonResponse $res @{ status = 'success'; printer = $printer; width_mm = $widthMm; height_mm = $heightMm; message = $out.Trim() }
            continue
        }
        Write-JsonResponse $res @{ status = 'error'; message = 'not found' } 404
    } catch {
        try { Write-JsonResponse $res @{ status = 'error'; message = [string]$_.Exception.Message } 500 } catch {}
    }
}
