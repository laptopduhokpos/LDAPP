<?php
/**
 * Shop AI assistant — context builder + chat endpoint.
 */
require_once __DIR__ . '/../config/pos_ai.php';
require_once __DIR__ . '/../config/pos_ai_help_guide.php';

if (!function_exists('pos_ai_load_settings')) {
    function pos_ai_load_settings(mysqli $conn): array {
        $res = $conn->query("SELECT setting_value FROM settings WHERE setting_key = 'app_settings' LIMIT 1");
        if ($res && ($row = $res->fetch_assoc())) {
            $s = json_decode($row['setting_value'] ?? '', true);
            if (is_array($s)) return $s;
        }
        return [];
    }
}

if (!function_exists('pos_ai_business_day_bounds')) {
    function pos_ai_business_day_bounds(mysqli $conn, string $dateYmd): array {
        $settings = pos_ai_load_settings($conn);
        $startHour = isset($settings['businessDayStartHour']) ? (int)$settings['businessDayStartHour'] : 0;
        if ($startHour < 0 || $startHour > 23) $startHour = 0;
        $from = $dateYmd . ' ' . str_pad((string)$startHour, 2, '0', STR_PAD_LEFT) . ':00:00';
        $toTs = strtotime($dateYmd . ' +1 day') + ($startHour * 3600) - 1;
        $to = date('Y-m-d H:i:s', $toTs);
        return [$from, $to];
    }
}

if (!function_exists('pos_ai_period_sales')) {
    function pos_ai_period_sales(mysqli $conn, string $from, string $to, bool $withProfit): array {
        $fromE = $conn->real_escape_string($from);
        $toE = $conn->real_escape_string($to);
        $out = ['sales_total' => 0.0, 'invoice_count' => 0, 'discount_total' => 0.0, 'sales_profit' => null];
        $q = "SELECT COUNT(*) AS cnt, COALESCE(SUM(total),0) AS tot, COALESCE(SUM(discount),0) AS disc
              FROM sales WHERE created_at >= '$fromE' AND created_at <= '$toE'
              AND (is_returned IS NULL OR is_returned = 0)";
        $res = $conn->query($q);
        if ($res && ($r = $res->fetch_assoc())) {
            $out['invoice_count'] = (int)($r['cnt'] ?? 0);
            $out['sales_total'] = roundMoney($r['tot'] ?? 0);
            $out['discount_total'] = roundMoney($r['disc'] ?? 0);
        }
        if ($withProfit && function_exists('pos_compute_sales_profit_for_range')) {
            $out['sales_profit'] = roundMoney(pos_compute_sales_profit_for_range($conn, $from, $to));
        }
        return $out;
    }
}

if (!function_exists('pos_compute_sales_profit_for_range')) {
    function pos_compute_sales_profit_for_range(mysqli $conn, string $from, string $to): float {
        $fromE = $conn->real_escape_string($from);
        $toE = $conn->real_escape_string($to);
        $profit = 0.0;
        $q = "SELECT items_json, total, discount FROM sales
              WHERE created_at >= '$fromE' AND created_at <= '$toE'
              AND (is_returned IS NULL OR is_returned = 0) LIMIT 5000";
        $res = $conn->query($q);
        if (!$res) return 0.0;
        $prodCosts = [];
        $pc = $conn->query("SELECT id, cost, price FROM products");
        if ($pc) {
            while ($p = $pc->fetch_assoc()) {
                $prodCosts[(int)$p['id']] = ['cost' => (float)($p['cost'] ?? 0), 'price' => (float)($p['price'] ?? 0)];
            }
        }
        while ($row = $res->fetch_assoc()) {
            $items = json_decode($row['items_json'] ?? '[]', true);
            if (!is_array($items)) continue;
            $lineRev = 0.0;
            $lineCost = 0.0;
            foreach ($items as $it) {
                $pid = (int)($it['id'] ?? $it['prodId'] ?? 0);
                $qty = (float)($it['qty'] ?? $it['quantity'] ?? 1);
                $price = (float)($it['price'] ?? ($prodCosts[$pid]['price'] ?? 0));
                $cost = (float)($it['cost'] ?? ($prodCosts[$pid]['cost'] ?? 0));
                $lineRev += $price * $qty;
                $lineCost += $cost * $qty;
            }
            $disc = (float)($row['discount'] ?? 0);
            $tot = (float)($row['total'] ?? 0);
            if ($lineRev > 0 && $disc > 0) {
                $ratio = min(1.0, $tot / max(0.001, $lineRev));
                $lineCost *= $ratio;
            }
            $profit += ($tot - $lineCost);
        }
        return $profit;
    }
}

if (!function_exists('pos_ai_period_expenses')) {
    function pos_ai_period_expenses(mysqli $conn, string $from, string $to): float {
        $fromE = $conn->real_escape_string($from);
        $toE = $conn->real_escape_string($to);
        $iqd = function_exists('pos_sql_expense_amount_iqd') ? pos_sql_expense_amount_iqd() : 'amount';
        $q = "SELECT COALESCE(SUM($iqd),0) AS tot FROM expenses
              WHERE date >= '$fromE' AND date <= '$toE'
              AND (type IS NULL OR type = '' OR type = 'operational')";
        $res = $conn->query($q);
        if ($res && ($r = $res->fetch_assoc())) return roundMoney($r['tot'] ?? 0);
        return 0.0;
    }
}

/**
 * Daily financial summary aligned with POS «پوختەی ڕۆژانە» (cash drawer / قاسە).
 * Prefers pos_get_financial_metrics_core so AI totals match Daily/Monthly panels.
 */
if (!function_exists('pos_ai_period_financial_summary')) {
    function pos_ai_period_financial_summary(mysqli $conn, string $from, string $to, bool $withProfit, bool $withExpenses): array {
        $fromE = $conn->real_escape_string($from);
        $toE = $conn->real_escape_string($to);

        $opening = 0.0;
        $rop = $conn->query("SELECT opening_balance FROM shifts WHERE startTime >= '$fromE' AND startTime <= '$toE' ORDER BY startTime ASC LIMIT 1");
        if ($rop && ($row = $rop->fetch_assoc())) {
            $opening = roundMoney($row['opening_balance'] ?? 0);
        }

        // Prefer unified core engine (same formulas as calendar / get_financial_metrics).
        $usedCore = false;
        $coreNetProfit = null;
        if (function_exists('pos_get_financial_metrics_core')) {
            $endExclusive = $to;
            try {
                $endExclusive = (new DateTimeImmutable($to))->modify('+1 second')->format('Y-m-d H:i:s');
            } catch (Throwable $eEnd) {
                $endExclusive = date('Y-m-d H:i:s', strtotime($to . ' +1 second'));
            }
            $mode = (function_exists('pos_is_usd_currency_system') && pos_is_usd_currency_system($conn)) ? 'USD' : 'IQD';
            $core = pos_get_financial_metrics_core($conn, $from, $endExclusive, $mode, [
                'see_shop_wide' => true,
            ]);
            $cashSales = roundMoney($core['cashSales'] ?? 0);
            $cashReturns = roundMoney($core['cashRefunds'] ?? 0);
            $customerDebtIn = roundMoney($core['debtPaymentsIn'] ?? 0);
            $companyDebtPay = roundMoney($core['companyDebtPayments'] ?? 0);
            $cashPurchases = roundMoney($core['cashPurchases'] ?? 0);
            $purchaseReturnsCash = roundMoney($core['purchaseReturnsIn'] ?? 0);
            $operExp = $withExpenses ? roundMoney($core['opExpenses'] ?? 0) : 0.0;
            $cashMovement = roundMoney($core['cashMovement'] ?? 0);
            $cashDrawer = roundMoney($opening + $cashMovement);
            $sales = [
                'sales_total' => roundMoney($core['totalSales'] ?? 0),
                'invoice_count' => (int)($core['salesCount'] ?? 0),
                'discount_total' => 0.0,
                'sales_profit' => $withProfit ? roundMoney($core['grossProfit'] ?? 0) : null,
            ];
            $coreNetProfit = $withProfit ? roundMoney($core['netProfit'] ?? 0) : null;
            $usedCore = true;
        }

        if (!$usedCore) {
        $sales = pos_ai_period_sales($conn, $from, $to, $withProfit);

        $cashSales = 0.0;
        $rCs = $conn->query("SELECT COALESCE(SUM(total),0) AS tot FROM sales
            WHERE created_at >= '$fromE' AND created_at <= '$toE'
            AND (is_returned IS NULL OR is_returned = 0)
            AND (payment_method IS NULL OR payment_method = '' OR payment_method <> 'debt')");
        if ($rCs && ($cs = $rCs->fetch_assoc())) {
            $cashSales = roundMoney($cs['tot'] ?? 0);
        }

        $cashReturns = 0.0;
        $rCr = $conn->query("SELECT COALESCE(SUM(total),0) AS tot FROM `returns`
            WHERE `date` >= '$fromE' AND `date` <= '$toE'
            AND (payment_method IS NULL OR payment_method = '' OR payment_method <> 'debt')");
        if ($rCr && ($cr = $rCr->fetch_assoc())) {
            $cashReturns = roundMoney($cr['tot'] ?? 0);
        }

        $customerDebtIn = 0.0;
        try {
            $rCdi = $conn->query("SELECT COALESCE(SUM(amount),0) AS tot FROM customer_ledger
                WHERE type = 'payment' AND `date` >= '$fromE' AND `date` <= '$toE'");
            if ($rCdi && ($cdi = $rCdi->fetch_assoc())) {
                $customerDebtIn = roundMoney($cdi['tot'] ?? 0);
            }
        } catch (Throwable $e) { /* ignore */ }

        $companyDebtPay = 0.0;
        $iqdExp = function_exists('pos_sql_expense_amount_iqd') ? pos_sql_expense_amount_iqd() : 'amount';
        $rCdp = $conn->query("SELECT COALESCE(SUM($iqdExp),0) AS tot FROM expenses
            WHERE `date` >= '$fromE' AND `date` <= '$toE' AND type = 'debt_payment'");
        if ($rCdp && ($cdp = $rCdp->fetch_assoc())) {
            $companyDebtPay = roundMoney($cdp['tot'] ?? 0);
        }

        $cashPurchases = 0.0;
        $rCp = $conn->query("SELECT COALESCE(SUM($iqdExp),0) AS tot FROM expenses
            WHERE `date` >= '$fromE' AND `date` <= '$toE' AND type = 'purchase'");
        if ($rCp && ($cp = $rCp->fetch_assoc())) {
            $cashPurchases = roundMoney($cp['tot'] ?? 0);
        }

        $purchaseReturnsCash = 0.0;
        $rPrc = $conn->query("SELECT COALESCE(SUM(ABS($iqdExp)),0) AS tot FROM expenses
            WHERE `date` >= '$fromE' AND `date` <= '$toE' AND type = 'purchase_return'");
        if ($rPrc && ($prc = $rPrc->fetch_assoc())) {
            $purchaseReturnsCash = roundMoney($prc['tot'] ?? 0);
        }

        $operExp = $withExpenses ? pos_ai_period_expenses($conn, $from, $to) : 0.0;

        $cashMovement = roundMoney(
            $cashSales + $customerDebtIn + $purchaseReturnsCash
            - $operExp - $cashPurchases - $companyDebtPay - $cashReturns
        );
        $cashDrawer = roundMoney($opening + $cashMovement);
        }

        $lastReceiptId = null;
        $rLr = $conn->query("SELECT id FROM sales WHERE created_at >= '$fromE' AND created_at <= '$toE'
            AND (is_returned IS NULL OR is_returned = 0) ORDER BY id DESC LIMIT 1");
        if ($rLr && ($lr = $rLr->fetch_assoc())) {
            $lastReceiptId = (int)($lr['id'] ?? 0);
        }

        $netProfit = null;
        if ($usedCore && $coreNetProfit !== null && $withExpenses) {
            $netProfit = $coreNetProfit;
        } elseif ($withProfit && $withExpenses && $sales['sales_profit'] !== null) {
            $netProfit = roundMoney($sales['sales_profit'] - $operExp);
        }

        return [
            'opening_balance' => $opening,
            'sales_total' => $sales['sales_total'],
            'sales_invoices' => $sales['invoice_count'],
            'cash_sales' => $cashSales,
            'cash_returns' => $cashReturns,
            'customer_debt_collected' => $customerDebtIn,
            'company_debt_paid' => $companyDebtPay,
            'cash_purchases' => $cashPurchases,
            'purchase_returns_cash' => $purchaseReturnsCash,
            'operational_expenses' => $operExp,
            'cash_movement' => $cashMovement,
            'cash_drawer' => $cashDrawer,
            'sales_profit' => $sales['sales_profit'],
            'net_profit' => $netProfit,
            'last_receipt_id' => $lastReceiptId,
            'metrics_engine' => $usedCore ? 'pos_get_financial_metrics_core' : 'legacy_sum',
        ];
    }
}

if (!function_exists('pos_ai_fetch_inventory_summary')) {
    function pos_ai_fetch_inventory_summary(mysqli $conn, bool $canProfit): array {
        $out = [
            'active_products' => 0,
            'total_units_in_stock' => 0.0,
            'zero_stock_count' => 0,
            'low_stock_count' => 0,
            'categories' => [],
            'top_by_qty' => [],
        ];
        $agg = $conn->query("SELECT COUNT(*) AS c,
            COALESCE(SUM(CASE WHEN trackStock = 1 THEN qty ELSE 0 END), 0) AS units,
            SUM(CASE WHEN trackStock = 1 AND qty <= 0 THEN 1 ELSE 0 END) AS zero_c,
            SUM(CASE WHEN trackStock = 1 AND minStock > 0 AND qty <= minStock THEN 1 ELSE 0 END) AS low_c
            FROM products WHERE is_active = 1");
        if ($agg && ($r = $agg->fetch_assoc())) {
            $out['active_products'] = (int)($r['c'] ?? 0);
            $out['total_units_in_stock'] = round((float)($r['units'] ?? 0), 3);
            $out['zero_stock_count'] = (int)($r['zero_c'] ?? 0);
            $out['low_stock_count'] = (int)($r['low_c'] ?? 0);
        }
        $catR = $conn->query("SELECT category, COUNT(*) AS c, COALESCE(SUM(qty),0) AS units
            FROM products WHERE is_active = 1 AND category IS NOT NULL AND TRIM(category) != ''
            GROUP BY category ORDER BY c DESC LIMIT 20");
        if ($catR) {
            while ($cr = $catR->fetch_assoc()) {
                $out['categories'][] = [
                    'name' => (string)($cr['category'] ?? ''),
                    'products' => (int)($cr['c'] ?? 0),
                    'units' => round((float)($cr['units'] ?? 0), 3),
                ];
            }
        }
        $topQ = $canProfit
            ? "SELECT name, qty, price, cost, category FROM products WHERE is_active = 1 AND trackStock = 1 ORDER BY qty DESC LIMIT 20"
            : "SELECT name, qty, price, category FROM products WHERE is_active = 1 AND trackStock = 1 ORDER BY qty DESC LIMIT 20";
        $topR = $conn->query($topQ);
        if ($topR) {
            while ($tr = $topR->fetch_assoc()) {
                $row = [
                    'name' => (string)($tr['name'] ?? ''),
                    'qty' => round((float)($tr['qty'] ?? 0), 3),
                    'price' => roundMoney($tr['price'] ?? 0),
                    'category' => (string)($tr['category'] ?? ''),
                ];
                if ($canProfit) {
                    $row['cost'] = roundMoney($tr['cost'] ?? 0);
                }
                $out['top_by_qty'][] = $row;
            }
        }
        return $out;
    }
}

if (!function_exists('pos_ai_fetch_customers_registry')) {
    function pos_ai_fetch_customers_registry(mysqli $conn): array {
        $list = [];
        $q = "SELECT id, name, phone, balance, debt_limit FROM customers
              WHERE (is_active = 1 OR is_active IS NULL)
              ORDER BY balance DESC, name ASC LIMIT 60";
        $res = $conn->query($q);
        if ($res) {
            while ($r = $res->fetch_assoc()) {
                $bal = roundMoney($r['balance'] ?? 0);
                if ($bal <= 0 && (float)($r['debt_limit'] ?? 0) <= 0) {
                    continue;
                }
                $list[] = [
                    'id' => (int)($r['id'] ?? 0),
                    'name' => (string)($r['name'] ?? ''),
                    'phone' => (string)($r['phone'] ?? ''),
                    'balance' => $bal,
                    'debt_limit' => roundMoney($r['debt_limit'] ?? 0),
                ];
            }
        }
        $tot = ['count' => 0, 'with_debt' => 0, 'total_debt' => 0.0];
        $tR = $conn->query("SELECT COUNT(*) AS c,
            SUM(CASE WHEN balance > 0 THEN 1 ELSE 0 END) AS wd,
            COALESCE(SUM(CASE WHEN balance > 0 THEN balance ELSE 0 END), 0) AS tot
            FROM customers WHERE (is_active = 1 OR is_active IS NULL)");
        if ($tR && ($t = $tR->fetch_assoc())) {
            $tot['count'] = (int)($t['c'] ?? 0);
            $tot['with_debt'] = (int)($t['wd'] ?? 0);
            $tot['total_debt'] = roundMoney($t['tot'] ?? 0);
        }
        return [
            'totals' => $tot,
            'list' => $list,
            'list_note' => 'لیست: کریارێن قەرزدار یان سنووردار — تا ٦٠',
        ];
    }
}

if (!function_exists('pos_ai_fetch_companies_registry')) {
    function pos_ai_fetch_companies_registry(mysqli $conn): array {
        $list = [];
        $res = $conn->query("SELECT id, name, phone, balance, debt_limit FROM companies
            WHERE balance != 0 OR debt_limit > 0
            ORDER BY ABS(balance) DESC, name ASC LIMIT 60");
        if ($res) {
            while ($r = $res->fetch_assoc()) {
                $bal = roundMoney($r['balance'] ?? 0);
                $list[] = [
                    'id' => (int)($r['id'] ?? 0),
                    'name' => (string)($r['name'] ?? ''),
                    'phone' => (string)($r['phone'] ?? ''),
                    'balance' => $bal,
                    'debt_limit' => roundMoney($r['debt_limit'] ?? 0),
                    'meaning' => $bal > 0 ? 'em qerzdar in bo vî dabinikêr' : ($bal < 0 ? 'wan li me qerz in' : 'balance_sifir'),
                ];
            }
        }
        $tot = ['count' => 0, 'we_owe_suppliers' => 0.0, 'they_owe_us' => 0.0];
        $tR = $conn->query("SELECT COUNT(*) AS c,
            COALESCE(SUM(CASE WHEN balance > 0 THEN balance ELSE 0 END), 0) AS owe,
            COALESCE(SUM(CASE WHEN balance < 0 THEN ABS(balance) ELSE 0 END), 0) AS recv
            FROM companies");
        if ($tR && ($t = $tR->fetch_assoc())) {
            $tot['count'] = (int)($t['c'] ?? 0);
            $tot['we_owe_suppliers'] = roundMoney($t['owe'] ?? 0);
            $tot['they_owe_us'] = roundMoney($t['recv'] ?? 0);
        }
        return [
            'totals' => $tot,
            'list' => $list,
            'list_note' => 'balance > 0 = em qerzdar in · balance < 0 = wan li me qerz in',
        ];
    }
}

if (!function_exists('pos_ai_fetch_customer_ledger_recent')) {
    function pos_ai_fetch_customer_ledger_recent(mysqli $conn, int $limit = 30): array {
        $limit = max(5, min(50, $limit));
        $rows = [];
        $q = "SELECT cl.id, cl.type, cl.amount, cl.date, cl.note, cl.receipt_id, cl.target_id,
                     COALESCE(c.name, u.name, CONCAT('#', cl.target_id)) AS party_name
              FROM customer_ledger cl
              LEFT JOIN customers c ON cl.target_type = 'customer' AND c.id = cl.target_id
              LEFT JOIN users u ON cl.target_type = 'user' AND u.id = cl.target_id
              ORDER BY cl.id DESC LIMIT $limit";
        $res = $conn->query($q);
        if ($res) {
            while ($r = $res->fetch_assoc()) {
                $rows[] = [
                    'id' => (int)($r['id'] ?? 0),
                    'type' => (string)($r['type'] ?? ''),
                    'amount' => roundMoney($r['amount'] ?? 0),
                    'date' => (string)($r['date'] ?? ''),
                    'party' => (string)($r['party_name'] ?? ''),
                    'receipt_id' => (string)($r['receipt_id'] ?? ''),
                    'note' => mb_substr((string)($r['note'] ?? ''), 0, 120),
                ];
            }
        }
        return $rows;
    }
}

if (!function_exists('pos_ai_fetch_cash_ledger_recent')) {
    function pos_ai_fetch_cash_ledger_recent(mysqli $conn, int $limit = 25): array {
        $limit = max(5, min(40, $limit));
        $rows = [];
        $res = $conn->query("SELECT id, type, amount, date, note, transaction_id FROM ledger ORDER BY id DESC LIMIT $limit");
        if ($res) {
            while ($r = $res->fetch_assoc()) {
                $rows[] = [
                    'type' => (string)($r['type'] ?? ''),
                    'amount' => roundMoney($r['amount'] ?? 0),
                    'date' => (string)($r['date'] ?? ''),
                    'note' => mb_substr((string)($r['note'] ?? ''), 0, 100),
                    'txn' => (string)($r['transaction_id'] ?? ''),
                ];
            }
        }
        return $rows;
    }
}

if (!function_exists('pos_ai_fetch_period_trade_summary')) {
    function pos_ai_fetch_period_trade_summary(mysqli $conn, string $from, string $to): array {
        $fromE = $conn->real_escape_string($from);
        $toE = $conn->real_escape_string($to);
        $out = [
            'purchases_total' => 0.0,
            'purchase_lines' => 0,
            'sales_returns_total' => 0.0,
            'sales_returns_count' => 0,
            'purchase_returns_total' => 0.0,
            'purchase_returns_count' => 0,
        ];
        $pR = $conn->query("SELECT COUNT(*) AS c, COALESCE(SUM(totalCost),0) AS tot FROM supplies
            WHERE `date` >= '$fromE' AND `date` <= '$toE'
            AND COALESCE(type,'') NOT IN ('return','opening') AND qtyAdded > 0");
        if ($pR && ($p = $pR->fetch_assoc())) {
            $out['purchase_lines'] = (int)($p['c'] ?? 0);
            $out['purchases_total'] = roundMoney($p['tot'] ?? 0);
        }
        $srR = $conn->query("SELECT COUNT(*) AS c, COALESCE(SUM(total),0) AS tot FROM `returns`
            WHERE `date` >= '$fromE' AND `date` <= '$toE'");
        if ($srR && ($sr = $srR->fetch_assoc())) {
            $out['sales_returns_count'] = (int)($sr['c'] ?? 0);
            $out['sales_returns_total'] = roundMoney($sr['tot'] ?? 0);
        }
        try {
            $prR = $conn->query("SELECT COUNT(*) AS c, COALESCE(SUM(total),0) AS tot FROM purchase_returns
                WHERE `date` >= '$fromE' AND `date` <= '$toE'");
            if ($prR && ($pr = $prR->fetch_assoc())) {
                $out['purchase_returns_count'] = (int)($pr['c'] ?? 0);
                $out['purchase_returns_total'] = roundMoney($pr['tot'] ?? 0);
            }
        } catch (Throwable $e) { /* optional table */ }
        return $out;
    }
}

if (!function_exists('pos_ai_summarize_sale_items')) {
    function pos_ai_summarize_sale_items(?string $itemsJson, int $maxItems = 8): array {
        $items = json_decode($itemsJson ?? '[]', true);
        if (!is_array($items)) return [];
        $out = [];
        foreach (array_slice($items, 0, $maxItems) as $it) {
            $out[] = [
                'name' => mb_substr(trim((string)($it['name'] ?? 'Unknown')), 0, 60),
                'qty' => round((float)($it['qty'] ?? $it['quantity'] ?? 1), 3),
                'price' => roundMoney($it['price'] ?? 0),
            ];
        }
        return $out;
    }
}

if (!function_exists('pos_ai_format_sale_row')) {
    function pos_ai_format_sale_row(mysqli $conn, array $r): array {
        $cid = (int)($r['customer_id'] ?? 0);
        $ctype = (string)($r['customer_type'] ?? 'customer');
        $cname = '';
        if ($cid > 0 && function_exists('pos_resolve_sale_customer_name')) {
            $cname = pos_resolve_sale_customer_name($conn, $cid, $ctype);
        }
        return [
            'receipt_id' => (int)($r['id'] ?? 0),
            'total' => roundMoney($r['total'] ?? 0),
            'discount' => roundMoney($r['discount'] ?? 0),
            'cashier' => (string)($r['cashier'] ?? ''),
            'customer' => $cname,
            'customer_id' => $cid > 0 ? $cid : null,
            'payment_method' => (string)($r['payment_method'] ?? 'cash'),
            'debt_amount' => roundMoney($r['debt_amount'] ?? 0),
            'paid_amount' => roundMoney($r['paid_amount'] ?? 0),
            'date' => (string)($r['created_at'] ?? $r['date'] ?? ''),
            'items' => pos_ai_summarize_sale_items($r['items_json'] ?? null),
            'is_returned' => (int)($r['is_returned'] ?? 0),
        ];
    }
}

if (!function_exists('pos_ai_fetch_sale_invoices')) {
    function pos_ai_fetch_sale_invoices(mysqli $conn, string $from, string $to, int $limit = 80): array {
        $limit = max(5, min(120, $limit));
        $fromE = $conn->real_escape_string($from);
        $toE = $conn->real_escape_string($to);
        $rows = [];
        $q = "SELECT id, total, discount, created_at, cashier, payment_method, customer_id, customer_type,
                     paid_amount, debt_amount, items_json, is_returned
              FROM sales WHERE created_at >= '$fromE' AND created_at <= '$toE'
              ORDER BY id DESC LIMIT $limit";
        $res = $conn->query($q);
        if ($res) {
            while ($r = $res->fetch_assoc()) {
                $rows[] = pos_ai_format_sale_row($conn, $r);
            }
        }
        return array_reverse($rows);
    }
}

if (!function_exists('pos_ai_fetch_sale_by_id')) {
    function pos_ai_fetch_sale_by_id(mysqli $conn, int $id): ?array {
        if ($id <= 0) return null;
        $res = $conn->query("SELECT id, total, discount, created_at, cashier, payment_method, customer_id, customer_type,
            paid_amount, debt_amount, bank_amount, items_json, is_returned, transaction_id
            FROM sales WHERE id = $id LIMIT 1");
        if (!$res || !($r = $res->fetch_assoc())) return null;
        $row = pos_ai_format_sale_row($conn, $r);
        $row['bank_amount'] = roundMoney($r['bank_amount'] ?? 0);
        $row['transaction_id'] = (string)($r['transaction_id'] ?? '');
        return $row;
    }
}

if (!function_exists('pos_ai_fetch_recent_returns')) {
    function pos_ai_fetch_recent_returns(mysqli $conn, int $limit = 20): array {
        $limit = max(5, min(40, $limit));
        $rows = [];
        $res = $conn->query("SELECT id, total, `date`, cashier, payment_method, items_json FROM `returns`
            ORDER BY id DESC LIMIT $limit");
        if ($res) {
            while ($r = $res->fetch_assoc()) {
                $rows[] = [
                    'return_id' => (int)($r['id'] ?? 0),
                    'total' => roundMoney($r['total'] ?? 0),
                    'date' => (string)($r['date'] ?? ''),
                    'cashier' => (string)($r['cashier'] ?? ''),
                    'payment_method' => (string)($r['payment_method'] ?? ''),
                    'items' => pos_ai_summarize_sale_items($r['items_json'] ?? null, 6),
                ];
            }
        }
        return $rows;
    }
}

if (!function_exists('pos_ai_fetch_recent_supplies')) {
    function pos_ai_fetch_recent_supplies(mysqli $conn, int $limit = 25): array {
        $limit = max(5, min(50, $limit));
        $rows = [];
        $res = $conn->query("SELECT id, itemName, company, qtyAdded, totalCost, `date`, type, transaction_id
            FROM supplies WHERE COALESCE(type,'') NOT IN ('return','opening') AND qtyAdded > 0
            ORDER BY id DESC LIMIT $limit");
        if ($res) {
            while ($r = $res->fetch_assoc()) {
                $rows[] = [
                    'id' => (int)($r['id'] ?? 0),
                    'product' => (string)($r['itemName'] ?? ''),
                    'company' => (string)($r['company'] ?? ''),
                    'qty' => round((float)($r['qtyAdded'] ?? 0), 3),
                    'total_cost' => roundMoney($r['totalCost'] ?? 0),
                    'date' => (string)($r['date'] ?? ''),
                    'txn' => (string)($r['transaction_id'] ?? ''),
                ];
            }
        }
        return $rows;
    }
}

if (!function_exists('pos_ai_fetch_payment_breakdown')) {
    function pos_ai_fetch_payment_breakdown(mysqli $conn, string $from, string $to): array {
        $fromE = $conn->real_escape_string($from);
        $toE = $conn->real_escape_string($to);
        $base = "created_at >= '$fromE' AND created_at <= '$toE' AND (is_returned IS NULL OR is_returned = 0)";
        $out = [
            'cash_sales' => 0.0,
            'debt_sales' => 0.0,
            'debt_amount_total' => 0.0,
            'bank_sales' => 0.0,
            'invoice_count' => 0,
            'sales_total' => 0.0,
        ];
        $res = $conn->query("SELECT COUNT(*) AS c, COALESCE(SUM(total),0) AS tot,
            COALESCE(SUM(debt_amount),0) AS debt_tot,
            COALESCE(SUM(bank_amount),0) AS bank_tot
            FROM sales WHERE $base");
        if ($res && ($r = $res->fetch_assoc())) {
            $out['invoice_count'] = (int)($r['c'] ?? 0);
            $out['sales_total'] = roundMoney($r['tot'] ?? 0);
            $out['debt_amount_total'] = roundMoney($r['debt_tot'] ?? 0);
            $out['bank_sales'] = roundMoney($r['bank_tot'] ?? 0);
        }
        $rCash = $conn->query("SELECT COALESCE(SUM(total),0) AS tot FROM sales WHERE $base
            AND (payment_method IS NULL OR payment_method = '' OR payment_method NOT IN ('debt','bank','mixed'))");
        if ($rCash && ($c = $rCash->fetch_assoc())) {
            $out['cash_sales'] = roundMoney($c['tot'] ?? 0);
        }
        $rDebt = $conn->query("SELECT COALESCE(SUM(total),0) AS tot, COUNT(*) AS c FROM sales WHERE $base
            AND (payment_method = 'debt' OR debt_amount > 0)");
        if ($rDebt && ($d = $rDebt->fetch_assoc())) {
            $out['debt_sales'] = roundMoney($d['tot'] ?? 0);
            $out['debt_invoices'] = (int)($d['c'] ?? 0);
        }
        return $out;
    }
}

if (!function_exists('pos_ai_fetch_products_index')) {
    function pos_ai_fetch_products_index(mysqli $conn, bool $canProfit, array $extraIds = []): array {
        $list = [];
        $extraIds = array_values(array_unique(array_filter(array_map('intval', $extraIds))));
        $limit = 350;
        $res = $conn->query("SELECT id, name, qty, price, cost, category, barcode, trackStock, minStock
            FROM products WHERE is_active = 1 ORDER BY name ASC LIMIT $limit");
        $seen = [];
        if ($res) {
            while ($r = $res->fetch_assoc()) {
                $id = (int)($r['id'] ?? 0);
                $seen[$id] = true;
                $row = [
                    'id' => $id,
                    'name' => (string)($r['name'] ?? ''),
                    'qty' => round((float)($r['qty'] ?? 0), 3),
                    'price' => roundMoney($r['price'] ?? 0),
                    'category' => (string)($r['category'] ?? ''),
                    'barcode' => (string)($r['barcode'] ?? ''),
                    'track_stock' => (int)($r['trackStock'] ?? 0),
                ];
                if ($canProfit) $row['cost'] = roundMoney($r['cost'] ?? 0);
                $list[] = $row;
            }
        }
        $missing = array_diff($extraIds, array_keys($seen));
        if ($missing) {
            $in = implode(',', $missing);
            $ex = $conn->query("SELECT id, name, qty, price, cost, category, barcode, trackStock, minStock
                FROM products WHERE id IN ($in)");
            if ($ex) {
                while ($r = $ex->fetch_assoc()) {
                    $row = [
                        'id' => (int)($r['id'] ?? 0),
                        'name' => (string)($r['name'] ?? ''),
                        'qty' => round((float)($r['qty'] ?? 0), 3),
                        'price' => roundMoney($r['price'] ?? 0),
                        'category' => (string)($r['category'] ?? ''),
                    ];
                    if ($canProfit) $row['cost'] = roundMoney($r['cost'] ?? 0);
                    $list[] = $row;
                }
            }
        }
        $total = 0;
        $tR = $conn->query("SELECT COUNT(*) AS c FROM products WHERE is_active = 1");
        if ($tR && ($t = $tR->fetch_assoc())) $total = (int)($t['c'] ?? 0);
        return [
            'total_active' => $total,
            'listed' => count($list),
            'list' => $list,
            'note' => $total > count($list) ? 'لیست سنووردارە — بۆ ناوی تایبەت question_focus بەکاربهێنە' : 'هەموو کاڵای چالاک',
        ];
    }
}

if (!function_exists('pos_ai_fetch_customers_index')) {
    function pos_ai_fetch_customers_index(mysqli $conn): array {
        $list = [];
        $res = $conn->query("SELECT id, name, phone, balance, debt_limit FROM customers
            WHERE (is_active = 1 OR is_active IS NULL) ORDER BY name ASC LIMIT 500");
        if ($res) {
            while ($r = $res->fetch_assoc()) {
                $list[] = [
                    'id' => (int)($r['id'] ?? 0),
                    'name' => (string)($r['name'] ?? ''),
                    'phone' => (string)($r['phone'] ?? ''),
                    'balance' => roundMoney($r['balance'] ?? 0),
                    'debt_limit' => roundMoney($r['debt_limit'] ?? 0),
                ];
            }
        }
        $total = count($list);
        $tR = $conn->query("SELECT COUNT(*) AS c FROM customers WHERE (is_active = 1 OR is_active IS NULL)");
        if ($tR && ($t = $tR->fetch_assoc())) $total = (int)($t['c'] ?? 0);
        return ['total' => $total, 'listed' => count($list), 'list' => $list];
    }
}

if (!function_exists('pos_ai_fetch_companies_index')) {
    function pos_ai_fetch_companies_index(mysqli $conn): array {
        $list = [];
        $res = $conn->query("SELECT id, name, phone, balance, debt_limit FROM companies ORDER BY name ASC LIMIT 200");
        if ($res) {
            while ($r = $res->fetch_assoc()) {
                $bal = roundMoney($r['balance'] ?? 0);
                $list[] = [
                    'id' => (int)($r['id'] ?? 0),
                    'name' => (string)($r['name'] ?? ''),
                    'phone' => (string)($r['phone'] ?? ''),
                    'balance' => $bal,
                    'meaning' => $bal > 0 ? 'em qerzdar in' : ($bal < 0 ? 'wan li me qerz in' : 'sifir'),
                ];
            }
        }
        return ['total' => count($list), 'list' => $list];
    }
}

if (!function_exists('pos_ai_fetch_shifts_summary')) {
    function pos_ai_fetch_shifts_summary(mysqli $conn): array {
        $out = ['open_shift' => null, 'recent' => []];
        $open = $conn->query("SELECT id, userId, startTime, opening_balance, closing_balance_actual FROM shifts
            WHERE endTime IS NULL OR endTime = '' OR endTime = '0000-00-00 00:00:00'
            ORDER BY startTime DESC LIMIT 1");
        if ($open && ($o = $open->fetch_assoc())) {
            $out['open_shift'] = [
                'id' => (int)($o['id'] ?? 0),
                'start' => (string)($o['startTime'] ?? ''),
                'opening_balance' => roundMoney($o['opening_balance'] ?? 0),
            ];
        }
        $rec = $conn->query("SELECT id, startTime, endTime, opening_balance, closing_balance_actual FROM shifts
            ORDER BY startTime DESC LIMIT 8");
        if ($rec) {
            while ($r = $rec->fetch_assoc()) {
                $out['recent'][] = [
                    'id' => (int)($r['id'] ?? 0),
                    'start' => (string)($r['startTime'] ?? ''),
                    'end' => (string)($r['endTime'] ?? ''),
                    'opening' => roundMoney($r['opening_balance'] ?? 0),
                    'closing' => roundMoney($r['closing_balance_actual'] ?? 0),
                ];
            }
        }
        return $out;
    }
}

if (!function_exists('pos_ai_fetch_expenses_by_type')) {
    function pos_ai_fetch_expenses_by_type(mysqli $conn, string $from, string $to): array {
        $fromE = $conn->real_escape_string($from);
        $toE = $conn->real_escape_string($to);
        $rows = [];
        $res = $conn->query("SELECT COALESCE(NULLIF(type,''),'operational') AS t,
            COUNT(*) AS c, COALESCE(SUM(amount),0) AS tot
            FROM expenses WHERE `date` >= '$fromE' AND `date` <= '$toE'
            GROUP BY t ORDER BY tot DESC");
        if ($res) {
            while ($r = $res->fetch_assoc()) {
                $rows[] = [
                    'type' => (string)($r['t'] ?? ''),
                    'count' => (int)($r['c'] ?? 0),
                    'total' => roundMoney($r['tot'] ?? 0),
                ];
            }
        }
        return $rows;
    }
}

if (!function_exists('pos_ai_extract_search_tokens')) {
    function pos_ai_extract_search_tokens(string $question): array {
        $q = mb_strtolower(trim($question));
        $stop = ['چەند', 'چاوا', 'چی', 'کێ', 'کام', 'ل', 'دا', 'دە', 'هەیە', 'بوو', 'ئەم', 'ئەو', 'من', 'تۆ',
            'the', 'how', 'what', 'who', 'many', 'much', 'today', 'yesterday', 'ئەڤرۆ', 'دوێنێ', 'قاسە', 'قەرز',
            'فرۆشت', 'کڕین', 'کۆگە', 'کاڵا', 'کریار', 'کۆمپانیا', 'پارە', 'وەسڵ', 'ژمارە'];
        $parts = preg_split('/[\s,،.?!؟\-]+/u', $q) ?: [];
        $tokens = [];
        foreach ($parts as $p) {
            $p = trim($p);
            if (mb_strlen($p) < 2) continue;
            if (in_array($p, $stop, true)) continue;
            if (preg_match('/^\d+$/', $p)) continue;
            $tokens[] = $p;
        }
        return array_values(array_unique(array_slice($tokens, 0, 6)));
    }
}

if (!function_exists('pos_ai_extract_receipt_ids')) {
    function pos_ai_extract_receipt_ids(string $question): array {
        $ids = [];
        if (preg_match_all('/(?:وەسڵ|وصل|receipt|invoice|#)\s*(\d{1,9})/ui', $question, $m)) {
            foreach ($m[1] as $id) $ids[] = (int)$id;
        }
        if (preg_match_all('/\b(\d{4,9})\b/', $question, $m2)) {
            foreach ($m2[1] as $id) $ids[] = (int)$id;
        }
        return array_values(array_unique(array_slice($ids, 0, 5)));
    }
}

if (!function_exists('pos_ai_enrich_context_for_question')) {
    function pos_ai_enrich_context_for_question(mysqli $conn, string $question, bool $canProfit): array {
        $focus = ['matched_receipts' => [], 'matched_customers' => [], 'matched_companies' => [], 'matched_products' => []];

        foreach (pos_ai_extract_receipt_ids($question) as $rid) {
            $sale = pos_ai_fetch_sale_by_id($conn, $rid);
            if ($sale) $focus['matched_receipts'][] = $sale;
        }

        $tokens = pos_ai_extract_search_tokens($question);
        $seenC = $seenCo = $seenP = [];

        foreach ($tokens as $tok) {
            $esc = $conn->real_escape_string($tok);
            if (mb_strlen($tok) >= 2) {
                $cq = $conn->query("SELECT id, name, phone, balance, debt_limit FROM customers
                    WHERE (is_active = 1 OR is_active IS NULL) AND name LIKE '%$esc%' LIMIT 5");
                if ($cq) {
                    while ($c = $cq->fetch_assoc()) {
                        $cid = (int)($c['id'] ?? 0);
                        if (isset($seenC[$cid])) continue;
                        $seenC[$cid] = true;
                        $cust = [
                            'id' => $cid,
                            'name' => (string)($c['name'] ?? ''),
                            'phone' => (string)($c['phone'] ?? ''),
                            'balance' => roundMoney($c['balance'] ?? 0),
                            'debt_limit' => roundMoney($c['debt_limit'] ?? 0),
                        ];
                        $ledger = [];
                        $lq = $conn->query("SELECT type, amount, date, note, receipt_id FROM customer_ledger
                            WHERE target_type = 'customer' AND target_id = $cid ORDER BY id DESC LIMIT 15");
                        if ($lq) {
                            while ($lr = $lq->fetch_assoc()) {
                                $ledger[] = [
                                    'type' => (string)($lr['type'] ?? ''),
                                    'amount' => roundMoney($lr['amount'] ?? 0),
                                    'date' => (string)($lr['date'] ?? ''),
                                    'receipt_id' => (string)($lr['receipt_id'] ?? ''),
                                    'note' => mb_substr((string)($lr['note'] ?? ''), 0, 80),
                                ];
                            }
                        }
                        $cust['ledger_recent'] = $ledger;
                        $salesQ = $conn->query("SELECT id, total, created_at, payment_method, debt_amount, items_json
                            FROM sales WHERE customer_id = $cid AND (is_returned IS NULL OR is_returned = 0)
                            ORDER BY id DESC LIMIT 10");
                        $recentSales = [];
                        if ($salesQ) {
                            while ($sr = $salesQ->fetch_assoc()) {
                                $recentSales[] = pos_ai_format_sale_row($conn, $sr);
                            }
                        }
                        $cust['recent_sales'] = $recentSales;
                        $focus['matched_customers'][] = $cust;
                    }
                }

                $coq = $conn->query("SELECT id, name, phone, balance FROM companies WHERE name LIKE '%$esc%' LIMIT 5");
                if ($coq) {
                    while ($co = $coq->fetch_assoc()) {
                        $coid = (int)($co['id'] ?? 0);
                        if (isset($seenCo[$coid])) continue;
                        $seenCo[$coid] = true;
                        $bal = roundMoney($co['balance'] ?? 0);
                        $comp = [
                            'id' => $coid,
                            'name' => (string)($co['name'] ?? ''),
                            'balance' => $bal,
                            'meaning' => $bal > 0 ? 'em qerzdar in' : ($bal < 0 ? 'wan li me qerz in' : 'sifir'),
                        ];
                        $pq = $conn->query("SELECT itemName, qtyAdded, totalCost, `date`, transaction_id FROM supplies
                            WHERE company LIKE '%$esc%' OR company = (SELECT name FROM companies WHERE id = $coid LIMIT 1)
                            ORDER BY id DESC LIMIT 12");
                        $purchases = [];
                        if ($pq) {
                            while ($pr = $pq->fetch_assoc()) {
                                $purchases[] = [
                                    'product' => (string)($pr['itemName'] ?? ''),
                                    'qty' => round((float)($pr['qtyAdded'] ?? 0), 3),
                                    'cost' => roundMoney($pr['totalCost'] ?? 0),
                                    'date' => (string)($pr['date'] ?? ''),
                                ];
                            }
                        }
                        $comp['recent_purchases'] = $purchases;
                        $focus['matched_companies'][] = $comp;
                    }
                }

                $pq2 = $conn->query("SELECT id, name, qty, price, cost, category, barcode, minStock, trackStock
                    FROM products WHERE is_active = 1 AND (name LIKE '%$esc%' OR barcode LIKE '%$esc%') LIMIT 8");
                if ($pq2) {
                    while ($pr = $pq2->fetch_assoc()) {
                        $pid = (int)($pr['id'] ?? 0);
                        if (isset($seenP[$pid])) continue;
                        $seenP[$pid] = true;
                        $row = [
                            'id' => $pid,
                            'name' => (string)($pr['name'] ?? ''),
                            'qty' => round((float)($pr['qty'] ?? 0), 3),
                            'price' => roundMoney($pr['price'] ?? 0),
                            'category' => (string)($pr['category'] ?? ''),
                            'min_stock' => round((float)($pr['minStock'] ?? 0), 3),
                        ];
                        if ($canProfit) $row['cost'] = roundMoney($pr['cost'] ?? 0);
                        $focus['matched_products'][] = $row;
                    }
                }
            }
        }

        return $focus;
    }
}

if (!function_exists('pos_ai_build_context')) {
    function pos_ai_build_context(mysqli $conn, bool $canProfit, bool $canExpenses): array {
        $settings = pos_ai_load_settings($conn);
        $today = date('Y-m-d');
        $yesterday = date('Y-m-d', strtotime('-1 day'));
        [$tFrom, $tTo] = pos_ai_business_day_bounds($conn, $today);
        [$yFrom, $yTo] = pos_ai_business_day_bounds($conn, $yesterday);

        $monthFrom = date('Y-m-01 00:00:00');
        $monthTo = date('Y-m-d 23:59:59');
        $lastMonthFrom = date('Y-m-01 00:00:00', strtotime('first day of last month'));
        $lastMonthTo = date('Y-m-t 23:59:59', strtotime('last day of last month'));

        $todaySales = pos_ai_period_sales($conn, $tFrom, $tTo, $canProfit);
        $yesterdaySales = pos_ai_period_sales($conn, $yFrom, $yTo, $canProfit);
        $monthSales = pos_ai_period_sales($conn, $monthFrom, $monthTo, $canProfit);
        $lastMonthSales = pos_ai_period_sales($conn, $lastMonthFrom, $lastMonthTo, $canProfit);

        $todayFin = pos_ai_period_financial_summary($conn, $tFrom, $tTo, $canProfit, $canExpenses);
        $yesterdayFin = pos_ai_period_financial_summary($conn, $yFrom, $yTo, $canProfit, $canExpenses);

        $recentDays = [];
        for ($d = 0; $d < 7; $d++) {
            $dayYmd = date('Y-m-d', strtotime("-$d days"));
            [$dFrom, $dTo] = pos_ai_business_day_bounds($conn, $dayYmd);
            $dFin = pos_ai_period_financial_summary($conn, $dFrom, $dTo, $canProfit, $canExpenses);
            $recentDays[] = [
                'date' => $dayYmd,
                'cash_drawer' => $dFin['cash_drawer'],
                'sales_total' => $dFin['sales_total'],
                'sales_invoices' => $dFin['sales_invoices'],
                'net_profit' => $dFin['net_profit'],
                'opening_balance' => $dFin['opening_balance'],
                'customer_debt_collected' => $dFin['customer_debt_collected'],
                'cash_purchases' => $dFin['cash_purchases'],
                'operational_expenses' => $dFin['operational_expenses'],
            ];
        }

        $monthFin = pos_ai_period_financial_summary($conn, $monthFrom, $monthTo, $canProfit, $canExpenses);
        $inventory = pos_ai_fetch_inventory_summary($conn, $canProfit);
        $customersRegistry = pos_ai_fetch_customers_registry($conn);
        $companiesRegistry = pos_ai_fetch_companies_registry($conn);
        $customerLedgerRecent = pos_ai_fetch_customer_ledger_recent($conn, 30);
        $cashLedgerRecent = pos_ai_fetch_cash_ledger_recent($conn, 25);
        $monthTrade = pos_ai_fetch_period_trade_summary($conn, $monthFrom, $monthTo);
        $todayTrade = pos_ai_fetch_period_trade_summary($conn, $tFrom, $tTo);

        $todaySalesList = pos_ai_fetch_sale_invoices($conn, $tFrom, $tTo, 100);
        $yesterdaySalesList = pos_ai_fetch_sale_invoices($conn, $yFrom, $yTo, 80);
        $recentSales = pos_ai_fetch_sale_invoices($conn, date('Y-m-d 00:00:00', strtotime('-30 days')), date('Y-m-d H:i:s'), 35);
        $recentReturns = pos_ai_fetch_recent_returns($conn, 20);
        $recentPurchases = pos_ai_fetch_recent_supplies($conn, 25);
        $todayPayments = pos_ai_fetch_payment_breakdown($conn, $tFrom, $tTo);
        $monthPayments = pos_ai_fetch_payment_breakdown($conn, $monthFrom, $monthTo);
        $productsIndex = pos_ai_fetch_products_index($conn, $canProfit);
        $customersIndex = pos_ai_fetch_customers_index($conn);
        $companiesIndex = pos_ai_fetch_companies_index($conn);
        $shifts = pos_ai_fetch_shifts_summary($conn);
        $monthExpByType = $canExpenses ? pos_ai_fetch_expenses_by_type($conn, $monthFrom, $monthTo) : [];

        $todayExp = $canExpenses ? $todayFin['operational_expenses'] : null;
        $monthExp = $canExpenses ? pos_ai_period_expenses($conn, $monthFrom, $monthTo) : null;

        $todayNet = $todayFin['net_profit'];
        $yesterdayNet = $yesterdayFin['net_profit'];

        // Monthly trend (12 months)
        $monthly = [];
        for ($i = 11; $i >= 0; $i--) {
            $mStart = date('Y-m-01 00:00:00', strtotime("-$i months"));
            $mEnd = date('Y-m-t 23:59:59', strtotime($mStart));
            $ms = pos_ai_period_sales($conn, $mStart, $mEnd, $canProfit);
            $me = $canExpenses ? pos_ai_period_expenses($conn, $mStart, $mEnd) : 0;
            $monthly[] = [
                'month' => date('Y-m', strtotime($mStart)),
                'sales' => $ms['sales_total'],
                'invoices' => $ms['invoice_count'],
                'profit' => $canProfit ? roundMoney(($ms['sales_profit'] ?? 0) - $me) : null,
            ];
        }

        // Low stock
        $lowStock = [];
        $lsQ = "SELECT id, name, qty, minStock, category, cost, price FROM products
                WHERE is_active = 1 AND trackStock = 1 AND minStock > 0 AND qty <= minStock
                ORDER BY (qty / NULLIF(minStock,0)) ASC LIMIT 25";
        $lsR = $conn->query($lsQ);
        if ($lsR) {
            while ($r = $lsR->fetch_assoc()) {
                $row = [
                    'id' => (int)$r['id'],
                    'name' => $r['name'],
                    'qty' => (float)$r['qty'],
                    'min_stock' => (float)$r['minStock'],
                    'category' => $r['category'],
                ];
                if ($canProfit) {
                    $row['margin_pct'] = ((float)$r['price'] > 0)
                        ? round((($r['price'] - $r['cost']) / $r['price']) * 100, 1) : 0;
                }
                $lowStock[] = $row;
            }
        }

        // Margin analysis
        $highMargin = [];
        $lowMargin = [];
        if ($canProfit) {
            $mQ = "SELECT id, name, price, cost, qty, category FROM products
                   WHERE is_active = 1 AND price > 0 ORDER BY ((price - cost) / price) DESC LIMIT 15";
            $mR = $conn->query($mQ);
            if ($mR) {
                while ($r = $mR->fetch_assoc()) {
                    $pct = round((($r['price'] - $r['cost']) / $r['price']) * 100, 1);
                    $highMargin[] = ['name' => $r['name'], 'margin_pct' => $pct, 'price' => (float)$r['price'], 'qty' => (float)$r['qty']];
                }
            }
            $lQ = "SELECT id, name, price, cost, qty, category FROM products
                   WHERE is_active = 1 AND price > 0 ORDER BY ((price - cost) / price) ASC LIMIT 15";
            $lR = $conn->query($lQ);
            if ($lR) {
                while ($r = $lR->fetch_assoc()) {
                    $pct = round((($r['price'] - $r['cost']) / $r['price']) * 100, 1);
                    $lowMargin[] = ['name' => $r['name'], 'margin_pct' => $pct, 'price' => (float)$r['price'], 'qty' => (float)$r['qty']];
                }
            }
        }

        // Top sellers this month
        $topSellers = [];
        $tsQ = "SELECT items_json FROM sales WHERE created_at >= '$monthFrom' AND created_at <= '$monthTo'
                AND (is_returned IS NULL OR is_returned = 0) LIMIT 3000";
        $agg = [];
        $tsR = $conn->query($tsQ);
        if ($tsR) {
            while ($row = $tsR->fetch_assoc()) {
                $items = json_decode($row['items_json'] ?? '[]', true);
                if (!is_array($items)) continue;
                foreach ($items as $it) {
                    $name = trim((string)($it['name'] ?? 'Unknown'));
                    $qty = (float)($it['qty'] ?? 1);
                    if (!isset($agg[$name])) $agg[$name] = ['qty' => 0, 'revenue' => 0.0];
                    $agg[$name]['qty'] += $qty;
                    $agg[$name]['revenue'] += (float)($it['price'] ?? 0) * $qty;
                }
            }
        }
        uasort($agg, function ($a, $b) { return $b['qty'] <=> $a['qty']; });
        $i = 0;
        foreach ($agg as $name => $v) {
            if ($i++ >= 15) break;
            $topSellers[] = ['name' => $name, 'qty_sold' => $v['qty'], 'revenue' => roundMoney($v['revenue'])];
        }

        // Employee performance (cashier)
        $employees = [];
        $empQ = "SELECT cashier, COUNT(*) AS cnt, COALESCE(SUM(total),0) AS tot, COALESCE(SUM(discount),0) AS disc
                 FROM sales WHERE created_at >= '$monthFrom' AND created_at <= '$monthTo'
                 AND (is_returned IS NULL OR is_returned = 0) AND cashier IS NOT NULL AND cashier != ''
                 GROUP BY cashier ORDER BY tot DESC LIMIT 15";
        $empR = $conn->query($empQ);
        if ($empR) {
            while ($r = $empR->fetch_assoc()) {
                $employees[] = [
                    'name' => $r['cashier'],
                    'invoices' => (int)$r['cnt'],
                    'sales_total' => roundMoney($r['tot']),
                    'discount_given' => roundMoney($r['disc']),
                ];
            }
        }

        // Supplier / company balances (legacy key — see companies_registry)
        $suppliers = [];
        $supQ = "SELECT id, name, balance FROM companies WHERE balance != 0 ORDER BY ABS(balance) DESC LIMIT 20";
        $supR = $conn->query($supQ);
        if ($supR) {
            while ($r = $supR->fetch_assoc()) {
                $suppliers[] = [
                    'name' => $r['name'],
                    'balance' => roundMoney($r['balance']),
                    'note' => ((float)$r['balance'] > 0) ? 'em diqîn — em qerzdar in' : 'wan li me qerz in',
                ];
            }
        }

        // Customer debt
        $customerDebt = [];
        $cdQ = "SELECT name, balance FROM customers WHERE balance > 0 ORDER BY balance DESC LIMIT 15";
        $cdR = $conn->query($cdQ);
        if ($cdR) {
            while ($r = $cdR->fetch_assoc()) {
                $customerDebt[] = ['name' => $r['name'], 'balance' => roundMoney($r['balance'])];
            }
        }

        // Recent expenses
        $recentExpenses = [];
        if ($canExpenses) {
            $exQ = "SELECT note, amount, currency, exchange_rate, date, type FROM expenses
                    ORDER BY date DESC LIMIT 12";
            $exR = $conn->query($exQ);
            if ($exR) {
                while ($r = $exR->fetch_assoc()) {
                    $recentExpenses[] = [
                        'description' => $r['note'],
                        'amount' => function_exists('pos_expense_amount_iqd') ? pos_expense_amount_iqd($r) : roundMoney($r['amount'] ?? 0),
                        'base_amount' => isset($r['amount']) ? (float)$r['amount'] : 0,
                        'currency' => strtoupper(trim((string)($r['currency'] ?? 'IQD'))) ?: 'IQD',
                        'exchange_rate' => (float)($r['exchange_rate'] ?? 0),
                        'date' => $r['date'],
                        'category' => $r['type'] ?? '',
                    ];
                }
            }
        }

        // Expiry alerts
        $expiring = [];
        $exDays = (int)($settings['expiry_alert_days'] ?? 30);
        $exQ2 = "SELECT name, expiry_date, qty FROM stock_batches sb
                 JOIN products p ON p.id = sb.product_id
                 WHERE sb.expiry_date IS NOT NULL AND sb.expiry_date <= DATE_ADD(CURDATE(), INTERVAL $exDays DAY)
                 AND sb.qty > 0 ORDER BY sb.expiry_date ASC LIMIT 15";
        $exR2 = @$conn->query($exQ2);
        if ($exR2) {
            while ($r = $exR2->fetch_assoc()) {
                $expiring[] = ['name' => $r['name'], 'expiry' => $r['expiry_date'], 'qty' => (float)$r['qty']];
            }
        }

        $productCount = (int)($inventory['active_products'] ?? 0);

        return [
            'generated_at' => date('Y-m-d H:i:s'),
            'data_scope' => 'تەنها ئەم JSON ـە — ژمارە مەخەیتە. ئیندێکسەکان (customers_index, products_index) بۆ گەڕان — question_focus بۆ ناوی تایبەت لە پرسیار.',
            'terms' => [
                'cash_drawer' => 'قاسە — پارەی نەقد ل قاسێ دا (opening + cash in − cash out). **نە** هەمان شت نییە لەگەڵ sales_total.',
                'sales_total' => 'فرۆتنا گشتی — هەموو وەسڵ (نەقد + قەرز). بۆ «چەند فرۆشت».',
                'net_profit' => 'قازانجێ سافی — قازانجی کاڵا − مەزاختن. **نە** هەمان شت نییە لەگەڵ cash_drawer.',
                'cash_sales' => 'فرۆتنا نەقد — تەنها بەشی نەقد لە فرۆشتن.',
                'customers_registry' => 'کریارێن قەرزدار (سنووردار)',
                'customers_index' => 'لیستا تەواوا کریاران (ناو+قەرز) — بۆ «کێ قەرزدارە»',
                'companies_registry' => 'کۆمپانیا/دابینکەر + قەرز',
                'companies_index' => 'لیستا هەموو کۆمپانیان',
                'customer_ledger_recent' => 'تۆمارا دوایی قەرزی کریار',
                'cash_ledger_recent' => 'تۆمارا دوایی پارە (قاسە)',
                'inventory' => 'کۆگە و ئایتم — کۆی گشتی',
                'products_index' => 'لیستا کاڵایان (ناو، qty، نرخ)',
                'today_sales_invoices' => 'هەموو وەسڵێن ئەمڕۆ — وەک پوختەی ڕۆژانە',
                'question_focus' => 'داتای تایبەت بە ناوی/وەسڵی لە پرسیار — پێشەنگی بدە',
            ],
            'today' => [
                'date' => $today,
                'sales' => $todaySales,
                'financial' => $todayFin,
                'payment_breakdown' => $todayPayments,
                'sales_invoices' => $todaySalesList,
                'expenses' => $todayExp,
                'net_profit' => $todayNet,
            ],
            'yesterday' => [
                'date' => $yesterday,
                'sales' => $yesterdaySales,
                'financial' => $yesterdayFin,
                'sales_invoices' => $yesterdaySalesList,
                'net_profit' => $yesterdayNet,
            ],
            'recent_7_days' => $recentDays,
            'this_month' => [
                'sales' => $monthSales,
                'financial' => $monthFin,
                'payment_breakdown' => $monthPayments,
                'trade' => $monthTrade,
                'expenses' => $monthExp,
                'expenses_by_type' => $monthExpByType,
                'net_profit' => $canProfit ? roundMoney(($monthSales['sales_profit'] ?? 0) - ($monthExp ?? 0)) : null,
            ],
            'today_trade' => $todayTrade,
            'inventory' => $inventory,
            'products_index' => $productsIndex,
            'customers_index' => $customersIndex,
            'companies_index' => $companiesIndex,
            'customers_registry' => $customersRegistry,
            'companies_registry' => $companiesRegistry,
            'customer_ledger_recent' => $customerLedgerRecent,
            'cash_ledger_recent' => $cashLedgerRecent,
            'recent_sales' => $recentSales,
            'recent_returns' => $recentReturns,
            'recent_purchases' => $recentPurchases,
            'shifts' => $shifts,
            'last_month' => [
                'sales' => $lastMonthSales,
                'net_profit' => $canProfit ? roundMoney(($lastMonthSales['sales_profit'] ?? 0) - ($canExpenses ? pos_ai_period_expenses($conn, $lastMonthFrom, $lastMonthTo) : 0)) : null,
            ],
            'monthly_trend_12m' => $monthly,
            'low_stock' => $lowStock,
            'high_margin_products' => $highMargin,
            'low_margin_products' => $lowMargin,
            'top_sellers_month' => $topSellers,
            'employee_performance_month' => $employees,
            'supplier_balances' => $suppliers,
            'customer_debts' => $customerDebt,
            'recent_expenses' => $recentExpenses,
            'expiring_products' => $expiring,
            'catalog' => ['active_products' => $productCount],
            'registry_totals' => [
                'customer_debt_total' => $customersRegistry['totals']['total_debt'] ?? 0,
                'customers_with_debt' => $customersRegistry['totals']['with_debt'] ?? 0,
                'company_we_owe' => $companiesRegistry['totals']['we_owe_suppliers'] ?? 0,
                'company_they_owe_us' => $companiesRegistry['totals']['they_owe_us'] ?? 0,
            ],
            'insights' => [
                'today_vs_yesterday_profit_diff' => ($canProfit && $todayNet !== null && $yesterdayNet !== null)
                    ? roundMoney($todayNet - $yesterdayNet) : null,
                'month_vs_last_month_sales_diff' => roundMoney($monthSales['sales_total'] - $lastMonthSales['sales_total']),
            ],
        ];
    }
}

// --- GET: status (API key configured?) ---
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'ai_shop_status') {
    header('Content-Type: application/json; charset=utf-8');
    pos_session_require_login_json();
    if (!pos_session_can_reports()) pos_json_perm_denied();
    if (function_exists('pos_ai_purge_secrets_from_db')) {
        pos_ai_purge_secrets_from_db($conn);
    }
    $key = pos_ai_resolve_api_key($conn);
    $model = pos_ai_resolve_model($conn);
    $usageSnap = function_exists('pos_ai_usage_snapshot') ? pos_ai_usage_snapshot($conn) : null;
    $packs = function_exists('pos_ai_pack_catalog') ? pos_ai_pack_catalog() : [];
    $vendorAllowed = function_exists('pos_ai_vendor_gemini_allowed') ? pos_ai_vendor_gemini_allowed($conn) : ($key !== '');
    $tier = is_array($usageSnap) ? (string)($usageSnap['tier'] ?? 'free') : 'free';
    echo json_encode([
        'status' => 'success',
        'configured' => $key !== '' && $vendorAllowed,
        'vendor_gemini' => $vendorAllowed,
        'tier' => $tier,
        'can_view_profit' => pos_session_can_view_profit(),
        'model' => $model,
        'models' => pos_ai_allowed_models(),
        'usage' => $usageSnap,
        'packs' => $packs,
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

// --- POST: redeem AI limit pack code ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'redeem_ai_limit_code') {
    header('Content-Type: application/json; charset=utf-8');
    pos_session_require_login_json();
    if (!pos_session_can_reports()) pos_json_perm_denied();
    $code = trim((string)($_POST['code'] ?? ''));
    if ($code === '') {
        echo json_encode(['status' => 'error', 'message' => 'کۆد پێویستە.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    if (!function_exists('pos_ai_supabase_redeem_limit_code')) {
        echo json_encode(['status' => 'error', 'message' => 'ڕێکخستنی Supabase تەواو نییە.'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $r = pos_ai_supabase_redeem_limit_code($conn, $code);
    if (empty($r['ok']) || empty($r['redeemed'])) {
        $reason = (string)($r['reason'] ?? 'error');
        $msgs = [
            'code_not_found' => 'کۆد نەدۆزرایەوە.',
            'code_used' => 'ئەم کۆدە پێشتر بەکارهاتووە.',
            'code_revoked' => 'ئەم کۆدە هەڵوەشاوە.',
            'invalid_input' => 'کۆد نادروستە.',
            'blocked' => 'لایسنس بلۆک کراوە.',
            'missing' => 'لایسنس چالاک نییە.',
        ];
        echo json_encode([
            'status' => 'error',
            'code' => $reason,
            'message' => $msgs[$reason] ?? 'کۆد سەرکەوتوو نەبوو.',
            'usage' => function_exists('pos_ai_usage_snapshot') ? pos_ai_usage_snapshot($conn) : null,
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    $bonus = (int)($r['bonus_added'] ?? 0);
    echo json_encode([
        'status' => 'success',
        'message' => $bonus > 0
            ? ('+' . $bonus . ' خاڵ زیادکرا بۆ ئەم هەفتەیە!')
            : 'کۆد چالاککرا.',
        'usage' => function_exists('pos_ai_usage_snapshot') ? pos_ai_usage_snapshot($conn) : null,
        'bonus_added' => $bonus,
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

// --- POST: chat ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'ai_shop_chat') {
    header('Content-Type: application/json; charset=utf-8');
    pos_session_require_login_json();
    if (!pos_session_can_reports()) pos_json_perm_denied();

    $question = trim((string)($_POST['question'] ?? ''));
    if ($question === '' || mb_strlen($question) > 2000) {
        echo json_encode(['status' => 'error', 'message' => 'پرسیار نادروستە / Question invalid'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $historyRaw = $_POST['history'] ?? '[]';
    $history = is_string($historyRaw) ? json_decode($historyRaw, true) : $historyRaw;
    if (!is_array($history)) $history = [];
    $turns = [];
    foreach (array_slice($history, -10) as $h) {
        if (!is_array($h)) continue;
        $role = ($h['role'] ?? '') === 'assistant' ? 'assistant' : 'user';
        $text = trim((string)($h['text'] ?? ''));
        if ($text !== '') $turns[] = ['role' => $role, 'text' => $text];
    }

    $canProfit = pos_session_can_view_profit();
    $canExpenses = pos_session_can_view_expenses();
    $settings = pos_ai_load_settings($conn);
    $data = pos_ai_build_context($conn, $canProfit, $canExpenses);

    if (function_exists('pos_ai_attach_question_timeframe')) {
        pos_ai_attach_question_timeframe($conn, $data, $question, $canProfit, $canExpenses);
    }

    $questionDate = function_exists('pos_ai_parse_question_date')
        ? pos_ai_parse_question_date($question)
        : null;
    if ($questionDate && empty($data['question_day'])) {
        [$qFrom, $qTo] = pos_ai_business_day_bounds($conn, $questionDate);
        $data['question_day'] = array_merge(
            ['date' => $questionDate, 'source' => 'mysql_full_history'],
            pos_ai_period_financial_summary($conn, $qFrom, $qTo, $canProfit, $canExpenses)
        );
        $data['question_day']['sales_invoices'] = pos_ai_fetch_sale_invoices($conn, $qFrom, $qTo, 100);
        $data['question_day']['payment_breakdown'] = pos_ai_fetch_payment_breakdown($conn, $qFrom, $qTo);
    }

    $data['question_focus'] = pos_ai_enrich_context_for_question($conn, $question, $canProfit);
    $extraProdIds = [];
    foreach ($data['question_focus']['matched_products'] ?? [] as $mp) {
        if (!empty($mp['id'])) $extraProdIds[] = (int)$mp['id'];
    }
    if ($extraProdIds) {
        $data['products_index'] = pos_ai_fetch_products_index($conn, $canProfit, $extraProdIds);
    }

    $questionIntent = function_exists('pos_ai_detect_question_intent')
        ? pos_ai_detect_question_intent($question)
        : 'unknown';

    $ctx = [
        'shop_name' => (string)($settings['cafeName'] ?? 'دکان'),
        'business_mode' => (string)($settings['systemMode'] ?? 'general'),
        'language' => (string)($settings['language'] ?? 'badini'),
        'user_question' => $question,
        'question_intent' => $questionIntent,
        'can_view_profit' => $canProfit,
        'data' => $data,
        'enabled_features' => pos_ai_settings_features_summary($settings),
        'system_help' => pos_ai_system_help_guide(),
    ];
    $systemPrompt = pos_ai_system_prompt($ctx);

    $apiKey = pos_ai_resolve_api_key($conn);
    if ($apiKey === '') {
        echo json_encode([
            'status' => 'error',
            'code' => 'no_api_key',
            'message' => 'یاریدەدەرێ AI لە سێرڤەردا ڕێکنەخراوە. پەیوەندی بکە لەگەڵ پشتیوانی سیستەم.',
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $quotaCheck = function_exists('pos_ai_check_quota_available') ? pos_ai_check_quota_available($conn) : ['ok' => true, 'snapshot' => null];
    if (empty($quotaCheck['ok'])) {
        echo json_encode([
            'status' => 'error',
            'code' => 'ai_limit_exceeded',
            'message' => $quotaCheck['message'] ?? 'سنوورا ٣٠ ڕۆژانە تەواو بوو.',
            'usage' => $quotaCheck['snapshot'] ?? null,
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $result = pos_ai_call_gemini($apiKey, $systemPrompt, $turns, $question, pos_ai_resolve_model($conn));
    if (empty($result['ok'])) {
        echo json_encode([
            'status' => 'error',
            'message' => $result['error'] ?? 'unknown',
            'code' => 'ai_failed',
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $userName = isset($_SESSION['user_name']) ? (string)$_SESSION['user_name'] : 'User';
    if (function_exists('logAction')) {
        logAction($conn, $userName, 'ai_shop_query', mb_substr($question, 0, 200));
    }

    $usageAfter = ['ok' => true, 'snapshot' => null, 'cost' => 0, 'requested_cost' => 0];
    $turnCost = function_exists('pos_ai_compute_turn_cost')
        ? pos_ai_compute_turn_cost($question, (string)$result['text'])
        : ['cost' => 1, 'tier' => 'short', 'chars' => 0, 'q_len' => 0, 'a_len' => 0];
    if (function_exists('pos_ai_consume_quota')) {
        $usageAfter = pos_ai_consume_quota($conn, (int)$turnCost['cost']);
    }

    echo json_encode([
        'status' => 'success',
        'answer' => $result['text'],
        'question_intent' => $questionIntent,
        'model_used' => $result['model'] ?? pos_ai_resolve_model($conn),
        'context_date' => $data['generated_at'] ?? date('Y-m-d H:i:s'),
        'usage' => $usageAfter['snapshot'] ?? null,
        'turn_cost' => [
            'cost' => (int)($usageAfter['cost'] ?? $turnCost['cost']),
            'requested' => (int)($usageAfter['requested_cost'] ?? $turnCost['cost']),
            'tier' => (string)($turnCost['tier'] ?? 'short'),
            'chars' => (int)($turnCost['chars'] ?? 0),
        ],
    ], JSON_UNESCAPED_UNICODE);
    exit();
}
