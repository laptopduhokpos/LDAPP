/**
 * Sidebar / FAB option menus — wide 3×2 (6 slots), 2 rows.
 * Overrides open*OptionsModal so layout stays consistent across rebuilds.
 */
(function () {
    'use strict';

    var MENU_VER = '2x3-tall-v6';
    var ALL_MENU_IDS = [
        'pos-options-popover',
        'purchase-options-popover',
        'purchase-returns-options-popover',
        'returns-options-popover',
        'warehouse-options-popover'
    ];

    function emptyTile() {
        return '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:14px 8px;min-height:98px;background:var(--input-bg);border:2px dashed var(--border);border-radius:14px;opacity:0.55;cursor:not-allowed;">' +
            '<i class="fas fa-plus" style="font-size:1.35rem;margin-bottom:8px;color:var(--text-muted);"></i>' +
            '<span style="font-size:0.75rem;color:var(--text-muted);font-weight:bold;" data-i18n="popover_menu_empty">ڤالا</span></div>';
    }

    function actionTile(o) {
        o = o || {};
        var hover = o.hover || 'var(--brand)';
        var shadow = o.shadow || 'rgba(14,74,255,0.15)';
        var html = '<div data-shortcut-id="' + (o.sid || '') + '" draggable="true" style="cursor:pointer;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:14px 8px;min-height:98px;background:var(--card);border:2px solid var(--border);border-radius:14px;transition:all .15s ease;" ' +
            'onmouseover="this.style.borderColor=\'' + hover + '\';this.style.transform=\'translateY(-2px)\';this.style.boxShadow=\'0 6px 14px ' + shadow + '\';" ' +
            'onmouseout="this.style.borderColor=\'var(--border)\';this.style.transform=\'none\';this.style.boxShadow=\'none\';" ' +
            'onclick="' + (o.onclick || '') + '">' +
            '<i class="' + (o.icon || 'fas fa-circle') + '" style="font-size:1.85rem;margin-bottom:8px;color:' + (o.color || 'var(--brand)') + ';"></i>' +
            '<span style="font-size:0.8rem;font-weight:800;color:var(--text);text-align:center;line-height:1.25;"' +
            (o.i18n ? (' data-i18n="' + o.i18n + '"') : '') + '>' + (o.label || '') + '</span></div>';
        if (o.perm) return '<div data-perm="' + o.perm + '">' + html + '</div>';
        return html;
    }

    function hideOthers(exceptId) {
        ALL_MENU_IDS.forEach(function (id) {
            if (id === exceptId) return;
            var el = document.getElementById(id);
            if (el) el.style.display = 'none';
        });
    }

    function positionMenu(modal, e) {
        if (e && e.currentTarget) {
            var rect = e.currentTarget.getBoundingClientRect();
            var isRightSidebar = e.currentTarget.closest && e.currentTarget.closest('.right-sidebar');
            var top = rect.top;
            var left = rect.left;
            if (isRightSidebar) {
                left = rect.left - 360;
            } else {
                top = rect.bottom + 6;
                left = rect.left + (rect.width / 2) - 170;
            }
            if (top + 420 > window.innerHeight) top = Math.max(10, window.innerHeight - 430);
            if (top < 10) top = 10;
            if (left + 360 > window.innerWidth) left = Math.max(10, window.innerWidth - 370);
            if (left < 10) left = 10;
            modal.style.top = top + 'px';
            modal.style.left = left + 'px';
            modal.style.transform = 'none';
        } else {
            modal.style.top = '50%';
            modal.style.left = '50%';
            modal.style.transform = 'translate(-50%, -50%)';
        }
    }

    function openMenu(cfg, e) {
        e = e || window.event;
        if (e) {
            try { e.preventDefault(); } catch (_p) {}
            try { e.stopPropagation(); } catch (_s) {}
        }
        hideOthers(cfg.id);

        var modal = document.getElementById(cfg.id);
        if (modal && modal.getAttribute('data-menu-ver') !== MENU_VER) {
            try { modal.remove(); } catch (_r) {}
            modal = null;
        }

        if (!modal) {
            modal = document.createElement('div');
            modal.id = cfg.id;
            modal.setAttribute('data-menu-ver', MENU_VER);
            modal.style.cssText = 'position:fixed;z-index:10050;background:var(--card);border:1px solid var(--border);border-radius:14px;box-shadow:0 12px 36px rgba(0,0,0,0.18);padding:14px 14px;min-width:300px;width:min(340px,92vw);display:none;flex-direction:column;gap:10px;box-sizing:border-box;';

            var tiles = (cfg.tiles || []).slice();
            while (tiles.length < 6) tiles.push(emptyTile());
            if (tiles.length > 6) tiles = tiles.slice(0, 6);

            modal.innerHTML =
                '<div style="font-size:0.95rem;color:var(--text);padding-bottom:10px;border-bottom:1px solid var(--border);margin-bottom:2px;font-weight:800;text-align:center;">' +
                '<i class="' + (cfg.titleIcon || 'fas fa-th-large') + '" style="margin-left:6px;"></i> ' +
                '<span data-i18n="' + (cfg.titleI18n || '') + '">' + (cfg.title || '') + '</span></div>' +
                '<div data-menu-cols="2" data-menu-rows="3" style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;">' +
                tiles.join('') +
                '</div>';

            document.body.appendChild(modal);
            modal.addEventListener('click', function (evt) { evt.stopPropagation(); });
            document.addEventListener('click', function (evt) {
                if (modal.style.display === 'flex' && !modal.contains(evt.target)) {
                    modal.style.display = 'none';
                }
            });
        }

        if (modal.style.display === 'flex') {
            modal.style.display = 'none';
            return;
        }

        modal.style.display = 'flex';
        if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
        positionMenu(modal, e);
    }

    function openPosOptionsModal(e) {
        openMenu({
            id: 'pos-options-popover',
            titleIcon: 'fas fa-th-large',
            titleI18n: 'popover_pos_menu_title',
            title: 'مینیویا فرۆتنێ',
            tiles: [
                actionTile({
                    sid: 'pos-sales-screen',
                    icon: 'fas fa-shopping-cart',
                    color: 'var(--brand)',
                    hover: 'var(--brand)',
                    shadow: 'rgba(14,74,255,0.15)',
                    i18n: 'popover_screen_sales',
                    label: 'شاشا فرۆتنێ',
                    onclick: "document.getElementById('pos-options-popover').style.display='none'; if(window.db && window.db.settings && window.db.settings.showTables !== true){ if(typeof openDirectPOS==='function') openDirectPOS(); else nav('pos'); } else { nav('pos'); }"
                }),
                actionTile({
                    sid: 'sales-history',
                    icon: 'fas fa-file-invoice-dollar',
                    color: '#8b5cf6',
                    hover: '#8b5cf6',
                    shadow: 'rgba(139,92,246,0.15)',
                    i18n: 'popover_history_sales',
                    label: 'مێژوویا فرۆتنێ',
                    perm: 'view_sales_history',
                    onclick: "document.getElementById('pos-options-popover').style.display='none'; if(typeof openSalesHistoryFromReturnsPrompt==='function') openSalesHistoryFromReturnsPrompt();"
                }),
                actionTile({
                    sid: 'debt',
                    icon: 'fas fa-users',
                    color: '#10b981',
                    hover: '#10b981',
                    shadow: 'rgba(16,185,129,0.15)',
                    i18n: 'view_debt_title',
                    label: 'کریار',
                    onclick: "document.getElementById('pos-options-popover').style.display='none'; nav('debt');"
                }),
                actionTile({
                    sid: 'voided-history',
                    icon: 'fas fa-trash-alt',
                    color: '#94a3b8',
                    hover: '#94a3b8',
                    shadow: 'rgba(148,163,184,0.2)',
                    i18n: 'popover_history_voided_sales',
                    label: 'مێژوویا ژێبرنا فرۆتنێ',
                    perm: 'view_sales_history',
                    onclick: "document.getElementById('pos-options-popover').style.display='none'; if(typeof openVoidedSalesHistoryOption==='function') openVoidedSalesHistoryOption();"
                }),
                actionTile({
                    sid: 'sale-edits-history',
                    icon: 'fas fa-pen-to-square',
                    color: '#0ea5e9',
                    hover: '#0ea5e9',
                    shadow: 'rgba(14,165,233,0.2)',
                    i18n: 'popover_history_sale_edits',
                    label: 'مێژوویا تەعدیلی فاتورە',
                    perm: 'view_sales_history',
                    onclick: "document.getElementById('pos-options-popover').style.display='none'; if(typeof openSaleEditsHistoryOption==='function') openSaleEditsHistoryOption();"
                })
            ]
        }, e);
    }

    function openPurchaseOptionsModal(e) {
        openMenu({
            id: 'purchase-options-popover',
            titleIcon: 'fas fa-shopping-basket',
            titleI18n: 'popover_purchase_menu_title',
            title: 'مینیویا کڕینێ',
            tiles: [
                actionTile({
                    sid: 'purchase',
                    icon: 'fas fa-shopping-basket',
                    color: 'var(--success)',
                    hover: 'var(--success)',
                    shadow: 'rgba(16,185,129,0.15)',
                    i18n: 'popover_screen_purchase',
                    label: 'شاشا کڕینێ',
                    onclick: "document.getElementById('purchase-options-popover').style.display='none'; nav('purchase');"
                }),
                actionTile({
                    sid: 'purchase-history',
                    icon: 'fas fa-history',
                    color: 'var(--warning)',
                    hover: 'var(--warning)',
                    shadow: 'rgba(245,158,11,0.15)',
                    i18n: 'popover_history_purchase',
                    label: 'مێژوویا کڕینێ',
                    perm: 'view_purchase_history',
                    onclick: "document.getElementById('purchase-options-popover').style.display='none'; if(typeof openPurchaseHistoryCompanyModal==='function') openPurchaseHistoryCompanyModal(event);"
                }),
                actionTile({
                    sid: 'purchase-edits-history',
                    icon: 'fas fa-pen-to-square',
                    color: '#f59e0b',
                    hover: '#f59e0b',
                    shadow: 'rgba(245,158,11,0.2)',
                    i18n: 'popover_history_purchase_edits',
                    label: 'مێژوویا تەعدیلی کڕینێ',
                    perm: 'view_purchase_history',
                    onclick: "document.getElementById('purchase-options-popover').style.display='none'; if(typeof openPurchaseEditsHistoryOption==='function') openPurchaseEditsHistoryOption();"
                }),
                actionTile({
                    sid: 'voided-purchases-history',
                    icon: 'fas fa-trash-alt',
                    color: '#14b8a6',
                    hover: '#14b8a6',
                    shadow: 'rgba(20,184,166,0.2)',
                    i18n: 'popover_history_voided_purchases',
                    label: 'مێژوویا ژێبرنا پسولێ کڕینێ',
                    perm: 'view_purchase_history',
                    onclick: "document.getElementById('purchase-options-popover').style.display='none'; if(typeof openVoidedPurchasesHistoryOption==='function') openVoidedPurchasesHistoryOption();"
                }),
                actionTile({
                    sid: 'companies-inventory',
                    icon: 'fas fa-building',
                    color: 'var(--info)',
                    hover: 'var(--info)',
                    shadow: 'rgba(14,74,255,0.15)',
                    i18n: 'popover_suppliers',
                    label: 'کۆمپانیا',
                    onclick: "document.getElementById('purchase-options-popover').style.display='none'; window._companyProfileDefaultTab='inventory'; nav('companies');"
                })
            ]
        }, e);
    }

    function openPurchaseReturnsOptionsModal(e) {
        openMenu({
            id: 'purchase-returns-options-popover',
            titleIcon: 'fas fa-undo',
            titleI18n: 'popover_purchase_returns_menu_title',
            title: 'مینیویا زڤڕاندنا کڕینێ',
            tiles: [
                actionTile({
                    sid: 'purchase-returns',
                    icon: 'fas fa-undo',
                    color: 'var(--danger)',
                    hover: 'var(--danger)',
                    shadow: 'rgba(220,38,38,0.15)',
                    i18n: 'popover_screen_purchase_returns',
                    label: 'زڤڕاندنا کڕینێ',
                    onclick: "document.getElementById('purchase-returns-options-popover').style.display='none'; nav('purchase-returns');"
                }),
                actionTile({
                    sid: 'companies-inventory',
                    icon: 'fas fa-building',
                    color: 'var(--info)',
                    hover: 'var(--info)',
                    shadow: 'rgba(14,74,255,0.15)',
                    i18n: 'popover_suppliers',
                    label: 'کۆمپانیا',
                    onclick: "document.getElementById('purchase-returns-options-popover').style.display='none'; window._companyProfileDefaultTab='inventory'; nav('companies');"
                }),
                actionTile({
                    sid: 'purchase-returns-history',
                    icon: 'fas fa-receipt',
                    color: 'var(--purple)',
                    hover: 'var(--purple)',
                    shadow: 'rgba(168,85,247,0.15)',
                    i18n: 'popover_history_purchase_returns',
                    label: 'مێژوویا زڤڕاندنا کڕینێ',
                    perm: 'view_purchase_history',
                    onclick: "document.getElementById('purchase-returns-options-popover').style.display='none'; if(typeof openPurchaseReturnsHistoryCompanyModal==='function') openPurchaseReturnsHistoryCompanyModal(event);"
                }),
                actionTile({
                    sid: 'voided-purchase-returns-history',
                    icon: 'fas fa-trash-alt',
                    color: '#94a3b8',
                    hover: '#94a3b8',
                    shadow: 'rgba(148,163,184,0.2)',
                    i18n: 'popover_history_voided_purchase_returns',
                    label: 'مێژوویا ژێبرنا پسولێ',
                    perm: 'view_purchase_history',
                    onclick: "document.getElementById('purchase-returns-options-popover').style.display='none'; if(typeof openVoidedPurchaseReturnsHistoryOption==='function') openVoidedPurchaseReturnsHistoryOption();"
                })
            ]
        }, e);
    }

    function openReturnsOptionsModal(e) {
        openMenu({
            id: 'returns-options-popover',
            titleIcon: 'fas fa-th-large',
            titleI18n: 'popover_returns_menu_title',
            title: 'مینیویا زڤڕاندنێ',
            tiles: [
                actionTile({
                    sid: 'returns-new',
                    icon: 'fas fa-undo-alt',
                    color: 'var(--danger)',
                    hover: 'var(--danger)',
                    shadow: 'rgba(220,38,38,0.15)',
                    i18n: 'popover_screen_returns',
                    label: 'شاشا زڤڕاندنێ',
                    onclick: "document.getElementById('returns-options-popover').style.display='none'; nav('returns-new');"
                }),
                actionTile({
                    sid: 'returns-history',
                    icon: 'fas fa-history',
                    color: 'var(--warning)',
                    hover: 'var(--warning)',
                    shadow: 'rgba(245,158,11,0.15)',
                    i18n: 'popover_history_returns',
                    label: 'مێژوویا زڤڕاندنێ',
                    onclick: "document.getElementById('returns-options-popover').style.display='none'; if(typeof openReturnsHistoryOption==='function') openReturnsHistoryOption();"
                }),
                actionTile({
                    sid: 'sales-history',
                    icon: 'fas fa-file-invoice-dollar',
                    color: '#8b5cf6',
                    hover: '#8b5cf6',
                    shadow: 'rgba(139,92,246,0.15)',
                    i18n: 'popover_history_sales',
                    label: 'مێژوویا فرۆتنێ',
                    perm: 'view_sales_history',
                    onclick: "document.getElementById('returns-options-popover').style.display='none'; if(typeof openSalesHistoryFromReturnsPrompt==='function') openSalesHistoryFromReturnsPrompt();"
                }),
                actionTile({
                    sid: 'voided-history',
                    icon: 'fas fa-trash-alt',
                    color: '#94a3b8',
                    hover: '#94a3b8',
                    shadow: 'rgba(148,163,184,0.2)',
                    i18n: 'popover_history_voided',
                    label: 'مێژوویا ژێبرنێ',
                    onclick: "document.getElementById('returns-options-popover').style.display='none'; if(typeof openVoidedSalesHistoryOption==='function') openVoidedSalesHistoryOption();"
                })
            ]
        }, e);
    }

    function openWarehouseOptionsModal(e) {
        openMenu({
            id: 'warehouse-options-popover',
            titleIcon: 'fas fa-warehouse',
            titleI18n: 'popover_warehouse_menu_title',
            title: 'مینیویا کۆگە',
            tiles: [
                actionTile({
                    sid: 'warehouse',
                    icon: 'fas fa-warehouse',
                    color: 'var(--brand)',
                    hover: 'var(--brand)',
                    i18n: 'popover_screen_warehouse',
                    label: 'شاشا کۆگە',
                    onclick: "document.getElementById('warehouse-options-popover').style.display='none'; nav('warehouse');"
                }),
                actionTile({
                    sid: 'wh-transfer',
                    icon: 'fas fa-dolly',
                    color: 'var(--success)',
                    hover: 'var(--success)',
                    shadow: 'rgba(16,185,129,0.15)',
                    i18n: 'popover_wh_transfer',
                    label: 'گواستنەوە',
                    onclick: "document.getElementById('warehouse-options-popover').style.display='none'; if(typeof openWhTransferModal==='function') openWhTransferModal();"
                }),
                actionTile({
                    sid: 'wh-transfer-history',
                    icon: 'fas fa-history',
                    color: 'var(--warning)',
                    hover: 'var(--warning)',
                    shadow: 'rgba(245,158,11,0.15)',
                    i18n: 'popover_wh_transfer_history',
                    label: 'مێژوویا گواستنەوە',
                    onclick: "document.getElementById('warehouse-options-popover').style.display='none'; if(typeof openWhTransferHistoryModal==='function') openWhTransferHistoryModal();"
                })
            ]
        }, e);
    }

    // Wipe any old 2×2 popovers left in the DOM from previous sessions
    try {
        ALL_MENU_IDS.forEach(function (id) {
            var el = document.getElementById(id);
            if (el && el.getAttribute('data-menu-ver') !== MENU_VER) el.remove();
        });
    } catch (_w) {}

    window.openPosOptionsModal = openPosOptionsModal;
    window.openPurchaseOptionsModal = openPurchaseOptionsModal;
    window.openPurchaseReturnsOptionsModal = openPurchaseReturnsOptionsModal;
    window.openReturnsOptionsModal = openReturnsOptionsModal;
    window.openWarehouseOptionsModal = openWarehouseOptionsModal;
})();
