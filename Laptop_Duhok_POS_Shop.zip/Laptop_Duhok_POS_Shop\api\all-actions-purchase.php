<?php
// POST: supplies, purchase returns
    // --- Purchase Returns: full cart in one request (زڤراندنا کەرەستان بۆ کۆمپانیێ) ---
    if ($act == 'save_purchase_return') {
        // Ensure purchase_returns table exists
        $conn->query("CREATE TABLE IF NOT EXISTS `purchase_returns` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `company_id` int(11) DEFAULT NULL,
            `company_name` varchar(255) DEFAULT NULL,
            `items_json` longtext DEFAULT NULL,
            `total` decimal(10,2) DEFAULT 0.00,
            `date` datetime DEFAULT NULL,
            `user` varchar(255) DEFAULT NULL,
            `note` text DEFAULT NULL,
            `transaction_id` varchar(50) DEFAULT NULL,
            `supplier_invoice_number` varchar(100) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        $companyId = (int)($_POST['company_id'] ?? 0);
        $companyName = trim($_POST['company_name'] ?? '');
        $itemsJson = $_POST['items'] ?? '[]';
        $note = trim($_POST['note'] ?? '');
        $supplierInvoiceNumber = isset($_POST['supplier_invoice_number']) ? trim($_POST['supplier_invoice_number']) : '';
        $user = $_POST['user'] ?? 'System';
        $date = date('Y-m-d H:i:s');
        $txnId = uniqid('TXPR');

        $items = json_decode($itemsJson, true);
        if (!is_array($items) || count($items) === 0) {
            echo json_encode(["status"=>"error", "message"=>"لیستا ئایتمان بەتاڵە."]); exit();
        }
        if ($supplierInvoiceNumber === '') {
            echo json_encode(["status"=>"error", "message"=>"ژمارا پسوولا کۆمپانیێ پێدڤیە (پێدڤیە)."]); exit();
        }

        // Resolve company
        if ($companyId > 0) {
            $st = $conn->prepare("SELECT id, name FROM companies WHERE id = ? AND (is_active IS NULL OR is_active = 1) LIMIT 1");
            $st->bind_param("i", $companyId);
            $st->execute();
            $res = $st->get_result();
            if (!$res || !$row = $res->fetch_assoc()) {
                echo json_encode(["status"=>"error", "message"=>"کۆمپانیا نەهاتە دیتن."]); exit();
            }
            $companyName = $row['name'];
            $companyId = (int)$row['id'];
        } elseif ($companyName !== '') {
            $st = $conn->prepare("SELECT id, name FROM companies WHERE name = ? AND (is_active IS NULL OR is_active = 1) LIMIT 1");
            $st->bind_param("s", $companyName);
            $st->execute();
            $res = $st->get_result();
            if (!$res || !$row = $res->fetch_assoc()) {
                echo json_encode(["status"=>"error", "message"=>"کۆمپانیا نەهاتە دیتن."]); exit();
            }
            $companyId = (int)$row['id'];
            $companyName = $row['name'];
        } else {
            echo json_encode(["status"=>"error", "message"=>"هەڵبژێرە کۆمپانیا."]); exit();
        }

        $resolvedInv = pos_resolve_purchase_supplier_invoice_ref($conn, $companyName, $supplierInvoiceNumber);
        if ($resolvedInv === null) {
            echo json_encode(["status"=>"error", "message"=>"ئەڤ ژمارا پسوولەیێ ($supplierInvoiceNumber) بۆ ڤێ کۆمپانیێ ($companyName) نەهاتیە دیتن. ژمارا پسوولێ کۆمپانیا یان ژمارا کڕینێ (وەک 000045) بنووسە."]); exit();
        }
        $supplierInvoiceNumber = (string)$resolvedInv['canonical'];
        $purchaseTxnId = trim((string)($resolvedInv['transaction_id'] ?? ''));
        $resolvedSupInv = trim((string)($resolvedInv['supplier_invoice_number'] ?? ''));
        checkAndAddCol($conn, 'supplies', 'warehouse_id', 'INT NOT NULL DEFAULT 1');

        $conn->begin_transaction();
        try {
            $grandTotal = 0;
            $validLines = [];
            foreach ($items as $row) {
                $pid = (int)($row['productId'] ?? 0);
                $qty = (float)($row['qty'] ?? 0);
                $unit = isset($row['unit']) ? $row['unit'] : 'piece';
                $costPerUnit = (float)($row['costPerUnit'] ?? 0);
                $discount = (float)($row['discount'] ?? 0);
                if ($pid <= 0 || $qty <= 0) continue;

                $stmtP = $conn->prepare("SELECT id, name, qty, trackStock, pieces_per_pack, packs_per_carton, qty_mode, unitType, unit_show_pack, unit_show_carton FROM products WHERE id = ? FOR UPDATE");
                $stmtP->bind_param("i", $pid);
                $stmtP->execute();
                $resP = $stmtP->get_result();
                if (!$resP || !$p = $resP->fetch_assoc()) continue;

                $qty = normalizeQtyForProductData($p, $qty);
                if ($qty <= 0) continue;
                $ppp = max(1, (int)($p['pieces_per_pack'] ?? 1));
                $ppc = max(1, (int)($p['packs_per_carton'] ?? 1));
                $mult = ($unit === 'carton') ? ($ppp * $ppc) : (($unit === 'pack') ? $ppp : 1);
                $pieces = (float)($qty * (float)$mult);
                if ($pieces <= 0) continue;

                $stAvail = $conn->prepare(
                    "SELECT COALESCE(SUM(qtyAdded), 0) AS avail FROM supplies
                     WHERE company = ? AND prodId = ?
                     AND (
                        (supplier_invoice_number != '' AND supplier_invoice_number = ?)
                        OR (transaction_id != '' AND transaction_id = ?)
                     )"
                );
                if ($stAvail) {
                    $matchSup = $resolvedSupInv !== '' ? $resolvedSupInv : $supplierInvoiceNumber;
                    $matchTxn = $purchaseTxnId !== '' ? $purchaseTxnId : $supplierInvoiceNumber;
                    $stAvail->bind_param('siss', $companyName, $pid, $matchSup, $matchTxn);
                    $stAvail->execute();
                    $resAvail = $stAvail->get_result();
                    $availPieces = ($resAvail && ($ar = $resAvail->fetch_assoc())) ? (float)($ar['avail'] ?? 0) : 0;
                    if ($pieces > $availPieces + 0.0001) {
                        $conn->rollback();
                        $name = $p['name'] ?? '';
                        echo json_encode([
                            'status' => 'error',
                            'message' => "ناتوانیت زیاتر بزڤڕینی: $name (داواکراو: $pieces تاک، بەردەست: $availPieces تاک لە پسوولێ $supplierInvoiceNumber)"
                        ], JSON_UNESCAPED_UNICODE);
                        exit();
                    }
                }

                $lineTotal = roundMoney(max(0, $qty * $costPerUnit - $discount));
                $grandTotal = roundMoney($grandTotal + $lineTotal);
                $lineWhId = 0;
                $matchSupWh = $resolvedSupInv !== '' ? $resolvedSupInv : $supplierInvoiceNumber;
                $matchTxnWh = $purchaseTxnId !== '' ? $purchaseTxnId : $supplierInvoiceNumber;
                $stWh = $conn->prepare(
                    "SELECT warehouse_id FROM supplies
                     WHERE company = ? AND prodId = ? AND qtyAdded > 0
                       AND COALESCE(type, '') NOT IN ('return', 'opening')
                       AND (
                            (supplier_invoice_number != '' AND supplier_invoice_number = ?)
                            OR (transaction_id != '' AND transaction_id = ?)
                       )
                     ORDER BY id ASC LIMIT 1"
                );
                if ($stWh) {
                    $stWh->bind_param('siss', $companyName, $pid, $matchSupWh, $matchTxnWh);
                    $stWh->execute();
                    $whRow = $stWh->get_result()->fetch_assoc();
                    if ($whRow) $lineWhId = (int)($whRow['warehouse_id'] ?? 0);
                }
                if ($lineWhId <= 0 && function_exists('pos_default_warehouse_id')) {
                    $lineWhId = (int)pos_default_warehouse_id($conn);
                }
                if ($lineWhId <= 0) $lineWhId = 1;

                if ($p['trackStock']) {
                    if ((float)$p['qty'] < $pieces) {
                        $conn->rollback();
                        echo json_encode(["status"=>"error", "message"=>"مەخزەن تێر ناکەت: " . ($p['name'] ?? '') . " (پێدڤی: $pieces، بەردەست: " . (float)$p['qty'] . ")"]); exit();
                    }
                    if (function_exists('pos_adjust_tracked_stock')) {
                        pos_adjust_tracked_stock($conn, (int)$pid, -(float)$pieces, $lineWhId);
                    } else {
                        $stmtU = $conn->prepare("UPDATE products SET qty = qty - ? WHERE id = ?");
                        $stmtU->bind_param("di", $pieces, $pid);
                        $stmtU->execute();
                    }
                }

                $retWhId = (int)$lineWhId;
                $stmtS = $conn->prepare("INSERT INTO supplies (company, prodId, itemName, qtyAdded, totalCost, date, type, transaction_id, supplier_invoice_number, warehouse_id) VALUES (?, ?, ?, ?, ?, ?, 'return', ?, ?, ?)");
                $negQty = -$pieces;
                $itemName = $p['name'] ?? '';
                $stmtS->bind_param("sisddsssi", $companyName, $pid, $itemName, $negQty, $lineTotal, $date, $txnId, $supplierInvoiceNumber, $retWhId);
                $stmtS->execute();

                $unitCost = $pieces != 0 ? $lineTotal / $pieces : 0;
                insertStockMovement($conn, $pid, '', 'supplier_return', -$pieces, $unitCost, $lineTotal, 'purchase_return', 0, $date, $user, $companyName, $retWhId);

                $validLines[] = ['productId'=>$pid, 'productName'=>$itemName, 'qty'=>$qty, 'unit'=>$unit, 'costPerUnit'=>$costPerUnit, 'discount'=>$discount, 'pieces'=>$pieces, 'lineTotal'=>$lineTotal];
            }

            if (count($validLines) === 0) {
                $conn->rollback();
                echo json_encode(["status"=>"error", "message"=>"چ ڕێز نەهاتنە بکارئینان."]); exit();
            }

            $fin = pos_apply_purchase_return_financials($conn, $companyId, $companyName, $grandTotal, $date, $txnId, $supplierInvoiceNumber, $user, count($validLines), $purchaseTxnId);

            $stmtPR = $conn->prepare("INSERT INTO purchase_returns (company_id, company_name, items_json, total, `date`, `user`, note, transaction_id, supplier_invoice_number, cash_refunded, debt_adjusted) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $itemsJsonStored = json_encode($validLines);
            $cashRef = (float)$fin['cash_refunded'];
            $debtAdj = (float)$fin['debt_adjusted'];
            $stmtPR->bind_param("issdsssssdd", $companyId, $companyName, $itemsJsonStored, $grandTotal, $date, $user, $note, $txnId, $supplierInvoiceNumber, $cashRef, $debtAdj);
            $stmtPR->execute();
            $returnId = $stmtPR->insert_id;

            $conn->commit();
            touchLastUpdate($conn);
            echo json_encode([
                "status" => "success",
                "id" => $returnId,
                "date" => $date,
                "transaction_id" => $txnId,
                "payment_type" => $fin['payment_type'],
                "debt_adjusted" => $fin['debt_adjusted'],
                "cash_refunded" => $fin['cash_refunded'],
                "company_balance" => $fin['company_balance'],
            ]); exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(["status"=>"error", "message"=>$e->getMessage()]); exit();
        }
    }

    if($act == 'save_company') {
        // Ensure optional debt-limit columns exist (for opening balance + warning)
        checkAndAddCol($conn, 'companies', 'debt_limit', "DECIMAL(18,3) DEFAULT 0");
        checkAndAddCol($conn, 'companies', 'opening_balance', "DECIMAL(18,3) DEFAULT 0");
        if (function_exists('pos_ensure_payment_due_schema')) pos_ensure_payment_due_schema($conn);
        pos_ensure_wide_debt_money_columns($conn);

        $name = trim($_POST['name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $addr = trim($_POST['address'] ?? '');
        list($opening, $limit) = pos_debt_form_amounts_to_stored_iqd($conn, $_POST['opening_balance'] ?? 0, $_POST['debt_limit'] ?? 0);
        $paymentTermValue = max(0, (int)($_POST['payment_term_value'] ?? 0));
        $paymentTermUnit = pos_normalize_payment_term_unit($_POST['payment_term_unit'] ?? 'day');
        if ($name === '') { echo json_encode(["status"=>"error", "message"=>"ناڤێ کۆمپانیێ پێدڤیە."]); exit(); }

        $stmt = $conn->prepare("INSERT INTO companies (name, phone, address, balance, debt_limit, opening_balance, payment_term_value, payment_term_unit) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssdddis", $name, $phone, $addr, $opening, $limit, $opening, $paymentTermValue, $paymentTermUnit);
        if($stmt->execute()) { echo json_encode(["status"=>"success", "id"=>$stmt->insert_id, "balance"=>$opening]); exit(); }
        else { echo json_encode(["status"=>"error", "message"=>$stmt->error ?: "نەشیا تۆمار کەت."]); exit(); }
    }

    if($act == 'update_company') {
        $id = (int)($_POST['id'] ?? 0);
        // Ensure optional debt-limit columns exist (for opening balance + warning)
        checkAndAddCol($conn, 'companies', 'debt_limit', "DECIMAL(18,3) DEFAULT 0");
        checkAndAddCol($conn, 'companies', 'opening_balance', "DECIMAL(18,3) DEFAULT 0");
        if (function_exists('pos_ensure_payment_due_schema')) pos_ensure_payment_due_schema($conn);
        pos_ensure_wide_debt_money_columns($conn);

        $name = trim($_POST['name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $addr = trim($_POST['address'] ?? '');
        list($openingNew, $limit) = pos_debt_form_amounts_to_stored_iqd($conn, $_POST['opening_balance'] ?? 0, $_POST['debt_limit'] ?? 0);
        $paymentTermValue = max(0, (int)($_POST['payment_term_value'] ?? 0));
        $paymentTermUnit = pos_normalize_payment_term_unit($_POST['payment_term_unit'] ?? 'day');
        if ($id <= 0 || $name === '') { echo json_encode(["status"=>"error", "message"=>"ناڤێ کۆمپانیێ پێدڤیە."]); exit(); }

        $conn->begin_transaction();
        try {
            $sel = $conn->prepare("SELECT name, opening_balance FROM companies WHERE id = ? FOR UPDATE");
            $sel->bind_param("i", $id);
            $sel->execute();
            $res = $sel->get_result();
            if(!$res || !($row = $res->fetch_assoc())) throw new Exception("کۆمپانیا نەهاتە دیتن");

            $oldName = trim((string)($row['name'] ?? ''));
            $openingOld = roundMoney((float)($row['opening_balance'] ?? 0));
            $delta = roundMoney($openingNew - $openingOld);

            $up = $conn->prepare("UPDATE companies SET name = ?, phone = ?, address = ?, debt_limit = ?, opening_balance = ?, payment_term_value = ?, payment_term_unit = ?, balance = balance + ? WHERE id = ?");
            $up->bind_param("sssddisdi", $name, $phone, $addr, $limit, $openingNew, $paymentTermValue, $paymentTermUnit, $delta, $id);
            $up->execute();

            if ($oldName !== '' && $oldName !== $name) {
                $stS = $conn->prepare("UPDATE supplies SET company = ? WHERE company = ?");
                if ($stS) {
                    $stS->bind_param("ss", $name, $oldName);
                    $stS->execute();
                }
                $stP = $conn->prepare("UPDATE products SET supplier = ? WHERE supplier = ?");
                if ($stP) {
                    $stP->bind_param("ss", $name, $oldName);
                    $stP->execute();
                }
                $prCheck = $conn->query("SHOW TABLES LIKE 'purchase_returns'");
                if ($prCheck && $prCheck->num_rows > 0) {
                    $stPr = $conn->prepare("UPDATE purchase_returns SET company_name = ? WHERE company_name = ?");
                    if ($stPr) {
                        $stPr->bind_param("ss", $name, $oldName);
                        $stPr->execute();
                    }
                }
            }

            $balStmt = $conn->prepare("SELECT balance FROM companies WHERE id = ?");
            $balStmt->bind_param("i", $id);
            $balStmt->execute();
            $balRes = $balStmt->get_result();
            $newBalance = ($balRes && ($brow = $balRes->fetch_assoc())) ? roundMoney((float)$brow['balance']) : 0;

            $conn->commit();
            logAction($conn, 'Admin', 'edit_company', "Updated company: #$id $name");
            echo json_encode([
                "status"=>"success",
                "balance"=>$newBalance,
                "opening_balance"=>$openingNew,
                "debt_limit"=>$limit,
                "payment_term_value"=>$paymentTermValue,
                "payment_term_unit"=>$paymentTermUnit,
                "name"=>$name,
                "old_name"=>$oldName
            ]); exit();
        } catch(Exception $e) {
            $conn->rollback();
            echo json_encode(["status"=>"error", "message"=>$e->getMessage()]); exit();
        }
    }

    if($act == 'save_expense') {
        if (function_exists('pos_ensure_expense_currency_columns')) {
            pos_ensure_expense_currency_columns($conn);
        }
        $note = $_POST['note'];
        $user = $_POST['user'] ?? 'System';
        $date = date('Y-m-d H:i:s');
        $type = $_POST['type'] ?? 'operational';
        $txnId = uniqid('TXE');
        $currency = function_exists('pos_normalize_currency_mode')
            ? pos_normalize_currency_mode($_POST['currency'] ?? ($_POST['base_currency'] ?? 'IQD'))
            : 'IQD';
        $postedAmt = isset($_POST['amount']) ? (float)str_replace(',', '', (string)$_POST['amount']) : 0;
        $exchangeRate = isset($_POST['exchange_rate']) ? (float)$_POST['exchange_rate'] : 0;
        if ($exchangeRate <= 0 && function_exists('pos_current_expense_exchange_rate')) {
            $exchangeRate = pos_current_expense_exchange_rate($conn);
        }
        if ($exchangeRate <= 0) {
            $exchangeRate = 1500.0;
        }
        if ($currency === 'USD') {
            $amount = function_exists('pos_round_usd_catalog_store') ? pos_round_usd_catalog_store($postedAmt) : round($postedAmt, 2);
        } else {
            $amount = roundMoney($postedAmt);
        }
        $ledgerIqd = function_exists('pos_convert_currency')
            ? pos_convert_currency($amount, $currency, 'IQD', $exchangeRate)
            : (($currency === 'USD') ? roundMoney($amount * $exchangeRate) : roundMoney($amount));
        
        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("INSERT INTO expenses (note, amount, `date`, user, type, transaction_id, currency, exchange_rate) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sdsssssd", $note, $amount, $date, $user, $type, $txnId, $currency, $exchangeRate);
            $stmt->execute();
            $expId = $stmt->insert_id;
            
            // UNIFIED LEDGER ENTRY (always IQD for drawer)
            $stmtL = $conn->prepare("INSERT INTO ledger (transaction_id, type, amount, related_id, note, date) VALUES (?, 'expense', ?, ?, ?, ?)");
            $stmtL->bind_param("sdiss", $txnId, $ledgerIqd, $expId, $note, $date);
            $stmtL->execute();
            
            $conn->commit();
            echo json_encode([
                "status" => "success",
                "id" => $expId,
                "date" => $date,
                "transaction_id" => $txnId,
                "currency" => $currency,
                "exchange_rate" => $exchangeRate,
                "amount" => $amount,
            ]); exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(["status"=>"error", "message"=>$e->getMessage()]); exit();
        }
    }

    if ($act == 'update_expense') {
        pos_session_require_login_json();
        if (!pos_session_can_manage_expenses()) {
            pos_json_perm_denied();
        }
        if (function_exists('pos_ensure_expense_currency_columns')) {
            pos_ensure_expense_currency_columns($conn);
        }
        $id = (int)($_POST['id'] ?? 0);
        $note = trim((string)($_POST['note'] ?? ''));
        $currency = function_exists('pos_normalize_currency_mode')
            ? pos_normalize_currency_mode($_POST['currency'] ?? ($_POST['base_currency'] ?? ''))
            : 'IQD';
        $postedAmt = isset($_POST['amount']) ? (float)str_replace(',', '', (string)$_POST['amount']) : 0;
        $exchangeRate = isset($_POST['exchange_rate']) ? (float)$_POST['exchange_rate'] : 0;
        if ($id <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'ناسنامەی مەزاختن نادروستە.']);
            exit();
        }
        if ($note === '') {
            echo json_encode(['status' => 'error', 'message' => 'تێبینی پێویستە.']);
            exit();
        }
        if ($postedAmt <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'بڕی مەزاختن دەبێت گەورەتر بێت لە ٠.']);
            exit();
        }

        $st = $conn->prepare('SELECT * FROM expenses WHERE id = ? LIMIT 1');
        $st->bind_param('i', $id);
        $st->execute();
        $res = $st->get_result();
        $row = $res ? $res->fetch_assoc() : null;
        if (!$row) {
            echo json_encode(['status' => 'error', 'message' => 'مەزاختن نەدۆزرایەوە.']);
            exit();
        }
        if (($row['type'] ?? '') === 'purchase') {
            echo json_encode(['status' => 'error', 'message' => 'مەزاختنێ کڕینێ ناتوانرێت لێرە دەستکاری بکرێت — کڕینەکە دەستکاری بکە.']);
            exit();
        }

        $oldCurrency = strtoupper(trim((string)($row['currency'] ?? 'IQD')));
        if ($oldCurrency !== 'USD' && $oldCurrency !== 'IQD') {
            $oldCurrency = 'IQD';
        }
        if ($currency !== 'USD' && $currency !== 'IQD') {
            $currency = $oldCurrency;
        }
        $oldRate = (float)($row['exchange_rate'] ?? 0);
        if ($exchangeRate <= 0) {
            $exchangeRate = $oldRate;
        }
        if ($exchangeRate <= 0 && function_exists('pos_current_expense_exchange_rate')) {
            $exchangeRate = pos_current_expense_exchange_rate($conn);
        }
        if ($exchangeRate <= 0) {
            $exchangeRate = 1500.0;
        }
        if ($currency === 'USD') {
            $amount = function_exists('pos_round_usd_catalog_store') ? pos_round_usd_catalog_store($postedAmt) : round($postedAmt, 2);
        } else {
            $amount = roundMoney($postedAmt);
        }
        $ledgerIqd = function_exists('pos_convert_currency')
            ? pos_convert_currency($amount, $currency, 'IQD', $exchangeRate)
            : (($currency === 'USD') ? roundMoney($amount * $exchangeRate) : roundMoney($amount));
        $oldAmount = (float)($row['amount'] ?? 0);
        $oldIqd = function_exists('pos_expense_amount_iqd') ? pos_expense_amount_iqd($row) : roundMoney($oldAmount);
        $txnId = (string)($row['transaction_id'] ?? '');
        $expDate = (string)($row['date'] ?? date('Y-m-d H:i:s'));
        $user = $_SESSION['user_name'] ?? ($_POST['user'] ?? 'System');

        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare('UPDATE expenses SET note = ?, amount = ?, currency = ?, exchange_rate = ? WHERE id = ?');
            $stmt->bind_param('sdsdi', $note, $amount, $currency, $exchangeRate, $id);
            $stmt->execute();

            if ($txnId !== '') {
                $stL = $conn->prepare("UPDATE ledger SET amount = ?, note = ? WHERE transaction_id = ? AND type = 'expense'");
                $stL->bind_param('dss', $ledgerIqd, $note, $txnId);
                $stL->execute();
            } else {
                $stL = $conn->prepare("UPDATE ledger SET amount = ?, note = ? WHERE related_id = ? AND type = 'expense'");
                $stL->bind_param('dsi', $ledgerIqd, $note, $id);
                $stL->execute();
            }

            $oldJson = json_encode($row, JSON_UNESCAPED_UNICODE);
            $newRow = array_merge($row, ['note' => $note, 'amount' => $amount, 'currency' => $currency, 'exchange_rate' => $exchangeRate]);
            $newJson = json_encode($newRow, JSON_UNESCAPED_UNICODE);
            logAction($conn, $user, 'update_expense', "Updated expense #$id: $note | Amount: $oldAmount → $amount $currency", null, 'expense', $id, $oldJson, $newJson);
            logGeneralHistory($conn, 'expense', (string)$id, 'update', $note, $newJson);

            $conn->commit();
            echo json_encode([
                'status' => 'success',
                'expense' => [
                    'id' => $id,
                    'note' => $note,
                    'amount' => $amount,
                    'currency' => $currency,
                    'exchange_rate' => $exchangeRate,
                    'date' => $expDate,
                    'user' => (string)($row['user'] ?? ''),
                    'type' => (string)($row['type'] ?? 'operational'),
                    'transaction_id' => $txnId,
                ],
                'old_amount' => $oldAmount,
                'old_iqd' => $oldIqd,
                'ledger_iqd' => $ledgerIqd,
            ]);
            exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
            exit();
        }
    }

    if ($act == 'delete_expense') {
        if (function_exists('pos_ensure_expenses_archive_columns')) {
            pos_ensure_expenses_archive_columns($conn);
        }
        if (!pos_session_can_manage_expenses()) {
            pos_json_perm_denied();
        }
        $id = (int)($_POST['id'] ?? 0);
        $user = $_SESSION['user_name'] ?? ($_POST['user'] ?? 'System');
        if ($id <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'ناسنامەی مەزاختن نادروستە.']);
            exit();
        }

        $st = $conn->prepare('SELECT * FROM expenses WHERE id = ? LIMIT 1');
        $st->bind_param('i', $id);
        $st->execute();
        $res = $st->get_result();
        $row = $res ? $res->fetch_assoc() : null;
        if (!$row) {
            echo json_encode(['status' => 'error', 'message' => 'مەزاختن نەدۆزرایەوە.']);
            exit();
        }
        if (($row['type'] ?? '') === 'purchase') {
            echo json_encode(['status' => 'error', 'message' => 'مەزاختنێ کڕینێ ناتوانرێت لێرە بسڕدرێتەوە — کڕینەکە بسڕەوە.']);
            exit();
        }

        $conn->begin_transaction();
        try {
            $now = date('Y-m-d H:i:s');
            $expId = (int)$row['id'];
            $note = (string)($row['note'] ?? '');
            $amount = roundMoney($row['amount'] ?? 0);
            $expDate = (string)($row['date'] ?? $now);
            $expUser = (string)($row['user'] ?? '');
            $expType = (string)($row['type'] ?? 'operational');
            $txnId = (string)($row['transaction_id'] ?? '');
            $expCurrency = strtoupper(trim((string)($row['currency'] ?? 'IQD')));
            if ($expCurrency !== 'USD' && $expCurrency !== 'IQD') {
                $expCurrency = 'IQD';
            }
            $expRate = (float)($row['exchange_rate'] ?? 0);
            $archiveReason = 'deleted';

            $stmtA = $conn->prepare('INSERT INTO expenses_archive (id, note, amount, `date`, user, type, transaction_id, archived_at, archive_reason, deleted_by, currency, exchange_rate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE note = VALUES(note), amount = VALUES(amount), `date` = VALUES(`date`), user = VALUES(user), type = VALUES(type), transaction_id = VALUES(transaction_id), archived_at = VALUES(archived_at), archive_reason = VALUES(archive_reason), deleted_by = VALUES(deleted_by), currency = VALUES(currency), exchange_rate = VALUES(exchange_rate)');
            $stmtA->bind_param('isdssssssssd', $expId, $note, $amount, $expDate, $expUser, $expType, $txnId, $now, $archiveReason, $user, $expCurrency, $expRate);
            $stmtA->execute();

            if ($txnId !== '') {
                $stDL = $conn->prepare("DELETE FROM ledger WHERE transaction_id = ? AND type = 'expense'");
                $stDL->bind_param('s', $txnId);
                $stDL->execute();
            } else {
                $stDL = $conn->prepare("DELETE FROM ledger WHERE related_id = ? AND type = 'expense'");
                $stDL->bind_param('i', $expId);
                $stDL->execute();
            }

            $stDE = $conn->prepare('DELETE FROM expenses WHERE id = ?');
            $stDE->bind_param('i', $expId);
            $stDE->execute();

            $oldJson = json_encode($row, JSON_UNESCAPED_UNICODE);
            $logDetails = "Deleted expense #$expId: $note | Amount: $amount | Original date: $expDate";
            logAction($conn, $user, 'delete_expense', $logDetails, null, 'expense', $expId, $oldJson, null);
            logGeneralHistory($conn, 'expense', (string)$expId, 'delete', $note, $oldJson);

            $conn->commit();
            touchLastUpdate($conn);
            echo json_encode([
                'status' => 'success',
                'deleted' => [
                    'id' => $expId,
                    'note' => $note,
                    'amount' => $amount,
                    'date' => $expDate,
                    'user' => $expUser,
                    'type' => $expType,
                    'transaction_id' => $txnId,
                    'currency' => $expCurrency,
                    'exchange_rate' => $expRate,
                    'archived_at' => $now,
                    'archive_reason' => $archiveReason,
                    'deleted_by' => $user,
                ],
            ]);
            exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
            exit();
        }
    }

    if($act == 'delete_product') {
        $id = (int)$_POST['id'];
        $user = $_POST['user'] ?? 'System';
        $st = $conn->prepare("SELECT 1 FROM supplies WHERE prodId=? LIMIT 1"); $st->bind_param("i", $id); $st->execute(); $chk = $st->get_result();
        if($chk && $chk->num_rows > 0) { echo json_encode(["status"=>"error", "message"=>"نەشێی ژێببەی چونکە لڤینێن دارایی (کڕین) هەنە."]); exit(); }
        $st = $conn->prepare("SELECT 1 FROM waste WHERE prodId=? LIMIT 1"); $st->bind_param("i", $id); $st->execute(); $chk = $st->get_result();
        if($chk && $chk->num_rows > 0) { echo json_encode(["status"=>"error", "message"=>"نەشێی ژێببەی چونکە تەلەف هەنە."]); exit(); }
        $st = $conn->prepare("SELECT 1 FROM stock_movements WHERE product_id=? LIMIT 1"); $st->bind_param("i", $id); $st->execute(); $chk = $st->get_result();
        if($chk && $chk->num_rows > 0) { echo json_encode(["status"=>"error", "message"=>"نەشێی ژێببەی چونکە مێژوویا لڤینان هەیە."]); exit(); }
        $st = $conn->prepare("SELECT name FROM products WHERE id=?"); $st->bind_param("i", $id); $st->execute(); $res = $st->get_result();
        if($res && $row=$res->fetch_assoc()) {
            logAction($conn, $user, 'delete_product', "Deleted Item: {$row['name']}", null, 'product', $id, null, null);
            logGeneralHistory($conn, 'product', $id, 'delete', "Deleted Item: {$row['name']}");
        }
        $st = $conn->prepare("DELETE FROM products WHERE id=?"); $st->bind_param("i", $id); $st->execute();
        echo json_encode(["status"=>"success"]); exit();
    }

    if($act == 'void_product') {
        $id = (int)$_POST['id'];
        $user = $_POST['user'] ?? 'System';
        if ($id <= 0) {
            echo json_encode(["status"=>"error", "message"=>"ئایتم نەهاتە دیتن"]); exit();
        }
        // Blocking void when stock or purchase history exists prevents the pharmacy bug:
        // invoice still shows the item, but warehouse/POS say "ئایتم نییە".
        $stQty = $conn->prepare("SELECT name, COALESCE(qty,0) AS qty, COALESCE(forSale,1) AS forSale FROM products WHERE id = ? LIMIT 1");
        if (!$stQty) { echo json_encode(["status"=>"error", "message"=>"Database error"]); exit(); }
        $stQty->bind_param("i", $id);
        $stQty->execute();
        $row = $stQty->get_result()->fetch_assoc();
        if (!$row) { echo json_encode(["status"=>"error", "message"=>"ئایتم نەهاتە دیتن"]); exit(); }
        $qty = (float)($row['qty'] ?? 0);
        $whQty = 0.0;
        $stWh = $conn->prepare("SELECT COALESCE(SUM(qty),0) AS t FROM warehouse_stock WHERE product_id = ?");
        if ($stWh) {
            $stWh->bind_param("i", $id);
            $stWh->execute();
            $whRow = $stWh->get_result()->fetch_assoc();
            if ($whRow) $whQty = (float)($whRow['t'] ?? 0);
        }
        if ($qty > 0.000001 || $whQty > 0.000001) {
            echo json_encode([
                "status" => "error",
                "reason" => "has_stock",
                "message" => "ناتوانیت ئەم ئایتمە ناچالاک بکەیت چونکە هێشتا کۆگەی هەیە. بۆ شاردنەوە لە فرۆشتن تەنها «پیشاندان لە فرۆتن» ناکارا بکە."
            ], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $stSup = $conn->prepare("SELECT 1 FROM supplies WHERE prodId = ? LIMIT 1");
        if ($stSup) {
            $stSup->bind_param("i", $id);
            $stSup->execute();
            $supChk = $stSup->get_result();
            if ($supChk && $supChk->num_rows > 0) {
                echo json_encode([
                    "status" => "error",
                    "reason" => "has_purchases",
                    "message" => "ئەم ئایتمە مێژووی کڕینی هەیە — ناچالاککردن دەیکاتە «نییە» لە کۆگە/فرۆشتن بەڵام لە پسوولە دەمێنێتەوە. بۆ شاردنەوە لە فرۆشتن «پیشاندان لە فرۆتن» ناکارا بکە، یان ناو بگۆڕە."
                ], JSON_UNESCAPED_UNICODE);
                exit();
            }
        }
        $st = $conn->prepare("UPDATE products SET is_active = 0 WHERE id = ?");
        $st->bind_param("i", $id);
        $st->execute();
        logAction($conn, $user, 'void_product', "Voided/Deactivated Item: {$row['name']} (ID $id)", null, 'product', $id, null, null);
        echo json_encode(["status"=>"success"]); exit();
    }

    if ($act == 'reactivate_product') {
        header('Content-Type: application/json; charset=utf-8');
        $id = (int)($_POST['id'] ?? 0);
        $user = $_POST['user'] ?? 'System';
        if ($id <= 0) {
            echo json_encode(["status"=>"error", "message"=>"ئایتم نەهاتە دیتن"], JSON_UNESCAPED_UNICODE); exit();
        }
        checkAndAddCol($conn, 'products', 'is_active', 'TINYINT(1) NOT NULL DEFAULT 1');
        $st = $conn->prepare("UPDATE products SET is_active = 1, forSale = 1 WHERE id = ?");
        if (!$st) {
            echo json_encode(["status"=>"error", "message"=>"Database error"], JSON_UNESCAPED_UNICODE); exit();
        }
        $st->bind_param("i", $id);
        $st->execute();
        if ($st->affected_rows < 0) {
            echo json_encode(["status"=>"error", "message"=>"نەشیا چالاک بکرێتەوە"], JSON_UNESCAPED_UNICODE); exit();
        }
        $stP = $conn->prepare("SELECT * FROM products WHERE id = ? LIMIT 1");
        $stP->bind_param("i", $id);
        $stP->execute();
        $prod = $stP->get_result()->fetch_assoc();
        if (!$prod) {
            echo json_encode(["status"=>"error", "message"=>"ئایتم نەهاتە دیتن"], JSON_UNESCAPED_UNICODE); exit();
        }
        try {
            logAction($conn, $user, 'reactivate_product', "Reactivated Item: {$prod['name']} (ID $id)", null, 'product', $id, null, null);
        } catch (Throwable $e) {}
        touchLastUpdate($conn);
        $mapped = null;
        if (function_exists('pos_map_product_row_for_client')) {
            [$bq, $be] = function_exists('pos_load_batch_maps_for_products')
                ? pos_load_batch_maps_for_products($conn, [$id])
                : [[], []];
            $mapped = pos_map_product_row_for_client($prod, $bq, $be, false);
        }
        echo json_encode(["status"=>"success", "id"=>$id, "product"=>$mapped], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if ($act == 'save_manufacturer') {
        if (function_exists('pos_ensure_manufacturers_schema')) {
            pos_ensure_manufacturers_schema($conn);
        }
        if (function_exists('pos_manufacturer_slot_limit_message')) {
            $slotMsg = pos_manufacturer_slot_limit_message($conn);
            if ($slotMsg !== null) {
                echo json_encode(['status' => 'error', 'reason' => 'manufacturer_slot_limit', 'message' => $slotMsg]);
                exit();
            }
        }
        $name = trim($_POST['name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $note = trim($_POST['note'] ?? '');
        if ($name === '') { echo json_encode(["status" => "error", "message" => "ناڤێ کۆمپانیا دروستکەر پێدڤیە."]); exit(); }
        if (strlen($name) > 100) $name = substr($name, 0, 100);
        if (strlen($phone) > 50) $phone = substr($phone, 0, 50);
        if (strlen($note) > 255) $note = substr($note, 0, 255);
        $stmt = $conn->prepare("INSERT INTO manufacturers (name, phone, note) VALUES (?, ?, ?)");
        if (!$stmt) {
            echo json_encode(["status" => "error", "message" => "خشتەی کۆمپانیا دروستکەر ئامادە نییە: " . ($conn->error ?: 'prepare failed')]); exit();
        }
        $stmt->bind_param("sss", $name, $phone, $note);
        if ($stmt->execute()) {
            echo json_encode(["status" => "success", "id" => $stmt->insert_id]); exit();
        }
        echo json_encode(["status" => "error", "message" => $stmt->error ?: "نەشیا تۆمار کەت."]); exit();
    }

    if ($act == 'update_manufacturer') {
        if (function_exists('pos_ensure_manufacturers_schema')) {
            pos_ensure_manufacturers_schema($conn);
        }
        $id = (int)($_POST['id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $note = trim($_POST['note'] ?? '');
        if ($id <= 0 || $name === '') { echo json_encode(["status" => "error", "message" => "ناڤ پێدڤیە."]); exit(); }
        if (strlen($name) > 100) $name = substr($name, 0, 100);
        if (strlen($phone) > 50) $phone = substr($phone, 0, 50);
        if (strlen($note) > 255) $note = substr($note, 0, 255);
        $sel = $conn->prepare("SELECT name FROM manufacturers WHERE id = ? LIMIT 1");
        if (!$sel) {
            echo json_encode(["status" => "error", "message" => "خشتەی کۆمپانیا دروستکەر ئامادە نییە."]); exit();
        }
        $sel->bind_param("i", $id);
        $sel->execute();
        $res = $sel->get_result();
        if (!$res || !($row = $res->fetch_assoc())) { echo json_encode(["status" => "error", "message" => "نەهاتە دیتن."]); exit(); }
        $oldName = trim((string)($row['name'] ?? ''));
        $up = $conn->prepare("UPDATE manufacturers SET name = ?, phone = ?, note = ? WHERE id = ?");
        if (!$up) {
            echo json_encode(["status" => "error", "message" => "نەشیا نوێ بکرێتەوە: " . ($conn->error ?: 'prepare failed')]); exit();
        }
        $up->bind_param("sssi", $name, $phone, $note, $id);
        $up->execute();
        if ($oldName !== '' && $oldName !== $name) {
            $stP = $conn->prepare("UPDATE products SET manufacturer = ? WHERE manufacturer = ?");
            if ($stP) {
                $stP->bind_param("ss", $name, $oldName);
                $stP->execute();
            }
        }
        logAction($conn, 'Admin', 'edit_manufacturer', "Updated manufacturer: #$id $name");
        echo json_encode(["status" => "success", "id" => $id, "name" => $name, "old_name" => $oldName]); exit();
    }

    if ($act == 'delete_manufacturer') {
        if (function_exists('pos_ensure_manufacturers_schema')) {
            pos_ensure_manufacturers_schema($conn);
        }
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) { echo json_encode(["status" => "error", "message" => "نادروستە."]); exit(); }
        $stmt = $conn->prepare("SELECT name FROM manufacturers WHERE id = ? LIMIT 1");
        if (!$stmt) {
            echo json_encode(["status" => "error", "message" => "خشتەی کۆمپانیا دروستکەر ئامادە نییە."]); exit();
        }
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $res = $stmt->get_result();
        $row = $res ? $res->fetch_assoc() : null;
        $mName = ($row && isset($row['name'])) ? trim((string)$row['name']) : '';
        if ($mName !== '') {
            $stP = $conn->prepare("UPDATE products SET manufacturer = '' WHERE manufacturer = ?");
            if ($stP) {
                $stP->bind_param("s", $mName);
                $stP->execute();
            }
        }
        $del = $conn->prepare("DELETE FROM manufacturers WHERE id = ?");
        $del->bind_param("i", $id);
        $del->execute();
        logAction($conn, $_POST['user'] ?? 'System', 'delete_manufacturer', $mName !== '' ? "Deleted manufacturer: $mName (#$id)" : "Deleted manufacturer ID: $id");
        echo json_encode(["status" => "success"]); exit();
    }

    if($act == 'delete_company') {
        $id = (int)$_POST['id'];
        $stmtName = $conn->prepare("SELECT name FROM companies WHERE id = ?");
        $stmtName->bind_param("i", $id);
        $stmtName->execute();
        $res = $stmtName->get_result();
        $row = $res ? $res->fetch_assoc() : null;
        if($row && trim($row['name']) !== '') {
            $name = $row['name'];
            $chkStmt = $conn->prepare("SELECT 1 FROM supplies WHERE company = ? LIMIT 1");
            $chkStmt->bind_param("s", $name);
            $chkStmt->execute();
            $chk = $chkStmt->get_result();
            if($chk && $chk->num_rows > 0) { echo json_encode(["status"=>"error", "message"=>"نەشێی ژێببەی چونکە لڤینێن دارایی هەنە."]); exit(); }
            $chkStmt2 = $conn->prepare("SELECT 1 FROM ledger WHERE companyId = ? LIMIT 1");
            $chkStmt2->bind_param("i", $id);
            $chkStmt2->execute();
            $chk = $chkStmt2->get_result();
            if($chk && $chk->num_rows > 0) { echo json_encode(["status"=>"error", "message"=>"نەشێی ژێببەی چونکە لڤینێن دەفتەری هەنە."]); exit(); }
        }
        $delStmt = $conn->prepare("DELETE FROM companies WHERE id = ?");
        $delStmt->bind_param("i", $id);
        $delStmt->execute();
        logGeneralHistory($conn, 'company', $id, 'delete', "Deleted company ID: $id");
        $delUser = $_POST['user'] ?? ($_SESSION['user_name'] ?? 'Staff');
        $cDelName = ($row && isset($row['name'])) ? trim((string)$row['name']) : '';
        $delNote = $cDelName !== '' ? "Deleted company: {$cDelName} (#$id)" : "Deleted company ID: $id";
        try {
            logAction($conn, $delUser, 'delete_company', $delNote, null, 'company', $id, null, null);
        } catch (Exception $e) {
        }
        echo json_encode(["status"=>"success"]); exit();
    }

    if($act == 'void_company') {
        $id = (int)$_POST['id'];
        $conn->query("UPDATE companies SET is_active = 0 WHERE id = $id");
        logAction($conn, $_POST['user'] ?? 'System', 'void_company', "Voided company ID: $id");
        echo json_encode(["status"=>"success"]); exit();
    }

    if ($act == 'save_purchase_invoice') {
        checkAndAddCol($conn, 'supplies', 'expiry_date', "DATE DEFAULT NULL");
        checkAndAddCol($conn, 'supplies', 'warehouse_id', 'INT NOT NULL DEFAULT 1');
        checkAndAddCol($conn, 'supplies', 'batch_number', "VARCHAR(100) DEFAULT ''");
        checkAndAddCol($conn, 'supplies', 'is_gift', "TINYINT(1) NOT NULL DEFAULT 0");
        checkAndAddCol($conn, 'supplies', 'payment_due_at', "DATETIME NULL DEFAULT NULL");
        $companyId = (int)($_POST['company_id'] ?? 0);
        $companyName = trim($_POST['company_name'] ?? '');
        if ($companyId > 0) {
            $stCompResolve = $conn->prepare("SELECT id, name FROM companies WHERE id = ? AND (is_active IS NULL OR is_active = 1) LIMIT 1");
            if ($stCompResolve) {
                $stCompResolve->bind_param("i", $companyId);
                $stCompResolve->execute();
                $compResolveRow = $stCompResolve->get_result()->fetch_assoc();
                if ($compResolveRow) {
                    $companyName = trim((string)($compResolveRow['name'] ?? $companyName));
                    $companyId = (int)$compResolveRow['id'];
                }
            }
        } elseif ($companyName !== '') {
            $stCompResolve = $conn->prepare("SELECT id, name FROM companies WHERE name = ? AND (is_active IS NULL OR is_active = 1) LIMIT 1");
            if ($stCompResolve) {
                $stCompResolve->bind_param("s", $companyName);
                $stCompResolve->execute();
                $compResolveRow = $stCompResolve->get_result()->fetch_assoc();
                if ($compResolveRow) {
                    $companyId = (int)$compResolveRow['id'];
                    $companyName = trim((string)($compResolveRow['name'] ?? $companyName));
                }
            }
        }
        $itemsJson = $_POST['items'] ?? '[]';
        $paymentType = strtolower(trim((string)($_POST['type'] ?? 'cash'))); // 'cash', 'credit', 'split', or 'fib'
        if ($paymentType === 'bankcard' || $paymentType === 'bank' || $paymentType === 'card') {
            $paymentType = 'fib';
        }
        $cashPaidSplit = isset($_POST['cash_paid']) ? roundMoney((float)$_POST['cash_paid']) : 0;
        $paidCashDrawer = null;
        $paidBankAmt = 0.0;
        $supplierInvoiceNumber = isset($_POST['supplier_invoice_number']) ? trim($_POST['supplier_invoice_number']) : '';
        $batchNumber = isset($_POST['batch_number']) ? trim($_POST['batch_number']) : '';
        $user = $_POST['user'] ?? 'System';
        $date = date('Y-m-d H:i:s');
        $txnId = allocateNextPurchaseTransactionId($conn);

        $items = json_decode($itemsJson, true);
        if (!is_array($items) || count($items) === 0) {
            echo json_encode(["status"=>"error", "message"=>"سەبەتا کڕینێ یا بەتاڵە."]); exit();
        }
        if ($supplierInvoiceNumber === '') {
            echo json_encode(["status"=>"error", "message"=>"پێدڤیە ژمارا پسوولێ بنڤیسی."]); exit();
        }
        $canUseBatch = function_exists('pos_can_use_purchase_batch') && pos_can_use_purchase_batch($conn);
        if ($canUseBatch && $batchNumber === '') {
            echo json_encode(["status"=>"error", "message"=>"پێدڤیە ژمارا وەجبێ بنڤیسی."]); exit();
        }
        if (!$canUseBatch) {
            $batchNumber = '';
        }

        $purchaseWarehouseId = pos_resolve_product_warehouse_id_for_save($conn, (int)($_POST['warehouse_id'] ?? 0));
        $appSettings = pos_load_app_settings_array($conn);
        $currencyMode = pos_settings_currency_mode_from_array($appSettings);
        $usdRatePerOne = pos_settings_usd_rate_per_one_from_array($appSettings);
        if (isset($_POST['exchange_rate']) && (float)$_POST['exchange_rate'] > 0) {
            $postedRate = (float)$_POST['exchange_rate'];
            $usdRatePerOne = ($postedRate >= 10000) ? ($postedRate / 100.0) : $postedRate;
        }
        $conn->begin_transaction();
        try {
            $lines = [];
            $grandTotal = 0;
            $newExpId = 0;
            foreach ($items as $row) {
                $pid = (int)($row['productId'] ?? 0);
                $qty = (float)($row['qty'] ?? 0);
                $unit = $row['unit'] ?? 'piece';
                $costPerUnit = (float)($row['costPerUnit'] ?? 0);
                $discount = (float)($row['discount'] ?? 0);
                $isGift = !empty($row['isGift']);
                $expiryVisible = !empty($row['expiry_visible']);
                $expiryDate = trim((string)($row['expiry_date'] ?? ''));
                if (!$expiryVisible || $expiryDate === '' || !isValidYmdDate($expiryDate)) {
                    $expiryDate = '';
                }

                $stP = $conn->prepare("SELECT name, pieces_per_pack, packs_per_carton, trackStock, qty_mode, unitType, unit_show_pack, unit_show_carton, base_currency FROM products WHERE id = ? FOR UPDATE");
                $stP->bind_param("i", $pid); $stP->execute(); $rP = $stP->get_result()->fetch_assoc();
                if (!$rP) continue;

                $qty = normalizeQtyForProductData($rP, $qty);
                if ($qty <= 0) continue;
                $ppp = max(1, (int)($rP['pieces_per_pack'] ?? 1));
                $ppc = max(1, (int)($rP['packs_per_carton'] ?? 1));
                $mult = ($unit === 'carton') ? ($ppp * $ppc) : (($unit === 'pack') ? $ppp : 1);
                $pieces = (float)($qty * (float)$mult);

                $lineTotal = $isGift ? 0 : roundMoney(max(0, $qty * $costPerUnit - $discount));
                $grandTotal += $lineTotal;
                $lineWhPosted = (int)($row['warehouseId'] ?? $row['warehouse_id'] ?? 0);
                $lineWarehouseId = $lineWhPosted > 0
                    ? pos_resolve_product_warehouse_id_for_save($conn, $lineWhPosted)
                    : $purchaseWarehouseId;
                $sellPerUnit = isset($row['sellPerUnit']) ? roundMoney(max(0, (float)$row['sellPerUnit'])) : null;
                $costPerUnitStored = $isGift ? 0 : roundMoney(max(0, $costPerUnit));
                $lines[] = ['pid' => $pid, 'qty' => $qty, 'unit' => $unit, 'rP' => $rP, 'pieces' => $pieces, 'lineTotal' => $lineTotal, 'expiry_date' => $expiryDate, 'warehouse_id' => $lineWarehouseId, 'sellPerUnit' => $sellPerUnit, 'costPerUnit' => $costPerUnitStored, 'is_gift' => $isGift ? 1 : 0];
            }

            if (count($lines) === 0) {
                throw new Exception("هیچ بەرهەمێکی دروست نەدۆزرایەوە.");
            }

            $splitJson = $_POST['split_allocations'] ?? '';
            if (is_string($splitJson) && trim($splitJson) !== '') {
                $alloc = json_decode($splitJson, true);
                if (is_array($alloc)) {
                    $aCash = roundMoney(max(0, (float)($alloc['cash'] ?? 0)));
                    $aBank = roundMoney(max(0, (float)($alloc['bank'] ?? 0)));
                    $aDebt = roundMoney(max(0, (float)($alloc['debt'] ?? 0)));
                    $sumA = roundMoney($aCash + $aBank + $aDebt);
                    $tol = max(1.0, abs($grandTotal) * 0.0001);
                    if ($sumA > 0 && $grandTotal > 0) {
                        if (abs($sumA - $grandTotal) > $tol) {
                            throw new Exception("کۆی پارەدان و کۆی وەسڵ یەک ناگرنەوە.");
                        }
                        if ($aDebt <= 0 && $aBank <= 0 && $aCash >= max(0, $grandTotal - $tol)) {
                            $paymentType = 'cash';
                            $paidCashDrawer = $aCash;
                            $paidBankAmt = 0.0;
                        } elseif ($aDebt <= 0 && $aCash <= 0 && $aBank >= max(0, $grandTotal - $tol)) {
                            $paymentType = 'fib';
                            $paidCashDrawer = 0.0;
                            $paidBankAmt = $aBank;
                        } elseif (($aCash + $aBank) <= 0 && $aDebt >= max(0, $grandTotal - $tol)) {
                            $paymentType = 'credit';
                            $paidCashDrawer = 0.0;
                            $paidBankAmt = 0.0;
                        } else {
                            $paymentType = 'split';
                            $cashPaidSplit = roundMoney($aCash + $aBank);
                            $paidCashDrawer = $aCash;
                            $paidBankAmt = $aBank;
                        }
                    }
                }
            }

            if ($paymentType === 'fib' && $paidCashDrawer === null) {
                $paidCashDrawer = 0.0;
                $paidBankAmt = $grandTotal;
            }

            $cogsRestockJobs = [];
            foreach ($lines as $L) {
                $pid = $L['pid'];
                $pieces = $L['pieces'];
                $lineTotal = $L['lineTotal'];
                $rP = $L['rP'];
                $expiryDate = $L['expiry_date'];
                $lineWarehouseId = (int)($L['warehouse_id'] ?? $purchaseWarehouseId);
                $isGiftLine = !empty($L['is_gift']) ? 1 : 0;

                $stS = $conn->prepare("INSERT INTO supplies (company, prodId, itemName, qtyAdded, totalCost, date, type, transaction_id, supplier_invoice_number, batch_number, expiry_date, warehouse_id, is_gift) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULLIF(?, ''), ?, ?)");
                $stS->bind_param("sisddssssssii", $companyName, $pid, $rP['name'], $pieces, $lineTotal, $date, $paymentType, $txnId, $supplierInvoiceNumber, $batchNumber, $expiryDate, $lineWarehouseId, $isGiftLine);
                $stS->execute();
                $supplyId = $stS->insert_id;
                if ($supplyId > 0 && function_exists('pos_stamp_table_fx')) {
                    pos_stamp_table_fx($conn, 'supplies', $supplyId, 'IQD', $usdRatePerOne);
                }

                if ($rP['trackStock']) {
                    pos_adjust_tracked_stock($conn, (int)$pid, (float)$pieces, $lineWarehouseId);
                }

                $uCost = $pieces != 0 ? $lineTotal / $pieces : 0;
                $moveNote = $isGiftLine ? "Bulk Invoice #$txnId (هدیە / فری)" : "Bulk Invoice #$txnId";
                if ($companyName !== '') $moveNote .= ' · ' . $companyName;
                insertStockMovement($conn, $pid, '', 'purchase', $pieces, $uCost, $lineTotal, 'supply', $supplyId, $date, $user, $moveNote, $lineWarehouseId);
                if ($expiryDate !== '') {
                    upsertStockBatchPurchase($conn, $pid, $expiryDate, $pieces, $uCost, 'purchase', $supplyId, $txnId);
                    pos_sync_product_expiry_from_batches($conn, $pid);
                } elseif (function_exists('productUsesExpiryTracking') && productUsesExpiryTracking($conn, $pid)) {
                    pos_backfill_batch_gap_for_product($conn, (int)$pid, (float)$pieces);
                }
                if (isset($L['sellPerUnit']) && $L['sellPerUnit'] !== null && (float)$L['sellPerUnit'] > 0) {
                    pos_apply_product_sell_price_for_unit($conn, $pid, $L['unit'] ?? 'piece', $L['sellPerUnit'], $currencyMode, $usdRatePerOne);
                }
                if (empty($L['is_gift'])) {
                    $qtyU = (float)($L['qty'] ?? 0);
                    $paidPerUnit = $qtyU > 0 ? roundMoney(((float)$lineTotal) / $qtyU) : (float)($L['costPerUnit'] ?? 0);
                    if ($paidPerUnit > 0) {
                        pos_apply_product_cost_for_unit($conn, $pid, $L['unit'] ?? 'piece', $paidPerUnit, $currencyMode, $usdRatePerOne);
                    }
                } elseif (function_exists('pos_apply_product_wac_after_stock_in')) {
                    pos_apply_product_wac_after_stock_in($conn, $pid, (float)$pieces, (float)$lineTotal, $currencyMode, $usdRatePerOne);
                }
                $cogsRestockJobs[] = ['pid' => (int)$pid, 'pieces' => (float)$pieces, 'total' => (float)$lineTotal];
            }

            if ($paymentType === 'credit' || $paymentType === 'split') {
                if ($companyId <= 0) {
                    throw new Exception("کۆمپانیا نەهاتە دیتن بۆ تۆمارکرنا قەرزێ.");
                }
                $stC = $conn->prepare("UPDATE companies SET balance = balance + ? WHERE id = ?");
                $stC->bind_param("di", $grandTotal, $companyId);
                $stC->execute();

                $itemsCount = count($lines);
                $note = "کڕین (قەرز): وەسڵ #$txnId | items=$itemsCount" . ($supplierInvoiceNumber ? " | supplier_inv=$supplierInvoiceNumber" : "");
                $stL = $conn->prepare("INSERT INTO ledger (companyId, type, amount, date, note, transaction_id) VALUES (?, 'credit_purchase', ?, ?, ?, ?)");
                $stL->bind_param("idsss", $companyId, $grandTotal, $date, $note, $txnId);
                $stL->execute();

                if ($paymentType === 'split' && $cashPaidSplit > 0) {
                    $stPay = $conn->prepare("UPDATE companies SET balance = balance - ? WHERE id = ?");
                    $stPay->bind_param("di", $cashPaidSplit, $companyId);
                    $stPay->execute();

                    $payNote = "پێشەکی بۆ وەسڵ #$txnId | paid_now=$cashPaidSplit" . ($supplierInvoiceNumber ? " | supplier_inv=$supplierInvoiceNumber" : "");
                    $stLPay = $conn->prepare("INSERT INTO ledger (companyId, type, amount, date, note, transaction_id) VALUES (?, 'payment', ?, ?, ?, ?)");
                    $stLPay->bind_param("idsss", $companyId, $cashPaidSplit, $date, $payNote, $txnId);
                    $stLPay->execute();

                    $drawerOut = ($paidCashDrawer !== null) ? roundMoney((float)$paidCashDrawer) : $cashPaidSplit;
                    $newExpId = insertCashPurchaseExpense($conn, $drawerOut, $payNote, $user, $date, $txnId);
                }
            } elseif ($paymentType === 'fib') {
                $itemsCount = count($lines);
                $expNote = "کڕین (FIB) ژ $companyName: وەسڵ #$txnId | items=$itemsCount" . ($supplierInvoiceNumber ? " | supplier_inv=$supplierInvoiceNumber" : "");
                $stL = $conn->prepare("INSERT INTO ledger (companyId, transaction_id, type, amount, note, date) VALUES (?, ?, 'purchase_fib', ?, ?, ?)");
                $stL->bind_param("isdss", $companyId, $txnId, $grandTotal, $expNote, $date);
                $stL->execute();
            } else {
                // Cash Payment -> Ledger + expense (cash leaves drawer)
                $itemsCount = count($lines);
                $expNote = "کڕین (نەقد) ژ $companyName: وەسڵ #$txnId | items=$itemsCount" . ($supplierInvoiceNumber ? " | supplier_inv=$supplierInvoiceNumber" : "");
                
                $stL = $conn->prepare("INSERT INTO ledger (companyId, transaction_id, type, amount, note, date) VALUES (?, ?, 'purchase', ?, ?, ?)");
                $stL->bind_param("isdss", $companyId, $txnId, $grandTotal, $expNote, $date);
                $stL->execute();
                $newExpId = insertCashPurchaseExpense($conn, $grandTotal, $expNote, $user, $date, $txnId);
            }

            $purchaseDebtAmount = 0;
            $paymentDueWarning = null;
            if ($paymentType === 'credit') {
                $purchaseDebtAmount = $grandTotal;
            } elseif ($paymentType === 'split') {
                $purchaseDebtAmount = roundMoney(max(0, $grandTotal - $cashPaidSplit));
            }
            if ($purchaseDebtAmount > 0 && $companyId > 0) {
                list($ptVal, $ptUnit) = pos_resolve_payment_term_from_post($conn, 'company', $companyId);
                $paymentDueAt = pos_compute_payment_due_at($ptVal, $ptUnit, $date);
                if ($paymentDueAt) {
                    $stDue = $conn->prepare("UPDATE supplies SET payment_due_at = ? WHERE transaction_id = ?");
                    if ($stDue) {
                        $stDue->bind_param('ss', $paymentDueAt, $txnId);
                        $stDue->execute();
                    }
                }
                // Track per-invoice remaining debt (for pay-this-invoice)
                if (function_exists('pos_ensure_payment_due_schema')) pos_ensure_payment_due_schema($conn);
                if ($paymentType === 'credit') {
                    $stRem = $conn->prepare("UPDATE supplies SET remaining_debt = totalCost WHERE transaction_id = ? AND type IN ('credit','split')");
                    if ($stRem) {
                        $stRem->bind_param('s', $txnId);
                        $stRem->execute();
                    }
                } elseif ($paymentType === 'split' && $grandTotal > 0) {
                    $debtRatio = $purchaseDebtAmount / $grandTotal;
                    $stRem = $conn->prepare(
                        "UPDATE supplies SET remaining_debt = ROUND(totalCost * ?, 3) "
                        . "WHERE transaction_id = ? AND type IN ('credit','split')"
                    );
                    if ($stRem) {
                        $stRem->bind_param('ds', $debtRatio, $txnId);
                        $stRem->execute();
                    }
                }
                if (pos_entity_has_overdue_payment_due_for_toast($conn, 'company', $companyId, $companyName)) {
                    $paymentDueWarning = pos_build_payment_due_warning($companyName);
                }
            }

            $companyBalanceOut = null;
            if ($companyId > 0) {
                $stBalOut = $conn->prepare("SELECT balance FROM companies WHERE id = ? LIMIT 1");
                if ($stBalOut) {
                    $stBalOut->bind_param("i", $companyId);
                    $stBalOut->execute();
                    $balRowOut = $stBalOut->get_result()->fetch_assoc();
                    if ($balRowOut) {
                        $companyBalanceOut = roundMoney((float)($balRowOut['balance'] ?? 0));
                    }
                }
            }

            $conn->commit();
            if (!empty($cogsRestockJobs) && function_exists('pos_after_purchase_stock_in_cogs')) {
                try {
                    foreach ($cogsRestockJobs as $job) {
                        pos_after_purchase_stock_in_cogs($conn, (int)$job['pid'], (float)$job['pieces'], (float)$job['total']);
                    }
                } catch (Throwable $eCogs) { /* inventory money already committed; COGS repair is best-effort */ }
            }
            touchLastUpdate($conn);
            echo json_encode([
                "status"=>"success",
                "transaction_id"=>$txnId,
                "expense_id"=>$newExpId,
                "payment_type"=>$paymentType,
                "company_id"=>$companyId,
                "company_balance"=>$companyBalanceOut,
                "payment_due_warning"=>$paymentDueWarning,
            ]); exit();
        } catch (Exception $e) { $conn->rollback(); echo json_encode(["status"=>"error", "message"=>$e->getMessage()]); exit(); }
    }

    /**
     * Replace all lines on an existing purchase invoice (edit-in-cart).
     * Keeps transaction_id + original date + payment type; updates stock/ledger/expenses.
     */
    if ($act === 'replace_purchase_cart') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        if (!pos_session_is_privileged() && !pos_session_has_perm('companies_manage')) {
            pos_json_perm_denied();
        }

        checkAndAddCol($conn, 'supplies', 'expiry_date', "DATE DEFAULT NULL");
        checkAndAddCol($conn, 'supplies', 'warehouse_id', 'INT NOT NULL DEFAULT 1');
        checkAndAddCol($conn, 'supplies', 'batch_number', "VARCHAR(100) DEFAULT ''");
        checkAndAddCol($conn, 'supplies', 'is_gift', "TINYINT(1) NOT NULL DEFAULT 0");

        $txnId = trim((string)($_POST['transaction_id'] ?? ''));
        $itemsJson = $_POST['items'] ?? '[]';
        $user = trim((string)($_POST['user'] ?? 'System'));
        if ($user === '') {
            $user = pos_session_user_name() ?: 'System';
        }
        $supplierInvoiceNumber = isset($_POST['supplier_invoice_number']) ? trim((string)$_POST['supplier_invoice_number']) : '';
        $batchNumber = isset($_POST['batch_number']) ? trim((string)$_POST['batch_number']) : '';

        if ($txnId === '') {
            echo json_encode(['status' => 'error', 'message' => 'وەسڵ نادروستە'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $items = json_decode(is_string($itemsJson) ? $itemsJson : '[]', true);
        if (!is_array($items) || count($items) === 0) {
            echo json_encode(['status' => 'error', 'message' => 'سەبەتا کڕینێ یا بەتاڵە.'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        if ($supplierInvoiceNumber === '') {
            echo json_encode(['status' => 'error', 'message' => 'پێدڤیە ژمارا پسوولێ بنڤیسی.'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $canUseBatch = function_exists('pos_can_use_purchase_batch') && pos_can_use_purchase_batch($conn);
        if ($canUseBatch && $batchNumber === '') {
            echo json_encode(['status' => 'error', 'message' => 'پێدڤیە ژمارا وەجبێ بنڤیسی.'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        if (!$canUseBatch) {
            $batchNumber = '';
        }

        $purchaseWarehouseId = pos_resolve_product_warehouse_id_for_save($conn, (int)($_POST['warehouse_id'] ?? 0));
        $appSettings = pos_load_app_settings_array($conn);
        $currencyMode = pos_settings_currency_mode_from_array($appSettings);
        $usdRatePerOne = pos_settings_usd_rate_per_one_from_array($appSettings);
        if (isset($_POST['exchange_rate']) && (float)$_POST['exchange_rate'] > 0) {
            $postedRate = (float)$_POST['exchange_rate'];
            $usdRatePerOne = ($postedRate >= 10000) ? ($postedRate / 100.0) : $postedRate;
        }

        $conn->begin_transaction();
        try {
            $stOld = $conn->prepare('SELECT * FROM supplies WHERE transaction_id = ? FOR UPDATE');
            if (!$stOld) {
                throw new Exception('Database error');
            }
            $stOld->bind_param('s', $txnId);
            $stOld->execute();
            $oldRes = $stOld->get_result();
            $oldSupplies = [];
            while ($oldRes && ($r = $oldRes->fetch_assoc())) {
                $oldSupplies[] = $r;
            }
            if (count($oldSupplies) === 0) {
                throw new Exception('وەسڵ نەهاتە دیتن');
            }
            $payType = strtolower(trim((string)($oldSupplies[0]['type'] ?? 'cash')));
            if ($payType === 'return') {
                throw new Exception('وەسڵێ زڤڕاندنێ ناکرێت تەعدیل بکرێت');
            }
            $compName = trim((string)($oldSupplies[0]['company'] ?? ''));
            $origDate = (string)($oldSupplies[0]['date'] ?? date('Y-m-d H:i:s'));
            if ($batchNumber === '' && !empty($oldSupplies[0]['batch_number'])) {
                $batchNumber = trim((string)$oldSupplies[0]['batch_number']);
            }

            $companyId = 0;
            if ($compName !== '') {
                $stComp = $conn->prepare('SELECT id, name, balance FROM companies WHERE name = ? LIMIT 1');
                if ($stComp) {
                    $stComp->bind_param('s', $compName);
                    $stComp->execute();
                    $compRow = $stComp->get_result()->fetch_assoc();
                    if ($compRow) {
                        $companyId = (int)$compRow['id'];
                        $compName = trim((string)($compRow['name'] ?? $compName));
                    }
                }
            }

            $oldGrandTotal = 0.0;
            $oldPiecesByKey = [];
            $oldDiffItems = [];
            foreach ($oldSupplies as $s) {
                $oldGrandTotal += (float)($s['totalCost'] ?? 0);
                $pid = (int)($s['prodId'] ?? 0);
                $pcs = (float)($s['qtyAdded'] ?? 0);
                $wh = (int)($s['warehouse_id'] ?? 1);
                $isGift = !empty($s['is_gift']);
                if ($pid > 0 && !$isGift && $pcs > 0.0001) {
                    $k = $pid . '@' . $wh;
                    if (!isset($oldPiecesByKey[$k])) {
                        $oldPiecesByKey[$k] = 0.0;
                    }
                    $oldPiecesByKey[$k] += $pcs;
                }
                $oldDiffItems[] = [
                    'id' => $pid,
                    'name' => (string)($s['itemName'] ?? ''),
                    'qty' => $pcs,
                    'price' => ($pcs > 0.0001 ? ((float)($s['totalCost'] ?? 0) / $pcs) : 0),
                    'saleUnit' => 'piece',
                    'isGift' => $isGift,
                ];
            }
            $oldGrandTotal = roundMoney($oldGrandTotal);

            $oldDebt = 0.0;
            $oldCashPaid = 0.0;
            if ($payType === 'credit') {
                $oldDebt = $oldGrandTotal;
            } elseif ($payType === 'split') {
                $stNet = $conn->prepare("SELECT
                    COALESCE(SUM(CASE WHEN type = 'credit_purchase' THEN amount ELSE 0 END), 0) AS cred,
                    COALESCE(SUM(CASE WHEN type = 'payment' THEN amount ELSE 0 END), 0) AS paid
                    FROM ledger WHERE transaction_id = ?");
                if ($stNet) {
                    $stNet->bind_param('s', $txnId);
                    $stNet->execute();
                    $netRow = $stNet->get_result()->fetch_assoc();
                    $oldCashPaid = roundMoney((float)($netRow['paid'] ?? 0));
                    $oldDebt = roundMoney(max(0, (float)($netRow['cred'] ?? 0) - $oldCashPaid));
                    if ($oldDebt <= 0 && $oldCashPaid <= 0) {
                        $oldDebt = roundMoney(max(0, $oldGrandTotal - $oldCashPaid));
                    }
                }
            }

            // Build new lines (same shape as save_purchase_invoice)
            $lines = [];
            $newGrandTotal = 0.0;
            $newPiecesByKey = [];
            $newDiffItems = [];
            foreach ($items as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $pid = (int)($row['productId'] ?? 0);
                $qty = (float)($row['qty'] ?? 0);
                $unit = $row['unit'] ?? 'piece';
                $costPerUnit = (float)($row['costPerUnit'] ?? 0);
                $discount = (float)($row['discount'] ?? 0);
                $isGift = !empty($row['isGift']);
                $expiryVisible = !empty($row['expiry_visible']);
                $expiryDate = trim((string)($row['expiry_date'] ?? ''));
                if (!$expiryVisible || $expiryDate === '' || !isValidYmdDate($expiryDate)) {
                    $expiryDate = '';
                }

                $stP = $conn->prepare('SELECT name, pieces_per_pack, packs_per_carton, trackStock, qty_mode, unitType, unit_show_pack, unit_show_carton FROM products WHERE id = ? FOR UPDATE');
                if (!$stP) {
                    continue;
                }
                $stP->bind_param('i', $pid);
                $stP->execute();
                $rP = $stP->get_result()->fetch_assoc();
                if (!$rP) {
                    continue;
                }

                $qty = normalizeQtyForProductData($rP, $qty);
                if ($qty <= 0) {
                    continue;
                }
                $ppp = max(1, (int)($rP['pieces_per_pack'] ?? 1));
                $ppc = max(1, (int)($rP['packs_per_carton'] ?? 1));
                $mult = ($unit === 'carton') ? ($ppp * $ppc) : (($unit === 'pack') ? $ppp : 1);
                $pieces = (float)($qty * (float)$mult);
                $lineTotal = $isGift ? 0 : roundMoney(max(0, $qty * $costPerUnit - $discount));
                $newGrandTotal += $lineTotal;
                $lineWhPosted = (int)($row['warehouseId'] ?? $row['warehouse_id'] ?? 0);
                $lineWarehouseId = $lineWhPosted > 0
                    ? pos_resolve_product_warehouse_id_for_save($conn, $lineWhPosted)
                    : $purchaseWarehouseId;
                $sellPerUnit = isset($row['sellPerUnit']) ? roundMoney(max(0, (float)$row['sellPerUnit'])) : null;
                $costPerUnitStored = $isGift ? 0 : roundMoney(max(0, $costPerUnit));
                $lines[] = [
                    'pid' => $pid,
                    'qty' => $qty,
                    'unit' => $unit,
                    'rP' => $rP,
                    'pieces' => $pieces,
                    'lineTotal' => $lineTotal,
                    'expiry_date' => $expiryDate,
                    'warehouse_id' => $lineWarehouseId,
                    'sellPerUnit' => $sellPerUnit,
                    'costPerUnit' => $costPerUnitStored,
                    'is_gift' => $isGift ? 1 : 0,
                ];
                if (!$isGift && $pieces > 0.0001) {
                    $k = $pid . '@' . $lineWarehouseId;
                    if (!isset($newPiecesByKey[$k])) {
                        $newPiecesByKey[$k] = 0.0;
                    }
                    $newPiecesByKey[$k] += $pieces;
                }
                $newDiffItems[] = [
                    'id' => $pid,
                    'name' => (string)($rP['name'] ?? ''),
                    'qty' => $pieces,
                    'price' => ($pieces > 0.0001 ? ($lineTotal / $pieces) : 0),
                    'saleUnit' => 'piece',
                    'isGift' => $isGift,
                ];
            }
            $newGrandTotal = roundMoney($newGrandTotal);
            if (count($lines) === 0) {
                throw new Exception('هیچ بەرهەمێکی دروست نەدۆزرایەوە.');
            }

            // Net stock deltas
            $allKeys = array_unique(array_merge(array_keys($oldPiecesByKey), array_keys($newPiecesByKey)));
            foreach ($allKeys as $k) {
                $oldPcs = (float)($oldPiecesByKey[$k] ?? 0);
                $newPcs = (float)($newPiecesByKey[$k] ?? 0);
                $delta = round($newPcs - $oldPcs, 4);
                if (abs($delta) < 0.0001) {
                    continue;
                }
                $parts = explode('@', $k, 2);
                $pid = (int)($parts[0] ?? 0);
                $whId = (int)($parts[1] ?? 1);
                if ($pid <= 0) {
                    continue;
                }
                $stTrk = $conn->prepare('SELECT trackStock FROM products WHERE id = ? LIMIT 1');
                $track = false;
                if ($stTrk) {
                    $stTrk->bind_param('i', $pid);
                    $stTrk->execute();
                    $tr = $stTrk->get_result()->fetch_assoc();
                    $track = $tr && !empty($tr['trackStock']);
                }
                if (!$track) {
                    continue;
                }
                pos_adjust_tracked_stock($conn, $pid, $delta, $whId);
                insertStockMovement(
                    $conn,
                    $pid,
                    '',
                    'purchase_edit',
                    $delta,
                    0,
                    0,
                    'supply',
                    0,
                    date('Y-m-d H:i:s'),
                    $user,
                    'تەعدیل وەسڵێ کڕینێ #' . $txnId,
                    $whId
                );
                if ($delta < 0 && function_exists('productUsesExpiryTracking') && productUsesExpiryTracking($conn, $pid)) {
                    pos_backfill_batch_gap_for_product($conn, $pid, $delta);
                }
            }

            // Remove old supply rows (stock already net-adjusted)
            $stDS = $conn->prepare('DELETE FROM supplies WHERE transaction_id = ?');
            $stDS->bind_param('s', $txnId);
            $stDS->execute();

            foreach ($lines as $L) {
                $pid = $L['pid'];
                $pieces = $L['pieces'];
                $lineTotal = $L['lineTotal'];
                $rP = $L['rP'];
                $expiryDate = $L['expiry_date'];
                $lineWarehouseId = (int)($L['warehouse_id'] ?? $purchaseWarehouseId);
                $isGiftLine = !empty($L['is_gift']) ? 1 : 0;

                $stS = $conn->prepare('INSERT INTO supplies (company, prodId, itemName, qtyAdded, totalCost, date, type, transaction_id, supplier_invoice_number, batch_number, expiry_date, warehouse_id, is_gift) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULLIF(?, \'\'), ?, ?)');
                $stS->bind_param(
                    'sisddssssssii',
                    $compName,
                    $pid,
                    $rP['name'],
                    $pieces,
                    $lineTotal,
                    $origDate,
                    $payType,
                    $txnId,
                    $supplierInvoiceNumber,
                    $batchNumber,
                    $expiryDate,
                    $lineWarehouseId,
                    $isGiftLine
                );
                $stS->execute();
                $supplyId = (int)$stS->insert_id;
                if ($supplyId > 0 && function_exists('pos_stamp_table_fx')) {
                    pos_stamp_table_fx($conn, 'supplies', $supplyId, 'IQD', $usdRatePerOne);
                }

                $uCost = $pieces != 0 ? $lineTotal / $pieces : 0;
                if ($expiryDate !== '') {
                    upsertStockBatchPurchase($conn, $pid, $expiryDate, $pieces, $uCost, 'purchase', $supplyId, $txnId);
                    pos_sync_product_expiry_from_batches($conn, $pid);
                } elseif (function_exists('productUsesExpiryTracking') && productUsesExpiryTracking($conn, $pid) && $pieces > 0) {
                    pos_backfill_batch_gap_for_product($conn, (int)$pid, (float)$pieces);
                }
                if (isset($L['sellPerUnit']) && $L['sellPerUnit'] !== null && (float)$L['sellPerUnit'] > 0) {
                    pos_apply_product_sell_price_for_unit($conn, $pid, $L['unit'] ?? 'piece', $L['sellPerUnit'], $currencyMode, $usdRatePerOne);
                }
                if (empty($L['is_gift'])) {
                    $qtyU = (float)($L['qty'] ?? 0);
                    $paidPerUnit = $qtyU > 0 ? roundMoney(((float)$lineTotal) / $qtyU) : (float)($L['costPerUnit'] ?? 0);
                    if ($paidPerUnit > 0) {
                        pos_apply_product_cost_for_unit($conn, $pid, $L['unit'] ?? 'piece', $paidPerUnit, $currencyMode, $usdRatePerOne);
                    }
                } elseif (function_exists('pos_apply_product_wac_after_stock_in')) {
                    pos_apply_product_wac_after_stock_in($conn, $pid, (float)$pieces, (float)$lineTotal, $currencyMode, $usdRatePerOne);
                }
            }

            // Payment / ledger / company balance
            $newCashPaid = 0.0;
            $newDebt = 0.0;
            if ($payType === 'cash') {
                $newCashPaid = $newGrandTotal;
                $newDebt = 0.0;
            } elseif ($payType === 'credit') {
                $newCashPaid = 0.0;
                $newDebt = $newGrandTotal;
            } else {
                $newCashPaid = min($oldCashPaid, $newGrandTotal);
                $newDebt = roundMoney(max(0, $newGrandTotal - $newCashPaid));
            }
            $debtDelta = roundMoney($newDebt - $oldDebt);
            $cashDelta = roundMoney($newCashPaid - $oldCashPaid);

            if ($companyId > 0 && abs($debtDelta) >= 0.01) {
                $stBal = $conn->prepare('UPDATE companies SET balance = balance + ? WHERE id = ?');
                if ($stBal) {
                    $stBal->bind_param('di', $debtDelta, $companyId);
                    $stBal->execute();
                }
            }

            if ($payType === 'credit') {
                $stUpL = $conn->prepare("UPDATE ledger SET amount = ? WHERE transaction_id = ? AND type = 'credit_purchase'");
                if ($stUpL) {
                    $stUpL->bind_param('ds', $newGrandTotal, $txnId);
                    $stUpL->execute();
                }
            } elseif ($payType === 'cash') {
                $stUpL = $conn->prepare("UPDATE ledger SET amount = ? WHERE transaction_id = ? AND type = 'purchase'");
                if ($stUpL) {
                    $stUpL->bind_param('ds', $newGrandTotal, $txnId);
                    $stUpL->execute();
                }
                $stUpE = $conn->prepare("UPDATE expenses SET amount = ? WHERE transaction_id = ? AND type = 'purchase'");
                if ($stUpE) {
                    $stUpE->bind_param('ds', $newGrandTotal, $txnId);
                    $stUpE->execute();
                }
            } elseif ($payType === 'split') {
                $stUpCred = $conn->prepare("UPDATE ledger SET amount = ? WHERE transaction_id = ? AND type = 'credit_purchase'");
                if ($stUpCred) {
                    $credAmt = roundMoney($newDebt + $newCashPaid); // often full then payment reduces — keep prior pattern: credit_purchase = grand, payment = cash
                    // Match save_purchase_invoice: credit_purchase = grandTotal, payment = cashPaid
                    $credAmt = $newGrandTotal;
                    $stUpCred->bind_param('ds', $credAmt, $txnId);
                    $stUpCred->execute();
                }
                $stUpPay = $conn->prepare("UPDATE ledger SET amount = ? WHERE transaction_id = ? AND type = 'payment'");
                if ($stUpPay) {
                    $stUpPay->bind_param('ds', $newCashPaid, $txnId);
                    $stUpPay->execute();
                }
                $stUpE = $conn->prepare("UPDATE expenses SET amount = ? WHERE transaction_id = ? AND type = 'purchase'");
                if ($stUpE) {
                    $stUpE->bind_param('ds', $newCashPaid, $txnId);
                    $stUpE->execute();
                }
            }

            $changeLines = [];
            try {
                $editDiff = function_exists('pos_build_sale_cart_edit_diff')
                    ? pos_build_sale_cart_edit_diff($oldDiffItems, $newDiffItems, $oldGrandTotal, $newGrandTotal)
                    : ['lines' => [], 'old_items' => $oldDiffItems, 'new_items' => $newDiffItems];
                $changeLines = $editDiff['lines'] ?? [];
                $detailsText = 'تەعدیل وەسڵێ کڕینێ #' . $txnId . ' | total ' . $oldGrandTotal . '→' . $newGrandTotal;
                if (!empty($changeLines)) {
                    $detailsText .= ' | ' . implode(' · ', $changeLines);
                }
                $oldJson = json_encode([
                    'total' => $oldGrandTotal,
                    'items' => $editDiff['old_items'] ?? $oldDiffItems,
                    'changes' => $changeLines,
                ], JSON_UNESCAPED_UNICODE);
                $newJson = json_encode([
                    'total' => $newGrandTotal,
                    'items' => $editDiff['new_items'] ?? $newDiffItems,
                ], JSON_UNESCAPED_UNICODE);
                logAction($conn, $user, 'purchase_cart_replace', $detailsText, null, 'purchase', null, $oldJson ?: null, $newJson ?: null);
            } catch (Throwable $eLog) {
            }

            $companyBalanceOut = null;
            if ($companyId > 0) {
                $stBalOut = $conn->prepare('SELECT balance FROM companies WHERE id = ? LIMIT 1');
                if ($stBalOut) {
                    $stBalOut->bind_param('i', $companyId);
                    $stBalOut->execute();
                    $balRowOut = $stBalOut->get_result()->fetch_assoc();
                    if ($balRowOut) {
                        $companyBalanceOut = roundMoney((float)($balRowOut['balance'] ?? 0));
                    }
                }
            }

            $conn->commit();
            touchLastUpdate($conn);
            echo json_encode([
                'status' => 'success',
                'transaction_id' => $txnId,
                'payment_type' => $payType,
                'company_id' => $companyId,
                'company_balance' => $companyBalanceOut,
                'total' => $newGrandTotal,
                'edited' => true,
                'changes' => $changeLines ?? [],
            ], JSON_UNESCAPED_UNICODE);
            exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
            exit();
        }
    }

    if ($act === 'delete_purchase_invoice') {
        $txnId = trim((string)($_POST['transaction_id'] ?? ''));
        $user = trim((string)($_POST['user'] ?? 'System'));
        if ($user === '') {
            $user = 'System';
        }
        // Only intentional voids (trash) are audited — not delete-for-edit rebuilds.
        $logVoid = !empty($_POST['log_void']) && (string)$_POST['log_void'] !== '0';
        if ($txnId === '') {
            echo json_encode(["status" => "error", "message" => "ID یا لڤینێ پێدڤیە"], JSON_UNESCAPED_UNICODE);
            exit();
        }

        $conn->begin_transaction();
        try {
            // 1. Get all items associated with this transaction (names for void history)
            $st = $conn->prepare(
                "SELECT s.id, s.prodId, s.qtyAdded, s.totalCost, s.company, s.type, s.date, s.supplier_invoice_number, s.batch_number, s.warehouse_id,
                        COALESCE(p.name, CONCAT('#', s.prodId)) AS product_name
                 FROM supplies s
                 LEFT JOIN products p ON p.id = s.prodId
                 WHERE s.transaction_id = ?"
            );
            $st->bind_param("s", $txnId);
            $st->execute();
            $res = $st->get_result();
            $supplies = [];
            $grandTotal = 0.0;
            $compName = '';
            $payType = '';
            $invDate = '';
            $supplierInv = '';
            $itemSnaps = [];
            while ($r = $res->fetch_assoc()) {
                $supplies[] = $r;
                $lineTotal = (float)$r['totalCost'];
                $grandTotal += $lineTotal;
                $compName = (string)($r['company'] ?? '');
                $payType = (string)($r['type'] ?? '');
                if ($invDate === '' && !empty($r['date'])) {
                    $invDate = (string)$r['date'];
                }
                if ($supplierInv === '' && !empty($r['supplier_invoice_number'])) {
                    $supplierInv = (string)$r['supplier_invoice_number'];
                }
                $itemSnaps[] = [
                    'id' => (int)$r['id'],
                    'prodId' => (int)$r['prodId'],
                    'name' => (string)($r['product_name'] ?? ''),
                    'qty' => (float)$r['qtyAdded'],
                    'totalCost' => function_exists('roundMoney') ? roundMoney($lineTotal) : $lineTotal,
                    'batch' => (string)($r['batch_number'] ?? ''),
                ];
            }

            if (count($supplies) === 0) {
                throw new Exception("Invoice not found or already deleted.");
            }

            $isReturn = (strtolower(trim($payType)) === 'return');
            $voidSnap = [
                'txn_id' => $txnId,
                'company' => $compName,
                'type' => $payType,
                'kind' => $isReturn ? 'return' : 'purchase',
                'total' => function_exists('roundMoney') ? roundMoney($grandTotal) : $grandTotal,
                'date' => $invDate,
                'supplier_invoice_number' => $supplierInv,
                'items_count' => count($itemSnaps),
                'items' => $itemSnaps,
            ];

            $revertCompanyId = 0;
            if ($compName !== '') {
                $stRevComp = $conn->prepare("SELECT id FROM companies WHERE name = ? LIMIT 1");
                if ($stRevComp) {
                    $stRevComp->bind_param("s", $compName);
                    $stRevComp->execute();
                    $revCompRow = $stRevComp->get_result()->fetch_assoc();
                    if ($revCompRow) {
                        $revertCompanyId = (int)$revCompRow['id'];
                    }
                }
            }

            // 2. Revert Stock
            foreach ($supplies as $s) {
                $pid = (int)$s['prodId'];
                $qty = (float)$s['qtyAdded'];
                $stU = $conn->prepare("UPDATE products SET qty = qty - ? WHERE id = ? AND trackStock = 1");
                $stU->bind_param("di", $qty, $pid);
                $stU->execute();

                // Log stock movement removal
                insertStockMovement($conn, $pid, '', 'purchase_deletion', -$qty, 0, 0, 'void', $s['id'], date('Y-m-d H:i:s'), $user, "Voided Invoice #$txnId");
            }

            // 3. Revert Balance (credit full debt, or net debt for split)
            if ($revertCompanyId > 0 && $payType === 'credit') {
                $stC = $conn->prepare("UPDATE companies SET balance = balance - ? WHERE id = ?");
                $stC->bind_param("di", $grandTotal, $revertCompanyId);
                $stC->execute();
            } elseif ($revertCompanyId > 0 && $payType === 'split') {
                $stNet = $conn->prepare("SELECT COALESCE(SUM(CASE WHEN type = 'credit_purchase' THEN amount ELSE 0 END), 0) - COALESCE(SUM(CASE WHEN type = 'payment' THEN amount ELSE 0 END), 0) AS net FROM ledger WHERE transaction_id = ?");
                $stNet->bind_param("s", $txnId);
                $stNet->execute();
                $rowNet = $stNet->get_result()->fetch_assoc();
                $netDebt = roundMoney((float)($rowNet['net'] ?? 0));
                if ($netDebt > 0) {
                    $stC = $conn->prepare("UPDATE companies SET balance = balance - ? WHERE id = ?");
                    $stC->bind_param("di", $netDebt, $revertCompanyId);
                    $stC->execute();
                }
            }

            if ($payType === 'cash' || $payType === 'split' || $payType === 'return') {
                $stDExp = $conn->prepare("DELETE FROM expenses WHERE transaction_id = ?");
                $stDExp->bind_param("s", $txnId);
                $stDExp->execute();
            }

            // 4. Delete Ledger & Supplies (+ purchase_returns row when present)
            $stDL = $conn->prepare("DELETE FROM ledger WHERE transaction_id = ?");
            $stDL->bind_param("s", $txnId);
            $stDL->execute();

            $stDS = $conn->prepare("DELETE FROM supplies WHERE transaction_id = ?");
            $stDS->bind_param("s", $txnId);
            $stDS->execute();

            $prTbl = $conn->query("SHOW TABLES LIKE 'purchase_returns'");
            if ($prTbl && $prTbl->num_rows > 0) {
                $stPR = $conn->prepare("DELETE FROM purchase_returns WHERE transaction_id = ?");
                if ($stPR) {
                    $stPR->bind_param("s", $txnId);
                    $stPR->execute();
                }
            }

            if ($logVoid && function_exists('logAction')) {
                $kindLabel = $isReturn ? 'زڤڕاندنا کڕینێ' : 'کڕین';
                $detailsText = 'ژێبرنا پسولێ #' . $txnId
                    . ' | ' . $kindLabel
                    . ($compName !== '' ? (' | ' . $compName) : '')
                    . ' | کۆ: ' . (function_exists('roundMoney') ? roundMoney($grandTotal) : $grandTotal);
                $oldJson = json_encode($voidSnap, JSON_UNESCAPED_UNICODE);
                logAction($conn, $user, 'void_purchase_invoice', $detailsText, null, 'purchase', null, $oldJson ?: null, null);
            }

            $conn->commit();
            touchLastUpdate($conn);
            echo json_encode(["status" => "success", "logged_void" => $logVoid ? 1 : 0, "kind" => $isReturn ? 'return' : 'purchase'], JSON_UNESCAPED_UNICODE);
            exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(["status" => "error", "message" => $e->getMessage()], JSON_UNESCAPED_UNICODE);
            exit();
        }
    }

    if ($act === 'restore_purchase_invoice') {
        header('Content-Type: application/json; charset=utf-8');
        $txnId = trim((string)($_POST['transaction_id'] ?? ''));
        $auditId = (int)($_POST['audit_id'] ?? 0);
        $user = trim((string)($_POST['user'] ?? 'System'));
        if ($user === '') $user = 'System';
        if ($txnId === '' && $auditId <= 0) {
            echo json_encode(["status" => "error", "message" => "ID یا لڤینێ پێدڤیە"], JSON_UNESCAPED_UNICODE);
            exit();
        }

        $conn->begin_transaction();
        try {
            $snap = null;
            if ($auditId > 0) {
                $stA = $conn->prepare("SELECT id, old_value FROM audit_logs WHERE id = ? AND action_type = 'void_purchase_invoice' LIMIT 1");
                if ($stA) {
                    $stA->bind_param("i", $auditId);
                    $stA->execute();
                    $rowA = $stA->get_result()->fetch_assoc();
                    if ($rowA && !empty($rowA['old_value'])) {
                        $snap = json_decode($rowA['old_value'], true);
                    }
                }
            }
            if (!$snap && $txnId !== '') {
                $like = '%"txn_id":"' . $conn->real_escape_string($txnId) . '"%';
                $resA = $conn->query("SELECT id, old_value FROM audit_logs WHERE action_type = 'void_purchase_invoice' AND old_value LIKE '$like' ORDER BY id DESC LIMIT 1");
                if ($resA && ($rowA = $resA->fetch_assoc()) && !empty($rowA['old_value'])) {
                    $snap = json_decode($rowA['old_value'], true);
                    $auditId = (int)$rowA['id'];
                }
            }
            if (!is_array($snap) || empty($snap['txn_id'])) {
                throw new Exception("تۆمارا ژێبرنێ نەهاتە دیتن — ناکرێت بێتە گەڕاندن");
            }
            $txnId = (string)$snap['txn_id'];
            $stExist = $conn->prepare("SELECT COUNT(*) AS c FROM supplies WHERE transaction_id = ?");
            $stExist->bind_param("s", $txnId);
            $stExist->execute();
            $existC = (int)(($stExist->get_result()->fetch_assoc()['c'] ?? 0));
            if ($existC > 0) {
                // Already back in supplies (previous restore) — just clear ژێبراو flag
                if (function_exists('pos_mark_void_purchase_audit_restored')) {
                    pos_mark_void_purchase_audit_restored($conn, $auditId, $txnId, $user);
                }
                if (function_exists('logAction')) {
                    logAction($conn, $user, 'restore_purchase_invoice', 'گەڕاندنا پسولێ (پێشتر هەبوو) #' . $txnId, null, 'purchase', null, null, json_encode(['txn_id' => $txnId, 'from_audit' => $auditId, 'already' => true], JSON_UNESCAPED_UNICODE));
                }
                $conn->commit();
                touchLastUpdate($conn);
                echo json_encode([
                    "status" => "success",
                    "restored" => true,
                    "already" => true,
                    "transaction_id" => $txnId,
                ], JSON_UNESCAPED_UNICODE);
                exit();
            }

            $compName = (string)($snap['company'] ?? '');
            $payType = (string)($snap['type'] ?? 'cash');
            $invDate = (string)($snap['date'] ?? date('Y-m-d H:i:s'));
            $supplierInv = (string)($snap['supplier_invoice_number'] ?? '');
            $items = is_array($snap['items'] ?? null) ? $snap['items'] : [];
            if (!count($items)) {
                throw new Exception("ئایتمێن پسوولێ نەهاتنە پاراستن");
            }

            $companyId = 0;
            if ($compName !== '') {
                $stC = $conn->prepare("SELECT id FROM companies WHERE name = ? LIMIT 1");
                if ($stC) {
                    $stC->bind_param("s", $compName);
                    $stC->execute();
                    $crow = $stC->get_result()->fetch_assoc();
                    if ($crow) $companyId = (int)$crow['id'];
                }
            }

            $grandTotal = 0.0;
            foreach ($items as $it) {
                $pid = (int)($it['prodId'] ?? $it['id'] ?? 0);
                $qty = (float)($it['qty'] ?? 0);
                $lineTotal = (float)($it['totalCost'] ?? 0);
                $itemName = (string)($it['name'] ?? '');
                $batch = (string)($it['batch'] ?? '');
                if ($pid <= 0 || $qty == 0) continue;
                $grandTotal += $lineTotal;

                $stIns = $conn->prepare("INSERT INTO supplies (company, prodId, itemName, qtyAdded, totalCost, `date`, type, transaction_id, supplier_invoice_number, batch_number) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                if (!$stIns) throw new Exception("Supply insert prepare failed");
                $stIns->bind_param("sisddsssss", $compName, $pid, $itemName, $qty, $lineTotal, $invDate, $payType, $txnId, $supplierInv, $batch);
                if (!$stIns->execute()) throw new Exception("Supply insert failed");

                $stU = $conn->prepare("UPDATE products SET qty = qty + ? WHERE id = ? AND trackStock = 1");
                if ($stU) {
                    $stU->bind_param("di", $qty, $pid);
                    $stU->execute();
                }
                if (function_exists('insertStockMovement')) {
                    insertStockMovement($conn, $pid, '', 'purchase_restore', $qty, 0, 0, 'restore', 0, date('Y-m-d H:i:s'), $user, "Restored Invoice #$txnId");
                }
            }
            if (function_exists('roundMoney')) $grandTotal = roundMoney($grandTotal);

            if ($companyId > 0 && $payType === 'credit' && $grandTotal > 0) {
                $stBal = $conn->prepare("UPDATE companies SET balance = balance + ? WHERE id = ?");
                if ($stBal) {
                    $stBal->bind_param("di", $grandTotal, $companyId);
                    $stBal->execute();
                }
                $ledType = 'credit_purchase';
                $stLed = $conn->prepare("INSERT INTO ledger (transaction_id, type, amount, note, date, companyId) VALUES (?, ?, ?, ?, ?, ?)");
                if ($stLed) {
                    $note = "Restored Purchase #$txnId";
                    $stLed->bind_param("ssdssi", $txnId, $ledType, $grandTotal, $note, $invDate, $companyId);
                    $stLed->execute();
                }
            } elseif ($payType === 'cash' && $grandTotal > 0) {
                $stExp = $conn->prepare("INSERT INTO expenses (amount, `date`, `user`, note, type, transaction_id) VALUES (?, ?, ?, ?, 'purchase', ?)");
                if ($stExp) {
                    $note = "Restored Purchase #$txnId" . ($compName !== '' ? (" | " . $compName) : '');
                    $stExp->bind_param("dssss", $grandTotal, $invDate, $user, $note, $txnId);
                    $stExp->execute();
                    $restoredExpId = (int)$conn->insert_id;
                    if ($restoredExpId > 0 && function_exists('pos_expense_stamp_fx')) {
                        pos_expense_stamp_fx($conn, $restoredExpId, 'IQD');
                    }
                }
            }

            if (function_exists('logAction')) {
                logAction($conn, $user, 'restore_purchase_invoice', 'گەڕاندنا پسولێ #' . $txnId . ($compName !== '' ? (' | ' . $compName) : '') . ' | کۆ: ' . $grandTotal, null, 'purchase', null, null, json_encode(['txn_id' => $txnId, 'from_audit' => $auditId], JSON_UNESCAPED_UNICODE));
            }
            if (function_exists('pos_mark_void_purchase_audit_restored')) {
                pos_mark_void_purchase_audit_restored($conn, $auditId, $txnId, $user);
            }

            $conn->commit();
            touchLastUpdate($conn);
            echo json_encode(["status" => "success", "restored" => true, "transaction_id" => $txnId, "total" => $grandTotal], JSON_UNESCAPED_UNICODE);
            exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(["status" => "error", "message" => $e->getMessage()], JSON_UNESCAPED_UNICODE);
            exit();
        }
    }

    if ($act === 'delete_purchase_line_item') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        
        $supplyId = (int)($_POST['supply_id'] ?? 0);
        $user = trim((string)($_POST['user'] ?? 'System'));
        
        if ($supplyId <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'ئایتم نەهاتە دیتن'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        
        $conn->begin_transaction();
        try {
            $stSup = $conn->prepare("SELECT id, prodId, qtyAdded, totalCost, transaction_id, type, company, warehouse_id, is_gift FROM supplies WHERE id = ? FOR UPDATE");
            if (!$stSup) throw new Exception('Database error');
            $stSup->bind_param('i', $supplyId);
            $stSup->execute();
            $s = $stSup->get_result()->fetch_assoc();
            if (!$s) throw new Exception('ئایتم نەهاتە دیتن د داتابەیسێ دا');
            
            $prodId = (int)$s['prodId'];
            $qty = (float)$s['qtyAdded'];
            $cost = (float)$s['totalCost'];
            $txnId = $s['transaction_id'];
            $payType = strtolower(trim((string)$s['type']));
            $companyName = trim((string)$s['company']);
            $whId = (int)($s['warehouse_id'] ?? 1);
            $isGift = !empty($s['is_gift']);
            
            // Delete the item
            $stDel = $conn->prepare("DELETE FROM supplies WHERE id = ?");
            $stDel->bind_param('i', $supplyId);
            $stDel->execute();
            
            // Re-adjust stock
            $stP = $conn->prepare("SELECT trackStock FROM products WHERE id = ? FOR UPDATE");
            $stP->bind_param('i', $prodId);
            $stP->execute();
            $rP = $stP->get_result()->fetch_assoc();
            
            if ($rP && !empty($rP['trackStock'])) {
                // Deduct stock (negative adjust)
                pos_adjust_tracked_stock($conn, $prodId, -$qty, $whId);
            }
            
            $unitCost = $qty != 0 ? ($cost / $qty) : 0;
            $nowStr = date('Y-m-d H:i:s');
            insertStockMovement($conn, $prodId, '', 'adjustment', -$qty, $unitCost, -$cost, 'delete_supply', $supplyId, $nowStr, $user, 'ڕەشکرنا ئایتمی ژ پسوولێ #' . $txnId, $whId);
            
            // Backfill batches
            if (function_exists('productUsesExpiryTracking') && productUsesExpiryTracking($conn, $prodId)) {
                pos_backfill_batch_gap_for_product($conn, $prodId, -$qty); // Pass negative to reduce
            }
            
            // Re-calculate grand total for this transaction
            $stSum = $conn->prepare('SELECT COALESCE(SUM(totalCost), 0) AS t FROM supplies WHERE transaction_id = ?');
            $newGrandTotal = 0;
            if ($stSum) {
                $stSum->bind_param('s', $txnId);
                $stSum->execute();
                $sumRow = $stSum->get_result()->fetch_assoc();
                $newGrandTotal = roundMoney((float)($sumRow['t'] ?? 0));
            }
            
            // Re-adjust Company Balance
            $companyId = 0;
            if ($companyName !== '') {
                $stComp = $conn->prepare('SELECT id FROM companies WHERE name = ? LIMIT 1');
                if ($stComp) {
                    $stComp->bind_param('s', $companyName);
                    $stComp->execute();
                    $compRow = $stComp->get_result()->fetch_assoc();
                    if ($compRow) $companyId = (int)$compRow['id'];
                }
            }
            
            if ($payType === 'credit' || $payType === 'split') {
                if ($companyId > 0 && abs($cost) >= 0.01) {
                    $stBal = $conn->prepare('UPDATE companies SET balance = balance - ? WHERE id = ?');
                    if ($stBal) {
                        $stBal->bind_param('di', $cost, $companyId);
                        $stBal->execute();
                    }
                }
                $stBulkLed = $conn->prepare("UPDATE ledger SET amount = ? WHERE transaction_id = ? AND type = 'credit_purchase' LIMIT 1");
                if ($stBulkLed) {
                    $stBulkLed->bind_param('ds', $newGrandTotal, $txnId);
                    $stBulkLed->execute();
                }
            }
            
            if ($payType === 'cash' || $payType === 'split') {
                $stBulkCash = $conn->prepare("UPDATE ledger SET amount = ? WHERE transaction_id = ? AND type = 'purchase' LIMIT 1");
                if ($stBulkCash) {
                    $stBulkCash->bind_param('ds', $newGrandTotal, $txnId);
                    $stBulkCash->execute();
                }
                
                if ($payType === 'cash') {
                    $posCashChange = $cost; // Cash is returned since purchase is deleted
                    $stPosIn = $conn->prepare('UPDATE shifts SET pos_in = pos_in + ? WHERE status = "open" AND user_id = (SELECT id FROM users WHERE username = ? LIMIT 1)');
                    if ($stPosIn) {
                        $stPosIn->bind_param('ds', $posCashChange, $user);
                        $stPosIn->execute();
                    }
                }
            }
            
            $conn->commit();
            touchLastUpdate($conn);
            echo json_encode(['status' => 'success']);
            exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
            exit();
        }
    }

    if ($act === 'add_purchase_line_to_invoice') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        checkAndAddCol($conn, 'supplies', 'expiry_date', "DATE DEFAULT NULL");
        checkAndAddCol($conn, 'supplies', 'warehouse_id', 'INT NOT NULL DEFAULT 1');
        checkAndAddCol($conn, 'supplies', 'batch_number', "VARCHAR(100) DEFAULT ''");
        checkAndAddCol($conn, 'supplies', 'is_gift', "TINYINT(1) NOT NULL DEFAULT 0");

        $txnId = trim((string)($_POST['transaction_id'] ?? ''));
        $prodId = (int)($_POST['prodId'] ?? 0);
        $newQty = (float)($_POST['qtyAdded'] ?? 0);
        $newTotal = roundMoney((float)($_POST['totalCost'] ?? 0));
        $user = trim((string)($_POST['user'] ?? 'System'));
        $expiryRaw = trim((string)($_POST['expiry_date'] ?? ''));
        $newExpiry = ($expiryRaw !== '' && isValidYmdDate($expiryRaw)) ? $expiryRaw : '';

        if ($txnId === '') {
            echo json_encode(['status' => 'error', 'message' => 'پسوولە نەهاتە دیتن'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        if ($prodId <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'ئایتم هەڵبژێرە'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        if ($newQty <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'ژمارە دڤێت گەورەتر بیت لە ٠'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        if ($newTotal < 0) {
            echo json_encode(['status' => 'error', 'message' => 'کۆ نابیت نەرێنی'], JSON_UNESCAPED_UNICODE);
            exit();
        }

        $conn->begin_transaction();
        try {
            $stTpl = $conn->prepare("SELECT id, company, date, type, supplier_invoice_number, batch_number, warehouse_id FROM supplies WHERE transaction_id = ? AND type != 'return' ORDER BY id ASC LIMIT 1 FOR UPDATE");
            if (!$stTpl) throw new Exception('Database error');
            $stTpl->bind_param('s', $txnId);
            $stTpl->execute();
            $tpl = $stTpl->get_result()->fetch_assoc();
            if (!$tpl) throw new Exception('پسوولە نەهاتە دیتن');

            $stP = $conn->prepare("SELECT name, trackStock FROM products WHERE id = ? FOR UPDATE");
            if (!$stP) throw new Exception('Database error');
            $stP->bind_param('i', $prodId);
            $stP->execute();
            $rP = $stP->get_result()->fetch_assoc();
            if (!$rP) throw new Exception('ئایتم نەهاتە دیتن');

            $companyName = trim((string)($tpl['company'] ?? ''));
            $payType = strtolower(trim((string)($tpl['type'] ?? 'cash')));
            $dateStr = trim((string)($tpl['date'] ?? ''));
            if ($dateStr === '') $dateStr = date('Y-m-d H:i:s');
            $supInv = trim((string)($tpl['supplier_invoice_number'] ?? ''));
            $batchNum = trim((string)($tpl['batch_number'] ?? ''));
            $whId = (int)($tpl['warehouse_id'] ?? 1);
            if ($whId <= 0) $whId = 1;
            $itemName = trim((string)($rP['name'] ?? ''));

            $stIns = $conn->prepare("INSERT INTO supplies (company, prodId, itemName, qtyAdded, totalCost, date, type, transaction_id, supplier_invoice_number, batch_number, expiry_date, warehouse_id, is_gift) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULLIF(?, ''), ?, 0)");
            if (!$stIns) throw new Exception('Database error');
            $stIns->bind_param("sisddssssssi", $companyName, $prodId, $itemName, $newQty, $newTotal, $dateStr, $payType, $txnId, $supInv, $batchNum, $newExpiry, $whId);
            $stIns->execute();
            $supplyId = (int)$stIns->insert_id;
            if ($supplyId > 0 && function_exists('pos_stamp_table_fx')) {
                pos_stamp_table_fx($conn, 'supplies', $supplyId, 'IQD', isset($usdRateAdd) ? $usdRateAdd : null);
            }

            $trackStock = !empty($rP['trackStock']);
            if ($trackStock) {
                pos_adjust_tracked_stock($conn, $prodId, $newQty, $whId);
            }
            $unitCost = $newQty != 0 ? ($newTotal / $newQty) : 0;
            insertStockMovement($conn, $prodId, '', 'purchase', $newQty, $unitCost, $newTotal, 'supply', $supplyId, $dateStr, $user, 'زیادکرنا ئایتمێ بۆ وەسڵ #' . $txnId, $whId);
            if ($unitCost > 0 && empty($rP['is_gift']) && function_exists('pos_apply_product_cost_for_unit')) {
                $appSettingsAdd = pos_load_app_settings_array($conn);
                $currencyModeAdd = pos_settings_currency_mode_from_array($appSettingsAdd);
                $usdRateAdd = pos_settings_usd_rate_per_one_from_array($appSettingsAdd);
                pos_apply_product_cost_for_unit($conn, $prodId, 'piece', $unitCost, $currencyModeAdd, $usdRateAdd);
            } elseif (!empty($rP['is_gift']) && function_exists('pos_apply_product_wac_after_stock_in')) {
                $appSettingsAdd = pos_load_app_settings_array($conn);
                $currencyModeAdd = pos_settings_currency_mode_from_array($appSettingsAdd);
                $usdRateAdd = pos_settings_usd_rate_per_one_from_array($appSettingsAdd);
                pos_apply_product_wac_after_stock_in($conn, $prodId, (float)$newQty, (float)$newTotal, $currencyModeAdd, $usdRateAdd);
            }
            if (function_exists('pos_after_purchase_stock_in_cogs')) {
                pos_after_purchase_stock_in_cogs($conn, (int)$prodId, (float)$newQty, (float)$newTotal);
            }
            if ($newExpiry !== '') {
                upsertStockBatchPurchase($conn, $prodId, $newExpiry, $newQty, $unitCost, 'purchase', $supplyId, $txnId);
                pos_sync_product_expiry_from_batches($conn, $prodId);
            } elseif (function_exists('productUsesExpiryTracking') && productUsesExpiryTracking($conn, $prodId)) {
                pos_backfill_batch_gap_for_product($conn, $prodId, $newQty);
            }

            $stSum = $conn->prepare('SELECT COALESCE(SUM(totalCost), 0) AS t FROM supplies WHERE transaction_id = ?');
            $newGrandTotal = $newTotal;
            if ($stSum) {
                $stSum->bind_param('s', $txnId);
                $stSum->execute();
                $sumRow = $stSum->get_result()->fetch_assoc();
                $newGrandTotal = roundMoney((float)($sumRow['t'] ?? $newTotal));
            }

            $companyId = 0;
            if ($companyName !== '') {
                $stComp = $conn->prepare('SELECT id FROM companies WHERE name = ? LIMIT 1');
                if ($stComp) {
                    $stComp->bind_param('s', $companyName);
                    $stComp->execute();
                    $compRow = $stComp->get_result()->fetch_assoc();
                    if ($compRow) $companyId = (int)$compRow['id'];
                }
            }

            if ($payType === 'credit' || $payType === 'split') {
                if ($companyId > 0 && abs($newTotal) >= 0.01) {
                    $stBal = $conn->prepare('UPDATE companies SET balance = balance + ? WHERE id = ?');
                    if ($stBal) {
                        $stBal->bind_param('di', $newTotal, $companyId);
                        $stBal->execute();
                    }
                }
                $stBulkLed = $conn->prepare("UPDATE ledger SET amount = ? WHERE transaction_id = ? AND type = 'credit_purchase' LIMIT 1");
                if ($stBulkLed) {
                    $stBulkLed->bind_param('ds', $newGrandTotal, $txnId);
                    $stBulkLed->execute();
                }
            }
            if ($payType === 'cash' || $payType === 'split') {
                $stBulkCash = $conn->prepare("UPDATE ledger SET amount = ? WHERE transaction_id = ? AND type = 'purchase' LIMIT 1");
                if ($stBulkCash) {
                    $stBulkCash->bind_param('ds', $newGrandTotal, $txnId);
                    $stBulkCash->execute();
                }
                if ($payType === 'cash') {
                    $stExp = $conn->prepare("UPDATE expenses SET amount = ? WHERE transaction_id = ? AND type = 'purchase' LIMIT 1");
                    if ($stExp) {
                        $stExp->bind_param('ds', $newGrandTotal, $txnId);
                        $stExp->execute();
                    }
                }
            }

            $companyBalanceOut = null;
            if ($companyId > 0) {
                $stBalOut = $conn->prepare('SELECT balance FROM companies WHERE id = ? LIMIT 1');
                if ($stBalOut) {
                    $stBalOut->bind_param('i', $companyId);
                    $stBalOut->execute();
                    $balRowOut = $stBalOut->get_result()->fetch_assoc();
                    if ($balRowOut) $companyBalanceOut = roundMoney((float)($balRowOut['balance'] ?? 0));
                }
            }

            try {
                logAction($conn, $user, 'purchase_line_add', 'زیادکرنا ئایتمێ #' . $supplyId . ' | وەسڵ ' . $txnId . ' | qty ' . $newQty . ' | cost ' . $newTotal);
            } catch (Throwable $e) {}

            $conn->commit();
            touchLastUpdate($conn);
            echo json_encode([
                'status' => 'success',
                'supply' => [
                    'id' => $supplyId,
                    'prodId' => $prodId,
                    'itemName' => $itemName,
                    'qtyAdded' => $newQty,
                    'totalCost' => $newTotal,
                    'date' => $dateStr,
                    'expiry_date' => $newExpiry !== '' ? $newExpiry : null,
                    'supplier_invoice_number' => $supInv,
                    'batch_number' => $batchNum,
                    'transaction_id' => $txnId,
                    'type' => $payType,
                    'company' => $companyName,
                ],
                'invoice_total' => $newGrandTotal,
                'company_balance' => $companyBalanceOut,
            ], JSON_UNESCAPED_UNICODE);
            exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
            exit();
        }
    }

    if ($act === 'update_purchase_line') {
        header('Content-Type: application/json; charset=utf-8');
        pos_session_require_login_json();
        checkAndAddCol($conn, 'supplies', 'batch_number', "VARCHAR(100) DEFAULT ''");

        $supplyId = (int)($_POST['supply_id'] ?? 0);
        $newQtyRaw = (float)($_POST['qtyAdded'] ?? 0);
        $newTotal = roundMoney((float)($_POST['totalCost'] ?? 0));
        $newDateInput = trim((string)($_POST['date'] ?? ''));
        $user = trim((string)($_POST['user'] ?? 'System'));
        if ($supplyId <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'ID یا ئایتمێ پێدڤیە'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        if ($newQtyRaw <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'ژمارە دڤێت گەورەتر بیت لە ٠'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        if ($newTotal < 0) {
            echo json_encode(['status' => 'error', 'message' => 'کۆ نابیت نەرێنی'], JSON_UNESCAPED_UNICODE);
            exit();
        }

        $conn->begin_transaction();
        try {
            $st = $conn->prepare("SELECT s.id, s.company, s.prodId, s.itemName, s.qtyAdded, s.totalCost, s.date, s.type, s.transaction_id, s.supplier_invoice_number, s.batch_number, s.expiry_date, s.warehouse_id,
                p.trackStock, p.qty AS prod_qty, p.qty_mode, p.unitType, p.unit_show_pack, p.unit_show_carton
                FROM supplies s
                LEFT JOIN products p ON p.id = s.prodId
                WHERE s.id = ?
                FOR UPDATE");
            if (!$st) throw new Exception('Database error');
            $st->bind_param('i', $supplyId);
            $st->execute();
            $res = $st->get_result();
            $row = $res ? $res->fetch_assoc() : null;
            if (!$row) throw new Exception('ئایتم نەهاتە دیتن');

            $payType = strtolower(trim((string)($row['type'] ?? 'cash')));
            if ($payType === 'return' || $payType === 'opening') {
                throw new Exception('دەستکارییا ئایتمێ تەنها بۆ کڕینێ دەکرێت');
            }

            $prodData = [
                'qty_mode' => $row['qty_mode'] ?? null,
                'unitType' => $row['unitType'] ?? null,
                'unit_show_pack' => $row['unit_show_pack'] ?? null,
                'unit_show_carton' => $row['unit_show_carton'] ?? null,
            ];
            $newQty = normalizeQtyForProductData($prodData, $newQtyRaw);
            if ($newQty <= 0) throw new Exception('ژمارەیا دروست نییە');

            $oldQty = (float)$row['qtyAdded'];
            $oldTotal = roundMoney((float)$row['totalCost']);
            $oldDateStr = trim((string)($row['date'] ?? ''));
            $oldDateYmd = '';
            if (preg_match('/^(\d{4}-\d{2}-\d{2})/', $oldDateStr, $oldDateMatch)) {
                $oldDateYmd = $oldDateMatch[1];
            } elseif ($oldDateStr !== '') {
                $oldTs = strtotime($oldDateStr);
                if ($oldTs !== false) $oldDateYmd = date('Y-m-d', $oldTs);
            }
            if ($oldDateYmd === '') $oldDateYmd = date('Y-m-d');

            if ($newDateInput === '') {
                $conn->rollback();
                echo json_encode(['status' => 'error', 'message' => 'بەروار پێدڤیە'], JSON_UNESCAPED_UNICODE);
                exit();
            }
            $newDateYmd = pos_parse_history_date_ymd($newDateInput, $oldDateYmd);
            $timePart = '12:00:00';
            if (preg_match('/(\d{2}:\d{2}:\d{2})/', $oldDateStr, $timeMatch)) {
                $timePart = $timeMatch[1];
            }
            $newDateTime = $newDateYmd . ' ' . $timePart;
            $dateChanged = ($newDateYmd !== $oldDateYmd);

            $oldExpiry = trim((string)($row['expiry_date'] ?? ''));
            $newExpiry = $oldExpiry;
            if (array_key_exists('expiry_date', $_POST)) {
                $expRaw = trim((string)$_POST['expiry_date']);
                if ($expRaw === '') {
                    $newExpiry = '';
                } elseif (!isValidYmdDate($expRaw)) {
                    throw new Exception('بەروارا بەسەرچوونێ نادروستە');
                } else {
                    $newExpiry = $expRaw;
                }
            }
            $expiryChanged = ($newExpiry !== $oldExpiry);

            $oldSupInv = trim((string)($row['supplier_invoice_number'] ?? ''));
            $newSupInv = $oldSupInv;
            $supInvChanged = false;
            if (array_key_exists('supplier_invoice_number', $_POST)) {
                $newSupInv = trim((string)$_POST['supplier_invoice_number']);
                if ($newSupInv === '') {
                    throw new Exception('ژمارا پسوولێ پێدڤیە — هەموو کۆمپانیێ دڤێت پسوول بدەت');
                }
                $supInvChanged = ($newSupInv !== $oldSupInv);
            }

            $oldBatchNum = trim((string)($row['batch_number'] ?? ''));
            $newBatchNum = $oldBatchNum;
            $batchNumChanged = false;
            if (array_key_exists('batch_number', $_POST)) {
                $canUseBatch = function_exists('pos_can_use_purchase_batch') && pos_can_use_purchase_batch($conn);
                if (!$canUseBatch) {
                    throw new Exception(function_exists('pos_purchase_batch_limit_message') ? pos_purchase_batch_limit_message() : 'ژمارا وەجبێ پێدڤیە Pro');
                }
                $newBatchNum = trim((string)$_POST['batch_number']);
                if ($newBatchNum === '') {
                    throw new Exception('ژمارا وەجبێ پێدڤیە');
                }
                $batchNumChanged = ($newBatchNum !== $oldBatchNum);
            }

            $qtyDelta = round((float)($newQty - $oldQty), 4);
            $costDelta = roundMoney($newTotal - $oldTotal);
            $txnId = trim((string)($row['transaction_id'] ?? ''));
            $prodId = (int)$row['prodId'];
            $whId = (int)($row['warehouse_id'] ?? 1);
            if ($whId <= 0) $whId = 1;
            $usesExpiry = productUsesExpiryTracking($conn, $prodId);
            $shouldExpiryBatch = $usesExpiry
                || ($newExpiry !== '' && isValidYmdDate($newExpiry))
                || ($oldExpiry !== '' && isValidYmdDate($oldExpiry));

            if (abs($qtyDelta) < 0.0001 && abs($costDelta) < 0.01 && !$dateChanged && !$expiryChanged && !$supInvChanged && !$batchNumChanged) {
                $conn->commit();
                echo json_encode([
                    'status' => 'success',
                    'unchanged' => true,
                    'supply' => [
                        'id' => $supplyId,
                        'qtyAdded' => $newQty,
                        'totalCost' => $newTotal,
                        'date' => $newDateTime,
                        'expiry_date' => $newExpiry !== '' ? $newExpiry : null,
                        'supplier_invoice_number' => $newSupInv,
                        'batch_number' => $newBatchNum,
                        'transaction_id' => $txnId,
                    ],
                ], JSON_UNESCAPED_UNICODE);
                exit();
            }

            if ($dateChanged) {
                if ($txnId !== '') {
                    $stDtSup = $conn->prepare('UPDATE supplies SET date = ? WHERE transaction_id = ?');
                    if ($stDtSup) {
                        $stDtSup->bind_param('ss', $newDateTime, $txnId);
                        $stDtSup->execute();
                    }
                    $stDtLed = $conn->prepare('UPDATE ledger SET date = ? WHERE transaction_id = ?');
                    if ($stDtLed) {
                        $stDtLed->bind_param('ss', $newDateTime, $txnId);
                        $stDtLed->execute();
                    }
                    $stDtExp = $conn->prepare("UPDATE expenses SET date = ? WHERE transaction_id = ? AND type = 'purchase'");
                    if ($stDtExp) {
                        $stDtExp->bind_param('ss', $newDateTime, $txnId);
                        $stDtExp->execute();
                    }
                } else {
                    $stDtOne = $conn->prepare('UPDATE supplies SET date = ? WHERE id = ?');
                    if ($stDtOne) {
                        $stDtOne->bind_param('si', $newDateTime, $supplyId);
                        $stDtOne->execute();
                    }
                    $stDtLedOne = $conn->prepare("UPDATE ledger SET date = ? WHERE related_id = ? AND type IN ('credit_purchase', 'purchase')");
                    if ($stDtLedOne) {
                        $stDtLedOne->bind_param('si', $newDateTime, $supplyId);
                        $stDtLedOne->execute();
                    }
                }
            }

            if ($supInvChanged) {
                if ($txnId !== '') {
                    $stInv = $conn->prepare('UPDATE supplies SET supplier_invoice_number = ? WHERE transaction_id = ?');
                    if ($stInv) {
                        $stInv->bind_param('ss', $newSupInv, $txnId);
                        $stInv->execute();
                    }
                } else {
                    $stInvOne = $conn->prepare('UPDATE supplies SET supplier_invoice_number = ? WHERE id = ?');
                    if ($stInvOne) {
                        $stInvOne->bind_param('si', $newSupInv, $supplyId);
                        $stInvOne->execute();
                    }
                }
            }

            if ($batchNumChanged) {
                if ($txnId !== '') {
                    $stBatch = $conn->prepare('UPDATE supplies SET batch_number = ? WHERE transaction_id = ?');
                    if ($stBatch) {
                        $stBatch->bind_param('ss', $newBatchNum, $txnId);
                        $stBatch->execute();
                    }
                } else {
                    $stBatchOne = $conn->prepare('UPDATE supplies SET batch_number = ? WHERE id = ?');
                    if ($stBatchOne) {
                        $stBatchOne->bind_param('si', $newBatchNum, $supplyId);
                        $stBatchOne->execute();
                    }
                }
            }

            if (abs($qtyDelta) < 0.0001 && abs($costDelta) < 0.01) {
                if ($expiryChanged) {
                    $unitCostMeta = $oldQty != 0 ? ($oldTotal / $oldQty) : 0;
                    if ($shouldExpiryBatch) {
                        pos_migrate_purchase_line_expiry_batch($conn, $prodId, $supplyId, $txnId, $oldExpiry, $newExpiry, $oldQty, $unitCostMeta);
                    }
                    $stExpOnly = $conn->prepare('UPDATE supplies SET expiry_date = NULLIF(?, "") WHERE id = ?');
                    if ($stExpOnly) {
                        $stExpOnly->bind_param('si', $newExpiry, $supplyId);
                        $stExpOnly->execute();
                    }
                }
                $logMeta = 'دەستکارییا مێژوو #' . $supplyId;
                if ($dateChanged) $logMeta .= ' | date ' . $oldDateYmd . '→' . $newDateYmd;
                if ($expiryChanged) $logMeta .= ' | expiry ' . ($oldExpiry !== '' ? $oldExpiry : '—') . '→' . ($newExpiry !== '' ? $newExpiry : '—');
                if ($supInvChanged) $logMeta .= ' | inv ' . ($oldSupInv !== '' ? $oldSupInv : '—') . '→' . $newSupInv;
                if ($batchNumChanged) $logMeta .= ' | batch ' . ($oldBatchNum !== '' ? $oldBatchNum : '—') . '→' . $newBatchNum;
                try {
                    logAction($conn, $user, 'purchase_line_edit', $logMeta);
                } catch (Throwable $e) {}
                $metaInvoiceTotal = $newTotal;
                if ($txnId !== '') {
                    $stSumMeta = $conn->prepare('SELECT COALESCE(SUM(totalCost), 0) AS t FROM supplies WHERE transaction_id = ?');
                    if ($stSumMeta) {
                        $stSumMeta->bind_param('s', $txnId);
                        $stSumMeta->execute();
                        $sumRowMeta = $stSumMeta->get_result()->fetch_assoc();
                        $metaInvoiceTotal = roundMoney((float)($sumRowMeta['t'] ?? $newTotal));
                    }
                }
                $metaCompanyBalance = null;
                $compNameMeta = trim((string)($row['company'] ?? ''));
                if ($compNameMeta !== '') {
                    $stBalMeta = $conn->prepare('SELECT balance FROM companies WHERE name = ? LIMIT 1');
                    if ($stBalMeta) {
                        $stBalMeta->bind_param('s', $compNameMeta);
                        $stBalMeta->execute();
                        $balMetaRow = $stBalMeta->get_result()->fetch_assoc();
                        if ($balMetaRow) $metaCompanyBalance = roundMoney((float)($balMetaRow['balance'] ?? 0));
                    }
                }
                $conn->commit();
                touchLastUpdate($conn);
                echo json_encode([
                    'status' => 'success',
                    'metadata_only' => true,
                    'supply' => [
                        'id' => $supplyId,
                        'prodId' => $prodId,
                        'itemName' => $row['itemName'],
                        'qtyAdded' => $newQty,
                        'totalCost' => $newTotal,
                        'date' => $newDateTime,
                        'expiry_date' => $newExpiry !== '' ? $newExpiry : null,
                        'supplier_invoice_number' => $newSupInv,
                        'batch_number' => $newBatchNum,
                        'transaction_id' => $txnId,
                        'type' => $payType,
                        'company' => $compNameMeta,
                    ],
                    'invoice_total' => $metaInvoiceTotal,
                    'company_balance' => $metaCompanyBalance,
                ], JSON_UNESCAPED_UNICODE);
                exit();
            }

            $trackStock = !empty($row['trackStock']);
            $unitCost = $newQty != 0 ? ($newTotal / $newQty) : 0;
            $activeExpiry = $newExpiry !== '' ? $newExpiry : $oldExpiry;
            $stockSkipped = false;

            if ($expiryChanged && $shouldExpiryBatch) {
                pos_migrate_purchase_line_expiry_batch($conn, $prodId, $supplyId, $txnId, $oldExpiry, $newExpiry, $oldQty, $unitCost);
                $activeExpiry = $newExpiry;
            }

            if ($trackStock && abs($qtyDelta) >= 0.0001) {
                $doStock = true;
                if ($qtyDelta < -0.0001) {
                    $needRemove = abs($qtyDelta);
                    $avail = (float)($row['prod_qty'] ?? 0);
                    if ($shouldExpiryBatch && $activeExpiry !== '' && isValidYmdDate($activeExpiry)) {
                        $batchQty = pos_purchase_line_batch_qty($conn, $prodId, $activeExpiry);
                        if ($batchQty > 0) {
                            $avail = min($avail, $batchQty);
                        }
                    }
                    if ($avail + 0.0001 < $needRemove) {
                        $doStock = false;
                        $stockSkipped = true;
                    }
                }
                if ($doStock) {
                    pos_adjust_tracked_stock($conn, $prodId, $qtyDelta, $whId);
                }
            }

            $stUp = $conn->prepare('UPDATE supplies SET qtyAdded = ?, totalCost = ?, expiry_date = NULLIF(?, "") WHERE id = ?');
            if (!$stUp) throw new Exception('Database error');
            $stUp->bind_param('ddsi', $newQty, $newTotal, $newExpiry, $supplyId);
            $stUp->execute();

            if ($unitCost > 0 && empty($row['is_gift']) && function_exists('pos_apply_product_cost_for_unit')) {
                $appSettingsEdit = pos_load_app_settings_array($conn);
                $currencyModeEdit = pos_settings_currency_mode_from_array($appSettingsEdit);
                $usdRateEdit = pos_settings_usd_rate_per_one_from_array($appSettingsEdit);
                pos_apply_product_cost_for_unit($conn, $prodId, 'piece', $unitCost, $currencyModeEdit, $usdRateEdit);
            }
            if ($qtyDelta > 0.000001 && function_exists('pos_after_purchase_stock_in_cogs')) {
                $lotCost = $newQty > 0 ? ((float)$newTotal / (float)$newQty) * (float)$qtyDelta : 0.0;
                pos_after_purchase_stock_in_cogs($conn, (int)$prodId, (float)$qtyDelta, $lotCost);
            }

            $editDate = date('Y-m-d H:i:s');
            $editNote = 'دەستکارییا ئایتمێ #' . $supplyId . ' | وەسڵ ' . ($txnId !== '' ? $txnId : '—');
            if ($stockSkipped) {
                $editNote .= ' | stock_skip';
            }
            if (abs($qtyDelta) >= 0.0001) {
                insertStockMovement($conn, $prodId, '', 'purchase_edit', $qtyDelta, $unitCost, $costDelta, 'supply', $supplyId, $editDate, $user, $editNote, $whId);
            }

            if ($shouldExpiryBatch && $activeExpiry !== '' && isValidYmdDate($activeExpiry) && abs($qtyDelta) >= 0.0001) {
                pos_adjust_purchase_line_batch_qty($conn, $prodId, $activeExpiry, $qtyDelta, $unitCost, $supplyId, $txnId);
            }

            $newGrandTotal = $oldTotal;
            if ($txnId !== '') {
                $stSum = $conn->prepare('SELECT COALESCE(SUM(totalCost), 0) AS t FROM supplies WHERE transaction_id = ?');
                if ($stSum) {
                    $stSum->bind_param('s', $txnId);
                    $stSum->execute();
                    $sumRow = $stSum->get_result()->fetch_assoc();
                    $newGrandTotal = roundMoney((float)($sumRow['t'] ?? $newTotal));
                }
            } else {
                $newGrandTotal = $newTotal;
            }

            $companyId = 0;
            $compName = trim((string)($row['company'] ?? ''));
            if ($compName !== '') {
                $stComp = $conn->prepare('SELECT id FROM companies WHERE name = ? LIMIT 1');
                if ($stComp) {
                    $stComp->bind_param('s', $compName);
                    $stComp->execute();
                    $compRow = $stComp->get_result()->fetch_assoc();
                    if ($compRow) $companyId = (int)$compRow['id'];
                }
            }

            if ($payType === 'credit' || $payType === 'split') {
                if ($companyId > 0 && abs($costDelta) >= 0.01) {
                    $stBal = $conn->prepare('UPDATE companies SET balance = balance + ? WHERE id = ?');
                    if ($stBal) {
                        $stBal->bind_param('di', $costDelta, $companyId);
                        $stBal->execute();
                    }
                }
                $stLineLed = $conn->prepare("UPDATE ledger SET amount = ? WHERE related_id = ? AND type = 'credit_purchase'");
                if ($stLineLed) {
                    $stLineLed->bind_param('di', $newTotal, $supplyId);
                    $stLineLed->execute();
                }
                if (!$stLineLed || $stLineLed->affected_rows === 0) {
                    $stBulkLed = $conn->prepare("UPDATE ledger SET amount = ? WHERE transaction_id = ? AND type = 'credit_purchase' LIMIT 1");
                    if ($stBulkLed && $txnId !== '') {
                        $stBulkLed->bind_param('ds', $newGrandTotal, $txnId);
                        $stBulkLed->execute();
                    }
                }
            }

            if ($payType === 'cash' || $payType === 'split') {
                $stLineCash = $conn->prepare("UPDATE ledger SET amount = ? WHERE related_id = ? AND type = 'purchase'");
                if ($stLineCash) {
                    $stLineCash->bind_param('di', $newTotal, $supplyId);
                    $stLineCash->execute();
                }
                if (!$stLineCash || $stLineCash->affected_rows === 0) {
                    if ($payType === 'cash' && $txnId !== '') {
                        $stBulkCash = $conn->prepare("UPDATE ledger SET amount = ? WHERE transaction_id = ? AND type = 'purchase' LIMIT 1");
                        if ($stBulkCash) {
                            $stBulkCash->bind_param('ds', $newGrandTotal, $txnId);
                            $stBulkCash->execute();
                        }
                        $stExp = $conn->prepare("UPDATE expenses SET amount = ? WHERE transaction_id = ? AND type = 'purchase' LIMIT 1");
                        if ($stExp) {
                            $stExp->bind_param('ds', $newGrandTotal, $txnId);
                            $stExp->execute();
                        }
                    }
                } else {
                    $stExpLine = $conn->prepare("UPDATE expenses SET amount = ? WHERE transaction_id = ? AND type = 'purchase' LIMIT 1");
                    if ($stExpLine && $txnId !== '') {
                        $stExpLine->bind_param('ds', $newGrandTotal, $txnId);
                        $stExpLine->execute();
                    }
                }
            }

            $companyBalanceOut = null;
            if ($companyId > 0) {
                $stBalOut = $conn->prepare('SELECT balance FROM companies WHERE id = ? LIMIT 1');
                if ($stBalOut) {
                    $stBalOut->bind_param('i', $companyId);
                    $stBalOut->execute();
                    $balRowOut = $stBalOut->get_result()->fetch_assoc();
                    if ($balRowOut) $companyBalanceOut = roundMoney((float)($balRowOut['balance'] ?? 0));
                }
            }

            try {
                $logBits = 'دەستکارییا ئایتمێ #' . $supplyId . ' | وەسڵ ' . ($txnId !== '' ? $txnId : '—');
                if ($dateChanged) $logBits .= ' | date ' . $oldDateYmd . '→' . $newDateYmd;
                if ($expiryChanged) $logBits .= ' | expiry ' . ($oldExpiry !== '' ? $oldExpiry : '—') . '→' . ($newExpiry !== '' ? $newExpiry : '—');
                if ($supInvChanged) $logBits .= ' | inv ' . ($oldSupInv !== '' ? $oldSupInv : '—') . '→' . $newSupInv;
                if ($batchNumChanged) $logBits .= ' | batch ' . ($oldBatchNum !== '' ? $oldBatchNum : '—') . '→' . $newBatchNum;
                $logBits .= ' | qty ' . $oldQty . '→' . $newQty . ' | cost ' . $oldTotal . '→' . $newTotal;
                if ($stockSkipped) $logBits .= ' | stock_skip';
                logAction($conn, $user, 'purchase_line_edit', $logBits);
            } catch (Throwable $e) {}

            $conn->commit();
            touchLastUpdate($conn);
            echo json_encode([
                'status' => 'success',
                'supply' => [
                    'id' => $supplyId,
                    'prodId' => $prodId,
                    'itemName' => $row['itemName'],
                    'qtyAdded' => $newQty,
                    'totalCost' => $newTotal,
                    'date' => $newDateTime,
                    'expiry_date' => $newExpiry !== '' ? $newExpiry : null,
                    'supplier_invoice_number' => $newSupInv,
                    'batch_number' => $newBatchNum,
                    'transaction_id' => $txnId,
                    'type' => $payType,
                    'company' => $compName,
                ],
                'invoice_total' => $newGrandTotal,
                'company_balance' => $companyBalanceOut,
                'stock_skipped' => $stockSkipped,
            ], JSON_UNESCAPED_UNICODE);
            exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
            exit();
        }
    }

    if($act == 'save_supply') {
        checkAndAddCol($conn, 'supplies', 'expiry_date', "DATE DEFAULT NULL");
        checkAndAddCol($conn, 'supplies', 'batch_number', "VARCHAR(100) DEFAULT ''");
        $compRaw = $_POST['company']; 
        $compEscaped = $conn->real_escape_string($compRaw);
        $pid = (int)$_POST['prodId']; $name = $_POST['itemName'];
        $qty = (float)$_POST['qtyAdded']; $cost = roundMoney($_POST['totalCost'] ?? 0); $type = $_POST['type'];
        $user = $_POST['user'] ?? 'System';
        $date = date('Y-m-d H:i:s');
        $txnId = uniqid('TXS');
        $supplierInvoiceNumber = isset($_POST['supplier_invoice_number']) ? trim($_POST['supplier_invoice_number']) : '';
        $batchNumber = isset($_POST['batch_number']) ? trim($_POST['batch_number']) : '';
        $expiryDate = trim((string)($_POST['expiry_date'] ?? ''));
        if ($expiryDate !== '' && !isValidYmdDate($expiryDate)) { echo json_encode(["status"=>"error","message"=>"Invalid expiry date"]); exit(); }
        // When creating a product, save_product already set qty; opening stock is not a supplier purchase.
        $skipStockUpdate = isset($_POST['skip_stock_update']) && ($_POST['skip_stock_update'] === '1' || $_POST['skip_stock_update'] === 'true');
        if ($skipStockUpdate) {
            echo json_encode(["status"=>"success", "id"=>0, "opening_inventory"=>true]); exit();
        }
        if ($supplierInvoiceNumber === '') {
            echo json_encode(["status"=>"error", "message"=>"پێدڤیە ژمارا پسوولێ بنڤیسی."]); exit();
        }
        $canUseBatch = function_exists('pos_can_use_purchase_batch') && pos_can_use_purchase_batch($conn);
        if ($canUseBatch && $batchNumber === '') {
            echo json_encode(["status"=>"error", "message"=>"پێدڤیە ژمارا وەجبێ بنڤیسی."]); exit();
        }
        if (!$canUseBatch) {
            $batchNumber = '';
        }
        
        // Zero Loss System: Capture entry unit details
        $entryUnit = $_POST['entryUnit'] ?? 'piece';
        $mainQty = (float)($_POST['mainQty'] ?? 0);
        $conversionFactor = (float)($_POST['conversionFactor'] ?? 1);
        
        // Create detailed note for audit trail
        $auditNote = "Entry Unit: $entryUnit, Main Qty: $mainQty, Conversion Factor: $conversionFactor, Total Pieces: $qty";
        
        $conn->begin_transaction();
        try {
            $newExpId = 0;
            $stmtP = $conn->prepare("SELECT qty_mode, unitType, unit_show_pack, unit_show_carton FROM products WHERE id = ? LIMIT 1");
            $stmtP->bind_param("i", $pid);
            $stmtP->execute();
            $resP = $stmtP->get_result();
            if ($resP && ($prodP = $resP->fetch_assoc())) {
                $qty = normalizeQtyForProductData($prodP, $qty);
            } else {
                $qty = normalizeQtyForProductData(null, $qty);
            }
            if ($qty <= 0) throw new Exception("Invalid quantity");
            $fxSupSnap = fxSnapshotBindStringsFromPost();
            $stmt = $conn->prepare("INSERT INTO supplies (company, prodId, itemName, qtyAdded, totalCost, date, type, transaction_id, fx_usd_rate, fx_currency_mode, supplier_invoice_number, batch_number, expiry_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, CAST(NULLIF(?, '') AS UNSIGNED), NULLIF(?, ''), ?, ?, NULLIF(?, ''))");
            $stmt->bind_param("sisddssssssss", $compRaw, $pid, $name, $qty, $cost, $date, $type, $txnId, $fxSupSnap['rate'], $fxSupSnap['mode'], $supplierInvoiceNumber, $batchNumber, $expiryDate);
            $stmt->execute();
            $insertId = $stmt->insert_id;
            if ($insertId > 0 && function_exists('pos_stamp_table_fx')) {
                pos_stamp_table_fx($conn, 'supplies', (int)$insertId, 'IQD');
            }

            if (!$skipStockUpdate) {
                $stmtUpd = $conn->prepare("UPDATE products SET qty = qty + ? WHERE id = ? AND trackStock = 1");
                $stmtUpd->bind_param("di", $qty, $pid);
                $stmtUpd->execute();
            }
            
            if($type == 'credit') {
                $stmtC = $conn->prepare("UPDATE companies SET balance = balance + ? WHERE name = ?");
                $stmtC->bind_param("ds", $cost, $compRaw);
                $stmtC->execute();
                
                $stmtCId = $conn->prepare("SELECT id FROM companies WHERE name = ?");
                $stmtCId->bind_param("s", $compRaw);
                $stmtCId->execute();
                $resC = $stmtCId->get_result();
                if($resC && $cRow = $resC->fetch_assoc()) {
                    $note = "کڕین: $name (قەرز)";
                    $stmtL = $conn->prepare("INSERT INTO ledger (companyId, type, amount, date, note, transaction_id, related_id) VALUES (?, 'credit_purchase', ?, ?, ?, ?, ?)");
                    $stmtL->bind_param("idsssi", $cRow['id'], $cost, $date, $note, $txnId, $insertId);
                    $stmtL->execute();
                }
            } else {
                // Cash Supply -> Ledger
                $stmtCId = $conn->prepare("SELECT id FROM companies WHERE name = ?");
                $stmtCId->bind_param("s", $compRaw);
                $stmtCId->execute();
                $resC = $stmtCId->get_result();
                $cId = 0;
                if($resC && $cRow = $resC->fetch_assoc()) {
                    $cId = $cRow['id'];
                }

                $expNote = "کڕین: $name ژ $compRaw (کاش)";
                
                // Add to Unified Ledger (Cash Purchase)
                $stmtL = $conn->prepare("INSERT INTO ledger (companyId, transaction_id, type, amount, note, date) VALUES (?, ?, 'purchase', ?, ?, ?)");
                $stmtL->bind_param("isdss", $cId, $txnId, $cost, $expNote, $date);
                $stmtL->execute();
                $newExpId = insertCashPurchaseExpense($conn, $cost, $expNote, $user, $date, $txnId);
            }
            $unitCost = $qty != 0 ? $cost / $qty : 0;
            insertStockMovement($conn, $pid, '', 'purchase', $qty, $unitCost, $cost, 'supply', $insertId, $date, $user, $auditNote);
            if ($unitCost > 0 && function_exists('pos_apply_product_cost_for_unit')) {
                $appSettingsSup = pos_load_app_settings_array($conn);
                $currencyModeSup = pos_settings_currency_mode_from_array($appSettingsSup);
                $usdRateSup = pos_settings_usd_rate_per_one_from_array($appSettingsSup);
                $entryU = in_array($entryUnit, ['carton', 'pack', 'piece'], true) ? $entryUnit : 'piece';
                // qty/cost are piece-based in save_supply; apply as piece catalog cost
                pos_apply_product_cost_for_unit($conn, $pid, 'piece', $unitCost, $currencyModeSup, $usdRateSup);
            }
            $doCogsRestock = ($type !== 'return' && $type !== 'supplier_return');
            if ($expiryDate !== '') {
                upsertStockBatchPurchase($conn, $pid, $expiryDate, $qty, $unitCost, 'purchase', $insertId, $txnId);
                pos_sync_product_expiry_from_batches($conn, $pid);
            }
            if (function_exists('pos_clear_product_catalog_only') && $type !== 'opening' && $type !== 'return') {
                pos_clear_product_catalog_only($conn, (int)$pid);
            }
            $conn->commit();
            if (!empty($doCogsRestock) && function_exists('pos_after_purchase_stock_in_cogs')) {
                pos_after_purchase_stock_in_cogs($conn, (int)$pid, (float)$qty, (float)$cost);
            }
            touchLastUpdate($conn);
            echo json_encode(["status"=>"success", "id"=>$insertId, "expense_id"=>$newExpId ?? 0, "transaction_id"=>$txnId]); exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(["status"=>"error"]); exit();
        }
    }

    if($act == 'save_ledger') {
        $cid = $_POST['companyId']; $type = $_POST['type']; $amount = $_POST['amount']; $note = $_POST['note'];
        $user = $_POST['user'] ?? 'System';
        $payTxnId = trim((string)($_POST['pay_transaction_id'] ?? $_POST['invoice_transaction_id'] ?? ''));
        $payChannel = function_exists('pos_normalize_debt_pay_channel')
            ? pos_normalize_debt_pay_channel($_POST['payment_method'] ?? 'cash')
            : (strtolower(trim((string)($_POST['payment_method'] ?? 'cash'))) === 'fib' ? 'fib' : 'cash');
        $date = date('Y-m-d H:i:s');
        $txnId = uniqid('TXL');
        
        $conn->begin_transaction();
        try {
            $cid = (int)$cid;
            $amount = roundMoney((float)$amount);
            if ($amount <= 0) {
                throw new Exception('بڕێ پارێ نادروستە');
            }

            $compName = '';
            $compBal = 0.0;
            $stN = $conn->prepare("SELECT name, balance FROM companies WHERE id = ? LIMIT 1");
            if ($stN) {
                $stN->bind_param("i", $cid);
                $stN->execute();
                $rN = $stN->get_result()->fetch_assoc();
                if ($rN) {
                    $compName = trim((string)($rN['name'] ?? ''));
                    $compBal = roundMoney((float)($rN['balance'] ?? 0));
                }
            }
            if ($cid <= 0 || $compName === '') {
                throw new Exception('کۆمپانیا نەهاتە دیتن');
            }

            if ($type == 'payment') {
                if ($compBal <= 0) {
                    throw new Exception('ئەڤ کۆمپانیە چ قەرز ل سەر نینن');
                }
                if ($amount > $compBal) {
                    $amount = $compBal;
                }
                if ($payTxnId !== '') {
                    $invRem = function_exists('pos_company_invoice_remaining_debt')
                        ? pos_company_invoice_remaining_debt($conn, $payTxnId)
                        : 0.0;
                    if ($invRem <= 0) {
                        throw new Exception('ئەڤ فاتورە چ قەرزێ مایی نینە');
                    }
                    if ($amount > $invRem) {
                        $amount = $invRem;
                    }
                }
            }

            if ($type == 'payment' && $payTxnId !== '') {
                $note = trim((string)$note);
                if ($note === '') {
                    $note = 'دانەڤا قەرزی - فاتورە';
                }
                $note .= ' | invoice_tx=' . $payTxnId;
            }
            if ($type == 'payment') {
                $note = trim((string)$note);
                $note .= ' | کانال: ' . ($payChannel === 'fib' ? 'FIB' : 'نقد');
            }

            // 1. Insert into Ledger
            $stmt = $conn->prepare("INSERT INTO ledger (companyId, type, amount, date, note, transaction_id) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("isdsss", $cid, $type, $amount, $date, $note, $txnId);
            $stmt->execute();
            $ledgerId = $stmt->insert_id;
            
            $newExpId = 0;
            if($type == 'payment') {
                $stmtPay = $conn->prepare("UPDATE companies SET balance = balance - ? WHERE id = ?");
                $stmtPay->bind_param("di", $amount, $cid);
                $stmtPay->execute();

                if (function_exists('pos_apply_company_invoice_debt_payment')) {
                    pos_apply_company_invoice_debt_payment($conn, $compName, $amount, $payTxnId);
                }

                $expNote = 'دانەڤا قەرزی کۆمپانیا: ' . ($compName !== '' ? $compName : ('#' . $cid));
                if ($payTxnId !== '') {
                    $expNote .= ' | فاتورە #' . $payTxnId;
                }
                $expNote .= ' | کانال: ' . ($payChannel === 'fib' ? 'FIB' : 'نقد');
                if ($note !== '') {
                    $expNote .= ' | ' . $note;
                }
                $newExpId = insertCompanyDebtPaymentExpense($conn, $amount, $expNote, $user, $date, $txnId, $cid, $payChannel);
            } elseif ($type == 'receive') {
                $stmtRecv = $conn->prepare("UPDATE companies SET balance = balance + ? WHERE id = ?");
                $stmtRecv->bind_param("di", $amount, $cid);
                $stmtRecv->execute();
            }
            
            $conn->commit();
            echo json_encode([
                "status"=>"success",
                "id"=>$ledgerId,
                "expense_id"=>$newExpId,
                "transaction_id"=>$txnId,
                "amount"=>$amount,
                "pay_transaction_id"=>$payTxnId,
                "payment_method"=>$payChannel,
            ], JSON_UNESCAPED_UNICODE); exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(["status"=>"error", "message"=>$e->getMessage()]); exit();
        }
    }

    if ($act == 'delete_company_payment') {
        pos_session_require_login_json();
        $id = (int)$_POST['id'];
        $user = isset($_POST['user']) ? trim((string)$_POST['user']) : 'System';

        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("SELECT companyId, type, amount, transaction_id FROM ledger WHERE id = ? AND (type = 'payment' OR type = 'receive') FOR UPDATE");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $res = $stmt->get_result();
            if (!$res || $res->num_rows === 0) {
                throw new Exception("لڤین نەهاتە دیتن یان جۆرێ وێ نەدرستە.");
            }
            $row = $res->fetch_assoc();
            
            $companyId = (int)$row['companyId'];
            $type = $row['type'];
            $amount = (float)$row['amount'];
            $txnId = $row['transaction_id'];
            
            if ($type === 'payment') {
                $stmtRefund = $conn->prepare("UPDATE companies SET balance = balance + ? WHERE id = ?");
                $stmtRefund->bind_param("di", $amount, $companyId);
                $stmtRefund->execute();

                if (!empty($txnId)) {
                    $stmtDelExp = $conn->prepare("DELETE FROM expenses WHERE type IN ('debt_payment','debt_payment_fib') AND transaction_id = ?");
                    $stmtDelExp->bind_param("s", $txnId);
                    $stmtDelExp->execute();
                }
            } elseif ($type === 'receive') {
                $stmtRefund = $conn->prepare("UPDATE companies SET balance = balance - ? WHERE id = ?");
                $stmtRefund->bind_param("di", $amount, $companyId);
                $stmtRefund->execute();
            }

            $stmtDel = $conn->prepare("DELETE FROM ledger WHERE id = ?");
            $stmtDel->bind_param("i", $id);
            $stmtDel->execute();

            logAction($conn, $user, 'delete_company_payment', "Deleted Company Payment ID: $id | Target: $companyId");
            $conn->commit();
            touchLastUpdate($conn);
            echo json_encode(["status"=>"success"]); exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(["status"=>"error", "message"=>$e->getMessage()], JSON_UNESCAPED_UNICODE); exit();
        }
    }

    if ($act == 'edit_company_payment') {
        pos_session_require_login_json();
        $id = (int)$_POST['id'];
        $new_amount = roundMoney((float)($_POST['amount'] ?? 0));
        $user = isset($_POST['user']) ? trim((string)$_POST['user']) : 'System';

        if ($new_amount <= 0) {
            echo json_encode(["status"=>"error", "message"=>"بڕێ پارێ نادروستە!"], JSON_UNESCAPED_UNICODE); exit();
        }

        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("SELECT companyId, type, amount, transaction_id FROM ledger WHERE id = ? AND (type = 'payment' OR type = 'receive') FOR UPDATE");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $res = $stmt->get_result();
            if (!$res || $res->num_rows === 0) {
                throw new Exception("لڤین نەهاتە دیتن یان جۆرێ وێ نەدرستە.");
            }
            $row = $res->fetch_assoc();
            
            $companyId = (int)$row['companyId'];
            $type = $row['type'];
            $old_amount = (float)$row['amount'];
            $txnId = $row['transaction_id'];
            
            $diff = $new_amount - $old_amount;
            
            if ($diff !== 0.0) {
                if ($type === 'payment') {
                    $stmtBal = $conn->prepare("SELECT balance FROM companies WHERE id = ? FOR UPDATE");
                    $stmtBal->bind_param("i", $companyId);
                    $stmtBal->execute();
                    $resBal = $stmtBal->get_result()->fetch_assoc();
                    if ($resBal) {
                        $current_balance = (float)$resBal['balance'];
                        if ($current_balance - $diff < 0) {
                            throw new Exception("بڕێ نوی ژ قەرزی مای مەزنترە!");
                        }
                    }
                    
                    $stmtUpdateBal = $conn->prepare("UPDATE companies SET balance = balance - ? WHERE id = ?");
                    $stmtUpdateBal->bind_param("di", $diff, $companyId);
                    $stmtUpdateBal->execute();

                    if (!empty($txnId)) {
                        $stmtUpdateExp = $conn->prepare("UPDATE expenses SET amount = ? WHERE type = 'debt_payment' AND transaction_id = ?");
                        $stmtUpdateExp->bind_param("ds", $new_amount, $txnId);
                        $stmtUpdateExp->execute();
                    }
                } elseif ($type === 'receive') {
                    $stmtUpdateBal = $conn->prepare("UPDATE companies SET balance = balance + ? WHERE id = ?");
                    $stmtUpdateBal->bind_param("di", $diff, $companyId);
                    $stmtUpdateBal->execute();
                }

                $stmtUpdateLedger = $conn->prepare("UPDATE ledger SET amount = ? WHERE id = ?");
                $stmtUpdateLedger->bind_param("di", $new_amount, $id);
                $stmtUpdateLedger->execute();
                
                logAction($conn, $user, 'edit_company_payment', "Edited Company Payment ID: $id | Target: $companyId");
            }

            $conn->commit();
            touchLastUpdate($conn);
            echo json_encode(["status"=>"success"]); exit();
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(["status"=>"error", "message"=>$e->getMessage()], JSON_UNESCAPED_UNICODE); exit();
        }
    }
