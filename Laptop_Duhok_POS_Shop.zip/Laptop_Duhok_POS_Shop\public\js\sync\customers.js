// sync/customers.js — debt, customers
        // --- DEBT NOTEBOOK LOGIC ---
        function toggleDebtSettings() {
            const enabled = document.getElementById('set-enable-debt').checked;
            const navItem = document.getElementById('nav-debt');
            if(navItem) navItem.style.display = enabled ? 'flex' : 'none';
            
            const posBtn = document.getElementById('btn-pos-debt-small');
            if(posBtn) posBtn.style.display = enabled ? 'block' : 'none';
        }

        function toggleMultiCartTabsUI() {
            const chk = document.getElementById('set-enable-multi-cart');
            const enabled = chk ? chk.checked : true;
            if (db && db.settings) {
                db.settings.enableMultiCartTabs = enabled;
            }
            const container = document.getElementById('pos-tabs-container');
            if (container) {
                container.style.display = enabled ? 'flex' : 'none';
            }
        }

        function toggleCustomerNameUI() {
            const enabled = document.getElementById('set-show-customer-name').checked;
            const input = document.getElementById('pos-customer-name');
            if(input) input.style.display = enabled ? 'block' : 'none';
        }

        window.refreshEntityDatalists = function() {
            if (typeof window.populateCustomerDatalist === 'function') window.populateCustomerDatalist();
            if (typeof window.populatePurchaseCompanyDatalist === 'function') window.populatePurchaseCompanyDatalist();
            var searchEl = document.getElementById('purchase-supplier-search');
            if (searchEl && document.activeElement === searchEl) return;
            if (typeof window.syncPurchaseSupplierSearchFromSelect === 'function') window.syncPurchaseSupplierSearchFromSelect();
        };

        function applyKitchenVisibility() {
            var enabled = (db && db.settings && db.settings.enableKitchen !== false);
            var chk = document.getElementById('set-enable-kitchen');
            if (chk) enabled = chk.checked;
            
            var btn = document.getElementById('btn-pos-kitchen');
            if (btn) btn.style.display = enabled ? '' : 'none';
            document.querySelectorAll('[onclick*="printKitchen"]').forEach(function(b) {
                b.style.display = enabled ? '' : 'none';
            });
        }

        function saveCustomer() {
            if(!checkPermission('debt_manage', 'زێدەکرنا کریاری')) return;

            const name = (document.getElementById('new-cust-name')?.value || '').trim();
            const phone = (document.getElementById('new-cust-phone')?.value || '').trim();
            const address = (document.getElementById('new-cust-address')?.value || '').trim();
            const openingBalance = parseCcEditMoneyField(document.getElementById('new-cust-opening-balance')?.value);
            const debtLimit = parseCcEditMoneyField(document.getElementById('new-cust-debt-limit')?.value);
            const payTerm = (typeof readProfilePaymentTerm === 'function')
                ? readProfilePaymentTerm('new-cust-payment-term-value', 'new-cust-payment-term-unit')
                : { value: 0, unit: 'day' };
            
            if(!name) return showToast('⚠️ هیڤیە ناڤێ کریاری بنڤیسە!', 'error');
            if(name.length < 2) return showToast('⚠️ ناڤ گەلەک یێ کورتە! (لانی کەم ٢ پیت)', 'error');
            
            const exists = (db.customers || []).some(function(c) {
                return c && (String(c.name || '').toLowerCase() === name.toLowerCase() || (phone && c.phone === phone));
            });
            if(exists) return showToast('⚠️ ئەڤ کریارە بەری نوکە یێ هەی!', 'error');
            
            const formData = new FormData();
            formData.append('action', 'save_customer');
            formData.append('name', name);
            formData.append('phone', phone);
            formData.append('address', address);
            formData.append('opening_balance', openingBalance);
            formData.append('debt_limit', debtLimit);
            formData.append('payment_term_value', payTerm.value);
            formData.append('payment_term_unit', payTerm.unit);
            
            fetch('?action=save_customer', { method: 'POST', body: formData, credentials: 'same-origin' })
            .then(function(res) {
                return res.text().then(function(raw) {
                    var t = String(raw || '').replace(/^\uFEFF/, '');
                    var i = t.indexOf('{');
                    if (i > 0) t = t.slice(i);
                    try { return JSON.parse(t); } catch (e1) {
                        throw new Error('وەڵامێ سێرڤەرێ نادروستە');
                    }
                });
            })
            .then(function(data) {
                if(data.status === 'success') {
                    const obSt = (typeof debtFormAmountToStoredIqd === 'function') ? debtFormAmountToStoredIqd(openingBalance) : openingBalance;
                    const dlSt = (typeof debtFormAmountToStoredIqd === 'function') ? debtFormAmountToStoredIqd(debtLimit) : debtLimit;
                    const bal = (typeof data.balance !== 'undefined') ? (parseFloat(data.balance) || 0) : obSt;
                    if (!db.customers) db.customers = [];
                    db.customers.push({ id: data.id, name: name, phone: phone, address: address, opening_balance: obSt, debt_limit: dlSt, balance: bal, payment_term_value: payTerm.value, payment_term_unit: payTerm.unit });
                    document.getElementById('new-cust-name').value = '';
                    document.getElementById('new-cust-phone').value = '';
                    if (document.getElementById('new-cust-address')) document.getElementById('new-cust-address').value = '';
                    if (document.getElementById('new-cust-opening-balance')) document.getElementById('new-cust-opening-balance').value = '0';
                    if (document.getElementById('new-cust-debt-limit')) document.getElementById('new-cust-debt-limit').value = '0';
                    if (document.getElementById('new-cust-payment-term-value')) document.getElementById('new-cust-payment-term-value').value = '0';
                    if (document.getElementById('new-cust-payment-term-unit')) document.getElementById('new-cust-payment-term-unit').value = 'day';
                    renderDebtView('customers');
                    if (typeof window.populateCustomerDatalist === 'function') window.populateCustomerDatalist();
                    if (typeof saveDB === 'function') saveDB();
                    showToast('✅ کریار ب سەرکەفتیانە هاتە زێدەکرن!');
                } else {
                    showToast('❌ ' + (data.message || 'نەشیا زێدە بکەت!'), 'error');
                }
            }).catch(function(err) { showToast('❌ هەڵە: ' + (err && err.message ? err.message : err), 'error'); });
        }

        function renderDebtView(type) {
            posScheduleListRender('debt_' + type, function() { renderDebtViewBody(type); });
        }

        /** Per-customer (or user) totals from local db.sales: sales + profit. */
        function buildDebtEntitySalesStatsMap(entityType) {
            var out = Object.create(null);
            var sales = (typeof db !== 'undefined' && db && Array.isArray(db.sales)) ? db.sales : [];
            if (!sales.length) return out;
            var expectType = (entityType === 'users' || entityType === 'user') ? 'user' : 'customer';
            var entities = expectType === 'user'
                ? ((db && db.users) || [])
                : ((db && db.customers) || []);
            var nameToId = Object.create(null);
            for (var ei = 0; ei < entities.length; ei++) {
                var ent = entities[ei];
                if (!ent || ent.id == null) continue;
                var nm = String(ent.name || '').trim().toLowerCase();
                if (nm) nameToId[nm] = ent.id;
            }
            var needProfit = (typeof canViewProfit === 'function') ? canViewProfit() : true;
            var productMap = null;
            function getProductMap() {
                if (productMap) return productMap;
                productMap = new Map();
                var prods = (db && db.products) || [];
                for (var pi = 0; pi < prods.length; pi++) {
                    if (prods[pi] && prods[pi].id != null) productMap.set(Number(prods[pi].id), prods[pi]);
                }
                return productMap;
            }
            for (var i = 0; i < sales.length; i++) {
                var s = sales[i];
                if (!s || s.is_returned) continue;
                var ctype = String(s.customer_type || 'customer').toLowerCase();
                if (ctype === 'staff') ctype = 'user';
                if (expectType === 'customer') {
                    if (ctype === 'user' || ctype === 'company') continue;
                } else if (ctype !== 'user') {
                    continue;
                }
                var cid = parseInt(s.customer_id, 10) || 0;
                if (cid <= 0) {
                    var cname = String(s.customer || s.customer_name || '').trim().toLowerCase();
                    if (cname && nameToId[cname] != null) cid = nameToId[cname];
                }
                if (cid <= 0) continue;
                var key = String(cid);
                if (!out[key]) out[key] = { sales: 0, profit: 0, salesUsd: 0, profitUsd: 0 };
                var total = parseFloat(s.total) || 0;
                out[key].sales += total;
                if (typeof frozenUsdFromStoredIqdRow === 'function') {
                    out[key].salesUsd += frozenUsdFromStoredIqdRow(s, total);
                }
                if (!needProfit) continue;
                var profit = 0;
                if (typeof computeSaleInvoiceProfit === 'function') {
                    var calc = computeSaleInvoiceProfit(s);
                    profit = (calc && calc.profit != null) ? Number(calc.profit) : 0;
                } else {
                    var items = s.items;
                    if (typeof items === 'string') {
                        try { items = JSON.parse(items); } catch (_eItems) { items = []; }
                    }
                    if (!Array.isArray(items)) items = [];
                    var resolveCost = (typeof resolveSaleLineCost === 'function')
                        ? resolveSaleLineCost
                        : function (it) { return parseFloat(it && it.cost) || 0; };
                    var getQty = (typeof getSaleLineQty === 'function')
                        ? getSaleLineQty
                        : function (it) {
                            var q = parseFloat(it && (it.qty != null ? it.qty : it.count));
                            return (!isNaN(q) && q > 0) ? q : 1;
                        };
                    var cogs = 0;
                    var map = getProductMap();
                    for (var li = 0; li < items.length; li++) {
                        cogs += resolveCost(items[li], map) * getQty(items[li]);
                    }
                    profit = total - cogs;
                }
                if (!isFinite(profit)) profit = 0;
                out[key].profit += profit;
                if (typeof frozenUsdFromStoredIqdRow === 'function') {
                    out[key].profitUsd += frozenUsdFromStoredIqdRow(s, profit);
                }
            }
            return out;
        }
        window.buildDebtEntitySalesStatsMap = buildDebtEntitySalesStatsMap;

        function renderDebtViewBody(type, opts) {
            opts = opts || {};
            const container = document.getElementById('debt-list-container');
            const addBox = document.getElementById('debt-add-customer-box');
            if (!container) return;

            var prevSearch = opts.preserveSearch != null ? opts.preserveSearch : '';
            if (!opts.serverRows) {
                try {
                    var _ds = document.getElementById('debt-search-input');
                    if (_ds) prevSearch = _ds.value;
                } catch (_eDs) {}
            }
            var searchTrim = String(prevSearch || '').trim();
            if (!opts.serverRows && type === 'customers') {
                var localRows = (typeof posFilterEntityRowsLocal === 'function')
                    ? posFilterEntityRowsLocal(db.customers || [], searchTrim)
                    : (db.customers || []).filter(function(c) { return c && (c.is_active == null || Number(c.is_active) !== 0); });
                renderDebtViewBody(type, {
                    serverRows: localRows,
                    serverHasMore: false,
                    preserveSearch: prevSearch,
                    fromLocal: true
                });
                var seq = (window._posCustSearchSeq = (window._posCustSearchSeq || 0) + 1);
                var seqNow = seq;
                var fetchFn = (typeof posFetchEntitySearchLocal === 'function')
                    ? posFetchEntitySearchLocal
                    : ((typeof posFetchEntitySearch === 'function') ? posFetchEntitySearch : null);
                if (!fetchFn) return;
                var dLimit = (typeof posListRenderLimit === 'function') ? posListRenderLimit(searchTrim) : 120;
                var p = fetchFn('customers', searchTrim, dLimit, 0);
                var timed = Promise.race([
                    p,
                    new Promise(function(resolve) {
                        setTimeout(function() { resolve({ status: 'timeout' }); }, 8000);
                    })
                ]);
                timed.then(function(res) {
                    if (seqNow !== window._posCustSearchSeq) return;
                    var inp = document.getElementById('debt-search-input');
                    if (inp && String(inp.value || '') !== String(prevSearch || '')) return;
                    if (!res || res.status !== 'ok') return;
                    if (res.rows && typeof posUpsertCustomers === 'function') posUpsertCustomers(res.rows);
                    renderDebtViewBody(type, { serverRows: res.rows || [], serverHasMore: !!res.has_more, preserveSearch: prevSearch });
                }).catch(function() {});
                return;
            }
            
            // 1. Advanced Header & Controls (Search & Sort)
            let controlsHtml = `
            <div style="grid-column: 1 / -1; display: flex; gap: 10px; margin-bottom: 15px; flex-wrap: wrap;">
                <div style="flex: 1; position: relative;">
                    <i class="fas fa-search" style="position: absolute; right: 15px; top: 15px; color: var(--text-muted);"></i>
                    <input type="text" id="debt-search-input" class="input-std" placeholder="${String(t('debt_search_placeholder')).replace(/"/g, '&quot;')}" style="margin:0; padding-right: 40px;" onkeyup="renderDebtView('${type}')">
                </div>
                <select id="debt-sort-select" class="input-std" style="width: auto; margin:0;" onchange="renderDebtView('${type}')">
                    <option value="high_debt">${escapeHtml(t('debt_sort_high'))}</option>
                    <option value="low_debt">${escapeHtml(t('debt_sort_low'))}</option>
                    <option value="name">${escapeHtml(t('debt_sort_name'))}</option>
                    <option value="recent">${escapeHtml(t('debt_sort_recent'))}</option>
                </select>
            </div>`;
            
            addBox.style.display = (type === 'customers') ? 'grid' : 'none';
            if (type === 'customers') syncDebtAddCustomerMoneyPlaceholders();
            
            // 2. Data Preparation
            let list = opts.serverRows ? opts.serverRows.slice() : ((type === 'customers') ? [...db.customers] : [...db.users]);
            list = list.filter(function(item) {
                return item && (item.is_active == null || Number(item.is_active) !== 0);
            });

            // 3. Sorting Logic (Advanced)
            const sortMode = document.getElementById('debt-sort-select') ? document.getElementById('debt-sort-select').value : 'high_debt';
            
            if (sortMode === 'high_debt') list.sort((a, b) => (b.balance || 0) - (a.balance || 0));
            else if (sortMode === 'low_debt') list.sort((a, b) => (a.balance || 0) - (b.balance || 0));
            else if (sortMode === 'name') list.sort((a, b) => a.name.localeCompare(b.name));
            else if (sortMode === 'recent') list.sort((a, b) => b.id - a.id);

            var totalDebt = (typeof roundMoney === 'function' ? roundMoney : function(x) { return Math.round(Number(x)); })(list.reduce((sum, item) => sum + (parseFloat(item.balance) || 0), 0));
            var totalDebtUsd = 0;
            var isUsdMode = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
            if (isUsdMode) {
                list.forEach(function(item) {
                    var b = parseFloat(item.balance) || 0;
                    if (b <= 0) return;
                    var bFx = (type === 'customers' && typeof fxUsdRateFormatOptsForEntityBalance === 'function')
                        ? fxUsdRateFormatOptsForEntityBalance(item.id, 'customer', b)
                        : undefined;
                    var usdAmt = 0;
                    if (typeof storedIqdToUsdDisplayAmount === 'function') {
                        usdAmt = storedIqdToUsdDisplayAmount(b, bFx);
                    } else if (bFx && bFx.fxUsdRate > 0) {
                        usdAmt = Math.round((b / (bFx.fxUsdRate / 100)) * 100) / 100;
                    } else {
                        var r = (typeof getUsdRatePerOne === 'function') ? getUsdRatePerOne() : 1500;
                        usdAmt = r > 0 ? (b / r) : 0;
                    }
                    totalDebtUsd += (usdAmt || 0);
                });
            }
            var totalCustDebtFx = (isUsdMode && totalDebtUsd > 0 && totalDebt > 0)
                ? { directUsd: totalDebtUsd, fxUsdRate: Math.round((totalDebt / totalDebtUsd) * 100) }
                : undefined;

            // 4. Summary Dashboard
            let html = `
            <div style="grid-column: 1 / -1; display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 20px;">
                <div class="card duhok-debt-total-card" style="background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); border: 1px solid #334155; padding: 15px; margin:0;">
                    <h4 style="color: #94a3b8; margin: 0 0 5px 0;"><i class="fas fa-money-bill-wave" style="margin-left:6px;"></i> ${escapeHtml(t('debt_summary_total'))}</h4>
                    <h1 style="color: #ef4444; margin: 0;">${formatCurrency(totalDebt, totalCustDebtFx)} <small style="font-size: 1rem;">${getCurrencySymbol()}</small></h1>
                    ${duhokPaperHintHtmlSafe(totalDebt, false, totalCustDebtFx)}
                    ${duhokPaperLegendHtmlSafe()}
                </div>
                <div class="card" style="background: var(--card); border: 1px solid var(--border); padding: 15px; margin:0;">
                    <h4 style="color: var(--text-muted); margin: 0 0 5px 0;"><i class="fas fa-users" style="margin-left:6px;color:var(--brand);"></i> ${escapeHtml(t('debt_summary_debtor_count'))}</h4>
                    <h1 style="color: var(--brand); margin: 0;">${list.length} <small style="font-size: 1rem;">${escapeHtml(t('debt_unit_person'))}</small></h1>
                </div>
            </div>
            ${controlsHtml}
            `;

            // 5. Render Cards (Professional Design)
            const searchTerm = (prevSearch || '').toLowerCase();
            
            const filteredList = opts.serverRows ? list : list.filter(item => {
                var idRaw = String(item.id != null ? item.id : '');
                return item.name.toLowerCase().includes(searchTerm)
                    || (item.phone && item.phone.includes(searchTerm))
                    || (idRaw && (idRaw === searchTerm || ('#' + idRaw) === searchTerm || idRaw.indexOf(searchTerm) !== -1));
            });
            var debtListLimit = (typeof posListRenderLimit === 'function') ? posListRenderLimit(searchTerm) : 100;

            if (opts.serverRows && !opts.fromLocal) {
                html += '<p style="grid-column:1/-1;font-size:0.85rem;color:var(--text-muted);margin:0 0 8px;"><i class="fas fa-database"></i> '
                    + escapeHtml((typeof t === 'function' && t('search_results_server') !== 'search_results_server') ? t('search_results_server') : 'ئەنجام لە سێرڤەر')
                    + (opts.serverHasMore ? ' — ' + escapeHtml((typeof t === 'function' && t('list_search_for_more') !== 'list_search_for_more') ? t('list_search_for_more') : 'گەڕان بکە بۆ زیاتر') : '')
                    + '</p>';
            }

            var showCardProfit = (typeof canViewProfit === 'function') ? canViewProfit() : true;
            var salesStatsMap = (type === 'customers' || type === 'users')
                ? buildDebtEntitySalesStatsMap(type)
                : Object.create(null);

            html += filteredList.slice(0, debtListLimit).map(item => {
                const balance = parseFloat(item.balance) || 0;
                const isDebt = balance > 0;
                const statusColor = isDebt ? '#ef4444' : '#10b981';
                const statusText = isDebt ? t('debt_status_owed') : t('debt_status_clear');
                const debtLimitStored = Math.max(0, parseFloat(item.debt_limit) || 0);
                const openingBalanceStored = Math.max(0, parseFloat(item.opening_balance) || 0);
                const overLimit = debtLimitStored > 0 && balance > debtLimitStored;
                var balFx = (type === 'customers' && typeof fxUsdRateFormatOptsForEntityBalance === 'function')
                    ? fxUsdRateFormatOptsForEntityBalance(item.id, 'customer', balance)
                    : undefined;
                const hasInstOverdue = (type === 'customers') && typeof customerHasOverdueInstallment === 'function' && customerHasOverdueInstallment(item.id);
                var stats = salesStatsMap[String(item.id)] || { sales: 0, profit: 0 };
                var salesAmt = parseFloat(stats.sales) || 0;
                var profitAmt = parseFloat(stats.profit) || 0;
                var profitColor = profitAmt > 0 ? '#10b981' : (profitAmt < 0 ? '#ef4444' : 'var(--text)');
                var salesProfitRow = (type === 'customers')
                    ? (`<div style="padding:6px 12px; background:var(--card); border-top:1px dashed var(--border); font-size:0.82rem; color:var(--text-muted); display:flex; justify-content:space-between; gap:10px; flex-wrap:wrap;">
                        <span><i class="fas fa-cart-shopping" style="margin-left:4px;"></i> ${escapeHtml(t('debt_card_sales'))}: <b style="color:var(--brand);">${(typeof formatCanonicalMoney === 'function') ? formatCanonicalMoney(salesAmt, stats.salesUsd) : formatCurrency(salesAmt)}</b></span>
                        ${showCardProfit ? `<span data-perm="view_profit"><i class="fas fa-chart-line" style="margin-left:4px;"></i> ${escapeHtml(t('debt_card_profit'))}: <b style="color:${profitColor};">${(typeof formatCanonicalMoney === 'function') ? formatCanonicalMoney(profitAmt, stats.profitUsd) : formatCurrency(profitAmt)}</b></span>` : ''}
                    </div>`)
                    : '';
                
                // Dynamic Progress Bar (Visualizing debt severity, assuming 500k is "high")
                const debtRatio = Math.min((balance / 500000) * 100, 100); 

                return `
                <div class="card debt-entity-card" title="${escapeHtml((typeof window.getEntityPaymentDueInfo === 'function' && window.getEntityPaymentDueInfo('customer', item) && window.getEntityPaymentDueInfo('customer', item).label) ? window.getEntityPaymentDueInfo('customer', item).label : '')}" data-debt-id="${item.id}" data-debt-type="${escapeHtml(type)}" data-debt-name="${escapeHtml(item.name || '')}" style="padding: 0; overflow: hidden; border: 1px solid ${overLimit ? '#f59e0b' : 'var(--border)'}; transition: transform 0.2s; cursor: pointer;">
                    <div style="padding: 15px; display: flex; justify-content: space-between; align-items: center; background: var(--input-bg);">
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <div style="width: 52px; height: 52px; border-radius: 50%; background: ${statusColor}20; color: ${statusColor}; display: flex; align-items: center; justify-content: center; font-size:1.35rem;">
                                <i class="fas ${isDebt ? 'fa-user-clock' : 'fa-user-check'}"></i>
                            </div>
                            <div>
                                <h3 style="margin: 0; font-size: 1rem; display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
                                    <span>${escapeHtml(item.name)}</span>
                                    <span style="background:rgba(59,130,246,0.15); color:#3b82f6; padding:1px 7px; border-radius:6px; font-size:0.72rem; font-weight:700; direction:ltr;" title="${escapeHtml(t('debt_card_id') || 'ئایدی')}">#${escapeHtml(String(item.id != null ? item.id : ''))}</span>
                                </h3>
                                <small style="color: var(--text-muted); display:block;"><i class="fas fa-phone" style="margin-left:4px;"></i> ${escapeHtml(item.phone || t('debt_no_phone'))}</small>
                                ${hasInstOverdue ? '<span class="installment-debt-badge">' + escapeHtml(typeof t === 'function' ? t('cust_installment_overdue_badge') : 'قست') + '</span>' : ''}
                                ${(type === 'customers' && typeof window.renderPaymentDueBadgeHtml === 'function') ? window.renderPaymentDueBadgeHtml('customer', item) : ''}
                                ${(type === 'customers' && item.address) ? `<small style="color: var(--text-muted); display:block;"><i class="fas fa-location-dot" style="margin-left:4px;"></i> ${escapeHtml(item.address)}</small>` : ''}
                            </div>
                        </div>
                        <div style="text-align: right;">
                            <h3 style="margin: 0; color: ${statusColor};"><i class="fas fa-coins" style="font-size:0.85rem;margin-left:4px;"></i> ${formatCurrency(balance, balFx)}</h3>
                            ${duhokPaperHintHtmlSafe(balance, false, balFx)}
                            <small style="color: ${statusColor}; font-weight: bold;">${escapeHtml(statusText)}</small>
                        </div>
                    </div>
                    ${(type === 'customers') ? `<div style="padding:8px 12px; background:${overLimit ? 'rgba(245,158,11,0.15)' : 'var(--card)'}; border-top:1px dashed var(--border); font-size:0.82rem; color:var(--text-muted); display:flex; justify-content:space-between; gap:10px; flex-wrap:wrap;">
                        <span><i class="fas fa-clock-rotate-left" style="margin-left:4px;"></i> ${escapeHtml(t('debt_card_old_opening'))}: <b style="color:var(--text);">${debtLedgerMoneyForCard(openingBalanceStored)}</b>${duhokPaperHintHtmlSafe(openingBalanceStored, true)}</span>
                        <span><i class="fas fa-gauge-high" style="margin-left:4px;"></i> ${escapeHtml(t('debt_card_limit'))}: <b style="color:${debtLimitStored > 0 ? (overLimit ? '#f59e0b' : 'var(--text)') : 'var(--text-muted)'};">${debtLimitStored > 0 ? debtLedgerMoneyForCard(debtLimitStored) : '—'}</b></span>
                        ${overLimit ? `<span style="color:#f59e0b; font-weight:700;"><i class="fas fa-exclamation-triangle"></i> ${escapeHtml(t('debt_over_limit_warning'))}</span>` : ''}
                    </div>` : ''}
                    ${(type === 'customers' && typeof window.renderPaymentDueRemainingRowHtml === 'function') ? window.renderPaymentDueRemainingRowHtml('customer', item) : ''}
                    ${salesProfitRow}
                    ${isDebt ? `<div style="height: 4px; background: var(--border); width: 100%;"><div style="height: 100%; background: ${statusColor}; width: ${debtRatio}%;"></div></div>` : ''}
                    <div class="page-action-row" style="padding: 10px; display: flex; gap: 5px; background: var(--card);">
                        <div class="page-actions-standard" style="display: flex; gap: 5px; width: 100%;">
                            <button type="button" class="btn btn-sm btn-success" style="flex: 1;" data-debt-action="pay" data-debt-id="${item.id}" data-debt-type="${escapeHtml(type)}"><i class="fas fa-hand-holding-usd"></i> ${escapeHtml(t('debt_btn_collect'))}</button>
                            <button type="button" class="btn btn-sm btn-info" style="flex: 1;" data-debt-action="profile" data-debt-id="${item.id}" data-debt-type="${escapeHtml(type)}" data-debt-name="${escapeHtml(item.name || '')}"><i class="fas fa-list"></i> ${escapeHtml(t('debt_btn_statement'))}</button>
                            ${type === 'customers' ? `<button type="button" class="btn btn-sm btn-warning" style="padding:0 10px;" data-debt-action="edit" data-debt-id="${item.id}" data-debt-name="${escapeHtml(item.name || '')}" title="${String(t('debt_btn_edit')).replace(/"/g, '&quot;')}"><i class="fas fa-edit"></i> ${escapeHtml(t('debt_btn_edit'))}</button>` : ''}
                            ${type === 'customers' ? `<button type="button" class="btn btn-sm btn-danger" style="width: 35px;" data-debt-action="delete" data-debt-id="${item.id}"><i class="fas fa-trash"></i></button>` : ''}
                        </div>
                    </div>
                </div>`;
            }).join('');

            if (filteredList.length > debtListLimit) {
                html += '<p style="grid-column:1/-1;text-align:center;color:var(--text-muted);font-size:0.88rem;margin:8px 0 0;">'
                    + '<i class="fas fa-search"></i> '
                    + escapeHtml((typeof t === 'function' && t('list_search_for_more') !== 'list_search_for_more') ? t('list_search_for_more') : 'گەڕان بکە بۆ بینینا زیاتر')
                    + ' — ' + debtListLimit + ' / ' + filteredList.length
                    + '</p>';
            }
            
            container.innerHTML = html;
            bindDebtListCardActions(container, type);
            
            // Restore search value; keep caret if user is still typing
            const searchInput = document.getElementById('debt-search-input');
            if (searchInput) {
                var keepFocus = document.activeElement && document.activeElement.id === 'debt-search-input';
                var caret = keepFocus ? document.activeElement.selectionStart : null;
                searchInput.value = prevSearch || searchTerm;
                if (keepFocus) {
                    searchInput.focus();
                    try {
                        var pos = (caret != null) ? caret : String(searchInput.value || '').length;
                        searchInput.setSelectionRange(pos, pos);
                    } catch (_eCaret) {}
                }
            }
            
            document.getElementById('debt-ledger-view').style.display = 'none';
            if (typeof window.applyI18nSubtree === 'function') {
                var debtViewRoot = document.getElementById('view-debt');
                if (debtViewRoot) window.applyI18nSubtree(debtViewRoot);
            }
        }

        function bindDebtListCardActions(container, listType) {
            if (!container) return;
            container.onclick = function(ev) {
                var btn = ev.target.closest('[data-debt-action]');
                if (btn) {
                    ev.preventDefault();
                    ev.stopPropagation();
                    var action = btn.getAttribute('data-debt-action');
                    var id = btn.getAttribute('data-debt-id');
                    var dtype = btn.getAttribute('data-debt-type') || listType;
                    var dname = btn.getAttribute('data-debt-name') || '';
                    if (id == null || id === '') return;
                    if (action === 'pay') payDebtAmount(id, dtype);
                    else if (action === 'profile') showDebtLedger(id, dtype, dname);
                    else if (action === 'edit') editCustomer(id, dname);
                    else if (action === 'delete') deleteCustomer(id);
                    return;
                }
                var card = ev.target.closest('.debt-entity-card[data-debt-id]');
                if (!card) return;
                showDebtLedger(card.getAttribute('data-debt-id'), card.getAttribute('data-debt-type') || listType, card.getAttribute('data-debt-name') || '');
            };
        }

        function showDebtLedger(id, type, name) {
            if (id == null || id === '') return;
            type = type || 'customers';
            name = name || '';
            currentDebtParams = { id: id, type: type, name: name };
            if (type === 'customers' || type === 'customer') {
                openCustomerProfile(id);
            } else {
                renderCurrentDebtLedger();
            }
        }

        function deleteCustomer(id) {
            if(confirm("دڵنیای ژ ژێبرنا ڤێ کریاری؟")) {
                const formData = new FormData();
                formData.append('action', 'delete_customer');
                formData.append('id', id);
                fetch('?action=delete_customer', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if(data.status === 'success') {
                        db.customers = (db.customers || []).filter(c => c && c.id != id);
                        var curCid = (typeof window.getPosActiveCustomerId === 'function') ? window.getPosActiveCustomerId() : 0;
                        if (curCid == id && typeof window.clearPosCustomerInput === 'function') {
                            window.clearPosCustomerInput();
                        }
                        if (typeof posTabs !== 'undefined' && Array.isArray(posTabs)) {
                            posTabs.forEach(function (tab) {
                                if (tab && tab.customerId == id) {
                                    tab.customerName = '';
                                    tab.customerId = null;
                                }
                            });
                        }
                        renderDebtView('customers');
                    } else if(data.message && confirm(data.message + '\n\nئەرێ تە دڤێت ژ کار بێخی ل شوینا ژێبرنێ؟')) {
                        const fd = new FormData();
                        fd.append('action', 'void_customer');
                        fd.append('id', id);
                        fetch('?action=void_customer', { method: 'POST', body: fd }).then(r => r.json()).then(d => {
                            if(d.status === 'success') {
                                if (window.db && Array.isArray(window.db.customers)) {
                                    window.db.customers = window.db.customers.filter(c => c && c.id != id);
                                }
                                var curCid2 = (typeof window.getPosActiveCustomerId === 'function') ? window.getPosActiveCustomerId() : 0;
                                if (curCid2 == id && typeof window.clearPosCustomerInput === 'function') {
                                    window.clearPosCustomerInput();
                                }
                                if (typeof posTabs !== 'undefined' && Array.isArray(posTabs)) {
                                    posTabs.forEach(function (tab) {
                                        if (tab && tab.customerId == id) {
                                            tab.customerName = '';
                                            tab.customerId = null;
                                        }
                                    });
                                }
                                renderDebtView('customers');
                                if (typeof connectToDB === 'function') connectToDB(true);
                            }
                        });
                    } else if(data.message) showToast(data.message, 'error');
                });
            }
        }

        function editCustomer(id, fallbackName) {
            if(!checkPermission('debt_manage', 'دەستکاریکرنا کریاری')) return;
            openCustomerCompanyEditModal('customer', id, fallbackName);
        }

        window.editCustomer = editCustomer;
        window.saveCustomer = saveCustomer;
        window.renderDebtView = renderDebtView;

        function renderCurrentDebtLedger() {
            if (typeof ensureDateFilterToday === 'function') ensureDateFilterToday('debt');
            if(!currentDebtParams) return;
            const {id, type, name} = currentDebtParams;
            
            document.getElementById('debt-ledger-view').style.display = 'block';
            document.getElementById('debt-ledger-title').innerHTML = escapeHtml(t('debt_ledger_title_prefix')) + ': ' + escapeHtml(name) + ' <button class="btn btn-success btn-sm" style="float:left" onclick="payDebtAmount(' + id + ', \'' + String(type).replace(/'/g, "\\'") + '\')">' + escapeHtml(t('pay_debt')) + '</button>';
            
            const targetType = (type === 'customers' || type === 'customer') ? 'customer' : 'user';
            const entity = (type === 'customers' || type === 'customer') ? db.customers.find(c => c.id == id) : db.users.find(u => u.id == id);
            const balance = entity ? (parseFloat(entity.balance) || 0) : 0;
            const ledger = db.customer_ledger.filter(l => l.target_id == id && l.target_type == targetType && isDateInScope(l.date, 'debt')).sort((a, b) => b.id - a.id);
            const totalSales = ledger.filter(l => l.type === 'sale').reduce((s, l) => s + (parseFloat(l.amount) || 0), 0);
            const totalPaid = ledger.filter(l => l.type === 'payment' || l.type === 'pay').reduce((s, l) => s + Math.abs(parseFloat(l.amount) || 0), 0);
            const totalReturn = ledger.filter(l => l.type === 'return').reduce((s, l) => s + Math.abs(parseFloat(l.amount) || 0), 0);
            
            const summaryHtml = '<div style="padding:10px; background:var(--input-bg); border-radius:8px; margin-bottom:12px; display:grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap:8px; font-size:0.9rem;"><span><b>' + escapeHtml(t('debt_ledger_current_balance')) + ':</b> ' + formatCurrency(balance) + '</span><span><b>' + escapeHtml(t('debt_ledger_total_sales')) + ':</b> ' + formatCurrency(totalSales) + '</span><span><b>' + escapeHtml(t('debt_ledger_paid')) + ':</b> ' + formatCurrency(totalPaid) + '</span><span><b>' + escapeHtml(t('debt_ledger_returns')) + ':</b> ' + formatCurrency(totalReturn) + '</span></div>';
            
            document.getElementById('debt-ledger-list').innerHTML = summaryHtml + ledger.map(l => {
                var rec = (l.receipt_id && l.receipt_id.toString().trim()) ? ' <small style="color:var(--text-muted);">' + escapeHtml(t('debt_ledger_receipt')) + escapeHtml(l.receipt_id) + '</small>' : '';
                var typeLabel = l.type === 'sale' ? t('debt_ledger_type_sale') : (l.type === 'return' ? t('debt_ledger_type_return') : t('debt_ledger_type_payment'));
                return `<div style="border-bottom:1px solid var(--border); padding:10px; display:flex; justify-content:space-between;">
                    <div>
                        <b>${escapeHtml(typeLabel)}${rec}</b><br>
                        <small>${new Date(l.date).toLocaleString()}</small>
                    </div>
                    <div style="text-align:right;">
                        <b style="color:${l.type === 'sale' ? 'red' : (l.type === 'return' ? 'orange' : 'green')}">${formatCurrency(l.amount, (typeof fxUsdRateFormatOpts === 'function') ? fxUsdRateFormatOpts(l) : undefined)}</b>
                    </div>
                </div>`;
            }).join('');
            if (typeof window.applyI18nSubtree === 'function') {
                var debtView2 = document.getElementById('view-debt');
                if (debtView2) window.applyI18nSubtree(debtView2);
            }
        }

        function payDebtAmount(id, type) {
            if (!checkPermission('debt_manage', 'دانەڤا قەرزی')) return;
            openCollectDebtModal(id, type);
        }

        var _collectDebtCtx = null;
        var _collectDebtPayMethod = 'cash';

        function setCollectDebtPayMethod(method) {
            var m = String(method || '').toLowerCase() === 'fib' ? 'fib' : 'cash';
            _collectDebtPayMethod = m;
            var hid = document.getElementById('cdm-pay-method');
            if (hid) hid.value = m;
            document.querySelectorAll('.debt-pay-method-toggle[data-debt-pay="collect"] .cart-pay-method-btn').forEach(function (btn) {
                var on = String(btn.getAttribute('data-pay') || '') === m;
                btn.classList.toggle('is-active', on);
                btn.setAttribute('aria-pressed', on ? 'true' : 'false');
            });
        }
        function getCollectDebtPayMethod() {
            var hid = document.getElementById('cdm-pay-method');
            if (hid && (hid.value === 'fib' || hid.value === 'cash')) return hid.value;
            return _collectDebtPayMethod === 'fib' ? 'fib' : 'cash';
        }
        function getCustomerSaleOwedDebt(s) {
            if (!s) return 0;
            // Prefer remaining_debt (already total − checkout paid − later debt payments).
            if (s.remaining_debt != null && s.remaining_debt !== '') {
                var rem = parseFloat(s.remaining_debt);
                if (!isNaN(rem)) return Math.max(0, rem);
            }
            // Fallback: unpaid at checkout = total − paid_amount (never treat full total as debt).
            var total = parseFloat(s.total) || 0;
            var paid = parseFloat(s.paid_amount) || 0;
            if (paid > 0 || (s.paid_amount != null && s.paid_amount !== '')) {
                return Math.max(0, total - paid);
            }
            var debt = parseFloat(s.debt_amount);
            if (!isNaN(debt) && debt > 0) return debt;
            var pm = String(s.payment_method || '').toLowerCase();
            if (pm === 'debt') return Math.max(0, total);
            return 0;
        }
        window.setCollectDebtPayMethod = setCollectDebtPayMethod;
        window.getCollectDebtPayMethod = getCollectDebtPayMethod;
        window.getCustomerSaleOwedDebt = getCustomerSaleOwedDebt;

        function collectDebtDisplayAmount(iqdAmount) {
            var n = parseFloat(iqdAmount) || 0;
            var frozen = (_collectDebtCtx && Number(_collectDebtCtx.fxRatePerOne) > 0) ? Number(_collectDebtCtx.fxRatePerOne) : 0;
            if (typeof storedIqdToDebtFormAmount === 'function') return storedIqdToDebtFormAmount(n, frozen || undefined);
            var isUsd = (typeof getActiveCurrency === 'function') && getActiveCurrency() === 'USD';
            var rate = frozen || ((typeof getUsdRatePerOne === 'function') ? getUsdRatePerOne() : 0);
            if (isUsd && rate > 0) {
                return (typeof storedIqdToUsdAmount === 'function') ? storedIqdToUsdAmount(n, rate) : Math.round((n / rate) * 100) / 100;
            }
            return n;
        }

        function collectDebtParseDisplayToIqd(displayVal) {
            var valDisplay = (typeof parseAmountInput === 'function')
                ? parseAmountInput(String(displayVal))
                : parseFloat(String(displayVal).replace(/,/g, ''));
            if (isNaN(valDisplay)) return NaN;
            if (valDisplay === 0) return 0;
            var frozen = (_collectDebtCtx && Number(_collectDebtCtx.fxRatePerOne) > 0) ? Number(_collectDebtCtx.fxRatePerOne) : 0;
            if (typeof debtFormAmountToStoredIqd === 'function') return debtFormAmountToStoredIqd(valDisplay, frozen || undefined);
            var isUsd = (typeof getActiveCurrency === 'function') && getActiveCurrency() === 'USD';
            var rate = frozen || ((typeof getUsdRatePerOne === 'function') ? getUsdRatePerOne() : 0);
            if (isUsd && rate > 0 && typeof usdAmountToStoredIqd === 'function') return usdAmountToStoredIqd(valDisplay, rate);
            var roundM = (typeof roundMoney === 'function') ? roundMoney : function (x) { return Math.round(Number(x)); };
            return (isUsd && rate > 0) ? roundM(valDisplay * rate) : valDisplay;
        }

        function collectDebtFormatOpts() {
            var r = (_collectDebtCtx && Number(_collectDebtCtx.fxRatePerOne) > 0)
                ? Number(_collectDebtCtx.fxRatePerOne)
                : 0;
            if (!(r > 0)) return undefined;
            var bundle = Math.round(r * 100);
            if (!isFinite(bundle) || bundle < 1000) return undefined;
            return { fxUsdRate: bundle };
        }

        function updateCollectDebtPreview() {
            if (!_collectDebtCtx) return;
            var amtEl = document.getElementById('cdm-amount');
            var afterEl = document.getElementById('cdm-after-balance');
            if (!amtEl || !afterEl) return;
            var raw = String(amtEl.value || '').trim();
            var iqd = collectDebtParseDisplayToIqd(raw);
            if (raw === '' || isNaN(iqd)) {
            afterEl.textContent = formatCurrency(_collectDebtCtx.previousDebtBeforePayment, collectDebtFormatOpts());
                return;
            }
            if (iqd === 0) iqd = _collectDebtCtx.previousDebtBeforePayment;
            var remain = Math.max(0, (_collectDebtCtx.previousDebtBeforePayment || 0) - iqd);
            afterEl.textContent = formatCurrency(remain, collectDebtFormatOpts());
        }

        function fillCollectDebtFullAmount() {
            if (!_collectDebtCtx) return;
            var amtEl = document.getElementById('cdm-amount');
            if (!amtEl) return;
            amtEl.value = String(_collectDebtCtx.balanceDisplay);
            updateCollectDebtPreview();
            amtEl.focus();
            amtEl.select();
        }

        function closeCollectDebtModal() {
            var m = document.getElementById('collect-debt-modal');
            if (m) m.style.display = 'none';
            _collectDebtCtx = null;
        }
        window.closeCollectDebtModal = closeCollectDebtModal;
        window.fillCollectDebtFullAmount = fillCollectDebtFullAmount;
        window.updateCollectDebtPreview = updateCollectDebtPreview;

        function openCollectDebtModal(id, type, opts) {
            opts = opts || {};
            var entity = null;
            var normType = (type === 'customers' || type === 'customer') ? 'customer' : 'user';
            if (normType === 'customer') entity = (db.customers || []).find(function (c) { return String(c.id) === String(id); });
            else entity = (db.users || []).find(function (u) { return String(u.id) === String(id); });
            if (!entity) {
                if (typeof showToast === 'function') showToast('بکر نەهاتە دیتن!', 'error');
                else if (typeof window.posAlert === 'function') window.posAlert({ message: 'بکر نەهاتە دیتن!', tone: 'danger' });
                else alert('بکر نەهاتە دیتن!');
                return;
            }
            if ((parseFloat(entity.balance) || 0) <= 0) {
                if (typeof showToast === 'function') showToast('ئەڤ بکرە چ پارە ل سەر نینن!', 'warning');
                else if (typeof window.posAlert === 'function') window.posAlert({ message: 'ئەڤ بکرە چ پارە ل سەر نینن!', tone: 'warning' });
                else alert('ئەڤ بکرە چ پارە ل سەر نینن!');
                return;
            }
            var previousDebtBeforePayment = parseFloat(entity.balance) || 0;
            var saleId = Math.max(0, parseInt(opts.saleId, 10) || 0);
            var invoiceRemaining = Math.max(0, parseFloat(opts.invoiceRemaining) || 0);
            if (saleId > 0 && invoiceRemaining > 0) {
                previousDebtBeforePayment = Math.min(previousDebtBeforePayment, invoiceRemaining);
            }
            var fxRatePerOne = 0;
            if (saleId > 0 && db && Array.isArray(db.sales)) {
                var saleFxRow = db.sales.find(function (s) { return parseInt(s.id, 10) === saleId; });
                if (saleFxRow && typeof fxBundleToRatePerOne === 'function') {
                    fxRatePerOne = fxBundleToRatePerOne(saleFxRow.fx_usd_rate);
                }
            }
            if (!(fxRatePerOne > 0) && normType === 'customer' && typeof fxUsdRateFormatOptsForEntityBalance === 'function') {
                var blend = fxUsdRateFormatOptsForEntityBalance(id, 'customer', previousDebtBeforePayment);
                if (blend && blend.fxUsdRate && typeof fxBundleToRatePerOne === 'function') {
                    fxRatePerOne = fxBundleToRatePerOne(blend.fxUsdRate);
                }
            }
            if (!(fxRatePerOne > 0) && typeof getUsdRatePerOne === 'function') fxRatePerOne = getUsdRatePerOne();
            _collectDebtCtx = {
                id: id,
                type: normType,
                entity: entity,
                previousDebtBeforePayment: previousDebtBeforePayment,
                saleId: saleId,
                invoiceRemaining: invoiceRemaining,
                fxRatePerOne: fxRatePerOne
            };
            var balanceDisplay = collectDebtDisplayAmount(previousDebtBeforePayment);
            _collectDebtCtx.balanceDisplay = balanceDisplay;
            var m = document.getElementById('collect-debt-modal');
            if (!m) {
                if (typeof showToast === 'function') showToast('مۆدال نەدۆزرایەوە', 'error');
                return;
            }
            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(m);
            var titleEl = document.getElementById('cdm-modal-title');
            if (titleEl) {
                var titleSpan = titleEl.querySelector('[data-i18n]');
                if (titleSpan) {
                    var titleKey = (saleId > 0) ? 'cdm_modal_title_invoice' : (normType === 'customer' ? 'cdm_modal_title' : 'cdm_modal_title_user');
                    titleSpan.setAttribute('data-i18n', titleKey);
                    if (typeof t === 'function') {
                        var tv = t(titleKey);
                        titleSpan.textContent = (tv && tv !== titleKey) ? tv : (saleId > 0 ? 'پارەدانی فاتورە' : (normType === 'customer' ? 'وەرگرتنا پارەی' : 'وەرگرتنا پارەی (کارمەند)'));
                    }
                }
            }
            var lblEl = document.querySelector('#cdm-entity-box [data-i18n="cdm_entity_label"]');
            if (lblEl && typeof t === 'function') {
                lblEl.setAttribute('data-i18n', normType === 'customer' ? 'cdm_entity_label' : 'cdm_entity_label_user');
                lblEl.textContent = t(normType === 'customer' ? 'cdm_entity_label' : 'cdm_entity_label_user');
            }
            var nameEl = document.getElementById('cdm-entity-name');
            var metaEl = document.getElementById('cdm-entity-meta');
            var debtEl = document.getElementById('cdm-current-debt');
            var idEl = document.getElementById('cdm-target-id');
            var typeEl = document.getElementById('cdm-target-type');
            var amtEl = document.getElementById('cdm-amount');
            var receiptEl = document.getElementById('cdm-receipt');
            var printEl = document.getElementById('cdm-print-chk');
            if (nameEl) {
                nameEl.textContent = entity.name || entity.username || ('#' + id);
                if (saleId > 0) nameEl.textContent += ' — #' + saleId;
            }
            if (metaEl) {
                var metaParts = [];
                if (entity.phone) metaParts.push('<i class="fas fa-phone"></i> ' + escapeHtml(String(entity.phone)));
                if (entity.address) metaParts.push('<i class="fas fa-map-marker-alt"></i> ' + escapeHtml(String(entity.address)));
                if (saleId > 0) {
                    var invLbl = (typeof t === 'function' && t('cdm_invoice_remaining') !== 'cdm_invoice_remaining')
                        ? t('cdm_invoice_remaining') : 'قەرزی فاتورە';
                    metaParts.push('<i class="fas fa-file-invoice"></i> ' + escapeHtml(invLbl) + ': ' + formatCurrency(previousDebtBeforePayment, collectDebtFormatOpts()));
                }
                metaEl.innerHTML = metaParts.join(' · ');
            }
            if (debtEl) debtEl.textContent = formatCurrency(previousDebtBeforePayment, collectDebtFormatOpts());
            if (idEl) idEl.value = String(id);
            if (typeEl) typeEl.value = normType;
            if (amtEl) {
                amtEl.value = String(balanceDisplay);
                setTimeout(function () { amtEl.focus(); amtEl.select(); }, 80);
            }
            if (receiptEl) receiptEl.value = saleId > 0 ? String(saleId) : '';
            if (printEl) printEl.checked = true;
            setCollectDebtPayMethod('cash');
            updateCollectDebtPreview();
            m.style.display = 'flex';
        }
        window.openCollectDebtModal = openCollectDebtModal;

        window.payCustomerInvoiceDebt = function(saleId, invoiceRemaining) {
            var custId = currentViewingCustomerId;
            if (!custId) return;
            saleId = parseInt(saleId, 10) || 0;
            invoiceRemaining = parseFloat(invoiceRemaining) || 0;
            if (saleId <= 0 || invoiceRemaining <= 0) {
                if (typeof showToast === 'function') showToast((typeof t === 'function' && t('cdm_invoice_no_debt') !== 'cdm_invoice_no_debt') ? t('cdm_invoice_no_debt') : 'ئەڤ فاتورە چ قەرزێ مایی نینە', 'warning');
                return;
            }
            if (!checkPermission('debt_manage', 'دانەڤا قەرزی')) return;
            openCollectDebtModal(custId, 'customer', { saleId: saleId, invoiceRemaining: invoiceRemaining });
        };

        function confirmCollectDebtPayment() {
            if (!_collectDebtCtx) return;
            var id = _collectDebtCtx.id;
            var type = _collectDebtCtx.type;
            var entity = _collectDebtCtx.entity;
            var previousDebtBeforePayment = _collectDebtCtx.previousDebtBeforePayment;
            var amtEl = document.getElementById('cdm-amount');
            var receiptEl = document.getElementById('cdm-receipt');
            var printEl = document.getElementById('cdm-print-chk');
            var btn = document.getElementById('cdm-confirm-btn');
            var amountStr = amtEl ? amtEl.value : '';
            var valDisplay = (typeof parseAmountInput === 'function')
                ? parseAmountInput(String(amountStr))
                : parseFloat(String(amountStr).replace(/,/g, ''));
            if (valDisplay === 0) valDisplay = _collectDebtCtx.balanceDisplay;
            var val = collectDebtParseDisplayToIqd(valDisplay);
            if (val === 0) val = previousDebtBeforePayment;
            if (isNaN(val) || val <= 0) {
                if (typeof showToast === 'function') showToast('ژمارە خەلەتە!', 'error');
                return;
            }
            if (val > previousDebtBeforePayment + 100) {
                if (typeof showToast === 'function') showToast('⚠️ بڕەکە ژ پارێ لای وی مەزنترە!', 'error');
                return;
            }
            var receiptId = (receiptEl && receiptEl.value) ? String(receiptEl.value).trim() : '';
            var wantPrint = printEl ? !!printEl.checked : false;
            if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>'; }
            var formData = new FormData();
            formData.append('action', 'pay_debt');
            formData.append('id', id);
            formData.append('type', type);
            formData.append('amount', val);
            formData.append('note', receiptId
                ? ('وەرگرتنا پارەی - ئیسڵەق #' + receiptId)
                : (_collectDebtCtx.saleId ? ('وەرگرتنا پارەی - فاتورە #' + _collectDebtCtx.saleId) : 'وەرگرتنا پارەی'));
            formData.append('receipt_id', receiptId);
            if (_collectDebtCtx.saleId) formData.append('sale_id', String(_collectDebtCtx.saleId));
            var payChannel = getCollectDebtPayMethod();
            formData.append('payment_method', payChannel);
            formData.append('user', (typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : 'System');
            var paidSaleId = _collectDebtCtx.saleId || 0;
            fetch('?action=pay_debt', { method: 'POST', body: formData })
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    if (btn) {
                        btn.disabled = false;
                        btn.innerHTML = '<i class="fas fa-check pos-ic"></i> <span data-i18n="cdm_confirm_pay">تۆمارکرنا پارەی</span>';
                        if (typeof applyI18nSubtree === 'function') applyI18nSubtree(btn.parentElement);
                    }
                        if (data.status === 'success') {
                        var paidAmt = parseFloat(data.amount != null ? data.amount : val) || 0;
                        var paidChannel = String(data.payment_method || payChannel || 'cash').toLowerCase() === 'fib' ? 'fib' : 'cash';
                        var ledgerTypeIn = String(data.ledger_type || (paidChannel === 'fib' ? 'debt_payment_in_fib' : 'debt_payment_in'));
                        entity.balance = (typeof roundMoney === 'function' ? roundMoney : function (x) { return Math.round(Number(x)); })((parseFloat(entity.balance) || 0) - paidAmt);
                        if (paidSaleId > 0 && Array.isArray(db.sales)) {
                            var saleRow = db.sales.find(function(s) { return s && String(s.id) === String(paidSaleId); });
                            if (saleRow) {
                                var remBefore = getCustomerSaleOwedDebt(saleRow);
                                saleRow.remaining_debt = Math.max(0, remBefore - paidAmt);
                                if (saleRow.remaining_debt <= 0.0001) saleRow.payment_due_at = null;
                            }
                        } else if (!paidSaleId && Array.isArray(db.sales) && type === 'customer') {
                            var leftPay = paidAmt;
                            (db.sales || []).filter(function(s) {
                                return s && String(s.customer_id) === String(id) && getCustomerSaleOwedDebt(s) > 0;
                            }).sort(function(a, b) {
                                return (new Date(a.date || a.created_at || 0)).getTime() - (new Date(b.date || b.created_at || 0)).getTime();
                            }).forEach(function(s) {
                                if (leftPay <= 0) return;
                                var owed = getCustomerSaleOwedDebt(s);
                                var take = Math.min(leftPay, owed);
                                s.remaining_debt = Math.max(0, owed - take);
                                if (s.remaining_debt <= 0.0001) s.payment_due_at = null;
                                leftPay -= take;
                            });
                        }
                        if (!db.customer_ledger) db.customer_ledger = [];
                        var payDateIso = new Date().toISOString();
                        try {
                            if (typeof getPosTimezoneParts === 'function') {
                                var _p = getPosTimezoneParts(new Date());
                                if (_p && _p.year) {
                                    payDateIso = String(_p.year) + '-' +
                                        String(_p.month).padStart(2, '0') + '-' +
                                        String(_p.day).padStart(2, '0') + ' ' +
                                        String(_p.hour).padStart(2, '0') + ':' +
                                        String(_p.minute).padStart(2, '0') + ':' +
                                        String(_p.second != null ? _p.second : '00').padStart(2, '0');
                                }
                            } else if (typeof getBusinessDate === 'function') {
                                payDateIso = getBusinessDate(new Date()) + ' ' + new Date().toTimeString().slice(0, 8);
                            }
                        } catch (_eDate) {}
                        var ledgerNotePay = data.ledger_note || (receiptId ? ('وەرگرتنا پارەی - ئیسڵەق #' + receiptId) : 'وەرگرتنا پارەی');
                        db.customer_ledger.push({
                            id: data.id || (Date.now() + Math.floor(Math.random() * 1000)),
                            target_id: id,
                            target_type: type,
                            type: 'payment',
                            amount: paidAmt,
                            date: payDateIso,
                            note: ledgerNotePay,
                            receipt_id: receiptId || (paidSaleId ? String(paidSaleId) : ''),
                            payment_method: paidChannel,
                            user: (typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : ''
                        });
                        if (!db.ledger) db.ledger = [];
                        db.ledger.push({
                            id: Date.now() + Math.floor(Math.random() * 1000),
                            transaction_id: 'TXP-LOC-' + Date.now(),
                            type: ledgerTypeIn,
                            amount: paidAmt,
                            date: payDateIso,
                            note: ledgerNotePay
                        });
                        if (paidChannel === 'cash') {
                            if (db.treasury !== undefined) {
                                var roundM = (typeof roundMoney === 'function') ? roundMoney : function (x) { return Math.round(Number(x)); };
                                db.treasury = roundM((parseFloat(db.treasury) || 0) + paidAmt);
                            }
                            if (db.today_stats) {
                                db.today_stats.debt_payments_in = (parseFloat(db.today_stats.debt_payments_in) || 0) + paidAmt;
                                db.today_stats.cash_movement = (parseFloat(db.today_stats.cash_movement) || 0) + paidAmt;
                            }
                        } else if (db.today_stats) {
                            db.today_stats.debt_payments_in_fib = (parseFloat(db.today_stats.debt_payments_in_fib) || 0) + paidAmt;
                        }
                        if (typeof posInvalidateDailyDetailCache === 'function') {
                            try { posInvalidateDailyDetailCache(typeof getBusinessDate === 'function' ? getBusinessDate(new Date()) : null); } catch (_eInv) {}
                        }
                        if (typeof posRefreshOpenFinancialScreens === 'function') {
                            try { posRefreshOpenFinancialScreens(); } catch (_eRef) {}
                        }
                        if (typeof updateStats === 'function') {
                            try { updateStats(); } catch (_eUs) {}
                        }
                        closeCollectDebtModal();
                        renderDebtView(type === 'user' ? 'users' : 'customers');
                        if (typeof renderCurrentDebtLedger === 'function') renderCurrentDebtLedger();
                        if (typeof window.posNotifyMobileDebtSync === 'function') window.posNotifyMobileDebtSync('pay_debt');
                        if (typeof showToast === 'function') {
                            showToast(paidChannel === 'fib'
                                ? ((typeof t === 'function' && t('cdm_paid_fib_toast') !== 'cdm_paid_fib_toast') ? t('cdm_paid_fib_toast') : '✅ پارە هاتە وەرگرتن — چووە هەژمارا FIB')
                                : ((typeof t === 'function' && t('cdm_paid_cash_toast') !== 'cdm_paid_cash_toast') ? t('cdm_paid_cash_toast') : '✅ پارە هاتە وەرگرتن — چووە قاسێ (نقد)'));
                        }
                        if (typeof logSecurityEvent === 'function') logSecurityEvent('debt_payment', 'Debt Payment: ' + paidAmt + ' for ID ' + id + ' by ' + (currentUser && currentUser.name));
                        try {
                            if (typeof posFlashScheduleSync === 'function') posFlashScheduleSync('debt');
                        } catch (_eFlashDebt) {}
                        var cashPaid = paidAmt;
                        var paymentReceiptData = {
                            id: data.id || ('PMT-' + Date.now()),
                            date: new Date(),
                            targetName: entity.name || entity.username || ('ID #' + id),
                            targetType: type,
                            grandTotal: cashPaid,
                            cashPaid: paidChannel === 'cash' ? cashPaid : 0,
                            fibPaid: paidChannel === 'fib' ? cashPaid : 0,
                            payChannel: paidChannel,
                            debtAdded: -cashPaid,
                            previousDebt: previousDebtBeforePayment,
                            totalOutstandingDebt: parseFloat(entity.balance) || 0,
                            receiptRef: receiptId || ''
                        };
                        if (wantPrint) printDebtPaymentReceipt(paymentReceiptData);
                        if (document.getElementById('customer-profile-modal') && document.getElementById('customer-profile-modal').style.display === 'flex') {
                            if (typeof renderCustomerLedgerHistory === 'function') renderCustomerLedgerHistory();
                            if (typeof renderCustomerInstallments === 'function') {
                                connectToDB(true).then(function () {
                                    renderCustomerInstallments();
                                    if (typeof checkInstallmentDueReminders === 'function') checkInstallmentDueReminders();
                                });
                            } else {
                                connectToDB(true);
                            }
                        } else {
                            connectToDB(true);
                        }
                    } else if (typeof showToast === 'function') {
                        showToast('❌ هەڵە: ' + data.message, 'error');
                    }
                })
                .catch(function () {
                    if (btn) {
                        btn.disabled = false;
                        btn.innerHTML = '<i class="fas fa-check pos-ic"></i> <span data-i18n="cdm_confirm_pay">تۆمارکرنا پارەی</span>';
                    }
                    if (typeof showToast === 'function') showToast('هەڵە ل پەیوەندیدا', 'error');
                });
        }
        window.confirmCollectDebtPayment = confirmCollectDebtPayment;

        function printDebtPaymentReceipt(d) {
            if (!d) return;
            const logoHtml = (typeof getThermalLogoHtml === 'function')
                ? getThermalLogoHtml('pos_sale')
                : ((typeof getReceiptLogoHtml === 'function') ? getReceiptLogoHtml({ mode: 'thermal' }) : '');
            const opts = getPrintConfig('pos_sale') || { paper: '80mm', design: '1' };
            const thermalFontClasses = typeof getThermalFontClasses === 'function' ? getThermalFontClasses() : '';
            const dateStr = new Date(d.date || new Date()).toLocaleString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ');
            const html = `
            <div class="print-thermal-container design-${opts.design || '1'}${thermalFontClasses}" style="max-width:${opts.paper || '80mm'}; width:100%;">
                ${logoHtml}
                <div class="thermal-header">
                    <h1>${escapeHtml((db.settings && db.settings.cafeName) ? db.settings.cafeName : 'Store')}</h1>
                    <p>${escapeHtml((db.settings && db.settings.cafeInfo) ? db.settings.cafeInfo : '')}</p>
                </div>
                <div class="thermal-divider"></div>
                <h3 style="margin:5px 0; background:#ecfeff; border:1px solid #06b6d4; color:#0c4a6e; padding:5px; border-radius:4px; text-align:center;">
                    <i class="fas fa-hand-holding-usd"></i> وەرگرتنا پارەی (Payment Receipt)
                </h3>
                <div class="thermal-info"><span>Date:</span><span>${dateStr}</span></div>
                <div class="thermal-info"><span>Receipt:</span><span>#${escapeHtml(String(d.id || '---'))}</span></div>
                <div class="thermal-info"><span>Target:</span><span>${escapeHtml(d.targetName || '---')}</span></div>
                <div class="thermal-info"><span>Type:</span><span>${escapeHtml(d.targetType || 'customer')}</span></div>
                ${d.receiptRef ? `<div class="thermal-info"><span>Ref:</span><span>${escapeHtml(String(d.receiptRef))}</span></div>` : ''}
                <div class="thermal-divider"></div>
                <div style="background:#f8fafc; border:1px dashed #cbd5e1; border-radius:10px; padding:10px;">
                    <div style="display:flex; justify-content:space-between; gap:10px; font-size:0.9rem; color:#64748b;"><span>Grand Total:</span><b style="color:#0f172a;">${formatCurrency(d.grandTotal || 0)}</b></div>
                    <div style="display:flex; justify-content:space-between; gap:10px; font-size:0.9rem; color:#64748b; margin-top:6px;"><span>${d.payChannel === 'fib' ? 'FIB' : 'نقد / Cash'}:</span><b style="color:${d.payChannel === 'fib' ? '#2563eb' : '#059669'};">${formatCurrency((d.payChannel === 'fib' ? d.fibPaid : d.cashPaid) || d.grandTotal || 0)}</b></div>
                    <div style="display:flex; justify-content:space-between; gap:10px; font-size:0.9rem; color:#64748b; margin-top:6px;"><span>Debt Added (Credit):</span><b style="color:#dc2626;">${formatCurrency(d.debtAdded || 0)}</b></div>
                    <div style="display:flex; justify-content:space-between; gap:10px; font-size:0.9rem; color:#64748b; margin-top:6px;"><span>Previous Debt:</span><b style="color:#0f172a;">${formatCurrency(d.previousDebt || 0)}</b></div>
                    <div style="display:flex; justify-content:space-between; gap:10px; font-size:0.95rem; color:#64748b; margin-top:6px; border-top:1px solid #e2e8f0; padding-top:8px;"><span>Total Outstanding Debt:</span><b style="color:#0f172a;">${formatCurrency(d.totalOutstandingDebt || 0)}</b></div>
                </div>
                <div class="thermal-footer">
                    <p>${escapeHtml((db.settings && db.settings.footer) ? db.settings.footer : 'Thank you')}</p>
                    ${typeof buildPosReceiptBrandFooterHtml === 'function' ? buildPosReceiptBrandFooterHtml() : ''}
                </div>
            </div>`;
            routePrint('pos_sale', html, { docId: String(d.id || ''), details: 'debt-payment-receipt' });
        }
        window.printDebtPaymentReceipt = printDebtPaymentReceipt;

        /** Reprint payment receipt from customer ledger row (وەرگرتنا پارەی). */
        function reprintCustomerPaymentFromLedger(ledgerId) {
            var lid = ledgerId;
            var entries = (window.currentCustomerLedgerAllEntries && window.currentCustomerLedgerAllEntries.length)
                ? window.currentCustomerLedgerAllEntries
                : ((db && db.customer_ledger) ? db.customer_ledger : []);
            var row = null;
            for (var i = 0; i < entries.length; i++) {
                if (entries[i] && String(entries[i].id) === String(lid)) {
                    row = entries[i];
                    break;
                }
            }
            if (!row) {
                if (typeof showToast === 'function') showToast('وەسڵێ پارەی نەهاتە دیتن', 'warning');
                return;
            }
            var custId = currentViewingCustomerId || (row.target_id);
            var cust = (db && db.customers || []).find(function (c) { return c && String(c.id) === String(custId); });
            var cashPaid = Math.abs(parseFloat(row.amount) || 0);
            var afterBal = (row._running_balance != null) ? (parseFloat(row._running_balance) || 0) : (cust ? (parseFloat(cust.balance) || 0) : 0);
            var previousDebt = afterBal + cashPaid;
            if (typeof printDebtPaymentReceipt !== 'function') {
                if (typeof showToast === 'function') showToast('چاپکرنا وەسڵێ بەردەست نییە', 'error');
                return;
            }
            printDebtPaymentReceipt({
                id: row.id || ('PMT-' + Date.now()),
                date: row.date || new Date(),
                targetName: (cust && (cust.name || cust.username)) || ('ID #' + custId),
                targetType: row.target_type || 'customer',
                grandTotal: cashPaid,
                cashPaid: cashPaid,
                debtAdded: -cashPaid,
                previousDebt: previousDebt,
                totalOutstandingDebt: afterBal,
                receiptRef: row.receipt_id || ''
            });
        }
        window.reprintCustomerPaymentFromLedger = reprintCustomerPaymentFromLedger;

        // --- CUSTOMER PROFILE & DEBT ---
        let currentViewingCustomerId = 0;
        function openCustomerProfile(id) {
            if (!db || !db.customers) {
                if (typeof showToast === 'function') showToast('❌ داتا نەهاتە بارکردن', 'error');
                return;
            }
            var cust = db.customers.find(function(c) { return c && String(c.id) === String(id); });
            if (!cust) {
                if (typeof showToast === 'function') showToast('❌ کریار نەهاتە دیتن', 'error');
                return;
            }
            var modalEl = document.getElementById('customer-profile-modal');
            if (!modalEl) {
                if (typeof showToast === 'function') showToast('❌ پڕۆفایلا کریاری نەهاتە دیتن', 'error');
                return;
            }

            currentViewingCustomerId = cust.id;
            window.currentViewingCustomerId = cust.id;

            modalEl.style.display = 'flex';
            modalEl.style.zIndex = '2100';

            var custId = cust.id;
            try {
                var nameEl = document.getElementById('cust-p-name');
                var idEl = document.getElementById('cust-p-id');
                var phoneEl = document.getElementById('cust-p-phone');
                var addrEl = document.getElementById('cust-p-address');
                var balEl = document.getElementById('cust-p-balance');
                if (nameEl) nameEl.innerText = cust.name || '';
                if (idEl) idEl.textContent = cust.id != null ? ('#' + String(cust.id)) : '';
                if (phoneEl) phoneEl.innerText = cust.phone || '';
                if (addrEl) addrEl.innerText = cust.address ? (' | ' + cust.address) : '';
                if (typeof fillElWithCurrencyAndDuhokPaper === 'function') {
                    var custBalFx = (typeof fxUsdRateFormatOptsForEntityBalance === 'function')
                        ? fxUsdRateFormatOptsForEntityBalance(cust.id, 'customer', cust.balance)
                        : undefined;
                    fillElWithCurrencyAndDuhokPaper(balEl, cust.balance || 0, custBalFx);
                } else if (balEl) balEl.innerText = formatCurrency(cust.balance || 0, (typeof fxUsdRateFormatOptsForEntityBalance === 'function') ? fxUsdRateFormatOptsForEntityBalance(cust.id, 'customer', cust.balance) : undefined) + ' ' + getCurrencySymbol();
            } catch (hdrErr) {
                console.error('openCustomerProfile header', hdrErr);
            }

            var debtBtn = document.getElementById('btn-customer-debt-action');
            if (debtBtn) {
                var bal = parseFloat(cust.balance) || 0;
                var tfCust = (typeof t === 'function');
                if (bal > 0) {
                    debtBtn.innerHTML = '<i class="fas fa-money-bill-wave"></i> ' + escapeHtml(tfCust ? t('cust_collect_payment') : 'وەرگرتنا پارەی');
                    debtBtn.className = 'btn btn-success';
                    debtBtn.onclick = function() { payDebtAmount(custId, 'customer'); };
                } else if (bal < 0) {
                    debtBtn.innerHTML = '<i class="fas fa-hand-holding-usd"></i> ' + escapeHtml(tfCust ? t('cust_pay_customer_credit') : 'دانەڤا پارەی بۆ کریاری');
                    debtBtn.className = 'btn btn-warning';
                    debtBtn.onclick = function() { payDebtAmount(custId, 'customer'); };
                } else {
                    debtBtn.innerHTML = '<i class="fas fa-check-circle"></i> ' + escapeHtml(tfCust ? t('cust_no_debt') : 'چ قەرز نینن');
                    debtBtn.className = 'btn btn-success';
                    debtBtn.onclick = null;
                }
            }

            try { switchCustomerTab('cust-history'); } catch (tabErr) { console.error('openCustomerProfile tab', tabErr); }
            try { renderCustomerHistory(); } catch (histErr) { console.error('openCustomerProfile history', histErr); }
            try { renderCustomerLedgerHistory(); } catch (ledErr) { console.error('openCustomerProfile ledger', ledErr); }
            try { renderCustomerInstallments(); } catch (instErr) { console.error('openCustomerProfile installments', instErr); }
            try { checkInstallmentDueReminders(); } catch (notifErr) { console.error('openCustomerProfile installment notif', notifErr); }

            if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modalEl);
        }

        function closeCustomerProfile() {
            document.getElementById('customer-profile-modal').style.display = 'none';
            currentViewingCustomerId = 0;
            window.currentViewingCustomerId = 0;
        }

        window.openCustomerProfile = openCustomerProfile;
        window.closeCustomerProfile = closeCustomerProfile;
        window.showDebtLedger = showDebtLedger;
        window.switchCustomerTab = switchCustomerTab;
        window.renderCustomerHistory = renderCustomerHistory;
        window.renderCustomerLedgerHistory = renderCustomerLedgerHistory;
        window.renderCustomerInstallments = renderCustomerInstallments;
        window.createCustomerInstallmentPlan = createCustomerInstallmentPlan;
        window.cancelCustomerInstallmentPlan = cancelCustomerInstallmentPlan;
        window.checkInstallmentDueReminders = checkInstallmentDueReminders;
        window.updateInstallmentPreview = updateInstallmentPreview;

        function printCustomerInstallmentReport(planId) {
            var custId = currentViewingCustomerId;
            if (!custId || !db) return;
            if (!canUseCustomerInstallments()) {
                if (typeof openInstallmentsPremiumUpsell === 'function') openInstallmentsPremiumUpsell();
                return;
            }
            var cust = (db.customers || []).find(function(c) { return c && String(c.id) === String(custId); });
            var plan = null;
            if (planId) {
                plan = (db.installment_plans || []).find(function(p) { return p && String(p.id) === String(planId); }) || null;
            } else {
                plan = typeof getCustomerActiveInstallmentPlan === 'function' ? getCustomerActiveInstallmentPlan(custId) : null;
            }
            if (!cust || !plan) {
                if (typeof showToast === 'function') showToast(typeof t === 'function' ? t('cust_installment_report_none') : 'چ پلانا قستێ نینە', 'warning');
                return;
            }
            var items = typeof getInstallmentItemsForPlan === 'function' ? getInstallmentItemsForPlan(plan.id) : [];
            if (!items.length) return;

            var today = new Date().toISOString().slice(0, 10);
            var tf = (typeof t === 'function');
            var totalPaid = items.reduce(function(s, it) { return s + (parseFloat(it.paid_amount) || 0); }, 0);
            var totalRemaining = items.reduce(function(s, it) {
                return s + Math.max(0, (parseFloat(it.amount) || 0) - (parseFloat(it.paid_amount) || 0));
            }, 0);
            var paidCount = 0;
            items.forEach(function(it) {
                var rem = Math.max(0, (parseFloat(it.amount) || 0) - (parseFloat(it.paid_amount) || 0));
                if (String(it.status) === 'paid' || rem <= 0.0001) paidCount++;
            });
            var remainingCount = items.length - paidCount;
            var progressPct = (parseFloat(plan.total_amount) || 0) > 0
                ? Math.min(100, Math.round((totalPaid / parseFloat(plan.total_amount)) * 100))
                : 0;

            var logoHtml = (typeof getReceiptLogoHtml === 'function')
                ? getReceiptLogoHtml({ mode: 'a4' })
                : ((typeof getPosShopLogoUrl === 'function' && getPosShopLogoUrl()) ? '<img src="' + getPosShopLogoUrl() + '" style="max-height:80px;max-width:150px;" alt="">' : '');
            var rowsHtml = items.map(function(it) {
                var st = String(it.status || 'pending');
                if ((st === 'pending' || st === 'partial') && String(it.due_date || '') < today) st = 'overdue';
                var itemRem = Math.max(0, (parseFloat(it.amount) || 0) - (parseFloat(it.paid_amount) || 0));
                var stLabel = typeof installmentStatusLabel === 'function' ? installmentStatusLabel(st) : st;
                return '<tr>' +
                    '<td>' + escapeHtml(String(it.installment_no || '')) + '</td>' +
                    '<td>' + escapeHtml(String(it.due_date || '')) + '</td>' +
                    '<td style="text-align:right;font-weight:bold;" dir="ltr">' + formatInstallmentIqd(it.amount || 0) + '</td>' +
                    '<td style="text-align:right;color:#059669;" dir="ltr">' + formatInstallmentIqd(it.paid_amount || 0) + '</td>' +
                    '<td style="text-align:right;color:#dc2626;font-weight:bold;" dir="ltr">' + formatInstallmentIqd(itemRem) + '</td>' +
                    '<td>' + escapeHtml(stLabel) + '</td>' +
                '</tr>';
            }).join('');

            var html = '<div class="print-a4-container" dir="rtl">' +
                '<div class="print-header">' +
                    '<div style="text-align:right"><h1 style="color:#000;margin:0;font-size:24px;">' + escapeHtml((db.settings && db.settings.cafeName) || 'POS') + '</h1>' +
                    '<p style="color:#444;margin:5px 0;font-size:14px;">' + escapeHtml((db.settings && db.settings.cafeInfo) || '') + '</p></div>' +
                    '<div style="text-align:center;">' + logoHtml + '</div>' +
                    '<div style="text-align:left" dir="rtl">' +
                        '<h2 style="color:#000;margin:0;font-size:20px;">' + escapeHtml(tf ? t('cust_installment_report_print_title') : 'ڕاپۆrta قستێ') + '</h2>' +
                        '<p style="color:#444;margin:5px 0;">' + escapeHtml(tf ? t('cust_installment_report_customer') : 'کریار') + ': ' + escapeHtml(cust.name || '') + '</p>' +
                        '<p style="color:#444;margin:5px 0;">' + escapeHtml(tf ? t('cust_installment_report_date') : 'بەروار') + ': ' + new Date().toLocaleString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ') + '</p>' +
                    '</div>' +
                '</div>' +
                '<div class="print-summary-box" style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:20px 0;">' +
                    '<div class="p-box" style="border-color:#3b82f6;padding:12px;border:2px solid #3b82f6;border-radius:8px;text-align:center;">' +
                        '<h3 style="margin:0 0 6px;font-size:14px;">' + escapeHtml(tf ? t('cust_installment_total_label') : 'کۆی قست') + '</h3>' +
                        '<h2 style="margin:0;color:#1e40af;" dir="ltr">' + formatInstallmentIqd(plan.total_amount || 0) + '</h2></div>' +
                    '<div class="p-box" style="border-color:#10b981;padding:12px;border:2px solid #10b981;border-radius:8px;text-align:center;">' +
                        '<h3 style="margin:0 0 6px;font-size:14px;">' + escapeHtml(tf ? t('cust_installment_report_paid_count') : 'قستا پاردراو') + '</h3>' +
                        '<h2 style="margin:0;color:#059669;" dir="ltr">' + paidCount + ' / ' + items.length + '</h2>' +
                        '<p style="margin:4px 0 0;font-size:13px;" dir="ltr">' + formatInstallmentIqd(totalPaid) + '</p></div>' +
                    '<div class="p-box" style="border-color:#ef4444;padding:12px;border:2px solid #ef4444;border-radius:8px;text-align:center;">' +
                        '<h3 style="margin:0 0 6px;font-size:14px;">' + escapeHtml(tf ? t('cust_installment_report_remaining_count') : 'قستا مای') + '</h3>' +
                        '<h2 style="margin:0;color:#dc2626;" dir="ltr">' + remainingCount + ' / ' + items.length + '</h2>' +
                        '<p style="margin:4px 0 0;font-size:13px;" dir="ltr">' + formatInstallmentIqd(totalRemaining) + '</p></div>' +
                '</div>' +
                '<p style="text-align:center;font-size:15px;margin:10px 0;"><b>' + escapeHtml(tf ? t('cust_installment_report_progress') : 'پێشکەوتن') + ':</b> ' + progressPct + '%</p>' +
                '<div class="section-title">' + escapeHtml(tf ? t('cust_installment_report_details') : 'وردەکاریێن قستان') + '</div>' +
                '<table class="print-table" dir="rtl"><thead><tr>' +
                    '<th>#</th><th>' + escapeHtml(tf ? t('cust_installment_col_date') : 'بەروار') + '</th>' +
                    '<th>' + escapeHtml(tf ? t('cust_installment_col_amount') : 'بڕ') + '</th>' +
                    '<th>' + escapeHtml(tf ? t('cust_installment_col_paid') : 'پاردراو') + '</th>' +
                    '<th>' + escapeHtml(tf ? t('cust_installment_col_remaining') : 'ماوە') + '</th>' +
                    '<th>' + escapeHtml(tf ? t('cust_installment_col_status') : 'دۆخ') + '</th>' +
                '</tr></thead><tbody>' + rowsHtml + '</tbody></table>' +
                '<div style="margin-top:20px;padding:12px;border:2px dashed #cbd5e1;border-radius:8px;text-align:center;">' +
                    '<b>' + escapeHtml(tf ? t('cust_balance_current_label') : 'ڕەسیدێ نوکە') + ':</b> ' +
                    '<span dir="ltr" style="color:#dc2626;font-size:18px;">' + formatCurrency(cust.balance || 0, (typeof fxUsdRateFormatOptsForEntityBalance === 'function') ? fxUsdRateFormatOptsForEntityBalance(cust.id, 'customer', cust.balance) : undefined) + ' ' + getCurrencySymbol() + '</span>' +
                '</div></div>';

            if (typeof routePrint === 'function') {
                routePrint('pos_sale', html, { docId: 'inst-' + plan.id, details: 'installment-report' });
            } else if (typeof printContent === 'function') {
                printContent(html);
            }
        }
        window.printCustomerInstallmentReport = printCustomerInstallmentReport;

        function switchCustomerTab(tabName) {
            const modal = document.getElementById('customer-profile-modal');
            if (!modal) return;
            modal.querySelectorAll('.tab-content').forEach(function(c) { c.classList.remove('active'); });
            modal.querySelectorAll('.tab-btn').forEach(function(b) { b.classList.remove('active'); });
            
            const tabEl = document.getElementById('tab-' + tabName);
            const btnEl = document.getElementById('tab-btn-' + tabName);
            if (tabEl) tabEl.classList.add('active');
            if (btnEl) btnEl.classList.add('active');
            if (tabName === 'cust-installments' && typeof renderCustomerInstallments === 'function') {
                renderCustomerInstallments();
            }
        }

        function formatLedgerSummaryTemplate(key, balance, debt, paid, ret) {
            var tpl = (typeof t === 'function') ? String(t(key) || '') : '';
            if (!tpl || tpl === key) {
                if (key === 'cust_ledger_summary_tpl') {
                    return 'کەشفێ حیسابا کڕیاری: ڕەسیدێ نوکە (قەرزێ مای): ' + formatCurrency(balance) + ' | کۆیا فرۆتنێ (قەرز): ' + formatCurrency(debt) + ' | پارەیێ هاتیە دان: ' + formatCurrency(paid) + ' | زڤڕاندن: ' + formatCurrency(ret);
                }
                return 'کەشفێ حیسابا دابینکەری: ڕەسیدێ نوکە (قەرزێ مە): ' + formatCurrency(balance) + ' | کۆیا کڕینێ (قەرز): ' + formatCurrency(debt) + ' | پارەیێ هاتیە دان: ' + formatCurrency(paid) + ' | زڤڕاندن: ' + formatCurrency(ret);
            }
            return tpl.replace(/\{b\}/g, formatCurrency(balance)).replace(/\{d\}/g, formatCurrency(debt)).replace(/\{p\}/g, formatCurrency(paid)).replace(/\{r\}/g, formatCurrency(ret));
        }

        function renderCustomerLedgerHistory() {
            if (typeof ensureDateFilterToday === 'function') ensureDateFilterToday('cust-ledger');
            const custId = currentViewingCustomerId;
            if(!custId) return;
            const list = document.getElementById('cust-p-ledger-list');
            if (!list) return;
            
            const cust = (db.customers || []).find(function(c) { return c && String(c.id) === String(custId); });
            if (!cust) return;

            list.innerHTML = '<tr><td colspan="5" style="text-align:center; padding:20px; color:#999"><i class="fas fa-spinner fa-spin"></i> بارکرنا پێداچوونێ...</td></tr>';
            
            window.currentCustomerLedgerAllEntries = [];
            
            fetch('?action=get_customer_ledger&customer_id=' + encodeURIComponent(custId) + '&customer_type=customer', { credentials: 'same-origin' })
            .then(async res => {
                const text = await res.text();
                try {
                    return JSON.parse(text);
                } catch (err) {
                    console.error("Invalid JSON content:", text);
                    throw new Error("Invalid JSON END: " + text.substring(Math.max(0, text.length - 150)));
                }
            })
            .then(data => {
                if (data.status === 'success') {
                    const allEntries = data.entries || [];
                    
                    // Step 2: Calculate running balance working backwards from current balance
                    let currentBal = parseFloat(cust.balance) || 0;
                    var startCustFx = (typeof fxUsdRateFormatOptsForEntityBalance === 'function')
                        ? fxUsdRateFormatOptsForEntityBalance(cust.id, 'customer', currentBal)
                        : undefined;
                    var currentBalUsd = (typeof storedIqdToUsdDisplayAmount === 'function')
                        ? storedIqdToUsdDisplayAmount(currentBal, startCustFx)
                        : 0;
                    if (startCustFx && startCustFx.directUsd != null && Number.isFinite(Number(startCustFx.directUsd))) {
                        currentBalUsd = Number(startCustFx.directUsd);
                    }
                    var lockUsdPerIqd = (currentBal > 0.0001 && currentBalUsd) ? (currentBalUsd / currentBal) : 0;
                    allEntries.forEach(l => {
                        l._running_balance = currentBal;
                        l._running_balance_usd = currentBalUsd;
                        l._line_fx = (typeof fxUsdRateFormatOpts === 'function') ? fxUsdRateFormatOpts(l) : undefined;
                        let amt = Math.abs(parseFloat(l.amount) || 0);
                        let amtUsd = (typeof storedIqdToUsdDisplayAmount === 'function')
                            ? storedIqdToUsdDisplayAmount(amt, l._line_fx)
                            : amt;
                        // Unstamped payment lines: keep contractual USD via locked entity ratio (never live FX).
                        if (!(amtUsd > 0) && amt > 0 && lockUsdPerIqd > 0) {
                            amtUsd = Math.round(amt * lockUsdPerIqd * 100) / 100;
                        }
                        let effect = 0;
                        let effectUsd = 0;
                        if (l.type === 'sale') {
                            effect = amt;
                            effectUsd = amtUsd;
                        } else if (l.type === 'payment' || l.type === 'pay' || l.type === 'return') {
                            effect = -amt;
                            effectUsd = -amtUsd;
                        }
                        currentBal = currentBal - effect;
                        currentBalUsd = currentBalUsd - effectUsd;
                    });

                    // Step 3: Filter by date scope for display
                    const entries = allEntries.filter(l => isDateInScope(l.date, 'cust-ledger'));
                    
                    window.currentCustomerLedgerAllEntries = allEntries;
                    
                    const balance = cust ? (parseFloat(cust.balance) || 0) : 0;
                    const totalSales = entries.filter(l => l.type === 'sale').reduce((s, l) => s + Math.abs(parseFloat(l.amount) || 0), 0);
                    const totalPaid = entries.filter(l => l.type === 'payment' || l.type === 'pay').reduce((s, l) => s + Math.abs(parseFloat(l.amount) || 0), 0);
                    const totalReturn = entries.filter(l => l.type === 'return').reduce((s, l) => s + Math.abs(parseFloat(l.amount) || 0), 0);
                    var sumUsdCust = function (rows) {
                        return rows.reduce(function (s, l) {
                            var amt = Math.abs(parseFloat(l.amount) || 0);
                            var fx = l._line_fx || ((typeof fxUsdRateFormatOpts === 'function') ? fxUsdRateFormatOpts(l) : undefined);
                            var u = (typeof storedIqdToUsdDisplayAmount === 'function') ? storedIqdToUsdDisplayAmount(amt, fx) : 0;
                            return s + u;
                        }, 0);
                    };
                    var fmtBalC = formatCurrency(balance, startCustFx);
                    var isUsdLed = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
                    var fmtDebtC = isUsdLed
                        ? formatCurrency(0, { directUsd: sumUsdCust(entries.filter(function (l) { return l.type === 'sale'; })) })
                        : formatCurrency(totalSales);
                    var fmtPaidC = isUsdLed
                        ? formatCurrency(0, { directUsd: sumUsdCust(entries.filter(function (l) { return l.type === 'payment' || l.type === 'pay'; })) })
                        : formatCurrency(totalPaid);
                    var fmtRetC = isUsdLed
                        ? formatCurrency(0, { directUsd: sumUsdCust(entries.filter(function (l) { return l.type === 'return'; })) })
                        : formatCurrency(totalReturn);
                    var summaryInnerCust = 'کەشفێ حیسابا کڕیاری: ڕەسیدێ نوکە (قەرزێ مای): ' + fmtBalC + ' | کۆیا فرۆتنێ (قەرز): ' + fmtDebtC + ' | پارەیێ هاتیە دان: ' + fmtPaidC + ' | زڤڕاندن: ' + fmtRetC;
                    if (typeof t === 'function') {
                        var tplC = String(t('cust_ledger_summary_tpl') || '');
                        if (tplC && tplC !== 'cust_ledger_summary_tpl') {
                            summaryInnerCust = tplC.replace(/\{b\}/g, fmtBalC).replace(/\{d\}/g, fmtDebtC).replace(/\{p\}/g, fmtPaidC).replace(/\{r\}/g, fmtRetC);
                        }
                    }
                    const summaryRow = '<tr style="background:var(--input-bg); font-weight:bold;"><td colspan="6" style="padding:10px; border-radius:8px;">' + escapeHtml(summaryInnerCust) + '</td></tr>';
                    
                    var emptyLed = (typeof t === 'function') ? t('comp_ledger_no_entries') : 'چ لڤین نینن';
                    if(entries.length === 0) { list.innerHTML = summaryRow + '<tr><td colspan="6" style="text-align:center;color:#999">' + escapeHtml(emptyLed) + '</td></tr>'; return; }

                    function mapLedgerType(lOrType) {
                        var row = (lOrType && typeof lOrType === 'object') ? lOrType : { type: lOrType };
                        var type = row.type;
                        var tf = (typeof t === 'function');
                        if (type === 'sale') return { label: tf ? t('cust_led_sale_credit') : 'فرۆتن ب قەرز', color: '#dc2626', icon: 'fa-shopping-cart' };
                        if (type === 'sale_cash') return { label: tf ? t('cust_led_sale_cash') : 'فرۆتن ب کاش (نەقد)', color: '#2563eb', icon: 'fa-cash-register' };
                        if (type === 'return') return { label: tf ? t('cust_led_return_debt') : 'زڤڕاندن (قەرز)', color: '#f59e0b', icon: 'fa-undo' };
                        if (type === 'return_cash') return { label: tf ? t('cust_led_return_cash') : 'زڤڕاندن (کاش)', color: '#f59e0b', icon: 'fa-undo' };
                        if (type === 'payment' || type === 'pay') {
                            var ch = (typeof customerDebtPaymentChannel === 'function')
                                ? customerDebtPaymentChannel(row)
                                : (String(row.payment_method || '').toLowerCase() === 'fib' ? 'fib' : 'cash');
                            if (ch === 'fib') {
                                return { label: (tf && t('cust_led_payment_in_fib') !== 'cust_led_payment_in_fib') ? t('cust_led_payment_in_fib') : 'پارە هاتە وەرگرتن (FIB)', color: '#2563eb', icon: 'fa-university' };
                            }
                            return { label: (tf && t('cust_led_payment_in_cash') !== 'cust_led_payment_in_cash') ? t('cust_led_payment_in_cash') : (tf ? t('cust_led_payment_in') : 'پارە هاتە وەرگرتن (نقد)'), color: '#16a34a', icon: 'fa-money-bill-wave' };
                        }
                        return { label: type ? (tf ? t('cust_led_movement') + ': ' + type : String(type)) : (tf ? t('cust_led_movement') : 'لڤین'), color: 'var(--text-muted)', icon: 'fa-receipt' };
                    }

                    list.innerHTML = summaryRow + entries.map(l => {
                        const meta = mapLedgerType(l);
                        const typeHtml = '<span style="color:' + meta.color + '; font-weight:bold"><i class="fas ' + meta.icon + '"></i> ' + escapeHtml(meta.label) + '</span>';
                        var noteParts = [];
                        if (l.transaction_id) noteParts.push('<div><b>TX:</b> <code style="background:none;padding:0;">' + escapeHtml(String(l.transaction_id)) + '</code></div>');
                        if (l.receipt_id) noteParts.push('<div><b>وەسڵ:</b> #' + escapeHtml(String(l.receipt_id)) + '</div>');
                        if (l.note) noteParts.push('<div style="white-space:normal; margin-top:4px;"><b>تێبینی:</b> ' + escapeHtml(l.note) + '</div>');
                        
                        let amountColor = '#16a34a'; 
                        let amountPrefix = '';
                        if (l.type === 'sale') {
                            amountColor = '#dc2626'; // red (debt added)
                            amountPrefix = '+ ';
                        } else if (l.type === 'sale_cash' || l.type === 'return_cash') {
                            amountColor = '#2563eb'; // blue (cash transaction)
                            amountPrefix = '';
                        } else if (l.type === 'payment' || l.type === 'pay' || l.type === 'return') {
                            amountColor = '#16a34a'; // green (paid/returned)
                            amountPrefix = '- ';
                        } else {
                            amountColor = 'var(--text)';
                        }

                        let rowAction = '';
                        if ((l.type === 'sale' || l.type === 'sale_cash') && l.receipt_id) {
                            rowAction = `onclick="reprintBill(${l.receipt_id})" style="cursor:pointer; transition:0.2s;" onmouseover="this.style.background='var(--input-bg)'" onmouseout="this.style.background='transparent'" title="بینینا وەسڵێ"`;
                        } else if ((l.type === 'return' || l.type === 'return_cash') && l.receipt_id) {
                            rowAction = `onclick="if(typeof printReturnReceipt === 'function') printReturnReceipt(${l.receipt_id})" style="cursor:pointer; transition:0.2s;" onmouseover="this.style.background='var(--input-bg)'" onmouseout="this.style.background='transparent'" title="بینینا وەسڵا زڤڕاندنێ"`;
                        } else if (l.type === 'payment' || l.type === 'pay') {
                            rowAction = "onclick='reprintCustomerPaymentFromLedger(" + JSON.stringify(String(l.id)) + ")' style='cursor:pointer; transition:0.2s;' onmouseover=\"this.style.background='var(--input-bg)'\" onmouseout=\"this.style.background='transparent'\" title='بینینا وەسڵا وەرگرتنا پارەی'";
                        }

                        var actionBtns = '';
                        if (l.type === 'sale' || l.type === 'sale_cash') {
                            var saleRid = parseInt(l.sale_id || l.receipt_id, 10);
                            var invRem = (l.invoice_remaining != null) ? (parseFloat(l.invoice_remaining) || 0) : -1;
                            if (invRem < 0 && saleRid > 0 && Array.isArray(db.sales)) {
                                var sLook = db.sales.find(function(s) { return s && String(s.id) === String(saleRid); });
                                if (sLook) invRem = (typeof getCustomerSaleOwedDebt === 'function') ? getCustomerSaleOwedDebt(sLook) : (parseFloat(sLook.remaining_debt) || 0);
                            }
                            if (saleRid > 0) {
                                actionBtns = '<div style="display:flex; gap:6px; justify-content:center; flex-wrap:wrap;">';
                                if (l.type === 'sale' && invRem > 0.0001) {
                                    actionBtns += '<button type="button" class="btn btn-sm btn-success" onclick="payCustomerInvoiceDebt(' + saleRid + ',' + invRem + ')" title="' + escapeHtml((typeof t === 'function' && t('cdm_pay_invoice') !== 'cdm_pay_invoice') ? t('cdm_pay_invoice') : 'پارەدانی فاتورە') + '"><i class="fas fa-hand-holding-usd"></i></button>';
                                }
                                actionBtns += '<button type="button" class="btn btn-sm btn-primary" onclick="editCustomerSaleInLedger(' + saleRid + ')" title="تەعدیل (Edit)"><i class="fas fa-edit"></i></button>' +
                                    '<button type="button" class="btn btn-sm btn-danger" onclick="deleteCustomerSaleInLedger(' + saleRid + ')" title="ژێبرن (Delete)"><i class="fas fa-trash-alt"></i></button>' +
                                '</div>';
                            }
                        } else if (l.type === 'payment' || l.type === 'pay') {
                            actionBtns = '<div style="display:flex; gap:6px; justify-content:center;">' +
                                '<button type="button" class="btn btn-sm btn-primary" onclick="editCustomerPayment(' + l.id + ', ' + Math.abs(l.amount) + ')" title="تەعدیل (Edit)"><i class="fas fa-edit"></i></button>' +
                                '<button type="button" class="btn btn-sm btn-danger" onclick="deleteCustomerPayment(' + l.id + ')" title="ژێبرن (Delete)"><i class="fas fa-trash-alt"></i></button>' +
                            '</div>';
                        }

                        return `<tr ${rowAction}>
                            <td style="white-space:nowrap;">${new Date(l.date).toLocaleString(typeof getDateLocale === 'function' ? getDateLocale() : 'ar-IQ')}</td>
                            <td>${typeHtml}</td>
                            <td style="font-weight:900; color:${amountColor}; font-size:1.05rem;" dir="ltr">${amountPrefix}${formatCurrency(Math.abs(l.amount), l._line_fx)}</td>
                            <td style="font-weight:900; color:var(--brand); font-size:1.1rem; background:var(--input-bg); border-radius:6px; text-align:center;" dir="ltr">${(typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD' && l._running_balance_usd != null) ? formatCurrency(0, { directUsd: l._running_balance_usd }) : formatCurrency(l._running_balance)}</td>
                            <td style="font-size:0.85rem; line-height:1.6; max-width:250px;">${noteParts.join('')}${((l.type === 'payment' || l.type === 'pay') ? '<div style="margin-top:4px;color:var(--brand);font-size:0.78rem;"><i class="fas fa-print"></i> کلیک بۆ وەسڵ</div>' : '')}${((l.type === 'sale' || l.type === 'sale_cash') && l.receipt_id ? '<div style="margin-top:4px;color:var(--brand);font-size:0.78rem;"><i class="fas fa-receipt"></i> کلیک بۆ وەسڵ</div>' : '')}</td>
                            <td style="text-align:center;" onclick="event.stopPropagation()">${actionBtns}</td>
                        </tr>`;
                    }).join('');
                } else {
                    list.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:20px; color:#f00">هەڵە د بارکرنا پێداچوونێ دا: ' + (data.message || '') + '</td></tr>';
                }
            })
            .catch(e => {
                console.error(e);
                list.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:20px; color:#f00">هەڵە د پەیوەندیێ دا: ' + escapeHtml(e.message || String(e)) + '</td></tr>';
            });
        }

        window.deleteCustomerSaleInLedger = function(saleId) {
            saleId = parseInt(saleId, 10);
            if (!saleId) return;
            var msg = 'دڵنیای تە دڤێت ڤێ پسوولێ ڕەش بکەی؟\n(مەواد دێ زڤڕیتەوە مەخزەن و قەرز دێ هێتە ڕێکخستن)';
            var go = function() { _doDeleteCustomerSaleInLedger(saleId); };
            if (typeof posConfirmDangerous === 'function') {
                posConfirmDangerous({
                    title: 'سڕینەوەی پسوولەی فرۆشتن',
                    message: msg,
                    confirmText: 'بەڵێ، ڕەش بکە'
                }).then(function(confirmed) {
                    if (confirmed) go();
                });
            } else if (typeof posConfirm === 'function') {
                posConfirm({
                    title: 'سڕینەوەی پسوولەی فرۆشتن',
                    message: msg,
                    tone: 'danger',
                    confirmText: 'بەڵێ، ڕەش بکە',
                    requirePhrase: String(1000 + Math.floor(Math.random() * 9000)),
                    phraseNumeric: true,
                    confirmDelayMs: 1500
                }).then(function(confirmed) {
                    if (confirmed) go();
                });
            } else {
                if (!confirm(msg)) return;
                go();
            }
        };

        function _doDeleteCustomerSaleInLedger(saleId) {
            var formData = new FormData();
            formData.append('action', 'delete_sale');
            formData.append('id', String(saleId));
            formData.append('user', (typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : 'System');

            fetch('?action=delete_sale', { method: 'POST', body: formData })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (data.status !== 'success') {
                        if (typeof window.posAlert === 'function') window.posAlert({ message: data.message || 'هەڵە د سڕینەوەی پسوولێ دا', tone: 'danger' });
                        else if (typeof showToast === 'function') showToast('هەڵە: ' + (data.message || 'Error'), 'error');
                        else alert('هەڵە: ' + (data.message || 'Error'));
                        return;
                    }
                    var saleIdx = (db.sales || []).findIndex(function(s) { return String(s.id) === String(saleId); });
                    if (saleIdx > -1) db.sales[saleIdx].is_returned = 1;
                    if (typeof showToast === 'function') {
                        showToast('✅ پسوولە هاتە سڕینەوە', 'success', {
                            actionLabel: (typeof t === 'function') ? t('btn_undo_void') : 'پەشێمان بم',
                            durationMs: 12000,
                            onAction: function() {
                                if (typeof restoreVoidedSale === 'function') restoreVoidedSale(saleId);
                            }
                        });
                    }
                    setTimeout(function() { if (typeof syncLiveData === 'function') syncLiveData(false); }, 150);
                    setTimeout(function() {
                        if (typeof renderCustomerLedgerHistory === 'function') renderCustomerLedgerHistory();
                        if (typeof openCustomerProfile === 'function' && currentViewingCustomerId) openCustomerProfile(currentViewingCustomerId);
                    }, 500);
                })
                .catch(function(err) {
                    if (typeof window.posAlert === 'function') window.posAlert({ message: err.message || String(err), tone: 'danger' });
                    else if (typeof showToast === 'function') showToast('هەڵە: ' + (err.message || err), 'error');
                    else alert('هەڵە: ' + (err.message || err));
                });
        }

        window.editCustomerSaleInLedger = function(saleId) {
            saleId = parseInt(saleId, 10);
            if (!saleId) return;
            if (typeof startEditSaleInPos === 'function') {
                startEditSaleInPos(saleId);
            } else if (typeof reprintBill === 'function') {
                reprintBill(saleId);
            } else if (typeof window.posAlert === 'function') {
                window.posAlert({ message: 'تەعدیل لە سەبەتە بەردەست نییە', tone: 'warning' });
            }
        };

        window.deleteCustomerPayment = function(id) {
            var msg = 'دڵنیای دڤێت ڤی پارەی ڕەش بکەی؟\n(دێ ڕاستەوخۆ ژ قەرزی کڕیاری هێتە زێدەکرن و ژ خەزنەی هێتە کێمکرن)';
            var go = function() { _doDeleteCustomerPayment(id); };
            if (typeof posConfirmDangerous === 'function') {
                posConfirmDangerous({
                    title: 'سڕینەوەی پارەدان',
                    message: msg,
                    confirmText: 'بەڵێ، ڕەش بکە'
                }).then(function(confirmed) {
                    if (confirmed) go();
                });
            } else if (typeof posConfirm === 'function') {
                posConfirm({
                    title: 'سڕینەوەی پارەدان',
                    message: msg,
                    tone: 'danger',
                    confirmText: 'بەڵێ، ڕەش بکە',
                    requirePhrase: String(1000 + Math.floor(Math.random() * 9000)),
                    phraseNumeric: true,
                    confirmDelayMs: 1500
                }).then(function(confirmed) {
                    if (confirmed) go();
                });
            } else {
                if (!confirm(msg)) return;
                go();
            }
        };

        function _doDeleteCustomerPayment(id) {
            var formData = new FormData();
            formData.append('action', 'delete_customer_payment');
            formData.append('id', String(id));
            formData.append('user', (typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : 'System');
            
            fetch('?action=delete_customer_payment', { method: 'POST', body: formData })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (data.status !== 'success') {
                        if (typeof window.posAlert === 'function') window.posAlert({ message: data.message || 'Error', tone: 'danger' });
                        else if (typeof showToast === 'function') showToast('هەڵە: ' + (data.message || 'Error'), 'error');
                        else alert('هەڵە: ' + (data.message || 'Error'));
                        return;
                    }
                    if (typeof showToast === 'function') showToast('✅ پارە هاتە سڕینەوە');
                    setTimeout(function() { if (typeof syncLiveData === 'function') syncLiveData(false); }, 150);
                    setTimeout(function() { if (typeof renderCustomerLedgerHistory === 'function') renderCustomerLedgerHistory(); }, 500);
                })
                .catch(function(err) {
                    if (typeof window.posAlert === 'function') window.posAlert({ message: err.message || String(err), tone: 'danger' });
                    else if (typeof showToast === 'function') showToast('هەڵە: ' + (err.message || err), 'error');
                    else alert('هەڵە: ' + (err.message || err));
                });
        };

        window.editCustomerPayment = function(id, currentAmount) {
            var modal = document.getElementById('edit-payment-modal');
            if (!modal) return;
            
            document.getElementById('epm-payment-id').value = id;
            document.getElementById('epm-current-amount').value = currentAmount;
            modal.dataset.mode = 'customer';
            
            var sym = (typeof getCurrencySymbol === 'function') ? getCurrencySymbol() : 'IQD';
            document.getElementById('epm-currency-sym').textContent = sym;
            
            var displayAmt = (typeof formatCurrency === 'function') ? formatCurrency(currentAmount) : currentAmount;
            document.getElementById('epm-old-amount-display').textContent = displayAmt + ' ' + sym;
            
            var inputEl = document.getElementById('epm-new-amount');
            inputEl.value = currentAmount;
            
            modal.style.display = 'flex';
            setTimeout(function() {
                inputEl.focus();
                inputEl.select();
            }, 100);
        };

        window.closeEditPaymentModal = function() {
            var modal = document.getElementById('edit-payment-modal');
            if (modal) modal.style.display = 'none';
        };

        window.saveEditPaymentModal = function() {
            var id = document.getElementById('epm-payment-id').value;
            var currentAmount = parseFloat(document.getElementById('epm-current-amount').value);
            var input = document.getElementById('epm-new-amount').value;
            var mode = document.getElementById('edit-payment-modal').dataset.mode || 'customer';
            
            if (input === null || input.trim() === '') return;
            var newAmt = parseFloat(input);
            if (isNaN(newAmt) || newAmt <= 0) {
                if (typeof window.posAlert === 'function') window.posAlert({ message: 'بڕێ پارێ نادروستە!', tone: 'danger' });
                else if (typeof showToast === 'function') showToast('هەڵە: بڕێ پارێ نادروستە!', 'error');
                else alert('بڕێ پارێ نادروستە!');
                return;
            }
            if (newAmt === currentAmount) {
                closeEditPaymentModal();
                return; // No change
            }

            var formData = new FormData();
            var actionName = mode === 'company' ? 'edit_company_payment' : 'edit_customer_payment';
            formData.append('action', actionName);
            formData.append('id', String(id));
            formData.append('amount', String(newAmt));
            formData.append('user', (typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : 'System');
            
            closeEditPaymentModal();
            
            fetch('?action=' + actionName, { method: 'POST', body: formData })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (data.status !== 'success') {
                        if (typeof window.posAlert === 'function') window.posAlert({ message: data.message || 'Error', tone: 'danger' });
                        else if (typeof showToast === 'function') showToast('هەڵە: ' + (data.message || 'Error'), 'error');
                        else alert('هەڵە: ' + (data.message || 'Error'));
                        return;
                    }
                    if (typeof showToast === 'function') showToast('✅ پارە هاتە تەعدیل کرن');
                    setTimeout(function() { if (typeof syncLiveData === 'function') syncLiveData(false); }, 150);
                    setTimeout(function() { 
                        if (mode === 'company') {
                            if (typeof renderLedgerHistory === 'function') renderLedgerHistory(); 
                        } else {
                            if (typeof renderCustomerLedgerHistory === 'function') renderCustomerLedgerHistory(); 
                        }
                    }, 500);
                })
                .catch(function(err) {
                    if (typeof window.posAlert === 'function') window.posAlert({ message: err.message || String(err), tone: 'danger' });
                    else if (typeof showToast === 'function') showToast('هەڵە: ' + (err.message || err), 'error');
                    else alert('هەڵە: ' + (err.message || err));
                });
        };

        function installmentIsUsd() {
            return typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD';
        }

        /** Stored IQD (canonical DB value). */
        function installmentMoneyIqd(val) {
            return Math.round(Number(val) || 0);
        }

        /** UI/form amount from stored IQD (respects currencyMode USD vs IQD). */
        function installmentDisplayAmount(storedIqdVal) {
            var n = installmentMoneyIqd(storedIqdVal);
            if (typeof storedIqdToDebtFormAmount === 'function') return storedIqdToDebtFormAmount(n);
            if (installmentIsUsd()) {
                var rate = typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0;
                if (rate > 0) return Math.round((n / rate) * 100) / 100;
            }
            return n;
        }

        /** Parse installment form input → stored IQD for API/DB. */
        function installmentParseDisplayToStored(displayVal) {
            var valDisplay = (typeof parseAmountInput === 'function')
                ? parseAmountInput(String(displayVal || ''))
                : (parseFloat(String(displayVal || '').replace(/,/g, '')) || 0);
            if (isNaN(valDisplay)) return 0;
            if (typeof debtFormAmountToStoredIqd === 'function') return installmentMoneyIqd(debtFormAmountToStoredIqd(valDisplay));
            if (installmentIsUsd()) {
                var rate = typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0;
                if (rate > 0) return installmentMoneyIqd(valDisplay * rate);
            }
            return installmentMoneyIqd(valDisplay);
        }

        function formatInstallmentInputValue(storedIqdVal) {
            var d = installmentDisplayAmount(storedIqdVal);
            if (installmentIsUsd() && typeof formatPaymentAmountNumber === 'function') {
                return formatPaymentAmountNumber(d, 'usd');
            }
            return String(Math.round(d));
        }

        function installmentIqdStep() {
            return 250;
        }

        function roundIqdStep(amount, step) {
            step = step || installmentIqdStep();
            return Math.round(Math.round(Number(amount) || 0) / step) * step;
        }

        function installmentScheduleAmountIqd(val) {
            return roundIqdStep(val, installmentIqdStep());
        }

        function splitInstallmentPracticalIqd(total, months) {
            total = installmentMoneyIqd(total);
            months = Math.max(1, parseInt(months, 10) || 0);
            if (total <= 0 || months <= 0) return [];
            if (months === 1) return [total];
            var step = installmentIqdStep();
            var base = total / months;
            var regular = roundIqdStep(base, step);
            if (regular <= 0) regular = step;
            var first = total - (regular * (months - 1));
            if (first <= 0) {
                regular = Math.ceil(base / step) * step;
                first = total - (regular * (months - 1));
            }
            var amounts = [first];
            for (var i = 1; i < months; i++) amounts.push(regular);
            return amounts;
        }

        function splitInstallmentWholeIqd(total, months) {
            return splitInstallmentPracticalIqd(total, months);
        }

        function formatInstallmentIqd(val) {
            var n = installmentMoneyIqd(val);
            var sym = (typeof getCurrencySymbol === 'function') ? getCurrencySymbol() : (installmentIsUsd() ? '$' : 'IQD');
            if (typeof formatCurrency === 'function') {
                return formatCurrency(n) + ' ' + sym;
            }
            return n.toLocaleString('en-US', {
                maximumFractionDigits: installmentIsUsd() ? 2 : 0,
                minimumFractionDigits: 0
            }) + ' ' + sym;
        }

        function canUseCustomerInstallments() {
            return typeof canUseInstallments === 'function' && canUseInstallments();
        }

        function syncInstallmentTabProLock() {
            var badge = document.getElementById('cust-inst-tab-pro-badge');
            if (!badge) return;
            badge.style.display = canUseCustomerInstallments() ? 'none' : 'inline-block';
        }

        window.openInstallmentsPremiumUpsell = function() {
            if (typeof showPremiumLockedPurchasePopup === 'function') {
                var title = (typeof t === 'function') ? t('cust_installment_pro_title') : 'قستەکان (Pro)';
                showPremiumLockedPurchasePopup(title, 'set-enable-customer-installments');
            }
        };
        window.syncInstallmentTabProLock = syncInstallmentTabProLock;

        function buildInstallmentsProTeaserHtml(tf) {
            return '<div class="wms-mwh-teaser wms-mwh-teaser--compact">' +
                '<div class="wms-mwh-teaser__inner wms-mwh-teaser__inner--compact">' +
                    '<div class="wms-mwh-teaser__content">' +
                        '<div class="wms-mwh-teaser__badges">' +
                            '<span class="wms-mwh-teaser__badge-pro">FEAT</span>' +
                            '<span class="wms-mwh-teaser__badge-price" data-pos-price="installments">$75</span>' +
                        '</div>' +
                        '<h3 class="wms-mwh-teaser__title"><i class="fas fa-calendar-check"></i> ' +
                            escapeHtml(tf ? t('cust_installment_pro_title') : 'قستەکان — پلانا قستێ') + '</h3>' +
                        '<p class="wms-mwh-teaser__desc">' + escapeHtml(typeof posPremiumPriceInText === 'function' ? posPremiumPriceInText(tf ? t('cust_installment_pro_desc') : 'ئەڤ تایبەتمەندییە $75 (FEAT) — بێ Pro.') : (tf ? t('cust_installment_pro_desc') : 'ئەڤ تایبەتمەندییە $75 — بێ Pro.')) + '</p>' +
                        '<ul class="wms-mwh-teaser__features">' +
                            '<li><i class="fas fa-layer-group"></i> <span>' + escapeHtml(tf ? t('cust_installment_pro_f1') : 'چەند پلانا قست بۆ هەر کریارێ') + '</span></li>' +
                            '<li><i class="fas fa-coins"></i> <span>' + escapeHtml(tf ? t('cust_installment_pro_f2') : 'بڕی ×250 دینار — گونجاو بۆ پارەی عێراقی') + '</span></li>' +
                            '<li><i class="fas fa-bell"></i> <span>' + escapeHtml(tf ? t('cust_installment_pro_f3') : 'ئاگاداری کاتێ قست دەگات') + '</span></li>' +
                            '<li><i class="fas fa-calendar-alt"></i> <span>' + escapeHtml(tf ? t('cust_installment_pro_f4') : 'قستەکان لە ڕۆژمێردا') + '</span></li>' +
                        '</ul>' +
                        '<button type="button" class="btn btn-brand wms-mwh-teaser__cta" onclick="if(typeof openInstallmentsPremiumUpsell===\'function\')openInstallmentsPremiumUpsell();">' +
                            '<i class="fas fa-unlock-alt"></i> <span>' + escapeHtml(typeof posPremiumPriceInText === 'function' ? posPremiumPriceInText(tf ? t('cust_installment_pro_cta') : 'کردنەوە — $75') : (tf ? t('cust_installment_pro_cta') : 'کردنەوە — $75')) + '</span>' +
                        '</button>' +
                        '<p class="wms-mwh-teaser__foot">' + escapeHtml(tf ? t('cust_installment_pro_foot') : 'پەیوەندیێ ب پشتیڤانیێ بکە · پشتی کڕینێ کۆدێ Pro ل ڤێرێ چالاک بکە.') + '</p>' +
                    '</div>' +
                    '<div class="wms-mwh-teaser__preview" aria-hidden="true">' +
                        '<div class="wms-mwh-teaser__mock">' +
                            '<div class="wms-mwh-teaser__mock-row"><i class="fas fa-user"></i> کریار → پلانا قستێ</div>' +
                            '<div class="wms-mwh-teaser__mock-row"><i class="fas fa-check-circle"></i> 3/6 قست پاردراو</div>' +
                            '<div class="wms-mwh-teaser__mock-row"><i class="fas fa-print"></i> ڕاپۆrta قستێ</div>' +
                        '</div>' +
                        '<div class="wms-mwh-teaser__lock"><i class="fas fa-lock"></i></div>' +
                    '</div>' +
                '</div>' +
            '</div>';
        }

        function getCustomerActiveInstallmentPlans(custId) {
            if (!db || !custId) return [];
            return (db.installment_plans || []).filter(function(p) {
                return p && String(p.customer_id) === String(custId) && p.status === 'active';
            }).sort(function(a, b) {
                return (parseInt(b.id, 10) || 0) - (parseInt(a.id, 10) || 0);
            });
        }

        function getCustomerActiveInstallmentPlan(custId) {
            var plans = getCustomerActiveInstallmentPlans(custId);
            return plans.length ? plans[0] : null;
        }

        function getCustomerInstallmentCommittedRemaining(custId) {
            var total = 0;
            getCustomerActiveInstallmentPlans(custId).forEach(function(plan) {
                getInstallmentItemsForPlan(plan.id).forEach(function(it) {
                    total += Math.max(0, (parseFloat(it.amount) || 0) - (parseFloat(it.paid_amount) || 0));
                });
            });
            return installmentMoneyIqd(total);
        }

        function getCustomerInstallmentAvailableAmount(custId, balance) {
            balance = installmentMoneyIqd(balance || 0);
            return Math.max(0, balance - getCustomerInstallmentCommittedRemaining(custId));
        }

        function getInstallmentItemsForPlan(planId) {
            if (!db || !planId) return [];
            return (db.installment_items || []).filter(function(it) {
                return it && String(it.plan_id) === String(planId);
            }).map(function(it) {
                var copy = Object.assign({}, it);
                copy.amount = installmentScheduleAmountIqd(copy.amount);
                copy.paid_amount = installmentMoneyIqd(copy.paid_amount);
                return copy;
            }).sort(function(a, b) {
                return (parseInt(a.installment_no, 10) || 0) - (parseInt(b.installment_no, 10) || 0);
            });
        }

        function customerHasOverdueInstallment(custId) {
            if (!canUseCustomerInstallments()) return false;
            var today = new Date().toISOString().slice(0, 10);
            return getCustomerActiveInstallmentPlans(custId).some(function(plan) {
                return getInstallmentItemsForPlan(plan.id).some(function(it) {
                    var st = String(it.status || '');
                    return (st === 'pending' || st === 'partial' || st === 'overdue') && String(it.due_date || '') <= today;
                });
            });
        }

        function installmentStatusLabel(status) {
            var key = 'cust_installment_status_' + String(status || 'pending');
            return (typeof t === 'function') ? t(key) : status;
        }

        function updateInstallmentPreview() {
            var amountEl = document.getElementById('cust-inst-amount');
            var monthsEl = document.getElementById('cust-inst-months');
            var previewEl = document.getElementById('cust-inst-preview');
            if (!amountEl || !monthsEl || !previewEl) return;
            var amount = installmentParseDisplayToStored(amountEl.value);
            var months = parseInt(monthsEl.value, 10) || 0;
            if (amount <= 0 || months < 2) {
                previewEl.innerHTML = '';
                return;
            }
            var amounts = splitInstallmentPracticalIqd(amount, months);
            var firstAmt = amounts[0] || 0;
            var regularAmt = amounts.length > 1 ? amounts[1] : firstAmt;
            var tpl = (typeof t === 'function') ? t('cust_installment_monthly_preview') : 'هەر مانگ: {amount}';
            var firstTpl = (typeof t === 'function') ? t('cust_installment_first_preview') : 'قستی یەکەم: {amount}';
            var perMonthHint = amounts.length <= 6
                ? amounts.map(function(a, idx) { return (idx + 1) + ': ' + formatInstallmentIqd(a); }).join(' · ')
                : formatInstallmentIqd(firstAmt) + ' + ' + (amounts.length - 1) + '×' + formatInstallmentIqd(regularAmt);
            previewEl.innerHTML = '<div class="cust-installment-summary">' +
                '<div>' + escapeHtml(tpl.replace(/\{amount\}/g, formatInstallmentIqd(regularAmt))) + '</div>' +
                (firstAmt !== regularAmt
                    ? '<div style="color:var(--text-muted);font-size:0.85rem;margin-top:4px;">' + escapeHtml(firstTpl.replace(/\{amount\}/g, formatInstallmentIqd(firstAmt))) + '</div>'
                    : '') +
                '<div style="color:var(--text-muted);font-size:0.85rem;margin-top:4px;">' + escapeHtml(perMonthHint) + '</div>' +
                '<div style="color:var(--text-muted);font-size:0.9rem;margin-top:4px;">' +
                escapeHtml((typeof t === 'function' ? t('cust_installment_total_preview') : 'کۆی گشتی: {amount}').replace(/\{amount\}/g, formatInstallmentIqd(amount))) +
                '</div></div>';
        }

        function buildInstallmentPlanCardHtml(plan, planNo, tf) {
            var items = getInstallmentItemsForPlan(plan.id);
            if (!items.length) return '';
            var totalPaid = items.reduce(function(s, it) { return s + (parseFloat(it.paid_amount) || 0); }, 0);
            var totalRemaining = items.reduce(function(s, it) {
                return s + Math.max(0, (parseFloat(it.amount) || 0) - (parseFloat(it.paid_amount) || 0));
            }, 0);
            var nextItem = items.find(function(it) { return String(it.status) !== 'paid'; });
            var today = new Date().toISOString().slice(0, 10);
            var paidCount = 0;
            var partialCount = 0;
            var overdueCount = 0;
            items.forEach(function(it) {
                var st = String(it.status || 'pending');
                var rem = Math.max(0, (parseFloat(it.amount) || 0) - (parseFloat(it.paid_amount) || 0));
                if (st === 'paid' || rem <= 0.0001) paidCount++;
                else if (st === 'partial') partialCount++;
                else if (String(it.due_date || '') < today) overdueCount++;
            });
            var totalCount = items.length;
            var remainingCount = totalCount - paidCount;
            var amountProgressPct = (parseFloat(plan.total_amount) || 0) > 0
                ? Math.min(100, Math.round((totalPaid / parseFloat(plan.total_amount)) * 100))
                : 0;
            var planLabelTpl = tf ? t('cust_installment_plan_no') : 'پلانا #{n}';
            var planLabel = planLabelTpl.replace(/\{n\}/g, String(planNo || plan.id || ''));

            return '<div class="cust-installment-plan-card">' +
                '<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:12px;">' +
                    '<h3 style="color:var(--text);margin:0;">' + escapeHtml(planLabel) + '</h3>' +
                    '<div style="display:flex;gap:8px;flex-wrap:wrap;">' +
                        '<button type="button" class="btn btn-sm btn-warning" onclick="printCustomerInstallmentReport(' + plan.id + ')"><i class="fas fa-print"></i> ' +
                            escapeHtml(tf ? t('cust_installment_print_btn') : 'چاپکرنا ڕاپۆرتێ') + '</button>' +
                        '<button type="button" class="btn btn-sm btn-danger" onclick="cancelCustomerInstallmentPlan(' + plan.id + ')"><i class="fas fa-times"></i> ' +
                            escapeHtml(tf ? t('cust_installment_cancel_btn') : 'هەڵوەشاندنا پلانێ') + '</button>' +
                    '</div>' +
                '</div>' +
                '<div class="cust-installment-report">' +
                    '<h4 class="cust-installment-report-title"><i class="fas fa-chart-pie"></i> ' +
                        escapeHtml(tf ? t('cust_installment_report_title') : 'ڕاپۆrta قستێ') + '</h4>' +
                    '<div class="cust-installment-report-grid">' +
                        '<div class="cust-installment-report-stat is-paid">' +
                            '<span class="cust-inst-label">' + escapeHtml(tf ? t('cust_installment_report_paid_count') : 'قستا پاردراو') + '</span>' +
                            '<strong>' + paidCount + ' / ' + totalCount + '</strong>' +
                            '<small>' + formatInstallmentIqd(totalPaid) + '</small>' +
                        '</div>' +
                        '<div class="cust-installment-report-stat is-remaining">' +
                            '<span class="cust-inst-label">' + escapeHtml(tf ? t('cust_installment_report_remaining_count') : 'قستا مای') + '</span>' +
                            '<strong>' + remainingCount + ' / ' + totalCount + '</strong>' +
                            '<small>' + formatInstallmentIqd(totalRemaining) + '</small>' +
                        '</div>' +
                        (partialCount > 0 ? '<div class="cust-installment-report-stat is-partial">' +
                            '<span class="cust-inst-label">' + escapeHtml(tf ? t('cust_installment_report_partial_count') : 'قستا بەشێکی') + '</span>' +
                            '<strong>' + partialCount + '</strong></div>' : '') +
                        (overdueCount > 0 ? '<div class="cust-installment-report-stat is-overdue">' +
                            '<span class="cust-inst-label">' + escapeHtml(tf ? t('cust_installment_report_overdue_count') : 'قستا دواکەوتوو') + '</span>' +
                            '<strong>' + overdueCount + '</strong></div>' : '') +
                    '</div>' +
                    '<div class="cust-installment-progress-wrap">' +
                        '<div class="cust-installment-progress-label">' +
                            escapeHtml(tf ? t('cust_installment_report_progress') : 'پێشکەوتن') + ': ' + amountProgressPct + '%' +
                        '</div>' +
                        '<div class="cust-installment-progress-bar"><div class="cust-installment-progress-fill" style="width:' + amountProgressPct + '%;"></div></div>' +
                    '</div>' +
                '</div>' +
                '<div class="cust-installment-summary">' +
                    '<div class="cust-installment-summary-grid">' +
                        '<div><span class="cust-inst-label">' + escapeHtml(tf ? t('cust_installment_total_label') : 'کۆی قست') + '</span><strong>' + formatInstallmentIqd(plan.total_amount || 0) + '</strong></div>' +
                        '<div><span class="cust-inst-label">' + escapeHtml(tf ? t('cust_installment_paid_label') : 'پاردراو') + '</span><strong style="color:#10b981;">' + formatInstallmentIqd(totalPaid) + '</strong></div>' +
                        '<div><span class="cust-inst-label">' + escapeHtml(tf ? t('cust_installment_remaining_label') : 'ماوە') + '</span><strong style="color:#ef4444;">' + formatInstallmentIqd(totalRemaining) + '</strong></div>' +
                        '<div><span class="cust-inst-label">' + escapeHtml(tf ? t('cust_installment_months_label') : 'ژمارەی مانگ') + '</span><strong>' + escapeHtml(String(plan.months || '')) + '</strong></div>' +
                    '</div>' +
                    (nextItem ? '<div style="margin-top:10px;font-size:0.9rem;color:var(--text-muted);">' +
                        escapeHtml(tf ? t('cust_installment_next_due') : 'قستا داهاتوو') + ': <b style="color:var(--text);">' +
                        formatInstallmentIqd(Math.max(0, (parseFloat(nextItem.amount) || 0) - (parseFloat(nextItem.paid_amount) || 0))) +
                        '</b> — ' + escapeHtml(String(nextItem.due_date || '')) + '</div>' : '') +
                '</div>' +
                '<div class="cust-profile-scroll-list" style="max-height:320px;overflow-y:auto;margin-top:12px;">' +
                    '<table class="report-table"><thead><tr>' +
                        '<th>#</th><th>' + escapeHtml(tf ? t('cust_installment_col_date') : 'بەروار') + '</th>' +
                        '<th>' + escapeHtml(tf ? t('cust_installment_col_amount') : 'بڕ') + '</th>' +
                        '<th>' + escapeHtml(tf ? t('cust_installment_col_paid') : 'پاردراو') + '</th>' +
                        '<th>' + escapeHtml(tf ? t('cust_installment_col_remaining') : 'ماوە') + '</th>' +
                        '<th>' + escapeHtml(tf ? t('cust_installment_col_status') : 'دۆخ') + '</th>' +
                    '</tr></thead><tbody>' +
                    items.map(function(it) {
                        var st = String(it.status || 'pending');
                        if ((st === 'pending' || st === 'partial') && String(it.due_date || '') < today) st = 'overdue';
                        var rowCls = (st === 'overdue') ? 'installment-overdue-row' : '';
                        var badgeCls = 'installment-status-badge installment-status-' + st;
                        var itemRem = Math.max(0, (parseFloat(it.amount) || 0) - (parseFloat(it.paid_amount) || 0));
                        return '<tr class="' + rowCls + '">' +
                            '<td>' + escapeHtml(String(it.installment_no || '')) + '</td>' +
                            '<td>' + escapeHtml(String(it.due_date || '')) + '</td>' +
                            '<td style="font-weight:bold;">' + formatInstallmentIqd(it.amount || 0) + '</td>' +
                            '<td style="color:#10b981;">' + formatInstallmentIqd(it.paid_amount || 0) + '</td>' +
                            '<td style="color:#ef4444;font-weight:bold;">' + formatInstallmentIqd(itemRem) + '</td>' +
                            '<td><span class="' + badgeCls + '">' + escapeHtml(installmentStatusLabel(st)) + '</span></td>' +
                        '</tr>';
                    }).join('') +
                    '</tbody></table></div>' +
            '</div>';
        }

        function buildInstallmentSetupFormHtml(defaultAmount, availableAmount, tf) {
            var amtDisplay = formatInstallmentInputValue(defaultAmount || 0);
            var sym = (typeof getCurrencySymbol === 'function') ? getCurrencySymbol() : (installmentIsUsd() ? '$' : 'IQD');
            return '<div class="cust-installment-add-section">' +
                '<h3 style="color:var(--text);margin:0 0 12px;">' + escapeHtml(tf ? t('cust_installment_add_plan_title') : 'زیادکرنا پلانەکا نوێ') + '</h3>' +
                '<div class="cust-installment-form">' +
                    '<div class="cust-installment-form-row">' +
                        '<label>' + escapeHtml(tf ? t('cust_installment_amount_label') : 'بڕی قست') + ' (' + escapeHtml(sym) + ')</label>' +
                        '<input type="text" id="cust-inst-amount" class="input-std" value="' + escapeHtml(amtDisplay) + '" oninput="updateInstallmentPreview()">' +
                        '<small style="color:var(--text-muted);">' +
                            escapeHtml(tf ? t('cust_installment_available_hint') : 'بەردەست') + ': ' + formatInstallmentIqd(availableAmount) +
                        '</small>' +
                    '</div>' +
                    '<div class="cust-installment-form-row">' +
                        '<label>' + escapeHtml(tf ? t('cust_installment_months_label') : 'ژمارەی مانگ') + '</label>' +
                        '<select id="cust-inst-months" class="input-std" onchange="updateInstallmentPreview()">' +
                            [2, 3, 4, 5, 6, 9, 12, 18, 24].map(function(m) {
                                return '<option value="' + m + '"' + (m === 6 ? ' selected' : '') + '>' + m + ' ' + escapeHtml(tf ? t('cust_installment_month_unit') : 'مانگ') + '</option>';
                            }).join('') +
                        '</select>' +
                    '</div>' +
                    '<div id="cust-inst-preview"></div>' +
                    '<button type="button" class="btn btn-brand" style="width:100%;margin-top:12px;" onclick="createCustomerInstallmentPlan()">' +
                        '<i class="fas fa-plus-circle"></i> ' + escapeHtml(tf ? t('cust_installment_add_plan_btn') : 'زیادکرنا پلانێ') +
                    '</button>' +
                '</div></div>';
        }

        function renderCustomerInstallments() {
            var custId = currentViewingCustomerId;
            var root = document.getElementById('cust-installments-root');
            if (!custId || !root) return;

            var tf = (typeof t === 'function');
            syncInstallmentTabProLock();

            if (!canUseCustomerInstallments()) {
                root.innerHTML = buildInstallmentsProTeaserHtml(tf);
                if (typeof applyI18nSubtree === 'function') applyI18nSubtree(root);
                if (typeof applyPosPremiumPricingLabels === 'function') applyPosPremiumPricingLabels(root);
                return;
            }

            var cust = (db.customers || []).find(function(c) { return c && String(c.id) === String(custId); });
            if (!cust) {
                root.innerHTML = '<div style="text-align:center;padding:20px;color:#999;">' + escapeHtml(typeof t === 'function' ? t('cust_installment_no_customer') : 'کریار نەهاتە دیتن') + '</div>';
                return;
            }

            var balance = parseFloat(cust.balance) || 0;
            var activePlans = getCustomerActiveInstallmentPlans(custId);
            var available = getCustomerInstallmentAvailableAmount(custId, balance);

            if (balance <= 0 && !activePlans.length) {
                root.innerHTML = '<div style="text-align:center;padding:24px;color:var(--text-muted);"><i class="fas fa-check-circle" style="font-size:2rem;color:#10b981;margin-bottom:10px;display:block;"></i>' +
                    escapeHtml(tf ? t('cust_installment_no_debt') : 'چ قەرز نییە بۆ قست') + '</div>';
                return;
            }

            var html = '';
            if (activePlans.length) {
                html += activePlans.map(function(plan, idx) {
                    return buildInstallmentPlanCardHtml(plan, activePlans.length - idx, tf);
                }).join('');
            }

            if (available > 0) {
                html += buildInstallmentSetupFormHtml(available, available, tf);
            } else if (!activePlans.length && balance > 0) {
                html += buildInstallmentSetupFormHtml(balance, balance, tf);
            } else if (activePlans.length && available <= 0) {
                html += '<div class="cust-installment-add-section" style="text-align:center;padding:16px;color:var(--text-muted);font-size:0.9rem;">' +
                    '<i class="fas fa-info-circle"></i> ' + escapeHtml(tf ? t('cust_installment_no_available') : 'هەموو قەرز لە پلانێن چالاکدا تۆمارکراوە') +
                '</div>';
            }

            root.innerHTML = html;
            if (available > 0 || (!activePlans.length && balance > 0)) {
                updateInstallmentPreview();
            }
        }

        function createCustomerInstallmentPlan() {
            var custId = currentViewingCustomerId;
            if (!custId) return;
            if (!canUseCustomerInstallments()) {
                if (typeof openInstallmentsPremiumUpsell === 'function') openInstallmentsPremiumUpsell();
                return;
            }
            if (typeof checkPermission === 'function' && !checkPermission('debt_manage', 'دامەزراندنا قستێ')) return;

            var amountEl = document.getElementById('cust-inst-amount');
            var monthsEl = document.getElementById('cust-inst-months');
            if (!amountEl || !monthsEl) return;

            var amount = installmentParseDisplayToStored(amountEl.value);
            var months = parseInt(monthsEl.value, 10) || 0;
            var cust = (db.customers || []).find(function(c) { return c && String(c.id) === String(custId); });
            var balance = cust ? installmentMoneyIqd(cust.balance) : 0;
            var available = getCustomerInstallmentAvailableAmount(custId, balance);

            if (amount <= 0) return showToast(typeof t === 'function' ? t('cust_installment_err_amount') : 'بڕی قست نادروستە', 'error');
            if (amount > available + 0.0001) return showToast(typeof t === 'function' ? t('cust_installment_err_over_available') : 'بڕی قست ژ قەرزی بەردەست مەزنترە', 'error');
            if (amount > balance + 0.0001) return showToast(typeof t === 'function' ? t('cust_installment_err_over_balance') : 'بڕی قست ژ قەرزی مەزنترە', 'error');
            if (months < 2 || months > 24) return showToast(typeof t === 'function' ? t('cust_installment_err_months') : 'ژمارەی مانگ نادروستە', 'error');

            var formData = new FormData();
            formData.append('action', 'create_installment_plan');
            formData.append('customer_id', custId);
            formData.append('amount', amount);
            formData.append('months', months);
            formData.append('start_date', new Date().toISOString().slice(0, 10));
            formData.append('created_by', (typeof currentUser !== 'undefined' && currentUser && currentUser.name) ? currentUser.name : 'System');

            fetch('?action=create_installment_plan', { method: 'POST', body: formData })
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    if (data.status === 'success') {
                        if (!db.installment_plans) db.installment_plans = [];
                        if (!db.installment_items) db.installment_items = [];
                        if (data.plan) db.installment_plans.unshift(data.plan);
                        if (Array.isArray(data.items)) {
                            data.items.forEach(function(it) { db.installment_items.push(it); });
                        }
                        showToast(typeof t === 'function' ? t('cust_installment_created_toast') : '✅ پلانا قستێ هاتە دامەزراندن');
                        renderCustomerInstallments();
                        if (typeof renderDebtView === 'function') renderDebtView('customers');
                        var vcal = document.getElementById('view-calendar');
                        if (vcal && vcal.classList.contains('active') && typeof renderWorkCalendar === 'function') renderWorkCalendar();
                    } else {
                        if (data.pro_required && typeof openInstallmentsPremiumUpsell === 'function') {
                            openInstallmentsPremiumUpsell();
                        }
                        showToast('❌ ' + (data.message || 'هەڵە'), 'error');
                    }
                })
                .catch(function(e) {
                    showToast('❌ ' + (e.message || String(e)), 'error');
                });
        }

        function cancelCustomerInstallmentPlan(planId) {
            if (!planId) return;
            if (!canUseCustomerInstallments()) {
                if (typeof openInstallmentsPremiumUpsell === 'function') openInstallmentsPremiumUpsell();
                return;
            }
            var items = typeof getInstallmentItemsForPlan === 'function' ? getInstallmentItemsForPlan(planId) : [];
            var totalPaid = items.reduce(function(s, it) { return s + (parseFloat(it.paid_amount) || 0); }, 0);
            var tf = (typeof t === 'function');
            var msg = totalPaid > 0
                ? (tf ? t('cust_installment_cancel_confirm_paid') : 'پلانێ هەڵبوەشێنە؟ پارەی پێشتر دراو دەمێنێتەوە.')
                : (tf ? t('cust_installment_cancel_confirm') : 'دڵنیایت لە هەڵوەشاندنا پلانێ؟');
            if (!confirm(msg)) return;

            var formData = new FormData();
            formData.append('action', 'cancel_installment_plan');
            formData.append('plan_id', planId);

            fetch('?action=cancel_installment_plan', { method: 'POST', body: formData })
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    if (data.status === 'success') {
                        if (db.installment_plans) {
                            db.installment_plans = db.installment_plans.map(function(p) {
                                if (p && String(p.id) === String(planId)) p.status = 'cancelled';
                                return p;
                            });
                        }
                        showToast(typeof t === 'function' ? t('cust_installment_cancelled_toast') : 'پلان هاتە هەڵوەشاندن');
                        renderCustomerInstallments();
                    } else {
                        showToast('❌ ' + (data.message || 'هەڵە'), 'error');
                    }
                });
        }

        function sendInstallmentDueTelegram(payload, cust) {
            if (!payload || !db || !db.settings || !db.settings.tgToken || !db.settings.tgChatId) return;
            if (typeof sendTelegramNotification !== 'function') return;
            var tgKey = 'pos_inst_tg_' + payload.installmentId + '_' + new Date().toISOString().slice(0, 10) + '_' + payload.type;
            try {
                if (localStorage.getItem(tgKey)) return;
                localStorage.setItem(tgKey, '1');
            } catch (e) { return; }
            var phone = cust && cust.phone ? String(cust.phone).trim() : '';
            var msg = '**' + payload.title + '**\n\n' +
                payload.message +
                (phone ? '\n📞 ' + phone : '') +
                '\n\n🏪 ' + (db.settings.cafeName || 'POS');
            // Do not send individual notifications to telegram, only send the daily report
            // sendTelegramNotification(msg);
        }

        function checkInstallmentDueReminders() {
            if (!canUseCustomerInstallments()) return;
            if (!db || !Array.isArray(db.installment_plans) || !Array.isArray(db.installment_items)) return;
            var today = new Date().toISOString().slice(0, 10);
            var tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 1);
            var tomorrowStr = tomorrow.toISOString().slice(0, 10);
            var notified = false;

            db.installment_plans.forEach(function(plan) {
                if (!plan || plan.status !== 'active') return;
                var cust = (db.customers || []).find(function(c) { return c && String(c.id) === String(plan.customer_id); });
                var custName = cust ? (cust.name || ('#' + plan.customer_id)) : ('#' + plan.customer_id);
                getInstallmentItemsForPlan(plan.id).forEach(function(it) {
                    if (!it || String(it.status) === 'paid') return;
                    var due = String(it.due_date || '');
                    if (!due) return;

                    var isOverdue = due < today;
                    var isDueToday = due === today;
                    var isDueTomorrow = due === tomorrowStr;
                    if (!isOverdue && !isDueToday && !isDueTomorrow) return;

                    var remaining = Math.max(0, (parseFloat(it.amount) || 0) - (parseFloat(it.paid_amount) || 0));
                    var tf = (typeof t === 'function');
                    var titleTpl, msgTpl, msgType;

                    if (isOverdue) {
                        titleTpl = tf ? t('cust_installment_notif_overdue_title') : '⚠️ قست دواکەوتوو — {name}';
                        msgTpl = tf ? t('cust_installment_notif_overdue_message') : 'قست #{n}: {amount} — دواکەوتوو لە {date}';
                        msgType = 'installment_overdue';
                    } else if (isDueToday) {
                        titleTpl = tf ? t('cust_installment_notif_due_title') : '⏰ ئەمڕۆ وەختی قستەکەیە — {name}';
                        msgTpl = tf ? t('cust_installment_notif_due_message') : 'قست #{n}: {amount} — ئەمڕۆ ({date})';
                        msgType = 'installment_due';
                    } else {
                        titleTpl = tf ? t('cust_installment_notif_soon_title') : '📅 سبەینێ قست — {name}';
                        msgTpl = tf ? t('cust_installment_notif_soon_message') : 'قست #{n}: {amount} — سبەینێ ({date})';
                        msgType = 'installment_upcoming';
                    }

                    var payload = {
                        id: 'inst-' + it.id + '-' + today + '-' + msgType,
                        title: titleTpl.replace(/\{name\}/g, custName),
                        message: msgTpl
                            .replace(/\{n\}/g, String(it.installment_no || ''))
                            .replace(/\{amount\}/g, typeof formatInstallmentIqd === 'function' ? formatInstallmentIqd(remaining) : String(Math.round(remaining)))
                            .replace(/\{date\}/g, due),
                        type: msgType,
                        createdBy: 'System',
                        createdAt: Date.now(),
                        customerId: plan.customer_id,
                        installmentId: it.id
                    };

                    var inboxKey = 'pos_inst_inbox_' + it.id + '_' + today + '_' + msgType;
                    var sessionKey = 'pos_inst_sess_' + it.id + '_' + today + '_' + msgType;
                    var alreadyInInbox = false;
                    var alreadyThisSession = false;
                    try {
                        alreadyInInbox = !!localStorage.getItem(inboxKey);
                        alreadyThisSession = !!sessionStorage.getItem(sessionKey);
                    } catch (e) { return; }

                    if (!alreadyInInbox) {
                        try { localStorage.setItem(inboxKey, '1'); } catch (e) {}
                        sendInstallmentDueTelegram(payload, cust);
                        if (window.POSNotifications && typeof window.POSNotifications.onMessage === 'function') {
                            window.POSNotifications.onMessage(payload);
                            notified = true;
                        } else if (window.POSNotifications && typeof window.POSNotifications.alertInstallment === 'function') {
                            window.POSNotifications.alertInstallment(payload);
                            notified = true;
                        } else if (typeof showToast === 'function') {
                            showToast(payload.title + ': ' + payload.message, payload.type);
                        }
                    } else if (!alreadyThisSession && (isDueToday || isOverdue)) {
                        try { sessionStorage.setItem(sessionKey, '1'); } catch (e) {}
                        if (window.POSNotifications && typeof window.POSNotifications.alertInstallment === 'function') {
                            window.POSNotifications.alertInstallment(payload);
                            notified = true;
                        }
                    }
                });
            });
            if (notified && typeof updateNotificationBadge === 'function') updateNotificationBadge();
        }

        function scheduleInstallmentReminderChecks() {
            if (window.__posInstallmentReminderInterval) return;
            window.__posInstallmentReminderInterval = setInterval(function() {
                try { checkInstallmentDueReminders(); } catch (e) {}
            }, 180000);
            if (!window.__posInstallmentReminderBound) {
                window.__posInstallmentReminderBound = true;
                document.addEventListener('visibilitychange', function() {
                    if (!document.hidden) {
                        try { checkInstallmentDueReminders(); } catch (e) {}
                    }
                });
                window.addEventListener('focus', function() {
                    try { checkInstallmentDueReminders(); } catch (e) {}
                });
            }
        }
        scheduleInstallmentReminderChecks();

        function renderCustomerHistory() {
            const custId = currentViewingCustomerId;
            if(!custId) return;
            const list = document.getElementById('cust-p-history-list');
            if (!list) return;
            
            list.innerHTML = '<div style="text-align:center; padding:20px; color:#999"><i class="fas fa-spinner fa-spin"></i> بارکرنا مێژوویێ...</div>';
            
            fetch('?action=get_sales_history&limit=10000&customer_id=' + encodeURIComponent(custId) + '&customer_type=customer', { credentials: 'same-origin' })
            .then(async res => {
                const text = await res.text();
                try {
                    return JSON.parse(text);
                } catch (err) {
                    throw new Error("Invalid JSON: " + text.substring(0, 100));
                }
            })
            .then(data => {
                if (data.status === 'success') {
                    let custSales = data.sales || [];
                    if(custSales.length === 0) { list.innerHTML = '<div style="text-align:center; padding:20px; color:#999">چ مێژوویا کڕینێ نینە</div>'; return; }
                    
                    list.innerHTML = '<table class="report-table"><thead><tr><th style="width:160px">بەروار</th><th style="width:120px">وەسڵ</th><th style="width:120px">کۆم بهای</th><th>تێبینی (ئایتم)</th></tr></thead><tbody>' + custSales.map(s => {
                        const itemsObj = (typeof s.items === 'string') ? JSON.parse(s.items) : (s.items || []);
                        
                        // Group identical items to prevent long lists (Fix for user report)
                        const grouped = {};
                        itemsObj.forEach(it => {
                            const nm = it.name || it.itemName || 'ئایتم';
                            const q = parseFloat(it.qty != null ? it.qty : (it.count != null ? it.count : 1)) || 0;
                            if (!grouped[nm]) grouped[nm] = 0;
                            grouped[nm] += q;
                        });
                        const itemPairs = Object.keys(grouped).map(nm => `<span style="background:rgba(59,130,246,0.1); color:#2563eb; padding:2px 6px; border-radius:4px; display:inline-block; margin:2px;">${escapeHtml(nm)} <b style="color:#1e40af">(${grouped[nm]})</b></span>`);
                        const maxShow = 15;
                        let itemNamesHtml = itemPairs.slice(0, maxShow).join(' ');
                        if (itemPairs.length > maxShow) {
                            itemNamesHtml += ` <span style="color:var(--text-muted); font-size:0.8rem;">... (و ${itemPairs.length - maxShow} یێن دی)</span>`;
                        }
                        if (!itemNamesHtml) itemNamesHtml = '<span style="color:var(--text-muted)">---</span>';

                        const isDebt = s.payment_method === 'debt' || s.payment_method === 'split';
                        const returnBadge = s.is_returned ? '<span style="background:var(--warning); color:white; font-size:0.7rem; padding:2px 5px; border-radius:4px;">زڤڕیایە</span> ' : '';
                        const debtBadge = isDebt ? '<span style="background:var(--danger); color:white; font-size:0.7rem; padding:2px 5px; border-radius:4px;">قەرز</span> ' : '';
                        const createdDate = s.created_at || s.date || '';
                        const formattedDate = createdDate ? new Date(createdDate).toLocaleString('ku-IQ', { year:'numeric', month:'numeric', day:'numeric', hour:'2-digit', minute:'2-digit' }) : '';

                        return `<tr style="transition: background 0.2s;" onmouseover="this.style.background='rgba(59,130,246,0.05)'" onmouseout="this.style.background='transparent'">
                            <td style="white-space:nowrap; font-size:0.85rem; color:var(--text-muted);">${formattedDate}</td>
                            <td style="white-space:nowrap;"><span style="font-weight:700; color:var(--brand)">#${s.id}</span><br>${returnBadge}${debtBadge}</td>
                            <td style="font-weight:900; color:var(--text); white-space:nowrap;">${typeof formatCurrency === 'function' ? formatCurrency(s.total, typeof fxUsdRateFormatOpts === 'function' ? fxUsdRateFormatOpts(s) : undefined) : s.total}</td>
                            <td><div style="font-size:0.85rem; line-height:1.6; max-height:100px; overflow-y:auto; word-break:break-word; padding:4px;">${itemNamesHtml}</div></td>
                        </tr>`;
                    }).join('') + '</tbody></table>';
                } else {
                    list.innerHTML = '<div style="text-align:center; padding:20px; color:#f00">هەڵە د بارکرنا مێژوویێ دا: ' + (data.message || '') + '</div>';
                }
            })
            .catch(e => {
                console.error(e);
                list.innerHTML = '<div style="text-align:center; padding:20px; color:#f00">هەڵە د پەیوەندیێ دا: ' + escapeHtml(e.message || String(e)) + '</div>';
            });
        }

