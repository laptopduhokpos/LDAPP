// sales/debt-bill.js — debt sale, bill, discount
        // --- DEBT SALE MODAL ---
        function openDebtModal() {
            const table = db.tables.find(t => t.id === activeTableId);
            if(!table || table.items.length === 0) return alert("سەبەت یا ڤالایە!");
            document.getElementById('debt-select-modal').style.display = 'flex';
            renderDebtSelect('customer');
        }
        function closeDebtModal() { document.getElementById('debt-select-modal').style.display = 'none'; }

        function renderDebtSelect(type) {
            const container = document.getElementById('debt-person-list');
            let list = [];
            if(type === 'customer') list = (db.customers || []).slice();
            else list = (db.users || []).slice();
            list.sort(function (a, b) { return (parseFloat(b.balance) || 0) - (parseFloat(a.balance) || 0); });
            var largeShop = (typeof isPosLargeShopMode === 'function' && isPosLargeShopMode());
            var lim = largeShop && type === 'customer'
                ? ((typeof posEntityPickLimit === 'function') ? posEntityPickLimit() : 36)
                : list.length;
            var shown = list.slice(0, lim);
            var hint = '';
            if (largeShop && type === 'customer' && list.length > shown.length) {
                hint = '<p style="grid-column:1/-1;font-size:0.85rem;color:var(--text-muted);margin:0 0 8px 0;">'
                    + escapeHtml((typeof t === 'function' && t('debt_pick_search_hint') !== 'debt_pick_search_hint')
                        ? t('debt_pick_search_hint')
                        : 'بۆ کڕیارێن تر: لە بەشی قەرز بگەڕێ یان ناو بنووسە')
                    + '</p>';
            }
            container.innerHTML = hint + shown.map(p => `
                <div class="debt-person-card" onclick="processDebtSale(${p.id}, '${type}')">
                    <b>${escapeHtml(p.name || 'ئایتم')}</b>
                    <small>قەرز: ${formatCurrency(p.balance || 0)}</small>
                    ${type === 'customer' && (parseFloat(p.debt_limit) || 0) > 0 && (parseFloat(p.balance) || 0) > (parseFloat(p.debt_limit) || 0)
                        ? `<small style="display:block; color:#f59e0b; margin-top:4px;"><i class="fas fa-exclamation-triangle"></i> دەرکەتن ژ سنوورێ قەرزێ</small>`
                        : ''}
                </div>
            `).join('');
        }

        function processDebtSale(targetId, targetType) {
            if(!confirm("دڵنیای؟ ئەڤ وەسڵە دێ چیتە سەر قەرزێ ڤی کەسی.")) return;
            closeDebtModal();
            if (targetType === 'customer' && typeof posEnsureCustomerById === 'function') {
                posEnsureCustomerById(targetId).then(function () {
                    processPayment('debt', targetId, targetType);
                });
                return;
            }
            processPayment('debt', targetId, targetType);
        }

        // --- BARCODE SCANNER LISTENER ---
        let barcodeBuffer = '';
        let barcodeTimer;
        let barcodeBufferStartedAt = 0;

        // Alt+F1 / Alt+F2 / Alt+F3 (هەردووک قۆناغ ٢) / Alt+S: Product form - steps and save
        document.addEventListener('keydown', function(e) {
            var viewProducts = document.getElementById('view-products');
            var productFormCard = document.getElementById('product-form-card');
            if (!viewProducts || !viewProducts.classList.contains('active') || !productFormCard) return;
            if (!e.altKey) return;
            var handled = false;
            if (e.key === 'F1') {
                e.preventDefault(); e.stopPropagation();
                if (typeof productFormGoToStep === 'function') productFormGoToStep(1);
                handled = true;
            } else if (e.key === 'F2') {
                e.preventDefault(); e.stopPropagation();
                if (typeof productFormGoToStep === 'function') productFormGoToStep(2);
                var nameEl = document.getElementById('p-name');
                if (nameEl) { nameEl.focus(); nameEl.select(); }
                handled = true;
            } else if (e.key === 'F3') {
                e.preventDefault(); e.stopPropagation();
                if (typeof productFormGoToStep === 'function') productFormGoToStep(2);
                handled = true;
            } else if (e.key === 's' || e.key === 'S') {
                e.preventDefault(); e.stopPropagation();
                if (typeof saveProduct === 'function') saveProduct();
                handled = true;
            }
        }, true);

        document.addEventListener('keydown', (e) => {
            // Ctrl+0: Reset zoom to 100%
            if (e.ctrlKey && (e.key === '0' || e.key === ')')) {
                e.preventDefault();
                if (typeof applyZoomLevel === 'function') applyZoomLevel(100);
                try { localStorage.setItem('pos_zoom', '100'); } catch (err) {}
                if (db && db.settings) db.settings.zoomLevel = 100;
                if (typeof saveSettings === 'function') saveSettings().catch(function() {});
                return;
            }

            // Checkout Shortcut (Up Arrow) — same path as Sell (payment screen if green + Pro)
            if (e.key === 'ArrowUp' && document.getElementById('view-pos').classList.contains('active')) {
                e.preventDefault();
                if (typeof sellFromPos === 'function') sellFromPos();
                return;
            }

            if (typeof isPosScannerBlocked === 'function' && isPosScannerBlocked()) {
                if (e.key === 'Enter' || e.key === 'Tab' || e.keyCode === 13) {
                    barcodeBuffer = '';
                    barcodeBufferStartedAt = 0;
                }
                return;
            }

            // If an input is focused, let its own handlers work. This is for global "headless" scanning.
            var ae = document.activeElement;
            if (ae) {
                var tag = ae.tagName;
                if ((tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || ae.isContentEditable) && !ae.readOnly && !ae.disabled) {
                    return;
                }
                if (ae.closest && ae.closest('.modal-overlay, .modal, [role="dialog"], .swal2-container')) {
                    return;
                }
            }

            // Headless scanner logic (acts like a keyboard but doesn't focus an input)
            if (e.key === 'Enter' || e.key === 'Tab' || e.keyCode === 13) {
                var buf = barcodeBuffer;
                var started = barcodeBufferStartedAt;
                barcodeBuffer = '';
                barcodeBufferStartedAt = 0;
                if (!buf) return;
                var elapsed = started ? (Date.now() - started) : 0;
                var len = buf.length;
                // Accept ALL lengths when arrival is scanner-fast. Reject slow human typing (ghost adds).
                if (len < 2) return;
                if (len <= 4 && elapsed > 250) return;
                if (elapsed > 2400) return;
                var avgCharTime = elapsed / len;
                if (avgCharTime > 90) return;
                if (document.getElementById('view-pos') && document.getElementById('view-pos').classList.contains('active')) {
                    if (typeof ensureDefaultCart === 'function') ensureDefaultCart();
                    var bill = document.getElementById('pos-bill-panel');
                    var bigBasket = (bill && bill.classList.contains('expanded'))
                        ? document.getElementById('pos-expand-search-input')
                        : document.getElementById('pos-barcode-input');
                    e.preventDefault();
                    if (typeof posEnqueueBarcodeScan === 'function') {
                        posEnqueueBarcodeScan(buf, bigBasket, { exactBarcodeOnly: true });
                        return;
                    }
                    if (typeof tryAddPosScanBySelectedUnit === 'function' && tryAddPosScanBySelectedUnit(buf, bigBasket, { exactBarcodeOnly: true })) {
                        return;
                    }
                    if (typeof showToast === 'function') showToast('بارکۆد نەهاتە دیتن', 'warning');
                    if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('pos', { clear: true, delay: 0 });
                    return;
                }
                if (document.getElementById('view-products') && document.getElementById('view-products').classList.contains('active')) {
                    const searchInput = document.getElementById('products-search-input');
                    if (searchInput) {
                        searchInput.value = buf;
                        renderProducts(buf);
                        searchInput.focus();
                    }
                    return;
                }
                if (document.getElementById('view-warehouse') && document.getElementById('view-warehouse').classList.contains('active')) {
                    var whIn = document.getElementById('wh-search');
                    if (whIn) {
                        whIn.value = buf;
                        if (typeof renderWarehouse === 'function') renderWarehouse();
                        whIn.focus();
                    }
                }
            } else if (e.key.length === 1 && !e.ctrlKey && !e.altKey && !e.metaKey) {
                let char = e.key;
                // Global Auto-Translate for Arabic/Kurdish Numerals (Scanner Fix)
                if (/[\u0660-\u0669]/.test(char)) char = String(char.charCodeAt(0) - 0x0660);
                else if (/[\u06F0-\u06F9]/.test(char)) char = String(char.charCodeAt(0) - 0x06F0);

                if (!barcodeBuffer) barcodeBufferStartedAt = Date.now();
                barcodeBuffer += char;
                clearTimeout(barcodeTimer);
                // Keep buffer between rapid scanner keystrokes (some USB devices gap ~80–140ms, wireless up to 220ms)
                barcodeTimer = setTimeout(function() {
                    barcodeBuffer = '';
                    barcodeBufferStartedAt = 0;
                }, 280);
            }
        });

        // --- SECURITY HELPERS ---
        var _secLogThrottle = {};
        var _secLogPending = null;
        function logSecurityEvent(type, details) {
            var key = String(type || 'event');
            var now = Date.now();
            var minGap = (typeof window.isPosTxnViewActive === 'function' && window.isPosTxnViewActive()) ? 1200
                : ((typeof window.isPosCpuSaveMode === 'function' && window.isPosCpuSaveMode()) ? 2800 : 2000);
            if (_secLogThrottle[key] && (now - _secLogThrottle[key]) < minGap) return;
            _secLogThrottle[key] = now;
            if (_secLogPending) clearTimeout(_secLogPending);
            _secLogPending = setTimeout(function() {
                _secLogPending = null;
                var formData = new FormData();
                formData.append('action', 'log_client_event');
                formData.append('type', type);
                formData.append('details', details);
                formData.append('user', currentUser ? currentUser.name : 'System');
                formData.append('user_id', currentUser ? currentUser.id : 0);
                fetch('?action=log_client_event', { method: 'POST', body: formData })
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        if (!data || data.status !== 'success' || typeof db === 'undefined' || !db) return;
                        if (!Array.isArray(db.logs)) db.logs = [];
                        db.logs.unshift({
                            user: currentUser ? currentUser.name : 'System',
                            action_type: type,
                            details: details,
                            created_at: new Date().toISOString(),
                            entity_type: null,
                            entity_id: null
                        });
                        if (db.logs.length > 400) db.logs.length = 400;
                        var sm = document.getElementById('security-modal');
                        if (sm && sm.style.display === 'flex' && typeof renderSecurityLogs === 'function') {
                            renderSecurityLogs();
                        }
                    })
                    .catch(function() {});
            }, 350);
        }

        function refreshAuditLogs(done) {
            if (!db) {
                if (typeof done === 'function') done();
                return;
            }
            fetch('?action=get_audit_logs&limit=300&t=' + Date.now())
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (data && data.status === 'success' && Array.isArray(data.logs)) {
                        db.logs = data.logs;
                    }
                    if (typeof done === 'function') done();
                })
                .catch(function() { if (typeof done === 'function') done(); });
        }
        if (typeof window !== 'undefined') window.refreshAuditLogs = refreshAuditLogs;

        function getSystemIcon() {
            const mode = (db.settings && db.settings.systemMode) ? db.settings.systemMode : 'general';
            if (mode === 'market') return 'fa-store';
            if (mode === 'pharmacy') return 'fa-clinic-medical';
            if (mode === 'stationery') return 'fa-pencil-alt';
            if (mode === 'mobile') return 'fa-mobile-screen-button';
            if (mode === 'company') return 'fa-building';
            if (mode === 'cafe') return 'fa-mug-hot';
            if (mode === 'restaurant') return 'fa-utensils';
            if (mode === 'clinic') return 'fa-user-md';
            if (mode === 'hotel') return 'fa-hotel';
            if (mode === 'factory') return 'fa-industry';
            if (mode === 'jewelry') return 'fa-gem';
            return 'fa-layer-group'; // general
        }

        function groupPosCartItems(table) {
            const grouped = {};
            let total = 0;
            const uniqueIds = new Set();
            (table.items || []).forEach(function (item) {
                var lineQty = getItemQty(item);
                var unitIqdLine = typeof getBillLineUnitIqd === 'function' ? getBillLineUnitIqd(item) : ((Number(item.price) || 0));
                total += unitIqdLine * lineQty;
                const matchKey = (typeof getCartLineMatchPrice === 'function' ? getCartLineMatchPrice(item) : (Number(item.price) || 0));
                const key = item.isManualItem
                    ? ('manual_' + String(item.name || '').trim() + '_' + matchKey + '_' + (item.note || '') + '_' + (item.saleUnit || 'piece') + '_' + (item.isGift ? 'gift' : 'normal') + '_' + (item.recipeSaleMode || 'auto'))
                    : (item.id + '_' + (item.note || '') + '_' + matchKey + '_' + (item.saleUnit || 'piece') + '_' + (item.isGift ? 'gift' : 'normal') + '_' + (item.recipeSaleMode || 'auto'));
                if (!grouped[key]) { grouped[key] = Object.assign({}, item, { count: 0, subtotal: 0, _key: key, isGift: !!item.isGift }); }
                grouped[key].count += lineQty;
                grouped[key].subtotal += unitIqdLine * lineQty;
                uniqueIds.add(item.id);
            });
            const productMap = new Map();
            uniqueIds.forEach(function (uid) {
                var p = (typeof posGetProductById === 'function') ? posGetProductById(uid) : null;
                if (!p && db.products) {
                    p = db.products.find(function (x) { return String(x.id) === String(uid); });
                }
                if (p) productMap.set(String(p.id), p);
            });
            return { grouped: grouped, productMap: productMap, total: total };
        }

        function stampPosMobileCartLabels(root) {
            if (typeof window.isTxnMobileViewport !== 'function' || !window.isTxnMobileViewport() || !root) return;
            root.querySelectorAll('.returns-row-disc').forEach(function (el) {
                el.setAttribute('data-txn-label', 'داشکاندن');
            });
            root.querySelectorAll('.returns-row-price').forEach(function (el) {
                el.setAttribute('data-txn-label', 'نرخ');
            });
            root.querySelectorAll('.returns-row-qty-wrap input[type="number"]').forEach(function (el) {
                el.setAttribute('data-txn-label', 'ژمارە');
            });
        }

        function buildPosCartRowHtml(g, originalProd, table) {
            function saleUnitLabel(u, p) {
                if (u === 'carton') {
                    const f = getProductUnitFactors(p);
                    return getProductUnitLabel(p, 'carton') + (f.piecesPerCarton > 1 ? ` (${f.piecesPerCarton} د)` : '');
                }
                if (u === 'pack') {
                    const f = getProductUnitFactors(p);
                    return getProductUnitLabel(p, 'pack') + (f.piecesPerPack > 1 ? ` (${f.piecesPerPack} د)` : '');
                }
                return getProductUnitLabel(p, 'piece');
            }
            function idParam(id) { return (typeof id === 'string') ? ("'" + String(id).replace(/\\/g, '\\\\').replace(/'/g, "\\'") + "'") : String(id); }
            const canEditPrice = typeof hasPermission === 'function' && hasPermission('pos_price');
            const idP = idParam(g.id);
            const noteEsc = (g.note || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'");
            const saleUnitEsc = (g.saleUnit || 'piece').replace(/'/g, "\\'");
            const unitIcon = (typeof window.getPosUnitIconHtml === 'function')
                ? window.getPosUnitIconHtml(g.saleUnit || 'piece', true)
                : '';
            const rowTitle = saleUnitLabel(g.saleUnit || 'piece', originalProd || g);
            const matchP = typeof getCartLineMatchPrice === 'function' ? getCartLineMatchPrice(g) : (Number(g.price) || 0);
            const unitIqd = typeof getBillLineUnitIqd === 'function' ? getBillLineUnitIqd(g) : (Number(g.price) || 0);
            const rowIdBase = `pos_row_${g.id}_${(g.saleUnit || 'piece').replace(/[^a-zA-Z0-9]/g, '')}_${String(matchP).replace(/[^a-zA-Z0-9]/g, '_')}`;
            const isUsdMode = (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD');
            const usdRatePerOne = (typeof getUsdRatePerOne === 'function') ? getUsdRatePerOne() : 0;
            const origPrice = originalProd ? (typeof getPriceForUnit === 'function' ? getPriceForUnit(originalProd, g.saleUnit || 'piece', table) : originalProd.price) : g.price;
            const discountIqd = Math.max(0, origPrice - unitIqd);
            const discountFieldVal = (isUsdMode && usdRatePerOne > 0)
                ? String(parseFloat((discountIqd / usdRatePerOne).toFixed(6)))
                : String(Math.round(discountIqd));
            const isWeight = isWeightProduct(originalProd || g);
            const qtyStep = '0.001';
            const qtyDelta = isWeight ? 0.25 : 1;
            const qtyVal = formatQtyForInput(g.count);
            const kiloQtyChips = renderKiloQtyPresetChips(originalProd || g, function(v) {
                return "commitCartItemQty(" + idP + ", '" + noteEsc + "', " + matchP + ", '" + saleUnitEsc + "', " + v + ")";
            });
            const rowUsdMoney = (typeof resolveCartLineMoney === 'function') ? resolveCartLineMoney(g) : null;
            const usdDisplayVal = (rowUsdMoney && rowUsdMoney.usd > 0)
                ? rowUsdMoney.usd
                : ((isUsdMode && usdRatePerOne > 0) ? ((Number(g.price) || 0) / usdRatePerOne) : 0);
            const usdValStr = isUsdMode ? String(parseFloat(Number(usdDisplayVal || 0).toFixed(6))) : '';
            const iqdHint = '';
            const priceChangeFn = isUsdMode ? 'commitCartItemUnitUsd' : 'commitCartItemPrice';
            const isGiftRow = !!g.isGift;
            const giftLbl = (typeof t === 'function') ? t('pos_gift_label') : 'دیاری';
            const priceInputClass = (canEditPrice && !isGiftRow) ? 'pos-cart-input returns-row-price' : 'pos-cart-input returns-row-price pos-cart-input-locked';
            const priceChangeAttr = (canEditPrice && !isGiftRow)
                ? (' onkeydown="if(event.key===\'Enter\') this.blur();" onchange="' + priceChangeFn + '(' + idP + ', \'' + noteEsc + '\', ' + matchP + ', \'' + saleUnitEsc + '\', this.value)" onfocus="this.select()"')
                : (' readonly tabindex="-1" title="' + (isGiftRow ? giftLbl : (isUsdMode ? '$ (USD)' : 'نرخ')) + '"');
            const priceInputHtml = isGiftRow
                ? ('<span class="pos-cart-gift-price" title="' + escapeHtml(giftLbl) + ' — ' + escapeHtml((typeof t === 'function') ? t('pos_gift_free_hint') : 'بەلاش فرۆتن') + '"><i class="fas fa-gift"></i> ' + escapeHtml(giftLbl) + '</span>')
                : ('<input type="number" id="' + rowIdBase + '_price" class="' + priceInputClass + '" min="0" step="' + (isUsdMode ? '0.000001' : '0.01') + '" value="' + (isUsdMode ? usdValStr : String(Math.round(Number(g.price) || 0))) + '"' + priceChangeAttr + ' title="' + (isUsdMode ? '$ (USD)' : 'نرخ') + '" />' + (isUsdMode ? iqdHint : ''));

            let tkBtn = '';
            if (canEditPrice && originalProd && !isGiftRow) {
                let twPrice = 0;
                if (g.saleUnit === 'carton' && originalProd.takeawayPrice_carton) twPrice = Number(originalProd.takeawayPrice_carton);
                else if (g.saleUnit === 'pack' && originalProd.takeawayPrice_pack) twPrice = Number(originalProd.takeawayPrice_pack);
                else if (originalProd.takeawayPrice) twPrice = Number(originalProd.takeawayPrice);

                if (twPrice > 0) {
                    const tkTitleToTk = 'گۆڕین بۆ جوملە';
                    const tkIcon = 'fas fa-box';
                    let normalPrice = typeof getPriceForUnit === 'function' ? getPriceForUnit(originalProd, g.saleUnit || 'piece', null) : Number(originalProd.price);
                    var twArg = twPrice;
                    var normalArg = normalPrice;
                    if (isUsdMode && usdRatePerOne > 0) {
                        twArg = parseFloat((twPrice / usdRatePerOne).toFixed(6));
                        normalArg = parseFloat((normalPrice / usdRatePerOne).toFixed(6));
                    }
                    if (Math.round(Number(g.price) || 0) !== Math.round(twPrice)) {
                        tkBtn = `<button type="button" class="qty-btn no-print" style="background:var(--warning); color:white; border:none; margin-right:4px; margin-left:4px; padding:0 8px; border-radius:4px; cursor:pointer;" onclick="${priceChangeFn}(${idP}, '${noteEsc}', ${matchP}, '${saleUnitEsc}', ${twArg})" title="${tkTitleToTk}"><i class="${tkIcon}"></i></button>`;
                    } else if (normalPrice > 0 && Math.round(Number(g.price) || 0) !== Math.round(normalPrice)) {
                        tkBtn = `<button type="button" class="qty-btn no-print" style="background:var(--success); color:white; border:none; margin-right:4px; margin-left:4px; padding:0 8px; border-radius:4px; cursor:pointer;" onclick="${priceChangeFn}(${idP}, '${noteEsc}', ${matchP}, '${saleUnitEsc}', ${normalArg})" title="گۆڕین بۆ ئاسایی"><i class="fas fa-store"></i></button>`;
                    }
                }
            }

            let giftBtn = '';
            if (db.settings && db.settings.enableGift !== false) {
                const isGiftNow = !!g.isGift;
                giftBtn = `<button type="button" class="qty-btn no-print pos-gift-toggle${isGiftNow ? ' is-active' : ''}" style="background:${isGiftNow ? '#ec4899' : 'var(--input-bg)'}; color:${isGiftNow ? 'white' : '#ec4899'}; border:1px solid #ec4899; margin-right:4px; padding:0 8px; border-radius:4px; cursor:pointer;" onclick="toggleCartItemGift(${idP}, '${noteEsc}', ${matchP}, '${saleUnitEsc}', ${isGiftNow})" title="${isGiftNow ? ((typeof t === 'function') ? t('pos_gift_remove') : 'لابردنا دیاریێ') : ((typeof t === 'function') ? t('pos_gift_make') : 'کرنە دیاری')}"><i class="fas fa-gift"></i></button>`;
            }

            let recipeModeHtml = '';
            let recipeModeSuffix = '';
            if (originalProd && typeof productHasRecipe === 'function' && productHasRecipe(originalProd.id)) {
                var curRecipeMode = typeof normalizeRecipeSaleMode === 'function'
                    ? normalizeRecipeSaleMode(g.recipeSaleMode || originalProd.recipe_sale_mode)
                    : 'auto';
                recipeModeSuffix = ' <span style="font-size:0.82em;color:#64748b;">(' + (typeof getRecipeSaleModeLabel === 'function' ? getRecipeSaleModeLabel(curRecipeMode) : curRecipeMode) + ')</span>';
                var rDirect = curRecipeMode === 'direct';
                var rMake = curRecipeMode === 'manufacture';
                var rAuto = curRecipeMode === 'auto';
                recipeModeHtml = '<span class="recipe-sale-mode-btns no-print" style="display:inline-flex; gap:3px; margin-left:4px;">' +
                    '<button type="button" class="qty-btn" style="font-size:10px; padding:0 6px; border-radius:4px; ' + (rDirect ? 'background:var(--brand);color:#fff;' : '') + '" onclick="commitCartRecipeSaleMode(' + idP + ', \'' + noteEsc + '\', ' + matchP + ', \'' + saleUnitEsc + '\', \'direct\', ' + !!g.isGift + ')" title="راستەوخو">ر</button>' +
                    '<button type="button" class="qty-btn" style="font-size:10px; padding:0 6px; border-radius:4px; ' + (rMake ? 'background:var(--success);color:#fff;' : '') + '" onclick="commitCartRecipeSaleMode(' + idP + ', \'' + noteEsc + '\', ' + matchP + ', \'' + saleUnitEsc + '\', \'manufacture\', ' + !!g.isGift + ')" title="دروستکردن">د</button>' +
                    '<button type="button" class="qty-btn" style="font-size:10px; padding:0 6px; border-radius:4px; ' + (rAuto ? 'background:var(--warning);color:#fff;' : '') + '" onclick="commitCartRecipeSaleMode(' + idP + ', \'' + noteEsc + '\', ' + matchP + ', \'' + saleUnitEsc + '\', \'auto\', ' + !!g.isGift + ')" title="خۆکار">خ</button>' +
                    '</span>';
            }

            var jewelryMetaHtml = '';
            var jewLabel = (typeof jewelryMetaLabel === 'function') ? jewelryMetaLabel(g) : '';
            if (!jewLabel && originalProd && (typeof jewelryMetaLabel === 'function')) jewLabel = jewelryMetaLabel(originalProd);
            if (jewLabel) {
                var jewW = (g.jewelry_weight != null ? g.jewelry_weight : g.weight_grams);
                var canEditJewW = (g.jewelry_price_mode === 'by_weight' || (originalProd && originalProd.jewelry_price_mode === 'by_weight'));
                jewelryMetaHtml = ' <span style="font-size:0.78em;color:#a67c00;font-weight:600;">[' + escapeHtml(jewLabel) + ']</span>';
                if (canEditJewW) {
                    jewelryMetaHtml += ' <button type="button" class="qty-btn no-print" style="font-size:10px;padding:0 6px;border-radius:4px;background:#c9a227;color:#1a1508;border:none;cursor:pointer;" title="گوهۆڕینا کێشێ" onclick="if(typeof editCartJewelryWeight===\'function\')editCartJewelryWeight(' + idP + ', \'' + noteEsc + '\', ' + matchP + ', \'' + saleUnitEsc + '\', \'' + String(jewW || '').replace(/'/g, '') + '\')"><i class="fas fa-weight-hanging"></i></button>';
                }
            }

            const discInputClass = (canEditPrice && !isGiftRow) ? 'pos-cart-input returns-row-disc' : 'pos-cart-input returns-row-disc pos-cart-input-locked';
            const discChangeAttr = (canEditPrice && !isGiftRow)
                ? (' onkeydown="if(event.key===\'Enter\') this.blur();" onchange="commitCartItemDiscount(' + idP + ', \'' + noteEsc + '\', ' + matchP + ', \'' + saleUnitEsc + '\', this.value)" onfocus="this.select()"')
                : ' readonly tabindex="-1"';

            return `
                <div class="bill-row returns-cart-row returns-cart-row-slim${isGiftRow ? ' pos-cart-row--gift' : ''}" data-pos-cart-pid="${escapeHtml(String(g.id))}" data-pos-cart-unit="${escapeHtml(String(g.saleUnit || 'piece'))}" data-pos-cart-gift="${isGiftRow ? '1' : '0'}">
                    <span class="returns-row-name" title="${escapeHtml(g.name || (originalProd ? originalProd.barcode : '') || 'ئایتم')}${g.note ? ' | ' + escapeHtml(g.note) : ''}${jewLabel ? ' | ' + escapeHtml(jewLabel) : ''}">${unitIcon}${escapeHtml(g.name || (originalProd ? originalProd.barcode : '') || 'ئایتم')} (${rowTitle})${jewelryMetaHtml}${recipeModeSuffix}${isGiftRow ? ' <span class="pos-gift-badge">(' + escapeHtml(giftLbl) + ')</span>' : ''}${recipeModeHtml}</span>
                    <input type="number" id="${rowIdBase}_disc" class="${discInputClass}" min="0" step="${isUsdMode ? '0.000001' : '0.01'}" value="${isGiftRow ? 0 : discountFieldVal}"${discChangeAttr} title="داشکاندن">
                    ${priceInputHtml}
                    <div class="qty-control no-print returns-row-qty-wrap" data-pos-cart-pid="${escapeHtml(String(g.id))}" data-pos-cart-note="${escapeHtml(g.note || '')}" data-pos-cart-match="${matchP}" data-pos-cart-unit="${escapeHtml(String(g.saleUnit || 'piece'))}" data-pos-cart-gift="${isGiftRow ? '1' : '0'}" data-pos-cart-delta="${qtyDelta}">
                        <button type="button" class="qty-btn remove" onclick="stepPosCartQty(this,-1)"><i class="fas fa-minus"></i></button>
                        <input type="number" id="${rowIdBase}_qty" class="pos-cart-input" value="${qtyVal}" min="0" step="${qtyStep}" inputmode="decimal" readonly title="دەستکاریکرنا ژمارە" onfocus="this.select()" onclick="openPosCartQtyPrompt(${idP}, '${noteEsc}', ${matchP}, '${saleUnitEsc}', this.value, ${!!g.isGift}); return false;" onkeydown="if(event.key==='Enter') this.blur();" onchange="commitCartItemQty(${idP}, '${noteEsc}', ${matchP}, '${saleUnitEsc}', this.value, ${!!g.isGift})">
                        <button type="button" class="qty-btn add" onclick="stepPosCartQty(this,1)"><i class="fas fa-plus"></i></button>
                        ${kiloQtyChips}
                    </div>
                    <span class="returns-row-total${isGiftRow ? ' pos-line-total--gift' : ''}">
                        ${formatPosLineSubtotal(g.subtotal, g, g.count)}
                    </span>
                    <div style="display:flex; gap:4px;">
                        ${tkBtn}
                        ${giftBtn}
                        <button type="button" class="qty-btn delete-btn returns-row-del no-print" onclick="removeGroupFromBill(${idP}, '${noteEsc}', ${matchP}, '${saleUnitEsc}', ${!!g.isGift})" title="حذف السطر"><i class="fas fa-trash-alt"></i></button>
                    </div>
                </div>`;
        }
        window.buildPosCartRowHtml = buildPosCartRowHtml;

        function appendPosCartLineFast(productId, saleUnit) {
            var container = document.getElementById('bill-rows');
            var table = (typeof findActivePosTable === 'function') ? findActivePosTable() : null;
            if (!container || !table || !Array.isArray(table.items) || !table.items.length) return false;
            var state = groupPosCartItems(table);
            var groups = Object.values(state.grouped);
            // If the container was showing empty state or has fewer rows than groups.length - 1,
            // fast append would leave previous items unrendered. Fall back to full renderBill!
            var currentRows = container.querySelectorAll('.bill-row');
            if (container.querySelector('.pos-empty-state') || (groups.length > 1 && currentRows.length < groups.length - 1)) {
                return false;
            }
            var match = null;
            for (var i = 0; i < groups.length; i++) {
                var g = groups[i];
                if (String(g.id) !== String(productId)) continue;
                if (saleUnit && (g.saleUnit || 'piece') !== saleUnit) continue;
                var already = false;
                var existing = container.querySelectorAll('.bill-row[data-pos-cart-pid="' + String(g.id) + '"]');
                for (var ei = 0; ei < existing.length; ei++) {
                    if ((existing[ei].getAttribute('data-pos-cart-unit') || 'piece') === (g.saleUnit || 'piece')
                        && (existing[ei].getAttribute('data-pos-cart-gift') === '1') === !!g.isGift) {
                        already = true;
                        break;
                    }
                }
                if (!already) { match = g; break; }
            }
            if (!match) return false;
            var empty = container.querySelector('.pos-empty-state');
            if (empty) empty.remove();
            container.insertAdjacentHTML('beforeend', buildPosCartRowHtml(match, state.productMap.get(String(match.id)), table));
            var newRow = container.lastElementChild;
            if (newRow) stampPosMobileCartLabels(newRow);
            if (typeof updatePosGiftSummaryUi === 'function') updatePosGiftSummaryUi();
            container.scrollTop = container.scrollHeight;
            return true;
        }
        window.appendPosCartLineFast = appendPosCartLineFast;

        function renderBill() {
            // Default Cart System: Ensure there's always an active cart
            if (!(typeof findActivePosTable === 'function' ? findActivePosTable() : null)) {
                ensureDefaultCart();
            }
            
            const table = (typeof findActivePosTable === 'function') ? findActivePosTable() : null;
            const container = document.getElementById('bill-rows');
            if(!table || !container) return; // Safety check to prevent crash
            if (typeof consolidateManualCartLines === 'function') consolidateManualCartLines(table);
            
            let activeFocusId = null;
            let activeFocusStart = null;
            let activeFocusEnd = null;
            if (document.activeElement && document.activeElement.classList.contains('pos-cart-input')) {
                activeFocusId = document.activeElement.id;
                try { activeFocusStart = document.activeElement.selectionStart; activeFocusEnd = document.activeElement.selectionEnd; } catch(e) {}
            }

            // Save Scroll Position
            const scrollPos = container.scrollTop;
            const isAtBottom = (container.scrollHeight - container.scrollTop === container.clientHeight);

            var groupedState = groupPosCartItems(table);
            const grouped = groupedState.grouped;
            const productMap = groupedState.productMap;

            if (!table.items || !table.items.length) {
                if (typeof clearPosCartDiscount === 'function') clearPosCartDiscount(table);
                var emptyCartTitle = (typeof t === 'function') ? t('pos_empty_cart_title') : 'سەبەتە بەتاڵە';
                var emptyCartHint = (typeof t === 'function') ? t('pos_empty_cart_hint') : 'کاڵایەک لە لیستەکە هەڵبژێرە بۆ دەستپێکردن';
                container.innerHTML = '<div class="pos-empty-state pos-empty-cart">' +
                    '<div class="pos-empty-state-icon pos-empty-state-icon--cart"><i class="fas fa-shopping-basket"></i></div>' +
                    '<p class="pos-empty-state-title">' + escapeHtml(emptyCartTitle) + '</p>' +
                    '<p class="pos-empty-state-hint"><i class="fas fa-hand-pointer"></i> ' + escapeHtml(emptyCartHint) + '</p>' +
                    '</div>';
                renderBillTotal();
                if (typeof updatePosGiftSummaryUi === 'function') updatePosGiftSummaryUi();
                var _skipDispEmpty = typeof posSkipCustomerDisplaySync === 'function' && posSkipCustomerDisplaySync();
                if (!_skipDispEmpty && window.customerChannel) {
                    window.customerChannel.postMessage({ type: 'update', items: [], total: 0, table: table.name, timestamp: Date.now() });
                }
                return;
            }

            container.innerHTML = Object.values(grouped).map(function (g) {
                return buildPosCartRowHtml(g, productMap.get(String(g.id)), table);
            }).join('');

            container.querySelectorAll('.bill-row').forEach(function (row) {
                stampPosMobileCartLabels(row);
            });
            
            renderBillTotal();
            if (typeof updatePosGiftSummaryUi === 'function') updatePosGiftSummaryUi();

            // Restore Scroll Position (or scroll to bottom if new item added)
            if(isAtBottom) container.scrollTop = container.scrollHeight;
            else container.scrollTop = scrollPos;
            
            // UPDATE CUSTOMER DISPLAY (skipped on txn-lite weak laptops)
            var _skipDisp = typeof posSkipCustomerDisplaySync === 'function' && posSkipCustomerDisplaySync();
            if (!_skipDisp) {
                var _billTotEl = document.getElementById('bill-total');
                var _totalSync = (_billTotEl && _billTotEl.dataset && _billTotEl.dataset.finalIqd != null)
                    ? _billTotEl.dataset.finalIqd
                    : ((_billTotEl && _billTotEl.innerText) ? String(_billTotEl.innerText).replace(/,/g, '') : '0');
                var _totalUsdSync = (_billTotEl && _billTotEl.dataset && _billTotEl.dataset.finalUsd != null)
                    ? _billTotEl.dataset.finalUsd
                    : '0';
                var _fxSync = (typeof getUsdRatePerOne === 'function') ? getUsdRatePerOne() : 0;
                var groupedVals = Object.values(grouped);
                var tableName = table.name;
                setTimeout(function () {
                    const displayData = {
                        type: 'update',
                        items: groupedVals,
                        total: _totalSync || 0,
                        totalUsd: _totalUsdSync || 0,
                        fxRate: _fxSync,
                        table: tableName,
                        timestamp: Date.now(),
                        icon: getSystemIcon()
                    };
                    if (window.customerChannel) {
                        window.customerChannel.postMessage(displayData);
                    }
                    try { localStorage.setItem('LAPTOP_DUHOK_POS_display_sync', JSON.stringify(displayData)); } catch (_eLs) {}
                    if (displaySyncTimeout) clearTimeout(displaySyncTimeout);
                    var _dispMs = (typeof posCustomerDisplaySyncMs === 'function') ? posCustomerDisplaySyncMs() : 500;
                    displaySyncTimeout = setTimeout(function () {
                        const formDataDisp = new FormData();
                        formDataDisp.append('action', 'update_customer_display');
                        formDataDisp.append('data', JSON.stringify(displayData));
                        fetch('?action=update_customer_display', { method: 'POST', body: formDataDisp }).catch(function () {});
                    }, _dispMs);
                }, 0);
            }
            if (!_skipDisp && db && db.settings && db.settings.language === 'ar') {
                var posView = document.getElementById('view-pos');
                if (posView && typeof localizeHardcodedUiText === 'function') localizeHardcodedUiText(posView);
            }

            if (activeFocusId) {
                setTimeout(() => {
                    const el = document.getElementById(activeFocusId);
                    if (el) { el.focus(); try { el.setSelectionRange(activeFocusStart, activeFocusEnd); } catch(e){} }
                }, 10);
            }
            if (typeof window.updateTxnPeekBar === 'function') window.updateTxnPeekBar('pos');
            if (!_skipDisp && typeof window.bounceTxnSheet === 'function' && table.items && table.items.length) window.bounceTxnSheet('pos');
        }
        
        function editItemPrice(id, currentPrice, note) {
            if(!checkPermission('pos_price', "دەستکاریکرنا بهای")) return;

            const newPrice = prompt("بهایێ نوی بنڤیسە (New Price):", currentPrice);
            if(newPrice === null) return;
            const price = parseFloat(newPrice);
            if(isNaN(price) || price < 0) return alert("بهایێ خەلەتە!");
            
            const table = db.tables.find(t => t.id === activeTableId);
            
            // Check for discount (Security Log)
            const product = db.products.find(function(p) { return String(p.id) === String(id); });
            const originalPrice = product ? product.price : currentPrice;
            let logType = 'manual_price_edit';
            const itemLabel = product ? product.name : id;
            let logDetails = `گۆڕینا نرخێ «${itemLabel}»: ${currentPrice} → ${price}`;

            if (price < originalPrice) {
                logType = 'alert_manual_discount';
                logDetails += ` (کەمتر لە کتڵۆگ: ${originalPrice - price})`;
            }

            table.items.forEach(item => {
                if (String(item.id) !== String(id) || (item.note || '') !== (note || '')) return;
                var m = typeof itemMatchesCartGroup === 'function'
                    ? itemMatchesCartGroup(item, id, note, currentPrice, item.saleUnit || 'piece')
                    : (Number(item.price) === Number(currentPrice));
                if (!m) return;
                item.price = price;
                item.isManualPrice = true;
                if (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD') {
                    var rEd = typeof getPosFrozenFxRatePerOne === 'function' ? getPosFrozenFxRatePerOne(item) : (typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0);
                    if (rEd > 0) {
                        item.bill_unit_usd = (typeof storedIqdToUsdAmount === 'function')
                            ? storedIqdToUsdAmount(price, rEd)
                            : (price / rEd);
                        item.fx_rate_per_one = rEd;
                    }
                }
            });
            scheduleSave();
            logSecurityEvent(logType, logDetails);
            renderBill();
        }

        function commitCartItemDiscount(id, note, currentPrice, saleUnit, newDiscountRaw, isGift = false) {
            if(!checkPermission('pos_price', "دەستکاریکرنا بهای")) return;
            saleUnit = saleUnit || 'piece';
            const discount = parseFloat(String(newDiscountRaw || '').replace(/,/g, ''));
            if (isNaN(discount) || discount < 0) return;

            const table = db.tables.find(t => t.id === activeTableId);
            if (!table) return;

            const product = db.products.find(p => String(p.id) === String(id));
            const originalPrice = product ? (typeof getPriceForUnit === 'function' ? getPriceForUnit(product, saleUnit, table) : product.price) : currentPrice;
            var rDisc = typeof getPosFrozenFxRatePerOne === 'function' ? getPosFrozenFxRatePerOne(null) : (typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0);
            var discountIqd = discount;
            var usdDisc = typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD';
            if (usdDisc && rDisc > 0) {
                discountIqd = (typeof usdAmountToStoredIqd === 'function')
                    ? usdAmountToStoredIqd(discount, rDisc)
                    : (discount * rDisc);
            }
            const newPrice = Math.max(0, originalPrice - discountIqd);

            let changed = false;
            table.items.forEach(function(item) {
                const match = typeof itemMatchesCartGroup === 'function'
                    ? itemMatchesCartGroup(item, id, note, currentPrice, saleUnit, isGift)
                    : (String(item.id) === String(id) && (item.note || '') === (note || '') && Number(item.price) === Number(currentPrice) && (item.saleUnit || 'piece') === saleUnit);
                if (match) {
                    item.price = newPrice;
                    item.isManualPrice = true;
                    if (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD' && rDisc > 0) {
                        item.bill_unit_usd = (typeof storedIqdToUsdAmount === 'function')
                            ? storedIqdToUsdAmount(newPrice, rDisc)
                            : (newPrice / rDisc);
                        item.fx_rate_per_one = rDisc;
                    }
                    changed = true;
                }
            });

            if (!changed) return;
            scheduleSave();
            const discLabel = product ? product.name : id;
            logSecurityEvent('alert_manual_discount', `داشکاندن لە POS: ${discountIqd} بۆ «${discLabel}» (نرخێ نوێ: ${newPrice})`);
            renderBill();
        }

        function commitCartItemPrice(id, note, currentPrice, saleUnit, newPriceRaw, isGift = false) {
            if(!checkPermission('pos_price', "دەستکاریکرنا بهای")) return;
            saleUnit = saleUnit || 'piece';
            const price = parseFloat(String(newPriceRaw || '').replace(/,/g, ''));
            if (isNaN(price) || price < 0) return;

            const table = db.tables.find(t => t.id === activeTableId);
            if (!table) return;

            const product = db.products.find(p => String(p.id) === String(id));
            const originalPrice = product
                ? (typeof getPriceForUnit === 'function' ? getPriceForUnit(product, saleUnit, table) : product.price)
                : currentPrice;
            let logType = 'manual_price_edit';
            const itemLabelCp = product ? product.name : id;
            let logDetails = `گۆڕینا نرخێ «${itemLabelCp}»: ${currentPrice} → ${price}`;
            if (price < originalPrice) {
                logType = 'alert_manual_discount';
                logDetails += ` (کەمتر لە کتڵۆگ: ${originalPrice - price})`;
            }

            let changed = false;
            var rCp = typeof getPosFrozenFxRatePerOne === 'function' ? getPosFrozenFxRatePerOne(null) : (typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0);
            table.items.forEach(function(item) {
                const match = typeof itemMatchesCartGroup === 'function'
                    ? itemMatchesCartGroup(item, id, note, currentPrice, saleUnit, isGift)
                    : (String(item.id) === String(id) &&
                        (item.note || '') === (note || '') &&
                        Number(item.price) === Number(currentPrice) &&
                        (item.saleUnit || 'piece') === saleUnit);
                if (match) {
                    item.price = price;
                    item.isManualPrice = true;
                    if (typeof getActiveCurrency === 'function' && getActiveCurrency() === 'USD' && rCp > 0) {
                        item.bill_unit_usd = (typeof storedIqdToUsdAmount === 'function')
                            ? storedIqdToUsdAmount(price, rCp)
                            : (price / rCp);
                        item.fx_rate_per_one = rCp;
                    }
                    changed = true;
                }
            });

            if (!changed) return;
            scheduleSave();
            logSecurityEvent(logType, logDetails);
            renderBill();
        }

        function commitCartItemUnitUsd(id, note, currentBillUsd, saleUnit, newUsdRaw) {
            if(!checkPermission('pos_price', "دەستکاریکرنا بهای")) return;
            saleUnit = saleUnit || 'piece';
            const newUsd = parseFloat(String(newUsdRaw || '').replace(/,/g, ''));
            if (isNaN(newUsd) || newUsd < 0) return;

            const table = db.tables.find(t => t.id === activeTableId);
            if (!table) return;

            const r = typeof getPosFrozenFxRatePerOne === 'function' ? getPosFrozenFxRatePerOne(null) : (typeof getUsdRatePerOne === 'function' ? getUsdRatePerOne() : 0);
            if (r <= 0) return;

            let changed = false;
            table.items.forEach(function(item) {
                const match = typeof itemMatchesCartGroup === 'function'
                    ? itemMatchesCartGroup(item, id, note, currentBillUsd, saleUnit)
                    : (String(item.id) === String(id) &&
                        (item.note || '') === (note || '') &&
                        Number(item.bill_unit_usd != null ? item.bill_unit_usd : item.price) === Number(currentBillUsd) &&
                        (item.saleUnit || 'piece') === saleUnit);
                if (match) {
                    var lineRate = typeof getPosFrozenFxRatePerOne === 'function' ? getPosFrozenFxRatePerOne(item) : r;
                    item.isManualPrice = true;
                    item.bill_unit_usd = (typeof roundUsdCents === 'function') ? roundUsdCents(newUsd) : newUsd;
                    item.price = (typeof usdAmountToStoredIqd === 'function')
                        ? usdAmountToStoredIqd(item.bill_unit_usd, lineRate)
                        : Math.round(item.bill_unit_usd * lineRate);
                    item.fx_rate_per_one = lineRate;
                    changed = true;
                }
            });

            if (!changed) return;
            scheduleSave();
            const usdProd = db.products.find(function(p) { return String(p.id) === String(id); });
            logSecurityEvent('manual_price_edit', `گۆڕینا نرخێ USD بۆ «${usdProd ? usdProd.name : id}» → ${newUsd}`);
            renderBill();
        }
        try { window.commitCartItemUnitUsd = commitCartItemUnitUsd; } catch (_wUsd) {}

        window.toggleCartItemGift = function(prodId, note, price, saleUnit, isGiftNow) {
            if (window._posCartOperationLock) return;
            saleUnit = saleUnit || 'piece';
            const table = db.tables.find(t => t.id === activeTableId);
            if (!table || !Array.isArray(table.items)) return;

            // Cart stores one entry per piece; UI groups them — gift must flip the whole group
            // so grand total (IQD/USD) drops to 0 for that line, not only the first piece.
            var becomingGift = !isGiftNow;
            var changed = 0;
            table.items.forEach(function(item) {
                var match = typeof itemMatchesCartGroup === 'function'
                    ? itemMatchesCartGroup(item, prodId, note, price, saleUnit, isGiftNow)
                    : (String(item.id) === String(prodId) &&
                        (item.note || '') === (note || '') &&
                        Number(item.price) === Number(price) &&
                        (item.saleUnit || 'piece') === saleUnit &&
                        !!item.isGift === !!isGiftNow);
                if (!match) return;
                item.isGift = becomingGift;
                changed += 1;
            });

            if (changed > 0) {
                // After gift: discount stays on paid lines only (never eats into gift / goes negative)
                if (typeof clampPosCartManualDiscount === 'function') clampPosCartManualDiscount(table);
                scheduleSave();
                if (typeof renderBill === 'function') renderBill();
                else if (typeof renderBillTotal === 'function') renderBillTotal();
                if (typeof showToast === 'function' && becomingGift) {
                    showToast((typeof t === 'function') ? t('pos_gift_marked') : 'بوو دیاری — بەلاش (٠ لسەر کۆیێ گشتی)', 'info');
                }
            }
        };

        function getPosGiftSummary(table) {
            table = table || (db && db.tables ? db.tables.find(function(t) { return t.id === activeTableId; }) : null);
            var lines = 0;
            var totalQty = 0;
            var value = 0;
            var items = [];
            if (!table || !Array.isArray(table.items)) return { lines: 0, totalQty: 0, value: 0, items: items };
            var byKey = {};
            table.items.forEach(function(it) {
                if (!it || !it.isGift) return;
                var q = typeof getItemQty === 'function' ? getItemQty(it) : (Number(it.qty || it.count) || 1);
                var unitIqd = Number(it.price) || 0;
                value += unitIqd * q;
                totalQty += q;
                var key = String(it.id) + '|' + (it.saleUnit || 'piece') + '|' + (it.name || '');
                if (!byKey[key]) {
                    byKey[key] = { name: it.name || 'ئایتم', qty: 0, unit: it.saleUnit || 'piece', value: 0 };
                    lines += 1;
                }
                byKey[key].qty += q;
                byKey[key].value += unitIqd * q;
            });
            items = Object.keys(byKey).map(function(k) { return byKey[k]; });
            return { lines: lines, totalQty: totalQty, value: value, items: items };
        }

        function updatePosGiftSummaryUi() {
            var box = document.getElementById('pos-gift-summary');
            var textEl = document.getElementById('pos-gift-summary-text');
            var detailEl = document.getElementById('pos-gift-summary-detail');
            if (!box || !textEl) return;
            if (db && db.settings && db.settings.enableGift === false) {
                box.classList.add('is-hidden');
                return;
            }
            var sum = getPosGiftSummary();
            if (!sum.lines) {
                box.classList.add('is-hidden');
                textEl.textContent = '';
                if (detailEl) detailEl.textContent = '';
                return;
            }
            box.classList.remove('is-hidden');
            var qtyStr = (typeof formatQtyForInput === 'function') ? formatQtyForInput(sum.totalQty, null) : String(sum.totalQty);
            var valStr = (typeof formatCurrency === 'function') ? formatCurrency(sum.value) : String(Math.round(sum.value || 0));
            textEl.textContent = sum.lines + ' جۆر · ' + qtyStr + ' دانە · ' + valStr;
            if (detailEl) {
                detailEl.textContent = sum.items.map(function(it) {
                    var q = (typeof formatQtyForInput === 'function') ? formatQtyForInput(it.qty, null) : String(it.qty);
                    return (it.name || '') + ' × ' + q;
                }).join(' · ');
            }
        }
        window.updatePosGiftSummaryUi = updatePosGiftSummaryUi;
        window.getPosGiftSummary = getPosGiftSummary;

        window.commitCartRecipeSaleMode = function(prodId, note, price, saleUnit, mode, isGift) {
            if (window._posCartOperationLock) return;
            var table = (typeof findActivePosTable === 'function') ? findActivePosTable() : db.tables.find(function(t) { return t.id === activeTableId; });
            if (!table || !Array.isArray(table.items)) return;
            var nextMode = typeof normalizeRecipeSaleMode === 'function' ? normalizeRecipeSaleMode(mode) : 'auto';
            table.items.forEach(function(item) {
                var match = typeof itemMatchesCartGroup === 'function'
                    ? itemMatchesCartGroup(item, prodId, note, price, saleUnit, isGift)
                    : (String(item.id) === String(prodId) &&
                        (item.note || '') === (note || '') &&
                        Number(item.price) === Number(price) &&
                        (item.saleUnit || 'piece') === saleUnit);
                if (match) item.recipeSaleMode = nextMode;
            });
            lastTableState = '';
            if (typeof onCartChanged === 'function') onCartChanged({ fast: true, productId: prodId });
        };

        window.stepPosCartQty = function (btn, dir) {
            var wrap = btn && btn.closest ? btn.closest('.returns-row-qty-wrap') : null;
            if (!wrap) return;
            var input = wrap.querySelector('input.pos-cart-input');
            var delta = parseFloat(wrap.getAttribute('data-pos-cart-delta'));
            if (!(delta > 0)) delta = 1;
            var cur = parseFloat(input && input.value);
            if (!isFinite(cur)) cur = 0;
            var next = Math.max(0, cur + (Number(dir) < 0 ? -delta : delta));
            var pid = wrap.getAttribute('data-pos-cart-pid');
            var note = wrap.getAttribute('data-pos-cart-note') || '';
            var match = parseFloat(wrap.getAttribute('data-pos-cart-match'));
            var unit = wrap.getAttribute('data-pos-cart-unit') || 'piece';
            var gift = wrap.getAttribute('data-pos-cart-gift') === '1';
            if (typeof commitCartItemQty === 'function') commitCartItemQty(pid, note, match, unit, next, gift);
            if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('pos', { clear: false, delay: 30 });
        };

        function commitCartItemQty(prodId, note, price, saleUnit, newQtyRaw, isGift = false) {
            if (window._posCartOperationLock) return;
            saleUnit = saleUnit || 'piece';
            const table = db.tables.find(t => t.id === activeTableId);
            if (!table) return;

            const matches = table.items.filter(function(item) {
                return typeof itemMatchesCartGroup === 'function'
                    ? itemMatchesCartGroup(item, prodId, note, price, saleUnit, isGift)
                    : (String(item.id) === String(prodId) &&
                        (item.note || '') === (note || '') &&
                        Number(item.price) === Number(price) &&
                        (item.saleUnit || 'piece') === saleUnit);
            });
            const currentQty = matches.length;
            var prod = db.products.find(function(p) { return String(p.id) === String(prodId); }) || matches[0];
            if (currentQty === 0 && prod && isWeightProduct(prod)) {
                saleUnit = 'piece';
                const fallbackMatches = table.items.filter(function(item) {
                    var priceOk = typeof getCartLineMatchPrice === 'function'
                        ? (Number(getCartLineMatchPrice(item)) === Number(price))
                        : (Number(item.price) === Number(price));
                    return String(item.id) === String(prodId) &&
                        (item.note || '') === (note || '') &&
                        priceOk;
                });
                if (fallbackMatches.length) {
                    fallbackMatches.forEach(function(it){ it.saleUnit = 'piece'; });
                } else {
                    return;
                }
            } else if (currentQty === 0) {
                return;
            }
            const resolvedMatches = table.items.filter(function(item) {
                return typeof itemMatchesCartGroup === 'function'
                    ? itemMatchesCartGroup(item, prodId, note, price, saleUnit, isGift)
                    : (String(item.id) === String(prodId) &&
                        (item.note || '') === (note || '') &&
                        Number(item.price) === Number(price) &&
                        (item.saleUnit || 'piece') === saleUnit);
            });
            if (!resolvedMatches.length) return;
            const desiredQty = normalizeQtyForProduct(prod, newQtyRaw);
            if (desiredQty === 0) {
                removeGroupFromBill(prodId, note, price, saleUnit, isGift);
                return;
            }
            if (resolvedMatches[0].isManualItem) {
                window._posCartOperationLock = true;
                try {
                    var primaryManual = resolvedMatches[0];
                    primaryManual.qty = desiredQty;
                    primaryManual.id = buildManualCartLineId(primaryManual.name, primaryManual.price, primaryManual.cost);
                    for (var mi = resolvedMatches.length - 1; mi >= 1; mi--) {
                        table.items.splice(table.items.indexOf(resolvedMatches[mi]), 1);
                    }
                    lastTableState = "";
                    if (typeof saveActivePosTabSnapshot === 'function') saveActivePosTabSnapshot();
                    if (typeof onCartChanged === 'function') onCartChanged({ fast: true, productId: prodId });
                } finally {
                    window._posCartOperationLock = false;
                }
                return;
            }
            if (isWeightProduct(prod)) {
                var primary = resolvedMatches[0];
                var prevQty = getItemQty(primary);
                var delta = desiredQty - prevQty;
                primary.qty = desiredQty;
                primary.count = desiredQty;
                for (var m = resolvedMatches.length - 1; m >= 1; m--) {
                    table.items.splice(table.items.indexOf(resolvedMatches[m]), 1);
                }
                lastTableState = "";
                if (typeof saveActivePosTabSnapshot === 'function') saveActivePosTabSnapshot();
                if (typeof onCartChanged === 'function') onCartChanged({ fast: true, productId: prodId });
                return;
            }
            if (desiredQty === resolvedMatches.length) return;

            // Block increasing qty beyond warehouse / set member stock
            if (desiredQty > resolvedMatches.length) {
                var isNegQty = (db.settings && (db.settings.allowNegativeStock == true || db.settings.allowNegativeStock == 'true' || db.settings.allowNegativeStock == 1));
                var jewelrySetQty = (typeof isJewelrySetProduct === 'function') && isJewelrySetProduct(prod);
                var enforceJew = (typeof jewelryEnforcesStock === 'function' && jewelryEnforcesStock(prod));
                if (!isNegQty && (jewelrySetQty || (prod && prod.trackStock) || enforceJew)) {
                    var remaining = 0;
                    if (jewelrySetQty && typeof jewelrySetAvailableCompleteSets === 'function') {
                        remaining = jewelrySetAvailableCompleteSets(prod);
                    } else if (typeof getPosAvailablePieces === 'function') {
                        remaining = getPosAvailablePieces(prod);
                    }
                    var currentInCart = resolvedMatches.length;
                    var maxTotal = Math.max(0, Math.floor(Number(remaining) || 0)) + currentInCart;
                    if (desiredQty > maxTotal) {
                        if (typeof showToast === 'function') {
                            if (jewelrySetQty) showToast('کۆگەی پارچەکانی سێت بەس نینە — زۆرترین: ' + maxTotal, 'error');
                            else showToast((typeof posSaleStockToastMessage === 'function')
                                ? posSaleStockToastMessage(prod, saleUnit || 'piece', remaining)
                                : ('کۆگە بەس نینە — زۆرترین: ' + maxTotal), 'error');
                        }
                        return;
                    }
                }
            }

            window._posCartOperationLock = true;
            try {
                if (desiredQty > resolvedMatches.length) {
                    const template = resolvedMatches[resolvedMatches.length - 1];
                    const diff = desiredQty - resolvedMatches.length;
                    for (let i = 0; i < diff; i++) {
                        const cloned = { ...template, billId: Date.now() + i };
                        table.items.push(cloned);
                    }
                } else {
                    const toRemove = resolvedMatches.length - desiredQty;
                    let removed = 0;
                    for (let i = table.items.length - 1; i >= 0 && removed < toRemove; i--) {
                        const item = table.items[i];
                        const match = typeof itemMatchesCartGroup === 'function'
                            ? itemMatchesCartGroup(item, prodId, note, price, saleUnit, isGift)
                            : (String(item.id) === String(prodId) &&
                                (item.note || '') === (note || '') &&
                                Number(item.price) === Number(price) &&
                                (item.saleUnit || 'piece') === saleUnit &&
                                !!item.isGift === !!isGift);
                        if (!match) continue;

                        table.items.splice(i, 1);
                        removed++;
                    }
                }

                lastTableState = "";
                if (typeof saveActivePosTabSnapshot === 'function') saveActivePosTabSnapshot();
                if (prod && table && typeof inventoryFifoSaleUnitCost === 'function') {
                    var reservedRestamp = 0;
                    for (var rsi = 0; rsi < table.items.length; rsi++) {
                        var rline = table.items[rsi];
                        if (!rline || rline.isManualItem || Number(rline.id) !== Number(prod.id)) continue;
                        var fifoC = inventoryFifoSaleUnitCost(prod, rline, {
                            remainingQty: parseFloat(prod.qty) || 0,
                            reservedPieces: reservedRestamp
                        });
                        if (fifoC != null && isFinite(Number(fifoC))) {
                            rline.cost = (typeof roundMoney === 'function') ? roundMoney(fifoC) : fifoC;
                        }
                        var rMult = (typeof piecesInSaleUnit === 'function') ? piecesInSaleUnit(prod, rline.saleUnit || 'piece') : 1;
                        var rQ = (typeof getSaleLineQty === 'function') ? getSaleLineQty(rline) : 1;
                        reservedRestamp += rMult * rQ;
                    }
                }
                if (typeof onCartChanged === 'function') onCartChanged({ fast: true, productId: prodId });
            } finally {
                window._posCartOperationLock = false;
            }
        }

        // --- UPDATED DISCOUNT LOGIC (PERCENTAGE ONLY) ---
        function addDiscount5() {
            if(!checkPermission('pos_discount', "داشکاندن")) return;

            const input = document.getElementById('pos-discount');
            if(!input) return;
            let current = parseFloat(input.value) || 0;
            if(current + 5 <= 100) {
                input.value = current + 5;
                renderBillTotal();
            }
        }

        function clearDiscount() {
            const input = document.getElementById('pos-discount');
            if(input) input.value = '';
            renderBillTotal();
        }
        
        function clearManualDiscount() {
            const table = db.tables.find(t => t.id === activeTableId);
            if(table) {
                delete table.manualDiscount;
                var pd = document.getElementById('pos-discount');
                if (pd) pd.placeholder = '0';
            }
        }

        /** Clear bill discount when cart is emptied (new customer must not inherit previous discount). */
        function clearPosCartDiscount(table) {
            var t = table || ((typeof findActivePosTable === 'function') ? findActivePosTable() : null)
                || (db && db.tables ? db.tables.find(function(x) { return x.id === activeTableId; }) : null);
            if (t) {
                delete t.manualDiscount;
            }
            var pd = document.getElementById('pos-discount');
            if (pd) {
                pd.value = '';
                pd.placeholder = '0';
            }
            try {
                if (typeof posTabs !== 'undefined' && Array.isArray(posTabs) && typeof activePosTabIndex === 'number' && posTabs[activePosTabIndex]) {
                    posTabs[activePosTabIndex].manualDiscount = null;
                    posTabs[activePosTabIndex].discountInput = '';
                }
            } catch (eTab) {}
        }
        window.clearPosCartDiscount = clearPosCartDiscount;

        var _billTotalEditSubTotal = 0;

        function _billTotalEditInputEl() {
            return document.getElementById('bill-total-edit-input');
        }

        function _billTotalEditFmtAmount(n, isUsd) {
            if (typeof formatPosMoneyDisplay === 'function') {
                return formatPosMoneyDisplay(n, isUsd ? n : undefined);
            }
            var v = parseFloat(n) || 0;
            if (isUsd) {
                if (typeof formatUsdNumberPlain === 'function') return formatUsdNumberPlain(v);
                var cents = Math.round(Math.abs(v) * 100) % 100;
                return cents === 0 ? String(Math.round(v)) : v.toFixed(2);
            }
            return Math.round(v).toLocaleString('en-US');
        }

        function updateBillTotalEditPreview() {
            var inp = _billTotalEditInputEl();
            if (!inp) return;
            var isUsd = !!(window._billTotalEditUsdMode);
            var subDisplay = window._billTotalEditSubDisplay || 0;
            var raw = String(inp.value || '').replace(/,/g, '').trim();
            var newVal = raw === '' ? NaN : parseFloat(raw);
            var discEl = document.getElementById('bill-total-edit-disc');
            if (!discEl) return;
            if (isNaN(newVal)) {
                discEl.textContent = '—';
                return;
            }
            if (!isUsd) {
                subDisplay = Math.round(Number(subDisplay) || 0);
                newVal = Math.round(newVal);
            }
            var disc = subDisplay - newVal;
            discEl.textContent = (disc > 0 ? '−' : (disc < 0 ? '+' : '')) + _billTotalEditFmtAmount(Math.abs(disc), isUsd);
        }

        function nudgeBillTotalEdit(dir) {
            var inp = _billTotalEditInputEl();
            if (!inp) return;
            var isUsd = !!(window._billTotalEditUsdMode);
            var cur = parseFloat(String(inp.value || '').replace(/,/g, ''));
            if (isNaN(cur)) cur = 0;
            var next;
            if (isUsd) {
                next = cur + ((dir < 0) ? -0.01 : 0.01);
                if (next < 0) next = 0;
                inp.value = String(parseFloat(next.toFixed(2)));
            } else {
                var step = 1000;
                try {
                    if (typeof window.isPremiumSettingsFeatureEnabled === 'function'
                        && window.isPremiumSettingsFeatureEnabled('set-enable-money-rounding')) {
                        step = 250;
                    }
                } catch (eSt) {}
                var n = Math.round(cur);
                if (dir > 0) next = Math.ceil((n + 1) / step) * step;
                else next = Math.floor((n - 1) / step) * step;
                if (next < 0) next = 0;
                inp.value = String(next);
            }
            updateBillTotalEditPreview();
            inp.focus();
        }

        function handleBillTotalEditNumpad(key) {
            var inp = _billTotalEditInputEl();
            if (!inp) return;
            var cur = String(inp.value || '');
            if (key === 'C') {
                inp.value = '';
            } else if (key === '.') {
                if (!window._billTotalEditUsdMode) return;
                if (cur.indexOf('.') >= 0) return;
                inp.value = cur ? (cur + '.') : '0.';
            } else if (key === '00') {
                inp.value = cur ? (cur + '00') : '0';
            } else {
                inp.value = cur === '0' ? key : (cur + key);
            }
            updateBillTotalEditPreview();
            inp.focus();
        }

        function openBillTotalEditModal(subTotal, opts) {
            opts = opts || {};
            var source = opts.source || 'pos';
            window._billTotalEditSource = source;
            var modal = document.getElementById('bill-total-edit-modal');
            var inp = _billTotalEditInputEl();
            if (!modal || !inp) return;
            var isUsdMode;
            var subIqd;
            var subUsd = 0;
            var finalIqd;
            var finalUsd = 0;
            var ratePerOne = (typeof getUsdRatePerOne === 'function') ? getUsdRatePerOne() : 0;
            if (source === 'purchase') {
                subIqd = Number(subTotal) || 0;
                finalIqd = subIqd;
                isUsdMode = (typeof isPurchaseUsdMode === 'function') ? isPurchaseUsdMode() : !!(window._billTotalEditUsdMode);
                if (isUsdMode) {
                    subUsd = (typeof purchaseIqdToDisplay === 'function') ? purchaseIqdToDisplay(subIqd) : (ratePerOne > 0 ? (subIqd / ratePerOne) : 0);
                    finalUsd = subUsd;
                }
            } else {
                var table = db && db.tables ? db.tables.find(function(t) { return t.id === activeTableId; }) : null;
                var totals = (table && typeof computePosCartTotals === 'function') ? computePosCartTotals(table) : null;
                subIqd = totals ? totals.subtotalIqd : (Number(subTotal) || 0);
                subUsd = totals ? totals.subtotalUsd : 0;
                finalIqd = totals ? totals.finalIqd : subIqd;
                finalUsd = totals ? totals.finalUsd : 0;
                isUsdMode = (typeof getActiveCurrency === 'function') ? (getActiveCurrency() === 'USD') : !!(db && db.settings && db.settings.currencyMode === 'USD');
            }
            _billTotalEditSubTotal = subIqd;
            window._billTotalEditSubUsd = subUsd;
            var subDisplay = isUsdMode
                ? (subUsd > 0 ? subUsd : (ratePerOne > 0 ? (subIqd / ratePerOne) : 0))
                : subIqd;
            var currentDisplay = isUsdMode
                ? (finalUsd > 0 || finalIqd === 0 ? finalUsd : (ratePerOne > 0 ? (finalIqd / ratePerOne) : 0))
                : finalIqd;
            window._billTotalEditUsdMode = isUsdMode;
            window._billTotalEditSubDisplay = subDisplay;
            window._billTotalEditRate = ratePerOne;
            var subEl = document.getElementById('bill-total-edit-sub');
            var hintEl = document.getElementById('bill-total-edit-currency-hint');
            var textHint = modal.querySelector('.bill-total-edit-hint');
            if (subEl) subEl.textContent = _billTotalEditFmtAmount(subDisplay, isUsdMode);
            if (hintEl) {
                hintEl.textContent = isUsdMode ? '$ USD' : ((typeof t === 'function' ? t('currency') : '') || 'دینار IQD');
            }
            var dotBtn = document.getElementById('bill-total-edit-dot');
            if (dotBtn) dotBtn.style.display = isUsdMode ? '' : 'none';
            inp.value = isUsdMode ? String(parseFloat(Number(currentDisplay || 0).toFixed(2)) || 0) : String(Math.round(currentDisplay) || 0);
            updateBillTotalEditPreview();
            try {
                if (typeof applyI18nSubtree === 'function') applyI18nSubtree(modal);
            } catch (eI18n) {}
            if (textHint && source === 'purchase') {
                var ph = (typeof t === 'function') ? t('purchase_total_edit_hint') : '';
                textHint.textContent = (ph && ph !== 'purchase_total_edit_hint') ? ph : 'کۆیێ گشتی نوێ بنڤیسە — بهایی کڕینێ ل سەر ئایتمان دابەش دبیت';
            }
            modal.style.display = 'flex';
            setTimeout(function() {
                inp.focus();
                if (inp.select) inp.select();
            }, 50);
            var onKey = function(e) {
                if (e.key === 'Escape') {
                    e.preventDefault();
                    closeBillTotalEditModal();
                } else if (e.key === 'Enter') {
                    e.preventDefault();
                    confirmBillTotalEdit();
                }
            };
            modal._billTotalKeyHandler = onKey;
            document.addEventListener('keydown', onKey);
        }

        function closeBillTotalEditModal() {
            var modal = document.getElementById('bill-total-edit-modal');
            if (!modal) return;
            modal.style.display = 'none';
            window._billTotalEditSource = 'pos';
            if (modal._billTotalKeyHandler) {
                document.removeEventListener('keydown', modal._billTotalKeyHandler);
                modal._billTotalKeyHandler = null;
            }
        }

        function confirmBillTotalEdit() {
            if (window._billTotalEditSource === 'purchase') {
                if (typeof confirmPurchaseCartTotalEdit === 'function') confirmPurchaseCartTotalEdit();
                else closeBillTotalEditModal();
                return;
            }
            var inp = _billTotalEditInputEl();
            if (!inp) return;
            var isUsdMode = !!window._billTotalEditUsdMode;
            var ratePerOne = window._billTotalEditRate || 0;
            var subIqd = _billTotalEditSubTotal;
            var subUsd = Number(window._billTotalEditSubUsd) || 0;
            var newTotalInput = parseFloat(String(inp.value || '').replace(/,/g, ''));
            if (isNaN(newTotalInput) || newTotalInput < 0) {
                var inv = (typeof t === 'function') ? t('bill_total_edit_invalid') : 'ژمارە خەلەتە';
                if (typeof showToast === 'function') showToast(inv, 'error');
                else alert(inv);
                return;
            }
            var newTotalIqd;
            if (isUsdMode && subUsd > 0 && subIqd > 0) {
                // Keep gift-excluded basket USD/IQD ratio (do not use warehouse FX alone)
                newTotalIqd = Math.round(subIqd * (newTotalInput / subUsd));
            } else if (isUsdMode && ratePerOne > 0) {
                newTotalIqd = Math.round(newTotalInput * ratePerOne);
            } else {
                newTotalIqd = newTotalInput;
            }
            if (newTotalIqd < 0) newTotalIqd = 0;
            var discount = subIqd - newTotalIqd;
            if (!isFinite(discount) || discount < 0) discount = 0;
            var table = db.tables.find(function(t) { return t.id === activeTableId; });
            if (table) {
                table.manualDiscount = discount;
                if (typeof clampPosCartManualDiscount === 'function') clampPosCartManualDiscount(table);
                logSecurityEvent('manual_discount_total', 'داشکاندنا کۆی گشتی: ' + (isUsdMode ? (newTotalInput + ' USD') : (newTotalIqd + ' IQD')) + ' (داشکاندن: ' + discount + ' IQD؛ دیاری ژ بنەڕەتێ دەرە)');
                scheduleSave();
                if (typeof renderBill === 'function') renderBill();
                else renderBillTotal();
            }
            closeBillTotalEditModal();
        }

        window.openBillTotalEditModal = openBillTotalEditModal;
        window.closeBillTotalEditModal = closeBillTotalEditModal;
        window.handleBillTotalEditNumpad = handleBillTotalEditNumpad;
        window.confirmBillTotalEdit = confirmBillTotalEdit;
        window.updateBillTotalEditPreview = updateBillTotalEditPreview;
        window.nudgeBillTotalEdit = nudgeBillTotalEdit;

        function editBillTotal(subTotal) {
            if(!checkPermission('pos_discount', "دەستکاریکرنا کۆیێ گشتی")) return;
            openBillTotalEditModal(subTotal);
        }

        function renderBillTotal() {
            if (!(typeof findActivePosTable === 'function' ? findActivePosTable() : null)) {
                ensureDefaultCart();
            }
            const table = (typeof findActivePosTable === 'function') ? findActivePosTable() : null;
            if (!table) return;

            if (typeof calculateDebtRemaining === 'function') calculateDebtRemaining();

            const totals = computePosCartTotals(table);
            const total = totals.subtotalIqd;
            const finalTotal = totals.finalIqd;
            const discountAmount = totals.discountIqd;

            const discountDiv = document.querySelector('.bill-footer .cashier-only');
            if (table.manualDiscount !== undefined && table.manualDiscount !== null && discountDiv) {
                const discountInput = document.getElementById('pos-discount');
                if (discountInput) {
                    discountInput.value = '';
                    discountInput.placeholder = 'Fixed';
                }
            }

            const isUSD = typeof getDefaultCurrency === 'function' ? (getDefaultCurrency() === 'USD') : (typeof getActiveCurrency === 'function' ? (getActiveCurrency() === 'USD') : !!(db.settings && db.settings.currencyMode === 'USD'));
            const shopRatePerOne = (typeof getUsdRatePerOne === 'function') ? getUsdRatePerOne() : 0;
            const visualRate100 = (typeof getEffectiveVisualUsdRate100 === 'function')
                ? getEffectiveVisualUsdRate100()
                : ((typeof getBasketVisualRate100Value === 'function' ? getBasketVisualRate100Value() : 0)
                    || (typeof loadBasketVisualRate100Value === 'function' ? loadBasketVisualRate100Value() : 0));
            const visualRatePerOne = visualRate100 / 100;
            const fxRate = visualRatePerOne > 0 ? visualRatePerOne : shopRatePerOne;
            const displayUsdFooter = (fxRate > 0)
                ? ((typeof convertCurrency === 'function') ? convertCurrency(finalTotal, 'IQD', 'USD', fxRate) : (finalTotal / fxRate))
                : (totals.finalUsd > 0 ? totals.finalUsd : 0);

            var dual = (typeof formatDualCurrencyLines === 'function')
                ? formatDualCurrencyLines(finalTotal, displayUsdFooter, fxRate)
                : null;
            var mainLine = dual ? dual.primary : (isUSD ? formatPosMoneyDisplay(finalTotal, displayUsdFooter) : (finalTotal > 0 ? formatPosMoneyDisplay(finalTotal) : '0'));

            var countEl = document.getElementById('pos-cart-item-count-val');
            if (countEl) countEl.textContent = String(Math.round(totals.itemsCount * 1000) / 1000);
            var subRow = document.getElementById('pos-bill-subtotal-row');
            var subVal = document.getElementById('pos-bill-subtotal-val');
            var discRow = document.getElementById('pos-bill-discount-row');
            var discVal = document.getElementById('pos-bill-discount-val');
            if (subRow && subVal) {
                var showBreakdown = finalTotal > 0 && discountAmount > 0;
                subRow.style.display = showBreakdown ? 'flex' : 'none';
                subVal.textContent = formatPosMoneyDisplay(total, isUSD ? totals.subtotalUsd : null);
            }
            if (discRow && discVal) {
                var showDisc = finalTotal > 0 && discountAmount > 0;
                discRow.style.display = showDisc ? 'flex' : 'none';
                discVal.textContent = '−' + formatPosMoneyDisplay(discountAmount, isUSD ? Math.max(0, (Number(totals.subtotalUsd) || 0) - (Number(totals.finalUsd) || 0)) : null);
            }

            var billTotalEl = document.getElementById('bill-total');
            if (!billTotalEl) return;
            billTotalEl.innerHTML = mainLine;
            try {
                billTotalEl.dataset.finalIqd = String(Math.round(finalTotal));
                billTotalEl.dataset.subtotalIqd = String(Math.round(total));
                billTotalEl.dataset.finalUsd = String(displayUsdFooter || 0);
            } catch (e1) {}

            billTotalEl.onclick = function() { editBillTotal(total); };
            billTotalEl.style.cursor = 'pointer';
            billTotalEl.title = 'کلیک بکە بۆ دەستکاریکرنا کۆم';

            var secEl = document.getElementById('pos-bill-total-secondary');
            var rateEl = document.getElementById('pos-bill-fx-rate');
            if (secEl) {
                if (finalTotal > 0 && dual && dual.secondary) {
                    secEl.textContent = dual.secondary;
                    secEl.style.display = '';
                } else {
                    secEl.innerHTML = '';
                    secEl.style.display = 'none';
                }
            }
            if (rateEl) {
                rateEl.textContent = '';
                rateEl.style.display = 'none';
            }

            var sidebarTotal = document.getElementById('bill-sidebar-total');
            if (sidebarTotal) {
                sidebarTotal.innerHTML = dual ? dual.primary : (finalTotal > 0 ? formatPosMoneyDisplay(finalTotal, displayUsdFooter) : '0');
                sidebarTotal.onclick = function() { editBillTotal(total); };
                sidebarTotal.title = 'کلیک بکە بۆ دەستکاریکرنا کۆم';
                sidebarTotal.style.cursor = 'pointer';
            }
            var sideSec = document.getElementById('bill-sidebar-total-secondary');
            if (sideSec) {
                sideSec.textContent = (finalTotal > 0 && dual && dual.secondary) ? dual.secondary : '';
            }
            var sideRate = document.getElementById('bill-sidebar-fx-rate');
            if (sideRate) {
                sideRate.textContent = '';
            }
        }

        function addNoteToItem(prodId, currentNote) {
            const note = prompt("تێبینی بنڤیسە (Add Note):", currentNote);
            if(note === null) return;
            const table = db.tables.find(t => t.id === activeTableId);
            // Update all items in this group
            table.items.forEach(item => {
                if(item.id === prodId && (item.note || '') === currentNote) {
                    item.note = note;
                }
            });
            scheduleSave(); renderBill();
        }

        function removeFromBill(prodId, note, price, saleUnit) {
            if(!checkPermission('pos_delete_item', "ژێبرنا ئایتمی")) return;
            if (window._posCartOperationLock) return;
            saleUnit = saleUnit || 'piece';

            const table = db.tables.find(t => t.id === activeTableId);
            if (!table) return;
            const idx = table.items.findIndex(function(item) {
                return typeof itemMatchesCartGroup === 'function'
                    ? itemMatchesCartGroup(item, prodId, note, price, saleUnit)
                    : (String(item.id) === String(prodId) && (item.note || '') === (note || '') && Number(item.price) === Number(price) && (item.saleUnit || 'piece') === saleUnit);
            });
            if(idx === -1) return;

            window._posCartOperationLock = true;
            try {
                const item = table.items[idx];
                
                logSecurityEvent('void_item', `ژێبرنا ئایتم لە فرۆشتن: «${item.name}» (${item.price}) — مێز: ${table.name}`);
                table.items.splice(idx, 1);
                if (!table.items.length && typeof clearPosCartDiscount === 'function') clearPosCartDiscount(table);
                lastTableState = "";
                if (typeof saveActivePosTabSnapshot === 'function') saveActivePosTabSnapshot();
                if (typeof onCartChanged === 'function') onCartChanged({ fast: true, productId: prodId, saleUnit: saleUnit, removed: true });
            } finally {
                window._posCartOperationLock = false;
            }
        }

        /** Remove all items in the cart that match this group (same id, note, price, saleUnit). Used for trash icon. */
        function removeGroupFromBill(prodId, note, price, saleUnit, isGift = false) {
            if(!checkPermission('pos_delete_item', "ژێبرنا ئایتمی")) return;
            if (window._posCartOperationLock) return;
            saleUnit = saleUnit || 'piece';

            const table = db.tables.find(t => t.id === activeTableId);
            if (!table) return;

            window._posCartOperationLock = true;
            try {
                const before = table.items.length;

                table.items = table.items.filter(function(item) {
                    const match = typeof itemMatchesCartGroup === 'function'
                        ? itemMatchesCartGroup(item, prodId, note, price, saleUnit, isGift)
                        : (String(item.id) === String(prodId) && (item.note || '') === (note || '') && Number(item.price) === Number(price) && (item.saleUnit || 'piece') === saleUnit);
                    if (match) {
                        return false;
                    }
                    return true;
                });
                if (table.items.length < before) {
                    if (!table.items.length && typeof clearPosCartDiscount === 'function') clearPosCartDiscount(table);
                    lastTableState = "";
                    if (typeof saveActivePosTabSnapshot === 'function') saveActivePosTabSnapshot();
                    if (typeof onCartChanged === 'function') onCartChanged({ fast: true, productId: prodId, saleUnit: saleUnit, removed: true });
                }
            } finally {
                window._posCartOperationLock = false;
                if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('pos', { clear: false, delay: 30 });
            }
        }

        async function cancelOrder() {
            if(!checkPermission('pos_access', "هەلوەشاندنا وەسڵێ (Clear Cart)")) return;
            if (window._posCartOperationLock) return;

            const table = db.tables.find(t => t.id === activeTableId);
            if(!table || table.items.length === 0) return;
            var itemCount = table.items.length;
            var ok = await (typeof window.posConfirm === 'function' ? window.posConfirm({
                title: typeof t === 'function' ? t('confirm_clear_cart_title') : 'ژێبرنا سەبەتە',
                message: (typeof t === 'function' ? t('confirm_clear_cart') : 'هەموو ئایتمەکان دەسڕدرێنەوە.') + (itemCount > 0 ? '\n(' + itemCount + ' ئایتم)' : ''),
                confirmText: typeof t === 'function' ? t('confirm_clear_cart_btn') : 'بەڵێ، ژێببە',
                cancelText: typeof t === 'function' ? t('btn_cancel') : 'پاشگەزبوون',
                icon: 'fa-trash-alt',
                tone: 'danger'
            }) : Promise.resolve(confirm(typeof t === 'function' ? t('confirm_clear_cart') : "ژێبرنا داواکاریێ؟")));
            if (!ok) return;

            window._posCartOperationLock = true;
            try {
                logSecurityEvent('void_order', `هەلوەشاندنا تەواوی فرۆشتن — مێز: ${table.name} (کۆ: ${table.items.reduce((a,b)=>a+b.price,0)})`);
                table.items = [];
                if (typeof clearPosCartDiscount === 'function') clearPosCartDiscount(table);
                if (window._posEditingSale) {
                    window._posEditingSale = null;
                    if (typeof updatePOSModeUI === 'function') updatePOSModeUI();
                }
                lastTableState = "";
                if (typeof onCartChanged === 'function') onCartChanged();
                var posView = document.getElementById('view-pos');
                if (posView && !posView.classList.contains('active') && typeof nav === 'function') nav('pos');
                var clearMsg = { type: 'clear', timestamp: Date.now(), icon: getSystemIcon() };
                if (window.customerChannel) window.customerChannel.postMessage(clearMsg);
                localStorage.setItem('LAPTOP_DUHOK_POS_display_sync', JSON.stringify(clearMsg));
                var fdClear = new FormData();
                fdClear.append('action', 'update_customer_display');
                fdClear.append('data', JSON.stringify(clearMsg));
                fetch('?action=update_customer_display', { method: 'POST', body: fdClear });
            } finally {
                window._posCartOperationLock = false;
                if (typeof window.focusTxnScannerInput === 'function') window.focusTxnScannerInput('pos', { clear: true, delay: 30 });
            }
        }

        function localizePrintHtml(htmlContent) {
            if (typeof htmlContent !== 'string' || !htmlContent) return htmlContent;
            if (htmlContent.indexOf('receipt-i18n-final') !== -1 || htmlContent.indexOf('data-skip-print-localize="1"') !== -1) {
                return htmlContent;
            }
            var lang = getCurrentLanguage();
            var tr = {
                date: { ar: 'التاريخ', badini: 'بەروار' },
                receipt: { ar: 'الإيصال', badini: 'وەسڵ' },
                target: { ar: 'الجهة', badini: 'ئامانج' },
                type: { ar: 'النوع', badini: 'جۆر' },
                ref: { ar: 'المرجع', badini: 'ڕیفرەنس' },
                cashier: { ar: 'الكاشير', badini: 'کاشێر' },
                item: { ar: 'الصنف', badini: 'ئایتم' },
                qty: { ar: 'الكمية', badini: 'ژمارە' },
                price: { ar: 'السعر', badini: 'نرخ' },
                total: { ar: 'المجموع', badini: 'کۆم' },
                subtotal: { ar: 'المجموع الفرعي', badini: 'کۆیا گشتی' },
                discount: { ar: 'الخصم', badini: 'داشکاندن' },
                netTotal: { ar: 'الصافي', badini: 'کۆی سافی' },
                grandTotal: { ar: 'المجموع الإجمالي', badini: 'کۆیا گشتی' },
                cash: { ar: 'نقد', badini: 'نەقد' },
                debtAdded: { ar: 'الدين المضاف', badini: 'قەرزی تێکەفتی' },
                previousDebt: { ar: 'الدين السابق', badini: 'قەرزی پێشوو' },
                outstanding: { ar: 'إجمالي الدين المتبقي', badini: 'قەرزی دواکەوت' },
                saleReturn: { ar: 'إرجاع مبيعات', badini: 'زڤڕاندن' },
                refund: { ar: 'استرداد المبلغ', badini: 'زڤڕاندن پارە' },
                reason: { ar: 'السبب', badini: 'ئەگەر' },
                thanksVisit: { ar: 'شكراً لزيارتكم!', badini: 'سوپاس بۆ سەردانا هەوە!' }
            };
            var pick = function(k) { return (tr[k] && tr[k][lang === 'ar' ? 'ar' : 'badini']) || ''; };

            var out = htmlContent;
            var rules = [
                { patterns: ['Date:', 'بەروار:'], to: pick('date') + ':' },
                { patterns: ['Receipt:', 'وەسڵ:'], to: pick('receipt') + ':' },
                { patterns: ['Target:', 'ئامانج:'], to: pick('target') + ':' },
                { patterns: ['Type:', 'جۆر:'], to: pick('type') + ':' },
                { patterns: ['Ref:', 'ڕیفرەنس:'], to: pick('ref') + ':' },
                { patterns: ['Cashier:', 'کاشێر:'], to: pick('cashier') + ':' },
                { patterns: ['Supplier:', 'مۆرد:'], to: (typeof t === 'function' ? t('print_supplier') : (lang === 'ar' ? 'المورد' : 'مۆرد')) + ':' },
                { patterns: ['>Item<', '>ئایتم<', '>الصنف<'], to: '>' + pick('item') + '<' },
                { patterns: ['>Qty<', '>ژمارە<', '>الكمية<'], to: '>' + pick('qty') + '<' },
                { patterns: ['>Price<', '>نرخ<', '>السعر<'], to: '>' + pick('price') + '<' },
                { patterns: ['>Total<', '>کۆم<', '>المجموع<'], to: '>' + pick('total') + '<' },
                { patterns: ['Grand Total', 'کۆیا گشتی'], to: pick('grandTotal') },
                { patterns: ['Sub Total', 'Subtotal', 'کۆیا گشتی'], to: (typeof t === 'function' ? t('print_subtotal') : pick('subtotal')) },
                { patterns: ['Cash', 'نەقد'], to: pick('cash') },
                { patterns: ['Bank/Card', 'Bank / Card'], to: (typeof t === 'function' ? t('print_bank_card') : (lang === 'ar' ? 'بنك/بطاقة' : 'بانک/کارت')) },
                { patterns: ['Printed by', 'Printed By'], to: (typeof t === 'function' ? t('print_printed_by') : (lang === 'ar' ? 'تمت الطباعة بواسطة' : 'چاپکرا لەلایەن')) },
                { patterns: ['Inv Reference', 'Invoice Ref', 'Reference'], to: (typeof t === 'function' ? t('print_reference') : (lang === 'ar' ? 'المرجع' : 'ڕیفرەنس')) },
                { patterns: ['Payment Receipt', 'وەرگرتنا پارەی'], to: (typeof t === 'function' ? t('print_payment_receipt') : (lang === 'ar' ? 'إيصال دفع' : 'وەرگرتنا پارەی')) },
                { patterns: ['COPY - REPRINT'], to: (typeof t === 'function' ? t('print_copy_reprint') : (lang === 'ar' ? 'نسخة - إعادة طباعة' : 'COPY - REPRINT')) },
                { patterns: ['Debt Added', 'قەرزی تێکەفتی'], to: pick('debtAdded') },
                { patterns: ['Previous Debt', 'قەرزی پێشوو'], to: pick('previousDebt') },
                { patterns: ['Total Outstanding', 'قەرزی دواکەوت'], to: pick('outstanding') },
                { patterns: ['SALE RETURN', 'زڤڕاندن'], to: pick('saleReturn') },
                { patterns: ['REFUND', 'زڤڕاندن پارە'], to: pick('refund') },
                { patterns: ['Reason:', 'ئەگەر:'], to: pick('reason') + ':' },
                { patterns: ['Thank you for your visit!', 'سوپاس بۆ سەردانا مە بکەنەڤە'], to: pick('thanksVisit') },
                { patterns: ['قەرز + نەقد / Bank', 'دين + نقد / بنك'], to: (lang === 'ar' ? 'دين + نقد / بنك' : 'قەرز + نەقد / Bank') }
            ];

            rules.forEach(function(rule) {
                rule.patterns.forEach(function(p) {
                    out = out.split(p).join(rule.to);
                });
            });
            // Final strict pass: unify any remaining translated labels in print templates.
            var strictPairs = [
                ['بەروار', 'التاريخ'],
                ['وەسڵ', 'الإيصال'],
                ['کاشێر', 'الكاشير'],
                ['ئایتم', 'الصنف'],
                ['ژمارە', 'الكمية'],
                ['نرخ', 'السعر'],
                ['کۆم', 'المجموع'],
                ['قەرز', 'دين'],
                ['نەقد', 'نقد'],
                ['داشکاندن', 'الخصم'],
                ['کۆی سافی', 'الصافي'],
                ['کۆیا گشتی', 'المجموع الإجمالي']
            ];
            out = replaceWithUiLangMap(out, buildUiLangMap(lang, strictPairs));
            out = stripMixedSuffixes(out, lang);
            return out;
        }

